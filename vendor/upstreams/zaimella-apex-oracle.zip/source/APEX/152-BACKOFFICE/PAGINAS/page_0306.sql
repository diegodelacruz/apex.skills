prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>152
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 152 - Backoffice
--
-- Application Export:
--   Application:     152
--   Name:            Backoffice
--   Date and Time:   13:57 Tuesday July 7, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 306
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_00306
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>306);
end;
/
prompt --application/pages/page_00306
begin
wwv_flow_imp_page.create_page(
 p_id=>306
,p_name=>'Dlg paso RPA'
,p_page_mode=>'MODAL'
,p_step_title=>'Paso RPA'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(405885183218277832)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'800'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152306010)
,p_plug_name=>'Paso RPA'
,p_region_name=>'frm_cntr_paso'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(406400168555332734)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152306020)
,p_plug_name=>'Botones'
,p_region_name=>'botones_cntr_paso'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(406400595196332734)
,p_plug_display_sequence=>90
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152306021)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(152306020)
,p_button_name=>'CANCELAR'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970980751278001)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.navigation.dialog.cancel(true);'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152306022)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(152306020)
,p_button_name=>'GUARDAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970980751278001)
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152306030)
,p_name=>'P306_ID_PASO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(152306010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152306031)
,p_name=>'P306_ID_DOCUMENTO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(152306010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152306032)
,p_name=>'P306_ORDEN'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(152306010)
,p_prompt=>'Orden'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>10
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152306033)
,p_name=>'P306_INSTRUCCION'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(152306010)
,p_prompt=>'Instruccion'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>100
,p_cMaxlength=>2000
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152306034)
,p_name=>'P306_SELECTOR_ELEMENTO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(152306010)
,p_prompt=>'URL o selector'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>100
,p_cMaxlength=>2000
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152306035)
,p_name=>'P306_VALOR_ENTRADA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(152306010)
,p_prompt=>'Valor fijo (opcional)'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>100
,p_cMaxlength=>1000
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152306041)
,p_name=>'P306_ORIGEN_VALOR'
,p_item_sequence=>65
,p_item_plug_id=>wwv_flow_imp.id(152306010)
,p_prompt=>'Valor de entrada'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Valor fijo;,Identificacion (persona o empresa);IDENTIFICACION,Nombres (persona);NOMBRES,Correo (persona);CORREO,Razon social (empresa);RAZON_SOCIAL,Nombre comercial (empresa);NOMBRE_COMERCIAL'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152306036)
,p_name=>'P306_TIEMPO_ESPERA_SEG'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(152306010)
,p_prompt=>'Espera (segundos)'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>10
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152306037)
,p_name=>'P306_REQUIERE_INTERVENCION'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(152306010)
,p_prompt=>'Requiere intervencion'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:No;0,Si;1'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152306038)
,p_name=>'P306_DESCRIPCION'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(152306010)
,p_prompt=>'Descripcion'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>100
,p_cHeight=>3
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152306039)
,p_name=>'P306_ESTADO'
,p_is_required=>true
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(152306010)
,p_prompt=>'Estado'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Activo;ACTIVO,Inactivo;INACTIVO'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152306040)
,p_name=>'P306_TIPO_ACCION'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(152306010)
,p_prompt=>'Accion'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Seleccione accion;,Navegar;NAVEGAR,Llenar;LLENAR,Click;CLICK,Esperar;ESPERAR,Descargar;DESCARGAR,Capturar pantalla;CAPTURAR'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152306051)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Guardar paso'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    data.pk_cntr_configuracion.guardar_paso(',
'        p_id_paso => :P306_ID_PASO,',
'        p_id_documento => :P306_ID_DOCUMENTO,',
'        p_orden => :P306_ORDEN,',
'        p_tipo_accion => :P306_TIPO_ACCION,',
'        p_selector_elemento => :P306_SELECTOR_ELEMENTO,',
'        p_valor_entrada => :P306_VALOR_ENTRADA,',
'        p_tiempo_espera_seg => :P306_TIEMPO_ESPERA_SEG,',
'        p_requiere_intervencion => :P306_REQUIERE_INTERVENCION,',
'        p_descripcion => :P306_DESCRIPCION,',
'        p_estado => :P306_ESTADO,',
'        p_origen_valor => :P306_ORIGEN_VALOR',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(152306022)
,p_process_success_message=>'Paso guardado correctamente.'
,p_internal_uid=>152306051
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152306050)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar paso'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    if :P306_ID_PASO is null then',
'        :P306_REQUIERE_INTERVENCION := nvl(:P306_REQUIERE_INTERVENCION, 0);',
'        :P306_ESTADO := nvl(:P306_ESTADO, ''ACTIVO'');',
'        if :P306_ORDEN is null and :P306_ID_DOCUMENTO is not null then',
'            select nvl(max(orden),0) + 1 into :P306_ORDEN from data.t_cntr_documento_pasos where id_documento = :P306_ID_DOCUMENTO;',
'        end if;',
'    else',
'        select id_documento, orden, instruccion, tipo_accion, selector_elemento, valor_entrada, origen_valor, tiempo_espera_seg, requiere_intervencion, descripcion, estado',
'          into :P306_ID_DOCUMENTO, :P306_ORDEN, :P306_INSTRUCCION, :P306_TIPO_ACCION, :P306_SELECTOR_ELEMENTO, :P306_VALOR_ENTRADA, :P306_ORIGEN_VALOR, :P306_TIEMPO_ESPERA_SEG, :P306_REQUIERE_INTERVENCION, :P306_DESCRIPCION, :P306_ESTADO',
'          from data.t_cntr_documento_pasos where id_paso = :P306_ID_PASO;',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>152306050
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
