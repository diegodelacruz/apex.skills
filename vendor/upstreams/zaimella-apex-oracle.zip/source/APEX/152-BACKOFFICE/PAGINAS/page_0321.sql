prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>152
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 152 - Backoffice
--
-- Application Export:
--   Application:     152
--   Name:            Backoffice
--   Date and Time:   14:18 Wednesday July 15, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 321
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_00321
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>321);
end;
/
prompt --application/pages/page_00321
begin
wwv_flow_imp_page.create_page(
 p_id=>321
,p_name=>'Dlg evidencias y versiones'
,p_page_mode=>'MODAL'
,p_step_title=>'Evidencias y versiones'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(405885183218277832)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'960'
,p_dialog_chained=>'N'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152321010)
,p_plug_name=>'Historial documental'
,p_region_name=>'ir_cntr_evidencia_versiones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(405917550338277892)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.numeroarchivo,',
'       d.nombre_documento documento,',
'       v.tipo_sujeto,',
'       case v.tipo_sujeto',
'           when ''PERSONA'' then per.identificacion || '' - '' || per.nombres',
'           when ''EMPRESA'' then emp.ruc || '' - '' || emp.razon_social',
'       end sujeto,',
'       v.version,',
'       v.filename,',
'       v.mimetype,',
'       v.estado,',
'       v.fecha,',
'       v.usuario_registro,',
'       v.observacion',
'  from data.vt_cntr_evidencia_versiones v',
'  join data.t_cntr_documentos d',
'    on d.id_documento = v.id_documento',
'  left join data.t_cntr_personas per',
'    on v.tipo_sujeto = ''PERSONA''',
'   and per.id_persona = v.id_sujeto',
'  left join data.t_cntr_empresas emp',
'    on v.tipo_sujeto = ''EMPRESA''',
'   and emp.id_empresa = v.id_sujeto',
' where (v.id_evidencia = :P321_ID_EVIDENCIA',
'        or (:P321_ID_EVIDENCIA is null',
'            and :P321_TIPO_SUJETO is not null',
'            and :P321_ID_SUJETO is not null',
'            and v.tipo_sujeto = upper(trim(:P321_TIPO_SUJETO))',
'            and v.id_sujeto = :P321_ID_SUJETO))',
'   and data.pk_cntr_rpa.puede_ver_evidencia(',
'           p_id_evidencia => v.id_evidencia,',
'           p_usuario => :APP_USER,',
'           p_compania => :G_COMPANIA,',
'           p_id_ejecucion => :P321_ID_EJECUCION,',
'           p_id_configuracion => :P321_ID_CONFIGURACION,',
'           p_mostrar_todos => nvl(:P321_MOSTRAR_TODOS, ''N'')) = 1',
' order by case when v.estado = ''ACTIVO'' then 0 else 1 end,',
'          d.nombre_documento,',
'          v.version desc'))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(152321020)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>152321020
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152321021)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Descargar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment:<span class="fa fa-download" title="Descargar version" aria-hidden="true"></span><span class="u-VisuallyHidden">Descargar version</span>:FILES'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152321022)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152321023)
,p_db_column_name=>'TIPO_SUJETO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tipo sujeto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152321024)
,p_db_column_name=>'SUJETO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Sujeto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152321025)
,p_db_column_name=>'VERSION'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Version'
,p_column_type=>'NUMBER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152321026)
,p_db_column_name=>'FILENAME'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Archivo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152321027)
,p_db_column_name=>'MIMETYPE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Tipo MIME'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152321028)
,p_db_column_name=>'ESTADO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152321029)
,p_db_column_name=>'FECHA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152321030)
,p_db_column_name=>'USUARIO_REGISTRO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152321031)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(306025418124520260)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3060255'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMEROARCHIVO:DOCUMENTO:TIPO_SUJETO:SUJETO:VERSION:FILENAME:MIMETYPE:ESTADO:FECHA:USUARIO_REGISTRO:OBSERVACION'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152321100)
,p_plug_name=>'Botones'
,p_region_name=>'botones_321'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(406400595196332734)
,p_plug_display_sequence=>90
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152321301)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(152321100)
,p_button_name=>'CERRAR'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970980751278001)
,p_button_image_alt=>'Cerrar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.navigation.dialog.cancel(true);'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152321201)
,p_name=>'P321_ID_EVIDENCIA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(152321010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152321202)
,p_name=>'P321_ID_EJECUCION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(152321010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152321203)
,p_name=>'P321_TIPO_SUJETO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(152321010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152321204)
,p_name=>'P321_ID_SUJETO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(152321010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152321205)
,p_name=>'P321_ID_CONFIGURACION'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(152321010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152321206)
,p_name=>'P321_MOSTRAR_TODOS'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(152321010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
