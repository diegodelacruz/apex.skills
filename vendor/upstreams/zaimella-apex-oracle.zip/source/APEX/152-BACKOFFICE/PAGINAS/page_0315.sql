prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>152
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 152 - Backoffice
--
-- Application Export:
--   Application:     152
--   Name:            Backoffice
--   Date and Time:   14:17 Friday August 14, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 315
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_00315
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>315);
end;
/
prompt --application/pages/page_00315
begin
wwv_flow_imp_page.create_page(
 p_id=>315
,p_name=>'Configuracion de captura'
,p_step_title=>'Configuracion de captura'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>'.a-PopupLOV-results, .a-PopupLOV-resultsContainer, .ui-autocomplete { max-height: 360px !important; overflow-y: auto !important; } #ir_cntr_documentos_config .t-Region-header, #ir_cntr_sujetos_config .t-Region-header, #ir_cntr_documentos_config .t-Re'
||'gion-title, #ir_cntr_sujetos_config .t-Region-title { display: block !important; }'
,p_page_template_options=>'#DEFAULT#'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152315010)
,p_plug_name=>'Datos de la configuracion'
,p_region_name=>'frm_cntr_configuracion'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(406400168555332734)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152315030)
,p_plug_name=>'Documentos seleccionados'
,p_region_name=>'ir_cntr_documentos_config'
,p_parent_plug_id=>wwv_flow_imp.id(152315090)
,p_region_template_options=>'#DEFAULT#:t-Region--showTitle'
,p_plug_template=>wwv_flow_imp.id(406399382902332734)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>'select d.nombre_documento documento,p.nombre_portal portal,cd.estado,case when cd.estado=''ACTIVO'' then ''fa fa-toggle-on'' else ''fa fa-toggle-off'' end cambiar_icono,case when cd.estado=''ACTIVO'' then ''Inactivar documento'' else ''Activar documento'' end ca'
||'mbiar_titulo,apex_page.get_url(p_page=>315,p_request=>''CAMBIAR_DOCUMENTO'',p_items=>''P315_ID_CONFIGURACION,P315_COMPANIA,P315_ID_DOCUMENTO,P315_ESTADO_ASOCIACION'',p_values=>:P315_ID_CONFIGURACION||'',''||:P315_COMPANIA||'',''||cd.id_documento||'',''||case w'
||'hen cd.estado=''ACTIVO'' then ''INACTIVO'' else ''ACTIVO'' end) cambiar_estado,apex_page.get_url(p_page=>315,p_request=>''ELIMINAR_DOCUMENTO'',p_items=>''P315_ID_CONFIGURACION,P315_COMPANIA,P315_ID_DOCUMENTO'',p_values=>:P315_ID_CONFIGURACION||'',''||:P315_COMPA'
||'NIA||'',''||cd.id_documento) eliminar from data.t_cntr_config_documentos cd join data.t_cntr_documentos d on d.id_documento=cd.id_documento join data.t_cntr_portales p on p.id_portal=d.id_portal where cd.id_configuracion=:P315_ID_CONFIGURACION and cd.e'
||'stado in (''ACTIVO'',''INACTIVO'') order by d.nombre_documento'
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(152315031)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>152315031
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152315032)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152315033)
,p_db_column_name=>'PORTAL'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Portal'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152315034)
,p_db_column_name=>'ESTADO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152315035)
,p_db_column_name=>'CAMBIAR_ESTADO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Estado'
,p_column_link=>'#CAMBIAR_ESTADO#'
,p_column_linktext=>'<span class="#CAMBIAR_ICONO#" title="#CAMBIAR_TITULO#"></span><span class="u-VisuallyHidden">#CAMBIAR_TITULO#</span>'
,p_column_link_attr=>'class="t-Button t-Button--noLabel t-Button--icon t-Button--link"'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152315036)
,p_db_column_name=>'CAMBIAR_ICONO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Icono estado'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152315037)
,p_db_column_name=>'CAMBIAR_TITULO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Titulo estado'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152315038)
,p_db_column_name=>'ELIMINAR'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Eliminar'
,p_column_link=>'#ELIMINAR#'
,p_column_linktext=>'<span class="fa fa-trash-o" title="Eliminar documento"></span><span class="u-VisuallyHidden">Eliminar documento</span>'
,p_column_link_attr=>unistr('class="t-Button t-Button--noLabel t-Button--icon t-Button--link" onclick="return confirm(''\00BFDesea eliminar el documento de la configuraci\00F3n?'');"')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(305057011245816549)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3220532'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENTO:PORTAL:ESTADO:CAMBIAR_ESTADO:CAMBIAR_ICONO:CAMBIAR_TITULO:ELIMINAR'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152315040)
,p_plug_name=>'Sujetos y empresas seleccionados'
,p_region_name=>'ir_cntr_sujetos_config'
,p_parent_plug_id=>wwv_flow_imp.id(152315090)
,p_region_template_options=>'#DEFAULT#:t-Region--showTitle'
,p_plug_template=>wwv_flow_imp.id(406399382902332734)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>'select ''SUJETO'' tipo,p.identificacion||'' - ''||p.nombres detalle,null cantidad_sujetos,null editar,''u-hidden'' editar_class,cs.estado,case when cs.estado=''ACTIVO'' then ''fa fa-toggle-on'' else ''fa fa-toggle-off'' end cambiar_icono,case when cs.estado=''ACT'
||'IVO'' then ''Inactivar sujeto'' else ''Activar sujeto'' end cambiar_titulo,apex_page.get_url(p_page=>315,p_request=>''CAMBIAR_ESTADO_SUJETO'',p_items=>''P315_ID_CONFIGURACION,P315_COMPANIA,P315_ID_SUJETO,P315_TIPO_SUJETO,P315_ESTADO_ASOCIACION'',p_values=>:P315_ID_C'
||'ONFIGURACION||'',''||:P315_COMPANIA||'',''||cs.id_sujeto||'',PERSONA,''||case when cs.estado=''ACTIVO'' then ''INACTIVO'' else ''ACTIVO'' end) cambiar_estado,apex_page.get_url(p_page=>315,p_request=>''ELIMINAR_SUJETO'',p_items=>''P315_ID_CONFIGURACION,P315_COMPANIA'
||',P315_ID_SUJETO,P315_TIPO_SUJETO'',p_values=>:P315_ID_CONFIGURACION||'',''||:P315_COMPANIA||'',''||cs.id_sujeto||'',PERSONA'') eliminar from data.t_cntr_config_sujetos cs join data.t_cntr_personas p on p.id_persona=cs.id_sujeto where cs.id_configuracion=:P3'
||'15_ID_CONFIGURACION and cs.tipo_sujeto=''PERSONA'' and cs.estado in (''ACTIVO'',''INACTIVO'') union all select ''EMPRESA'',e.ruc||'' - ''||e.razon_social,null,null,''u-hidden'',cs.estado,case when cs.estado=''ACTIVO'' then ''fa fa-toggle-on'' else ''fa fa-toggle-off'' end,case when c'
||'s.estado=''ACTIVO'' then ''Inactivar empresa'' else ''Activar empresa'' end,apex_page.get_url(p_page=>315,p_request=>''CAMBIAR_ESTADO_SUJETO'',p_items=>''P315_ID_CONFIGURACION,P315_COMPANIA,P315_ID_SUJETO,P315_TIPO_SUJETO,P315_ESTADO_ASOCIACION'',p_values=>:P315_ID_C'
||'ONFIGURACION||'',''||:P315_COMPANIA||'',''||cs.id_sujeto||'',EMPRESA,''||case when cs.estado=''ACTIVO'' then ''INACTIVO'' else ''ACTIVO'' end),apex_page.get_url(p_page=>315,p_request=>''ELIMINAR_SUJETO'',p_items=>''P315_ID_CONFIGURACION,P315_COMPANIA,P315_ID_SUJETO'
||',P315_TIPO_SUJETO'',p_values=>:P315_ID_CONFIGURACION||'',''||:P315_COMPANIA||'',''||cs.id_sujeto||'',EMPRESA'') from data.t_cntr_config_sujetos cs join data.t_cntr_empresas e on e.id_empresa=cs.id_sujeto where cs.id_configuracion=:P315_ID_CONFIGURACION and '
||'cs.tipo_sujeto=''EMPRESA'' and cs.estado in (''ACTIVO'',''INACTIVO'') union all select ''EMPRESA'',e.ruc||'' - ''||e.razon_social,(select count(*) from data.t_cntr_config_empresa_personas cep where cep.id_config_empresa=ce.id_config_empresa and cep.estado=''ACTIVO''),apex_page.'
||'get_url(p_page=>318,p_items=>''P318_CONFIGURACION,P318_ID_CONFIG_EMPRESA'',p_values=>:P315_ID_CONFIGURACION||'',''||ce.id_config_empresa),'''',ce.estado,case when ce.estado=''ACTIVO'' then ''fa fa-toggle-on'' else ''fa fa-toggle-off'' end,case when ce.estado=''AC'
||'TIVO'' then ''Inactivar empresa'' else ''Activar empresa'' end,apex_page.get_url(p_page=>315,p_request=>''CAMBIAR_EMPRESA'',p_items=>''P315_ID_CONFIGURACION,P315_COMPANIA,P315_ID_CONFIG_EMPRESA,P315_ESTADO_ASOCIACION'',p_values=>:P315_ID_CONFIGURACION||'',''||:'
||'P315_COMPANIA||'',''||ce.id_config_empresa||'',''||case when ce.estado=''ACTIVO'' then ''INACTIVO'' else ''ACTIVO'' end),apex_page.get_url(p_page=>315,p_request=>''ELIMINAR_EMPRESA'',p_items=>''P315_ID_CONFIGURACION,P315_COMPANIA,P315_ID_CONFIG_EMPRESA'',p_values='
||'>:P315_ID_CONFIGURACION||'',''||:P315_COMPANIA||'',''||ce.id_config_empresa) from data.t_cntr_config_empresas ce join data.t_cntr_empresas e on e.id_empresa=ce.id_empresa where ce.id_configuracion=:P315_ID_CONFIGURACION and ce.estado in (''ACTIVO'',''INACTIVO'')'
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(152315041)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>152315041
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152315042)
,p_db_column_name=>'TIPO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152315043)
,p_db_column_name=>'DETALLE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Sujeto o empresa'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152315044)
,p_db_column_name=>'CANTIDAD_SUJETOS'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Sujetos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152315045)
,p_db_column_name=>'EDITAR'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Editar'
,p_column_link=>'#EDITAR#'
,p_column_linktext=>'<span class="fa fa-pencil" title="Editar empresa"></span><span class="u-VisuallyHidden">Editar empresa</span>'
,p_column_link_attr=>'class="t-Button t-Button--noLabel t-Button--icon t-Button--link #EDITAR_CLASS#"'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152315048)
,p_db_column_name=>'ESTADO'
,p_display_order=>50
,p_column_identifier=>'G'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152315049)
,p_db_column_name=>'CAMBIAR_ESTADO'
,p_display_order=>60
,p_column_identifier=>'H'
,p_column_label=>'Estado'
,p_column_link=>'#CAMBIAR_ESTADO#'
,p_column_linktext=>'<span class="#CAMBIAR_ICONO#" title="#CAMBIAR_TITULO#"></span><span class="u-VisuallyHidden">#CAMBIAR_TITULO#</span>'
,p_column_link_attr=>'class="t-Button t-Button--noLabel t-Button--icon t-Button--link"'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152315046)
,p_db_column_name=>'ELIMINAR'
,p_display_order=>70
,p_column_identifier=>'E'
,p_column_label=>'Eliminar'
,p_column_link=>'#ELIMINAR#'
,p_column_linktext=>'<span class="fa fa-trash-o" title="Eliminar registro"></span><span class="u-VisuallyHidden">Eliminar registro</span>'
,p_column_link_attr=>unistr('class="t-Button t-Button--noLabel t-Button--icon t-Button--link" onclick="return confirm(''\00BFDesea eliminar el registro de la configuraci\00F3n?'');"')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152315047)
,p_db_column_name=>'EDITAR_CLASS'
,p_display_order=>80
,p_column_identifier=>'F'
,p_column_label=>'Clase editar'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152315051)
,p_db_column_name=>'CAMBIAR_ICONO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Icono estado'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152315052)
,p_db_column_name=>'CAMBIAR_TITULO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Titulo estado'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(305057688867816553)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3220536'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TIPO:DETALLE:CANTIDAD_SUJETOS:EDITAR:ESTADO:CAMBIAR_ESTADO:ELIMINAR:EDITAR_CLASS:CAMBIAR_ICONO:CAMBIAR_TITULO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152315090)
,p_plug_name=>'Configuracion documental'
,p_region_name=>'tabs_cntr_configuracion'
,p_parent_plug_id=>wwv_flow_imp.id(152315010)
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_imp.id(406400168555332734)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2('display_region_icons','N','include_show_all','N','rds_mode','STANDARD','remember_selection','SESSION')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152315091)
,p_plug_name=>'Usuarios compartidos'
,p_region_name=>'ir_cntr_usuarios_compartidos'
,p_parent_plug_id=>wwv_flow_imp.id(152315090)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(406399382902332734)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>'select usuario_apex usuario, fecha_creacion, apex_page.get_url(p_page=>315,p_request=>''ELIMINAR_USUARIO_COMPARTIDO'',p_items=>''P315_ID_CONFIGURACION,P315_USUARIO_A_REVOCAR'',p_values=>:P315_ID_CONFIGURACION||'',''||usuario_apex) eliminar from data.t_cntr_config_usuarios where id_configuracion=:P315_ID_CONFIGURACION order by usuario_apex'
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(152315092)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_show_detail_link=>'N'
,p_owner=>'JBALCAZAR'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152315093)
,p_db_column_name=>'USUARIO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Usuario compartido'
,p_column_type=>'STRING'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152315094)
,p_db_column_name=>'FECHA_CREACION'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fecha de asignacion'
,p_column_type=>'DATE'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152315095)
,p_db_column_name=>'ELIMINAR'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Eliminar'
,p_column_link=>'#ELIMINAR#'
,p_column_linktext=>'<span class="fa fa-trash-o" aria-hidden="true"></span><span class="u-VisuallyHidden">Eliminar usuario compartido</span>'
,p_column_link_attr=>'class="t-Button t-Button--noLabel t-Button--icon t-Button--link"'
,p_column_type=>'STRING'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(152315096)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3220596'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'USUARIO:FECHA_CREACION:ELIMINAR'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152315020)
,p_plug_name=>'Barra de acciones'
,p_region_name=>'barra_cntr_configuracion'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(406399719584332734)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152315050)
,p_plug_name=>'Configuracion de captura'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_imp.id(406400910855332735)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(405872152752277696)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(405971733953278003)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152315061)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(152315020)
,p_button_name=>'VOLVER'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_image_alt=>'Volver'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:314:&SESSION.::&DEBUG.:314::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152315081)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(152315091)
,p_button_name=>'COMPARTIR_USUARIO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_image_alt=>'Agregar usuario'
,p_button_redirect_url=>'f?p=&APP_ID.:325:&SESSION.::&DEBUG.:325:P325_CONFIGURACION:&P315_ID_CONFIGURACION.'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_icon_css_classes=>'fa-share-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152315062)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(152315020)
,p_button_name=>'GUARDAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152315063)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(152315030)
,p_button_name=>'AGREGAR_DOCUMENTO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Agregar documento'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:316:&SESSION.::&DEBUG.:316:P316_CONFIGURACION:&P315_ID_CONFIGURACION.'
,p_button_condition=>'P315_ID_CONFIGURACION'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152315064)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(152315040)
,p_button_name=>'AGREGAR_SUJETO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_image_alt=>'Agregar sujeto'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:317:&SESSION.::&DEBUG.:317:P317_CONFIGURACION:&P315_ID_CONFIGURACION.'
,p_button_condition=>'P315_ID_CONFIGURACION'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-user-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152315065)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(152315040)
,p_button_name=>'AGREGAR_EMPRESA'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_image_alt=>'Agregar empresa'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:318:&SESSION.::&DEBUG.:318:P318_CONFIGURACION:&P315_ID_CONFIGURACION.'
,p_button_condition=>'P315_ID_CONFIGURACION'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-building-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152315068)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(152315040)
,p_button_name=>'CARGAR_SUJETOS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_image_alt=>'Subir sujetos'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:312:&SESSION.::&DEBUG.:RP,312:P312_ID_CONFIGURACION:&P315_ID_CONFIGURACION.'
,p_button_condition=>'P315_ID_CONFIGURACION'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-upload'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152315069)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(152315040)
,p_button_name=>'CARGAR_EMPRESA_SUJETOS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_image_alt=>'Subir empresas y sujetos'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:313:&SESSION.::&DEBUG.:RP,313:P313_ID_CONFIGURACION:&P315_ID_CONFIGURACION.'
,p_button_condition=>'P315_ID_CONFIGURACION'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-upload'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152315070)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(152315040)
,p_button_name=>'DESCARGAR_FORMATO_SUJETOS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_image_alt=>'Descargar formato de sujetos'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:312:&SESSION.:DESCARGAR_FORMATO:&DEBUG.:RP,312:P312_ID_CONFIGURACION:&P315_ID_CONFIGURACION.'
,p_button_condition=>'P315_ID_CONFIGURACION'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-download'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152315071)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(152315040)
,p_button_name=>'DESCARGAR_FORMATO_EMPRESA_SUJETOS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_image_alt=>'Descargar formato de empresas y sujetos'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:313:&SESSION.:DESCARGAR_FORMATO:&DEBUG.:RP,313:P313_ID_CONFIGURACION:&P315_ID_CONFIGURACION.'
,p_button_condition=>'P315_ID_CONFIGURACION'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-download'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152315201)
,p_name=>'P315_ID_CONFIGURACION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(152315010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152315202)
,p_name=>'P315_COMPANIA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(152315010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152315203)
,p_name=>'P315_NOMBRE'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(152315010)
,p_prompt=>'Nombre'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>50
,p_cMaxlength=>200
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152315204)
,p_name=>'P315_ESTADO'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(152315010)
,p_prompt=>'Estado'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Activo;ACTIVO,Inactivo;INACTIVO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152315205)
,p_name=>'P315_ID_DOCUMENTO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(152315010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152315206)
,p_name=>'P315_ID_SUJETO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(152315010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152315207)
,p_name=>'P315_ID_CONFIG_EMPRESA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(152315010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152315208)
,p_name=>'P315_ESTADO_ASOCIACION'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(152315010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152315209)
,p_name=>'P315_TIPO_SUJETO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(152315010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152315210)
,p_name=>'P315_USUARIO_COMPARTIDO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(152315091)
,p_display_as=>'NATIVE_HIDDEN'
,p_lov=>'select nombreusuario d,nombreusuario r from data.vt_corp_usuario u where nvl(u.estado,0)=1 and upper(u.departamento)=(select upper(departamento) from data.vt_corp_usuario where upper(nombreusuario)=upper(:APP_USER) and rownum=1) and upper(u.nombreusu'
||'ario)<>upper(:APP_USER) and not exists (select 1 from data.t_cntr_config_usuarios cu where cu.id_configuracion=:P315_ID_CONFIGURACION and upper(cu.usuario_apex)=upper(u.nombreusuario)) order by 1'
,p_lov_display_extra=>'NO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152315211)
,p_name=>'P315_USUARIO_A_REVOCAR'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(152315010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(152315700)
,p_name=>'Refrescar tablas al cerrar dialogo'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(152315701)
,p_event_id=>wwv_flow_imp.id(152315700)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Refrescar documentos'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(152315030)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(152315702)
,p_event_id=>wwv_flow_imp.id(152315700)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Refrescar sujetos'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(152315040)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(152315703)
,p_event_id=>wwv_flow_imp.id(152315700)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'Refrescar usuarios compartidos'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(152315091)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152315502)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Guardar configuracion'
,p_process_sql_clob=>'begin data.pk_cntr_configuracion.guardar_configuracion(:P315_ID_CONFIGURACION,:P315_COMPANIA,:P315_NOMBRE,:P315_ESTADO); commit; end;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(152315062)
,p_process_success_message=>'Configuracion guardada correctamente.'
,p_internal_uid=>152315502
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152315504)
,p_process_sequence=>25
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Compartir configuracion'
,p_process_sql_clob=>'begin data.pk_cntr_configuracion.compartir_configuracion(:P315_ID_CONFIGURACION,:P315_USUARIO_COMPARTIDO); commit; end;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(152315081)
,p_process_success_message=>'Usuario agregado a la configuracion compartida.'
,p_internal_uid=>152315504
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152315501)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar configuracion'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
':P315_COMPANIA:=nvl(:P315_COMPANIA,:G_COMPANIA);',
'if :P315_COMPANIA is null then raise_application_error(-20070,''Seleccione una compania antes de configurar la captura.''); end if;',
'if :P315_ID_CONFIGURACION is null then :P315_ESTADO:=''INACTIVO''; else select nombre,estado into :P315_NOMBRE,:P315_ESTADO from data.vt_cntr_configuraciones where id_configuracion=:P315_ID_CONFIGURACION and compania=:P315_COMPANIA; end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>152315501
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152315503)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Gestionar asociacion'
,p_process_sql_clob=>'begin case :REQUEST when ''CAMBIAR_DOCUMENTO'' then data.pk_cntr_configuracion.cambiar_estado_config_documento(:P315_ID_CONFIGURACION,:P315_ID_DOCUMENTO,:P315_ESTADO_ASOCIACION); when ''CAMBIAR_ESTADO_SUJETO'' then data.pk_cntr_configuracion.cambiar_estado_conf'
||'ig_sujeto(:P315_ID_CONFIGURACION,:P315_ID_SUJETO,:P315_ESTADO_ASOCIACION,:P315_TIPO_SUJETO); when ''CAMBIAR_ESTADO_SUJETO'' then data.pk_cntr_configuracion.cambiar_estado_config_sujeto(:P315_ID_CONFIGURACION,:P315_ID_SUJETO,:P315_ESTADO_ASOCIACION,:P315_TIPO_SUJETO); when ''CAMBIAR_EMPRESA'' then data.pk_cntr_configuracion.cambiar_estado_config_empresa(:P315_ID_CONFIGURACION,:P315_ID_CONFIG_EMPRESA,:P315_ESTADO_ASOCIACION);'
||' when ''ELIMINAR_DOCUMENTO'' then data.pk_cntr_configuracion.eliminar_config_documento(:P315_ID_CONFIGURACION,:P315_ID_DOCUMENTO); when ''ELIMINAR_SUJETO'' then data.pk_cntr_configuracion.eliminar_config_sujeto(:P315_ID_CONFIGURACION,:P315_ID_SUJETO,:P31'
||'5_TIPO_SUJETO); when ''ELIMINAR_EMPRESA'' then data.pk_cntr_configuracion.eliminar_config_empresa(:P315_ID_CONFIGURACION,:P315_ID_CONFIG_EMPRESA); when ''ELIMINAR_USUARIO_COMPARTIDO'' then data.pk_cntr_configuracion.eliminar_usuario_compartido(:P315_ID_CONFIGURACION,:P315_USUARIO_A_REVOCAR); end case; commit; end;'
,p_process_clob_language=>'PLSQL'
,p_process_when=>'CAMBIAR_DOCUMENTO,CAMBIAR_ESTADO_SUJETO,CAMBIAR_EMPRESA,ELIMINAR_DOCUMENTO,ELIMINAR_SUJETO,ELIMINAR_EMPRESA,ELIMINAR_USUARIO_COMPARTIDO'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>152315503
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152315506)
,p_process_sequence=>25
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cambiar estado de sujeto'
,p_process_sql_clob=>'begin data.pk_cntr_configuracion.cambiar_estado_config_sujeto(:P315_ID_CONFIGURACION,:P315_ID_SUJETO,:P315_ESTADO_ASOCIACION,:P315_TIPO_SUJETO); commit; end;'
,p_process_clob_language=>'PLSQL'
,p_process_when=>'CAMBIAR_ESTADO_SUJETO'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>152315506
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
