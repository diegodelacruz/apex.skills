prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>152
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 152 - Backoffice
--
-- Application Export:
--   Application:     152
--   Name:            Backoffice
--   Date and Time:   13:57 Tuesday July 7, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 302
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_00302
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>302);
end;
/
prompt --application/pages/page_00302
begin
wwv_flow_imp_page.create_page(
 p_id=>302
,p_name=>'Dlg portal'
,p_page_mode=>'MODAL'
,p_step_title=>'Portal'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(405885183218277832)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'720'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152302010)
,p_plug_name=>'Portal'
,p_region_name=>'frm_cntr_portal'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(406400168555332734)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152302020)
,p_plug_name=>'Botones'
,p_region_name=>'botones_cntr_portal'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(406400595196332734)
,p_plug_display_sequence=>90
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152302021)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(152302020)
,p_button_name=>'CANCELAR'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970980751278001)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.navigation.dialog.cancel(true);'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152302022)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(152302020)
,p_button_name=>'GUARDAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970980751278001)
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152302030)
,p_name=>'P302_ID_PORTAL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(152302010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152302031)
,p_name=>'P302_COMPANIA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(152302010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152302032)
,p_name=>'P302_NOMBRE_PORTAL'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(152302010)
,p_prompt=>'Portal'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_cMaxlength=>200
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152302033)
,p_name=>'P302_URL_BASE'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(152302010)
,p_prompt=>'URL base'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>100
,p_cMaxlength=>1000
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152302034)
,p_name=>'P302_DESCRIPCION'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(152302010)
,p_prompt=>'Descripcion'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>100
,p_cHeight=>3
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152302035)
,p_name=>'P302_REQUIERE_CAPTCHA'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(152302010)
,p_prompt=>'Requiere captcha'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:No;0,Si;1'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152302036)
,p_name=>'P302_REQUIERE_LOGIN'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(152302010)
,p_prompt=>'Requiere login'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:No;0,Si;1'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152302038)
,p_name=>'P302_ESTADO'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(152302010)
,p_prompt=>'Estado'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Activo;ACTIVO,Inactivo;INACTIVO,No verificable;NO_VERIFICABLE'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152302051)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Guardar portal'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    data.pk_cntr_configuracion.guardar_portal(',
'        p_id_portal => :P302_ID_PORTAL,',
'        p_compania => :P302_COMPANIA,',
'        p_nombre_portal => :P302_NOMBRE_PORTAL,',
'        p_url_base => :P302_URL_BASE,',
'        p_descripcion => :P302_DESCRIPCION,',
'        p_requiere_captcha => :P302_REQUIERE_CAPTCHA,',
'        p_requiere_login => :P302_REQUIERE_LOGIN,',
'        p_estado => :P302_ESTADO',
'    );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(152302022)
,p_process_success_message=>'Portal guardado correctamente.'
,p_internal_uid=>152302051
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152302052)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Cerrar dialogo'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(152302022)
,p_internal_uid=>152302052
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152302050)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar portal'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    :P302_COMPANIA := nvl(:P302_COMPANIA, nvl(:G_COMPANIA, ''00001''));',
'    if :P302_ID_PORTAL is null then',
'        :P302_REQUIERE_CAPTCHA := nvl(:P302_REQUIERE_CAPTCHA, 0);',
'        :P302_REQUIERE_LOGIN := nvl(:P302_REQUIERE_LOGIN, 0);',
'        :P302_ESTADO := nvl(:P302_ESTADO, ''ACTIVO'');',
'    else',
'        select compania, nombre_portal, url_base, descripcion,',
'               requiere_captcha, requiere_login, estado',
'          into :P302_COMPANIA, :P302_NOMBRE_PORTAL, :P302_URL_BASE, :P302_DESCRIPCION,',
'               :P302_REQUIERE_CAPTCHA, :P302_REQUIERE_LOGIN, :P302_ESTADO',
'          from data.t_cntr_portales',
'         where id_portal = :P302_ID_PORTAL;',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>152302050
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
