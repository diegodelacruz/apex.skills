prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>152
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 152 - Backoffice
--
-- Application Export:
--   Application:     152
--   Name:            Backoffice
--   Date and Time:   14:43 Tuesday July 7, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 309
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_00309
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>309);
end;
/
prompt --application/pages/page_00309
begin
wwv_flow_imp_page.create_page(
 p_id=>309
,p_name=>'Dlg empresa'
,p_page_mode=>'MODAL'
,p_step_title=>'Empresa'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(405885183218277832)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'760'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152309010)
,p_plug_name=>'Empresa'
,p_region_name=>'frm_cntr_empresa'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(406400168555332734)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152309020)
,p_plug_name=>'Botones'
,p_region_name=>'botones_309'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(406400595196332734)
,p_plug_display_sequence=>90
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152309061)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(152309020)
,p_button_name=>'CANCELAR'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970980751278001)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.navigation.dialog.cancel(true);'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152309062)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(152309020)
,p_button_name=>'GUARDAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970980751278001)
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152309201)
,p_name=>'P309_ID_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(152309010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152309202)
,p_name=>'P309_COMPANIA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(152309010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152309203)
,p_name=>'P309_RUC'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(152309010)
,p_prompt=>'RUC'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_cMaxlength=>30
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152309204)
,p_name=>'P309_RAZON_SOCIAL'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(152309010)
,p_prompt=>'Razon social'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_cMaxlength=>300
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152309205)
,p_name=>'P309_NOMBRE_COMERCIAL'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(152309010)
,p_prompt=>'Nombre comercial'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_cMaxlength=>300
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152309206)
,p_name=>'P309_TIPO_EMPRESA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(152309010)
,p_prompt=>'Tipo empresa'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Nacional;NACIONAL,Exterior;EXTERIOR'
,p_cSize=>80
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152309207)
,p_name=>'P309_ESTADO'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(152309010)
,p_prompt=>'Estado'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Activo;ACTIVO,Inactivo;INACTIVO'
,p_cSize=>80
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152309502)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Guardar empresa'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'data.pk_cntr_configuracion.guardar_empresa(:P309_ID_EMPRESA,:P309_COMPANIA,:P309_RUC,:P309_RAZON_SOCIAL,:P309_NOMBRE_COMERCIAL,:P309_TIPO_EMPRESA,:P309_ESTADO);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(152309062)
,p_process_success_message=>'Empresa guardada correctamente.'
,p_internal_uid=>152309502
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152309503)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Cerrar dialogo'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(152309062)
,p_internal_uid=>152309503
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152309501)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar empresa'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
':P309_COMPANIA := nvl(:P309_COMPANIA, :G_COMPANIA);',
'if :P309_COMPANIA is null then',
'    raise_application_error(-20071, ''No se pudo determinar la compania activa.'');',
'end if;',
'if :P309_ID_EMPRESA is null then',
':P309_ESTADO := nvl(:P309_ESTADO, ''ACTIVO'');',
'else',
'select compania, ruc, razon_social, nombre_comercial, tipo_empresa, estado into :P309_COMPANIA, :P309_RUC, :P309_RAZON_SOCIAL, :P309_NOMBRE_COMERCIAL, :P309_TIPO_EMPRESA, :P309_ESTADO from data.t_cntr_empresas where id_empresa = :P309_ID_EMPRESA;',
'end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>152309501
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
