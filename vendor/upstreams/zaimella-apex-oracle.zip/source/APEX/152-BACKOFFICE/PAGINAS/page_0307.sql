prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>152
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 152 - Backoffice
--
-- Application Export:
--   Application:     152
--   Name:            Backoffice
--   Date and Time:   16:36 Tuesday July 7, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 307
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_00307
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>307);
end;
/
prompt --application/pages/page_00307
begin
wwv_flow_imp_page.create_page(
 p_id=>307
,p_name=>'Matricula de Sujetos'
,p_step_title=>'Matricula de Sujetos'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152307010)
,p_plug_name=>'Sujetos'
,p_region_name=>'tabs_cntr_sujetos'
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_imp.id(406400168555332734)
,p_plug_display_sequence=>20
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'N',
  'rds_mode', 'STANDARD',
  'remember_selection', 'SESSION')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152307100)
,p_plug_name=>'Personas'
,p_region_name=>'ir_cntr_personas'
,p_parent_plug_id=>wwv_flow_imp.id(152307010)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(405917550338277892)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>'select id_persona, tipo_identificacion, identificacion, nombre_completo, correo, telefono, estado, id_persona editar from data.vt_cntr_personas where compania = nvl(:G_COMPANIA, compania)'
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(152307110)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>152307110
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152307121)
,p_db_column_name=>'ID_PERSONA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152307122)
,p_db_column_name=>'TIPO_IDENTIFICACION'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152307123)
,p_db_column_name=>'IDENTIFICACION'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Identificacion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152307124)
,p_db_column_name=>'NOMBRE_COMPLETO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Persona'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152307125)
,p_db_column_name=>'CORREO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Correo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152307126)
,p_db_column_name=>'TELEFONO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Telefono'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152307127)
,p_db_column_name=>'ESTADO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152307128)
,p_db_column_name=>'EDITAR'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Editar'
,p_column_link=>'f?p=&APP_ID.:308:&SESSION.::&DEBUG.:RP,308:P308_ID_PERSONA:#ID_PERSONA#'
,p_column_linktext=>'<span class="fa fa-edit" title="Editar persona"></span><span class="u-VisuallyHidden">Editar persona</span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(152307190)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'CNTR307_100'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TIPO_IDENTIFICACION:IDENTIFICACION:NOMBRE_COMPLETO:CORREO:TELEFONO:ESTADO:EDITAR'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152307200)
,p_plug_name=>'Empresas'
,p_region_name=>'ir_cntr_empresas'
,p_parent_plug_id=>wwv_flow_imp.id(152307010)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(405917550338277892)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>'select id_empresa, ruc, razon_social, nombre_comercial, tipo_empresa, estado, id_empresa editar, id_empresa personas from data.vt_cntr_empresas where compania = nvl(:G_COMPANIA, compania)'
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(152307210)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>152307210
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152307221)
,p_db_column_name=>'ID_EMPRESA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152307222)
,p_db_column_name=>'RUC'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'RUC'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152307223)
,p_db_column_name=>'RAZON_SOCIAL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Razon social'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152307224)
,p_db_column_name=>'NOMBRE_COMERCIAL'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Nombre comercial'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152307225)
,p_db_column_name=>'TIPO_EMPRESA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Tipo empresa'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152307226)
,p_db_column_name=>'ESTADO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152307227)
,p_db_column_name=>'EDITAR'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Editar'
,p_column_link=>'f?p=&APP_ID.:309:&SESSION.::&DEBUG.:RP,309:P309_ID_EMPRESA:#ID_EMPRESA#'
,p_column_linktext=>'<span class="fa fa-edit" title="Editar empresa"></span><span class="u-VisuallyHidden">Editar empresa</span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152307228)
,p_db_column_name=>'PERSONAS'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Personas'
,p_column_link=>'f?p=&APP_ID.:310:&SESSION.::&DEBUG.:RP,310:P310_ID_EMPRESA:#ID_EMPRESA#'
,p_column_linktext=>'<span class="fa fa-users" title="Personas vinculadas"></span><span class="u-VisuallyHidden">Personas vinculadas</span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(152307290)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'CNTR307_200'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'RUC:RAZON_SOCIAL:NOMBRE_COMERCIAL:TIPO_EMPRESA:ESTADO:EDITAR:PERSONAS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152307040)
,p_plug_name=>'Matricula de Sujetos'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(406400910855332735)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(405872152752277696)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(405971733953278003)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152307050)
,p_plug_name=>'Barra de acciones'
,p_region_name=>'barra_cntr_sujetos'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(406399719584332734)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152307061)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(152307050)
,p_button_name=>'CREAR_PERSONA'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_image_alt=>'Crear persona'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:308:&SESSION.::&DEBUG.:RP,308::'
,p_icon_css_classes=>'fa-user-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152307062)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(152307050)
,p_button_name=>'CREAR_EMPRESA'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_image_alt=>'Crear empresa'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:309:&SESSION.::&DEBUG.:RP,309::'
,p_icon_css_classes=>'fa-building-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152307063)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(152307050)
,p_button_name=>'CARGA_PERSONAS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_image_alt=>'Carga personas'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:312:&SESSION.::&DEBUG.:RP,312::'
,p_icon_css_classes=>'fa-upload'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152307064)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(152307050)
,p_button_name=>'CARGA_VINCULOS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_image_alt=>'Carga vinculos'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:313:&SESSION.::&DEBUG.:RP,313::'
,p_icon_css_classes=>'fa-link'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(152307900)
,p_name=>'Refrescar al cerrar dialogo'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(152307901)
,p_event_id=>wwv_flow_imp.id(152307900)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(152307100)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(152307902)
,p_event_id=>wwv_flow_imp.id(152307900)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(152307200)
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
