prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>152
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
prompt APPLICATION 152 - Backoffice
prompt --application/pages/delete_00324
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>324);
end;
/
prompt --application/pages/page_00324
begin
wwv_flow_imp_page.create_page(
 p_id=>324
,p_name=>'Dlg último análisis IA de configuración'
,p_page_mode=>'MODAL'
,p_step_title=>'Último análisis IA por sujeto'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(405885183218277832)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'1200'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152324010)
,p_plug_name=>'Último análisis IA por sujeto'
,p_region_name=>'ir_cntr_ia_masivo'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(405917550338277892)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id_analisis,',
'       tipo_sujeto,',
'       sujeto,',
'       fecha_solicitud,',
'       fecha_fin,',
'       estado,',
'       resumen,',
'       nvl(resultado, error_tecnico) resultado,',
'       confianza,',
'       advertencias',
'  from (',
'        select a.*,',
'               row_number() over (partition by a.tipo_sujeto, a.id_sujeto order by a.fecha_solicitud desc, a.id_analisis desc) orden',
'          from data.vt_cntr_ia_analisis a',
'          join data.t_cntr_configuraciones c on c.id_configuracion = a.id_configuracion',
'         where a.id_configuracion = :P324_ID_CONFIGURACION',
'           and a.compania = :G_COMPANIA',
'           and upper(c.usuario_creacion) = upper(:APP_USER)',
'       )',
' where orden = 1',
' order by fecha_solicitud desc, id_analisis desc'))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(152324011)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'N'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>152324011
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152324012)
,p_db_column_name=>'ID_ANALISIS'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Análisis'
,p_column_type=>'NUMBER'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152324013)
,p_db_column_name=>'TIPO_SUJETO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo sujeto'
,p_column_type=>'STRING'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152324014)
,p_db_column_name=>'SUJETO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Sujeto'
,p_column_type=>'STRING'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152324015)
,p_db_column_name=>'FECHA_SOLICITUD'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fecha de análisis'
,p_column_type=>'DATE'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152324016)
,p_db_column_name=>'FECHA_FIN'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Finalizado'
,p_column_type=>'DATE'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152324017)
,p_db_column_name=>'ESTADO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152324018)
,p_db_column_name=>'RESUMEN'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Resumen'
,p_column_type=>'STRING'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152324019)
,p_db_column_name=>'RESULTADO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Resultado de análisis IA'
,p_column_type=>'STRING'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152324020)
,p_db_column_name=>'CONFIANZA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Confianza'
,p_column_type=>'NUMBER'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152324021)
,p_db_column_name=>'ADVERTENCIAS'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Advertencias'
,p_column_type=>'STRING'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(152324022)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'152324IA'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID_ANALISIS:TIPO_SUJETO:SUJETO:FECHA_SOLICITUD:FECHA_FIN:ESTADO:RESUMEN:RESULTADO:CONFIANZA:ADVERTENCIAS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152324030)
,p_plug_name=>'Botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(406400595196332734)
,p_plug_display_sequence=>90
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152324031)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(152324030)
,p_button_name=>'CERRAR'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970980751278001)
,p_button_image_alt=>'Cerrar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.navigation.dialog.cancel(true);'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152324201)
,p_name=>'P324_ID_CONFIGURACION'
,p_is_required=>true
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
