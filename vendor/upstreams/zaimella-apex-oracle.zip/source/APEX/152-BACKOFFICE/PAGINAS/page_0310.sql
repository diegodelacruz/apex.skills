prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>152
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 152 - Backoffice
--
-- Application Export:
--   Application:     152
--   Name:            Backoffice
--   Date and Time:   16:36 Tuesday July 7, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 310
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_00310
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>310);
end;
/
prompt --application/pages/page_00310
begin
wwv_flow_imp_page.create_page(
 p_id=>310
,p_name=>'Personas vinculadas a empresa'
,p_step_title=>'Personas vinculadas a empresa'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152310040)
,p_plug_name=>'Personas vinculadas a empresa'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(406400910855332735)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(405872152752277696)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(405971733953278003)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152310050)
,p_plug_name=>'Barra de acciones'
,p_region_name=>'barra_cntr_vinculos'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(406399719584332734)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152310070)
,p_plug_name=>'Empresa'
,p_region_name=>'frm_cntr_empresa_contexto'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(406400168555332734)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152310100)
,p_plug_name=>'Personas vinculadas'
,p_parent_plug_id=>wwv_flow_imp.id(152310070)
,p_region_name=>'ir_cntr_empresa_personas'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(405917550338277892)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>'select id_empresa_persona, id_empresa, ruc, razon_social, identificacion, nombre_persona, rol, estado, id_empresa_persona editar, id_empresa_persona desvincular from data.vt_cntr_empresa_personas where id_empresa = :P310_ID_EMPRESA order by nombre_pe'
||'rsona, rol'
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(152310110)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>152310110
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152310121)
,p_db_column_name=>'ID_EMPRESA_PERSONA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152310122)
,p_db_column_name=>'ID_EMPRESA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'ID empresa'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152310123)
,p_db_column_name=>'RUC'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'RUC'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152310124)
,p_db_column_name=>'RAZON_SOCIAL'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Empresa'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152310125)
,p_db_column_name=>'IDENTIFICACION'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Identificacion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152310126)
,p_db_column_name=>'NOMBRE_PERSONA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Persona'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152310127)
,p_db_column_name=>'ROL'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Rol'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152310128)
,p_db_column_name=>'ESTADO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152310129)
,p_db_column_name=>'EDITAR'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Editar'
,p_column_link=>'f?p=&APP_ID.:311:&SESSION.::&DEBUG.:RP,311:P311_ID_EMPRESA_PERSONA,P311_ID_EMPRESA:#ID_EMPRESA_PERSONA#,#ID_EMPRESA#'
,p_column_linktext=>'<span class="fa fa-edit" title="Editar vinculo"></span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152310130)
,p_db_column_name=>'DESVINCULAR'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Desvincular'
,p_column_link=>'f?p=&APP_ID.:310:&SESSION.:DESVINCULAR:&DEBUG.:RP,310:P310_ID_EMPRESA,P310_ID_EMPRESA_PERSONA:#ID_EMPRESA#,#ID_EMPRESA_PERSONA#'
,p_column_linktext=>'<span class="fa fa-unlink" title="Desvincular"></span>'
,p_column_link_attr=>'onclick="return confirm(''Desea desvincular la persona?'');"'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(152310190)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'CNTR310_100'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'RUC:RAZON_SOCIAL:IDENTIFICACION:NOMBRE_PERSONA:ROL:ESTADO:EDITAR:DESVINCULAR'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152310061)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(152310050)
,p_button_name=>'ATRAS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:307:&SESSION.::&DEBUG.:RP::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152310062)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(152310050)
,p_button_name=>'VINCULAR_PERSONA'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_image_alt=>'Vincular persona'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:311:&SESSION.::&DEBUG.:RP,311:P311_ID_EMPRESA:&P310_ID_EMPRESA.'
,p_icon_css_classes=>'fa-link'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152310201)
,p_name=>'P310_ID_EMPRESA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(152310050)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152310202)
,p_name=>'P310_ID_EMPRESA_PERSONA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(152310050)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152310203)
,p_name=>'P310_EMPRESA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(152310070)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>12
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(152310900)
,p_name=>'Refrescar al cerrar dialogo'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(152310901)
,p_event_id=>wwv_flow_imp.id(152310900)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(152310100)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152310501)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Procesar accion'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'if :REQUEST = ''DESVINCULAR'' and :P310_ID_EMPRESA_PERSONA is not null then',
'data.pk_cntr_configuracion.desvincular_persona_empresa(:P310_ID_EMPRESA_PERSONA);',
'end if;',
'if :P310_ID_EMPRESA is not null then',
'begin',
'select ruc || '' - '' || razon_social into :P310_EMPRESA from data.t_cntr_empresas where id_empresa = :P310_ID_EMPRESA;',
'exception when no_data_found then',
':P310_EMPRESA := ''Empresa no encontrada'';',
'end;',
'end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>152310501
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
