prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>152
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 152 - Backoffice
--
-- Application Export:
--   Application:     152
--   Name:            Backoffice
--   Date and Time:   17:02 Friday August 7, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 303
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_00303
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>303);
end;
/
prompt --application/pages/page_00303
begin
wwv_flow_imp_page.create_page(
 p_id=>303
,p_name=>'Documentos del portal'
,p_step_title=>'Documentos del portal'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152303010)
,p_plug_name=>'Documentos'
,p_region_name=>'ir_cntr_documentos'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(405917550338277892)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id_documento, id_portal, nombre_portal, nombre_documento,',
'       evidencia_esperada, modo_captura, dato_busqueda, actualizacion_minima_dias, estado,',
'       id_documento as editar, id_documento as pasos',
'  from data.vt_cntr_documentos',
' where (:P303_ID_PORTAL is null or id_portal = :P303_ID_PORTAL)',
'   and compania = nvl(:G_COMPANIA, compania)'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(152303020)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>152303020
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152303021)
,p_db_column_name=>'ID_DOCUMENTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152303022)
,p_db_column_name=>'ID_PORTAL'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'ID portal'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152303023)
,p_db_column_name=>'NOMBRE_PORTAL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Portal'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152303024)
,p_db_column_name=>'NOMBRE_DOCUMENTO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Documento'
,p_column_link=>'f?p=&APP_ID.:305:&SESSION.::&DEBUG.:RP,305:P305_ID_DOCUMENTO:#ID_DOCUMENTO#'
,p_column_linktext=>'#NOMBRE_DOCUMENTO#'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152303025)
,p_db_column_name=>'EVIDENCIA_ESPERADA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Evidencia esperada'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152303026)
,p_db_column_name=>'MODO_CAPTURA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Modo captura'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152303027)
,p_db_column_name=>'DATO_BUSQUEDA'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Dato busqueda'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152303032)
,p_db_column_name=>'ACTUALIZACION_MINIMA_DIAS'
,p_display_order=>75
,p_column_identifier=>'K'
,p_column_label=>unistr('Actualizaci\00F3n m\00EDnima (d\00EDas)')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152303028)
,p_db_column_name=>'ESTADO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152303029)
,p_db_column_name=>'EDITAR'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Editar'
,p_column_link=>'f?p=&APP_ID.:304:&SESSION.::&DEBUG.:RP,304:P304_ID_DOCUMENTO,P304_ID_PORTAL:#ID_DOCUMENTO#,#ID_PORTAL#'
,p_column_linktext=>'<span class="fa fa-edit" title="Editar documento"></span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152303030)
,p_db_column_name=>'PASOS'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Pasos'
,p_column_link=>'f?p=&APP_ID.:305:&SESSION.::&DEBUG.:RP,305:P305_ID_DOCUMENTO:#ID_DOCUMENTO#'
,p_column_linktext=>'<span class="fa fa-list-ol" title="Ver pasos"></span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(152303031)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'CNTR303'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NOMBRE_PORTAL:NOMBRE_DOCUMENTO:EVIDENCIA_ESPERADA:MODO_CAPTURA:DATO_BUSQUEDA:ACTUALIZACION_MINIMA_DIAS:ESTADO:EDITAR:PASOS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152303040)
,p_plug_name=>'Documentos del portal'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(406400910855332735)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(405872152752277696)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(405971733953278003)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152303050)
,p_plug_name=>'Barra de acciones'
,p_region_name=>'barra_cntr_documentos'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(406399719584332734)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152303051)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(152303050)
,p_button_name=>'ATRAS'
,p_button_static_id=>'btnAtras'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:301:&SESSION.::&DEBUG.:RP::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152303052)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(152303050)
,p_button_name=>'CREAR_DOCUMENTO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_image_alt=>'Crear documento'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:304:&SESSION.::&DEBUG.:RP,304:P304_ID_PORTAL:&P303_ID_PORTAL.'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152303060)
,p_name=>'P303_ID_PORTAL'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(152303070)
,p_name=>'Refrescar al cerrar dialogo'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(152303071)
,p_event_id=>wwv_flow_imp.id(152303070)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(152303010)
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
