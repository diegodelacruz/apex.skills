prompt --application/set_environment
set define off verify off feedback off
begin
wwv_flow_imp.import_begin(p_version_yyyy_mm_dd=>'2024.05.31',p_release=>'24.1.3',p_default_workspace_id=>1282803584972340,p_default_application_id=>152,p_default_id_offset=>0,p_default_owner=>'DATA');
end;
/
prompt --application/pages/delete_00314
begin wwv_flow_imp_page.remove_page(p_flow_id=>wwv_flow.g_flow_id,p_page_id=>314); end;
/
prompt --application/pages/page_00314
begin
wwv_flow_imp_page.create_page(p_id=>314,p_name=>'Configuraciones de captura',p_step_title=>'Configuraciones de captura',p_autocomplete_on_off=>'OFF',p_page_template_options=>'#DEFAULT#');
wwv_flow_imp_page.create_page_plug(p_id=>wwv_flow_imp.id(152314040),p_plug_name=>'Configuraciones de captura',p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle',p_plug_template=>wwv_flow_imp.id(406400910855332735),p_plug_display_sequence=>10,p_plug_display_point=>'REGION_POSITION_01',p_menu_id=>wwv_flow_imp.id(405872152752277696),p_plug_source_type=>'NATIVE_BREADCRUMB',p_menu_template_id=>wwv_flow_imp.id(405971733953278003));
wwv_flow_imp_page.create_page_plug(p_id=>wwv_flow_imp.id(152314050),p_plug_name=>'Barra de acciones',p_region_name=>'barra_cntr_configuraciones',p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs',p_plug_template=>wwv_flow_imp.id(406399719584332734),p_plug_display_sequence=>30,p_plug_display_point=>'REGION_POSITION_01',p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2('expand_shortcuts','N','output_as','HTML')).to_clob);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152314100),p_plug_name=>'Mis configuraciones',p_region_name=>'ir_cntr_configuraciones',p_plug_template=>wwv_flow_imp.id(405917550338277892),p_plug_display_sequence=>10,p_plug_source_type=>'NATIVE_IR',
 p_plug_source=>'select id_configuracion, nombre, estado, cantidad_sujetos, cantidad_empresas, cantidad_documentos, fecha_actualizacion, id_configuracion editar from data.vt_cntr_configuraciones where upper(usuario_propietario)=upper(:APP_USER) order by nombre');
wwv_flow_imp_page.create_worksheet(p_id=>wwv_flow_imp.id(152314110),p_max_row_count=>'1000000',p_show_nulls_as=>'-',p_pagination_type=>'ROWS_X_TO_Y',p_pagination_display_pos=>'BOTTOM_RIGHT',p_report_list_mode=>'TABS',p_lazy_loading=>false,p_show_detail_link=>'N',p_show_notify=>'Y',p_download_formats=>'CSV:HTML:XLSX:PDF',p_enable_mail_download=>'Y',p_owner=>'JBALCAZAR',p_internal_uid=>152314110);
wwv_flow_imp_page.create_worksheet_column(p_id=>wwv_flow_imp.id(152314121),p_db_column_name=>'ID_CONFIGURACION',p_display_order=>10,p_column_identifier=>'A',p_column_label=>'ID',p_column_type=>'NUMBER',p_display_text_as=>'HIDDEN');
wwv_flow_imp_page.create_worksheet_column(p_id=>wwv_flow_imp.id(152314122),p_db_column_name=>'NOMBRE',p_display_order=>20,p_column_identifier=>'B',p_column_label=>'Configuracion',p_column_type=>'STRING');
wwv_flow_imp_page.create_worksheet_column(p_id=>wwv_flow_imp.id(152314123),p_db_column_name=>'ESTADO',p_display_order=>30,p_column_identifier=>'C',p_column_label=>'Estado',p_column_type=>'STRING');
wwv_flow_imp_page.create_worksheet_column(p_id=>wwv_flow_imp.id(152314124),p_db_column_name=>'CANTIDAD_SUJETOS',p_display_order=>40,p_column_identifier=>'D',p_column_label=>'Sujetos',p_column_type=>'NUMBER');
wwv_flow_imp_page.create_worksheet_column(p_id=>wwv_flow_imp.id(152314127),p_db_column_name=>'CANTIDAD_EMPRESAS',p_display_order=>50,p_column_identifier=>'G',p_column_label=>'Empresas',p_column_type=>'NUMBER');
wwv_flow_imp_page.create_worksheet_column(p_id=>wwv_flow_imp.id(152314125),p_db_column_name=>'CANTIDAD_DOCUMENTOS',p_display_order=>60,p_column_identifier=>'E',p_column_label=>'Documentos',p_column_type=>'NUMBER');
wwv_flow_imp_page.create_worksheet_column(p_id=>wwv_flow_imp.id(152314126),p_db_column_name=>'FECHA_ACTUALIZACION',p_display_order=>70,p_column_identifier=>'F',p_column_label=>'Actualizacion',p_column_type=>'DATE');
wwv_flow_imp_page.create_worksheet_column(p_id=>wwv_flow_imp.id(152314128),p_db_column_name=>'EDITAR',p_display_order=>80,p_column_identifier=>'H',p_column_label=>'Editar',p_column_link=>'f?p=&APP_ID.:315:&SESSION.::&DEBUG.:315:P315_ID_CONFIGURACION:#ID_CONFIGURACION#',p_column_linktext=>'<span class="fa fa-edit" title="Editar configuracion"></span><span class="u-VisuallyHidden">Editar configuracion</span>',p_column_type=>'NUMBER',p_column_alignment=>'CENTER');
wwv_flow_imp_page.create_page_button(p_id=>wwv_flow_imp.id(152314200),p_button_sequence=>10,p_button_plug_id=>wwv_flow_imp.id(152314050),p_button_name=>'CREAR_CONFIGURACION',p_button_action=>'REDIRECT_PAGE',p_button_template_options=>'#DEFAULT#',p_button_template_id=>wwv_flow_imp.id(405970874804277995),p_button_is_hot=>'Y',p_button_image_alt=>'Nueva configuracion',p_button_position=>'BELOW_BOX',p_button_alignment=>'RIGHT',p_button_redirect_url=>'f?p=&APP_ID.:315:&SESSION.::&DEBUG.:315::',p_icon_css_classes=>'fa-plus');
end;
/
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false));
commit;
end;
/
