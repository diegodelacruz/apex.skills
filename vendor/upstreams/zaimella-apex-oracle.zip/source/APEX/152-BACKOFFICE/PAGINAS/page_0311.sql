prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>152
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 152 - Backoffice
--
-- Application Export:
--   Application:     152
--   Name:            Backoffice
--   Date and Time:   16:36 Tuesday July 7, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 311
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_00311
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>311);
end;
/
prompt --application/pages/page_00311
begin
wwv_flow_imp_page.create_page(
 p_id=>311
,p_name=>'Dlg vincular persona'
,p_page_mode=>'MODAL'
,p_step_title=>'Vincular persona'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(405885183218277832)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'760'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152311010)
,p_plug_name=>'Vinculo empresa-persona'
,p_region_name=>'frm_cntr_vinculo'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(406400168555332734)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152311020)
,p_plug_name=>'Botones'
,p_region_name=>'botones_311'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(406400595196332734)
,p_plug_display_sequence=>90
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152311061)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(152311020)
,p_button_name=>'CANCELAR'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970980751278001)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.navigation.dialog.cancel(true);'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152311062)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(152311020)
,p_button_name=>'GUARDAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970980751278001)
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152311201)
,p_name=>'P311_ID_EMPRESA_PERSONA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(152311010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152311202)
,p_name=>'P311_ID_EMPRESA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(152311010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152311203)
,p_name=>'P311_ID_PERSONA'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(152311010)
,p_prompt=>'Persona'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nombre_completo || '' - '' || identificacion d, id_persona r',
'from data.vt_cntr_personas',
'where compania = nvl(:G_COMPANIA, compania)',
'  and estado = ''ACTIVO''',
'order by nombre_completo'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione persona'
,p_cSize=>80
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152311204)
,p_name=>'P311_ROL'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(152311010)
,p_prompt=>'Rol'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Representante;REPRESENTANTE,Socio;SOCIO,Accionista;ACCIONISTA,Relacionado;RELACIONADO,Empleado;EMPLEADO,Beneficiario final;BENEFICIARIO_FINAL,Contacto;CONTACTO'
,p_cSize=>80
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152311205)
,p_name=>'P311_ESTADO'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(152311010)
,p_prompt=>'Estado'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Activo;ACTIVO,Inactivo;INACTIVO'
,p_cSize=>80
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152311206)
,p_name=>'P311_OBSERVACION'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(152311010)
,p_prompt=>'Observacion'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>100
,p_cHeight=>3
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'NONE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152311502)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Guardar vinculo'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'data.pk_cntr_configuracion.vincular_persona_empresa(:P311_ID_EMPRESA_PERSONA,:P311_ID_EMPRESA,:P311_ID_PERSONA,:P311_ROL,:P311_ESTADO,:P311_OBSERVACION);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(152311062)
,p_process_success_message=>'Persona vinculada correctamente.'
,p_internal_uid=>152311502
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152311503)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Cerrar dialogo'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(152311062)
,p_internal_uid=>152311503
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152311501)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar vinculo'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'if :P311_ID_EMPRESA_PERSONA is null then',
':P311_ESTADO := nvl(:P311_ESTADO, ''ACTIVO'');',
'else',
'select id_empresa, id_persona, rol, estado, observacion into :P311_ID_EMPRESA, :P311_ID_PERSONA, :P311_ROL, :P311_ESTADO, :P311_OBSERVACION from data.t_cntr_empresa_personas where id_empresa_persona = :P311_ID_EMPRESA_PERSONA;',
'end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>152311501
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
