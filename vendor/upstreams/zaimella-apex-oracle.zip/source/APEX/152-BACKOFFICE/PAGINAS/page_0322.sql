prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>152
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
prompt APPLICATION 152 - Backoffice
prompt --application/pages/delete_00322
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>322);
end;
/
prompt --application/pages/page_00322
begin
wwv_flow_imp_page.create_page(
 p_id=>322
,p_name=>'Dlg documento manual'
,p_page_mode=>'MODAL'
,p_step_title=>'Documento manual'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(405885183218277832)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'760'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152322010)
,p_plug_name=>'Evidencia manual'
,p_region_name=>'frm_cntr_evidencia_manual'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(406400168555332734)
,p_plug_display_sequence=>10
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152322020)
,p_plug_name=>'Botones'
,p_region_name=>'botones_cntr_evidencia_manual'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(406400595196332734)
,p_plug_display_sequence=>90
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152322021)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(152322020)
,p_button_name=>'CANCELAR'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970980751278001)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.navigation.dialog.cancel(true);'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152322022)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(152322020)
,p_button_name=>'GUARDAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970980751278001)
,p_button_image_alt=>'Guardar evidencia'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152322201)
,p_name=>'P322_TIPO_SUJETO'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(152322010)
,p_prompt=>'Tipo de sujeto'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Seleccione;,Persona;PERSONA,Empresa;EMPRESA'
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152322202)
,p_name=>'P322_ID_SUJETO'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(152322010)
,p_prompt=>'Sujeto'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select d, r from (select identificacion || '' - '' || nombres d, id_persona r, ''PERSONA'' tipo from data.t_cntr_personas where compania = :G_COMPANIA and estado = ''ACTIVO'' union all select ruc || '' - '' || razon_social d, id_empresa r, ''EMPRESA'' tipo from data.t_cntr_empresas where compania = :G_COMPANIA and estado = ''ACTIVO'') where tipo = :P322_TIPO_SUJETO order by 1'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione sujeto'
,p_lov_cascade_parent_items=>'P322_TIPO_SUJETO'
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152322203)
,p_name=>'P322_ID_DOCUMENTO'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(152322010)
,p_prompt=>'Documento manual'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select nombre_documento d, id_documento r from data.t_cntr_documentos where compania = :G_COMPANIA and modo_captura in (''MANUAL'',''SEMIAUTOMATICO'') and estado = ''ACTIVO'' order by 1'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione documento'
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152322204)
,p_name=>'P322_ARCHIVO'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(152322010)
,p_prompt=>'Archivo'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_is_persistent=>'U'
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'NATIVE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152322205)
,p_name=>'P322_ID_EVIDENCIA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(152322010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152322501)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Guardar evidencia manual'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_numeroarchivo number;',
'begin',
'  data.pk_cntr_rpa.registrar_evidencia_manual(',
'    p_id_documento => :P322_ID_DOCUMENTO,',
'    p_tipo_sujeto => :P322_TIPO_SUJETO,',
'    p_id_sujeto => :P322_ID_SUJETO,',
'    p_archivo => :P322_ARCHIVO,',
'    p_usuario => :APP_USER,',
'    p_id_evidencia => :P322_ID_EVIDENCIA,',
'    p_numeroarchivo => l_numeroarchivo);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(152322022)
,p_process_success_message=>'Evidencia manual guardada correctamente.'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152322502)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Cerrar dialogo'
,p_process_when_button_id=>wwv_flow_imp.id(152322022)
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
