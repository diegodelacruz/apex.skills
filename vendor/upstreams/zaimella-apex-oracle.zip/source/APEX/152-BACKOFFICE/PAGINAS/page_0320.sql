prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>152
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 152 - Backoffice
--
-- Application Export:
--   Application:     152
--   Name:            Backoffice
--   Date and Time:   14:31 Wednesday July 15, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 320
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_00320
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>320);
end;
/
prompt --application/pages/page_00320
begin
wwv_flow_imp_page.create_page(
 p_id=>320
,p_name=>'Matriz documental'
,p_step_title=>'Matriz documental'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#matriz_cntr_documental .t-Report-tableWrap{max-width:100%;overflow-x:auto;position:relative}',
'#matriz_cntr_documental .t-Report-report{min-width:max-content}',
'#matriz_cntr_documental .t-Report-cell{vertical-align:middle}',
'#matriz_cntr_documental .t-Report-colHead:nth-child(1),#matriz_cntr_documental .t-Report-cell:nth-child(1){position:sticky;left:0;min-width:10rem;width:10rem;max-width:10rem}',
'#matriz_cntr_documental .t-Report-colHead:nth-child(2),#matriz_cntr_documental .t-Report-cell:nth-child(2){position:sticky;left:10rem;min-width:20rem;width:20rem;max-width:20rem}',
'#matriz_cntr_documental .t-Report-cell:nth-child(1),#matriz_cntr_documental .t-Report-cell:nth-child(2){z-index:2;background-color:var(--ut-component-background-color,#fff);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
'#matriz_cntr_documental .t-Report-colHead:nth-child(1),#matriz_cntr_documental .t-Report-colHead:nth-child(2){z-index:3;background-color:var(--a-gv-header-background-color,#f4f4f4)}',
'#matriz_cntr_documental .t-Report-colHead:nth-child(2),#matriz_cntr_documental .t-Report-cell:nth-child(2){box-shadow:2px 0 2px rgba(0,0,0,.12)}',
'#matriz_cntr_documental .cntr-dual-scroll{height:1.5rem;margin:0 0 .25rem;overflow-x:auto;overflow-y:hidden;scrollbar-gutter:stable;background:var(--ut-region-background-color,#f8f8f8);border:1px solid rgba(0,0,0,.12);border-radius:2px}',
'#matriz_cntr_documental .cntr-dual-scroll__spacer{height:1px}'))
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(function(){',
'  "use strict";',
'  var regionId="matriz_cntr_documental";',
'  function initialize(){',
'    var region=document.getElementById(regionId);',
'    if(!region){return;}',
'    var wrapper=region.querySelector(".t-Report-tableWrap")||region.querySelector(".t-fht-tbody")||region.querySelector(".a-IRR-tableContainer");',
'    if(!wrapper){return;}',
'    Array.prototype.forEach.call(region.querySelectorAll(".cntr-dual-scroll"),function(element){element.remove();});',
'    if(region._cntrDualScrollObserver){region._cntrDualScrollObserver.disconnect();}',
'    var top=document.createElement("div");',
'    var spacer=document.createElement("div");',
'    var syncing=false;',
'    top.className="cntr-dual-scroll";',
'    top.setAttribute("data-cntr-scroll-for",regionId);',
'    top.setAttribute("aria-label","Desplazamiento horizontal de la tabla");',
'    spacer.className="cntr-dual-scroll__spacer";',
'    top.appendChild(spacer);',
'    var insertion=wrapper;',
'    var fixedHeader=wrapper.parentNode.querySelector(".t-fht-thead");',
'    if(fixedHeader){insertion=fixedHeader;}',
'    wrapper.parentNode.insertBefore(top,insertion);',
'    function update(){',
'      spacer.style.width=wrapper.scrollWidth+"px";',
'      top.hidden=wrapper.scrollWidth<=wrapper.clientWidth;',
'      if(!top.hidden&&top.scrollLeft!==wrapper.scrollLeft){top.scrollLeft=wrapper.scrollLeft;}',
'    }',
'    top.addEventListener("scroll",function(){if(syncing){return;}syncing=true;wrapper.scrollLeft=top.scrollLeft;syncing=false;});',
'    wrapper.addEventListener("scroll",function(){if(syncing){return;}syncing=true;top.scrollLeft=wrapper.scrollLeft;syncing=false;});',
'    if(window.ResizeObserver){region._cntrDualScrollObserver=new ResizeObserver(update);region._cntrDualScrollObserver.observe(wrapper);}',
'    update();',
'  }',
'  function start(){',
'    var region=document.getElementById(regionId);',
'    initialize();',
'    if(region&&!region.dataset.cntrDualScrollRefresh){region.dataset.cntrDualScrollRefresh="Y";region.addEventListener("apexafterrefresh",function(){window.setTimeout(initialize,0);});}',
'    window.setTimeout(initialize,250);',
'  }',
'  if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",start);}else{start();}',
'  window.addEventListener("resize",initialize);',
'}());'))
,p_page_template_options=>'#DEFAULT#'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152320010)
,p_plug_name=>'Matriz documental'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_imp.id(406400910855332735)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(405872152752277696)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(405971733953278003)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152320020)
,p_plug_name=>'Barra de acciones'
,p_region_name=>'barra_cntr_matriz'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(406399719584332734)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152320030)
,p_plug_name=>'Filtros'
,p_region_name=>'frm_cntr_matriz_filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(406400168555332734)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152320100)
,p_plug_name=>'Documentos por sujeto'
,p_region_name=>'matriz_cntr_documental'
,p_parent_plug_id=>wwv_flow_imp.id(152320030)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(405917550338277892)
,p_plug_display_sequence=>20
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return data.pk_cntr_rpa.renderizar_matriz(',
'    p_id_configuracion => :P320_ID_CONFIGURACION,',
'    p_usuario => :APP_USER,',
'    p_compania => :G_COMPANIA,',
'    p_mostrar_todos => case when :P320_ID_CONFIGURACION = -1 then ''S'' else ''N'' end);'))
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152320110)
,p_plug_name=>'Historial de análisis IA'
,p_region_name=>'ir_cntr_ia_historial'
,p_plug_display_condition_type=>'NEVER'
,p_parent_plug_id=>wwv_flow_imp.id(152320030)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(405917550338277892)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.id_analisis,',
'       a.id_solicitud_analisis,',
'       a.tipo_sujeto,',
'       a.sujeto,',
'       a.estado,',
'       a.fecha_solicitud,',
'       a.fecha_fin,',
'       a.advertencias,',
'       ''Ver análisis'' resultado_link',
'  from data.vt_cntr_ia_analisis a',
'  join data.t_cntr_configuraciones c on c.id_configuracion = a.id_configuracion',
' where a.id_configuracion = :P320_ID_CONFIGURACION',
'   and a.compania = :G_COMPANIA',
'   and exists (select 1 from data.v_cntr_rpa_configuraciones vc where vc.id_configuracion = c.id_configuracion and upper(vc.usuario_apex) = upper(:APP_USER))',
' order by a.fecha_solicitud desc, a.id_analisis desc'))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(152320111)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'N'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>152320111
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152320112)
,p_db_column_name=>'ID_ANALISIS'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Análisis'
,p_column_type=>'NUMBER'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152320113)
,p_db_column_name=>'ID_SOLICITUD_ANALISIS'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Solicitud'
,p_column_type=>'NUMBER'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152320114)
,p_db_column_name=>'TIPO_SUJETO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tipo sujeto'
,p_column_type=>'STRING'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152320115)
,p_db_column_name=>'SUJETO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Sujeto'
,p_column_type=>'STRING'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152320116)
,p_db_column_name=>'ESTADO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Progreso'
,p_column_type=>'STRING'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152320117)
,p_db_column_name=>'FECHA_SOLICITUD'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Solicitado'
,p_column_type=>'DATE'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152320118)
,p_db_column_name=>'FECHA_FIN'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Finalizado'
,p_column_type=>'DATE'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152320119)
,p_db_column_name=>'ADVERTENCIAS'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Advertencias'
,p_column_type=>'STRING'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152320120)
,p_db_column_name=>'RESULTADO_LINK'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Resultado'
,p_column_link=>'f?p=&APP_ID.:320:&SESSION.::&DEBUG.::P320_ID_CONFIGURACION,P320_ID_ANALISIS:&P320_ID_CONFIGURACION.,#ID_ANALISIS#'
,p_column_linktext=>'#RESULTADO_LINK#'
,p_column_type=>'STRING'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(152320121)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'152320IA'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID_ANALISIS:ID_SOLICITUD_ANALISIS:TIPO_SUJETO:SUJETO:ESTADO:FECHA_SOLICITUD:FECHA_FIN:ADVERTENCIAS:RESULTADO_LINK'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152320122)
,p_plug_name=>'Resultado de análisis IA'
,p_region_name=>'resultado_cntr_ia'
,p_plug_display_condition_type=>'NEVER'
,p_parent_plug_id=>wwv_flow_imp.id(152320030)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(405917550338277892)
,p_plug_display_sequence=>40
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_resultado clob;',
'begin',
'    if :P320_ID_ANALISIS is null then return ''Seleccione “Ver análisis” en el historial para consultar el resultado consolidado.''; end if;',
'    select nvl(a.resultado, a.error_tecnico)',
'      into l_resultado',
'      from data.t_cntr_ia_analisis a',
'      join data.t_cntr_configuraciones c on c.id_configuracion = a.id_configuracion',
'     where a.id_analisis = :P320_ID_ANALISIS',
'       and a.id_configuracion = :P320_ID_CONFIGURACION',
'       and a.compania = :G_COMPANIA',
'       and exists (select 1 from data.v_cntr_rpa_configuraciones vc where vc.id_configuracion = c.id_configuracion and upper(vc.usuario_apex) = upper(:APP_USER));',
'    return replace(apex_escape.html(nvl(l_resultado, ''El análisis aún no tiene resultado.'')), chr(10), ''<br>'');',
'exception when no_data_found then return ''No está autorizado para consultar este análisis.''; end;'))
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152320301)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(152320020)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Consultar matriz'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152320302)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(152320020)
,p_button_name=>'REGISTRAR_EVIDENCIA_MANUAL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_image_alt=>'Registrar evidencia manual'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:322:&SESSION.::&DEBUG.:322::'
,p_icon_css_classes=>'fa-upload'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152320303)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(152320020)
,p_button_name=>'ANALISIS_IA_MASIVO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_image_alt=>'Análisis IA de configuración'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-magic'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152320304)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(152320020)
,p_button_name=>'VER_ANALISIS_MASIVO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_image_alt=>'Ver análisis masivo'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:324:&SESSION.::&DEBUG.::P324_ID_CONFIGURACION:&P320_ID_CONFIGURACION.'
,p_icon_css_classes=>'fa-eye'
,p_button_condition=>':P320_ID_CONFIGURACION > 0'
,p_button_condition_type=>'PLSQL_EXPRESSION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(152320700)
,p_name=>'Refrescar matriz al cerrar evidencia manual'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(152320302)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(152320701)
,p_event_id=>wwv_flow_imp.id(152320700)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(152320100)
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152320201)
,p_name=>'P320_ID_CONFIGURACION'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(152320030)
,p_prompt=>unistr('Configuraci\00F3n')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d, r',
'  from (',
'        select c.nombre d, c.id_configuracion r, 1 orden',
'          from data.vt_cntr_configuraciones c',
'         where c.compania = :G_COMPANIA',
'           and c.estado = ''ACTIVO''',
'        union all',
'        select ''Todos'' d, -1 r, 0 orden',
'          from dual',
'         where data.pk_cntr_rpa.tiene_todos_matriz(:APP_USER, :G_COMPANIA) = 1',
'       )',
' order by orden, d'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>unistr('Seleccione configuraci\00F3n')
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152320202)
,p_name=>'P320_TIPO_SUJETO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(152320030)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152320203)
,p_name=>'P320_ID_SUJETO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(152320030)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152320204)
,p_name=>'P320_ID_ANALISIS'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(152320030)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152320402)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Crear solicitud análisis IA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_solicitud number;',
'    l_total number;',
'begin',
'    if :P320_ID_CONFIGURACION is null or :P320_ID_CONFIGURACION = -1 then',
'        raise_application_error(-20001, ''Seleccione una configuración activa para análisis IA.'');',
'    end if;',
'    data.pk_cntr_ia_analisis.crear_solicitud(:P320_ID_CONFIGURACION, case when :REQUEST = ''ANALISIS_IA_SUJETO'' then :P320_TIPO_SUJETO end, case when :REQUEST = ''ANALISIS_IA_SUJETO'' then :P320_ID_SUJETO end, :APP_USER, :G_COMPANIA, l_solicitud, l_total);',
'    if l_total = 0 then',
'        raise_application_error(-20002, ''No existen documentos vigentes con instrucción IA para analizar.'');',
'    end if;',
'    data.pk_cntr_ia_analisis.notificar_solicitud(l_solicitud);',
'    apex_application.g_print_success_message := ''Solicitud IA '' || l_solicitud || '' creada para '' || l_total || '' sujeto(s).'';',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'ANALISIS_IA_SUJETO,ANALISIS_IA_MASIVO'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>152320402
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152320401)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Descargar documentos vigentes'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_archivo blob;',
'    l_nombre varchar2(400);',
'begin',
'    data.pk_cntr_rpa.obtener_zip_vigentes(',
'        p_id_configuracion => :P320_ID_CONFIGURACION,',
'        p_tipo_sujeto => :P320_TIPO_SUJETO,',
'        p_id_sujeto => :P320_ID_SUJETO,',
'        p_usuario => :APP_USER,',
'        p_compania => :G_COMPANIA,',
'        p_archivo => l_archivo,',
'        p_nombre_archivo => l_nombre,',
'        p_mostrar_todos => case when :P320_ID_CONFIGURACION = -1 then ''S'' else ''N'' end);',
'    sys.htp.init;',
'    owa_util.mime_header(''application/zip'', false);',
'    sys.htp.p(''Content-Length: '' || dbms_lob.getlength(l_archivo));',
'    sys.htp.p(''Content-Disposition: attachment; filename="'' || replace(l_nombre, ''"'', '''') || ''"'');',
'    owa_util.http_header_close;',
'    wpg_docload.download_file(l_archivo);',
'    apex_application.stop_apex_engine;',
'exception',
'    when apex_application.e_stop_apex_engine then',
'        raise;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'No fue posible generar la descarga.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'DESCARGAR_ZIP'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>152320401
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
