prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>152
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 152 - Backoffice
--
-- Application Export:
--   Application:     152
--   Name:            Backoffice
--   Date and Time:   16:51 Tuesday July 7, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 313
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_00313
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>313);
end;
/
prompt --application/pages/page_00313
begin
wwv_flow_imp_page.create_page(
 p_id=>313
,p_name=>'Carga masiva de vinculos'
,p_step_title=>'Carga masiva de vinculos'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_inline_css=>q'~#frm_cntr_carga_vinculos_empresa .t-Form-fieldContainer { position: relative; z-index: 2; } #ir_cntr_carga_vinculos { position: relative; z-index: 1; clear: both; }~'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152313040)
,p_plug_name=>'Carga masiva de vinculos'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(406400910855332735)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(405872152752277696)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(405971733953278003)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152313050)
,p_plug_name=>'Barra de acciones'
,p_region_name=>'barra_cntr_carga_vinculos'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(406399719584332734)
,p_plug_display_sequence=>15
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152313100)
,p_plug_name=>'Resultado de carga'
,p_parent_plug_id=>wwv_flow_imp.id(152313060)
,p_region_name=>'ir_cntr_carga_vinculos'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(405917550338277892)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>'select numero_fila, clave_referencia, accion, estado, mensaje, datos_fila from data.vt_cntr_carga_detalles where id_carga = :P313_ID_CARGA order by id_carga_detalle'
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(152313110)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>152313110
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152313121)
,p_db_column_name=>'NUMERO_FILA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Fila'
,p_column_type=>'NUMBER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152313122)
,p_db_column_name=>'CLAVE_REFERENCIA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Referencia'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152313123)
,p_db_column_name=>'ACCION'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Accion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152313124)
,p_db_column_name=>'ESTADO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152313125)
,p_db_column_name=>'MENSAJE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Mensaje'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152313126)
,p_db_column_name=>'DATOS_FILA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Datos fila'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(152313190)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'CNTR313_100'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMERO_FILA:CLAVE_REFERENCIA:ACCION:ESTADO:MENSAJE:DATOS_FILA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152313061)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(152313050)
,p_button_name=>'ATRAS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:307:&SESSION.::&DEBUG.:RP::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152313062)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(152313050)
,p_button_name=>'DESCARGAR_FORMATO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_image_alt=>'Descargar formato'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:313:&SESSION.:DESCARGAR_FORMATO:&DEBUG.::::'
,p_icon_css_classes=>'fa-download'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152313063)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(152313050)
,p_button_name=>'SUBIR_EXCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_image_alt=>'Subir Excel'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:300:&SESSION.::&DEBUG.:RP,300:G_MODULO,G_PAGINA:&APP_ID.,313'
,p_icon_css_classes=>'fa-upload'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152313064)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(152313050)
,p_button_name=>'PROCESAR_CARGA'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_image_alt=>'Procesar carga'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-check'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152313201)
,p_name=>'P313_ID_CARGA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(152313050)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152313203)
,p_name=>'P313_ID_CONFIGURACION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(152313050)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152313060)
,p_plug_name=>'Empresa de la carga'
,p_region_name=>'frm_cntr_carga_vinculos_empresa'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(406400168555332734)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152313202)
,p_name=>'P313_ID_EMPRESA'
,p_is_required=>false
,p_display_when=>'P313_ID_CONFIGURACION'
,p_display_when_type=>'ITEM_IS_NULL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(152313060)
,p_prompt=>'Empresa'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select ruc || '' - '' || razon_social d, id_empresa r from data.t_cntr_empresas where compania = :G_COMPANIA and estado = ''ACTIVO'' order by 1'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione empresa'
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152313502)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Procesar carga vinculos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'if :P313_ID_CONFIGURACION is null then',
'  data.pk_cntr_configuracion.confirmar_carga_vinculos(:G_COMPANIA, :P313_ID_EMPRESA, :P313_ID_CARGA);',
'else',
'  data.pk_cntr_configuracion.confirmar_carga_config_empresa_personas(:P313_ID_CONFIGURACION, :G_COMPANIA, :P313_ID_CARGA);',
'end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(152313064)
,p_process_success_message=>'Carga de vinculos procesada.'
,p_internal_uid=>152313502
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152313501)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Descargar formato'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'if :P313_ID_CONFIGURACION is null then',
'  data.pk_cntr_configuracion.descargar_formato_vinculos_xlsx;',
'else',
'  data.pk_cntr_configuracion.descargar_formato_config_empresa_personas_xlsx;',
'end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'DESCARGAR_FORMATO'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>152313501
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
