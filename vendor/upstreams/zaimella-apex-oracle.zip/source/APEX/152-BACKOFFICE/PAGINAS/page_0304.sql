prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>152
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 152 - Backoffice
--
-- Application Export:
--   Application:     152
--   Name:            Backoffice
--   Date and Time:   13:57 Tuesday July 7, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 304
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_00304
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>304);
end;
/
prompt --application/pages/page_00304
begin
wwv_flow_imp_page.create_page(
 p_id=>304
,p_name=>'Dlg documento'
,p_page_mode=>'MODAL'
,p_step_title=>'Documento'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(405885183218277832)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'720'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152304010)
,p_plug_name=>'Documento'
,p_region_name=>'frm_cntr_documento'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(406400168555332734)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152304020)
,p_plug_name=>'Botones'
,p_region_name=>'botones_cntr_documento'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(406400595196332734)
,p_plug_display_sequence=>90
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152304021)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(152304020)
,p_button_name=>'CANCELAR'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970980751278001)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.navigation.dialog.cancel(true);'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152304022)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(152304020)
,p_button_name=>'GUARDAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970980751278001)
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152304030)
,p_name=>'P304_ID_DOCUMENTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(152304010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152304031)
,p_name=>'P304_ID_PORTAL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(152304010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152304032)
,p_name=>'P304_COMPANIA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(152304010)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152304033)
,p_name=>'P304_NOMBRE_DOCUMENTO'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(152304010)
,p_prompt=>'Documento'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_cMaxlength=>250
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152304034)
,p_name=>'P304_EVIDENCIA_ESPERADA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(152304010)
,p_prompt=>'Evidencia esperada'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>100
,p_cHeight=>3
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152304035)
,p_name=>'P304_MODO_CAPTURA'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(152304010)
,p_prompt=>'Modo captura'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Automatico;AUTOMATICO,Semiautomatico;SEMIAUTOMATICO,Manual;MANUAL'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152304036)
,p_name=>'P304_DATO_BUSQUEDA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(152304010)
,p_prompt=>'Dato busqueda'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_cMaxlength=>250
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152304037)
,p_name=>'P304_ESTADO'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(152304010)
,p_prompt=>'Estado'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Activo;ACTIVO,Inactivo;INACTIVO'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152304039)
,p_name=>'P304_ACTUALIZACION_MINIMA_DIAS'
,p_item_sequence=>76
,p_item_plug_id=>wwv_flow_imp.id(152304010)
,p_prompt=>unistr('Actualizaci\00F3n m\00EDnima (d\00EDas)')
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>20
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_item_default=>'7'
,p_help_text=>unistr('Valor predeterminado: 7 d\00EDas. Si existe una evidencia vigente m\00E1s reciente que este n\00FAmero de d\00EDas, el RPA no volver\00E1 a consultarla.')
,p_attribute_01=>'0'
,p_attribute_02=>'9999'
,p_attribute_03=>'0'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152304038)
,p_name=>'P304_PROMPT_IA'
,p_item_sequence=>75
,p_item_plug_id=>wwv_flow_imp.id(152304010)
,p_prompt=>'Instrucción de análisis IA'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>80
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(405970281783277992)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152304051)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Guardar documento'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    data.pk_cntr_configuracion.guardar_documento(:P304_ID_DOCUMENTO,:P304_ID_PORTAL,:P304_COMPANIA,:P304_NOMBRE_DOCUMENTO,:P304_EVIDENCIA_ESPERADA,:P304_MODO_CAPTURA,:P304_DATO_BUSQUEDA,:P304_PROMPT_IA,:P304_ACTUALIZACION_MINIMA_DIAS,:P304_ESTADO);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(152304022)
,p_process_success_message=>'Documento guardado correctamente.'
,p_internal_uid=>152304051
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152304052)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Cerrar dialogo'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(152304022)
,p_internal_uid=>152304052
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(152304050)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar documento'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    :P304_COMPANIA := nvl(:P304_COMPANIA, :G_COMPANIA);',
'    if :P304_COMPANIA is null then',
'        raise_application_error(-20001, ''No existe compañía activa en la sesión.'');',
'    end if;',
'    if :P304_ID_DOCUMENTO is null then',
'        :P304_MODO_CAPTURA := nvl(:P304_MODO_CAPTURA, ''AUTOMATICO'');',
'        :P304_ESTADO := nvl(:P304_ESTADO, ''ACTIVO'');',
'    else',
'        select id_portal, compania, nombre_documento, evidencia_esperada, modo_captura, dato_busqueda, prompt_ia, actualizacion_minima_dias, estado',
'          into :P304_ID_PORTAL, :P304_COMPANIA, :P304_NOMBRE_DOCUMENTO, :P304_EVIDENCIA_ESPERADA, :P304_MODO_CAPTURA, :P304_DATO_BUSQUEDA, :P304_PROMPT_IA, :P304_ACTUALIZACION_MINIMA_DIAS, :P304_ESTADO',
'          from data.t_cntr_documentos where id_documento = :P304_ID_DOCUMENTO;',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>152304050
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
