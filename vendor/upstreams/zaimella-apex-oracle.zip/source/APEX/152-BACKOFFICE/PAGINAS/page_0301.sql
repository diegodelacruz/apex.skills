prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>152
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 152 - Backoffice
--
-- Application Export:
--   Application:     152
--   Name:            Backoffice
--   Date and Time:   12:34 Friday July 17, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 301
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_00301
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>301);
end;
/
prompt --application/pages/page_00301
begin
wwv_flow_imp_page.create_page(
 p_id=>301
,p_name=>'Administracion de portales'
,p_step_title=>'Administracion de portales'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152301010)
,p_plug_name=>'Portales'
,p_region_name=>'ir_cntr_portales'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(405917550338277892)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id_portal,',
'       nombre_portal,',
'       url_base,',
'       requiere_captcha_txt as requiere_captcha,',
'       requiere_login_txt as requiere_login,',
'       estado,',
'       id_portal as editar,',
'       id_portal as documentos',
'  from data.vt_cntr_portales',
' where compania = nvl(:G_COMPANIA, compania)'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(152301020)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>152301020
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152301021)
,p_db_column_name=>'ID_PORTAL'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152301022)
,p_db_column_name=>'NOMBRE_PORTAL'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Portal'
,p_column_link=>'f?p=&APP_ID.:303:&SESSION.::&DEBUG.:RP,303:P303_ID_PORTAL:#ID_PORTAL#'
,p_column_linktext=>'#NOMBRE_PORTAL#'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152301023)
,p_db_column_name=>'URL_BASE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'URL base'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152301024)
,p_db_column_name=>'REQUIERE_CAPTCHA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Requiere captcha'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152301025)
,p_db_column_name=>'REQUIERE_LOGIN'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Requiere login'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152301026)
,p_db_column_name=>'ESTADO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152301027)
,p_db_column_name=>'EDITAR'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Editar'
,p_column_link=>'f?p=&APP_ID.:302:&SESSION.::&DEBUG.:RP,302:P302_ID_PORTAL:#ID_PORTAL#'
,p_column_linktext=>'<span class="fa fa-edit" title="Editar portal"></span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152301028)
,p_db_column_name=>'DOCUMENTOS'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Documentos'
,p_column_link=>'f?p=&APP_ID.:303:&SESSION.::&DEBUG.:RP,303:P303_ID_PORTAL:#ID_PORTAL#'
,p_column_linktext=>'<span class="fa fa-file-text-o" title="Ver documentos"></span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(152301029)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'CNTR301'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NOMBRE_PORTAL:URL_BASE:REQUIERE_CAPTCHA:REQUIERE_LOGIN:ESTADO:EDITAR:DOCUMENTOS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152301030)
,p_plug_name=>'Administracion de portales'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(406400910855332735)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(405872152752277696)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(405971733953278003)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152301040)
,p_plug_name=>'Barra de acciones'
,p_region_name=>'barra_cntr_portales'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(406399719584332734)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152301041)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(152301040)
,p_button_name=>'CREAR_PORTAL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(405970874804277995)
,p_button_image_alt=>'Crear portal'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:302:&SESSION.::&DEBUG.:RP,302::'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(152301050)
,p_name=>'Refrescar al cerrar dialogo'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(152301051)
,p_event_id=>wwv_flow_imp.id(152301050)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(152301010)
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
