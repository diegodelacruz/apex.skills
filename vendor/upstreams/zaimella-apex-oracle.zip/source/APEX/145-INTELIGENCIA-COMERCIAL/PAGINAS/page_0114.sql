prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>145
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 145 - Inteligencia Comercial
--
-- Application Export:
--   Application:     145
--   Name:            Inteligencia Comercial
--   Date and Time:   12:29 Thursday July 30, 2026
--   Exported By:     JBALCAZAR
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 114
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800175940242830
--

begin
null;
end;
/
prompt --application/pages/delete_00114
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>114);
end;
/
prompt --application/pages/page_00114
begin
wwv_flow_imp_page.create_page(
 p_id=>114
,p_name=>'Dlg. Gestionar envios'
,p_alias=>unistr('GESTIONAR-ENV\00CDOS-M\00DALTIPLES-Y-C\00C1LCULO-DE-PREFACTURA')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Gestionar env\00EDos')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*function enforceSingleSelection() {',
'    var v_tipoEnvio=apex.item("P114_TIPOENVIO").getValue();',
'    if(v_tipoEnvio!="2"){return;}',
'    var grid = apex.region("tblDetalle").widget().interactiveGrid("getViews", "grid");',
'    var v_model=grid.model;',
'    v_model.subscribe({',
'        onChange: function(type, change) {',
'            if (type === "set") {',
'                v_model.forEach(function(record) {',
'                    if (record === change.record) {',
'                        apex.item("P114_CODIGO_PDV").setValue(record[0]);',
'                    }',
'                });',
'            }',
'        }',
'    });',
'}*/',
'function validaProcentaje(){',
'   (function(){',
'',
'    var v_tipoEnvio=apex.item("P114_TIPOENVIO").getValue();',
'    if(v_tipoEnvio!="1"){return;}',
'    var grid = apex.region("tblDetalle").widget();',
'    var model = grid.interactiveGrid("getViews", "grid").model;',
'    let actions = grid.interactiveGrid("getActions");',
'    var errorMsg = "";',
'    var errorMsgTotal = "";',
'    var errorMsg2 = "";',
'    var errorMsgTotal2 = "";',
'    var arrRowIds01 = {};',
'    var arrRowIds02 = {};',
'    var porcentaje=0;',
'    /*Buscar los datos por agrpuador codigopdv*/',
'    model.forEach(function(record) {',
'        var porcentajepdv = record[2];',
'        var codigoppdv = record[3];',
'        if (!arrRowIds01[codigoppdv]) { arrRowIds01[codigoppdv] = ""; }',
'        if (!arrRowIds02[codigoppdv]) { arrRowIds02[codigoppdv] = 0; }',
'        //for (i = 0; i < record.length; i++) {console.log(record[i]);}   ',
'        /*suma los porcentajes y valida los que tienen 0 (cero) o vacio*/',
'',
'        if (porcentajepdv.trim()==""){porcentajepdv="0";}',
'        if(porcentajepdv!="0"){',
'            /*suma los porcentajes*/',
'            porcentaje=parseFloat(porcentajepdv.replace(",","."), 10) || 0',
'            arrRowIds02[codigoppdv] += porcentaje;      ',
'        }else{',
'            /*para desplegar los registros en 0 (cero) o vacio*/',
'            arrRowIds01[codigoppdv]+="<li>"+record[0]+" "+record[1]+"</li>";',
'        }        ',
'    });',
'    /*',
'    Recorre los regisitros que tienen cero para desplegar en el mensaje de error',
'    */',
'    ',
'    Object.keys(arrRowIds01).forEach(function(codigoppdv) {',
'        actions.hide("save"); ',
'        errorMsg="";',
'        errorMsg = arrRowIds01[codigoppdv];',
'        if(errorMsg!=""){ errorMsgTotal+=errorMsg;}',
'    });',
'    if(errorMsgTotal.trim()!=""){ ',
'        errorMsgTotal=("Locales con porentajes en 0 (Cero) o vacio")+errorMsgTotal;',
'    }',
'    /*',
'    Recorre los regisitros de las sumatorias de los porentajes para ',
'    validar que cumplan el 100 %',
'    para desplegar en el mensaje de error',
'    */',
'    Object.keys(arrRowIds02).forEach(function(codigoppdv) {',
'        errorMsg2=""; ',
'        if(arrRowIds02[codigoppdv] != 100){',
'            actions.hide("save"); ',
'            var valor =apex.locale.formatNumber(arrRowIds02[codigoppdv], "FM999G999G990D00");',
'            var diferencia =apex.locale.formatNumber(Math.abs(100-arrRowIds02[codigoppdv]), "FM999G999G990D00");',
'            errorMsg2+="<li>"+codigoppdv +" - "+valor  +"% diferencia "+diferencia+"% </li>"',
'            ',
'        }',
'        if(errorMsg2!=""){ errorMsgTotal2+=errorMsg2;}',
'    });',
'    /*',
'        Si y solo si existe un error muestra mensaje de error  ',
'        */',
'    if(errorMsgTotal2.trim()!=""){ ',
'        errorMsgTotal2=("La suma de los porcentajes de estos PDV no es 100%.")+errorMsgTotal2;',
'    }',
'        if (errorMsgTotal.trim() != "" || errorMsgTotal2.trim() != "") {',
'            mensajeError(errorMsgTotal+errorMsgTotal2);',
'            actions.hide("save"); ',
unistr('            return false; // Detener la acci\00F3n de guardado'),
'        }',
'        /*',
'        Si y solo si no existiese un error muestra el boton de guardar',
'        */',
'        actions.show("save");',
'        document.querySelector(".t-Button--closeAlert")?.click();',
'    })();',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(secItems).hide();',
'//enforceSingleSelection();',
'validaProcentaje();',
''))
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_protection_level=>'C'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1021174981928414237)
,p_plug_name=>'Formulario'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--noBorder:t-Region--hiddenOverflow:t-Form--slimPadding:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(179262469115062452)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>':P114_EDITAR=1 or :P114_CODIGO_GRUPO is null'
,p_plug_read_only_when2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1021175099750414238)
,p_plug_name=>'Detalle'
,p_region_name=>'tblDetalle'
,p_parent_plug_id=>wwv_flow_imp.id(1021174981928414237)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(179261337032062452)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT * FROM (  ',
'      SELECT ',
'         C.CODIGOPDV||'' - ''||CL.NUMERO CODIGO,CL.NOMBRECONOCIDO LOCAL, ',
'         CL.PORCENTAJEPROMO, CL.PROMOCIONAL , CL.CODIGOPDV,CL.NUMERO,',
'         gn.DESCRIPCION_NIVEL2 || '' / '' || gn.DESCRIPCION_NIVEL3 || '' / '' || gn.DESCRIPCION_NIVEL4 ENVIO_UBICACION, ',
'         CL.ENVIO_DIRECCION',
'      FROM ',
'           t_trad_cliente C ',
'           LEFT JOIN T_TRAD_CLIENTELOCAL CL ON (CL.CODIGOPDV = C.CODIGOPDV)',
'           left join VT_TRAD_GEOGRAFICO_NIVEL gn on ( c.compania = gn.compania ',
'                and cl.ENVIO_UBICACION = gn.id and NIVEL = :P114_NIVEL  )',
'    WHERE 1=1',
'AND C.CODIGOPDV=:P114_PCODIGOPDV',
'AND CL.ESTADO= 1',
'ORDER BY CL.CODIGOPDV,CL.NUMERO)',
'',
''))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P114_PCODIGOPDV'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P114_TIPOENVIO in (1,2,3)'
,p_plug_display_when_cond2=>'PLSQL'
,p_plug_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_read_only_when=>'P114_EDITAR'
,p_plug_read_only_when2=>'1'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Detalle'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(44086411236289506)
,p_name=>'ENVIO_UBICACION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ENVIO_UBICACION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Envio Ubicacion'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(44086521452289507)
,p_name=>'ENVIO_DIRECCION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ENVIO_DIRECCION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Envio Direccion'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>500
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1021176743455414254)
,p_name=>'CODIGO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODIGO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Codigo'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>30
,p_value_alignment=>'CENTER'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1021176775533414255)
,p_name=>'LOCAL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LOCAL'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Local'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>40
,p_value_alignment=>'CENTER'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1021176920288414256)
,p_name=>'PORCENTAJEPROMO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PORCENTAJEPROMO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'%'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>50
,p_value_alignment=>'CENTER'
,p_attribute_01=>'0'
,p_attribute_02=>'100'
,p_attribute_03=>'center'
,p_attribute_04=>'decimal'
,p_format_mask=>'FM999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'VALUE_OF_ITEM_IN_CONDITION_IN_COLON_DELIMITED_LIST'
,p_display_condition=>'P114_TIPOENVIO'
,p_display_condition2=>'1:3'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1021176981033414257)
,p_name=>'PROMOCIONAL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROMOCIONAL'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SINGLE_CHECKBOX'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_01=>'N'
,p_attribute_02=>'1'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P114_TIPOENVIO'
,p_display_condition2=>'2'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1021177103635414258)
,p_name=>'CODIGOPDV'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODIGOPDV'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Codigopdv'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>70
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1021177223316414259)
,p_name=>'NUMERO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUMERO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Numero'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>80
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1029362156062413210)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(1029362208633413211)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
,p_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(1021176647622414253)
,p_internal_uid=>1021176647622414253
,p_is_editable=>true
,p_edit_operations=>'u'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU:SAVE'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>false
,p_download_formats=>null
,p_enable_mail_download=>true
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>350
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (config) {',
'	return cargarToolbar(config);',
'}',
'',
''))
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(1029349398307375742)
,p_interactive_grid_id=>wwv_flow_imp.id(1021176647622414253)
,p_static_id=>'5123637'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(1029349598715375743)
,p_report_id=>wwv_flow_imp.id(1029349398307375742)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(44453099629188164)
,p_view_id=>wwv_flow_imp.id(1029349598715375743)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(44086411236289506)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(44453960315188176)
,p_view_id=>wwv_flow_imp.id(1029349598715375743)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(44086521452289507)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1029350115352375748)
,p_view_id=>wwv_flow_imp.id(1029349598715375743)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(1021176743455414254)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>93.872
,p_sort_order=>1
,p_sort_direction=>'ASC'
,p_sort_nulls=>'LAST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1029351032024375753)
,p_view_id=>wwv_flow_imp.id(1029349598715375743)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(1021176775533414255)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1029351917738375756)
,p_view_id=>wwv_flow_imp.id(1029349598715375743)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(1021176920288414256)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>62.25
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1029352807910375758)
,p_view_id=>wwv_flow_imp.id(1029349598715375743)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(1021176981033414257)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>78.1493
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1029353742993375760)
,p_view_id=>wwv_flow_imp.id(1029349598715375743)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(1021177103635414258)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1029354656231375762)
,p_view_id=>wwv_flow_imp.id(1029349598715375743)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(1021177223316414259)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(1029368249263415741)
,p_view_id=>wwv_flow_imp.id(1029349598715375743)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(1029362156062413210)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1021175855832414245)
,p_plug_name=>'Botones'
,p_parent_plug_id=>wwv_flow_imp.id(1021174981928414237)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(179743730524086789)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1021176178534414249)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(179743289580086788)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(516986697479806352)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1021175855832414245)
,p_button_name=>'Cerrar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(179314748967062478)
,p_button_image_alt=>'Cerrar'
,p_icon_css_classes=>'fa-times'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44086886512289510)
,p_name=>'P114_NIVEL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(1021176178534414249)
,p_prompt=>'Nivel'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(179314285338062478)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44086901006289511)
,p_name=>'P114_PAISCOD'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(1021176178534414249)
,p_prompt=>'Paiscod'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(179314285338062478)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(512379936535606937)
,p_name=>'P114_EDITAR'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(1021176178534414249)
,p_prompt=>'Editar'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(179314285338062478)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(516987389502806354)
,p_name=>'P114_CODIGO_GRUPO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1021174981928414237)
,p_prompt=>'Grupo'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(179314056998062478)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(516987715126806356)
,p_name=>'P114_NOMBRE_GRUPO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1021174981928414237)
,p_prompt=>'Nombre'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(179314056998062478)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(516988108629806357)
,p_name=>'P114_TIPOENVIO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1021174981928414237)
,p_prompt=>unistr('Tipo Env\00CDo')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'SELECT DESCRIPCION,TIPO_ENVIO FROM VT_TRAD_TIPOENVIO ORDER BY TIPO_ENVIO '
,p_read_only_when=>'P114_EDITAR'
,p_read_only_when2=>'1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(179314056998062478)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'4'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(516988562024806357)
,p_name=>'P114_PCODIGOPDV'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1021176178534414249)
,p_prompt=>'p_Codigopdv'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(179314056998062478)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(516993743967806373)
,p_name=>'P114_MENSAJE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1021176178534414249)
,p_prompt=>'Mensaje'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(179314056998062478)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(516994114037806374)
,p_name=>'P114_CODIGO_PDV'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1021176178534414249)
,p_prompt=>'Codigo Pdv'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(179314056998062478)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(516999220377806391)
,p_name=>'ValidaPorcentaje'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1021175099750414238)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridselectionchange'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P114_TIPOENVIO'
,p_display_when_cond2=>'1'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(516999766683806392)
,p_event_id=>wwv_flow_imp.id(516999220377806391)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'validaProcentaje();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(516996096784806387)
,p_name=>'CambiarPromocional'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P114_CODIGO_PDV'
,p_condition_element=>'P114_CODIGO_PDV'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P114_TIPOENVIO'
,p_display_when_cond2=>'2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(516996567811806389)
,p_event_id=>wwv_flow_imp.id(516996096784806387)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'CODIGO_PDV'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(516998386806806391)
,p_name=>'New'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P114_PCODIGOPDV'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(516998804182806391)
,p_event_id=>wwv_flow_imp.id(516998386806806391)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'TIPOENVIOPDV'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(516996994105806390)
,p_name=>'TIPO ENVIO'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P114_TIPOENVIO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(516997444689806391)
,p_event_id=>wwv_flow_imp.id(516996994105806390)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update t_trad_cliente tipo set ENVIOTIPO=:P114_TIPOENVIO where 1=1 AND CODIGOPDV=:P114_PCODIGOPDV AND ESTADO= 1;',
'',
'pk_commons.sp_apex_log(''APEX.gestionarenviosmultiples'',1,''update t_trad_cliente tipo set ENVIOTIPO=''||:P114_TIPOENVIO||'' where 1=1 AND CODIGOPDV=''||:P114_PCODIGOPDV||'' AND ESTADO= 1;'',''yyy'',''zzz'',null); ',
'--  if(:P114_TIPOENVIO in(0,3))then ',
'--      update t_trad_clientelocal set PORCENTAJEPROMO=0,PROMOCIONAL=0 where CODIGOPDV=:P114_PCODIGOPDV AND ESTADO= 1;',
'--  end if; ',
'--  if(:P114_TIPOENVIO=1)then ',
'--      update t_trad_clientelocal set PROMOCIONAL=0 where CODIGOPDV=:P114_PCODIGOPDV AND ESTADO= 1;',
'--  end if; ',
'--  if(:P114_TIPOENVIO=2)then ',
'--      update t_trad_clientelocal set PORCENTAJEPROMO=0 where CODIGOPDV=:P114_PCODIGOPDV AND ESTADO= 1;',
'--  end if; ',
unistr('--  apex_application.g_print_success_message := ''\00A1Registro guardado exitosamente!'';')))
,p_attribute_02=>'P114_TIPOENVIO,P114_PCODIGOPDV'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(516997964874806391)
,p_event_id=>wwv_flow_imp.id(516996994105806390)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'TIPOENVIOPDV'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(44086613626289508)
,p_name=>'Cerrar'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(516986697479806352)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44086780778289509)
,p_event_id=>wwv_flow_imp.id(44086613626289508)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(102009024811274802)
,p_name=>'New_1'
,p_event_sequence=>70
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1021175099750414238)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridsave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102009122980274803)
,p_event_id=>wwv_flow_imp.id(102009024811274802)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1021175099750414238)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(102295782302789431)
,p_name=>'New_2'
,p_event_sequence=>80
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(1021175099750414238)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102295855990789432)
,p_event_id=>wwv_flow_imp.id(102295782302789431)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'console.log(''dfdsfsdf'');'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(516993137771806372)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(1021175099750414238)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Detalle - Save Interactive Grid Data'
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'v_codigopdv varchar2(10);',
'v_numero varchar2(10);',
'BEGIN',
'    :P114_MENSAJE:='''';',
'    if (:P114_TIPOENVIO = 2)then',
'',
'        UPDATE t_trad_clientelocal',
'        SET PROMOCIONAL=0',
'        WHERE  CODIGOPDV=:CODIGOPDV;',
'        ',
'        UPDATE t_trad_clientelocal',
'        SET PROMOCIONAL=1',
'        WHERE CODIGOPDV=:CODIGOPDV AND NUMERO=:NUMERO;',
'',
'    elsif (:P114_TIPOENVIO in  (1,3))then',
'        UPDATE t_trad_clientelocal',
'        SET porcentajepromo=:porcentajepromo',
'        WHERE 1=1',
'        AND (CODIGOPDV=:CODIGOPDV AND NUMERO=:NUMERO) and CODIGOPDV=:CODIGOPDV;',
'        ',
'    end if;',
unistr('    apex_application.g_print_success_message := ''\00A1Registro guardado exitosamente!'';'),
'END;'))
,p_attribute_05=>'N'
,p_attribute_06=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>516993137771806372
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(516995269057806387)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'CerrarDialogo'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(516986697479806352)
,p_internal_uid=>516995269057806387
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(516995660661806387)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    SELECT ',
'             tC.CODIGOPDV,tC.razonsocial LOCAL, nvl(ENVIOTIPO,0) ENVIOTIPO',
'        into :P114_CODIGO_GRUPO,:P114_NOMBRE_GRUPO,:P114_TIPOENVIO',
'    FROM t_trad_cliente TC ',
'    WHERE 1=1',
'    and ((:P114_EDITAR=0 and tc.estado=1) or :P114_EDITAR=1)',
'    and tC.CODIGOPDV=:P114_PCODIGOPDV;',
'exception when others then',
'',
'    :P114_CODIGO_GRUPO:=null;:P114_NOMBRE_GRUPO:=null;:P114_TIPOENVIO:=0;',
'enD;',
'begin',
'    select valor INTO :P114_NIVEL from data.T_CORP_UDC ',
'    where id_cabecera = ''TRAD_NGEOG'' and codigocompania = :g_compania; ',
'    ',
'end ;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>516995660661806387
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
