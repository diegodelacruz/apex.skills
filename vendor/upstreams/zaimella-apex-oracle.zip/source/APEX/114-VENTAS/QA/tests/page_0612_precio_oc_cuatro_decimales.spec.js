const { test, expect } = require('@playwright/test');

const baseUrl = 'http://sistemas.zaimella.com:8090/apex/';
const loginUrl = `${baseUrl}f?p=100:9999::::::`;

async function firstVisible(locator) {
  const count = await locator.count().catch(() => 0);
  for (let index = 0; index < count; index += 1) {
    const item = locator.nth(index);
    if (await item.isVisible().catch(() => false)) return item;
  }
  return null;
}

async function loginPeru(page) {
  await page.goto(loginUrl, { waitUntil: 'domcontentloaded' });
  const user = await firstVisible(page.locator('input[type="text"], input:not([type])'));
  expect(user, 'Debe existir el campo de usuario').toBeTruthy();
  await user.fill('JBALCAZAR');

  const select = page.locator('select:visible').first();
  if (await select.count()) {
    const options = await select.locator('option').evaluateAll((items) =>
      items.map((item) => ({ value: item.value, text: item.textContent || '' }))
    );
    const peru = options.find((item) => /00003|peru/i.test(`${item.value} ${item.text}`));
    expect(peru, 'Debe existir la compania Peru').toBeTruthy();
    await select.selectOption(peru.value);
  }

  const button = await firstVisible(page.getByText(/Ingresar/i));
  expect(button, 'Debe existir el boton Ingresar').toBeTruthy();
  await button.click();
  await page.waitForTimeout(1500);
}

test('C23 pagina 612 muestra y conserva cuatro decimales para Peru', async ({ page }) => {
  test.setTimeout(120000);
  await loginPeru(page);
  const session = page.url().match(/f\?p=\d+:\d+:(\d+)/)?.[1] || '';
  expect(session, 'Debe existir sesion APEX activa').toBeTruthy();

  await page.goto(
    `${baseUrl}f?p=114:612:${session}::NO:RP,612:P612_NUMERO:11938`,
    { waitUntil: 'domcontentloaded' }
  );
  await expect(page.locator('body')).toContainText(/Detalle Orden/i, { timeout: 30000 });
  await expect(page.locator('body')).toContainText(/3[.,]8567/, { timeout: 30000 });
  const price = page.getByText(/3[.,]8567/).first();
  await price.scrollIntoViewIfNeeded();
  await page.screenshot({
    path: 'qa/tareas/C23/screenshots/page612_peru_precio_oc_4_decimales.png',
    fullPage: false,
  });
});
