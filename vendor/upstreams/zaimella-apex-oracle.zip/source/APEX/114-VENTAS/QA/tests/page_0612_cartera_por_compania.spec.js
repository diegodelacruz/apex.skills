const { test, expect } = require('@playwright/test');

const baseUrl = 'http://sistemas.zaimella.com:8090/apex/';
const loginUrl = `${baseUrl}f?p=100:9999::::::`;

async function firstVisible(locator) {
  const count = await locator.count().catch(() => 0);
  for (let index = 0; index < count; index += 1) {
    const item = locator.nth(index);
    if (await item.isVisible().catch(() => false)) return item;
  }
  return null;
}

async function login(page, companyPattern) {
  await page.goto(loginUrl, { waitUntil: 'domcontentloaded' });
  const user = await firstVisible(page.locator('input[type="text"], input:not([type])'));
  expect(user, 'Debe existir el campo de usuario').toBeTruthy();
  await user.fill('JBALCAZAR');

  const select = page.locator('select:visible').first();
  const options = await select.locator('option').evaluateAll((items) =>
    items.map((item) => ({ value: item.value, text: item.textContent || '' }))
  );
  const company = options.find((item) => companyPattern.test(`${item.value} ${item.text}`));
  expect(company, 'Debe existir la compania requerida').toBeTruthy();
  await select.selectOption(company.value);

  const button = await firstVisible(page.getByText(/Ingresar/i));
  expect(button, 'Debe existir el boton Ingresar').toBeTruthy();
  await button.click();
  await page.waitForTimeout(1500);

  const session = page.url().match(/f\?p=\d+:\d+:(\d+)/)?.[1] || '';
  expect(session, 'Debe existir sesion APEX activa').toBeTruthy();
  return session;
}

async function openPedido(page, session, pedido) {
  await page.goto(
    `${baseUrl}f?p=114:612:${session}::NO:RP,612:P612_NUMERO:${pedido}`,
    { waitUntil: 'domcontentloaded' }
  );
  await expect(page.locator('body')).toContainText(/Detalle Orden/i, { timeout: 30000 });
  await expect(page.locator('body')).not.toContainText(/ORA-00904|identificador no v[aá]lido/i);
}

test('C25 pagina 612 carga cartera Peru sin ORA-00904', async ({ page }) => {
  test.setTimeout(120000);
  const session = await login(page, /00003|peru/i);
  await openPedido(page, session, 11938);
  await expect(page.locator('body')).toContainText(/3[.,]8567/, { timeout: 30000 });
});

test('C25 pagina 612 conserva carga Ecuador sin ORA-00904', async ({ page }) => {
  test.setTimeout(120000);
  const session = await login(page, /00001|ecuador/i);
  await openPedido(page, session, 11951);
});
