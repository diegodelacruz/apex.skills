prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>114
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 114 - Ventas
--
-- Application Export:
--   Application:     114
--   Name:            Ventas
--   Date and Time:   14:54 Wednesday August 5, 2026
--   Exported By:     JBALCAZAR
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 612
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800175940242830
--

begin
null;
end;
/
prompt --application/pages/delete_00612
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>612);
end;
/
prompt --application/pages/page_00612
begin
wwv_flow_imp_page.create_page(
 p_id=>612
,p_name=>'Pedido Ingresar'
,p_alias=>'ORDEN-DE-COMPRA'
,p_step_title=>'Pedido - Orden de compra'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-table tr th:nth-child(6),.a-IRR-table tr td:nth-child(6)',
'{',
'    position: sticky;',
'    left: 0em !important;',
'}',
'',
'.a-IRR-table tr th:nth-child(7),.a-IRR-table tr td:nth-child(7)',
'{',
'    position: sticky;',
'    left: 9em !important;',
'}',
'',
'.a-IRR-table tr th:nth-child(8),.a-IRR-table tr td:nth-child(8)',
'{',
'    position: sticky;',
'    left: 17em !important;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(130554266745713927)
,p_plug_name=>'Pedido - Orden de compra'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_imp.id(207624090311798915)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(207077902574778828)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(207177697621778923)
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Orden de Compra'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(130554307024713928)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(207622883613798915)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(130554462741713929)
,p_plug_name=>'Formulario'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(207623277923798915)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(123610224540198040)
,p_plug_name=>'Excel'
,p_parent_plug_id=>wwv_flow_imp.id(130554462741713929)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(207123407083778876)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select C01, C02,C03,C04,C05,C06,C07,C08,C09,C10,C11, ',
'      C12,C13,C14,C15,C16,C17,C18,C19,C20,C21',
'      from VT_APEX_EXCEL;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'NEVER'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Excel'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(156846217151939704)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>156846217151939704
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(156846336230939705)
,p_db_column_name=>'C01'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'C01'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(156846457442939706)
,p_db_column_name=>'C02'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'C02'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(156846574058939707)
,p_db_column_name=>'C03'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'C03'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(156846685832939708)
,p_db_column_name=>'C04'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'C04'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(156846731227939709)
,p_db_column_name=>'C05'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'C05'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(156846887799939710)
,p_db_column_name=>'C06'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'C06'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(156846916520939711)
,p_db_column_name=>'C07'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'C07'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(156847066249939712)
,p_db_column_name=>'C08'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'C08'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(156847119614939713)
,p_db_column_name=>'C09'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'C09'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(156847233704939714)
,p_db_column_name=>'C10'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'C10'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(156847373008939715)
,p_db_column_name=>'C11'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'C11'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(156847461318939716)
,p_db_column_name=>'C12'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'C12'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(156847562382939717)
,p_db_column_name=>'C13'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'C13'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(156847612335939718)
,p_db_column_name=>'C14'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'C14'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(156847781318939719)
,p_db_column_name=>'C15'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'C15'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(156847829742939720)
,p_db_column_name=>'C16'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'C16'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(156847927596939721)
,p_db_column_name=>'C17'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'C17'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(156848090302939722)
,p_db_column_name=>'C18'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'C18'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(156848130698939723)
,p_db_column_name=>'C19'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'C19'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(156848254837939724)
,p_db_column_name=>'C20'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'C20'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(156848388312939725)
,p_db_column_name=>'C21'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'C21'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(156896603034550600)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1568967'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'C01:C02:C03:C04:C05:C06:C07:C08:C09:C10:C11:C12:C13:C14:C15:C16:C17:C18:C19:C20:C21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(130555559067713940)
,p_plug_name=>'Detalle Orden'
,p_parent_plug_id=>wwv_flow_imp.id(130554462741713929)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(207622408396798914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CASE WHEN PE.ESTADO = 1 THEN apex_item.checkbox(1,PE.LINEA,''class="chkF01"'') else '''' end seleccion,pe.codigocliente,PE.IDPEDIDO,PE.LINEA, ',
'PE.GRUPO, PE.CODIGOPRODUCTOCLIENTE, PE.NOMBREPRODUCTO, PE.CODIGOBARRA, ',
'PE.CODIGOPRODUCTO, estado_Producto,LINEA_NEGOCIO,PROMOCIONAL,',
'PE.PRESENTACION, PE.CANTIDAD_BU_CA,PE.CANTIDAD_UND, PE.CANTIDAD_BU_CA_OC,PE.CANTIDAD_OC, ',
'PE.PRECIO, precio_final,PE.CANTIDADSUGERIDA, ',
'case when PE.COMPANIA = ''00003'' then to_char(PE.PRECIO_OC, ''FML999G999G999G999G990D0000'') else to_char(PE.PRECIO_OC, ''FML999G999G999G999G990D00'') end as PRECIO_OC,',
'PE.DESCUENTO, PE.DESCUENTO_OC,',
'case when PE.COMPANIA = ''00003'' then to_char(precio_oc_final, ''FML999G999G999G999G990D0000'') else to_char(precio_oc_final, ''FML999G999G999G999G990D00'') end as PRECIO_OC_FINAL,',
'PE.ICE, PE.TOTAL,PE.TOTAL_OC,total_diferencia,PE.ESTADO,to_char(PE.TIPOINACTIVO) as TIPOINACTIVO,PE.OBSERVACION,CLIPRO.ESTADOCICLO,',
'pk_vtas_pedidos.f_numerrores(p_idpedido => pe.idpedido, p_linea => pe.linea) as n_errores,',
'pk_vtas_pedidos.f_mensaje_errores(p_idpedido => pe.idpedido, p_linea => pe.linea) as msg_errores,',
'cast(null as number) CANT_TOTALHIJAS, cast(null as number) CANT_TOTALPADRE, VOLUMEN,',
'PE.PRECIO AS PRECIO_EC, precio_final AS PRECIO_FINAL_EC, PE.TOTAL_OC AS TOTAL_OC_EC, PE.TOTAL AS TOTAL_EC,',
'--pk_vtas_pedidos.f_cantidadpadre(p_idpedido => PE.IDPADRE, p_codigoproducto => PE.CODIGOPRODUCTO) AS CANT_TOTALPADRE,',
'--pk_vtas_pedidos.f_cantidadtotalhijas(p_idpedido => PE.IDPADRE, p_codigoproducto => PE.CODIGOPRODUCTO) AS CANT_TOTALHIJAS,',
'',
'CASE WHEN PE.ESTADO = 1 THEN ''<span class="fa fa-ban" aria-hidden="true" title="Inactivar"></span>'' ELSE NULL END as INACTIVAR,',
'CASE WHEN PE.ESTADO = 0 and nvl(clipro.estado, 0 ) = 0 ',
'    THEN ''<span class="fa fa-check" aria-hidden="true" title="Activar"></span>'' ELSE NULL END as ACTIVAR,',
'',
'CASE WHEN (PE.CODIGOPRODUCTO IS NULL AND nvl(PE.ESTADO,1) =1  AND PE.CODIGOPRODUCTOCLIENTE IS NOT NULL) OR ',
'    (CLIPRO.ESTADO=0  AND PE.CODIGOPRODUCTOCLIENTE IS NOT NULL)',
unistr('THEN ''<span class="fa fa-plus" title="Agregar C\00F3digo a Cliente" aria-hidden="true"></span>'' ELSE NULL END as AGREGAR, '),
'',
'pe.codigogrupo, pe.codigocliente codigocli',
'FROM vt_vtas_pedidos PE',
'    LEFT JOIN t_vtas_cliente_producto CLIPRO',
'    on (clipro.compania = pe.compania and pe.codigoproducto = clipro.codigoproducto and pe.codigogrupo = clipro.codigogrupo and PE.codigocliente = clipro.codigocliente)',
'where PE.IDPEDIDO = :P612_NUMERO',
'  and PE.COMPANIA = :G_COMPANIA'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P612_NUMERO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Detalle Orden'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(132070157540948721)
,p_max_row_count=>'1000'
,p_max_rows_per_page=>'50'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>400
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'NETBY3'
,p_internal_uid=>132070157540948721
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132070250478948722)
,p_db_column_name=>'IDPEDIDO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Idpedido'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293927614952735702)
,p_db_column_name=>'ACTIVAR'
,p_display_order=>20
,p_column_identifier=>'BH'
,p_column_label=>'ACTIVAR'
,p_column_link=>'f?p=&APP_ID.:608:&SESSION.::&DEBUG.:608:P608_GRUPO,P608_CLIENTE,P608_PRODUCTO,P608_ACCION,P608_NUMLINEA:#CODIGOGRUPO#,#CODIGOCLI#,#CODIGOPRODUCTO#,A,#LINEA#'
,p_column_linktext=>'#ACTIVAR#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132072100594948741)
,p_db_column_name=>'INACTIVAR'
,p_display_order=>30
,p_column_identifier=>'T'
,p_column_label=>'CANCELAR'
,p_column_link=>'f?p=&APP_ID.:613:&SESSION.::&DEBUG.:CR,613:P613_CODIGOBARRA,P613_CODIGOPRODUCTO,P613_CODIGOPRODUCTOCLIENT,P613_IDPEDIDO,P613_NOMBREPRODUCTO,P613_LINEA:#CODIGOBARRA#,#CODIGOPRODUCTO#,#CODIGOPRODUCTOCLIENTE#,#IDPEDIDO#,#NOMBREPRODUCTO#,#LINEA#'
,p_column_linktext=>'#INACTIVAR#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134341105270362323)
,p_db_column_name=>'AGREGAR'
,p_display_order=>40
,p_column_identifier=>'AC'
,p_column_label=>'HOMOLOGAR'
,p_column_link=>'f?p=&APP_ID.:614:&SESSION.::&DEBUG.:CR,614:P614_IDPEDIDO,P614_CODIGOPRODUCTOCLI,P614_CODIGOBARRA,P614_LINEA,P614_NOMBREPROD:#IDPEDIDO#,#CODIGOPRODUCTOCLIENTE#,#CODIGOBARRA#,#LINEA#,#NOMBREPRODUCTO#'
,p_column_linktext=>'#AGREGAR#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(151436645326046605)
,p_db_column_name=>'SELECCION'
,p_display_order=>60
,p_column_identifier=>'BB'
,p_column_label=>'SELECCIONAR'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(135647961020929018)
,p_db_column_name=>'LINEA'
,p_display_order=>70
,p_column_identifier=>'AN'
,p_column_label=>'Linea'
,p_column_type=>'NUMBER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132070324130948723)
,p_db_column_name=>'GRUPO'
,p_display_order=>80
,p_column_identifier=>'B'
,p_column_label=>'Grupo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132070412875948724)
,p_db_column_name=>'CODIGOPRODUCTOCLIENTE'
,p_display_order=>90
,p_column_identifier=>'C'
,p_column_label=>unistr('C\00F3digo cliente')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132070725020948727)
,p_db_column_name=>'CODIGOPRODUCTO'
,p_display_order=>100
,p_column_identifier=>'F'
,p_column_label=>unistr('C\00F3digo ZM')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132070635553948726)
,p_db_column_name=>'CODIGOBARRA'
,p_display_order=>110
,p_column_identifier=>'E'
,p_column_label=>'EAN 13'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132070510680948725)
,p_db_column_name=>'NOMBREPRODUCTO'
,p_display_order=>120
,p_column_identifier=>'D'
,p_column_label=>unistr(' Descripci\00F3n producto')
,p_column_html_expression=>'<span style="display:block; width:250px">#NOMBREPRODUCTO#</span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132071308487948733)
,p_db_column_name=>'CANTIDADSUGERIDA'
,p_display_order=>130
,p_column_identifier=>'L'
,p_column_label=>'Cantidad Sugerida'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132071487280948734)
,p_db_column_name=>'DESCUENTO'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>'Descuento ZM'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132071646174948736)
,p_db_column_name=>'PRECIO'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Precio ZM'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':G_COMPANIA <> ''00001'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(900000000000000001)
,p_db_column_name=>'PRECIO_EC'
,p_display_order=>151
,p_column_identifier=>'BG'
,p_column_label=>'Precio ZM'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':G_COMPANIA = ''00001'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132071726764948737)
,p_db_column_name=>'CANTIDAD_OC'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Cantidad OC'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P612_TIPO'
,p_display_condition2=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132071806143948738)
,p_db_column_name=>'PRECIO_OC'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Precio OC'
,p_column_type=>'STRING'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P612_TIPO'
,p_display_condition2=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132071919905948739)
,p_db_column_name=>'DESCUENTO_OC'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Descuento OC'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P612_TIPO'
,p_display_condition2=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132072099904948740)
,p_db_column_name=>'ICE'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Ice'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134340352313362315)
,p_db_column_name=>'PRESENTACION'
,p_display_order=>200
,p_column_identifier=>'U'
,p_column_label=>'um'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134340480762362316)
,p_db_column_name=>'CANTIDAD_BU_CA'
,p_display_order=>210
,p_column_identifier=>'V'
,p_column_label=>'Cantidad  a enviar Bu / Ca'
,p_column_html_expression=>'<span class="#DIF_CANTIDAD#">#CANTIDAD_BU_CA#</span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134340543652362317)
,p_db_column_name=>'CANTIDAD_UND'
,p_display_order=>220
,p_column_identifier=>'W'
,p_column_label=>'Cantidad a enviar Pq / Un'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P612_TIPO'
,p_display_condition2=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134340640950362318)
,p_db_column_name=>'CANTIDAD_BU_CA_OC'
,p_display_order=>230
,p_column_identifier=>'X'
,p_column_label=>'Cantidad Bu/Ca Oc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P612_TIPO'
,p_display_condition2=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134340955848362321)
,p_db_column_name=>'TOTAL'
,p_display_order=>240
,p_column_identifier=>'AA'
,p_column_label=>'Total ZM'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':G_COMPANIA <> ''00001'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(900000000000000002)
,p_db_column_name=>'TOTAL_EC'
,p_display_order=>241
,p_column_identifier=>'BH'
,p_column_label=>'Total ZM'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':G_COMPANIA = ''00001'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134341008750362322)
,p_db_column_name=>'TOTAL_OC'
,p_display_order=>250
,p_column_identifier=>'AB'
,p_column_label=>'Total Oc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':G_COMPANIA = ''00003'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(900000000000000003)
,p_db_column_name=>'TOTAL_OC_EC'
,p_display_order=>251
,p_column_identifier=>'BI'
,p_column_label=>'Total Oc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':G_COMPANIA = ''00001'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134341969225362331)
,p_db_column_name=>'ESTADO'
,p_display_order=>260
,p_column_identifier=>'AD'
,p_column_label=>unistr('L\00EDnea')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(117652766075112970)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134342169150362333)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>270
,p_column_identifier=>'AF'
,p_column_label=>unistr('Observaci\00F3n')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134342381937362335)
,p_db_column_name=>'TIPOINACTIVO'
,p_display_order=>280
,p_column_identifier=>'AH'
,p_column_label=>unistr('Tipo de cancelaci\00F3n')
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(135134069597792485)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(135145710592062311)
,p_db_column_name=>'ESTADOCICLO'
,p_display_order=>290
,p_column_identifier=>'AI'
,p_column_label=>'Estado Ciclo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(117655439470138631)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(135648686432929025)
,p_db_column_name=>'N_ERRORES'
,p_display_order=>300
,p_column_identifier=>'AR'
,p_column_label=>'N Errores'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(135648745789929026)
,p_db_column_name=>'MSG_ERRORES'
,p_display_order=>310
,p_column_identifier=>'AS'
,p_column_label=>unistr('Descripci\00F3n Novedades')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123610046080198038)
,p_db_column_name=>'CANT_TOTALPADRE'
,p_display_order=>320
,p_column_identifier=>'AT'
,p_column_label=>'CantIdad Total padre'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P612_TIPO  IN (3)  '
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123610109815198039)
,p_db_column_name=>'CANT_TOTALHIJAS'
,p_display_order=>330
,p_column_identifier=>'AU'
,p_column_label=>'CantIdad Total hijas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P612_TIPO  IN (3)  '
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(126975129499698148)
,p_db_column_name=>'CODIGOCLIENTE'
,p_display_order=>340
,p_column_identifier=>'AV'
,p_column_label=>'Cliente'
,p_column_html_expression=>'<span style="display:block; width:200px">#CODIGOCLIENTE#</span>'
,p_allow_filtering=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(126975322219698150)
,p_db_column_name=>'ESTADO_PRODUCTO'
,p_display_order=>350
,p_column_identifier=>'AX'
,p_column_label=>'Estado Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(151436238921046601)
,p_db_column_name=>'LINEA_NEGOCIO'
,p_display_order=>360
,p_column_identifier=>'AY'
,p_column_label=>'Linea Negocio'
,p_column_html_expression=>'<span style="display:block; width:200px">#LINEA_NEGOCIO#</span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(151436365506046602)
,p_db_column_name=>'PROMOCIONAL'
,p_display_order=>370
,p_column_identifier=>'AZ'
,p_column_label=>'Promocional'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(151436468039046603)
,p_db_column_name=>'TOTAL_DIFERENCIA'
,p_display_order=>380
,p_column_identifier=>'BA'
,p_column_label=>'Total Diferencia'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P612_TIPO'
,p_display_condition2=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(151796311532694023)
,p_db_column_name=>'PRECIO_FINAL'
,p_display_order=>390
,p_column_identifier=>'BE'
,p_column_label=>'Precio Final ZM'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':G_COMPANIA = ''00003'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(900000000000000004)
,p_db_column_name=>'PRECIO_FINAL_EC'
,p_display_order=>391
,p_column_identifier=>'BJ'
,p_column_label=>'Precio Final ZM'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':G_COMPANIA = ''00001'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(151796432956694024)
,p_db_column_name=>'PRECIO_OC_FINAL'
,p_display_order=>400
,p_column_identifier=>'BF'
,p_column_label=>'Precio Oc Final'
,p_column_type=>'STRING'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P612_TIPO'
,p_display_condition2=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(246182876716033006)
,p_db_column_name=>'VOLUMEN'
,p_display_order=>410
,p_column_identifier=>'BG'
,p_column_label=>'Volumen'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P612_TIPO  IN (2,3) '
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293927711054735703)
,p_db_column_name=>'CODIGOGRUPO'
,p_display_order=>420
,p_column_identifier=>'BI'
,p_column_label=>'Codigogrupo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293927831660735704)
,p_db_column_name=>'CODIGOCLI'
,p_display_order=>430
,p_column_identifier=>'BJ'
,p_column_label=>'Codigocli'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(134322451815535777)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1343225'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SELECCION:ACTIVAR:AGREGAR:INACTIVAR:CODIGOCLIENTE:CODIGOPRODUCTOCLIENTE:CODIGOBARRA:CODIGOPRODUCTO:NOMBREPRODUCTO:LINEA_NEGOCIO:PROMOCIONAL:ESTADO_PRODUCTO:ESTADOCICLO:PRESENTACION:CANTIDAD_OC:CANTIDAD_BU_CA_OC:CANTIDAD_BU_CA:CANTIDAD_UND:CANTIDADSUG'
||'ERIDA:PRECIO_OC:DESCUENTO_OC:PRECIO_OC_FINAL:PRECIO:PRECIO_EC:DESCUENTO:ICE:PRECIO_FINAL:PRECIO_FINAL_EC:TOTAL_OC:TOTAL_OC_EC:TOTAL:TOTAL_EC:TOTAL_DIFERENCIA:ESTADO:TIPOINACTIVO:OBSERVACION:MSG_ERRORES:'
,p_sort_column_1=>'N_ERRORES'
,p_sort_direction_1=>'DESC NULLS LAST'
,p_sort_column_2=>'ESTADO'
,p_sort_direction_2=>'ASC NULLS LAST'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_sum_columns_on_break=>'TOTAL_OC:TOTAL_OC_EC:TOTAL:TOTAL_EC:TOTAL_DIFERENCIA:CANTIDAD_BU_CA:VOLUMEN'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(314280624246745284)
,p_report_id=>wwv_flow_imp.id(134322451815535777)
,p_name=>'INACTIVOS'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ESTADO'
,p_operator=>'='
,p_expr=>'Inactivo'
,p_condition_sql=>' (case when ("ESTADO" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''Inactivo''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#ffd6d2'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(314281016627745285)
,p_report_id=>wwv_flow_imp.id(134322451815535777)
,p_name=>'NOVEDADES'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'N_ERRORES'
,p_operator=>'>'
,p_expr=>'0'
,p_condition_sql=>' (case when ("N_ERRORES" > to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#fcff5c'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(134343509417362347)
,p_plug_name=>'Resumen orden de compra '
,p_parent_plug_id=>wwv_flow_imp.id(130554462741713929)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(207622408396798914)
,p_plug_display_sequence=>30
,p_plug_grid_column_span=>6
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT LINEA_NEGOCIO, SUM(total) AS TOTAL, SUM(cantidad_bu_ca) AS cantidad_bu_ca',
'FROM vt_vtas_pedidos ped ',
'where ped.idpedido = :P612_NUMERO  and ped.estado = 1 AND codigoproducto IS NOT NULL',
'GROUP BY LINEA_NEGOCIO;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P612_NUMERO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Resumen orden de compra '
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(135144857972062302)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'NETBY3'
,p_internal_uid=>135144857972062302
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(135145073903062304)
,p_db_column_name=>'TOTAL'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Total $ '
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(151439623198046635)
,p_db_column_name=>'LINEA_NEGOCIO'
,p_display_order=>30
,p_column_identifier=>'D'
,p_column_label=>'Linea Negocio'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(151439780078046636)
,p_db_column_name=>'CANTIDAD_BU_CA'
,p_display_order=>40
,p_column_identifier=>'E'
,p_column_label=>'Total Bu/Ca'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(135158165756066410)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1351582'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LINEA_NEGOCIO:CANTIDAD_BU_CA:TOTAL:'
,p_sum_columns_on_break=>'TOTAL:TOTAL_OC:CANTIDAD_BU_CA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(240055039921560605)
,p_plug_name=>unistr('Datos exportaci\00F3n')
,p_parent_plug_id=>wwv_flow_imp.id(130554462741713929)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(207113483708778870)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(255642224701309310)
,p_plug_name=>'Datos cliente'
,p_parent_plug_id=>wwv_flow_imp.id(130554462741713929)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(207623277923798915)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>9
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(255642315284309311)
,p_plug_name=>'Cartera cliente'
,p_parent_plug_id=>wwv_flow_imp.id(130554462741713929)
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(207113483708778870)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(151797214080694032)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(130554307024713928)
,p_button_name=>'ATRAS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176753300778920)
,p_button_image_alt=>'Atras'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(194491850862136235)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(130554307024713928)
,p_button_name=>'ELIMINAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176753300778920)
,p_button_image_alt=>'Eliminar'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-trash'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(132069464257948714)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(130554307024713928)
,p_button_name=>'BTN_ADJUNTAR'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176753300778920)
,p_button_image_alt=>'Adjuntos'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:401:&SESSION.::&DEBUG.:RP,401:P401_TABLA,P401_ID,P401_ESTADO:T_VTAS_PEDIDOS_CAB,&P612_NUMERO.,1'
,p_button_condition=>'P612_NUMERO'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-paperclip'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(126973877171698135)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(130554307024713928)
,p_button_name=>'BTN_COMENTARIO'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176753300778920)
,p_button_image_alt=>'Comentario'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:105:&SESSION.::&DEBUG.:RP,401:G_MODULO,G_COMPANIA,G_USUARIO,G_OBJETO_ID,G_OBJETO:&APP_MODULO.,&G_COMPANIA.,&APP_USER.,&P612_NUMERO.,PEDIDO'
,p_button_condition=>'P612_NUMERO'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-comment'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(156848717085939729)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(130554307024713928)
,p_button_name=>'PDF_EXCEL'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176753300778920)
,p_button_image_alt=>'Adjuntar PDF OC'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:401:&SESSION.::&DEBUG.:RP,401:P401_TABLA,P401_ID,P401_ESTADO,P401_TIPO:T_VTAS_PEDIDOS_CAB,&P612_NUMERO.,1,OC_PDF'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P612_NUMERO IS NOT NULL AND :G_COMPANIA = ''00003'''
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-file-pdf-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(230314153811306447)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(130554307024713928)
,p_button_name=>'HTML_EXCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176753300778920)
,p_button_image_alt=>'Convertir HTML a EXCEL'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-file-excel-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(156848717085939740)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(130554307024713928)
,p_button_name=>'PROCESAR_PDF_OC'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176753300778920)
,p_button_image_alt=>'Procesar PDF OC'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=114:617:&SESSION.::&DEBUG.:RP,617:P617_ID:&P612_NUMERO.'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P612_NUMERO IS NOT NULL AND :G_COMPANIA = ''00003'''
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-file-pdf-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(132069514475948715)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(130554307024713928)
,p_button_name=>'BTN_AGREGAROC'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176753300778920)
,p_button_image_alt=>'Ingresar OC'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:300:&SESSION.::&DEBUG.:RP,300:G_VALOR1:0'
,p_icon_css_classes=>'fa-upload'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(130555464212713939)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(130554307024713928)
,p_button_name=>'GUARDAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176753300778920)
,p_button_image_alt=>'Guardar'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(132068555705948705)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(130554307024713928)
,p_button_name=>'ENVIAR_INICIO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176753300778920)
,p_button_image_alt=>'Enviar'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P612_NUMERO is not NULL'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(151438323532046622)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(130554307024713928)
,p_button_name=>'ENVIAR_RUTA'
,p_button_static_id=>'btnEnviar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176753300778920)
,p_button_image_alt=>'Enviar'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:107:&SESSION.::&DEBUG.::G_VALOR1:&P612_ERRORES.'
,p_button_condition=>':P612_NUMERO is not NULL'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-check-circle-o'
,p_button_cattributes=>'style="     display: none; "'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(251020952361896427)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(130555559067713940)
,p_button_name=>'PDF_OC'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176753300778920)
,p_button_image_alt=>'Pdf Oc'
,p_button_position=>'COPY'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P612_TIPO'
,p_button_condition2=>'3'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-file-pdf-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(277882599174794346)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(130555559067713940)
,p_button_name=>'DESCARGAR_FORMATO'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176753300778920)
,p_button_image_alt=>'Formato'
,p_button_position=>'COPY'
,p_button_redirect_url=>'#APP_FILES#Formatos/Detalle Orden.xlsx'
,p_button_condition=>'PK_VTAS_PEDIDOS_COMMONS.F_PEDIDO_MANUAL(:app_user)=1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-download'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(277882698006794347)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(130555559067713940)
,p_button_name=>'SUBIR_FORMATO'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176753300778920)
,p_button_image_alt=>'Subir formato'
,p_button_position=>'COPY'
,p_button_redirect_url=>'f?p=100:300:&SESSION.::&DEBUG.:RP,300:G_VALOR1:0'
,p_button_condition=>'PK_VTAS_PEDIDOS_COMMONS.F_PEDIDO_MANUAL(:app_user)=1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-upload'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(258271544325561937)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(130555559067713940)
,p_button_name=>'SUGERIDO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176753300778920)
,p_button_image_alt=>'Sugerido'
,p_button_position=>'COPY'
,p_icon_css_classes=>'fa-shopping-basket'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(151438979470046628)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(130555559067713940)
,p_button_name=>'CANCELAR_MASIVO'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176753300778920)
,p_button_image_alt=>'Cancelar Masivo'
,p_button_position=>'COPY'
,p_button_redirect_url=>'f?p=100:107:&SESSION.::&DEBUG.::G_VALOR1:1'
,p_icon_css_classes=>'fa-ban'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(151797157382694031)
,p_branch_name=>'Go To Page 100'
,p_branch_action=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(194491850862136235)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(194492343437136240)
,p_branch_name=>'Go To Page 100'
,p_branch_action=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(151438323532046622)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(123609988734198037)
,p_name=>'P612_CLIENTE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(255642224701309310)
,p_prompt=>'Cliente'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select codigocliente || '' - '' || nombres, codigocliente',
'from vt_gzm_cliente',
'where ESTADO = 1',
'  AND codigogrupo = :P612_GRUPOCLIENTE',
'  AND codigocliente <> :P612_GRUPOCLIENTE',
'  AND compania = :G_COMPANIA'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Todos'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(123610355251198041)
,p_name=>'P612_SUBTOTAL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(123610224540198040)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(123610426150198042)
,p_name=>'P612_ICE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(123610224540198040)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(123610584984198043)
,p_name=>'P612_TOTAL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(123610224540198040)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(126974155557698138)
,p_name=>'P612_ERRORES'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(130554462741713929)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(126974910372698146)
,p_name=>'P612_COMENTARIO_RUTA'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(130554462741713929)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(130554782798713932)
,p_name=>'P612_GRUPOCLIENTE'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(255642224701309310)
,p_prompt=>'Grupo'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_GZM_GRUPOCLIENTES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  CODIGOGRUPO || '' - '' || GRUPO D, CODIGOGRUPO R FROM VT_GZM_CLIENTE',
'WHERE ESTADO = 1 AND CODIGOGRUPO = CODIGOCLIENTE AND (:G_ROL = 1 OR (:G_ROL = 2 AND EJECUTIVO = :G_IDENTIFICACION))',
'AND COMPANIA = :G_COMPANIA  AND CODIGOCANAL <>''.  '' ;'))
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(130554809499713933)
,p_name=>'P612_ORIGEN'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(130554462741713929)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(130555144517713936)
,p_name=>'P612_TIPO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(255642224701309310)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION, VALOR ',
'FROM T_CORP_UDC ',
'WHERE ID_CABECERA = ''VTAS_TOC'' AND ACTIVO = ''1'' ',
'AND ((:P612_ORIGEN = ''NAC'' AND VALOR = ''1'')',
' OR (:P612_ORIGEN = ''EXT'' AND VALOR IN (''2'',''3'')))'))
,p_lov_cascade_parent_items=>'P612_ORIGEN'
,p_ajax_items_to_submit=>'P612_ORIGEN'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(130555284620713937)
,p_name=>'P612_ORDENPADRE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(255642224701309310)
,p_prompt=>'Orden Padre'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ORDENCOMPRA D, PED.IDPEDIDO AS R',
'FROM T_VTAS_PEDIDOS_CAB PED',
'WHERE PED.ESTADO = 1',
'  AND PED.TIPO = 2',
'  AND PED.CODIGOCLIENTE = :P612_CLIENTE',
'  AND PED.COMPANIA = :G_COMPANIA and AUDITORIAFECHA > sysdate-90'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P612_TIPO,P612_CLIENTE'
,p_ajax_items_to_submit=>'P612_TIPO,P612_CLIENTE,G_COMPANIA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(130555718375713942)
,p_name=>'P612_NUMERO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(255642224701309310)
,p_prompt=>'# Pedido'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(130555889578713943)
,p_name=>'P612_FECHAENTREGA'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(255642224701309310)
,p_prompt=>'Fecha entrega'
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(130555989856713944)
,p_name=>'P612_OBSERVACION'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(255642224701309310)
,p_prompt=>unistr('Observaci\00F3n')
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(130556045182713945)
,p_name=>'P612_LICITACION'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(255642224701309310)
,p_item_default=>'0'
,p_prompt=>'Licitacion'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_UDC_ESTADO_SI_NO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DESCRIPCION2,VALOR  from T_CORP_UDC',
'WHERE ID_CABECERA = ''ESTADOS''',
'ORDER BY DESCRIPCION ASC'))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(132069233345948712)
,p_name=>'P612_TIPOUNIDAD'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(255642224701309310)
,p_prompt=>unistr('Tipo Presentaci\00F3n')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_VTAS_TIPOUNIDAD'
,p_lov=>'SELECT DESCRIPCION D, ID_TABLA R FROM T_CORP_UDC WHERE id_cabecera = ''VTAS_PUND'';'
,p_cHeight=>1
,p_display_when=>'P612_NUMERO'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(151437427451046613)
,p_name=>'P612_COMENTARIO_CANCELAR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(130555559067713940)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(151439948712046638)
,p_name=>'P612_ORDEN_COMPRA'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(255642224701309310)
,p_prompt=>'Orden compra'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>23
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(151798259203694042)
,p_name=>'P612_OC_VALIDA'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(130554462741713929)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(156845957058939701)
,p_name=>'P612_SEPARADOR'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(130554462741713929)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(156846164472939703)
,p_name=>'P612_ARCHIVO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(130554462741713929)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(156848424945939726)
,p_name=>'P612_ERROR_MENSAJE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(130554462741713929)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(240055167955560606)
,p_name=>'P612_TIPO_CONTENEDOR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(240055039921560605)
,p_prompt=>'Tipo Contenedor'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_TIPO_CONTENEDOR'
,p_lov=>'SELECT DESCRIPCION, ID FROM VT_VTAS_TIPO_CONTENEDOR '
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(240055301566560608)
,p_name=>'P612_TIPO_NEGOCIACION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(240055039921560605)
,p_prompt=>'Tipo Negociacion'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_TIPO_NEGOCIACION_EXP'
,p_lov=>'SELECT ID, DESCRIPCION FROM VT_VTAS_TIPO_NEGOCIACION_EXP'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(240055416017560609)
,p_name=>'P612_RUTA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(240055039921560605)
,p_prompt=>'Ruta'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_RUTA_EXP'
,p_lov=>'SELECT ID, DESCRIPCION FROM VT_VTAS_RUTA_EXP'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(240055542594560610)
,p_name=>'P612_PARTIDA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(240055039921560605)
,p_prompt=>'Partida'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_PARTIDA_EXP'
,p_lov=>'SELECT ID, DESCRIPCION FROM VT_VTAS_PARTIDA_EXP'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(240055641117560611)
,p_name=>'P612_MODO_TRANSPORTE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(240055039921560605)
,p_prompt=>'Modo  de Transporte'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_TRANSPORTE_EXP'
,p_lov=>'SELECT ID, DESCRIPCION FROM VT_VTAS_TRANSPORTE_EXP'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(240055734423560612)
,p_name=>'P612_INFOADICIONAL'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(255642224701309310)
,p_prompt=>unistr('Informaci\00F3n adicional')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cMaxlength=>30
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(240055808107560613)
,p_name=>'P612_INFOADICIONAL2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(255642224701309310)
,p_prompt=>unistr('Informaci\00F3n adicional 2')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cMaxlength=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(246182726797033005)
,p_name=>'P612_OC_CLIENTE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(240055039921560605)
,p_prompt=>'OC cliente'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(254230456030921234)
,p_name=>'P612_FECHA_MIN'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(130554462741713929)
,p_source=>'sysdate'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(255642444386309312)
,p_name=>'P612_CUPO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(255642315284309311)
,p_prompt=>'Cupo'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>7
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(255642586008309313)
,p_name=>'P612_SALDO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(255642315284309311)
,p_prompt=>'Saldo Pendiente'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>7
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(255642655218309314)
,p_name=>'P612_POR_FACTURAR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(255642315284309311)
,p_prompt=>'Pedidos por Facturar'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>7
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(255642706521309315)
,p_name=>'P612_SALDO_TOTAL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(255642315284309311)
,p_prompt=>'Saldo Total'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>7
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(255642824944309316)
,p_name=>'P612_CUPO_DISPONIBLE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(255642315284309311)
,p_prompt=>'Cupo Disponible'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>7
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(282827130250551219)
,p_name=>'P612_CANAL'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(130554462741713929)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(293928438893735710)
,p_name=>'P612_NUM_LINEA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(130555559067713940)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(132068663589948706)
,p_validation_name=>'VAL_GRUPO'
,p_validation_sequence=>10
,p_validation=>'P612_GRUPOCLIENTE'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe seleccionar un grupo'
,p_always_execute=>'Y'
,p_validation_condition_type=>'NEVER'
,p_associated_item=>wwv_flow_imp.id(130554782798713932)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(132068753746948707)
,p_validation_name=>'VAL_CLIENTE'
,p_validation_sequence=>20
,p_validation=>'P612_CLIENTE'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe seleccionar un cliente'
,p_always_execute=>'Y'
,p_validation_condition_type=>'NEVER'
,p_associated_item=>wwv_flow_imp.id(123609988734198037)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(132068889274948708)
,p_validation_name=>'VAL_TIPO'
,p_validation_sequence=>30
,p_validation=>'P612_TIPO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe seleccionar un tipo'
,p_always_execute=>'Y'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(132068949576948709)
,p_validation_name=>'VAL_ORDENPADRE'
,p_validation_sequence=>40
,p_validation=>'P612_ORDENPADRE'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe seleccionar una orden padre'
,p_always_execute=>'Y'
,p_validation_condition=>':P612_TIPO =3 and :P612_CANAL not in(''C04'')'
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(151438323532046622)
,p_associated_item=>wwv_flow_imp.id(130555284620713937)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(132069090721948710)
,p_validation_name=>'VAL_FECHAENTREGA'
,p_validation_sequence=>50
,p_validation=>':P612_FECHAENTREGA IS NOT NULL AND :P612_FECHAENTREGA >= trunc(SYSDATE)'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('Debe seleccionar una fecha mayor al d\00EDa de hoy')
,p_always_execute=>'Y'
,p_validation_condition_type=>'NEVER'
,p_associated_item=>wwv_flow_imp.id(130555889578713943)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(240056194055560616)
,p_name=>'Cambia Tipo'
,p_event_sequence=>1
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P612_TIPO'
,p_condition_element=>'P612_TIPO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(240056242052560617)
,p_event_id=>wwv_flow_imp.id(240056194055560616)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P612_ORDENPADRE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(240056325184560618)
,p_event_id=>wwv_flow_imp.id(240056194055560616)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P612_ORDENPADRE'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P612_TIPO'
,p_client_condition_expression=>'3'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(132069673153948716)
,p_name=>'Cierra Dialogo Lectura OC'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(132069514475948715)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(132069779269948717)
,p_event_id=>wwv_flow_imp.id(132069673153948716)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log(''Lectura de OC'');',
'mostrarBarra();'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(132069920353948719)
,p_event_id=>wwv_flow_imp.id(132069673153948716)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'pk_vtas_pedidos.sp_lecturaoc(p_idpedido => :P612_NUMERO);'
,p_attribute_02=>'P612_NUMERO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(135648911236929028)
,p_event_id=>wwv_flow_imp.id(132069673153948716)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'BTN_AGREGAROC'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(282825590121551203)
,p_event_id=>wwv_flow_imp.id(132069673153948716)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(132073038265948750)
,p_name=>'CAMBIO_TIPOORIGEN'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P612_ORIGEN'
,p_condition_element=>'P612_ORIGEN'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'NAC'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(134338912267362301)
,p_event_id=>wwv_flow_imp.id(132073038265948750)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(240055039921560605)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(134339452122362306)
,p_event_id=>wwv_flow_imp.id(132073038265948750)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P612_TIPO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(240056845477560623)
,p_event_id=>wwv_flow_imp.id(132073038265948750)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P612_TIPO,P612_ORDENPADRE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(240056948191560624)
,p_event_id=>wwv_flow_imp.id(132073038265948750)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(240055039921560605)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(134339120372362303)
,p_event_id=>wwv_flow_imp.id(132073038265948750)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P612_TIPO'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P612_ORIGEN'
,p_client_condition_expression=>'NAC'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(240056701732560622)
,p_event_id=>wwv_flow_imp.id(132073038265948750)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P612_TIPO'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'2'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P612_ORIGEN'
,p_client_condition_expression=>'NAC'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(126974244919698139)
,p_name=>'Inicio envio'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(132068555705948705)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(126974314088698140)
,p_event_id=>wwv_flow_imp.id(126974244919698139)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEst\00E1 seguro de enviar a ruta?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(156848591577939727)
,p_event_id=>wwv_flow_imp.id(126974244919698139)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(126974462940698141)
,p_event_id=>wwv_flow_imp.id(126974244919698139)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select count(1) into :P612_ERRORES',
'  from vt_vtas_pedidos',
' WHERE idpedido = :P612_NUMERO',
'   and compania = :G_COMPANIA',
'   and pk_vtas_pedidos.f_numerrores(p_idpedido => idpedido, p_linea => linea, p_ruta=>1) > 0',
'   and estado = 1;',
'',
':P612_ERRORES := case when :P612_ERRORES>0 then 1 else 0 end;',
':G_VALOR1 := :P612_ERRORES;',
'',
'pk_vtas_pedidos.sp_guardaordencompra (',
'    p_idpedido      => :P612_NUMERO,',
'    p_grupo         => :P612_GRUPOCLIENTE,',
'    p_cliente       => :P612_CLIENTE,',
'    p_OrdenCompra   => :P612_ORDEN_COMPRA,',
'    p_oc_cliente    => :P612_OC_CLIENTE,',
'    p_tipo          => :P612_TIPO,',
'    p_ordenpadre    => :P612_ORDENPADRE,',
'    p_fechaentrega  => :P612_FECHAENTREGA,',
'    p_licitacion    => :P612_LICITACION,',
'    p_observacion   => :P612_OBSERVACION,',
'    P_Contenedor    => :P612_TIPO_CONTENEDOR,',
'    P_Negociacion   => :P612_TIPO_NEGOCIACION,',
'    P_Ruta          => :P612_RUTA,',
'    P_Partida       => :P612_PARTIDA,',
'    P_Transporte    => :P612_MODO_TRANSPORTE,',
'    p_infoadicional => RPAD(:P612_INFOADICIONAL, 30,'' '') || RPAD(:P612_INFOADICIONAL2, 30,'' ''),',
'    p_usuario       => :APP_USER,',
'    p_compania      => :G_COMPANIA);',
'',
'PK_VTAS_PEDIDOS_COMMONS.SP_VALIDAR_OC (',
'    P_PEDIDO        => :P612_NUMERO,',
'    P_ORDENCOMPRA   => :P612_ORDEN_COMPRA,',
'    P_CLIENTE       => :P612_GRUPOCLIENTE,',
'    P_RESULTADO     => :P612_OC_VALIDA,',
'    P_MENSAJE_ERROR => :P612_ERROR_MENSAJE,',
'    P_COMPANIA      => :G_COMPANIA);'))
,p_attribute_02=>'P612_NUMERO,P612_GRUPOCLIENTE,P612_CLIENTE,P612_ORDEN_COMPRA,P612_OC_CLIENTE,P612_TIPO,P612_ORDENPADRE,P612_FECHAENTREGA,P612_LICITACION,P612_OBSERVACION,P612_TIPO_CONTENEDOR,P612_TIPO_NEGOCIACION,P612_RUTA,P612_PARTIDA,P612_MODO_TRANSPORTE,P612_INFO'
||'ADICIONAL,P612_INFOADICIONAL2,G_COMPANIA,G_VALOR1,P612_OC_VALIDA,P612_ERROR_MENSAJE'
,p_attribute_03=>'P612_ERRORES,P612_OC_VALIDA,P612_ERROR_MENSAJE,G_VALOR1,P612_NUMERO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(126974640840698143)
,p_event_id=>wwv_flow_imp.id(126974244919698139)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log(''Inicio ruta, P612_ERRORES :''+$v(''P612_ERRORES''));',
'',
'if($v(''P612_OC_VALIDA'')==1) {',
'    $("#btnEnviar").click();',
'}else{',
' mensajeError($v(''P612_ERROR_MENSAJE''));',
'}',
'ocultarBarra();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(151438467391046623)
,p_name=>'Enviar ruta'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(151438323532046622)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(151438616197046625)
,p_event_id=>wwv_flow_imp.id(151438467391046623)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log(''Envia a ruta'');',
'$s(''P612_COMENTARIO_RUTA'',this.data.G_COMENTARIO);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(151438570341046624)
,p_event_id=>wwv_flow_imp.id(151438467391046623)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'ENVIAR_RUTA'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(151439099973046629)
,p_name=>'Cancelar Masivo'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(151438979470046628)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(151439378184046632)
,p_event_id=>wwv_flow_imp.id(151439099973046629)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log(''cancelar masivo'');',
'$s(''P612_COMENTARIO_CANCELAR'',this.data.G_COMENTARIO);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(151439184029046630)
,p_event_id=>wwv_flow_imp.id(151439099973046629)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'CANCELAR_MASIVO'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(156848851252939730)
,p_name=>'PROCESAR_PDF_OC'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(156848717085939740)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(156848965750939731)
,p_event_id=>wwv_flow_imp.id(156848851252939730)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log(''Lectura PDF OC'');',
'mostrarBarra();'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(156848965750939732)
,p_event_id=>wwv_flow_imp.id(156848851252939730)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'PK_VTAS_OC_PDF.SP_CONVERTIR_Y_LEER_PDF(P_IDPEDIDO => :P612_NUMERO, P_USUARIO => :APP_USER);'
,p_attribute_02=>'P612_NUMERO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(156848965750939733)
,p_event_id=>wwv_flow_imp.id(156848851252939730)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(130555559067713940)
,p_attribute_01=>'REFRESH_PDF_OC'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(156848965750939735)
,p_event_id=>wwv_flow_imp.id(156848851252939730)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(134343509417362347)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(156848965750939734)
,p_event_id=>wwv_flow_imp.id(156848851252939730)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(251021096628896428)
,p_name=>'PDF_OC'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(251020952361896427)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(251021122701896429)
,p_event_id=>wwv_flow_imp.id(251021096628896428)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'window.open(''http://jasper.zaimella.com:8090/jasperserver/flow.html?j_username=jasperproduccion&j_password=jasperproduccion&_flowId=viewReportFlow&ParentFolderUri=%2FZaimella_Del_Ecuador%2FPromociones&theme=jasper_embedded&standAlone=true&decorate=no'
||'&reportUnit=%2FPRODUCCION%2FVentas%2FReporteOrdenCompra&output=pdf&P_CODIGOCABECERA=''+$v(''P612_NUMERO''), ''_blank'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(165694896986398827)
,p_name=>'Cliente hijo'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P612_GRUPOCLIENTE'
,p_condition_element=>'P612_GRUPOCLIENTE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(165695210815398842)
,p_event_id=>wwv_flow_imp.id(165694896986398827)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_contador number :=0;',
'begin',
'    select count(1) into v_contador',
'    from vt_gzm_cliente',
'    where codigogrupo = :P612_GRUPOCLIENTE',
'      and codigocliente <> :P612_GRUPOCLIENTE',
'      and compania = :G_COMPANIA;',
'',
'    if(v_contador=0) then',
'        :P612_CLIENTE := :P612_GRUPOCLIENTE;',
'    else',
'        :P612_CLIENTE := null;',
'    end if;',
'',
'    if :G_COMPANIA = ''00003'' then',
'        SELECT to_char(sum(CUPO), ''FML999G999G999G999G990D00''),',
'               to_char(sum(SALDOPENDIENTE), ''FML999G999G999G999G990D00''),',
'               to_char(sum(PEDIDOFACTURAR), ''FML999G999G999G999G990D00''),',
'               to_char(sum(SALDOTOTAL), ''FML999G999G999G999G990D00''),',
'               to_char(sum(CUPODISPONIBLE), ''FML999G999G999G999G990D00'')',
'          into :P612_CUPO, :P612_SALDO, :P612_POR_FACTURAR, :P612_SALDO_TOTAL, :P612_CUPO_DISPONIBLE',
'          FROM VT_VTAS_CARTERA_CLIENTE_PE',
'         WHERE CODIGOGRUPO=:P612_GRUPOCLIENTE',
'           AND COMPANIA=:G_COMPANIA;',
'    else',
'        SELECT to_char(sum(CUPO), ''FML999G999G999G999G990D00''),',
'               to_char(sum(SALDOPENDIENTE), ''FML999G999G999G999G990D00''),',
'               to_char(sum(PEDIDOFACTURAR), ''FML999G999G999G999G990D00''),',
'               to_char(sum(SALDOTOTAL), ''FML999G999G999G999G990D00''),',
'               to_char(sum(CUPODISPONIBLE), ''FML999G999G999G999G990D00'')',
'          into :P612_CUPO, :P612_SALDO, :P612_POR_FACTURAR, :P612_SALDO_TOTAL, :P612_CUPO_DISPONIBLE',
'          FROM VT_VTAS_CARTERA_CLIENTE',
'         WHERE CODIGOGRUPO=:P612_GRUPOCLIENTE;',
'    end if;',
'end;'))
,p_attribute_02=>'P612_GRUPOCLIENTE,P612_CLIENTE,G_COMPANIA'
,p_attribute_03=>'P612_CLIENTE,P612_CUPO, P612_SALDO, P612_POR_FACTURAR, P612_SALDO_TOTAL, P612_CUPO_DISPONIBLE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(130555037928713935)
,p_event_id=>wwv_flow_imp.id(165694896986398827)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CODIGOORIGEN, CODIGOCANAL INTO :P612_ORIGEN, :P612_CANAL',
'FROM vt_gzm_cliente',
'WHERE CODIGOCLIENTE = :P612_GRUPOCLIENTE',
'  AND COMPANIA = :G_COMPANIA'))
,p_attribute_02=>'P612_GRUPOCLIENTE,P612_CLIENTE,G_COMPANIA'
,p_attribute_03=>'P612_ORIGEN,P612_CANAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(232447965786570901)
,p_event_id=>wwv_flow_imp.id(165694896986398827)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var show = $v(''P612_CLIENTE'')!=$v(''P612_GRUPOCLIENTE'');',
'console.log(''cambia grupo SHOW: ''+show);',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(165695721218398842)
,p_event_id=>wwv_flow_imp.id(165694896986398827)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P612_CLIENTE'
,p_client_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_client_condition_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$v(''P612_CLIENTE'')!=$v(''P612_GRUPOCLIENTE'')',
'',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(165696212590398842)
,p_event_id=>wwv_flow_imp.id(165694896986398827)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P612_CLIENTE'
,p_client_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_client_condition_expression=>'$v(''P612_CLIENTE'')==$v(''P612_GRUPOCLIENTE'')'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(194492006614136237)
,p_name=>'Eliminar'
,p_event_sequence=>130
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(194491850862136235)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(194492175809136238)
,p_event_id=>wwv_flow_imp.id(194492006614136237)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEst\00E1 seguro de eliminar el registro?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(194492218377136239)
,p_event_id=>wwv_flow_imp.id(194492006614136237)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'ELIMINAR'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(230314227254306448)
,p_name=>'HTML_EXCEL'
,p_event_sequence=>140
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(230314153811306447)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(230314463679306450)
,p_event_id=>wwv_flow_imp.id(230314227254306448)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>' window.open(''https://www.better-converter.com/Format-converters/Html/Html-to-Excel'', ''_blank'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(240056484748560619)
,p_name=>'Datos exportacion'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P612_TIPO'
,p_condition_element=>'P612_TIPO'
,p_triggering_condition_type=>'IN_LIST'
,p_triggering_expression=>'2,3'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(240056561510560620)
,p_event_id=>wwv_flow_imp.id(240056484748560619)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(240055039921560605)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(240056661472560621)
,p_event_id=>wwv_flow_imp.id(240056484748560619)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(240055039921560605)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(240057018324560625)
,p_name=>'Page load'
,p_event_sequence=>160
,p_condition_element=>'P612_GRUPOCLIENTE'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(240057140918560626)
,p_event_id=>wwv_flow_imp.id(240057018324560625)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P612_TIPO,P612_ORDENPADRE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(240057281525560627)
,p_event_id=>wwv_flow_imp.id(240057018324560625)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(240055039921560605)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(240057377769560628)
,p_name=>'cAMBIAR PADRE'
,p_event_sequence=>170
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P612_ORDENPADRE'
,p_condition_element=>'P612_ORDENPADRE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(240057487717560629)
,p_event_id=>wwv_flow_imp.id(240057377769560628)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select exp_contenedor, EXP_NEGOCIACION, exp_ruta, exp_transporte, exp_partida,',
'       substr(INFORMACIONADICIONAL,1,30), substr(INFORMACIONADICIONAL,31,60), EXP_ORDENCOMPRA',
'  INTO :P612_TIPO_CONTENEDOR, :P612_TIPO_NEGOCIACION, :P612_RUTA, :P612_MODO_TRANSPORTE, :P612_PARTIDA,',
'       :P612_INFOADICIONAL, :P612_INFOADICIONAL2, :P612_OC_CLIENTE',
'  FROM T_VTAS_PEDIDOS_CAB',
' WHERE IDPEDIDO = :P612_ORDENPADRE',
'   AND COMPANIA = :G_COMPANIA;'))
,p_attribute_02=>'P612_ORDENPADRE,G_COMPANIA'
,p_attribute_03=>'P612_TIPO_CONTENEDOR,P612_TIPO_NEGOCIACION,P612_RUTA,P612_MODO_TRANSPORTE,P612_PARTIDA,P612_INFOADICIONAL,P612_INFOADICIONAL2,P612_OC_CLIENTE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(277882779016794348)
,p_name=>'Subir formato'
,p_event_sequence=>180
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(277882698006794347)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(277882975297794350)
,p_event_id=>wwv_flow_imp.id(277882779016794348)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log(''subir formato manual'');',
'mostrarBarra();'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(282825408085551202)
,p_event_id=>wwv_flow_imp.id(277882779016794348)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'SUBIR_FORMATO'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(126973648723698133)
,p_event_id=>wwv_flow_imp.id(277882779016794348)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(293928761777735713)
,p_name=>'CerrarDialogoActivar'
,p_event_sequence=>190
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(130555559067713940)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(293928848871735714)
,p_event_id=>wwv_flow_imp.id(293928761777735713)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(293929591408735721)
,p_event_id=>wwv_flow_imp.id(293928761777735713)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P612_NUM_LINEA'
,p_attribute_01=>'DIALOG_RETURN_ITEM'
,p_attribute_09=>'N'
,p_attribute_10=>'P608_NUMLINEA'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(293929069945735716)
,p_event_id=>wwv_flow_imp.id(293928761777735713)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update T_VTAS_PEDIDOS',
'set estado = 1 ',
'where idpedido = :P612_NUMERO',
'and linea = :P612_NUM_LINEA ;',
'',
'pk_vtas_pedidos.sp_inactivacion(p_idpedido => :P612_NUMERO, p_linea => :P612_NUM_LINEA );',
'',
':P612_NUM_LINEA := 0;'))
,p_attribute_02=>'P612_NUMERO,P612_NUM_LINEA'
,p_attribute_03=>'P612_NUM_LINEA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P612_NUM_LINEA'
,p_client_condition_expression=>'0'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(293929245434735718)
,p_event_id=>wwv_flow_imp.id(293928761777735713)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(130555559067713940)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(151798356685694043)
,p_event_id=>wwv_flow_imp.id(293928761777735713)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(134343509417362347)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(293928902483735715)
,p_event_id=>wwv_flow_imp.id(293928761777735713)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(132069355762948713)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Traer Informaci\00F3n')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P612_NUMERO is not null then',
'',
'    select IDPADRE,TIPO,p.CODIGOGRUPO,p.CODIGOCLIENTE,',
'            FECHAENTREGA,LICITACION,OBSERVACION,PRESENTACION_OC,ORDENCOMPRA,',
'            exp_contenedor,    EXP_NEGOCIACION,    exp_ruta,    exp_transporte,    exp_partida,EXP_ORDENCOMPRA,',
'             substr(INFORMACIONADICIONAL,1,30),            substr(INFORMACIONADICIONAL,31,60), CODIGOORIGEN',
'            INTO :P612_ORDENPADRE, :P612_TIPO, :P612_GRUPOCLIENTE, :P612_CLIENTE,',
'             :P612_FECHAENTREGA, :P612_LICITACION, :P612_OBSERVACION, :P612_TIPOUNIDAD,:P612_ORDEN_COMPRA,',
'             :P612_TIPO_CONTENEDOR, :P612_TIPO_NEGOCIACION, :P612_RUTA, :P612_MODO_TRANSPORTE, :P612_PARTIDA, :P612_OC_CLIENTE,',
'             :P612_INFOADICIONAL,:P612_INFOADICIONAL2, :P612_ORIGEN',
'            FROM T_VTAS_PEDIDOS_CAB P',
'            LEFT JOIN vt_gzm_cliente C ON (C.CODIGOCLIENTE=P.CODIGOGRUPO AND C.COMPANIA=P.COMPANIA)',
'            WHERE IDPEDIDO = :P612_NUMERO',
'              AND P.COMPANIA = :G_COMPANIA;',
'',
'    select MAX(SEPARADOR),  MAX(TIPOARCHIVO) INTO :G_VALOR3, :G_VALOR2',
'     from t_vtas_pedido_conf_oc',
'    WHERE CODIGOGRUPO=:P612_GRUPOCLIENTE',
'      AND COMPANIA=:G_COMPANIA;',
'',
'    if :G_COMPANIA = ''00003'' then',
'        SELECT to_char(sum(CUPO), ''FML999G999G999G999G990D00''), to_char(sum(SALDOPENDIENTE), ''FML999G999G999G999G990D00''),',
'               to_char(sum(PEDIDOFACTURAR), ''FML999G999G999G999G990D00''), to_char(sum(SALDOTOTAL), ''FML999G999G999G999G990D00''),',
'               to_char(sum(CUPODISPONIBLE), ''FML999G999G999G999G990D00'')',
'          into :P612_CUPO, :P612_SALDO, :P612_POR_FACTURAR, :P612_SALDO_TOTAL, :P612_CUPO_DISPONIBLE',
'          FROM VT_VTAS_CARTERA_CLIENTE_PE',
'         WHERE CODIGOGRUPO = :P612_GRUPOCLIENTE',
'           AND COMPANIA = :G_COMPANIA;',
'    else',
'        SELECT to_char(sum(CUPO), ''FML999G999G999G999G990D00''), to_char(sum(SALDOPENDIENTE), ''FML999G999G999G999G990D00''),',
'               to_char(sum(PEDIDOFACTURAR), ''FML999G999G999G999G990D00''), to_char(sum(SALDOTOTAL), ''FML999G999G999G999G990D00''),',
'               to_char(sum(CUPODISPONIBLE), ''FML999G999G999G999G990D00'')',
'          into :P612_CUPO, :P612_SALDO, :P612_POR_FACTURAR, :P612_SALDO_TOTAL, :P612_CUPO_DISPONIBLE',
'          FROM VT_VTAS_CARTERA_CLIENTE',
'         WHERE CODIGOGRUPO = :P612_GRUPOCLIENTE;',
'    end if;',
'',
'    :P612_ARCHIVO := case when :G_VALOR2=1 then ''EXCEL'' ELSE ''CSV'' END;',
'    :P612_SEPARADOR := :G_VALOR3;',
'end if;',
'',
':P612_NUM_LINEA := 0 ;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>132069355762948713
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(194491901343136236)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Eliminar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'pk_vtas_pedidos.sp_eliminarOrdenCompra(p_idpedido => :P612_NUMERO, p_usuario => :APP_USER);',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(194491850862136235)
,p_process_success_message=>unistr('Se elimin\00F3 con \00E9xito.')
,p_internal_uid=>194491901343136236
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(132068452563948704)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Guarda OC'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pk_vtas_pedidos.sp_guardaordencompra (',
'                p_idpedido      => :P612_NUMERO, ',
'                p_grupo         => :P612_GRUPOCLIENTE, ',
'                p_cliente       => :P612_CLIENTE,',
'                p_OrdenCompra => :P612_ORDEN_COMPRA, ',
'                p_oc_cliente => :P612_OC_CLIENTE,',
'                p_tipo          => :P612_TIPO, ',
'                p_ordenpadre    => :P612_ORDENPADRE, ',
'                p_fechaentrega  => :P612_FECHAENTREGA,',
'                p_licitacion    => :P612_LICITACION, ',
'                p_observacion   => :P612_OBSERVACION,',
'                P_Contenedor  =>:P612_TIPO_CONTENEDOR,',
'                P_Negociacion  =>:P612_TIPO_NEGOCIACION, ',
'                P_Ruta  =>:P612_RUTA,',
'                P_Partida  =>:P612_PARTIDA,',
'                P_Transporte  =>:P612_MODO_TRANSPORTE,',
'                p_infoadicional=> RPAD( :P612_INFOADICIONAL, 30,'' '')||RPAD( :P612_INFOADICIONAL2, 30,'' '')  ,',
'                p_usuario       => :APP_USER, ',
'                p_compania      => :G_COMPANIA);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>132068452563948704
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(258271652643561938)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Sugerido'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    pk_vtas_pedidos.sp_simular_pedidosugerido(p_codigogrupo => :P612_GRUPOCLIENTE, p_codigocliente=> :P612_CLIENTE, p_IDPEDIDO=>:P612_NUMERO);',
'        '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(258271544325561937)
,p_internal_uid=>258271652643561938
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(151437580130046614)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cancelar Masivo'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'v_id 				varchar(250);',
'begin',
'	for i in 1..apex_application.g_f01.count loop  --Recorre las filas seleccionadas',
'			v_id := apex_application.g_f01(i);',
'',
'        pk_vtas_pedidos.sp_inactivacion ',
'            (',
'                p_idpedido      => :P612_NUMERO,',
'                p_linea         => v_id,',
'                p_observacion   => :P612_COMENTARIO_CANCELAR,',
'                P_TIPO =>4',
'            );',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(151438979470046628)
,p_process_success_message=>unistr('Se cancelo masivo con \00E9xito')
,p_internal_uid=>151437580130046614
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(126973546435698132)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Subir OC'
,p_process_sql_clob=>'pk_vtas_pedidos.sp_lecturaoc(p_idpedido => :P612_NUMERO);'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(132069514475948715)
,p_internal_uid=>126973546435698132
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(156848965750939740)
,p_process_sequence=>55
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Procesar PDF OC'
,p_process_sql_clob=>'PK_VTAS_OC_PDF.SP_CONVERTIR_Y_LEER_PDF(P_IDPEDIDO => :P612_NUMERO, P_USUARIO => :APP_USER);'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(156848717085939740)
,p_process_when_type=>'NEVER'
,p_process_success_message=>'PDF OC procesado correctamente.'
,p_internal_uid=>156848965750939740
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(282825634212551204)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Subir formato manual'
,p_process_sql_clob=>'    pk_vtas_pedidos.sp_lecturaOrdenCompraManual(p_idpedido => :P612_NUMERO);'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(277882698006794347)
,p_internal_uid=>282825634212551204
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(135145823250062312)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Envio Flujo'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pk_vtas_pedidos.sp_envioocflujo',
'    (',
'        p_idpedido => :P612_NUMERO,',
'        p_usuario => :APP_USER,',
'        P_COMENTARIO=>:P612_COMENTARIO_RUTA,',
'        p_compania => :G_COMPANIA',
'    );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(151438323532046622)
,p_process_success_message=>unistr('Se envi\00F3 con \00E9xito ')
,p_internal_uid=>135145823250062312
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(135145914220062313)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Limpiar Datos'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(151438323532046622)
,p_process_success_message=>unistr('Se ha enviado a ruta de aprobaci\00F3n')
,p_internal_uid=>135145914220062313
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
