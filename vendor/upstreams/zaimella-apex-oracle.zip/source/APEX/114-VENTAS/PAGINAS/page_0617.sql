prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>114
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 114 - Ventas
--
-- Application Export:
--   Application:     114
--   Name:            Ventas
--   Date and Time:   17:00 Tuesday July 21, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 617
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_00617
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>617);
end;
/
prompt --application/pages/page_00617
begin
wwv_flow_imp_page.create_page(
 p_id=>617
,p_name=>'Dlg Adjuntar PDF OC'
,p_alias=>'ADJUNTAR-PDF-OC'
,p_page_mode=>'MODAL'
,p_step_title=>'Adjuntar PDF OC'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_title=>'Adjuntar PDF OC'
,p_dialog_height=>'360'
,p_dialog_width=>'720'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(108366634689294480201)
,p_plug_name=>'Adjuntar PDF OC'
,p_region_name=>'dlgPdfOc'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(207623277923798915)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28881082835865104685)
,p_name=>'P617_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(108366634689294480201)
,p_prompt=>'Pedido'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(42994453618432000)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28881082835865104686)
,p_name=>'P617_ADJUNTO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(108366634689294480201)
,p_prompt=>'PDF OC'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,application/pdf"'
,p_field_template=>wwv_flow_imp.id(42994453618432000)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(36817228757787830697)
,p_name=>'Restringir selector a PDF'
,p_event_sequence=>5
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(36817228757787830700)
,p_event_id=>wwv_flow_imp.id(36817228757787830697)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P617_ADJUNTO_input").attr("accept", ".pdf,application/pdf");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(36817228702241830695)
,p_name=>'Adjuntar PDF OC'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P617_ADJUNTO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(36817228757787830696)
,p_event_id=>wwv_flow_imp.id(36817228702241830695)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'SUBIR_PDF_OC'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(17970877144534698187)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Guardar PDF OC'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'declare',
'    v_numeroarchivo number;',
'begin',
'    for r in (',
'        select numeroarchivo',
'          from files.t_apex_archivos',
'         where tabla = ''T_VTAS_PEDIDOS_CAB''',
'           and id_tabla = to_char(:P617_ID)',
'    ) loop',
'        data.pk_apex_archivos.sp_eliminaarchivo(r.numeroarchivo);',
'    end loop;',
'',
'    data.pk_apex_archivos.sp_creararchivo(',
'        p_archivo       => :P617_ADJUNTO,',
'        p_tabla         => ''T_VTAS_PEDIDOS_CAB'',',
'        p_idtabla       => :P617_ID,',
'        p_tipo          => ''OC_PDF'',',
'        p_usuario       => :APP_USER,',
'        p_numeroarchivo => v_numeroarchivo',
'    );',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P617_ADJUNTO'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>147678623400211878
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(17970877144534698188)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Cerrar dialogo'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P617_ADJUNTO'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>147678623400211878
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
