prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>114
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 114 - Ventas
--
-- Application Export:
--   Application:     114
--   Name:            Ventas
--   Date and Time:   14:18 Thursday July 16, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 309
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_00309
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>309);
end;
/
prompt --application/pages/page_00309
begin
wwv_flow_imp_page.create_page(
 p_id=>309
,p_name=>'Reporte Pedidos Detalle'
,p_alias=>'REPORTE-PEDIDOS-DETALLE'
,p_step_title=>'Reporte Pedidos Detalle'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''.apex-rds'').data(''onRegionChange'', function(mode, activeTab) {',
'    apex.item( "P309_TABACTIVO" ).setValue(activeTab.href);',
'});'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(397187284415161597)
,p_plug_name=>'Detalle de pedidos'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_imp.id(207624090311798915)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(207077902574778828)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(207177697621778923)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(397187305772161598)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(207622883613798915)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(397187445097161599)
,p_plug_name=>'Formulario'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(207623277923798915)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(250780893031083709)
,p_plug_name=>'Reportes'
,p_parent_plug_id=>wwv_flow_imp.id(397187445097161599)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(207623277923798915)
,p_plug_display_sequence=>100
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'N',
  'rds_mode', 'STANDARD',
  'remember_selection', 'SESSION')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(309003002)
,p_plug_name=>'Con novedades'
,p_parent_plug_id=>wwv_flow_imp.id(250780893031083709)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(207123407083778876)
,p_plug_display_sequence=>25
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'select IDPEDIDO, ORIGEN, CLIENTE,',
'       LINEA_NEGOCIO, MARCA, SUBMARCA, NOMBRE_PRODUCTO, CODIGO_BARRA, CODIGO_PRODUCTO,',
'       ORDEN_COMPRA, FECHA_PEDIDO, TIPO, ESTADO, UNIDAD_MEDIDA,',
'       CANTIDAD_BU_CA, CANTIDAD_UND, PRECIO, TOTAL, TIPO_INACTIVO, OBSERVACION',
'from DATA.VT_VTAS_PEDIDOS_INACTIVOS_PE',
'where FECHA_PEDIDO between to_date(:P309_FECHAINICIO, ''DD/MM/YYYY'') and to_date(:P309_FECHAFIN, ''DD/MM/YYYY'') + 0.99999',
'  and CODIGO_GRUPO = nvl(:P309_GRUPO, CODIGO_GRUPO)',
'  and CODIGO_CANAL = nvl(:P309_CANAL, CODIGO_CANAL)',
'  and ORIGEN = :P309_ORIGEN',
'  and (:G_ROL = 1 or (:G_ROL = 2 and EJECUTIVO = :G_IDENTIFICACION))',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P309_FECHAINICIO,P309_FECHAFIN,P309_GRUPO,P309_CANAL,,P309_ORIGEN'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'G_COMPANIA'
,p_plug_display_when_cond2=>'00003'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Con novedades'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(309003102)
,p_name=>'Con novedades'
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>309003102
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003102010)
,p_db_column_name=>'IDPEDIDO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Idpedido'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003102020)
,p_db_column_name=>'ORIGEN'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Origen'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003102040)
,p_db_column_name=>'LINEA_NEGOCIO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Linea Negocio'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003102050)
,p_db_column_name=>'MARCA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Marca'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003102060)
,p_db_column_name=>'SUBMARCA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Submarca'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003102070)
,p_db_column_name=>'NOMBRE_PRODUCTO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Nombre Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003102080)
,p_db_column_name=>'CODIGO_BARRA'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Codigo Barra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003102090)
,p_db_column_name=>'CODIGO_PRODUCTO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Codigo Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003102100)
,p_db_column_name=>'ORDEN_COMPRA'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003102110)
,p_db_column_name=>'FECHA_PEDIDO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Fecha Pedido'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003102120)
,p_db_column_name=>'TIPO'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Tipo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003102130)
,p_db_column_name=>'ESTADO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Estado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003102140)
,p_db_column_name=>'UNIDAD_MEDIDA'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Unidad Medida'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003102150)
,p_db_column_name=>'CANTIDAD_BU_CA'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Cantidad Bu Ca'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003102160)
,p_db_column_name=>'CANTIDAD_UND'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Cantidad Und'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003102170)
,p_db_column_name=>'PRECIO'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003102180)
,p_db_column_name=>'TOTAL'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003102190)
,p_db_column_name=>'TIPO_INACTIVO'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Tipo Inactivo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(135134069597792485)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003102200)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003102210)
,p_db_column_name=>'CLIENTE'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(309003102510)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'309003102510'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'IDPEDIDO:ORIGEN:CLIENTE:LINEA_NEGOCIO:MARCA:SUBMARCA:NOMBRE_PRODUCTO:CODIGO_BARRA:CODIGO_PRODUCTO:ORDEN_COMPRA:FECHA_PEDIDO:UNIDAD_MEDIDA:CANTIDAD_BU_CA:CANTIDAD_UND:PRECIO:TOTAL:TIPO_INACTIVO:OBSERVACION:'
,p_sort_column_1=>'FECHA_PEDIDO'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(253597915420338737)
,p_plug_name=>'Con novedades'
,p_parent_plug_id=>wwv_flow_imp.id(250780893031083709)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(207123407083778876)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select IDPEDIDO,origen, CLIENTE,',
'LINEA_NEGOCIO, MARCA, SUBMARCA, NOMBRE_PRODUCTO, CODIGO_BARRA, CODIGO_PRODUCTO,',
' ORDEN_COMPRA, FECHA_PEDIDO, TIPO,  ESTADO, UNIDAD_MEDIDA,',
'CANTIDAD_BU_CA, CANTIDAD_UND, PRECIO, TOTAL, TIPO_INACTIVO, OBSERVACION',
'from VT_VTAS_PEDIDOS_Inactivos WHERE  ',
' --:P309_TABACTIVO =''#TblTracking'' and',
'  FECHA_PEDIDO BETWEEN :P309_FECHAINICIO AND :P309_FECHAFIN',
'     AND CODIGO_GRUPO=NVL(:P309_GRUPO,CODIGO_GRUPO )  AND codigo_canal=NVL(:P309_CANAL,codigo_canal )',
'     AND ORIGEN=:P309_ORIGEN  AND (:G_ROL = 1 OR (:G_ROL = 2 AND EJECUTIVO = :G_IDENTIFICACION))',
';'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P309_FECHAINICIO,P309_FECHAFIN,P309_GRUPO,P309_CANAL,,P309_ORIGEN'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'G_COMPANIA'
,p_plug_display_when_cond2=>'00001'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Con novedades'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(253598050261338738)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>253598050261338738
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253598198096338739)
,p_db_column_name=>'IDPEDIDO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Idpedido'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253598285037338740)
,p_db_column_name=>'ORIGEN'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Origen'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253598468237338742)
,p_db_column_name=>'LINEA_NEGOCIO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Linea Negocio'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253598571208338743)
,p_db_column_name=>'MARCA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Marca'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253598670131338744)
,p_db_column_name=>'SUBMARCA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Submarca'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253598706556338745)
,p_db_column_name=>'NOMBRE_PRODUCTO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Nombre Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253598845580338746)
,p_db_column_name=>'CODIGO_BARRA'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Codigo Barra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253598932320338747)
,p_db_column_name=>'CODIGO_PRODUCTO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Codigo Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253599083678338748)
,p_db_column_name=>'ORDEN_COMPRA'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253599101525338749)
,p_db_column_name=>'FECHA_PEDIDO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Fecha Pedido'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253599297621338750)
,p_db_column_name=>'TIPO'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Tipo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(254227157428921201)
,p_db_column_name=>'ESTADO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Estado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(254227218329921202)
,p_db_column_name=>'UNIDAD_MEDIDA'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Unidad Medida'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(254227384348921203)
,p_db_column_name=>'CANTIDAD_BU_CA'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Cantidad Bu Ca'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(254227426293921204)
,p_db_column_name=>'CANTIDAD_UND'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Cantidad Und'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(254227563502921205)
,p_db_column_name=>'PRECIO'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(254227639576921206)
,p_db_column_name=>'TOTAL'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(254227727622921207)
,p_db_column_name=>'TIPO_INACTIVO'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Tipo Inactivo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(135134069597792485)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(254227820912921208)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(254227949887921209)
,p_db_column_name=>'CLIENTE'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(254246695529921691)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2542467'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'IDPEDIDO:ORIGEN:CLIENTE:LINEA_NEGOCIO:MARCA:SUBMARCA:NOMBRE_PRODUCTO:CODIGO_BARRA:CODIGO_PRODUCTO:ORDEN_COMPRA:FECHA_PEDIDO:UNIDAD_MEDIDA:CANTIDAD_BU_CA:CANTIDAD_UND:PRECIO:TOTAL:TIPO_INACTIVO:OBSERVACION:'
,p_sort_column_1=>'FECHA_PEDIDO'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(379832577128420639)
,p_plug_name=>'Tracking'
,p_region_name=>'TblTracking'
,p_parent_plug_id=>wwv_flow_imp.id(250780893031083709)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(207124544257778878)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(309003001)
,p_plug_name=>' '
,p_region_name=>'TblTracking'
,p_parent_plug_id=>wwv_flow_imp.id(379832577128420639)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(207622408396798914)
,p_plug_display_sequence=>15
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with tracking as (',
'    select ID, IDPEDIDO, TIPO, CANAL, ORIGEN, CODIGO_GRUPO, GRUPO, CODIGO_CLIENTE, CLIENTE,',
'           ORDEN_COMPRA, ESTADO_PEDIDO, USUARIO, FECHA_PEDIDO, CUBICADO, FACTURADO, CODIGO_RETENCION,',
'           CANTIDAD_BU_CA_OC, CANTIDAD_BU_CA_ENVIAR, CANTIDAD_BU_CA_PEDIDO,',
'           SUBTOTAL_OC, SUBTOTAL_ENVIAR, SUBTOTAL_PEDIDO',
'    from DATA.VT_VTAS_PEDIDOS_TRACKING_PE',
'    where :P309_TABACTIVO = ''#TblTracking''',
'      and trunc(FECHA_PEDIDO) between trunc(to_date(:P309_FECHAINICIO, ''DD/MM/YYYY'')) and trunc(to_date(:P309_FECHAFIN, ''DD/MM/YYYY''))',
'      and CODIGO_GRUPO = nvl(:P309_GRUPO, CODIGO_GRUPO)',
'      and CODIGOCANAL = nvl(:P309_CANAL, CODIGOCANAL)',
'      and ORIGEN = :P309_ORIGEN',
'      and (:G_ROL = 1 or (:G_ROL = 2 and EJECUTIVO = :G_IDENTIFICACION))',
'),',
'factura_base as (',
'    select',
'        R."DocNum" ORDEN_ERP,',
'        cast(R."NumAtCard" as varchar2(100)) ORDEN_COMPRA_SAP,',
'        cast(F."NumAtCard" as varchar2(100)) NUMERO_FACTURA,',
'        cast(nvl(F."U_BPP_MDTD", regexp_substr(F."NumAtCard", ''[^-]+'', 1, 1)) as varchar2(10)) TIPO_DOCUMENTO,',
'        cast(nvl(F."U_BPP_MDSD", regexp_substr(F."NumAtCard", ''[^-]+'', 1, 2)) as varchar2(20)) SERIE_DOCUMENTO,',
'        cast(nvl(F."U_BPP_MDCD", regexp_substr(F."NumAtCard", ''[^-]+'', 1, 3)) as varchar2(20)) NUMERO_DOCUMENTO,',
'        F."DocDate" FECHA_FACTURA,',
'        F."DocTotal" TOTAL_FACTURA,',
'        F."DocEntry" FACTURA_DOCENTRY',
'    from OINV@HANA_PE F',
'    join INV1@HANA_PE D on D."DocEntry" = F."DocEntry"',
'    left join ODLN@HANA_PE E on D."BaseType" = 15 and E."DocEntry" = D."BaseEntry"',
'    left join DLN1@HANA_PE ED on E."DocEntry" = ED."DocEntry" and ED."LineNum" = D."BaseLine"',
'    left join ORDR@HANA_PE R',
'        on (D."BaseType" = 17 and R."DocEntry" = D."BaseEntry")',
'        or (ED."BaseType" = 17 and R."DocEntry" = ED."BaseEntry")',
'    where F."CANCELED" = ''N''',
'      and F."DocDate" between to_date(:P309_FECHAINICIO, ''DD/MM/YYYY'') - 60 and to_date(:P309_FECHAFIN, ''DD/MM/YYYY'') + 60',
'),',
'facturas_documento as (',
'    select distinct ORDEN_ERP, ORDEN_COMPRA_SAP, NUMERO_FACTURA, TIPO_DOCUMENTO, SERIE_DOCUMENTO, NUMERO_DOCUMENTO,',
'           FECHA_FACTURA, TOTAL_FACTURA, FACTURA_DOCENTRY',
'      from factura_base',
'     where ORDEN_ERP is not null',
'),',
'facturas_peru as (',
'    select',
'        ORDEN_ERP,',
'        max(ORDEN_COMPRA_SAP) keep (dense_rank last order by FECHA_FACTURA, FACTURA_DOCENTRY) ORDEN_COMPRA_SAP,',
'        max(NUMERO_FACTURA) keep (dense_rank last order by FECHA_FACTURA, FACTURA_DOCENTRY) NUMERO_FACTURA,',
'        max(TIPO_DOCUMENTO) keep (dense_rank last order by FECHA_FACTURA, FACTURA_DOCENTRY) TIPO_DOCUMENTO,',
'        max(SERIE_DOCUMENTO) keep (dense_rank last order by FECHA_FACTURA, FACTURA_DOCENTRY) SERIE_DOCUMENTO,',
'        max(NUMERO_DOCUMENTO) keep (dense_rank last order by FECHA_FACTURA, FACTURA_DOCENTRY) NUMERO_DOCUMENTO,',
'        count(*) NUMERO_FACTURAS,',
'        sum(TOTAL_FACTURA) TOTAL_FACTURADO,',
'        ''20519078504-'' ||',
'        max(TIPO_DOCUMENTO) keep (dense_rank last order by FECHA_FACTURA, FACTURA_DOCENTRY) || ''-'' ||',
'        max(SERIE_DOCUMENTO) keep (dense_rank last order by FECHA_FACTURA, FACTURA_DOCENTRY) || ''-'' ||',
'        max(NUMERO_DOCUMENTO) keep (dense_rank last order by FECHA_FACTURA, FACTURA_DOCENTRY) || ''.pdf'' FILENAME_FACTURA',
'    from facturas_documento',
'    group by ORDEN_ERP',
')',
'select T.ID, T.IDPEDIDO, T.TIPO, T.CANAL, T.ORIGEN, T.CODIGO_GRUPO, T.GRUPO, T.CODIGO_CLIENTE, T.CLIENTE,',
'       nvl(F.ORDEN_COMPRA_SAP, T.ORDEN_COMPRA) ORDEN_COMPRA,',
'       nvl(F.ORDEN_ERP, to_number(T.CODIGO_RETENCION default null on conversion error)) ORDEN_ERP,',
'       case when F.NUMERO_FACTURAS = 1 then F.NUMERO_FACTURA end NUMERO_FACTURA,',
'       nvl(F.NUMERO_FACTURAS, 0) NUMERO_FACTURAS,',
'       nvl(F.TOTAL_FACTURADO, 0) TOTAL_FACTURADO,',
'       T.ESTADO_PEDIDO, T.USUARIO, T.FECHA_PEDIDO, T.CUBICADO, case when F.ORDEN_ERP is not null then 1 else 0 end FACTURADO, T.CODIGO_RETENCION,',
'       T.CANTIDAD_BU_CA_OC, T.CANTIDAD_BU_CA_ENVIAR, T.CANTIDAD_BU_CA_PEDIDO,',
'       T.SUBTOTAL_OC, T.SUBTOTAL_ENVIAR, T.SUBTOTAL_PEDIDO,',
'       T.SUBTOTAL_ENVIAR - T.SUBTOTAL_PEDIDO diferencia,',
'       case when F.NUMERO_FACTURAS = 1 then ''<span class="fa fa-file-pdf-o" aria-hidden="true"></span>''',
'            when F.NUMERO_FACTURAS >= 2 then ''<span class="fa fa-list-alt" aria-hidden="true"></span>'' else '''' end VER_FACTURA,',
'       case when F.NUMERO_FACTURAS = 1 then ''http://192.168.5.109/SapPDF/'' || F.FILENAME_FACTURA',
'            when F.NUMERO_FACTURAS >= 2 then ''f?p=&APP_ID.:310:&SESSION.::&DEBUG.::P310_ORDEN_ERP,P310_IDPEDIDO:'' || F.ORDEN_ERP || '','' || T.IDPEDIDO end URL_FACTURA,',
'       ''<span aria-hidden="true" class="fa fa-table"></span>'' VER_PEDIDO,',
'       ''<span class="fa fa-paperclip" aria-hidden="true"></span>'' VER_ADJUNTOS',
'from tracking T',
'left join facturas_peru F on F.ORDEN_ERP = to_number(T.CODIGO_RETENCION default null on conversion error)',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P309_FECHAINICIO,P309_FECHAFIN,P309_GRUPO,P309_CANAL,P309_ORIGEN,P309_TABACTIVO'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'G_COMPANIA'
,p_plug_display_when_cond2=>'00003'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Tracking'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(309003101)
,p_name=>'Tracking Peru'
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>350
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>309003101
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101010)
,p_db_column_name=>'IDPEDIDO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Idpedido'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101020)
,p_db_column_name=>'TIPO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(132058678629439622)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101030)
,p_db_column_name=>'CANAL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Canal'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101040)
,p_db_column_name=>'ORIGEN'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Origen'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101050)
,p_db_column_name=>'CODIGO_GRUPO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Codigo Grupo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101060)
,p_db_column_name=>'GRUPO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Grupo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101070)
,p_db_column_name=>'CODIGO_CLIENTE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Codigo Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101080)
,p_db_column_name=>'CLIENTE'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101090)
,p_db_column_name=>'ORDEN_COMPRA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101091)
,p_db_column_name=>'ORDEN_ERP'
,p_display_order=>95
,p_column_identifier=>'AB'
,p_column_label=>'Orden ERP'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101092)
,p_db_column_name=>'NUMERO_FACTURA'
,p_display_order=>96
,p_column_identifier=>'AC'
,p_column_label=>'Numero Factura'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101093)
,p_db_column_name=>'URL_FACTURA'
,p_display_order=>97
,p_column_identifier=>'AD'
,p_column_label=>'Url Factura'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101094)
,p_db_column_name=>'NUMERO_FACTURAS'
,p_display_order=>98
,p_column_identifier=>'AE'
,p_column_label=>'Facturas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101095)
,p_db_column_name=>'TOTAL_FACTURADO'
,p_display_order=>99
,p_column_identifier=>'AF'
,p_column_label=>'Total Facturado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101100)
,p_db_column_name=>'ESTADO_PEDIDO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Estado Pedido'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(250805827464152630)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101110)
,p_db_column_name=>'USUARIO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101120)
,p_db_column_name=>'FECHA_PEDIDO'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Fecha Pedido'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101130)
,p_db_column_name=>'CUBICADO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Cubicado'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(123891575071627861)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101140)
,p_db_column_name=>'FACTURADO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Facturado'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(123891575071627861)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101150)
,p_db_column_name=>'CANTIDAD_BU_CA_OC'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Cantidad Bu Ca Oc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101160)
,p_db_column_name=>'CANTIDAD_BU_CA_ENVIAR'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Cantidad Bu Ca Enviar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101170)
,p_db_column_name=>'CANTIDAD_BU_CA_PEDIDO'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Cantidad Bu Ca Pedido'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101180)
,p_db_column_name=>'SUBTOTAL_OC'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Subtotal Oc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101190)
,p_db_column_name=>'SUBTOTAL_ENVIAR'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Subtotal Enviar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101200)
,p_db_column_name=>'SUBTOTAL_PEDIDO'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Subtotal Pedido'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101210)
,p_db_column_name=>'ID'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101220)
,p_db_column_name=>'VER_PEDIDO'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Ver Pedido'
,p_column_link=>'f?p=&APP_ID.:615:&SESSION.::&DEBUG.::P615_NUMERO:#IDPEDIDO#'
,p_column_linktext=>'#VER_PEDIDO#'
,p_column_link_attr=>'target="_blank"'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101240)
,p_db_column_name=>'VER_FACTURA'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Ver Factura'
,p_column_link=>'#URL_FACTURA#'
,p_column_linktext=>'#VER_FACTURA#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101250)
,p_db_column_name=>'VER_ADJUNTOS'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Ver Adjuntos'
,p_column_link=>'f?p=100:401:&SESSION.::&DEBUG.::P401_TABLA,P401_ID,P401_ESTADO:T_VTAS_PEDIDOS_CAB,#IDPEDIDO#,0'
,p_column_linktext=>'#VER_ADJUNTOS#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101260)
,p_db_column_name=>'CODIGO_RETENCION'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Codigo ERP'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309003101270)
,p_db_column_name=>'DIFERENCIA'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Diferencia'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(309003101510)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'309003101510'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'IDPEDIDO:ORIGEN:CANAL:GRUPO:CLIENTE:FECHA_PEDIDO:ORDEN_COMPRA:ORDEN_ERP:NUMERO_FACTURA:NUMERO_FACTURAS:TOTAL_FACTURADO:TIPO:ESTADO_PEDIDO:USUARIO:FACTURADO:CANTIDAD_BU_CA_OC:CANTIDAD_BU_CA_ENVIAR:CANTIDAD_BU_CA_PEDIDO:SUBTOTAL_OC:SUBTOTAL_ENVIAR:SUBTOTAL_PEDIDO:DIFERENCIA:VER_ADJUN'
||'TOS:VER_PEDIDO:VER_FACTURA:'
,p_sort_column_1=>'IDPEDIDO'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'DESC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'0:0:0:0:0'
,p_break_enabled_on=>'0:0:0:0:0'
,p_sum_columns_on_break=>'SUBTOTAL_OC:CANTIDAD_BU_CA_ENVIAR:SUBTOTAL_ENVIAR:SUBTOTAL_PEDIDO:CANTIDAD_BU_CA_PEDIDO:CANTIDAD_BU_CA_OC:DIFERENCIA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(250118035408829711)
,p_plug_name=>' '
,p_region_name=>'TblTracking'
,p_parent_plug_id=>wwv_flow_imp.id(379832577128420639)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(207622408396798914)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,  IDPEDIDO, TIPO, CANAL, ORIGEN, CODIGO_GRUPO, GRUPO, CODIGO_CLIENTE, CLIENTE, ',
'ORDEN_COMPRA, ESTADO_PEDIDO, USUARIO, FECHA_PEDIDO, CUBICADO, FACTURADO,CODIGO_RETENCION,',
' CANTIDAD_BU_CA_OC, CANTIDAD_BU_CA_ENVIAR, CANTIDAD_BU_CA_PEDIDO, SUBTOTAL_OC, SUBTOTAL_ENVIAR, SUBTOTAL_PEDIDO, SUBTOTAL_ENVIAR-SUBTOTAL_PEDIDO diferencia,',
' case when FACTURADO=1 then ''<span class="fa fa-list-alt" aria-hidden="true"></span>'' else '''' end VER_FACTURA, ',
' ''<span aria-hidden="true" class="fa fa-table"></span>'' VER_PEDIDO, ',
' ''<span class="fa fa-paperclip" aria-hidden="true"></span>'' VER_ADJUNTOS',
'from VT_VTAS_PEDIDOS_TRACKIG ',
'WHERE   :P309_TABACTIVO =''#TblTracking'' ',
'    and TRUNC(FECHA_PEDIDO) BETWEEN TRUNC(TO_DATE(:P309_FECHAINICIO, ''DD/MM/YYYY'')) AND TRUNC(TO_DATE(:P309_FECHAFIN, ''DD/MM/YYYY''))',
'     AND CODIGO_GRUPO=NVL(:P309_GRUPO,CODIGO_GRUPO )  AND CODIGOCANAL=NVL(:P309_CANAL,CODIGOCANAL )',
'     AND ORIGEN=:P309_ORIGEN  AND (:G_ROL = 1 OR (:G_ROL = 2 AND EJECUTIVO = :G_IDENTIFICACION))',
';'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P309_FECHAINICIO,P309_FECHAFIN,P309_GRUPO,P309_CANAL,,P309_ORIGEN'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'G_COMPANIA'
,p_plug_display_when_cond2=>'00001'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Tracking'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(250118178490829712)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>350
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>250118178490829712
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250118268593829713)
,p_db_column_name=>'IDPEDIDO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Idpedido'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250118370211829714)
,p_db_column_name=>'TIPO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(132058678629439622)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250118487530829715)
,p_db_column_name=>'CANAL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Canal'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250118565354829716)
,p_db_column_name=>'ORIGEN'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Origen'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250118660529829717)
,p_db_column_name=>'CODIGO_GRUPO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Codigo Grupo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250118728332829718)
,p_db_column_name=>'GRUPO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Grupo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250118814573829719)
,p_db_column_name=>'CODIGO_CLIENTE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Codigo Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250118980614829720)
,p_db_column_name=>'CLIENTE'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250119017972829721)
,p_db_column_name=>'ORDEN_COMPRA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250119130368829722)
,p_db_column_name=>'ESTADO_PEDIDO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Estado Pedido'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(250805827464152630)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250119217721829723)
,p_db_column_name=>'USUARIO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250119398688829724)
,p_db_column_name=>'FECHA_PEDIDO'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Fecha Pedido'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250119415149829725)
,p_db_column_name=>'CUBICADO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Cubicado'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(123891575071627861)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250119577769829726)
,p_db_column_name=>'FACTURADO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Facturado'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(123891575071627861)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250119632352829727)
,p_db_column_name=>'CANTIDAD_BU_CA_OC'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Cantidad Bu Ca Oc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250119791045829728)
,p_db_column_name=>'CANTIDAD_BU_CA_ENVIAR'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Cantidad Bu Ca Enviar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250119849038829729)
,p_db_column_name=>'CANTIDAD_BU_CA_PEDIDO'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Cantidad Bu Ca Pedido'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250119953104829730)
,p_db_column_name=>'SUBTOTAL_OC'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Subtotal Oc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250120069544829731)
,p_db_column_name=>'SUBTOTAL_ENVIAR'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Subtotal Enviar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250120141425829732)
,p_db_column_name=>'SUBTOTAL_PEDIDO'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Subtotal Pedido'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250783155554083732)
,p_db_column_name=>'ID'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250783230482083733)
,p_db_column_name=>'VER_PEDIDO'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Ver Pedido'
,p_column_link=>'f?p=&APP_ID.:615:&SESSION.::&DEBUG.::P615_NUMERO:#IDPEDIDO#'
,p_column_linktext=>'#VER_PEDIDO#'
,p_column_link_attr=>'target="_blank"'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250783410929083735)
,p_db_column_name=>'VER_FACTURA'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Ver Factura'
,p_column_link=>'f?p=&APP_ID.:310:&SESSION.::&DEBUG.::P310_GRUPO,P310_ORDEN_COMPRA,P310_CLIENTE:#CODIGO_GRUPO#,#ORDEN_COMPRA#,#CODIGO_CLIENTE#'
,p_column_linktext=>'#VER_FACTURA#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(251020305816896421)
,p_db_column_name=>'VER_ADJUNTOS'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Ver Adjuntos'
,p_column_link=>'f?p=100:401:&SESSION.::&DEBUG.::P401_TABLA,P401_ID,P401_ESTADO:T_VTAS_PEDIDOS_CAB,#IDPEDIDO#,0'
,p_column_linktext=>'#VER_ADJUNTOS#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(251020426491896422)
,p_db_column_name=>'CODIGO_RETENCION'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Codigo Retencion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(277880417291794325)
,p_db_column_name=>'DIFERENCIA'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Diferencia'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(250774754974035728)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2507748'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'IDPEDIDO:ORIGEN:CANAL:GRUPO:CLIENTE:FECHA_PEDIDO:ORDEN_COMPRA:TIPO:ESTADO_PEDIDO:USUARIO:CUBICADO:FACTURADO:CODIGO_RETENCION:CANTIDAD_BU_CA_OC:CANTIDAD_BU_CA_ENVIAR:CANTIDAD_BU_CA_PEDIDO:SUBTOTAL_OC:SUBTOTAL_ENVIAR:SUBTOTAL_PEDIDO:DIFERENCIA:VER_ADJU'
||'NTOS:VER_PEDIDO:VER_FACTURA:'
,p_sort_column_1=>'IDPEDIDO'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'DESC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'0:0:0:0:0'
,p_break_enabled_on=>'0:0:0:0:0'
,p_sum_columns_on_break=>'SUBTOTAL_OC:CANTIDAD_BU_CA_ENVIAR:SUBTOTAL_ENVIAR:SUBTOTAL_PEDIDO:CANTIDAD_BU_CA_PEDIDO:CANTIDAD_BU_CA_OC:DIFERENCIA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(379832615224420640)
,p_plug_name=>'Auditoria Creacion'
,p_parent_plug_id=>wwv_flow_imp.id(379832577128420639)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(207622408396798914)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT SLDOCO PEDIDO_NUMERO, SLDCTO PEDIDO_TIPO,  SLPA8 CODIGO_GRUPO,NOMBRES GRUPO, SLVR01 ORDEN_COMPRA, SLUSER USUARIO, ',
'to_date(TO_DATE(SLUPMJ + 1900000,''yyyyddd'')||'' ''||lpad(SLTDAY, 6,''0''), ''DD/MM/YYYY HH24MISS'') FECHA',
'FROM F42199@JDEDTADL ',
'INNER JOIN vt_jde_cliente ON (SLPA8=CODIGO)',
'WHERE  :P309_TABACTIVO =''#TblTracking''  ',
'AND SLPA8=:P309_GRUPO --and  SLVR01=rpad(''082024_3'', 25,'' '')  AND  TO_DATE(SLUPMJ + 1900000,''yyyyddd'') ',
'AND SLDCTO IN (''VN'', ''VE'') AND SLLTTR=520 AND SLLNID=1000',
'AND SLUPMJ BETWEEN  to_char(TO_DATE(:P309_FECHAINICIO, ''DD/MM/YYYY''), ''YYYYDDD'') - 1900000 AND  to_char(TO_DATE(:P309_FECHAFIN, ''DD/MM/YYYY''), ''YYYYDDD'') - 1900000',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'G_COMPANIA'
,p_plug_display_when_cond2=>'00001'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Auditoria Creacion'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(379832778169420641)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>350
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>379832778169420641
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379832884318420642)
,p_db_column_name=>'PEDIDO_NUMERO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Pedido Numero'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379832964995420643)
,p_db_column_name=>'PEDIDO_TIPO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Pedido Tipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379833016168420644)
,p_db_column_name=>'CODIGO_GRUPO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Codigo Grupo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379833166657420645)
,p_db_column_name=>'GRUPO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Grupo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379833292167420646)
,p_db_column_name=>'ORDEN_COMPRA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379833343913420647)
,p_db_column_name=>'USUARIO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(379833439996420648)
,p_db_column_name=>'FECHA'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY HH24:MI:SS'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(420888584559445791)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'4208886'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PEDIDO_NUMERO:PEDIDO_TIPO:CODIGO_GRUPO:GRUPO:ORDEN_COMPRA:USUARIO:FECHA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(250258818498270342)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(397187305772161598)
,p_button_name=>'BTN_BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176753300778920)
,p_button_image_alt=>'Buscar'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(250120397270829734)
,p_name=>'P309_TABACTIVO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(397187445097161599)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(250259583363270344)
,p_name=>'P309_ORIGEN'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(397187445097161599)
,p_prompt=>'Origen'
,p_source=>'NAC'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct CODIGOORIGEN D, CODIGOORIGEN R from vt_gzm_cliente',
'where nvl(TRIM(codigocanal), '' '') not in ( '' '', ''.'') and  ESTADO = 1 AND CODIGOGRUPO = CODIGOCLIENTE AND (:G_ROL = 1 OR (:G_ROL = 2 AND EJECUTIVO = :G_IDENTIFICACION))',
'AND COMPANIA = :G_COMPANIA;',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(250259857302270346)
,p_name=>'P309_CANAL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(397187445097161599)
,p_prompt=>'Canal'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct canal, codigocanal from vt_gzm_cliente',
'where nvl(TRIM(codigocanal), '' '') not in ( '' '', ''.'') and  ESTADO = 1 AND CODIGOGRUPO = CODIGOCLIENTE AND (:G_ROL = 1 OR (:G_ROL = 2 AND EJECUTIVO = :G_IDENTIFICACION))',
'AND COMPANIA = :G_COMPANIA;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Todos'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(250260279250270346)
,p_name=>'P309_GRUPO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(397187445097161599)
,p_prompt=>'Grupo'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  CODIGOGRUPO || '' - '' || GRUPO D, CODIGOGRUPO R FROM VT_GZM_CLIENTE',
'WHERE ESTADO = 1 AND CODIGOGRUPO = CODIGOCLIENTE AND (:G_ROL = 1 OR (:G_ROL = 2 AND EJECUTIVO = :G_IDENTIFICACION))',
' AND CODIGOCANAL = NVL(:P309_CANAL, CODIGOCANAL) AND ',
' CODIGOORIGEN= NVL(:P309_ORIGEN, CODIGOORIGEN) AND ',
' COMPANIA = :G_COMPANIA; '))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'TODOS'
,p_lov_cascade_parent_items=>'P309_CANAL,P309_ORIGEN'
,p_ajax_items_to_submit=>'P309_CANAL'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(250260671570270347)
,p_name=>'P309_FECHAINICIO'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(397187445097161599)
,p_item_default=>'sysdate-5'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Inicio'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(250261091355270347)
,p_name=>'P309_FECHAFIN'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(397187445097161599)
,p_item_default=>'SYSDATE'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Fin'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(250261498635270347)
,p_name=>'P309_CLIENTE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(397187445097161599)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(250261854437270347)
,p_name=>'P309_CARGA'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(397187445097161599)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(250279547359270388)
,p_name=>'CAMBIA_GRUPOELEGIDO'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P309_GRUPOELEGIDO'
,p_condition_element=>'P309_GRUPOELEGIDO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(250276359163270383)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pk_vtas_pedidos.sp_inserta_reportepedidos(',
'    p_canal => :P309_CANAL, ',
'    p_codigogrupo => :P309_GRUPO, ',
'    p_codigocliente => :P309_CLIENTE, ',
'    p_fechainicio => :P309_FECHAINICIO, ',
'    p_fechafin => :P309_FECHAFIN);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>250276359163270383
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(250276703151270384)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar datos'
,p_process_sql_clob=>':P309_CARGA :=0;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>250276703151270384
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
