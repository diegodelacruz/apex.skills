prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>114
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 114 - Ventas
--
-- Application Export:
--   Application:     114
--   Name:            Ventas
--   Date and Time:   11:47 Friday August 14, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 310
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_00310
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>310);
end;
/
prompt --application/pages/page_00310
begin
wwv_flow_imp_page.create_page(
 p_id=>310
,p_name=>'DLG lista factura'
,p_alias=>'DLG-LISTA-FACTURA'
,p_page_mode=>'MODAL'
,p_step_title=>'lista factura'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(250783506997083736)
,p_plug_name=>'Formulario'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(207623277923798915)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(251018757453896405)
,p_plug_name=>'Facturas'
,p_parent_plug_id=>wwv_flow_imp.id(250783506997083736)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(207622408396798914)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'G_COMPANIA'
,p_plug_display_when_cond2=>'00001'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT NUMERO_DOCUMENTO, TIPO_DOCUMENTO, NUMERO_FACTURA, TIPO_FACTURA,XMCTC1 || ''-'' || XMCTC2 || ''-'' || XMAA10 NUMERO_COMPROBANTE,',
'  case when a.numeroarchivo is null then '''' else ',
'  ''http://apps.zaimella.com/QCPs/fileApexDownloadWS/''||a.numeroarchivo end  DESCARGA, ',
'',
'     ar.ID NUMEROARCHIVO , ar.NUMERO_COMPROBANTE||''.pdf'' FILENAME, dbms_lob.getlength(AR.RIDE) BLOBCONTENT,  ''application/pdf'' MIMETYPE,',
' case when a.numeroarchivo is null then '''' else  ''<span class="fa fa-download" aria-hidden="true"></span>'' end icono,',
'  case when ar.ID is null then '''' else  ''<span class="fa fa-download" aria-hidden="true"></span>'' end icono2',
'  FROM ',
'    (select  DISTINCT SDDOCO NUMERO_DOCUMENTO, SDDCTO TIPO_DOCUMENTO, SDDOC NUMERO_FACTURA, SDDCT TIPO_FACTURA',
'        from F42119@JDEDTADL WHERE SDAN8=:P310_CLIENTE and  SDVR01=rpad(:P310_ORDEN_COMPRA, 25,'' '')',
'        UNION ',
'    select DISTINCT SDDOCO, SDDCTO, SDDOC, SDDCT from F4211@JDEDTADL WHERE SDAN8=:P310_CLIENTE and  SDVR01=rpad(:P310_ORDEN_COMPRA, 25,'' ''))',
'',
'   INNER JOIN F76ECXML@JDEDTADL ON (NUMERO_FACTURA=XMDOC AND TIPO_FACTURA=XMDCT)',
'   left join t_finz_documento_electronico f on (NUMERO_FACTURA=NUMERODOCUMENTO AND TIPO_FACTURA=TIPODOCUMENTO)',
'   left join FILES.T_APEX_ARCHIVOS a on (TABLA=''T_FINZ_DOCUMENTO_ELECTRONICO'' AND TIPO=''ARCH_PDF'' and ID_TABLA=f.id)',
'   left join dp.log_trx_electronica ar   on ( trim(NUMERO_COMPROBANTE)=trim(XMCTC1 || ''-'' || XMCTC2 || ''-'' || XMAA10) and TIPO_COMPROBANTE=''01'')',
'   WHERE XMDOC>0',
'   GROUP BY NUMERO_DOCUMENTO, TIPO_DOCUMENTO, NUMERO_FACTURA,TIPO_FACTURA, XMCTC1, XMCTC2, XMAA10, XMTAXX, XMDOC, XMDCT,',
'    a.numeroarchivo,   ar.ID, ar.NUMERO_COMPROBANTE, dbms_lob.getlength(AR.RIDE);  '))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Facturas'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(251018865955896406)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>251018865955896406
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(251018971739896407)
,p_db_column_name=>'NUMERO_DOCUMENTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Numero Documento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(251019013345896408)
,p_db_column_name=>'TIPO_DOCUMENTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo Documento'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(251019176993896409)
,p_db_column_name=>'NUMERO_FACTURA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Numero Factura'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(251019230179896410)
,p_db_column_name=>'TIPO_FACTURA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Tipo Factura'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(251019361916896411)
,p_db_column_name=>'DESCARGA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Descarga'
,p_column_link=>'#DESCARGA#'
,p_column_linktext=>'<span class="fa fa-download" aria-hidden="true"></span>'
,p_column_link_attr=>'target="_blank"'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(362609992140005433)
,p_db_column_name=>'ICONO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Icono'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(362610033698005434)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Numeroarchivo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(362610134952005435)
,p_db_column_name=>'FILENAME'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(362610223764005436)
,p_db_column_name=>'MIMETYPE'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Mimetype'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(362610375543005437)
,p_db_column_name=>'ICONO2'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Icono2'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(362610525543005439)
,p_db_column_name=>'NUMERO_COMPROBANTE'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Numero Comprobante'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(362610635932005440)
,p_db_column_name=>'BLOBCONTENT'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Descarga antiguo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'DOWNLOAD:VT_LOG_TRX_ELECTRONICA:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment:Descargar:DP'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(251058111390079662)
,p_application_user=>'C59SAPF'
,p_report_seq=>10
,p_report_alias=>'2510582'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMERO_DOCUMENTO:TIPO_DOCUMENTO:NUMERO_FACTURA:TIPO_FACTURA:NUMERO_COMPROBANTE:DESCARGA:BLOBCONTENT:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(310003160001)
,p_plug_name=>'Facturas'
,p_parent_plug_id=>wwv_flow_imp.id(250783506997083736)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(207622408396798914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'G_COMPANIA'
,p_plug_display_when_cond2=>'00003'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct cast(F."NumAtCard" as varchar2(100)) NUMERO_FACTURA_SAP, F."DocDate" FECHA_FACTURA_SAP,',
'       F."DocTotal" TOTAL_FACTURA_SAP,',
'       ''http://192.168.5.109/SapPDF/20519078504-'' ||',
'       nvl(F."U_BPP_MDTD", regexp_substr(F."NumAtCard", ''[^-]+'', 1, 1)) || ''-'' ||',
'       nvl(F."U_BPP_MDSD", regexp_substr(F."NumAtCard", ''[^-]+'', 1, 2)) || ''-'' ||',
'       nvl(F."U_BPP_MDCD", regexp_substr(F."NumAtCard", ''[^-]+'', 1, 3)) || ''.pdf'' DESCARGA_SAP',
'  from OINV@HANA_PE F join INV1@HANA_PE D on D."DocEntry" = F."DocEntry"',
'  left join ODLN@HANA_PE E on D."BaseType" = 15 and E."DocEntry" = D."BaseEntry"',
'  left join DLN1@HANA_PE ED on E."DocEntry" = ED."DocEntry" and ED."LineNum" = D."BaseLine"',
'  left join ORDR@HANA_PE R on (D."BaseType" = 17 and R."DocEntry" = D."BaseEntry") or (ED."BaseType" = 17 and R."DocEntry" = ED."BaseEntry")',
' where F."CANCELED" = ''N'' and R."DocNum" = :P310_ORDEN_ERP',
' order by FECHA_FACTURA_SAP, NUMERO_FACTURA_SAP'))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(310003160002)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>310003160002
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(310003160011)
,p_db_column_name=>'NUMERO_FACTURA_SAP'
,p_display_order=>10
,p_column_identifier=>'N'
,p_column_label=>'Numero Factura'
,p_column_type=>'STRING'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(310003160012)
,p_db_column_name=>'FECHA_FACTURA_SAP'
,p_display_order=>20
,p_column_identifier=>'O'
,p_column_label=>'Fecha Factura'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/YYYY'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(310003160013)
,p_db_column_name=>'TOTAL_FACTURA_SAP'
,p_display_order=>30
,p_column_identifier=>'P'
,p_column_label=>'Total Factura'
,p_column_type=>'NUMBER'
,p_format_mask=>'FML999G999G999G999G990D00'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(310003160014)
,p_db_column_name=>'DESCARGA_SAP'
,p_display_order=>40
,p_column_identifier=>'Q'
,p_column_label=>'Descargar'
,p_column_link=>'#DESCARGA_SAP#'
,p_column_linktext=>'<span class="fa fa-download" aria-hidden="true"></span>'
,p_column_link_attr=>'target="_blank" rel="noopener"'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(310003160021)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>20
,p_report_alias=>'C59SAPF'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMERO_FACTURA_SAP:FECHA_FACTURA_SAP:TOTAL_FACTURA_SAP:DESCARGA_SAP:'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(250783612346083737)
,p_name=>'P310_GRUPO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(250783506997083736)
,p_prompt=>'Grupo'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_CLIENTES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT to_char(NOMBRECLIENTE),CODIGOGRUPO FROM DP.V_GRUPO_CLIENTE ',
'WHERE TRIM(CODIGOGRUPO)=TRIM(CODIGOCLIENTE) AND CODORIGEN=''NAC'' AND (CODCANAL=''C03'' OR CODCANAL=''C01'') ',
'UNION ALL',
'select ''ECONOFARM S.A.'',''15772'' from dual ',
'UNION ALL',
'select ''FARMACIAS Y COMISARIATOS DE MEDICINAS S.'', ''10319'' from dual ',
'UNION ALL',
'select ''MEGA SANTAMARIA S.A.'',''66600'' from dual; ',
''))
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(250783715678083738)
,p_name=>'P310_ORDEN_COMPRA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(250783506997083736)
,p_prompt=>'Orden Compra'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(251019650347896414)
,p_name=>'P310_URL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(250783506997083736)
,p_item_default=>'192.168.5.40:8181/edocVisorRide/descargarride?compania=00001&tipo=01&comprobante='
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(310003160031)
,p_name=>'P310_ORDEN_ERP'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(250783506997083736)
,p_prompt=>'Orden ERP'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(310003160032)
,p_name=>'P310_IDPEDIDO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(250783506997083736)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(258271201549561934)
,p_name=>'P310_CLIENTE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(250783506997083736)
,p_prompt=>'Cliente'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_VTAS_CLIENTES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'CODIGOCLIENTE || '' - '' || NOMBRES AS DESCRIPCION, CODIGOCLIENTE',
'FROM VT_GZM_CLIENTE',
'WHERE COMPANIA = :G_COMPANIA;'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
