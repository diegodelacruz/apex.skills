prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>114
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 114 - Ventas
--
-- Application Export:
--   Application:     114
--   Name:            Ventas
--   Date and Time:   12:16 Friday August 14, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 314
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_00314
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>314);
end;
/
prompt --application/pages/page_00314
begin
wwv_flow_imp_page.create_page(
 p_id=>314
,p_name=>'Reporte incumplimiento y cancelados'
,p_alias=>'REPORTE-INCUMPLIMIENTO-Y-CANCELADOS'
,p_step_title=>'Reporte incumplimiento y cancelados'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''.apex-rds'').data(''onRegionChange'', function(mode, activeTab) {',
'    apex.item( "P314_TABACTIVO" ).setValue(activeTab.href);',
'});'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#rgnResumen_data_panel{',
'   height: 400px;',
'    OVERFLOW-Y: scroll;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(401365978341885315)
,p_plug_name=>'Reporte incumplimiento y cancelados'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_imp.id(207624090311798915)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(207077902574778828)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(207177697621778923)
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(401365999698885316)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(207622883613798915)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(401366139023885317)
,p_plug_name=>'Formulario'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(207623277923798915)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(254230533526921235)
,p_plug_name=>'Reportes'
,p_parent_plug_id=>wwv_flow_imp.id(401366139023885317)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(207623277923798915)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'N',
  'rds_mode', 'STANDARD',
  'remember_selection', 'SESSION')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(314003001)
,p_plug_name=>'Incumplimiento'
,p_region_name=>'tblIncumplimiento'
,p_parent_plug_id=>wwv_flow_imp.id(254230533526921235)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(207622408396798914)
,p_plug_display_sequence=>11
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'select',
'    i.FECHA_INGRESO,',
'    i.IDPEDIDO,',
'    i.ORDENCOMPRA ORDEN_COMPRA,',
'    i.TIPO,',
'    C.CODIGOORIGEN ORIGEN,',
'    C.CANAL,',
'    i.CODIGOCLIENTE || ''-'' || nvl(C.NOMBRES, i.CLIENTE_SAP) CLIENTE,',
'    i.CODIGOGRUPO || ''-'' || nvl(C.GRUPO, i.CLIENTE_SAP) GRUPO,',
'    nvl(nullif(trim(P.LINEANEGOCIO), ''''), cast(B."ItmsGrpNam" as varchar2(200))) LINEA_NEGOCIO,',
'    nvl(P.NOMBREPRODUCTO, i.PRODUCTO_SAP) PRODUCTO,',
'    P.CODIGOBARRA CODIGO_BARRA,',
'    i.CODIGOPRODUCTO CODIGO_PRODUCTO,',
'    i.CODIGO_PRODUCTO_CLIENTE,',
'    i.PRESENTACION,',
'    i.PRECIO,',
'    i.DESCUENTO,',
'    i.ID_INVERSION,',
'    i.CANTIDAD_BU_CA_OC,',
'    i.CANTIDAD_BU_CA_SOLICITADO,',
'    i.CANTIDAD_BU_CA_INCUMP,',
'    i.CANTIDAD_BU_CA_ALCANCE,',
'    i.CANTIDAD_UND_OC CANTIDAD_OC_UND,',
'    i.CANTIDAD_UND_SOLICITADO,',
'    i.CANTIDAD_UN_INCUMP,',
'    i.CANTIDAD_UND_ALCANCE,',
'    i.SUBTOTAL_OC,',
'    i.SUBTOTAL_SOLICITADO,',
'    i.SUBTOTAL_INCUMP,',
'    i.SUBTOTAL_ALCANCE,',
'    i.INFORMACION_ADICIONAL,',
'    i.INFORMACION_ADICIONAL_2,',
'    i.ESTADO_SAP ESTADO_JDE',
'from VT_VTAS_PEDIDOS_INCUMPLIMIENTO_PE i',
'left join VT_GZM_CLIENTE C',
'    on C.COMPANIA = ''00003''',
'   and C.CODIGOCLIENTE = i.CODIGOCLIENTE',
'left join VT_GZM_PRODUCTO P',
'    on P.COMPANIA = ''00003''',
'   and P.CODIGOPRODUCTO = i.CODIGOPRODUCTO',
'left join OITM@HANA_PE I',
'    on I."ItemCode" = i.CODIGOPRODUCTO',
'left join OITB@HANA_PE B',
'    on B."ItmsGrpCod" = I."ItmsGrpCod"',
'where :P314_CARGA = 1',
'  and (:P314_ORIGEN is null or C.CODIGOORIGEN = :P314_ORIGEN)',
'  and (:P314_CANAL is null or C.CODIGOCANAL = :P314_CANAL)',
'  and (:P314_GRUPO is null or i.CODIGOGRUPO = :P314_GRUPO)',
'  and trunc(i.FECHA_INGRESO) between trunc(to_date(:P314_FECHAINICIO, ''DD/MM/YYYY'')) and trunc(to_date(:P314_FECHAFIN, ''DD/MM/YYYY''))',
'  and (:G_ROL = 1 or (:G_ROL = 2 and C.EJECUTIVO = :G_IDENTIFICACION))',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P314_CARGA,P314_FECHAINICIO,P314_FECHAFIN,P314_GRUPO,P314_CANAL,P314_ORIGEN'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'G_COMPANIA'
,p_plug_display_when_cond2=>'00003'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Incumplimiento'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(314003101)
,p_name=>'Incumplimiento'
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>350
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>314003101
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101010)
,p_db_column_name=>'FECHA_INGRESO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Fecha Ingreso'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101020)
,p_db_column_name=>'IDPEDIDO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'# pedido'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101030)
,p_db_column_name=>'ORDEN_COMPRA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101040)
,p_db_column_name=>'TIPO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Tipo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101050)
,p_db_column_name=>'ORIGEN'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Origen'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101060)
,p_db_column_name=>'CANAL'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Canal'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101070)
,p_db_column_name=>'CLIENTE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101080)
,p_db_column_name=>'LINEA_NEGOCIO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Linea Negocio'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101090)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101100)
,p_db_column_name=>'CODIGO_BARRA'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Codigo Barra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101110)
,p_db_column_name=>'CODIGO_PRODUCTO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Codigo Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101120)
,p_db_column_name=>'PRESENTACION'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Presentacion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101130)
,p_db_column_name=>'PRECIO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101140)
,p_db_column_name=>'DESCUENTO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101150)
,p_db_column_name=>'CANTIDAD_BU_CA_OC'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Cantidad Bu Ca Oc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101160)
,p_db_column_name=>'CANTIDAD_BU_CA_SOLICITADO'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Cantidad Bu Ca Solicitado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101170)
,p_db_column_name=>'CANTIDAD_BU_CA_INCUMP'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Cantidad Bu Ca Incump'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101180)
,p_db_column_name=>'CANTIDAD_BU_CA_ALCANCE'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Cantidad Bu Ca Alcance'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101190)
,p_db_column_name=>'CANTIDAD_OC_UND'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Cantidad Und PQ Oc '
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101200)
,p_db_column_name=>'CANTIDAD_UND_SOLICITADO'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Cantidad Und PQ Solicitado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101210)
,p_db_column_name=>'CANTIDAD_UN_INCUMP'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Cantidad Un  PQ Incump'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101220)
,p_db_column_name=>'CANTIDAD_UND_ALCANCE'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Cantidad Und  PQ Alcance'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101230)
,p_db_column_name=>'SUBTOTAL_OC'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Subtotal Oc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101240)
,p_db_column_name=>'SUBTOTAL_SOLICITADO'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Subtotal Solicitado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101250)
,p_db_column_name=>'SUBTOTAL_INCUMP'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Subtotal Incump'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101260)
,p_db_column_name=>'SUBTOTAL_ALCANCE'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Subtotal Alcance'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101270)
,p_db_column_name=>'GRUPO'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Grupo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101280)
,p_db_column_name=>'ESTADO_JDE'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Estado ERP'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101290)
,p_db_column_name=>'INFORMACION_ADICIONAL'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Informacion Adicional'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101300)
,p_db_column_name=>'INFORMACION_ADICIONAL_2'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Informacion Adicional 2'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101310)
,p_db_column_name=>'CODIGO_PRODUCTO_CLIENTE'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Codigo Producto Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314003101320)
,p_db_column_name=>'ID_INVERSION'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Id Inversion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(314003101510)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'314003101510'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FECHA_INGRESO:IDPEDIDO:ORDEN_COMPRA:GRUPO:CANAL:CLIENTE:LINEA_NEGOCIO:PRODUCTO:CODIGO_BARRA:CODIGO_PRODUCTO:CODIGO_PRODUCTO_CLIENTE:PRESENTACION:PRECIO:DESCUENTO:ID_INVERSION:ESTADO_JDE:CANTIDAD_BU_CA_OC:CANTIDAD_BU_CA_SOLICITADO:CANTIDAD_BU_CA_INCUM'
||'P:CANTIDAD_BU_CA_ALCANCE:CANTIDAD_OC_UND:CANTIDAD_UND_SOLICITADO:CANTIDAD_UN_INCUMP:CANTIDAD_UND_ALCANCE:SUBTOTAL_OC:SUBTOTAL_SOLICITADO:SUBTOTAL_INCUMP:SUBTOTAL_ALCANCE:INFORMACION_ADICIONAL:INFORMACION_ADICIONAL_2:'
,p_sum_columns_on_break=>'CANTIDAD_BU_CA_OC:CANTIDAD_BU_CA_SOLICITADO:CANTIDAD_BU_CA_INCUMP:CANTIDAD_BU_CA_ALCANCE:CANTIDAD_OC_UND:CANTIDAD_UND_SOLICITADO:CANTIDAD_UN_INCUMP:CANTIDAD_UND_ALCANCE:SUBTOTAL_OC:SUBTOTAL_SOLICITADO:SUBTOTAL_INCUMP:SUBTOTAL_ALCANCE'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(314004001)
,p_plug_name=>'Con novedades'
,p_parent_plug_id=>wwv_flow_imp.id(254230533526921235)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(207123407083778876)
,p_plug_display_sequence=>12
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'select',
'    IDPEDIDO,',
'    ORIGEN,',
'    CLIENTE,',
'    LINEA_NEGOCIO,',
'    MARCA,',
'    SUBMARCA,',
'    NOMBRE_PRODUCTO,',
'    CODIGO_BARRA,',
'    CODIGO_PRODUCTO,',
'    ORDEN_COMPRA,',
'    FECHA_PEDIDO,',
'    TIPO,',
'    ESTADO,',
'    UNIDAD_MEDIDA,',
'    CANTIDAD_BU_CA,',
'    CANTIDAD_UND,',
'    PRECIO,',
'    TOTAL,',
'    TIPO_INACTIVO,',
'    OBSERVACION',
'from DATA.VT_VTAS_PEDIDOS_INACTIVOS_PE',
'where :P314_CARGA = 1',
'  and ORIGEN = :P314_ORIGEN',
'  and (:P314_CANAL is null or CODIGO_CANAL = :P314_CANAL)',
'  and (:P314_GRUPO is null or CODIGO_GRUPO = :P314_GRUPO)',
'  and trunc(FECHA_PEDIDO) between trunc(to_date(:P314_FECHAINICIO, ''DD/MM/YYYY'')) and trunc(to_date(:P314_FECHAFIN, ''DD/MM/YYYY''))',
'  and (:G_ROL = 1 or (:G_ROL = 2 and EJECUTIVO = :G_IDENTIFICACION))',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P314_CARGA,P314_FECHAINICIO,P314_FECHAFIN,P314_GRUPO,P314_CANAL,P314_ORIGEN'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'G_COMPANIA'
,p_plug_display_when_cond2=>'00003'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Con novedades'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(314004101)
,p_name=>'Con novedades'
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>314004101
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314004101010)
,p_db_column_name=>'IDPEDIDO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Idpedido'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314004101020)
,p_db_column_name=>'ORIGEN'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Origen'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314004101040)
,p_db_column_name=>'LINEA_NEGOCIO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Linea Negocio'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314004101050)
,p_db_column_name=>'MARCA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Marca'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314004101060)
,p_db_column_name=>'SUBMARCA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Submarca'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314004101070)
,p_db_column_name=>'NOMBRE_PRODUCTO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Nombre Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314004101080)
,p_db_column_name=>'CODIGO_BARRA'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Codigo Barra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314004101090)
,p_db_column_name=>'CODIGO_PRODUCTO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Codigo Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314004101100)
,p_db_column_name=>'ORDEN_COMPRA'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314004101110)
,p_db_column_name=>'FECHA_PEDIDO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Fecha Pedido'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314004101120)
,p_db_column_name=>'TIPO'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Tipo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314004101130)
,p_db_column_name=>'ESTADO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Estado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314004101140)
,p_db_column_name=>'UNIDAD_MEDIDA'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Unidad Medida'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314004101150)
,p_db_column_name=>'CANTIDAD_BU_CA'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Cantidad Bu Ca'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314004101160)
,p_db_column_name=>'CANTIDAD_UND'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Cantidad Und'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314004101170)
,p_db_column_name=>'PRECIO'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314004101180)
,p_db_column_name=>'TOTAL'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314004101190)
,p_db_column_name=>'TIPO_INACTIVO'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Tipo Inactivo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(135134069597792485)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314004101200)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314004101210)
,p_db_column_name=>'CLIENTE'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(314004101510)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'314004101510'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'IDPEDIDO:ORIGEN:CLIENTE:LINEA_NEGOCIO:MARCA:SUBMARCA:NOMBRE_PRODUCTO:CODIGO_BARRA:CODIGO_PRODUCTO:ORDEN_COMPRA:FECHA_PEDIDO:UNIDAD_MEDIDA:CANTIDAD_BU_CA:CANTIDAD_UND:PRECIO:TOTAL:TIPO_INACTIVO:OBSERVACION:'
,p_sort_column_1=>'FECHA_PEDIDO'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_sum_columns_on_break=>'TOTAL:CANTIDAD_BU_CA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(314005001)
,p_plug_name=>'Cancelado'
,p_region_name=>'tblCancelado'
,p_parent_plug_id=>wwv_flow_imp.id(254230533526921235)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(207123407083778876)
,p_plug_display_sequence=>21
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'select',
'    FECHA_INGRESO,',
'    IDPEDIDO,',
'    ORDENCOMPRA ORDEN_COMPRA,',
'    TIPO,',
'    ORIGEN,',
'    CANAL,',
'    CODIGOCLIENTE || ''-'' || CLIENTE CLIENTE,',
'    LINEANEGOCIO LINEA_NEGOCIO,',
'    NOMBREPRODUCTO PRODUCTO,',
'    CODIGOBARRA CODIGO_BARRA,',
'    CODIGOPRODUCTO CODIGO_PRODUCTO,',
'    PRESENTACION,',
'    PRECIO,',
'    DESCUENTO,',
'    CANTIDAD_BU_CA_OC,',
'    CANTIDAD_BU_CA_SOLICITADO,',
'    CANTIDAD_UND_OC CANTIDAD_OC_UND,',
'    CANTIDAD_UND_SOLICITADO,',
'    SUBTOTAL_OC,',
'    SUBTOTAL_SOLICITADO',
'from DATA.VT_VTAS_PEDIDOS_CANCELADOS_PE',
'where :P314_CARGA = 1',
'  and ORIGEN = :P314_ORIGEN',
'  and (:P314_CANAL is null or CODIGO_CANAL = :P314_CANAL)',
'  and (:P314_GRUPO is null or CODIGOGRUPO = :P314_GRUPO)',
'  and trunc(FECHA_INGRESO) between trunc(to_date(:P314_FECHAINICIO, ''DD/MM/YYYY'')) and trunc(to_date(:P314_FECHAFIN, ''DD/MM/YYYY''))',
'  and (:G_ROL = 1 or (:G_ROL = 2 and EJECUTIVO = :G_IDENTIFICACION))',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P314_CARGA,P314_FECHAINICIO,P314_FECHAFIN,P314_GRUPO,P314_CANAL,P314_ORIGEN'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'G_COMPANIA'
,p_plug_display_when_cond2=>'00003'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Cancelado'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(314005101)
,p_name=>'Cancelado'
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>350
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>314005101
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314005101010)
,p_db_column_name=>'FECHA_INGRESO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Fecha Ingreso'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314005101020)
,p_db_column_name=>'IDPEDIDO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Idpedido'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314005101030)
,p_db_column_name=>'ORDEN_COMPRA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314005101040)
,p_db_column_name=>'TIPO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Tipo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314005101050)
,p_db_column_name=>'ORIGEN'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Origen'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314005101060)
,p_db_column_name=>'CANAL'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Canal'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314005101070)
,p_db_column_name=>'CLIENTE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314005101080)
,p_db_column_name=>'LINEA_NEGOCIO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Linea Negocio'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314005101090)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314005101100)
,p_db_column_name=>'CODIGO_BARRA'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Codigo Barra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314005101110)
,p_db_column_name=>'CODIGO_PRODUCTO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Codigo Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314005101120)
,p_db_column_name=>'PRESENTACION'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Presentacion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314005101130)
,p_db_column_name=>'PRECIO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314005101140)
,p_db_column_name=>'DESCUENTO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314005101150)
,p_db_column_name=>'CANTIDAD_BU_CA_OC'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Cantidad Bu Ca Oc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314005101160)
,p_db_column_name=>'CANTIDAD_BU_CA_SOLICITADO'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Cantidad Bu Ca Solicitado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314005101170)
,p_db_column_name=>'CANTIDAD_OC_UND'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Cantidad Und Pq Oc '
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314005101180)
,p_db_column_name=>'CANTIDAD_UND_SOLICITADO'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Cantidad Und  Pq Solicitado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314005101190)
,p_db_column_name=>'SUBTOTAL_OC'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Subtotal Oc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314005101200)
,p_db_column_name=>'SUBTOTAL_SOLICITADO'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Subtotal Solicitado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(314005101510)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'314005101510'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FECHA_INGRESO:IDPEDIDO:ORDEN_COMPRA:TIPO:ORIGEN:CANAL:CLIENTE:LINEA_NEGOCIO:PRODUCTO:CODIGO_BARRA:CODIGO_PRODUCTO:PRESENTACION:PRECIO:DESCUENTO:CANTIDAD_BU_CA_OC:CANTIDAD_BU_CA_SOLICITADO:CANTIDAD_OC_UND:CANTIDAD_UND_SOLICITADO:SUBTOTAL_OC:SUBTOTAL_S'
||'OLICITADO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(255598487033264105)
,p_plug_name=>'Incumplimiento'
,p_region_name=>'tblIncumplimiento'
,p_parent_plug_id=>wwv_flow_imp.id(254230533526921235)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(207622408396798914)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT FECHA_INGRESO,IDPEDIDO, ORDENCOMPRA ORDEN_COMPRA, i.TIPO,',
'CODIGOORIGEN ORIGEN, CANAL,  i.CODIGOCLIENTE||''-''||NOMBRES Cliente ,C.CODIGOGRUPO||''-''||C.GRUPO GRUPO,',
'LINEANEGOCIO LINEA_NEGOCIO,NOMBREPRODUCTO producto, CODIGOBARRA CODIGO_BARRA,  i.CODIGOPRODUCTO CODIGO_PRODUCTO,CODIGO_PRODUCTO_CLIENTE, i.PRESENTACION, ',
'PRECIO, DESCUENTO, ID_INVERSION,',
'CANTIDAD_BU_CA_OC, CANTIDAD_BU_CA_SOLICITADO, CANTIDAD_BU_CA_INCUMP, CANTIDAD_BU_CA_ALCANCE, ',
'CANTIDAD_UND_OC CANTIDAD_OC_UND, CANTIDAD_UND_SOLICITADO, CANTIDAD_UN_INCUMP, CANTIDAD_UND_ALCANCE, ',
'SUBTOTAL_OC, SUBTOTAL_SOLICITADO, SUBTOTAL_INCUMP, SUBTOTAL_ALCANCE, ',
'INFORMACION_ADICIONAL,INFORMACION_ADICIONAL_2,ESTADO_JDE',
'FROM VT_VTAS_PEDIDOS_INCUMPLIMIENTO_CANCELADO  i',
'INNER JOIN vt_jde_cliente C ON (i.CODIGOCLIENTE=c.CODIGO)',
'INNER JOIN VT_JDE_PRODUCTOS P ON (p.CODIGOPRODUCTO=i.CODIGOPRODUCTO)',
'where :P314_CARGA=1 --and :P314_TABACTIVO=''#tblIncumplimiento''  ',
'and  i.ESTADO=1      AND CODIGOCANAL=NVL(:P314_CANAL,CODIGOCANAL ) and  i.CODIGOgrupo=NVL(:P314_GRUPO,i.CODIGOgrupo ) ',
'AND CODIGOORIGEN=:P314_ORIGEN',
'and  trunc(FECHA_INGRESO) between TRUNC(TO_DATE(:P314_FECHAINICIO, ''DD/MM/YYYY'')) and TRUNC(TO_DATE(:P314_FECHAFIN,  ''DD/MM/YYYY''));'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P314_CARGA,P314_FECHAINICIO,P314_FECHAFIN,P314_GRUPO,P314_CANAL,P314_ORIGEN'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'G_COMPANIA'
,p_plug_display_when_cond2=>'00001'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Incumplimiento'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(255598565078264106)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>350
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>255598565078264106
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255598680005264107)
,p_db_column_name=>'FECHA_INGRESO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Fecha Ingreso'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255598752639264108)
,p_db_column_name=>'IDPEDIDO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'# pedido'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255598800071264109)
,p_db_column_name=>'ORDEN_COMPRA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255598934648264110)
,p_db_column_name=>'TIPO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Tipo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255599088815264111)
,p_db_column_name=>'ORIGEN'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Origen'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255599199870264112)
,p_db_column_name=>'CANAL'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Canal'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255599248083264113)
,p_db_column_name=>'CLIENTE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255599317958264114)
,p_db_column_name=>'LINEA_NEGOCIO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Linea Negocio'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255599401249264115)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255599592802264116)
,p_db_column_name=>'CODIGO_BARRA'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Codigo Barra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255599678174264117)
,p_db_column_name=>'CODIGO_PRODUCTO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Codigo Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255599795087264118)
,p_db_column_name=>'PRESENTACION'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Presentacion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255599851875264119)
,p_db_column_name=>'PRECIO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255599943352264120)
,p_db_column_name=>'DESCUENTO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255600012408264121)
,p_db_column_name=>'CANTIDAD_BU_CA_OC'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Cantidad Bu Ca Oc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255600107510264122)
,p_db_column_name=>'CANTIDAD_BU_CA_SOLICITADO'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Cantidad Bu Ca Solicitado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255600253676264123)
,p_db_column_name=>'CANTIDAD_BU_CA_INCUMP'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Cantidad Bu Ca Incump'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255600369105264124)
,p_db_column_name=>'CANTIDAD_BU_CA_ALCANCE'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Cantidad Bu Ca Alcance'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255600434370264125)
,p_db_column_name=>'CANTIDAD_OC_UND'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Cantidad Und PQ Oc '
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255600570187264126)
,p_db_column_name=>'CANTIDAD_UND_SOLICITADO'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Cantidad Und PQ Solicitado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255600662206264127)
,p_db_column_name=>'CANTIDAD_UN_INCUMP'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Cantidad Un  PQ Incump'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255600721630264128)
,p_db_column_name=>'CANTIDAD_UND_ALCANCE'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Cantidad Und  PQ Alcance'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255600805279264129)
,p_db_column_name=>'SUBTOTAL_OC'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Subtotal Oc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255600944248264130)
,p_db_column_name=>'SUBTOTAL_SOLICITADO'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Subtotal Solicitado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255601002752264131)
,p_db_column_name=>'SUBTOTAL_INCUMP'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Subtotal Incump'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255601116677264132)
,p_db_column_name=>'SUBTOTAL_ALCANCE'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Subtotal Alcance'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(277880652712794327)
,p_db_column_name=>'GRUPO'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Grupo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(277880766415794328)
,p_db_column_name=>'ESTADO_JDE'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Estado ERP'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(277880840446794329)
,p_db_column_name=>'INFORMACION_ADICIONAL'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Informacion Adicional'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(277880931251794330)
,p_db_column_name=>'INFORMACION_ADICIONAL_2'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Informacion Adicional 2'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(277881058517794331)
,p_db_column_name=>'CODIGO_PRODUCTO_CLIENTE'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Codigo Producto Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(277881113019794332)
,p_db_column_name=>'ID_INVERSION'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Id Inversion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(255653475454311305)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2556535'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FECHA_INGRESO:IDPEDIDO:ORDEN_COMPRA:GRUPO:CANAL:CLIENTE:LINEA_NEGOCIO:PRODUCTO:CODIGO_BARRA:CODIGO_PRODUCTO:CODIGO_PRODUCTO_CLIENTE:PRESENTACION:PRECIO:DESCUENTO:ID_INVERSION:ESTADO_JDE:CANTIDAD_BU_CA_OC:CANTIDAD_BU_CA_SOLICITADO:CANTIDAD_BU_CA_INCUM'
||'P:CANTIDAD_BU_CA_ALCANCE:CANTIDAD_OC_UND:CANTIDAD_UND_SOLICITADO:CANTIDAD_UN_INCUMP:CANTIDAD_UND_ALCANCE:SUBTOTAL_OC:SUBTOTAL_SOLICITADO:SUBTOTAL_INCUMP:SUBTOTAL_ALCANCE:INFORMACION_ADICIONAL:INFORMACION_ADICIONAL_2:'
,p_sum_columns_on_break=>'CANTIDAD_BU_CA_OC:CANTIDAD_BU_CA_SOLICITADO:CANTIDAD_BU_CA_INCUMP:CANTIDAD_BU_CA_ALCANCE:CANTIDAD_OC_UND:CANTIDAD_UND_SOLICITADO:CANTIDAD_UN_INCUMP:CANTIDAD_UND_ALCANCE:SUBTOTAL_OC:SUBTOTAL_SOLICITADO:SUBTOTAL_INCUMP:SUBTOTAL_ALCANCE'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(255601272564264133)
,p_plug_name=>'Cancelado'
,p_region_name=>'tblCancelado'
,p_parent_plug_id=>wwv_flow_imp.id(254230533526921235)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(207123407083778876)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT FECHA_INGRESO,IDPEDIDO, ORDENCOMPRA ORDEN_COMPRA, i.TIPO,',
'CODIGOORIGEN ORIGEN, CANAL,  i.CODIGOCLIENTE||''-''||NOMBRES Cliente ,',
'LINEANEGOCIO LINEA_NEGOCIO,NOMBREPRODUCTO producto, CODIGOBARRA CODIGO_BARRA, ',
' i.CODIGOPRODUCTO CODIGO_PRODUCTO, i.PRESENTACION, PRECIO, DESCUENTO, ',
'CANTIDAD_BU_CA_OC, CANTIDAD_BU_CA_SOLICITADO,   CANTIDAD_UND_OC CANTIDAD_OC_UND, CANTIDAD_UND_SOLICITADO,   SUBTOTAL_OC, SUBTOTAL_SOLICITADO',
'FROM VT_VTAS_PEDIDOS_INCUMPLIMIENTO_CANCELADO  i',
'INNER JOIN vt_jde_cliente C ON (i.CODIGOCLIENTE=c.CODIGO)',
'INNER JOIN VT_JDE_PRODUCTOS P ON (p.CODIGOPRODUCTO=i.CODIGOPRODUCTO)',
'where :P314_CARGA=1 --and :P314_TABACTIVO=''#tblCancelado''  ',
'and  i.ESTADO=3     AND CODIGOCANAL=NVL(:P314_CANAL,CODIGOCANAL ) and  i.CODIGOgrupo=NVL(:P314_GRUPO,i.CODIGOgrupo ) ',
'AND CODIGOORIGEN=:P314_ORIGEN',
'and  FECHA_INGRESO between :P314_FECHAINICIO and :P314_FECHAFIN;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P314_CARGA,P314_FECHAINICIO,P314_FECHAFIN,P314_GRUPO,P314_CANAL,P314_ORIGEN'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'G_COMPANIA'
,p_plug_display_when_cond2=>'00001'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Cancelado'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(255601300533264134)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>350
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>255601300533264134
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255601453865264135)
,p_db_column_name=>'FECHA_INGRESO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Fecha Ingreso'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255601542011264136)
,p_db_column_name=>'IDPEDIDO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Idpedido'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255601697322264137)
,p_db_column_name=>'ORDEN_COMPRA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255601780674264138)
,p_db_column_name=>'TIPO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Tipo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255601817379264139)
,p_db_column_name=>'ORIGEN'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Origen'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255601986437264140)
,p_db_column_name=>'CANAL'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Canal'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255602063641264141)
,p_db_column_name=>'CLIENTE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255602143105264142)
,p_db_column_name=>'LINEA_NEGOCIO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Linea Negocio'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255602298520264143)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255602387395264144)
,p_db_column_name=>'CODIGO_BARRA'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Codigo Barra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255602499262264145)
,p_db_column_name=>'CODIGO_PRODUCTO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Codigo Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255602588445264146)
,p_db_column_name=>'PRESENTACION'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Presentacion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255602603312264147)
,p_db_column_name=>'PRECIO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255602776759264148)
,p_db_column_name=>'DESCUENTO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255602839345264149)
,p_db_column_name=>'CANTIDAD_BU_CA_OC'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Cantidad Bu Ca Oc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255602927716264150)
,p_db_column_name=>'CANTIDAD_BU_CA_SOLICITADO'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Cantidad Bu Ca Solicitado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255641383131309301)
,p_db_column_name=>'CANTIDAD_OC_UND'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Cantidad Und Pq Oc '
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255641493596309302)
,p_db_column_name=>'CANTIDAD_UND_SOLICITADO'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Cantidad Und  Pq Solicitado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255641521849309303)
,p_db_column_name=>'SUBTOTAL_OC'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Subtotal Oc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255641695734309304)
,p_db_column_name=>'SUBTOTAL_SOLICITADO'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Subtotal Solicitado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(255654013855311373)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2556541'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FECHA_INGRESO:IDPEDIDO:ORDEN_COMPRA:TIPO:ORIGEN:CANAL:CLIENTE:LINEA_NEGOCIO:PRODUCTO:CODIGO_BARRA:CODIGO_PRODUCTO:PRESENTACION:PRECIO:DESCUENTO:CANTIDAD_BU_CA_OC:CANTIDAD_BU_CA_SOLICITADO:CANTIDAD_OC_UND:CANTIDAD_UND_SOLICITADO:SUBTOTAL_OC:SUBTOTAL_S'
||'OLICITADO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(535345950098353946)
,p_plug_name=>'Con novedades'
,p_parent_plug_id=>wwv_flow_imp.id(254230533526921235)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(207123407083778876)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select IDPEDIDO,origen, CLIENTE,',
'LINEA_NEGOCIO, MARCA, SUBMARCA, NOMBRE_PRODUCTO, CODIGO_BARRA, CODIGO_PRODUCTO,',
' ORDEN_COMPRA, FECHA_PEDIDO, TIPO,  ESTADO, UNIDAD_MEDIDA,',
'CANTIDAD_BU_CA, CANTIDAD_UND, PRECIO, TOTAL, TIPO_INACTIVO, OBSERVACION',
'from VT_VTAS_PEDIDOS_Inactivos ',
'where :P314_CARGA=1 --and :P314_TABACTIVO=''#tblIncumplimiento''  ',
'AND ORIGEN=:P314_ORIGEN   AND codigo_canal=NVL(:P314_CANAL,codigo_canal ) and  CODIGO_GRUPO=NVL(:P314_GRUPO,CODIGO_GRUPO ) ',
'and  FECHA_PEDIDO between :P314_FECHAINICIO and :P314_FECHAFIN',
'AND (:G_ROL = 1 OR (:G_ROL = 2 AND EJECUTIVO = :G_IDENTIFICACION));'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P314_CARGA,P314_FECHAINICIO,P314_FECHAFIN,P314_GRUPO,P314_CANAL,P314_ORIGEN'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'G_COMPANIA'
,p_plug_display_when_cond2=>'00001'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Con novedades'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(535346084939353947)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>535346084939353947
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(281748343239015230)
,p_db_column_name=>'IDPEDIDO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Idpedido'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(281748715210015231)
,p_db_column_name=>'ORIGEN'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Origen'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(281749166192015232)
,p_db_column_name=>'LINEA_NEGOCIO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Linea Negocio'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(281749568798015232)
,p_db_column_name=>'MARCA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Marca'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(281749979950015232)
,p_db_column_name=>'SUBMARCA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Submarca'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(281750376109015232)
,p_db_column_name=>'NOMBRE_PRODUCTO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Nombre Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(281750702495015232)
,p_db_column_name=>'CODIGO_BARRA'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Codigo Barra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(281751171869015232)
,p_db_column_name=>'CODIGO_PRODUCTO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Codigo Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(281751571586015233)
,p_db_column_name=>'ORDEN_COMPRA'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(281751931442015233)
,p_db_column_name=>'FECHA_PEDIDO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Fecha Pedido'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(281752377718015233)
,p_db_column_name=>'TIPO'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Tipo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(281752711232015233)
,p_db_column_name=>'ESTADO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Estado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(281753168986015234)
,p_db_column_name=>'UNIDAD_MEDIDA'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Unidad Medida'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(281753533587015234)
,p_db_column_name=>'CANTIDAD_BU_CA'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Cantidad Bu Ca'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(281753985797015234)
,p_db_column_name=>'CANTIDAD_UND'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Cantidad Und'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(281754355231015234)
,p_db_column_name=>'PRECIO'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(281754762915015234)
,p_db_column_name=>'TOTAL'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(281755141788015234)
,p_db_column_name=>'TIPO_INACTIVO'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Tipo Inactivo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(135134069597792485)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(281755564596015235)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(281755950169015235)
,p_db_column_name=>'CLIENTE'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(535994730207936900)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2542467'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'IDPEDIDO:ORIGEN:CLIENTE:LINEA_NEGOCIO:MARCA:SUBMARCA:NOMBRE_PRODUCTO:CODIGO_BARRA:CODIGO_PRODUCTO:ORDEN_COMPRA:FECHA_PEDIDO:UNIDAD_MEDIDA:CANTIDAD_BU_CA:CANTIDAD_UND:PRECIO:TOTAL:TIPO_INACTIVO:OBSERVACION:'
,p_sort_column_1=>'FECHA_PEDIDO'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_sum_columns_on_break=>'TOTAL:CANTIDAD_BU_CA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(254437487983994061)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(401365999698885316)
,p_button_name=>'BTN_BUSCAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176753300778920)
,p_button_image_alt=>'Buscar'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(362606734657005401)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(255598487033264105)
,p_button_name=>'ACTUALIZAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176753300778920)
,p_button_image_alt=>'Actualizar'
,p_button_position=>'COPY'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(254438166721994064)
,p_name=>'P314_ORIGEN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(401366139023885317)
,p_item_default=>'NAC'
,p_prompt=>'Origen'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct CODIGOORIGEN D, CODIGOORIGEN R from vt_gzm_cliente',
'where nvl(TRIM(codigocanal), '' '') not in ( '' '', ''.'') and  ESTADO = 1 AND CODIGOGRUPO = CODIGOCLIENTE AND (:G_ROL = 1 OR (:G_ROL = 2 AND EJECUTIVO = :G_IDENTIFICACION))',
'AND COMPANIA = :G_COMPANIA;',
''))
,p_cHeight=>1
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(254438517784994067)
,p_name=>'P314_CANAL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(401366139023885317)
,p_prompt=>'Canal'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct canal, codigocanal from vt_gzm_cliente',
'where nvl(TRIM(codigocanal), '' '') not in ( '' '', ''.'') and  ESTADO = 1 AND CODIGOGRUPO = CODIGOCLIENTE AND (:G_ROL = 1 OR (:G_ROL = 2 AND EJECUTIVO = :G_IDENTIFICACION))',
'AND COMPANIA = :G_COMPANIA;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Todos'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(254438975883994067)
,p_name=>'P314_GRUPO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(401366139023885317)
,p_prompt=>'Grupo'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  CODIGOGRUPO || '' - '' || GRUPO D, CODIGOGRUPO R FROM VT_GZM_CLIENTE',
'WHERE ESTADO = 1 AND CODIGOGRUPO = CODIGOCLIENTE AND (:G_ROL = 1 OR (:G_ROL = 2 AND EJECUTIVO = :G_IDENTIFICACION))',
'AND CODIGOORIGEN = :P314_ORIGEN',
' AND CODIGOCANAL = NVL(:P314_CANAL, CODIGOCANAL) AND COMPANIA = :G_COMPANIA; '))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Todos'
,p_lov_cascade_parent_items=>'P314_CANAL,P314_ORIGEN'
,p_ajax_items_to_submit=>'P314_CANAL,P314_ORIGEN'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(254439357297994067)
,p_name=>'P314_FECHAINICIO'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(401366139023885317)
,p_item_default=>'trunc((sysdate),''MM'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Inicio'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(254439798056994068)
,p_name=>'P314_FECHAFIN'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(401366139023885317)
,p_item_default=>'SYSDATE'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Fin'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(254440564237994068)
,p_name=>'P314_CARGA'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(401366139023885317)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(255550967656081438)
,p_name=>'P314_TABACTIVO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(401366139023885317)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(254460941836994110)
,p_name=>'CAMBIA_GRUPOELEGIDO'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P314_GRUPOELEGIDO'
,p_condition_element=>'P314_GRUPOELEGIDO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(254458555436994105)
,p_name=>'Buscar reportes'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(254437487983994061)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(254460598706994110)
,p_event_id=>wwv_flow_imp.id(254458555436994105)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P314_CARGA :=1;'
,p_attribute_03=>'P314_CARGA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(255550813678081437)
,p_event_id=>wwv_flow_imp.id(254458555436994105)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(255598487033264105)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(255641713583309305)
,p_event_id=>wwv_flow_imp.id(254458555436994105)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(255601272564264133)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(277880508653794326)
,p_event_id=>wwv_flow_imp.id(254458555436994105)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(535345950098353946)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(314006001)
,p_event_id=>wwv_flow_imp.id(254458555436994105)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(314003001)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(314006002)
,p_event_id=>wwv_flow_imp.id(254458555436994105)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(314004001)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(314006003)
,p_event_id=>wwv_flow_imp.id(254458555436994105)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(314005001)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(254457797541994103)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pk_vtas_pedidos.sp_inserta_reportepedidos(',
'    p_canal => :P314_CANAL, ',
'    p_codigogrupo => :P314_GRUPO, ',
'    p_codigocliente => :P314_CLIENTE, ',
'    p_fechainicio => :P314_FECHAINICIO, ',
'    p_fechafin => :P314_FECHAFIN);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>254457797541994103
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(362606856501005402)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ACTUALIZAR CANCELAR ORDEN'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  PK_VTAS_PEDIDOS_COMMONS.SP_CANCELAR_PEDIDO();',
'--rollback; ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(362606734657005401)
,p_internal_uid=>362606856501005402
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(254458167548994104)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar datos'
,p_process_sql_clob=>':P314_CARGA := case when :REQUEST = ''BTN_BUSCAR'' then 1 else 0 end;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>254458167548994104
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
