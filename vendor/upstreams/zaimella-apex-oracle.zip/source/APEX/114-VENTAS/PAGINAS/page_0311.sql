prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>114
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 114 - Ventas
--
-- Application Export:
--   Application:     114
--   Name:            Ventas
--   Date and Time:   15:28 Tuesday July 21, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 311
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_00311
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>311);
end;
/
prompt --application/pages/page_00311
begin
wwv_flow_imp_page.create_page(
 p_id=>311
,p_name=>unistr('Reporte Notas de Cr\00E9dito')
,p_step_title=>'Devolucion Post entrega'
,p_warn_on_unsaved_changes=>'N'
,p_welcome_text=>'Reporte de Ordenes'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(488675859637909479)
,p_plug_name=>unistr('Reporte Notas de Cr\00E9dito')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_imp.id(207624090311798915)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(207077902574778828)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(207177697621778923)
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(488675947243909480)
,p_plug_name=>'Barra de accion'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(207622883613798915)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(583079264145895715)
,p_plug_name=>'Formulario'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(207623277923798915)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(253522502145945531)
,p_plug_name=>'Reportes'
,p_parent_plug_id=>wwv_flow_imp.id(583079264145895715)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(207623277923798915)
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'N',
  'rds_mode', 'STANDARD',
  'remember_selection', 'SESSION')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(251023022221896448)
,p_plug_name=>'Devoluciones'
,p_parent_plug_id=>wwv_flow_imp.id(253522502145945531)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(207123407083778876)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT nc.IDDEVOLUCION, nc.canal,nc.GRUPO, nc.CODIGO_CLIENTE, nc.CLIENTE, nc.OBSERVACION, nc.USUARIO, nc.FECHA_INGRESO,',
' FECHA_APROBACION, FECHA_NC, ORDENNUMERO, ORDENTIPO, ESTADO_JDE, TIPO_NC, NUMERO_NC,NUMERO_FACT, CODIGO_PRODUCTO, PRODUCTO,',
'  UNIDAD_MEDIDA, CANTIDAD_UN, PRECIO, SUBTOTAL, MOTIVO, nc.ESTADO, nc.ESTADO_DESCRIPCION,',
'case when nc.ESTADO is not null THEN',
'''<span class="fa fa-road" aria-hidden="true"></span>'' else '''' end VER_RUTA,',
'DECODE(numeroarchivo, NULL, decode(NUMERO_NC, 0, '''',''http://ws-server.zaimella.com:8181/edocVisorRide/descargarride?compania=00001&tipo=04&comprobante=''||XMCTC1 || ''-'' || XMCTC2 || ''-'' || XMAA10||''&ruc=''||XMTAXX  ),',
'''http://apps.zaimella.com/QCPs/fileApexDownloadWS/''||numeroarchivo) VER_NC ',
'FROM vt_VTAS_DEVOLUCIONES_HISTORICO  nc',
'left JOIN (SELECT DISTINCT XMDOC,XMDCT, XMCTC1,XMCTC2, XMAA10, XMTAXX FROM  F76ECXML@JDEDTADL  WHERE XMDCT=''D1'') ON (NUMERO_NC=XMDOC AND TIPO_NC=XMDCT AND XMDOC>0 )',
'left join t_finz_documento_electronico f on (nc.NUMERO_NC=f.NUMERODOCUMENTO AND nc.TIPO_NC=f.TIPODOCUMENTO)',
'left join FILES.T_APEX_ARCHIVOS a on (a.TABLA=''T_FINZ_DOCUMENTO_ELECTRONICO'' AND a.TIPO=''ARCH_PDF'' and a.ID_TABLA=f.id)',
'where :P311_CARGA =1 AND CODIGO_CANAL=NVL(:P311_CANAL,CODIGO_CANAL )  and CODIGO_GRUPO=NVL(:P311_GRUPO,CODIGO_GRUPO ) ',
'AND (:G_ROL = 1 OR (:G_ROL = 2 AND EJECUTIVO = :G_IDENTIFICACION))',
'and FECHA_INGRESO between :P311_FECHA_INI and :P311_FECHA_FIN;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P311_FECHA_INI,P311_FECHA_FIN,P311_CARGA'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select 1 from dual where :G_COMPANIA = ''00001'''
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Devoluciones'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(251023168992896449)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>350
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>251023168992896449
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(251023201980896450)
,p_db_column_name=>'IDDEVOLUCION'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id devolucion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253519509435945501)
,p_db_column_name=>'CODIGO_CLIENTE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Codigo Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253519633902945502)
,p_db_column_name=>'CLIENTE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253519708779945503)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253519813423945504)
,p_db_column_name=>'USUARIO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253519980002945505)
,p_db_column_name=>'FECHA_INGRESO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fecha Ingreso'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253520025680945506)
,p_db_column_name=>'FECHA_APROBACION'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fecha Aprobacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253520218872945508)
,p_db_column_name=>'ORDENNUMERO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Ordennumero'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253520384250945509)
,p_db_column_name=>'ORDENTIPO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Ordentipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253520485162945510)
,p_db_column_name=>'ESTADO_JDE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Estado ERP'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253520645159945512)
,p_db_column_name=>'CODIGO_PRODUCTO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Codigo Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253520792187945513)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253520887997945514)
,p_db_column_name=>'UNIDAD_MEDIDA'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Unidad Medida'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253520965629945515)
,p_db_column_name=>'CANTIDAD_UN'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Cantidad Un'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253521058221945516)
,p_db_column_name=>'PRECIO'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253521161307945517)
,p_db_column_name=>'SUBTOTAL'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Subtotal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253521230912945518)
,p_db_column_name=>'MOTIVO'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Motivo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253521353756945519)
,p_db_column_name=>'ESTADO'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Estado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253521452407945520)
,p_db_column_name=>'ESTADO_DESCRIPCION'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253521544689945521)
,p_db_column_name=>'FECHA_NC'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Fecha Nc'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253521610455945522)
,p_db_column_name=>'NUMERO_NC'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Numero Nc'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253521709563945523)
,p_db_column_name=>'VER_RUTA'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Ver Ruta'
,p_column_link=>'f?p=100:104:&SESSION.::&DEBUG.::G_OBJETO,G_OBJETO_ID,G_TODO:DEVOLUCION,#IDDEVOLUCION#,true'
,p_column_linktext=>'#VER_RUTA#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253521993324945525)
,p_db_column_name=>'VER_NC'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Ver Nc'
,p_column_link=>'#VER_NC#'
,p_column_linktext=>'<span aria-hidden="true" class="fa fa-list-alt"></span>'
,p_column_link_attr=>'target="_blank" rel="noopener"'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253522369403945529)
,p_db_column_name=>'CANAL'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Canal'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253522400343945530)
,p_db_column_name=>'GRUPO'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Grupo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(258271391774561935)
,p_db_column_name=>'NUMERO_FACT'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Numero Fact'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(258271414505561936)
,p_db_column_name=>'TIPO_NC'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Tipo Nc'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(253544193482954055)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2535442'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'IDDEVOLUCION:ESTADO_DESCRIPCION:VER_RUTA:CANAL:GRUPO:CLIENTE:CODIGO_CLIENTE:OBSERVACION:USUARIO:FECHA_INGRESO:FECHA_APROBACION:ORDENNUMERO:ORDENTIPO:FECHA_NC:TIPO_NC:NUMERO_NC:VER_NC:ESTADO_JDE:NUMERO_FACT:CODIGO_PRODUCTO:PRODUCTO:UNIDAD_MEDIDA:CANTI'
||'DAD_UN:PRECIO:SUBTOTAL:MOTIVO:'
,p_sort_column_1=>'FECHA_INGRESO'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_sum_columns_on_break=>'SUBTOTAL:CANTIDAD_UN'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(253522646642945532)
,p_plug_name=>'Resumen por motivo'
,p_parent_plug_id=>wwv_flow_imp.id(253522502145945531)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(207123407083778876)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  MOTIVO, GRUPO, CLIENTE,     FECHA_NC,    NUMERO_NC,   sum(SUBTOTAL) SUBTOTAL',
'FROM vt_VTAS_DEVOLUCIONES_HISTORICO',
'left JOIN F76ECXML@JDEDTADL ON (NUMERO_NC=XMDOC AND TIPO_NC=XMDCT AND XMDOC>0)',
'where :P311_CARGA =1 AND ',
'CODIGO_CANAL=NVL(:P311_CANAL,CODIGO_CANAL )  and CODIGO_GRUPO=NVL(:P311_GRUPO,CODIGO_GRUPO ) and',
'FECHA_INGRESO between :P311_FECHA_INI and :P311_FECHA_FIN',
'GROUP BY MOTIVO, GRUPO, CLIENTE,     FECHA_NC,    NUMERO_NC',
';'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P311_FECHA_INI,P311_FECHA_FIN,P311_CARGA'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select 1 from dual where :G_COMPANIA = ''00001'''
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Resumen por motivo'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(253522744740945533)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>350
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>253522744740945533
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253523050578945536)
,p_db_column_name=>'CLIENTE'
,p_display_order=>30
,p_column_identifier=>'A'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253524318012945549)
,p_db_column_name=>'SUBTOTAL'
,p_display_order=>160
,p_column_identifier=>'B'
,p_column_label=>'Subtotal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253524497438945550)
,p_db_column_name=>'MOTIVO'
,p_display_order=>170
,p_column_identifier=>'C'
,p_column_label=>'Motivo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253594502202338703)
,p_db_column_name=>'FECHA_NC'
,p_display_order=>200
,p_column_identifier=>'D'
,p_column_label=>'Fecha Nc'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253594610715338704)
,p_db_column_name=>'NUMERO_NC'
,p_display_order=>210
,p_column_identifier=>'E'
,p_column_label=>'Numero Nc'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253595035661338708)
,p_db_column_name=>'GRUPO'
,p_display_order=>250
,p_column_identifier=>'F'
,p_column_label=>'Grupo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(253612378971368550)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2536124'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'MOTIVO:GRUPO:CLIENTE:FECHA_NC:NUMERO_NC:SUBTOTAL:'
,p_break_on=>'MOTIVO:0:0:0:0:0'
,p_break_enabled_on=>'MOTIVO:0:0:0:0:0'
,p_sum_columns_on_break=>'SUBTOTAL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(282825771206551205)
,p_plug_name=>'Nota credito financiera'
,p_parent_plug_id=>wwv_flow_imp.id(253522502145945531)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(207123407083778876)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT nc.canal, nc.GRUPO, nc.CLIENTE, nc.NUMERO_NC, nc.TIPO_NC,  nc.SUBTOTAL, nc.FECHA, nc.NUMERO_FACT, nc.TIPO, nc.OBSERVACION,',
'case when numeroarchivo is not null then ''<span class="fa fa-list-alt" aria-hidden="true" title="descargar"></span>'' else ''-''  end ICONO, ',
'DECODE(numeroarchivo, NULL, '''',''http://apps.zaimella.com/QCPs/fileApexDownloadWS/''||numeroarchivo) VER_NC',
' , dbms_lob.getlength(AR.RIDE) BLOBCONTENT,  ',
'     ar.ID NUMEROARCHIVO , ar.NUMERO_COMPROBANTE||''.pdf'' FILENAME, ''application/pdf'' MIMETYPE',
'     ,f.XMCTC1 || ''-'' || f.XMCTC2 || ''-'' || f.XMAA10 NUMERO_COMPROBANTE',
'FROM VT_VTAS_NOTACREDITO_FINANCIERA nc',
'left JOIN F76ECXML@JDEDTADL f ON (nc.NUMERO_NC=f.XMDOC AND nc.TIPO_NC=f.XMDCT AND f.XMDOC>0)',
'left join t_finz_documento_electronico f on (nc.NUMERO_NC=f.NUMERODOCUMENTO AND nc.TIPO_NC=f.TIPODOCUMENTO)',
'left join FILES.T_APEX_ARCHIVOS a on (a.TABLA=''T_FINZ_DOCUMENTO_ELECTRONICO'' AND a.TIPO=''ARCH_PDF'' and a.ID_TABLA=f.id)',
'left join dp.log_trx_electronica ar on ( trim(NUMERO_COMPROBANTE)=trim(f.XMCTC1 || ''-'' || f.XMCTC2 || ''-'' || f.XMAA10))',
'where :P311_CARGA =1 AND CODIGO_CANAL=NVL(:P311_CANAL,CODIGO_CANAL )  and CODIGO_GRUPO=NVL(:P311_GRUPO,CODIGO_GRUPO ) ',
'AND (:G_ROL = 1 OR (:G_ROL = 2 AND EJECUTIVO = :G_IDENTIFICACION))',
'and nc.FECHA between :P311_FECHA_INI and :P311_FECHA_FIN;;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select 1 from dual where :G_COMPANIA = ''00001'''
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Nota credito financiera'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(282825898839551206)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>282825898839551206
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(282825993910551207)
,p_db_column_name=>'GRUPO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Grupo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(282826026857551208)
,p_db_column_name=>'CLIENTE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(282826131841551209)
,p_db_column_name=>'NUMERO_NC'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Numero Nc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(282826289919551210)
,p_db_column_name=>'TIPO_NC'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Tipo Nc'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(282826321937551211)
,p_db_column_name=>'SUBTOTAL'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Subtotal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(282826450340551212)
,p_db_column_name=>'FECHA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(282826504218551213)
,p_db_column_name=>'NUMERO_FACT'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Numero Fact'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(282826643295551214)
,p_db_column_name=>'TIPO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(282826768234551215)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(282826876160551216)
,p_db_column_name=>'VER_NC'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Ver Nc'
,p_column_link=>'#VER_NC#'
,p_column_linktext=>'<span class="fa fa-list-alt" aria-hidden="true" title="descargar"></span>'
,p_column_link_attr=>'target="_blank" rel="noopener"'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(282827079939551218)
,p_db_column_name=>'CANAL'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Canal'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(353184507063009120)
,p_db_column_name=>'BLOBCONTENT'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Nc'
,p_column_type=>'NUMBER'
,p_format_mask=>'DOWNLOAD:VT_LOG_TRX_ELECTRONICA:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment:<span class="fa fa-list-alt" aria-hidden="true" title="descargar"></span>:DP'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(353184645501009121)
,p_db_column_name=>'FILENAME'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(353184741613009122)
,p_db_column_name=>'MIMETYPE'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Mimetype'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(353184933513009124)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>160
,p_column_identifier=>'Q'
,p_column_label=>'Numeroarchivo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(353185019571009125)
,p_db_column_name=>'NUMERO_COMPROBANTE'
,p_display_order=>170
,p_column_identifier=>'R'
,p_column_label=>'Numero Comprobante'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(353185295275009127)
,p_db_column_name=>'ICONO'
,p_display_order=>180
,p_column_identifier=>'T'
,p_column_label=>'Icono'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(282852027092027838)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2828521'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CANAL:GRUPO:CLIENTE:FECHA:TIPO_NC:NUMERO_NC:VER_NC:BLOBCONTENT:SUBTOTAL:NUMERO_FACT:TIPO:OBSERVACION'
,p_sort_column_1=>'FECHA'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_sum_columns_on_break=>'SUBTOTAL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(108366634689294480211)
,p_plug_name=>'Devoluciones'
,p_region_name=>'DEVOLUCIONES_PE'
,p_parent_plug_id=>wwv_flow_imp.id(253522502145945531)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(207123407083778876)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'select null iddevolucion,',
'       cli.canal,',
'       cli.codigogrupo || ''-'' || cli.grupo grupo,',
'       cli.codigocliente codigo_cliente,',
'       cli.codigocliente || ''-'' || cli.nombres cliente,',
'       n."Comments" observacion,',
'       cast(null as varchar2(100)) usuario,',
'       n."CreateDate" fecha_ingreso,',
'       n."DocDate" fecha_aprobacion,',
'       n."TaxDate" fecha_nc,',
'       case when l."BaseDocNum" = n."DocNum" then null else l."BaseDocNum" end ordennumero,',
'       to_char(l."BaseType") ordentipo,',
'       n."DocStatus" estado_jde,',
'       to_char(n."ObjType") tipo_nc,',
'       n."U_BPP_MDSD" || '' - '' || n."U_BPP_MDCD" numero_nc,',
'       coalesce(l."BaseAtCard", l."BaseRef", n."NumAtCard") numero_fact,',
'       l."ItemCode" codigo_producto,',
'       l."Dscription" producto,',
'       nvl(l."unitMsr", l."UomCode") unidad_medida,',
'       l."Quantity" cantidad_un,',
'       l."Price" precio,',
'       l."LineTotal" subtotal,',
'       nvl(n."Comments", ''Nota de credito SAP'') motivo,',
'       case when n."CANCELED" = ''Y'' then 0 else 1 end estado,',
'       case',
'           when n."CANCELED" = ''Y'' then ''Anulado''',
'           when n."DocStatus" = ''O'' then ''Abierto''',
'           when n."DocStatus" = ''C'' then ''Cerrado''',
'       end estado_descripcion,',
'       '''' ver_ruta,',
'       case when n."NumAtCard" is not null then ''<span class="fa fa-file-pdf-o" aria-hidden="true"></span>'' else '''' end ver_nc,',
'       case when n."NumAtCard" is not null then ''http://192.168.5.109/SapPDF/20519078504-'' || replace(n."NumAtCard", '' '', '''') || ''.pdf'' end url_nc,',
'       cli.ejecutivo,',
'       cli.codigocanal codigo_canal,',
'       cli.codigogrupo codigo_grupo',
'  from ORIN@HANA_PE n',
'  join RIN1@HANA_PE l',
'    on l."DocEntry" = n."DocEntry"',
'  join data.vt_gzm_cliente cli',
'    on cli.compania = ''00003''',
'   and (',
'        n."CardCode" = ''C'' || cli.codigocliente',
'        or n."CardCode" = ''C'' || cli.ruc',
'        or n."CardCode" = cli.codigocliente',
'       )',
' where :P311_CARGA = 1',
'   and cli.codigocanal = nvl(:P311_CANAL, cli.codigocanal)',
'   and cli.codigogrupo = nvl(:P311_GRUPO, cli.codigogrupo)',
'   and (:G_ROL = 1 or (:G_ROL = 2 and cli.ejecutivo = :G_IDENTIFICACION))',
'   and trunc(n."DocDate") between trunc(to_date(:P311_FECHA_INI, ''DD/MM/YYYY'')) and trunc(to_date(:P311_FECHA_FIN, ''DD/MM/YYYY''))',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P311_FECHA_INI,P311_FECHA_FIN,P311_CARGA'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select 1 from dual where :G_COMPANIA = ''00003'''
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Devoluciones'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(43270543845454471490)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>350
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>251023168992896449
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205002)
,p_db_column_name=>'IDDEVOLUCION'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id devolucion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205003)
,p_db_column_name=>'CODIGO_CLIENTE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Codigo Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205004)
,p_db_column_name=>'CLIENTE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205005)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205006)
,p_db_column_name=>'USUARIO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205007)
,p_db_column_name=>'FECHA_INGRESO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fecha Ingreso'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205008)
,p_db_column_name=>'FECHA_APROBACION'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fecha Aprobacion'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205009)
,p_db_column_name=>'ORDENNUMERO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Ordennumero'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205010)
,p_db_column_name=>'ORDENTIPO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Ordentipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205011)
,p_db_column_name=>'ESTADO_JDE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Estado ERP'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205012)
,p_db_column_name=>'CODIGO_PRODUCTO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Codigo Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205013)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205014)
,p_db_column_name=>'UNIDAD_MEDIDA'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Unidad Medida'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205015)
,p_db_column_name=>'CANTIDAD_UN'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Cantidad Un'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205016)
,p_db_column_name=>'PRECIO'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205017)
,p_db_column_name=>'SUBTOTAL'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Subtotal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205018)
,p_db_column_name=>'MOTIVO'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Motivo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205019)
,p_db_column_name=>'ESTADO'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Estado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205020)
,p_db_column_name=>'ESTADO_DESCRIPCION'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205021)
,p_db_column_name=>'FECHA_NC'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Fecha Nc'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205022)
,p_db_column_name=>'NUMERO_NC'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Numero Nc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205023)
,p_db_column_name=>'VER_RUTA'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Ver Ruta'
,p_column_link=>'f?p=100:104:&SESSION.::&DEBUG.::G_OBJETO,G_OBJETO_ID,G_TODO:DEVOLUCION,#IDDEVOLUCION#,true'
,p_column_linktext=>'#VER_RUTA#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205024)
,p_db_column_name=>'VER_NC'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Ver Nc'
,p_column_link=>'#URL_NC#'
,p_column_linktext=>'#VER_NC#'
,p_column_link_attr=>'target="_blank" rel="noopener"'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(910311001003)
,p_db_column_name=>'URL_NC'
,p_display_order=>255
,p_column_identifier=>'AD'
,p_column_label=>'Url Nc'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205025)
,p_db_column_name=>'CANAL'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Canal'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205026)
,p_db_column_name=>'GRUPO'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Grupo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205027)
,p_db_column_name=>'NUMERO_FACT'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Numero Fact'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205028)
,p_db_column_name=>'TIPO_NC'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Tipo Nc'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(43270546721390478906)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2535442'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'IDDEVOLUCION:ESTADO_DESCRIPCION:VER_RUTA:CANAL:GRUPO:CLIENTE:CODIGO_CLIENTE:OBSERVACION:USUARIO:FECHA_INGRESO:FECHA_APROBACION:ORDENNUMERO:ORDENTIPO:FECHA_NC:TIPO_NC:NUMERO_NC:VER_NC:ESTADO_JDE:NUMERO_FACT:CODIGO_PRODUCTO:PRODUCTO:UNIDAD_MEDIDA:CANTI'
||'DAD_UN:PRECIO:SUBTOTAL:MOTIVO:'
,p_sort_column_1=>'FECHA_INGRESO'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_sum_columns_on_break=>'SUBTOTAL:CANTIDAD_UN'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(108366634689294480212)
,p_plug_name=>'Nota credito financiera'
,p_region_name=>'NOTA_CREDITO_FINANCIERA_PE'
,p_parent_plug_id=>wwv_flow_imp.id(253522502145945531)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(207123407083778876)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'select cli.canal,',
'       cli.codigogrupo || ''-'' || cli.grupo grupo,',
'       cli.codigocliente || ''-'' || cli.nombres cliente,',
'       n."U_BPP_MDSD" || '' - '' || n."U_BPP_MDCD" numero_nc,',
'       to_char(n."ObjType") tipo_nc,',
'       l."LineTotal" subtotal,',
'       n."DocDate" fecha,',
'       coalesce(l."BaseAtCard", l."BaseRef", n."NumAtCard") numero_fact,',
'       case',
'           when l."BaseType" = -1 then ''Manual''',
'           when l."BaseType" = 13 then ''Factura''',
'           else to_char(l."BaseType")',
'       end tipo,',
'       n."Comments" observacion,',
'       case when n."NumAtCard" is not null then ''<span class="fa fa-file-pdf-o" aria-hidden="true"></span>'' else '''' end icono,',
'       case when n."NumAtCard" is not null then ''<span class="fa fa-file-pdf-o" aria-hidden="true"></span>'' else '''' end ver_nc,',
'       case when n."NumAtCard" is not null then ''http://192.168.5.109/SapPDF/20519078504-'' || replace(n."NumAtCard", '' '', '''') || ''.pdf'' end url_nc,',
'       cast(null as number) blobcontent,',
'       cast(null as number) numeroarchivo,',
'       ''20519078504-'' || replace(n."NumAtCard", '' '', '''') || ''.pdf'' filename,',
'       ''application/pdf'' mimetype,',
'       n."NumAtCard" numero_comprobante,',
'       cli.ejecutivo,',
'       cli.codigocanal codigo_canal,',
'       cli.codigogrupo codigo_grupo',
'  from ORIN@HANA_PE n',
'  join RIN1@HANA_PE l',
'    on l."DocEntry" = n."DocEntry"',
'  join data.vt_gzm_cliente cli',
'    on cli.compania = ''00003''',
'   and (',
'        n."CardCode" = ''C'' || cli.codigocliente',
'        or n."CardCode" = ''C'' || cli.ruc',
'        or n."CardCode" = cli.codigocliente',
'       )',
' where :P311_CARGA = 1',
'   and cli.codigocanal = nvl(:P311_CANAL, cli.codigocanal)',
'   and cli.codigogrupo = nvl(:P311_GRUPO, cli.codigogrupo)',
'   and (:G_ROL = 1 or (:G_ROL = 2 and cli.ejecutivo = :G_IDENTIFICACION))',
'   and trunc(n."DocDate") between trunc(to_date(:P311_FECHA_INI, ''DD/MM/YYYY'')) and trunc(to_date(:P311_FECHA_FIN, ''DD/MM/YYYY''))',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select 1 from dual where :G_COMPANIA = ''00003'''
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Nota credito financiera'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(43270543845454471491)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>282825898839551206
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205029)
,p_db_column_name=>'GRUPO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Grupo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205030)
,p_db_column_name=>'CLIENTE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205031)
,p_db_column_name=>'NUMERO_NC'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Numero Nc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205032)
,p_db_column_name=>'TIPO_NC'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Tipo Nc'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205033)
,p_db_column_name=>'SUBTOTAL'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Subtotal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205034)
,p_db_column_name=>'FECHA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205035)
,p_db_column_name=>'NUMERO_FACT'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Numero Fact'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205036)
,p_db_column_name=>'TIPO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205037)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205038)
,p_db_column_name=>'VER_NC'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Ver Nc'
,p_column_link=>'#URL_NC#'
,p_column_linktext=>'#VER_NC#'
,p_column_link_attr=>'target="_blank" rel="noopener"'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(910311001004)
,p_db_column_name=>'URL_NC'
,p_display_order=>105
,p_column_identifier=>'AD'
,p_column_label=>'Url Nc'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205039)
,p_db_column_name=>'CANAL'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Canal'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205040)
,p_db_column_name=>'BLOBCONTENT'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Nc'
,p_column_type=>'NUMBER'
,p_format_mask=>'DOWNLOAD:VT_LOG_TRX_ELECTRONICA:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment:<span class="fa fa-list-alt" aria-hidden="true" title="descargar"></span>:DP'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205041)
,p_db_column_name=>'FILENAME'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205042)
,p_db_column_name=>'MIMETYPE'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Mimetype'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205043)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>160
,p_column_identifier=>'Q'
,p_column_label=>'Numeroarchivo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205044)
,p_db_column_name=>'NUMERO_COMPROBANTE'
,p_display_order=>170
,p_column_identifier=>'R'
,p_column_label=>'Numero Comprobante'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205045)
,p_db_column_name=>'ICONO'
,p_display_order=>180
,p_column_identifier=>'T'
,p_column_label=>'Icono'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(43270546721390478907)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2828521'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CANAL:GRUPO:CLIENTE:FECHA:TIPO_NC:NUMERO_NC:VER_NC:BLOBCONTENT:SUBTOTAL:NUMERO_FACT:TIPO:OBSERVACION'
,p_sort_column_1=>'FECHA'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_sum_columns_on_break=>'SUBTOTAL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(108366634689294480213)
,p_plug_name=>'Resumen por motivo'
,p_region_name=>'RESUMEN_MOTIVO_PE'
,p_parent_plug_id=>wwv_flow_imp.id(253522502145945531)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(207123407083778876)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'select nvl(n."Comments", ''Nota de credito SAP'') motivo,',
'       cli.codigogrupo || ''-'' || cli.grupo grupo,',
'       cli.codigocliente || ''-'' || cli.nombres cliente,',
'       n."TaxDate" fecha_nc,',
'       n."U_BPP_MDSD" || '' - '' || n."U_BPP_MDCD" numero_nc,',
'       sum(l."LineTotal") subtotal',
'  from ORIN@HANA_PE n',
'  join RIN1@HANA_PE l',
'    on l."DocEntry" = n."DocEntry"',
'  join data.vt_gzm_cliente cli',
'    on cli.compania = ''00003''',
'   and (',
'        n."CardCode" = ''C'' || cli.codigocliente',
'        or n."CardCode" = ''C'' || cli.ruc',
'        or n."CardCode" = cli.codigocliente',
'       )',
' where :P311_CARGA = 1',
'   and cli.codigocanal = nvl(:P311_CANAL, cli.codigocanal)',
'   and cli.codigogrupo = nvl(:P311_GRUPO, cli.codigogrupo)',
'   and trunc(n."DocDate") between trunc(to_date(:P311_FECHA_INI, ''DD/MM/YYYY'')) and trunc(to_date(:P311_FECHA_FIN, ''DD/MM/YYYY''))',
' group by nvl(n."Comments", ''Nota de credito SAP''),',
'          cli.codigogrupo || ''-'' || cli.grupo,',
'          cli.codigocliente || ''-'' || cli.nombres,',
'          n."TaxDate",',
'          n."U_BPP_MDSD",',
'          n."U_BPP_MDCD"',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P311_FECHA_INI,P311_FECHA_FIN,P311_CARGA'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>'select 1 from dual where :G_COMPANIA = ''00003'''
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Resumen por motivo'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(43270543845454471492)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>350
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>253522744740945533
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205046)
,p_db_column_name=>'CLIENTE'
,p_display_order=>30
,p_column_identifier=>'A'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205047)
,p_db_column_name=>'SUBTOTAL'
,p_display_order=>160
,p_column_identifier=>'B'
,p_column_label=>'Subtotal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205048)
,p_db_column_name=>'MOTIVO'
,p_display_order=>170
,p_column_identifier=>'C'
,p_column_label=>'Motivo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205049)
,p_db_column_name=>'FECHA_NC'
,p_display_order=>200
,p_column_identifier=>'D'
,p_column_label=>'Fecha Nc'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205050)
,p_db_column_name=>'NUMERO_NC'
,p_display_order=>210
,p_column_identifier=>'E'
,p_column_label=>'Numero Nc'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083205051)
,p_db_column_name=>'GRUPO'
,p_display_order=>250
,p_column_identifier=>'F'
,p_column_label=>'Grupo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(43270546721390478908)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2536124'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'MOTIVO:GRUPO:CLIENTE:FECHA_NC:NUMERO_NC:SUBTOTAL:'
,p_break_on=>'MOTIVO:0:0:0:0:0'
,p_break_enabled_on=>'MOTIVO:0:0:0:0:0'
,p_sum_columns_on_break=>'SUBTOTAL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(580778877406786818)
,p_plug_name=>'Filtros'
,p_parent_plug_id=>wwv_flow_imp.id(583079264145895715)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(207623277923798915)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(251432225642772686)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(488675947243909480)
,p_button_name=>'Buscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176753300778920)
,p_button_image_alt=>'Buscar'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(251433278387772697)
,p_name=>'P311_FECHA_INI'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(580778877406786818)
,p_item_default=>'trunc(SYSDATE, ''MM'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Inicio'
,p_placeholder=>'Escoja la fecha desde'
,p_pre_element_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
''))
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(251433644928772701)
,p_name=>'P311_FECHA_FIN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(580778877406786818)
,p_item_default=>'SYSDATE'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha fin'
,p_placeholder=>'Escoja la fecha hasta'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(253522184755945527)
,p_name=>'P311_CANAL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(580778877406786818)
,p_prompt=>'Canal'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct canal, codigocanal from vt_gzm_cliente',
'where nvl(TRIM(codigocanal), '' '') not in ( '' '', ''.'') and  ESTADO = 1 AND CODIGOGRUPO = CODIGOCLIENTE AND (:G_ROL = 1 OR (:G_ROL = 2 AND EJECUTIVO = :G_IDENTIFICACION))',
'AND COMPANIA = :G_COMPANIA;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Todos'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(253522250063945528)
,p_name=>'P311_GRUPO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(580778877406786818)
,p_prompt=>'Grupo'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  CODIGOGRUPO || '' - '' || GRUPO D, CODIGOGRUPO R FROM VT_GZM_CLIENTE',
'WHERE ESTADO = 1 AND CODIGOGRUPO = CODIGOCLIENTE AND (:G_ROL = 1 OR (:G_ROL = 2 AND EJECUTIVO = :G_IDENTIFICACION))',
' AND CODIGOCANAL = NVL(:P311_CANAL, CODIGOCANAL) AND COMPANIA = :G_COMPANIA; '))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Todos'
,p_lov_cascade_parent_items=>'P311_CANAL'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(253595160663338709)
,p_name=>'P311_CARGA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(580778877406786818)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(253595384650338711)
,p_name=>'Page load'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(253595446809338712)
,p_event_id=>wwv_flow_imp.id(253595384650338711)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P311_CARGA :=1;'
,p_attribute_03=>'P311_CARGA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(253595513988338713)
,p_event_id=>wwv_flow_imp.id(253595384650338711)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(251023022221896448)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(253595681288338714)
,p_event_id=>wwv_flow_imp.id(253595384650338711)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(253522646642945532)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(282826991019551217)
,p_event_id=>wwv_flow_imp.id(253595384650338711)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(282825771206551205)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(36817228757787830697)
,p_event_id=>wwv_flow_imp.id(253595384650338711)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(108366634689294480211)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(36817228757787830698)
,p_event_id=>wwv_flow_imp.id(253595384650338711)
,p_event_result=>'TRUE'
,p_action_sequence=>51
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(108366634689294480212)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(36817228757787830699)
,p_event_id=>wwv_flow_imp.id(253595384650338711)
,p_event_result=>'TRUE'
,p_action_sequence=>52
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(108366634689294480213)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(253595279321338710)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar datos'
,p_process_sql_clob=>':P311_CARGA :=1;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>253595279321338710
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
