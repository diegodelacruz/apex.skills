prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>114
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 114 - Ventas
--
-- Application Export:
--   Application:     114
--   Name:            Ventas
--   Date and Time:   14:18 Thursday July 16, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 303
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_00303
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>303);
end;
/
prompt --application/pages/page_00303
begin
wwv_flow_imp_page.create_page(
 p_id=>303
,p_name=>'Reporte Pedidos Resumen'
,p_alias=>'REPORTE-PEDIDOS'
,p_step_title=>'Reporte Pedidos'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#rgnResumen_data_panel{',
'   height: 400px;',
'    OVERFLOW-Y: scroll;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(146929285108891302)
,p_plug_name=>'Reporte de Pedidos'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_imp.id(207624090311798915)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(207077902574778828)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(207177697621778923)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(146929306465891303)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(207622883613798915)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(146929445790891304)
,p_plug_name=>'Formulario'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(207623277923798915)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(303004001)
,p_plug_name=>'Reportes'
,p_parent_plug_id=>wwv_flow_imp.id(146929445790891304)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(207622408396798914)
,p_plug_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>12
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'G_COMPANIA'
,p_plug_display_when_cond2=>'00001'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(148664860584016417)
,p_plug_name=>'Resumen grupo'
,p_parent_plug_id=>wwv_flow_imp.id(303004001)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(207622408396798914)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>6
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'with cliente as (',
'            select  CODIGOGRUPO, codigo CODIGOCLIENTE,  GRUPO,  CANAL',
'            from vt_jde_cliente where CODIGOORIGEN=:P303_ORIGEN  and (:P303_CANAL is null or CODIGOCANAL = :P303_CANAL)',
'            AND codigo=NVL(:P303_GRUPO,CODIGOGRUPO )',
'             AND (:G_ROL = 1 OR (:G_ROL = 2 AND EJECUTIVO = :G_IDENTIFICACION)) ),',
'    ventaFactura as (',
'           select  CODIGOGRUPO, GRUPO, CANAL, sum(SDUORG/10000) CANTIDAD_BU_CA,   sum(SDAEXP/100) SUBTOTAL',
'            FROM F42119@JDEDTADL',
'            INNER JOIN cliente C ON (SDPA8=CODIGOGRUPO)',
'            WHERE SDTRDJ BETWEEN TO_CHAR( TO_DATE(:P303_FECHAINICIO, ''DD/MM/YYYY''), ''YYYYDDD'')-1900000  AND TO_CHAR(TO_DATE(:P303_FECHAFIN, ''DD/MM/YYYY''), ''YYYYDDD'')-1900000',
'            AND SDDCTO IN (''VN'', ''VE'')',
'            AND SDITM NOT IN (962015)--ICE',
'            group by CODIGOGRUPO,  GRUPO, CANAL',
'        ),',
'    venta as (select  CODIGOGRUPO, GRUPO, CANAL, sum(SDUORG/10000) CANTIDAD_BU_CA,   sum(SDAEXP/100) SUBTOTAL',
'            FROM F4211@JDEDTADL',
'            INNER JOIN cliente C ON (SDPA8=CODIGOGRUPO)',
'            WHERE SDTRDJ BETWEEN TO_CHAR( TO_DATE(:P303_FECHAINICIO, ''DD/MM/YYYY''), ''YYYYDDD'')-1900000  AND TO_CHAR(TO_DATE(:P303_FECHAFIN, ''DD/MM/YYYY''), ''YYYYDDD'')-1900000',
'            AND SDDCTO IN (''VN'', ''VE'')  AND SDLTTR NOT IN (980, 984) AND SDITM NOT IN (962015)--ICE',
'            group by CODIGOGRUPO, GRUPO, CANAL)',
'    select   CODIGO_GRUPO, GRUPO, CANAL,  SUM(CANTIDAD_BU_CA) CANTIDAD_BU_CA, SUM(SUBTOTAL) SUBTOTAL',
'     from (',
'        SELECT CODIGOGRUPO CODIGO_GRUPO, GRUPO, CANAL,   CANTIDAD_BU_CA,  SUBTOTAL',
'        FROM ventaFactura',
'        union all',
'        select  CODIGOGRUPO CODIGO_GRUPO, GRUPO, CANAL,   CANTIDAD_BU_CA,  SUBTOTAL',
'        FROM venta )',
'        group by  CODIGO_GRUPO, GRUPO, CANAL',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Resumen grupo'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(148665610089016425)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>350
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'NETBY3'
,p_internal_uid=>148665610089016425
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(257824652338100604)
,p_db_column_name=>'CODIGO_GRUPO'
,p_display_order=>10
,p_column_identifier=>'AI'
,p_column_label=>'-'
,p_column_link=>'javascript:$s(''P303_GRUPOELEGIDO'',''''); $s(''P303_GRUPOELEGIDO'',''#CODIGO_GRUPO#'');'
,p_column_linktext=>'<span class="fa fa-check" aria-hidden="true"></span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(247882946229942248)
,p_db_column_name=>'CANAL'
,p_display_order=>20
,p_column_identifier=>'AE'
,p_column_label=>'Canal'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(247882804426942247)
,p_db_column_name=>'GRUPO'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Grupo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(247882650235942245)
,p_db_column_name=>'CANTIDAD_BU_CA'
,p_display_order=>40
,p_column_identifier=>'AB'
,p_column_label=>'Cantidad Bu Ca'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(247882773142942246)
,p_db_column_name=>'SUBTOTAL'
,p_display_order=>50
,p_column_identifier=>'AC'
,p_column_label=>'Subtotal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(149077125223931702)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1490772'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODIGO_GRUPO:CANAL:GRUPO:CANTIDAD_BU_CA:SUBTOTAL:'
,p_sum_columns_on_break=>'SUBTOTAL:CANTIDAD_BU_CA'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(248675758514699425)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'SIN INDUSTRIAL'
,p_report_seq=>10
,p_report_alias=>'2486758'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODIGO_GRUPO:CANAL:GRUPO:CANTIDAD_BU_CA:SUBTOTAL:'
,p_sum_columns_on_break=>'SUBTOTAL:CANTIDAD_BU_CA'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(298879959870337856)
,p_report_id=>wwv_flow_imp.id(248675758514699425)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'CANAL'
,p_operator=>'!='
,p_expr=>'INDUSTRIAL'
,p_condition_sql=>'"CANAL" != #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# != ''INDUSTRIAL''  '
,p_enabled=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(149101184779457512)
,p_plug_name=>'Cliente y Linea de Negocio'
,p_region_name=>'rgnResumen'
,p_parent_plug_id=>wwv_flow_imp.id(303004001)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(207622408396798914)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>6
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'with cliente as (',
'            select   codigo CODIGOCLIENTE,  NOMBRES CLIENTE',
'            from vt_jde_cliente where  CODIGOORIGEN=:P303_ORIGEN  and (:P303_CANAL is null or CODIGOCANAL = :P303_CANAL) and (CODIGOGRUPO=:P303_GRUPOELEGIDO or :P303_TODOS=''Y'')),',
'    ventaFactura as (',
'           select  CODIGOCLIENTE CODIGO_CLIENTE, CLIENTE, sum(SDUORG/10000) CANTIDAD_BU_CA,   sum(SDAEXP/100) SUBTOTAL, LINEANEGOCIO LINEA_NEGOCIO',
'            FROM F42119@JDEDTADL',
'            INNER JOIN cliente C ON (SDAN8=CODIGOCLIENTE)',
'            INNER JOIN VT_JDE_PRODUCTOS P ON (CODIGOCORTO=SDITM)',
'            WHERE SDTRDJ BETWEEN TO_CHAR( TO_DATE(:P303_FECHAINICIO, ''DD/MM/YYYY''), ''YYYYDDD'')-1900000  AND TO_CHAR(TO_DATE(:P303_FECHAFIN, ''DD/MM/YYYY''), ''YYYYDDD'')-1900000',
'            AND SDDCTO IN (''VN'', ''VE'') AND SDITM NOT IN (962015)--ICE',
'            group by CODIGOCLIENTE,  CLIENTE, LINEANEGOCIO',
'        ),',
'    venta as (select  CODIGOCLIENTE CODIGO_CLIENTE, CLIENTE, sum(SDUORG/10000) CANTIDAD_BU_CA,   sum(SDAEXP/100) SUBTOTAL, LINEANEGOCIO LINEA_NEGOCIO',
'            FROM F4211@JDEDTADL',
'            INNER JOIN cliente C ON (SDAN8=CODIGOCLIENTE)',
'            INNER JOIN VT_JDE_PRODUCTOS P ON (CODIGOCORTO=SDITM)',
'            WHERE SDTRDJ BETWEEN TO_CHAR( TO_DATE(:P303_FECHAINICIO, ''DD/MM/YYYY''), ''YYYYDDD'')-1900000  AND TO_CHAR(TO_DATE(:P303_FECHAFIN, ''DD/MM/YYYY''), ''YYYYDDD'')-1900000',
'            AND SDDCTO IN (''VN'', ''VE'')  AND SDLTTR NOT IN (980, 984) AND SDITM NOT IN (962015)--ICE',
'            group by CODIGOCLIENTE,  CLIENTE, LINEANEGOCIO)',
'    select   CODIGO_CLIENTE, CLIENTE, LINEA_NEGOCIO, SUM(CANTIDAD_BU_CA) CANTIDAD_BU_CA, SUM(SUBTOTAL) SUBTOTAL',
'     from (',
'        SELECT CODIGO_CLIENTE, CLIENTE, LINEA_NEGOCIO,   CANTIDAD_BU_CA,  SUBTOTAL',
'        FROM ventaFactura',
'        union all',
'        select  CODIGO_CLIENTE, CLIENTE, LINEA_NEGOCIO,   CANTIDAD_BU_CA,  SUBTOTAL',
'        FROM venta )',
'        group by  CODIGO_CLIENTE, CLIENTE, LINEA_NEGOCIO',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P303_GRUPOELEGIDO,P303_TODOS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Cliente y Linea de Negocio'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(149101252275457513)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>350
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'NETBY3'
,p_internal_uid=>149101252275457513
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(248657729043649708)
,p_db_column_name=>'CANTIDAD_BU_CA'
,p_display_order=>50
,p_column_identifier=>'H'
,p_column_label=>'Cantidad Bu Ca'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(248657964301649710)
,p_db_column_name=>'CODIGO_CLIENTE'
,p_display_order=>70
,p_column_identifier=>'J'
,p_column_label=>'Codigo Cliente'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(248658034736649711)
,p_db_column_name=>'CLIENTE'
,p_display_order=>80
,p_column_identifier=>'K'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(248658194601649712)
,p_db_column_name=>'LINEA_NEGOCIO'
,p_display_order=>90
,p_column_identifier=>'L'
,p_column_label=>'Linea Negocio'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(257824464438100602)
,p_db_column_name=>'SUBTOTAL'
,p_display_order=>100
,p_column_identifier=>'N'
,p_column_label=>'Subtotal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(149117102883545449)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'GROUP_BY'
,p_report_alias=>'1491172'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'CLIENTE:LINEA_NEGOCIO:CANTIDAD_BU_CA'
,p_sort_column_1=>'CODIGOCLIENTE'
,p_sort_direction_1=>'ASC NULLS LAST'
,p_sort_column_2=>'LINEANEGOCIO'
,p_sort_direction_2=>'ASC NULLS LAST'
,p_sort_column_3=>'TOT_CANTIDAD'
,p_sort_direction_3=>'ASC NULLS LAST'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'0:0:0:0:0'
,p_break_enabled_on=>'0:0:0:0:0'
,p_sum_columns_on_break=>'TOT_CANTIDAD:TOT_VALOR:SUBTOTAL'
);
wwv_flow_imp_page.create_worksheet_group_by(
 p_id=>wwv_flow_imp.id(253626270165448278)
,p_report_id=>wwv_flow_imp.id(149117102883545449)
,p_group_by_columns=>'CLIENTE'
,p_function_01=>'SUM'
,p_function_column_01=>'CANTIDAD_BU_CA'
,p_function_db_column_name_01=>'APXWS_GBFC_01'
,p_function_label_01=>'Cantidad'
,p_function_format_mask_01=>'999G999G999G999G990'
,p_function_sum_01=>'Y'
,p_function_02=>'SUM'
,p_function_column_02=>'SUBTOTAL'
,p_function_db_column_name_02=>'APXWS_GBFC_02'
,p_function_label_02=>'Total'
,p_function_format_mask_02=>'FML999G999G999G999G990D00'
,p_function_sum_02=>'Y'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(253623946938437186)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'Linea Negocio'
,p_report_seq=>10
,p_report_alias=>'2536240'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'CLIENTE:LINEA_NEGOCIO:CANTIDAD_BU_CA:SUBTOTAL:'
,p_sort_column_1=>'CODIGOCLIENTE'
,p_sort_direction_1=>'ASC NULLS LAST'
,p_sort_column_2=>'LINEANEGOCIO'
,p_sort_direction_2=>'ASC NULLS LAST'
,p_sort_column_3=>'TOT_CANTIDAD'
,p_sort_direction_3=>'ASC NULLS LAST'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'CLIENTE:0:0:0:0:0'
,p_break_enabled_on=>'0:0:0:0:0:CLIENTE'
,p_sum_columns_on_break=>'TOT_CANTIDAD:TOT_VALOR:SUBTOTAL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(149221581516582336)
,p_plug_name=>'Detalle'
,p_parent_plug_id=>wwv_flow_imp.id(303004001)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(207622408396798914)
,p_plug_display_sequence=>50
,p_plug_grid_column_span=>12
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'with cliente as (',
'            select   C.grupo, C.CODIGO , C.NOMBRES',
'            from vt_jde_cliente c where  CODIGOORIGEN=:P303_ORIGEN  and (:P303_CANAL is null or CODIGOCANAL = :P303_CANAL) and (CODIGOGRUPO=:P303_GRUPOELEGIDO or :P303_TODOS=''Y'')),',
'    ventaFactura as (',
'           select  C.grupo, C.CODIGO CODIGO_CLIENTE,  C.CODIGO||''-''||C.NOMBRES CLIENTE, SDTRDJ,SDITM,SDAN8,',
'           P.LINEANEGOCIO LINEA_NEGOCIO , P.MARCA, P.SUBMARCA SUB_MARCA',
'                  ,P.CODIGOPRODUCTO  CODIGO_PRODUCTO , P.NOMBREPRODUCTO producto , P.codigobarra codigo_barra',
'           ,SDVR01 ORDEN_COMPRA, SDDOCO ORDEN_JDE, TO_DATE(SDTRDJ + 1900000,''yyyyddd'') FECHA_JDE, TO_DATE(sdivd + 1900000,''yyyyddd'') FECHA_FACTURA ,',
'         SDDOC NUMERO_FACTURA,sdUOM UNIDAD_MEDIDA,(SDUORG/10000) CANTIDAD_BU_CA, (SDPQOR/10000) CANTIDAD_UN, (SDUPRC)/10000 PRECIO,(SDAEXP/100) SUBTOTAL',
'                    FROM F42119@JDEDTADL',
'            INNER JOIN cliente C ON (SDAN8=c.CODIGO)',
'            INNER JOIN VT_JDE_PRODUCTOS P ON (CODIGOCORTO=SDITM)',
'           WHERE SDTRDJ BETWEEN TO_CHAR( TO_DATE(:P303_FECHAINICIO, ''DD/MM/YYYY''), ''YYYYDDD'')-1900000  AND TO_CHAR(TO_DATE(:P303_FECHAFIN, ''DD/MM/YYYY''), ''YYYYDDD'')-1900000',
'            AND SDDCTO IN (''VN'', ''VE'') AND SDITM NOT IN (962015)--ICE',
'        ),',
'    venta as ( select C.grupo, C.CODIGO CODIGO_CLIENTE,  C.CODIGO||''-''||C.NOMBRES CLIENTE, SDTRDJ,SDITM,SDAN8,',
'                   P.LINEANEGOCIO LINEA_NEGOCIO , P.MARCA, P.SUBMARCA SUB_MARCA',
'                          ,P.CODIGOPRODUCTO  CODIGO_PRODUCTO , P.NOMBREPRODUCTO producto , P.codigobarra codigo_barra',
'                   ,SDVR01 ORDEN_COMPRA, SDDOCO ORDEN_JDE, TO_DATE(SDTRDJ + 1900000,''yyyyddd'') FECHA_JDE,',
'                   case when sdivd>0 then  TO_DATE(sdivd + 1900000,''yyyyddd'') else null end FECHA_FACTURA ,',
'                 SDDOC NUMERO_FACTURA,sdUOM UNIDAD_MEDIDA,(SDUORG/10000) CANTIDAD_BU_CA, (SDPQOR/10000) CANTIDAD_UN, (SDUPRC)/10000 PRECIO,(SDAEXP/100) SUBTOTAL',
'            FROM F4211@JDEDTADL',
'            INNER JOIN cliente C ON (SDAN8=CODIGO)',
'            INNER JOIN VT_JDE_PRODUCTOS P ON (CODIGOCORTO=SDITM)',
'            WHERE SDTRDJ BETWEEN TO_CHAR( TO_DATE(:P303_FECHAINICIO, ''DD/MM/YYYY''), ''YYYYDDD'')-1900000  AND TO_CHAR(TO_DATE(:P303_FECHAFIN, ''DD/MM/YYYY''), ''YYYYDDD'')-1900000',
'            AND SDDCTO IN (''VN'', ''VE'')  AND SDLTTR NOT IN (980, 984) AND SDITM NOT IN (962015)--ICE',
'            )',
'    select  v.*, B.ADPFN1 ID_INVERSION ,A.ADFVTR/10000 DESCUENTO',
'     from (',
'        SELECT  grupo,  CODIGO_CLIENTE,  CLIENTE,LINEA_NEGOCIO ,MARCA, SUB_MARCA , SDTRDJ,SDITM,SDAN8',
'                          , CODIGO_PRODUCTO , producto , codigo_barra',
'                   ,ORDEN_COMPRA, ORDEN_JDE,FECHA_JDE, FECHA_FACTURA ,NUMERO_FACTURA, UNIDAD_MEDIDA,CANTIDAD_BU_CA,  CANTIDAD_UN, PRECIO, SUBTOTAL',
'        FROM ventaFactura',
'      union all',
'        select  grupo,  CODIGO_CLIENTE,  CLIENTE,LINEA_NEGOCIO ,MARCA, SUB_MARCA , SDTRDJ,SDITM,SDAN8',
'                          , CODIGO_PRODUCTO , producto , codigo_barra',
'                   ,ORDEN_COMPRA, ORDEN_JDE,FECHA_JDE, FECHA_FACTURA ,NUMERO_FACTURA, UNIDAD_MEDIDA,CANTIDAD_BU_CA,  CANTIDAD_UN, PRECIO, SUBTOTAL',
'        FROM venta ) v',
'         LEFT join F4072@JDEDTADL  A  on (SDITM = a.ADITM or a.ADITM=0) and SDAN8 = a.ADAN8 and ( A.ADMNQ <= 100000000.000000 AND SDTRDJ BETWEEN A.ADEFTJ AND A.ADEXDJ AND A.ADBKTPID = 0.000000 )',
'        LEFT join  (SELECT DISTINCT ADAST, ADITM, ADAN8, ADEXDJ, ADUPMJ, ADPFN1',
'        FROM F554072A@JDEDTADL)   B on  a.ADAST = b.ADAST and a.ADITM = b.ADITM and a.ADAN8 = b.ADAN8 and a.ADEXDJ = b.ADEXDJ and a.ADUPMJ = b.ADUPMJ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P303_GRUPOELEGIDO,P303_TODOS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Detalle'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(149231908708688908)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>350
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'NETBY3'
,p_internal_uid=>149231908708688908
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253596202344338720)
,p_db_column_name=>'ID_INVERSION'
,p_display_order=>290
,p_column_identifier=>'AL'
,p_column_label=>'Id Inversion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(257828415002100642)
,p_db_column_name=>'GRUPO'
,p_display_order=>300
,p_column_identifier=>'AM'
,p_column_label=>'Grupo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(257828592215100643)
,p_db_column_name=>'CODIGO_CLIENTE'
,p_display_order=>310
,p_column_identifier=>'AN'
,p_column_label=>'Codigo Cliente'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(257828654702100644)
,p_db_column_name=>'CLIENTE'
,p_display_order=>320
,p_column_identifier=>'AO'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(257828715262100645)
,p_db_column_name=>'LINEA_NEGOCIO'
,p_display_order=>330
,p_column_identifier=>'AP'
,p_column_label=>'Linea Negocio'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(257828810732100646)
,p_db_column_name=>'MARCA'
,p_display_order=>340
,p_column_identifier=>'AQ'
,p_column_label=>'Marca'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(257828955062100647)
,p_db_column_name=>'SUB_MARCA'
,p_display_order=>350
,p_column_identifier=>'AR'
,p_column_label=>'Sub Marca'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(257829033113100648)
,p_db_column_name=>'SDTRDJ'
,p_display_order=>360
,p_column_identifier=>'AS'
,p_column_label=>'Sdtrdj'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(257829193376100649)
,p_db_column_name=>'SDITM'
,p_display_order=>370
,p_column_identifier=>'AT'
,p_column_label=>'Sditm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(257829270517100650)
,p_db_column_name=>'SDAN8'
,p_display_order=>380
,p_column_identifier=>'AU'
,p_column_label=>'Sdan8'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(258267921494561901)
,p_db_column_name=>'CODIGO_PRODUCTO'
,p_display_order=>390
,p_column_identifier=>'AV'
,p_column_label=>'Codigo Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(258268047332561902)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>400
,p_column_identifier=>'AW'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(258268168236561903)
,p_db_column_name=>'CODIGO_BARRA'
,p_display_order=>410
,p_column_identifier=>'AX'
,p_column_label=>'Codigo Barra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(258268224796561904)
,p_db_column_name=>'DESCUENTO'
,p_display_order=>420
,p_column_identifier=>'AY'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(258268413057561906)
,p_db_column_name=>'ORDEN_COMPRA'
,p_display_order=>440
,p_column_identifier=>'BA'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(258268588778561907)
,p_db_column_name=>'ORDEN_JDE'
,p_display_order=>450
,p_column_identifier=>'BB'
,p_column_label=>'Orden ERP'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(258268667227561908)
,p_db_column_name=>'FECHA_JDE'
,p_display_order=>460
,p_column_identifier=>'BC'
,p_column_label=>'Fecha ERP'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(258268707009561909)
,p_db_column_name=>'FECHA_FACTURA'
,p_display_order=>470
,p_column_identifier=>'BD'
,p_column_label=>'Fecha Factura'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(258268828553561910)
,p_db_column_name=>'NUMERO_FACTURA'
,p_display_order=>480
,p_column_identifier=>'BE'
,p_column_label=>'Numero Factura'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(258268994194561911)
,p_db_column_name=>'UNIDAD_MEDIDA'
,p_display_order=>490
,p_column_identifier=>'BF'
,p_column_label=>'Unidad Medida'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(258269088980561912)
,p_db_column_name=>'CANTIDAD_BU_CA'
,p_display_order=>500
,p_column_identifier=>'BG'
,p_column_label=>'Cantidad Bu Ca'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(258269192392561913)
,p_db_column_name=>'CANTIDAD_UN'
,p_display_order=>510
,p_column_identifier=>'BH'
,p_column_label=>'Cantidad Un'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(258269237317561914)
,p_db_column_name=>'PRECIO'
,p_display_order=>520
,p_column_identifier=>'BI'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(258269320766561915)
,p_db_column_name=>'SUBTOTAL'
,p_display_order=>530
,p_column_identifier=>'BJ'
,p_column_label=>'Subtotal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(149253704257694053)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1492538'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'GRUPO:CLIENTE:LINEA_NEGOCIO:SUB_MARCA:MARCA:PRODUCTO:CODIGO_BARRA:CODIGO_PRODUCTO:ORDEN_COMPRA:ORDEN_JDE:FECHA_JDE:NUMERO_FACTURA:FECHA_FACTURA:DESCUENTO:ID_INVERSION:UNIDAD_MEDIDA:CANTIDAD_BU_CA:CANTIDAD_UN:PRECIO:SUBTOTAL:'
,p_sort_column_1=>'FECHA_JDE'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_sum_columns_on_break=>'CANTIDAD_BU_CA:SUBTOTAL'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(600764171101586709)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'Sin facturar'
,p_report_seq=>10
,p_report_alias=>'6007642'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'GRUPO:CLIENTE:LINEA_NEGOCIO:SUB_MARCA:MARCA:PRODUCTO:CODIGO_BARRA:CODIGO_PRODUCTO:ORDEN_COMPRA:ORDEN_JDE:FECHA_JDE:NUMERO_FACTURA:FECHA_FACTURA:DESCUENTO:ID_INVERSION:UNIDAD_MEDIDA:CANTIDAD_BU_CA:CANTIDAD_UN:PRECIO:SUBTOTAL:'
,p_sort_column_1=>'FECHA_JDE'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_sum_columns_on_break=>'CANTIDAD_BU_CA:SUBTOTAL'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(600764549111586710)
,p_report_id=>wwv_flow_imp.id(600764171101586709)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'FECHA_FACTURA'
,p_operator=>'is null'
,p_condition_sql=>'"FECHA_FACTURA" is null'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(303004002)
,p_plug_name=>'Reportes'
,p_parent_plug_id=>wwv_flow_imp.id(146929445790891304)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(207622408396798914)
,p_plug_display_sequence=>110
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>12
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'G_COMPANIA'
,p_plug_display_when_cond2=>'00003'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(303003001)
,p_plug_name=>'Resumen grupo'
,p_parent_plug_id=>wwv_flow_imp.id(303004002)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(207622408396798914)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>6
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'with conv_origen as (',
'    select',
'        I."ItemCode",',
'        I."UgpEntry",',
'        U."UomEntry",',
'        G1."AltQty",',
'        G1."BaseQty",',
'        row_number() over (',
'            partition by I."ItemCode", U."UomEntry"',
'            order by G1."LineNum"',
'        ) rn',
'    from OITM@HANA_PE I',
'    join UGP1@HANA_PE G1 on G1."UgpEntry" = I."UgpEntry"',
'    join OUOM@HANA_PE U on U."UomEntry" = G1."UomEntry"',
'),',
'conv_destino as (',
'    select "UgpEntry", target_uom, "AltQty", "BaseQty"',
'    from (',
'        select',
'            G1."UgpEntry",',
'            cast(U."UomCode" as varchar2(20)) target_uom,',
'            G1."AltQty",',
'            G1."BaseQty",',
'            row_number() over (',
'                partition by G1."UgpEntry"',
'                order by',
'                    case cast(U."UomCode" as varchar2(20))',
'                        when ''BU'' then 1',
'                        when ''CA'' then 2',
'                        else 9',
'                    end,',
'                    G1."LineNum"',
'            ) rn',
'        from UGP1@HANA_PE G1',
'        join OUOM@HANA_PE U on U."UomEntry" = G1."UomEntry"',
'        where cast(U."UomCode" as varchar2(20)) in (''BU'', ''CA'')',
'    )',
'    where rn = 1',
'),',
'lineas_peru as (',
'    select',
'        F."DocEntry",',
'        F."DocNum",',
'        F."CardCode",',
'        F."CardName",',
'        F."NumAtCard",',
'        F."DocDate",',
'        F."TaxDate",',
'        D."LineNum",',
'        D."ItemCode",',
'        D."CodeBars",',
'        D."DiscPrcnt",',
'        D."BaseDocNum",',
'        D."Quantity",',
'        D."Price",',
'        D."LineTotal",',
'        R."DocNum" ORDEN_ERP_SAP,',
'        R."NumAtCard" ORDEN_COMPRA_SAP,',
'        F."NumAtCard" NUMERO_FACTURA_SAP,',
'        cast(D."UomCode" as varchar2(50)) uom_code,',
'        case',
'            when T.target_uom is not null then',
'                D."Quantity" *',
'                (',
'                    (O."BaseQty" / nullif(O."AltQty", 0)) *',
'                    (T."AltQty" / nullif(T."BaseQty", 0))',
'                )',
'            else D."Quantity"',
'        end cantidad_bu_ca,',
'        T.target_uom unidad_bu_ca,',
'        C."LicTradNum",',
'        G.CODIGOGRUPO,',
'        G.GRUPO,',
'        G.CANAL,',
'        G.CODIGOCLIENTE,',
'        G.NOMBRES,',
'        G.CODIGOORIGEN,',
'        G.CODIGOCANAL,',
'        G.EJECUTIVO,',
'        I."ItemName",',
'        I."CodeBars" item_code_bars,',
'        B."ItmsGrpNam",',
'        P.LINEANEGOCIO,',
'        P.MARCA,',
'        P.SUBMARCA,',
'        P.NOMBREPRODUCTO,',
'        P.CODIGOBARRA',
'    from OINV@HANA_PE F',
'    join INV1@HANA_PE D on D."DocEntry" = F."DocEntry"',
'    left join OCRD@HANA_PE C on C."CardCode" = F."CardCode"',
'    left join VT_GZM_CLIENTE G',
'        on G.COMPANIA = ''00003''',
'       and (',
'            G.CODIGOCLIENTE = replace(cast(F."CardCode" as varchar2(50)), ''C'', '''')',
'            or G.RUC = cast(C."LicTradNum" as varchar2(50))',
'       )',
'    left join OITM@HANA_PE I on I."ItemCode" = D."ItemCode"',
'    left join OITB@HANA_PE B on B."ItmsGrpCod" = I."ItmsGrpCod"',
'    left join ODLN@HANA_PE E on D."BaseType" = 15 and E."DocEntry" = D."BaseEntry"',
'    left join DLN1@HANA_PE ED on E."DocEntry" = ED."DocEntry" and ED."LineNum" = D."BaseLine"',
'    left join ORDR@HANA_PE R',
'        on (D."BaseType" = 17 and R."DocEntry" = D."BaseEntry")',
'        or (ED."BaseType" = 17 and R."DocEntry" = ED."BaseEntry")',
'    left join VT_GZM_PRODUCTO P',
'        on P.COMPANIA = ''00003''',
'       and P.CODIGOPRODUCTO = cast(D."ItemCode" as varchar2(100))',
'    left join conv_origen O',
'        on O."ItemCode" = D."ItemCode"',
'       and O."UomEntry" = D."UomEntry"',
'       and O.rn = 1',
'    left join conv_destino T on T."UgpEntry" = O."UgpEntry"',
'    where F."CANCELED" = ''N''',
'      and D."ItemCode" is not null',
')',
'',
'select',
'    case',
'        when regexp_like(nvl(CODIGOGRUPO, replace(cast("CardCode" as varchar2(50)), ''C'', '''')), ''^\d+$'')',
'        then to_number(nvl(CODIGOGRUPO, replace(cast("CardCode" as varchar2(50)), ''C'', '''')))',
'    end CODIGO_GRUPO,',
'    nvl(max(GRUPO), max(cast("CardName" as varchar2(500)))) GRUPO,',
'    max(CANAL) CANAL,',
'    sum(cantidad_bu_ca) CANTIDAD_BU_CA,',
'    sum("LineTotal") SUBTOTAL',
'from lineas_peru',
'where "DocDate" between to_date(:P303_FECHAINICIO, ''DD/MM/YYYY'') and to_date(:P303_FECHAFIN, ''DD/MM/YYYY'')',
'  and (:P303_ORIGEN is null or CODIGOORIGEN = :P303_ORIGEN)',
'  and (:P303_CANAL is null or CODIGOCANAL = :P303_CANAL)',
'  and (:P303_GRUPO is null or CODIGOGRUPO = :P303_GRUPO)',
'  and (:G_ROL = 1 or (:G_ROL = 2 and EJECUTIVO = :G_IDENTIFICACION))',
'group by nvl(CODIGOGRUPO, replace(cast("CardCode" as varchar2(50)), ''C'', ''''))',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Resumen grupo'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(303003101)
,p_name=>'Resumen grupo Peru'
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>350
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'NETBY3'
,p_internal_uid=>303003101
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003101010)
,p_db_column_name=>'CODIGO_GRUPO'
,p_display_order=>10
,p_column_identifier=>'AI'
,p_column_label=>'-'
,p_column_link=>'javascript:$s(''P303_TODOS'',''N''); $s(''P303_GRUPOELEGIDO'',''''); $s(''P303_GRUPOELEGIDO'',''#CODIGO_GRUPO#'');'
,p_column_linktext=>'<span class="fa fa-check" aria-hidden="true"></span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003101020)
,p_db_column_name=>'CANAL'
,p_display_order=>20
,p_column_identifier=>'AE'
,p_column_label=>'Canal'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003101030)
,p_db_column_name=>'GRUPO'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Grupo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003101040)
,p_db_column_name=>'CANTIDAD_BU_CA'
,p_display_order=>40
,p_column_identifier=>'AB'
,p_column_label=>'Cantidad Bu Ca'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003101050)
,p_db_column_name=>'SUBTOTAL'
,p_display_order=>50
,p_column_identifier=>'AC'
,p_column_label=>'Subtotal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(303003101510)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'303003101510'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODIGO_GRUPO:CANAL:GRUPO:CANTIDAD_BU_CA:SUBTOTAL:'
,p_sum_columns_on_break=>'SUBTOTAL:CANTIDAD_BU_CA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(303003002)
,p_plug_name=>'Cliente y Linea de Negocio'
,p_region_name=>'rgnResumen'
,p_parent_plug_id=>wwv_flow_imp.id(303004002)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(207622408396798914)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>6
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'with conv_origen as (',
'    select',
'        I."ItemCode",',
'        I."UgpEntry",',
'        U."UomEntry",',
'        G1."AltQty",',
'        G1."BaseQty",',
'        row_number() over (',
'            partition by I."ItemCode", U."UomEntry"',
'            order by G1."LineNum"',
'        ) rn',
'    from OITM@HANA_PE I',
'    join UGP1@HANA_PE G1 on G1."UgpEntry" = I."UgpEntry"',
'    join OUOM@HANA_PE U on U."UomEntry" = G1."UomEntry"',
'),',
'conv_destino as (',
'    select "UgpEntry", target_uom, "AltQty", "BaseQty"',
'    from (',
'        select',
'            G1."UgpEntry",',
'            cast(U."UomCode" as varchar2(20)) target_uom,',
'            G1."AltQty",',
'            G1."BaseQty",',
'            row_number() over (',
'                partition by G1."UgpEntry"',
'                order by',
'                    case cast(U."UomCode" as varchar2(20))',
'                        when ''BU'' then 1',
'                        when ''CA'' then 2',
'                        else 9',
'                    end,',
'                    G1."LineNum"',
'            ) rn',
'        from UGP1@HANA_PE G1',
'        join OUOM@HANA_PE U on U."UomEntry" = G1."UomEntry"',
'        where cast(U."UomCode" as varchar2(20)) in (''BU'', ''CA'')',
'    )',
'    where rn = 1',
'),',
'lineas_peru as (',
'    select',
'        F."DocEntry",',
'        F."DocNum",',
'        F."CardCode",',
'        F."CardName",',
'        F."NumAtCard",',
'        F."DocDate",',
'        F."TaxDate",',
'        D."LineNum",',
'        D."ItemCode",',
'        D."CodeBars",',
'        D."DiscPrcnt",',
'        D."BaseDocNum",',
'        D."Quantity",',
'        D."Price",',
'        D."LineTotal",',
'        cast(D."UomCode" as varchar2(50)) uom_code,',
'        case',
'            when T.target_uom is not null then',
'                D."Quantity" *',
'                (',
'                    (O."BaseQty" / nullif(O."AltQty", 0)) *',
'                    (T."AltQty" / nullif(T."BaseQty", 0))',
'                )',
'            else D."Quantity"',
'        end cantidad_bu_ca,',
'        T.target_uom unidad_bu_ca,',
'        C."LicTradNum",',
'        G.CODIGOGRUPO,',
'        G.GRUPO,',
'        G.CANAL,',
'        G.CODIGOCLIENTE,',
'        G.NOMBRES,',
'        G.CODIGOORIGEN,',
'        G.CODIGOCANAL,',
'        G.EJECUTIVO,',
'        I."ItemName",',
'        I."CodeBars" item_code_bars,',
'        B."ItmsGrpNam",',
'        P.LINEANEGOCIO,',
'        P.MARCA,',
'        P.SUBMARCA,',
'        P.NOMBREPRODUCTO,',
'        P.CODIGOBARRA',
'    from OINV@HANA_PE F',
'    join INV1@HANA_PE D on D."DocEntry" = F."DocEntry"',
'    left join OCRD@HANA_PE C on C."CardCode" = F."CardCode"',
'    left join VT_GZM_CLIENTE G',
'        on G.COMPANIA = ''00003''',
'       and (',
'            G.CODIGOCLIENTE = replace(cast(F."CardCode" as varchar2(50)), ''C'', '''')',
'            or G.RUC = cast(C."LicTradNum" as varchar2(50))',
'       )',
'    left join OITM@HANA_PE I on I."ItemCode" = D."ItemCode"',
'    left join OITB@HANA_PE B on B."ItmsGrpCod" = I."ItmsGrpCod"',
'    left join VT_GZM_PRODUCTO P',
'        on P.COMPANIA = ''00003''',
'       and P.CODIGOPRODUCTO = cast(D."ItemCode" as varchar2(100))',
'    left join conv_origen O',
'        on O."ItemCode" = D."ItemCode"',
'       and O."UomEntry" = D."UomEntry"',
'       and O.rn = 1',
'    left join conv_destino T on T."UgpEntry" = O."UgpEntry"',
'    where F."CANCELED" = ''N''',
'      and D."ItemCode" is not null',
')',
'',
'select',
'    case',
'        when regexp_like(replace(cast("CardCode" as varchar2(50)), ''C'', ''''), ''^\d+$'')',
'        then to_number(replace(cast("CardCode" as varchar2(50)), ''C'', ''''))',
'    end CODIGO_CLIENTE,',
'    max(nvl(NOMBRES, cast("CardName" as varchar2(500)))) CLIENTE,',
'    nvl(nullif(trim(LINEANEGOCIO), ''''), cast("ItmsGrpNam" as varchar2(200))) LINEA_NEGOCIO,',
'    sum(cantidad_bu_ca) CANTIDAD_BU_CA,',
'    sum("LineTotal") SUBTOTAL',
'from lineas_peru',
'where "DocDate" between to_date(:P303_FECHAINICIO, ''DD/MM/YYYY'') and to_date(:P303_FECHAFIN, ''DD/MM/YYYY'')',
'  and (:P303_ORIGEN is null or CODIGOORIGEN = :P303_ORIGEN)',
'  and (:P303_CANAL is null or CODIGOCANAL = :P303_CANAL)',
'  and (CODIGOGRUPO = :P303_GRUPOELEGIDO or :P303_TODOS = ''Y'')',
'  and (:G_ROL = 1 or (:G_ROL = 2 and EJECUTIVO = :G_IDENTIFICACION))',
'group by',
'    replace(cast("CardCode" as varchar2(50)), ''C'', ''''),',
'    nvl(nullif(trim(LINEANEGOCIO), ''''), cast("ItmsGrpNam" as varchar2(200)))',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P303_GRUPOELEGIDO,P303_TODOS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Cliente y Linea de Negocio'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(303003102)
,p_name=>'Cliente y Linea de Negocio Peru'
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>350
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'NETBY3'
,p_internal_uid=>303003102
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003102050)
,p_db_column_name=>'CANTIDAD_BU_CA'
,p_display_order=>50
,p_column_identifier=>'H'
,p_column_label=>'Cantidad Bu Ca'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003102070)
,p_db_column_name=>'CODIGO_CLIENTE'
,p_display_order=>70
,p_column_identifier=>'J'
,p_column_label=>'Codigo Cliente'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003102080)
,p_db_column_name=>'CLIENTE'
,p_display_order=>80
,p_column_identifier=>'K'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003102090)
,p_db_column_name=>'LINEA_NEGOCIO'
,p_display_order=>90
,p_column_identifier=>'L'
,p_column_label=>'Linea Negocio'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003102100)
,p_db_column_name=>'SUBTOTAL'
,p_display_order=>100
,p_column_identifier=>'N'
,p_column_label=>'Subtotal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(303003102510)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'303003102510'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'CLIENTE:LINEA_NEGOCIO:CANTIDAD_BU_CA:SUBTOTAL'
,p_sort_column_1=>'CODIGOCLIENTE'
,p_sort_direction_1=>'ASC NULLS LAST'
,p_sort_column_2=>'LINEANEGOCIO'
,p_sort_direction_2=>'ASC NULLS LAST'
,p_sort_column_3=>'TOT_CANTIDAD'
,p_sort_direction_3=>'ASC NULLS LAST'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'0:0:0:0:0'
,p_break_enabled_on=>'0:0:0:0:0'
,p_sum_columns_on_break=>'TOT_CANTIDAD:TOT_VALOR:SUBTOTAL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(303003003)
,p_plug_name=>'Detalle'
,p_parent_plug_id=>wwv_flow_imp.id(303004002)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(207622408396798914)
,p_plug_display_sequence=>50
,p_plug_grid_column_span=>12
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'with conv_origen as (',
'    select',
'        I."ItemCode",',
'        I."UgpEntry",',
'        U."UomEntry",',
'        G1."AltQty",',
'        G1."BaseQty",',
'        row_number() over (',
'            partition by I."ItemCode", U."UomEntry"',
'            order by G1."LineNum"',
'        ) rn',
'    from OITM@HANA_PE I',
'    join UGP1@HANA_PE G1 on G1."UgpEntry" = I."UgpEntry"',
'    join OUOM@HANA_PE U on U."UomEntry" = G1."UomEntry"',
'),',
'conv_destino as (',
'    select "UgpEntry", target_uom, "AltQty", "BaseQty"',
'    from (',
'        select',
'            G1."UgpEntry",',
'            cast(U."UomCode" as varchar2(20)) target_uom,',
'            G1."AltQty",',
'            G1."BaseQty",',
'            row_number() over (',
'                partition by G1."UgpEntry"',
'                order by',
'                    case cast(U."UomCode" as varchar2(20))',
'                        when ''BU'' then 1',
'                        when ''CA'' then 2',
'                        else 9',
'                    end,',
'                    G1."LineNum"',
'            ) rn',
'        from UGP1@HANA_PE G1',
'        join OUOM@HANA_PE U on U."UomEntry" = G1."UomEntry"',
'        where cast(U."UomCode" as varchar2(20)) in (''BU'', ''CA'')',
'    )',
'    where rn = 1',
'),',
'lineas_peru as (',
'    select',
'        F."DocEntry",',
'        F."DocNum",',
'        F."CardCode",',
'        F."CardName",',
'        F."NumAtCard",',
'        F."DocDate",',
'        F."TaxDate",',
'        D."LineNum",',
'        D."ItemCode",',
'        D."CodeBars",',
'        D."DiscPrcnt",',
'        D."BaseDocNum",',
'        D."Quantity",',
'        D."Price",',
'        D."LineTotal",',
'        R."DocNum" ORDEN_ERP_SAP,',
'        R."NumAtCard" ORDEN_COMPRA_SAP,',
'        F."NumAtCard" NUMERO_FACTURA_SAP,',
'        cast(D."UomCode" as varchar2(50)) uom_code,',
'        case',
'            when T.target_uom is not null then',
'                D."Quantity" *',
'                (',
'                    (O."BaseQty" / nullif(O."AltQty", 0)) *',
'                    (T."AltQty" / nullif(T."BaseQty", 0))',
'                )',
'            else D."Quantity"',
'        end cantidad_bu_ca,',
'        T.target_uom unidad_bu_ca,',
'        C."LicTradNum",',
'        G.CODIGOGRUPO,',
'        G.GRUPO,',
'        G.CANAL,',
'        G.CODIGOCLIENTE,',
'        G.NOMBRES,',
'        G.CODIGOORIGEN,',
'        G.CODIGOCANAL,',
'        G.EJECUTIVO,',
'        G.CANAL CANAL_VENTA,',
'        RL."U_BPP_OPER" OPERACION_EXONERADA_INAFECTA,',
'        RL."U_STR_FE_SUNATC7" AFECTACION_IGV,',
'        R."ShipToCode" LOGISTICA_DESTINO,',
'        R."Address2" DIRECCION_DESTINO,',
'        I."ItemName",',
'        I."CodeBars" item_code_bars,',
'        B."ItmsGrpNam",',
'        P.LINEANEGOCIO,',
'        P.MARCA,',
'        P.SUBMARCA,',
'        P.NOMBREPRODUCTO,',
'        P.CODIGOBARRA',
'    from OINV@HANA_PE F',
'    join INV1@HANA_PE D on D."DocEntry" = F."DocEntry"',
'    left join OCRD@HANA_PE C on C."CardCode" = F."CardCode"',
'    left join VT_GZM_CLIENTE G',
'        on G.COMPANIA = ''00003''',
'       and (',
'            G.CODIGOCLIENTE = replace(cast(F."CardCode" as varchar2(50)), ''C'', '''')',
'            or G.RUC = cast(C."LicTradNum" as varchar2(50))',
'       )',
'    left join OITM@HANA_PE I on I."ItemCode" = D."ItemCode"',
'    left join OITB@HANA_PE B on B."ItmsGrpCod" = I."ItmsGrpCod"',
'    left join ODLN@HANA_PE E on D."BaseType" = 15 and E."DocEntry" = D."BaseEntry"',
'    left join DLN1@HANA_PE ED on E."DocEntry" = ED."DocEntry" and ED."LineNum" = D."BaseLine"',
'    left join ORDR@HANA_PE R',
'        on (D."BaseType" = 17 and R."DocEntry" = D."BaseEntry")',
'        or (ED."BaseType" = 17 and R."DocEntry" = ED."BaseEntry")',
'    left join RDR1@HANA_PE RL',
'        on (D."BaseType" = 17 and RL."DocEntry" = D."BaseEntry" and RL."LineNum" = D."BaseLine")',
'        or (ED."BaseType" = 17 and RL."DocEntry" = ED."BaseEntry" and RL."LineNum" = ED."BaseLine")',
'    left join VT_GZM_PRODUCTO P',
'        on P.COMPANIA = ''00003''',
'       and P.CODIGOPRODUCTO = cast(D."ItemCode" as varchar2(100))',
'    left join conv_origen O',
'        on O."ItemCode" = D."ItemCode"',
'       and O."UomEntry" = D."UomEntry"',
'       and O.rn = 1',
'    left join conv_destino T on T."UgpEntry" = O."UgpEntry"',
'    where F."CANCELED" = ''N''',
'      and D."ItemCode" is not null',
')',
'',
'select',
'    cast(null as number) ID_INVERSION,',
'    nvl(GRUPO, cast("CardName" as varchar2(500))) GRUPO,',
'    case',
'        when regexp_like(replace(cast("CardCode" as varchar2(50)), ''C'', ''''), ''^\d+$'')',
'        then to_number(replace(cast("CardCode" as varchar2(50)), ''C'', ''''))',
'    end CODIGO_CLIENTE,',
'    replace(cast("CardCode" as varchar2(50)), ''C'', '''') || ''-'' || nvl(NOMBRES, cast("CardName" as varchar2(500))) CLIENTE,',
'    nvl(nullif(trim(LINEANEGOCIO), ''''), cast("ItmsGrpNam" as varchar2(200))) LINEA_NEGOCIO,',
'    nullif(trim(MARCA), '''') MARCA,',
'    nullif(trim(SUBMARCA), '''') SUB_MARCA,',
'    to_number(to_char("DocDate", ''YYYYMMDD'')) SDTRDJ,',
'    cast(null as number) SDITM,',
'    case',
'        when regexp_like(replace(cast("CardCode" as varchar2(50)), ''C'', ''''), ''^\d+$'')',
'        then to_number(replace(cast("CardCode" as varchar2(50)), ''C'', ''''))',
'    end SDAN8,',
'    cast("ItemCode" as varchar2(100)) CODIGO_PRODUCTO,',
'    nvl(NOMBREPRODUCTO, cast("ItemName" as varchar2(500))) PRODUCTO,',
'    nvl(CODIGOBARRA, nvl(cast(item_code_bars as varchar2(100)), cast("CodeBars" as varchar2(100)))) CODIGO_BARRA,',
'    "DiscPrcnt" DESCUENTO,',
'    cast(ORDEN_COMPRA_SAP as varchar2(100)) ORDEN_COMPRA,',
'    ORDEN_ERP_SAP ORDEN_JDE,',
'    "DocDate" FECHA_JDE,',
'    "TaxDate" FECHA_FACTURA,',
'    cast(NUMERO_FACTURA_SAP as varchar2(100)) NUMERO_FACTURA,',
'    uom_code UNIDAD_MEDIDA,',
'    cantidad_bu_ca CANTIDAD_BU_CA,',
'    "Quantity" CANTIDAD_UN,',
'    "Price" PRECIO,',
'    "LineTotal" SUBTOTAL',
'    ,CANAL_VENTA',
'    ,OPERACION_EXONERADA_INAFECTA',
'    ,AFECTACION_IGV',
'    ,LOGISTICA_DESTINO',
'    ,DIRECCION_DESTINO',
'from lineas_peru',
'where "DocDate" between to_date(:P303_FECHAINICIO, ''DD/MM/YYYY'') and to_date(:P303_FECHAFIN, ''DD/MM/YYYY'')',
'  and (:P303_ORIGEN is null or CODIGOORIGEN = :P303_ORIGEN)',
'  and (:P303_CANAL is null or CODIGOCANAL = :P303_CANAL)',
'  and (CODIGOGRUPO = :P303_GRUPOELEGIDO or :P303_TODOS = ''Y'')',
'  and (:G_ROL = 1 or (:G_ROL = 2 and EJECUTIVO = :G_IDENTIFICACION))',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P303_GRUPOELEGIDO,P303_TODOS'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Detalle'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(303003103)
,p_name=>'Detalle Peru'
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>350
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'NETBY3'
,p_internal_uid=>303003103
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103290)
,p_db_column_name=>'ID_INVERSION'
,p_display_order=>290
,p_column_identifier=>'AL'
,p_column_label=>'Id Inversion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103300)
,p_db_column_name=>'GRUPO'
,p_display_order=>300
,p_column_identifier=>'AM'
,p_column_label=>'Grupo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103310)
,p_db_column_name=>'CODIGO_CLIENTE'
,p_display_order=>310
,p_column_identifier=>'AN'
,p_column_label=>'Codigo Cliente'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103320)
,p_db_column_name=>'CLIENTE'
,p_display_order=>320
,p_column_identifier=>'AO'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103330)
,p_db_column_name=>'LINEA_NEGOCIO'
,p_display_order=>330
,p_column_identifier=>'AP'
,p_column_label=>'Linea Negocio'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103340)
,p_db_column_name=>'MARCA'
,p_display_order=>340
,p_column_identifier=>'AQ'
,p_column_label=>'Marca'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103350)
,p_db_column_name=>'SUB_MARCA'
,p_display_order=>350
,p_column_identifier=>'AR'
,p_column_label=>'Sub Marca'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103360)
,p_db_column_name=>'SDTRDJ'
,p_display_order=>360
,p_column_identifier=>'AS'
,p_column_label=>'Sdtrdj'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103370)
,p_db_column_name=>'SDITM'
,p_display_order=>370
,p_column_identifier=>'AT'
,p_column_label=>'Sditm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103380)
,p_db_column_name=>'SDAN8'
,p_display_order=>380
,p_column_identifier=>'AU'
,p_column_label=>'Sdan8'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103390)
,p_db_column_name=>'CODIGO_PRODUCTO'
,p_display_order=>390
,p_column_identifier=>'AV'
,p_column_label=>'Codigo Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103400)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>400
,p_column_identifier=>'AW'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103410)
,p_db_column_name=>'CODIGO_BARRA'
,p_display_order=>410
,p_column_identifier=>'AX'
,p_column_label=>'Codigo Barra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103420)
,p_db_column_name=>'DESCUENTO'
,p_display_order=>420
,p_column_identifier=>'AY'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103440)
,p_db_column_name=>'ORDEN_COMPRA'
,p_display_order=>440
,p_column_identifier=>'BA'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103450)
,p_db_column_name=>'ORDEN_JDE'
,p_display_order=>450
,p_column_identifier=>'BB'
,p_column_label=>'Orden ERP'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103460)
,p_db_column_name=>'FECHA_JDE'
,p_display_order=>460
,p_column_identifier=>'BC'
,p_column_label=>'Fecha ERP'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103470)
,p_db_column_name=>'FECHA_FACTURA'
,p_display_order=>470
,p_column_identifier=>'BD'
,p_column_label=>'Fecha Factura'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103480)
,p_db_column_name=>'NUMERO_FACTURA'
,p_display_order=>480
,p_column_identifier=>'BE'
,p_column_label=>'Numero Factura'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103490)
,p_db_column_name=>'UNIDAD_MEDIDA'
,p_display_order=>490
,p_column_identifier=>'BF'
,p_column_label=>'Unidad Medida'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103500)
,p_db_column_name=>'CANTIDAD_BU_CA'
,p_display_order=>500
,p_column_identifier=>'BG'
,p_column_label=>'Cantidad Bu Ca'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103510)
,p_db_column_name=>'CANTIDAD_UN'
,p_display_order=>510
,p_column_identifier=>'BH'
,p_column_label=>'Cantidad Un'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103520)
,p_db_column_name=>'PRECIO'
,p_display_order=>520
,p_column_identifier=>'BI'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103530)
,p_db_column_name=>'SUBTOTAL'
,p_display_order=>530
,p_column_identifier=>'BJ'
,p_column_label=>'Subtotal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103540)
,p_db_column_name=>'CANAL_VENTA'
,p_display_order=>540
,p_column_identifier=>'BK'
,p_column_label=>'Canal Venta'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103550)
,p_db_column_name=>'OPERACION_EXONERADA_INAFECTA'
,p_display_order=>550
,p_column_identifier=>'BL'
,p_column_label=>'Operacion Exonerada o Inafecta'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103560)
,p_db_column_name=>'AFECTACION_IGV'
,p_display_order=>560
,p_column_identifier=>'BM'
,p_column_label=>'Afectacion del IGV'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103570)
,p_db_column_name=>'LOGISTICA_DESTINO'
,p_display_order=>570
,p_column_identifier=>'BN'
,p_column_label=>'Logistica Destino'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(303003103580)
,p_db_column_name=>'DIRECCION_DESTINO'
,p_display_order=>580
,p_column_identifier=>'BO'
,p_column_label=>'Direccion Destino'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(303003103510)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'303003103510'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'GRUPO:CODIGO_CLIENTE:CLIENTE:LINEA_NEGOCIO:SUB_MARCA:MARCA:PRODUCTO:CODIGO_BARRA:CODIGO_PRODUCTO:ORDEN_COMPRA:ORDEN_JDE:FECHA_JDE:NUMERO_FACTURA:FECHA_FACTURA:DESCUENTO:ID_INVERSION:UNIDAD_MEDIDA:CANTIDAD_BU_CA:CANTIDAD_UN:PRECIO:SUBTOTAL:CANAL_VENTA:OPERACION_EXONERADA_INAFECTA:AFECTACION_IGV:LOGISTICA_DESTINO:DIRECCION_DESTINO:'
,p_sort_column_1=>'FECHA_JDE'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_sum_columns_on_break=>'CANTIDAD_BU_CA:SUBTOTAL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(148665274888016421)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(146929306465891303)
,p_button_name=>'BTN_BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176753300778920)
,p_button_image_alt=>'Buscar'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(148664903213016418)
,p_name=>'P303_CANAL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(146929445790891304)
,p_prompt=>'Canal'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct canal, codigocanal from vt_gzm_cliente',
'where nvl(TRIM(codigocanal), '' '') not in ( '' '', ''.'') and  ESTADO = 1 AND CODIGOGRUPO = CODIGOCLIENTE AND (:G_ROL = 1 OR (:G_ROL = 2 AND EJECUTIVO = :G_IDENTIFICACION))',
'AND COMPANIA = :G_COMPANIA;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Todos'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(148665042946016419)
,p_name=>'P303_GRUPO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(146929445790891304)
,p_prompt=>'Grupo'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  CODIGOGRUPO || '' - '' || GRUPO D, CODIGOGRUPO R FROM VT_GZM_CLIENTE',
'WHERE ESTADO = 1 AND CODIGOORIGEN=:P303_ORIGEN AND CODIGOCANAL = NVL(:P303_CANAL, CODIGOCANAL)',
'AND CODIGOGRUPO = CODIGOCLIENTE ',
'AND (:G_ROL = 1 OR (:G_ROL = 2 AND EJECUTIVO = :G_IDENTIFICACION))',
'AND COMPANIA = :G_COMPANIA; '))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'TODOS'
,p_lov_cascade_parent_items=>'P303_CANAL,P303_ORIGEN'
,p_ajax_items_to_submit=>'P303_CANAL'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(148665108990016420)
,p_name=>'P303_CLIENTE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(146929445790891304)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(148665422792016423)
,p_name=>'P303_FECHAINICIO'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(146929445790891304)
,p_item_default=>'trunc((sysdate),''MM'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Inicio'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(148665524067016424)
,p_name=>'P303_FECHAFIN'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(146929445790891304)
,p_item_default=>'SYSDATE'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Fin'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(149100872522457509)
,p_name=>'P303_GRUPOELEGIDO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(146929445790891304)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(248657001511649701)
,p_name=>'P303_ORIGEN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(146929445790891304)
,p_prompt=>'Origen'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct CODIGOORIGEN D, CODIGOORIGEN R from vt_gzm_cliente',
'where nvl(TRIM(codigocanal), '' '') not in ( '' '', ''.'') and  ESTADO = 1 AND CODIGOGRUPO = CODIGOCLIENTE AND (:G_ROL = 1 OR (:G_ROL = 2 AND EJECUTIVO = :G_IDENTIFICACION))',
'AND COMPANIA = :G_COMPANIA;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Todos'
,p_cHeight=>1
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(248659966302649730)
,p_name=>'P303_CARGA'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(146929445790891304)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(569392374811790227)
,p_name=>'P303_TODOS'
,p_item_sequence=>55
,p_item_plug_id=>wwv_flow_imp.id(146929445790891304)
,p_prompt=>'Todos'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(149100950576457510)
,p_name=>'CAMBIA_GRUPOELEGIDO'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P303_GRUPOELEGIDO'
,p_condition_element=>'P303_GRUPOELEGIDO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(149221325115582334)
,p_event_id=>wwv_flow_imp.id(149100950576457510)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(149101184779457512)
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P303_GRUPOELEGIDO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(149657305829417548)
,p_event_id=>wwv_flow_imp.id(149100950576457510)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(149221581516582336)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(303005001)
,p_event_id=>wwv_flow_imp.id(149100950576457510)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(303003002)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(303005002)
,p_event_id=>wwv_flow_imp.id(149100950576457510)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(303003003)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(248658551917649716)
,p_name=>'Cambiar'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P303_CANAL,P303_GRUPO,P303_ORIGEN'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(248658677910649717)
,p_event_id=>wwv_flow_imp.id(248658551917649716)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P303_GRUPOELEGIDO := null;'
,p_attribute_03=>'P303_GRUPOELEGIDO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(248660031317649731)
,p_name=>'Page Load'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(248660192601649732)
,p_event_id=>wwv_flow_imp.id(248660031317649731)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P303_CARGA :=1;'
,p_attribute_03=>'P303_CARGA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(248660234580649733)
,p_event_id=>wwv_flow_imp.id(248660031317649731)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(148664860584016417)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(248660333694649734)
,p_event_id=>wwv_flow_imp.id(248660031317649731)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(149101184779457512)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(248660480954649735)
,p_event_id=>wwv_flow_imp.id(248660031317649731)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(149221581516582336)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(303005003)
,p_event_id=>wwv_flow_imp.id(248660031317649731)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(303003002)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(303005004)
,p_event_id=>wwv_flow_imp.id(248660031317649731)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(303003003)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(569392444075790228)
,p_name=>'Seleccion todos'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P303_TODOS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(569392591533790229)
,p_event_id=>wwv_flow_imp.id(569392444075790228)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(149101184779457512)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(569392614616790230)
,p_event_id=>wwv_flow_imp.id(569392444075790228)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(149221581516582336)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(303005005)
,p_event_id=>wwv_flow_imp.id(569392444075790228)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(303003002)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(303005006)
,p_event_id=>wwv_flow_imp.id(569392444075790228)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(303003003)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(148665373672016422)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pk_vtas_pedidos.sp_inserta_reportepedidos(',
'    p_canal => :P303_CANAL, ',
'    p_codigogrupo => :P303_GRUPO, ',
'    p_codigocliente => :P303_CLIENTE, ',
'    p_fechainicio => :P303_FECHAINICIO, ',
'    p_fechafin => :P303_FECHAFIN);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>148665373672016422
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(148667364902016442)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar datos'
,p_process_sql_clob=>':P303_CARGA :=0;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>148667364902016442
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
