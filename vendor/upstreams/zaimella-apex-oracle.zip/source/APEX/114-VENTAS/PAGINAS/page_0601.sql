prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>114
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 114 - Ventas
--
-- Application Export:
--   Application:     114
--   Name:            Ventas
--   Date and Time:   17:00 Tuesday July 21, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 601
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_00601
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>601);
end;
/
prompt --application/pages/page_00601
begin
wwv_flow_imp_page.create_page(
 p_id=>601
,p_name=>'Dlg Configuracion Orden de Compra'
,p_alias=>unistr('DATOS-CONFIGURACI\00D3N-ORDEN-COMPRA')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Configuraci\00F3n Orden de Compra')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-GV-footer.js-stickyWidget-toggle.is-stuck {',
'    position: absolute !important;',
'}'))
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_protection_level=>'C'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(154141022030475435)
,p_plug_name=>'Formulario'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(207623277923798915)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(114876377289166095)
,p_plug_name=>'Orden de Compra'
,p_parent_plug_id=>wwv_flow_imp.id(154141022030475435)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(207623277923798915)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(114886539406166109)
,p_plug_name=>'Buttons'
,p_parent_plug_id=>wwv_flow_imp.id(154141022030475435)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(207623620294798915)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(161404908527612801)
,p_plug_name=>'Detalle OC'
,p_parent_plug_id=>wwv_flow_imp.id(154141022030475435)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(207622088470798914)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(114865248788138216)
,p_plug_name=>'Mapeo Detalle de Orden'
,p_parent_plug_id=>wwv_flow_imp.id(161404908527612801)
,p_region_template_options=>'#DEFAULT#:margin-top-md'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(207123407083778876)
,p_plug_display_sequence=>40
,p_query_type=>'TABLE'
,p_query_table=>'VT_VTAS_PEDIDO_CONF_OC'
,p_query_where=>'CODIGOGRUPO=:P601_CODIGOGRUPO AND COMPANIA=:G_COMPANIA'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P601_CODIGOGRUPO'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P601_ID'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Mapeo Detalle de Orden'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(114865409622138218)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>70
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(114865705668138221)
,p_name=>'COLUMNA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COLUMNA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Columna'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>20
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(115287657438981811)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(115287782690981812)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
,p_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(154141355215475438)
,p_name=>'FORMULA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FORMULA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Formula'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>2500
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(154141482096475439)
,p_name=>'CODIGOCLIENTE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODIGOCLIENTE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(154141522352475440)
,p_name=>'CODIGOGRUPO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODIGOGRUPO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>50
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(154141657732475441)
,p_name=>'ORDEN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ORDEN'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>80
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(154141777612475442)
,p_name=>'COLUMNA_DESCRIPCION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COLUMNA_DESCRIPCION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Descripcion'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(154141878680475443)
,p_name=>'COLUMNA_VARIABLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COLUMNA_VARIABLE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>100
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(114865353762138217)
,p_internal_uid=>114865353762138217
,p_is_editable=>true
,p_edit_operations=>'u'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>false
,p_fixed_row_height=>false
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>false
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (config) {',
' return cargarToolbar(config);',
'}'))
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(115231131582013058)
,p_interactive_grid_id=>wwv_flow_imp.id(114865353762138217)
,p_static_id=>'1152312'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(115231375069013059)
,p_report_id=>wwv_flow_imp.id(115231131582013058)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(115231888888013060)
,p_view_id=>wwv_flow_imp.id(115231375069013059)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(114865409622138218)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(115234599671013069)
,p_view_id=>wwv_flow_imp.id(115231375069013059)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(114865705668138221)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(117311070104246637)
,p_view_id=>wwv_flow_imp.id(115231375069013059)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(115287657438981811)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(156473031023058212)
,p_view_id=>wwv_flow_imp.id(115231375069013059)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(154141355215475438)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(156748435394003497)
,p_view_id=>wwv_flow_imp.id(115231375069013059)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(154141482096475439)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(156749349529003502)
,p_view_id=>wwv_flow_imp.id(115231375069013059)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(154141522352475440)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(156750213024003505)
,p_view_id=>wwv_flow_imp.id(115231375069013059)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(154141657732475441)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(156751162036003507)
,p_view_id=>wwv_flow_imp.id(115231375069013059)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(154141777612475442)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(156752057786003508)
,p_view_id=>wwv_flow_imp.id(115231375069013059)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(154141878680475443)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(114867529518138239)
,p_plug_name=>'Nuevo Mapeo Detalle de Orden'
,p_parent_plug_id=>wwv_flow_imp.id(161404908527612801)
,p_region_template_options=>'#DEFAULT#:margin-top-md'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(207123407083778876)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT SEQ_ID, c001 as VALOR, c002 COLUMNA, c003 FORMULA',
'   FROM APEX_collections',
' WHERE collection_name = ''COL_VTAS_OC_CONF'''))
,p_plug_source_type=>'NATIVE_IG'
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'P601_ID'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Nuevo Mapeo Detalle de Orden'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(114868327607138247)
,p_name=>'VALOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VALOR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Valor / VARIABLE FORMULA'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(115302590143146686)
,p_lov_display_extra=>false
,p_lov_display_null=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(114868424166138248)
,p_name=>'COLUMNA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COLUMNA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Columna'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(114868563385138249)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(114868656954138250)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
,p_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(115286784334981802)
,p_name=>'SEQ_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SEQ_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'N'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(154141231954475437)
,p_name=>'FORMULA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FORMULA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Formula'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(114867638172138240)
,p_internal_uid=>114867638172138240
,p_is_editable=>true
,p_edit_operations=>'u'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>false
,p_fixed_row_height=>false
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>false
,p_show_toolbar=>true
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (config) {',
' return cargarToolbar(config);',
'}'))
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(115283067188971510)
,p_interactive_grid_id=>wwv_flow_imp.id(114867638172138240)
,p_static_id=>'1152831'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(115283291877971510)
,p_report_id=>wwv_flow_imp.id(115283067188971510)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(115283738396971515)
,p_view_id=>wwv_flow_imp.id(115283291877971510)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(114868327607138247)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(115284660177971518)
,p_view_id=>wwv_flow_imp.id(115283291877971510)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(114868424166138248)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(115292932391983536)
,p_view_id=>wwv_flow_imp.id(115283291877971510)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(114868563385138249)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(115298351018090058)
,p_view_id=>wwv_flow_imp.id(115283291877971510)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(115286784334981802)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(156470863159030735)
,p_view_id=>wwv_flow_imp.id(115283291877971510)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(154141231954475437)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(156850643214939748)
,p_plug_name=>'Ejemplo Formulas'
,p_parent_plug_id=>wwv_flow_imp.id(161404908527612801)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(207113483708778870)
,p_plug_display_sequence=>70
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(108366634689294480202)
,p_plug_name=>'PDF a Excel para mapeo'
,p_region_name=>'PDF_MAPEO_OC'
,p_parent_plug_id=>wwv_flow_imp.id(161404908527612801)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(207113483708778870)
,p_plug_display_sequence=>60
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P601_ID'
,p_plug_header=>'<style>#P601_PDF_MAPEO_CONTAINER a-file-upload{display:block;max-width:360px}#P601_PDF_MAPEO_CONTAINER input[type=file].apex-item-file{opacity:1!important;position:static!important;width:100%!important;height:32px!important}#P601_PDF_MAPEO_CONTAINER '
||'.t-Form-inputContainer{min-height:36px}</style>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(108366634689294480203)
,p_plug_name=>'Excel generado'
,p_region_name=>'EXCEL_MAPEO_OC'
,p_parent_plug_id=>wwv_flow_imp.id(108366634689294480202)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(207113483708778870)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'SELECT NUMEROARCHIVO,',
'       FILENAME,',
'       DBMS_LOB.GETLENGTH(BLOBCONTENT) BLOBCONTENT,',
'       NUMEROARCHIVO DESCARGAR,',
'       MIMETYPE,',
'       FECHA,',
'       NOMBREUSUARIO USUARIO,',
'       NUMEROARCHIVO ELIMINAR,',
'       APEX_PAGE.GET_URL(',
'           P_PAGE    => 601,',
'           P_REQUEST => ''ELIMINAR_EXCEL_MAPEO'',',
'           P_ITEMS   => ''P601_ID,P601_ARCHIVO_ELIMINAR'',',
'           P_VALUES  => :P601_ID || '','' || NUMEROARCHIVO',
'       ) ELIMINAR_URL',
'  FROM FILES.T_APEX_ARCHIVOS',
' WHERE TABLA = ''T_VTAS_PEDIDO_CONF_OC''',
'   AND ID_TABLA = TO_CHAR(:P601_ID)',
'   AND TIPO = ''OC_MAPEO_EXCEL''',
' ORDER BY FECHA DESC, NUMEROARCHIVO DESC',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P601_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(43270543845454471485)
,p_name=>'Excel generado'
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'No existe Excel generado para esta configuracion.'
,p_max_rows_per_page=>'10'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>293471502527414746
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083204945)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Numero archivo'
,p_display_in_default_rpt=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083204946)
,p_db_column_name=>'FILENAME'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Archivo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083204947)
,p_db_column_name=>'BLOBCONTENT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Blob content'
,p_display_in_default_rpt=>'N'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment::FILES'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083204948)
,p_db_column_name=>'DESCARGAR'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Descargar'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment::FILES'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083204949)
,p_db_column_name=>'MIMETYPE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Mime type'
,p_display_in_default_rpt=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083204950)
,p_db_column_name=>'FECHA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083204951)
,p_db_column_name=>'USUARIO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083204952)
,p_db_column_name=>'ELIMINAR'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Eliminar'
,p_column_link=>'#ELIMINAR_URL#'
,p_column_linktext=>'<span title="Eliminar" class="fa fa-trash"></span>'
,p_column_link_attr=>'onclick="return confirm(''Desea eliminar el Excel generado para esta configuracion?'');"'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(17990710234083204953)
,p_db_column_name=>'ELIMINAR_URL'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Eliminar URL'
,p_display_in_default_rpt=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(273757091608920964)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2737633'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FILENAME:DESCARGAR:FECHA:USUARIO:ELIMINAR'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(43270546721390478900)
,p_application_user=>'APXWS_DEFAULT'
,p_name=>'Primary Report'
,p_report_seq=>10
,p_report_alias=>'1476778'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>10
,p_report_columns=>'FILENAME:DESCARGAR:FECHA:USUARIO:ELIMINAR:'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(114888792075166112)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(114886539406166109)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176819582778921)
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P601_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(29391521649605884380)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(108366634689294480202)
,p_button_name=>'CONVERTIR_PDF_MAPEO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176819582778921)
,p_button_image_alt=>'Convertir PDF a Excel'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_button_condition=>'P601_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(114889182087166112)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(114886539406166109)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176819582778921)
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P601_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(114886986213166109)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(114886539406166109)
,p_button_name=>'CANCEL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176819582778921)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(114888364079166112)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(114886539406166109)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(207176819582778921)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_icon_css_classes=>'fa-trash'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_confirm_message=>unistr('¿Est\00E1 seguro de eliminar el registro?')
,p_confirm_style=>'danger'
,p_button_condition_type=>'NEVER'
,p_grid_new_row=>'Y'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(103103059187016545)
,p_name=>'P601_ROL'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(114876377289166095)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(103103157539016546)
,p_name=>'P601_IDENTIFICACION'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(114876377289166095)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(114865190912138215)
,p_name=>'P601_COLUMNA_OC'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(114876377289166095)
,p_prompt=>'Columna de OC'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(114876792902166096)
,p_name=>'P601_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(114876377289166095)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(114877539814166103)
,p_name=>'P601_CODIGOGRUPO'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(114876377289166095)
,p_prompt=>'Grupo'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'CODIGOGRUPO || '' - '' || GRUPO AS DESCRIPCION, CODIGOGRUPO',
'FROM VT_GZM_CLIENTE',
'WHERE COMPANIA = :G_COMPANIA',
'AND CODIGOCLIENTE = CODIGOGRUPO',
'AND (:P601_ROL = 1 OR (:P601_ROL = 2 AND EJECUTIVO = :P601_IDENTIFICACION));'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P601_ROL,P601_IDENTIFICACION'
,p_ajax_items_to_submit=>'P601_ROL,P601_IDENTIFICACION'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>32
,p_cMaxlength=>50
,p_colspan=>6
,p_read_only_when=>'P601_CODIGOGRUPO'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(114877957236166103)
,p_name=>'P601_TIPOARCHIVO'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(114876377289166095)
,p_prompt=>'Tipo de Archivo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_VTAS_TIPOARCHIVO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select descripcion d, id_tabla r',
'from t_corp_udc where id_cabecera = ''VTAS_PTARC'' and activo = ''1'';'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'-- Seleccione --'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(114878323905166103)
,p_name=>'P601_SEPARADOR'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(114876377289166095)
,p_prompt=>'Separador'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>2
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(114878780623166104)
,p_name=>'P601_INICIOFILADETALLE'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(114876377289166095)
,p_prompt=>unistr('N\00FAmero de fila inicio detalle')
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(114879172271166104)
,p_name=>'P601_FILA_OC'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(114876377289166095)
,p_prompt=>'Fila de OC'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>10
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(114879571399166104)
,p_name=>'P601_FORMATO_NUM'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(114876377289166095)
,p_prompt=>unistr('Formato N\00FAmero')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_VTAS_FORMATOSNUMERO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION D, VALOR R FROM T_CORP_UDC ',
'WHERE id_cabecera =''VTAS_FNUM'' AND ACTIVO = ''1'''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'NINGUNO'
,p_cHeight=>1
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(114879922492166104)
,p_name=>'P601_TIPOUNIDAD'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(114876377289166095)
,p_prompt=>'Tipo de Unidad'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_VTAS_TIPOUNIDAD'
,p_lov=>'SELECT DESCRIPCION D, ID_TABLA R FROM T_CORP_UDC WHERE id_cabecera = ''VTAS_PUND'';'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(114881936490166105)
,p_name=>'P601_ESTADO'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(114876377289166095)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(156850520379939747)
,p_name=>'P601_FORMULAS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(156850643214939748)
,p_prompt=>'FORMULAS'
,p_source=>'<ul><li><strong>CANTIDAD_OC </strong>= Cantidad que viene en la orden de compra</li><li><strong>PRECIO_OC</strong> = Precio que viene en la orden de compra&nbsp;</li><li><strong>DESCUENTO_OC </strong>= Descuento que viene en la orden&nbsp;</li><li><s'
||unistr('trong>CANTIDADPRESENTACION </strong>= Presentaci\00F3n del producto&nbsp;</li><li><strong>DESCUENTO</strong>= Descuento JDE</li><li><strong>PRECIO</strong>= Precio lista JDE</li><li><strong>ICE</strong>= Ice JDE</li></ul><p><mark class="marker-yellow">Ej')
||'emplo de uso:</mark></p><p><strong>PRECIO_OC</strong> = <strong>PRECIO_OC</strong> - (<strong>PRECIO_OC</strong> * <strong>DESCUENTO_OC/100)&nbsp;</strong>'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'HTML'
,p_attribute_02=>'FULL'
,p_attribute_03=>'MULTILINE'
,p_attribute_04=>'180'
,p_attribute_07=>'N'
,p_attribute_25=>'CKEDITOR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28881082835865104687)
,p_name=>'P601_PDF_MAPEO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(108366634689294480202)
,p_prompt=>'PDF para convertir a Excel'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_tag_attributes=>'accept=".pdf,application/pdf"'
,p_display_when=>'P601_ID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(207176190675778917)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_12=>'NATIVE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28881082835865104688)
,p_name=>'P601_ARCHIVO_ELIMINAR'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(108366634689294480202)
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(28881082835865104689)
,p_name=>'P601_ARCHIVO_DESCARGAR'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(108366634689294480202)
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(114867109379138235)
,p_name=>'CambioTipoArchivo'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P601_TIPOARCHIVO'
,p_condition_element=>'P601_TIPOARCHIVO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(114867231434138236)
,p_event_id=>wwv_flow_imp.id(114867109379138235)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P601_SEPARADOR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(114867380884138237)
,p_event_id=>wwv_flow_imp.id(114867109379138235)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P601_SEPARADOR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(114867437242138238)
,p_event_id=>wwv_flow_imp.id(114867109379138235)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P601_SEPARADOR'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(115286641531981801)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(114867529518138239)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Nuevo Mapeo Detalle de Orden - Save Interactive Grid Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'APEX_COLLECTION.UPDATE_MEMBER (',
'    p_collection_name   => ''COL_VTAS_OC_CONF'',',
'    p_seq               => :SEQ_ID,',
'    p_c001              => :VALOR,',
'    p_c002              => :COLUMNA,',
'    p_c003              => :FORMULA);',
'end;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>115286641531981801
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(115287851806981813)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(114865248788138216)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Mapeo Detalle de Orden - Save Interactive Grid Data'
,p_process_sql_clob=>'pk_vtas_pedidos.sp_actualizamapeoconfig(P_ID => :ID, P_COLUMNA => :COLUMNA, P_FORMULA => :FORMULA);'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,CREATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>115287851806981813
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(17970877144534698189)
,p_process_sequence=>25
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Convertir PDF a Excel de mapeo'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    DATA.PK_VTAS_OC_PDF.SP_CONVERTIR_PDF_MAPEO(',
'        P_IDCONFIG => :P601_ID,',
'        P_ARCHIVO  => :P601_PDF_MAPEO,',
'        P_USUARIO  => :APP_USER',
'    );',
'    :P601_PDF_MAPEO := NULL;',
'EXCEPTION',
'    WHEN OTHERS THEN',
'        RAISE_APPLICATION_ERROR(-20100, ''Error al convertir PDF a Excel para mapeo: '' || SQLERRM);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(29391521649605884380)
,p_process_success_message=>'PDF convertido a Excel correctamente.'
,p_internal_uid=>114889950138166113
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(114889950138166113)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Process form Datos Configuraci\00F3n Pedido')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'V_RESULTADO NUMBER;',
'BEGIN',
'pk_vtas_pedidos.sp_guardaconfigordencompra(',
'    P_ID => :P601_ID, P_CODIGOCLIENTE => :P601_CODIGOGRUPO, ',
'    P_CODIGOGRUPO => :P601_CODIGOGRUPO, P_TIPOARCHIVO => :P601_TIPOARCHIVO, ',
'    P_SEPARADOR => :P601_SEPARADOR, P_INICIOFILADETALLE => :P601_INICIOFILADETALLE,',
'    P_FILA_OC => :P601_FILA_OC, P_COLUMNA_OC => :P601_COLUMNA_OC, ',
'    P_FORMATO_NUM => :P601_FORMATO_NUM, P_TIPOUNIDAD => :P601_TIPOUNIDAD, ',
'    P_ESTADO => 1, P_EJECUTIVO => :P601_IDENTIFICACION, ',
'    P_COMPANIA => :G_COMPANIA,',
'    P_RESULTADO => V_RESULTADO',
');',
'',
'IF V_RESULTADO = 1 THEN',
'    pk_vtas_pedidos.sp_crearmapeoconfig(P_ID_CABECERA => :P601_ID);',
'',
'    ',
'END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error al guardar'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_process_success_message=>unistr('Se ha guardado con \00E9xito')
,p_internal_uid=>114889950138166113
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(114890367896166113)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(114886986213166109)
,p_internal_uid=>114890367896166113
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(17970877144534698190)
,p_process_sequence=>5
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Acciones Excel mapeo OC'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'DECLARE',
'    V_BLOB     FILES.T_APEX_ARCHIVOS.BLOBCONTENT%TYPE;',
'    V_FILENAME FILES.T_APEX_ARCHIVOS.FILENAME%TYPE;',
'    V_MIME     FILES.T_APEX_ARCHIVOS.MIMETYPE%TYPE;',
'BEGIN',
'    IF V(''REQUEST'') = ''ELIMINAR_EXCEL_MAPEO'' AND :P601_ARCHIVO_ELIMINAR IS NOT NULL THEN',
'        DATA.PK_VTAS_OC_PDF.SP_ELIMINAR_EXCEL_MAPEO(',
'            P_IDCONFIG      => :P601_ID,',
'            P_NUMEROARCHIVO => TO_NUMBER(:P601_ARCHIVO_ELIMINAR)',
'        );',
'        :P601_ARCHIVO_ELIMINAR := NULL;',
'        APEX_APPLICATION.G_PRINT_SUCCESS_MESSAGE := ''Excel eliminado correctamente.'';',
'    ELSIF V(''REQUEST'') = ''DESCARGAR_EXCEL_MAPEO'' AND :P601_ARCHIVO_DESCARGAR IS NOT NULL THEN',
'        SELECT BLOBCONTENT, FILENAME, MIMETYPE',
'          INTO V_BLOB, V_FILENAME, V_MIME',
'          FROM FILES.T_APEX_ARCHIVOS',
'         WHERE NUMEROARCHIVO = TO_NUMBER(:P601_ARCHIVO_DESCARGAR)',
'           AND TABLA = ''T_VTAS_PEDIDO_CONF_OC''',
'           AND ID_TABLA = TO_CHAR(:P601_ID)',
'           AND TIPO = ''OC_MAPEO_EXCEL'';',
'',
'        OWA_UTIL.MIME_HEADER(NVL(V_MIME, ''application/vnd.openxmlformats-officedocument.spreadsheetml.sheet''), FALSE);',
'        HTP.P(''Content-Disposition: attachment; filename="'' || REPLACE(V_FILENAME, ''"'', '''') || ''"'');',
'        HTP.P(''Content-Length: '' || DBMS_LOB.GETLENGTH(V_BLOB));',
'        OWA_UTIL.HTTP_HEADER_CLOSE;',
'        WPG_DOCLOAD.DOWNLOAD_FILE(V_BLOB);',
'        APEX_APPLICATION.STOP_APEX_ENGINE;',
'    END IF;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>114889950138166113
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(114889575127166113)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Initialize form Datos Configuraci\00F3n Pedido')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'V_QUERY VARCHAR2(100);',
'BEGIN',
unistr('IF :P601_ID IS NOT NULL THEN--ES CREACI\00D3N DE NUEVA CONFIG'),
'SELECT',
'CODIGOGRUPO,',
'TIPOARCHIVO,',
'SEPARADOR,',
'INICIOFILADETALLE,',
'substr(POSICION_OC,1,instr(POSICION_OC,'';'')-1),',
'substr(POSICION_OC,instr(POSICION_OC,'';'')+1),',
'FORMATO_NUM,',
'TIPOUNIDAD,',
'ESTADO',
'INTO',
':P601_CODIGOGRUPO,',
':P601_TIPOARCHIVO,',
':P601_SEPARADOR,',
':P601_INICIOFILADETALLE,',
':P601_FILA_OC,',
':P601_COLUMNA_OC,',
':P601_FORMATO_NUM,',
':P601_TIPOUNIDAD,',
':P601_ESTADO',
'FROM T_VTAS_PEDIDO_CONF_OC WHERE ID = :P601_ID;',
'',
'ELSE',
'    V_QUERY := ''select id_tabla from t_corp_udc where id_cabecera = ''''VTAS_POCMP'''' and activo = ''''1'''' '';',
'    APEX_COLLECTION.CREATE_COLLECTION_FROM_QUERY (',
'        p_collection_name       => ''COL_VTAS_OC_CONF'', ',
'        p_query                 => V_QUERY,',
'        p_truncate_if_exists    => ''YES'');',
'END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>114889575127166113
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
