prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 100 - Portales
--
-- Application Export:
--   Application:     100
--   Name:            Portales
--   Date and Time:   10:03 Monday July 13, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 300
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_00300
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>300);
end;
/
prompt --application/pages/page_00300
begin
wwv_flow_imp_page.create_page(
 p_id=>300
,p_name=>'Dlg Excel a Tabla'
,p_page_mode=>'MODAL'
,p_step_title=>'Excel a Tabla'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.apex-item-file {',
'    opacity: 1 !important;',
'    border: 1px solid #ccced1;',
'}'))
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(154141940427475444)
,p_plug_name=>'Formulario'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(43042879882535456)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(286679594544312604)
,p_plug_name=>'Datos'
,p_parent_plug_id=>wwv_flow_imp.id(154141940427475444)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(43042879882535456)
,p_plug_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(286861270886020522)
,p_plug_name=>'Botones'
,p_parent_plug_id=>wwv_flow_imp.id(154141940427475444)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(55899395327902964)
,p_plug_display_sequence=>50
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(287056552042023615)
,p_plug_name=>'Resultado'
,p_parent_plug_id=>wwv_flow_imp.id(154141940427475444)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(42941718074431964)
,p_plug_display_sequence=>40
,p_query_type=>'TABLE'
,p_query_table=>'VT_APEX_EXCEL'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(287078556151054817)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>300
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>287078556151054817
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287078793129054819)
,p_db_column_name=>'C01'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'&P300_C0_1.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287078835663054820)
,p_db_column_name=>'C02'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'&P300_C0_2.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287078944699054821)
,p_db_column_name=>'C03'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'&P300_C0_3.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287079081881054822)
,p_db_column_name=>'C04'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'&P300_C0_4.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287079135736054823)
,p_db_column_name=>'C05'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'&P300_C0_5.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287079247003054824)
,p_db_column_name=>'C06'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'&P300_C0_6.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287079379511054825)
,p_db_column_name=>'C07'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'&P300_C0_7.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287079431578054826)
,p_db_column_name=>'C08'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'&P300_C0_8.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287079515418054827)
,p_db_column_name=>'C09'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'&P300_C0_9.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287079609499054828)
,p_db_column_name=>'C10'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'&P300_C0_10.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287079783411054829)
,p_db_column_name=>'C11'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'&P300_C0_11.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287079899121054830)
,p_db_column_name=>'C12'
,p_display_order=>130
,p_column_identifier=>'L'
,p_column_label=>'&P300_C0_12.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287079994217054831)
,p_db_column_name=>'C13'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>'&P300_C0_13.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287080052770054832)
,p_db_column_name=>'C14'
,p_display_order=>150
,p_column_identifier=>'N'
,p_column_label=>'&P300_C0_14.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287080136218054833)
,p_db_column_name=>'C15'
,p_display_order=>160
,p_column_identifier=>'O'
,p_column_label=>'&P300_C0_15.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287080209806054834)
,p_db_column_name=>'C16'
,p_display_order=>170
,p_column_identifier=>'P'
,p_column_label=>'&P300_C0_16.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287080366408054835)
,p_db_column_name=>'C17'
,p_display_order=>180
,p_column_identifier=>'Q'
,p_column_label=>'&P300_C0_17.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287080448715054836)
,p_db_column_name=>'C18'
,p_display_order=>190
,p_column_identifier=>'R'
,p_column_label=>'&P300_C0_18.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287080591886054837)
,p_db_column_name=>'C19'
,p_display_order=>200
,p_column_identifier=>'S'
,p_column_label=>'&P300_C0_19.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287080694203054838)
,p_db_column_name=>'C20'
,p_display_order=>210
,p_column_identifier=>'T'
,p_column_label=>'&P300_C0_20.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287080744639054839)
,p_db_column_name=>'C21'
,p_display_order=>220
,p_column_identifier=>'U'
,p_column_label=>'C21'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287080873632054840)
,p_db_column_name=>'C22'
,p_display_order=>230
,p_column_identifier=>'V'
,p_column_label=>'C22'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287080933903054841)
,p_db_column_name=>'C23'
,p_display_order=>240
,p_column_identifier=>'W'
,p_column_label=>'C23'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287081025554054842)
,p_db_column_name=>'C24'
,p_display_order=>250
,p_column_identifier=>'X'
,p_column_label=>'C24'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287081153620054843)
,p_db_column_name=>'C25'
,p_display_order=>260
,p_column_identifier=>'Y'
,p_column_label=>'C25'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287081262541054844)
,p_db_column_name=>'C26'
,p_display_order=>270
,p_column_identifier=>'Z'
,p_column_label=>'C26'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287081300207054845)
,p_db_column_name=>'C27'
,p_display_order=>280
,p_column_identifier=>'AA'
,p_column_label=>'C27'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287081413872054846)
,p_db_column_name=>'C28'
,p_display_order=>290
,p_column_identifier=>'AB'
,p_column_label=>'C28'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287081556761054847)
,p_db_column_name=>'C29'
,p_display_order=>300
,p_column_identifier=>'AC'
,p_column_label=>'C29'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287081619014054848)
,p_db_column_name=>'C30'
,p_display_order=>310
,p_column_identifier=>'AD'
,p_column_label=>'C30'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287081724750054849)
,p_db_column_name=>'C31'
,p_display_order=>320
,p_column_identifier=>'AE'
,p_column_label=>'C31'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287081869219054850)
,p_db_column_name=>'C32'
,p_display_order=>330
,p_column_identifier=>'AF'
,p_column_label=>'C32'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287129611182341801)
,p_db_column_name=>'C33'
,p_display_order=>340
,p_column_identifier=>'AG'
,p_column_label=>'C33'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287129723772341802)
,p_db_column_name=>'C34'
,p_display_order=>350
,p_column_identifier=>'AH'
,p_column_label=>'C34'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287129885677341803)
,p_db_column_name=>'C35'
,p_display_order=>360
,p_column_identifier=>'AI'
,p_column_label=>'C35'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287129960378341804)
,p_db_column_name=>'C36'
,p_display_order=>370
,p_column_identifier=>'AJ'
,p_column_label=>'C36'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287130046763341805)
,p_db_column_name=>'C37'
,p_display_order=>380
,p_column_identifier=>'AK'
,p_column_label=>'C37'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287130183906341806)
,p_db_column_name=>'C38'
,p_display_order=>390
,p_column_identifier=>'AL'
,p_column_label=>'C38'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287130257715341807)
,p_db_column_name=>'C39'
,p_display_order=>400
,p_column_identifier=>'AM'
,p_column_label=>'C39'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287130351234341808)
,p_db_column_name=>'C40'
,p_display_order=>410
,p_column_identifier=>'AN'
,p_column_label=>'C40'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287130479046341809)
,p_db_column_name=>'C41'
,p_display_order=>420
,p_column_identifier=>'AO'
,p_column_label=>'C41'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287130570986341810)
,p_db_column_name=>'C42'
,p_display_order=>430
,p_column_identifier=>'AP'
,p_column_label=>'C42'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287130635176341811)
,p_db_column_name=>'C43'
,p_display_order=>440
,p_column_identifier=>'AQ'
,p_column_label=>'C43'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287130733983341812)
,p_db_column_name=>'C44'
,p_display_order=>450
,p_column_identifier=>'AR'
,p_column_label=>'C44'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287130820701341813)
,p_db_column_name=>'C45'
,p_display_order=>460
,p_column_identifier=>'AS'
,p_column_label=>'C45'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287130957169341814)
,p_db_column_name=>'C46'
,p_display_order=>470
,p_column_identifier=>'AT'
,p_column_label=>'C46'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287131065056341815)
,p_db_column_name=>'C47'
,p_display_order=>480
,p_column_identifier=>'AU'
,p_column_label=>'C47'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287131167040341816)
,p_db_column_name=>'C48'
,p_display_order=>490
,p_column_identifier=>'AV'
,p_column_label=>'C48'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287131246540341817)
,p_db_column_name=>'C49'
,p_display_order=>500
,p_column_identifier=>'AW'
,p_column_label=>'C49'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(287131347207341818)
,p_db_column_name=>'C50'
,p_display_order=>510
,p_column_identifier=>'AX'
,p_column_label=>'C50'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(156846013739939702)
,p_db_column_name=>'ID'
,p_display_order=>520
,p_column_identifier=>'AY'
,p_column_label=>'#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(287165436866355618)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2871655'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>1000
,p_report_columns=>'C01:C02:C03:C04:C05:C06:C07:C08:C09:C10:C11:C12:C13:C14:C15:C16:C17:C18:C19:C20:C21:C22:C23:C24:C25:C26:C27:C28:C29:C30:C31:C32:C33:C34:C35:C36:C37:C38:C39:C40:C41:C42:C43:C44:C45:C46:C47:C48:C49:C50:'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(286861331768020523)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(286861270886020522)
,p_button_name=>'CARGAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(42995151985432000)
,p_button_image_alt=>'Cargar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_button_condition=>':P300_PAGINA IS NULL OR :P300_APP IS NULL'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(287133577163341840)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(286861270886020522)
,p_button_name=>'SIGUIENTE'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(42995151985432000)
,p_button_image_alt=>'Siguiente'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&P300_APP.:&P300_PAGINA.:&SESSION.::&DEBUG.:RP::'
,p_button_condition=>':P300_PAGINA IS NOT NULL AND :P300_APP IS NOT NULL'
,p_button_condition2=>'SQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(154142031242475445)
,p_name=>'P300_TIPO'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_item_default=>'1'
,p_prompt=>'Tipo:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2(,):.XLS,.XLSX1.CSV2'
,p_cHeight=>1
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(42994453618432000)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(154142256765475447)
,p_name=>'P300_SEPARADOR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_prompt=>'Separador:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(42994453618432000)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171253229802723501)
,p_name=>'P300_CABECERA'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(286679647279312605)
,p_name=>'P300_ARCHIVO'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_prompt=>'Archivo:'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(42994453618432000)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'U'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'NATIVE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(286898604251042144)
,p_name=>'P300_CARGA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287023579311975644)
,p_name=>'P300_C0'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287023600419975645)
,p_name=>'P300_C0_1'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287023764633975646)
,p_name=>'P300_C0_2'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287023857205975647)
,p_name=>'P300_C0_3'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287023991375975648)
,p_name=>'P300_C0_4'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287024064633975649)
,p_name=>'P300_C0_5'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287024111576975650)
,p_name=>'P300_C0_6'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287055178897023601)
,p_name=>'P300_C0_7'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287055261177023602)
,p_name=>'P300_C0_8'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287055324108023603)
,p_name=>'P300_C0_9'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287055455068023604)
,p_name=>'P300_C0_10'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287055535466023605)
,p_name=>'P300_C0_11'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287055687913023606)
,p_name=>'P300_C0_12'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287055791774023607)
,p_name=>'P300_C0_13'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287055812424023608)
,p_name=>'P300_C0_14'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287055991056023609)
,p_name=>'P300_C0_15'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287056098802023610)
,p_name=>'P300_C0_16'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287056182919023611)
,p_name=>'P300_C0_17'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287056203045023612)
,p_name=>'P300_C0_18'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287056370252023613)
,p_name=>'P300_C0_19'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287056430161023614)
,p_name=>'P300_C0_20'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287133382461341838)
,p_name=>'P300_APP'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(287133414219341839)
,p_name=>'P300_PAGINA'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(286679594544312604)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(286898720210042145)
,p_computation_sequence=>10
,p_computation_item=>'P300_CARGA'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'1'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(286825158872668509)
,p_name=>'Actualizar'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P300_ARCHIVO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(286825227100668510)
,p_event_id=>wwv_flow_imp.id(286825158872668509)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(154142362229475448)
,p_name=>'Cambiar Tipo'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P300_TIPO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(154142417157475449)
,p_event_id=>wwv_flow_imp.id(154142362229475448)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P300_SEPARADOR'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P300_TIPO'
,p_client_condition_expression=>'1'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(154142596150475450)
,p_event_id=>wwv_flow_imp.id(154142362229475448)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P300_SEPARADOR'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P300_TIPO'
,p_client_condition_expression=>'2'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(286896808177042126)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    V_HOJA varchar2(1000);',
'    v_blob BLOB;',
'    v_clob CLOB;',
'    v_query clob;',
'    v_query2 clob;',
'    v_file_clob clob;',
'    v_file_size integer := dbms_lob.lobmaxsize;',
'    v_dest_offset integer := 1;',
'    v_src_offset integer := 1;',
'    v_blob_csid number := dbms_lob.default_csid;',
'    v_lang_context number := dbms_lob.default_lang_ctx;',
'    v_warning integer;',
'    v_length number;',
'    l_vc_arr2    APEX_APPLICATION_GLOBAL.VC_ARR2;',
'    v_nombre varchar2(1000);',
'    v_mime varchar2(1000);',
'    v_archivo_id number;',
'    v_url varchar2(2000);',
'    v_payload clob;',
'    v_respuesta clob;',
'    v_exito varchar2(20);',
'    v_mensaje varchar2(4000);',
'    v_carga_texto boolean := false;',
'',
'    PROCEDURE SP_AGREGAR_LINEA(P_TEXTO IN VARCHAR2, P_NUMERO IN PLS_INTEGER, P_SEPARADOR IN VARCHAR2) IS',
'        v_campos APEX_APPLICATION_GLOBAL.VC_ARR2;',
'    BEGIN',
'        v_campos := APEX_UTIL.STRING_TO_TABLE(P_TEXTO, P_SEPARADOR);',
'        APEX_COLLECTION.ADD_MEMBER(',
'            P_COLLECTION_NAME => ''TABLA_EXCEL'', P_C001 => TO_CHAR(P_NUMERO),',
'            P_C002 => v_campos(1), P_C003 => v_campos(2), P_C004 => v_campos(3), P_C005 => v_campos(4), P_C006 => v_campos(5),',
'            P_C007 => v_campos(6), P_C008 => v_campos(7), P_C009 => v_campos(8), P_C010 => v_campos(9), P_C011 => v_campos(10),',
'            P_C012 => v_campos(11), P_C013 => v_campos(12), P_C014 => v_campos(13), P_C015 => v_campos(14), P_C016 => v_campos(15),',
'            P_C017 => v_campos(16), P_C018 => v_campos(17), P_C019 => v_campos(18), P_C020 => v_campos(19), P_C021 => v_campos(20),',
'            P_C022 => v_campos(21), P_C023 => v_campos(22), P_C024 => v_campos(23), P_C025 => v_campos(24), P_C026 => v_campos(25),',
'            P_C027 => v_campos(26), P_C028 => v_campos(27), P_C029 => v_campos(28), P_C030 => v_campos(29), P_C031 => v_campos(30),',
'            P_C032 => v_campos(31), P_C033 => v_campos(32), P_C034 => v_campos(33), P_C035 => v_campos(34), P_C036 => v_campos(35),',
'            P_C037 => v_campos(36), P_C038 => v_campos(37), P_C039 => v_campos(38), P_C040 => v_campos(39), P_C041 => v_campos(40),',
'            P_C042 => v_campos(41), P_C043 => v_campos(42), P_C044 => v_campos(43), P_C045 => v_campos(44), P_C046 => v_campos(45),',
'            P_C047 => v_campos(46), P_C048 => v_campos(47), P_C049 => v_campos(48), P_C050 => v_campos(49));',
'    END SP_AGREGAR_LINEA;',
'begin',
'',
'    IF  APEX_COLLECTION.COLLECTION_EXISTS (p_collection_name => ''TABLA_EXCEL'') THEN',
'        APEX_COLLECTION.DELETE_COLLECTION(p_collection_name => ''TABLA_EXCEL'');',
'    END IF;',
'',
'    IF(:P300_TIPO=1) THEN --- EXCEL',
'        SELECT blob_content, filename, mime_type',
'          INTO v_blob, v_nombre, v_mime',
'          FROM apex_application_temp_files',
'         WHERE name = :P300_ARCHIVO',
'           AND ROWNUM = 1;',
'',
'        -- XLS legado: no es ZIP, se reconoce por extensión y firma OLE.',
'        IF LOWER(v_nombre) LIKE ''%.xls''',
'           AND RAWTOHEX(DBMS_LOB.SUBSTR(v_blob, 8, 1)) = ''D0CF11E0A1B11AE1'' THEN',
'            BEGIN',
'                DATA.PK_APEX_ARCHIVOS.SP_CREARARCHIVOMANUAL(',
'                    P_ARCHIVO       => v_blob,',
'                    P_ARCHIVONOMBRE => v_nombre,',
'                    P_ARCHIVOTYPE   => v_mime,',
'                    P_RIDE          => NULL,',
'                    P_TABLA         => ''APEX_TEMP_CONVERSION'',',
'                    P_IDTABLA       => :P300_ARCHIVO,',
'                    P_TIPO          => ''EXCEL_CSV'',',
'                    P_OBSERVACION   => ''CONVERSION_XLS_CSV'',',
'                    P_USUARIO       => :APP_USER,',
'                    P_NUMEROARCHIVO => v_archivo_id',
'                );',
'                COMMIT;',
'                -- ID existente de configuración: la URL varía por ambiente.',
'                SELECT valor INTO v_url',
'                  FROM data.t_corp_udc',
'                 WHERE id_cabecera = ''WEBSERVICE'' AND id_tabla = ''17'' AND activo = ''1'';',
'                SELECT JSON_OBJECT(''numeroArchivo'' VALUE v_archivo_id, ''numeroHoja'' VALUE 0,',
'                       ''usuario'' VALUE :APP_USER RETURNING CLOB) INTO v_payload FROM dual;',
'                APEX_WEB_SERVICE.G_REQUEST_HEADERS.DELETE;',
'                APEX_WEB_SERVICE.G_REQUEST_HEADERS(1).NAME := ''Content-Type'';',
'                APEX_WEB_SERVICE.G_REQUEST_HEADERS(1).VALUE := ''application/json'';',
'                v_respuesta := APEX_WEB_SERVICE.MAKE_REST_REQUEST(',
'                    P_URL => v_url, P_HTTP_METHOD => ''POST'', P_BODY => v_payload);',
'                v_exito := JSON_VALUE(v_respuesta, ''$.exito'' RETURNING VARCHAR2 DEFAULT ''false'' ON ERROR);',
'                v_mensaje := JSON_VALUE(v_respuesta, ''$.mensaje'' RETURNING VARCHAR2 NULL ON ERROR);',
'                IF NVL(LOWER(v_exito), ''false'') NOT IN (''true'', ''1'') THEN',
'                    RAISE_APPLICATION_ERROR(-20100, ''No se pudo convertir el Excel XLS a CSV. '' ||',
'                        NVL(v_mensaje, DBMS_LOB.SUBSTR(v_respuesta, 3500, 1)));',
'                END IF;',
'                SELECT blobcontent INTO v_blob FROM files.t_apex_archivos',
'                 WHERE numeroarchivo = v_archivo_id;',
'                DBMS_LOB.CREATETEMPORARY(v_clob, TRUE);',
'                DBMS_LOB.CONVERTTOCLOB(v_clob, v_blob, v_file_size, v_dest_offset,',
'                    v_src_offset, v_blob_csid, v_lang_context, v_warning);',
'                APEX_COLLECTION.CREATE_COLLECTION(''TABLA_EXCEL'');',
'                FOR line IN (',
'                    SELECT REGEXP_SUBSTR(v_clob, ''[^''||CHR(10)||CHR(13)||'']+'', 1, LEVEL) AS line, rownum numero',
'                      FROM dual',
'                    CONNECT BY LEVEL <= REGEXP_COUNT(v_clob, ''[^''||CHR(10)||CHR(13)||'']+'')',
'                ) LOOP',
'                    SP_AGREGAR_LINEA(line.line, line.numero, '','');',
'                END LOOP;',
'                DBMS_LOB.FREETEMPORARY(v_clob);',
'                v_carga_texto := true;',
'                DATA.PK_APEX_ARCHIVOS.SP_ELIMINAARCHIVO(v_archivo_id);',
'            EXCEPTION',
'                WHEN OTHERS THEN',
'                    IF v_archivo_id IS NOT NULL THEN',
'                        DATA.PK_APEX_ARCHIVOS.SP_ELIMINAARCHIVO(v_archivo_id);',
'                    END IF;',
'                    IF DBMS_LOB.ISTEMPORARY(v_clob) = 1 THEN',
'                        DBMS_LOB.FREETEMPORARY(v_clob);',
'                    END IF;',
'                    RAISE;',
'            END;',
'        ELSE',
'            -- XLSX: se conserva la lectura existente.',
'            SELECT column_value INTO V_HOJA FROM TABLE(',
'                PK_APEX_XLS.get_worksheets(p_xlsx_name => :P300_ARCHIVO)) WHERE ROWNUM=1;',
'            V_QUERY := ''SELECT * FROM table(',
'                        PK_APEX_XLS.parse(',
'                            p_xlsx_name      => ''''''||:P300_ARCHIVO||'''''',',
'                            p_worksheet_name => ''''''||''sheet1''||''''''',
'                        ))'';',
'        END IF;',
'    ELSE -- .CSV',
'',
'        SELECT blob_content INTO v_blob FROM APEX_APPLICATION_TEMP_FILES WHERE name =:P300_ARCHIVO AND ROWNUM=1;',
'        -- Convert BLOB to CLOB (assuming the CSV file is encoded in UTF-8)',
'        DBMS_LOB.CREATETEMPORARY(v_clob, TRUE);',
'        DBMS_LOB.CONVERTTOCLOB(v_clob, v_blob, v_file_size,v_dest_offset,v_src_offset,v_blob_csid,v_lang_context,v_warning);',
'        APEX_COLLECTION.CREATE_COLLECTION(''TABLA_EXCEL'');',
'',
unistr('        -- Dividir la cadena en l\00EDneas Para recorrer las lineas'),
'         ',
'        FOR line IN (SELECT REGEXP_SUBSTR(v_clob, ''[^''||CHR(10)||CHR(13)||'']+'', 1, LEVEL) AS line, rownum numero',
'                     FROM dual',
'                     CONNECT BY LEVEL <= REGEXP_COUNT(v_clob, ''[^''||CHR(10)||CHR(13)||'']+''))',
'        LOOP',
'            SP_AGREGAR_LINEA(line.line, line.numero, :P300_SEPARADOR);',
'        ',
'        end loop;',
'        ',
'        -- Liberar el CLOB temporal',
'        DBMS_LOB.FREETEMPORARY(v_clob);',
'        v_carga_texto := true;',
'    END IF;  ',
'',
'    IF NOT v_carga_texto THEN',
'    APEX_COLLECTION.CREATE_COLLECTION_FROM_QUERY (',
'            p_collection_name => ''TABLA_EXCEL'', ',
'            p_query => V_QUERY,',
'            p_generate_md5 => ''YES'');',
'    END IF;',
'            ',
'    SELECT NVL(C01,''C01''),NVL(C02,''C02''),NVL(C03,''C03''),NVL(C04,''C04''),NVL(C05,''C05''),NVL(C06,''C06''),NVL(C07,''C07''),NVL(C08,''C08''),NVL(C09,''C09''),NVL(C10,''C10''),',
'               NVL(C11,''C11''),NVL(C12,''C12''),NVL(C13,''C13''),NVL(C14,''C14''),NVL(C15,''C15''),NVL(C16,''C16''),NVL(C17,''C17''),NVL(C18,''C18''),NVL(C19,''C19''),NVL(C20,''C20'')',
'    INTO',
'        :P300_C0_1,:P300_C0_2,:P300_C0_3,:P300_C0_4,:P300_C0_5,:P300_C0_6,:P300_C0_7,:P300_C0_8,:P300_C0_9,:P300_C0_10,',
'        :P300_C0_11,:P300_C0_12,:P300_C0_13,:P300_C0_14,:P300_C0_15,:P300_C0_16,:P300_C0_17,:P300_C0_18,:P300_C0_19,:P300_C0_20',
'    FROM VT_APEX_EXCEL where ID =1;',
'        ',
'        ',
'    IF(NVL(:P300_CABECERA, 1) = 1 ) THEN  ',
'      ',
'',
'        SELECT NVL(C01,''C01''),NVL(C02,''C02''),NVL(C03,''C03''),NVL(C04,''C04''),NVL(C05,''C05''),NVL(C06,''C06''),NVL(C07,''C07''),NVL(C08,''C08''),NVL(C09,''C09''),NVL(C10,''C10''),',
'               NVL(C11,''C11''),NVL(C12,''C12''),NVL(C13,''C13''),NVL(C14,''C14''),NVL(C15,''C15''),NVL(C16,''C16''),NVL(C17,''C17''),NVL(C18,''C18''),NVL(C19,''C19''),NVL(C20,''C20'')',
'        INTO',
'            :P300_C0_1,:P300_C0_2,:P300_C0_3,:P300_C0_4,:P300_C0_5,:P300_C0_6,:P300_C0_7,:P300_C0_8,:P300_C0_9,:P300_C0_10,',
'            :P300_C0_11,:P300_C0_12,:P300_C0_13,:P300_C0_14,:P300_C0_15,:P300_C0_16,:P300_C0_17,:P300_C0_18,:P300_C0_19,:P300_C0_20',
'        FROM VT_APEX_EXCEL where ID =1;',
'',
'         APEX_COLLECTION.DELETE_MEMBER(',
'        p_collection_name => ''TABLA_EXCEL'',',
'        p_seq => ''1'');',
'',
'    ELSE ',
'',
'        SELECT ''C01'',''C02'',''C03'',''C04'',''C05'',''C06'',''C07'',''C08'',''C09'',''C10'',',
'               ''C11'',''C12'',''C13'',''C14'',''C15'',''C16'',''C17'',''C18'',''C19'',''C20''',
'        INTO',
'            :P300_C0_1,:P300_C0_2,:P300_C0_3,:P300_C0_4,:P300_C0_5,:P300_C0_6,:P300_C0_7,:P300_C0_8,:P300_C0_9,:P300_C0_10,',
'            :P300_C0_11,:P300_C0_12,:P300_C0_13,:P300_C0_14,:P300_C0_15,:P300_C0_16,:P300_C0_17,:P300_C0_18,:P300_C0_19,:P300_C0_20',
'        FROM VT_APEX_EXCEL where ID =1;',
'    ',
'    END IF;   ',
'',
'End;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P300_ARCHIVO'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>286896808177042126
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(286896923445042127)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Cerra dialogo'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(286861331768020523)
,p_internal_uid=>286896923445042127
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(295188249043697647)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar datos url'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P300_PAGINA := :G_PAGINA;',
':P300_APP := :G_MODULO;',
':P300_CABECERA := :G_VALOR1;',
':P300_TIPO:= :G_VALOR2;',
':P300_SEPARADOR := :G_VALOR3;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>295188249043697647
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(286898816533042146)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Inicializar carga'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF APEX_COLLECTION.COLLECTION_EXISTS(p_collection_name => ''TABLA_EXCEL'') THEN',
'    APEX_COLLECTION.DELETE_COLLECTION(p_collection_name => ''TABLA_EXCEL'');',
'END IF;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P300_CARGA'
,p_process_when_type=>'ITEM_IS_NULL'
,p_internal_uid=>286898816533042146
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
