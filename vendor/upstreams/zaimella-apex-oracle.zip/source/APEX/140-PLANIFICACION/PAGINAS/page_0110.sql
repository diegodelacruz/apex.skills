prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>140
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 140 - PLANIFICACION
--
-- Application Export:
--   Application:     140
--   Name:            PLANIFICACION
--   Date and Time:   14:15 Thursday August 6, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 110
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_00110
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>110);
end;
/
prompt --application/pages/page_00110
begin
wwv_flow_imp_page.create_page(
 p_id=>110
,p_name=>unistr('M\00E1quinas')
,p_alias=>unistr('M\00C1QUINAS')
,p_step_title=>unistr('M\00E1quinas')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(443468129875717513)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(535719775917545246)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(533583382097487435)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(533683083484487562)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(443468660579717518)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(535720157374545246)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(443469796767717529)
,p_plug_name=>unistr('Planificaci\00F3n Mensual')
,p_parent_plug_id=>wwv_flow_imp.id(443468660579717518)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(535718930294545243)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  IF :G_COMPANIA = ''00003'' THEN',
'    RETURN q''[SELECT NULL DIVISION, X.CODIGOMAQUINA, NVL(B."Descr", B."BinCode") NOMBRE,',
'                 X.EFICIENCIA, X.TURNOS, EXTRACT(DAY FROM X.FECHAHASTA)*2 TURNOS_MAX, X.HORASTURNO,',
'                 X.TURNOS*X.HORASTURNO CAPACIDAD, EXTRACT(DAY FROM X.FECHAHASTA)*2*24 CAPACIDAD_MAX,',
'                 X.PERSONAS, X.PERSONAS*X.GRUPOS TOTALPERSONAS, X.GRUPOS',
'            FROM T_PPLA_MAQUINAS X',
'            LEFT JOIN OBIN@HANA_PE B ON TRIM(B."BinCode") = TRIM(X.CODIGOMAQUINA)',
'           WHERE X.COMPANIA = ''00003''',
'             AND TO_NUMBER(TO_CHAR(X.FECHADESDE,''YYYY'')) = :P110_ANIO',
'             AND TO_NUMBER(TO_CHAR(X.FECHADESDE,''MM'')) = :P110_MES]'';',
'  END IF;',
'  RETURN q''[SELECT DIVISION, CODIGOMAQUINA, NOMBRE, EFICIENCIA, TURNOS, TURNOS_MAX, HORASTURNO,',
'                 CAPACIDAD, CAPACIDAD_MAX, PERSONAS, TOTALPERSONAS, GRUPOS',
'            FROM VT_PPLA_MAQUINAMES',
'           WHERE COMPANIA = ''00001'' AND ANIO = :P110_ANIO AND MES = :P110_MES]'';',
'END;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P110_ANIO,P110_MES'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Planificaci\00F3n Mensual')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(443469858753717530)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MALBAN'
,p_internal_uid=>443469858753717530
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(443469938136717531)
,p_db_column_name=>'DIVISION'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>unistr('Divisi\00F3n ')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(443470081530717532)
,p_db_column_name=>'CODIGOMAQUINA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>unistr('C\00F3digo')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(443470602133717538)
,p_db_column_name=>'TURNOS'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Turnos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(443470761810717539)
,p_db_column_name=>'HORASTURNO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Horas Turno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(443470893649717540)
,p_db_column_name=>'CAPACIDAD'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Capacidad Horas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(443470903724717541)
,p_db_column_name=>'EFICIENCIA'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Eficiencia'
,p_column_type=>'NUMBER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(443471003100717542)
,p_db_column_name=>'PERSONAS'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Personas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(443471121760717543)
,p_db_column_name=>'TOTALPERSONAS'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(630806761713619635)
,p_db_column_name=>'NOMBRE'
,p_display_order=>150
,p_column_identifier=>'P'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(630807059104619638)
,p_db_column_name=>'TURNOS_MAX'
,p_display_order=>180
,p_column_identifier=>'Q'
,p_column_label=>'Turnos Max'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(630807232848619640)
,p_db_column_name=>'CAPACIDAD_MAX'
,p_display_order=>200
,p_column_identifier=>'S'
,p_column_label=>'Capacidad Max'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(630807309184619641)
,p_db_column_name=>'GRUPOS'
,p_display_order=>210
,p_column_identifier=>'T'
,p_column_label=>'Grupos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(444535989885628709)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'4445360'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DIVISION:CODIGOMAQUINA:NOMBRE:TURNOS:HORASTURNO:CAPACIDAD:EFICIENCIA:TURNOS_MAX:CAPACIDAD_MAX:PERSONAS:GRUPOS:TOTALPERSONAS'
,p_sort_column_1=>'DIVISION'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'NOMBRE'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(443515356658990301)
,p_plug_name=>unistr('M\00E1quinas')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(535720918100545250)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(533583382097487435)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(533683083484487562)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(443468280740717514)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(443468129875717513)
,p_button_name=>'Subir'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(533682160901487559)
,p_button_image_alt=>'Cargar Excel'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:300:&SESSION.::&DEBUG.:300::'
,p_button_condition=>'TO_NUMBER(:P110_DIASMAXIMO)>TO_NUMBER(to_char(sysdate,''dd''))'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-box-arrow-out-north'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(443468308407717515)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(443468129875717513)
,p_button_name=>'Formato'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(533682160901487559)
,p_button_image_alt=>'Descargar Formato'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>unistr('#APP_FILES#Formato m\00E1quinas.xlsx')
,p_button_condition=>'TO_NUMBER(:P110_DIASMAXIMO)>TO_NUMBER(to_char(sysdate,''dd''))'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-box-arrow-out-south'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(443468447571717516)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(443468129875717513)
,p_button_name=>'Anterior'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(533682160901487559)
,p_button_image_alt=>'Mes Anterior'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-arrow-left-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(443468520387717517)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(443468129875717513)
,p_button_name=>'Siguiente'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(533682160901487559)
,p_button_image_alt=>'Mes Siguiente'
,p_button_alignment=>'RIGHT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(to_number(TO_CHAR(SYSDATE,''mm''))<>:P110_MES AND TO_CHAR(SYSDATE,''YYYY'')=:P110_ANIO)',
'--OR (to_number(TO_CHAR(SYSDATE,''mm''))=:P110_MES AND TO_CHAR(SYSDATE,''YYYY'')<:P110_ANIO)',
'OR (:P110_ANIO<to_number(TO_CHAR(SYSDATE,''YYYY'')))'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-arrow-right-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(443471466422717546)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(443468129875717513)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(533682160901487559)
,p_button_image_alt=>'Buscar'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'1=2'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(443468711704717519)
,p_name=>'P110_ANIO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(443468660579717518)
,p_prompt=>unistr('A\00F1o: ')
,p_source=>'TO_CHAR(SYSDATE,''YYYY'')'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_ANIOS2'
,p_lov=>'select to_char(sysdate,''yyyy'') + (level-2) d,to_char(sysdate,''yyyy'') + (level-2) r from dual connect by level <= 4'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(443468805454717520)
,p_name=>'P110_MES'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(443468660579717518)
,p_prompt=>'Mes: '
,p_source=>'TO_NUMBER(TO_CHAR(SYSDATE,''MM''))'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MESES_12'
,p_lov=>'select to_char(to_date(level,''MM''),''Month'') d, level r from dual connect by level <= 12'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(443469006600717522)
,p_name=>'P110_DIASMAXIMO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(443468660579717518)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(443469621126717528)
,p_name=>'P110_MENSAJE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(443468660579717518)
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_04=>'N'
,p_attribute_05=>'HTML_UNSAFE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(443469314706717525)
,p_name=>'Cierre dialogo subir archivo'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(443468280740717514)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(443469570159717527)
,p_event_id=>wwv_flow_imp.id(443469314706717525)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'Subir'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(461147473911639003)
,p_name=>'Cambiar fechas'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P110_MES,P110_ANIO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(461147588998639004)
,p_event_id=>wwv_flow_imp.id(461147473911639003)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(443469251792717524)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CARGA_DATOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT VALOR INTO :P110_DIASMAXIMO FROM T_CORP_UDC',
'WHERE ID_CABECERA=''PPLA_PARAM'' AND ID_TABLA=''PAR3'';',
'',
':P110_MENSAJE:='''';',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>443469251792717524
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(443471722914717549)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'MES_ATRAS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('-- Si es ENERO, resto uno a\00F1o y asigno 12 (diciembre) a mes'),
'IF :P110_MES=''1'' THEN',
'   :P110_MES:=12;',
'   :P110_ANIO:=:P110_ANIO-1;',
'  ELSE',
'    :P110_MES:=:P110_MES-1;',
'END IF;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(443468447571717516)
,p_internal_uid=>443471722914717549
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(443471872404717550)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'MES_ADELANTE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('-- Si es DICIEMBRE, sumo uno al a\00F1o y asigno 1 (enero) a mes'),
'IF :P110_MES=''12'' THEN',
'   :P110_MES:=1;',
'   :P110_ANIO:=:P110_ANIO+1;',
'  ELSE',
'    :P110_MES:=:P110_MES+1;',
'END IF;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(443468520387717517)
,p_internal_uid=>443471872404717550
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(461147224074639001)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Subir archivos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'   V_ERROR VARCHAR2(100) :='''';',
'',
'BEGIN',
'PK_PPLA_CONFIGURACION.SP_PROCESACARGAMAQUINA(:G_COMPANIA,:APP_USER,V_ERROR);',
':P110_MENSAJE:=V_ERROR;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(443468280740717514)
,p_internal_uid=>461147224074639001
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
