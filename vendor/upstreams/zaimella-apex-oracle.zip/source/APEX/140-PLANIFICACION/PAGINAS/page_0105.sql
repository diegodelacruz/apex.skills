prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>140
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 140 - PLANIFICACION
--
-- Application Export:
--   Application:     140
--   Name:            PLANIFICACION
--   Date and Time:   14:14 Thursday August 6, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 105
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_00105
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>105);
end;
/
prompt --application/pages/page_00105
begin
wwv_flow_imp_page.create_page(
 p_id=>105
,p_name=>'Planificador Producto'
,p_alias=>'PLANIFICADOR-PRODUCTO'
,p_step_title=>'Planificador Producto'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(429205214546107302)
,p_plug_name=>'Contenedor'
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_imp.id(533636752386487514)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(429205316756107303)
,p_plug_name=>'Resumen'
,p_parent_plug_id=>wwv_flow_imp.id(429205214546107302)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(533628879219487509)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  IF :G_COMPANIA = ''00003'' THEN',
'    RETURN q''[SELECT ''HMORA'' NOMBRES, DIVISION_MANUFACTURA DIVMANUFACTURA, NULL CENTROTRABAJO, TIPOPRODUCTO, COUNT(*) CANT',
'                 FROM VT_GZM_PRODUCTO',
'                WHERE COMPANIA = ''00003'' AND ESTADO = 1',
'                GROUP BY DIVISION_MANUFACTURA, TIPOPRODUCTO]'';',
'  END IF;',
'  RETURN q''[SELECT NOMBRES,DIVMANUFACTURA,CENTROTRABAJO,TIPOPRODUCTO, COUNT(*) CANT',
'               FROM VT_PPLA_PRODUCTO_PLANIFICADOR',
'              WHERE COMPANIA = ''00001''',
'              GROUP BY NOMBRES,DIVMANUFACTURA,CENTROTRABAJO,TIPOPRODUCTO]'';',
'END;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Resumen'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(569391749865790221)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>569391749865790221
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(569391868493790222)
,p_db_column_name=>'NOMBRES'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Nombres'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(569391901900790223)
,p_db_column_name=>'DIVMANUFACTURA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Divmanufactura'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(569392067761790224)
,p_db_column_name=>'CENTROTRABAJO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Centrotrabajo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(569392202056790226)
,p_db_column_name=>'CANT'
,p_display_order=>40
,p_column_identifier=>'E'
,p_column_label=>'Cant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(569394116775790245)
,p_db_column_name=>'TIPOPRODUCTO'
,p_display_order=>50
,p_column_identifier=>'F'
,p_column_label=>'Tipo producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(599324097942707178)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5993241'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NOMBRES:TIPOPRODUCTO:DIVMANUFACTURA:CENTROTRABAJO:CANT:'
,p_sort_column_1=>'NOMBRES'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'TIPOPRODUCTO'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'DIVMANUFACTURA'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'CENTROTRABAJO'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_sum_columns_on_break=>'CANT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(429205447231107304)
,p_plug_name=>'Detalle'
,p_parent_plug_id=>wwv_flow_imp.id(429205214546107302)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(533628879219487509)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  IF :G_COMPANIA = ''00003'' THEN',
'    RETURN q''[SELECT CODIGOPRODUCTO, NOMBREPRODUCTO PRODUCTO, ''HMORA'' NOMBRES, LINEANEGOCIO, MARCA,',
'                 NULL CENTROTRABAJO, DIVISION_MANUFACTURA DIVMANUFACTURA, SUBMARCA, NULL MAQUINA, TIPOPRODUCTO',
'                 FROM VT_GZM_PRODUCTO',
'                WHERE COMPANIA = ''00003'' AND ESTADO = 1',
'                ORDER BY CODIGOPRODUCTO]'';',
'  END IF;',
'  RETURN q''[SELECT CODIGOPRODUCTO,X.PRODUCTO,NOMBRES,LINEANEGOCIO,MARCA,CENTROTRABAJO,DIVMANUFACTURA,SUBMARCA,MAQUINA,TIPOPRODUCTO',
'               FROM VT_PPLA_PRODUCTO_PLANIFICADOR X',
'              WHERE COMPANIA = ''00001''',
'              ORDER BY CODIGOPRODUCTO]'';',
'END;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Detalle'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(429206089398107310)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MALBAN'
,p_internal_uid=>429206089398107310
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(429206120308107311)
,p_db_column_name=>'CODIGOPRODUCTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>unistr('C\00F3digo producto')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(429206259968107312)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Nombre Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(429206385392107313)
,p_db_column_name=>'NOMBRES'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Nombre Planificador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(429206473956107314)
,p_db_column_name=>'LINEANEGOCIO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Linea de Negocio'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(429206588240107315)
,p_db_column_name=>'MARCA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Marca'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(429206643070107316)
,p_db_column_name=>'CENTROTRABAJO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Centro de Trabajo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(496735134242663146)
,p_db_column_name=>'DIVMANUFACTURA'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>unistr('Divisi\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(497547742853647303)
,p_db_column_name=>'SUBMARCA'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Submarca'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(497547885863647304)
,p_db_column_name=>'MAQUINA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Maquina'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(569394066165790244)
,p_db_column_name=>'TIPOPRODUCTO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Tipo producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(441702496154237366)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'4417025'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>1000
,p_report_columns=>'NOMBRES:TIPOPRODUCTO:DIVMANUFACTURA:CENTROTRABAJO:MAQUINA:CODIGOPRODUCTO:PRODUCTO:LINEANEGOCIO:MARCA:SUBMARCA:'
,p_sort_column_1=>'NOMBRES'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'TIPOPRODUCTO'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'DIVMANUFACTURA'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'CENTROTRABAJO'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(441685868928739228)
,p_plug_name=>'Planificador - Producto'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(535720918100545250)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(533583382097487435)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(533683083484487562)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(496735259036663147)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(429205447231107304)
,p_button_name=>'Subir'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(533682160901487559)
,p_button_image_alt=>'Subir'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:300:&SESSION.::&DEBUG.:300::'
,p_icon_css_classes=>'fa-box-arrow-out-north'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(496735448137663149)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(429205447231107304)
,p_button_name=>'Formato'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--pill'
,p_button_template_id=>wwv_flow_imp.id(533682160901487559)
,p_button_image_alt=>'Formato'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'#APP_FILES#Formato producto planificador.xlsx'
,p_icon_css_classes=>'fa-box-arrow-in-south'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(496735593550663150)
,p_name=>'Cierre dialogo subir archivo'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(496735259036663147)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(497547541129647301)
,p_event_id=>wwv_flow_imp.id(496735593550663150)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(497547632603647302)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Craga_EXCEL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'   V_ERROR  VARCHAR2(3000) :='''';',
'',
'BEGIN',
'-- proceso el archivo cargado',
'IF :G_COMPANIA = ''00003'' THEN',
'  apex_application.g_print_success_message := ''Perú utiliza el planificador general HMORA; no se actualizan productos en SAP.'';',
'ELSE',
'  PK_PPLA_CONFIGURACION.SP_PRODUCTOPLANIFICADOR(:G_COMPANIA,:APP_USER,V_ERROR);',
'END IF;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>unistr('Se carg\00F3 con \00E9xito.')
,p_internal_uid=>497547632603647302
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
