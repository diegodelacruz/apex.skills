prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>140
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 140 - PLANIFICACION
--
-- Application Export:
--   Application:     140
--   Name:            PLANIFICACION
--   Date and Time:   09:55 Wednesday July 29, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 1001
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_01001
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>1001);
end;
/
prompt --application/pages/page_01001
begin
wwv_flow_imp_page.create_page(
 p_id=>1001
,p_name=>unistr('Editar Par\00E1metros')
,p_alias=>unistr('EDITAR-PAR\00C1METROS')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Editar Par\00E1metros')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(450802490309118328)
,p_plug_name=>'Datos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(535720157374545246)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(450802848667118332)
,p_plug_name=>'Botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(535720515340545248)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(450802161501118325)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(450802848667118332)
,p_button_name=>'Cerrar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(533682248139487560)
,p_button_image_alt=>'Cerrar'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(450803124447118335)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(450802848667118332)
,p_button_name=>'Guardar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(533682248139487560)
,p_button_image_alt=>'Guardar'
,p_button_position=>'PREVIOUS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(450802694120118330)
,p_name=>'P1001_AGOTAMIENTO_MP'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(450802490309118328)
,p_prompt=>'Agotamiento MP $'
,p_source=>'TO_NUMBER(REPLACE(PK_ICOM_COMMONS.F_TRAERVALORUDC(''PPLA_PARAM'',''PAR13'',:G_COMPANIA),'','',''.''), ''999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' )'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'0'
,p_attribute_03=>'left'
,p_attribute_04=>'numeric'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(450802736372118331)
,p_name=>'P1001_INVERSION_MP'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(450802490309118328)
,p_prompt=>unistr('Inversi\00F3n MP $')
,p_source=>'TO_NUMBER(REPLACE(PK_ICOM_COMMONS.F_TRAERVALORUDC(''PPLA_PARAM'',''PAR14'',:G_COMPANIA),'','',''.''), ''999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' )'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'0'
,p_attribute_03=>'left'
,p_attribute_04=>'numeric'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(450803410632118338)
,p_validation_name=>'New'
,p_validation_sequence=>10
,p_validation=>':P1001_AGOTAMIENTO_MP IS NOT NULL'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('No puede ser vac\00EDo')
,p_associated_item=>wwv_flow_imp.id(450802694120118330)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(450803576463118339)
,p_validation_name=>'New_1'
,p_validation_sequence=>20
,p_validation=>':P1001_INVERSION_MP IS NOT NULL'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('No puede ser vac\00EDo')
,p_associated_item=>wwv_flow_imp.id(450802736372118331)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(450802200401118326)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(450802161501118325)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(450802307477118327)
,p_event_id=>wwv_flow_imp.id(450802200401118326)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(450803270561118336)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Guardar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'UPDATE T_CORP_UDC ',
'SET VALOR = :P1001_AGOTAMIENTO_MP ',
'WHERE ID_CABECERA = ''PPLA_PARAM'' AND ID_TABLA = ''PAR13'';',
'',
'UPDATE T_CORP_UDC ',
'SET VALOR = :P1001_INVERSION_MP ',
'WHERE ID_CABECERA = ''PPLA_PARAM'' AND ID_TABLA = ''PAR14'';',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>450803270561118336
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(450803316389118337)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Cerrar'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>450803316389118337
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
