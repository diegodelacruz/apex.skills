prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>140
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 140 - PLANIFICACION
--
-- Application Export:
--   Application:     140
--   Name:            PLANIFICACION
--   Date and Time:   11:11 Monday July 20, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 1000
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_01000
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>1000);
end;
/
prompt --application/pages/page_01000
begin
wwv_flow_imp_page.create_page(
 p_id=>1000
,p_name=>unistr('Reporte de variaci\00F3n mensual')
,p_alias=>'STOCK-IDEAL-MENSUAL'
,p_step_title=>unistr('Reporte de variaci\00F3n mensual')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function pplaUbicarEnlaceProductosNuevos() {',
'    var enlaceProductosNuevos = apex.jQuery(''a[href^="javascript:pplaMostrarProductosNuevos"]'').first();',
'    var tablaResumen = apex.jQuery(''#ppla_resumen .a-IRR'').first();',
'    if (enlaceProductosNuevos.length && tablaResumen.length) { enlaceProductosNuevos.insertBefore(tablaResumen); }',
'}',
'',
'function pplaMostrarVista(vista) {',
'    var tablaResumen = apex.jQuery(''#ppla_resumen .a-IRR'').first();',
'    var enlaceProductosNuevos = apex.jQuery(''a[href^="javascript:pplaMostrarProductosNuevos"]'').first();',
'    if (apex.item(''P1000_SOLO_NUEVOS'').getValue() !== ''S'') { apex.jQuery(''#P1000_NUEVOS_GRUPO_CONTAINER'').addClass(''u-hidden''); }',
'    tablaResumen.addClass(''u-hidden'');',
'    enlaceProductosNuevos.addClass(''u-hidden'');',
'    apex.jQuery(''#ppla_analisis_segmento, #ppla_detalle_stock, #ppla_ajuste_stock'').addClass(''u-hidden'');',
'    if (vista === ''RESUMEN'') { pplaUbicarEnlaceProductosNuevos(); tablaResumen.removeClass(''u-hidden''); enlaceProductosNuevos.removeClass(''u-hidden''); }',
'    if (vista === ''ANALISIS'') { apex.jQuery(''#ppla_analisis_segmento'').removeClass(''u-hidden''); }',
'    if (vista === ''DETALLE'') { apex.jQuery(''#ppla_detalle_stock, #ppla_ajuste_stock'').removeClass(''u-hidden''); }',
'}',
'',
'function pplaAbrirAnalisis(tipoProducto) {',
'    tipoProducto = tipoProducto.replace(/_/g, '' '');',
'    apex.item(''P1000_SOLO_NUEVOS'').setValue(''N'');',
'    apex.jQuery(''#P1000_NUEVOS_GRUPO_CONTAINER'').addClass(''u-hidden'');',
'    apex.item(''P1000_AGR_TIPO_PRODUCTO'').setValue(tipoProducto);',
'    apex.item(''P1000_AGR_TIPO_GRUPO'').setValue(tipoProducto === ''MATERIA PRIMA'' ? ''CATEGORIA_PLANIFICACION'' : ''LINEA_NEGOCIO'');',
'    apex.item(''P1000_AGR_GRUPO'').setValue('''');',
'    apex.item(''P1000_AJ_SKU'').setValue('''');',
'    apex.page.submit({request: ''PPLA_ANALISIS'', showWait: true});',
'}',
'',
'function pplaPrepararLinksResumen() {',
'    apex.jQuery(''#ppla_resumen a[href^="javascript:pplaAbrirAnalisis"]'').each(function () {',
'        var enlace = apex.jQuery(this);',
'        var texto = enlace.text().trim();',
'        if (!(/^Est.*ndar (MP|PT)$/.test(texto))) {',
'            enlace.replaceWith(apex.jQuery(''<span></span>'').text(enlace.text()));',
'        }',
'    });',
'}',
'',
'function pplaResaltarProductosNuevos() {',
'    apex.jQuery(''#ppla_detalle_stock .a-IRR-table tbody tr'').each(function () {',
'        var fila = apex.jQuery(this);',
'        if (fila.find(''td'').filter(function () { return apex.jQuery(this).text().trim() === ''Producto nuevo''; }).length) { fila.addClass(''ppla-producto-nuevo''); }',
'    });',
'}',
'',
'function pplaSeleccionarGrupo(tipoProducto, tipoGrupo, grupo) {',
'    apex.item(''P1000_SOLO_NUEVOS'').setValue(''N'');',
'    apex.jQuery(''#P1000_NUEVOS_GRUPO_CONTAINER'').addClass(''u-hidden'');',
'    apex.item(''P1000_NUEVOS_GRUPO'').setValue('''');',
'    apex.item(''P1000_AGR_TIPO_PRODUCTO'').setValue(tipoProducto);',
'    apex.item(''P1000_AGR_TIPO_GRUPO'').setValue(tipoGrupo);',
'    apex.item(''P1000_AGR_GRUPO'').setValue(grupo);',
'    apex.item(''P1000_AJ_MINIMO_DIAS'').setValue('''');',
'    apex.item(''P1000_AJ_MAXIMO_DIAS'').setValue('''');',
'    apex.item(''P1000_AJ_SKU'').setValue('''');',
'    apex.jQuery(''#ppla_ajuste_alcance'').text(''Ajuste masivo del grupo seleccionado.'');',
'    pplaMostrarVista(''DETALLE'');',
'    apex.jQuery(''#ppla_detalle_stock'').one(''apexafterrefresh'', function () { pplaMostrarVista(''DETALLE''); });',
'    apex.region(''ppla_detalle_stock'').refresh();',
'}',
'',
'function pplaVolverResumen() {',
'    apex.item(''P1000_AJ_SKU'').setValue('''');',
'    apex.item(''P1000_SOLO_NUEVOS'').setValue(''N'');',
'    apex.item(''P1000_AGR_TIPO_PRODUCTO'').setValue('''');',
'    apex.item(''P1000_AGR_TIPO_GRUPO'').setValue('''');',
'    apex.item(''P1000_AGR_GRUPO'').setValue('''');',
'    apex.item(''P1000_NUEVOS_GRUPO'').setValue('''');',
'    pplaMostrarVista(''RESUMEN'');',
'}',
'',
'function pplaMostrarProductosNuevos() {',
'    apex.item(''P1000_SOLO_NUEVOS'').setValue(''S'');',
'    apex.item(''P1000_AGR_TIPO_PRODUCTO'').setValue('''');',
'    apex.item(''P1000_AGR_TIPO_GRUPO'').setValue('''');',
'    apex.item(''P1000_AGR_GRUPO'').setValue('''');',
'    apex.item(''P1000_NUEVOS_GRUPO'').setValue('''');',
'    apex.jQuery(''#P1000_NUEVOS_GRUPO_CONTAINER'').removeClass(''u-hidden'');',
'    apex.jQuery(''#ppla_ajuste_alcance'').text(''Seleccione una categoria o linea para habilitar el ajuste masivo de productos nuevos.'');',
'    pplaMostrarVista(''DETALLE'');',
'    apex.jQuery(''#ppla_detalle_stock'').one(''apexafterrefresh'', function () { pplaMostrarVista(''DETALLE''); });',
'    apex.region(''ppla_detalle_stock'').refresh();',
'}',
'',
'function pplaFiltrarProductosNuevos(valor) {',
'    var partes = (valor || '''').split(String.fromCharCode(31));',
'    if (partes.length !== 3) {',
'        apex.item(''P1000_AGR_TIPO_PRODUCTO'').setValue('''');',
'        apex.item(''P1000_AGR_TIPO_GRUPO'').setValue('''');',
'        apex.item(''P1000_AGR_GRUPO'').setValue('''');',
'        apex.jQuery(''#ppla_ajuste_alcance'').text(''Seleccione una categoria o linea para habilitar el ajuste masivo de productos nuevos.'');',
'        apex.jQuery(''#P1000_NUEVOS_GRUPO_CONTAINER'').removeClass(''u-hidden'');',
'    } else {',
'        apex.item(''P1000_AGR_TIPO_PRODUCTO'').setValue(partes[0]);',
'        apex.item(''P1000_AGR_TIPO_GRUPO'').setValue(partes[1]);',
'        apex.item(''P1000_AGR_GRUPO'').setValue(partes[2]);',
'        apex.jQuery(''#ppla_ajuste_alcance'').text(''Ajuste masivo para los productos nuevos del grupo seleccionado.'');',
'        apex.jQuery(''#P1000_NUEVOS_GRUPO_CONTAINER'').addClass(''u-hidden'');',
'    }',
'    pplaMostrarVista(''DETALLE'');',
'    apex.region(''ppla_detalle_stock'').refresh();',
'}',
'',
'function pplaVolverAnalisis() {',
'    apex.item(''P1000_AJ_SKU'').setValue('''');',
'    if (apex.item(''P1000_SOLO_NUEVOS'').getValue() === ''S'') {',
'        pplaVolverResumen();',
'        return;',
'    }',
'    pplaMostrarVista(''ANALISIS'');',
'}',
'',
'apex.jQuery(function () {',
'    pplaMostrarVista(apex.item(''P1000_AGR_TIPO_PRODUCTO'').getValue() ? ''ANALISIS'' : ''RESUMEN'');',
'    pplaUbicarEnlaceProductosNuevos();',
'    window.setTimeout(pplaPrepararLinksResumen, 0);',
'    apex.jQuery(''#ppla_resumen'').on(''apexafterrefresh'', function () { pplaPrepararLinksResumen(); pplaUbicarEnlaceProductosNuevos(); });',
'    apex.jQuery(''#ppla_detalle_stock'').on(''apexafterrefresh'', pplaResaltarProductosNuevos);',
'    apex.jQuery(document).on(''apexafterclosedialog'', function () { if (!apex.jQuery(''#ppla_detalle_stock'').hasClass(''u-hidden'')) { apex.region(''ppla_detalle_stock'').refresh(); } });',
'});'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#ppla_analisis_segmento .a-IRR-table td { vertical-align: middle; }',
'#ppla_analisis_segmento .a-IRR-table td[headers="CUMPLIMIENTO"] { font-weight: 700; }',
'#ppla_ajuste_stock .t-Region-body { background: #f7f9fb; }',
'.ppla-producto-nuevo td { background-color: #fff3b0 !important; }',
'.ppla-periodo-alerta { margin-bottom: 1rem; }'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(150253642267662348)
,p_plug_name=>'Formulario'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(535720157374545246)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(150357359910727447)
,p_plug_name=>'Grupo'
,p_parent_plug_id=>wwv_flow_imp.id(150253642267662348)
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_imp.id(533636752386487514)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'USER')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(153000905947992230)
,p_plug_name=>'Resumen'
,p_region_name=>'ppla_resumen'
,p_parent_plug_id=>wwv_flow_imp.id(150357359910727447)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(533628879219487509)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('    ''Est\00E1ndar MP'' as concepto,'),
'    TO_CHAR(TO_NUMBER(REPLACE(:P1000_ESTANDAR_MP,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' ), ''FML999G999G999D00'') as valor1,',
unistr('    ''Variaci\00F3n Absoluta < Min'' as descripcion,'),
'    TO_CHAR(',
'        (SELECT NVL(SUM(BAJOMINIMOUSD),0) ',
'        FROM T_PPLA_STOCKIDEAL ',
'        WHERE COMPANIA = :G_COMPANIA',
'        AND FECHA = :P1000_FECHA_DATOS',
'        AND TIPOPRODUCTO = ''MATERIA PRIMA'')',
'        , ''FML999G999G999'') as valor2,',
'    NULL as cumple,',
'    ''MATERIA_PRIMA'' as seccion',
'FROM dual',
'UNION ALL',
'SELECT ',
'    ''Inventario en Agotamiento MP'',',
'    TO_CHAR(',
'        TO_NUMBER(REPLACE(:P1000_AGOTAMIENTO_MP,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' )',
'        , ''FML999G999G999''),',
unistr('    ''Variaci\00F3n Absoluta > Max'','),
'    TO_CHAR(',
'        (SELECT NVL(SUM(SOBREMAXIMOUSD),0)',
'        FROM T_PPLA_STOCKIDEAL ',
'        WHERE COMPANIA = :G_COMPANIA',
'        AND FECHA = :P1000_FECHA_DATOS',
'        AND TIPOPRODUCTO = ''MATERIA PRIMA'')',
'        , ''FML999G999G999''),',
'    NULL,',
'    ''MATERIA_PRIMA''',
'FROM dual',
'UNION ALL',
'SELECT ',
unistr('    ''Inversi\00F3n MP'','),
'    TO_CHAR(',
'        TO_NUMBER(REPLACE(:P1000_INVERSION_MP,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' )',
'        , ''FML999G999G999''),',
'    NULL,',
'    NULL,',
'    NULL,',
'    ''MATERIA_PRIMA''',
'FROM dual',
'UNION ALL',
'SELECT ',
unistr('    ''Total Est\00E1ndar MP'','),
'    TO_CHAR(TO_NUMBER(REPLACE(:P1000_TOTAL_ESTANDAR_MP,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' ), ''FML999G999G999D00'') , ',
unistr('    ''Variaci\00F3n Absoluta Total'','),
'    TO_CHAR(',
'        (SELECT NVL(SUM(VARIACIONUSD),0) ',
'        FROM T_PPLA_STOCKIDEAL ',
'        WHERE COMPANIA = :G_COMPANIA',
'        AND FECHA = :P1000_FECHA_DATOS',
'        AND TIPOPRODUCTO = ''MATERIA PRIMA'')',
'        , ''FML999G999G999''),',
'    NULL,',
'    ''MATERIA_PRIMA''',
'FROM dual',
'UNION ALL',
'SELECT ',
unistr('    ''Meta de Variaci\00F3n Absoluta <= ''||:P1000_MET_VAR_MP||''%'','),
'    NULL,',
unistr('    ''Variaci\00F3n vs. Est\00E1ndar'','),
'    TO_CHAR(',
'        ((',
'            SELECT NVL(SUM(VARIACIONUSD),0) ',
'            FROM T_PPLA_STOCKIDEAL ',
'            WHERE COMPANIA = :G_COMPANIA',
'            AND FECHA = :P1000_FECHA_DATOS',
'            AND TIPOPRODUCTO = ''MATERIA PRIMA''',
'        )/NULLIF(TO_NUMBER(REPLACE(:P1000_TOTAL_ESTANDAR_MP,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' ),0))*100',
'        , ''999G999G990D000'')||''%'',',
'    CASE ',
'        WHEN NVL(TO_NUMBER(REPLACE(:P1000_TOTAL_ESTANDAR_MP,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' ),0)=0 THEN ''SIN ESTANDAR''',
'        WHEN',
'        ((',
'            SELECT NVL(SUM(VARIACIONUSD),0) ',
'            FROM T_PPLA_STOCKIDEAL ',
'            WHERE COMPANIA = :G_COMPANIA',
'            AND FECHA = :P1000_FECHA_DATOS',
'            AND TIPOPRODUCTO = ''MATERIA PRIMA''',
'        )/NULLIF(TO_NUMBER(REPLACE(:P1000_TOTAL_ESTANDAR_MP,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' ),0))*100 <= TO_NUMBER(REPLACE(:P1000_MET_VAR_MP,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' )',
'        THEN ''SI''',
'        ELSE ''NO''',
'    END,',
'    ''META_MP''',
'FROM dual',
'UNION ALL',
'SELECT ',
'    ''Cierre Anterior MP'',',
'    TO_CHAR(TO_NUMBER(REPLACE(:P1000_INICIAL_MP,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' ), ''FML999G999G999D00''),',
'    NULL,',
'    NULL,',
'    NULL,',
'    ''META_MP''',
'FROM dual',
'UNION ALL',
'SELECT ',
'    NULL,',
'    NULL,',
'    NULL,',
'    NULL,',
'    NULL,',
'    ''META_MP''',
'FROM dual',
'-- PT',
'UNION ALL',
'SELECT ',
unistr('    ''Est\00E1ndar PT'','),
'    TO_CHAR(TO_NUMBER(REPLACE(:P1000_ESTANDAR_PT,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' ), ''FML999G999G999D00'') ,',
unistr('    ''Variaci\00F3n Absoluta < Min'','),
'    TO_CHAR(',
'        (SELECT NVL(SUM(BAJOMINIMOUSD),0) ',
'        FROM T_PPLA_STOCKIDEAL ',
'        WHERE COMPANIA = :G_COMPANIA',
'        AND FECHA = :P1000_FECHA_DATOS',
'        AND TIPOPRODUCTO = ''PRODUCTO TERMINADO'')',
'        , ''FML999G999G999''),',
'    NULL,',
'    ''PRODUCTO_TERMINADO''',
'FROM dual',
'UNION ALL',
'SELECT ',
'    '''',',
'    '''',',
unistr('    ''Variaci\00F3n Absoluta > Max'','),
'    TO_CHAR(',
'        (SELECT NVL(SUM(SOBREMAXIMOUSD),0) ',
'        FROM T_PPLA_STOCKIDEAL ',
'        WHERE COMPANIA = :G_COMPANIA',
'        AND FECHA = :P1000_FECHA_DATOS',
'        AND TIPOPRODUCTO = ''PRODUCTO TERMINADO'')',
'        , ''FML999G999G990''),',
'    NULL,',
'    ''PRODUCTO_TERMINADO''',
'FROM dual',
'UNION ALL',
'SELECT ',
'    NULL,',
'    NULL,',
unistr('    ''Variaci\00F3n Absoluta Total'','),
'    TO_CHAR(',
'        (SELECT NVL(SUM(VARIACIONUSD),0) ',
'        FROM T_PPLA_STOCKIDEAL ',
'        WHERE COMPANIA = :G_COMPANIA',
'        AND FECHA = :P1000_FECHA_DATOS',
'        AND TIPOPRODUCTO = ''PRODUCTO TERMINADO'')',
'        , ''FML999G999G999''),',
'    NULL,',
'    ''META_MP''',
'FROM dual',
'UNION ALL',
'SELECT ',
unistr('    ''Meta de Variaci\00F3n Absoluta <= ''||:P1000_MET_VAR_PT||''%'','),
'    NULL,',
unistr('    ''Variaci\00F3n vs. Est\00E1ndar'','),
'    TO_CHAR(',
'        ((',
'            SELECT NVL(SUM(VARIACIONUSD),(0))',
'            FROM T_PPLA_STOCKIDEAL ',
'            WHERE COMPANIA = :G_COMPANIA',
'            AND FECHA = :P1000_FECHA_DATOS',
'            AND TIPOPRODUCTO = ''PRODUCTO TERMINADO''',
'        )/NULLIF(TO_NUMBER(REPLACE(:P1000_ESTANDAR_PT,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' ),0))*100',
'        , ''999G999G990D000'')||''%'',',
'    CASE ',
'        WHEN NVL(TO_NUMBER(REPLACE(:P1000_ESTANDAR_PT,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' ),0)=0 THEN ''SIN ESTANDAR''',
'        WHEN',
'            ((',
'            SELECT NVL(SUM(VARIACIONUSD),(0))',
'            FROM T_PPLA_STOCKIDEAL ',
'            WHERE COMPANIA = :G_COMPANIA',
'            AND FECHA = :P1000_FECHA_DATOS',
'            AND TIPOPRODUCTO = ''PRODUCTO TERMINADO''',
'        )/NULLIF(TO_NUMBER(REPLACE(:P1000_ESTANDAR_PT,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' ),0))*100 <= TO_NUMBER(REPLACE(:P1000_MET_VAR_PT,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' )',
'        THEN ''SI''',
'        ELSE ''NO''',
'    END,',
'    ''META_PT''',
'FROM dual',
'UNION ALL',
'SELECT ',
'    ''Cierre Anterior PT'',',
'    TO_CHAR(TO_NUMBER(REPLACE(:P1000_INICIAL_PT,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' ), ''FML999G999G999D00''),',
'    NULL,',
'    NULL,',
'    NULL,',
'    ''META_PT''',
'FROM dual'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(153002229109992243)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>153002229109992243
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153002388064992244)
,p_db_column_name=>'CONCEPTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Concepto'
,p_column_link=>'javascript:pplaAbrirAnalisis(''#SECCION!JS#'');'
,p_column_linktext=>'#CONCEPTO#'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153002458326992245)
,p_db_column_name=>'VALOR1'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Valor1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153002511982992246)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153002606083992247)
,p_db_column_name=>'VALOR2'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Valor2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153002754902992248)
,p_db_column_name=>'CUMPLE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Cumple'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153002846573992249)
,p_db_column_name=>'SECCION'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Seccion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(153085085008137382)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1530851'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CONCEPTO:VALOR1:DESCRIPCION:VALOR2:CUMPLE:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(902005001000000011)
,p_plug_name=>'Productos nuevos'
,p_region_name=>'ppla_productos_nuevos'
,p_parent_plug_id=>wwv_flow_imp.id(153000905947992230)
,p_plug_display_sequence=>5
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2('DECLARE V_CANTIDAD NUMBER; BEGIN SELECT COUNT(*) INTO V_CANTIDAD FROM T_PPLA_STOCKIDEAL WHERE COMPANIA=:G_COMPANIA AND FECHA=:P1000_FECHA_DATOS AND ORIGEN_REGISTRO=''AUTO''; HTP.P(''<a href="javascript:pplaMostrarProductosNuevos();">''||V_CANTIDAD||'' productos nuevos</a>''); END;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(902002001000000010)
,p_plug_name=>'Analisis por segmento'
,p_region_name=>'ppla_analisis_segmento'
,p_parent_plug_id=>wwv_flow_imp.id(153000905947992230)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(533628879219487509)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH LINEA_PRODUCTO AS (',
'    SELECT TRIM(COMPANIA) COMPANIA, CAST(TRIM(CODIGOPRODUCTO) AS VARCHAR2(30)) CODIGOPRODUCTO,',
'           CAST(MAX(TRIM(LINEANEGOCIO)) AS VARCHAR2(100)) LINEANEGOCIO',
'      FROM VT_JDE_PRODUCTOS',
'     GROUP BY TRIM(COMPANIA), TRIM(CODIGOPRODUCTO)',
'), BASE AS (',
'    SELECT STOCK.TIPOPRODUCTO, STOCK.CODIGOSKU, STOCK.PROMEDIOINVENTARIOUSD,',
'           STOCK.STOCKMINIMOUSD, STOCK.STOCKMAXIMOUSD, STOCK.BAJOMINIMOUSD,',
'           STOCK.SOBREMAXIMOUSD, STOCK.VARIACIONUSD,',
'           CASE WHEN STOCK.TIPOPRODUCTO = ''MATERIA PRIMA'' THEN ''CATEGORIA_PLANIFICACION'' ELSE ''LINEA_NEGOCIO'' END TIPO_GRUPO,',
'           CASE WHEN STOCK.TIPOPRODUCTO = ''MATERIA PRIMA''',
'                THEN NVL(TRIM(STOCK.CATEGORIAPLANIFICACION), ''Sin categoria de planificacion'')',
'                ELSE NVL(LINEA.LINEANEGOCIO, ''Sin linea de negocio'') END GRUPO',
'      FROM T_PPLA_STOCKIDEAL STOCK',
'      LEFT JOIN LINEA_PRODUCTO LINEA',
'        ON LINEA.COMPANIA = TRIM(STOCK.COMPANIA)',
'       AND LINEA.CODIGOPRODUCTO = TRIM(STOCK.CODIGOSKU)',
'     WHERE STOCK.COMPANIA = :G_COMPANIA',
'       AND STOCK.FECHA = :P1000_FECHA_DATOS',
'       AND :P1000_AGR_TIPO_PRODUCTO IS NOT NULL',
'       AND STOCK.TIPOPRODUCTO = :P1000_AGR_TIPO_PRODUCTO',
')',
'SELECT TIPOPRODUCTO, TIPO_GRUPO, GRUPO, COUNT(DISTINCT CODIGOSKU) CANTIDAD_SKU,',
'       SUM(NVL(PROMEDIOINVENTARIOUSD,0)) INVENTARIO_PROMEDIO_USD,',
'       SUM(NVL(STOCKMINIMOUSD,0)) STOCK_MINIMO_USD,',
'       SUM(NVL(STOCKMAXIMOUSD,0)) STOCK_MAXIMO_USD,',
'       SUM(NVL(BAJOMINIMOUSD,0)) BAJO_MINIMO_USD,',
'       SUM(NVL(SOBREMAXIMOUSD,0)) SOBRE_MAXIMO_USD,',
'       SUM(NVL(VARIACIONUSD,0)) VARIACION_USD,',
'       CASE WHEN TIPOPRODUCTO = ''MATERIA PRIMA'' THEN NVL(TO_NUMBER(REPLACE(:P1000_TOTAL_ESTANDAR_MP,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' ),0)',
'            ELSE NVL(TO_NUMBER(REPLACE(:P1000_ESTANDAR_PT,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' ),0) END ESTANDAR_KPI,',
'       ROUND(CASE WHEN CASE WHEN TIPOPRODUCTO = ''MATERIA PRIMA'' THEN NVL(TO_NUMBER(REPLACE(:P1000_TOTAL_ESTANDAR_MP,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' ),0)',
'                                 ELSE NVL(TO_NUMBER(REPLACE(:P1000_ESTANDAR_PT,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' ),0) END = 0 THEN NULL',
'                  ELSE SUM(NVL(VARIACIONUSD,0)) /',
'                       CASE WHEN TIPOPRODUCTO = ''MATERIA PRIMA'' THEN TO_NUMBER(REPLACE(:P1000_TOTAL_ESTANDAR_MP,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' )',
'                            ELSE TO_NUMBER(REPLACE(:P1000_ESTANDAR_PT,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' ) END * 100 END, 2) PORCENTAJE_VARIACION,',
'       CASE WHEN TIPOPRODUCTO = ''MATERIA PRIMA'' THEN TO_NUMBER(REPLACE(:P1000_MET_VAR_MP,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' )',
'            ELSE TO_NUMBER(REPLACE(:P1000_MET_VAR_PT,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' ) END META,',
'       CASE WHEN CASE WHEN TIPOPRODUCTO = ''MATERIA PRIMA'' THEN NVL(TO_NUMBER(REPLACE(:P1000_TOTAL_ESTANDAR_MP,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' ),0)',
'                           ELSE NVL(TO_NUMBER(REPLACE(:P1000_ESTANDAR_PT,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' ),0) END = 0 THEN ''Sin estandar''',
'            WHEN ROUND(CASE WHEN CASE WHEN TIPOPRODUCTO = ''MATERIA PRIMA'' THEN NVL(TO_NUMBER(REPLACE(:P1000_TOTAL_ESTANDAR_MP,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' ),0)',
'                                      ELSE NVL(TO_NUMBER(REPLACE(:P1000_ESTANDAR_PT,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' ),0) END = 0 THEN NULL',
'                             ELSE SUM(NVL(VARIACIONUSD,0)) /',
'                                  CASE WHEN TIPOPRODUCTO = ''MATERIA PRIMA'' THEN TO_NUMBER(REPLACE(:P1000_TOTAL_ESTANDAR_MP,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' )',
'                                       ELSE TO_NUMBER(REPLACE(:P1000_ESTANDAR_PT,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' ) END * 100 END, 2)',
'                     <= CASE WHEN TIPOPRODUCTO = ''MATERIA PRIMA'' THEN TO_NUMBER(REPLACE(:P1000_MET_VAR_MP,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' )',
'                             ELSE TO_NUMBER(REPLACE(:P1000_MET_VAR_PT,'','', ''.''), ''999999999999999999999999D999999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' ) END THEN ''Cumple'' ELSE ''No cumple'' END CUMPLIMIENTO',
'  FROM BASE',
' GROUP BY TIPOPRODUCTO, TIPO_GRUPO, GRUPO',
' ORDER BY TIPOPRODUCTO, VARIACION_USD DESC'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P1000_FECHA_DATOS,P1000_AGR_TIPO_PRODUCTO,P1000_TOTAL_ESTANDAR_MP,P1000_ESTANDAR_PT,P1000_MET_VAR_MP,P1000_MET_VAR_PT'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(902002001000000011)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>420
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>902002001000000011
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000012)
,p_db_column_name=>'TIPOPRODUCTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Tipo de producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000013)
,p_db_column_name=>'TIPO_GRUPO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo grupo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000014)
,p_db_column_name=>'GRUPO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Grupo'
,p_column_link=>'javascript:pplaSeleccionarGrupo(''#TIPOPRODUCTO!JS#'',''#TIPO_GRUPO!JS#'',''#GRUPO!JS#'');'
,p_column_linktext=>'#GRUPO#'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000015)
,p_db_column_name=>'CANTIDAD_SKU'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'SKU'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000016)
,p_db_column_name=>'INVENTARIO_PROMEDIO_USD'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Inventario promedio USD'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000017)
,p_db_column_name=>'STOCK_MINIMO_USD'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Stock minimo USD'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000018)
,p_db_column_name=>'STOCK_MAXIMO_USD'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Stock maximo USD'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000019)
,p_db_column_name=>'BAJO_MINIMO_USD'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Bajo minimo USD'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000020)
,p_db_column_name=>'SOBRE_MAXIMO_USD'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Sobre maximo USD'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000021)
,p_db_column_name=>'VARIACION_USD'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Variacion USD'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000022)
,p_db_column_name=>'ESTANDAR_KPI'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Estandar KPI'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000023)
,p_db_column_name=>'PORCENTAJE_VARIACION'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'% variacion KPI'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FM999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000024)
,p_db_column_name=>'META'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Meta %'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000025)
,p_db_column_name=>'CUMPLIMIENTO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Resultado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(902002001000000026)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'9020020011'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TIPOPRODUCTO:GRUPO:CANTIDAD_SKU:INVENTARIO_PROMEDIO_USD:STOCK_MINIMO_USD:STOCK_MAXIMO_USD:BAJO_MINIMO_USD:SOBRE_MAXIMO_USD:VARIACION_USD:PORCENTAJE_VARIACION:META:CUMPLIMIENTO:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(902002001000000030)
,p_plug_name=>'Detalle SKU del grupo seleccionado'
,p_region_name=>'ppla_detalle_stock'
,p_parent_plug_id=>wwv_flow_imp.id(153000905947992230)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(533628879219487509)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH LINEA_PRODUCTO AS (',
'    SELECT TRIM(COMPANIA) COMPANIA, CAST(TRIM(CODIGOPRODUCTO) AS VARCHAR2(30)) CODIGOPRODUCTO,',
'           CAST(MAX(TRIM(LINEANEGOCIO)) AS VARCHAR2(100)) LINEANEGOCIO',
'      FROM VT_JDE_PRODUCTOS GROUP BY TRIM(COMPANIA), TRIM(CODIGOPRODUCTO)',
')',
'SELECT STOCK.TIPOPRODUCTO, STOCK.CODIGOSKU, STOCK.DESCRIPCIONSKU,',
'       STOCK.CATEGORIAPLANIFICACION, NVL(LINEA.LINEANEGOCIO,''Sin linea de negocio'') LINEA_NEGOCIO,',
'       STOCK.PROMEDIOINVENTARIOUSD, STOCK.PROMEDIOINVENTARIOCANTIDAD, STOCK.CONSUMOPROMEDIOUSD,',
'       NVL(PARAMETRO.MINIMODIAS, STOCK.MINIMODIAS) MINIMODIAS,',
'       NVL(PARAMETRO.MAXIMODIAS, STOCK.MAXIMODIAS) MAXIMODIAS,',
'       STOCK.STOCKMINIMOUSD, STOCK.STOCKMAXIMOUSD,',
'       STOCK.BAJOMINIMOUSD, STOCK.SOBREMAXIMOUSD, STOCK.VARIACIONUSD, STOCK.COSTOSTANDARD,',
'       STOCK.INICIALUSD, NVL(PARAMETRO.METODOCALCULO, STOCK.METODOCALCULO) METODOCALCULO, STOCK.ORIGEN_REGISTRO,',
'       CASE WHEN STOCK.ORIGEN_REGISTRO = ''AUTO'' THEN ''Producto nuevo''',
'            ELSE NVL(PARAMETRO.OBSERVACION, STOCK.OBSERVACION) END OBSERVACION,',
'       CASE WHEN STOCK.TIPOPRODUCTO=''MATERIA PRIMA'' THEN ''CATEGORIA_PLANIFICACION'' ELSE ''LINEA_NEGOCIO'' END TIPO_GRUPO,',
'       CASE WHEN STOCK.TIPOPRODUCTO=''MATERIA PRIMA'' THEN NVL(TRIM(STOCK.CATEGORIAPLANIFICACION),''Sin categoria de planificacion'') ELSE NVL(LINEA.LINEANEGOCIO,''Sin linea de negocio'') END GRUPO,',
'       TO_CHAR(NVL(PARAMETRO.MINIMODIAS, STOCK.MINIMODIAS), ''FM999999999999990D999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' ) MINIMODIAS_URL,',
'       TO_CHAR(NVL(PARAMETRO.MAXIMODIAS, STOCK.MAXIMODIAS), ''FM999999999999990D999999'', ''NLS_NUMERIC_CHARACTERS=''''.,'''''' ) MAXIMODIAS_URL',
'  FROM T_PPLA_STOCKIDEAL STOCK',
'  LEFT JOIN LINEA_PRODUCTO LINEA ON LINEA.COMPANIA=TRIM(STOCK.COMPANIA) AND LINEA.CODIGOPRODUCTO=TRIM(STOCK.CODIGOSKU)',
'  LEFT JOIN T_PPLA_STOCKIDEALPARAMETROS PARAMETRO ON PARAMETRO.COMPANIA=STOCK.COMPANIA AND PARAMETRO.TIPOPRODUCTO=STOCK.TIPOPRODUCTO AND TRIM(PARAMETRO.CODIGOPRODUCTO)=TRIM(STOCK.CODIGOSKU) AND PARAMETRO.ESTADO=1',
' WHERE STOCK.COMPANIA=:G_COMPANIA',
'   AND STOCK.FECHA=:P1000_FECHA_DATOS',
'   AND ((:P1000_SOLO_NUEVOS=''S'' AND STOCK.ORIGEN_REGISTRO=''AUTO''',
'         AND (:P1000_AGR_TIPO_PRODUCTO IS NULL OR',
'              (STOCK.TIPOPRODUCTO=:P1000_AGR_TIPO_PRODUCTO AND',
'               ((:P1000_AGR_TIPO_GRUPO=''CATEGORIA_PLANIFICACION'' AND NVL(TRIM(STOCK.CATEGORIAPLANIFICACION),''Sin categoria de planificacion'')=:P1000_AGR_GRUPO)',
'                 OR (:P1000_AGR_TIPO_GRUPO=''LINEA_NEGOCIO'' AND NVL(LINEA.LINEANEGOCIO,''Sin linea de negocio'')=:P1000_AGR_GRUPO))))) OR',
'        (:P1000_SOLO_NUEVOS<>''S'' AND :P1000_AGR_TIPO_PRODUCTO IS NOT NULL AND :P1000_AGR_GRUPO IS NOT NULL',
'         AND STOCK.TIPOPRODUCTO=:P1000_AGR_TIPO_PRODUCTO',
'         AND ((:P1000_AGR_TIPO_GRUPO=''CATEGORIA_PLANIFICACION'' AND NVL(TRIM(STOCK.CATEGORIAPLANIFICACION),''Sin categoria de planificacion'')=:P1000_AGR_GRUPO)',
'           OR (:P1000_AGR_TIPO_GRUPO=''LINEA_NEGOCIO'' AND NVL(LINEA.LINEANEGOCIO,''Sin linea de negocio'')=:P1000_AGR_GRUPO))))',
' ORDER BY STOCK.VARIACIONUSD DESC, STOCK.CODIGOSKU'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P1000_FECHA_DATOS,P1000_SOLO_NUEVOS,P1000_AGR_TIPO_PRODUCTO,P1000_AGR_TIPO_GRUPO,P1000_AGR_GRUPO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(902002001000000031)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'REGION'
,p_fixed_header_max_height=>420
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>902002001000000031
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000032)
,p_db_column_name=>'TIPOPRODUCTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000251)
,p_db_column_name=>'ORIGEN_REGISTRO'
,p_display_order=>195
,p_column_identifier=>'T'
,p_column_label=>'Origen'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000252)
,p_db_column_name=>'TIPO_GRUPO'
,p_display_order=>196
,p_column_identifier=>'U'
,p_column_label=>'Tipo grupo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000253)
,p_db_column_name=>'GRUPO'
,p_display_order=>197
,p_column_identifier=>'V'
,p_column_label=>'Grupo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000254)
,p_db_column_name=>'MINIMODIAS_URL'
,p_display_order=>198
,p_column_identifier=>'W'
,p_column_label=>'Dias minimo URL'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000255)
,p_db_column_name=>'MAXIMODIAS_URL'
,p_display_order=>199
,p_column_identifier=>'X'
,p_column_label=>'Dias maximo URL'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000033)
,p_db_column_name=>'CODIGOSKU'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'SKU (editar)'
,p_column_link=>'f?p=&APP_ID.:1002:&SESSION.::NO:1002:P1002_SKU,P1002_DESCRIPCION,P1002_MINIMO_DIAS,P1002_MAXIMO_DIAS,P1002_METODO_CALCULO,P1002_TIPO_PRODUCTO,P1002_TIPO_GRUPO,P1002_GRUPO,P1002_PERIODO:#CODIGOSKU#,#DESCRIPCIONSKU#,#MINIMODIAS_URL#,#MAXIMODIAS_URL#,#METODOCALCULO#,#TIPOPRODUCTO#,#TIPO_GRUPO#,#GRUPO#,&P1000_FECHA_DATOS.'
,p_column_linktext=>'#CODIGOSKU#'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000034)
,p_db_column_name=>'DESCRIPCIONSKU'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000035)
,p_db_column_name=>'CATEGORIAPLANIFICACION'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Categoria planificacion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000036)
,p_db_column_name=>'LINEA_NEGOCIO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Linea de negocio'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000037)
,p_db_column_name=>'PROMEDIOINVENTARIOUSD'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Inventario promedio USD'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000038)
,p_db_column_name=>'PROMEDIOINVENTARIOCANTIDAD'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Inventario promedio cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FM999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000039)
,p_db_column_name=>'CONSUMOPROMEDIOUSD'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Consumo promedio USD'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000040)
,p_db_column_name=>'MINIMODIAS'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Dias minimo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000041)
,p_db_column_name=>'MAXIMODIAS'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Dias maximo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000042)
,p_db_column_name=>'STOCKMINIMOUSD'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Stock minimo USD'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000043)
,p_db_column_name=>'STOCKMAXIMOUSD'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Stock maximo USD'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000044)
,p_db_column_name=>'BAJOMINIMOUSD'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Bajo minimo USD'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000045)
,p_db_column_name=>'SOBREMAXIMOUSD'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Sobre maximo USD'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000046)
,p_db_column_name=>'VARIACIONUSD'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Variacion USD'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000047)
,p_db_column_name=>'COSTOSTANDARD'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Costo estandar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000048)
,p_db_column_name=>'INICIALUSD'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Inicial USD'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000049)
,p_db_column_name=>'METODOCALCULO'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Metodo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(902002001000000050)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(902002001000000051)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'9020020031'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TIPOPRODUCTO:CODIGOSKU:DESCRIPCIONSKU:CATEGORIAPLANIFICACION:LINEA_NEGOCIO:PROMEDIOINVENTARIOUSD:CONSUMOPROMEDIOUSD:MINIMODIAS:MAXIMODIAS:STOCKMINIMOUSD:STOCKMAXIMOUSD:BAJOMINIMOUSD:SOBREMAXIMOUSD:VARIACIONUSD:COSTOSTANDARD:INICIALUSD:METODOCALCULO:O'
||'BSERVACION:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(902002001000000060)
,p_plug_name=>'Ajustar grupo'
,p_region_name=>'ppla_ajuste_stock'
,p_parent_plug_id=>wwv_flow_imp.id(153000905947992230)
,p_region_template_options=>'#DEFAULT#:t-Region--accent1:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(535720157374545246)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(308879567417807009)
,p_plug_name=>'Stock Ideal'
,p_parent_plug_id=>wwv_flow_imp.id(150357359910727447)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(535720157374545246)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(124618796915893310)
,p_plug_name=>'Stock Ideal'
,p_parent_plug_id=>wwv_flow_imp.id(308879567417807009)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(533628879219487509)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select IDSTOCKIDEAL,',
'       TIPOPRODUCTO,',
'       CODIGOSKU,',
'       DESCRIPCIONSKU,',
'       CATEGORIAPLANIFICACION,',
'       PROMEDIOINVENTARIOUSD,',
'       PROMEDIOINVENTARIOCANTIDAD,',
'       CONSUMOPROMEDIOUSD,',
'       MINIMODIAS,',
'       MAXIMODIAS,',
'       STOCKMINIMOUSD,',
'       STOCKMAXIMOUSD,',
'       SOBREMAXIMOUSD,',
'       BAJOMINIMOUSD,',
'       VARIACIONUSD,',
'       COSTOSTANDARD,',
'       OBSERVACION,',
'       FECHAPROCESO,',
'       USUARIOPROCESO,',
'       COMPANIA,',
'       METODOCALCULO,',
'       TOTALCANTIDAD,',
'       TOTALUSD,',
'       FECHA,',
'       INICIALUSD',
'  from T_PPLA_STOCKIDEAL',
' where COMPANIA = :G_COMPANIA',
'AND (FECHA = :P1000_PERIODO)',
'AND (TIPOPRODUCTO = :P1000_TIPO_PRODUCTO OR :P1000_TIPO_PRODUCTO IS NULL)',
'AND (CODIGOSKU = TRIM(:P1000_PRODUCTO) OR :P1000_PRODUCTO IS NULL)',
'AND (CATEGORIAPLANIFICACION = :P1000_CATEOGRIA_PLANIFICACION OR :P1000_CATEOGRIA_PLANIFICACION IS NULL)'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P1000_PERIODO,P1000_CATEOGRIA_PLANIFICACION,P1000_TIPO_PRODUCTO,P1000_PRODUCTO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(124618841716893311)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>124618841716893311
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124619125105893314)
,p_db_column_name=>'TIPOPRODUCTO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tipoproducto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124619281460893315)
,p_db_column_name=>'CODIGOSKU'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Codigosku'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124619339243893316)
,p_db_column_name=>'DESCRIPCIONSKU'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Descripcionsku'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124619482871893317)
,p_db_column_name=>'CATEGORIAPLANIFICACION'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Categoriaplanificacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124619540375893318)
,p_db_column_name=>'PROMEDIOINVENTARIOUSD'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Promedioinventariousd'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124619692077893319)
,p_db_column_name=>'PROMEDIOINVENTARIOCANTIDAD'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Promedioinventariocantidad'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124619720900893320)
,p_db_column_name=>'CONSUMOPROMEDIOUSD'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Consumopromediousd'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124619877725893321)
,p_db_column_name=>'MINIMODIAS'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Minimodias'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124619978754893322)
,p_db_column_name=>'MAXIMODIAS'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Maximodias'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124620003032893323)
,p_db_column_name=>'STOCKMINIMOUSD'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Stockminimousd'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124620156277893324)
,p_db_column_name=>'STOCKMAXIMOUSD'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Stockmaximousd'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124620248653893325)
,p_db_column_name=>'SOBREMAXIMOUSD'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Sobremaximousd'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124620357176893326)
,p_db_column_name=>'BAJOMINIMOUSD'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Bajominimousd'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124620466322893327)
,p_db_column_name=>'VARIACIONUSD'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Variacionusd'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124620531242893328)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124620601150893329)
,p_db_column_name=>'FECHAPROCESO'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Fechaproceso'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124620704658893330)
,p_db_column_name=>'USUARIOPROCESO'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Usuarioproceso'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124620843592893331)
,p_db_column_name=>'COMPANIA'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(236058236656885450)
,p_db_column_name=>'METODOCALCULO'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Metodocalculo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(308878782187807001)
,p_db_column_name=>'TOTALCANTIDAD'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Totalcantidad'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(308878885399807002)
,p_db_column_name=>'TOTALUSD'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Totalusd'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(308879112660807005)
,p_db_column_name=>'IDSTOCKIDEAL'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Idstockideal'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(308881525540807029)
,p_db_column_name=>'FECHA'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Fecha Datos'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(308882035894807034)
,p_db_column_name=>'COSTOSTANDARD'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Costostandard'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(450801247380118316)
,p_db_column_name=>'INICIALUSD'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Inicialusd'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(151675942557703093)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1516760'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FECHA:TIPOPRODUCTO:CODIGOSKU:DESCRIPCIONSKU:CATEGORIAPLANIFICACION:PROMEDIOINVENTARIOUSD:PROMEDIOINVENTARIOCANTIDAD:CONSUMOPROMEDIOUSD:MINIMODIAS:MAXIMODIAS:STOCKMINIMOUSD:STOCKMAXIMOUSD:SOBREMAXIMOUSD:BAJOMINIMOUSD:VARIACIONUSD:COSTOSTANDARD:OBSERVA'
||'CION:FECHAPROCESO:USUARIOPROCESO:TOTALCANTIDAD:TOTALUSD:INICIALUSD:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(150353941511727413)
,p_plug_name=>'Filtros'
,p_parent_plug_id=>wwv_flow_imp.id(308879567417807009)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(535720157374545246)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(153002903525992250)
,p_plug_name=>'Parametros'
,p_parent_plug_id=>wwv_flow_imp.id(150253642267662348)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_region_attributes=>'style="display:none"'
,p_plug_template=>wwv_flow_imp.id(535720157374545246)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(579366956764543224)
,p_plug_name=>unistr('Reporte de variaci\00F3n mensual')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(535720918100545250)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(533583382097487435)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(533683083484487562)
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(591865086055802910)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(535719775917545246)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(902002001000000090)
,p_button_sequence=>5
,p_button_plug_id=>wwv_flow_imp.id(902002001000000010)
,p_button_name=>'VOLVER_RESUMEN'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(533682160901487559)
,p_button_image_alt=>'Atras'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'LEFT'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(902002001000000091)
,p_button_sequence=>5
,p_button_plug_id=>wwv_flow_imp.id(902002001000000030)
,p_button_name=>'VOLVER_ANALISIS'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(533682160901487559)
,p_button_image_alt=>'Atras'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'LEFT'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(450801861490118322)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(591865086055802910)
,p_button_name=>'Editar_Par'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(533682160901487559)
,p_button_image_alt=>'Editar parametros'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:1001:&SESSION.::&DEBUG.:CR,1001::'
,p_icon_css_classes=>'fa-edit'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(902005001000000010)
,p_button_sequence=>15
,p_button_plug_id=>wwv_flow_imp.id(591865086055802910)
,p_button_name=>'EDITAR_METAS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(533682160901487559)
,p_button_image_alt=>'Modificar metas'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:1003:&SESSION.::&DEBUG.:1003::'
,p_icon_css_classes=>'fa-bullseye'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(902002001000000061)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(902002001000000060)
,p_button_name=>'GUARDAR_AJUSTE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(533682160901487559)
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES(''PLAN'',:APP_USER,''1000'',''AJUSTAR_STOCK_IDEAL'',:G_COMPANIA)=1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(150166093013435926)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(591865086055802910)
,p_button_name=>'Actualizar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(533682160901487559)
,p_button_image_alt=>'Ejecutar calculo'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'EXTRACT(DAY FROM SYSDATE) <= TO_NUMBER(PK_ICOM_COMMONS.F_TRAERVALORUDC(''PPLA_PARAM'',''PAR11'',:G_COMPANIA))'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(902002001000000062)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(902002001000000060)
,p_button_name=>'GUARDAR_Y_RECALCULAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(533682160901487559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar y recalcular'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_confirm_message=>unistr('Se guardaran los cambios y se solicitara el recalculo del periodo cerrado. \00BFEsta seguro de continuar?')
,p_confirm_style=>'warning'
,p_button_condition=>'PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES(''PLAN'',:APP_USER,''1000'',''AJUSTAR_STOCK_IDEAL'',:G_COMPANIA)=1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(150354121142727415)
,p_name=>'P1000_PERIODO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(150353941511727413)
,p_prompt=>'Fecha Datos'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT DISTINCT FECHA r,FECHA d FROM T_PPLA_STOCKIDEAL ORDER BY FECHA DESC'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(150354235732727416)
,p_name=>'P1000_TIPO_PRODUCTO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(150353941511727413)
,p_prompt=>'Tipo Producto'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:MATERIA PRIMA;MATERIA PRIMA,PRODUCTO TERMINADO;PRODUCTO TERMINADO'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(150354374810727417)
,p_name=>'P1000_CATEOGRIA_PLANIFICACION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(150353941511727413)
,p_prompt=>'Categoria Planificacion'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT DISTINCT CATEGORIAPLANIFICACION r,CATEGORIAPLANIFICACION d FROM T_PPLA_STOCKIDEALPARAMETROS WHERE CATEGORIAPLANIFICACION IS NOT NULL'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(150354418281727418)
,p_name=>'P1000_PRODUCTO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(150353941511727413)
,p_prompt=>'Producto'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'SELECT IMLITM||'' ''||TRIM(IMDSC1)||'' ''||TRIM(IMDSC2)  D,IMLITM R',
'FROM F4101@JDEDTADL',
'WHERE IMGLPT IN (''IN30'',''IN40'',''IN60'',''IN65'',''IN80'',''IN85'',''IN10'', ''IN50'')',
'--AND IMSTKT NOT IN (''R'',''X'',''O'')',
'ORDER BY IMLITM'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'.'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(153153428867465201)
,p_name=>'P1000_MET_VAR_PT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(153002903525992250)
,p_prompt=>'Met Var Pt'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(153153595007465202)
,p_name=>'P1000_MET_VAR_MP'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(153002903525992250)
,p_prompt=>'Met Var Pt'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(153154289150465209)
,p_name=>'P1000_ESTANDAR_MP'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(153002903525992250)
,p_prompt=>'Estandar Mp'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(153154301163465210)
,p_name=>'P1000_PERIODO_ACTUAL'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(153002903525992250)
,p_prompt=>'Periodo Actual'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(153154567203465212)
,p_name=>'P1000_ESTANDAR_PT'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(153002903525992250)
,p_prompt=>'Estandar Mp'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308879407902807008)
,p_name=>'P1000_AGOTAMIENTO_MP'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(153002903525992250)
,p_prompt=>'Agotamiento Mp'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308881233883807026)
,p_name=>'P1000_AGOTAMIENTO_PT'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(153002903525992250)
,p_prompt=>'Agotamiento Pt'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(450801367984118317)
,p_name=>'P1000_INICIAL_MP'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(153002903525992250)
,p_prompt=>'Periodo Actual'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(450801436819118318)
,p_name=>'P1000_INICIAL_PT'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(153002903525992250)
,p_prompt=>'Periodo Actual'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(450801692361118320)
,p_name=>'P1000_INVERSION_MP'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(153002903525992250)
,p_prompt=>'Periodo Actual'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(450801728674118321)
,p_name=>'P1000_TOTAL_ESTANDAR_MP'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(153002903525992250)
,p_prompt=>'Periodo Actual'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(450802975466118333)
,p_name=>'P1000_FECHA_DATOS'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(153002903525992250)
,p_prompt=>'Periodo Actual'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(902002001000000070)
,p_name=>'P1000_AGR_TIPO_PRODUCTO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(153002903525992250)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(902002001000000071)
,p_name=>'P1000_AGR_TIPO_GRUPO'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(153002903525992250)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(902002001000000072)
,p_name=>'P1000_AGR_GRUPO'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(153002903525992250)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(902002001000000073)
,p_name=>'P1000_AJ_ID_AJUSTE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(153002903525992250)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(902005001000000012)
,p_name=>'P1000_SOLO_NUEVOS'
,p_item_sequence=>125
,p_item_plug_id=>wwv_flow_imp.id(153002903525992250)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(902005001000000013)
,p_name=>'P1000_NUEVOS_GRUPO'
,p_item_sequence=>5
,p_item_plug_id=>wwv_flow_imp.id(902002001000000060)
,p_prompt=>'Filtrar productos nuevos por categoria o linea'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CASE WHEN TIPO_PRODUCTO=''MATERIA PRIMA'' THEN ''Categoria: '' ELSE ''Linea: '' END || GRUPO D,',
'       TIPO_PRODUCTO || CHR(31) || TIPO_GRUPO || CHR(31) || GRUPO R',
'  FROM (',
'    SELECT DISTINCT STOCK.TIPOPRODUCTO TIPO_PRODUCTO,',
'           CASE WHEN STOCK.TIPOPRODUCTO=''MATERIA PRIMA'' THEN ''CATEGORIA_PLANIFICACION'' ELSE ''LINEA_NEGOCIO'' END TIPO_GRUPO,',
'           CASE WHEN STOCK.TIPOPRODUCTO=''MATERIA PRIMA'' THEN NVL(TRIM(STOCK.CATEGORIAPLANIFICACION),''Sin categoria de planificacion'')',
'                ELSE NVL(TRIM(PROD.LINEANEGOCIO),''Sin linea de negocio'') END GRUPO',
'      FROM T_PPLA_STOCKIDEAL STOCK',
'      LEFT JOIN VT_GZM_PRODUCTO PROD ON TRIM(PROD.COMPANIA)=TRIM(STOCK.COMPANIA) AND TRIM(PROD.CODIGOPRODUCTO)=TRIM(STOCK.CODIGOSKU)',
'     WHERE STOCK.COMPANIA=:G_COMPANIA',
'       AND STOCK.FECHA=:P1000_FECHA_DATOS',
'       AND STOCK.ORIGEN_REGISTRO=''AUTO''',
'  )',
' ORDER BY 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'- Todos los productos nuevos -'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(902002001000000082)
,p_name=>'P1000_AJ_SKU'
,p_item_sequence=>135
,p_item_plug_id=>wwv_flow_imp.id(153002903525992250)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(902002001000000074)
,p_name=>'P1000_AJ_APLICA_MINIMO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(902002001000000060)
,p_prompt=>'Modificar dias minimo'
,p_display_as=>'NATIVE_HIDDEN'
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(902002001000000075)
,p_name=>'P1000_AJ_MINIMO_DIAS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(902002001000000060)
,p_prompt=>'Dias minimo (opcional)'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>15
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'right'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(902002001000000076)
,p_name=>'P1000_AJ_APLICA_MAXIMO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(902002001000000060)
,p_prompt=>'Modificar dias maximo'
,p_display_as=>'NATIVE_HIDDEN'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(902002001000000077)
,p_name=>'P1000_AJ_MAXIMO_DIAS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(902002001000000060)
,p_prompt=>'Dias maximo (opcional)'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>15
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'right'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(902002001000000078)
,p_name=>'P1000_AJ_APLICA_OBSERVACION'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(902002001000000060)
,p_prompt=>'Modificar observacion'
,p_display_as=>'NATIVE_HIDDEN'
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(902002001000000079)
,p_name=>'P1000_AJ_OBSERVACION'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(902002001000000060)
,p_prompt=>'Nueva observacion'
,p_display_as=>'NATIVE_HIDDEN'
,p_cSize=>100
,p_cHeight=>3
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(902002001000000080)
,p_name=>'P1000_AJ_SKU_EXCLUIDOS'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(902002001000000060)
,p_prompt=>'SKU excluidos (opcional, separados por coma)'
,p_display_as=>'NATIVE_HIDDEN'
,p_cSize=>100
,p_cHeight=>2
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(902002001000000081)
,p_name=>'P1000_AJ_MOTIVO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(902002001000000060)
,p_prompt=>'Motivo del ajuste'
,p_display_as=>'NATIVE_HIDDEN'
,p_cSize=>100
,p_cHeight=>3
,p_field_template=>wwv_flow_imp.id(533681551919487559)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(150168272457435943)
,p_name=>'Procesar'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(150166093013435926)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(150168714861435943)
,p_event_id=>wwv_flow_imp.id(150168272457435943)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00DAnicamente se reprocesar\00E1 el periodo vigente')
,p_attribute_02=>unistr('\00BFEst\00E1 seguro de ejecutar esta acci\00F3n?')
,p_attribute_03=>'danger'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(150357256888727446)
,p_event_id=>wwv_flow_imp.id(150168272457435943)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(150169261269435943)
,p_event_id=>wwv_flow_imp.id(150168272457435943)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'PK_PPLA_TAREAS_AUTOMATICAS.SP_CALCULARSTOCKIDEAL(TO_NUMBER(:P1000_PERIODO_ACTUAL),:G_COMPANIA,:APP_USER);'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(153154447338465211)
,p_event_id=>wwv_flow_imp.id(150168272457435943)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(150169739553435943)
,p_event_id=>wwv_flow_imp.id(150168272457435943)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(153153797068465204)
,p_name=>'New'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1000_PERIODO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(153153804783465205)
,p_event_id=>wwv_flow_imp.id(153153797068465204)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(124618796915893310)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(153153998148465206)
,p_name=>'New_1'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1000_CATEOGRIA_PLANIFICACION'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(153154007457465207)
,p_event_id=>wwv_flow_imp.id(153153998148465206)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(124618796915893310)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(153154692373465213)
,p_name=>'New_2'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1000_TIPO_PRODUCTO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(153154710855465214)
,p_event_id=>wwv_flow_imp.id(153154692373465213)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(124618796915893310)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(153154886065465215)
,p_name=>'New_3'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1000_PRODUCTO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(153154922529465216)
,p_event_id=>wwv_flow_imp.id(153154886065465215)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(124618796915893310)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(450801992591118323)
,p_name=>'New_4'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(450801861490118322)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(450802034361118324)
,p_event_id=>wwv_flow_imp.id(450801992591118323)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(902002001000000092)
,p_name=>'Volver a Resumen'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(902002001000000090)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(902002001000000093)
,p_event_id=>wwv_flow_imp.id(902002001000000092)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'pplaVolverResumen();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(902002001000000094)
,p_name=>'Volver a Analisis'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(902002001000000091)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(902002001000000095)
,p_event_id=>wwv_flow_imp.id(902002001000000094)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'pplaVolverAnalisis();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(902005001000000014)
,p_name=>'Filtrar productos nuevos'
,p_event_sequence=>95
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1000_NUEVOS_GRUPO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(902005001000000015)
,p_event_id=>wwv_flow_imp.id(902005001000000014)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'pplaFiltrarProductosNuevos(apex.item(''P1000_NUEVOS_GRUPO'').getValue());'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(902002001000000096)
,p_name=>'Guardar ajuste sin recargar detalle'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(902002001000000061)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(902002001000000097)
,p_event_id=>wwv_flow_imp.id(902002001000000096)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (apex.item(''P1000_SOLO_NUEVOS'').getValue() === ''S'' && !apex.item(''P1000_AGR_GRUPO'').getValue()) {',
'  apex.message.showErrors([{ type: ''error'', location: ''page'', message: ''Seleccione una categoria o linea antes de aplicar un ajuste masivo a productos nuevos.'', unsafe: false }]);',
'  return;',
'}',
'mostrarBarra();',
'apex.server.process(''GUARDAR_AJUSTE_SKU'', { pageItems: ''#P1000_FECHA_DATOS,#P1000_AGR_TIPO_PRODUCTO,#P1000_AGR_TIPO_GRUPO,#P1000_AGR_GRUPO,#P1000_AJ_SKU,#P1000_AJ_MINIMO_DIAS,#P1000_AJ_MAXIMO_DIAS'' }, {',
'  dataType: ''text'',',
'  success: function () {',
'    ocultarBarra();',
'    apex.item(''P1000_AJ_SKU'').setValue('''');',
'    apex.item(''P1000_AJ_MINIMO_DIAS'').setValue('''');',
'    apex.item(''P1000_AJ_MAXIMO_DIAS'').setValue('''');',
'    pplaMostrarVista(''DETALLE'');',
'    apex.region(''ppla_detalle_stock'').refresh();',
'    apex.message.showPageSuccess(''Ajuste guardado correctamente.'');',
'  },',
'  error: function (jqXHR, textStatus, errorThrown) {',
'    ocultarBarra();',
'    apex.message.clearErrors();',
'    apex.message.showErrors([{ type: ''error'', location: ''page'', message: ''No fue posible guardar el ajuste. '' + (jqXHR.responseText || errorThrown || ''''), unsafe: false }]);',
'  }',
'});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(902002001000000098)
,p_name=>'Guardar y recalcular sin recargar detalle'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(902002001000000062)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(902002001000000099)
,p_event_id=>wwv_flow_imp.id(902002001000000098)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mostrarBarra();',
'apex.server.process(''GUARDAR_Y_RECALCULAR_AJUSTE'', { pageItems: ''#P1000_FECHA_DATOS,#P1000_AGR_TIPO_PRODUCTO,#P1000_AGR_TIPO_GRUPO,#P1000_AGR_GRUPO,#P1000_AJ_SKU,#P1000_AJ_MINIMO_DIAS,#P1000_AJ_MAXIMO_DIAS'' }, {',
'  dataType: ''text'',',
'  success: function (mensaje) {',
'    ocultarBarra();',
'    apex.item(''P1000_AJ_SKU'').setValue('''');',
'    apex.item(''P1000_AJ_MINIMO_DIAS'').setValue('''');',
'    apex.item(''P1000_AJ_MAXIMO_DIAS'').setValue('''');',
'    pplaMostrarVista(''DETALLE'');',
'    apex.region(''ppla_detalle_stock'').refresh();',
'    apex.message.showPageSuccess(mensaje || ''Cambios guardados y recalculo solicitado.'');',
'  },',
'  error: function (jqXHR, textStatus, errorThrown) {',
'    ocultarBarra();',
'    apex.message.clearErrors();',
'    apex.message.showErrors([{ type: ''error'', location: ''page'', message: jqXHR.responseText || errorThrown || ''No fue posible guardar y recalcular el ajuste.'', unsafe: false }]);',
'  }',
'});'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(153153652094465203)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga Datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'EXECUTE IMMEDIATE ''ALTER SESSION SET NLS_NUMERIC_CHARACTERS = ''''.,'''''';',
'',
'SELECT VALOR ',
'INTO :P1000_MET_VAR_PT',
'FROM T_CORP_UDC',
'WHERE ID_CABECERA=''PPLA_PARAM'' AND ID_TABLA=''PAR9'' AND ACTIVO=1 AND CODIGOCOMPANIA = :G_COMPANIA;',
'',
'SELECT VALOR ',
'INTO :P1000_MET_VAR_MP',
'FROM T_CORP_UDC',
'WHERE ID_CABECERA=''PPLA_PARAM'' AND ID_TABLA=''PAR10'' AND ACTIVO=1 AND CODIGOCOMPANIA = :G_COMPANIA;',
'',
':P1000_PERIODO_ACTUAL := TO_CHAR(SYSDATE,''YYYYMM'');',
'SELECT NVL(MAX(FECHA), TO_NUMBER(TO_CHAR(ADD_MONTHS(SYSDATE,-1),''YYYYMM'')))',
'INTO :P1000_FECHA_DATOS',
'FROM T_PPLA_STOCKIDEAL',
'WHERE COMPANIA=:G_COMPANIA',
'AND FECHA <= TO_NUMBER(TO_CHAR(ADD_MONTHS(SYSDATE,-1),''YYYYMM''));',
'',
'SELECT ',
'SUM(',
'    CASE WHEN CODTIPO IN (''SEM   '',''PTE   '') THEN STOCKINICIALIDEAL*(COUNCS/10000) ELSE 0 END',
'),',
'SUM(',
'    CASE WHEN CODTIPO NOT IN (''SEM   '',''PTE   '') THEN STOCKINICIALIDEAL*(COUNCS/10000) ELSE 0 END',
')',
'INTO :P1000_ESTANDAR_PT,:P1000_ESTANDAR_MP',
'FROM  T_PPLA_PRODUCTOSTOCKIDEAL X,VT_JDE_PRODUCTOS Y,F4105@JDEDTADL',
'WHERE X.CODIGOPRODUCTO=Y.CODIGOPRODUCTO',
'AND X.CODIGOPRODUCTO=TRIM(COLITM) AND TO_CHAR(FECHAHASTA,''YYYYMMDD'')>TO_CHAR(SYSDATE,''YYYYMMDD'')',
'AND COMCU= CASE WHEN CODTIPO IN (''SEM   '',''PTE   '') THEN ''       17003'' ELSE ''       17001'' END',
'AND COCSIN=''I'';',
'',
'',
'-- :P1000_ESTANDAR_MP := :P1000_ESTANDAR_MP + 900000;',
'-- :P1000_ESTANDAR_PT := :P1000_ESTANDAR_PT + 700000;',
'',
'SELECT NVL(MAX(CASE WHEN ID_TABLA=''PAR13'' THEN TO_NUMBER(VALOR) END),0),',
'       NVL(MAX(CASE WHEN ID_TABLA=''PAR14'' THEN TO_NUMBER(VALOR) END),0)',
'  INTO :P1000_AGOTAMIENTO_MP, :P1000_INVERSION_MP',
'  FROM T_CORP_UDC',
' WHERE ID_CABECERA=''PPLA_PARAM''',
'   AND ID_TABLA IN (''PAR13'',''PAR14'')',
'   AND ACTIVO=1',
'   AND CODIGOCOMPANIA=:G_COMPANIA;',
':P1000_TOTAL_ESTANDAR_MP := TO_NUMBER(:P1000_ESTANDAR_MP) + TO_NUMBER(:P1000_AGOTAMIENTO_MP) + TO_NUMBER(:P1000_INVERSION_MP);',
'',
'SELECT NVL(SUM(NVL(PROMEDIOINVENTARIOUSD,0)),0)',
'INTO :P1000_AGOTAMIENTO_PT',
'FROM T_PPLA_STOCKIDEAL ',
'WHERE COMPANIA = :G_COMPANIA',
'AND FECHA = :P1000_FECHA_DATOS',
'AND METODOCALCULO = ''AGOTAMIENTO''',
'AND TIPOPRODUCTO = ''PRODUCTO TERMINADO'';',
'',
'SELECT NVL(SUM(NVL(INICIALUSD,0)),0)',
'INTO :P1000_INICIAL_MP',
'FROM T_PPLA_STOCKIDEAL ',
'WHERE COMPANIA = :G_COMPANIA',
'AND FECHA = :P1000_FECHA_DATOS',
'AND TIPOPRODUCTO = ''MATERIA PRIMA'';',
'',
'SELECT NVL(SUM(NVL(INICIALUSD,0)),0)',
'INTO :P1000_INICIAL_PT',
'FROM T_PPLA_STOCKIDEAL ',
'WHERE COMPANIA = :G_COMPANIA',
'AND FECHA = :P1000_FECHA_DATOS',
'AND TIPOPRODUCTO = ''PRODUCTO TERMINADO'';',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>153153652094465203
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(902002001000000090)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Guardar ajuste de grupo'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    V_ID_AJUSTE NUMBER;',
'    V_ACTUALIZADOS NUMBER;',
'    V_OMITIDOS NUMBER;',
'    V_RECHAZADOS NUMBER;',
'BEGIN',
'    PK_PPLA_STOCKIDEAL.SP_GUARDAR_AJUSTE(',
'        P_COMPANIA => :G_COMPANIA,',
'        P_PERIODO => TO_NUMBER(:P1000_FECHA_DATOS),',
'        P_TIPO_PRODUCTO => :P1000_AGR_TIPO_PRODUCTO,',
'        P_TIPO_GRUPO => :P1000_AGR_TIPO_GRUPO,',
'        P_GRUPO => :P1000_AGR_GRUPO,',
'        P_CODIGO_SKU => :P1000_AJ_SKU,',
'        P_APLICA_MINIMO => CASE WHEN :P1000_AJ_MINIMO_DIAS IS NULL THEN 0 ELSE 1 END,',
'        P_MINIMO_DIAS => :P1000_AJ_MINIMO_DIAS,',
'        P_APLICA_MAXIMO => CASE WHEN :P1000_AJ_MAXIMO_DIAS IS NULL THEN 0 ELSE 1 END,',
'        P_MAXIMO_DIAS => :P1000_AJ_MAXIMO_DIAS,',
'        P_APLICA_OBSERVACION => 0,',
'        P_OBSERVACION => NULL,',
'        P_SKU_EXCLUIDOS => NULL,',
'        P_MOTIVO => ''Ajuste desde pagina 1000'',',
'        P_USUARIO => :APP_USER,',
'        P_ID_AJUSTE => V_ID_AJUSTE,',
'        P_ACTUALIZADOS => V_ACTUALIZADOS,',
'        P_OMITIDOS => V_OMITIDOS,',
'        P_RECHAZADOS => V_RECHAZADOS);',
'    :P1000_AJ_ID_AJUSTE := V_ID_AJUSTE;',
'    APEX_APPLICATION.G_PRINT_SUCCESS_MESSAGE := ''Cambios guardados; pendiente recalculo. Actualizados: ''||V_ACTUALIZADOS||'', omitidos: ''||V_OMITIDOS||'', rechazados: ''||V_RECHAZADOS||''.'';',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'No fue posible guardar el ajuste. Revise los datos ingresados.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(902002001000000061)
,p_internal_uid=>902002001000000090
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(902002001000000091)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Guardar y recalcular grupo'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    V_ID_AJUSTE NUMBER;',
'    V_ACTUALIZADOS NUMBER;',
'    V_OMITIDOS NUMBER;',
'    V_RECHAZADOS NUMBER;',
'    V_ID_JOB NUMBER;',
'    V_MENSAJE VARCHAR2(4000);',
'BEGIN',
'    PK_PPLA_STOCKIDEAL.SP_GUARDAR_AJUSTE(',
'        P_COMPANIA => :G_COMPANIA,',
'        P_PERIODO => TO_NUMBER(:P1000_FECHA_DATOS),',
'        P_TIPO_PRODUCTO => :P1000_AGR_TIPO_PRODUCTO,',
'        P_TIPO_GRUPO => :P1000_AGR_TIPO_GRUPO,',
'        P_GRUPO => :P1000_AGR_GRUPO,',
'        P_CODIGO_SKU => :P1000_AJ_SKU,',
'        P_APLICA_MINIMO => CASE WHEN :P1000_AJ_MINIMO_DIAS IS NULL THEN 0 ELSE 1 END,',
'        P_MINIMO_DIAS => :P1000_AJ_MINIMO_DIAS,',
'        P_APLICA_MAXIMO => CASE WHEN :P1000_AJ_MAXIMO_DIAS IS NULL THEN 0 ELSE 1 END,',
'        P_MAXIMO_DIAS => :P1000_AJ_MAXIMO_DIAS,',
'        P_APLICA_OBSERVACION => 0,',
'        P_OBSERVACION => NULL,',
'        P_SKU_EXCLUIDOS => NULL,',
'        P_MOTIVO => ''Ajuste desde pagina 1000'',',
'        P_USUARIO => :APP_USER,',
'        P_ID_AJUSTE => V_ID_AJUSTE,',
'        P_ACTUALIZADOS => V_ACTUALIZADOS,',
'        P_OMITIDOS => V_OMITIDOS,',
'        P_RECHAZADOS => V_RECHAZADOS);',
'    :P1000_AJ_ID_AJUSTE := V_ID_AJUSTE;',
'    PK_PPLA_STOCKIDEAL.SP_SOLICITAR_RECALCULO(V_ID_AJUSTE,:G_COMPANIA,:APP_USER,V_ID_JOB,V_MENSAJE);',
'    APEX_APPLICATION.G_PRINT_SUCCESS_MESSAGE := ''Cambios guardados. ''||V_MENSAJE||'' Actualizados: ''||V_ACTUALIZADOS||'', omitidos: ''||V_OMITIDOS||'', rechazados: ''||V_RECHAZADOS||''.'';',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'No fue posible guardar y recalcular el ajuste. Revise los datos ingresados.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(902002001000000062)
,p_internal_uid=>902002001000000091
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(902002001000000100)
,p_process_sequence=>50
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GUARDAR_Y_RECALCULAR_AJUSTE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE V_ID NUMBER; V_A NUMBER; V_O NUMBER; V_R NUMBER; V_EXITO NUMBER; V_MENSAJE VARCHAR2(4000);',
'BEGIN',
' IF :P1000_AJ_MINIMO_DIAS IS NOT NULL OR :P1000_AJ_MAXIMO_DIAS IS NOT NULL THEN',
'   PK_PPLA_STOCKIDEAL.SP_GUARDAR_AJUSTE(P_COMPANIA=>:G_COMPANIA,P_PERIODO=>TO_NUMBER(:P1000_FECHA_DATOS),P_TIPO_PRODUCTO=>:P1000_AGR_TIPO_PRODUCTO,P_TIPO_GRUPO=>:P1000_AGR_TIPO_GRUPO,P_GRUPO=>:P1000_AGR_GRUPO,P_CODIGO_SKU=>:P1000_AJ_SKU,P_APLICA_MINIMO=>CASE WHEN :P1000_AJ_MINIMO_DIAS IS NULL THEN 0 ELSE 1 END,P_MINIMO_DIAS=>:P1000_AJ_MINIMO_DIAS,P_APLICA_MAXIMO=>CASE WHEN :P1000_AJ_MAXIMO_DIAS IS NULL THEN 0 ELSE 1 END,P_MAXIMO_DIAS=>:P1000_AJ_MAXIMO_DIAS,P_APLICA_OBSERVACION=>0,P_OBSERVACION=>NULL,P_SKU_EXCLUIDOS=>NULL,P_MOTIVO=>''Ajuste desde pagina 1000'',P_USUARIO=>:APP_USER,P_ID_AJUSTE=>V_ID,P_ACTUALIZADOS=>V_A,P_OMITIDOS=>V_O,P_RECHAZADOS=>V_R);',
' ELSE',
'   SELECT MAX(ID_AJUSTE) INTO V_ID FROM T_PPLA_STOCKIDEAL_AJUSTE_CAB WHERE COMPANIA=:G_COMPANIA AND PERIODO=TO_NUMBER(:P1000_FECHA_DATOS) AND TIPO_PRODUCTO=:P1000_AGR_TIPO_PRODUCTO AND TIPO_GRUPO=:P1000_AGR_TIPO_GRUPO AND GRUPO=:P1000_AGR_GRUPO AND ESTADO IN (''PENDIENTE_RECALCULO'',''ERROR_RECALCULO'');',
'   IF V_ID IS NULL THEN RAISE_APPLICATION_ERROR(-20001,''No existe un ajuste pendiente para el grupo seleccionado. Edite primero un producto o ingrese dias para un ajuste masivo.''); END IF;',
' END IF;',
' PK_PPLA_STOCKIDEAL.SP_RECALCULAR_AJUSTE(V_ID,:G_COMPANIA,:APP_USER,V_EXITO,V_MENSAJE);',
' HTP.P(CASE WHEN V_EXITO=1 THEN ''Cambios guardados y recalculados. '' ELSE ''Cambios guardados; '' END || V_MENSAJE || '' Actualizados: ''||V_A||''.'');',
'EXCEPTION WHEN OTHERS THEN',
' HTP.P(''No fue posible guardar y recalcular: ''||SQLERRM);',
' RAISE;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'No fue posible guardar y recalcular el ajuste.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>902002001000000100
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(902002001000000093)
,p_process_sequence=>40
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GUARDAR_AJUSTE_SKU'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE V_ID NUMBER; V_A NUMBER; V_O NUMBER; V_R NUMBER;',
'BEGIN',
' PK_PPLA_STOCKIDEAL.SP_GUARDAR_AJUSTE(P_COMPANIA=>:G_COMPANIA,P_PERIODO=>TO_NUMBER(:P1000_FECHA_DATOS),P_TIPO_PRODUCTO=>:P1000_AGR_TIPO_PRODUCTO,P_TIPO_GRUPO=>:P1000_AGR_TIPO_GRUPO,P_GRUPO=>:P1000_AGR_GRUPO,P_CODIGO_SKU=>:P1000_AJ_SKU,P_APLICA_MINIMO=>CASE WHEN :P1000_AJ_MINIMO_DIAS IS NULL THEN 0 ELSE 1 END,P_MINIMO_DIAS=>:P1000_AJ_MINIMO_DIAS,P_APLICA_MAXIMO=>CASE WHEN :P1000_AJ_MAXIMO_DIAS IS NULL THEN 0 ELSE 1 END,P_MAXIMO_DIAS=>:P1000_AJ_MAXIMO_DIAS,P_APLICA_OBSERVACION=>0,P_OBSERVACION=>NULL,P_SKU_EXCLUIDOS=>NULL,P_MOTIVO=>''Ajuste individual desde pagina 1000'',P_USUARIO=>:APP_USER,P_ID_AJUSTE=>V_ID,P_ACTUALIZADOS=>V_A,P_OMITIDOS=>V_O,P_RECHAZADOS=>V_R);',
' apex_json.open_object; apex_json.write(''actualizados'',V_A); apex_json.close_object;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'No fue posible guardar el SKU seleccionado.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>902002001000000093
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
