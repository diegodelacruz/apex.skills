prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>140
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 140 - PLANIFICACION
--
-- Application Export:
--   Application:     140
--   Name:            PLANIFICACION
--   Date and Time:   14:34 Tuesday July 28, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 109
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_00109
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>109);
end;
/
prompt --application/pages/page_00109
begin
wwv_flow_imp_page.create_page(
 p_id=>109
,p_name=>unistr('Costo Est\00E1ndar ')
,p_alias=>'COSTO-STANDAR'
,p_step_title=>unistr('Est\00E1ndar ')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(308881672684807030)
,p_plug_name=>unistr('Est\00E1ndar')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(535720918100545250)
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(533583382097487435)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(533683083484487562)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(308881765781807031)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(535719775917545246)
,p_plug_display_sequence=>50
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(533583382097487435)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(533683083484487562)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(779755480000027081)
,p_plug_name=>'Stock Inicial'
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_imp.id(533636752386487514)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(779755555436027082)
,p_plug_name=>'Detalle'
,p_region_name=>'rptDetalle'
,p_parent_plug_id=>wwv_flow_imp.id(779755480000027081)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(533628879219487509)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT Y.DEPARTAMENTO DIVISION,Y.LINEANEGOCIO,Y.MARCA,Y.SUBMARCA,Y.NOMBREPRODUCTO||'' ''||Y.CODIGOALTERNO NOMBRE,X.CODIGOPRODUCTO,X.COSTOSTANDARD',
'FROM T_PPLA_PRODUCTOS_COSTO_STANDARD X',
'JOIN VT_JDE_PRODUCTOS Y ON TRIM(X.CODIGOPRODUCTO)=TRIM(Y.CODIGOPRODUCTO) AND TRIM(X.COMPANIA)=TRIM(Y.COMPANIA)',
'--AND TO_CHAR(FECHAHASTA,''YYYYMMDD'')>TO_CHAR(SYSDATE,''YYYYMMDD'')',
'AND FECHAHASTA > SYSDATE',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Detalle'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(794015669741637265)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MALBAN'
,p_internal_uid=>794015669741637265
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(794015757125637266)
,p_db_column_name=>'LINEANEGOCIO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>unistr('L\00EDnea de Negocio')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(794015861937637267)
,p_db_column_name=>'MARCA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Marca'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(794015948387637268)
,p_db_column_name=>'SUBMARCA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Submarca'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(794016074610637269)
,p_db_column_name=>'NOMBRE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(794016240882637270)
,p_db_column_name=>'CODIGOPRODUCTO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>unistr('C\00F3digo Producto')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(308881852533807032)
,p_db_column_name=>'DIVISION'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Division'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(308881965014807033)
,p_db_column_name=>'COSTOSTANDARD'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>unistr('Est\00E1ndar')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(794031781208639902)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'4434831'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>1000
,p_report_columns=>'DIVISION:LINEANEGOCIO:MARCA:SUBMARCA:CODIGOPRODUCTO:NOMBRE:COSTOSTANDARD:'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(779755699992027083)
,p_name=>'Resumen'
,p_parent_plug_id=>wwv_flow_imp.id(779755480000027081)
,p_template=>wwv_flow_imp.id(535720157374545246)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH F4105_FILTRADA AS (',
'    SELECT COLITM, COMCU',
'    FROM F4105@JDEDTADL',
'    WHERE COCSIN = ''I''',
')',
'SELECT ',
'    CASE ',
'        WHEN Y.CODTIPO IN (''SEM   '',''PTE   '') THEN ''PRODUCTO TERMINADO''',
'        ELSE ''MATERIA PRIMA''',
'    END AS TIPO,',
'    SUM(X.COSTOSTANDARD) AS VALOR2',
'FROM T_PPLA_PRODUCTOS_COSTO_STANDARD X',
'JOIN VT_JDE_PRODUCTOS Y',
'    ON TRIM(X.CODIGOPRODUCTO) = TRIM(Y.CODIGOPRODUCTO) AND TRIM(X.COMPANIA) = TRIM(Y.COMPANIA)',
'JOIN F4105_FILTRADA F',
'    ON RPAD(X.CODIGOPRODUCTO, 25) = F.COLITM',
'   AND F.COMCU = CASE ',
'                    WHEN Y.CODTIPO IN (''SEM   '',''PTE   '') THEN ''       17003''',
'                    ELSE ''       17001''',
'                 END',
'WHERE X.FECHAHASTA > SYSDATE',
'GROUP BY CASE ',
'        WHEN Y.CODTIPO IN (''SEM   '',''PTE   '') THEN ''PRODUCTO TERMINADO''',
'        ELSE ''MATERIA PRIMA''         END'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(533654280455487531)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(308882213293807036)
,p_query_column_id=>1
,p_column_alias=>'TIPO'
,p_column_display_sequence=>10
,p_column_heading=>'Tipo'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(350557003803919887)
,p_query_column_id=>2
,p_column_alias=>'VALOR2'
,p_column_display_sequence=>20
,p_column_heading=>unistr('Est\00E1ndar')
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(350550059258919866)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(308881765781807031)
,p_button_name=>'Formato'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(533682160901487559)
,p_button_image_alt=>'Descargar Formato'
,p_button_redirect_url=>'#APP_FILES#formato standard.xlsx'
,p_icon_css_classes=>'fa-box-arrow-in-south'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(350549672846919864)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(308881765781807031)
,p_button_name=>'Subir'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(533682160901487559)
,p_button_image_alt=>'Subir informacion de costos estandar'
,p_button_redirect_url=>'f?p=100:300:&SESSION.::&DEBUG.:RP,300::'
,p_icon_css_classes=>'fa-box-arrow-out-north'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(350550459245919866)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(308881765781807031)
,p_button_name=>'Actualizar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(533682160901487559)
,p_button_image_alt=>'Actualizar Stock'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from VT_APEX_EXCEL;'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(350559937049919915)
,p_name=>'Cierre dialogo subir archivo'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(350549672846919864)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(350560473404919918)
,p_event_id=>wwv_flow_imp.id(350559937049919915)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'Subir'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(350560854352919919)
,p_name=>'confirmar'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(350550459245919866)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(350561398902919919)
,p_event_id=>wwv_flow_imp.id(350560854352919919)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEst\00E1 seguro de realizar la actualizaci\00F3n?')
,p_attribute_03=>'danger'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(350561875173919920)
,p_event_id=>wwv_flow_imp.id(350560854352919919)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'PK_PPLA_CONFIGURACION.SP_ACTUALIZA_STOCKSTANDARD(:G_COMPANIA,:APP_USER);'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(350562396008919920)
,p_event_id=>wwv_flow_imp.id(350560854352919919)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(350559549117919913)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga_excel'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- proceso el archivo cargado',
'PK_PPLA_CONFIGURACION.SP_PROCESACARGASCOSTOSTANDARD(:G_COMPANIA,:APP_USER);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(350549672846919864)
,p_internal_uid=>350559549117919913
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
