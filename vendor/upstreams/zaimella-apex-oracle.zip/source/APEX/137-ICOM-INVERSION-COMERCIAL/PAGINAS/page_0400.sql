﻿prompt --application/set_environment
set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- Oracle APEX export file
--
-- You should run this script using a SQL client connected to the database as
-- the owner (parsing schema) of the application or as a database user with the
-- APEX_ADMINISTRATOR_ROLE role.
--
-- This export file has been automatically generated. Modifying this file is not
-- supported by Oracle and can lead to unexpected application and/or instance
-- behavior now or in the future.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_imp.import_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>137
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
end;
/
 
prompt APPLICATION 137 - InversiÃ³n comercial
--
-- Application Export:
--   Application:     137
--   Name:            InversiÃ³n comercial
--   Date and Time:   09:06 Tuesday July 7, 2026
--   Exported By:     DATA
--   Flashback:       0
--   Export Type:     Page Export
--   Manifest
--     PAGE: 400
--   Manifest End
--   Version:         24.1.3
--   Instance ID:     800138191179969
--

begin
null;
end;
/
prompt --application/pages/delete_00400
begin
wwv_flow_imp_page.remove_page (p_flow_id=>wwv_flow.g_flow_id, p_page_id=>400);
end;
/
prompt --application/pages/page_00400
begin
wwv_flow_imp_page.create_page(
 p_id=>400
,p_name=>'Mesa de trabajo'
,p_step_title=>'Mesa de trabajo'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function tablaGrupo($row, inicio, total ){',
'        if ( total === 0 ){',
'            return;',
'        }',
'        var i, index = inicio, cont=1, lst=[] ;',
'        var tds = $row.find(''td:eq(''+index+'')'');',
'        var ctrl = $(tds[0]);',
'        lst.push($row[0]);',
'        for ( i=1; i<=tds.length; i++ ){',
'            if (ctrl.text()==$(tds[i]).text()){',
'                cont++;',
'                $(tds[i]).addClass(''deleted'');',
'                lst.push($row[i]);',
'            }else{',
'                if(cont>1){',
'                    ctrl.attr(''rowspan'',cont);',
'                    tablaGrupo($(lst), index+1, total-1 );',
'                }',
'                cont = 1;',
'                lst = [];',
'                ctrl = $(tds[i]);',
'                lst.push($row[i]);',
'            }',
'',
'        }',
'    }',
'    ',
'$ ( function() {    ',
'    tablaGrupo($(''#tbTrazabilidad tr:has(td)''),0,2);',
'    $(''#tbTrazabilidad .deleted'').remove();',
'});',
'',
'function actulizarTablas(){',
'    var tipo=$v(''P400_TIPO'');',
'console.log("actualiza tablas: "+tipo);',
'    if(tipo==''#tabInversion'' ||tipo=='''' ){',
'',
'        apex.region("tblInversion").refresh();',
'    }',
'    else if(tipo==''#tabNegociacion''){',
'',
'        apex.region("tblCliente").refresh();',
'		apex.region("tblDescuento").refresh();',
'        apex.region("tblDescuentoInactivacion").refresh();',
'    }',
'	else if(tipo==''#tabImplementa''){',
'',
'        apex.region("tblProceso").refresh();',
'    }',
'	else if(tipo==''#tblValidacion''){',
'',
'        apex.region("tblValidacion").refresh();',
'    }',
'    else if(tipo==''#tabMonitoreo''){',
'',
'         var iframe = document.getElementById("powerBIFrame");',
'        if (iframe) {',
'            // Recarga el iframe usando el mismo src',
'            iframe.src = iframe.src;',
'        }',
'    }',
'    else if(tipo==''#tabPDVSinasignar''){',
'        apex.region("listadoPdvSinAsignar").refresh();',
'    }',
'    ',
'',
'    ',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''.apex-rds'').data(''onRegionChange'', function(mode, activeTab) {',
'    apex.item( "P400_TIPO" ).setValue(activeTab.href);',
'});'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'li.a-IRR-controls-item.a-IRR-controls-item--controlBreak,',
'li.a-IRR-reportSummary-item.a-IRR-reportSummary-item--controlBreak,',
'li#SHOW_ALL_tab  {',
'    display: none;',
'}',
'',
'',
'#rgnAnio .container {',
'    WIDTH: 160px;',
'}',
'',
'#rgnMes .container {',
'    WIDTH: 400px;',
'}',
'',
'',
'    ',
'.duracion {',
'    background-color: cornflowerblue !important;',
'    font-size: 2.6rem !important;',
'    line-height: 1rem !important;',
'    color: white !important;',
'    padding: 11px !important;',
'}',
'',
'.inicia {',
'    background-color: red !important;',
'    font-size: 2.6rem !important;',
'    line-height: 1rem !important;',
'    color: white !important;',
'    padding: 11px !important;',
'}',
'',
'#report_tbTrazabilidad.t-Report tr .t-Report-colHead {',
'    background-color: rgb(0, 0, 128);',
'    font-weight: bold;',
'    color: white;',
'}',
'',
'#report_tbTrazabilidad.t-Report tr td[headers*="ETAPA"]',
'{',
'    background-color: #73a6c1!important;',
'    color: white;',
'}',
'',
'#report_tbTrazabilidad.t-Report tr td[headers*="ORIGEN"]',
'{',
'    background-color: #adc6d4!important;',
'}',
'',
'.t-fht-thead{',
'  overflow: auto !important;',
'}',
'',
'th#DISTRIBUIDOR, ',
'td[headers="DISTRIBUIDOR"] {',
'    width: 2000px !important;',
'    white-space: nowrap;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(66767765596004746)
,p_plug_name=>'Mesa de trabajo'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(66450403430391136)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(65921922062345197)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(66021687114345242)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(66767878384004747)
,p_plug_name=>'Barra de accion'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(66449263692391136)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(96158064080462004)
,p_plug_name=>'Modal Asignar Pago Recurrente'
,p_region_name=>'dialogoAsignarPagoRecurrente'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size720x480'
,p_plug_template=>wwv_flow_imp.id(65965332063345222)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_04'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(96158674233462010)
,p_plug_name=>'Formulario'
,p_parent_plug_id=>wwv_flow_imp.id(96158064080462004)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(66449693245391136)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(96158985777462013)
,p_plug_name=>'Botones'
,p_parent_plug_id=>wwv_flow_imp.id(96158674233462010)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(66450057576391136)
,p_plug_display_sequence=>40
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(102296245454789436)
,p_plug_name=>'Negociaciones disponibles'
,p_title=>'Negociaciones disponibles'
,p_region_name=>'negociacionesDisponibles'
,p_parent_plug_id=>wwv_flow_imp.id(96158674233462010)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(65967409977345223)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('select DISTINCT a.ID || '' - '' || a.observacion observacion, a.ID, APEX_ITEM.CHECKBOX2(20, a.ID, '' '' ||'' class="chkF02"'' ) AS sel_pdv -- \00EDndice 10'),
',a.vigenciadesde DESDE,a.vigenciahasta HASTA',
'from DATA.t_comp_negociacion a',
'inner join DATA.t_comp_negociacioncab b on a.id = b.idneg ',
'where a.recurrente = ''SI'' and b.UNIDADNEGOCIO in (''BUSINESSINT'',''TRADE'',''VTSIE6'')',
'and a.estadoflujo = ''APROBADO'' ',
'--omito las que ya estan asignadas a la seleccionada',
'AND NOT EXISTS (',
'    select 1 ',
'    FROM DATA.vt_icom_inversion_pago_recurrente inv',
'    WHERE inv.IDINVERSION = :P400_ID_INVERSION',
'      AND inv.IDPAGO = a.ID',
')',
'--que el anio de inicio de la inversion coincida con el anio de la negociacion',
'AND EXTRACT(YEAR FROM (',
'      SELECT FECHAINICIO ',
'      FROM DATA.T_ICOM_INVERSIONES ',
'      WHERE ID = :P400_ID_INVERSION',
')) = EXTRACT(YEAR FROM a.vigenciadesde)',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Negociaciones disponibles'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3><strong>Pagos Disponibles</strong></h3>',
''))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(102296434546789438)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>102296434546789438
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102296671845789440)
,p_db_column_name=>'ID'
,p_display_order=>20
,p_is_primary_key=>'Y'
,p_column_identifier=>'B'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104991156425056702)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(104991229814056703)
,p_db_column_name=>'SEL_PDV'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Sel'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(190044897487606213)
,p_db_column_name=>'DESDE'
,p_display_order=>50
,p_column_identifier=>'G'
,p_column_label=>'Desde'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(190044926747606214)
,p_db_column_name=>'HASTA'
,p_display_order=>60
,p_column_identifier=>'H'
,p_column_label=>'Hasta'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(104924994372776650)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1049250'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'OBSERVACION:SEL_PDV:DESDE:HASTA:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(102296733370789441)
,p_plug_name=>'Negociaciones seleccionadas'
,p_title=>'Negociaciones seleccionadas'
,p_parent_plug_id=>wwv_flow_imp.id(96158674233462010)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(65967409977345223)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>'select IDPAGO, OBSERVACION from vt_icom_inversion_pago_recurrente  where IDINVERSION= :P400_ID_INVERSION;'
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P400_ID_INVERSION'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Negociaciones seleccionadas'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h3><strong>Pagos Asignados</strong></h3>',
''))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(102296872534789442)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>102296872534789442
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102297167798789445)
,p_db_column_name=>'IDPAGO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Idpago'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102297225979789446)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(104927113312805333)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1049272'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'IDPAGO:OBSERVACION'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(99946222142054027)
,p_plug_name=>'Formulario'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(66449693245391136)
,p_plug_display_sequence=>20
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(99946386738054028)
,p_plug_name=>'Mesa Trabajo'
,p_parent_plug_id=>wwv_flow_imp.id(99946222142054027)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(66449693245391136)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'SESSION')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(88213287684774801)
,p_plug_name=>'PDV Sin asignar'
,p_region_name=>'tabPDVSinasignar'
,p_parent_plug_id=>wwv_flow_imp.id(99946386738054028)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(66449693245391136)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES (P_CODIGOMODULO => :APP_MODULO , P_CODIGOUSUARIO => :APP_USER ',
'                                                                                    , P_RUTAPAGINA => 400 , P_CODIGOACCION => ''ASIGNAR_PDV'')=1'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(88214903596774818)
,p_plug_name=>'Listado pdv'
,p_region_name=>'listadoPdvSinAsignar'
,p_parent_plug_id=>wwv_flow_imp.id(88213287684774801)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(65967409977345223)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with PDV_CANDIDATOS as (SELECT ',
'    cli.codigopdv,',
'    ROUND(SUM(NVL(ms.valorventa,0))/:P400_NMESES_BUSQUEDA_SIN_ASGINAR,2) AS promedio_venta ',
'FROM T_TRAD_CLIENTE cli ',
'JOIN T_TRAD_CLIENTELOCAL t_cloc ON cli.codigopdv = t_cloc.codigopdv AND t_cloc.matriz = 1 AND t_cloc.estado = 1  ',
'AND t_cloc.IDGEOGRAFICO like ''EC%''',
'LEFT JOIN MVT_TRAD_SELLOUT ms ON cli.codigopdv = ms.codigopdv ',
'AND ms.fecha BETWEEN TRUNC(ADD_MONTHS(SYSDATE, - :P400_NMESES_BUSQUEDA_SIN_ASGINAR ), ''MM'') ',
'AND LAST_DAY(ADD_MONTHS(SYSDATE, -1)) ',
unistr('WHERE :P400_TIPO=''#tabPDVSinasignar''   and -- Contacto v\00E1lido '),
'cli.COmpania = :G_COMPANIA AND ms.COMPANIA = :G_COMPANIA AND',
'cli.CODIGOCLIENTE IS NULL AND --- tradicional',
'    --(t_cloc.email IS NOT NULL) AND ',
'    NOT EXISTS ( ',
'        SELECT 1 ',
'        FROM T_ICOM_CLIENTE_PDV ic ',
'        WHERE ic.codigopdv = cli.codigopdv AND',
'            EXISTS ( ',
'                SELECT 1 ',
'                FROM T_ICOM_INVERSIONES inv ',
'                WHERE inv.id = ic.idinversion AND ',
'                inv.idinversiontipo = 5 AND ',
'                inv.idetapa IN (2,3,7) -- Etapas aprobadas',
'            ) AND ',
'            NVL(ic.contratoaprobar,1) IN (1,2,3,4)',
'        ) ',
'          ',
'GROUP BY cli.codigopdv, t_cloc.latitud, t_cloc.longitud, t_cloc.email, t_cloc.telefono',
'HAVING  ROUND(SUM(NVL(ms.valorventa,0)),2)/:P400_NMESES_BUSQUEDA_SIN_ASGINAR >= PK_ICOM_COMMONS.f_traervalorudc(''ICOM_PARAM'', ''36'', :P400_COMPANIA)',
'),',
'',
'PROVEEDOR_VENTAS AS (',
'  SELECT',
'      trso.CODIGOPDV,',
'      C.NOMBRES,',
'      SUM(trso.VALORVENTA) AS TOTAL_PROVEEDOR',
'  FROM data.mvt_trad_sellout trso',
'  LEFT JOIN VT_GZM_CLIENTE C ',
'    ON C.CODIGOCLIENTE = trso.CODIGOGRUPO ',
'   AND C.COMPANIA = :G_COMPANIA',
'  WHERE :P400_TIPO=''#tabPDVSinasignar''  AND trso.FECHA BETWEEN ADD_MONTHS(TRUNC(SYSDATE,''MM''), -:P400_NMESES_BUSQUEDA_SIN_ASGINAR) AND LAST_DAY(SYSDATE)',
'    AND trso.COMPANIA = :G_COMPANIA',
'  GROUP BY trso.CODIGOPDV, C.NOMBRES',
'),',
'--sellout ultimos 6 meses',
'MESES_SELLOUT as ',
'(',
'SELECT trso.CODIGOPDV,',
'       SUM(CASE WHEN TRUNC(trso.FECHA,''MM'') = ADD_MONTHS(TRUNC(SYSDATE,''MM''),-6) THEN trso.VALORVENTA ELSE 0 END) MES_7,',
'       SUM(CASE WHEN TRUNC(trso.FECHA,''MM'') = ADD_MONTHS(TRUNC(SYSDATE,''MM''),-5) THEN trso.VALORVENTA ELSE 0 END) MES_6,',
'       SUM(CASE WHEN TRUNC(trso.FECHA,''MM'') = ADD_MONTHS(TRUNC(SYSDATE,''MM''),-4) THEN trso.VALORVENTA ELSE 0 END) MES_5,',
'       SUM(CASE WHEN TRUNC(trso.FECHA,''MM'') = ADD_MONTHS(TRUNC(SYSDATE,''MM''),-3) THEN trso.VALORVENTA ELSE 0 END) MES_4,',
'       SUM(CASE WHEN TRUNC(trso.FECHA,''MM'') = ADD_MONTHS(TRUNC(SYSDATE,''MM''),-2) THEN trso.VALORVENTA ELSE 0 END) MES_3,',
'       SUM(CASE WHEN TRUNC(trso.FECHA,''MM'') = ADD_MONTHS(TRUNC(SYSDATE,''MM''),-1) THEN trso.VALORVENTA ELSE 0 END) MES_2,',
'       SUM(CASE WHEN TRUNC(trso.FECHA,''MM'') = TRUNC(SYSDATE,''MM'') THEN trso.VALORVENTA ELSE 0 END) MES_ACTUAL,',
'     --  LISTAGG( DISTINCT C.NOMBRES, '', '') WITHIN GROUP (ORDER BY C.NOMBRES) AS PROVEEDOR',
' (    SELECT LISTAGG(pv.NOMBRES || '' ('' || TO_CHAR(pv.TOTAL_PROVEEDOR, ''999G999G990D00'') || '')'', '', '')',
'        WITHIN GROUP (ORDER BY pv.NOMBRES)',
'        FROM PROVEEDOR_VENTAS pv',
'        WHERE pv.CODIGOPDV = trso.CODIGOPDV',
'      ) AS PROVEEDOR',
'FROM data.mvt_trad_sellout trso',
'INNER JOIN PDV_CANDIDATOS candidatos ',
'    ON candidatos.codigopdv = trso.CODIGOPDV',
'LEFT JOIN VT_GZM_CLIENTE C ON C.CODIGOCLIENTE= trso.CODIGOGRUPO     ',
'WHERE :P400_TIPO=''#tabPDVSinasignar''  AND trso.FECHA BETWEEN ADD_MONTHS(TRUNC(SYSDATE,''MM''),-6) AND LAST_DAY(SYSDATE) AND trso.COMPANIA = :G_COMPANIA AND C.COMPANIA = :G_COMPANIA',
'GROUP BY trso.CODIGOPDV',
'ORDER BY trso.CODIGOPDV ',
')',
'',
'SELECT ',
unistr('       APEX_ITEM.CHECKBOX2(10, T1.CODIGOPDV, CASE WHEN :P400_SELECCIONAR_TODO_1=1 THEN ''CHECKED '' ELSE '' '' END ||'' class="chkF02"'' ) AS sel_pdv, -- \00EDndice 10 '),
'       APEX_ITEM.HIDDEN(11, T1.RUC) ruc_hidden,',
'       T1.CODIGOPDV,',
'       T1.RUC,',
'       T1.RAZONSOCIAL,',
'       T1.NOMBRECONOCIDO,',
'       T1.TELEFONO,',
'       T1.CLASIFICACION CLASIFICACION_PDV,  ',
'       T1.COORDINADOR SUPERVISOR,',
'       T1.ZONA,',
'       T1.DESCRIPCION_NIVEL2 PROVINCIA,',
'       T1.DESCRIPCION_NIVEL3 CIUDAD,',
'       T1.DESCRIPCION_NIVEL4 PARROQUIA,',
'       T1.CONTACTO,',
'       T1.EMAIL,',
'       T1.DIRECCION,',
'       candidatos.promedio_venta,',
'       MS.MES_ACTUAL,',
'       MS.MES_2,',
'       MS.MES_3,',
'       MS.MES_4,',
'       MS.MES_5,',
'       MS.MES_6,',
'       MS.MES_7,',
'       MS.PROVEEDOR',
'FROM (',
'    SELECT cli_local.CODIGOPDV,',
'           cli_local.NOMBRECONOCIDO,',
'           cli_local.RUC,',
'           cli_local.RAZONSOCIAL,',
'           cli_local.TELEFONO,',
'           cli_local.CLASIFICACION,',
'           cli_local.COORDINADOR,',
'           cli_local.ZONA,',
'           cli_local.DESCRIPCION_NIVEL2,',
'           cli_local.DESCRIPCION_NIVEL3,',
'           cli_local.DESCRIPCION_NIVEL4,',
'           cli_local.CONTACTO,',
'           cli_local.EMAIL,',
'           cli_local.DIRECCION,',
'           cli_local.CODIGOCLIENTE',
'    FROM   VT_TRAD_CLIENTELOCAL cli_local',
unistr('    WHERE  cli_local.matriz = 1   -- \00BF solo matriz'),
'    AND cli_local.estado = 1',
'    AND cli_local.compania = :P400_COMPANIA',
') T1',
'--LEFT JOIN DATA.VT_GZM_CLIENTE vgz ',
'    --ON (T1.CODIGOCLIENTE-- = vgz.CODIGOCLIENTE) AND vgz.CODIGOCANAL = ''C01''',
'INNER JOIN PDV_CANDIDATOS candidatos ',
'    ON candidatos.codigopdv = T1.CODIGOPDV',
'LEFT JOIN MESES_SELLOUT MS',
'    ON MS.CODIGOPDV = T1.CODIGOPDV',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P400_TIPO,P400_SELECCIONAR_TODO_1'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(88272130699031825)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MFERRIN'
,p_internal_uid=>88272130699031825
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(88273678090031840)
,p_db_column_name=>'SEL_PDV'
,p_display_order=>10
,p_is_primary_key=>'Y'
,p_column_identifier=>'O'
,p_column_label=>'-'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_format_mask=>'PCT_GRAPH:::'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(88533168954319526)
,p_db_column_name=>'RUC_HIDDEN'
,p_display_order=>20
,p_column_identifier=>'P'
,p_column_label=>'-'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'PCT_GRAPH:::1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(88272262572031826)
,p_db_column_name=>'CODIGOPDV'
,p_display_order=>30
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'Codigopdv'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(88272328800031827)
,p_db_column_name=>'RUC'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'Ruc'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_static_id=>'f11'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(88272455563031828)
,p_db_column_name=>'RAZONSOCIAL'
,p_display_order=>50
,p_column_identifier=>'C'
,p_column_label=>'Razonsocial'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(88272509348031829)
,p_db_column_name=>'NOMBRECONOCIDO'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Nombreconocido'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(88272658542031830)
,p_db_column_name=>'TELEFONO'
,p_display_order=>70
,p_column_identifier=>'E'
,p_column_label=>'Telefono'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(88272789036031831)
,p_db_column_name=>'CLASIFICACION_PDV'
,p_display_order=>80
,p_column_identifier=>'F'
,p_column_label=>'Clasificacion Pdv'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(88272843854031832)
,p_db_column_name=>'SUPERVISOR'
,p_display_order=>90
,p_column_identifier=>'G'
,p_column_label=>'Supervisor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(88272965259031833)
,p_db_column_name=>'ZONA'
,p_display_order=>100
,p_column_identifier=>'H'
,p_column_label=>'Zona'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(88273020229031834)
,p_db_column_name=>'PROVINCIA'
,p_display_order=>110
,p_column_identifier=>'I'
,p_column_label=>'Provincia'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(88273120026031835)
,p_db_column_name=>'CIUDAD'
,p_display_order=>120
,p_column_identifier=>'J'
,p_column_label=>'Ciudad'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(88273226534031836)
,p_db_column_name=>'PARROQUIA'
,p_display_order=>130
,p_column_identifier=>'K'
,p_column_label=>'Parroquia'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(88273315038031837)
,p_db_column_name=>'CONTACTO'
,p_display_order=>140
,p_column_identifier=>'L'
,p_column_label=>'Contacto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(88273447282031838)
,p_db_column_name=>'EMAIL'
,p_display_order=>150
,p_column_identifier=>'M'
,p_column_label=>'Email'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(88273592084031839)
,p_db_column_name=>'DIRECCION'
,p_display_order=>160
,p_column_identifier=>'N'
,p_column_label=>'Direccion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(96160466652462028)
,p_db_column_name=>'MES_ACTUAL'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Mes Actual'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(96160579663462029)
,p_db_column_name=>'MES_2'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Mes 2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(96160668111462030)
,p_db_column_name=>'MES_3'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Mes 3'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(96160705704462031)
,p_db_column_name=>'MES_4'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Mes 4'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(96160850201462032)
,p_db_column_name=>'MES_5'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Mes 5'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(96160949631462033)
,p_db_column_name=>'MES_6'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Mes 6'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(96161136068462035)
,p_db_column_name=>'PROMEDIO_VENTA'
,p_display_order=>240
,p_column_identifier=>'Y'
,p_column_label=>'Promedio Venta'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(99801962800791501)
,p_db_column_name=>'MES_7'
,p_display_order=>250
,p_column_identifier=>'Z'
,p_column_label=>'Mes 7'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(107049901495842834)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>260
,p_column_identifier=>'AB'
,p_column_label=>'Distribuidor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_static_id=>'DISTRIBUIDOR'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(88410172884041591)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'884102'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'SEL_PDV:CODIGOPDV:RUC:RAZONSOCIAL:NOMBRECONOCIDO:TELEFONO:CLASIFICACION_PDV:SUPERVISOR:ZONA:PROVINCIA:CIUDAD:PARROQUIA:CONTACTO:EMAIL:DIRECCION:PROVEEDOR:PROMEDIO_VENTA:MES_ACTUAL:MES_2:MES_3:MES_4:MES_5:MES_6:MES_7:RUC_HIDDEN:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(98020672675044836)
,p_plug_name=>'Monitoreo'
,p_region_name=>'tabMonitoreo'
,p_parent_plug_id=>wwv_flow_imp.id(99946386738054028)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(66449693245391136)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(98020905254044839)
,p_plug_name=>'Negociaciones '
,p_parent_plug_id=>wwv_flow_imp.id(98020672675044836)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(65957459765345220)
,p_plug_display_sequence=>40
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(98021187180044841)
,p_name=>'Trazabilidad Propuesta'
,p_region_name=>'tbTrazabilidad'
,p_parent_plug_id=>wwv_flow_imp.id(98020905254044839)
,p_template=>wwv_flow_imp.id(66448811477391136)
,p_display_sequence=>110
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select i.etapa, nvl(i.origen, ''-'') origen , i.id, ',
'       trunc(rutaFechaFin) - trunc(rutaFechaInicio) dias_Ruta,',
'       trunc(i.fechainicio) - trunc(rutaFechaFin) dias_anticipacion, ',
'       r.num_rechazo frecuencia_rechazo,',
'       (select count(1) from data.t_icom_inversiones re where re.idpadre = i.id ) num_replanificacion',
'from data.vt_icom_inversiones i',
'left join ( select entidad_id idRuta, MIN(FECHA_INICIO) rutaFechaInicio, MAX(FECHA_FIN) rutaFechaFin,',
'                   sum(case when estado = ''RECHAZADO'' then 1 else 0 end) num_rechazo',
'              from data.t_flujo_aprobacion_cab where codmodulo=''ICOM'' ',
'              group by entidad_id ) r on ( r.idruta = to_char(i.id) ) ',
'where i.idetapa in (2,3) /*trunc(nvl(i.FECHAINICIO, sysdate)) between :P400_FECHAINICIO and :P400_FECHAFIN ',
'AND :P400_TIPOINVERSION is null or I.IDINVERSIONTIPO=:P400_TIPOINVERSION*/',
'order by i.etapa, nvl(i.origen, ''-'')'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P400_FECHAINICIO,P400_FECHAFIN'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(65992881922345233)
,p_query_num_rows=>1500
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_prn_output=>'Y'
,p_prn_format=>'PDF'
,p_prn_output_link_text=>'Print'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width_units=>'PERCENTAGE'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Trazabilidad Propuesta'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(98021296424044842)
,p_query_column_id=>1
,p_column_alias=>'ETAPA'
,p_column_display_sequence=>10
,p_column_heading=>'Etapa'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(98021359413044843)
,p_query_column_id=>2
,p_column_alias=>'ORIGEN'
,p_column_display_sequence=>20
,p_column_heading=>'Origen'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(98021406490044844)
,p_query_column_id=>3
,p_column_alias=>'ID'
,p_column_display_sequence=>30
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(98021549174044845)
,p_query_column_id=>4
,p_column_alias=>'DIAS_RUTA'
,p_column_display_sequence=>40
,p_column_heading=>'Dias Ruta'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(98021651165044846)
,p_query_column_id=>5
,p_column_alias=>'DIAS_ANTICIPACION'
,p_column_display_sequence=>50
,p_column_heading=>'Dias Anticipacion'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(98021715573044847)
,p_query_column_id=>6
,p_column_alias=>'FRECUENCIA_RECHAZO'
,p_column_display_sequence=>60
,p_column_heading=>'Frecuencia Rechazo'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(98021854884044848)
,p_query_column_id=>7
,p_column_alias=>'NUM_REPLANIFICACION'
,p_column_display_sequence=>70
,p_column_heading=>'Num Replanificacion'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(98021026865044840)
,p_plug_name=>'Propuesta'
,p_parent_plug_id=>wwv_flow_imp.id(98020672675044836)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(65957459765345220)
,p_plug_display_sequence=>30
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(197258942304840691)
,p_plug_name=>'Cumplimiento por Cliente'
,p_region_name=>'tblCumplimiento'
,p_parent_plug_id=>wwv_flow_imp.id(98021026865044840)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(66448489226391134)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'RgnCumpliemientoCliente'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with dato as (',
'    select codigogrupo, nombres, ',
'        sum(case when nvl(estadonegociacion,0) = 1 and trunc(fechainicio) >= trunc(inv_fechainicio) and trunc(fechafin) <= trunc(inv_fechafin) then 1 else 0 end) segun_planificado,',
'        sum(case when nvl(estadonegociacion,0) = 1 and (trunc(fechainicio) < trunc(inv_fechainicio) or trunc(fechafin) > trunc(inv_fechafin)) then 1 else 0 end) fuera_planificado,',
'        sum(case when nvl(estadonegociacion,0) = 0 and (inv_fechainicio - sysdate) <= 21  then 1 else 0 end) sin_negociar_urgente,',
'        sum(case when nvl(estadonegociacion,0) = 0 and (inv_fechainicio - sysdate) > 21  then 1 else 0 end) sin_negociar_tiempo,',
'        sum(case when nvl(estadonegociacion,0) = 2 then 1 else 0 end) no_aceptada,',
'        sum(1) total',
'    from VT_ICOM_INVERSION_CLIENTE G',
'    where 1=1',
'    AND (idInversion in(SELECT regexp_substr(:P400_INVERSIONES,''[^:]+'', 1, level) FROM DUAL connect by regexp_substr(:P400_INVERSIONES, ''[^:]+'', 1, level) is not null )',
'    OR ( TRIM(:P400_INVERSIONES) IS NULL ',
'         AND EXISTS (',
'                Select 1 from t_icom_inversiones i',
'                where compania=:G_compania and idpadre is null and  G.idInversion=i.ID ',
'                --AND exists (select 1 from t_icom_inversion_proceso p where idinversion=i.id and p.estado=1) ',
'                AND to_char(FECHAINICIO, ''YYYY'') in ((SELECT regexp_substr(:P400_ANIO,''[^:]+'', 1, level) FROM DUAL connect by regexp_substr(:P400_ANIO, ''[^:]+'', 1, level) is not null ))',
'                AND to_char(FECHAINICIO, ''MM'') in ((SELECT regexp_substr(:P400_MES,''[^:]+'', 1, level) FROM DUAL connect by regexp_substr(:P400_MES, ''[^:]+'', 1, level) is not null ))',
'                AND IDAREA IN ((SELECT regexp_substr(:P400_AREA,''[^:]+'', 1, level) FROM DUAL connect by regexp_substr(:P400_AREA, ''[^:]+'', 1, level) is not null ))',
'            )',
'        )',
'    )',
'    and idetapa in (2,3) --Implementacion y Negociacion',
'    and idorigen in (1,2) --Cliente y Trade',
'    and estadonegociacion != 3 ',
'    and codigocanal != ''C02'' ',
'    group by  codigogrupo,  nombres ',
') ',
'select  nombres, round((segun_planificado/total)*100,2) segun_plan,',
'round((fuera_planificado/total)*100,2) fuera_plan,',
'round((sin_negociar_urgente/total)*100,2) sin_negociar_urg,',
'round((sin_negociar_tiempo/total)*100,2) sin_negociar_tmp,',
'round((no_aceptada/total)*100,2) no_Acepta',
'from dato'))
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(98872529357653857)
,p_region_id=>wwv_flow_imp.id(197258942304840691)
,p_chart_type=>'bar'
,p_width=>'800'
,p_height=>'500'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'horizontal'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'on'
,p_legend_position=>'top'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(98874247056653858)
,p_chart_id=>wwv_flow_imp.id(98872529357653857)
,p_seq=>10
,p_name=>'Segun lo  Planificado'
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'SEGUN_PLAN'
,p_items_label_column_name=>'NOMBRES'
,p_color=>'#154bef'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'center'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(98874812717653858)
,p_chart_id=>wwv_flow_imp.id(98872529357653857)
,p_seq=>20
,p_name=>'Fuera de lo Planificado'
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'FUERA_PLAN'
,p_items_label_column_name=>'NOMBRES'
,p_color=>'#ffcc00'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'center'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(98875401174653859)
,p_chart_id=>wwv_flow_imp.id(98872529357653857)
,p_seq=>30
,p_name=>'Sin Negociar Urgente'
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'SIN_NEGOCIAR_URG'
,p_items_label_column_name=>'NOMBRES'
,p_color=>'#ff0000'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'center'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(98876036879653859)
,p_chart_id=>wwv_flow_imp.id(98872529357653857)
,p_seq=>40
,p_name=>'Sin Negociar a Tiempo'
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'SIN_NEGOCIAR_TMP'
,p_items_label_column_name=>'NOMBRES'
,p_color=>'#4cd964'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'center'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(98876670069653860)
,p_chart_id=>wwv_flow_imp.id(98872529357653857)
,p_seq=>50
,p_name=>'No Aceptada'
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'NO_ACEPTA'
,p_items_label_column_name=>'NOMBRES'
,p_color=>'#8e8e93'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'center'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(98873614122653858)
,p_chart_id=>wwv_flow_imp.id(98872529357653857)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'Porcentaje'
,p_max=>1
,p_format_type=>'percent'
,p_decimal_places=>0
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(98873065444653858)
,p_chart_id=>wwv_flow_imp.id(98872529357653857)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'Clientes'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(195505743849934755)
,p_plug_name=>'Procesos Operativos'
,p_parent_plug_id=>wwv_flow_imp.id(98020672675044836)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(65957459765345220)
,p_plug_display_sequence=>20
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(195504909200934746)
,p_plug_name=>'Filtros'
,p_parent_plug_id=>wwv_flow_imp.id(195505743849934755)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(66448489226391134)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(195506405035934761)
,p_plug_name=>'Inversiones'
,p_region_name=>'rgnInversion'
,p_parent_plug_id=>wwv_flow_imp.id(195504909200934746)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_region_attributes=>'style="background-color: transparent;"'
,p_plug_template=>wwv_flow_imp.id(66448489226391134)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(534738430450355633)
,p_plug_name=>'Filtros2'
,p_parent_plug_id=>wwv_flow_imp.id(195504909200934746)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_region_attributes=>'style="background-color: #dfdddd2e;"'
,p_plug_template=>wwv_flow_imp.id(66449693245391136)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(195505403136934751)
,p_plug_name=>unistr('A\00F1os')
,p_region_name=>'rgnAnio'
,p_parent_plug_id=>wwv_flow_imp.id(534738430450355633)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_region_attributes=>'style="background-color: transparent;"'
,p_plug_template=>wwv_flow_imp.id(66448489226391134)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>2
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(195505513006934752)
,p_plug_name=>'Meses'
,p_region_name=>'rgnMes'
,p_parent_plug_id=>wwv_flow_imp.id(534738430450355633)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_region_attributes=>'style="background-color: transparent;"'
,p_plug_template=>wwv_flow_imp.id(66448489226391134)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>5
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(195506150827934759)
,p_plug_name=>'Area'
,p_region_name=>'rgnArea'
,p_parent_plug_id=>wwv_flow_imp.id(534738430450355633)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_region_attributes=>'style="background-color: transparent;"'
,p_plug_template=>wwv_flow_imp.id(66448489226391134)
,p_plug_display_sequence=>40
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(195507810575934775)
,p_plug_name=>'Fechas'
,p_parent_plug_id=>wwv_flow_imp.id(534738430450355633)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_region_attributes=>'style="background-color: transparent;"'
,p_plug_template=>wwv_flow_imp.id(66448489226391134)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(195505886840934756)
,p_plug_name=>'Resultado'
,p_parent_plug_id=>wwv_flow_imp.id(195505743849934755)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(66449693245391136)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(195506521133934762)
,p_plug_name=>'Procesos operativos'
,p_parent_plug_id=>wwv_flow_imp.id(195505886840934756)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(66448489226391134)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_css_classes=>'RgnprocesoOperativo'
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(196839784115513843)
,p_plug_name=>'Tareas'
,p_parent_plug_id=>wwv_flow_imp.id(195506521133934762)
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(65968525767345223)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(98832118487469057)
,p_region_id=>wwv_flow_imp.id(196839784115513843)
,p_chart_type=>'gantt'
,p_height=>'400'
,p_animation_on_display=>'none'
,p_animation_on_data_change=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_fill_multi_series_gaps=>false
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>false
,p_show_value=>false
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>false
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'visible'
,p_vertical_grid=>'visible'
,p_row_axis_rendered=>'on'
,p_gantt_axis_position=>'top'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>false
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ) {',
'',
'    var event = new Date();',
'    // Define Reference Object line on the chart',
'    var constantLine = [ { value: event.toISOString() } ];',
'    ',
'    // Set the referenceObjects option as part of the chart initialization',
'    options.referenceObjects = constantLine;',
'    ',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(98833870388469057)
,p_chart_id=>wwv_flow_imp.id(98832118487469057)
,p_seq=>10
,p_name=>'Tasks'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT INVERSION, PROCESO,ID, ID_PADRE, FECHAINICIO_TASK, FECHAFIN_TASK, PORCENTAJE, ',
'FECHAINICIO_GANTT, FECHAFIN_GANTT  ',
'    FROM ( SELECT * FROM VT_ICOM_INVERSION_PROCESO_GANTT G',
'            where idInversion in(SELECT regexp_substr(:P400_INVERSIONES,''[^:]+'', 1, level) ',
'                FROM DUAL connect by regexp_substr(:P400_INVERSIONES, ''[^:]+'', 1, level) is not null )',
'                OR (TRIM(:P400_INVERSIONES) IS NULL AND',
'                EXISTS (',
'                        Select 1 from t_icom_inversiones i',
'                            where compania=:G_compania and idpadre is null and  G.idInversion=i.ID AND',
'                        exists (select 1 from t_icom_inversion_proceso p where idinversion=i.id and p.estado=1) and',
'                        to_char(FECHAINICIO, ''YYYY'') in ((SELECT regexp_substr(:P400_ANIO,''[^:]+'', 1, level) FROM DUAL connect by regexp_substr(:P400_ANIO, ''[^:]+'', 1, level) is not null ))',
'                        AND to_char(FECHAINICIO, ''MM'') in ((SELECT regexp_substr(:P400_MES,''[^:]+'', 1, level) FROM DUAL connect by regexp_substr(:P400_MES, ''[^:]+'', 1, level) is not null ))',
'                        AND IDAREA IN ((SELECT regexp_substr(:P400_AREA,''[^:]+'', 1, level) FROM DUAL connect by regexp_substr(:P400_AREA, ''[^:]+'', 1, level) is not null ))',
'',
'',
'                )',
'                ',
'                )',
'',
'',
'',
'',
'',
'',
'',
'            ) --G start with ID_PADRE is null  ',
'    --connect by prior id = ID_PADRE  ',
'    --order siblings by PROCESO  ',
'    order by INVERSION, PROCESO'))
,p_ajax_items_to_submit=>'P400_INVERSIONES,P400_ANIO,P400_AREA,P400_MES'
,p_items_label_rendered=>true
,p_items_label_display_as=>'PERCENT'
,p_items_label_font_color=>'#080808'
,p_gantt_start_date_source=>'DB_COLUMN'
,p_gantt_start_date_column=>'FECHAINICIO_GANTT'
,p_gantt_end_date_source=>'DB_COLUMN'
,p_gantt_end_date_column=>'FECHAFIN_GANTT'
,p_gantt_row_name=>'INVERSION'
,p_gantt_task_id=>'ID'
,p_gantt_task_name=>'PROCESO'
,p_gantt_task_start_date=>'FECHAINICIO_TASK'
,p_gantt_task_end_date=>'FECHAFIN_TASK'
,p_gantt_progress_column=>'PORCENTAJE'
,p_task_label_position=>'start'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(98832612941469057)
,p_chart_id=>wwv_flow_imp.id(98832118487469057)
,p_axis=>'major'
,p_is_rendered=>'on'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_axis_scale=>'months'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>true
,p_zoom_order_quarters=>true
,p_zoom_order_years=>true
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(98833293910469057)
,p_chart_id=>wwv_flow_imp.id(98832118487469057)
,p_axis=>'minor'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_axis_scale=>'weeks'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>true
,p_zoom_order_months=>true
,p_zoom_order_quarters=>true
,p_zoom_order_years=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(196841453345513860)
,p_plug_name=>'Gasto/Avance'
,p_parent_plug_id=>wwv_flow_imp.id(195505886840934756)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(66449693245391136)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>3
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(195506536018934763)
,p_plug_name=>'Porcentaje de avance'
,p_parent_plug_id=>wwv_flow_imp.id(196841453345513860)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(66448489226391134)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(196839301513513838)
,p_plug_name=>'Porcentaje'
,p_parent_plug_id=>wwv_flow_imp.id(195506536018934763)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(66449693245391136)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(98826881677469049)
,p_region_id=>wwv_flow_imp.id(196839301513513838)
,p_chart_type=>'dial'
,p_width=>'90'
,p_height=>'100'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_text_type=>'percent'
,p_value_position=>'auto'
,p_value_format_type=>'percent'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_fill_multi_series_gaps=>false
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>false
,p_show_value=>false
,p_show_label=>false
,p_show_row=>false
,p_show_start=>false
,p_show_end=>false
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_indicator_size=>1
,p_gauge_inner_radius=>.7
,p_gauge_plot_area=>'on'
,p_gauge_start_angle=>90
,p_gauge_angle_extent=>360
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(98827327675469049)
,p_chart_id=>wwv_flow_imp.id(98826881677469049)
,p_seq=>10
,p_name=>'Commission'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
' SELECT sum(duracion) max_value, sum(avance) value FROM VT_ICOM_INVERSION_PROCESO_GANTT',
'            where idInversion in(SELECT regexp_substr(:P400_INVERSIONES,''[^:]+'', 1, level) ',
'                FROM DUAL connect by regexp_substr(:P400_INVERSIONES, ''[^:]+'', 1, level) is not null )',
'            '))
,p_items_value_column_name=>'VALUE'
,p_items_max_value=>'MAX_VALUE'
,p_color=>'#1a3ad9'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(196841331584513859)
,p_plug_name=>'Inicia En'
,p_parent_plug_id=>wwv_flow_imp.id(195506536018934763)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(66449693245391136)
,p_plug_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(196841533100513861)
,p_plug_name=>'Analisis de gasto'
,p_parent_plug_id=>wwv_flow_imp.id(196841453345513860)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(66448489226391134)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(196841762853513863)
,p_plug_name=>'Gasto grafico'
,p_parent_plug_id=>wwv_flow_imp.id(196841533100513861)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(66449693245391136)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(98823341105469042)
,p_region_id=>wwv_flow_imp.id(196841762853513863)
,p_chart_type=>'bar'
,p_height=>'270'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_fill_multi_series_gaps=>false
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>false
,p_show_group_name=>false
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ){ ',
'        ',
'    // Setup a callback function which gets called when data is retrieved, it allows to manipulate the series ',
'    options.dataFilter = function( data ) { ',
'        data.series[ 0 ].items[0].color = "rgb(60, 175, 133)"; ',
'        data.series[ 0 ].items[1].color = "rgb(48, 159, 219)"; ',
'        return data; ',
'    };',
'        ',
'    // Set chart initialization options ',
'    return options; ',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(98825635637469047)
,p_chart_id=>wwv_flow_imp.id(98823341105469042)
,p_seq=>10
,p_name=>'Meta'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT SUM(VALORMETA) valor, ''Valor Meta'' descripcion FROM t_icom_inversion_gasto G',
' WHERE  GASTOTIPO=''GASTO''and idinversion  in(SELECT regexp_substr(:P400_INVERSIONES,''[^:]+'', 1, level) ',
'                FROM DUAL connect by regexp_substr(:P400_INVERSIONES, ''[^:]+'', 1, level) is not null )',
'             OR (TRIM(:P400_INVERSIONES) IS NULL AND',
'                EXISTS (',
'                        Select 1 from t_icom_inversiones i',
'                            where compania=:G_compania and idpadre is null and  G.idInversion=i.ID AND',
'                        exists (select 1 from t_icom_inversion_proceso p where idinversion=i.id and p.estado=1) and',
'                        to_char(FECHAINICIO, ''YYYY'') in ((SELECT regexp_substr(:P400_ANIO,''[^:]+'', 1, level) FROM DUAL connect by regexp_substr(:P400_ANIO, ''[^:]+'', 1, level) is not null ))',
'                        AND to_char(FECHAINICIO, ''MM'') in ((SELECT regexp_substr(:P400_MES,''[^:]+'', 1, level) FROM DUAL connect by regexp_substr(:P400_MES, ''[^:]+'', 1, level) is not null ))',
'                        AND IDAREA IN ((SELECT regexp_substr(:P400_AREA,''[^:]+'', 1, level) FROM DUAL connect by regexp_substr(:P400_AREA, ''[^:]+'', 1, level) is not null ))',
'',
'',
'                )',
'                ',
'                )',
'',
'',
'',
'',
'',
'                union ',
'                ',
'  SELECT SUM(VALORReal) valor, ''Valor Real'' descripcion FROM t_icom_inversion_gasto G',
' WHERE  GASTOTIPO=''GASTO''and idinversion  in(SELECT regexp_substr(:P400_INVERSIONES,''[^:]+'', 1, level) ',
'                FROM DUAL connect by regexp_substr(:P400_INVERSIONES, ''[^:]+'', 1, level) is not null )',
'                ',
'                 OR (TRIM(:P400_INVERSIONES) IS NULL AND',
'                EXISTS (',
'                        Select 1 from t_icom_inversiones i',
'                            where compania=:G_compania and idpadre is null and  G.idInversion=i.ID AND',
'                        exists (select 1 from t_icom_inversion_proceso p where idinversion=i.id and p.estado=1) and',
'                        to_char(FECHAINICIO, ''YYYY'') in ((SELECT regexp_substr(:P400_ANIO,''[^:]+'', 1, level) FROM DUAL connect by regexp_substr(:P400_ANIO, ''[^:]+'', 1, level) is not null ))',
'                        AND to_char(FECHAINICIO, ''MM'') in ((SELECT regexp_substr(:P400_MES,''[^:]+'', 1, level) FROM DUAL connect by regexp_substr(:P400_MES, ''[^:]+'', 1, level) is not null ))',
'                        AND IDAREA IN ((SELECT regexp_substr(:P400_AREA,''[^:]+'', 1, level) FROM DUAL connect by regexp_substr(:P400_AREA, ''[^:]+'', 1, level) is not null ))',
'',
'',
'                )',
'                ',
'                )',
'',
'                ;'))
,p_ajax_items_to_submit=>'P400_INVERSIONES,P400_ANIO,P400_AREA,P400_MES'
,p_items_value_column_name=>'VALOR'
,p_items_label_column_name=>'DESCRIPCION'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(98825000359469045)
,p_chart_id=>wwv_flow_imp.id(98823341105469042)
,p_axis=>'y2'
,p_is_rendered=>'off'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_split_dual_y=>'auto'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(98824441782469045)
,p_chart_id=>wwv_flow_imp.id(98823341105469042)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'currency'
,p_decimal_places=>0
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(98823865315469044)
,p_chart_id=>wwv_flow_imp.id(98823341105469042)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_type=>'currency'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(630807612067619644)
,p_plug_name=>'Monitoreo'
,p_region_name=>'rgMonitoreo'
,p_parent_plug_id=>wwv_flow_imp.id(98020672675044836)
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(65957459765345220)
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="content">',
'    <iframe id="powerBIFrame" title="Monitoreo" width="1250" height="750" ',
'        src="https://app.powerbi.com/view?r=eyJrIjoiZjY4OGI4ZTItZjc4YS00MGI3LTllYzktODdiY2JjNjhmYjlmIiwidCI6IjY0NWQ5MjVlLTZkNWUtNGIxMy04OTc3LWQ2YzVhNjFlN2Q2MSIsImMiOjR9" ',
'        frameborder="0" allowFullScreen="true">',
'    </iframe>    ',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(99946446836054029)
,p_plug_name=>'Validaciones'
,p_region_name=>'tblValidacion'
,p_parent_plug_id=>wwv_flow_imp.id(99946386738054028)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(66449693245391136)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT cv.idagrupacion, cv.nombreagrupacion, cv.fecha, cv.usuariocreacion,',
'       CASE cv.estado ',
'           WHEN 0 THEN ''Inicio''',
'           WHEN 1 THEN ''Aprobada''',
'           WHEN 2 THEN ''Pendiente''',
'           WHEN 3 THEN ''Ruta''',
'       end  as estado, ',
'       APEX_PAGE.GET_URL ( p_application => :APP_ID,',
'                   p_page   =>',
'                   --ESTADO VALIDACION',
'                   CASE WHEN cv.estado = 0 THEN 261 --Validacion iniciada',
'                        WHEN cv.estado = 1 THEN 266 --Validacion aprobada',
'                        WHEN cv.estado = 2 THEN 264 --Validacion pendiente de finalizacion',
'                        WHEN cv.estado = 3 THEN 266 --Validacion en ruta de aprobacion   ',
'                   END,',
'                   p_clear_cache => --ESTADO VALIDACION',
'                   CASE WHEN cv.estado = 0 THEN 261 --Validacion iniciada',
'                        WHEN cv.estado = 1 THEN 266 --Validacion aprobada',
'                        WHEN cv.estado = 2 THEN 264 --Validacion pendiente de finalizacion',
'                        WHEN cv.estado = 3 THEN 266 --Validacion en ruta de aprobacion   ',
'                   END, ',
'                   p_items  => ',
'                   --ESTADO VALIDACION',
'                   CASE WHEN cv.estado = 0 THEN ''P261_IDAGRUPACION,P261_INVERSION_TIPO,P261_VALIDACION_TIPO'' --Validacion iniciada',
'                        WHEN cv.estado = 1 THEN ''P266_IDAGRUPACION,P266_APROBADOR,P266_ESTADO'' --Validacion aprobada',
'                        WHEN cv.estado = 2 THEN ''P264_IDAGRUPACION,P264_INVERSION_TIPO,P264_VALIDACION_TIPO'' --Validacion pendiente de finalizacion',
'                        WHEN cv.estado = 3 THEN ''P266_IDAGRUPACION,P266_APROBADOR,P266_ESTADO'' --Validacion en ruta de aprobacion   ',
'                   END,',
'                   p_values =>',
'                   --ESTADO VALIDACION',
'                   CASE WHEN cv.estado = 0 THEN to_char(cv.idagrupacion)||'',0,0'' --Validacion iniciada',
'                        WHEN cv.estado = 1 THEN cv.idagrupacion||'',NULL,''||cv.estado --Validacion aprobada',
'                        WHEN cv.estado = 2 THEN cv.idagrupacion||'',0,0'' --Validacion pendiente de finalizacion',
'                        WHEN cv.estado = 3 THEN cv.idagrupacion||'',''||F.USUARIOACTUAL||'',''||cv.estado --Validacion en ruta de aprobacion   ',
'                   END ) URL, ',
'       F.USUARIOACTUAL APROBADOR,',
'       ''<span class="fa fa-road" aria-hidden="true"></span>'' RUTA,',
'       (SELECT PK_CORP_FLUJOAPROBACION.F_GESTIONCOLOR(:APP_USER, F.USUARIOACTUAL, F.ESTADO, :G_COMPANIA, :APP_MODULO) FROM DUAL) CSS ,',
'       (SELECT PK_CORP_FLUJOAPROBACION.F_MESAORDEN(PK_CORP_FLUJOAPROBACION.F_GESTIONCOLOR(:APP_USER, F.USUARIOACTUAL, F.ESTADO, :G_COMPANIA, :APP_MODULO)) FROM DUAL) orden,',
'       case cv.estado when 0 then ''<span class="fa fa-trash-o" aria-hidden="true"></span>'' else '''' end borrar  ',
'FROM ( select ic.compania, ic.idagrupacion, ic.nombreagrupacion, ic.usuariocreacion, max(ic.estado) estado, ',
'              max(ic.fechacreacion) fecha',
'       from data.t_icom_cliente_validacion  ic',
'       where ( ic.estado = 0 and ic.nombreagrupacion is not null ) or ic.estado in (1,2,3) ',
'       group by ic.compania, ic.idagrupacion, ic.nombreagrupacion,  ic.usuariocreacion ) cv',
'  LEFT JOIN DATA.T_FLUJO_APROBACION_CAB F ',
'      ON ( F.codmodulo=''ICOM'' AND F.ESTADO=''EN_PROCESO'' ',
'          AND F.ENTIDAD_ID = TO_CHAR(cv.idagrupacion) ',
'          AND F.ENTIDAD_CLASE = ''VALIDACION_INVERSION'' ) ',
'WHERE :P400_TIPO=''#tblValidacion'' AND cv.COMPANIA =:G_COMPANIA ',
'AND (   (:P400_ESTADO = 2 AND trunc(cv.fecha) between :P400_FECHAINICIO and :P400_FECHAFIN )',
'	 OR  (:P400_ESTADO = 1 ',
'          AND ( ( F.USUARIOACTUAL IS NOT NULL ',
'                -- AND PK_CORP_FLUJOAPROBACION.F_APROBADORFLUJO(:APP_USER,F.USUARIOACTUAL,:APP_MODULO,:G_COMPANIA) = 1',
'                )',
'               OR ( F.USUARIOACTUAL is null and cv.usuariocreacion = :APP_USER ) --creador de la validacion ',
'              ))',
'	)',
'',
'ORDER BY orden asc , cv.idagrupacion DESC ;',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P400_ESTADO,P400_FECHAINICIO,P400_FECHAFIN,P400_TIPO'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES (P_CODIGOMODULO => :APP_MODULO , P_CODIGOUSUARIO => :APP_USER ',
unistr('                                                                                    , P_RUTAPAGINA => 400 , P_CODIGOACCION => ''APROBACI\00D3N_DE_VALIDACI\00D3N'')=1')))
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(99946541533054030)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'NETBY2'
,p_internal_uid=>99946541533054030
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(99946991126054034)
,p_db_column_name=>'URL'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Url'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(99947697335054041)
,p_db_column_name=>'RUTA'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'-'
,p_column_link=>'f?p=100:104:&SESSION.::&DEBUG.:RP:G_OBJETO,G_OBJETO_ID,G_TODO:&APP_VALIDACION.,#IDAGRUPACION#,true'
,p_column_linktext=>'#RUTA#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(99947730458054042)
,p_db_column_name=>'APROBADOR'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Aprobador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(99947896557054043)
,p_db_column_name=>'CSS'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Css'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(99947916014054044)
,p_db_column_name=>'ORDEN'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Orden'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(99948558961054050)
,p_db_column_name=>'IDAGRUPACION'
,p_display_order=>150
,p_column_identifier=>'T'
,p_column_label=>'#'
,p_column_link=>'#URL#'
,p_column_linktext=>'<span class=''#CSS#''>#IDAGRUPACION#</span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100325600402607401)
,p_db_column_name=>'NOMBREAGRUPACION'
,p_display_order=>160
,p_column_identifier=>'U'
,p_column_label=>'Nombre Agrupacion'
,p_column_link=>'#URL#'
,p_column_linktext=>'<span class=''#CSS#''>#NOMBREAGRUPACION#</span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100325731229607402)
,p_db_column_name=>'FECHA'
,p_display_order=>170
,p_column_identifier=>'V'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100328825050607433)
,p_db_column_name=>'ESTADO'
,p_display_order=>180
,p_column_identifier=>'X'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100329791529607442)
,p_db_column_name=>'USUARIOCREACION'
,p_display_order=>190
,p_column_identifier=>'Y'
,p_column_label=>'Usuario Creacion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(48860070212547347)
,p_db_column_name=>'BORRAR'
,p_display_order=>200
,p_column_identifier=>'Z'
,p_column_label=>'-'
,p_column_link=>'JavaScript: $s(''P400_IDAGRUPA'', ''#IDAGRUPACION#'');'
,p_column_linktext=>'#BORRAR#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(100324732674258186)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1003248'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'IDAGRUPACION:NOMBREAGRUPACION:FECHA:APROBADOR:USUARIOCREACION:ESTADO:BORRAR:RUTA:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(101572436989053001)
,p_plug_name=>'Negociaciones'
,p_region_name=>'tabNegociacion'
,p_parent_plug_id=>wwv_flow_imp.id(99946386738054028)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(66449693245391136)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES (P_CODIGOMODULO => :APP_MODULO , P_CODIGOUSUARIO => :APP_USER ',
unistr('                                                                                    , P_RUTAPAGINA => 400 , P_CODIGOACCION => ''APROBACI\00D3N_DE_NEGOCIACI\00D3N'')=1')))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(94993901103751611)
,p_plug_name=>'Tab'
,p_parent_plug_id=>wwv_flow_imp.id(101572436989053001)
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_imp.id(65975394802345225)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(94993515469751607)
,p_plug_name=>'Descuentos'
,p_region_name=>'tblDescuento'
,p_parent_plug_id=>wwv_flow_imp.id(94993901103751611)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(65967409977345223)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT D.IDINVERSION ID_INVERSION,D.IDFLUJO, D.NOMBRE, D.GRUPO, D.CODIGOCLIENTE CODIGO_CLIENTE, D.CLIENTE, D.LINEANEGOCIO LINEA_NEGOCIO, D.MARCA,',
' D.CODIGOPRODUCTO CODIGO_PRODUCTO, D.CODIGOBARRA CODIGO_BARRA, D.PRODUCTO, FECHA_INV_INICIO, FECHA_INV_FIN, ',
'D.FECHA_NEG_INICIO, D.FECHA_NEG_FIN, D.FECHA_DESC_INICIO, D.FECHA_DESC_FIN, DESCUENTO,USUARIOACTUAL APROBADOR, USUARIOINICIADOR SOLICITANTE, FECHA_INICIO,',
'APEX_ITEM.CHECKBOX(4,D.IDFLUJO,CASE WHEN :P400_SELECCIONAR_DESCUENTO=1 THEN ''CHECKED '' ELSE '''' END ||'' class="chkF04"'') seleccion,',
'case when NEGOCIACION=1 then ''ACEPTA Y CONTINUA'' ELSE ''ACEPTA Y FINALIZA'' END NEGOCIACION',
'',
'FROM VT_ICOM_INVERSION_DESCUENTO_FECHAS d',
'INNER join t_flujo_aprobacion_cab f on (d.IDFLUJO=f.entidad_id and f.CODMODULO=''ICOM'' ',
'AND ENTIDAD_CLASE=''PARAMETRIZACION_DESCUENTO'' AND F.ESTADO=''EN_PROCESO'')',
'WHERE   :P400_TIPO=''#tabNegociacion'' AND D.ESTADO=2 AND CIA=:G_COMPANIA AND USUARIOACTUAL=:APP_USER',
'     ;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P400_TIPO,P400_SELECCIONAR_DESCUENTO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Descuentos'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(94993732898751609)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>94993732898751609
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94994156466751613)
,p_db_column_name=>'IDFLUJO'
,p_display_order=>20
,p_column_identifier=>'C'
,p_column_label=>'Idflujo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94994288830751614)
,p_db_column_name=>'NOMBRE'
,p_display_order=>30
,p_column_identifier=>'D'
,p_column_label=>'Nombre'
,p_column_html_expression=>'<span style="display:block; width:300px">#NOMBRE#</span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94994378257751615)
,p_db_column_name=>'GRUPO'
,p_display_order=>40
,p_column_identifier=>'E'
,p_column_label=>'Grupo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94994551544751617)
,p_db_column_name=>'CLIENTE'
,p_display_order=>60
,p_column_identifier=>'G'
,p_column_label=>'Cliente'
,p_column_html_expression=>'<span style="display:block; width:200px">#CLIENTE#</span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94994761429751619)
,p_db_column_name=>'MARCA'
,p_display_order=>80
,p_column_identifier=>'I'
,p_column_label=>'Marca'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94995073910751622)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>110
,p_column_identifier=>'L'
,p_column_label=>'Producto'
,p_column_html_expression=>'<span style="display:block; width:150px">#PRODUCTO#</span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94995147449751623)
,p_db_column_name=>'FECHA_NEG_INICIO'
,p_display_order=>120
,p_column_identifier=>'M'
,p_column_label=>'Fecha Neg Inicio'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94995286964751624)
,p_db_column_name=>'FECHA_NEG_FIN'
,p_display_order=>130
,p_column_identifier=>'N'
,p_column_label=>'Fecha Neg Fin'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94995432008751626)
,p_db_column_name=>'FECHA_DESC_FIN'
,p_display_order=>150
,p_column_identifier=>'P'
,p_column_label=>'Fecha Desc Fin'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94995567461751627)
,p_db_column_name=>'DESCUENTO'
,p_display_order=>160
,p_column_identifier=>'Q'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94995898202751630)
,p_db_column_name=>'FECHA_INICIO'
,p_display_order=>190
,p_column_identifier=>'T'
,p_column_label=>'Fecha Inicio'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94995931734751631)
,p_db_column_name=>'APROBADOR'
,p_display_order=>200
,p_column_identifier=>'U'
,p_column_label=>'Aprobador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94996031175751632)
,p_db_column_name=>'SOLICITANTE'
,p_display_order=>210
,p_column_identifier=>'V'
,p_column_label=>'Solicitante'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94996138932751633)
,p_db_column_name=>'CODIGO_CLIENTE'
,p_display_order=>220
,p_column_identifier=>'W'
,p_column_label=>'Codigo Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94996296114751634)
,p_db_column_name=>'LINEA_NEGOCIO'
,p_display_order=>230
,p_column_identifier=>'X'
,p_column_label=>'Linea Negocio'
,p_column_html_expression=>'<span style="display:block; width:100px">#LINEA_NEGOCIO#</span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94996375231751635)
,p_db_column_name=>'CODIGO_PRODUCTO'
,p_display_order=>240
,p_column_identifier=>'Y'
,p_column_label=>'Codigo Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94996474004751636)
,p_db_column_name=>'CODIGO_BARRA'
,p_display_order=>250
,p_column_identifier=>'Z'
,p_column_label=>'Codigo Barra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94996551984751637)
,p_db_column_name=>'ID_INVERSION'
,p_display_order=>260
,p_column_identifier=>'AA'
,p_column_label=>'Id Inversion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94996996315751641)
,p_db_column_name=>'SELECCION'
,p_display_order=>270
,p_column_identifier=>'AB'
,p_column_label=>'-'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(96682304936465705)
,p_db_column_name=>'FECHA_DESC_INICIO'
,p_display_order=>280
,p_column_identifier=>'AC'
,p_column_label=>'Fecha Desc Inicio'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(495356397155959237)
,p_db_column_name=>'FECHA_INV_INICIO'
,p_display_order=>290
,p_column_identifier=>'AD'
,p_column_label=>'Fecha Inv Inicio'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(495356413524959238)
,p_db_column_name=>'FECHA_INV_FIN'
,p_display_order=>300
,p_column_identifier=>'AE'
,p_column_label=>'Fecha Inv Fin'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(495356599115959239)
,p_db_column_name=>'NEGOCIACION'
,p_display_order=>310
,p_column_identifier=>'AF'
,p_column_label=>'Negociacion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(96647648387175119)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'966477'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'GRUPO:SELECCION:CLIENTE:NEGOCIACION:LINEA_NEGOCIO:MARCA:PRODUCTO:CODIGO_PRODUCTO:FECHA_INV_INICIO:FECHA_INV_FIN:FECHA_NEG_INICIO:FECHA_NEG_FIN:FECHA_DESC_INICIO:FECHA_DESC_FIN:DESCUENTO:ID_INVERSION:NOMBRE:SOLICITANTE:'
,p_break_on=>'GRUPO:SELECCION:0:0:0:0'
,p_break_enabled_on=>'GRUPO:SELECCION:0:0:0:0'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(100627884741237929)
,p_plug_name=>'Clientes'
,p_region_name=>'tblCliente'
,p_parent_plug_id=>wwv_flow_imp.id(94993901103751611)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(65967409977345223)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  g.IDINVERSION, G.INVERSION,g.NOMBRES,g.CODIGOGRUPO,',
'G.FECHAINICIO,G.FECHAFIN, G.ESTADONEGOCIACION,G.OBSERVACION, G.MOTIVORECHAZO,',
'G.IDINVERSION||''-''||G.CODIGOGRUPO ID, ',
'APEX_ITEM.CHECKBOX(3,G.IDINVERSION||''-''||G.CODIGOGRUPO,CASE WHEN :P400_SELECCIONAR_TODO=1 THEN ''CHECKED '' ELSE '''' END ||'' class="chkF02"'') seleccion,',
'DESCUENTO, TIPOLOCAL,',
'''<span class="fa fa-calculator" aria-hidden="true" title="Material Pop"></span>'' MPOP, inv_fechainicio, inv_fechafin,',
'''<span class="fa fa-comment" aria-hidden="true" title="Comentario"></span>'' comentario,',
'''<span class="fa fa-file-new" aria-hidden="true" title="Ver Preliminar de Encuestas"></span>'' ver_encuestas',
'',
'FROM  VT_ICOM_MESA_NEGOCIACION G',
'WHERE :P400_TIPO=''#tabNegociacion''',
'AND  USUARIOACTUAL=upper(:APP_USER)',
'AND COMPANIA=:G_COMPANIA',
'     ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P400_SELECCIONAR_TODO,P400_TIPO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(100627969288237930)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>100627969288237930
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100628002706237931)
,p_db_column_name=>'IDINVERSION'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id inversion'
,p_column_link=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:RP:P200_ID:#IDINVERSION#'
,p_column_linktext=>'#IDINVERSION#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100628171263237932)
,p_db_column_name=>'INVERSION'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Inversion'
,p_column_link=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:RP:P200_ID:#IDINVERSION#'
,p_column_linktext=>'#INVERSION#'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100628290522237933)
,p_db_column_name=>'NOMBRES'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100628364362237934)
,p_db_column_name=>'CODIGOGRUPO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Codigo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100628451666237935)
,p_db_column_name=>'FECHAINICIO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Negocia Fecha inicio'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100628505343237936)
,p_db_column_name=>'FECHAFIN'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Negocia Fecha fin'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100628657932237937)
,p_db_column_name=>'ESTADONEGOCIACION'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Negociacion'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(87929139252971825)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100628715389237938)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100628842951237939)
,p_db_column_name=>'MOTIVORECHAZO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Motivo rechazo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100628966592237940)
,p_db_column_name=>'ID'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Id'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100629073523237941)
,p_db_column_name=>'SELECCION'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'-'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(111206218386335602)
,p_db_column_name=>'MPOP'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Mpop'
,p_column_link=>'f?p=&APP_ID.:221:&SESSION.::&DEBUG.:221:P221_CODIGO,P221_ID,P221_SUBIR,P221_EDITAR,P221_CLIENTE,P221_NEGOCIACION:#CODIGOGRUPO#,#IDINVERSION#,0,0,#NOMBRES#,1'
,p_column_linktext=>'#MPOP#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(111939583633550513)
,p_db_column_name=>'INV_FECHAINICIO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Macro Fecha Inicio'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(111939674942550514)
,p_db_column_name=>'INV_FECHAFIN'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Macro Fecha Fin'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119197040364450601)
,p_db_column_name=>'COMENTARIO'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Comentario'
,p_column_link=>'f?p=100:105:&SESSION.::&DEBUG.::G_MODULO,G_COMPANIA,G_USUARIO,G_OBJETO,G_OBJETO_ID:ICOM,&G_COMPANIA.,&APP_USER.,&APP_NEGOCIACLIENTE.,#ID#'
,p_column_linktext=>'#COMENTARIO#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(419553182528294222)
,p_db_column_name=>'VER_ENCUESTAS'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'-'
,p_column_link=>'f?p=&APP_ID.:122:&SESSION.::&DEBUG.:RR,122:P122_CODIGOGRUPO,P122_ID,P122_PRESTAERROR:#CODIGOGRUPO#,#IDINVERSION#,0'
,p_column_linktext=>'#VER_ENCUESTAS#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(431376710560634810)
,p_db_column_name=>'DESCUENTO'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(431376855320634811)
,p_db_column_name=>'TIPOLOCAL'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Tipolocal'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(436147911080728901)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(101568962369991185)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1015690'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SELECCION:IDINVERSION:NOMBRES:VER_ENCUESTAS:INVERSION:CODIGOGRUPO:INV_FECHAINICIO:INV_FECHAFIN:FECHAINICIO:FECHAFIN:ESTADONEGOCIACION:OBSERVACION:MOTIVORECHAZO:DESCUENTO:TIPOLOCAL:MPOP:'
,p_break_on=>'SELECCION:IDINVERSION:NOMBRES:VER_ENCUESTAS:0:0'
,p_break_enabled_on=>'SELECCION:IDINVERSION:NOMBRES:VER_ENCUESTAS:0:0'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(511961636946001102)
,p_plug_name=>'Descuentos inactivacion'
,p_region_name=>'tblDescuentoInactivacion'
,p_parent_plug_id=>wwv_flow_imp.id(94993901103751611)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_region_attributes=>'style="text-wrap:revert-layer;"'
,p_plug_template=>wwv_flow_imp.id(65967409977345223)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    d.idinversion id_inversion,d.idflujo,d.idinversion||'' - ''||PK_FINZ_SRI_GESTION.F_TRIMETIQUETA(d.nombre)nombre,',
'    ''[ ''||d.idflujo||'' ]  - ''|| d.grupo grupo,d.codigocliente codigo_cliente',
'    ,d.cliente,d.lineanegocio linea_negocio,',
'    d.marca,d.codigoproducto codigo_producto,d.codigobarra codigo_barra,d.producto,fecha_inv_inicio,fecha_inv_fin,d.fecha_neg_inicio,',
'    d.fecha_neg_fin,d.fecha_desc_inicio,d.fecha_desc_fin,descuento,usuarioactual aprobador,usuarioiniciador solicitante,fecha_inicio,',
'    apex_item.checkbox(5,d.idflujo||''-''||d.idinversion,''class="chkF05"'') seleccion,',
'    DECODE(negociacion,1,''ACEPTA Y CONTINUA'' ,''ACEPTA Y FINALIZA'')negociacion',
'FROM vt_icom_inversion_descuento_cancelacion_fechas d',
'INNER JOIN t_flujo_aprobacion_cab f ON ( d.idflujo = f.entidad_id',
'                                             AND f.codmodulo = ''ICOM''',
'                                             AND entidad_clase = ''PARAMETRIZACION_DESCUENTO_CANCELACION''',
'                                             AND f.estado = ''EN_PROCESO'' )',
'WHERE :p400_tipo = ''#tabNegociacion'' AND ',
'        d.estado = 4',
'    AND cia = :g_compania AND usuarioactual = :app_user  ; '))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P400_TIPO,P400_SELECCIONAR_DESCUENTO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Descuentos inactivacion'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(511961722473001103)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>511961722473001103
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(511962088625001106)
,p_db_column_name=>'GRUPO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Grupo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(511962109970001107)
,p_db_column_name=>'CLIENTE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Cliente'
,p_column_html_expression=>'<span style="display:block; width:200px">#CLIENTE#</span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(511964093212001126)
,p_db_column_name=>'NEGOCIACION'
,p_display_order=>50
,p_column_identifier=>'W'
,p_column_label=>'Negociacion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(511963292296001118)
,p_db_column_name=>'LINEA_NEGOCIO'
,p_display_order=>60
,p_column_identifier=>'O'
,p_column_label=>'Linea Negocio'
,p_column_html_expression=>'<span style="display:block; width:100px">#LINEA_NEGOCIO#</span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(511962241648001108)
,p_db_column_name=>'MARCA'
,p_display_order=>70
,p_column_identifier=>'E'
,p_column_label=>'Marca'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(511962379369001109)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>80
,p_column_identifier=>'F'
,p_column_label=>'Producto'
,p_column_html_expression=>'<span style="display:block; width:150px">#PRODUCTO#</span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(511963312957001119)
,p_db_column_name=>'CODIGO_PRODUCTO'
,p_display_order=>90
,p_column_identifier=>'P'
,p_column_label=>'Codigo Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(511963827774001124)
,p_db_column_name=>'FECHA_INV_INICIO'
,p_display_order=>100
,p_column_identifier=>'U'
,p_column_label=>'Fecha Inv Inicio'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(511963937357001125)
,p_db_column_name=>'FECHA_INV_FIN'
,p_display_order=>110
,p_column_identifier=>'V'
,p_column_label=>'Fecha Inv Fin'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(511962435192001110)
,p_db_column_name=>'FECHA_NEG_INICIO'
,p_display_order=>120
,p_column_identifier=>'G'
,p_column_label=>'Fecha Neg Inicio'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(511962595491001111)
,p_db_column_name=>'FECHA_NEG_FIN'
,p_display_order=>130
,p_column_identifier=>'H'
,p_column_label=>'Fecha Neg Fin'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(511963760397001123)
,p_db_column_name=>'FECHA_DESC_INICIO'
,p_display_order=>140
,p_column_identifier=>'T'
,p_column_label=>'Fecha Desc Inicio'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(511962623259001112)
,p_db_column_name=>'FECHA_DESC_FIN'
,p_display_order=>150
,p_column_identifier=>'I'
,p_column_label=>'Fecha Desc Fin'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(511962788582001113)
,p_db_column_name=>'DESCUENTO'
,p_display_order=>160
,p_column_identifier=>'J'
,p_column_label=>'Descuento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(511963571407001121)
,p_db_column_name=>'ID_INVERSION'
,p_display_order=>170
,p_column_identifier=>'R'
,p_column_label=>'Id Inversion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(511961992342001105)
,p_db_column_name=>'NOMBRE'
,p_display_order=>180
,p_column_identifier=>'B'
,p_column_label=>unistr('Inversi\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(511963071536001116)
,p_db_column_name=>'SOLICITANTE'
,p_display_order=>190
,p_column_identifier=>'M'
,p_column_label=>'Solicitante'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(511962988824001115)
,p_db_column_name=>'APROBADOR'
,p_display_order=>200
,p_column_identifier=>'L'
,p_column_label=>'Aprobador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(511962893052001114)
,p_db_column_name=>'FECHA_INICIO'
,p_display_order=>210
,p_column_identifier=>'K'
,p_column_label=>'Fecha Inicio'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(511963117714001117)
,p_db_column_name=>'CODIGO_CLIENTE'
,p_display_order=>230
,p_column_identifier=>'N'
,p_column_label=>'Codigo Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(511963452527001120)
,p_db_column_name=>'CODIGO_BARRA'
,p_display_order=>240
,p_column_identifier=>'Q'
,p_column_label=>'Codigo Barra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(511963683486001122)
,p_db_column_name=>'SELECCION'
,p_display_order=>250
,p_column_identifier=>'S'
,p_column_label=>'-'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(511961845068001104)
,p_db_column_name=>'IDFLUJO'
,p_display_order=>260
,p_column_identifier=>'A'
,p_column_label=>'Idflujo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(518845668509532583)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5188457'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'GRUPO:SELECCION:CLIENTE:NEGOCIACION:LINEA_NEGOCIO:MARCA:PRODUCTO:CODIGO_PRODUCTO:FECHA_INV_INICIO:FECHA_INV_FIN:FECHA_NEG_INICIO:FECHA_NEG_FIN:FECHA_DESC_INICIO:FECHA_DESC_FIN:DESCUENTO:ID_INVERSION:NOMBRE:SOLICITANTE:'
,p_break_on=>'SELECCION:IDFLUJO:NOMBRE:GRUPO:0:0'
,p_break_enabled_on=>'SELECCION:IDFLUJO:NOMBRE:GRUPO:0:0'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(101574121229053018)
,p_plug_name=>'Inversiones'
,p_region_name=>'tabInversion'
,p_parent_plug_id=>wwv_flow_imp.id(99946386738054028)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(66449693245391136)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(66767993232004748)
,p_plug_name=>'Inversiones Comerciales'
,p_region_name=>'tblInversion'
,p_parent_plug_id=>wwv_flow_imp.id(101574121229053018)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(65967409977345223)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT I.ID, i.IDGRUPO,i.grupal, ',
'I.ETAPA, i.IDANALISTA, I.NOMBRE, I.ESTADO,   I.IDETAPA2,I.ETAPA_ALTERNA, i.INVERSIONTIPO, i.FIRMACONTRATO,',
'i.origen, i.tipo, i.fechainicio, i.usuario coordinador, ',
'CASE                    WHEN i.IDETAPA = 1 THEN',
'                               CASE WHEN I.ESTADO = 2 THEN 201 --APROBAR ',
'                                    ELSE 200  --VER PROPUESTA',
'                               END',
'                        WHEN i.IDETAPA = 2 AND i.IDETAPA2 IS NULL AND  (:P400_EJECUTIVO=1 OR :P400_NEGOCIADOR=1) THEN 300 -- NEGOCIADOR',
'                        WHEN i.IDETAPA IN (2,3,7) AND I.ESTADO = 2 AND i.IDETAPA2 IS NOT NULL THEN ',
unistr('                           CASE WHEN i.IDETAPA2 = 5 THEN 254   -- APROBADOR DE REPLANIFICACI\00D3N'),
'                                WHEN i.IDETAPA2 = 6 and i.FIRMACONTRATO=2 THEN 243   -- APROBADOR DE CLAUSURA INVERSION',
'                                WHEN i.IDETAPA2 = 6 and i.FIRMACONTRATO IS NULL THEN 200   -- APROBADOR DE CLAUSURA INVERSION',
'                               ',
'                           END',
'                        WHEN i.IDETAPA = 4 then -- cierre',
'                           case  when i.estado in (2,4) then  271 --es aprobacion',
'                                 else 270  --',
'                           end',
'                      ELSE  200',
'                   END paggina,',
'APEX_PAGE.GET_URL (p_application => :APP_ID,',
'                   p_page   =>',
'                   --ETAPA PROPUESTA',
'                   CASE WHEN i.IDETAPA = 1 THEN',
'                           CASE WHEN I.ESTADO = 2 THEN 201 --APROBAR ',
'                                ELSE 200  --VER PROPUESTA',
'                           END',
'                        WHEN i.IDETAPA = 2 AND i.IDETAPA2 IS NULL AND  (:P400_EJECUTIVO=1 OR :P400_NEGOCIADOR=1) THEN 300 -- NEGOCIADOR',
'                        WHEN i.IDETAPA IN (2,3,7) AND I.ESTADO = 2 AND i.IDETAPA2 IS NOT NULL THEN ',
unistr('                           CASE WHEN i.IDETAPA2 = 5 THEN 254   -- APROBADOR DE REPLANIFICACI\00D3N'),
'                                WHEN i.IDETAPA2 = 6 and i.FIRMACONTRATO=2 THEN 243   -- APROBADOR DE CLAUSURA INVERSION',
'                                WHEN i.IDETAPA2 = 6 and i.FIRMACONTRATO IS NULL THEN 200   -- APROBADOR DE CLAUSURA INVERSION',
'                               ',
'                           END',
'                        WHEN i.IDETAPA = 4 then -- cierre',
'                           case  when i.estado in (2,4) then  271 --es aprobacion',
'                                 else 270  --',
'                           end',
'                      ELSE  200',
'                   END,',
'                   p_items  => ',
'                   --ETAPA PROPUESTA',
'                   CASE WHEN i.IDETAPA = 1 THEN',
'                            CASE WHEN I.ESTADO = 2 THEN ',
'                               ''P201_ID,P201_APROBADOR,P201_COMPANIA'' ',
'                            ELSE',
'                               ''P200_ID,P200_ESCLIENTE'' ',
'                            END',
'                        WHEN i.IDETAPA = 2  AND  i.IDETAPA2 IS NULL AND (:P400_EJECUTIVO=1 OR :P400_NEGOCIADOR=1)',
'                               THEN ''P300_ID''',
'                        WHEN i.IDETAPA IN (2,3) AND I.ESTADO = 2 AND i.IDETAPA2 IS NOT NULL THEN ',
unistr('                           CASE WHEN i.IDETAPA2 = 5 THEN ''P254_ID,P254_IDPADRE,P254_APROBADOR''      -- APROBADOR DE REPLANIFICACI\00D3N'),
'                                WHEN i.IDETAPA2 = 6 and i.FIRMACONTRATO=2 THEN ''P243_ID,P243_APROBADOR''   -- APROBADOR DE CLAUSURA INVERSION',
'                                WHEN i.IDETAPA2 = 6 and i.FIRMACONTRATO IS NULL THEN  ''P200_ID,P200_APROBADOR,P200_ESCLIENTE''    -- APROBADOR DE CLAUSURA INVERSION',
'                                ',
'                           END   ',
'                       WHEN i.IDETAPA = 4 then -- cierre',
'                           case  when i.estado in (2,4) then  ''P271_IDINVERSION,P271_APROBADOR''',
'                                else  ''P270_IDINVERSION''',
'                           end',
'                   ELSE',
'                        ''P200_ID,P200_ESCLIENTE'' ',
'                   END,',
'                   p_values =>',
'                   --ETAPA PROPUESTA',
'                   CASE WHEN I.IDETAPA = 1 THEN',
'                             CASE WHEN I.ESTADO = 2 THEN ',
'                                   I.ID||'',''||I.USUARIOACTUAL||'',''||i.compania           ',
'                             ELSE',
'                                   TO_CHAR(I.ID)||'',0''    ',
'                             END',
'                        WHEN i.IDETAPA = 2  AND  I.IDETAPA2 IS NULL AND (:P400_EJECUTIVO=1 OR :P400_NEGOCIADOR=1)',
'                           THEN TO_CHAR(I.ID)',
'                       WHEN i.IDETAPA IN (2,3) AND I.ESTADO = 2 AND i.IDETAPA2 IS NOT NULL THEN ',
unistr('                           CASE WHEN i.IDETAPA2 = 5 THEN  TO_CHAR(I.ID)||'',''||I.ID||'',''||I.USUARIOACTUAL    -- APROBADOR DE REPLANIFICACI\00D3N'),
'                                WHEN i.IDETAPA2 = 6  THEN TO_CHAR(I.ID)||'',''||I.USUARIOACTUAL||'',0''    -- APROBADOR DE CLAUSURA INVERSION',
'                           END   ',
'                       WHEN i.IDETAPA = 4 then -- cierre',
'                           case  when i.estado in (2,4) then  TO_CHAR(I.ID)||'',''||I.USUARIOACTUAL',
'                                 else  TO_CHAR(I.ID)',
'                           end',
'                  ELSE ',
'                       TO_CHAR(I.ID)||'',0''    ',
'                   END ) URL, ',
'                  I.USUARIOACTUAL APROBADOR,',
'                  CASE WHEN (I.IDETAPA not in (2) AND I.ESTADO=2 AND I.IDGRUPO IS NULL ) OR (I.ESTADO=2 AND I.IDETAPA2 IS NOT NULL) ',
'                  THEN ''<span class="fa fa-road" aria-hidden="true"></span>'' ELSE '''' END RUTA,',
'',
'                   (Select PK_ICOM_COMMONS.F_INVERSION_COLOR (P_IDINVERSION => i.id, P_IDETAPA => i.idetapa, ',
'                                                                  P_ESTADO => i.estado, P_ANALISTA => i.idanalista, P_USUARIO=> i.USUARIO,',
'                                                                  P_LOGEADO => :APP_USER , P_APROBADOR => I.USUARIOACTUAL , P_COMPANIA => :G_COMPANIA) FROM DUAL) CSS,',
'                  (SELECT  PK_CORP_FLUJOAPROBACION.F_MESAORDEN(PK_CORP_FLUJOAPROBACION.F_GESTIONCOLOR(:APP_USER, I.USUARIOACTUAL, ESTADOFLUJO, :G_COMPANIA, :APP_MODULO)) ',
'                     FROM DUAL) orden ,',
'                  DATA.PK_ICOM_COMMONS.F_VERLINEANEGOCIO( P_ID => I.ID )  lineaNegocio, ',
'                  DATA.PK_ICOM_COMMONS.F_VERCANAL( P_ID => I.ID ) Canal, DIAS_RUTA, DIAS_CIERRE, COMPANIA,',
'        case when ( (i.idetapa = 1 OR i.idetapa2 = 5) and i.estado = 2 ) and i.usuarioactual = :APP_USER  then          ',
'            apex_item.checkbox( 1 , i.id||''|''||i.idetapa||''|''||I.USUARIOACTUAL,''CHECKED class="chkF01"'')',
'            else '''' end seleccion,',
'            PK_ICOM_FORMULAS.F_TotalGastoMetaInv (P_ID => i.id ) Gasto_Meta,',
'        case when i.idetapa in (2,3,7) THEN ''<span class="fa fa-tasks" aria-hidden="true"></span>'' ELSE '''' END asignar_Pago_Recurrente,',
'        ''<span class="fa fa-tasks" ></span>'' Actualizar_Coordinador',
'    FROM DATA.VT_ICOM_INVERSIONES_MESA I',
'    WHERE :P400_TIPO=''#tabInversion'' AND (i.COMPANIA =:G_COMPANIA or :P400_TODAS_COMPANIA = 1 ) ',
'    AND  (:P400_TIPO_INVERSION is null or I.IDINVERSIONTIPO=:P400_TIPO_INVERSION) AND',
'       ( ',
'            (:P400_ESTADO = 2 AND i.fechainicio between :P400_FECHAINICIO and :P400_FECHAFIN and (:P400_ESTADO_AC=1 and ESTADO<>4 or :P400_ESTADO_AC=0 and estado=4)) --todos por fechas    ',
'            OR :P400_ESTADO = 1 AND   --mis pendientes ',
'                 (    (I.USUARIOACTUAL = :APP_USER ) ---APROBADOR --> I.USUARIOACTUAL IS NOT NULL AND PK_CORP_FLUJOAPROBACION.F_APROBADORFLUJO(:APP_USER,I.USUARIOACTUAL,:APP_MODULO,:G_COMPANIA) = 1',
'                   OR (i.idetapa = 1 AND  i.estado=0 and i.USUARIO=:APP_USER)  --- CREADOR DE LA INVERSION',
'                   OR (i.idetapa = 4 AND i.estado in (0,1) and i.idanalista = :APP_USER) --- EVALUADOR DE LA INVERSION',
'                   OR (i.idetapa = 2 AND I.IDETAPA2 IS NULL AND  ---EJECUTIVO',
'                        EXISTS ( SELECT 1  FROM T_ICOM_INVERSION_CLIENTE_G C',
'                                WHERE C.IDINVERSION = I.ID  AND C.NEGOCIACION IN (0, 1) AND C.ESTADO IN (0, 1) ',
'                                AND EXISTS ( SELECT 1 FROM DATA.VT_GZM_CLIENTE A',
'                                        WHERE A.COMPANIA = :G_COMPANIA AND C.CODIGOGRUPO = A.CODIGOCLIENTE AND A.EJECUTIVO = :P400_IDENTIFICACION))',
'                       )    ',
'                  )',
'       );',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P400_ESTADO_AC,P400_ESTADO,P400_FECHAINICIO,P400_FECHAFIN,P400_TIPO,P400_TIPO_INVERSION'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(66768063297004749)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>66768063297004749
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(66768143597004750)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'#'
,p_column_link=>'#URL#'
,p_column_linktext=>'<span class=''#CSS#''>#ID#</span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(66976609450279002)
,p_db_column_name=>'NOMBRE'
,p_display_order=>20
,p_column_identifier=>'C'
,p_column_label=>'Nombre'
,p_column_link=>'#URL#'
,p_column_linktext=>'<span style="display:block; width:350px"  class=''#CSS#''>#NOMBRE#</span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(66976557143279001)
,p_db_column_name=>'IDANALISTA'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Evaluador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(74332438632721545)
,p_db_column_name=>'URL'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Url'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78098677612292111)
,p_db_column_name=>'ESTADO'
,p_display_order=>50
,p_column_identifier=>'F'
,p_column_label=>'Estado'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(92754014705005861)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(80496541468105612)
,p_db_column_name=>'ETAPA'
,p_display_order=>60
,p_column_identifier=>'H'
,p_column_label=>'Etapa'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91241783866671430)
,p_db_column_name=>'INVERSIONTIPO'
,p_display_order=>90
,p_column_identifier=>'K'
,p_column_label=>'Inversiontipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91241878207671431)
,p_db_column_name=>'FIRMACONTRATO'
,p_display_order=>100
,p_column_identifier=>'L'
,p_column_label=>'Firmacontrato'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91679948821427933)
,p_db_column_name=>'RUTA'
,p_display_order=>110
,p_column_identifier=>'M'
,p_column_label=>'-'
,p_column_link=>'f?p=100:104:&SESSION.::&DEBUG.:RP:G_OBJETO,G_OBJETO_ID,G_TODO:&APP_OBJETO.,#ID#,true'
,p_column_linktext=>'#RUTA#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91680082428427934)
,p_db_column_name=>'APROBADOR'
,p_display_order=>120
,p_column_identifier=>'N'
,p_column_label=>'Usuario Act.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92683834942446501)
,p_db_column_name=>'CSS'
,p_display_order=>130
,p_column_identifier=>'O'
,p_column_label=>'Css'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92683987963446502)
,p_db_column_name=>'ORDEN'
,p_display_order=>140
,p_column_identifier=>'P'
,p_column_label=>'Orden'
,p_column_type=>'NUMBER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(96164329496081205)
,p_db_column_name=>'ORIGEN'
,p_display_order=>150
,p_column_identifier=>'Q'
,p_column_label=>'Origen'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(96164438840081206)
,p_db_column_name=>'TIPO'
,p_display_order=>160
,p_column_identifier=>'R'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(96164502413081207)
,p_db_column_name=>'FECHAINICIO'
,p_display_order=>170
,p_column_identifier=>'S'
,p_column_label=>'Fecha inicio'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(96164681397081208)
,p_db_column_name=>'COORDINADOR'
,p_display_order=>180
,p_column_identifier=>'T'
,p_column_label=>'COORDINADOR'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94435278040991050)
,p_db_column_name=>'IDGRUPO'
,p_display_order=>190
,p_column_identifier=>'X'
,p_column_label=>'Grupo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103220332817173740)
,p_db_column_name=>'IDETAPA2'
,p_display_order=>200
,p_column_identifier=>'Y'
,p_column_label=>'Idetapa2'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103220479615173741)
,p_db_column_name=>'ETAPA_ALTERNA'
,p_display_order=>210
,p_column_identifier=>'Z'
,p_column_label=>'Etapa Alterna'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(128091200797624402)
,p_db_column_name=>'LINEANEGOCIO'
,p_display_order=>220
,p_column_identifier=>'AA'
,p_column_label=>'Linea Negocio'
,p_column_html_expression=>'<span style="display:block; width:350px">#LINEANEGOCIO#</span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(128091354043624403)
,p_db_column_name=>'CANAL'
,p_display_order=>230
,p_column_identifier=>'AB'
,p_column_label=>'Canal'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(128492977229855745)
,p_db_column_name=>'GRUPAL'
,p_display_order=>240
,p_column_identifier=>'AC'
,p_column_label=>'Grupal'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(66566087199922082)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(98886976763711830)
,p_db_column_name=>'COMPANIA'
,p_display_order=>250
,p_column_identifier=>'AD'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(103095346604929544)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(194490331730136220)
,p_db_column_name=>'DIAS_RUTA'
,p_display_order=>260
,p_column_identifier=>'AE'
,p_column_label=>'Dias en mi bandeja'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(900508900000000401)
,p_db_column_name=>'DIAS_CIERRE'
,p_display_order=>265
,p_column_identifier=>'AK'
,p_column_label=>'Dias en cierre'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(314313314816891928)
,p_db_column_name=>'SELECCION'
,p_display_order=>270
,p_column_identifier=>'AF'
,p_column_label=>'<input type="checkbox" id="selectallocs">'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P400_MASIVO = 1 '
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(320099781381569706)
,p_db_column_name=>'GASTO_META'
,p_display_order=>280
,p_column_identifier=>'AG'
,p_column_label=>'Gasto Meta'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(526179251048955034)
,p_db_column_name=>'PAGGINA'
,p_display_order=>290
,p_column_identifier=>'AH'
,p_column_label=>'Paggina'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(95486999090199335)
,p_db_column_name=>'ASIGNAR_PAGO_RECURRENTE'
,p_display_order=>300
,p_column_identifier=>'AI'
,p_column_label=>'Asignar Pago Recurrente'
,p_column_link=>'JavaScript: $s(''P400_ID_INVERSION'', ''#ID#'');'
,p_column_linktext=>'#ASIGNAR_PAGO_RECURRENTE#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES (P_CODIGOMODULO => :APP_MODULO , P_CODIGOUSUARIO => :APP_USER ',
'                                                                                    , P_RUTAPAGINA => 400 , P_CODIGOACCION => ''ACTUALIZAR_INV_MESA'')=0'))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102293132936789405)
,p_db_column_name=>'ACTUALIZAR_COORDINADOR'
,p_display_order=>310
,p_column_identifier=>'AJ'
,p_column_label=>'Actualizar Coordinador'
,p_column_link=>'JavaScript: $s(''P400_ID_INVERSION_C'', ''#ID#''); $s(''P400_USUARIOS'', ''#COORDINADOR#'');'
,p_column_linktext=>'#ACTUALIZAR_COORDINADOR#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES (P_CODIGOMODULO => :APP_MODULO , P_CODIGOUSUARIO => :APP_USER ',
'                                                                                    , P_RUTAPAGINA => 400 , P_CODIGOACCION => ''ACTUALIZAR_INV_MESA_COORDINADOR'')=0'))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(66984299919283171)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'669843'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100
,p_report_columns=>'SELECCION:ID:NOMBRE:GASTO_META:DIAS_RUTA:DIAS_CIERRE:IDGRUPO:GRUPAL:ETAPA:ETAPA_ALTERNA:ESTADO:ORIGEN:TIPO:CANAL:FECHAINICIO:COORDINADOR:IDANALISTA:APROBADOR:COMPANIA:ASIGNAR_PAGO_RECURRENTE:ACTUALIZAR_COORDINADOR:RUTA:'
,p_sort_column_1=>'ORDEN'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'DIAS_RUTA'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'ID'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(101574231179053019)
,p_plug_name=>'Filtros'
,p_parent_plug_id=>wwv_flow_imp.id(99946386738054028)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(66449693245391136)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(130828310084067115)
,p_plug_name=>'Implementacion'
,p_region_name=>'tabImplementa'
,p_parent_plug_id=>wwv_flow_imp.id(99946386738054028)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(66449693245391136)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(130830201072067134)
,p_plug_name=>'Procesos Operativos'
,p_region_name=>'tblProceso'
,p_parent_plug_id=>wwv_flow_imp.id(130828310084067115)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(66448811477391136)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with dato as ( ',
' select  CASE WHEN DATA.PK_ICOM_PROCESOS.F_BUSCAUSUARIO( P_USUARIO => :APP_USER, ',
'         P_CADENA => nvl(trim(m.USUARIOGESTION),''0'')||'';''||nvl(trim(m.USUARIO),''0'')||'';''||nvl(m.usuarioactual,''0'') )=1 AND PORCENTAJE <= 100 ',
'            THEN 1 ELSE 0 END EDITAR, ',
'            DECODE(m.usuario,  NULL, '''', m.usuario)||DECODE(USUARIOGESTION, NULL,'''', '' / ''||USUARIOGESTION) USUARIOS_GESTION, ',
'            CASE WHEN estadoflujo =''EN_PROCESO'' THEN ''<span class="fa fa-road" aria-hidden="true"></span>'' ELSE '''' END RUTA,',
'            CASE WHEN IDPROCESO =1 THEN ''<span class="fa fa-ban" title="Cancelacion" aria-hidden="true"></span>'' ELSE '''' END CANCELACION,',
'            (SELECT count(distinct 1)',
'                FROM vt_icom_descuentos_activos de',
'                inner join T_ICOM_PRODUCTO_DESCUENTO_FEC fe ',
'                on  de.CODIGOCLIENTE=fe.CODIGOCLIENTE ',
'                and de.CODIGOGRUPO=fe.CODIGOGRUPO ',
'                and de.CODIGOPRODUCTO=fe.CODIGOPRODUCTO ',
'                and de.IDINVERSION1=fe.IDINVERSION ',
'                and de.FECHADESDE=fe.FECHAINICIO ',
'                and de.FECHAHASTA=fe.FECHAFIN ',
'            where  to_number(de.IDINVERSION1)=to_number(m.IDINVERSION) AND ESTADO = 3 and m.IDPROCESO =1) tienedescuentosaprob,',
'            M.*',
'    from data.VT_ICOM_MESATRABAJOPROCESO m -- WHERE M.idproceso = 4 --AND M.ENTIDAD IS NOT NULL',
'    WHERE :P400_TIPO=''#tabImplementa''  ',
')',
'select d.IDINVERSION, d.INVERSION,  d.IDPROCESO,  d.DESCRIPCION,  d.PORCENTAJE, d.FECHAINICIO, d.FECHAFIN,',
'    d.editar, d.USUARIOS_GESTION,USUARIOACTUAL APROBADOR, d.estadoproceso,',
'     PK_CORP_FLUJOAPROBACION.F_GESTIONCOLOR(:APP_USER, CASE WHEN EDITAR=1 THEN :APP_USER ELSE USUARIOACTUAL END, D.ESTADOFLUJO, :G_COMPANIA, :APP_MODULO) css,',
'    PK_CORP_FLUJOAPROBACION.F_MESAORDEN(PK_CORP_FLUJOAPROBACION.F_GESTIONCOLOR(:APP_USER, CASE WHEN EDITAR=1 THEN :APP_USER ELSE NULL END, D.ESTADOFLUJO, :G_COMPANIA, :APP_MODULO)) orden,',
'    RUTA,decode(tienedescuentosaprob,1,CANCELACION,null)CANCELACION,ENTIDAD,idetapa ETAPA, idetapa2 ETAPA_ALTERNA,',
'    case d.idproceso ',
unistr('                                   when 1 then  ''P610_ID,P610_EDITAR'' --PARAMETRIZACI\00D3N DE DESCUENTOS '),
'                                   when 8 then ''P600_ID,P600_EDITAR'' --Codigos Promocionales',
unistr('                                   when 5 then ''P602_ID,P602_EDITAR'' --Dise\00F1o de Arte'),
'                                   when 10 then ''P604_ID,P604_EDITAR'' --Referencia Cruzada',
'                                   when 6 then ',
'                                        case d.tipo ',
'                                           when 1 then ''P606_ID,P606_GRUPO,P606_EDITAR'' --Compra Material POP',
'                                           when 2 then ''P606_ID,P606_GRUPO,P606_EDITAR'' --Compra Material POP/APROBACION',
'                                           when 3 then ''P607_ID,P607_ESTADO,P607_EDITAR'' --Ingresa Distribucion Material POP',
'                                           when 4 then ''P607_ID,P607_ESTADO,P607_EDITAR'' --Revisar Material POP',
'                                           when 5 then ''P607_ID,P607_ESTADO,P607_EDITAR,P607_APROBADOR'' --Aprobar Material POP',
'                                        end  ',
'                                    when 4 then ''P608_ID,P608_EDITAR,P608_PORCENTAJE,P608_APROBADOR,P608_ENTIDAD_ID'' --Producto Distribucion     ',
'                                    when 11 then ''P609_ID,P609_EDITAR,P609_APROBADOR,P609_ESTADO'' --Gestion de Muestras',
'                               end  PAGGINA,',
'    APEX_PAGE.GET_URL ( p_application => :APP_ID,',
'                   p_page   => case d.idproceso ',
unistr('                                   when 1 then 610 --PARAMETRIZACI\00D3N DE DESCUENTOS'),
'                                   when 8 then 600 --Codigos Promocionales',
unistr('                                   when 5 then 602 --Dise\00F1o de Arte'),
'                                   when 10 then 604 --Referencia Cruzada',
'                                   when 6 then ',
'                                       case  ',
'                                           when d.tipo = 1 then 606 --Compra Material POP',
'                                           when d.tipo = 2 then 606 --Compra Material POP / APROBACION',
'                                           when d.tipo in (3,4,5) then 607 --Distribucion Material POP',
'                                       end    ',
'                                   when 4 then 608 --Producto Distribucion',
'                                   when 11 then 609 --Gestion de Mestras',
'                               end ,',
'                   p_items  => case d.idproceso ',
unistr('                                   when 1 then  ''P610_ID,P610_EDITAR'' --PARAMETRIZACI\00D3N DE DESCUENTOS '),
'                                   when 8 then ''P600_ID,P600_EDITAR'' --Codigos Promocionales',
unistr('                                   when 5 then ''P602_ID,P602_EDITAR'' --Dise\00F1o de Arte'),
'                                   when 10 then ''P604_ID,P604_EDITAR'' --Referencia Cruzada',
'                                   when 6 then ',
'                                        case d.tipo ',
'                                           when 1 then ''P606_ID,P606_GRUPO,P606_EDITAR'' --Compra Material POP',
'                                           when 2 then ''P606_ID,P606_GRUPO,P606_EDITAR'' --Compra Material POP/APROBACION',
'                                           when 3 then ''P607_ID,P607_ESTADO,P607_EDITAR'' --Ingresa Distribucion Material POP',
'                                           when 4 then ''P607_ID,P607_ESTADO,P607_EDITAR'' --Revisar Material POP',
'                                           when 5 then ''P607_ID,P607_ESTADO,P607_EDITAR,P607_APROBADOR'' --Aprobar Material POP',
'                                        end  ',
'                                    when 4 then ''P608_ID,P608_EDITAR,P608_PORCENTAJE,P608_APROBADOR,P608_ENTIDAD_ID'' --Producto Distribucion     ',
'                                    when 11 then ''P609_ID,P609_EDITAR,P609_APROBADOR,P609_ESTADO'' --Gestion de Muestras',
'                               end  ,',
'                   p_values => case d.idproceso ',
unistr('                                   when 1 then d.idinversion||'',''||d.editar --PARAMETRIZACI\00D3N DE DESCUENTOS  '),
'                                   when 8 then d.idinversion||'',''||d.editar --Codigos Promocionales',
unistr('                                   when 5 then d.idinversion||'',''||d.editar --Dise\00F1o de Arte'),
'                                   when 10 then d.idinversion||'',''||d.editar --Referencia Cruzada',
'                                   when 6 then ',
'                                        case d.tipo ',
'                                           when 1 then to_char(d.idinversion)||'',''||'',''||d.editar --Compra Material POP',
'                                           when 2 then SUBSTR(d.idinversion, 1, INSTR(d.idinversion, ''-'', 1) -1)||'',''',
'                                           ||SUBSTR(d.idinversion, INSTR(d.idinversion, ''-'', 1)+1)||'',''||d.editar --Compra Material POP / APROBACION',
'                                           when 3 then to_char(d.idinversion)||'',0,''||d.editar --Ingreso Distribucion Material POP',
'                                           when 4 then to_char(d.idinversion)||'',1,0'' -- Revisar Material pop',
'                                           when 5 then to_char(d.idinversion)||'',2,''||d.editar||'',''||d.USUARIOACTUAL -- Aprobar Distribucion Material POP',
'                                           ',
'                                        end   ',
'                                   when 4 then d.idinversion||'',''||d.editar||'',''||d.porcentaje||'',''||d.USUARIOACTUAL||'',''||d.ENTIDADID  --Producto Distribucion       ',
'                                   when 11 then d.idinversion||'',''||d.editar||'',''||d.USUARIOACTUAL||'',''||d.tipo  --Gestion de Muestras',
'                               end , ',
'                    p_clear_cache=>''RP,600,602,604,606,607,608, 609, 610'' ) URL',
'from dato d',
'where  :P400_TIPO=''#tabImplementa''  AND    (EDITAR = 1    --mis pendientes ',
'       OR (:P400_ESTADO = 2 AND d.fechainicio between :P400_FECHAINICIO and :P400_FECHAFIN )  --TODOS',
')',
'    ',
'--order by orden'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P400_ESTADO,P400_FECHAINICIO,P400_FECHAFIN,P400_TIPO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(130830356990067135)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'No existen datos'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'NETBY2'
,p_internal_uid=>130830356990067135
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(130830632457067138)
,p_db_column_name=>'IDPROCESO'
,p_display_order=>10
,p_column_identifier=>'C'
,p_column_label=>'Id Proceso'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(130830721010067139)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>20
,p_column_identifier=>'D'
,p_column_label=>'Proceso'
,p_column_link=>'#URL#'
,p_column_linktext=>'<span class=''#CSS#''>#DESCRIPCION#</span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(130830537183067137)
,p_db_column_name=>'INVERSION'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'Nombre Inversion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(130831023665067142)
,p_db_column_name=>'FECHAINICIO'
,p_display_order=>60
,p_column_identifier=>'G'
,p_column_label=>'Fecha Inicio'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(130831128879067143)
,p_db_column_name=>'FECHAFIN'
,p_display_order=>70
,p_column_identifier=>'H'
,p_column_label=>'Fecha Fin'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(130830917294067141)
,p_db_column_name=>'PORCENTAJE'
,p_display_order=>80
,p_column_identifier=>'F'
,p_column_label=>'Porcentaje'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132121652806055302)
,p_db_column_name=>'ESTADOPROCESO'
,p_display_order=>90
,p_column_identifier=>'O'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132121552403055301)
,p_db_column_name=>'EDITAR'
,p_display_order=>110
,p_column_identifier=>'N'
,p_column_label=>'Editar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132121729455055303)
,p_db_column_name=>'CSS'
,p_display_order=>120
,p_column_identifier=>'P'
,p_column_label=>'Css'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132121897363055304)
,p_db_column_name=>'ORDEN'
,p_display_order=>130
,p_column_identifier=>'Q'
,p_column_label=>'Orden'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132122794390055313)
,p_db_column_name=>'URL'
,p_display_order=>140
,p_column_identifier=>'R'
,p_column_label=>'Url'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(84558970225958205)
,p_db_column_name=>'IDINVERSION'
,p_display_order=>150
,p_column_identifier=>'S'
,p_column_label=>'Id'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(96682568858465707)
,p_db_column_name=>'USUARIOS_GESTION'
,p_display_order=>160
,p_column_identifier=>'T'
,p_column_label=>'Usuarios Gestion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(96682651471465708)
,p_db_column_name=>'APROBADOR'
,p_display_order=>170
,p_column_identifier=>'U'
,p_column_label=>'Aprobador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(96682742213465709)
,p_db_column_name=>'RUTA'
,p_display_order=>180
,p_column_identifier=>'V'
,p_column_label=>'Ruta'
,p_column_link=>'f?p=100:104:&SESSION.::&DEBUG.::G_OBJETO,G_OBJETO_ID,G_TODO:#ENTIDAD#,#IDINVERSION#,true'
,p_column_linktext=>'#RUTA#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(96682867903465710)
,p_db_column_name=>'ENTIDAD'
,p_display_order=>190
,p_column_identifier=>'W'
,p_column_label=>'Entidad'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(98885286177711813)
,p_db_column_name=>'ETAPA'
,p_display_order=>200
,p_column_identifier=>'X'
,p_column_label=>'Etapa'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(66564499404855100)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(98885372882711814)
,p_db_column_name=>'ETAPA_ALTERNA'
,p_display_order=>210
,p_column_identifier=>'Y'
,p_column_label=>'Etapa Alterna'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(66564499404855100)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(517178399562653927)
,p_db_column_name=>'CANCELACION'
,p_display_order=>220
,p_column_identifier=>'Z'
,p_column_label=>'-'
,p_column_link=>'f?p=&APP_ID.:125:&SESSION.::&DEBUG.:RR,125:P125_IDINVERSION:#IDINVERSION#'
,p_column_linktext=>'#CANCELACION#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(537215702190498448)
,p_db_column_name=>'PAGGINA'
,p_display_order=>230
,p_column_identifier=>'AA'
,p_column_label=>'Paggina'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(132105932146315800)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1321060'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'IDINVERSION:DESCRIPCION:INVERSION:ETAPA:ETAPA_ALTERNA:FECHAINICIO:FECHAFIN:APROBADOR:USUARIOS_GESTION:PORCENTAJE:ESTADOPROCESO:RUTA:CANCELACION:'
,p_sort_column_1=>'RUTA'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'DESCRIPCION'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'IDINVERSION'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(102293386240789407)
,p_plug_name=>'Modal Actualizar Coordinador'
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_imp.id(65965332063345222)
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_04'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(102293407374789408)
,p_plug_name=>'Formulario'
,p_parent_plug_id=>wwv_flow_imp.id(102293386240789407)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(66449693245391136)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(102293652634789410)
,p_plug_name=>'Botones'
,p_parent_plug_id=>wwv_flow_imp.id(102293407374789408)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(66450057576391136)
,p_plug_display_sequence=>40
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(100629157638237942)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(66767878384004747)
,p_button_name=>'INFORMACION'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020723356345242)
,p_button_image_alt=>'Informacion'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.:RP::'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES (P_CODIGOMODULO => :APP_MODULO , P_CODIGOUSUARIO => :APP_USER ',
unistr('                                                                                    , P_RUTAPAGINA => 200 , P_CODIGOACCION => ''INFORMACI\00D3N_DE_CLIENTE'')=1')))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-info-circle-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(71890828246322141)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(66767878384004747)
,p_button_name=>'NUEVA'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020723356345242)
,p_button_image_alt=>'Nueva inversion'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:RP,200::'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES (P_CODIGOMODULO => :APP_MODULO , P_CODIGOUSUARIO => :APP_USER ',
unistr('                                                                                    , P_RUTAPAGINA => 400 , P_CODIGOACCION => ''BOT\00D3N_M\00C1S'')=1')))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(91761527590409850)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(66767878384004747)
,p_button_name=>'BUSCAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020723356345242)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(391804004566295202)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(66767878384004747)
,p_button_name=>'Ver_Notificacion'
,p_button_static_id=>'btVerNotificaciones'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020723356345242)
,p_button_image_alt=>'Ver Notificacion'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:119:&SESSION.::&DEBUG.:RR,119:P119_SOLOPRESENTACION,P119_NOMBREUSUARIO:1,&APP_USER.'
,p_icon_css_classes=>'fa-window-terminal'
,p_button_cattributes=>'style="display:none"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(668860856496045737)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(630807612067619644)
,p_button_name=>'POWERBI'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020723356345242)
,p_button_image_alt=>'Power bi'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-bar-chart'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(96159065277462014)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(96158985777462013)
,p_button_name=>'Salir'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020869239345242)
,p_button_image_alt=>'Salir'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(102293769235789411)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(102293652634789410)
,p_button_name=>'Salir_C'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020869239345242)
,p_button_image_alt=>'Salir'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(102293818200789412)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(102293652634789410)
,p_button_name=>'Guardar_C'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020869239345242)
,p_button_image_alt=>'Guardar'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(98831411970469056)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(195504909200934746)
,p_button_name=>'MOSTRAR_FILTRO'
,p_button_static_id=>'btnMostrarFiltro'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020723356345242)
,p_button_image_alt=>'Mostrar filtro'
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-chevron-circle-down'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(98831013060469055)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(195504909200934746)
,p_button_name=>'OCULTAR_FILTRO'
,p_button_static_id=>'btnOcultarFiltro'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020723356345242)
,p_button_image_alt=>'Ocultar Filtro'
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-chevron-circle-up'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(101572699150053003)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(100627884741237929)
,p_button_name=>'SELECCIONAR_TODO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020723356345242)
,p_button_image_alt=>'Seleccionar Todas las fechas'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-check-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(104991372917056704)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(102296245454789436)
,p_button_name=>'Guardar_Pagos'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020723356345242)
,p_button_image_alt=>'Guardar Pagos'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-plus-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(110642875976077740)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(88214903596774818)
,p_button_name=>'SELECCIONAR_TODO_1'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020723356345242)
,p_button_image_alt=>'Seleccionar Todo'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-check-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(314313512980891930)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(66767993232004748)
,p_button_name=>'BTNAPROBAR'
,p_button_static_id=>'btnAprobar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020723356345242)
,p_button_image_alt=>'Aprobar Todo'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P400_MASIVO=1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-thumbs-up'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(517180259965653946)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(511961636946001102)
,p_button_name=>'APROBAR_CANCLEACION_DESCUENTO'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020723356345242)
,p_button_image_alt=>unistr('Aprobar Inactivaci\00F3n descuentos')
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:107:&SESSION.::&DEBUG.:RP,:G_VALOR1:0'
,p_icon_css_classes=>'fa-thumbs-up'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(517180392564653947)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(511961636946001102)
,p_button_name=>'RECHAZAR_CANCELACIONDESCUENTO'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020723356345242)
,p_button_image_alt=>unistr('Rechazar Inactivaci\00F3n descuentos')
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:107:&SESSION.::&DEBUG.:RP,:G_VALOR1:1'
,p_icon_css_classes=>'fa-thumbs-down'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(88271707697031821)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(88214903596774818)
,p_button_name=>'AgregarAInversion'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020723356345242)
,p_button_image_alt=>unistr('Agregar a Inversi\00F3n')
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(94996626510751638)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(94993515469751607)
,p_button_name=>'SELECCIONAR_TODO_DESC'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020723356345242)
,p_button_image_alt=>'Seleccionar Todos los descuentos'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-check-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(314314122823891936)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(66767993232004748)
,p_button_name=>'BTNRECHAZAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020723356345242)
,p_button_image_alt=>'Rechazar Todo'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P400_MASIVO=1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-thumbs-down'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(88534846804319543)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(88214903596774818)
,p_button_name=>'AgregarAInversion_1'
,p_button_static_id=>'btnConvenio'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020723356345242)
,p_button_image_alt=>unistr('Agregar a Inversi\00F3n')
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:401:&SESSION.::&DEBUG.:RP,401::'
,p_icon_css_classes=>'fa-plus'
,p_button_cattributes=>'style="display:none;"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(94996713419751639)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(94993515469751607)
,p_button_name=>'APROBAR_DESCUENTO'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020723356345242)
,p_button_image_alt=>'Aprobar descuentos'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:107:&SESSION.::&DEBUG.:RP,:G_VALOR1:0'
,p_icon_css_classes=>'fa-thumbs-up'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(101573181033053008)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(100627884741237929)
,p_button_name=>'NEGOCIACION_APROBAR'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020723356345242)
,p_button_image_alt=>'Aprobar fechas'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:107:&SESSION.::&DEBUG.:RP,:G_VALOR1:0'
,p_icon_css_classes=>'fa-thumbs-up'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(314315077676891945)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(66767993232004748)
,p_button_name=>'APROBARMASIVO'
,p_button_static_id=>'AprobarMasivo'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020723356345242)
,p_button_image_alt=>'Aprobar Masivo'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:107:&SESSION.::&DEBUG.:RP,:G_VALOR1:0'
,p_icon_css_classes=>'fa-thumbs-up'
,p_button_cattributes=>'style="display:none;"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(101573262238053009)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(100627884741237929)
,p_button_name=>'NEGOCIACION_RECHAZAR'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020723356345242)
,p_button_image_alt=>'Rechazar fechas'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:107:&SESSION.::&DEBUG.:RP,:G_VALOR1:1'
,p_icon_css_classes=>'fa-thumbs-down'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(314315154905891946)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(66767993232004748)
,p_button_name=>'RECHAZARMASIVO'
,p_button_static_id=>'RechazarMasivo'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020723356345242)
,p_button_image_alt=>'Rechazarmasivo'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:107:&SESSION.::&DEBUG.:RP,:G_VALOR1:1'
,p_icon_css_classes=>'fa-thumbs-down'
,p_button_cattributes=>'style="display:none;"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(94996803290751640)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(94993515469751607)
,p_button_name=>'RECHAZAR_DESCUENTO'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020723356345242)
,p_button_image_alt=>'Rechazar descuentos'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:107:&SESSION.::&DEBUG.:RP,:G_VALOR1:1'
,p_icon_css_classes=>'fa-thumbs-down'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(137561193101719767)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(66767993232004748)
,p_button_name=>'DESCARGAR_FORMATO'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020723356345242)
,p_button_image_alt=>'Descargar formato'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'#APP_IMAGES#Formatos/FORMATO_INVERSIONES.xlsx'
,p_button_css_classes=>'btnAccion'
,p_icon_css_classes=>'fa-download'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(137558558842715374)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(66767993232004748)
,p_button_name=>'SUBIR_DATOS'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(66020723356345242)
,p_button_image_alt=>'Subir Datos'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:300:&SESSION.::&DEBUG.:RP,300::'
,p_button_css_classes=>'btnAccion'
,p_icon_css_classes=>'fa-upload'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(104992495454056715)
,p_branch_action=>'#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(104991372917056704)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(107051155257842846)
,p_branch_name=>'Go To Page #'
,p_branch_action=>'#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(88271707697031821)
,p_branch_sequence=>30
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48860158818547348)
,p_name=>'P400_IDAGRUPA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(99946446836054029)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(52761313475753503)
,p_name=>'P400_TIPOVAL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(99946446836054029)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(88271401842031818)
,p_name=>'P400_NMESES_BUSQUEDA_SIN_ASGINAR'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(99946222142054027)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91760893135409843)
,p_name=>'P400_ESTADO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(101574231179053019)
,p_item_default=>'1'
,p_prompt=>'Inversiones:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Mis Pendientes;1,Todos;2'
,p_cHeight=>1
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(66020158316345242)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91760935152409844)
,p_name=>'P400_FECHAINICIO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(101574231179053019)
,p_item_default=>'trunc(add_months(SYSDATE, -8),''MONTH'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Inicio:'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(66020158316345242)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91761017665409845)
,p_name=>'P400_FECHAFIN'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(101574231179053019)
,p_item_default=>'SELECT LAST_DAY(add_months(SYSDATE, +8)) FROM DUAL'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Fecha Fin:'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(66020158316345242)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(94435058930991048)
,p_name=>'P400_TIPO_INVERSION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(101574231179053019)
,p_prompt=>'Tipo:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT DESCRIPCION d , IDINVERSIONTIPO r  FROM VT_ICOM_INVERSIONTIPO WHERE ESTADO=1'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(66020158316345242)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(94997057972751642)
,p_name=>'P400_SELECCIONAR_DESCUENTO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(94993515469751607)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(95488297780199348)
,p_name=>'P400_ID_INVERSION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(66767993232004748)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98828231638469050)
,p_name=>'P400_INCIA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(196841331584513859)
,p_prompt=>'Incia en:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_css_classes=>'inicia'
,p_colspan=>12
,p_grid_label_column_span=>6
,p_field_template=>wwv_flow_imp.id(66020158316345242)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98829257222469053)
,p_name=>'P400_AREA_TODOS'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(195506150827934759)
,p_prompt=>'Todos'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(66020158316345242)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98829641229469053)
,p_name=>'P400_AREA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(195506150827934759)
,p_prompt=>'Area'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'LOV_AREA'
,p_lov=>'SELECT  DESCRIPCION, IDAREA FROM VT_ICOM_AREA where compania = :g_compania ;'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(66020158316345242)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'6'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98830364831469054)
,p_name=>'P400_INVERSIONES'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(195506405035934761)
,p_prompt=>'Inversiones'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Select id||''-''||nombre nombre, id from t_icom_inversiones i',
'where compania=:G_compania and idpadre is null and idetapa in (2,3,7)',
'and exists (select 1 from t_icom_inversion_proceso p where idinversion=i.id and p.estado=1) and',
'(to_char(FECHAINICIO, ''YYYY'') in ((SELECT regexp_substr(:P400_ANIO,''[^:]+'', 1, level) FROM DUAL connect by regexp_substr(:P400_ANIO, ''[^:]+'', 1, level) is not null )) or :P400_ANIO is null)',
'AND (to_char(FECHAINICIO, ''MM'') in ((SELECT regexp_substr(:P400_MES,''[^:]+'', 1, level) FROM DUAL connect by regexp_substr(:P400_MES, ''[^:]+'', 1, level) is not null )) or :P400_MES is null)',
'AND (IDAREA IN ((SELECT regexp_substr(:P400_AREA,''[^:]+'', 1, level) FROM DUAL connect by regexp_substr(:P400_AREA, ''[^:]+'', 1, level) is not null )) or :P400_AREA is null)'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P400_ANIO,P400_MES,P400_AREA'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(66020158316345242)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98835036565469058)
,p_name=>'P400_MESES_TODOS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(195505513006934752)
,p_prompt=>'Todos'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(66020158316345242)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98835400060469059)
,p_name=>'P400_MES'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(195505513006934752)
,p_prompt=>'Mes'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'LOV_LISTA_MES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT substr(TO_CHAR(to_date(level, ''MM''), ''Month''),1,3) AS mes, to_char(to_date(level, ''MM''), ''MM'') numero  ',
'FROM dual',
'CONNECT BY level <= 12;'))
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(66020158316345242)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'4'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98836190302469059)
,p_name=>'P400_ANIO_TODOS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(195505403136934751)
,p_prompt=>'Todos'
,p_display_as=>'NATIVE_SINGLE_CHECKBOX'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(66020158316345242)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98836515781469059)
,p_name=>'P400_ANIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(195505403136934751)
,p_prompt=>'Anio'
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'LOV_LISTA_ANIO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT sUbstr(TO_CHAR(SYSDATE, ''YYYY'') - LEVEL + 1, 3,4) AS ANIO, TO_CHAR(SYSDATE, ''YYYY'') - LEVEL + 1 NUMERO',
'FROM dual',
'CONNECT BY LEVEL <= 3;'))
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(66020158316345242)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--radioButtonGroup'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'5'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98837200990469060)
,p_name=>'P400_FECHA_INCIO_INV'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(195507810575934775)
,p_prompt=>'Incio Inv'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>5
,p_field_template=>wwv_flow_imp.id(66020158316345242)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98837693852469060)
,p_name=>'P400_FECHA_FIN_INV'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(195507810575934775)
,p_prompt=>'Fin Inv'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>5
,p_field_template=>wwv_flow_imp.id(66020158316345242)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98838092296469060)
,p_name=>'P400_DURACION_INV'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(195507810575934775)
,p_prompt=>'Duracion'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_css_classes=>'duracion '
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(66020158316345242)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98838402928469060)
,p_name=>'P400_FECHA_INCIO_NEG'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(195507810575934775)
,p_prompt=>'Incio Neg'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>5
,p_field_template=>wwv_flow_imp.id(66020158316345242)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98838890255469061)
,p_name=>'P400_FECHA_FIN_NEG'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(195507810575934775)
,p_prompt=>'Fin Neg'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>5
,p_field_template=>wwv_flow_imp.id(66020158316345242)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98839278477469061)
,p_name=>'P400_DURACION_NEG'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(195507810575934775)
,p_prompt=>'Duracion'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_css_classes=>'duracion '
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(66020158316345242)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(100325853838607403)
,p_name=>'P400_TIPO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(99946222142054027)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101557498745638113)
,p_name=>'P400_TODAS_COMPANIA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(99946222142054027)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101572532948053002)
,p_name=>'P400_SELECCIONAR_TODO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(100627884741237929)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101573042024053007)
,p_name=>'P400_COMENTARIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(101572436989053001)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101574396602053020)
,p_name=>'P400_EJECUTIVO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(99946222142054027)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101574407843053021)
,p_name=>'P400_NEGOCIADOR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(99946222142054027)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(102293534265789409)
,p_name=>'P400_USUARIOS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(102293407374789408)
,p_prompt=>'Usuarios'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'SELECT NOMBREUSUARIO||'' - ''|| APELLIDOS||'' ''||NOMBRES,NOMBREUSUARIO FROM DATA.VT_CORP_USUARIO;'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(66020158316345242)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(102293930108789413)
,p_name=>'P400_ID_INVERSION_C'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(66767993232004748)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(107460267907039901)
,p_name=>'P400_IDENTIFICACION'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(99946222142054027)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(110643262085077744)
,p_name=>'P400_SELECCIONAR_TODO_1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(88214903596774818)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(117216770598492650)
,p_name=>'P400_COMENTARIOUSUARIO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(101572436989053001)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(238713358121364430)
,p_name=>'P400_ESTADO_AC'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(101574231179053019)
,p_item_default=>'1'
,p_prompt=>'Estado:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Abiertas;1,Cerradas;0'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(66020158316345242)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(314313467941891929)
,p_name=>'P400_MASIVO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(99946222142054027)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(340099213992298910)
,p_name=>'P400_MODULO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(99946222142054027)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(340099377900298911)
,p_name=>'P400_COMPANIA'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(99946222142054027)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(396849334542788315)
,p_name=>'P400_NOTIFICACIONES'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(99946222142054027)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(518900459780611806)
,p_name=>'P400_CONTADOR'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(99946222142054027)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(100325911444607404)
,p_name=>'Cambiar tab'
,p_event_sequence=>5
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_TIPO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(238713058878364427)
,p_event_id=>wwv_flow_imp.id(100325911444607404)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'actulizarTablas();',
'',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(91761162641409846)
,p_name=>'mostrarFiltro'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_ESTADO'
,p_condition_element=>'P400_ESTADO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(91761462027409849)
,p_event_id=>wwv_flow_imp.id(91761162641409846)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P400_FECHAINICIO,P400_FECHAFIN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(238713841547364435)
,p_event_id=>wwv_flow_imp.id(91761162641409846)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P400_ESTADO_AC,P400_TIPO_INVERSION'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P400_TIPO'
,p_client_condition_expression=>'#tabInversion'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(91761281334409847)
,p_event_id=>wwv_flow_imp.id(91761162641409846)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P400_FECHAINICIO,P400_FECHAFIN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(238713614459364433)
,p_event_id=>wwv_flow_imp.id(91761162641409846)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P400_ESTADO_AC,P400_TIPO_INVERSION'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P400_TIPO'
,p_client_condition_expression=>'#tabInversion'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(276682043567681426)
,p_name=>'load'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(276682197630681427)
,p_event_id=>wwv_flow_imp.id(276682043567681426)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log(''load page'');',
'',
'if($v(''P400_TIPO'')==''''){',
'    //$s(''P400_TIPO'',''#tabInversion'');  ',
'        $(''.apex-rds'').data(''onRegionChange'', function(mode, activeTab) {',
'        apex.item( "P400_TIPO" ).setValue(activeTab.href);',
'    });',
'    console.log(''click tabInversion_tab'');',
'    $("#tabInversion_tab a").click();',
'}',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(132122238288055308)
,p_event_id=>wwv_flow_imp.id(276682043567681426)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_util.set_session_state(''G_EJECUTIVO'', PK_ICOM_COMMONS.F_ESEJECUTIVO(P_USUARIO=>:APP_USER, P_COMPANIA=>:G_COMPANIA) );',
'apex_util.set_session_state(''G_NEGOCIADOR'', PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES ( P_CODIGOMODULO => :APP_MODULO, ',
'                                                                             P_CODIGOUSUARIO => :APP_USER    , ',
'                                                                             P_RUTAPAGINA => 300    , ',
'                                                                             P_CODIGOACCION => ''NEGOCIADOR'') );',
'',
''))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(105035025257338916)
,p_name=>'mostrarEstado'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_TIPO'
,p_condition_element=>'P400_TIPO'
,p_triggering_condition_type=>'NOT_IN_LIST'
,p_triggering_expression=>'#tabNegociacion, #tabMonitoreo,#tabPDVSinasignar'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(105035120323338917)
,p_event_id=>wwv_flow_imp.id(105035025257338916)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P400_ESTADO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(105035337686338919)
,p_event_id=>wwv_flow_imp.id(105035025257338916)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P400_ESTADO,P400_FECHAINICIO,P400_FECHAFIN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(105035915867338925)
,p_event_id=>wwv_flow_imp.id(105035025257338916)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P400_FECHAINICIO,P400_FECHAFIN'
,p_client_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_client_condition_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(apex.item(''P400_TIPO'').getValue() != ''#tabNegociacion'' &&',
'   apex.item(''P400_ESTADO'').getValue() == 2)'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(105035424698338920)
,p_name=>'mostrarTipo'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_TIPO'
,p_condition_element=>'P400_TIPO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'#tabInversion'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(105035525532338921)
,p_event_id=>wwv_flow_imp.id(105035424698338920)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P400_TIPO_INVERSION,P400_ESTADO_AC'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P400_ESTADO'
,p_client_condition_expression=>'2'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(105035701507338923)
,p_event_id=>wwv_flow_imp.id(105035424698338920)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P400_TIPO_INVERSION,P400_ESTADO_AC'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(101572708674053004)
,p_name=>'Seleccionar todo'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(101572699150053003)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(101572875240053005)
,p_event_id=>wwv_flow_imp.id(101572708674053004)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P400_SELECCIONAR_TODO:= CASE WHEN :P400_SELECCIONAR_TODO IS NULL THEN 1 ',
'                               WHEN :P400_SELECCIONAR_TODO= 1 THEN 0 ELSE 1 END;'))
,p_attribute_02=>'P400_SELECCIONAR_TODO'
,p_attribute_03=>'P400_SELECCIONAR_TODO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(101572929270053006)
,p_event_id=>wwv_flow_imp.id(101572708674053004)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(100627884741237929)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(110642994126077741)
,p_name=>'Seleccionar todo_1'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(110642875976077740)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(110643034415077742)
,p_event_id=>wwv_flow_imp.id(110642994126077741)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P400_SELECCIONAR_TODO_1:= CASE WHEN :P400_SELECCIONAR_TODO_1 IS NULL THEN 1 ',
'                               WHEN :P400_SELECCIONAR_TODO_1= 1 THEN 0 ELSE 1 END;'))
,p_attribute_02=>'P400_SELECCIONAR_TODO_1'
,p_attribute_03=>'P400_SELECCIONAR_TODO_1'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(110643149991077743)
,p_event_id=>wwv_flow_imp.id(110642994126077741)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(88214903596774818)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(94997193560751643)
,p_name=>'Seleccionar todo Descuento'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(94996626510751638)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94997288256751644)
,p_event_id=>wwv_flow_imp.id(94997193560751643)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P400_SELECCIONAR_DESCUENTO:= CASE WHEN :P400_SELECCIONAR_DESCUENTO IS NULL THEN 1 ',
'                               WHEN :P400_SELECCIONAR_DESCUENTO= 1 THEN 0 ELSE 1 END;'))
,p_attribute_02=>'P400_SELECCIONAR_DESCUENTO'
,p_attribute_03=>'P400_SELECCIONAR_DESCUENTO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94997342440751645)
,p_event_id=>wwv_flow_imp.id(94997193560751643)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(94993515469751607)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(101573328423053010)
,p_name=>'Aprobar negociacion'
,p_event_sequence=>120
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(101573181033053008)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(101573498743053011)
,p_event_id=>wwv_flow_imp.id(101573328423053010)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$s(''P400_COMENTARIO'',this.data.G_COMENTARIO);',
'$s(''P400_COMENTARIOUSUARIO'',this.data.G_USUARIOS_LISTA);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(101573511088053012)
,p_event_id=>wwv_flow_imp.id(101573328423053010)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'NEGOCIACION_APROBAR'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(94997433701751646)
,p_name=>'Aprobar descuento'
,p_event_sequence=>130
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(94996713419751639)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94997587047751647)
,p_event_id=>wwv_flow_imp.id(94997433701751646)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s(''P400_COMENTARIO'',this.data.G_COMENTARIO);'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94997611728751648)
,p_event_id=>wwv_flow_imp.id(94997433701751646)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'APROBAR_DESCUENTO'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(517180463053653948)
,p_name=>'Aprobar cancelacion descuento'
,p_event_sequence=>140
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(517180259965653946)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(517180521364653949)
,p_event_id=>wwv_flow_imp.id(517180463053653948)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s(''P400_COMENTARIO'',this.data.G_COMENTARIO);'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(517180612828653950)
,p_event_id=>wwv_flow_imp.id(517180463053653948)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'APROBAR_CANCELACION_DESCUENTO'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(98852090225492940)
,p_name=>'Dashboards Page load'
,p_event_sequence=>150
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(98852468317492941)
,p_event_id=>wwv_flow_imp.id(98852090225492940)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(101573616677053013)
,p_name=>'Rechazar negociacion'
,p_event_sequence=>160
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(101573262238053009)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(101573719549053014)
,p_event_id=>wwv_flow_imp.id(101573616677053013)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$s(''P400_COMENTARIO'',this.data.G_COMENTARIO);',
'$s(''P400_COMENTARIOUSUARIO'',this.data.G_USUARIOS_LISTA);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(101573873137053015)
,p_event_id=>wwv_flow_imp.id(101573616677053013)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'NEGOCIACION_RECHAZAR'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(94997709283751649)
,p_name=>'Rechazar descuento'
,p_event_sequence=>170
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(94996803290751640)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94997887320751650)
,p_event_id=>wwv_flow_imp.id(94997709283751649)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s(''P400_COMENTARIO'',this.data.G_COMENTARIO);'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(96681924467465701)
,p_event_id=>wwv_flow_imp.id(94997709283751649)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'RECHAZAR_DESCUENTO'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(518899936115611801)
,p_name=>'Rechazar cancelacion descuento'
,p_event_sequence=>180
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(517180392564653947)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(518900036004611802)
,p_event_id=>wwv_flow_imp.id(518899936115611801)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s(''P400_COMENTARIO'',this.data.G_COMENTARIO);'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(518900110862611803)
,p_event_id=>wwv_flow_imp.id(518899936115611801)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'RECHAZAR_CANCELACION_DESCUENTO'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(137558758665718119)
,p_name=>'ActualizarDatos'
,p_event_sequence=>190
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(137558558842715374)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(137559157475718137)
,p_event_id=>wwv_flow_imp.id(137558758665718119)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(137559603703718137)
,p_event_id=>wwv_flow_imp.id(137558758665718119)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_ICOM_CRUD.SP_INVERSIONMASIVAGRUPAL(',
'    P_COMPANIA => :g_compania,',
'    P_USUARIO => :APP_USER',
'  );',
''))
,p_attribute_02=>'P261_IDAGRUPACION,P261_INVERSION_TIPO,P261_VALIDACION_TIPO'
,p_attribute_03=>'P262_INICIO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(137560168435718137)
,p_event_id=>wwv_flow_imp.id(137558758665718119)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(66767993232004748)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(137560619008718137)
,p_event_id=>wwv_flow_imp.id(137558758665718119)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(98852890122497892)
,p_name=>'Dashboards Anio todos'
,p_event_sequence=>200
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_ANIO_TODOS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(98853287547497893)
,p_event_id=>wwv_flow_imp.id(98852890122497892)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF(:P400_ANIO_TODOS=''Y'') THEN ',
'',
'    SELECT LISTAGG(NUMERO, '':'') WITHIN GROUP (ORDER BY NUMERO) AS NUMERO INTO :P400_ANIO',
'        FROM (SELECT  TO_CHAR(SYSDATE, ''YYYY'') - LEVEL + 1 NUMERO',
'                FROM dual CONNECT BY LEVEL <= 3);',
'ELSE',
'    :P400_ANIO := NULL;',
'',
'END IF;'))
,p_attribute_02=>'P400_ANIO_TODOS'
,p_attribute_03=>'P400_ANIO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(98853828182502746)
,p_name=>'Dashboards Meses todos'
,p_event_sequence=>210
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_MESES_TODOS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(98854255132502746)
,p_event_id=>wwv_flow_imp.id(98853828182502746)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF(:P400_MESES_TODOS=''Y'') THEN ',
'',
'    SELECT LISTAGG(NUMERO, '':'') WITHIN GROUP (ORDER BY NUMERO) AS NUMERO INTO :P400_MES',
'        FROM (SELECT to_char(to_date(level, ''MM''), ''MM'') numero  ',
'                FROM dual CONNECT BY level <= 12);',
'ELSE',
'    :P400_MES := NULL;',
'',
'END IF;'))
,p_attribute_02=>'P400_MESES_TODOS'
,p_attribute_03=>'P400_MES'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(98855730862506120)
,p_name=>'Dashboards Area todos'
,p_event_sequence=>220
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_AREA_TODOS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(98856187881506120)
,p_event_id=>wwv_flow_imp.id(98855730862506120)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF(:P400_AREA_TODOS=''Y'') THEN ',
'',
'    SELECT LISTAGG(NUMERO, '':'') WITHIN GROUP (ORDER BY NUMERO) AS NUMERO INTO :P400_AREA',
'        FROM (SELECT IDAREA numero FROM VT_ICOM_AREA WHERE COMPANIA =:G_COMPANIA);',
'ELSE',
'    :P400_AREA := NULL;',
'',
'END IF;'))
,p_attribute_02=>'P400_AREA_TODOS'
,p_attribute_03=>'P400_AREA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(98856577671512901)
,p_name=>'Dashboards Seleccion inversion'
,p_event_sequence=>230
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_INVERSIONES,P400_AREA'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(98857932545512903)
,p_event_id=>wwv_flow_imp.id(98856577671512901)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'v_contador NUMBER;',
'v_ID NUMBER;',
'begin ',
'',
'IF(TRIM(:P400_INVERSIONES) IS NULL) THEN ',
'    :P400_FECHA_INCIO_INV:=NULL;',
'    :P400_FECHA_FIN_INV:=NULL;',
'    :P400_FECHA_INCIO_NEG:=NULL;',
'    :P400_FECHA_FIN_NEG:=NULL;',
'    :P400_DURACION_INV:=NULL;',
'    :P400_DURACION_NEG:=NULL;',
'    :P400_INCIA :=null;',
'    RETURN;',
'END IF;',
'',
'select count( 1) INTO v_contador from (',
'SELECT regexp_substr(:P400_INVERSIONES,''[^:]+'', 1, level) FROM DUAL connect by regexp_substr(:P400_INVERSIONES, ''[^:]+'', 1, level) is not null);',
'',
'IF(v_contador=1) THEN ',
'    select FECHAINICIO, FECHAFIN,  FECHAFIN-FECHAINICIO,  ID, round(FECHAINICIO-sysdate) INTO ',
'    :P400_FECHA_INCIO_INV, :P400_FECHA_FIN_INV, :P400_DURACION_INV, V_ID,  :P400_INCIA',
'    from t_icom_inversiones WHERE ID IN (',
'    SELECT regexp_substr(:P400_INVERSIONES,''[^:]+'', 1, level) FROM DUAL connect by regexp_substr(:P400_INVERSIONES, ''[^:]+'', 1, level) is not null);',
'',
'    select MIN(FECHAINICIO), MAX(FECHAFIN),  MAX(FECHAFIN)-MIN(FECHAINICIO) INTO ',
'        :P400_FECHA_INCIO_NEG, :P400_FECHA_FIN_NEG, :P400_DURACION_NEG',
'    from t_icom_inversion_cliente_g WHERE IDINVERSION=v_ID;',
'',
'ELSE',
'    :P400_FECHA_INCIO_INV:=NULL;',
'    :P400_FECHA_FIN_INV:=NULL;',
'    :P400_FECHA_INCIO_NEG:=NULL;',
'    :P400_FECHA_FIN_NEG:=NULL;',
'    :P400_DURACION_INV:=NULL;',
'    :P400_DURACION_NEG:=NULL;',
'    :P400_INCIA :=null;',
'END IF;',
'',
'',
'',
'end;'))
,p_attribute_02=>'P400_INVERSIONES'
,p_attribute_03=>'P400_FECHA_INCIO_INV,P400_FECHA_FIN_INV,P400_FECHA_INCIO_NEG,P400_FECHA_FIN_NEG,P400_DURACION_NEG,P400_DURACION_INV,P400_INCIA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(98858470147512903)
,p_event_id=>wwv_flow_imp.id(98856577671512901)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(196839784115513843)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(534739017944355639)
,p_event_id=>wwv_flow_imp.id(98856577671512901)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(197258942304840691)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(98856919851512902)
,p_event_id=>wwv_flow_imp.id(98856577671512901)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(196839301513513838)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(98857448492512902)
,p_event_id=>wwv_flow_imp.id(98856577671512901)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(196841762853513863)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(98858874110517554)
,p_name=>'Dashboards Ocultar filtro'
,p_event_sequence=>240
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(98831013060469055)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(534738341931355632)
,p_event_id=>wwv_flow_imp.id(98858874110517554)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(534738430450355633)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(98860120615519505)
,p_name=>'Dashboards Mostrar filtro'
,p_event_sequence=>250
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(98831411970469056)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(534738583668355634)
,p_event_id=>wwv_flow_imp.id(98860120615519505)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(534738430450355633)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(314313666156891931)
,p_name=>'ExisteSeleccion'
,p_event_sequence=>260
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(314313512980891930)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'(document.querySelectorAll(''.chkF01'').length == [].filter.call( document.querySelectorAll(''.chkF01''), function( el ) {return !el.checked}).length )'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(314313767032891932)
,p_event_id=>wwv_flow_imp.id(314313666156891931)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>unistr('mensaje(''error'',''Debe seleccionar al menos una inversi\00F3n, valide y vuelva a intentar.''); ')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(314314851997891943)
,p_event_id=>wwv_flow_imp.id(314313666156891931)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#AprobarMasivo'').trigger("click");'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(314313821466891933)
,p_event_id=>wwv_flow_imp.id(314313666156891931)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(314314291881891937)
,p_name=>'ExisteSeleccionRechaza'
,p_event_sequence=>270
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(314314122823891936)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'(document.querySelectorAll(''.chkF01'').length == [].filter.call( document.querySelectorAll(''.chkF01''), function( el ) {return !el.checked}).length )'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(314314368526891938)
,p_event_id=>wwv_flow_imp.id(314314291881891937)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>unistr('mensaje(''error'',''Debe seleccionar al menos una inversi\00F3n, valide y vuelva a intentar.''); ')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(314314406022891939)
,p_event_id=>wwv_flow_imp.id(314314291881891937)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#RechazarMasivo'').trigger("click");'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(314314514881891940)
,p_event_id=>wwv_flow_imp.id(314314291881891937)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(314315358259891948)
,p_name=>'CloseComentarioAprobar'
,p_event_sequence=>280
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(314315077676891945)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(314315405765891949)
,p_event_id=>wwv_flow_imp.id(314315358259891948)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$s(''P400_COMENTARIO'',this.data.G_COMENTARIO);',
'$s(''P400_COMENTARIOUSUARIO'',this.data.G_USUARIOS_LISTA);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(314315571355891950)
,p_event_id=>wwv_flow_imp.id(314315358259891948)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'APROBARMASIVO'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(320099285398569701)
,p_name=>'CloseComentarioRechazar'
,p_event_sequence=>290
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(314315154905891946)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(320099317298569702)
,p_event_id=>wwv_flow_imp.id(320099285398569701)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$s(''P400_COMENTARIO'',this.data.G_COMENTARIO);',
'$s(''P400_COMENTARIOUSUARIO'',this.data.G_USUARIOS_LISTA);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(320099428323569703)
,p_event_id=>wwv_flow_imp.id(320099285398569701)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'RECHAZARMASIVO'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(320099574283569704)
,p_name=>'SeleccionTodosInversion'
,p_event_sequence=>300
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectallocs'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#tblInversion'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(320099621234569705)
,p_event_id=>wwv_flow_imp.id(320099574283569704)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#tblInversion #selectallocs'' ).is('':checked'')) {',
'    $(''#tblInversion input[type=checkbox][name=f01]'').prop(''checked'',true);',
'} else {',
'    $(''#tblInversion input[type=checkbox][name=f01]'').prop(''checked'',false);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(391804447318295206)
,p_name=>'VerNotificaciones'
,p_event_sequence=>310
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P400_NOTIFICACIONES'
,p_display_when_cond2=>'1'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(391804593404295207)
,p_event_id=>wwv_flow_imp.id(391804447318295206)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#btVerNotificaciones'').trigger("click");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(238713924902364436)
,p_name=>'Buscar'
,p_event_sequence=>320
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(91761527590409850)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(238714092394364437)
,p_event_id=>wwv_flow_imp.id(238713924902364436)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'actulizarTablas();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(238714236161364439)
,p_name=>'Onchange mis pendientes'
,p_event_sequence=>330
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_ESTADO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(238714329769364440)
,p_event_id=>wwv_flow_imp.id(238714236161364439)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log("Cambio mis pendientes: "+$v("P400_ESTADO"));',
'actulizarTablas();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(534226403480713643)
,p_name=>'Dashboards Prop  Anio todos'
,p_event_sequence=>340
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_PROP_ANIO_TODOS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(534226593065713644)
,p_event_id=>wwv_flow_imp.id(534226403480713643)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF(:P400_PROP_ANIO_TODOS=''Y'') THEN ',
'',
'    SELECT LISTAGG(NUMERO, '':'') WITHIN GROUP (ORDER BY NUMERO) AS NUMERO INTO :P400_PROP_ANIO',
'        FROM (SELECT  TO_CHAR(SYSDATE, ''YYYY'') - LEVEL + 1 NUMERO',
'                FROM dual CONNECT BY LEVEL <= 3);',
'ELSE',
'    :P400_PROP_ANIO := NULL;',
'',
'END IF;'))
,p_attribute_02=>'P400_PROP_ANIO_TODOS'
,p_attribute_03=>'P400_PROP_ANIO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(534738692790355635)
,p_name=>'Cargar Pagina'
,p_event_sequence=>350
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(534738746687355636)
,p_event_id=>wwv_flow_imp.id(534738692790355635)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#btnOcultarFiltro'').trigger("click");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(534227001069713649)
,p_name=>'Dashboards Prop Meses todos'
,p_event_sequence=>360
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_PROP_MESES_TODOS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(534227199726713650)
,p_event_id=>wwv_flow_imp.id(534227001069713649)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF(:P400_PROP_MESES_TODOS=''Y'') THEN ',
'',
'    SELECT LISTAGG(NUMERO, '':'') WITHIN GROUP (ORDER BY NUMERO) AS NUMERO INTO :P400_PROP_MES',
'        FROM (SELECT to_char(to_date(level, ''MM''), ''MM'') numero  ',
'                FROM dual CONNECT BY level <= 12);',
'ELSE',
'    :P400_PROP_MES := NULL;',
'',
'END IF;'))
,p_attribute_02=>'P400_PROP_MESES_TODOS'
,p_attribute_03=>'P400_PROP_MES'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(534736524453355614)
,p_name=>'Dashboards Prop Area todos'
,p_event_sequence=>370
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_PROP_AREA_TODOS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(534736632564355615)
,p_event_id=>wwv_flow_imp.id(534736524453355614)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF(:P400_PROP_AREA_TODOS=''Y'') THEN ',
'',
'    SELECT LISTAGG(NUMERO, '':'') WITHIN GROUP (ORDER BY NUMERO) AS NUMERO INTO :P400_PROP_AREA',
'        FROM (SELECT IDAREA numero FROM VT_ICOM_AREA WHERE COMPANIA =:G_COMPANIA);',
'ELSE',
'    :P400_PROP_AREA := NULL;',
'',
'END IF;'))
,p_attribute_02=>'P400_PROP_AREA_TODOS'
,p_attribute_03=>'P400_PROP_AREA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(534737742588355626)
,p_name=>'Dashboards Prop Seleccion Area'
,p_event_sequence=>380
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_PROP_AREA,P400_PROP_INVERSIONES'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(534737806849355627)
,p_event_id=>wwv_flow_imp.id(534737742588355626)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'v_contador NUMBER;',
'v_ID NUMBER;',
'begin ',
'',
'IF(TRIM(:P400_PROP_INVERSIONES) IS NULL) THEN ',
'    :P400_PROP_FECHA_INCIO_INV:=NULL;',
'    :P400_PROP_FECHA_FIN_INV:=NULL;',
'    :P400_PROP_FECHA_INCIO_NEG:=NULL;',
'    :P400_PROP_FECHA_FIN_NEG:=NULL;',
'    :P400_PROP_DURACION_INV:=NULL;',
'    :P400_PROP_DURACION_NEG:=NULL;',
'    RETURN;',
'END IF;',
'',
'select count(1) INTO v_contador from (',
'SELECT regexp_substr(:P400_PROP_INVERSIONES,''[^:]+'', 1, level) FROM DUAL connect by regexp_substr(:P400_PROP_INVERSIONES, ''[^:]+'', 1, level) is not null);',
'',
'IF(v_contador=1) THEN ',
'    select FECHAINICIO, FECHAFIN,  FECHAFIN-FECHAINICIO,  ID INTO ',
'    :P400_PROP_FECHA_INCIO_INV, :P400_PROP_FECHA_FIN_INV, :P400_PROP_DURACION_INV, V_ID',
'    from t_icom_inversiones WHERE ID IN (',
'    SELECT regexp_substr(:P400_PROP_INVERSIONES,''[^:]+'', 1, level) FROM DUAL connect by regexp_substr(:P400_PROP_INVERSIONES, ''[^:]+'', 1, level) is not null);',
'',
'    select MIN(FECHAINICIO), MAX(FECHAFIN),  MAX(FECHAFIN)-MIN(FECHAINICIO) INTO ',
'        :P400_PROP_FECHA_INCIO_NEG, :P400_PROP_FECHA_FIN_NEG, :P400_PROP_DURACION_NEG',
'    from t_icom_inversion_cliente_g WHERE IDINVERSION=v_ID;',
'',
'ELSE',
'    :P400_PROP_FECHA_INCIO_INV:=NULL;',
'    :P400_PROP_FECHA_FIN_INV:=NULL;',
'    :P400_PROP_FECHA_INCIO_NEG:=NULL;',
'    :P400_PROP_FECHA_FIN_NEG:=NULL;',
'    :P400_PROP_DURACION_INV:=NULL;',
'    :P400_PROP_DURACION_NEG:=NULL;',
'',
'END IF;',
'',
'',
'',
'end;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(534738253656355631)
,p_event_id=>wwv_flow_imp.id(534737742588355626)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(197258942304840691)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(668860983248045738)
,p_name=>'Abrir power BI'
,p_event_sequence=>390
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(668860856496045737)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(668861024187045739)
,p_event_id=>wwv_flow_imp.id(668860983248045738)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'window.open(',
'  "https://app.powerbi.com/view?r=eyJrIjoiZjY4OGI4ZTItZjc4YS00MGI3LTllYzktODdiY2JjNjhmYjlmIiwidCI6IjY0NWQ5MjVlLTZkNWUtNGIxMy04OTc3LWQ2YzVhNjFlN2Q2MSIsImMiOjR9",',
'  "_blank"',
');',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(48860286852547349)
,p_name=>'ChageIdAgrupa'
,p_event_sequence=>400
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_IDAGRUPA'
,p_condition_element=>'P400_IDAGRUPA'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48860354533547350)
,p_event_id=>wwv_flow_imp.id(48860286852547349)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Est\00E1 seguro de borrar la agupaci\00F3n &P400_IDAGRUPA.')
,p_attribute_02=>'Adventencia'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(52761163816753501)
,p_event_id=>wwv_flow_imp.id(48860286852547349)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'BORRAR'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(88271959048031823)
,p_name=>'Click'
,p_event_sequence=>410
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(88271707697031821)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(88534981261319544)
,p_event_id=>wwv_flow_imp.id(88271959048031823)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let elementos = document.getElementsByName("f10");',
'let algunoMarcado = Array.from(elementos).some(el => el.checked);',
'',
'if (algunoMarcado) {',
'    document.getElementById("btnConvenio").click();',
'}',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(88535018477319545)
,p_name=>'Cerrar dialogo'
,p_event_sequence=>420
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(88534846804319543)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(88535149278319546)
,p_event_id=>wwv_flow_imp.id(88535018477319545)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(88214903596774818)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(95488399112199349)
,p_name=>'Aux Change'
,p_event_sequence=>440
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_ID_INVERSION'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(96160312184462027)
,p_event_id=>wwv_flow_imp.id(95488399112199349)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P400_NEGOCIACION'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(95488436846199350)
,p_event_id=>wwv_flow_imp.id(95488399112199349)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(96158064080462004)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102297331718789447)
,p_event_id=>wwv_flow_imp.id(95488399112199349)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'Refrescar Asignados'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(102296733370789441)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102297424195789448)
,p_event_id=>wwv_flow_imp.id(95488399112199349)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'Refrescar Disponibles'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(102296245454789436)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(104991017795056701)
,p_event_id=>wwv_flow_imp.id(95488399112199349)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.jQuery("#dialogoAsignarPagoRecurrente")',
'  .closest(".ui-dialog")',
'  .css({',
'    "width": "80%",',
'    "height": "600px",',
'    "max-width": "none"',
'  });',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(96159229368462016)
,p_name=>'Cerrar Modal Asignar Pago Recurrente'
,p_event_sequence=>450
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(96159065277462014)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(96159328588462017)
,p_event_id=>wwv_flow_imp.id(96159229368462016)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(96158064080462004)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(102294534859789419)
,p_name=>'New'
,p_event_sequence=>460
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P400_ID_INVERSION_C'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102294702120789421)
,p_event_id=>wwv_flow_imp.id(102294534859789419)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_OPEN_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(102293386240789407)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(102294888324789422)
,p_name=>'Cierra'
,p_event_sequence=>470
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(102293769235789411)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102294965057789423)
,p_event_id=>wwv_flow_imp.id(102294888324789422)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(102293386240789407)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(102295070580789424)
,p_name=>'GuardarCoordinador'
,p_event_sequence=>480
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(102293818200789412)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102295173036789425)
,p_event_id=>wwv_flow_imp.id(102295070580789424)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEst\00E1 seguro de seleccionar el coordinador?')
,p_attribute_02=>'Confirmar'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102295215094789426)
,p_event_id=>wwv_flow_imp.id(102295070580789424)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    UPDATE DATA.T_ICOM_INVERSIONES SET USUARIO = :P400_USUARIOS WHERE ID = :P400_ID_INVERSION_C;',
'    COMMIT;',
'END;'))
,p_attribute_02=>'P400_ID_INVERSION_C,P400_USUARIOS'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102295396503789427)
,p_event_id=>wwv_flow_imp.id(102295070580789424)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLOSE_REGION'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(102293386240789407)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102295415289789428)
,p_event_id=>wwv_flow_imp.id(102295070580789424)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(66767993232004748)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(104991437249056705)
,p_name=>'Proceso_Guardar'
,p_event_sequence=>490
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(104991372917056704)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(104991520468056706)
,p_event_id=>wwv_flow_imp.id(104991437249056705)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Confirmar'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Est\00E1 seguro de asignar?')
,p_attribute_02=>'Confirmar'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(104992750311056718)
,p_event_id=>wwv_flow_imp.id(104991437249056705)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Refrescar Negociaciones Seleccionadas'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(102296733370789441)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(104992864273056719)
,p_event_id=>wwv_flow_imp.id(104991437249056705)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'Refrescar Negociaciones Disponibles'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(102296245454789436)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(101573994841053016)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Negociacion aprobar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_id 				varchar2(2500);',
'v_idinversion		varchar2(2500);',
'v_codigogrupo		varchar(250);',
'begin',
'    for i in 1..apex_application.g_f03.count loop  --Recorre las filas seleccionadas',
'        v_id := apex_application.g_f03(i);',
'        select item into v_idinversion  from table(pk_commons.f_dividirtexto(v_id,''-'')) where id = 1;',
'        select item into v_codigogrupo	from table(pk_commons.f_dividirtexto(v_id,''-'')) where id = 2;',
'     ',
'            DATA.PK_ICOM_NEGOCIACION.SP_APROBACION (P_ID =>v_idinversion,',
'                                                     P_GRUPO =>v_codigogrupo, ',
'                                                    P_ESTADO =>1,',
'                                                    P_COMENTARIO => :P400_COMENTARIO,',
'                                                    P_USUARIO =>:APP_USER, ',
'                                                    P_COMPANIA =>:G_COMPANIA,',
'                                                    P_COMENTARIO_DIRIGIDO => :P400_COMENTARIOUSUARIO );',
'                                                    COMMIT;',
'    end loop;',
'end;                                                     '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(101573181033053008)
,p_process_success_message=>unistr('Se aprobaron todos los clientes con \00E9xito')
,p_internal_uid=>101573994841053016
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(101574039728053017)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Negociacion rechazar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_id 				varchar2(2500);',
'v_idinversion		varchar2(2500);',
'v_codigogrupo		varchar(250);',
'begin',
'    for i in 1..apex_application.g_f03.count loop  --Recorre las filas seleccionadas',
'        v_id := apex_application.g_f03(i);',
'        select item into v_idinversion  from table(pk_commons.f_dividirtexto(v_id,''-'')) where id = 1;',
'        select item into v_codigogrupo	from table(pk_commons.f_dividirtexto(v_id,''-'')) where id = 2;',
'     ',
'            DATA.PK_ICOM_NEGOCIACION.SP_APROBACION (P_ID =>v_idinversion,',
'                                                     P_GRUPO =>v_codigogrupo, ',
'                                                    P_ESTADO =>0,',
'                                                    P_COMENTARIO => :P400_COMENTARIO,',
'                                                    P_USUARIO =>:APP_USER, ',
'                                                    P_COMPANIA =>:G_COMPANIA,',
'                                                    P_COMENTARIO_DIRIGIDO => :P400_COMENTARIOUSUARIO);',
'    end loop;',
'end;                                                     '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(101573262238053009)
,p_process_success_message=>unistr('Se rechazaron todos los clientes con \00E9xito')
,p_internal_uid=>101574039728053017
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(96682031702465702)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Descuento aprobar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_id 				varchar2(2500);',
'v_grupo		varchar2(2500);',
'v_codigogrupo		varchar(250);',
'begin',
'    for i in 1..apex_application.g_f04.count loop  --Recorre las filas seleccionadas',
'        v_id := apex_application.g_f04(i);',
'        select item into v_codigogrupo  from table(pk_commons.f_dividirtexto(v_id,''-'')) where id = 1;',
'        select item into v_grupo	from table(pk_commons.f_dividirtexto(v_id,''-'')) where id = 2;',
'     ',
'            DATA.PK_ICOM_PROCESOS.SP_DESCUENTO_APROBAR(',
'                P_ESTADO =>1, ',
'                P_GRUPO =>v_grupo, ',
'                P_CODIGOGRUPO =>v_codigogrupo, ',
'                P_USUARIO =>:APP_USER,  ',
'                P_COMENTARIO =>:P400_COMENTARIO, ',
'                P_COMPANIA =>:G_COMPANIA);',
'           COMMIT;',
'    end loop;',
'end;               '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(94996713419751639)
,p_process_success_message=>unistr('Se aprobaron todos los descuentos con \00E9xito')
,p_internal_uid=>96682031702465702
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(96682195876465703)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Descuento rechazar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_id 				varchar2(2500);',
'v_grupo		varchar2(2500);',
'v_codigogrupo		varchar(250);',
'begin',
'    for i in 1..apex_application.g_f04.count loop  --Recorre las filas seleccionadas',
'        v_id := apex_application.g_f04(i);',
'        select item into v_codigogrupo  from table(pk_commons.f_dividirtexto(v_id,''-'')) where id = 1;',
'        select item into v_grupo	from table(pk_commons.f_dividirtexto(v_id,''-'')) where id = 2;',
'     ',
'            DATA.PK_ICOM_PROCESOS.SP_DESCUENTO_APROBAR(',
'                P_ESTADO =>0, ',
'                P_GRUPO =>v_grupo, ',
'                P_CODIGOGRUPO =>v_codigogrupo, ',
'                P_USUARIO =>:APP_USER,  ',
'                P_COMENTARIO =>:P400_COMENTARIO, ',
'                P_COMPANIA =>:G_COMPANIA);',
'           COMMIT;',
'    end loop;',
'end;  '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(94996803290751640)
,p_process_success_message=>unistr('Se rechazaron todos los descuentos con \00E9xito')
,p_internal_uid=>96682195876465703
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(518900248823611804)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Descuento cancelacion aprobar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_id 				varchar2(2500);',
'v_idinversion 				varchar2(2500);',
'v_grupo		varchar2(2500);',
'v_codigogrupo		varchar(250);',
'v_cont number:=0;',
'begin',
'    for i in 1..apex_application.g_f05.count loop  --Recorre las filas seleccionadas',
'        v_id := apex_application.g_f05(i);',
'        --84721-2-21362',
'        SELECT ',
'            PK_FINZ_SRI_GESTION.F_TRIMETIQUETA(CAMPO1)CAMPO1,',
'            PK_FINZ_SRI_GESTION.F_TRIMETIQUETA(CAMPO2)CAMPO2,',
'            PK_FINZ_SRI_GESTION.F_TRIMETIQUETA(CAMPO3)CAMPO3',
'        into v_CODIGOGRUPO,v_grupo,v_IDINVERSION',
'        FROM table(pk_commons.f_split2table(p_cadena =>v_id,p_delimitadorcolumna =>''-'',p_delimitadorfila =>'';''));',
'',
'        DATA.PK_ICOM_PROCESOS.SP_DESCUENTO_CANCELAR_APROBAR(',
'            p_idinversion =>v_idinversion,',
'            P_ESTADO =>1,',
'            P_GRUPO =>v_grupo,',
'            P_CODIGOGRUPO =>v_codigogrupo,',
'            P_USUARIO =>:APP_USER,',
'            P_COMENTARIO =>to_char(:P400_COMENTARIO),',
'            P_COMPANIA =>:G_COMPANIA',
'        );',
'        v_cont :=v_cont +1;',
'    end loop;',
'    :P400_CONTADOR:=v_cont ;',
'end;               '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'APROBAR_CANCELACION_DESCUENTO'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_process_success_message=>unistr('Se aprobaron todos los descuentos con \00E9xito')
,p_internal_uid=>518900248823611804
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(518900333896611805)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Descuento cancelacion rechazar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_id 				varchar2(2500);',
'v_idinversion 				varchar2(2500);',
'v_grupo		varchar2(2500);',
'v_codigogrupo		varchar(250);',
'v_cont number:=0;',
'begin',
'    for i in 1..apex_application.g_f05.count loop  --Recorre las filas seleccionadas',
'        v_id := apex_application.g_f05(i);',
'        --84721-2-21362',
'        SELECT ',
'            PK_FINZ_SRI_GESTION.F_TRIMETIQUETA(CAMPO1)CAMPO1,',
'            PK_FINZ_SRI_GESTION.F_TRIMETIQUETA(CAMPO2)CAMPO2,',
'            PK_FINZ_SRI_GESTION.F_TRIMETIQUETA(CAMPO3)CAMPO3',
'        into v_CODIGOGRUPO,v_grupo,v_IDINVERSION',
'        FROM table(pk_commons.f_split2table(p_cadena =>v_id,p_delimitadorcolumna =>''-'',p_delimitadorfila =>'';''));',
'',
'        DATA.PK_ICOM_PROCESOS.SP_DESCUENTO_CANCELAR_APROBAR(',
'            p_idinversion =>v_idinversion,',
'            P_ESTADO =>0,',
'            P_GRUPO =>v_grupo,',
'            P_CODIGOGRUPO =>v_codigogrupo,',
'            P_USUARIO =>:APP_USER,',
'            P_COMENTARIO =>to_char(:P400_COMENTARIO),',
'            P_COMPANIA =>:G_COMPANIA',
'        );',
'        v_cont :=v_cont +1;',
'    end loop;',
'    :P400_CONTADOR:=v_cont ;',
'end;  '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(94996803290751640)
,p_process_success_message=>unistr('Se rechazaron todos los descuentos con \00E9xito')
,p_internal_uid=>518900333896611805
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(314314033232891935)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'APROBARMASIVO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    v_id 	varchar2(2500);',
'    v_idinversion number ;',
'    v_idetapa number;',
'    v_aprobador varchar2(30);',
'    v_error number:= 0 ;',
'    v_idinversionError varchar2(3900):= '''' ;',
'    V_FInversion DATA.VT_ICOM_INVERSIONES%rowtype;',
'    v_proceso varchar2(250);',
'    v_estado number :=1;',
unistr('    v_mensaje varchar2(500) :=''Se aprob\00F3 con \00E9xito las inversiones.'';'),
'BEGIN',
'    APEX_DEBUG.ENABLE(apex_debug.c_log_level_info);',
'    apex_debug.message(''APROBACION MASIVO'');  ',
'    for i in 1..apex_application.g_f01.count loop  --Recorre las filas seleccionadas',
'		v_id := apex_application.g_f01(i);',
'		--Se recupera los datos d cada registro seleccionado',
'		--v_idinversion identificador de la inversion comercial',
'        select item into v_idinversion	from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 1;',
'		--v_idetapa identificador de la etapa',
'		select item into v_idetapa	from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 2;',
'		--v_aprobador	(IDENTIFICADOR DE APROBADOR)',
'		select item into v_aprobador	from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 3;',
'		begin',
'             v_proceso:=''v_idinversion:[''||v_idinversion||''];  v_idetapa:[''||v_idetapa||''];  v_aprobador:[''||v_aprobador||''];  '';',
'             DBMS_OUTPUT.PUT_LINE(v_proceso);',
'            begin ',
'                select *',
'                INTO V_FInversion',
'                from DATA.VT_ICOM_INVERSIONES',
'                where ESTADO =2  AND IDETAPA= 5',
'                AND IDPADRE=v_idinversion;',
'               ',
'            EXCEPTION WHEN OTHERS THEN ',
'                null;',
'            end ;        ',
'            DBMS_OUTPUT.PUT_LINE(''V_FInversion.ID:''||V_FInversion.ID);',
'           ',
'            if (V_FInversion.ID is null) then',
'                DBMS_OUTPUT.PUT_LINE(v_proceso);',
'                    data.PK_ICOM_CRUD.SP_APROBAR(',
'                        P_ID => v_idinversion,',
'                        P_ETAPA => v_idetapa, ',
'                        P_ESTADO => v_estado,',
'                        P_USUARIO => v_aprobador, ',
'                        P_COMPANIA => :G_COMPANIA,',
'                        P_COMENTARIO => :P400_COMENTARIO,',
'                        P_COMENTARIO_DIRIGIDO => :P400_COMENTARIOUSUARIO',
'                    );',
'            else ',
'               ',
'                data.PK_ICOM_CRUD.SP_APROBAR(',
'                    P_ID => V_FInversion.ID,',
'                    P_ETAPA => V_FInversion.IDETAPA, ',
'                    P_ESTADO => v_estado,',
'                    P_USUARIO => v_aprobador, ',
'                    P_COMPANIA => :G_COMPANIA,',
'                    P_COMENTARIO => :P400_COMENTARIO,',
'                    P_COMENTARIO_DIRIGIDO => :P400_COMENTARIOUSUARIO,',
'                    P_IDPADRE => V_FInversion.IDPADRE',
'                );',
'            end if;            ',
'           commit;',
'             DBMS_OUTPUT.PUT_LINE(''termina1:''||SQLERRM);',
'        exception when others then',
'             DBMS_OUTPUT.PUT_LINE(''termina2:''||SQLERRM);',
'            v_error := v_error +1 ;',
'            v_idinversionError := v_idinversionError||''<li>''||v_idinversion||'',  ERROR: ''||SQLERRM||''</li>'';',
'            ROLLBACK;',
'        end ;    ',
'',
'    end loop;',
'    DBMS_OUTPUT.PUT_LINE(''v_error:''||v_error);',
'    if v_error > 0 then',
'        apex_error.add_error(p_message => ''Las inversiones con errores son: <ul>''||v_idinversionError||''</ul>'', p_display_location => apex_error.c_inline_in_notification ) ;',
'    else',
'        apex_application.g_print_success_message :=v_mensaje;',
'    end if;                     ',
'END ;                         '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(314315077676891945)
,p_internal_uid=>314314033232891935
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(314315257615891947)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RECHAZARMASIVO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'    v_id 	varchar2(2500);',
'    v_idinversion number ;',
'    v_idetapa number;',
'    v_aprobador varchar2(30);',
'    v_error number:= 0 ;',
'    v_idinversionError varchar2(3900):= '''' ;',
'    V_FInversion DATA.VT_ICOM_INVERSIONES%rowtype;',
'    v_proceso varchar2(250);',
'    v_estado number :=0;',
unistr('    v_mensaje varchar2(500) :=''Se rechaz\00F3 con \00E9xito las inversiones.'';'),
'BEGIN',
'    for i in 1..apex_application.g_f01.count loop  --Recorre las filas seleccionadas',
'		v_id := apex_application.g_f01(i);',
'		--Se recupera los datos d cada registro seleccionado',
'		--v_idinversion identificador de la inversion comercial',
'        select item into v_idinversion	from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 1;',
'		--v_idetapa identificador de la etapa',
'		select item into v_idetapa	from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 2;',
'		--v_aprobador	(IDENTIFICADOR DE APROBADOR)',
'		select item into v_aprobador	from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 3;',
'		begin',
'             v_proceso:=''v_idinversion:[''||v_idinversion||''];  v_idetapa:[''||v_idetapa||''];  v_aprobador:[''||v_aprobador||''];  '';',
'             DBMS_OUTPUT.PUT_LINE(v_proceso);',
'           begin ',
'                select *',
'                INTO V_FInversion',
'                from DATA.VT_ICOM_INVERSIONES',
'                where ESTADO =2  AND IDETAPA= 5',
'                AND IDPADRE=v_idinversion;',
'               ',
'            EXCEPTION WHEN OTHERS THEN ',
'                null;',
'            end ;     ',
'            DBMS_OUTPUT.PUT_LINE(''V_FInversion.ID:''||V_FInversion.ID);',
'            ',
'             if (V_FInversion.ID is null) then',
'                DBMS_OUTPUT.PUT_LINE(v_proceso);',
'                    data.PK_ICOM_CRUD.SP_APROBAR(',
'                        P_ID => v_idinversion,',
'                        P_ETAPA => v_idetapa, ',
'                        P_ESTADO => v_estado,',
'                        P_USUARIO => v_aprobador, ',
'                        P_COMPANIA => :G_COMPANIA,',
'                        P_COMENTARIO => :P400_COMENTARIO,',
'                        P_COMENTARIO_DIRIGIDO => :P400_COMENTARIOUSUARIO',
'                    );',
'            else ',
'               ',
'                data.PK_ICOM_CRUD.SP_APROBAR(',
'                    P_ID => V_FInversion.ID,',
'                    P_ETAPA => V_FInversion.IDETAPA, ',
'                    P_ESTADO => v_estado,',
'                    P_USUARIO => v_aprobador, ',
'                    P_COMPANIA => :G_COMPANIA,',
'                    P_COMENTARIO => :P400_COMENTARIO,',
'                    P_COMENTARIO_DIRIGIDO => :P400_COMENTARIOUSUARIO,',
'                    P_IDPADRE => V_FInversion.IDPADRE',
'                );',
'            end if;            ',
'           commit;',
'             DBMS_OUTPUT.PUT_LINE(''termina1:''||SQLERRM);',
'        exception when others then',
'             DBMS_OUTPUT.PUT_LINE(''termina2:''||SQLERRM);',
'            v_error := v_error +1 ;',
'            v_idinversionError := v_idinversionError||''<li>''||v_idinversion||'',  ERROR: ''||SQLERRM||''</li>'';',
'            ROLLBACK;',
'        end ;   ',
' ',
'    end loop;',
'    DBMS_OUTPUT.PUT_LINE(''v_error:''||v_error);',
'    if v_error > 0 then',
'        apex_error.add_error(p_message => ''Las inversiones con errores son: <ul>''||v_idinversionError||''</ul>'', p_display_location => apex_error.c_inline_in_notification ) ;',
'    else',
'        apex_application.g_print_success_message := v_mensaje;',
'    end if;                     ',
'END ;                         '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(314315154905891946)
,p_internal_uid=>314315257615891947
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(52761202120753502)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'BORRAR VALIDACION'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    DATA.PK_ICOM_VALIDACION.SP_ELIMINAVALIDACION(',
'        P_IDVALIDACIONTIPO => null,',
'        P_IDAGRUPACION => :P400_IDAGRUPA',
'      );',
'END;  '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'BORRAR'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>52761202120753502
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(104992363154056714)
,p_process_sequence=>120
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GUARDAR PAGOS INVERSION'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_id   VARCHAR2(200);',
'BEGIN',
'    SELECT NVL(PAGO_RECURRENTE, '''') ',
'      INTO l_id ',
'      FROM DATA.T_ICOM_INVERSIONES ',
'     WHERE ID = :P400_ID_INVERSION;',
'',
'    -- recorre todos los checkboxes de la columna F20',
'    FOR i IN 1 .. NVL(APEX_APPLICATION.G_F20.COUNT, 0) LOOP',
'        IF APEX_APPLICATION.G_F20(i) IS NOT NULL THEN',
'            IF l_id IS NULL OR l_id = '''' THEN',
'                l_id := APEX_APPLICATION.G_F20(i);',
'            ELSE',
'                l_id := l_id || '','' || APEX_APPLICATION.G_F20(i);',
'            END IF;',
'        END IF;',
'    END LOOP;',
'    ',
'    UPDATE DATA.T_ICOM_INVERSIONES',
'    SET PAGO_RECURRENTE = l_id',
'    WHERE ID = :P400_ID_INVERSION;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(104991372917056704)
,p_internal_uid=>104992363154056714
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(101574542055053022)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P400_EJECUTIVO :=PK_ICOM_COMMONS.F_ESEJECUTIVO(P_USUARIO=>:APP_USER, P_COMPANIA=>:G_COMPANIA);',
':P400_NEGOCIADOR :=PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES (P_CODIGOMODULO => :APP_MODULO , P_CODIGOUSUARIO => :APP_USER ',
'                                                                                    , P_RUTAPAGINA => 300 , P_CODIGOACCION => ''NEGOCIADOR'');',
':P400_TODAS_COMPANIA := PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES (',
'      P_CODIGOMODULO => :APP_MODULO ',
'    , P_CODIGOUSUARIO => :APP_USER',
'    , P_RUTAPAGINA => 400',
'    , P_CODIGOACCION => ''TODAS_COMPANIA''); ',
'',
':P400_MASIVO := PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES (',
'      P_CODIGOMODULO => :APP_MODULO ',
'    , P_CODIGOUSUARIO => :APP_USER',
'    , P_RUTAPAGINA => 400',
'    , P_CODIGOACCION => ''GESTION_LOTE''); ',
'',
':P400_MODULO:=:APP_MODULO;',
':P400_COMPANIA:=:G_COMPANIA;',
'',
' select MAX(NUMEROIDENTIFICACION) INTO :P400_IDENTIFICACION',
'        from data.VT_CORP_USUARIO where NOMBREUSUARIO=:APP_USER;',
'',
'',
':P400_NOTIFICACIONES:=PK_ICOM_HERRAMIENTAS.F_COMUNICADO_USUARIO (P_CODMODULO =>:APP_MODULO,P_CODEMPRESA =>:G_COMPANIA,P_USUARIO =>:APP_USER);',
'',
':P400_NMESES_BUSQUEDA_SIN_ASGINAR := to_number(PK_ICOM_COMMONS.f_traervalorudc(''ICOM_PARAM'', ''36'', :g_compania,''Valor2''));'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>101574542055053022
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(88273772518031841)
,p_process_sequence=>110
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GUARDAR COLECCION PDV SELECCIONADOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    l_id   VARCHAR2(50);',
'    v_counter NUMBER := 0;',
'BEGIN',
unistr('    -- Crear colecci\00F3n si no existe'),
'    IF APEX_COLLECTION.COLLECTION_EXISTS(''CANDIDATOS_PDV'') THEN',
'        APEX_COLLECTION.DELETE_COLLECTION(''CANDIDATOS_PDV'');',
'    END IF;',
'',
'    APEX_COLLECTION.CREATE_COLLECTION(''CANDIDATOS_PDV'');',
'',
'    FOR i IN 1 .. NVL(APEX_APPLICATION.G_F10.COUNT, 0) LOOP',
'        -- Solo procesar si el checkbox fue marcado',
'        IF APEX_APPLICATION.G_F10(i) IS NOT NULL THEN',
'            APEX_COLLECTION.ADD_MEMBER(',
'                p_collection_name => ''CANDIDATOS_PDV'',',
'                p_c001            => APEX_APPLICATION.G_F10(i), -- CODIGOPDV',
'                p_c002            => APEX_APPLICATION.G_F11(i)  -- RUC',
'            );',
'            v_counter := v_counter + 1;',
'        END IF;',
'    END LOOP;',
'',
'    IF (v_counter = 0) THEN',
'        apex_error.add_error (',
'        p_message          => ''Debe seleccionar los PDVs!'',',
'        p_display_location => apex_error.c_inline_in_notification );',
'    END IF;',
'',
'    ',
'END;',
'',
'COMMIT;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(88271707697031821)
,p_internal_uid=>88273772518031841
);
end;
/
prompt --application/end_environment
begin
wwv_flow_imp.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false)
);
commit;
end;
/
set verify on feedback on define on
prompt  ...done

