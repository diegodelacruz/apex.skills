-- CASE-50999
-- Migracion de locales TRADE: ECONOFARM -> FARCOMED y GRUPO USCOCOVICH -> FARMAMIA.
-- Ambiente origen: TEST. Ejecutar solo desde el commit candidato aprobado.
-- Calcula los consecutivos desde el maximo vigente de cada destino.
-- La ejecucion se bloquea si los clientes origen ya fueron desvinculados/inactivados.

ALTER SESSION SET CURRENT_SCHEMA = DATA;

DECLARE
    c_origen_econofarm       CONSTANT NUMBER := 41203;
    c_destino_farcomed       CONSTANT NUMBER := 42672;
    c_origen_uscocovich      CONSTANT NUMBER := 145373;
    c_destino_farmamia       CONSTANT NUMBER := 128060;
    l_locales_econofarm      PLS_INTEGER;
    l_locales_uscocovich     PLS_INTEGER;
    l_maximo_farcomed        PLS_INTEGER;
    l_maximo_farmamia        PLS_INTEGER;
    l_total                  PLS_INTEGER;

    PROCEDURE validar_origen(
        p_codigopdv         IN NUMBER,
        p_grupo_esperado    IN VARCHAR2,
        p_cliente_esperado  IN VARCHAR2
    ) IS
        l_estado          NUMBER;
        l_codigogrupo     VARCHAR2(50);
        l_codigocliente   VARCHAR2(125);
    BEGIN
        SELECT estado, codigogrupo, codigocliente
          INTO l_estado, l_codigogrupo, l_codigocliente
          FROM t_trad_cliente
         WHERE codigopdv = p_codigopdv
           FOR UPDATE;

        IF l_estado <> 1
           OR NVL(l_codigogrupo, CHR(0)) <> p_grupo_esperado
           OR NVL(l_codigocliente, CHR(0)) <> p_cliente_esperado THEN
            RAISE_APPLICATION_ERROR(
                -20001,
                'Origen no disponible para migracion o ya migrado: CODIGOPDV=' || p_codigopdv
            );
        END IF;
    END validar_origen;
BEGIN
    SAVEPOINT case_50999_inicio;

    validar_origen(c_origen_econofarm, '10318', '15772');
    validar_origen(c_origen_uscocovich, '30780', '30780');

    SELECT COUNT(*), NVL(MAX(numero), 0)
      INTO l_locales_econofarm, l_maximo_farcomed
      FROM t_trad_clientelocal
     WHERE codigopdv = c_origen_econofarm;

    SELECT COUNT(*), NVL(MAX(numero), 0)
      INTO l_locales_uscocovich, l_maximo_farmamia
      FROM t_trad_clientelocal
     WHERE codigopdv = c_origen_uscocovich;

    SELECT NVL(MAX(numero), 0)
      INTO l_maximo_farcomed
      FROM t_trad_clientelocal
     WHERE codigopdv = c_destino_farcomed;

    SELECT NVL(MAX(numero), 0)
      INTO l_maximo_farmamia
      FROM t_trad_clientelocal
     WHERE codigopdv = c_destino_farmamia;

    INSERT INTO t_trad_clientelocal (
        codigopdv, numero, codigolocal, clasificacion, nombrecomercial,
        nombreconocido, zonificacion, idgeografico, direccion, latitud,
        longitud, contacto, telefono, email, casificacioninicio,
        casificacionfin, matriz, flujo, promocional, porcentajepromo,
        estado, auditoriafecha, auditoriausuario, formato, idruta,
        idrutacambio, estadoruta, bodega, perfil, estadoflujo, creaxruc,
        fechainicioclasificacion, fecharuta, numero_establecimiento,
        estado_establecimiento, tipovisita, auditoriafecha_modificacion,
        envio_ubicacion, envio_direccion, segmentacion
    )
    SELECT
        c_destino_farcomed,
        l_maximo_farcomed + ROW_NUMBER() OVER (ORDER BY numero),
        codigolocal, clasificacion, nombrecomercial, nombreconocido,
        zonificacion, idgeografico, direccion, latitud, longitud, contacto,
        telefono, email, casificacioninicio, casificacionfin, matriz, flujo,
        promocional, porcentajepromo, estado, SYSTIMESTAMP, USER, formato,
        idruta, idrutacambio, estadoruta, bodega, perfil, estadoflujo,
        creaxruc, fechainicioclasificacion, fecharuta, numero_establecimiento,
        estado_establecimiento, tipovisita, NULL, envio_ubicacion,
        envio_direccion, segmentacion
      FROM t_trad_clientelocal
     WHERE codigopdv = c_origen_econofarm;

    IF SQL%ROWCOUNT <> l_locales_econofarm THEN
        RAISE_APPLICATION_ERROR(-20002, 'Cantidad insertada ECONOFARM invalida: ' || SQL%ROWCOUNT);
    END IF;

    INSERT INTO t_trad_clientelocal (
        codigopdv, numero, codigolocal, clasificacion, nombrecomercial,
        nombreconocido, zonificacion, idgeografico, direccion, latitud,
        longitud, contacto, telefono, email, casificacioninicio,
        casificacionfin, matriz, flujo, promocional, porcentajepromo,
        estado, auditoriafecha, auditoriausuario, formato, idruta,
        idrutacambio, estadoruta, bodega, perfil, estadoflujo, creaxruc,
        fechainicioclasificacion, fecharuta, numero_establecimiento,
        estado_establecimiento, tipovisita, auditoriafecha_modificacion,
        envio_ubicacion, envio_direccion, segmentacion
    )
    SELECT
        c_destino_farmamia,
        l_maximo_farmamia + ROW_NUMBER() OVER (ORDER BY numero),
        codigolocal, clasificacion, nombrecomercial, nombreconocido,
        zonificacion, idgeografico, direccion, latitud, longitud, contacto,
        telefono, email, casificacioninicio, casificacionfin, matriz, flujo,
        promocional, porcentajepromo, estado, SYSTIMESTAMP, USER, formato,
        idruta, idrutacambio, estadoruta, bodega, perfil, estadoflujo,
        creaxruc, fechainicioclasificacion, fecharuta, numero_establecimiento,
        estado_establecimiento, tipovisita, NULL, envio_ubicacion,
        envio_direccion, segmentacion
      FROM t_trad_clientelocal
     WHERE codigopdv = c_origen_uscocovich;

    IF SQL%ROWCOUNT <> l_locales_uscocovich THEN
        RAISE_APPLICATION_ERROR(-20003, 'Cantidad insertada USCOCOVICH invalida: ' || SQL%ROWCOUNT);
    END IF;

    UPDATE t_trad_cliente
       SET codigogrupo = NULL,
           codigocliente = NULL,
           estado = 0,
           auditoriausuario = USER
     WHERE codigopdv IN (c_origen_econofarm, c_origen_uscocovich);

    IF SQL%ROWCOUNT <> 2 THEN
        RAISE_APPLICATION_ERROR(-20004, 'Clientes antiguos actualizados: ' || SQL%ROWCOUNT);
    END IF;

    UPDATE t_trad_clientelocal
       SET estado = 0,
           auditoriausuario = USER
     WHERE codigopdv IN (c_origen_econofarm, c_origen_uscocovich);

    IF SQL%ROWCOUNT <> l_locales_econofarm + l_locales_uscocovich THEN
        RAISE_APPLICATION_ERROR(-20005, 'Locales antiguos actualizados: ' || SQL%ROWCOUNT);
    END IF;

    UPDATE t_trad_clienteruc
       SET estado = 0,
           auditoriausuario = USER
     WHERE codigopdv IN (c_origen_econofarm, c_origen_uscocovich);

    IF SQL%ROWCOUNT <> 2 THEN
        RAISE_APPLICATION_ERROR(-20006, 'RUC antiguos actualizados: ' || SQL%ROWCOUNT);
    END IF;

    SELECT COUNT(*) INTO l_total
      FROM t_trad_clientelocal
     WHERE codigopdv = c_destino_farcomed
       AND numero BETWEEN l_maximo_farcomed + 1 AND l_maximo_farcomed + l_locales_econofarm;
    IF l_total <> l_locales_econofarm THEN
        RAISE_APPLICATION_ERROR(-20007, 'Validacion final FARCOMED invalida: ' || l_total);
    END IF;

    SELECT COUNT(*) INTO l_total
      FROM t_trad_clientelocal
     WHERE codigopdv = c_destino_farmamia
       AND numero BETWEEN l_maximo_farmamia + 1 AND l_maximo_farmamia + l_locales_uscocovich;
    IF l_total <> l_locales_uscocovich THEN
        RAISE_APPLICATION_ERROR(-20008, 'Validacion final FARMAMIA invalida: ' || l_total);
    END IF;

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK TO case_50999_inicio;
        RAISE;
END;
/
