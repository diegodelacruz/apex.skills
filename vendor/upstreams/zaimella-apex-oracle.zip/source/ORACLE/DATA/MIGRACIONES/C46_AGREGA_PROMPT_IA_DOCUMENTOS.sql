declare
    l_count number;
begin
    select count(*)
      into l_count
      from all_tab_columns
     where owner = 'DATA'
       and table_name = 'T_CNTR_DOCUMENTOS'
       and column_name = 'PROMPT_IA';

    if l_count = 0 then
        execute immediate 'alter table data.t_cntr_documentos add (prompt_ia clob)';
    end if;
end;
/

comment on column data.t_cntr_documentos.prompt_ia is
    'Instruccion opcional aplicada por IA al documento; habilita su participacion en el analisis.';
