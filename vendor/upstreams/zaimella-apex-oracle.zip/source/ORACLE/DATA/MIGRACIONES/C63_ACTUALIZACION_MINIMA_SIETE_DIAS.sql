declare
    l_column_count number;
    l_nullable all_tab_columns.nullable%type;
begin
    select count(*)
      into l_column_count
      from all_tab_columns
     where owner = 'DATA'
       and table_name = 'T_CNTR_DOCUMENTOS'
       and column_name = 'ACTUALIZACION_MINIMA_DIAS';

    if l_column_count = 0 then
        raise_application_error(-20075, 'No existe la columna ACTUALIZACION_MINIMA_DIAS de C.61.');
    end if;

    -- La decisión funcional establece siete días para todos los documentos existentes.
    update data.t_cntr_documentos
       set actualizacion_minima_dias = 7
     where nvl(actualizacion_minima_dias, -1) <> 7;

    select nullable
      into l_nullable
      from all_tab_columns
     where owner = 'DATA'
       and table_name = 'T_CNTR_DOCUMENTOS'
       and column_name = 'ACTUALIZACION_MINIMA_DIAS';

    execute immediate 'alter table data.t_cntr_documentos modify (actualizacion_minima_dias default 7)';

    if l_nullable = 'Y' then
        execute immediate 'alter table data.t_cntr_documentos modify (actualizacion_minima_dias not null)';
    end if;
end;
/

comment on column data.t_cntr_documentos.actualizacion_minima_dias is
    'Días mínimos de vigencia para evitar una nueva consulta RPA. Valor predeterminado y operativo: 7 días.';
