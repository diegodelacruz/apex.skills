-- C34 - Matricula de productos activos para clientes con configuracion de OC.
-- Alcance: DATA, compania 00003. No actualiza ni elimina matriculas existentes.
-- Regla aprobada: completar cada producto activo para los clientes con OC activa.
-- Marca de reversa C34: 2026-07-20 11:19:42.
-- Los productos sin referencia previa usan ESTADO=1, ESTADOCICLO=3,
-- PRESENTACION=0 y precios nulos, conforme a la autorizacion del usuario.

whenever sqlerror exit failure rollback

merge into data.t_vtas_cliente_producto destino
using (
    with clientes_oc as (
        select distinct configuracion.codigocliente
          from data.t_vtas_pedido_conf_oc configuracion
         where configuracion.compania = '00003'
           and configuracion.estado = 1
    ),
    clientes as (
        select cliente.codigocliente,
               cliente.codigogrupo
          from data.t_gzm_cliente cliente
          join clientes_oc configuracion
            on configuracion.codigocliente = cliente.codigocliente
         where cliente.compania = '00003'
           and cliente.estado = 1
    ),
    productos as (
        select producto.codigoproducto
          from data.t_gzm_producto producto
         where producto.compania = '00003'
           and producto.estado = 1
    ),
    plantilla as (
        select codigoproducto,
               codigoean,
               codigoproductocliente,
               ps_periodos,
               ps_dias_inventario,
               estado,
               estadociclo,
               clasificacion,
               preciomayorista,
               preciominorista,
               preciosugeridosiniva,
               preciosugeridoconiva,
               ice,
               presentacion,
               preciolista,
               fechaprecio
          from (
              select matricula.*,
                     row_number() over (
                         partition by matricula.codigoproducto
                         order by matricula.codigocliente
                     ) as orden
                from data.t_vtas_cliente_producto matricula
                join clientes_oc configuracion
                  on configuracion.codigocliente = matricula.codigocliente
               where matricula.compania = '00003'
          )
         where orden = 1
    )
    select clientes.codigocliente,
           clientes.codigogrupo,
           productos.codigoproducto,
           plantilla.codigoean,
           plantilla.codigoproductocliente,
           plantilla.ps_periodos,
           plantilla.ps_dias_inventario,
           nvl(plantilla.estado, 1) as estado,
           nvl(plantilla.estadociclo, 3) as estadociclo,
           plantilla.clasificacion,
           plantilla.preciomayorista,
           plantilla.preciominorista,
           plantilla.preciosugeridosiniva,
           plantilla.preciosugeridoconiva,
           plantilla.ice,
           nvl(plantilla.presentacion, 0) as presentacion,
           plantilla.preciolista,
           plantilla.fechaprecio
      from clientes
      cross join productos
      left join plantilla
        on plantilla.codigoproducto = productos.codigoproducto
) fuente
on (
    destino.compania = '00003'
    and destino.codigocliente = fuente.codigocliente
    and destino.codigoproducto = fuente.codigoproducto
)
when not matched then
    insert (
        codigogrupo,
        codigocliente,
        codigoproducto,
        codigoean,
        codigoproductocliente,
        ps_periodos,
        ps_dias_inventario,
        estado,
        estadociclo,
        clasificacion,
        preciomayorista,
        preciominorista,
        preciosugeridosiniva,
        preciosugeridoconiva,
        ice,
        fechacodificacion,
        fechaprecio,
        presentacion,
        preciolista,
        compania
    )
    values (
        fuente.codigogrupo,
        fuente.codigocliente,
        fuente.codigoproducto,
        fuente.codigoean,
        fuente.codigoproductocliente,
        fuente.ps_periodos,
        fuente.ps_dias_inventario,
        fuente.estado,
        fuente.estadociclo,
        fuente.clasificacion,
        fuente.preciomayorista,
        fuente.preciominorista,
        fuente.preciosugeridosiniva,
        fuente.preciosugeridoconiva,
        fuente.ice,
        to_date('2026-07-20 11:19:42', 'YYYY-MM-DD HH24:MI:SS'),
        fuente.fechaprecio,
        fuente.presentacion,
        fuente.preciolista,
        '00003'
    );

commit;
