-- C.33 - Ajustes de configuracion documental RPA validados en TEST.
-- Alcance: instrucciones Supercias por RUC e inactivacion global de Equifax.
-- No incluye sujetos, configuraciones de prueba, ejecuciones ni evidencias.

declare
  l_filas pls_integer;
begin
  update data.t_cntr_documento_pasos
     set instruccion = 'Ingrese al Portal de Información / Sector Societario / Búsqueda de Compañías. La navegación inicial es automática; no requiere intervención humana.',
         requiere_intervencion = 0,
         fecha_actualizacion = systimestamp,
         usuario_actualizacion = 'JBALCAZAR'
   where id_paso = 1
     and id_documento = 1;
  l_filas := sql%rowcount;
  if l_filas <> 1 then
    raise_application_error(-20001, 'C.33: se esperaba exactamente el paso 1 del documento Supercias en PRODUCCION.');
  end if;

  update data.t_cntr_documento_pasos
     set instruccion = 'Seleccione la opción R.U.C. (no Expediente ni Nombre), ingrese el RUC del sujeto y presione Consultar. Solo deténgase si el portal muestra un CAPTCHA visible que impida continuar.',
         valor_entrada = 'RUC',
         requiere_intervencion = 0,
         fecha_actualizacion = systimestamp,
         usuario_actualizacion = 'JBALCAZAR'
   where id_paso = 2
     and id_documento = 1;
  l_filas := sql%rowcount;
  if l_filas <> 1 then
    raise_application_error(-20002, 'C.33: se esperaba exactamente el paso 2 del documento Supercias en PRODUCCION.');
  end if;

  update data.t_cntr_documentos
     set estado = 'INACTIVO',
         fecha_actualizacion = systimestamp,
         usuario_actualizacion = 'JBALCAZAR'
   where id_documento = 7
     and nombre_documento = 'Consulta documental - Equifax';
  l_filas := sql%rowcount;
  if l_filas <> 1 then
    raise_application_error(-20003, 'C.33: no se encontro el documento Equifax esperado en PRODUCCION.');
  end if;

  commit;
end;
/
