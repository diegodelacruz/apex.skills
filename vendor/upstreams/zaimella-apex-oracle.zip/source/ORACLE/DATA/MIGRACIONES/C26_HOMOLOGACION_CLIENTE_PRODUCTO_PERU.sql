-- C26 - Homologacion masiva cliente-producto Peru.
-- Fuente controlada: Homologacion Zm Peru (Protecto Apex  Carga de Pedidos).xlsx
-- Alcance: DATA, COMPANIA = '00003'; no modifica Ecuador ni otras companias.
-- Regla funcional aprobada: conservar la primera fila del Excel por (cliente, producto ERP).
-- Se omiten 23 filas posteriores que repiten 20 claves cliente/producto ERP con otro CODART.
-- Carga efectiva: 373 homologaciones unicas para 19 clientes.
set define off
whenever sqlerror exit failure rollback

-- Matricula idempotente: solo clientes sin configuracion OC activa.
insert into data.t_vtas_pedido_conf_oc (
    id, codigocliente, codigogrupo, tipoarchivo, separador, iniciofiladetalle,
    posicion_oc, formato_num, tipounidad, ejecutivo, compania, usuariocreacion,
    fechacreacion, usuariomodificacion, fechamodificacion, estado
)
select data.pk_commons.f_secuencia('T_VTAS_PEDIDO_CONF_OC'),
       c.codigocliente, c.codigogrupo, 1, null, 1, null, null, 2, c.ejecutivo,
       '00003', 'CODEX_C26', sysdate, null, null, 1
  from data.vt_gzm_cliente c
 where c.compania = '00003'
   and c.estado = 1
   and c.codigocliente in ('20100239559', '20531321970', '20603215088', '20271522950', '20538277721', '20100220700', '20612232203', '20515346113', '20384891943', '20109072177', '20517411613', '20100025168', '20515774182', '20536865595', '20108730294', '20100070970', '20508565934', '20393864886', 'NIT783272106')
   and not exists (select 1 from data.t_vtas_pedido_conf_oc o where o.compania = '00003' and o.estado = 1 and o.codigocliente = c.codigocliente);

-- Homologacion idempotente: actualiza solo el primer CODART recibido por clave cliente/producto ERP.
merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300150' codigoproductocliente, '7861001853117' codigoean, '12073909041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300155' codigoproductocliente, '7861001853124' codigoean, '12073908051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300160' codigoproductocliente, '7861001853131' codigoean, '12073907061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300337' codigoproductocliente, '7754069001289' codigoean, '12214018041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300336' codigoproductocliente, '7754069001272' codigoean, '12214021031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300338' codigoproductocliente, '7754069001296' codigoean, '12214013051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300340' codigoproductocliente, '7754069001371' codigoean, '12214222051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300110' codigoproductocliente, '7754069001401' codigoean, '12074232051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300339' codigoproductocliente, '7754069001302' codigoean, '12214011061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300341' codigoproductocliente, '7754069001388' codigoean, '12214233061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300115' codigoproductocliente, '7754069001418' codigoean, '12074232061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300100' codigoproductocliente, '7754069001258' codigoean, '12073704011' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300105' codigoproductocliente, '7754069001265' codigoean, '12073711021' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300310' codigoproductocliente, '7861078303119' codigoean, '13124304041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300305' codigoproductocliente, '7861078303102' codigoean, '13124304031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300300' codigoproductocliente, '7861078301597' codigoean, '13124303021' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300320' codigoproductocliente, '7861001847833' codigoean, '111030016' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300315' codigoproductocliente, '7861001847826' codigoean, '111020018' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300330' codigoproductocliente, '7861001802535' codigoean, '100060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300325' codigoproductocliente, '7861001851427' codigoean, '108060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300335' codigoproductocliente, '7861078301931' codigoean, '107060010' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300205' codigoproductocliente, '7861001853162' codigoean, '45074126071' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300200' codigoproductocliente, '7861001853629' codigoean, '45074138071' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300503' codigoproductocliente, '7754069001289' codigoean, '12074018041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300505' codigoproductocliente, '7754069001302' codigoean, '12074011061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100239559' codigocliente, '18300504' codigoproductocliente, '7754069001296' codigoean, '12074013051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450044' codigoproductocliente, '7861078301931' codigoean, '107060010' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450062' codigoproductocliente, '7861001853117' codigoean, '12073909041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450063' codigoproductocliente, '7861001853124' codigoean, '12073908051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450064' codigoproductocliente, '7861001853131' codigoean, '12073907061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450059' codigoproductocliente, '7754069001289' codigoean, '12074018041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450066' codigoproductocliente, '7754069001180' codigoean, '12213818041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450073' codigoproductocliente, '7754069001289' codigoean, '12214018041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450057' codigoproductocliente, '7754069001371' codigoean, '12074222051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450069' codigoproductocliente, '7754069001371' codigoean, '12214222051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450058' codigoproductocliente, '7754069001388' codigoean, '12074233061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450070' codigoproductocliente, '7754069001388' codigoean, '12214233061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450052' codigoproductocliente, '7754069001272' codigoean, '12074021031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450056' codigoproductocliente, '7754069000008' codigoean, '12073821031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450065' codigoproductocliente, '7754069000008' codigoean, '12213821031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450076' codigoproductocliente, '7754069001272' codigoean, '12214021031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450050' codigoproductocliente, '7754069001401' codigoean, '12074232051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450060' codigoproductocliente, '7754069001296' codigoean, '12074013051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450067' codigoproductocliente, '7754069001197' codigoean, '12213813051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450074' codigoproductocliente, '7754069001296' codigoean, '12214013051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450051' codigoproductocliente, '7754069001418' codigoean, '12074232061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450061' codigoproductocliente, '7754069001302' codigoean, '12074011061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450068' codigoproductocliente, '7754069001203' codigoean, '12213811061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450075' codigoproductocliente, '7754069001302' codigoean, '12214011061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450018' codigoproductocliente, '7754069001258' codigoean, '12073704011' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450049' codigoproductocliente, '7754069001265' codigoean, '12073711021' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450045' codigoproductocliente, '7861001851427' codigoean, '108060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450037' codigoproductocliente, '7861001802535' codigoean, '100060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450041' codigoproductocliente, '7861078303119' codigoean, '13124304041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450040' codigoproductocliente, '7861078303102' codigoean, '13124304031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450039' codigoproductocliente, '7861078301597' codigoean, '13124303021' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450043' codigoproductocliente, '7861001847833' codigoean, '111030016' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450042' codigoproductocliente, '7861001847826' codigoean, '111020018' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450048' codigoproductocliente, '7861001853162' codigoean, '45074126071' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20531321970' codigocliente, '450035' codigoproductocliente, '7861001853629' codigoean, '45074138071' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450044' codigoproductocliente, '7861078301931' codigoean, '107060010' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450062' codigoproductocliente, '7861001853117' codigoean, '12073909041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450063' codigoproductocliente, '7861001853124' codigoean, '12073908051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450064' codigoproductocliente, '7861001853131' codigoean, '12073907061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450059' codigoproductocliente, '7754069001289' codigoean, '12074018041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450066' codigoproductocliente, '7754069001180' codigoean, '12213818041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450073' codigoproductocliente, '7754069001289' codigoean, '12214018041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450057' codigoproductocliente, '7754069001371' codigoean, '12074222051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450069' codigoproductocliente, '7754069001371' codigoean, '12214222051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450058' codigoproductocliente, '7754069001388' codigoean, '12074233061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450070' codigoproductocliente, '7754069001388' codigoean, '12214233061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450052' codigoproductocliente, '7754069001272' codigoean, '12074021031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450056' codigoproductocliente, '7754069000008' codigoean, '12073821031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450065' codigoproductocliente, '7754069000008' codigoean, '12213821031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450076' codigoproductocliente, '7754069001272' codigoean, '12214021031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450050' codigoproductocliente, '7754069001401' codigoean, '12074232051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450060' codigoproductocliente, '7754069001296' codigoean, '12074013051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450067' codigoproductocliente, '7754069001197' codigoean, '12213813051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450074' codigoproductocliente, '7754069001296' codigoean, '12214013051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450051' codigoproductocliente, '7754069001418' codigoean, '12074232061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450061' codigoproductocliente, '7754069001302' codigoean, '12074011061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450068' codigoproductocliente, '7754069001203' codigoean, '12213811061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450075' codigoproductocliente, '7754069001302' codigoean, '12214011061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450018' codigoproductocliente, '7754069001258' codigoean, '12073704011' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450049' codigoproductocliente, '7754069001265' codigoean, '12073711021' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450045' codigoproductocliente, '7861001851427' codigoean, '108060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450037' codigoproductocliente, '7861001802535' codigoean, '100060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450041' codigoproductocliente, '7861078303119' codigoean, '13124304041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450040' codigoproductocliente, '7861078303102' codigoean, '13124304031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450039' codigoproductocliente, '7861078301597' codigoean, '13124303021' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450043' codigoproductocliente, '7861001847833' codigoean, '111030016' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450042' codigoproductocliente, '7861001847826' codigoean, '111020018' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450048' codigoproductocliente, '7861001853162' codigoean, '45074126071' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20603215088' codigocliente, '450035' codigoproductocliente, '7861001853629' codigoean, '45074138071' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450044' codigoproductocliente, '7861078301931' codigoean, '107060010' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450062' codigoproductocliente, '7861001853117' codigoean, '12073909041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450063' codigoproductocliente, '7861001853124' codigoean, '12073908051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450064' codigoproductocliente, '7861001853131' codigoean, '12073907061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450059' codigoproductocliente, '7754069001289' codigoean, '12074018041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450066' codigoproductocliente, '7754069001180' codigoean, '12213818041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450073' codigoproductocliente, '7754069001289' codigoean, '12214018041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450057' codigoproductocliente, '7754069001371' codigoean, '12074222051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450069' codigoproductocliente, '7754069001371' codigoean, '12214222051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450058' codigoproductocliente, '7754069001388' codigoean, '12074233061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450070' codigoproductocliente, '7754069001388' codigoean, '12214233061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450052' codigoproductocliente, '7754069001272' codigoean, '12074021031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450056' codigoproductocliente, '7754069000008' codigoean, '12073821031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450065' codigoproductocliente, '7754069000008' codigoean, '12213821031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450076' codigoproductocliente, '7754069001272' codigoean, '12214021031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450050' codigoproductocliente, '7754069001401' codigoean, '12074232051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450060' codigoproductocliente, '7754069001296' codigoean, '12074013051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450067' codigoproductocliente, '7754069001197' codigoean, '12213813051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450074' codigoproductocliente, '7754069001296' codigoean, '12214013051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450051' codigoproductocliente, '7754069001418' codigoean, '12074232061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450061' codigoproductocliente, '7754069001302' codigoean, '12074011061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450068' codigoproductocliente, '7754069001203' codigoean, '12213811061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450075' codigoproductocliente, '7754069001302' codigoean, '12214011061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450018' codigoproductocliente, '7754069001258' codigoean, '12073704011' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450049' codigoproductocliente, '7754069001265' codigoean, '12073711021' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450045' codigoproductocliente, '7861001851427' codigoean, '108060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450037' codigoproductocliente, '7861001802535' codigoean, '100060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450041' codigoproductocliente, '7861078303119' codigoean, '13124304041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450040' codigoproductocliente, '7861078303102' codigoean, '13124304031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450039' codigoproductocliente, '7861078301597' codigoean, '13124303021' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450043' codigoproductocliente, '7861001847833' codigoean, '111030016' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450042' codigoproductocliente, '7861001847826' codigoean, '111020018' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450048' codigoproductocliente, '7861001853162' codigoean, '45074126071' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20271522950' codigocliente, '450035' codigoproductocliente, '7861001853629' codigoean, '45074138071' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450044' codigoproductocliente, '7861078301931' codigoean, '107060010' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450062' codigoproductocliente, '7861001853117' codigoean, '12073909041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450063' codigoproductocliente, '7861001853124' codigoean, '12073908051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450064' codigoproductocliente, '7861001853131' codigoean, '12073907061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450059' codigoproductocliente, '7754069001289' codigoean, '12074018041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450066' codigoproductocliente, '7754069001180' codigoean, '12213818041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450073' codigoproductocliente, '7754069001289' codigoean, '12214018041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450057' codigoproductocliente, '7754069001371' codigoean, '12074222051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450069' codigoproductocliente, '7754069001371' codigoean, '12214222051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450058' codigoproductocliente, '7754069001388' codigoean, '12074233061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450070' codigoproductocliente, '7754069001388' codigoean, '12214233061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450052' codigoproductocliente, '7754069001272' codigoean, '12074021031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450056' codigoproductocliente, '7754069000008' codigoean, '12073821031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450065' codigoproductocliente, '7754069000008' codigoean, '12213821031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450076' codigoproductocliente, '7754069001272' codigoean, '12214021031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450050' codigoproductocliente, '7754069001401' codigoean, '12074232051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450060' codigoproductocliente, '7754069001296' codigoean, '12074013051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450067' codigoproductocliente, '7754069001197' codigoean, '12213813051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450074' codigoproductocliente, '7754069001296' codigoean, '12214013051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450051' codigoproductocliente, '7754069001418' codigoean, '12074232061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450061' codigoproductocliente, '7754069001302' codigoean, '12074011061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450068' codigoproductocliente, '7754069001203' codigoean, '12213811061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450075' codigoproductocliente, '7754069001302' codigoean, '12214011061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450018' codigoproductocliente, '7754069001258' codigoean, '12073704011' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450049' codigoproductocliente, '7754069001265' codigoean, '12073711021' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450045' codigoproductocliente, '7861001851427' codigoean, '108060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450037' codigoproductocliente, '7861001802535' codigoean, '100060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450041' codigoproductocliente, '7861078303119' codigoean, '13124304041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450040' codigoproductocliente, '7861078303102' codigoean, '13124304031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450039' codigoproductocliente, '7861078301597' codigoean, '13124303021' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450043' codigoproductocliente, '7861001847833' codigoean, '111030016' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450042' codigoproductocliente, '7861001847826' codigoean, '111020018' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450048' codigoproductocliente, '7861001853162' codigoean, '45074126071' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20538277721' codigocliente, '450035' codigoproductocliente, '7861001853629' codigoean, '45074138071' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127139' codigoproductocliente, '7861001853124' codigoean, '12073908051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127140' codigoproductocliente, '7861001853131' codigoean, '12073907061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127162' codigoproductocliente, '7861078301931' codigoean, '107060010' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127154' codigoproductocliente, '7754069001401' codigoean, '12074232051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127155' codigoproductocliente, '7754069001418' codigoean, '12074232061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127126' codigoproductocliente, '7754069001289' codigoean, '12074018041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127127' codigoproductocliente, '7754069001272' codigoean, '12074021031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127128' codigoproductocliente, '7754069001296' codigoean, '12074013051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127129' codigoproductocliente, '7754069001302' codigoean, '12074011061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127150' codigoproductocliente, '7754069001371' codigoean, '12074222051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127151' codigoproductocliente, '7754069001388' codigoean, '12074233061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127131' codigoproductocliente, '7754069001265' codigoean, '12073711021' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127130' codigoproductocliente, '7754069001258' codigoean, '12073704011' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127141' codigoproductocliente, '7861001851427' codigoean, '108060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127160' codigoproductocliente, '7861001802535' codigoean, '100060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127106' codigoproductocliente, '7861078303119' codigoean, '13124304041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127149' codigoproductocliente, '7861078303102' codigoean, '13124304031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127161' codigoproductocliente, '7861078301597' codigoean, '13124303021' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127157' codigoproductocliente, '7861001847833' codigoean, '111030016' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127156' codigoproductocliente, '7861001847826' codigoean, '111020018' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '996800' codigoproductocliente, '7861001853155' codigoean, '45034138071' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127147' codigoproductocliente, '7861001853162' codigoean, '45074126071' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127159' codigoproductocliente, '7861001853629' codigoean, '45074138071' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127164' codigoproductocliente, '7754069000008' codigoean, '12213821031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127163' codigoproductocliente, '7754069001180' codigoean, '12213818041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127165' codigoproductocliente, '7754069001197' codigoean, '12213813051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127166' codigoproductocliente, '7754069001203' codigoean, '12213811061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127167' codigoproductocliente, '7754069001371' codigoean, '12214222051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100220700' codigocliente, '127168' codigoproductocliente, '7754069001388' codigoean, '12214233061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20612232203' codigocliente, '11010200153155' codigoproductocliente, '7861001853155' codigoean, '45034138071' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20612232203' codigocliente, '11010100201418' codigoproductocliente, '7754069001418' codigoean, '12074232061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20612232203' codigocliente, '11010100201401' codigoproductocliente, '7754069001401' codigoean, '12074232051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20612232203' codigocliente, '11010100201395' codigoproductocliente, '' codigoean, '12074232041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515346113' codigocliente, '47139' codigoproductocliente, '7861001853124' codigoean, '12073908051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515346113' codigocliente, '47170' codigoproductocliente, '7861001853131' codigoean, '12073907061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515346113' codigocliente, '47961' codigoproductocliente, '7754069001289' codigoean, '12214018041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515346113' codigocliente, '47172' codigoproductocliente, '7754069001272' codigoean, '12214021031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515346113' codigocliente, '47960' codigoproductocliente, '7754069001296' codigoean, '12214013051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515346113' codigocliente, '47855' codigoproductocliente, '7754069001371' codigoean, '12214222051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515346113' codigocliente, '47959' codigoproductocliente, '7754069001302' codigoean, '12214011061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515346113' codigocliente, '47856' codigoproductocliente, '7754069001388' codigoean, '12214233061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515346113' codigocliente, '47168' codigoproductocliente, '7754069001258' codigoean, '12073704011' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515346113' codigocliente, '21059' codigoproductocliente, '7861078303119' codigoean, '13124304041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515346113' codigocliente, '21057' codigoproductocliente, '7861078303102' codigoean, '13124304031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515346113' codigocliente, '46035' codigoproductocliente, '7861001847833' codigoean, '111030016' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515346113' codigocliente, '46036' codigoproductocliente, '7861001847826' codigoean, '111020018' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515346113' codigocliente, '46037' codigoproductocliente, '7861001802535' codigoean, '100060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515346113' codigocliente, '45319' codigoproductocliente, '7861001851427' codigoean, '108060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20384891943' codigocliente, '75943' codigoproductocliente, '7754069001197' codigoean, '12073813051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20384891943' codigocliente, '85067' codigoproductocliente, '7754069001371' codigoean, '12074222051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20384891943' codigocliente, '75942' codigoproductocliente, '7754069001203' codigoean, '12073811061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20384891943' codigocliente, '85066' codigoproductocliente, '7754069001388' codigoean, '12074233061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20384891943' codigocliente, '75088' codigoproductocliente, '7754069001258' codigoean, '12073704011' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20384891943' codigocliente, '85077' codigoproductocliente, '7861001802535' codigoean, '100060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20384891943' codigocliente, '72606' codigoproductocliente, '7861078303119' codigoean, '13124304041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20384891943' codigocliente, '72605' codigoproductocliente, '7861078303102' codigoean, '13124304031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20384891943' codigocliente, '81342' codigoproductocliente, '7861078301597' codigoean, '13124303021' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20384891943' codigocliente, '75951' codigoproductocliente, '7861001847833' codigoean, '111030016' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20384891943' codigocliente, '75952' codigoproductocliente, '7861001847826' codigoean, '111020018' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20384891943' codigocliente, '75089' codigoproductocliente, '7861001851427' codigoean, '108060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20109072177' codigocliente, '973199' codigoproductocliente, '2050044164310' codigoean, '12110718041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20109072177' codigocliente, '973200' codigoproductocliente, '2050044164334' codigoean, '12110713051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20109072177' codigocliente, '973201' codigoproductocliente, '2050044164358' codigoean, '12110711061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20109072177' codigocliente, '989668' codigoproductocliente, '2050044226704' codigoean, '12110722051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20109072177' codigocliente, '989669' codigoproductocliente, '2050044226728' codigoean, '12110722061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20517411613' codigocliente, '180762' codigoproductocliente, '7754069001289' codigoean, '12214018041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20517411613' codigocliente, '180761' codigoproductocliente, '7754069001272' codigoean, '12214021031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20517411613' codigocliente, '180765' codigoproductocliente, '7754069001371' codigoean, '12214222051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20517411613' codigocliente, '180766' codigoproductocliente, '7754069001388' codigoean, '12214233061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20517411613' codigocliente, '180764' codigoproductocliente, '7754069001302' codigoean, '12214011061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20517411613' codigocliente, '180760' codigoproductocliente, '7754069001258' codigoean, '12073704011' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20517411613' codigocliente, '11753' codigoproductocliente, '7861078303119' codigoean, '13124304041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20517411613' codigocliente, '11751' codigoproductocliente, '7861078303102' codigoean, '13124304031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100025168' codigocliente, '23878' codigoproductocliente, '7861001802535' codigoean, '100060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100025168' codigocliente, '20880' codigoproductocliente, '7861078303119' codigoean, '13124304041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100025168' codigocliente, '20878' codigoproductocliente, '7861078303102' codigoean, '13124304031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100025168' codigocliente, '16493' codigoproductocliente, '7861001847833' codigoean, '111030016' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100025168' codigocliente, '416' codigoproductocliente, '7861001847826' codigoean, '111020018' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100025168' codigocliente, '26919' codigoproductocliente, '7861001851427' codigoean, '108060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515774182' codigocliente, '218163' codigoproductocliente, '7861001853124' codigoean, '12073908051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515774182' codigocliente, '218164' codigoproductocliente, '7861001853131' codigoean, '12073907061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515774182' codigocliente, '215770' codigoproductocliente, '7754069001289' codigoean, '12214018041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515774182' codigocliente, '216011' codigoproductocliente, '7754069001371' codigoean, '12214222051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515774182' codigocliente, '216012' codigoproductocliente, '7754069001388' codigoean, '12214233061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515774182' codigocliente, '215767' codigoproductocliente, '7754069001296' codigoean, '12214013051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515774182' codigocliente, '215766' codigoproductocliente, '7754069001258' codigoean, '12073704011' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515774182' codigocliente, '215771' codigoproductocliente, '7754069001265' codigoean, '12073711021' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515774182' codigocliente, '218967' codigoproductocliente, '7861001802535' codigoean, '100060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515774182' codigocliente, '194284' codigoproductocliente, '7861078303119' codigoean, '13124304041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515774182' codigocliente, '194283' codigoproductocliente, '7861078303102' codigoean, '13124304031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515774182' codigocliente, '218965' codigoproductocliente, '7861001847833' codigoean, '111030016' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515774182' codigocliente, '218966' codigoproductocliente, '7861001847826' codigoean, '111020018' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20515774182' codigocliente, '216125' codigoproductocliente, '7861001851427' codigoean, '108060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20536865595' codigocliente, '100000101' codigoproductocliente, '7861001853124' codigoean, '12073908051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20536865595' codigocliente, '100000339' codigoproductocliente, '7754069001289' codigoean, '12214018041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20536865595' codigocliente, '100000012' codigoproductocliente, '7754069001388' codigoean, '12214233061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20536865595' codigocliente, '100000344' codigoproductocliente, '7754069001272' codigoean, '12214021031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20536865595' codigocliente, '00005491' codigoproductocliente, '7754069001265' codigoean, '12073711021' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20536865595' codigocliente, '100000207' codigoproductocliente, '7861001802535' codigoean, '100060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20536865595' codigocliente, '100000338' codigoproductocliente, '7861078303119' codigoean, '13124304041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20536865595' codigocliente, '100000330' codigoproductocliente, '7861078303102' codigoean, '13124304031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20536865595' codigocliente, '00005185' codigoproductocliente, '7861001851427' codigoean, '108060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20536865595' codigocliente, '100000358' codigoproductocliente, '7861001853162' codigoean, '45074126071' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20108730294' codigocliente, '62231' codigoproductocliente, '7754069001227' codigoean, '12030413041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20108730294' codigocliente, '62230' codigoproductocliente, '7754069001210' codigoean, '12030417031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20108730294' codigocliente, '62232' codigoproductocliente, '7754069001234' codigoean, '12030409051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20108730294' codigocliente, '62233' codigoproductocliente, '7754069001241' codigoean, '12030408061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20108730294' codigocliente, '63586' codigoproductocliente, '' codigoean, '12074232041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20108730294' codigocliente, '62163' codigoproductocliente, '7754069001289' codigoean, '12214018041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20108730294' codigocliente, '62162' codigoproductocliente, '7754069001272' codigoean, '12214021031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20108730294' codigocliente, '63587' codigoproductocliente, '7754069001401' codigoean, '12074232051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20108730294' codigocliente, '62164' codigoproductocliente, '7754069001296' codigoean, '12214013051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20108730294' codigocliente, '63588' codigoproductocliente, '7754069001418' codigoean, '12074232061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20108730294' codigocliente, '62165' codigoproductocliente, '7754069001302' codigoean, '12214011061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20108730294' codigocliente, '57415' codigoproductocliente, '7861001802535' codigoean, '100060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20108730294' codigocliente, '28476' codigoproductocliente, '7861078303119' codigoean, '13124304041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20108730294' codigocliente, '28475' codigoproductocliente, '7861078303102' codigoean, '13124304031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20108730294' codigocliente, '62485' codigoproductocliente, '7861001851427' codigoean, '108060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100070970' codigocliente, '20295421' codigoproductocliente, '7861001851427' codigoean, '108060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100070970' codigocliente, '20198953' codigoproductocliente, '7861001847826' codigoean, '111020018' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100070970' codigocliente, '20198955' codigoproductocliente, '7861001847833' codigoean, '111030016' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100070970' codigocliente, '20198954' codigoproductocliente, '7861001802535' codigoean, '100060020' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100070970' codigocliente, '20198415' codigoproductocliente, '7861078301931' codigoean, '107060010' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100070970' codigocliente, '20395734' codigoproductocliente, '7861001852998' codigoean, '44120030071' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100070970' codigocliente, '20466157' codigoproductocliente, '7861078303119' codigoean, '13124304041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100070970' codigocliente, '20466159' codigoproductocliente, '7861078303102' codigoean, '13124304031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100070970' codigocliente, '20565210' codigoproductocliente, '7861078304338' codigoean, '107050010' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20100070970' codigocliente, '20426503' codigoproductocliente, '7861001851908' codigoean, '47170026102' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '43439017' codigoproductocliente, '7861001853124' codigoean, '12073908051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '43439018' codigoproductocliente, '7861001853131' codigoean, '12073907061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '43439015' codigoproductocliente, '7754069001371' codigoean, '12074222051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '43439016' codigoproductocliente, '7754069001388' codigoean, '12074233061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '41785398' codigoproductocliente, '2000417853983' codigoean, '13102403041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '41785399' codigoproductocliente, '2000417853990' codigoean, '13102405041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '41785396' codigoproductocliente, '2000417853969' codigoean, '13102403031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '41785397' codigoproductocliente, '2000417853976' codigoean, '13102405031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '41760182' codigoproductocliente, '2000417601829' codigoean, '12092613041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '41760181' codigoproductocliente, '2000417601812' codigoean, '12092615031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '41760180' codigoproductocliente, '2000417601805' codigoean, '12092613021' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '43157914' codigoproductocliente, '2000431579142' codigoean, '12092631051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '41760183' codigoproductocliente, '2000417601836' codigoean, '12092609051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '43157915' codigoproductocliente, '2000431579159' codigoean, '12092631061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '41760184' codigoproductocliente, '2000417601843' codigoean, '12092608061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '40729966' codigoproductocliente, '2000407299661' codigoean, '12092526051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '40779345' codigoproductocliente, '2000407793459' codigoean, '12092526061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '41760193' codigoproductocliente, '2000417601935' codigoean, '12101316041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '41760194' codigoproductocliente, '2000417601942' codigoean, '12101311051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '42837178' codigoproductocliente, '2000428371780' codigoean, '12101321051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '42837179' codigoproductocliente, '2000428371797' codigoean, '12101321061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '41760187' codigoproductocliente, '2000417601874' codigoean, '12102318041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '41760188' codigoproductocliente, '2000417601881' codigoean, '12102313051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '42837176' codigoproductocliente, '2000428371766' codigoean, '12102322051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '43556608' codigoproductocliente, '2000435566087' codigoean, '12104622061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '43556613' codigoproductocliente, '2000435566131' codigoean, '12104620031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '43556614' codigoproductocliente, '2000435566148' codigoean, '12104619021' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '43556611' codigoproductocliente, '2000435566117' codigoean, '12104611061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20508565934' codigocliente, '41291481' codigoproductocliente, '2000412914818' codigoean, '44102404071' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '43439017' codigoproductocliente, '7861001853124' codigoean, '12073908051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '43439018' codigoproductocliente, '7861001853131' codigoean, '12073907061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '43439015' codigoproductocliente, '7754069001371' codigoean, '12074222051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '43439016' codigoproductocliente, '7754069001388' codigoean, '12074233061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '41785398' codigoproductocliente, '2000417853983' codigoean, '13102403041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '41785399' codigoproductocliente, '2000417853990' codigoean, '13102405041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '41785396' codigoproductocliente, '2000417853969' codigoean, '13102403031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '41785397' codigoproductocliente, '2000417853976' codigoean, '13102405031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '41760182' codigoproductocliente, '2000417601829' codigoean, '12092613041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '41760181' codigoproductocliente, '2000417601812' codigoean, '12092615031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '41760180' codigoproductocliente, '2000417601805' codigoean, '12092613021' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '43157914' codigoproductocliente, '2000431579142' codigoean, '12092631051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '41760183' codigoproductocliente, '2000417601836' codigoean, '12092609051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '43157915' codigoproductocliente, '2000431579159' codigoean, '12092631061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '41760184' codigoproductocliente, '2000417601843' codigoean, '12092608061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '40729966' codigoproductocliente, '2000407299661' codigoean, '12092526051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '40779345' codigoproductocliente, '2000407793459' codigoean, '12092526061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '41760193' codigoproductocliente, '2000417601935' codigoean, '12101316041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '41760194' codigoproductocliente, '2000417601942' codigoean, '12101311051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '42837178' codigoproductocliente, '2000428371780' codigoean, '12101321051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '42837179' codigoproductocliente, '2000428371797' codigoean, '12101321061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '41760187' codigoproductocliente, '2000417601874' codigoean, '12102318041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '41760188' codigoproductocliente, '2000417601881' codigoean, '12102313051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '42837176' codigoproductocliente, '2000428371766' codigoean, '12102322051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '43556608' codigoproductocliente, '2000435566087' codigoean, '12104622061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '43556613' codigoproductocliente, '2000435566131' codigoean, '12104620031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '43556614' codigoproductocliente, '2000435566148' codigoean, '12104619021' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '43556611' codigoproductocliente, '2000435566117' codigoean, '12104611061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select '20393864886' codigocliente, '41291481' codigoproductocliente, '2000412914818' codigoean, '44102404071' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select 'NIT783272106' codigocliente, '41785398' codigoproductocliente, '2000417853983' codigoean, '13102403041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select 'NIT783272106' codigocliente, '41785399' codigoproductocliente, '2000417853990' codigoean, '13102405041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select 'NIT783272106' codigocliente, '41785396' codigoproductocliente, '2000417853969' codigoean, '13102403031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select 'NIT783272106' codigocliente, '41785397' codigoproductocliente, '2000417853976' codigoean, '13102405031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select 'NIT783272106' codigocliente, '41760182' codigoproductocliente, '2000417601829' codigoean, '12092613041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select 'NIT783272106' codigocliente, '41760181' codigoproductocliente, '2000417601812' codigoean, '12092615031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select 'NIT783272106' codigocliente, '41760180' codigoproductocliente, '2000417601805' codigoean, '12092613021' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select 'NIT783272106' codigocliente, '43157914' codigoproductocliente, '2000431579142' codigoean, '12092631051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select 'NIT783272106' codigocliente, '41760183' codigoproductocliente, '2000417601836' codigoean, '12092609051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select 'NIT783272106' codigocliente, '43157915' codigoproductocliente, '2000431579159' codigoean, '12092631061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select 'NIT783272106' codigocliente, '41760184' codigoproductocliente, '2000417601843' codigoean, '12092608061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select 'NIT783272106' codigocliente, '40729966' codigoproductocliente, '2000407299661' codigoean, '12092526051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select 'NIT783272106' codigocliente, '40779345' codigoproductocliente, '2000407793459' codigoean, '12092526061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select 'NIT783272106' codigocliente, '41760193' codigoproductocliente, '2000417601935' codigoean, '12101316041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select 'NIT783272106' codigocliente, '41760194' codigoproductocliente, '2000417601942' codigoean, '12101311051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select 'NIT783272106' codigocliente, '42837178' codigoproductocliente, '2000428371780' codigoean, '12101321051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select 'NIT783272106' codigocliente, '42837179' codigoproductocliente, '2000428371797' codigoean, '12101321061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select 'NIT783272106' codigocliente, '41760187' codigoproductocliente, '2000417601874' codigoean, '12102318041' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select 'NIT783272106' codigocliente, '41760188' codigoproductocliente, '2000417601881' codigoean, '12102313051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select 'NIT783272106' codigocliente, '42837176' codigoproductocliente, '2000428371766' codigoean, '12102322051' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select 'NIT783272106' codigocliente, '43556608' codigoproductocliente, '2000435566087' codigoean, '12104622061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select 'NIT783272106' codigocliente, '43556613' codigoproductocliente, '2000435566131' codigoean, '12104620031' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select 'NIT783272106' codigocliente, '43556614' codigoproductocliente, '2000435566148' codigoean, '12104619021' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select 'NIT783272106' codigocliente, '43556611' codigoproductocliente, '2000435566117' codigoean, '12104611061' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

merge into data.t_vtas_cliente_producto t
using (
    select 'NIT783272106' codigocliente, '41291481' codigoproductocliente, '2000412914818' codigoean, '44102404071' codigoproducto from dual
) s
on (t.compania = '00003' and t.codigocliente = s.codigocliente and t.codigoproducto = s.codigoproducto)
when matched then update set
    t.codigoean = s.codigoean,
    t.codigoproductocliente = s.codigoproductocliente,
    t.estado = 1,
    t.fechacodificacion = sysdate
when not matched then insert (
    codigogrupo, codigocliente, codigoproducto, codigoean, codigoproductocliente,
    estado, fechacodificacion, compania
) values (
    s.codigocliente, s.codigocliente, s.codigoproducto, s.codigoean, s.codigoproductocliente,
    1, sysdate, '00003'
);

commit;
