-- C.39 - Un diálogo APEX se abre desde su página padre, no desde el menú.
-- Alcance: oculta la entrada navegable CNTRP321 y conserva sus permisos para
-- la apertura autorizada desde Ejecuciones RPA.
update data.t_admi_modulopagina
   set estado = 0,
       usuario_aud = 'JBALCAZAR',
       fechamodificacion = sysdate
 where codigomodulo = 'CNTR'
   and codigopagina = 'CNTRP321'
   and estado <> 0;

commit;
