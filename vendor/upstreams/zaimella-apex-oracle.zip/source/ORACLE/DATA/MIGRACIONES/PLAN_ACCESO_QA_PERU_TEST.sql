-- Acceso QA temporal para APEX-010 en TEST.
-- Conserva la jerarquia existente y habilita al rol corporativo 10 de PLAN para JBALCAZAR/00003.
merge into data.t_admi_modulopagina t
using (select 'PLAN' codigomodulo, 'PLAN0980' codigopagina from dual) s
on (t.codigomodulo=s.codigomodulo and t.codigopagina=s.codigopagina)
when matched then update set t.descripcion='Configuración', t.orden=2, t.rutapagina=NULL, t.estado=1, t.usuario_aud='JBALCAZAR', t.fechamodificacion=sysdate, t.opcionmenu='Configuración', t.iconocss='fa-pie-chart', t.codigopadre='PLAN00001', t.nivel=2
when not matched then insert (codigopagina,codigomodulo,descripcion,orden,rutapagina,estado,usuario_aud,fechacreacion,opcionmenu,iconocss,codigopadre,nivel)
values ('PLAN0980','PLAN','Configuración',2,NULL,1,'JBALCAZAR',sysdate,'Configuración','fa-pie-chart','PLAN00001',2);

merge into data.t_admi_rolaccesos t
using (select 10 id_rol, p.id id_modulopagina from data.t_admi_modulopagina p where p.codigomodulo='PLAN' and p.codigopagina='PLAN0980') s
on (t.id_rol=s.id_rol and t.id_modulopagina=s.id_modulopagina and nvl(t.codigoaccion,'~')='~' and nvl(t.codigo_tg,'~')='~')
when matched then update set t.estado=1, t.usuario_aud='JBALCAZAR', t.fechamodificacion=sysdate, t.agregar=0, t.guardar=0, t.eliminar=0, t.comentar=0, t.imprimir=0, t.cancelar=1
when not matched then insert (id_rol,id_modulopagina,estado,usuario_aud,fechacreacion,codigoaccion,codigo_tg,agregar,guardar,eliminar,comentar,imprimir,cancelar)
values (s.id_rol,s.id_modulopagina,1,'JBALCAZAR',sysdate,NULL,NULL,0,0,0,0,0,1);

merge into data.t_admi_rolusuario t
using (select 10 id_rol from dual) s
on (t.id_rol=s.id_rol and t.codigomodulo='PLAN' and t.codigocompania='00003' and t.codigousuario='JBALCAZAR' and t.estado=1)
when not matched then insert (id_rol,codigomodulo,codigocompania,codigousuario,estado,usuario_aud,fechacreacion)
values (s.id_rol,'PLAN','00003','JBALCAZAR',1,'JBALCAZAR',sysdate);
