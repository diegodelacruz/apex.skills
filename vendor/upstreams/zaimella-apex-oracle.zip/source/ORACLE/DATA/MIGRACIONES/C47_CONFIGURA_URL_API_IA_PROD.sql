declare
    l_total number;
begin
    select count(*) into l_total
      from data.t_corp_udc
     where id_cabecera = 'CNTRIAAPI'
       and descripcion = 'URL_EJECUTAR';
    if l_total = 0 then
        insert into data.t_corp_udc(id,id_cabecera,id_tabla,descripcion,valor,activo)
        values (
            data.pk_commons.f_secuencia('T_CORP_UDC'),
            'CNTRIAAPI',1,'URL_EJECUTAR',
            'http://192.168.5.146:8095/api/v1',1
        );
    else
        update data.t_corp_udc
           set valor = 'http://192.168.5.146:8095/api/v1',
               activo = 1
         where id_cabecera = 'CNTRIAAPI'
           and descripcion = 'URL_EJECUTAR';
    end if;
end;
/
