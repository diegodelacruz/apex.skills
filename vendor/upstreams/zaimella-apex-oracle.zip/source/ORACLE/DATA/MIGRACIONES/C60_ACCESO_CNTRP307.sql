-- Generado por apex_menu_access_tool.py. Ejecutar solo para TEST y versionar en el deploy de la tarea.
merge into data.t_admi_modulopagina t
using (select 'CNTR' codigomodulo, 'CNTRP307' codigopagina from dual) s
on (t.codigomodulo=s.codigomodulo and t.codigopagina=s.codigopagina)
when matched then update set t.descripcion='Matricula de Sujetos', t.orden=1, t.rutapagina='307', t.estado=1, t.usuario_aud='JBALCAZAR', t.fechamodificacion=sysdate, t.opcionmenu='Matricula de Sujetos', t.iconocss=NULL, t.codigopadre='CNTR00002', t.nivel=3
when not matched then insert (codigopagina,codigomodulo,descripcion,orden,rutapagina,estado,usuario_aud,fechacreacion,opcionmenu,iconocss,codigopadre,nivel)
values ('CNTRP307','CNTR','Matricula de Sujetos',1,'307',1,'JBALCAZAR',sysdate,'Matricula de Sujetos',NULL,'CNTR00002',3);

merge into data.t_admi_rolaccesos t
using (select 5 id_rol, p.id id_modulopagina from data.t_admi_modulopagina p where p.codigomodulo='CNTR' and p.codigopagina='CNTRP307') s
on (t.id_rol=s.id_rol and t.id_modulopagina=s.id_modulopagina and nvl(t.codigoaccion,'~')=nvl(NULL,'~') and nvl(t.codigo_tg,'~')=nvl(NULL,'~'))
when matched then update set t.estado=1, t.usuario_aud='JBALCAZAR', t.fechamodificacion=sysdate, t.agregar=0, t.guardar=0, t.eliminar=0, t.comentar=0, t.imprimir=0, t.cancelar=0
when not matched then insert (id_rol,id_modulopagina,estado,usuario_aud,fechacreacion,codigoaccion,codigo_tg,agregar,guardar,eliminar,comentar,imprimir,cancelar)
values (s.id_rol,s.id_modulopagina,1,'JBALCAZAR',sysdate,NULL,NULL,0,0,0,0,0,0);

merge into data.t_admi_rolusuario t
using (select 5 id_rol from dual) s
on (t.id_rol=s.id_rol and t.codigomodulo='CNTR' and t.codigocompania='00001' and t.codigousuario='MRGUILLCA' and t.estado=1)
when not matched then insert (id_rol,codigomodulo,codigocompania,codigousuario,estado,usuario_aud,fechacreacion)
values (s.id_rol,'CNTR','00001','MRGUILLCA',1,'JBALCAZAR',sysdate);
