prompt -- C.13: una persona puede estar vinculada una sola vez a cada empresa
declare
    cursor c_duplicados is
        select id_empresa, id_persona, id_empresa_persona,
               row_number() over (
                   partition by id_empresa, id_persona
                   order by fecha_creacion, id_empresa_persona
               ) rn
          from data.t_cntr_empresa_personas;
begin
    for r in c_duplicados loop
        if r.rn > 1 then
            delete from data.t_cntr_empresa_personas
             where id_empresa_persona = r.id_empresa_persona;
        end if;
    end loop;

    execute immediate 'alter table data.t_cntr_empresa_personas drop constraint t_cntr_empresa_personas_uk1';
    execute immediate 'alter table data.t_cntr_empresa_personas add constraint t_cntr_empresa_personas_uk1 unique (id_empresa, id_persona)';
end;
/
