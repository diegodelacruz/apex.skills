declare
    v_cabecera number;
begin
    for r in (select id_documento, tipo_sujeto, id_sujeto, min(id_evidencia) id_cabecera from data.t_cntr_evidencias group by id_documento, tipo_sujeto, id_sujeto) loop
        v_cabecera := r.id_cabecera;
        update files.t_apex_archivos a set a.id_tabla=to_char(v_cabecera), a.tipo='EVIDENCIA_CNTR'
         where a.tabla='T_CNTR_EVIDENCIAS' and a.id_tabla in (select to_char(e.id_evidencia) from data.t_cntr_evidencias e where e.id_documento=r.id_documento and e.tipo_sujeto=r.tipo_sujeto and e.id_sujeto=r.id_sujeto);
        update data.t_cntr_rpa_ejecuciones_detalle d set d.id_evidencia=v_cabecera
         where d.id_evidencia in (select e.id_evidencia from data.t_cntr_evidencias e where e.id_documento=r.id_documento and e.tipo_sujeto=r.tipo_sujeto and e.id_sujeto=r.id_sujeto);
    end loop;
    update data.t_cntr_evidencias set id_evidencia_anterior=null;
    delete from data.t_cntr_evidencias e where e.id_evidencia <> (select min(x.id_evidencia) from data.t_cntr_evidencias x where x.id_documento=e.id_documento and x.tipo_sujeto=e.tipo_sujeto and x.id_sujeto=e.id_sujeto);
    merge into files.t_apex_archivos a using (select numeroarchivo,row_number() over(partition by tabla,id_tabla,tipo order by fecha desc nulls last,numeroarchivo desc) rn from files.t_apex_archivos where tabla='T_CNTR_EVIDENCIAS' and tipo='EVIDENCIA_CNTR') v on(v.numeroarchivo=a.numeroarchivo)
    when matched then update set a.estado=case when v.rn=1 then 'ACTIVO' else 'REEMPLAZADO' end;
end;
/
alter table data.t_cntr_rpa_ejecuciones_detalle add (id_empresa_origen number);
alter table data.t_cntr_rpa_ejecuciones_detalle add constraint t_cntr_rpa_ejec_det_fk4 foreign key (id_empresa_origen) references data.t_cntr_empresas(id_empresa);
alter table data.t_cntr_evidencias drop constraint t_cntr_evidencias_fk1;
alter table data.t_cntr_evidencias drop constraint t_cntr_evidencias_fk2;
alter table data.t_cntr_evidencias drop constraint t_cntr_evidencias_fk3;
alter table data.t_cntr_evidencias drop constraint t_cntr_evidencias_ck1;
alter table data.t_cntr_evidencias drop constraint t_cntr_evidencias_ck2;
alter table data.t_cntr_evidencias drop constraint t_cntr_evidencias_ck3;
drop index data.t_cntr_evidencias_uk1;
alter table data.t_cntr_evidencias drop (id_ejecucion_detalle,numeroarchivo,origen,fecha_obtencion,hash_sha256,numero_version,es_vigente,id_evidencia_anterior,estado);
alter table data.t_cntr_evidencias add constraint t_cntr_evidencias_fk1 foreign key (id_documento) references data.t_cntr_documentos(id_documento);
alter table data.t_cntr_evidencias add constraint t_cntr_evidencias_ck1 check (tipo_sujeto in ('PERSONA','EMPRESA'));
create unique index data.t_cntr_evidencias_uk1 on data.t_cntr_evidencias (id_documento,tipo_sujeto,id_sujeto);
