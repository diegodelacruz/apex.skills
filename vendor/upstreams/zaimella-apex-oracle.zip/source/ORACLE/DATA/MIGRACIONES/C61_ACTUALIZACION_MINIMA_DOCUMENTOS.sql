declare
    l_count number;
begin
    select count(*)
      into l_count
      from all_tab_columns
     where owner = 'DATA'
       and table_name = 'T_CNTR_DOCUMENTOS'
       and column_name = 'ACTUALIZACION_MINIMA_DIAS';

    if l_count = 0 then
        execute immediate 'alter table data.t_cntr_documentos add (actualizacion_minima_dias number)';
    end if;

    select count(*)
      into l_count
      from all_constraints
     where owner = 'DATA'
       and table_name = 'T_CNTR_DOCUMENTOS'
       and constraint_name = 'T_CNTR_DOCUMENTOS_CK3';

    if l_count = 0 then
        execute immediate q'[alter table data.t_cntr_documentos add constraint t_cntr_documentos_ck3 check (actualizacion_minima_dias is null or actualizacion_minima_dias >= 0)]';
    end if;
end;
/

comment on column data.t_cntr_documentos.actualizacion_minima_dias is
    'Cantidad opcional de dias durante los que una evidencia vigente reciente excluye una nueva consulta RPA.';
