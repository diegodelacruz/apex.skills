-- Generado por apex_menu_access_tool.py. Ejecutar solo para TEST y versionar en el deploy de la tarea.
merge into data.t_admi_modulopagina t
using (select 'BACK' codigomodulo, 'BACKCN320' codigopagina from dual) s
on (t.codigomodulo=s.codigomodulo and t.codigopagina=s.codigopagina)
when matched then update set t.descripcion='Matriz documental', t.orden=20, t.rutapagina='320', t.estado=1, t.usuario_aud='JBALCAZAR', t.fechamodificacion=sysdate, t.opcionmenu='Matriz documental', t.iconocss='fa-table', t.codigopadre='BACKCNTR2', t.nivel=3
when not matched then insert (codigopagina,codigomodulo,descripcion,orden,rutapagina,estado,usuario_aud,fechacreacion,opcionmenu,iconocss,codigopadre,nivel)
values ('BACKCN320','BACK','Matriz documental',20,'320',1,'JBALCAZAR',sysdate,'Matriz documental','fa-table','BACKCNTR2',3);

merge into data.t_admi_rolaccesos t
using (select 10 id_rol, p.id id_modulopagina from data.t_admi_modulopagina p where p.codigomodulo='BACK' and p.codigopagina='BACKCN320') s
on (t.id_rol=s.id_rol and t.id_modulopagina=s.id_modulopagina and nvl(t.codigoaccion,'~')=nvl(NULL,'~') and nvl(t.codigo_tg,'~')=nvl(NULL,'~'))
when matched then update set t.estado=1, t.usuario_aud='JBALCAZAR', t.fechamodificacion=sysdate, t.agregar=1, t.guardar=1, t.eliminar=1, t.comentar=1, t.imprimir=1, t.cancelar=1
when not matched then insert (id_rol,id_modulopagina,estado,usuario_aud,fechacreacion,codigoaccion,codigo_tg,agregar,guardar,eliminar,comentar,imprimir,cancelar)
values (s.id_rol,s.id_modulopagina,1,'JBALCAZAR',sysdate,NULL,NULL,1,1,1,1,1,1);

