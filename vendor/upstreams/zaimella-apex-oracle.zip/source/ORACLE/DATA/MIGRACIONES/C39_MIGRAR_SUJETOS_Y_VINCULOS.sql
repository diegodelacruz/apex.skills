-- C.39 - Migra sujetos y vínculos CNTR desde ZAITEST a Producción.
-- Excluye de forma explícita cualquier dato de prueba marcado con QA.
merge into data.t_cntr_empresas destino
using (
  select e.compania, e.ruc, e.razon_social, e.nombre_comercial,
         case when upper(trim(e.tipo_empresa)) in ('EXTRANJERA','EXTERIOR') then 'EXTERIOR'
              else upper(trim(e.tipo_empresa)) end tipo_empresa,
         e.estado
    from data.t_cntr_empresas@zaides e
   where upper(e.ruc || ' ' || e.razon_social || ' ' || nvl(e.nombre_comercial,'~')) not like '%QA%'
) fuente
on (destino.compania=fuente.compania and destino.ruc=fuente.ruc)
when matched then update set destino.razon_social=fuente.razon_social,
  destino.nombre_comercial=fuente.nombre_comercial, destino.tipo_empresa=fuente.tipo_empresa,
  destino.estado=fuente.estado, destino.fecha_actualizacion=systimestamp,
  destino.usuario_actualizacion='JBALCAZAR'
when not matched then insert (compania,ruc,razon_social,nombre_comercial,tipo_empresa,estado)
  values (fuente.compania,fuente.ruc,fuente.razon_social,fuente.nombre_comercial,fuente.tipo_empresa,fuente.estado);

merge into data.t_cntr_personas destino
using (
  select p.compania,p.tipo_identificacion,p.identificacion,p.nombres,p.correo,p.telefono,p.estado
    from data.t_cntr_personas@zaides p
   where upper(p.identificacion || ' ' || p.nombres || ' ' || nvl(p.correo,'~')) not like '%QA%'
) fuente
on (destino.compania=fuente.compania and destino.tipo_identificacion=fuente.tipo_identificacion
    and destino.identificacion=fuente.identificacion)
when matched then update set destino.nombres=fuente.nombres,destino.correo=fuente.correo,
  destino.telefono=fuente.telefono,destino.estado=fuente.estado,
  destino.fecha_actualizacion=systimestamp,destino.usuario_actualizacion='JBALCAZAR'
when not matched then insert (compania,tipo_identificacion,identificacion,nombres,correo,telefono,estado)
  values (fuente.compania,fuente.tipo_identificacion,fuente.identificacion,fuente.nombres,fuente.correo,fuente.telefono,fuente.estado);

merge into data.t_cntr_empresa_personas destino
using (
  select empresa_destino.id_empresa, persona_destino.id_persona, vinculo.rol,
         vinculo.estado, vinculo.observacion
    from data.t_cntr_empresa_personas@zaides vinculo
    join data.t_cntr_empresas@zaides empresa_origen on empresa_origen.id_empresa=vinculo.id_empresa
    join data.t_cntr_personas@zaides persona_origen on persona_origen.id_persona=vinculo.id_persona
    join data.t_cntr_empresas empresa_destino on empresa_destino.compania=empresa_origen.compania
      and empresa_destino.ruc=empresa_origen.ruc
    join data.t_cntr_personas persona_destino on persona_destino.compania=persona_origen.compania
      and persona_destino.tipo_identificacion=persona_origen.tipo_identificacion
      and persona_destino.identificacion=persona_origen.identificacion
   where upper(empresa_origen.ruc || ' ' || empresa_origen.razon_social || ' ' || nvl(empresa_origen.nombre_comercial,'~') || ' '
               || persona_origen.identificacion || ' ' || persona_origen.nombres || ' ' || nvl(persona_origen.correo,'~')) not like '%QA%'
) fuente
on (destino.id_empresa=fuente.id_empresa and destino.id_persona=fuente.id_persona)
when matched then update set destino.rol=fuente.rol,destino.estado=fuente.estado,
  destino.observacion=fuente.observacion,destino.fecha_actualizacion=systimestamp,
  destino.usuario_actualizacion='JBALCAZAR'
when not matched then insert (id_empresa,id_persona,rol,estado,observacion)
  values (fuente.id_empresa,fuente.id_persona,fuente.rol,fuente.estado,fuente.observacion);

commit;
