-- Configuración técnica idempotente del primer documento ejecutable por motor declarativo.
merge into data.t_cntr_documento_pasos p
using (
    select 25 id_documento, 1 orden, 'NAVEGAR' tipo_accion,
           'https://www.iess.gob.ec/empleador-web/pages/morapatronal/certificadoCumplimientoPublico.jsf' selector_elemento,
           cast(null as varchar2(1000)) valor_entrada, 1 tiempo_espera_seg,
           'Abrir consulta pública IESS.' descripcion from dual
    union all
    select 25, 2, 'LLENAR', 'input[name="frmCertificadoCumplimiento:j_id9"]', '{{IDENTIFICACION}}', 0,
           'Ingresar RUC de la empresa.' from dual
    union all
    select 25, 3, 'DESCARGAR', 'input[name="frmCertificadoCumplimiento:j_id11"]', cast(null as varchar2(1000)), 0,
           'Descargar certificado público IESS.' from dual
) s
on (p.id_documento=s.id_documento and p.orden=s.orden)
when matched then update set
    p.tipo_accion=s.tipo_accion, p.selector_elemento=s.selector_elemento, p.valor_entrada=s.valor_entrada,
    p.tiempo_espera_seg=s.tiempo_espera_seg, p.requiere_intervencion=0, p.descripcion=s.descripcion,
    p.fecha_actualizacion=systimestamp, p.usuario_actualizacion='DATA'
when not matched then insert (
    id_documento, orden, instruccion, tipo_accion, selector_elemento, valor_entrada,
    tiempo_espera_seg, requiere_intervencion, descripcion, estado, usuario_creacion
) values (
    s.id_documento, s.orden, s.descripcion, s.tipo_accion, s.selector_elemento, s.valor_entrada,
    s.tiempo_espera_seg, 0, s.descripcion, 'ACTIVO', 'DATA'
);
/
