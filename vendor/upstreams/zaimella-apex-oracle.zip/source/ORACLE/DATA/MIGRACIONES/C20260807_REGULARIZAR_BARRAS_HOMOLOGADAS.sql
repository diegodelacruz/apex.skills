-- CASE-20260807-005 - Regulariza codigos de barra en datos rezagados.
-- Ambiente inicial: TEST. Destino autorizado: DATA.
-- Alcance: solo T_TRAD_SELLOUT.CODIGOBARRA y T_TRAD_LECTURA_INCORRECTOS.CODIGOBARRA nulos.
-- No modifica CODIGOPRODUCTO, controles de archivo ni elimina pendientes.
-- Idempotencia: una ejecucion posterior no actualiza filas que ya tengan codigo de barra.

whenever sqlerror exit failure rollback
set serveroutput on

alter session set current_schema = DATA;

declare
    v_sellout_actualizado number := 0;
    v_lectura_actualizada number := 0;
begin
    -- Recorre solo homologaciones activas sin ambiguedad para habilitar acceso indexable
    -- por compania, grupo y producto cliente en las tablas objetivo.
    for r in (
        select h.compania,
               h.codigogrupo,
               h.codigoproductocliente,
               max(trim(h.codigobarra)) codigobarra
          from t_intc_homologacion h
         where h.estado = 1
           and nullif(trim(h.codigobarra), '') is not null
         group by h.compania,
                  h.codigogrupo,
                  h.codigoproductocliente
        having count(distinct trim(h.codigobarra)) = 1
    ) loop
        update t_trad_sellout s
           set s.codigobarra = r.codigobarra,
               s.usuariomodifica = 'CASE-20260807-005',
               s.fechamodifica = systimestamp
         where s.compania = r.compania
           and s.codigogrupo = r.codigogrupo
           and s.codigoproducto_cliente = r.codigoproductocliente
           and s.codigobarra is null;
        v_sellout_actualizado := v_sellout_actualizado + sql%rowcount;

        update t_trad_lectura_incorrectos l
           set l.codigobarra = r.codigobarra,
               l.usermodi = 'CASE-20260807-005',
               l.fechmodi = systimestamp
         where l.compania = r.compania
           and l.codigogrupo = r.codigogrupo
           and l.codigoproducto_cliente = r.codigoproductocliente
           and l.categoria = 'HOMOLOGACION'
           and l.codigobarra is null;
        v_lectura_actualizada := v_lectura_actualizada + sql%rowcount;
    end loop;

    dbms_output.put_line(
        'CASE-20260807-005: sellout con barra=' || v_sellout_actualizado ||
        ', pendientes con barra=' || v_lectura_actualizada
    );
end;
/

commit;
