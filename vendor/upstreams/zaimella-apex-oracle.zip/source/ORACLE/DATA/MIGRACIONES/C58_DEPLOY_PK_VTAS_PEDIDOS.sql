-- C58: ejecutor controlado del PACKAGE BODY en el esquema aplicativo.
ALTER SESSION SET CURRENT_SCHEMA = DATA;
@@../PAQUETES/BODIES/PK_VTAS_PEDIDOS.sql
