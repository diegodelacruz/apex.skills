-- CASE-51724. Pase productivo autorizado: paquete, saneamiento e índice.
@@../PAQUETES/BODIES/PK_TRAD_PEDIDOS.sql
@@CASE_51724_ELIMINAR_DUPLICADOS.sql
@@../INDICES/I_TRAD_PEDIDOSUGERIDO_UK1.sql
