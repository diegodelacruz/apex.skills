/* C.30 - Origen declarativo del valor resuelto por sujeto/empresa para RPA. */
declare
    v_existe number;
begin
    select count(*)
      into v_existe
      from all_tab_columns
     where owner = 'DATA'
       and table_name = 'T_CNTR_DOCUMENTO_PASOS'
       and column_name = 'ORIGEN_VALOR';

    if v_existe = 0 then
        execute immediate 'alter table data.t_cntr_documento_pasos add (origen_valor varchar2(30))';
        execute immediate q'[alter table data.t_cntr_documento_pasos add constraint t_cntr_documento_pasos_ck4 check (origen_valor is null or origen_valor in ('IDENTIFICACION', 'NOMBRES', 'CORREO', 'RAZON_SOCIAL', 'NOMBRE_COMERCIAL'))]';
    end if;
end;
/
