-- CASE-51724: solo lectura. La regla autorizada conserva el primer pedido
-- confirmado por compañía, PDV y fecha de visita.
SELECT id_pedido,
       id_conservado,
       compania,
       codigopdv,
       fechavisita,
       fechacreacion,
       usuario
  FROM (
      SELECT h.id_pedido,
             FIRST_VALUE(h.id_pedido) OVER (
                 PARTITION BY h.compania, h.codigopdv, h.fechavisita
                 ORDER BY h.fechacreacion, h.id_pedido
             ) AS id_conservado,
             h.compania,
             h.codigopdv,
             h.fechavisita,
             h.fechacreacion,
             h.usuario,
             ROW_NUMBER() OVER (
                 PARTITION BY h.compania, h.codigopdv, h.fechavisita
                 ORDER BY h.fechacreacion, h.id_pedido
             ) AS orden
        FROM data.t_trad_pedidosugerido h
       WHERE h.confirmado = 1
  )
 WHERE orden > 1
 ORDER BY compania, codigopdv, fechavisita, id_pedido;
