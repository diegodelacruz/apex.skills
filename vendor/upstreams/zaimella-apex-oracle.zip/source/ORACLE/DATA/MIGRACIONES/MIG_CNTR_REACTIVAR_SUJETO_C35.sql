update data.t_cntr_config_sujetos cs
   set cs.estado = 'ACTIVO',
       cs.fecha_actualizacion = systimestamp,
       cs.usuario_actualizacion = nvl(sys_context('APEX$SESSION','APP_USER'), user)
 where cs.tipo_sujeto = 'PERSONA'
   and exists (
       select 1
         from data.t_cntr_configuraciones c
        where c.id_configuracion = cs.id_configuracion
          and c.nombre = 'C35 PILOTO RPA PRODUCCION'
   )
   and exists (
       select 1
         from data.t_cntr_personas p
        where p.id_persona = cs.id_sujeto
          and p.identificacion = '1710008366'
          and p.estado = 'ACTIVO'
   );
commit;
