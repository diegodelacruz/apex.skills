prompt C49 - Ampliar catalogos de bitacora para cargas por configuracion

begin
    begin
        execute immediate 'alter table data.t_cntr_cargas drop constraint t_cntr_cargas_ck1';
    exception
        when others then
            if sqlcode != -2443 then
                raise;
            end if;
    end;

    execute immediate q'[
        alter table data.t_cntr_cargas add constraint t_cntr_cargas_ck1
        check (tipo_carga in ('PERSONAS', 'VINCULOS', 'CONFIG_SUJETOS', 'CONFIG_EMPRESA_SUJETOS'))
    ]';

    begin
        execute immediate 'alter table data.t_cntr_carga_detalles drop constraint t_cntr_carga_detalles_ck1';
    exception
        when others then
            if sqlcode != -2443 then
                raise;
            end if;
    end;

    execute immediate q'[
        alter table data.t_cntr_carga_detalles add constraint t_cntr_carga_detalles_ck1
        check (accion in ('CREADO', 'ACTUALIZADO', 'ASOCIADO', 'RECHAZADO'))
    ]';
end;
/
