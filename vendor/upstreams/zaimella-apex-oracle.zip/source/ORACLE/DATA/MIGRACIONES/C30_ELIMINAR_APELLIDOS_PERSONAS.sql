/*
  C.30 - Elimina la representacion duplicada de apellidos.
  NOMBRES conserva el nombre completo del sujeto.
*/
declare
    v_existe number;
begin
    select count(*)
      into v_existe
      from all_tab_columns
     where owner = 'DATA'
       and table_name = 'T_CNTR_PERSONAS'
       and column_name = 'APELLIDOS';

    if v_existe > 0 then
        execute immediate 'alter table data.t_cntr_personas drop column apellidos';
    end if;
end;
/
