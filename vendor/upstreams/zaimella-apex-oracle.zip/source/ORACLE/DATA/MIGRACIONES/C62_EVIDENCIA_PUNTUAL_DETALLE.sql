-- C.62: conserva el archivo exacto generado por cada detalle de ejecución.
declare
    l_existe number;
begin
    select count(*) into l_existe
      from all_tab_columns
     where owner = 'DATA'
       and table_name = 'T_CNTR_RPA_EJECUCIONES_DETALLE'
       and column_name = 'NUMEROARCHIVO_EVIDENCIA';
    if l_existe = 0 then
        execute immediate 'alter table data.t_cntr_rpa_ejecuciones_detalle add (numeroarchivo_evidencia number)';
    end if;
end;
/

comment on column data.t_cntr_rpa_ejecuciones_detalle.numeroarchivo_evidencia is 'Archivo FILES exacto capturado por este detalle; conserva la trazabilidad aun cuando existan versiones posteriores.';

-- Recupera solo históricos cuya observación fue emitida por PK_CNTR_RPA con el identificador de detalle.
merge into data.t_cntr_rpa_ejecuciones_detalle d
using (
    select to_number(regexp_substr(a.observacion, '(^|;)[[:space:]]*Detalle=([0-9]+)', 1, 1, null, 2)) id_detalle,
           max(a.numeroarchivo) keep (dense_rank last order by a.fecha nulls last, a.numeroarchivo) numeroarchivo
      from files.t_apex_archivos a
     where a.tabla = 'T_CNTR_EVIDENCIAS'
       and a.tipo = 'EVIDENCIA_CNTR'
       and regexp_like(a.observacion, '(^|;)[[:space:]]*Detalle=[0-9]+')
     group by to_number(regexp_substr(a.observacion, '(^|;)[[:space:]]*Detalle=([0-9]+)', 1, 1, null, 2))
) origen
on (d.id_ejecucion_detalle = origen.id_detalle)
when matched then update set d.numeroarchivo_evidencia = origen.numeroarchivo
 where d.numeroarchivo_evidencia is null;

-- Un PDF truncado nunca debe conservar un resultado exitoso ni quedar disponible para descarga puntual.
update data.t_cntr_rpa_ejecuciones_detalle d
   set estado = 'ERROR',
       tipo_error = 'EVIDENCIA_INVALIDA',
       mensaje = 'La evidencia PDF almacenada no tiene una estructura válida.',
       numeroarchivo_evidencia = null,
       fecha_fin = nvl(fecha_fin, systimestamp)
 where d.estado = 'COMPLETADO'
   and d.numeroarchivo_evidencia is not null
   and exists (
       select 1
         from files.t_apex_archivos a
        where a.numeroarchivo = d.numeroarchivo_evidencia
          and a.tabla = 'T_CNTR_EVIDENCIAS'
          and a.id_tabla = to_char(d.id_evidencia)
          and a.tipo = 'EVIDENCIA_CNTR'
          and lower(a.mimetype) = 'application/pdf'
          and (dbms_lob.getlength(a.blobcontent) < 100
               or dbms_lob.instr(a.blobcontent, utl_raw.cast_to_raw('startxref'), 1, 1) = 0
               or instr(rawtohex(dbms_lob.substr(a.blobcontent, least(1000, dbms_lob.getlength(a.blobcontent)), greatest(1, dbms_lob.getlength(a.blobcontent) - 999))), '2525454F46') = 0)
   );
