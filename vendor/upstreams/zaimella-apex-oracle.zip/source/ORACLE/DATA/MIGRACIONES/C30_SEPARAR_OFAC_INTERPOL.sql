/*
  C.30 - Separa el registro historico OFAC / INTERPOL segun CONSULTAS.xlsx.
  Conserva el identificador existente para OFAC y agrega INTERPOL a las mismas
  configuraciones activas, evitando duplicados en ejecuciones repetidas.
*/
declare
    v_id_ofac_portal number;
    v_id_ofac_documento number;
    v_id_interpol_portal number;
    v_id_interpol_documento number;
    v_id_paso number;
begin
    begin
        select id_portal
          into v_id_ofac_portal
          from data.t_cntr_portales
         where compania = '00001'
           and nombre_portal = 'OFAC';
    exception
        when no_data_found then
            select id_portal
              into v_id_ofac_portal
              from data.t_cntr_portales
             where compania = '00001'
               and nombre_portal = 'OFAC / INTERPOL';
    end;

    data.pk_cntr_configuracion.guardar_portal(
        p_id_portal => v_id_ofac_portal,
        p_compania => '00001',
        p_nombre_portal => 'OFAC',
        p_url_base => 'https://sanctionssearch.ofac.treas.gov/',
        p_descripcion => 'Fuente CONSULTAS.xlsx. Captura de pantalla.',
        p_requiere_captcha => 0,
        p_requiere_login => 0,
        p_estado => 'ACTIVO'
    );

    begin
        select id_documento
          into v_id_ofac_documento
          from data.t_cntr_documentos
         where id_portal = v_id_ofac_portal
           and nombre_documento = 'Consulta documental - OFAC';
    exception
        when no_data_found then
            select id_documento
              into v_id_ofac_documento
              from data.t_cntr_documentos
             where id_portal = v_id_ofac_portal
               and nombre_documento = 'Consulta documental - OFAC / INTERPOL';
    end;

    data.pk_cntr_configuracion.guardar_documento(
        p_id_documento => v_id_ofac_documento,
        p_id_portal => v_id_ofac_portal,
        p_compania => '00001',
        p_nombre_documento => 'Consulta documental - OFAC',
        p_evidencia_esperada => 'Captura de pantalla',
        p_modo_captura => 'AUTOMATICO',
        p_dato_busqueda => 'Segun instruccion',
        p_estado => 'ACTIVO'
    );

    begin
        select id_paso
          into v_id_paso
          from data.t_cntr_documento_pasos
         where id_documento = v_id_ofac_documento
           and orden = 1;
    exception
        when no_data_found then
            v_id_paso := null;
    end;

    data.pk_cntr_configuracion.guardar_paso(
        p_id_paso => v_id_paso,
        p_id_documento => v_id_ofac_documento,
        p_orden => 1,
        p_instruccion => 'Consultar el sujeto en OFAC y guardar la captura de pantalla del resultado.',
        p_valor_entrada => null,
        p_requiere_intervencion => 0,
        p_estado => 'ACTIVO'
    );

    begin
        select id_portal
          into v_id_interpol_portal
          from data.t_cntr_portales
         where compania = '00001'
           and nombre_portal = 'INTERPOL';
    exception
        when no_data_found then
            v_id_interpol_portal := null;
    end;

    data.pk_cntr_configuracion.guardar_portal(
        p_id_portal => v_id_interpol_portal,
        p_compania => '00001',
        p_nombre_portal => 'INTERPOL',
        p_url_base => 'https://www.interpol.int/es/Como-trabajamos/Notificaciones/Notificaciones-rojas/Ver-las-notificaciones-rojas',
        p_descripcion => 'Fuente CONSULTAS.xlsx. Captura de pantalla.',
        p_requiere_captcha => 0,
        p_requiere_login => 0,
        p_estado => 'ACTIVO'
    );

    begin
        select id_documento
          into v_id_interpol_documento
          from data.t_cntr_documentos
         where id_portal = v_id_interpol_portal
           and nombre_documento = 'Consulta documental - INTERPOL';
    exception
        when no_data_found then
            v_id_interpol_documento := null;
    end;

    data.pk_cntr_configuracion.guardar_documento(
        p_id_documento => v_id_interpol_documento,
        p_id_portal => v_id_interpol_portal,
        p_compania => '00001',
        p_nombre_documento => 'Consulta documental - INTERPOL',
        p_evidencia_esperada => 'Captura de pantalla',
        p_modo_captura => 'AUTOMATICO',
        p_dato_busqueda => 'Segun instruccion',
        p_estado => 'ACTIVO'
    );

    begin
        select id_paso
          into v_id_paso
          from data.t_cntr_documento_pasos
         where id_documento = v_id_interpol_documento
           and orden = 1;
    exception
        when no_data_found then
            v_id_paso := null;
    end;

    data.pk_cntr_configuracion.guardar_paso(
        p_id_paso => v_id_paso,
        p_id_documento => v_id_interpol_documento,
        p_orden => 1,
        p_instruccion => 'Consultar el sujeto en INTERPOL y guardar la captura de pantalla del resultado.',
        p_valor_entrada => null,
        p_requiere_intervencion => 0,
        p_estado => 'ACTIVO'
    );

    merge into data.t_cntr_config_documentos destino
    using (
        select id_configuracion, v_id_interpol_documento id_documento, estado
          from data.t_cntr_config_documentos
         where id_documento = v_id_ofac_documento
    ) origen
       on (destino.id_configuracion = origen.id_configuracion
           and destino.id_documento = origen.id_documento)
    when not matched then
        insert (id_configuracion, id_documento, estado)
        values (origen.id_configuracion, origen.id_documento, origen.estado);
end;
/
