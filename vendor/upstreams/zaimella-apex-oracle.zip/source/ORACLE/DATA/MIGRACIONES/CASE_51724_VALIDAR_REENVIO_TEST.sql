ALTER SESSION SET CURRENT_SCHEMA = DATA;

DECLARE
    l_pdv CONSTANT VARCHAR2(100) := 'CASE51724-TEST';
    l_fecha CONSTANT VARCHAR2(10) := '13/08/2026';
    l_total NUMBER;
    l_json CLOB := q'~{
      "usuario":"CASE51724",
      "compania":"00001",
      "pedidos":[{
        "codigopdv":"CASE51724-TEST",
        "fecha_visita":"13/08/2026",
        "observaciones":"Prueba temporal CASE-51724",
        "confirmado":"true",
        "pedido_sugerido":[{
          "sku":"CASE51724-PRODUCTO",
          "descripcion":"Prueba temporal",
          "codigobarra":"CASE51724-BARRA",
          "cantidad_sugerida":1,
          "inventario":0,
          "cantidad_a_pedir":1,
          "justificacion":""
        }]
      }]
    }~';
BEGIN
    DELETE FROM data.t_trad_pedidosugeridodet
     WHERE id_pedido IN (
         SELECT id_pedido
           FROM data.t_trad_pedidosugerido
          WHERE compania = '00001'
            AND codigopdv = l_pdv
            AND fechavisita = TO_DATE(l_fecha, 'DD/MM/YYYY')
     );
    DELETE FROM data.t_trad_pedidosugerido
     WHERE compania = '00001'
       AND codigopdv = l_pdv
       AND fechavisita = TO_DATE(l_fecha, 'DD/MM/YYYY');

    data.pk_trad_pedidos.sp_registrarpedidosugerido(l_json, NULL);
    data.pk_trad_pedidos.sp_registrarpedidosugerido(l_json, NULL);

    SELECT COUNT(*)
      INTO l_total
      FROM data.t_trad_pedidosugerido
     WHERE compania = '00001'
       AND codigopdv = l_pdv
       AND fechavisita = TO_DATE(l_fecha, 'DD/MM/YYYY')
       AND confirmado = 1;

    IF l_total <> 1 THEN
        RAISE_APPLICATION_ERROR(-20051, 'CASE-51724 esperaba una cabecera y obtuvo ' || l_total);
    END IF;

    DELETE FROM data.t_trad_pedidosugeridodet
     WHERE id_pedido IN (
         SELECT id_pedido
           FROM data.t_trad_pedidosugerido
          WHERE compania = '00001'
            AND codigopdv = l_pdv
            AND fechavisita = TO_DATE(l_fecha, 'DD/MM/YYYY')
     );
    DELETE FROM data.t_trad_pedidosugerido
     WHERE compania = '00001'
       AND codigopdv = l_pdv
       AND fechavisita = TO_DATE(l_fecha, 'DD/MM/YYYY');
    COMMIT;
END;
/
