-- CASE-51724: ejecutar solo en el ambiente autorizado, después de revisar 01.
-- Regla autorizada: conservar el primer pedido confirmado por compañía, PDV y fecha.
CREATE TABLE data.bkp_trad_pedidosug_51724 AS
SELECT h.*
  FROM data.t_trad_pedidosugerido h
 WHERE h.id_pedido IN (
     SELECT id_pedido
       FROM (
           SELECT h2.id_pedido,
                  ROW_NUMBER() OVER (
                      PARTITION BY h2.compania, h2.codigopdv, h2.fechavisita
                      ORDER BY h2.fechacreacion, h2.id_pedido
                  ) AS orden
             FROM data.t_trad_pedidosugerido h2
            WHERE h2.confirmado = 1
       )
      WHERE orden > 1
 );

CREATE TABLE data.bkp_trad_pedidosugdet_51724 AS
SELECT d.*
  FROM data.t_trad_pedidosugeridodet d
 WHERE d.id_pedido IN (SELECT id_pedido FROM data.bkp_trad_pedidosug_51724);

DELETE FROM data.t_trad_pedidosugeridodet
 WHERE id_pedido IN (SELECT id_pedido FROM data.bkp_trad_pedidosug_51724);

DELETE FROM data.t_trad_pedidosugerido
 WHERE id_pedido IN (SELECT id_pedido FROM data.bkp_trad_pedidosug_51724);

COMMIT;
