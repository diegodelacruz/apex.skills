merge into data.t_corp_udc destino
using (
    select 'CNTRIAAPI' id_cabecera,
           'URL_EJECUTAR' descripcion,
           'http://172.17.6.135:8095/api/v1' valor
      from dual
) fuente
on (destino.id_cabecera = fuente.id_cabecera and destino.descripcion = fuente.descripcion)
when matched then update set destino.valor = fuente.valor, destino.activo = 1
when not matched then insert (
    id,id_cabecera,id_tabla,descripcion,valor,activo
) values (
    data.pk_commons.f_secuencia('T_CORP_UDC'),fuente.id_cabecera,1,fuente.descripcion,fuente.valor,1
);
/
