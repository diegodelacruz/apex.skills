declare
    v_usuario varchar2(100) := nvl(sys_context('APEX$SESSION','APP_USER'), user);
begin
    for r in (
        select cs.id_config_sujeto,
               cs.id_configuracion,
               cs.id_sujeto id_empresa
          from data.t_cntr_config_sujetos cs
         where cs.tipo_sujeto = 'EMPRESA'
           and cs.estado = 'ACTIVO'
    ) loop
        merge into data.t_cntr_config_empresas d
        using (select r.id_configuracion id_configuracion, r.id_empresa id_empresa from dual) s
           on (d.id_configuracion = s.id_configuracion and d.id_empresa = s.id_empresa)
        when matched then update
             set d.incluir_todos = 'S',
                 d.estado = 'ACTIVO',
                 d.fecha_actualizacion = systimestamp,
                 d.usuario_actualizacion = v_usuario
        when not matched then insert (
             id_configuracion, id_empresa, incluir_todos, estado, usuario_creacion
        ) values (
             s.id_configuracion, s.id_empresa, 'S', 'ACTIVO', v_usuario
        );

        update data.t_cntr_config_sujetos
           set estado = 'INACTIVO',
               fecha_actualizacion = systimestamp,
               usuario_actualizacion = v_usuario
         where id_config_sujeto = r.id_config_sujeto;
    end loop;
    commit;
end;
/
