prompt ============================================================
prompt C.6 - Menu y acceso Matricula de Sujetos
prompt Ambiente origen: TEST
prompt Esquema: DATA
prompt Responsable: JBALCAZAR
prompt ============================================================

declare
    v_id_contraloria number;
    v_id_configuracion number;
    v_id_matricula number;
begin
    merge into data.t_admi_modulopagina destino
    using (
        select 'BACKCNTR0' codigopagina,
               'BACK' codigomodulo,
               'Contraloria' descripcion,
               20 orden,
               null rutapagina,
               'Contraloria' opcionmenu,
               'fa-balance-scale' iconocss,
               null codigopadre,
               1 nivel
          from dual
    ) fuente
    on (destino.codigopagina = fuente.codigopagina and destino.codigomodulo = fuente.codigomodulo)
    when matched then update set
        destino.descripcion = fuente.descripcion,
        destino.orden = fuente.orden,
        destino.rutapagina = fuente.rutapagina,
        destino.estado = 1,
        destino.usuario_aud = 'JBALCAZAR',
        destino.fechamodificacion = sysdate,
        destino.opcionmenu = fuente.opcionmenu,
        destino.iconocss = fuente.iconocss,
        destino.codigopadre = fuente.codigopadre,
        destino.nivel = fuente.nivel
    when not matched then insert (
        id, codigopagina, codigomodulo, descripcion, orden, rutapagina, estado,
        usuario_aud, fechacreacion, opcionmenu, iconocss, codigopadre, nivel
    ) values (
        data.sq_admi_modulopagina.nextval, fuente.codigopagina, fuente.codigomodulo,
        fuente.descripcion, fuente.orden, fuente.rutapagina, 1, 'JBALCAZAR',
        sysdate, fuente.opcionmenu, fuente.iconocss, fuente.codigopadre, fuente.nivel
    );

    merge into data.t_admi_modulopagina destino
    using (
        select 'BACKCNTR1' codigopagina,
               'BACK' codigomodulo,
               'Configuracion' descripcion,
               1 orden,
               null rutapagina,
               'Configuracion' opcionmenu,
               'fa-gear' iconocss,
               'BACKCNTR0' codigopadre,
               2 nivel
          from dual
    ) fuente
    on (destino.codigopagina = fuente.codigopagina and destino.codigomodulo = fuente.codigomodulo)
    when matched then update set
        destino.descripcion = fuente.descripcion,
        destino.orden = fuente.orden,
        destino.rutapagina = fuente.rutapagina,
        destino.estado = 1,
        destino.usuario_aud = 'JBALCAZAR',
        destino.fechamodificacion = sysdate,
        destino.opcionmenu = fuente.opcionmenu,
        destino.iconocss = fuente.iconocss,
        destino.codigopadre = fuente.codigopadre,
        destino.nivel = fuente.nivel
    when not matched then insert (
        id, codigopagina, codigomodulo, descripcion, orden, rutapagina, estado,
        usuario_aud, fechacreacion, opcionmenu, iconocss, codigopadre, nivel
    ) values (
        data.sq_admi_modulopagina.nextval, fuente.codigopagina, fuente.codigomodulo,
        fuente.descripcion, fuente.orden, fuente.rutapagina, 1, 'JBALCAZAR',
        sysdate, fuente.opcionmenu, fuente.iconocss, fuente.codigopadre, fuente.nivel
    );

    merge into data.t_admi_modulopagina destino
    using (
        select 'BACKCN307' codigopagina,
               'BACK' codigomodulo,
               'Matricula de Sujetos' descripcion,
               2 orden,
               '307' rutapagina,
               'Matricula de Sujetos' opcionmenu,
               'fa-users' iconocss,
               'BACKCNTR1' codigopadre,
               3 nivel
          from dual
    ) fuente
    on (destino.codigopagina = fuente.codigopagina and destino.codigomodulo = fuente.codigomodulo)
    when matched then update set
        destino.descripcion = fuente.descripcion,
        destino.orden = fuente.orden,
        destino.rutapagina = fuente.rutapagina,
        destino.estado = 1,
        destino.usuario_aud = 'JBALCAZAR',
        destino.fechamodificacion = sysdate,
        destino.opcionmenu = fuente.opcionmenu,
        destino.iconocss = fuente.iconocss,
        destino.codigopadre = fuente.codigopadre,
        destino.nivel = fuente.nivel
    when not matched then insert (
        id, codigopagina, codigomodulo, descripcion, orden, rutapagina, estado,
        usuario_aud, fechacreacion, opcionmenu, iconocss, codigopadre, nivel
    ) values (
        data.sq_admi_modulopagina.nextval, fuente.codigopagina, fuente.codigomodulo,
        fuente.descripcion, fuente.orden, fuente.rutapagina, 1, 'JBALCAZAR',
        sysdate, fuente.opcionmenu, fuente.iconocss, fuente.codigopadre, fuente.nivel
    );

    select id into v_id_contraloria
      from data.t_admi_modulopagina
     where codigomodulo = 'BACK'
       and codigopagina = 'BACKCNTR0';

    select id into v_id_configuracion
      from data.t_admi_modulopagina
     where codigomodulo = 'BACK'
       and codigopagina = 'BACKCNTR1';

    select id into v_id_matricula
      from data.t_admi_modulopagina
     where codigomodulo = 'BACK'
       and codigopagina = 'BACKCN307';

    merge into data.t_admi_rolusuario destino
    using (
        select 1 id_rol,
               'BACK' codigomodulo,
               '00001' codigocompania,
               'JBALCAZAR' codigousuario
          from dual
    ) fuente
    on (
        destino.id_rol = fuente.id_rol
        and destino.codigomodulo = fuente.codigomodulo
        and destino.codigocompania = fuente.codigocompania
        and destino.codigousuario = fuente.codigousuario
        and destino.estado = 1
    )
    when matched then update set
        destino.usuario_aud = 'JBALCAZAR',
        destino.fechamodificacion = sysdate
    when not matched then insert (
        id, id_rol, codigomodulo, codigocompania, codigousuario, estado,
        usuario_aud, fechacreacion
    ) values (
        data.sq_admi_rolusuario.nextval, fuente.id_rol, fuente.codigomodulo,
        fuente.codigocompania, fuente.codigousuario, 1, 'JBALCAZAR', sysdate
    );

    for pagina in (
        select v_id_contraloria id_modulopagina from dual
        union all
        select v_id_configuracion from dual
        union all
        select v_id_matricula from dual
    ) loop
        merge into data.t_admi_rolaccesos destino
        using (
            select 1 id_rol,
                   pagina.id_modulopagina id_modulopagina
              from dual
        ) fuente
        on (
            destino.id_rol = fuente.id_rol
            and destino.id_modulopagina = fuente.id_modulopagina
            and nvl(destino.codigoaccion, '-') = '-'
            and nvl(destino.codigo_tg, '-') = '-'
        )
        when matched then update set
            destino.estado = 1,
            destino.usuario_aud = 'JBALCAZAR',
            destino.fechamodificacion = sysdate,
            destino.agregar = 1,
            destino.guardar = 1,
            destino.eliminar = 1,
            destino.comentar = 1,
            destino.imprimir = 1
        when not matched then insert (
            id, id_rol, id_modulopagina, estado, usuario_aud, fechacreacion,
            agregar, guardar, eliminar, comentar, imprimir
        ) values (
            data.sq_admi_rolaccesos.nextval, fuente.id_rol, fuente.id_modulopagina,
            1, 'JBALCAZAR', sysdate, 1, 1, 1, 1, 1
        );
    end loop;
end;
/
