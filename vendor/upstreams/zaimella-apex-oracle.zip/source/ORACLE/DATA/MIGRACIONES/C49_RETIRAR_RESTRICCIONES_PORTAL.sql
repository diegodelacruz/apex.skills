-- C.49: respaldo y retiro del atributo de portal sin consumidor funcional.
declare
    l_columnas number;
    l_respaldo number;
begin
    select count(*) into l_columnas
      from user_tab_columns
     where table_name = 'T_CNTR_PORTALES'
       and column_name = 'RESTRICCIONES';

    if l_columnas = 1 then
        select count(*) into l_respaldo
          from user_tables
         where table_name = 'T_CNTR_PORTALES_RESTRICCIONES_BKP';
        if l_respaldo = 0 then
            execute immediate q'[
                create table data.t_cntr_portales_restricciones_bkp as
                select id_portal, restricciones, systimestamp fecha_respaldo
                  from data.t_cntr_portales
            ]';
        end if;
        execute immediate 'alter table data.t_cntr_portales drop column restricciones';
    end if;
end;
/
