-- CASE-50999
-- Sincroniza las clasificaciones omitidas al migrar locales TRADE.
-- Requiere que la migracion de locales C50999_MIGRACION_LOCALES_TRAD.sql
-- ya se haya ejecutado con los rangos historicos de PRODUCCION/TEST.
-- Es idempotente: inserta clasificaciones faltantes y actualiza las existentes.

ALTER SESSION SET CURRENT_SCHEMA = DATA;

DECLARE
    c_origen_econofarm       CONSTANT NUMBER := 41203;
    c_destino_farcomed       CONSTANT NUMBER := 42672;
    c_origen_uscocovich      CONSTANT NUMBER := 145373;
    c_destino_farmamia       CONSTANT NUMBER := 128060;
    l_base_farcomed          NUMBER;
    l_base_farmamia          NUMBER;
    l_locales_econofarm      PLS_INTEGER;
    l_locales_uscocovich     PLS_INTEGER;
    l_locales_mapeados       PLS_INTEGER;
    l_clasificaciones_origen PLS_INTEGER;
    l_clasificaciones_destino PLS_INTEGER;

    /* Deriva el desplazamiento histórico: un único NUMERO destino por cada local origen y CODIGOLOCAL. */
    PROCEDURE obtener_bases_historicas IS
        l_candidatos_farcomed PLS_INTEGER;
        l_candidatos_farmamia PLS_INTEGER;
    BEGIN
        SELECT COUNT(*) INTO l_locales_econofarm FROM t_trad_clientelocal WHERE codigopdv = c_origen_econofarm;
        SELECT COUNT(*) INTO l_locales_uscocovich FROM t_trad_clientelocal WHERE codigopdv = c_origen_uscocovich;

        WITH origen AS (
            SELECT l.numero numero_origen, l.codigolocal,
                   ROW_NUMBER() OVER (ORDER BY l.numero) rn
              FROM t_trad_clientelocal l
             WHERE l.codigopdv = c_origen_econofarm
        ), candidatos AS (
            SELECT d.numero - o.rn base_numero, o.numero_origen
              FROM origen o
              JOIN t_trad_clientelocal d
                ON d.codigopdv = c_destino_farcomed
               AND NVL(d.codigolocal, CHR(0)) = NVL(o.codigolocal, CHR(0))
        )
        SELECT MIN(base_numero), COUNT(*)
          INTO l_base_farcomed, l_candidatos_farcomed
          FROM (SELECT base_numero FROM candidatos GROUP BY base_numero HAVING COUNT(DISTINCT numero_origen) = l_locales_econofarm);

        WITH origen AS (
            SELECT l.numero numero_origen, l.codigolocal,
                   ROW_NUMBER() OVER (ORDER BY l.numero) rn
              FROM t_trad_clientelocal l
             WHERE l.codigopdv = c_origen_uscocovich
        ), candidatos AS (
            SELECT d.numero - o.rn base_numero, o.numero_origen
              FROM origen o
              JOIN t_trad_clientelocal d
                ON d.codigopdv = c_destino_farmamia
               AND NVL(d.codigolocal, CHR(0)) = NVL(o.codigolocal, CHR(0))
        )
        SELECT MIN(base_numero), COUNT(*)
          INTO l_base_farmamia, l_candidatos_farmamia
          FROM (SELECT base_numero FROM candidatos GROUP BY base_numero HAVING COUNT(DISTINCT numero_origen) = l_locales_uscocovich);

        IF l_candidatos_farcomed <> 1 OR l_candidatos_farmamia <> 1 THEN
            RAISE_APPLICATION_ERROR(-20021, 'No existe una correspondencia histórica única de locales.');
        END IF;
    END obtener_bases_historicas;
BEGIN
    SAVEPOINT case_50999_clasificaciones;

    obtener_bases_historicas;

    SELECT COUNT(*)
      INTO l_clasificaciones_origen
      FROM t_trad_clientelocalclasifica c
     WHERE (c.codigopdv = c_origen_econofarm AND EXISTS (
                SELECT 1 FROM t_trad_clientelocal l
                 WHERE l.codigopdv = c_origen_econofarm AND l.numero = c.numero))
        OR (c.codigopdv = c_origen_uscocovich AND EXISTS (
                SELECT 1 FROM t_trad_clientelocal l
                 WHERE l.codigopdv = c_origen_uscocovich AND l.numero = c.numero));

    IF l_clasificaciones_origen = 0 THEN
        RAISE_APPLICATION_ERROR(-20022, 'No existen clasificaciones origen para sincronizar.');
    END IF;

    MERGE INTO t_trad_clientelocalclasifica d
    USING (
        WITH pares AS (
            SELECT c_origen_econofarm origen, c_destino_farcomed destino, l_base_farcomed base_numero FROM dual
            UNION ALL
            SELECT c_origen_uscocovich, c_destino_farmamia, l_base_farmamia FROM dual
        ), mapeo AS (
            SELECT p.origen,
                   p.destino,
                   l.numero numero_origen,
                   p.base_numero + ROW_NUMBER() OVER (PARTITION BY p.origen ORDER BY l.numero) numero_destino
              FROM pares p
              JOIN t_trad_clientelocal l ON l.codigopdv = p.origen
        )
        SELECT m.destino codigopdv,
               m.numero_destino numero,
               c.idclasificaciontipo,
               c.idclasificacion,
               c.estado,
               c.estadoflujo,
               c.fechainicio,
               c.usuariocrea,
               c.fechacrea
          FROM mapeo m
          JOIN t_trad_clientelocalclasifica c
            ON c.codigopdv = m.origen
           AND c.numero = m.numero_origen
    ) s
       ON (d.codigopdv = s.codigopdv
           AND d.numero = s.numero
           AND d.idclasificaciontipo = s.idclasificaciontipo)
    WHEN MATCHED THEN
        UPDATE SET d.idclasificacion = s.idclasificacion,
                   d.estado = s.estado,
                   d.estadoflujo = s.estadoflujo,
                   d.fechainicio = s.fechainicio,
                   d.usuariomodifica = USER,
                   d.fechamodifica = SYSDATE
         WHERE NVL(d.idclasificacion, CHR(0)) <> NVL(s.idclasificacion, CHR(0))
            OR NVL(d.estado, -1) <> NVL(s.estado, -1)
            OR NVL(d.estadoflujo, -1) <> NVL(s.estadoflujo, -1)
            OR NVL(d.fechainicio, CHR(0)) <> NVL(s.fechainicio, CHR(0))
    WHEN NOT MATCHED THEN
        INSERT (codigopdv, numero, idclasificaciontipo, idclasificacion,
                estado, estadoflujo, fechainicio, usuariocrea, fechacrea)
        VALUES (s.codigopdv, s.numero, s.idclasificaciontipo, s.idclasificacion,
                s.estado, s.estadoflujo, s.fechainicio, s.usuariocrea, s.fechacrea);

    SELECT COUNT(*)
      INTO l_clasificaciones_destino
      FROM (
            WITH pares AS (
                SELECT c_origen_econofarm origen, c_destino_farcomed destino, l_base_farcomed base_numero FROM dual
                UNION ALL
                SELECT c_origen_uscocovich, c_destino_farmamia, l_base_farmamia FROM dual
            ), mapeo AS (
                SELECT p.origen,
                       p.destino,
                       l.numero numero_origen,
                       p.base_numero + ROW_NUMBER() OVER (PARTITION BY p.origen ORDER BY l.numero) numero_destino
                  FROM pares p
                  JOIN t_trad_clientelocal l ON l.codigopdv = p.origen
            )
            SELECT 1
              FROM mapeo m
              JOIN t_trad_clientelocalclasifica o
                ON o.codigopdv = m.origen AND o.numero = m.numero_origen
              JOIN t_trad_clientelocalclasifica d
                ON d.codigopdv = m.destino
               AND d.numero = m.numero_destino
               AND d.idclasificaciontipo = o.idclasificaciontipo
               AND NVL(d.idclasificacion, CHR(0)) = NVL(o.idclasificacion, CHR(0))
               AND NVL(d.estado, -1) = NVL(o.estado, -1)
               AND NVL(d.estadoflujo, -1) = NVL(o.estadoflujo, -1)
               AND NVL(d.fechainicio, CHR(0)) = NVL(o.fechainicio, CHR(0))
           );

    IF l_clasificaciones_destino <> l_clasificaciones_origen THEN
        RAISE_APPLICATION_ERROR(-20023, 'Clasificaciones destino no reconciliadas: ' || l_clasificaciones_destino);
    END IF;

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK TO case_50999_clasificaciones;
        RAISE;
END;
/
