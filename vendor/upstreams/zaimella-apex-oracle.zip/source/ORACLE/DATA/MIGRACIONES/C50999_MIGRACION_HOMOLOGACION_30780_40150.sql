-- CASE-50999-HOMOLOGACION
-- Copia homologaciones INTC del grupo 30780 al grupo 40150.
-- La clave funcional es CODIGOPRODUCTOCLIENTE, CODIGOPRODUCTOZM y COMPANIA.
-- No modifica el origen ni las filas existentes equivalentes en destino.

ALTER SESSION SET CURRENT_SCHEMA = DATA;

DECLARE
    c_grupo_origen      CONSTANT VARCHAR2(5) := '30780';
    c_grupo_destino     CONSTANT VARCHAR2(5) := '40150';
    l_origen            PLS_INTEGER;
    l_duplicados_origen PLS_INTEGER;
    l_duplicados_destino PLS_INTEGER;
    l_faltantes         PLS_INTEGER;
    l_insertadas        PLS_INTEGER;
BEGIN
    SAVEPOINT case_50999_homologacion;

    SELECT COUNT(*)
      INTO l_origen
      FROM t_intc_homologacion
     WHERE codigogrupo = c_grupo_origen;

    IF l_origen = 0 THEN
        RAISE_APPLICATION_ERROR(-20031, 'No existen homologaciones en el grupo origen ' || c_grupo_origen);
    END IF;

    SELECT COUNT(*)
      INTO l_duplicados_origen
      FROM (
            SELECT codigoproductocliente, codigoproductozm, compania
              FROM t_intc_homologacion
             WHERE codigogrupo = c_grupo_origen
             GROUP BY codigoproductocliente, codigoproductozm, compania
            HAVING COUNT(*) > 1
           );

    SELECT COUNT(*)
      INTO l_duplicados_destino
      FROM (
            SELECT codigoproductocliente, codigoproductozm, compania
              FROM t_intc_homologacion
             WHERE codigogrupo = c_grupo_destino
             GROUP BY codigoproductocliente, codigoproductozm, compania
            HAVING COUNT(*) > 1
           );

    IF l_duplicados_origen <> 0 OR l_duplicados_destino <> 0 THEN
        RAISE_APPLICATION_ERROR(-20032, 'Existen claves funcionales duplicadas. Origen=' || l_duplicados_origen || ', destino=' || l_duplicados_destino);
    END IF;

    -- Si la clave ya existe, se conserva la fila destino. Esto evita repetirla o
    -- sobrescribir una homologación ya mantenida para el grupo 40150.

    SELECT COUNT(*)
      INTO l_faltantes
      FROM t_intc_homologacion o
     WHERE o.codigogrupo = c_grupo_origen
       AND NOT EXISTS (
            SELECT 1
              FROM t_intc_homologacion d
             WHERE d.codigogrupo = c_grupo_destino
               AND NVL(d.codigoproductocliente, CHR(0)) = NVL(o.codigoproductocliente, CHR(0))
               AND NVL(d.codigoproductozm, CHR(0)) = NVL(o.codigoproductozm, CHR(0))
               AND NVL(d.compania, CHR(0)) = NVL(o.compania, CHR(0))
       );

    INSERT INTO t_intc_homologacion (
        codigogrupo, codigoproductocliente, codigoproductozm, factor,
        estado, compania, factorinv, codigobarra, producto_cliente_nombre
    )
    SELECT c_grupo_destino, o.codigoproductocliente, o.codigoproductozm, o.factor,
           o.estado, o.compania, o.factorinv, o.codigobarra, o.producto_cliente_nombre
      FROM t_intc_homologacion o
     WHERE o.codigogrupo = c_grupo_origen
       AND NOT EXISTS (
            SELECT 1
              FROM t_intc_homologacion d
             WHERE d.codigogrupo = c_grupo_destino
               AND NVL(d.codigoproductocliente, CHR(0)) = NVL(o.codigoproductocliente, CHR(0))
               AND NVL(d.codigoproductozm, CHR(0)) = NVL(o.codigoproductozm, CHR(0))
               AND NVL(d.compania, CHR(0)) = NVL(o.compania, CHR(0))
       );

    l_insertadas := SQL%ROWCOUNT;

    IF l_insertadas <> l_faltantes THEN
        RAISE_APPLICATION_ERROR(-20034, 'Insertadas=' || l_insertadas || ', faltantes esperadas=' || l_faltantes);
    END IF;

    SELECT COUNT(*)
      INTO l_faltantes
      FROM t_intc_homologacion o
     WHERE o.codigogrupo = c_grupo_origen
       AND NOT EXISTS (
            SELECT 1
              FROM t_intc_homologacion d
             WHERE d.codigogrupo = c_grupo_destino
               AND NVL(d.codigoproductocliente, CHR(0)) = NVL(o.codigoproductocliente, CHR(0))
               AND NVL(d.codigoproductozm, CHR(0)) = NVL(o.codigoproductozm, CHR(0))
               AND NVL(d.compania, CHR(0)) = NVL(o.compania, CHR(0))
       );

    IF l_faltantes <> 0 THEN
        RAISE_APPLICATION_ERROR(-20035, 'Persisten homologaciones sin copiar: ' || l_faltantes);
    END IF;

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK TO case_50999_homologacion;
        RAISE;
END;
/
