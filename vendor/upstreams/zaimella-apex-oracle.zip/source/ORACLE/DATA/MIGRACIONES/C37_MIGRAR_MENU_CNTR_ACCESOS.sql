-- C.37 - Unifica el menú documental CNTR de APP 152.
-- Ejecutar con la credencial autorizada y CURRENT_SCHEMA=DATA.
-- Es idempotente: conserva el legado como inactivo y no elimina historial.
declare
  procedure asegurar_menu(
    p_codigo varchar2, p_descripcion varchar2, p_orden number, p_ruta varchar2,
    p_opcion varchar2, p_icono varchar2, p_padre varchar2, p_nivel number
  ) is
  begin
    merge into data.t_admi_modulopagina t
    using (select p_codigo codigopagina from dual) s
       on (t.codigomodulo = 'CNTR' and t.codigopagina = s.codigopagina)
    when matched then update set
      t.descripcion = p_descripcion, t.orden = p_orden, t.rutapagina = p_ruta,
      t.estado = 1, t.usuario_aud = 'JBALCAZAR', t.fechamodificacion = sysdate,
      t.opcionmenu = p_opcion, t.iconocss = p_icono, t.codigopadre = p_padre,
      t.nivel = p_nivel
    when not matched then insert (
      id, codigopagina, codigomodulo, descripcion, orden, rutapagina, estado,
      usuario_aud, fechacreacion, opcionmenu, iconocss, codigopadre, nivel
    ) values (
      data.sq_admi_modulopagina.nextval, p_codigo, 'CNTR', p_descripcion,
      p_orden, p_ruta, 1, 'JBALCAZAR', sysdate, p_opcion, p_icono, p_padre, p_nivel
    );
  end asegurar_menu;
begin
  -- CNTR es el único módulo corporativo de Contraloría. Reutiliza el dominio
  -- del Backoffice del ambiente para no fijar URL de TEST o PRODUCCIÓN.
  merge into data.t_admi_modulo t
  using (
    select 'CNTR' codigo, 'CONTRALORIA' nombre,
           (select dominio from data.t_admi_modulo where codigo='BACK') dominio,
           '/apex/f?p=152' rutamodulo, 11080 orden, 1 estado, 'APEX' grupo
      from dual
  ) s
  on (t.codigo=s.codigo)
  when matched then update set
    t.nombre=s.nombre, t.dominio=s.dominio, t.rutamodulo=s.rutamodulo,
    t.orden=s.orden, t.estado=s.estado, t.grupo=s.grupo,
    t.usuario_aud='JBALCAZAR', t.fechamodificacion=sysdate
  when not matched then insert (
    codigo,nombre,dominio,rutamodulo,orden,estado,usuario_aud,fechacreacion,grupo,modulopadre
  ) values (
    s.codigo,s.nombre,s.dominio,s.rutamodulo,s.orden,s.estado,'JBALCAZAR',sysdate,s.grupo,null
  );

  -- El árbol visible CNTR reemplaza al árbol BACKCNTR*, no las páginas APEX.
  asegurar_menu('CNTR00001', 'Contraloria', 20, null, 'Contraloria', 'fa-balance-scale', null, 1);
  asegurar_menu('CNTRP500', 'Mesa de trabajo', 10, '500', 'Mesa de trabajo', 'fa-tasks', 'CNTR00001', 2);
  asegurar_menu('CNTR00002', 'Configuracion', 1, null, 'Configuracion', 'fa-gear', 'CNTR00001', 2);
  asegurar_menu('CNTR00003', 'Documentos', 20, null, 'Documentos', 'fa-folder-open-o', 'CNTR00001', 2);
  asegurar_menu('CNTRP301', 'Portales RPA', 1, '301', 'Portales RPA', 'fa-robot', 'CNTR00002', 3);
  asegurar_menu('CNTRP307', 'Matricula de Sujetos', 2, '307', 'Matricula de Sujetos', 'fa-users', 'CNTR00002', 3);
  asegurar_menu('CNTRP314', 'Configuraciones de captura', 3, '314', 'Configuraciones de captura', 'fa-cog', 'CNTR00002', 3);
  asegurar_menu('CNTRP319', 'Ejecuciones RPA', 10, '319', 'Ejecuciones RPA', 'fa-play-circle', 'CNTR00003', 3);
  asegurar_menu('CNTRP320', 'Matriz documental', 20, '320', 'Matriz documental', 'fa-table', 'CNTR00003', 3);
  asegurar_menu('CNTRP321', 'Evidencias y versiones', 30, '321', 'Evidencias y versiones', 'fa-files-o', 'CNTR00003', 3);

  -- Migra cada permiso de rol, incluidos permisos específicos de acción.
  merge into data.t_admi_rolaccesos destino
  using (
    select a.id_rol, objetivo.id id_modulopagina, a.codigoaccion, a.codigo_tg,
           nvl(a.agregar,0) agregar, nvl(a.guardar,0) guardar, nvl(a.eliminar,0) eliminar,
           nvl(a.comentar,0) comentar, nvl(a.imprimir,0) imprimir, nvl(a.cancelar,0) cancelar
      from data.t_admi_modulopagina origen
      join data.t_admi_rolaccesos a on a.id_modulopagina = origen.id and a.estado = 1
      join (
        select 'BACKCNTR0' origen, 'CNTR00001' destino from dual union all
        select 'BACKCNTR1', 'CNTR00002' from dual union all
        select 'BACKCNTR2', 'CNTR00003' from dual union all
        select 'BACKCN301', 'CNTRP301' from dual union all
        select 'BACKCN307', 'CNTRP307' from dual union all
        select 'BACKCN314', 'CNTRP314' from dual union all
        select 'BACKCN319', 'CNTRP319' from dual union all
        select 'BACKCN320', 'CNTRP320' from dual union all
        select 'BACKCN321', 'CNTRP321' from dual
      ) mapa on mapa.origen = origen.codigopagina
      join data.t_admi_modulopagina objetivo
        on objetivo.codigomodulo = 'CNTR' and objetivo.codigopagina = mapa.destino
     where origen.codigomodulo = 'BACK'
  ) fuente
  on (destino.id_rol = fuente.id_rol
      and destino.id_modulopagina = fuente.id_modulopagina
      and nvl(destino.codigoaccion,'~') = nvl(fuente.codigoaccion,'~')
      and nvl(destino.codigo_tg,'~') = nvl(fuente.codigo_tg,'~'))
  when matched then update set
    destino.estado = 1, destino.usuario_aud = 'JBALCAZAR', destino.fechamodificacion = sysdate,
    destino.agregar = fuente.agregar, destino.guardar = fuente.guardar,
    destino.eliminar = fuente.eliminar, destino.comentar = fuente.comentar,
    destino.imprimir = fuente.imprimir, destino.cancelar = fuente.cancelar
  when not matched then insert (
    id_rol,id_modulopagina,estado,usuario_aud,fechacreacion,codigoaccion,codigo_tg,
    agregar,guardar,eliminar,comentar,imprimir,cancelar
  ) values (
    fuente.id_rol,fuente.id_modulopagina,1,'JBALCAZAR',sysdate,fuente.codigoaccion,fuente.codigo_tg,
    fuente.agregar,fuente.guardar,fuente.eliminar,fuente.comentar,fuente.imprimir,fuente.cancelar
  );

  -- Los padres sólo reciben visibilidad para roles que ya tenían un destino CNTR vigente.
  merge into data.t_admi_rolaccesos destino
  using (
    select distinct a.id_rol, padre.id id_modulopagina
      from data.t_admi_modulopagina origen
      join data.t_admi_rolaccesos a on a.id_modulopagina = origen.id and a.estado = 1
      join data.t_admi_modulopagina padre on padre.codigomodulo = 'CNTR'
       and padre.codigopagina in (
         'CNTR00001',
         case when origen.codigopagina in ('BACKCN301','BACKCN307','BACKCN314','BACKCNTR1') then 'CNTR00002' end,
         case when origen.codigopagina in ('BACKCN319','BACKCN320','BACKCN321','BACKCNTR2') then 'CNTR00003' end
       )
     where origen.codigomodulo = 'BACK'
       and origen.codigopagina in ('BACKCNTR0','BACKCNTR1','BACKCNTR2','BACKCN301','BACKCN307','BACKCN314','BACKCN319','BACKCN320','BACKCN321')
  ) fuente
  on (destino.id_rol = fuente.id_rol and destino.id_modulopagina = fuente.id_modulopagina
      and destino.codigoaccion is null)
  when matched then update set destino.estado=1, destino.usuario_aud='JBALCAZAR', destino.fechamodificacion=sysdate,
    destino.agregar=0, destino.guardar=0, destino.eliminar=0, destino.comentar=0, destino.imprimir=0, destino.cancelar=1
  when not matched then insert (id_rol,id_modulopagina,estado,usuario_aud,fechacreacion,codigoaccion,codigo_tg,agregar,guardar,eliminar,comentar,imprimir,cancelar)
    values (fuente.id_rol,fuente.id_modulopagina,1,'JBALCAZAR',sysdate,null,null,0,0,0,0,0,1);

  -- Copia asignaciones sólo de roles que tenían permisos en el árbol CNTR de BACK.
  merge into data.t_admi_rolusuario destino
  using (
    select distinct u.id_rol, u.codigocompania, u.codigousuario
      from data.t_admi_rolusuario u
      join data.t_admi_rolaccesos a on a.id_rol = u.id_rol and a.estado = 1
      join data.t_admi_modulopagina p on p.id = a.id_modulopagina
     where u.estado = 1 and u.codigomodulo = 'BACK'
       and p.codigomodulo = 'BACK'
       and p.codigopagina in ('BACKCNTR0','BACKCNTR1','BACKCNTR2','BACKCN301','BACKCN307','BACKCN314','BACKCN319','BACKCN320','BACKCN321')
  ) fuente
  on (destino.id_rol=fuente.id_rol and destino.codigomodulo='CNTR'
      and destino.codigocompania=fuente.codigocompania and destino.codigousuario=fuente.codigousuario)
  when matched then update set destino.estado=1, destino.usuario_aud='JBALCAZAR', destino.fechamodificacion=sysdate
  when not matched then insert (id,id_rol,codigomodulo,codigocompania,codigousuario,estado,usuario_aud,fechacreacion)
    values (data.sq_admi_rolusuario.nextval,fuente.id_rol,'CNTR',fuente.codigocompania,fuente.codigousuario,1,'JBALCAZAR',sysdate);

  -- Normaliza permisos históricos de página 500 sin ampliar sus facultades.
  update data.t_admi_rolaccesos a set
    a.agregar=nvl(a.agregar,0), a.guardar=nvl(a.guardar,0), a.eliminar=nvl(a.eliminar,0),
    a.comentar=nvl(a.comentar,0), a.imprimir=nvl(a.imprimir,0), a.cancelar=nvl(a.cancelar,0),
    a.usuario_aud='JBALCAZAR', a.fechamodificacion=sysdate
   where a.id_modulopagina in (select id from data.t_admi_modulopagina where codigomodulo='CNTR' and codigopagina='CNTRP500');

  -- Retira duplicados visibles sin borrar evidencia histórica ni desactivar asignaciones BACK compartidas.
  update data.t_admi_rolaccesos a set a.estado=0, a.usuario_aud='JBALCAZAR', a.fechamodificacion=sysdate
   where a.id_modulopagina in (
     select id from data.t_admi_modulopagina
      where codigomodulo='BACK' and codigopagina in ('BACKCNTR0','BACKCNTR1','BACKCNTR2','BACKCN301','BACKCN307','BACKCN314','BACKCN319','BACKCN320','BACKCN321')
   );
  update data.t_admi_modulopagina set estado=0, usuario_aud='JBALCAZAR', fechamodificacion=sysdate
   where codigomodulo='BACK' and codigopagina in ('BACKCNTR0','BACKCNTR1','BACKCNTR2','BACKCN301','BACKCN307','BACKCN314','BACKCN319','BACKCN320','BACKCN321');
end;
/
