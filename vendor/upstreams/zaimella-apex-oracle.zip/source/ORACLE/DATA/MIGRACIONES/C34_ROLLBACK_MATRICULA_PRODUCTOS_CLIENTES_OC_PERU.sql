-- Reversa C34 - Elimina exclusivamente las matriculas creadas por C34.
-- La marca de fecha coincide con C34_MATRICULA_PRODUCTOS_CLIENTES_OC_PERU.sql.

whenever sqlerror exit failure rollback

delete from data.t_vtas_cliente_producto matricula
 where matricula.compania = '00003'
   and matricula.fechacodificacion = to_date('2026-07-20 11:19:42', 'YYYY-MM-DD HH24:MI:SS')
   and exists (
       select 1
         from data.t_vtas_pedido_conf_oc configuracion
        where configuracion.compania = '00003'
          and configuracion.estado = 1
          and configuracion.codigocliente = matricula.codigocliente
   )
   and exists (
       select 1
         from data.t_gzm_producto producto
        where producto.compania = '00003'
          and producto.estado = 1
          and producto.codigoproducto = matricula.codigoproducto
   );

commit;
