create table data.t_trad_productos_sugeridos (
  codigoproducto varchar2(50) not null,
  tipo           varchar2(2),
  codigopdv      number not null,
  compania       varchar2(5) not null,
  producto       varchar2(250),
  codigobarra    varchar2(50) not null,
  selloutmes     number not null,
  ub             number,
  constraint pk_trad_productos_sugeridos primary key (compania, codigopdv, codigoproducto)
);
/

create index data.ix_trad_prod_sugeridos_pdv
  on data.t_trad_productos_sugeridos (compania, codigopdv);
/

create index data.ix_trad_prod_sugeridos_barra
  on data.t_trad_productos_sugeridos (compania, codigobarra);
/
