create sequence data.seq_cntr_evidencias
    start with 1
    increment by 1
    nocache
    nocycle;
