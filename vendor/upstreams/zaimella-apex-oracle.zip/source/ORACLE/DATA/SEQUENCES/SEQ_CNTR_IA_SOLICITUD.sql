create sequence data.seq_cntr_ia_solicitud start with 1 increment by 1 nocache;
