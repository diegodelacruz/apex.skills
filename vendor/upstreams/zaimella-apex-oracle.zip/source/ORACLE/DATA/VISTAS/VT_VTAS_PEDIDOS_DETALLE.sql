﻿prompt TEST VIEW DATA.VT_VTAS_PEDIDOS_DETALLE

  CREATE OR REPLACE FORCE EDITIONABLE VIEW VT_VTAS_PEDIDOS_DETALLE ("IDPEDIDO", "LINEA", "GRUPO", "CODIGOCLIENTE", "CODIGOPRODUCTOCLIENTE", "NOMBREPRODUCTO", "CODIGOBARRA", "CODIGOPRODUCTO", "PROMOCIONAL", "ESTADO", "TIPOINACTIVO", "OBSERVACION", "UNIDAD_MEDIDA", "PRESENTACION", "CANTIDAD_BU_CA", "CANTIDAD_UND", "CANTIDAD_BU_CA_OC", "CANTIDAD_OC", "VOLUMEN", "PRECIO", "CANTIDADSUGERIDA", "PRECIO_OC", "DESCUENTO", "DESCUENTO_OC", "ICE", "PRECIO_OC_FINAL", "PRECIO_FINAL", "TOTAL", "TOTAL_OC", "TOTAL_DIFERENCIA") AS 
  SELECT pe.idpedido,
       pe.linea,
       pe.grupo,
       pe.codigocliente codigocliente,
       pe.codigoproductocliente,
       pe.nombreproducto nombreproducto,
       pe.codigobarra,
       NVL(pe.codigoproductoreferencia, pe.codigoproducto) codigoproducto,
       CASE
           WHEN pe.codigoproductoreferencia = pe.codigoproducto THEN 'NO'
           ELSE 'SI'
       END promocional,
       pe.estado,
       pe.tipoinactivo,
       pe.observacion,
       unidad_medida,
       pe.cantidadpresentacion AS presentacion,
       CASE
           WHEN c.compania = '00003' AND c.presentacion_oc = '2'
               THEN pe.cantidad_oc
           WHEN c.compania = '00003'
               THEN pe.cantidad / NULLIF(pe.cantidadpresentacion, 0)
           ELSE pe.cantidad
       END cantidad_bu_ca,
       CASE
           WHEN c.compania = '00003'
               THEN pe.cantidad
           ELSE pe.cantidad * NVL(pe.cantidadpresentacion, 1)
       END cantidad_und,
       CASE
           WHEN c.compania = '00003' AND c.presentacion_oc = '2'
               THEN pe.cantidad_oc
           WHEN c.compania = '00003'
               THEN pe.cantidad_oc / NULLIF(pe.cantidadpresentacion, 0)
           ELSE pe.cantidadori
       END cantidad_bu_ca_oc,
       pe.cantidad_oc,
       metroscubicos * pe.cantidad volumen,
       pe.precio,
       pe.cantidadsugerida,
       pe.precio_oc,
       pe.descuento,
       pe.descuento_oc,
       pe.ice,
       CASE
           WHEN c.compania = '00003' THEN ROUND(NVL(precio_oc - (precio_oc * (descuento_oc / 100)), 0), 4)
           ELSE ROUND(NVL(precio_oc - (precio_oc * (descuento_oc / 100)), 0), 2)
       END precio_oc_final,
       CASE
           WHEN c.compania = '00003' THEN ROUND(NVL((precio - (precio * (descuento / 100))) + ice, 0), 4)
           ELSE ROUND(NVL((precio - (precio * (descuento / 100))) + ice, 0), 2)
       END precio_final,
       NVL(ROUND(NVL((precio - (precio * (descuento / 100))), 0), 4)
           * CASE
                 WHEN c.compania = '00003' THEN pe.cantidad
                 ELSE pe.cantidad * NVL(pe.cantidadpresentacion, 1)
             END, 0) AS total,
       NVL(ROUND(NVL(precio_oc - (precio_oc * (descuento_oc / 100)), 0), 2)
           * CASE
                 WHEN c.compania = '00003' THEN pe.cantidadori
                 ELSE pe.cantidadori * NVL(pe.cantidadpresentacion, 1)
             END, 0) AS total_oc,
       NVL(ROUND(NVL((precio - (precio * (descuento / 100))), 0), 2)
           * CASE
                 WHEN c.compania = '00003' THEN pe.cantidad
                 ELSE pe.cantidad * NVL(pe.cantidadpresentacion, 1)
             END, 0)
       - NVL(ROUND(NVL(precio_oc - (precio_oc * (descuento_oc / 100)), 0), 2)
           * CASE
                 WHEN c.compania = '00003' THEN pe.cantidadori
                 ELSE pe.cantidadori * NVL(pe.cantidadpresentacion, 1)
             END, 0) total_diferencia
  FROM data.t_vtas_pedidos pe
  JOIN data.t_vtas_pedidos_cab c
    ON pe.idpedido = c.idpedido;
/
