create or replace view data.vt_cntr_rpa_monitor_detalle as
select d.id_ejecucion_detalle,
       d.id_ejecucion,
       d.id_documento,
       p.nombre_portal portal,
       doc.nombre_documento documento,
       d.tipo_sujeto,
       d.id_sujeto,
       case d.tipo_sujeto
           when 'PERSONA' then per.identificacion || ' - ' || per.nombres
           when 'EMPRESA' then emp.ruc || ' - ' || emp.razon_social
       end sujeto,
       d.id_empresa_origen,
       eo.razon_social empresa_origen,
       d.estado,
       d.intento,
       d.fecha_inicio,
       d.fecha_fin,
       d.mensaje,
       d.tipo_error,
       d.paso_orden,
       d.id_evidencia,
       d.numeroarchivo_evidencia
  from data.t_cntr_rpa_ejecuciones_detalle d
  join data.t_cntr_documentos doc
    on doc.id_documento = d.id_documento
  join data.t_cntr_portales p
    on p.id_portal = doc.id_portal
  left join data.t_cntr_personas per
    on d.tipo_sujeto = 'PERSONA'
   and per.id_persona = d.id_sujeto
  left join data.t_cntr_empresas emp
    on d.tipo_sujeto = 'EMPRESA'
   and emp.id_empresa = d.id_sujeto
  left join data.t_cntr_empresas eo
    on eo.id_empresa = d.id_empresa_origen;
comment on table data.vt_cntr_rpa_monitor_detalle is 'Detalle descriptivo de cada documento y sujeto procesado por el RPA.';
comment on column data.vt_cntr_rpa_monitor_detalle.id_ejecucion_detalle is 'Identificador interno del detalle de ejecucion.';
comment on column data.vt_cntr_rpa_monitor_detalle.id_ejecucion is 'Identificador interno de la ejecucion cabecera.';
comment on column data.vt_cntr_rpa_monitor_detalle.id_documento is 'Identificador interno del documento configurado.';
comment on column data.vt_cntr_rpa_monitor_detalle.portal is 'Nombre visible del portal consultado.';
comment on column data.vt_cntr_rpa_monitor_detalle.documento is 'Nombre visible del documento consultado.';
comment on column data.vt_cntr_rpa_monitor_detalle.tipo_sujeto is 'Tipo de propietario PERSONA o EMPRESA.';
comment on column data.vt_cntr_rpa_monitor_detalle.id_sujeto is 'Identificador interno del propietario documental.';
comment on column data.vt_cntr_rpa_monitor_detalle.sujeto is 'Identificacion y nombre visible del propietario.';
comment on column data.vt_cntr_rpa_monitor_detalle.id_empresa_origen is 'Empresa desde la que fue incluido un integrante.';
comment on column data.vt_cntr_rpa_monitor_detalle.empresa_origen is 'Razon social visible de la empresa de origen.';
comment on column data.vt_cntr_rpa_monitor_detalle.estado is 'Estado del procesamiento del detalle.';
comment on column data.vt_cntr_rpa_monitor_detalle.intento is 'Numero de intento del procesamiento.';
comment on column data.vt_cntr_rpa_monitor_detalle.fecha_inicio is 'Fecha y hora de inicio del detalle.';
comment on column data.vt_cntr_rpa_monitor_detalle.fecha_fin is 'Fecha y hora de finalizacion del detalle.';
comment on column data.vt_cntr_rpa_monitor_detalle.mensaje is 'Mensaje funcional o tecnico del detalle.';
comment on column data.vt_cntr_rpa_monitor_detalle.tipo_error is 'Clasificacion tecnica del error.';
comment on column data.vt_cntr_rpa_monitor_detalle.paso_orden is 'Paso RPA en el que ocurrio el error.';
comment on column data.vt_cntr_rpa_monitor_detalle.id_evidencia is 'Cabecera documental generada por el detalle.';
comment on column data.vt_cntr_rpa_monitor_detalle.numeroarchivo_evidencia is 'Archivo exacto de evidencia generado por el detalle.';

