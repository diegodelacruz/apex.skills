﻿prompt PROD VIEW DATA.VT_ICOM_REPLAN_MATERIAL_POP

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_REPLAN_MATERIAL_POP" ("IDPADRE", "IDINVERSION_ORIG", "IDINVERSION_REP", "CODIGOGRUPO", "MATERIAL_ORIG", "MATERIAL_REP", "DIFERENCIA") AS 
  with material_original as(
select  NVL(IDPADRE, ID) IDPADRE, codigogrupo,idinversion ,
 CODIGOGRUPO||'|'||IDMATERIAL||'|'||m.TIPO
||'|'||m.FECHAINICIO||'|'||m.FECHAFIN||'|'||m.FORMATO||'|'||round(m.TOTAL) material
from T_ICOM_CLIENTE_MATERIAL  m
INNER JOIN T_ICOM_INVERSIONES I ON (I.ID=M.IDINVERSION)
where idpadre is null),

material_replanificado as(
select  NVL(IDPADRE, ID) IDPADRE, codigogrupo,  idinversion ,
CODIGOGRUPO||'|'||IDMATERIAL||'|'||m.TIPO
||'|'||m.FECHAINICIO||'|'||m.FECHAFIN||'|'||m.FORMATO||'|'||round(m.TOTAL) material
from T_ICOM_CLIENTE_MATERIAL  m
INNER JOIN T_ICOM_INVERSIONES I ON (I.ID=M.IDINVERSION)
where idpadre is not null and  i.estado in(0,2))

select nvl(o.IDPADRE,r.IDPADRE) IDPADRE , o.IDINVERSION IDINVERSION_orig,
r.IDINVERSION IDINVERSION_rep,nvl(o.codigogrupo,r.codigogrupo) codigogrupo
, o.material material_orig, r.material material_rep,
CASE WHEN NVL(o.material,'')=NVL(R.material,'') THEN 0 ELSE 1 END DIFERENCIA
from  material_original o  
full  JOIN material_replanificado r on (o.IDPADRE=r.IDPADRE and  o.material=r.material);
/

