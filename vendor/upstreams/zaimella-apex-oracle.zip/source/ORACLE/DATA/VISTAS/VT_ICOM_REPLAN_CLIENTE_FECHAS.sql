﻿prompt PROD VIEW DATA.VT_ICOM_REPLAN_CLIENTE_FECHAS

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_REPLAN_CLIENTE_FECHAS" ("IDPADRE", "IDINVERSION_ORIG", "IDINVERSION_REP", "CODIGOGRUPO", "IDENTIFICATIVO_ORIG", "IDENTIFICATIVO_REP", "DIFERENCIA") AS 
  with original as(
select  NVL(IDPADRE, ID) IDPADRE, codigogrupo,idinversion ,
 CODIGOGRUPO||'|'||NUMERO||'|'||TIPOLOCAL
||'|'||t.FECHAINICIO||'|'||t.FECHAFIN identificativo
from T_ICOM_CLIENTE_FECHAS  t
INNER JOIN T_ICOM_INVERSIONES I ON (I.ID=t.IDINVERSION)
where idpadre is null),

replanificado as(
select  NVL(IDPADRE, ID) IDPADRE, codigogrupo,  idinversion ,
CODIGOGRUPO||'|'||NUMERO||'|'||TIPOLOCAL
||'|'||m.FECHAINICIO||'|'||m.FECHAFIN identificativo
from T_ICOM_CLIENTE_FECHAS  m
INNER JOIN T_ICOM_INVERSIONES I ON (I.ID=M.IDINVERSION)
where idpadre is not null and  i.estado in(0,2))

select nvl(o.IDPADRE,r.IDPADRE) IDPADRE , o.IDINVERSION IDINVERSION_orig,
r.IDINVERSION IDINVERSION_rep,nvl(o.codigogrupo,r.codigogrupo) codigogrupo
, o.identificativo identificativo_orig, r.identificativo identificativo_rep,
CASE WHEN NVL(o.identificativo,'')=NVL(R.identificativo,'') THEN 0 ELSE 1 END DIFERENCIA
from  original o  
full  JOIN replanificado r on (o.IDPADRE=r.IDPADRE and  o.identificativo=r.identificativo);
/

