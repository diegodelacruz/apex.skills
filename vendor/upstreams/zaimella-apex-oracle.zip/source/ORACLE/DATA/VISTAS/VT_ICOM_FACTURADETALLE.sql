﻿prompt PROD VIEW DATA.VT_ICOM_FACTURADETALLE

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_FACTURADETALLE" ("COMPANIA", "FACTURA", "CANTIDAD", "CODIGOPRODUCTO", "CODIGOCLIENTE", "FECHA") AS 
  select  COMPANIA, FACTURA,      CANTIDAD,  CODIGOPRODUCTO,      CODIGOCLIENTE,   FECHA
FROM  VT_ICOM_FACTURADETALLE@JDEDTADL 
/*Union
select '00002',  to_char(trim(codigo)), 
        to_number(nvl(cantidadvendida,0)),  to_char(trim(codigo)),  
        to_char(trim(codigocliente)), fechaventa 
from VT_SAP_VENTAS@HANA 
*/;
/

