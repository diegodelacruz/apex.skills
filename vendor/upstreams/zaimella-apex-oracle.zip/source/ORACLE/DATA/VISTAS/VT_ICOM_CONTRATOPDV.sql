﻿prompt PROD VIEW DATA.VT_ICOM_CONTRATOPDV

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_CONTRATOPDV" ("IDINVERSION", "NOMBREINVERSION", "FECHAINICIO", "FECHAFIN", "CODIGOPDV", "NOMBRE", "CODIGOGRUPO", "NOMBREGRUPO", "TIPOCONTRATO", "ESTADOCONTRATO", "IDCONTRATO", "ID_TIP_CONTRATO", "IDCONTRATOMANUAL", "ID_TIP_CONTRATOMANUAL", "ESCALA", "IDZONA", "ZONA", "COORDINADOR", "DESARROLLADOR", "SECUENCIAL", "CORREO", "RUC", "COMPANIA") AS 
  select i.id idinversion, i.nombre nombreinversion, i.fechainicio fechainicio, i.fechafin fechafin, 
p.codigopdv, cl.razonsocial nombre, p.codigogrupo, gr.nombres  nombregrupo, 
case when nvl(p.contratoaprobar,0) = 3 then 'CONTRATO PDV' 
     when nvl(p.contratoclausura,-1) = 1 then 'FINIQUITO' end tipocontrato,
ne.descripcion estadocontrato, co.id idcontrato, co.tipocontrato id_tip_contrato, 
cm.id idcontratomanual, cm.tipocontrato id_tip_contratomanual, p.escala, clo.idzona, 
clo.zona,  clo.coordinador, clo.desarrollador, p.secuencial , cl.correo, p.ruc,i.compania
from  data.vt_icom_inversiontipo it 
inner join data.t_icom_inversiones i on ( it.idinversiontipo = i.idinversiontipo )
inner join data.t_icom_cliente_pdv p on (i.id = p.idinversion 
                                         and ( ( nvl(p.estado,-1) = -1  and nvl(p.contratoaprobar,0) in (1,3) and nvl(p.contratoclausura,-1) = -1 ) 
                                              or (nvl(p.estado,-1) = 1  and nvl(p.contratoaprobar,0) = 4 and nvl(p.contratoclausura,-1) = 1 ) ) )
left join data.Vt_trad_cliente cl on ( p.codigopdv = trim(cl.codigopdv) )
left join data.vt_gzm_cliente gr on ( gr.compania = i.compania and  p.codigogrupo = gr.codigocliente)
left join data.t_corp_udc ne on ( ne.id_cabecera = 'ICOM_ESPDV'  and i.compania= ne.CODIGOCOMPANIA
                                and ( ( ne.valor is not null and nvl(p.estado,-1) = -1  and nvl(p.contratoaprobar,0) = ne.valor and nvl(p.contratoclausura,-1) = -1) 
                                     or ( ne.valor2 is not null and nvl(p.estado,-1) = 1  and nvl(p.contratoaprobar,0) = 4 and nvl(p.contratoclausura,-1) = ne.valor2  )  ) )
inner join ( select ctt.id, ctt.tipocontrato, cc.idinversion, cc.codigopdv
            from  data.t_icom_contratos ctt 
                inner join ( select distinct idcontrato, idinversion, codigopdv from  data.t_icom_contrato_contenido ) cc
                on ( cc.idcontrato = ctt.id  ) 
            where nvl(ctt.subtipocontrato,1) = 1 --formato electronico    
			and ctt.estado = 1 
   ) co on ( p.idinversion = co.idinversion and p.codigopdv = co.codigopdv 
         and co.tipocontrato =  case when (nvl(p.estado,-1) = -1  and ne.valor is not null and nvl(p.contratoaprobar,0) = ne.valor and nvl(p.contratoclausura,-1) = -1) then 2 
                                when (nvl(p.estado,-1) = 1  and ne.valor2 is not null and nvl(p.contratoaprobar,0) = 4 and nvl(p.contratoclausura,-1) = ne.valor2 ) then 4 end )
left join ( select ctt.id, ctt.tipocontrato, cc.idinversion, cc.codigopdv
            from  data.t_icom_contratos ctt 
                inner join ( select distinct idcontrato, idinversion, codigopdv from  data.t_icom_contrato_contenido ) cc
                on ( cc.idcontrato = ctt.id  ) 
            where nvl(ctt.subtipocontrato,1) = 2 --formato manual  
			and ctt.estado = 1 		
   ) cm on ( p.idinversion = cm.idinversion and p.codigopdv = cm.codigopdv 
         and cm.tipocontrato =  case when (nvl(p.estado,-1) = -1  and ne.valor is not null and nvl(p.contratoaprobar,0) = ne.valor and nvl(p.contratoclausura,-1) = -1) then 2 
                                when (nvl(p.estado,-1) = 1  and ne.valor2 is not null and nvl(p.contratoaprobar,0) = 4 and nvl(p.contratoclausura,-1) = ne.valor2 ) then 4 end )    
left join data.vt_trad_clientelocal clo
               on ( p.codigopdv = clo.codigopdv and clo.matriz = 1 and clo.estado=1)
 where it.firmacontrato = 2  and i.idetapa>=2;
/

