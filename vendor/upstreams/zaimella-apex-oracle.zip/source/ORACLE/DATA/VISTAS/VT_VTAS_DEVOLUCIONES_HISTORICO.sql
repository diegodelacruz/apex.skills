CREATE OR REPLACE FORCE VIEW DATA.VT_VTAS_DEVOLUCIONES_HISTORICO
(
    IDDEVOLUCION, CODIGO_CANAL, CANAL, CODIGO_GRUPO, GRUPO,
    CODIGO_CLIENTE, CLIENTE, OBSERVACION, USUARIO, FECHA_INGRESO,
    FECHA_APROBACION, FECHA_NC, ORDENNUMERO, ORDENTIPO, ESTADO_JDE,
    NUMERO_NC, TIPO_NC, NUMERO_FACT, CODIGO_PRODUCTO, PRODUCTO,
    UNIDAD_MEDIDA, CANTIDAD_UN, PRECIO, SUBTOTAL, MOTIVO, ESTADO,
    ESTADO_DESCRIPCION, EJECUTIVO
) AS
WITH devoluciones_registradas AS (
    SELECT c.iddevolucion,
           CAST(cl.codigocanal AS VARCHAR2(6)) codigo_canal,
           CAST(cl.canal AS VARCHAR2(300)) canal,
           CAST(cl.codigogrupo AS NUMBER) codigo_grupo,
           CAST(cl.codigogrupo || '-' || cl.grupo AS NVARCHAR2(142)) grupo,
           CAST(c.codigocliente AS VARCHAR2(50)) codigo_cliente,
           CAST(c.codigocliente || '-' || c.cliente AS VARCHAR2(1111)) cliente,
           CAST(c.observacion AS VARCHAR2(300)) observacion,
           CAST(c.auditoriausuario AS VARCHAR2(100)) usuario,
           c.auditoriafecha fecha_ingreso,
           TO_DATE(NVL(j.sdtrdj, j2.sdtrdj) + 1900000, 'yyyyddd') fecha_aprobacion,
           CASE
               WHEN NVL(j.sdivd, j2.sdivd) > 0
                   THEN TO_DATE(NVL(j.sdivd, j2.sdivd) + 1900000, 'yyyyddd')
           END fecha_nc,
           CAST(c.ordennumero AS NUMBER) ordennumero,
           CAST(c.ordentipo AS VARCHAR2(10)) ordentipo,
           CAST(NVL(j.sdlttr, j2.sdlttr) AS NVARCHAR2(3)) estado_jde,
           CAST(NVL(j.sddoc, j2.sddoc) AS NUMBER) numero_nc,
           CAST(NVL(j.sddct, j2.sddct) AS NVARCHAR2(2)) tipo_nc,
           CAST(NVL(j.sdvr01, j2.sdvr01) AS NVARCHAR2(25)) numero_fact,
           CAST(NVL(j.sdlitm, j2.sdlitm) AS NVARCHAR2(25)) codigo_producto,
           CAST(NVL(j.sddsc1, j2.sddsc1) AS NVARCHAR2(30)) producto,
           CAST(NVL(j.sduom, j2.sduom) AS NVARCHAR2(2)) unidad_medida,
           CAST(NVL(j.sdpqor, j2.sdpqor) / 10000 AS NUMBER) cantidad_un,
           CAST(NVL(j.sduprc, j2.sduprc) / 10000 AS NUMBER) precio,
           CAST(NVL(j.sdaexp, j2.sdaexp) / 100 AS NUMBER) subtotal,
           CAST(m.descripcion AS NCHAR(60)) motivo,
           CAST(c.estado AS NUMBER) estado,
           CAST(e.descripcion AS VARCHAR2(2000)) estado_descripcion,
           CAST(cl.ejecutivo AS VARCHAR2(200)) ejecutivo
      FROM data.t_vtas_devolucion_cab c
      LEFT JOIN f4211@jdedtadl j
        ON c.ordennumero = j.sddoco
       AND c.ordentipo = j.sddcto
      LEFT JOIN f42119@jdedtadl j2
        ON c.ordennumero = j2.sddoco
       AND c.ordentipo = j2.sddcto
      INNER JOIN data.vt_jde_cliente cl
        ON c.codigocliente = cl.codigo
      LEFT JOIN data.vt_vtas_devolucion_motivos m
        ON m.id = NVL(j.sdeuse, j2.sdeuse)
      LEFT JOIN data.vt_vtas_pedido_estados e
        ON e.id = c.estado
), devoluciones_jde AS (
    SELECT CAST(NULL AS NUMBER) iddevolucion,
           CAST(c.codigocanal AS VARCHAR2(6)) codigo_canal,
           CAST(c.canal AS VARCHAR2(300)) canal,
           CAST(c.codigogrupo AS NUMBER) codigo_grupo,
           CAST(c.codigogrupo || '-' || c.grupo AS NVARCHAR2(142)) grupo,
           CAST(TO_CHAR(j.sdan8) AS VARCHAR2(50)) codigo_cliente,
           CAST(j.sdan8 || '-' || c.nombres AS VARCHAR2(1111)) cliente,
           CAST(NULL AS VARCHAR2(300)) observacion,
           CAST(NULL AS VARCHAR2(100)) usuario,
           TO_DATE(j.sdtrdj + 1900000, 'yyyyddd') fecha_ingreso,
           TO_DATE(j.sdtrdj + 1900000, 'yyyyddd') fecha_aprobacion,
           TO_DATE(j.sdivd + 1900000, 'yyyyddd') fecha_nc,
           CAST(j.sddoco AS NUMBER) ordennumero,
           CAST(j.sddcto AS VARCHAR2(10)) ordentipo,
           CAST(j.sdlttr AS NVARCHAR2(3)) estado_jde,
           CAST(j.sddoc AS NUMBER) numero_nc,
           CAST(j.sddct AS NVARCHAR2(2)) tipo_nc,
           CAST(j.sdvr01 AS NVARCHAR2(25)) numero_fact,
           CAST(j.sdlitm AS NVARCHAR2(25)) codigo_producto,
           CAST(j.sddsc1 AS NVARCHAR2(30)) producto,
           CAST(j.sduom AS NVARCHAR2(2)) unidad_medida,
           CAST(j.sduorg / 10000 AS NUMBER) cantidad_un,
           CAST(j.sduprc / 10000 AS NUMBER) precio,
           CAST(j.sdaexp / 100 AS NUMBER) subtotal,
           CAST(m.descripcion AS NCHAR(60)) motivo,
           CAST(NULL AS NUMBER) estado,
           CAST(NULL AS VARCHAR2(2000)) estado_descripcion,
           CAST(c.ejecutivo AS VARCHAR2(200)) ejecutivo
      FROM f42119@jdedtadl j
      INNER JOIN data.vt_jde_cliente c
        ON j.sdan8 = c.codigo
      LEFT JOIN data.vt_vtas_devolucion_motivos m
        ON m.id = j.sdeuse
     WHERE j.sddcto IN ('DC', 'DG', 'DE')
)
SELECT *
  FROM devoluciones_registradas
UNION ALL
SELECT j.*
  FROM devoluciones_jde j
 WHERE NOT EXISTS (
    SELECT 1
      FROM devoluciones_registradas r
     WHERE TO_CHAR(r.numero_nc) = TO_CHAR(j.numero_nc)
       AND RTRIM(r.tipo_nc) = RTRIM(j.tipo_nc)
       AND TO_CHAR(r.ordennumero) = TO_CHAR(j.ordennumero)
       AND RTRIM(r.ordentipo) = RTRIM(j.ordentipo)
       AND RTRIM(r.codigo_producto) = RTRIM(j.codigo_producto)
       AND TO_CHAR(r.cantidad_un) = TO_CHAR(j.cantidad_un)
       AND TO_CHAR(r.precio) = TO_CHAR(j.precio)
       AND TO_CHAR(r.subtotal) = TO_CHAR(j.subtotal)
 );
