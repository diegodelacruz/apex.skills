  CREATE OR REPLACE VIEW DATA.VT_VTAS_PEDIDOS_INCUMPLIMIENTO_PE ("IDPEDIDO", "ESTADO", "ESTADO_SAP", "TIPO", "ORDENCOMPRA", "FECHA_INGRESO", "CODIGOGRUPO", "CODIGOCLIENTE", "CODIGOPRODUCTO", "CODIGO_PRODUCTO_CLIENTE", "PRECIO", "DESCUENTO", "ID_INVERSION", "PRESENTACION", "CANTIDAD_BU_CA_OC", "CANTIDAD_BU_CA_SOLICITADO", "CANTIDAD_BU_CA_INCUMP", "CANTIDAD_BU_CA_ALCANCE", "CANTIDAD_UND_OC", "CANTIDAD_UND_SOLICITADO", "CANTIDAD_UN_INCUMP", "CANTIDAD_UND_ALCANCE", "SUBTOTAL_OC", "SUBTOTAL_SOLICITADO", "SUBTOTAL_INCUMP", "SUBTOTAL_ALCANCE", "INFORMACION_ADICIONAL", "INFORMACION_ADICIONAL_2", "CLIENTE_SAP", "PRODUCTO_SAP", "CANTIDAD_ENTREGADA", "CANTIDAD_FACTURADA", "SALDO_SAP", "NUMERO_ORDEN_SAP", "LINEA_SAP", "TARGET_TYPE", "UNIDAD_MEDIDA", "TIENE_PEDIDO_APEX") AS 
  with entregas as (
    select
        D."BaseEntry" docentry_orden,
        D."BaseLine" linea_orden,
        sum(D."Quantity") cantidad_entregada
    from ODLN@HANA_PE H
    join DLN1@HANA_PE D on D."DocEntry" = H."DocEntry"
    where H."CANCELED" = 'N'
      and D."BaseType" = 17
    group by D."BaseEntry", D."BaseLine"
),
facturas_directas as (
    select
        D."BaseEntry" docentry_orden,
        D."BaseLine" linea_orden,
        sum(D."Quantity") cantidad_facturada
    from OINV@HANA_PE H
    join INV1@HANA_PE D on D."DocEntry" = H."DocEntry"
    where H."CANCELED" = 'N'
      and D."BaseType" = 17
    group by D."BaseEntry", D."BaseLine"
),
facturas_desde_entrega as (
    select
        DL."BaseEntry" docentry_orden,
        DL."BaseLine" linea_orden,
        sum(I."Quantity") cantidad_facturada
    from OINV@HANA_PE H
    join INV1@HANA_PE I on I."DocEntry" = H."DocEntry"
    join DLN1@HANA_PE DL on DL."DocEntry" = I."BaseEntry"
                         and DL."LineNum" = I."BaseLine"
    where H."CANCELED" = 'N'
      and I."BaseType" = 15
      and DL."BaseType" = 17
    group by DL."BaseEntry", DL."BaseLine"
),
facturas as (
    select docentry_orden, linea_orden, sum(cantidad_facturada) cantidad_facturada
    from (
        select * from facturas_directas
        union all
        select * from facturas_desde_entrega
    )
    group by docentry_orden, linea_orden
),
pedido_apex as (
    select
        ordencompra,
        codigocliente,
        codigogrupo,
        codigoproducto,
        min(idpedido) idpedido_apex,
        max(tipo) tipo_apex,
        max(fecha_pedido) fecha_pedido,
        max(codigoproductocliente) codigo_producto_cliente,
        max(unidad_medida) unidad_medida_apex,
        max(presentacion) presentacion,
        max(precio) precio,
        max(descuento) descuento,
        sum(cantidad_bu_ca) cantidad_bu_ca_solicitado,
        sum(cantidad_und) cantidad_und_solicitado,
        sum(cantidad_bu_ca_oc) cantidad_bu_ca_oc,
        sum(cantidad_oc) cantidad_und_oc,
        sum(total) subtotal_solicitado,
        sum(total_oc) subtotal_oc,
        max(substr(informacionadicional, 1, 30)) informacion_adicional,
        max(substr(informacionadicional, 31, 60)) informacion_adicional_2
    from VT_VTAS_PEDIDOS
    where compania = '00003'
      and tipo in (1, 3)
      and estado_pedido in (1, 3)
      and estado = 1
    group by ordencompra, codigocliente, codigogrupo, codigoproducto
),
base_sap as (
    select
        O."DocEntry" docentry_sap,
        O."DocNum" numero_orden_sap,
        O."NumAtCard" ordencompra_sap,
        O."DocDate" fecha_sap,
        O."CardCode" cardcode,
        O."CardName" cardname,
        R."LineNum" linea_sap,
        R."LineStatus" estado_sap,
        R."TargetType" target_type,
        cast(R."ItemCode" as varchar2(100)) codigoproducto_sap,
        R."Dscription" producto_sap,
        R."Quantity" cantidad_solicitada_sap,
        nvl(E.cantidad_entregada, 0) cantidad_entregada,
        nvl(F.cantidad_facturada, 0) cantidad_facturada,
        R."OpenQty" saldo_sap,
        R."UomCode" unidad_medida_sap,
        R."Price" precio_sap,
        R."DiscPrcnt" descuento_sap,
        R."LineTotal" subtotal_solicitado_sap
    from ORDR@HANA_PE O
    join RDR1@HANA_PE R on R."DocEntry" = O."DocEntry"
    left join entregas E on E.docentry_orden = R."DocEntry"
                        and E.linea_orden = R."LineNum"
    left join facturas F on F.docentry_orden = R."DocEntry"
                        and F.linea_orden = R."LineNum"
    where O."CANCELED" = 'N'
      and R."ItemCode" is not null
),
base as (
    select
        S.*,
        A.idpedido_apex,
        A.tipo_apex,
        A.fecha_pedido,
        A.codigocliente codigocliente_apex,
        A.codigogrupo codigogrupo_apex,
        A.codigoproducto codigoproducto_apex,
        A.codigo_producto_cliente,
        A.unidad_medida_apex,
        A.presentacion,
        A.precio precio_apex,
        A.descuento descuento_apex,
        A.cantidad_bu_ca_solicitado cantidad_bu_ca_solicitado_apex,
        A.cantidad_und_solicitado cantidad_und_solicitado_apex,
        A.cantidad_bu_ca_oc cantidad_bu_ca_oc_apex,
        A.cantidad_und_oc cantidad_und_oc_apex,
        A.subtotal_solicitado subtotal_solicitado_apex,
        A.subtotal_oc subtotal_oc_apex,
        A.informacion_adicional informacion_adicional_apex,
        A.informacion_adicional_2 informacion_adicional_2_apex
    from base_sap S
    left join pedido_apex A
        on upper(trim(A.ordencompra)) = upper(trim(S.ordencompra_sap))
       and A.codigocliente = replace(cast(S.cardcode as varchar2(50)), 'C', '')
       and A.codigoproducto = S.codigoproducto_sap
    where nvl(A.cantidad_bu_ca_solicitado, S.cantidad_solicitada_sap) > S.cantidad_facturada
)
select
    nvl(idpedido_apex, docentry_sap) idpedido,
    1 estado,
    cast(estado_sap as varchar2(20)) estado_sap,
    nvl(tipo_apex, 1) tipo,
    nvl(ordencompra_sap, 'Orden SAP ' || numero_orden_sap) ordencompra,
    nvl(fecha_pedido, fecha_sap) fecha_ingreso,
    nvl(codigogrupo_apex, nvl(G.CODIGOGRUPO, replace(cast(cardcode as varchar2(50)), 'C', ''))) codigogrupo,
    nvl(codigocliente_apex, replace(cast(cardcode as varchar2(50)), 'C', '')) codigocliente,
    nvl(codigoproducto_apex, codigoproducto_sap) codigoproducto,
    nvl(codigo_producto_cliente, codigoproducto_sap) codigo_producto_cliente,
    nvl(precio_apex, precio_sap) precio,
    nvl(descuento_apex, descuento_sap) descuento,
    cast(null as number) id_inversion,
    nvl(presentacion, 1) presentacion,
    nvl(cantidad_bu_ca_oc_apex, cantidad_solicitada_sap) cantidad_bu_ca_oc,
    nvl(cantidad_bu_ca_solicitado_apex, cantidad_solicitada_sap) cantidad_bu_ca_solicitado,
    nvl(cantidad_bu_ca_solicitado_apex, cantidad_solicitada_sap) - cantidad_facturada cantidad_bu_ca_incump,
    cantidad_facturada cantidad_bu_ca_alcance,
    nvl(cantidad_und_oc_apex, nvl(cantidad_bu_ca_oc_apex, cantidad_solicitada_sap) * nvl(presentacion, 1)) cantidad_und_oc,
    nvl(cantidad_und_solicitado_apex, nvl(cantidad_bu_ca_solicitado_apex, cantidad_solicitada_sap) * nvl(presentacion, 1)) cantidad_und_solicitado,
    (nvl(cantidad_bu_ca_solicitado_apex, cantidad_solicitada_sap) - cantidad_facturada) * nvl(presentacion, 1) cantidad_un_incump,
    cantidad_facturada * nvl(presentacion, 1) cantidad_und_alcance,
    nvl(subtotal_oc_apex, subtotal_solicitado_sap) subtotal_oc,
    nvl(subtotal_solicitado_apex, subtotal_solicitado_sap) subtotal_solicitado,
    case
        when nvl(cantidad_bu_ca_solicitado_apex, cantidad_solicitada_sap) = 0 then 0
        else round((nvl(subtotal_solicitado_apex, subtotal_solicitado_sap) / nvl(cantidad_bu_ca_solicitado_apex, cantidad_solicitada_sap)) * (nvl(cantidad_bu_ca_solicitado_apex, cantidad_solicitada_sap) - cantidad_facturada), 2)
    end subtotal_incump,
    case
        when nvl(cantidad_bu_ca_solicitado_apex, cantidad_solicitada_sap) = 0 then 0
        else round((nvl(subtotal_solicitado_apex, subtotal_solicitado_sap) / nvl(cantidad_bu_ca_solicitado_apex, cantidad_solicitada_sap)) * cantidad_facturada, 2)
    end subtotal_alcance,
    nvl(informacion_adicional_apex, 'Orden SAP ' || numero_orden_sap || ' Linea ' || linea_sap) informacion_adicional,
    nvl(informacion_adicional_2_apex, 'Entregado ' || cantidad_entregada || ' Facturado ' || cantidad_facturada || ' Saldo ' || saldo_sap) informacion_adicional_2,
    cardname cliente_sap,
    producto_sap producto_sap,
    cantidad_entregada,
    cantidad_facturada,
    saldo_sap,
    numero_orden_sap,
    linea_sap,
    target_type,
    nvl(unidad_medida_apex, unidad_medida_sap) unidad_medida,
    case when idpedido_apex is not null then 'S' else 'N' end tiene_pedido_apex
from base B
left join VT_GZM_CLIENTE G
    on G.COMPANIA = '00003'
   and (G.CODIGOCLIENTE = replace(cast(B.cardcode as varchar2(50)), 'C', '') or G.RUC = replace(cast(B.cardcode as varchar2(50)), 'C', ''));
/


/
COMMENT ON TABLE DATA.VT_VTAS_PEDIDOS_INCUMPLIMIENTO_PE IS 'Presenta pedidos de Peru con cantidades pendientes de entrega o facturacion consultados desde SAP.';
COMMENT ON COLUMN DATA.VT_VTAS_PEDIDOS_INCUMPLIMIENTO_PE.ESTADO IS 'Estado publicado del pedido. Valores permitidos: 1 = activo.';
COMMENT ON COLUMN DATA.VT_VTAS_PEDIDOS_INCUMPLIMIENTO_PE.TIPO IS 'Tipo funcional del pedido. Valores permitidos: 1 = pedido; 3 = pedido especial.';
