﻿prompt PROD VIEW DATA.VT_ICOM_CONTRATOAUDITORIA

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_CONTRATOAUDITORIA" ("IDINVERSION", "NOMBREINVERSION", "FECHA", "USUARIO", "CODIGO", "NOMBRE", "TIPOCONTRATO", "AUDITORIATIPO", "COMENTARIO", "DES_AUDITORIATIPO", "IDCONVENIO", "IDCONTRATO", "IDTIPOCONTRATO", "CODIGOPDV", "CODIGODISTRIBUIDOR", "FECHAINICIO", "FECHAFIN", "METAMENSUAL", "COMPANIA") AS 
  Select a.idinversion, i.nombre nombreinversion, a.fecha, a.usuario, nvl(a.codigopdv, a.codigogrupo) codigo,
        decode(nvl(a.codigopdv,'0'), '0', cl.nombres, pdv.razonsocial) Nombre, tc.descripcion tipoContrato, 
        a.auditoriaTipo, a.comentario, cta.descripcion des_auditoriaTipo, i.id||'-'||cp.secuencial idConvenio, 
        a.idcontrato, a.tipocontrato idtipocontrato, a.codigoPDV, cp.codigogrupo codigodistribuidor, 
        i.FECHAINICIO, i.FECHAFIN,METAMENSUAL,
        i.compania
    from data.t_icom_contratoauditoria a
        inner join data.t_icom_inversiones i on (a.idinversion = i.id)
        left join data.vt_gzm_cliente cl on (i.compania=cl.compania and a.codigogrupo = cl.codigocliente ) 
        left join data.t_trad_cliente pdv on ( a.codigopdv = trim(pdv.codigopdv) )
        left join data.t_icom_cliente_pdv cp on (a.idinversion =cp.idinversion and  a.codigopdv = cp.codigopdv  )
        left join DATA.T_CORP_UDC tc on (tc.id_cabecera = 'TIPOCONTRA' and a.tipocontrato = tc.valor and i.compania= tc.CODIGOCOMPANIA)
        left join data.vt_icom_contratotipoaud cta on (a.auditoriaTipo = cta.id ) where  1=1;
/

