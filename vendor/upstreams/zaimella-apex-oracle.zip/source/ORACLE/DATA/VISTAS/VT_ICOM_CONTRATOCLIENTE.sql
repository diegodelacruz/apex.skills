﻿prompt PROD VIEW DATA.VT_ICOM_CONTRATOCLIENTE

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_CONTRATOCLIENTE" ("IDINVERSION", "NOMBREINVERSION", "IDETAPA", "CODIGOCLIENTE", "NOMBRECLIENTE", "FECHAINICIO", "FECHAFIN", "CODIGOCANAL", "CANAL", "ESTADOCONTRATO", "TIPOCONTRATO", "CONTRATOREPRESENTANTE", "CONTRATOCORREO", "IDCONTRATO", "ID_TIP_CONTRATO", "IDCONTRATOMANUAL", "ID_TIP_CONTRATOMANUAL") AS 
  select i.id idinversion, i.nombre nombreinversion, i.idetapa, g.codigogrupo codigocliente, 
cl.nombres nombrecliente, g.fechainicio, g.fechafin, cl.codigocanal, cl.canal, 
case when ( g.estado = 0 and nvl(g.negociacion,0) = 0 ) then 'SIN CORREO' 
     when ( g.estado = 1 and nvl(g.negociacion,0) = 0 ) then 'PENDIENTE APROBACIÃ“N' 
	 when nvl(g.negociacion,0) = 3  then 'PENDIENTE APROBACIÃ“N' end estadocontrato,  
case when ( g.estado in (0,1)  and nvl(g.negociacion,0) = 0 ) then 'CONTRATO' 
	 when ( i.estado = 3 and nvl(g.negociacion,0) in (1,3) ) then 'ADEMDUM' end tipocontrato, 
	 g.contratorepresentante, g.contratocorreo, co.id idcontrato, co.tipocontrato id_tip_contrato,
     cm.id idcontratomanual, cm.tipocontrato id_tip_contratomanual 
from  data.vt_icom_inversiontipo it 
inner join data.t_icom_inversiones i on (it.idinversiontipo = i.idinversiontipo )
inner join data.t_icom_inversion_cliente_g g on (i.id = g.idinversion 
                                   and ( (g.estado in (0,1) and nvl(g.negociacion,0) = 0)  
								        or (i.estado = 3 and nvl(g.negociacion,0) in (1,3) ) ) )
inner join data.vt_gzm_cliente cl on (i.compania=cl.compania and g.codigogrupo = cl.codigocliente ) 
left join ( select ctt.id, ctt.tipocontrato, cc.idinversion, cc.codigogrupo
            from  data.t_icom_contratos ctt 
                inner join ( select distinct idcontrato, idinversion, codigogrupo from  data.t_icom_contrato_contenido ) cc
                on ( cc.idcontrato = ctt.id  ) 
            where nvl(ctt.subtipocontrato,1) = 1 --formato electronico    
              and ctt.estado = 1 
   ) co on ( g.idinversion = co.idinversion and g.codigogrupo = co.codigogrupo 
         and co.tipocontrato =  case when ( g.estado in (0,1) and nvl(g.negociacion,0) = 0 ) then 1
                                     when nvl(g.negociacion,0) = 3  then 3 end 
         )
left join ( select ctt.id, ctt.tipocontrato, cc.idinversion, cc.codigogrupo
            from  data.t_icom_contratos ctt 
                inner join ( select distinct idcontrato, idinversion, codigogrupo from  data.t_icom_contrato_contenido ) cc
                on ( cc.idcontrato = ctt.id  ) 
            where nvl(ctt.subtipocontrato,1) = 2 --formato manual   
            and ctt.estado = 1 
   ) cm on ( g.idinversion = cm.idinversion and g.codigogrupo = cm.codigogrupo 
         and cm.tipocontrato =  case when ( g.estado in (0,1) and nvl(g.negociacion,0) = 0 ) then 1
                                     when nvl(g.negociacion,0) = 3  then 3 end 
         )  
where it.firmacontrato = 1 and i.grupal=0;
/

