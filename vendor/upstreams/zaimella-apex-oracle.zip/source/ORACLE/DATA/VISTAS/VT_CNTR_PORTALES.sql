create or replace view data.vt_cntr_portales as
select id_portal,
       compania,
       nombre_portal,
       url_base,
       descripcion,
       requiere_captcha,
       case requiere_captcha when 1 then 'Si' else 'No' end requiere_captcha_txt,
       requiere_login,
       case requiere_login when 1 then 'Si' else 'No' end requiere_login_txt,
       estado,
       fecha_creacion,
       usuario_creacion,
       fecha_actualizacion,
       usuario_actualizacion
  from data.t_cntr_portales;
