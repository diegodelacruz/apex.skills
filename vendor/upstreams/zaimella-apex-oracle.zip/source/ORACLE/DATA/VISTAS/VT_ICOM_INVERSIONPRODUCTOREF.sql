﻿prompt PROD VIEW DATA.VT_ICOM_INVERSIONPRODUCTOREF

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_INVERSIONPRODUCTOREF" ("IDINVERSION", "INVERSION", "IDPROCESO", "DESCRIPCION", "USUARIOGESTION", "PORCENTAJE", "FECHAINICIO", "FECHAFIN", "ESTADO", "CODIGOPRODUCTO", "PRODUCTO", "LINEANEGOCIO", "MARCA", "SUBMARCA", "CODIGOBARRA", "CODIGOPRODUCTOPADRE", "STOCKPADRE", "STOCKPRODUCTO", "NOMBRES", "CANAL", "COMPANIA") AS 
  select ip.idinversion, ip.inversion, ip.idproceso, ip.descripcion, ip.usuariogestion, ip.porcentaje,
        ip.fechainicio, ip.fechafin, ip.estado, pr.codigoproducto, pr.producto, pr.lineanegocio,
        pr.marca, pr.submarca, pr.codigobarra, pr.codigoproductopadre,
        DATA.PK_JDE_INVENTARIO.F_STOCKPRODUCTO(pr.codigoproductopadre, '17003') stockPadre, 
        DATA.PK_JDE_INVENTARIO.F_STOCKPRODUCTO(pr.codigoproducto, '17003') stockProducto,
        '' nombres, '' canal, ip.compania
from data.vt_icom_inversionProcesoActivo ip
    inner join data.t_icom_inversion_producto pr on 
        ( pr.idinversion = ip.idinversion and
        pr.CODIGOPRODUCTO<>pr.cODIGOPRODUCTOPADRE
        )
where ip.idproceso = 10;
/

