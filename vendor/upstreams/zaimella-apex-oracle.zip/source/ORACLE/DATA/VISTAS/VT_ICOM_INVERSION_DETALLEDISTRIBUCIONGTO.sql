﻿prompt PROD VIEW DATA.VT_ICOM_INVERSION_DETALLEDISTRIBUCIONGTO

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_INVERSION_DETALLEDISTRIBUCIONGTO" ("ID", "IDGASTO", "IDINVERSION", "TIPO", "TIPO_DESC", "TABLAID", "TABLADESCRIPCION", "DESCRIPCION", "COMPANIA", "VALOR", "ESELIMINAR", "CODIGOBARRA", "VALORDISTRIBUCION", "PESODISTRIBUCION", "VALORINICIAL", "CODIGOPRODUCTO", "VALORPEQ", "VALORMETA", "VALORREAL", "NOMBREPRODUCTO", "LINEANEGOCIO", "MARCA", "SUBMARCA", "CANAL", "CODIGOGRUPO", "GRUPO", "CODIGOCLIENTE", "NOMBRES", "AUDITORIAUSUARIO", "AUDITORIAFECHA", "OBSERVACIONES", "DOCUMENTOTIPO", "DOCUMENTO", "GASTOTIPO", "FECHA_ACTIVIDAD", "FECHA_ACTIVIDAD_FIN") AS 
  with producto as (
    SELECT  TRIM( (CODIGOPRODUCTO))CODIGOPRODUCTO, (CODIGOCORTO)CODIGOCORTO, (CODIGOALTERNO)CODIGOALTERNO, trim(NOMBREPRODUCTO)NOMBREPRODUCTO,
    prd.codigoproducto||'-'|| prd.nombreproducto||'('||prd.codigocorto||')' n_producto,
    CODIGOBARRA, TEXTOBUSQUEDA, UNIDADPRINCIPAL,
    codigolinea ||'-'||LINEANEGOCIO LINEANEGOCIO,
    CODIGOMARCA ||'-'||MARCA MARCA,
    codigosubmarca ||'-'||SUBMARCA SUBMARCA,
    ESTADO, TIPOPRODUCTO, COMPANIA
    FROM vt_gzm_producto prd 
)

--,GATOS as(
SELECT  
    GTO.ID,
    GTO.IDGASTO,
    nvl(gto.IDINVERSION, g.IDINVERSION) IDINVERSION,
    gto.tipo,
    case gto.tipo
        when 1 then 'PROPRUESTA' 
        when 2 then 'PUNTO DE EQUILIBRIO' 
        when 3 then 'REAL' 
    END tipo_DESC,
    gto.TABLAID,
    gto.TABLADESCRIPCION,
    nvl(gto.DESCRIPCION, g.fuente) DESCRIPCION,
    gto.COMPANIA,
    gto.VALOR,
    GTO.ESELIMINAR,
    GTO.codigobarra,
    VALORDISTRIBUCION, PESODISTRIBUCION, VALORINICIAL,gto.codigoproducto,
    g.VALORPEQ, g.VALORMETA, g.VALORREAL,
    DECODE(prd.codigoproducto,NULL,' ',prd.n_producto )nombreproducto,
    DECODE(prd.lineanegocio,NULL,' ',prd.lineanegocio )lineanegocio,
    DECODE(prd.marca,NULL,' ',prd.marca )marca,
    DECODE(prd.marca,NULL,' ',prd.submarca )submarca,
    (cli.canal   )canal,
    cli.CODIGOGRUPO CODIGOGRUPO, 
    cli.CODIGOGRUPO ||'-'||cli.grupo grupo,
    gto.codigocliente,
    (cli.NOMBRES   )nombres,
    gto.USERCREA AUDITORIAUSUARIO,
    trunc(gto.FECHCREA) AUDITORIAFECHA,
    nvl(gto.OBSERVACION, nvl(gto.DESCRIPCION, g.OBSERVACION)) OBSERVACIONES,
    gto.DOCUMENTOTIPO,
    gto.DOCUMENTO
    , g.GASTOTIPO ||' '||g.TIPO GASTOTIPO
    , gto.fecha_actividad
    , gto.fecha_actividad_fin
FROM T_ICOM_INVERSION_GASTO g
inner join t_icom_inversiones i on   i.id=g.idinversion and  i.idpadre is null
left join T_ICOM_INVERSION_GASTODISTRIBUCION gto on (g.IDINVERSION=gto.IDINVERSION and g.IDGASTO=gto.IDGASTO)
left JOIN vt_gzm_cliente  cli ON cli.codigocliente=nvl(gto.codigocliente, gto.codigogrupo)
left JOIN producto prd ON (  trim(gto.codigoproducto)= trim(prd.codigoproducto) and gto.compania=prd.compania  );
/

