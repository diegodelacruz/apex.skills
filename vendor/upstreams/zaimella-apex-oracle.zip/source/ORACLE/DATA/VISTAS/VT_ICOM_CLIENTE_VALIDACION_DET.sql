﻿prompt PROD VIEW DATA.VT_ICOM_CLIENTE_VALIDACION_DET

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_CLIENTE_VALIDACION_DET" ("IDINVERSION", "IDAGRUPACION", "IDVALIDACIONTIPO", "CODIGOCLIENTE", "CLIENTE", "CODIGOGRUPO", "GRUPO", "CODIGOCANAL", "CANAL", "CANALALTERNO", "CODIGOPRODUCTO", "NOMBREPRODUCTO", "CODIGOLINEA", "LINEANEGOCIO", "CODIGOMARCA", "MARCA", "CODIGOSUBMARCA", "SUBMARCA", "FACTURA", "FACTURA_FECHA", "NOTA_CREDITO", "NOTA_CREDITO_DES", "VALORVENTA", "PRECIOLISTA", "PCT_APLICACION", "CLI_CANTIDAD", "CLI_VALOR", "CLI_DESCUENTO", "VALORZAIMELLA", "VALORDIFERENCIA", "NC_VALOR", "NC_DESCRIPCION", "VALOREXCEPCION", "VAL_VENTAUND") AS 
  select cv.idinversion,cv.idagrupacion , cv.idvalidaciontipo,
---cliente 
C.CODIGOCLIENTE,c.NOMBRES Cliente,  C.CODIGOGRUPO, c.GRUPO Grupo, c.CODIGOCANAL, c.CANAL, c.CANALALTERNO,
--Producto 
p.CODIGOPRODUCTO, p.NOMBREPRODUCTO, p.CODIGOLINEA, p.LINEANEGOCIO, p.CODIGOMARCA, p.MARCA, p.CODIGOSUBMARCA, p.SUBMARCA,
--valores
factura,fac_fecha factura_fecha,nc_valor nota_credito, nc_descripcion nota_credito_des,
round(det.VALORVENTA,2) VALORVENTA, det.PRECIOLISTA, det.PCT_APLICACION, det.CLI_CANTIDAD,
round(det.CLI_VALOR,2) CLI_VALOR ,round(det.CLI_DESCUENTO,2) CLI_DESCUENTO, 
round(det.VALORZAIMELLA,4) VALORZAIMELLA, round(det.VALORDIFERENCIA,2) VALORDIFERENCIA,
round(NC_VALOR,2) NC_VALOR, NC_DESCRIPCION, round(VALOREXCEPCION,2) VALOREXCEPCION, round(VAL_VENTAUND,2) VAL_VENTAUND
from data.t_icom_cliente_validacion cv
    inner join data.t_icom_cliente_validacion_det det on (cv.id = det.idvalidacion and cv.codigogrupo = det.codigogrupo)
    inner join vt_gzm_cliente c on (det.codigoCliente=c.codigoCliente) 
    inner join vt_gzm_producto p on (det.codigoProducto=p.codigoProducto)
--where IDINVERSION = 1025
--and cv.idvalidaciontipo = :P267_VALIDACION_TIPO;;
/

