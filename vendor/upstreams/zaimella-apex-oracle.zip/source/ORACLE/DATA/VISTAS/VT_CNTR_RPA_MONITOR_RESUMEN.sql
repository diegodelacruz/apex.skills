create or replace view data.vt_cntr_rpa_monitor_resumen as
select e.id_ejecucion,
       e.id_configuracion,
       c.nombre configuracion,
       e.compania,
       e.usuario_apex,
       e.estado,
       e.fecha_inicio fecha_inicio_ejecucion,
       e.fecha_fin fecha_fin_ejecucion,
       min(d.fecha_inicio) inicio_detalle,
       max(d.fecha_fin) fin_detalle,
       count(distinct d.id_documento) cantidad_documentos,
       count(distinct case when d.id_sujeto is not null then d.tipo_sujeto || ':' || to_char(d.id_sujeto) end) cantidad_sujetos,
       sum(case when d.estado = 'COMPLETADO' then 1 else 0 end) cantidad_detalle_exito,
       sum(case when d.estado = 'ERROR' then 1 else 0 end) cantidad_detalle_error
  from data.t_cntr_rpa_ejecuciones e
  join data.t_cntr_configuraciones c
    on c.id_configuracion = e.id_configuracion
   and c.compania = e.compania
  left join data.t_cntr_rpa_ejecuciones_detalle d
    on d.id_ejecucion = e.id_ejecucion
 group by e.id_ejecucion,
          e.id_configuracion,
          c.nombre,
          e.compania,
          e.usuario_apex,
          e.estado,
          e.fecha_inicio,
          e.fecha_fin;
