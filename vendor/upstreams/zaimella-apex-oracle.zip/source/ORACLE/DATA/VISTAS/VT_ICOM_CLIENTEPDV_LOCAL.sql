﻿prompt PROD VIEW DATA.VT_ICOM_CLIENTEPDV_LOCAL

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_CLIENTEPDV_LOCAL" ("CODIGOPDV", "NUMERO", "NOMBRECLIENTE", "CODIGOLOCAL", "NOMBRECOMERCIAL", "NOMBRECONOCIDO", "CODIGOGRUPO", "ESTADO", "COMPANIA") AS 
  (select cli.codigopdv, cll.numero, cli.razonsocial NombreCliente, cll.codigolocal, cll.nombrecomercial,
 cll.nombreconocido, cli.codigogrupo, cll.estado, cli.compania 
from data.t_trad_clientelocal  cll
    INNER JOIN data.t_trad_cliente cli ON (cli.codigopdv = cll.codigopdv) );
/

