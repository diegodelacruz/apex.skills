create or replace view data.vt_cntr_rpa_monitor as
select e.id_ejecucion,
       e.id_configuracion,
       c.nombre configuracion,
       e.compania,
       e.usuario_apex,
       e.tipo_ejecucion,
       e.ambiente,
       e.estado,
       e.fecha_inicio,
       e.fecha_fin,
       e.mensaje,
       count(d.id_ejecucion_detalle) total_detalles,
       sum(case when d.estado = 'COMPLETADO' then 1 else 0 end) completados,
       sum(case when d.estado in ('ERROR', 'FINALIZADA_CON_ERROR') then 1 else 0 end) errores,
       sum(case when d.estado in ('EN_PROCESO', 'PENDIENTE_INTERVENCION', 'REINTENTABLE') then 1 else 0 end) pendientes
  from data.t_cntr_rpa_ejecuciones e
  join data.t_cntr_configuraciones c
    on c.id_configuracion = e.id_configuracion
   and c.compania = e.compania
  left join data.t_cntr_rpa_ejecuciones_detalle d
    on d.id_ejecucion = e.id_ejecucion
 group by e.id_ejecucion,
          e.id_configuracion,
          c.nombre,
          e.compania,
          e.usuario_apex,
          e.tipo_ejecucion,
          e.ambiente,
          e.estado,
          e.fecha_inicio,
          e.fecha_fin,
          e.mensaje;
/

comment on table data.vt_cntr_rpa_monitor is 'Resumen descriptivo de ejecuciones RPA para el monitor APEX.';
comment on column data.vt_cntr_rpa_monitor.id_ejecucion is 'Identificador interno de la ejecucion RPA.';
comment on column data.vt_cntr_rpa_monitor.id_configuracion is 'Identificador interno de la configuracion de captura.';
comment on column data.vt_cntr_rpa_monitor.configuracion is 'Nombre visible de la configuracion de captura.';
comment on column data.vt_cntr_rpa_monitor.compania is 'Compania propietaria de la ejecucion.';
comment on column data.vt_cntr_rpa_monitor.usuario_apex is 'Usuario APEX propietario de la ejecucion.';
comment on column data.vt_cntr_rpa_monitor.tipo_ejecucion is 'Tipo de inicio manual o automatico.';
comment on column data.vt_cntr_rpa_monitor.ambiente is 'Ambiente informado por el agente RPA.';
comment on column data.vt_cntr_rpa_monitor.estado is 'Estado consolidado de la ejecucion.';
comment on column data.vt_cntr_rpa_monitor.fecha_inicio is 'Fecha y hora de inicio.';
comment on column data.vt_cntr_rpa_monitor.fecha_fin is 'Fecha y hora de finalizacion.';
comment on column data.vt_cntr_rpa_monitor.mensaje is 'Mensaje consolidado de la ejecucion.';
comment on column data.vt_cntr_rpa_monitor.total_detalles is 'Cantidad total de documentos y sujetos procesados.';
comment on column data.vt_cntr_rpa_monitor.completados is 'Cantidad de detalles completados con evidencia.';
comment on column data.vt_cntr_rpa_monitor.errores is 'Cantidad de detalles terminados con error.';
comment on column data.vt_cntr_rpa_monitor.pendientes is 'Cantidad de detalles aun no terminales.';

