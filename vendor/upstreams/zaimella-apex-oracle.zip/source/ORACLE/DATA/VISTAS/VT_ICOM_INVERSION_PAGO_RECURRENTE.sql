﻿prompt PROD VIEW DATA.VT_ICOM_INVERSION_PAGO_RECURRENTE

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_INVERSION_PAGO_RECURRENTE" ("IDINVERSION", "IDPAGO", "OBSERVACION") AS 
  with inversiones as (
SELECT DISTINCT id idinversion, 
  TO_NUMBER(TRIM(REGEXP_SUBSTR(i.pago_recurrente, '[^,]+', 1, LEVEL))) AS idpago
FROM t_icom_inversiones i
WHERE i.pago_recurrente IS NOT NULL
CONNECT BY REGEXP_SUBSTR(i.pago_recurrente, '[^,]+', 1, LEVEL) IS NOT NULL
   AND PRIOR i.rowid = i.rowid
   AND PRIOR SYS_GUID() IS NOT NULL
ORDER BY idpago)
select i.idinversion, i.idpago, n.observacion from inversiones i inner join t_comp_negociacion n  on n.id=idpago;
/

