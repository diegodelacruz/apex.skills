﻿prompt PROD VIEW DATA.VT_ICOM_NEGOCIACION

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_NEGOCIACION" ("CODIGOCANAL", "CODIGOGRUPO", "NOMBREGRUPO", "CODIGOCLIENTE", "NOMBRECLIENTE", "ID", "ETAPA", "NOMBREINVERSION", "FECHAINICIO", "FECHAFIN", "AREA", "LINEANEGOCIO", "MARCA", "SUBMARCA", "PRODUCTO", "CODIGOBARRA", "NEGOCIACION", "FORMAPAGO", "EJECUTIVO", "DESCUENTOCALCULADO", "DESCUENTO", "COMPANIA") AS 
  select 
g.codigocanal, g.codigogrupo, g.nombres nombreGrupo, cl.codigocliente, a.nombres nombrecliente,
i.id,  IDETAPA      ETAPA, i.nombre nombreInversion, i.fechainicio, i.fechafin, IDAREA      AREA,
 d.lineanegocio lineanegocio,  d.marca  marca, 
d.submarca submarca,  d.producto producto, d.codigobarra codigobarra , 
g.negociacion,  fp.descripcion formapago, 
a.ejecutivo, d.descuentocalculado*100 descuentocalculado, descuentocliente descuento,
i.COMPANIA
from data.t_icom_inversiones i
inner join data.t_icom_inversion_cliente_g g on (i.id = g.idinversion )
inner join data.t_icom_inversion_cliente cl on (g.idinversion = cl.idinversion and g.codigogrupo = cl.codigogrupo)
left join data.t_icom_producto_descuento d 
    on ( cl.idinversion = d.idinversion and cl.codigocliente = d.codigocliente )
inner join data.VT_GZM_CLIENTE A on (i.COMPANIA=A.COMPANIA AND cl.codigocliente = a.codigoCLIENTE)
left join data.vt_icom_formapago fp on (fp.idformapago=g.idformapago)
--LEFT JOIN DATA.VT_GZM_PRODUCTO PR ON (D.CODIGOBARRA=d.CODIGOBARRA AND I.COMPANIA=d.COMPANIA)   
where IDINVERSIONTIPO=1 and idpadre is null and grupal=0;
/

