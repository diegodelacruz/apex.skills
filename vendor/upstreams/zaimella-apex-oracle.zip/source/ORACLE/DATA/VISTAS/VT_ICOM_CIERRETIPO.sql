﻿prompt PROD VIEW DATA.VT_ICOM_CIERRETIPO

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_CIERRETIPO" ("ID", "DESCRIPCION", "ESTADO", "COMPANIA") AS 
  select id_tabla id, descripcion, activo estado,CODIGOCOMPANIA COMPANIA
  from data.T_CORP_UDC
  where id_cabecera = 'ICOM_CTIPO';
/

