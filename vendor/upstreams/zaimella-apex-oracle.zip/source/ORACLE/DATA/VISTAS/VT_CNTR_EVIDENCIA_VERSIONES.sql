create or replace view data.vt_cntr_evidencia_versiones as
select e.id_evidencia,
       e.id_documento,
       e.tipo_sujeto,
       e.id_sujeto,
       a.numeroarchivo,
       row_number() over (
           partition by e.id_evidencia
           order by a.fecha, a.numeroarchivo) version,
       a.filename,
       a.mimetype,
       a.estado,
       a.fecha,
       a.nombreusuario usuario_registro,
       a.observacion
  from data.t_cntr_evidencias e
  join files.t_apex_archivos a
    on a.tabla = 'T_CNTR_EVIDENCIAS'
   and a.id_tabla = to_char(e.id_evidencia)
   and a.tipo = 'EVIDENCIA_CNTR';
/

comment on table data.vt_cntr_evidencia_versiones is 'Historial completo de archivos versionados por cabecera documental CNTR.';
comment on column data.vt_cntr_evidencia_versiones.id_evidencia is 'Identificador de la cabecera documental.';
comment on column data.vt_cntr_evidencia_versiones.id_documento is 'Identificador del tipo de documento.';
comment on column data.vt_cntr_evidencia_versiones.tipo_sujeto is 'Tipo de propietario PERSONA o EMPRESA.';
comment on column data.vt_cntr_evidencia_versiones.id_sujeto is 'Identificador interno del propietario.';
comment on column data.vt_cntr_evidencia_versiones.numeroarchivo is 'Identificador del archivo almacenado en FILES.';
comment on column data.vt_cntr_evidencia_versiones.version is 'Numero secuencial de version por evidencia.';
comment on column data.vt_cntr_evidencia_versiones.filename is 'Nombre original del archivo.';
comment on column data.vt_cntr_evidencia_versiones.mimetype is 'Tipo MIME del archivo.';
comment on column data.vt_cntr_evidencia_versiones.estado is 'ACTIVO para la ultima version o REEMPLAZADO para historicas.';
comment on column data.vt_cntr_evidencia_versiones.fecha is 'Fecha de registro del archivo.';
comment on column data.vt_cntr_evidencia_versiones.usuario_registro is 'Usuario que registro el archivo.';
comment on column data.vt_cntr_evidencia_versiones.observacion is 'Metadatos funcionales de la version.';
