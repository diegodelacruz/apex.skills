﻿prompt TEST VIEW DATA.VT_VTAS_PEDIDOS

  CREATE OR REPLACE FORCE EDITIONABLE VIEW VT_VTAS_PEDIDOS ("IDPEDIDO", "IDPADRE", "TIPO", "EXP_PARTIDA", "LINEA", "GRUPO", "CODIGOCLIENTE", "CODIGOGRUPO", "CODIGOPRODUCTOCLIENTE", "NOMBREPRODUCTO", "CODIGOBARRA", "CODIGOPRODUCTO", "LINEA_NEGOCIO", "ESTADO_PRODUCTO", "PROMOCIONAL", "ESTADO", "ESTADO_CUBICAJE", "ESTADO_PEDIDO", "TIPOINACTIVO", "OBSERVACION", "INFORMACIONADICIONAL", "UNIDAD_MEDIDA", "ORDENCOMPRA", "LICITACION", "FECHAENTREGA", "PRESENTACION", "CANTIDAD_BU_CA", "CANTIDAD_UND", "CANTIDAD_BU_CA_OC", "CANTIDAD_OC", "METROSCUBICOS", "VOLUMEN", "PRECIO", "CANTIDADSUGERIDA", "PRECIO_OC", "DESCUENTO", "DESCUENTO_OC", "ICE", "PRECIO_OC_FINAL", "PRECIO_FINAL", "TOTAL", "TOTAL_OC", "TOTAL_DIFERENCIA", "FECHA_PEDIDO", "COMPANIA") AS 
  SELECT pe.idpedido,
       c.idpadre,
       c.tipo,
       c.exp_partida,
       pe.linea,
       pe.grupo,
       NVL(pe.codigocliente, c.codigocliente) codigocliente,
       c.codigogrupo,
       pe.codigoproductocliente,
       pe.nombreproducto nombreproducto,
       pe.codigobarra,
       NVL(pe.codigoproductoreferencia, pe.codigoproducto) codigoproducto,
       p.lineanegocio linea_negocio,
       CASE
           WHEN p.estado IS NULL THEN ''
           WHEN p.estado = 1 THEN 'ACTIVO'
           ELSE 'INACTIVO'
       END estado_producto,
       CASE
           WHEN pe.codigoproductoreferencia = pe.codigoproducto THEN 'NO'
           ELSE 'SI'
       END promocional,
       pe.estado,
       estado_cubicaje,
       c.estado estado_pedido,
       pe.tipoinactivo,
       pe.observacion,
       informacionadicional,
       unidad_medida,
       ordencompra,
       c.licitacion,
       c.fechaentrega,
       pe.cantidadpresentacion AS presentacion,
       CASE
           WHEN c.compania = '00003' AND c.presentacion_oc = '2'
               THEN pe.cantidad_oc
           WHEN c.compania = '00003'
               THEN pe.cantidad / NULLIF(NVL(pe.cantidadpresentacion, 1), 0)
           ELSE pe.cantidad
       END cantidad_bu_ca,
       CASE
           WHEN c.compania = '00003'
               THEN pe.cantidad
           ELSE pe.cantidad * NVL(pe.cantidadpresentacion, 1)
       END cantidad_und,
       CASE
           WHEN c.compania = '00003' AND c.presentacion_oc = '2'
               THEN pe.cantidad_oc
           WHEN c.compania = '00003'
               THEN pe.cantidad_oc / NULLIF(NVL(pe.cantidadpresentacion, 1), 0)
           ELSE pe.cantidadori
       END cantidad_bu_ca_oc,
       pe.cantidad_oc,
       metroscubicos,
       metroscubicos * CASE
           WHEN c.compania = '00003' THEN pe.cantidad
           ELSE pe.cantidad
       END volumen,
       pe.precio,
       pe.cantidadsugerida,
       pe.precio_oc,
       pe.descuento,
       pe.descuento_oc,
       pe.ice,
       CASE
           WHEN c.compania = '00003' THEN ROUND(NVL(precio_oc - (precio_oc * (descuento_oc / 100)), 0), 4)
           ELSE ROUND(NVL(precio_oc - (precio_oc * (descuento_oc / 100)), 0), 2)
       END precio_oc_final,
       CASE
           WHEN c.compania = '00003' THEN ROUND(NVL((precio - (precio * (descuento / 100))) + ice, 0), 4)
           ELSE ROUND(NVL((precio - (precio * (descuento / 100))) + ice, 0), 2)
       END precio_final,
       NVL(ROUND(NVL((precio - (precio * (descuento / 100))) + ice, 0), 2)
           * CASE
                 WHEN c.compania = '00003' THEN pe.cantidad
                 ELSE pe.cantidad * NVL(pe.cantidadpresentacion, 1)
             END, 0) AS total,
       NVL(ROUND(NVL(precio_oc - (precio_oc * (descuento_oc / 100)), 0), 2)
           * CASE
                 WHEN c.compania = '00003' THEN pe.cantidadori
                 ELSE pe.cantidadori * NVL(pe.cantidadpresentacion, 1)
             END, 0) AS total_oc,
       NVL(ROUND(NVL((precio - (precio * (descuento / 100))) + ice, 0), 2)
           * CASE
                 WHEN c.compania = '00003' THEN pe.cantidad
                 ELSE pe.cantidad * NVL(pe.cantidadpresentacion, 1)
             END, 0)
       - NVL(ROUND(NVL(precio_oc - (precio_oc * (descuento_oc / 100)), 0), 2)
           * CASE
                 WHEN c.compania = '00003' THEN pe.cantidadori
                 ELSE pe.cantidadori * NVL(pe.cantidadpresentacion, 1)
             END, 0) total_diferencia,
       auditoriafecha fecha_pedido,
       c.compania
  FROM data.t_vtas_pedidos pe
  JOIN data.t_vtas_pedidos_cab c
    ON pe.idpedido = c.idpedido
  LEFT JOIN data.vt_gzm_producto p
    ON p.codigoproducto = NVL(pe.codigoproductoreferencia, pe.codigoproducto)
   AND p.compania = c.compania
 WHERE pe.idpedido = c.idpedido;
/

