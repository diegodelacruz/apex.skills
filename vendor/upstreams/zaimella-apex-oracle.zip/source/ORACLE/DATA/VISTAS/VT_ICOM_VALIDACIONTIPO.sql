﻿prompt PROD VIEW DATA.VT_ICOM_VALIDACIONTIPO

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_VALIDACIONTIPO" ("ID", "DESCRIPCION", "FLUJOAPROBACION", "ESTADO", "COMPANIA") AS 
  select id_tabla id, descripcion, valor flujoaprobacion, activo estado,CODIGOCOMPANIA COMPANIA
from data.T_CORP_UDC
where id_cabecera = 'ICOM_VALT';
/

