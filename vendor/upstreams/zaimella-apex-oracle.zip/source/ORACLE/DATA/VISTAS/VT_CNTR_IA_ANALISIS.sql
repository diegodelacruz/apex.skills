create or replace view data.vt_cntr_ia_analisis as
select analisis.id_analisis,
       analisis.id_solicitud_analisis,
       analisis.id_configuracion,
       configuracion.nombre configuracion,
       analisis.tipo_sujeto,
       analisis.id_sujeto,
       case analisis.tipo_sujeto when 'PERSONA' then persona.nombres else empresa.razon_social end sujeto,
       analisis.compania,
       analisis.usuario_solicitante,
       analisis.estado,
       analisis.fecha_solicitud,
       analisis.fecha_inicio,
       analisis.fecha_fin,
       analisis.proveedor,
       analisis.modelo,
       analisis.resultado,
       analisis.resumen,
       analisis.confianza,
       analisis.advertencias,
       analisis.error_tecnico
  from data.t_cntr_ia_analisis analisis
  join data.t_cntr_configuraciones configuracion on configuracion.id_configuracion=analisis.id_configuracion
  left join data.t_cntr_personas persona on analisis.tipo_sujeto='PERSONA' and persona.id_persona=analisis.id_sujeto
  left join data.t_cntr_empresas empresa on analisis.tipo_sujeto='EMPRESA' and empresa.id_empresa=analisis.id_sujeto;

comment on table data.vt_cntr_ia_analisis is 'Muestra el historial y progreso de análisis IA por sujeto y configuración.';
