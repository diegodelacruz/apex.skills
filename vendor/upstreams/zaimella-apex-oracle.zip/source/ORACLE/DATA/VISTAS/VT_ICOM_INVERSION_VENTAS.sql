﻿prompt PROD VIEW DATA.VT_ICOM_INVERSION_VENTAS

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_INVERSION_VENTAS" ("ID", "IDINVERSION", "TIPO", "PRECIOLISTA", "VENTAINICIAL", "CANTIDADINICIAL", "COSTOINICIAL", "VENTAREAL", "CANTIDADREAL", "COSTOREAL", "PESO", "VTAESTADO", "CODIGOPRODUCTOVTA", "CODIGOPRODUCTO", "CODIGOCORTO", "CODIGOBARRA", "CODIGOBARRAVTA", "NOMBREPRODUCTO", "COMPANIA", "PRODESTADO", "CODIGOLINEA", "LINEANEGOCIO", "CODIGOMARCA", "MARCA", "CODIGOSUBMARCA", "SUBMARCA", "CODIGOCLIENTE", "NOMBRES", "CODIGOCANAL", "CANAL", "GRUPO", "CODIGOGRUPO", "CLIESTADO", "CRECIMIENTO", "VENTAMETA", "CANTIDADMETA") AS 
  with producto as (
    SELECT  max(CODIGOPRODUCTO)CODIGOPRODUCTO, max(CODIGOCORTO)CODIGOCORTO, max(CODIGOALTERNO)CODIGOALTERNO, max(NOMBREPRODUCTO)NOMBREPRODUCTO,
    CODIGOBARRA, TEXTOBUSQUEDA, UNIDADPRINCIPAL, CODIGOLINEA, LINEANEGOCIO, CODIGOMARCA, MARCA, CODIGOSUBMARCA, SUBMARCA, ESTADO, TIPOPRODUCTO, COMPANIA
    FROM vt_gzm_producto prd 
    where 1=1
    and ESTADO= 1
    and (LINEANEGOCIO is not null and MARCA  is not null and SUBMARCA  is not null )
    group by CODIGOBARRA, TEXTOBUSQUEDA, UNIDADPRINCIPAL, CODIGOLINEA, LINEANEGOCIO, CODIGOMARCA, MARCA, CODIGOSUBMARCA, SUBMARCA, ESTADO, TIPOPRODUCTO, COMPANIA  
)
,sellin as(    SELECT
        vta.id,
        vta.idinversion,
        vta.tipo,
        vta.preciolista,
        vta.ventainicial,
        vta.cantidadinicial,
        vta.costoinicial,
        vta.ventareal,
        vta.cantidadreal,
        vta.costoreal,
        vta.peso,
        vta.estado vtaestado,
        vta.codigoproducto codigoproductovta,
        prd.codigoproducto,
        prd.codigocorto,
        prd.codigobarra,
        vta.codigobarra codigobarravta,
        prd.nombreproducto,
        prd.compania,
        prd.estado prodestado,
        prd.codigolinea,
        prd.lineanegocio,
        prd.codigomarca,
        prd.marca,
        prd.codigosubmarca,
        prd.submarca,
        cli.codigocliente,
        cli.nombres,
        cli.codigocanal,
        cli.canal,
        cli.grupo,
        cli.codigogrupo,
        cli.estado cliestado,
        0 crecimiento,
        vta.ventainicial * 0 /*crecimiento*/ ventameta,
        vta.cantidadinicial * 0 /*crecimiento*/ cantidadmeta

    FROM
             t_icom_inversion_ventas vta
        left JOIN vt_gzm_cliente  cli ON vta.codigocliente = cli.codigocliente
        left JOIN producto prd ON ( prd.codigoproducto = vta.codigoproducto )
        where vta.tipo=1 
)
,sellout as(    SELECT
        vta.id,
        vta.idinversion,
        vta.tipo,
        vta.preciolista,
        vta.ventainicial,
        vta.cantidadinicial,
        vta.costoinicial,
        vta.ventareal,
        vta.cantidadreal,
        vta.costoreal,
        vta.peso,
        vta.estado vtaestado,
        vta.codigoproducto codigoproductovta,
        prd.codigoproducto,
        prd.codigocorto,
        prd.codigobarra,
        vta.codigobarra codigobarravta,
        prd.nombreproducto,
        prd.compania,
        prd.estado prodestado,
        prd.codigolinea,
        prd.lineanegocio,
        prd.codigomarca,
        prd.marca,
        prd.codigosubmarca,
        prd.submarca,
        cli.codigocliente,
        cli.nombres,
        cli.codigocanal,
        cli.canal,
        cli.grupo,
        cli.codigogrupo,
        cli.estado cliestado,
        0 crecimiento,
        vta.ventainicial * 0 /*crecimiento*/ ventameta,
        vta.cantidadinicial * 0 /*crecimiento*/ cantidadmeta

    FROM
             t_icom_inversion_ventas vta
        left JOIN vt_gzm_cliente  cli ON vta.codigocliente = cli.codigocliente
        left JOIN producto prd ON ( prd.codigobarra = vta.codigobarra )
        where vta.tipo=2 
)
SELECT "ID","IDINVERSION","TIPO","PRECIOLISTA","VENTAINICIAL","CANTIDADINICIAL","COSTOINICIAL","VENTAREAL","CANTIDADREAL","COSTOREAL","PESO","VTAESTADO","CODIGOPRODUCTOVTA","CODIGOPRODUCTO","CODIGOCORTO","CODIGOBARRA","CODIGOBARRAVTA","NOMBREPRODUCTO","COMPANIA","PRODESTADO","CODIGOLINEA","LINEANEGOCIO","CODIGOMARCA","MARCA","CODIGOSUBMARCA","SUBMARCA","CODIGOCLIENTE","NOMBRES","CODIGOCANAL","CANAL","GRUPO","CODIGOGRUPO","CLIESTADO","CRECIMIENTO","VENTAMETA","CANTIDADMETA" FROM sellin union all
SELECT "ID","IDINVERSION","TIPO","PRECIOLISTA","VENTAINICIAL","CANTIDADINICIAL","COSTOINICIAL","VENTAREAL","CANTIDADREAL","COSTOREAL","PESO","VTAESTADO","CODIGOPRODUCTOVTA","CODIGOPRODUCTO","CODIGOCORTO","CODIGOBARRA","CODIGOBARRAVTA","NOMBREPRODUCTO","COMPANIA","PRODESTADO","CODIGOLINEA","LINEANEGOCIO","CODIGOMARCA","MARCA","CODIGOSUBMARCA","SUBMARCA","CODIGOCLIENTE","NOMBRES","CODIGOCANAL","CANAL","GRUPO","CODIGOGRUPO","CLIESTADO","CRECIMIENTO","VENTAMETA","CANTIDADMETA" FROM sellout;
/

