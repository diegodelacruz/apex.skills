create or replace view data.vt_cntr_carga_detalles as
select c.id_carga,
       c.compania,
       c.tipo_carga,
       c.total_filas,
       c.filas_validas,
       c.filas_error,
       c.estado as estado_carga,
       c.fecha_creacion as fecha_carga,
       c.usuario_creacion as usuario_carga,
       d.id_carga_detalle,
       d.numero_fila,
       d.clave_referencia,
       d.accion,
       d.estado,
       d.mensaje,
       d.datos_fila,
       d.fecha_creacion
  from data.t_cntr_cargas c
  join data.t_cntr_carga_detalles d
    on d.id_carga = c.id_carga;

comment on table data.vt_cntr_carga_detalles is
    'Muestra el detalle por fila de las cargas masivas Excel de personas y vinculos del modulo CNTR.';
