﻿prompt PROD VIEW DATA.VT_ICOM_CLIENTEREBATEDET

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_CLIENTEREBATEDET" ("IDVALIDACION", "IDINVERSION", "CODIGOGRUPO", "NOMBRES", "NOMBREREBATE", "FILA", "VALOR1", "VALOR2", "VALOR3", "VALOR4", "VALOR5", "VALOR6", "VALOR7", "VALOR8", "VALOR9", "VALOR10", "VALOR11", "VALOR12", "VALOR13", "VALOR14", "VALOR15", "VALOR16", "VALOR17", "VALOR18", "VALOR19", "VALOR20") AS 
  ( select crd.idvalidacion, crd.idinversion, crd.codigogrupo, cli.nombres, reb.nombre nombrerebate, crd.fila, crd.valor1, crd.valor2, crd.valor3, crd.valor4, crd.valor5, crd.valor6, 
      crd.valor7, crd.valor8, crd.valor9, crd.valor10, crd.valor11, crd.valor12, crd.valor13, crd.valor14, crd.valor15, crd.valor16, 
      crd.valor17, crd.valor18, crd.valor19, crd.valor20
  from data.t_icom_clienterebatedet crd
     inner join data.t_icom_cliente_validacion val on
         ( crd.idvalidacion = val.id  )
     inner join data.VT_GZM_CLIENTE cli on (Cli.COMPANIA= val.COMPANIA AND cli.codigoCLIENTE = val.codigogrupo)     
     left join data.t_icom_conf_rebate reb on ( crd.idrebate = reb.id and val.compania = reb.compania)
);
/

