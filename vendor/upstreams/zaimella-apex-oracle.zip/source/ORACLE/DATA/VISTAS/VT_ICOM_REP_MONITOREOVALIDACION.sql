﻿prompt PROD VIEW DATA.VT_ICOM_REP_MONITOREOVALIDACION

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_REP_MONITOREOVALIDACION" ("ID", "CLIENTE", "INVERSIONTIPO", "AREA", "ORIGEN", "TIPO", "IDVALIDACION", "IDAGRUPACION", "MARCA", "LINEANEGOCIO", "NOMBRE", "VAL_FECHAINICIO", "VAL_FECHAFIN", "FORMAPAGO", "VALOR", "ESTADO", "APROBADOR", "FEC_ENVIO", "FEC_APROBADO", "CLI_FECHAINICIO", "CLI_FECHAFIN", "NEGOCIACION", "VALIDACIONTIPO", "CODIGOGRUPO", "INV_FECHAINICIO", "INV_FECHAFIN", "OBSERVACION", "TOT_VALORCLIENTE", "TOT_VALORZAIMELLA", "TOT_VALOREXCEPCION", "DIFERENCIA", "IDREBATE", "PERIODO", "USUARIO_CREACION", "COMPANIA") AS 
  WITH flujo_aprobacion_filtrado AS (
    SELECT *
    FROM (
        SELECT f.*,
               ROW_NUMBER() OVER (
                   PARTITION BY f.entidad_id
                   ORDER BY f.fecha_inicio DESC
               ) AS rn
        FROM data.T_FLUJO_APROBACION_CAB f
        WHERE f.codmodulo = 'ICOM'
          AND f.entidad_clase = 'VALIDACION_INVERSION'
          AND f.estado IN ('APROBADO', 'EN_PROCESO')
    )
    WHERE rn = 1
)
SELECT i.id,
       gc.nombres cliente,
       i.inversiontipo,
       i.area,
       i.origen,
       i.tipo,
       va.id idvalidacion,
       IDAGRUPACION,
       DATA.PK_ICOM_COMMONS.F_VerMarca(P_ID => i.id) marca,
       DATA.PK_ICOM_COMMONS.F_VERLINEANEGOCIO(P_ID => i.id) lineanegocio,
       i.nombre,
       va.val_fechainicio,
       va.val_fechafin,
       fp.descripcion formapago,
       va.tot_valorzaimella + NVL(va.tot_valorexcepcion, 0) valor,
       va.estado,
       NVL(f.USUARIOACTUAL, va.USUARIOCREACION) APROBADOR,
       NVL(f.fecha_inicio, va.FECHACREACION) fec_envio,
       CASE
           WHEN f.id IS NOT NULL THEN f.FECHA_FIN
           ELSE va.FECHACREACION
       END fec_aprobado,
       g.fechainicio cli_fechainicio,
       g.fechafin cli_fechafin,
       g.negociacion,
       vt.descripcion validaciontipo,
       g.codigogrupo,
       i.fechainicio inv_fechainicio,
       i.fechafin inv_fechafin,
       va.OBSERVACIONES observacion,
       NVL(va.tot_valorcliente, 0) tot_valorcliente,
       NVL(va.tot_valorzaimella, 0) tot_valorzaimella,
       NVL(va.tot_valorexcepcion, 0) tot_valorexcepcion,
       ((NVL(va.tot_valorzaimella, 0) + NVL(tot_valorexcepcion, 0)) - NVL(va.tot_valorcliente, 0)) DIFERENCIA,
       va.idrebate,
       va.periodo,
       USUARIOCREACION USUARIO_CREACION,
       I.COMPANIA
FROM data.vt_icom_inversiones i
         INNER JOIN data.T_ICOM_INVERSION_CLIENTE_G g
             ON i.id = g.idinversion
         INNER JOIN data.VT_GZM_CLIENTE gc
             ON gc.COMPANIA = i.COMPANIA AND gc.codigoCLIENTE = g.codigogrupo
         INNER JOIN data.t_icom_cliente_validacion va
             ON i.id = va.idinversion AND g.codigogrupo = va.codigogrupo
         LEFT JOIN data.vt_icom_formapago fp
             ON g.idformapago = fp.idformapago
         LEFT JOIN flujo_aprobacion_filtrado f
             ON f.entidad_id = TO_CHAR(va.idagrupacion)
         LEFT JOIN data.VT_ICOM_VALIDACIONTIPO vt
             ON va.idvalidaciontipo = vt.id
WHERE i.idpadre IS NULL
  AND i.idetapa IN (2, 3, 7, 4);
/

