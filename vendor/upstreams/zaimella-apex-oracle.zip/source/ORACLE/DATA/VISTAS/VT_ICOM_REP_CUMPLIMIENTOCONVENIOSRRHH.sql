﻿prompt PROD VIEW DATA.VT_ICOM_REP_CUMPLIMIENTOCONVENIOSRRHH

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_REP_CUMPLIMIENTOCONVENIOSRRHH" ("IDINVERSION", "IDCONVENIO", "NOMBREINVERSION", "FECHA", "USUARIO", "CODIGO", "NOMBRE", "TIPOCONTRATO", "AUDITORIATIPO", "DES_AUDITORIATIPO", "COMENTARIO", "DISTRIBUIDOR", "IDZONA", "ZONA", "COORDINADOR", "NOM_COORDINADOR", "FECHAINICIO", "FECHAFIN", "METAMENSUAL", "VENTAREAL", "PERIODO", "CUMPLIMIENTO", "METAPERIODO", "IDVALIDACION", "COMPANIA") AS 
  Select v.IDINVERSION, v.idConvenio, v.NOMBREINVERSION, v.FECHA, v.USUARIO, v.CODIGO, v.NOMBRE, v.TIPOCONTRATO, 

       v.AUDITORIATIPO, v.DES_AUDITORIATIPO, v.COMENTARIO, GC.NOMBRES DISTRIBUIDOR, CL.IDZONA, CL.ZONA, cl.coordinador,
       u.nombres||' '||u.apellidos nom_coordinador , v.FECHAINICIO, v.FECHAFIN,METAMENSUAL
       ,r.VALOR3 ventaReal, r.VALOR6 periodo, nvl(r.VALOR14, r.VALOR11) cumplimiento, 
       case when VALOR2 is null then VALOR9 else  VALOR10 end metaPeriodo, v.id idvalidacion,
       v.COMPANIA
from data.vt_icom_contratoauditoria v
    LEFT JOIN VT_GZM_CLIENTE GC ON ( v.COMPANIA = GC.COMPANIA AND v.codigodistribuidor = GC.CODIGOCLIENTE)
    LEFT JOIN VT_TRAD_CLIENTELOCAL CL ON (CL.CODIGOPDV = v.CODIGOPDV AND cl.matriz = 1 )
    left join data.vt_corp_usuario u on ( u.nombreusuario = cl.coordinador ) 
    left join t_icom_clienterebatedet r on (v.IDINVERSION=r.IDINVERSION 
    and (r.VALOR2=v.CODIGOPDV or r.CODIGOGRUPO= v.CODIGO) and r.FILA>0)
    inner join t_icom_cliente_validacion v on (v.id=r.IDVALIDACION)
where v.AUDITORIATIPO = 2;
/

