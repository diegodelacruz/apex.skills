﻿prompt PROD VIEW DATA.VT_ICOM_CONTRATOPDV_APROBACION

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_CONTRATOPDV_APROBACION" ("IDINVERSION", "NOMBREINVERSION", "FECHAINICIO", "FECHAFIN", "CODIGOPDV", "NOMBRE", "CODIGOGRUPO", "NOMBREGRUPO", "TIPOCONTRATO", "ESTADOCONTRATO", "IDCONTRATO", "ID_TIP_CONTRATO", "IDCONTRATOMANUAL", "ID_TIP_CONTRATOMANUAL", "ESCALA", "IDZONA", "ZONA", "COORDINADOR", "DESARROLLADOR", "SECUENCIAL", "CORREO", "RUC", "COMPANIA", "CONTRATOAPROBAR", "CONTRATOCLAUSURA", "NOTIFICADO") AS 
  select i.id idinversion, i.nombre nombreinversion, i.fechainicio fechainicio, i.fechafin fechafin, 
p.codigopdv, cl.razonsocial nombre, p.codigogrupo, gr.nombres  nombregrupo, 
case when nvl(p.contratoaprobar,0) = 3 then 'ACEPTACION' 
     when nvl(p.contratoclausura,-1) in(1,3) then 'FINIQUITO'
     when nvl(p.contratoaprobar,0) = 4 then 'ACEPTACION' end tipocontrato,
ne.descripcion estadocontrato, co.id idcontrato, nvl(co.tipocontrato,
    case
        when p.contratoclausura in(1,3) then 4
        when p.contratoaprobar in(1,3,4) then 2
    end
) id_tip_contrato, --cheuqear tipo de contrato, valiar que si es nulo dependiendo si estado aporbacion es 4 y si clausura es 1
null idcontratomanual, null id_tip_contratomanual, p.escala, clo.idzona, 
clo.zona,  clo.coordinador, clo.desarrollador, p.secuencial , cl.correo, p.ruc,i.compania, p.contratoaprobar,p.contratoclausura,
case 
    when (nvl(p.contratoclausura, 0) =  3) then 'SI'
    when (nvl(p.contratoclausura, 0) =  1) and p.contratoaprobar = 4 then 'NO'
    when  p.contratoaprobar = 4 then 'SI'
    else 'NO'
    end
notificado

from  data.vt_icom_inversiontipo it 
inner join data.t_icom_inversiones i on ( it.idinversiontipo = i.idinversiontipo )
inner join data.t_icom_cliente_pdv p on (i.id = p.idinversion 
                                         and ( ( nvl(p.estado,-1) = -1  and nvl(p.contratoaprobar,0) in (1,3) and nvl(p.contratoclausura,-1) = -1 ) 
                                              --or (nvl(p.estado,-1) = 1  and nvl(p.contratoaprobar,0) = 4 and nvl(p.contratoclausura,-1) = 1 ) ) )
                                                or (nvl(p.estado,-1) in (1,3) and nvl(p.contratoaprobar,0) = 4 and nvl(p.contratoclausura,-1) in (-1,1,3) ) ) )
left join data.Vt_trad_cliente cl on ( p.codigopdv = trim(cl.codigopdv) )
left join data.vt_gzm_cliente gr on ( gr.compania = i.compania and  p.codigogrupo = gr.codigocliente)
left join data.t_corp_udc ne on ( ne.id_cabecera = 'ICOM_ESPDV'  --and i.compania= ne.CODIGOCOMPANIA
                                and ( ( ne.valor is not null and nvl(p.estado,-1) in (-1,1) /*= -1*/  and nvl(p.contratoaprobar,0) = ne.valor and nvl(p.contratoclausura,-1) = -1) 
                                     or ( ne.valor2 is not null and nvl(p.estado,-1) in(1,3)  and nvl(p.contratoaprobar,0) = 4 and nvl(p.contratoclausura,-1) = ne.valor2  )  ) )
left join ( select ctt.id, ctt.tipocontrato, cc.idinversion, cc.codigopdv
            from  data.t_icom_contratos ctt 
                inner join ( select distinct idcontrato, idinversion, codigopdv from  data.t_icom_contrato_contenido ) cc
                on ( cc.idcontrato = ctt.id  ) 
            where nvl(ctt.subtipocontrato,1) = 1 --formato electronico    
			and ctt.estado = 1 
   ) co on ( p.idinversion = co.idinversion and p.codigopdv = co.codigopdv 
         and co.tipocontrato =  case when (nvl(p.estado,-1) = -1  and ne.valor is not null and nvl(p.contratoaprobar,0) = ne.valor and nvl(p.contratoclausura,-1) = -1) then 2 
                                when (nvl(p.estado,-1) = 1  and ne.valor2 is not null and nvl(p.contratoaprobar,0) = 4 and nvl(p.contratoclausura,-1) = ne.valor2 ) then 4 end )

left join data.vt_trad_clientelocal clo
               on ( p.codigopdv = clo.codigopdv and clo.matriz = 1 and clo.estado=1)

 where it.firmacontrato = 2  and i.idetapa in (2,3,7) and (p.contratoaprobar in(1,3,4) or nvl(p.contratoclausura,-1) in (-1,1,3));
/

