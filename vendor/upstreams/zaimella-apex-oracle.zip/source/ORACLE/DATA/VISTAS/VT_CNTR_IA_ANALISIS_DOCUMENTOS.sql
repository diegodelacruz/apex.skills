create or replace view data.vt_cntr_ia_analisis_documentos as
select detalle.id_analisis_documento,
       detalle.id_analisis,
       detalle.id_documento,
       documento.nombre_documento,
       detalle.id_evidencia,
       detalle.numero_archivo,
       detalle.nombre_archivo,
       detalle.prompt_ia,
       detalle.estado_extraccion,
       detalle.texto_extraido,
       detalle.paginas_procesadas,
       detalle.advertencias,
       detalle.error_tecnico,
       detalle.fecha_procesamiento
  from data.t_cntr_ia_analisis_documento detalle
  join data.t_cntr_documentos documento on documento.id_documento=detalle.id_documento;

comment on table data.vt_cntr_ia_analisis_documentos is 'Muestra los documentos y el texto extraído que respaldan cada análisis IA.';
