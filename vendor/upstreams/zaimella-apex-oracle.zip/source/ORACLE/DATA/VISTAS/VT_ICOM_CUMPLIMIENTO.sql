﻿prompt PROD VIEW DATA.VT_ICOM_CUMPLIMIENTO

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_CUMPLIMIENTO" ("ID", "DESCRIPCION", "VALOR", "ESTADO", "COMPANIA") AS 
  select id_tabla id, descripcion, to_number(valor) valor, activo estado,CODIGOCOMPANIA COMPANIA
  from data.T_CORP_UDC
  where id_cabecera = 'ICOM_CUMPL';
/

