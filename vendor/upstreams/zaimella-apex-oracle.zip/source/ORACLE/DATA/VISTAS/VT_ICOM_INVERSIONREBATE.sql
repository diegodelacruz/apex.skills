﻿prompt PROD VIEW DATA.VT_ICOM_INVERSIONREBATE

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_INVERSIONREBATE" ("IDINVERSION", "IDREBATE", "NOMBREREBATE", "NOMBREINVERSION", "CALCULO", "OBSERVACION", "VALOR", "VALORPORCENTAJE", "FECHAINICIO", "FECHAFIN", "TIPOREBATE", "IDTIPOREBATE", "USAFORMULA", "FORMULA", "IDCALCULO", "PERIODO") AS 
  (
select i.id idinversion, re.id idrebate, re.nombre nombrerebate, i.nombre nombreinversion,  
nvl(gtc.descripcion,' ') calculo, nvl(ig.observacion, ' ') observacion,  ig.valor, ig.valorporcentaje, 
case when mes.inicio is not null then to_date('01/'||mes.inicio||'/'||to_char(i.fechainicio,'yyyy'),'dd/mm/yyyy') else null end  fechainicio,
case when mes.fin is not null then last_Day(to_date('01/'||mes.fin||'/'||to_char(i.fechainicio,'yyyy'),'dd/mm/yyyy')) else null end fechafin,
re.tiporebate, re.idtiporebate, re.usaformula, re.formula, ig.calculo idcalculo, ig.periodo
from data.vt_icom_conf_rebate re
    inner join data.t_icom_inversiones i on ( re.idinversiontipo = i.idinversiontipo and i.idetapa in (2, 3, 7,8) )
    left join data.t_icom_inversion_gasto ig on ( re.idtiporebate = 1  and i.id = ig.idinversion and ig.gastotipo = 'GASTOREBATE' and to_char(re.id) = ig.tipo     )
    left join data.vt_icom_gastotipocalculo gtc on (re.idtiporebate = 1 and ig.calculo = gtc.id )     
    left join ( select codigo, periododescripcion,  min(orden) inicio, max(orden) fin from data.vt_icom_periodos   
                  group by codigo, periododescripcion )  mes on ( re.idtiporebate = 1 and i.analisisperiodo = mes.codigo and ig.periodo = mes.periododescripcion ) 
where re.estado = 1 );
/

