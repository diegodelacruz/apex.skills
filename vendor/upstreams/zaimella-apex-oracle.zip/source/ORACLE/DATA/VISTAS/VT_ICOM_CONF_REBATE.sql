﻿prompt PROD VIEW DATA.VT_ICOM_CONF_REBATE

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_CONF_REBATE" ("ID", "NOMBRE", "IDINVERSIONTIPO", "DESCRIPCION", "TIPOREBATE", "ESTADO", "COMPANIA", "IDTIPOREBATE", "USAFORMULA", "FORMULA") AS 
  (
select r.id, r.nombre, r.idinversiontipo, t.descripcion, 
case when r.tiporebate = 1 then 'MANUAL' else 'AUTOMATICO' end tiporebate, r.estado, r.compania,
r.tiporebate idtiporebate, r.usaformula, r.formula
from data.t_icom_conf_rebate r
left join data.vt_icom_inversiontipo t on ( r.idinversiontipo = t.idinversiontipo )
);
/

