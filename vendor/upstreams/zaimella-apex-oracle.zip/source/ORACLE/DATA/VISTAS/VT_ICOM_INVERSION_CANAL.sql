﻿prompt PROD VIEW DATA.VT_ICOM_INVERSION_CANAL

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_INVERSION_CANAL" ("IDINVERSION", "CODIGOCANAL", "CANAL") AS 
  SELECT i.idinversion,c.CODIGOCANAL, c.CANAL  from t_icom_inversion_cliente_g i
    inner join vt_gzm_cliente c on (c.codigocliente=i.codigogrupo)
    group by i.idinversion,c.CODIGOCANAL, c.CANAL;
/

