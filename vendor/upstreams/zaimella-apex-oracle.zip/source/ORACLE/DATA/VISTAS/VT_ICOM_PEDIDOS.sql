﻿prompt PROD VIEW DATA.VT_ICOM_PEDIDOS

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_PEDIDOS" ("FECHA", "CODIGOCLIENTE", "CODIGOGRUPO", "CODIGOPRODUCTO", "UNIDAD", "CANTIDADPEDIDA", "CANTIDADDESPACHADA", "COMPANIA") AS 
  (
  SELECT acadte fecha, to_char(ACAAN8) codigocliente, to_char(ACAPAN8) codigogrupo,  Acalitm codigoproducto, ACAUOM1 unidad,
 ACAQTPD1 - ACAQTDV1 cantidadpedida, ACAQTPD1 - ACAQTDV1 cantidaddespachada, 
 '00001' compania From t_aca_res@etldl where acadte between trunc(add_months(sysdate,-12),'MM') and sysdate
  UNION 
SELECT FECHA, to_char(CODIGOCLIENTE), to_char(CODIGOGRUPO), CODIGOPRODUCTO, UNIDAD, CANTIDAD,0, COMPANIA FROM VT_ICOM_PEDIDOSINCUMPLIDOS@JDEDTADL
);
/

