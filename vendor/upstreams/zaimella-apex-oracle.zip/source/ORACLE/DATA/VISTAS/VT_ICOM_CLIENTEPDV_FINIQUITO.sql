﻿prompt PROD VIEW DATA.VT_ICOM_CLIENTEPDV_FINIQUITO

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_CLIENTEPDV_FINIQUITO" ("CODIGOGRUPO", "DISTRIBUIDOR", "RUCDISTRIBUIDOR", "FECHAINICIO", "FECHAFIN", "CODIGOPDV", "RAZONSOCIAL", "NOMBREPDV", "RUCPDV", "CORREO", "TELEFONO", "ESCALA", "IDZONA", "ZONA", "SECUENCIAL", "IDINVERSION", "FECHACONTRATO", "METRATRIMESTRAL", "METATIMESTRAL109", "METATIMESTRAL110", "REBATE", "FIRMACONTRATO", "COMPANIA") AS 
  (
select p.codigogrupo, gr.nombres distribuidor, gr.ruc rucDistribuidor, i.fechainicio fechainicio, i.fechafin fechafin, 
p.codigopdv, cl.razonsocial razonSocial, cl.nombrecliente nombrePdv, cl.cedula rucPdv, cl.correo, cl.telefono,  
p.escala, clo.idzona, clo.zona, i.id||'-'||p.secuencial secuencial, i.id idinversion, p.fechacontrato , 
(p.metamensual*3) MetraTrimestral, ((p.metamensual*3)*1.099) MetaTimestral109, ((p.metamensual*3)*1.10) MetaTimestral110, 
case when gasto.tipo is not null then gasto.tipo||'%' else '' end  Rebate, it.firmacontrato ,
i.compania
from  data.vt_icom_inversiontipo it 
inner join data.t_icom_inversiones i on ( it.idinversiontipo = i.idinversiontipo )
inner join data.t_icom_cliente_pdv p on (i.id = p.idinversion  and p.estado = 1  and nvl(p.contratoaprobar,0) = 4 and nvl(p.contratoclausura,-1) = -1 ) 
left join data.t_trad_cliente cl on ( p.codigopdv = trim(cl.codigopdv) )
left join data.vt_gzm_cliente gr on ( gr.compania = i.compania and  p.codigogrupo = gr.codigocliente)
inner join ( select ctt.id, ctt.tipocontrato, cc.idinversion, cc.codigopdv
             from  data.t_icom_contratos ctt 
                inner join ( select distinct idcontrato, idinversion, codigopdv from  data.t_icom_contrato_contenido ) cc
                    on ( cc.idcontrato = ctt.id  ) 
            where nvl(ctt.subtipocontrato,1) = 1 --formato electronico    
			and ctt.estado = 1 ) co on ( p.idinversion = co.idinversion and p.codigopdv = co.codigopdv and co.tipocontrato =  2)
left join ( select ctt.id, ctt.tipocontrato, cc.idinversion, cc.codigopdv
            from  data.t_icom_contratos ctt 
                inner join ( select distinct idcontrato, idinversion, codigopdv from  data.t_icom_contrato_contenido ) cc
                on ( cc.idcontrato = ctt.id  ) 
            where nvl(ctt.subtipocontrato,1) = 2 --formato manual  
			and ctt.estado = 1 	) cm on ( p.idinversion = cm.idinversion and p.codigopdv = cm.codigopdv and cm.tipocontrato =  2 )    
left join data.vt_trad_clientelocal clo  on ( p.codigopdv = clo.codigopdv and clo.matriz = 1 and clo.estado=1)
left join ( select distinct idinversion, tipo from data.t_icom_inversion_gasto where  gastotipo = 'GASTOREBATE' ) gasto  
    on (i.id = gasto.idinversion  )   );
/

