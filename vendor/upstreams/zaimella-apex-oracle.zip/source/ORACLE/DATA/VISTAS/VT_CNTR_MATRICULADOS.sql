create or replace view data.vt_cntr_matriculados as
select p.compania,
       'PERSONA' tipo_sujeto,
       p.id_persona id_sujeto,
       p.identificacion,
       p.nombres sujeto
  from data.t_cntr_personas p
 where p.estado = 'ACTIVO'
union all
select e.compania,
       'EMPRESA' tipo_sujeto,
       e.id_empresa id_sujeto,
       e.ruc identificacion,
       e.razon_social sujeto
  from data.t_cntr_empresas e
 where e.estado = 'ACTIVO';
/

comment on table data.vt_cntr_matriculados is
    'Sujetos activos matriculados, personas y empresas, disponibles para la matriz documental por compania.';
comment on column data.vt_cntr_matriculados.compania is
    'Compania a la que pertenece el sujeto matriculado.';
comment on column data.vt_cntr_matriculados.tipo_sujeto is
    'Clasificacion documental del sujeto: PERSONA o EMPRESA.';
comment on column data.vt_cntr_matriculados.id_sujeto is
    'Identificador de la persona o empresa dentro de su tabla de origen.';
comment on column data.vt_cntr_matriculados.identificacion is
    'Cedula, pasaporte o RUC visible del sujeto.';
comment on column data.vt_cntr_matriculados.sujeto is
    'Nombre completo de la persona o razon social de la empresa.';
