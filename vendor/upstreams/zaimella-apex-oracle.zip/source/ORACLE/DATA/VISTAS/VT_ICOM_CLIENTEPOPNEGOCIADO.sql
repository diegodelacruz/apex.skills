﻿prompt PROD VIEW DATA.VT_ICOM_CLIENTEPOPNEGOCIADO

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_CLIENTEPOPNEGOCIADO" ("IDINVERSION", "CODIGOGRUPO", "IDMATERIAL", "CANTIDAD", "NOMBRE", "FECHAINICIO", "FECHAFIN", "NOMBREGRUPO", "CANAL", "NOMBREMATERIAL", "CLASIFICACION", "NOMBREPDV", "CLASIFICAPDV", "NEG_FECHAINICIO", "NEG_FECHAFIN") AS 
  (
select cma.idinversion, cma.codigogrupo, cma.idmaterial, cma.cantidad, 
    inv.nombre, inv.fechainicio, inv.fechafin,
    gru.nombres nombreGrupo, gru.canal,
    pop.descripcion nombreMaterial, pop.clasificacion,
    tcl.nombreconocido nombrePdv, tcl.clasificacion clasificaPdv,
    gru.fechainicio neg_fechainicio, gru.fechafin neg_fechafin
from data.t_icom_cliente_material cma
    inner join data.t_icom_inversiones inv on (cma.idinversion = inv.id )
    left join data.vt_icom_inversion_cliente gru on ( cma.idinversion = gru.idinversion and cma.codigogrupo = gru.codigogrupo )
    inner join data.vt_icom_materialpop pop on ( cma.idmaterial = pop.id )
    left join data.t_trad_clientelocal tcl on (cma.codigopdv = tcl.codigopdv||'-'||tcl.numero )
where nvl(cma.negociacion, -1) in( 1,-1) --and cma.estado = 1
);
/

