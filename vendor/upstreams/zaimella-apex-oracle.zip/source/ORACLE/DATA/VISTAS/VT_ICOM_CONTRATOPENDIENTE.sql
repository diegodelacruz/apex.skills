﻿prompt PROD VIEW DATA.VT_ICOM_CONTRATOPENDIENTE

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_CONTRATOPENDIENTE" ("IDINVERSION", "NOMBREINVERSION", "FECHAINICIO", "FECHAFIN", "CODIGOCLIENTE", "CODIGOPDV", "NOMBRE", "TIPOCONTRATO", "ID_TIP_CONTRATO", "DISTRIBUIDOR", "CANALZONA", "ESTADO", "FECHA", "NOMBREUSUARIO", "BLOBCONTENIDO", "MIMETYPE", "NOMBREARCHIVO", "NUMEROARCHIVO", "SECUENCIAL", "RUC", "CODIGOGRUPO", "ESCALA") AS 
  (
select v.idinversion, v.nombreinversion, v.fechainicio, v.fechafin,  v.codigocliente, v.codigopdv, v.nombre,
       v.tipocontrato,  v.id_tip_contrato, v.distribuidor, v.canalZona, a.estado, a.fecha, a.nombreusuario ,  A.BLOBCONTENIDO, 
       A.MIMETYPE, 
	   A.NOMBREARCHIVO, a.numeroarchivo, v.secuencial, v.ruc, v.codigogrupo,
       v.escala
from data.t_icom_archivos a
inner join  (   select vcc.idinversion, vcc.nombreinversion, vcc.fechainicio, vcc.fechafin,  vcc.codigocliente, null codigopdv, vcc.nombrecliente nombre,
                    vcc.tipocontrato, vcc.idcontratomanual idcontrato, vcc.id_tip_contratomanual id_tip_contrato,  
                    null distribuidor, vcc.canal canalZona, null secuencial, null ruc, null codigogrupo,
                    null escala
                from data.vt_icom_contratocliente vcc 
                union
                select vcp.idinversion, vcp.nombreinversion, vcp.fechainicio, vcp.fechafin,  null, vcp.codigopdv , vcp.nombre nombre,
                    vcp.tipocontrato, vcp.idcontratomanual idcontrato, vcp.id_tip_contratomanual id_tip_contrato, 
                    vcp.nombregrupo , vcp.zona, vcp.secuencial, vcp.ruc, vcp.codigogrupo,
                    vcp.escala
                from data.vt_icom_contratopdv vcp     
    ) v on ( v.idinversion = a.idinversion 
             and ( (a.codigopdv is not null and v.codigopdv = a.codigopdv) 
                 or ( a.codigogrupo is not null and v.codigocliente = a.codigogrupo ) 
                 )
             and v.idcontrato = a.idcontrato   
			 and v.id_tip_contrato = a.tipocontrato 
            )
);
/

