﻿prompt PROD VIEW DATA.VT_ICOM_ESTATUS_CLIENTE

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_ESTATUS_CLIENTE" ("ID", "IDPADRE", "ETAPA", "ETAPA_ALTERNA", "NOMBRE", "FECHAINICIO", "FECHAFIN", "AREA", "CANAL", "CODIGOGRUPO", "NOMBRES", "TIPOLOCAL", "NEGOCIACION", "ORIGEN", "INVERSIONTIPO", "TIPO", "SOLICITANTE", "APROBADOR", "FECHAINICIO_NEG", "FECHAFIN_NEG", "ESTADO_FECHA", "AUDITORIAFECHA", "USUARIOGESTION", "MOTIVORECHAZO", "FORMAPAGO", "OBSERVACION", "ESTADO_CLIENTE", "LINEA", "MARCAS", "SUBMARCAS", "PROCESO_1", "PROCESO_2", "PROCESO_3", "PROCESO_4", "PROCESO_5", "PROCESO_6", "PROCESO_7", "PROCESO_8", "PROCESO_9", "PROCESO_10", "PROCESO_11", "PROCESO_12", "PROCESO_13", "COMPANIA") AS 
  select i.id, i.IDGRUPO IDPADRE, i.etapa, I.ETAPA_ALTERNA, i.nombre, i.fechainicio, i.fechafin, i.area,
GC.canal, g.codigogrupo, TRIM(g.nombres), cf.tipolocal, G.NEGOCIACION, i.origen, i.inversiontipo,I.TIPO,
f.usuarioiniciador solicitante, F.USUARIOACTUAL aprobador,
CF.fechainicio fechainicio_neg, CF.fechafin fechafin_neg, cf.estado estado_fecha, CF.auditoriafecha , g.usuariogestion, G.MOTIVORECHAZO ,   	
fp.descripcion formapago, g.observacion,
case when G.estado=1 then 'EN EDICION' 
when G.estado=2 then 'EN RUTA' ELSE '' END ESTADO_CLIENTE, 
DATA.PK_ICOM_COMMONS.F_VERLINEANEGOCIO(P_ID => I.ID ) LINEA, 
DATA.PK_ICOM_COMMONS.F_VERMARCA(P_ID => I.ID ) MARCAS, 
DATA.PK_ICOM_COMMONS.F_VERSUBMARCA(P_ID => I.ID) SUBMARCAS,
 --p.idproceso, vp.descripcion proceso , p.porcentaje, p.fechainicio fechainicio_pro, p.fechafin fechafin_pro,  
 --ep.descripcion estado_pro, vp.usuariogestion usuario_pro, vp.notificacion_imp
(select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=1) PROCESO_1,

(select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=2) PROCESO_2,

(select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=3) PROCESO_3,

(select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=4) PROCESO_4,

(select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=5) PROCESO_5,

(select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=6) PROCESO_6,

(select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=7) PROCESO_7,

(select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=8) PROCESO_8,

(select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=9) PROCESO_9,

(select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=10) PROCESO_10,

(select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=11) PROCESO_11,

(select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=12) PROCESO_12,

(select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=13) PROCESO_13,

I.COMPANIA

from data.vt_icom_inversiones i
    left join data.t_icom_inversion_cliente_g g on (i.id = g.idinversion )
    LEFT JOIN VT_GZM_CLIENTE GC ON (gc.codigocliente=G.codigogrupo)
    LEFT JOIN t_icom_cliente_fechas CF ON (g.idinversion =CF.idinversion  AND G.codigogrupo=CF.codigogrupo)
    left join data.t_flujo_aprobacion_cab f on (f.codmodulo='ICOM' and f.entidad_clase='CLIENTE_INVERSION_COMERCIAL' 
        AND F.ESTADO='EN_PROCESO' and f.ENTIDAD_ID=i.id||'-'||G.codigogrupo)
    left join data.vt_icom_formapago fp on (fp.idformapago=G.idformapago) 
 /*   left join data.t_icom_inversion_proceso p on
        ( i.id = p.idinversion and p.estado = 1 )
    left join data.vt_icom_proceso vp on
        ( p.idproceso = vp.idproceso)
    left join data.vt_icom_estadoproceso ep on
        ( p.idproceso = ep.idproceso and p.porcentaje = ep.porcentaje and ep.estado = 1 )*/
where i.grupal =0
and IDETAPA not in (5)
order by i.id, g.CODIGOGRUPO;
/

