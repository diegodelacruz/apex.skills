﻿prompt PROD VIEW DATA.VT_ICOM_VENTATIPO

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_VENTATIPO" ("ID", "DESCRIPCION", "VALOR", "ESTADO", "COMPANIA") AS 
  select id_tabla id,  descripcion,  valor , activo estado,CODIGOCOMPANIA COMPANIA
from data.T_CORP_UDC
where id_cabecera = 'ICOM_TVENT';
/


prompt Esquema DATA para codigo PL/SQL
alter session set current_schema=DATA;

