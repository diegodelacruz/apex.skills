﻿prompt PROD VIEW DATA.VT_ICOM_TRANSACCIONPAGO

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_TRANSACCIONPAGO" ("ID", "ETAPA", "NOMBRE", "FECHAINICIO", "FECHAFIN", "AREA", "LINEANEGOCIO", "MARCA", "SUBMARCA", "PRODUCTO", "CANAL", "GRUPO", "CODIGOGRUPO", "CLIENTE", "ESTADO", "ESTADONEGOCIACION", "ORIGEN", "INVERSIONTIPO", "TIPO", "FEC_INICIOGRUPO", "FEC_FINGRUPO", "IDFORMAPAGO", "OBSERVACION", "GASTOFIJO", "GASTOSOTROS", "GASTOVARIABLE", "VAL_FECHAINICIO", "VAL_FECHAFIN", "TOT_VALIDACION", "PLANIFICADO_VARIABLE", "PLANIFICADO_FIJO", "PLANIFICADO_OTRO", "COMPANIA") AS 
  with 
inversion as ( 
    SELECT * FROM vt_icom_inversiones inv 
    where 1=1
--    and inv.fechainicio BETWEEN '01/01/2024' AND '30/04/2024' 
    AND inv.idpadre is null
),
validacion as ( 
    select idinversion, codigogrupo, min(val_fechainicio) fechaInicio, max(val_fechafin) fechaFin, sum(nvl(TOT_VALORZAIMELLA,0)+nvl(TOT_VALOREXCEPCION,0)) tot_valor
    from data.t_icom_cliente_validacion  where estado=1 
    group by idinversion, codigogrupo ),
RESULTADO AS(
    select 
        inv.id, 
        inv.etapa, 
        inv.nombre, 
        inv.fechainicio, 
        inv.fechafin, 
        inv.area,
        DATA.PK_ICOM_COMMONS.F_VERLINEANEGOCIO( P_ID => inv.id ) lineanegocio,
        DATA.PK_ICOM_COMMONS.F_VerMarca( P_ID => inv.id ) marca,
        DATA.PK_ICOM_COMMONS.F_VerSubMarca( P_ID => inv.id ) submarca,
        DATA.PK_ICOM_COMMONS.F_VerProducto( P_ID => inv.id ) producto,
        gru.canal, trim(gru.nombres ) grupo,  
        gru.codigogrupo,
        DATA.PK_ICOM_COMMONS.F_VerCliente( P_ID => inv.id, P_CODIGOGRUPO => gru.codigogrupo, P_COMPANIA => inv.compania ) cliente,
        gru.estado, 
        gru.estadonegociacion, 
        inv.origen, 
        inv.inversiontipo, 
        inv.tipo, 
        gru.fechainicio fec_iniciogrupo, 
        gru.fechafin fec_fingrupo, 
        gru.idformapago, 
        gru.observacion, 
        nvl((select sum(m.total) from data.t_icom_cliente_material m  where m.negociacion = 1 and m.estado = 1 and gru.idinversion = m.idinversion and gru.codigogrupo = m.codigogrupo) ,0)gastoFijo,
        nvl((
        select sum(gd.valor) valor 
        from t_icom_inversion_gasto g 
        inner join t_icom_inversion_gastodistribucion gd on (g.IDINVERSION=gd.IDINVERSION and  g.IDGASTO=gd.IDGASTO)
        where  g.idinversion=gru.idinversion and 
        g.TIPO='FIJO' and g.GASTOTIPO='GASTO' and g.CALCULADO=0 and  gru.codigogrupo = gd.CODIGOGRUPO
        /*select sum(VALORMETA) valor from t_icom_inversion_gasto g
        where TIPO='FIJO' and GASTOTIPO='GASTO' and CALCULADO=0 and g.idinversion=gru.idinversion*/) ,0)gastosOtros,
        nvl(data.PK_ICOM_FORMULAS.F_GASTOVARIABLECLIENTE( P_ID => inv.id, P_CODIGOGRUPO => gru.codigogrupo,P_DURACION => inv.duracion,P_SELLOUT => gru.sellout, P_CRECIMIENTO => gru.selloutcrecimiento) ,0)gastoVariable, 
--        inv.duracion,gru.sellout,gru.selloutcrecimiento,
        val.fechaInicio Val_fechaInicio, 
        val.fechafin val_fechafin, 
        val.tot_valor  tot_validacion
        ,PK_ICOM_VALIDACION.F_TRAERVALORPLANIFICADO ( P_IDINVERSION => inv.id, P_CODIGOGRUPO => gru.codigogrupo, P_TIPO =>'F' ) planificado_fijo
        ,PK_ICOM_VALIDACION.F_TRAERVALORPLANIFICADO ( P_IDINVERSION => inv.id, P_CODIGOGRUPO => gru.codigogrupo, P_TIPO =>'O' ) planificado_otro
        ,PK_ICOM_VALIDACION.F_TRAERVALORPLANIFICADO ( P_IDINVERSION => inv.id, P_CODIGOGRUPO => gru.codigogrupo, P_TIPO =>'V',P_DURACION => inv.duracion,P_SELLOUT => gru.sellout, P_CRECIMIENTO => gru.selloutcrecimiento ) planificado_variable
        ,inv.compania
    from inversion inv
    inner join data.vt_icom_inversion_cliente gru on (inv.id = gru.idinversion )
    left join validacion val on ( gru.idinversion = val.idinversion and gru.codigogrupo = val.codigogrupo )
 )
 SELECT ID, ETAPA, NOMBRE, FECHAINICIO, FECHAFIN, AREA, LINEANEGOCIO, MARCA, SUBMARCA, PRODUCTO, CANAL, GRUPO, CODIGOGRUPO, CLIENTE, ESTADO, ESTADONEGOCIACION, ORIGEN, INVERSIONTIPO, TIPO, FEC_INICIOGRUPO, FEC_FINGRUPO, IDFORMAPAGO, OBSERVACION, round(GASTOFIJO,2)GASTOFIJO, round(GASTOSOTROS,2)GASTOSOTROS, round(GASTOVARIABLE,2)GASTOVARIABLE, VAL_FECHAINICIO, VAL_FECHAFIN, TOT_VALIDACION, round(PLANIFICADO_VARIABLE,2)PLANIFICADO_VARIABLE, round(PLANIFICADO_FIJO,2) PLANIFICADO_FIJO , round(PLANIFICADO_OTRO,2) PLANIFICADO_OTRO, COMPANIA
 FROM RESULTADO;
/

