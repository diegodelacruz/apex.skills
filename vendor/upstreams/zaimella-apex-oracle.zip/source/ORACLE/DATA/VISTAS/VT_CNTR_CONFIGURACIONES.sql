create or replace view data.vt_cntr_configuraciones as
select c.id_configuracion,
       c.compania,
       c.nombre,
       c.estado,
       c.usuario_creacion usuario_propietario,
       (select count(*)
          from (
                select cs.id_sujeto
                  from data.t_cntr_config_sujetos cs
                 where cs.id_configuracion = c.id_configuracion
                   and cs.tipo_sujeto = 'PERSONA'
                   and cs.estado = 'ACTIVO'
                union
                select ep.id_persona
                  from data.t_cntr_config_empresas ce
                  join data.t_cntr_empresa_personas ep
                    on ep.id_empresa = ce.id_empresa
                   and ep.estado = 'ACTIVO'
                 where ce.id_configuracion = c.id_configuracion
                   and ce.estado = 'ACTIVO'
                   and ce.incluir_todos = 'S'
                union
                select cep.id_persona
                  from data.t_cntr_config_empresas ce
                  join data.t_cntr_config_empresa_personas cep
                    on cep.id_config_empresa = ce.id_config_empresa
                   and cep.estado = 'ACTIVO'
                 where ce.id_configuracion = c.id_configuracion
                   and ce.estado = 'ACTIVO'
                   and ce.incluir_todos = 'N'
          )) cantidad_sujetos,
       (select count(*) from data.t_cntr_config_empresas e where e.id_configuracion=c.id_configuracion and e.estado='ACTIVO') cantidad_empresas,
       (select count(*) from data.t_cntr_config_documentos d where d.id_configuracion=c.id_configuracion and d.estado='ACTIVO') cantidad_documentos,
       c.fecha_creacion,
       c.fecha_actualizacion
  from data.t_cntr_configuraciones c
 where c.usuario_creacion = nvl(sys_context('APEX$SESSION', 'APP_USER'), user);

comment on table data.vt_cntr_configuraciones is
    'Resumen de configuraciones CNTR aislado por el usuario autenticado.';
