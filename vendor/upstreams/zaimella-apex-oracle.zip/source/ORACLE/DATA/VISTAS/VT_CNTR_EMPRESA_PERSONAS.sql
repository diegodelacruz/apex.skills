create or replace view data.vt_cntr_empresa_personas as
select ep.id_empresa_persona,
       e.compania,
       ep.id_empresa,
       e.ruc,
       e.razon_social,
       ep.id_persona,
       p.tipo_identificacion,
       p.identificacion,
       p.nombres as nombre_persona,
       ep.rol,
       ep.estado,
       ep.observacion,
       ep.fecha_creacion,
       ep.usuario_creacion,
       ep.fecha_actualizacion,
       ep.usuario_actualizacion
  from data.t_cntr_empresa_personas ep
  join data.t_cntr_empresas e
    on e.id_empresa = ep.id_empresa
  join data.t_cntr_personas p
    on p.id_persona = ep.id_persona;

comment on table data.vt_cntr_empresa_personas is
    'Muestra las personas vinculadas a empresas del modulo CNTR, incluyendo identificacion, rol y estado del vinculo.';
