  CREATE OR REPLACE VIEW DATA.VT_VTAS_PEDIDOS_CANCELADOS_PE ("IDPEDIDO", "NUMERO_ORDEN_SAP", "ORDENCOMPRA", "FECHA_INGRESO", "CODIGOCLIENTE", "CODIGOGRUPO", "ORIGEN", "CODIGO_CANAL", "CANAL", "CLIENTE", "GRUPO", "EJECUTIVO", "CODIGOPRODUCTO", "PRODUCTO_SAP", "NOMBREPRODUCTO", "CODIGOBARRA", "LINEANEGOCIO", "MARCA", "SUBMARCA", "TIPO", "PRESENTACION", "PRECIO", "DESCUENTO", "CANTIDAD_BU_CA_OC", "CANTIDAD_BU_CA_SOLICITADO", "CANTIDAD_UND_OC", "CANTIDAD_UND_SOLICITADO", "SUBTOTAL_OC", "SUBTOTAL_SOLICITADO", "CANCELADO_SAP", "ESTADO_SAP", "LINEA_SAP", "UNIDAD_MEDIDA") AS 
  select
    O."DocEntry" idpedido,
    O."DocNum" numero_orden_sap,
    cast(O."NumAtCard" as varchar2(200)) ordencompra,
    O."DocDate" fecha_ingreso,
    cast(replace(cast(O."CardCode" as varchar2(50)), 'C', '') as varchar2(50)) codigocliente,
    cast(nvl(C.CODIGOGRUPO, replace(cast(O."CardCode" as varchar2(50)), 'C', '')) as varchar2(50)) codigogrupo,
    cast(C.CODIGOORIGEN as varchar2(50)) origen,
    cast(C.CODIGOCANAL as varchar2(50)) codigo_canal,
    cast(C.CANAL as varchar2(200)) canal,
    cast(nvl(C.NOMBRES, cast(O."CardName" as varchar2(300))) as varchar2(300)) cliente,
    cast(nvl(C.GRUPO, cast(O."CardName" as varchar2(300))) as varchar2(300)) grupo,
    cast(C.EJECUTIVO as varchar2(100)) ejecutivo,
    cast(R."ItemCode" as varchar2(100)) codigoproducto,
    cast(R."Dscription" as varchar2(500)) producto_sap,
    cast(nvl(P.NOMBREPRODUCTO, cast(R."Dscription" as varchar2(500))) as varchar2(500)) nombreproducto,
    cast(P.CODIGOBARRA as varchar2(100)) codigobarra,
    cast(nvl(nullif(trim(P.LINEANEGOCIO), ''), cast(B."ItmsGrpNam" as varchar2(200))) as varchar2(200)) lineanegocio,
    cast(P.MARCA as varchar2(200)) marca,
    cast(P.SUBMARCA as varchar2(200)) submarca,
    1 tipo,
    cast(1 as number) presentacion,
    R."Price" precio,
    R."DiscPrcnt" descuento,
    R."Quantity" cantidad_bu_ca_oc,
    R."Quantity" cantidad_bu_ca_solicitado,
    R."Quantity" cantidad_und_oc,
    R."Quantity" cantidad_und_solicitado,
    R."LineTotal" subtotal_oc,
    R."LineTotal" subtotal_solicitado,
    cast('Y' as varchar2(1)) cancelado_sap,
    cast(R."LineStatus" as varchar2(20)) estado_sap,
    R."LineNum" linea_sap,
    cast(R."UomCode" as varchar2(50)) unidad_medida
from ORDR@HANA_PE O
join RDR1@HANA_PE R
    on R."DocEntry" = O."DocEntry"
left join VT_GZM_CLIENTE C
    on C.COMPANIA = '00003'
   and C.CODIGOCLIENTE = replace(cast(O."CardCode" as varchar2(50)), 'C', '')
left join VT_GZM_PRODUCTO P
    on P.COMPANIA = '00003'
   and P.CODIGOPRODUCTO = cast(R."ItemCode" as varchar2(100))
left join OITM@HANA_PE I
    on I."ItemCode" = R."ItemCode"
left join OITB@HANA_PE B
    on B."ItmsGrpCod" = I."ItmsGrpCod"
where O."CANCELED" = 'Y'
  and R."ItemCode" is not null
union all
select
    P.IDPEDIDO idpedido,
    cast(null as number) numero_orden_sap,
    cast(P.ORDENCOMPRA as varchar2(200)) ordencompra,
    P.FECHA_PEDIDO fecha_ingreso,
    cast(P.CODIGOCLIENTE as varchar2(50)) codigocliente,
    cast(P.CODIGOGRUPO as varchar2(50)) codigogrupo,
    cast(C.CODIGOORIGEN as varchar2(50)) origen,
    cast(C.CODIGOCANAL as varchar2(50)) codigo_canal,
    cast(C.CANAL as varchar2(200)) canal,
    cast(nvl(C.NOMBRES, P.CODIGOCLIENTE) as varchar2(300)) cliente,
    cast(nvl(C.GRUPO, P.CODIGOGRUPO) as varchar2(300)) grupo,
    cast(C.EJECUTIVO as varchar2(100)) ejecutivo,
    cast(P.CODIGOPRODUCTO as varchar2(100)) codigoproducto,
    cast(P.NOMBREPRODUCTO as varchar2(500)) producto_sap,
    cast(nvl(PR.NOMBREPRODUCTO, P.NOMBREPRODUCTO) as varchar2(500)) nombreproducto,
    cast(nvl(PR.CODIGOBARRA, P.CODIGOBARRA) as varchar2(100)) codigobarra,
    cast(nvl(PR.LINEANEGOCIO, P.LINEA_NEGOCIO) as varchar2(200)) lineanegocio,
    cast(PR.MARCA as varchar2(200)) marca,
    cast(PR.SUBMARCA as varchar2(200)) submarca,
    P.TIPO tipo,
    nvl(P.PRESENTACION, 1) presentacion,
    P.PRECIO precio,
    P.DESCUENTO descuento,
    P.CANTIDAD_BU_CA_OC cantidad_bu_ca_oc,
    P.CANTIDAD_BU_CA cantidad_bu_ca_solicitado,
    P.CANTIDAD_OC cantidad_und_oc,
    P.CANTIDAD_UND cantidad_und_solicitado,
    P.TOTAL_OC subtotal_oc,
    P.TOTAL subtotal_solicitado,
    cast('LOCAL' as varchar2(5)) cancelado_sap,
    cast('Cancelado' as varchar2(20)) estado_sap,
    P.LINEA linea_sap,
    cast(P.UNIDAD_MEDIDA as varchar2(50)) unidad_medida
from DATA.VT_VTAS_PEDIDOS P
left join DATA.VT_GZM_CLIENTE C
    on C.COMPANIA = '00003'
   and C.CODIGOCLIENTE = P.CODIGOCLIENTE
left join DATA.VT_GZM_PRODUCTO PR
    on PR.COMPANIA = '00003'
   and PR.CODIGOPRODUCTO = P.CODIGOPRODUCTO
where P.COMPANIA = '00003'
  and P.ESTADO_PEDIDO = 3;
/
COMMENT ON TABLE DATA.VT_VTAS_PEDIDOS_CANCELADOS_PE IS 'Presenta pedidos cancelados de Peru consultados desde SAP y pedidos locales relacionados.';
COMMENT ON COLUMN DATA.VT_VTAS_PEDIDOS_CANCELADOS_PE.TIPO IS 'Tipo funcional del pedido. Valores permitidos: 1 = pedido; 3 = pedido especial.';
COMMENT ON COLUMN DATA.VT_VTAS_PEDIDOS_CANCELADOS_PE.ESTADO_SAP IS 'Estado publicado del pedido. Valores permitidos: 1 = activo.';
