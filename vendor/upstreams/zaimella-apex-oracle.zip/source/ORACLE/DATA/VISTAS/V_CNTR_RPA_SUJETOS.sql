create or replace view data.v_cntr_rpa_sujetos as
select distinct
       cs.id_configuracion,
       cs.tipo_sujeto,
       cs.id_sujeto,
       cast(null as number) as id_empresa_origen,
       'DIRECTO' as origen_configuracion
  from data.t_cntr_config_sujetos cs
 where cs.estado = 'ACTIVO'
union all
select distinct
       ce.id_configuracion,
       'EMPRESA' as tipo_sujeto,
       ce.id_empresa as id_sujeto,
       ce.id_empresa as id_empresa_origen,
       'EMPRESA' as origen_configuracion
  from data.t_cntr_config_empresas ce
 where ce.estado = 'ACTIVO'
union all
select distinct
       ce.id_configuracion,
       'PERSONA' as tipo_sujeto,
       ep.id_persona as id_sujeto,
       ce.id_empresa as id_empresa_origen,
       'EMPRESA' as origen_configuracion
  from data.t_cntr_config_empresas ce
  join data.t_cntr_empresa_personas ep
    on ep.id_empresa = ce.id_empresa
   and ep.estado = 'ACTIVO'
  left join data.t_cntr_config_empresa_personas cep
    on cep.id_config_empresa = ce.id_config_empresa
   and cep.id_persona = ep.id_persona
   and cep.estado = 'ACTIVO'
 where ce.estado = 'ACTIVO'
   and (ce.incluir_todos = 'S' or cep.id_config_empresa_persona is not null);
/
