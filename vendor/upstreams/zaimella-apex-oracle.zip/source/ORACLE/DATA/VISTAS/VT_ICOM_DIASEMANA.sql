﻿prompt PROD VIEW DATA.VT_ICOM_DIASEMANA

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_DIASEMANA" ("ID", "DIA") AS 
  SELECT Level id ,
decode(level, 1, 'Lunes', 2, 'Martes', 3, 'Miercoles', 4, 'Jueves', 5,'Viernes', 6, 'Sabado', 'Domingo' ) dia  
FROM Dual CONNECT BY Level <= 7;
/

