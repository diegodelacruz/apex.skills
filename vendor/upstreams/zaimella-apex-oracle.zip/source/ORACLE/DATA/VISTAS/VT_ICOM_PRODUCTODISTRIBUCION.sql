﻿prompt PROD VIEW DATA.VT_ICOM_PRODUCTODISTRIBUCION

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_PRODUCTODISTRIBUCION" ("IDINVERSION", "CODIGOPRODUCTO", "PRODUCTO", "CODIGOREGALO", "REGALO", "CODIGOPDV", "NOMBREPDV", "TOTAL", "CANTIDADONPACKS", "SELLOUT", "MINIMO", "DISPONIBLE", "DISPONIBLEONPACKS", "MINIMOBULTO", "BULTOAJUSTADO", "PAQUETESFINAL", "CANTIDADDISTRIBUCION", "CANTIDAD", "ONPACKSTOTAL", "ZONA", "IDZONA", "VALORVA", "CANAL", "PROMOCIONAL", "FECHAINICIO", "DIRECCION", "CONTACTO", "FECHAFIN") AS 
  select pd.IDINVERSION, pd.CODIGOPRODUCTO, pd.PRODUCTO, pd.CODIGOREGALO, pd.REGALO, pd.CODIGOPDV, cll.NOMBRECOMERCIAL NOMBREPDV, pd.TOTAL, 
         pd.CANTIDADONPACKS, pd.SELLOUT, pd.MINIMO, pd.DISPONIBLE, pd.DISPONIBLEONPACKS, pd.MINIMOBULTO, pd.BULTOAJUSTADO, 
         pd.PAQUETESFINAL, pd.CANTIDADDISTRIBUCION, T.CANTIDAD,nvl(pd.PAQUETESFINAL,0)*nvl(t.cantidad,0) onpacksTotal,
         vgg.zona, vgg.idzona, 
         pd.valorva, pd.canal, cll.promocional, i.fechainicio, cll.direccion, cll.contacto,
         i.fechafin
  from data.t_icom_productodistribucion pd
    inner join data.t_icom_inversiones i on (pd.idinversion = i.id )
    left join data.T_TRAD_CLIENTELOCAL cll ON ( pd.codigopdv = cll.codigopdv AND CLL.ESTADO = 1 AND CLL.MATRIZ = 1 )        
    LEFT JOIN data.VT_TRAD_GEOGRAFICO_NIVEL vgg ON cll.idgeografico = vgg.id
    left join data.t_icom_producto_dis_parametro t on ( pd.idinversion = t.idinversion 
         and pd.codigoproducto = t.codigoproducto and pd.codigoregalo = t.codigoregalo );
/

