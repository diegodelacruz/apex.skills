﻿prompt PROD VIEW DATA.VT_ICOM_INVERSIONPROCESOACTIVO

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_INVERSIONPROCESOACTIVO" ("IDINVERSION", "INVERSION", "IDPROCESO", "DESCRIPCION", "PORCENTAJE", "FECHAINICIO", "FECHAFIN", "FEC_INICIOINV", "FEC_FININV", "ESTADO", "ESTADOINVERSION", "USUARIO", "USUARIOGESTION", "COMPANIA", "NOTIFICACION_IMP", "IDORIGEN", "IDETAPA", "IDETAPA2") AS 
  select i.id idinversion, nombre inversion, p.idproceso, vp.descripcion ,
    p.porcentaje, p.fechainicio, p.fechafin,  
    i.fechainicio fec_InicioInv, i.fechafin fec_FinInv,
    ep.descripcion estado, i.estado estadoinversion, 
    i.usuario, vp.usuariogestion, i.compania, vp.notificacion_imp, i.idorigen, i.idetapa, i.idetapa2
from data.t_icom_inversiones i
    inner join data.t_icom_inversion_proceso p on
        ( i.id = p.idinversion and p.estado = 1 )
    inner join data.vt_icom_proceso vp on
        ( p.idproceso = vp.idproceso)
    left join data.vt_icom_estadoproceso ep on
        ( p.idproceso = ep.idproceso and p.porcentaje = ep.porcentaje and ep.estado = 1 )
where i.idetapa in (2,3,7);
/

