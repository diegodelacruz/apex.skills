﻿prompt PROD VIEW DATA.VT_ICOM_MATERIALPOP

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_MATERIALPOP" ("ID", "DESCRIPCION", "CLASIFICACION", "MEDIBLE", "NOMBRECOMERCIAL", "ESTADO", "COMPANIA") AS 
  select id_tabla id , descripcion descripcion, valor clasificacion,pk_commons.safe_to_number(VALOR2) medible,
  descripcion2 NOMBRECOMERCIAL,activo estado,CODIGOCOMPANIA COMPANIA
    from data.T_CORP_UDC where ID_CABECERA = 'ICOM_MATER';
/

