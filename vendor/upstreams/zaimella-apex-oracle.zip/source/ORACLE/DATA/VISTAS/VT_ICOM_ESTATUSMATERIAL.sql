﻿prompt PROD VIEW DATA.VT_ICOM_ESTATUSMATERIAL

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_ESTATUSMATERIAL" ("ID", "NOMBREINVERSION", "ETAPA", "IDETAPA", "CODIGOCANAL", "CODIGOGRUPO", "NOMBREGRUPO", "CANAL", "FORMATO", "CODIGOPDV", "RAZONSOCIAL", "ZONA", "MATERIALPOP", "IDMATERIAL", "IMPLEMENTA", "MEDIBLE", "LINEA", "MARCAS", "SUBMARCAS", "FECHAINICIO_MPOP", "FECHAFIN_MPOP", "NEGOCIACION", "CANTIDAD", "PRECIO", "TOTAL", "OBSERVACION", "ESTADO", "TIPO", "PROCESO_1", "PROCESO_2", "PROCESO_3", "PROCESO_4", "PROCESO_5", "PROCESO_6", "PROCESO_7", "PROCESO_8", "PROCESO_9", "PROCESO_10", "PROCESO_11", "PROCESO_12", "PROCESO_13", "COMPANIA") AS 
  ( select i.id, i.nombre nombreInversion, i.etapa, i.idetapa, g.codigocanal, g.codigogrupo, g.nombres nombreGrupo,A.canal,  ma.FORMATO FORMATO, 
case when ma.codigopdv = '0' then null else ma.codigopdv end codigopdv, cl.nombrecomercial razonsocial,  vg.zona,  
m.descripcion materialpop, MA.IDMATERIAL, im.descripcion implementa, case when ma.medible = 1 then 'SI' when ma.medible = 0 then  'NO' else '' end medible, 
DATA.PK_ICOM_COMMONS.F_VERLINEANEGOCIO(P_ID => I.ID ) LINEA, 
DATA.PK_ICOM_COMMONS.F_VERMARCA(P_ID => I.ID ) MARCAS, 
DATA.PK_ICOM_COMMONS.F_VERSUBMARCA(P_ID => I.ID) SUBMARCAS,
ma.fechainicio fechainicio_mpop, ma.fechafin fechafin_mpop,   
NEGO.DESCRIPCION negociacion, round(ma.cantidad,2) cantidad, round(ma.costo,2) precio, round(ma.total, 2) total, 
ma.observaciones observacion, es.descripcion estado, TP.DESCRIPCION tipo, 
--p.idproceso, vp.descripcion proceso , p.porcentaje, p.fechainicio fechainicio_pro,
--p.fechafin fechafin_pro,  
-- ep.descripcion estado_pro, vp.usuariogestion usuario_pro, vp.notificacion_imp,
 
 (select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=1) PROCESO_1,

(select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=2) PROCESO_2,

(select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=3) PROCESO_3,

(select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=4) PROCESO_4,

(select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=5) PROCESO_5,

(select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=6) PROCESO_6,

(select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=7) PROCESO_7,

(select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=8) PROCESO_8,

(select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=9) PROCESO_9,

(select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=10) PROCESO_10,

(select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=11) PROCESO_11,

(select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=12) PROCESO_12,

(select decode(ip.estado, 1, 'SI', 'NO') ESTADO from t_icom_inversion_proceso ip
left join  vt_icom_proceso p on (p.IDPROCESO=ip.IDPROCESO)
WHERE ip.IDINVERSION=i.ID AND p.IDPROCESO=13) PROCESO_13,
i.COMPANIA
 
 
from data.vt_icom_inversiones i
inner join data.t_icom_inversion_cliente_g g on (i.id = g.idinversion )
left join data.VT_GZM_CLIENTE A on (i.COMPANIA=A.COMPANIA AND g.codigogrupo = a.codigoCLIENTE)
inner join data.t_icom_cliente_material ma on ( g.idinversion = ma.idinversion and g.codigogrupo = ma.codigogrupo )
LEFT JOIN vt_icom_materialpop M ON (MA.IDMATERIAL=M.ID)
left join data.t_trad_clientelocal cl on (cl.codigopdv||'-'||cl.numero = ma.codigopdv )		   
left join data.vt_trad_geografia vg on ( i.compania = vg.compania and cl.idgeografico = vg.id ) 			   
left join data.T_CORP_UDC im on ( im.ID_CABECERA = 'ICOM_MATIM' and ma.implementacion = im.id_tabla )
left join data.VT_ICOM_ESTADO_MATERIALPOP es on ( ma.estado = es.id )
left join data.VT_ICOM_ESTADONEG_MATERIALPOP NEGO ON ( MA.NEGOCIACION = NEGO.ID )
left join data.VT_ICOM_TIPOINGRESOMATERIALPOP TP ON ( MA.TIPO = TP.ID )
/*left join data.t_icom_inversion_proceso p on
        ( i.id = p.idinversion and p.estado = 1 )
    left join data.vt_icom_proceso vp on
        ( p.idproceso = vp.idproceso)
    left join data.vt_icom_estadoproceso ep on
        ( p.idproceso = ep.idproceso and p.porcentaje = ep.porcentaje and ep.estado = 1 )*/
WHERE I.IDPADRE IS NULL );
/

