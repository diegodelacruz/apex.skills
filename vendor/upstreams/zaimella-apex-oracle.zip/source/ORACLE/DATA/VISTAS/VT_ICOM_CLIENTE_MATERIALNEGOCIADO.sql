﻿prompt PROD VIEW DATA.VT_ICOM_CLIENTE_MATERIALNEGOCIADO

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_CLIENTE_MATERIALNEGOCIADO" ("ID", "IDINVERSION", "CODIGOGRUPO", "IDMATERIAL", "CANTIDAD", "COSTO", "TOTAL", "NOMBRES", "CANAL", "MATERIAL", "DISTRIBUCION", "TOTAL_COMPRA", "TOTAL_PENDIENTE", "CANTIDAD_PENDIENTE", "COSTO_PENDIENTE", "TOTAL_BORRADOR", "CANTIDAD_BORRADOR") AS 
  WITH MATERIALCOMPRA AS (
        SELECT mc.idinversion,mc.codigogrupo,mc.idmaterial,
        sum(case when  mc.estadoruta in (1,2,3) then (cantidad*costo ) else 0 end)   total,
        sum(case when  mc.estadoruta in (1,2,3) then (MC.cantidad ) else 0 end)   cantidad,
        nvl( sum(case when  mc.estadoruta not in (1,2,3) then (cantidad*costo) else 0 end) ,0)  total_borrador,
        nvl(sum(case when  mc.estadoruta not in (1,2,3) then (MC.cantidad ) else 0 end),0)   cantidad_borrador
        FROM t_icom_cliente_materialcompra mc 
        inner JOIN  vt_icom_materialpop      mp ON ( mc.idmaterial = mp.id )
        group by mc.idinversion,mc.codigogrupo,mc.idmaterial
)
,MATERIAL AS (
        SELECT        (m.idinversion)idinversion,
        (m.codigogrupo)codigogrupo,        (m.idmaterial)idmaterial,      
        SUM(nvl((m.cantidad),0))cantidad,
        AVG(nvl((m.costo), 0))costo,
        SUM(nvl((m.total), 0))total,
        (c.nombres)nombres,
        (c.canal)canal,        (mp.descripcion)material,
        (decode(mp.clasificacion,'1','1','0'))              distribucion,
        max(REQUISICIONLINEA)  REQUISICIONLINEA
        FROM         t_icom_cliente_material m
        inner JOIN  vt_icom_materialpop      mp ON ( m.idmaterial = mp.id )
        LEFT JOIN  vt_gzm_cliente           c  ON ( m.codigogrupo = c.codigocliente )
        WHERE m.negociacion=1 AND m.estado=1 
        GROUP BY (m.idinversion),(m.codigogrupo),(m.idmaterial), 
        (c.nombres), (c.canal),        (mp.descripcion),       (decode(mp.clasificacion,'1','1','0'))              
    )
    SELECT (M.IDINVERSION||'_'||M.CODIGOGRUPO||'_'||M.IDMATERIAL)ID,
            M.IDINVERSION, M.CODIGOGRUPO, M.IDMATERIAL, (M.CANTIDAD)  CANTIDAD, M.COSTO,  
            round(M.TOTAL,2) TOTAL, M.NOMBRES, M.CANAL, M.MATERIAL, M.DISTRIBUCION,
            NVL((MC.TOTAL),0) TOTAL_COMPRA, 
            case when REQUISICIONLINEA is null then round((M.TOTAL)-(NVL((MC.TOTAL),0)),2) else 0 end  TOTAL_PENDIENTE,
            case when distribucion = 1 then   round((M.cantidad)-(NVL((MC.cantidad),0)),2)  else 1 end CANTIDAD_PENDIENTE,
            case when distribucion = 1 then    M.COSTO  else round((M.TOTAL)-(NVL((MC.TOTAL),0)),2) end costo_PENDIENTE
            ,  round(nvl(total_borrador,0),2) total_borrador, nvl(cantidad_borrador,0)cantidad_borrador
    FROM MATERIAL M
    LEFT JOIN MATERIALCOMPRA MC ON m.idinversion=mc.idinversion AND nvl(m.codigogrupo,0)=nvl(mc.codigogrupo,0) AND m.idmaterial=mc.idmaterial;
/

