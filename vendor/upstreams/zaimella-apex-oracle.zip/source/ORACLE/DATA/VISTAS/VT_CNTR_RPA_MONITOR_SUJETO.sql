create or replace view data.vt_cntr_rpa_monitor_sujeto as
select e.id_ejecucion,
       e.id_configuracion,
       c.nombre configuracion,
       e.compania,
       e.usuario_apex,
       e.estado,
       d.tipo_sujeto,
       d.id_sujeto,
       case d.tipo_sujeto
           when 'PERSONA' then per.identificacion || ' - ' || per.nombres
           when 'EMPRESA' then emp.ruc || ' - ' || emp.razon_social
       end sujeto,
       min(d.fecha_inicio) inicio_detalle,
       max(d.fecha_fin) fin_detalle,
       count(distinct d.id_documento) cantidad_documentos,
       sum(case when d.estado = 'COMPLETADO' then 1 else 0 end) cantidad_detalle_exito,
       sum(case when d.estado = 'ERROR' then 1 else 0 end) cantidad_detalle_error
  from data.t_cntr_rpa_ejecuciones e
  join data.t_cntr_configuraciones c
    on c.id_configuracion = e.id_configuracion
   and c.compania = e.compania
  join data.t_cntr_rpa_ejecuciones_detalle d
    on d.id_ejecucion = e.id_ejecucion
  left join data.t_cntr_personas per
    on d.tipo_sujeto = 'PERSONA'
   and per.id_persona = d.id_sujeto
  left join data.t_cntr_empresas emp
    on d.tipo_sujeto = 'EMPRESA'
   and emp.id_empresa = d.id_sujeto
 group by e.id_ejecucion,
          e.id_configuracion,
          c.nombre,
          e.compania,
          e.usuario_apex,
          e.estado,
          d.tipo_sujeto,
          d.id_sujeto,
          per.identificacion,
          per.nombres,
          emp.ruc,
          emp.razon_social;
