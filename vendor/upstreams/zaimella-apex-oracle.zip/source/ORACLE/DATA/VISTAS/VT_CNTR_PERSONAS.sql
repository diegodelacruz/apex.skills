create or replace view data.vt_cntr_personas as
select id_persona,
       compania,
       tipo_identificacion,
       identificacion,
       nombres,
       nombres as nombre_completo,
       correo,
       telefono,
       estado,
       fecha_creacion,
       usuario_creacion,
       fecha_actualizacion,
       usuario_actualizacion
  from data.t_cntr_personas;

comment on table data.vt_cntr_personas is
    'Muestra personas matriculadas del modulo CNTR para consulta y mantenimiento desde APEX.';
