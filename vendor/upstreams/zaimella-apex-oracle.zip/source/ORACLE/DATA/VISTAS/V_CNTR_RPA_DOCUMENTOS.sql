create or replace view data.v_cntr_rpa_documentos as
select cd.id_configuracion,
       d.id_documento,
       d.id_portal,
       d.nombre_documento,
       d.evidencia_esperada,
       d.modo_captura,
       d.dato_busqueda,
       d.actualizacion_minima_dias
  from data.t_cntr_config_documentos cd
  join data.t_cntr_documentos d on d.id_documento = cd.id_documento
 where cd.estado = 'ACTIVO'
   and d.estado = 'ACTIVO';
