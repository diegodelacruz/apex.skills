﻿prompt PROD VIEW DATA.VT_ICOM_MESATRABAJOPROCESO

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_MESATRABAJOPROCESO" ("IDINVERSION", "INVERSION", "IDPROCESO", "DESCRIPCION", "USUARIOGESTION", "PORCENTAJE", "FECHAINICIO", "FECHAFIN", "USUARIO", "ESTADOPROCESO", "USUARIOACTUAL", "ESTADOFLUJO", "ENTIDAD", "ENTIDADID", "TIPO", "IDETAPA", "IDETAPA2") AS 
  select to_char(idinversion) idinversion, inversion, idproceso, descripcion, usuariogestion, porcentaje, 
       pro_fechainicio fechainicio, pro_fechafin fechafin, usuario, estadoproceso,  NULL USUARIOACTUAL, 
       case when porcentaje=100 then 'CERRADO' ELSE '' END estadoflujo,'' ENTIDAD ,'' ENTIDADID, 1 tipo,idetapa , idetapa2 
from data.vt_icom_procesocodigopromo
group by idinversion, inversion, idproceso, descripcion, usuariogestion, porcentaje, pro_fechainicio, pro_fechafin, usuario, estado, estadoproceso,idetapa, idetapa2
union
select to_char(p.idinversion), p.inversion, p.idproceso, p.descripcion, p.usuariogestion, 
       p.porcentaje, p.pro_fechainicio, p.pro_fechafin, p.usuario, p.estadoproceso, NULL USUARIOACTUAL, 
       case when porcentaje=100 then 'CERRADO' ELSE '' END estadoflujo, '' ENTIDAD ,'' ENTIDADID,1 tipo  ,idetapa, idetapa2
from data.vt_icom_procesoDisenoArte p
union

--Referencia Cruzada
select to_char(p.idinversion), p.inversion, p.idproceso, p.descripcion, p.usuariogestion, 
       p.porcentaje, p.pro_fechainicio, p.pro_fechafin, p.usuario, p.estado, NULL USUARIOACTUAL, 
       case when porcentaje=100 then 'CERRADO' ELSE '' END estadoflujo, '' ENTIDAD ,'' ENTIDADID,
       1 tipo  ,idetapa, idetapa2
from data.VT_ICOM_PROCESOREF_CRUZADA p
UNION
---COMPRA DE MATERIAL POP/ESPACIO CONTRATADO
SELECT to_char(idinversion), INVERSION, IDPROCESO, DESCRIPCION, USUARIOGESTION, PORCENTAJE, FECHAINICIO, FECHAFIN
 ,  USUARIO,  NULL estadoproceso, NULL USUARIOACTUAL, null estadoflujo,'' ENTIDAD ,'' ENTIDADID, 1 tipo  ,idetapa, idetapa2
FROM vt_icom_procesocomprapop MP 
WHERE (porcentaje<100 or (porcentaje>=75 and exists (SELECT 1 FROM vt_icom_cliente_material_negociado MN 
WHERE MN.idinversion=MP.idinversion AND requisicionlinea IS NULL )) )

---COMPRA DE MATERIAL POP/ESPACIO CONTRATADO APROBAR
UNION
SELECT ENTIDAD_ID IDINVERSION, ENTIDAD_DESCRIPCION  INVERSION, IDPROCESO, 'APROBACIÃ“N / '||DESCRIPCION,  '' USUARIOGESTION, PORCENTAJE, FECHAINICIO, FECHAFIN
 ,  '' usuario,  NULL estadoproceso, CASE WHEN F.ESTADO='EN_PROCESO' THEN USUARIOACTUAL ELSE '' END, f.ESTADO /*'EN_PROCESO'*/ estadoflujo,ENTIDAD_CLASE ENTIDAD ,ENTIDAD_ID ENTIDADID, 2 tipo  ,idetapa, idetapa2
FROM vt_icom_procesocomprapop p
INNER JOIN 
( SELECT USUARIOACTUAL, SUBSTR(ENTIDAD_ID, 1, INSTR(ENTIDAD_ID, '-', 1) -1) IDINVERSION, ENTIDAD_ID,
ENTIDAD_DESCRIPCION, ENTIDAD_CLASE, ESTADO
    FROM T_FLUJO_APROBACION_CAB WHERE CODMODULO='ICOM' AND ESTADO IN ('EN_PROCESO', 'APROBADO') AND ENTIDAD_CLASE='COMPRA_MATERIAL_POP') f
 on (p.IDINVERSION=f.IDINVERSION)   
--WHERE (porcentaje<75
UNION

---DISTRIBUCION DE MATERIAL POP
SELECT v.idinversion||'-'||m.ordencompra, v.INVERSION, v.IDPROCESO, 'DISTRIBUCION DE MATERIAL POP' DESCRIPCION, v.USUARIOGESTION, v.PORCENTAJE, v.FECHAINICIO, v.FECHAFIN
 , NULL  usuario,  v.estado estadoproceso, F.USUARIOACTUAL, case when porcentaje=100 then 'CERRADO' ELSE F.ESTADO END  estadoflujo, ENTIDAD_CLASE ENTIDAD ,ENTIDAD_ID ENTIDADID,
 Case nvl(d.estado,0) when 0 then 3 --Ingresado
                      when 1 then 4 --Aprobado
                      when 2 then 5 --En Ruta
 end tipo  ,idetapa, idetapa2
FROM vt_icom_procesocomprapop v
    inner join t_icom_cliente_materialcompra m on (v.idinversion = m.idinversion and m.ORDENCOMPRA is not null and DISTRIBUCION=1 )
    left join ( select ordencompra, idinversion, min(estado) estado from t_icom_cliente_material_dis group by ordencompra, idinversion ) d 
        on ( m.idinversion = d.idinversion and m.ordencompra = d.ordencompra  )
    LEFT JOIN DATA.T_FLUJO_APROBACION_CAB F ON 
		( F.codmodulo='ICOM' AND F.ENTIDAD_CLASE='DISTRIBUCION_MATERIAL_POP' AND F.ENTIDAD_ID= v.idinversion||'-'||m.ordencompra AND F.ESTADO='EN_PROCESO' )    
WHERE porcentaje>=75
group by v.idinversion||'-'||m.ordencompra, v.INVERSION, v.IDPROCESO, v.DESCRIPCION, v.USUARIOGESTION, v.PORCENTAJE, v.FECHAINICIO, v.FECHAFIN
 , v.usuario,  v.estado , F.USUARIOACTUAL, F.Estado, ENTIDAD_CLASE ,ENTIDAD_ID, 
 Case nvl(d.estado,0) when 0 then 3 --Ingresado
                      when 1 then 4 --Aprobado
                      when 2 then 5 --En Ruta
 end,idetapa, idetapa2
 UNION
 --distribucion producto regalo
 select to_char(p.idinversion), p.inversion, p.idproceso, p.descripcion, p.usuariogestion, p.porcentaje, 
      p.pro_fechainicio, p.pro_fechafin, p.usuario, p.estadoproceso, F.USUARIOACTUAL, 
      case when porcentaje=100 then 'CERRADO' ELSE F.ESTADO END  estadoflujo,ENTIDAD_CLASE ENTIDAD ,ENTIDAD_ID ENTIDADID , 1 tipo  ,idetapa, idetapa2
from data.vt_icom_procesoProductoDis p
	LEFT JOIN DATA.T_FLUJO_APROBACION_CAB F ON 
  		( F.codmodulo='ICOM' AND F.ENTIDAD_CLASE='PROCESO_PRODUCTO_REGALO' AND F.ENTIDAD_ID like p.idinversion||'%' AND F.ESTADO='EN_PROCESO' )
UNION
 --gestion de muestras
 select to_char(p.idinversion), p.inversion, p.idproceso, p.descripcion, p.usuariogestion, p.porcentaje, 
      p.PRO_FECHAINICIO, p.PRO_FECHAfin, p.usuario, p.estado, 
      F.USUARIOACTUAL, case when porcentaje=100 then 'CERRADO' ELSE F.ESTADO END  estadoflujo,
      ENTIDAD_CLASE ENTIDAD ,ENTIDAD_ID ENTIDADID,p.estadoproducto tipo  ,idetapa, idetapa2
from data.vt_icom_procesoMuestra p
	LEFT JOIN DATA.T_FLUJO_APROBACION_CAB F ON 
		( F.codmodulo='ICOM' AND F.ENTIDAD_CLASE='PROCESO_PRODUCTO_MUESTRA' AND F.ENTIDAD_ID= p.idinversion AND F.ESTADO='EN_PROCESO' )

UNION 

----PARAMETRIZACIÃ“N DE DESCUENTOS EN JDE
SELECT to_char(idinversion), INVERSION, IDPROCESO, DESCRIPCION, USUARIOGESTION, PORCENTAJE, FECHAINICIO, FECHAFIN
 ,  NULL USUARIO, ESTADO, NULL USUARIOACTUAL, null estadoflujo, NULL ENTIDAD ,NULL ENTIDADID,1 tipo  ,idetapa, idetapa2
FROM vt_icom_procesoDescuento;
/

