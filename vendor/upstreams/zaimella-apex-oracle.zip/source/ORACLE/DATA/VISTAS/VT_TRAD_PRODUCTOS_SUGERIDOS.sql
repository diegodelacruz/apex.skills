alter session set current_schema=DATA;
create or replace view data.vt_trad_productos_sugeridos as
select s.compania, s.codigopdv, s.codigoproducto,
       p.nombreproducto as producto, cast(null as varchar2(30)) as tipo,
       s.selloutmes, round(s.selloutmes / 30, 0) as rotacion,
       p.codigobarra, s.ub
  from data.t_trad_productos_sugeridos s
  join data.vt_gzm_producto p
    on p.compania = s.compania
   and p.codigoproducto = s.codigoproducto;
/
