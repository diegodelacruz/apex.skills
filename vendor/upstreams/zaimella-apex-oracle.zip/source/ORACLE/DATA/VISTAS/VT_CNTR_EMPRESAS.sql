create or replace view data.vt_cntr_empresas as
select id_empresa,
       compania,
       ruc,
       razon_social,
       nombre_comercial,
       tipo_empresa,
       estado,
       fecha_creacion,
       usuario_creacion,
       fecha_actualizacion,
       usuario_actualizacion
  from data.t_cntr_empresas;

comment on table data.vt_cntr_empresas is
    'Muestra empresas matriculadas del modulo CNTR para consulta y mantenimiento desde APEX.';
