create or replace view data.vt_cntr_documento_pasos as
select pasos.id_paso,
       pasos.id_documento,
       documentos.id_portal,
       portales.nombre_portal,
       documentos.nombre_documento,
       documentos.compania,
       pasos.orden,
       pasos.instruccion,
       pasos.tipo_accion,
       pasos.selector_elemento,
       pasos.valor_entrada,
       pasos.origen_valor,
       pasos.tiempo_espera_seg,
       pasos.requiere_intervencion,
       case pasos.requiere_intervencion when 1 then 'Si' else 'No' end requiere_intervencion_txt,
       pasos.descripcion,
       pasos.estado,
       pasos.fecha_creacion,
       pasos.usuario_creacion,
       pasos.fecha_actualizacion,
       pasos.usuario_actualizacion
  from data.t_cntr_documento_pasos pasos
       join data.t_cntr_documentos documentos
         on documentos.id_documento = pasos.id_documento
       join data.t_cntr_portales portales
         on portales.id_portal = documentos.id_portal;
