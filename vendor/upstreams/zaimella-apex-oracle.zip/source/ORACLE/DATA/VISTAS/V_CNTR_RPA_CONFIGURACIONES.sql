create or replace view data.v_cntr_rpa_configuraciones as
select c.id_configuracion,
       c.compania,
       c.nombre,
       c.usuario_creacion as usuario_apex
  from data.t_cntr_configuraciones c
 where c.estado = 'ACTIVO';
/
