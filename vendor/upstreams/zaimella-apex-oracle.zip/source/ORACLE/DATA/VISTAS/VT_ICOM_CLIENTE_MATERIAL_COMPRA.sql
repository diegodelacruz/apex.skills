﻿prompt PROD VIEW DATA.VT_ICOM_CLIENTE_MATERIAL_COMPRA

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_CLIENTE_MATERIAL_COMPRA" ("ID", "GRUPO", "IDINVERSION", "IDMATERIAL", "MATERIAL", "CODIGOGRUPO", "CLIENTE", "REQUISICIONLINEA", "LINEA", "REQUISICION", "REQUISICIONTIPO", "ORDENCOMPRA", "ORDENCOMPRATIPO", "DISTRIBUCION", "ACA_MARCA", "ACA_LINEA", "ACA_CLIENTE", "ACA_CANAL", "ICA", "INFORMACION", "OBSERVACIONES", "DESCRIPCION2", "JUSTIFICACION", "AUDITORIAFECHA", "AUDITORIAUSUARIO", "CANTIDAD", "COSTO", "TOTAL", "ESTADO", "ESTADO_DESCRIPCION", "FECHA_ACTIVIDAD", "FECHA_ACTIVIDAD_FIN", "COMPANIA") AS 
  SELECT
             c.id id
            ,c.GRUPO,c.idinversion,c.idmaterial, (mp.descripcion)material ,c.codigogrupo, NOMBRES CLIENTE
            ,c.requisicionlinea,c.requisicionlinea*1000 linea
            ,c.REQUISICION, c.REQUISICIONTIPO,c.ordencompra,c.ordencompratipo,
             nvl(mp.clasificacion,0) distribucion
            ,c.ACA_MARCA,c.ACA_LINEA,c.ACA_CLIENTE,c."ACA_CANAL",c."ICA",c.INFORMACION,c.OBSERVACIONES,c.DESCRIPCION2
            ,c.justificacion,c.auditoriafecha,c.auditoriausuario
            ,round(c.cantidad,2) cantidad,round(c.costo,2)costo,round(costo*cantidad,2)total,
            --,TOTAL_PENDIENTE, CANTIDAD_PENDIENTE, TOTAL_BORRADOR, CANTIDAD_BORRADOR, 
            c.estadoruta estado, 
            case when c.estadoruta in (-1,0) then 'BORRADOR' 
            when c.estadoruta =2 then 'EN RUTA'
            when c.estadoruta =1 then 'APROBADO' 
            when c.estadoruta =3 then 'RECEPCIONADO' ELSE '' END ESTADO_DESCRIPCION,
            c.FECHA_ACTIVIDAD,
            c.FECHA_ACTIVIDAD_FIN,
            mp.COMPANIA

        FROM t_icom_cliente_materialcompra  c
         inner JOIN  vt_icom_materialpop      mp ON ( c.idmaterial = mp.id )
         LEFT JOIN VT_GZM_CLIENTE CL ON CL.CODIGOCLIENTE=C.codigogrupo;
/

