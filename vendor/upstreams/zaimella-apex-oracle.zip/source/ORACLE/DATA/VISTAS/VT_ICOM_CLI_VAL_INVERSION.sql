﻿prompt PROD VIEW DATA.VT_ICOM_CLI_VAL_INVERSION

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_CLI_VAL_INVERSION" ("IDVALIDACION", "IDINVERSION", "IDINVERSIONTIPO", "CODIGOGRUPO", "IDVALIDACIONTIPO", "IDFORMAPAGO", "FECHAINICIO", "FECHAFIN", "ESTADO", "IDAGRUPACION", "VAL_FECHAINICIO", "VAL_FECHAFIN", "OBSERVACIONES", "TOT_VENTA", "TOT_VALORCLIENTE", "TOT_VALORZAIMELLA", "TOT_VALOREXCEPCION", "TOT_VALOR", "TIPO", "AREA", "NOMBRE", "CATEGORIA", "NOMBREGRUPO", "FORMAPAGO", "TOT_VENTAUND", "DIFERENCIA", "IDREBATE", "PERIODO") AS 
  select a.id idvalidacion, a.idinversion, a.idinversiontipo, a.codigogrupo, 
a.idvalidaciontipo, a.idformapago, a.fechainicio, a.fechafin,
a.estado, a.idagrupacion, a.val_fechainicio, a.val_fechafin,
a.observaciones, a.tot_venta, a.tot_valorcliente, a.tot_valorzaimella, 
a.tot_valorexcepcion, tot_valorzaimella+nvl(tot_valorexcepcion,0) tot_valor, v.inversiontipo tipo, v.area, v.nombre, 
g.categoria, c.nombres nombregrupo, F.DESCRIPCION formapago, a.tot_ventaund, 
((tot_valorzaimella+nvl(tot_valorexcepcion,0)) - tot_valorcliente) DIFERENCIA,
a.idrebate, a.periodo
from data.t_icom_cliente_validacion a
    inner join data.vt_icom_inversiones v on (a.idinversion = v.id )
    inner join data.t_icom_inversion_cliente_g g
        on (a.idinversion = g.idinversion and a.codigogrupo = g.codigogrupo )
	left join data.VT_GZM_CLIENTE c on (C.COMPANIA=A.COMPANIA AND c.codigoCLIENTE = a.codigogrupo)	
	LEFT JOIN data.VT_ICOM_FORMAPAGO F ON (F.IDFORMAPAGO=a.IDFORMAPAGO);
/

