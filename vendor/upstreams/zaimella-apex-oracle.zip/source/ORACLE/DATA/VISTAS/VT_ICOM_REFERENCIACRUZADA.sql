﻿prompt PROD VIEW DATA.VT_ICOM_REFERENCIACRUZADA

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_REFERENCIACRUZADA" ("IDINVERSION", "FECHAHASTA", "FECHADESDE", "CODIGOCLIENTE", "CODIGOPRODUCTO", "CODIGOPRODUCTOREF", "NOMBREPRODUCTO", "IDINVERSION1", "IDINVERSION2", "IDINVERSION3", "IDINVERSION4", "IDINVERSION5", "IDINVERSION6", "CLIENTE", "CODIGOGRUPO", "CANAL", "PRODUCTOREF", "TIPO") AS 
  SELECT f2.IVPFN1 idinversion, TO_DATE(f.IVEXDJ + 1900000,'YYYYDDD') fechaHasta,
TO_DATE(f.IVEFTJ + 1900000,'YYYYDDD') fechaDesde,
f.IVAN8 codigoCliente, trim(f.IVCITM) codigoProducto,  trim(f.IVLITM) codigoProductoRef, f.IVDSC1 nombreproducto ,
f2.IVPFN1 idInversion1, f2.IVPFN2 idInversion2, f2.IVPFN3 idInversion3, f2.IVPFN4 idInversion4, f2.IVPFN5 idInversion5, f2.IVPFN6 idInversion6,
cl.nombres Cliente, cl.codigogrupo, cl.canal, p.nombreproducto ProductoRef, f.IVXRT Tipo from
F4104@JDEDTADL   f --on ( pr.codigoproducto = trim(f.IVCITM) and nvl(f.IVEXDJ,0) > 116000  and TO_DATE(f.IVEXDJ + 1900000,'YYYYDDD') < sysdate )
left join F554104@JDEDTADL  f2 on 
    (f.IVAN8=f2.IVAN8  and  f.IVXRT=f2.IVXRT and  f.IVITM=f2.IVITM  and f.IVEXDJ=f2.IVEXDJ and f.IVCITM=f2.IVCITM )
left join data.vt_gzm_cliente cl on ( trim(f.IVAN8) = cl.codigocliente )    
left join data.vt_gzm_producto p on (trim(f.IVLITM) = p.codigoproducto )
where f.IVAN8<>0 and f.IVXRT='SP' AND 
((TO_CHAR(SYSDATE,'YYYYDDD')-1900000 BETWEEN f.IVEFTJ AND f.IVEXDJ or f.IVEFTJ > TO_CHAR(SYSDATE,'YYYYDDD')-1900000));
/

