create or replace view data.vt_cntr_matriz_documental as
select c.id_configuracion,
       c.compania,
       c.usuario_creacion usuario_propietario,
       s.tipo_sujeto,
       s.id_sujeto,
       s.id_empresa_origen,
       case s.tipo_sujeto
           when 'PERSONA' then per.identificacion
           when 'EMPRESA' then emp.ruc
       end identificacion,
       case s.tipo_sujeto
           when 'PERSONA' then per.nombres
           when 'EMPRESA' then emp.razon_social
       end sujeto,
       d.id_documento,
       p.nombre_portal portal,
       d.nombre_documento documento,
       ev.id_evidencia,
       fa.numeroarchivo,
       fa.filename,
       fa.mimetype,
       fa.fecha fecha_documento,
       case
           when fa.numeroarchivo is not null then 'LISTO'
           when det.estado in ('ERROR', 'FINALIZADA_CON_ERROR') then 'ERROR'
           when det.estado = 'NO_APLICA' then 'NO_APLICA'
           else 'PENDIENTE'
       end estado_documental
  from data.t_cntr_configuraciones c
  join (
        select id_configuracion,
               tipo_sujeto,
               id_sujeto,
               min(id_empresa_origen) id_empresa_origen
          from data.v_cntr_rpa_sujetos
         group by id_configuracion, tipo_sujeto, id_sujeto
       ) s
    on s.id_configuracion = c.id_configuracion
  join data.v_cntr_rpa_documentos rd
    on rd.id_configuracion = c.id_configuracion
  join data.t_cntr_documentos d
    on d.id_documento = rd.id_documento
  join data.t_cntr_portales p
    on p.id_portal = d.id_portal
  left join data.t_cntr_personas per
    on s.tipo_sujeto = 'PERSONA'
   and per.id_persona = s.id_sujeto
  left join data.t_cntr_empresas emp
    on s.tipo_sujeto = 'EMPRESA'
   and emp.id_empresa = s.id_sujeto
  left join data.t_cntr_evidencias ev
    on ev.id_documento = d.id_documento
   and ev.tipo_sujeto = s.tipo_sujeto
   and ev.id_sujeto = s.id_sujeto
  left join files.t_apex_archivos fa
    on fa.tabla = 'T_CNTR_EVIDENCIAS'
   and fa.id_tabla = to_char(ev.id_evidencia)
   and fa.tipo = 'EVIDENCIA_CNTR'
   and fa.estado = 'ACTIVO'
  left join (
        select id_configuracion,
               id_documento,
               tipo_sujeto,
               id_sujeto,
               estado
          from (
                select e.id_configuracion,
                       d.id_documento,
                       d.tipo_sujeto,
                       d.id_sujeto,
                       d.estado,
                       row_number() over (
                           partition by e.id_configuracion, d.id_documento, d.tipo_sujeto, d.id_sujeto
                           order by d.fecha_inicio desc, d.id_ejecucion_detalle desc) orden
                  from data.t_cntr_rpa_ejecuciones e
                  join data.t_cntr_rpa_ejecuciones_detalle d
                    on d.id_ejecucion = e.id_ejecucion
               )
         where orden = 1
       ) det
    on det.id_configuracion = c.id_configuracion
   and det.id_documento = d.id_documento
   and det.tipo_sujeto = s.tipo_sujeto
   and det.id_sujeto = s.id_sujeto
 where c.estado = 'ACTIVO';
/

comment on table data.vt_cntr_matriz_documental is 'Matriz normalizada de sujetos, documentos y evidencia vigente por configuracion.';
comment on column data.vt_cntr_matriz_documental.id_configuracion is 'Configuracion de captura que define filas y columnas.';
comment on column data.vt_cntr_matriz_documental.compania is 'Compania propietaria de la configuracion.';
comment on column data.vt_cntr_matriz_documental.usuario_propietario is 'Usuario APEX propietario de la configuracion.';
comment on column data.vt_cntr_matriz_documental.tipo_sujeto is 'Tipo de propietario PERSONA o EMPRESA.';
comment on column data.vt_cntr_matriz_documental.id_sujeto is 'Identificador interno del propietario documental.';
comment on column data.vt_cntr_matriz_documental.id_empresa_origen is 'Empresa que incluyo al sujeto cuando corresponde.';
comment on column data.vt_cntr_matriz_documental.identificacion is 'Cedula o RUC visible del propietario.';
comment on column data.vt_cntr_matriz_documental.sujeto is 'Nombre o razon social visible del propietario.';
comment on column data.vt_cntr_matriz_documental.id_documento is 'Identificador interno del documento.';
comment on column data.vt_cntr_matriz_documental.portal is 'Nombre visible del portal fuente.';
comment on column data.vt_cntr_matriz_documental.documento is 'Nombre visible del documento.';
comment on column data.vt_cntr_matriz_documental.id_evidencia is 'Identificador de la cabecera documental cuando existe.';
comment on column data.vt_cntr_matriz_documental.numeroarchivo is 'Archivo vigente asociado a la evidencia.';
comment on column data.vt_cntr_matriz_documental.filename is 'Nombre del archivo vigente.';
comment on column data.vt_cntr_matriz_documental.mimetype is 'Tipo MIME del archivo vigente.';
comment on column data.vt_cntr_matriz_documental.fecha_documento is 'Fecha de registro de la version vigente.';
comment on column data.vt_cntr_matriz_documental.estado_documental is 'Estado LISTO, PENDIENTE, ERROR o NO_APLICA.';
