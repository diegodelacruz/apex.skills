﻿prompt PROD VIEW DATA.VT_ICOM_EJECUCION

  CREATE OR REPLACE FORCE EDITIONABLE VIEW "DATA"."VT_ICOM_EJECUCION" ("ID", "DESCRIPCION", "ESTADO", "ORDEN", "COMPANIA") AS 
  select id_tabla id, descripcion, activo estado, TO_NUMBER(VALOR) orden,CODIGOCOMPANIA COMPANIA
  from data.T_CORP_UDC
  where id_cabecera = 'ICOM_EJECU';
/

