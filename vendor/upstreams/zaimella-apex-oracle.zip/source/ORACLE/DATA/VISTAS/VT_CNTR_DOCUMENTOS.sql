create or replace view data.vt_cntr_documentos as
select documentos.id_documento,
       documentos.id_portal,
       portales.nombre_portal,
       documentos.compania,
       documentos.nombre_documento,
       documentos.evidencia_esperada,
       documentos.modo_captura,
       documentos.dato_busqueda,
       documentos.prompt_ia,
       documentos.actualizacion_minima_dias,
       documentos.estado,
       documentos.fecha_creacion,
       documentos.usuario_creacion,
       documentos.fecha_actualizacion,
       documentos.usuario_actualizacion
  from data.t_cntr_documentos documentos
       join data.t_cntr_portales portales
         on portales.id_portal = documentos.id_portal;
