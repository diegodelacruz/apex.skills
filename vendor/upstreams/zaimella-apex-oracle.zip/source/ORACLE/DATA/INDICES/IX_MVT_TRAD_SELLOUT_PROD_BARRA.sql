create index data.ix_mvt_trad_sellout_pdv_barra
  on data.mvt_trad_sellout (compania, codigobarra, codigopdv, fecha);
/
