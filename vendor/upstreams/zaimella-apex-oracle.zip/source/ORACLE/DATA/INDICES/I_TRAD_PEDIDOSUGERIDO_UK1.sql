ALTER SESSION SET CURRENT_SCHEMA = DATA;

/*
  Una sola cabecera confirmada por compañía, PDV y fecha de visita.
  Las cabeceras no confirmadas quedan fuera de la regla hasta su confirmación.
*/
CREATE UNIQUE INDEX I_TRAD_PEDIDOSUGERIDO_UK1
    ON T_TRAD_PEDIDOSUGERIDO (
        CASE WHEN CONFIRMADO = 1 THEN COMPANIA END,
        CASE WHEN CONFIRMADO = 1 THEN CODIGOPDV END,
        CASE WHEN CONFIRMADO = 1 THEN TRUNC(FECHAVISITA) END
    );
