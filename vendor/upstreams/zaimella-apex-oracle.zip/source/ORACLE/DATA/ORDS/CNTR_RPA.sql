begin
    ords.delete_module(p_module_name => 'CNTR_RPA');
    ords.define_module('CNTR_RPA', '/cntr-rpa/', 100, 'PUBLISHED',
        'API autenticada para ejecucion documental CNTR RPA.');

    ords.define_template('CNTR_RPA', 'health', p_etag_type => 'NONE');
    ords.define_handler('CNTR_RPA', 'health', 'GET', ords.source_type_query_one_row,
        q'[select 'ok' estado, systimestamp fecha_servidor from dual]');

    ords.define_template('CNTR_RPA', 'configuraciones-activas', p_etag_type => 'NONE');
    ords.define_handler('CNTR_RPA', 'configuraciones-activas', 'GET', ords.source_type_collection_feed,
        q'[select id_configuracion, compania, nombre, usuario_apex
             from data.v_cntr_rpa_configuraciones
            where upper(usuario_apex) = upper(:usuario_apex)
            order by nombre]');

    ords.define_template('CNTR_RPA', 'configuraciones/:id_configuracion/documentos', p_etag_type => 'NONE');
    ords.define_handler('CNTR_RPA', 'configuraciones/:id_configuracion/documentos', 'GET', ords.source_type_collection_feed,
        q'[select d.id_documento, d.id_portal, d.nombre_documento, d.evidencia_esperada,
                  d.modo_captura, d.dato_busqueda, p.nombre_portal, p.url_base,
                  p.requiere_captcha, p.requiere_login, d.actualizacion_minima_dias
             from data.v_cntr_rpa_documentos d
             join data.t_cntr_portales p on p.id_portal = d.id_portal and p.estado = 'ACTIVO'
            where d.id_configuracion = :id_configuracion
            order by d.id_documento]');

    ords.define_template('CNTR_RPA', 'configuraciones/:id_configuracion/sujetos', p_etag_type => 'NONE');
    ords.define_handler('CNTR_RPA', 'configuraciones/:id_configuracion/sujetos', 'GET', ords.source_type_collection_feed,
        q'[select s.tipo_sujeto, s.id_sujeto, s.id_empresa_origen, s.origen_configuracion,
                  case when s.tipo_sujeto = 'PERSONA' then p.identificacion else e.ruc end identificacion,
                  case when s.tipo_sujeto = 'PERSONA' then p.nombres else e.razon_social end nombre_sujeto
             from data.v_cntr_rpa_sujetos s
             left join data.t_cntr_personas p on p.id_persona = s.id_sujeto and s.tipo_sujeto = 'PERSONA'
             left join data.t_cntr_empresas e on e.id_empresa = s.id_sujeto and s.tipo_sujeto = 'EMPRESA'
            where s.id_configuracion = :id_configuracion
            order by s.tipo_sujeto, nombre_sujeto]');

    -- Entrega pares documento/sujeto ya resueltos por Oracle.  No se filtran
    -- documentos por portal en Python: solo se excluye una evidencia con archivo
    -- activo y fecha reciente cuando el documento declara una ventana positiva.
    ords.define_template('CNTR_RPA', 'configuraciones/:id_configuracion/pendientes', p_etag_type => 'NONE');
    ords.define_handler('CNTR_RPA', 'configuraciones/:id_configuracion/pendientes', 'GET', ords.source_type_collection_feed,
        q'[select d.id_documento, d.id_portal, d.nombre_documento, d.evidencia_esperada,
                  d.modo_captura, d.dato_busqueda, d.actualizacion_minima_dias,
                  p.nombre_portal, p.url_base, p.requiere_captcha, p.requiere_login,
                  s.tipo_sujeto, s.id_sujeto, s.id_empresa_origen, s.origen_configuracion,
                  case when s.tipo_sujeto = 'PERSONA' then per.identificacion else emp.ruc end identificacion,
                  case when s.tipo_sujeto = 'PERSONA' then per.nombres else emp.razon_social end nombre_sujeto
             from data.v_cntr_rpa_documentos d
             join data.t_cntr_portales p
               on p.id_portal = d.id_portal
              and p.estado = 'ACTIVO'
             join data.v_cntr_rpa_sujetos s
               on s.id_configuracion = d.id_configuracion
             left join data.t_cntr_personas per
               on per.id_persona = s.id_sujeto
              and s.tipo_sujeto = 'PERSONA'
             left join data.t_cntr_empresas emp
               on emp.id_empresa = s.id_sujeto
              and s.tipo_sujeto = 'EMPRESA'
            where d.id_configuracion = :id_configuracion
              and not exists (
                  select 1
                    from data.t_cntr_evidencias e
                    join files.t_apex_archivos a
                      on a.tabla = 'T_CNTR_EVIDENCIAS'
                     and a.id_tabla = to_char(e.id_evidencia)
                     and a.tipo = 'EVIDENCIA_CNTR'
                     and a.estado = 'ACTIVO'
                   where e.id_documento = d.id_documento
                     and e.tipo_sujeto = s.tipo_sujeto
                     and e.id_sujeto = s.id_sujeto
                     and nvl(d.actualizacion_minima_dias, 0) > 0
                     and a.fecha >= sysdate - d.actualizacion_minima_dias
              )
            order by d.id_documento, s.tipo_sujeto, nombre_sujeto]');

    ords.define_template('CNTR_RPA', 'ejecuciones-pendientes', p_etag_type => 'NONE');
    ords.define_handler('CNTR_RPA', 'ejecuciones-pendientes', 'GET', ords.source_type_collection_feed,
        q'[select e.id_ejecucion, e.id_configuracion, e.fecha_inicio
             from data.t_cntr_rpa_ejecuciones e
            where e.estado = 'EN_PROCESO'
              and upper(e.usuario_apex) = upper(:usuario_apex)
              and (:id_configuracion is null or e.id_configuracion = :id_configuracion)
              and exists (
                  select 1
                    from data.t_cntr_rpa_ejecuciones_detalle d
                   where d.id_ejecucion = e.id_ejecucion
                     and d.estado in ('EN_PROCESO', 'REINTENTABLE')
              )
            order by e.fecha_inicio, e.id_ejecucion]');

    ords.define_template('CNTR_RPA', 'ejecuciones', p_etag_type => 'NONE');
    ords.define_handler('CNTR_RPA', 'ejecuciones', 'POST', ords.source_type_plsql,
        q'[declare l_id_ejecucion number; begin
               data.pk_cntr_rpa.crear_ejecucion(:id_configuracion, :tipo_ejecucion, :usuario_apex, :ambiente, l_id_ejecucion);
               owa_util.mime_header('application/json; charset=utf-8');
               htp.prn('{"ok":true,"id_ejecucion":' || to_char(l_id_ejecucion) || '}');
           exception when others then
               :status_code := 400; owa_util.mime_header('application/json; charset=utf-8'); htp.prn('{"ok":false,"error":' || apex_json.stringify(sqlerrm) || '}');
           end;]');

    ords.define_template('CNTR_RPA', 'ejecuciones/:id_ejecucion/detalles', p_etag_type => 'NONE');
    ords.define_handler('CNTR_RPA', 'ejecuciones/:id_ejecucion/detalles', 'POST', ords.source_type_plsql,
        q'[declare l_id_detalle number; begin
               data.pk_cntr_rpa.iniciar_detalle(:id_ejecucion, :id_documento, :tipo_sujeto, :id_sujeto, l_id_detalle, :id_empresa_origen);
               owa_util.mime_header('application/json; charset=utf-8'); htp.prn('{"ok":true,"id_detalle":' || to_char(l_id_detalle) || '}');
           exception when others then
               :status_code := 400; owa_util.mime_header('application/json; charset=utf-8'); htp.prn('{"ok":false,"error":' || apex_json.stringify(sqlerrm) || '}');
           end;]');

    ords.define_template('CNTR_RPA', 'ejecuciones/:id_ejecucion/detalles-pendientes', p_etag_type => 'NONE');
    ords.define_handler('CNTR_RPA', 'ejecuciones/:id_ejecucion/detalles-pendientes', 'GET', ords.source_type_collection_feed,
        q'[select ed.id_ejecucion_detalle id_detalle, e.id_configuracion, ed.id_documento,
                  ed.tipo_sujeto, ed.id_sujeto, ed.id_empresa_origen, ed.estado
             from data.t_cntr_rpa_ejecuciones e
             join data.t_cntr_rpa_ejecuciones_detalle ed on ed.id_ejecucion = e.id_ejecucion
            where e.id_ejecucion = :id_ejecucion
              and upper(e.usuario_apex) = upper(:usuario_apex)
              and e.estado = 'EN_PROCESO'
              and ed.estado in ('EN_PROCESO', 'REINTENTABLE')
            order by ed.id_ejecucion_detalle]');

    ords.define_template('CNTR_RPA', 'ejecuciones-detalle/:id_detalle/pasos', p_etag_type => 'NONE');
    ords.define_handler('CNTR_RPA', 'ejecuciones-detalle/:id_detalle/pasos', 'GET', ords.source_type_collection_feed,
        q'[select dp.id_paso, dp.orden, dp.tipo_accion, dp.selector_elemento, dp.valor_entrada, dp.origen_valor,
                  case dp.origen_valor
                      when 'IDENTIFICACION' then case ed.tipo_sujeto when 'PERSONA' then per.identificacion else emp.ruc end
                      when 'NOMBRES' then case ed.tipo_sujeto when 'PERSONA' then per.nombres end
                      when 'CORREO' then case ed.tipo_sujeto when 'PERSONA' then per.correo end
                      when 'RAZON_SOCIAL' then case ed.tipo_sujeto when 'EMPRESA' then emp.razon_social end
                      when 'NOMBRE_COMERCIAL' then case ed.tipo_sujeto when 'EMPRESA' then emp.nombre_comercial end
                      else dp.valor_entrada
                  end valor_resuelto,
                  dp.tiempo_espera_seg, dp.requiere_intervencion, dp.descripcion, dp.instruccion
             from data.t_cntr_rpa_ejecuciones_detalle ed
             join data.t_cntr_documento_pasos dp on dp.id_documento = ed.id_documento
             left join data.t_cntr_personas per on per.id_persona = ed.id_sujeto and ed.tipo_sujeto = 'PERSONA'
             left join data.t_cntr_empresas emp on emp.id_empresa = ed.id_sujeto and ed.tipo_sujeto = 'EMPRESA'
            where ed.id_ejecucion_detalle = :id_detalle
              and dp.estado = 'ACTIVO'
            order by dp.orden]');

    ords.define_template('CNTR_RPA', 'ejecuciones-detalle/:id_detalle/resultado', p_etag_type => 'NONE');
    ords.define_handler('CNTR_RPA', 'ejecuciones-detalle/:id_detalle/resultado', 'PUT', ords.source_type_plsql,
        q'[declare l_id_evidencia number; l_version number; begin
               data.pk_cntr_rpa.registrar_resultado(
                   :id_detalle, :body, :filename, coalesce(:mimetype, :content_type), :origen,
                   to_timestamp(:fecha_obtencion, 'YYYY-MM-DD"T"HH24:MI:SS.FF'), :hash_sha256,
                   :usuario, l_id_evidencia, l_version);
               owa_util.mime_header('application/json; charset=utf-8'); htp.prn('{"ok":true,"id_evidencia":' || to_char(l_id_evidencia) || ',"version":' || to_char(l_version) || '}');
           exception when others then
               :status_code := 400; owa_util.mime_header('application/json; charset=utf-8'); htp.prn('{"ok":false,"error":' || apex_json.stringify(sqlerrm) || '}');
           end;]', null, 'application/pdf,image/png,image/jpeg');

    ords.define_template('CNTR_RPA', 'ejecuciones-detalle/:id_detalle/estado', p_etag_type => 'NONE');
    ords.define_handler('CNTR_RPA', 'ejecuciones-detalle/:id_detalle/estado', 'POST', ords.source_type_plsql,
        q'[begin data.pk_cntr_rpa.registrar_estado(:id_detalle, :estado, :mensaje); owa_util.mime_header('application/json; charset=utf-8'); htp.prn('{"ok":true}');
           exception when others then :status_code := 400; owa_util.mime_header('application/json; charset=utf-8'); htp.prn('{"ok":false,"error":' || apex_json.stringify(sqlerrm) || '}'); end;]');

    ords.define_template('CNTR_RPA', 'ejecuciones-detalle/:id_detalle/error', p_etag_type => 'NONE');
    ords.define_handler('CNTR_RPA', 'ejecuciones-detalle/:id_detalle/error', 'POST', ords.source_type_plsql,
        q'[begin data.pk_cntr_rpa.registrar_error(:id_detalle, :tipo_error, :mensaje, :paso_orden, :reintentable); owa_util.mime_header('application/json; charset=utf-8'); htp.prn('{"ok":true}');
           exception when others then :status_code := 400; owa_util.mime_header('application/json; charset=utf-8'); htp.prn('{"ok":false,"error":' || apex_json.stringify(sqlerrm) || '}'); end;]');

    ords.define_template('CNTR_RPA', 'ejecuciones-detalle/:id_detalle/reintentar', p_etag_type => 'NONE');
    ords.define_handler('CNTR_RPA', 'ejecuciones-detalle/:id_detalle/reintentar', 'POST', ords.source_type_plsql,
        q'[begin data.pk_cntr_rpa.reintentar_detalle(:id_detalle); owa_util.mime_header('application/json; charset=utf-8'); htp.prn('{"ok":true}');
           exception when others then :status_code := 400; owa_util.mime_header('application/json; charset=utf-8'); htp.prn('{"ok":false,"error":' || apex_json.stringify(sqlerrm) || '}'); end;]');

    -- Análisis IA: comparte módulo y autenticación OAuth del RPA.
    ords.define_template('CNTR_RPA', 'ia/health', p_etag_type => 'NONE');
    ords.define_handler('CNTR_RPA', 'ia/health', 'GET', ords.source_type_query_one_row,
        'select ''OK'' estado, systimestamp fecha from dual');
    ords.define_template('CNTR_RPA', 'ia/solicitudes-pendientes', p_etag_type => 'NONE');
    ords.define_handler('CNTR_RPA', 'ia/solicitudes-pendientes', 'GET', ords.source_type_collection_feed,
        'select distinct id_solicitud_analisis from data.t_cntr_ia_analisis where estado in (''PENDIENTE'',''ERROR_REINTENTABLE'') order by id_solicitud_analisis');
    ords.define_template('CNTR_RPA', 'ia/solicitudes/:id_solicitud/cabeceras', p_etag_type => 'NONE');
    ords.define_handler('CNTR_RPA', 'ia/solicitudes/:id_solicitud/cabeceras', 'GET', ords.source_type_collection_feed,
        'select id_analisis,id_solicitud_analisis,id_configuracion,tipo_sujeto,id_sujeto,compania,usuario_solicitante,estado from data.t_cntr_ia_analisis where id_solicitud_analisis=:id_solicitud and estado in (''PENDIENTE'',''ERROR_REINTENTABLE'') order by id_analisis');
    ords.define_template('CNTR_RPA', 'ia/analisis/:id_analisis/documentos', p_etag_type => 'NONE');
    ords.define_handler('CNTR_RPA', 'ia/analisis/:id_analisis/documentos', 'GET', ords.source_type_collection_feed,
        'select matriz.id_documento,matriz.id_evidencia,matriz.numeroarchivo,matriz.filename nombre_archivo,documento.prompt_ia from data.t_cntr_ia_analisis analisis join data.vt_cntr_matriz_documental matriz on matriz.id_configuracion=analisis.id_configuracion and matriz.tipo_sujeto=analisis.tipo_sujeto and matriz.id_sujeto=analisis.id_sujeto join data.t_cntr_documentos documento on documento.id_documento=matriz.id_documento where analisis.id_analisis=:id_analisis and matriz.id_evidencia is not null and trim(documento.prompt_ia) is not null');
    ords.define_handler('CNTR_RPA', 'ia/analisis/:id_analisis/documentos', 'POST', ords.source_type_plsql,
        'begin data.pk_cntr_ia_analisis.registrar_documento(:id_analisis,:id_documento,:id_evidencia,:numero_archivo,:nombre_archivo,:prompt_ia,:estado_extraccion,:texto_extraido,:paginas_procesadas,:advertencias,:error_tecnico); :status_code:=204; end;');
    ords.define_template('CNTR_RPA', 'ia/analisis/:id_analisis/documentos/:numero_archivo/archivo', p_etag_type => 'NONE');
    ords.define_handler('CNTR_RPA', 'ia/analisis/:id_analisis/documentos/:numero_archivo/archivo', 'GET', ords.source_type_plsql,
        q'[declare
               l_archivo blob;
               l_mimetype varchar2(255);
           begin
               select archivo.blobcontent, archivo.mimetype
                 into l_archivo, l_mimetype
                 from data.t_cntr_ia_analisis analisis
                 join data.vt_cntr_matriz_documental matriz
                   on matriz.id_configuracion = analisis.id_configuracion
                  and matriz.tipo_sujeto = analisis.tipo_sujeto
                  and matriz.id_sujeto = analisis.id_sujeto
                 join data.t_cntr_documentos documento
                   on documento.id_documento = matriz.id_documento
                 join files.t_apex_archivos archivo
                   on archivo.numeroarchivo = matriz.numeroarchivo
                  and archivo.tabla = 'T_CNTR_EVIDENCIAS'
                  and archivo.tipo = 'EVIDENCIA_CNTR'
                  and archivo.estado = 'ACTIVO'
                where analisis.id_analisis = :id_analisis
                  and archivo.numeroarchivo = :numero_archivo
                  and trim(documento.prompt_ia) is not null;
               sys.htp.init;
               owa_util.mime_header(nvl(l_mimetype, 'application/octet-stream'), false);
               sys.htp.p('Content-Length: ' || dbms_lob.getlength(l_archivo));
               owa_util.http_header_close;
               wpg_docload.download_file(l_archivo);
           exception
               when no_data_found then
                   :status_code := 404;
           end;]');
    ords.define_template('CNTR_RPA', 'ia/analisis/:id_analisis/iniciar', p_etag_type => 'NONE');
    ords.define_handler('CNTR_RPA', 'ia/analisis/:id_analisis/iniciar', 'POST', ords.source_type_plsql,
        'begin data.pk_cntr_ia_analisis.iniciar_analisis(:id_analisis); :status_code:=204; end;');
    ords.define_template('CNTR_RPA', 'ia/analisis/:id_analisis/reintentar', p_etag_type => 'NONE');
    ords.define_handler('CNTR_RPA', 'ia/analisis/:id_analisis/reintentar', 'POST', ords.source_type_plsql,
        'begin data.pk_cntr_ia_analisis.reintentar_analisis(:id_analisis,:mensaje); :status_code:=204; end;');
    ords.define_template('CNTR_RPA', 'ia/analisis/:id_analisis/finalizar', p_etag_type => 'NONE');
    ords.define_handler('CNTR_RPA', 'ia/analisis/:id_analisis/finalizar', 'POST', ords.source_type_plsql,
        'begin data.pk_cntr_ia_analisis.finalizar_analisis(:id_analisis,:estado,:proveedor,:modelo,:resultado,:resumen,:confianza,:advertencias,:error_tecnico); :status_code:=204; end;');

    ords.define_privilege(
        p_privilege_name => 'CNTR_RPA_AUTHENTICATED',
        p_roles => sys.owa.vc_arr(),
        p_patterns => sys.owa.vc_arr('/cntr-rpa/*'),
        p_modules => sys.owa.vc_arr('CNTR_RPA'),
        p_label => 'CNTR RPA authenticated',
        p_description => 'Protege los contratos del robot documental y análisis IA CNTR.');
    commit;
end;
/
