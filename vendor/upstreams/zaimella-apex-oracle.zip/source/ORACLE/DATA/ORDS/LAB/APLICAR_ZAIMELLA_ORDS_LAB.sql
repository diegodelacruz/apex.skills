declare
    V_RESULTADO varchar2(4000);
begin
    data.pk_lab_ords.aplicar;
    data.pk_lab_ords.validar(V_RESULTADO);
    if V_RESULTADO <> 'ORDS_OK;VERSION=' || data.pk_lab_ords.f_version then
        raise_application_error(-20085, 'Validacion ORDS posterior no conforme.');
    end if;
end;
/
