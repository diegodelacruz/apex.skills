-- Modulo: LAB
-- Alcance: API ORDS minima y publicador estable bajo DATA.
-- Responsable: JBALCAZAR
-- Orden: package spec, package body y aplicacion idempotente del modulo.
alter session set current_schema=DATA;

@@../../PAQUETES/SPECS/PK_LAB_ORDS.sql
@@../../PAQUETES/BODIES/PK_LAB_ORDS.sql
@@APLICAR_ZAIMELLA_ORDS_LAB.sql
