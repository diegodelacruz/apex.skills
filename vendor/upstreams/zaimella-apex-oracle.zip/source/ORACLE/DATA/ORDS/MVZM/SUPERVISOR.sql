begin
  ords.define_handler(
    p_module_name => 'MVZM',
    p_pattern     => 'supervisor/:NombreUsuario/:Compania',
    p_method      => 'GET',
    p_source_type => ords.source_type_collection_feed,
    p_source      => q'~
SELECT
    u.nombres || ' ' || u.apellidos AS nombres,
    NVL(u.email, 'mv@zaimella.com') AS correo,
    CAST(NULL AS VARCHAR2(50)) AS celular,
    (
        SELECT LISTAGG(z.zona, ', ') WITHIN GROUP (ORDER BY z.zona)
        FROM vt_trad_zonas z
        WHERE z.usuariocordinador = u.nombreusuario
          AND z.compania = :Compania
    ) AS zona,
    u.nombreusuario AS usuario
FROM vt_corp_usuario u
WHERE u.nombreusuario = DATA.PK_EVOLUTION_EMPLEADO.F_RETORNASUPERVISOR(
    P_USUARIO => UPPER(:NombreUsuario)
)
~'
  );
  commit;
end;
/
