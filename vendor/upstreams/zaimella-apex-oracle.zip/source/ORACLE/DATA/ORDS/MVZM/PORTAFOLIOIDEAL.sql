/* Caso 50661: conserva el contrato JSON historico; solo cambia la fuente a VT_TRAD_PRODUCTOS_SUGERIDOS. */
begin
  execute immediate 'alter session set current_schema=DATA';
  ords.define_handler(
    p_module_name => 'MVZM',
    p_pattern     => 'portafolioideal/',
    p_method      => 'GET',
    p_source_type => ords.source_type_plsql,
    p_source      => q'~
begin
  /*
    Sin p_codigopdv descarga los PDV de las visitas del usuario para hoy.
    Con p_codigopdv atiende una visita provisional sin cargar el resto
    del portafolio. La app puede enviar CODIGOPDV-NUMERO; solo se usa el
    codigo base porque T_TRAD_PRODUCTOS_SUGERIDOS ya no maneja NUMERO.
  */
  declare
    v_codigopdv number;
  begin
    if :p_codigopdv is not null then
      v_codigopdv := to_number(regexp_substr(:p_codigopdv, '^[^-]+'));
    end if;

  apex_json.initialize_clob_output;
  apex_json.open_object;
  apex_json.open_array('items');

  for r_pdvs in (
    select distinct to_number(regexp_substr(referenciaid, '^[0-9]+')) as codigopdv,
           referenciaid as codigo_local
      from data.t_mvzm_visitas
     where compania = :p_compania
       and upper(usuario) = upper(:p_usuario)
       and trunc(fechavisita) = trunc(sysdate)
       and regexp_like(referenciaid, '^[0-9]+-')
       and v_codigopdv is null
    union all
    select v_codigopdv, to_char(v_codigopdv)
      from dual
     where v_codigopdv is not null
  ) loop
    apex_json.open_object;
    apex_json.write('codigopdv', r_pdvs.codigo_local);
    apex_json.open_array('portafolio_ideal');
    for r_prod in (
      select codigoproducto, producto, nvl(tipo, 'A') as tipo,
             selloutmes, rotacion, codigobarra, nvl(ub, 0) as ub
        from data.vt_trad_productos_sugeridos
       where compania = :p_compania
         and codigopdv = r_pdvs.codigopdv
    ) loop
      apex_json.open_object;
      apex_json.write('codigoproducto', r_prod.codigoproducto);
      apex_json.write('descripcion', r_prod.producto);
      apex_json.write('codigobarra', r_prod.codigobarra);
      apex_json.write('sellout', r_prod.selloutmes);
      apex_json.write('ub', r_prod.ub);
      apex_json.write('rotacion', r_prod.rotacion);
      apex_json.write('tipo', r_prod.tipo);
      apex_json.close_object;
    end loop;
    apex_json.close_array;
    apex_json.close_object;
  end loop;

  apex_json.close_array;
  apex_json.write('fecha_actualizacion', to_char(sysdate, 'ddmmyyyy hh24:mi:ss'));
  apex_json.close_object;
  owa_util.mime_header('application/json', false);
  htp.p('Cache-Control: no-cache');
  owa_util.http_header_close;
  htp.prn(apex_json.get_clob_output);
  apex_json.free_output;
  end;
end;~'
  );
  commit;
end;
/
