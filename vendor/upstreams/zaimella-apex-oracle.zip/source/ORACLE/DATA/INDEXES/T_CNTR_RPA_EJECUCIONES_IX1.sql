declare
    v_total number;
begin
    select count(*)
      into v_total
      from user_indexes
     where index_name = 'T_CNTR_RPA_EJECUCIONES_IX1';

    if v_total = 0 then
        execute immediate q'[
            create index data.t_cntr_rpa_ejecuciones_ix1
                on data.t_cntr_rpa_ejecuciones (
                    compania,
                    upper(usuario_apex),
                    fecha_inicio desc,
                    id_ejecucion)
        ]';
    end if;
end;
/

