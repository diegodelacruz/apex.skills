create unique index data.t_cntr_evidencias_uk1 on data.t_cntr_evidencias
    (id_documento, tipo_sujeto, id_sujeto);
