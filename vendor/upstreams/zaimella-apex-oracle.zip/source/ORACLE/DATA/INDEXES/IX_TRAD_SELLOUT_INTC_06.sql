-- INC71: indice de cobertura para el promedio historico de Sellout.
-- Ejecutar con CURRENT_SCHEMA=DATA. No modifica datos transaccionales.
DECLARE
  l_existe NUMBER;
BEGIN
  SELECT COUNT(*)
    INTO l_existe
    FROM user_indexes
   WHERE index_name = 'IX_TRAD_SELLOUT_INTC_06';

  IF l_existe = 0 THEN
    EXECUTE IMMEDIATE q'[
      CREATE INDEX IX_TRAD_SELLOUT_INTC_06
        ON T_TRAD_SELLOUT (NVL(CODIGOGRUPO, CODIGOCLIENTE), FECHA, VALORTOTAL)
    ]';
  END IF;

  EXECUTE IMMEDIATE 'ALTER INDEX IX_TRAD_SELLOUT_INTC_06 VISIBLE';
END;
/
