declare
    v_total number;
begin
    select count(*)
      into v_total
      from user_indexes
     where index_name = 'T_CNTR_RPA_EJEC_DET_IX1';

    if v_total = 0 then
        execute immediate q'[
            create index data.t_cntr_rpa_ejec_det_ix1
                on data.t_cntr_rpa_ejecuciones_detalle (
                    id_ejecucion,
                    fecha_inicio,
                    id_ejecucion_detalle)
        ]';
    end if;
end;
/
