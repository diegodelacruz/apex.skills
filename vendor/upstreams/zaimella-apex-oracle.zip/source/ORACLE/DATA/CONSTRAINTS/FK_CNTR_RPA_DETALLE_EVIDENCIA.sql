alter table data.t_cntr_rpa_ejecuciones_detalle add constraint t_cntr_rpa_ejec_det_fk3
    foreign key (id_evidencia)
    references data.t_cntr_evidencias(id_evidencia);
