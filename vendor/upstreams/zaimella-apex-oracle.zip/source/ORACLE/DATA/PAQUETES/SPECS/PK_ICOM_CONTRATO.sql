﻿prompt Esquema DATA para codigo PL/SQL
alter session set current_schema=DATA;

prompt PROD PACKAGE DATA.PK_ICOM_CONTRATO

  CREATE OR REPLACE EDITIONABLE PACKAGE PK_ICOM_CONTRATO as
    
    G_MODULO VARCHAR(4):='ICOM';
    G_MENSAJE	CLOB;

    PROCEDURE SP_CONTRATOGUARDAR (P_ID IN OUT NUMBER,P_TIPO IN NUMBER,p_NOMBRE VARCHAR,p_TIPOINVERSION VARCHAR,
                                  p_TIPOCONTRATO VARCHAR,p_ESTADO NUMBER, P_CONTENIDO CLOB, P_SUBTIPO NUMBER DEFAULT 1
                                  ,  P_COMPANIA VARCHAR);

    PROCEDURE SP_CONTRATO_AGREGARREGISTROS(P_IDCONTRATO NUMBER);
    
    PROCEDURE SP_DISTRIBUIDOR_INICIO(P_IDINVERSION NUMBER, P_COMPANIA VARCHAR);  

    PROCEDURE SP_CONTRATO_DISTRIBUIDOR (P_IDINVERSION NUMBER, P_CODGRUPO VARCHAR2);

    PROCEDURE SP_DISTRIBUIDOR_GESTION(P_IDINVERSION NUMBER, P_CLIENTE VARCHAR);

    PROCEDURE SP_CONTRATO_ENVIAR (P_IDINVERSION VARCHAR, P_CODIGOCLIENTE VARCHAR2 DEFAULT NULL, 
                                  P_CODIGOPDV VARCHAR2 DEFAULT NULL, P_TIPOCONTRATO NUMBER, P_USUARIO VARCHAR2 );
                                  
    PROCEDURE SP_CONTRATO_ACEPTAR (P_IDINVERSION NUMBER, P_CODIGOCLIENTE VARCHAR2 DEFAULT NULL, P_CODIGOPDV VARCHAR2 DEFAULT NULL, 
                                   P_ACEPTA NUMBER, P_TIPOCONTRATO NUMBER, P_USUARIO VARCHAR2, P_SUBTIPO NUMBER DEFAULT 1, P_COMENTARIO VARCHAR2 DEFAULT NULL ); 
   
    PROCEDURE SP_CONTRATOAUDITORIA ( P_IDINVERSION NUMBER, P_CODIGOGRUPO VARCHAR2, P_CODIGOPDV VARCHAR2, 
                                     P_IDCONTRATO NUMBER, P_USUARIO VARCHAR2, P_TIPOCONTRATO VARCHAR2, 
                                     P_COMENTARIO VARCHAR2, P_AUDITORIATIPO VARCHAR2 ) ;
   
    PROCEDURE SP_ContratoContenido ( P_IDCONTRATO NUMBER, P_IDINVERSION NUMBER, 
        P_CODIGOGRUPO VARCHAR2, P_CODIGOPDV VARCHAR2, P_TIPOCONTRATO VARCHAR2, 
        P_ESTADO VARCHAR2, P_USUARIO VARCHAR2, P_NOMBRE VARCHAR2 ) ;
   
   PROCEDURE SP_Act_CorreoRepresentante ( P_IDINVERSION NUMBER, P_CODIGOGRUPO VARCHAR2, P_CORREO VARCHAR2, 
                                                P_REPRESENTANTE VARCHAR2 ); 
                                                
                                                
   PROCEDURE SP_ENVAR_NOTIFICACION(P_IDINVERSION VARCHAR, P_CODIGOCLIENTE VARCHAR2 DEFAULT NULL, 
                                  P_CODIGOPDV VARCHAR2 DEFAULT NULL, P_TIPOCONTRATO NUMBER, P_USUARIO VARCHAR2);
   
    FUNCTION F_TIENECONTRATOGENERADO(P_IDINVERSION  NUMBER, P_CODIGOCLIENTE NUMBER, P_CODIGOGRUPO NUMBER) RETURN NUMBER;

    FUNCTION F_URLCONTRATO(P_IDINVERSION  NUMBER, P_CODIGOCLIENTE VARCHAR2, P_CODIGOGRUPO VARCHAR2, P_PAGINA VARCHAR2, P_SESION VARCHAR2, 
                           P_CACHE NUMBER, P_PRIVADO NUMBER) RETURN VARCHAR2;

    FUNCTION F_URLCONTRATO( P_PAGINA VARCHAR2, P_SESION VARCHAR2, P_CACHE NUMBER, P_PRIVADO NUMBER, 
                            P_PARAMETROS VARCHAR2) RETURN VARCHAR2 ;                           

    FUNCTION F_OBTENER_IDCONTRATO(P_IDINVERSION NUMBER, P_CODIGOGRUPO VARCHAR2 DEFAULT NULL, P_CODIGOPDV VARCHAR2 DEFAULT NULL, 
                                  P_TIPOCONTRATO NUMBER, P_SUBTIPO NUMBER DEFAULT 1) RETURN NUMBER;

   FUNCTION F_MOSTRAR_BOTONES_CONTRATO(P_IDINVERSION NUMBER, P_CODIGOGRUPO VARCHAR2 DEFAULT NULL, P_CODIGOPDV VARCHAR2 DEFAULT NULL, P_TIPOCONTRATO NUMBER ) RETURN NUMBER;
   
   FUNCTION F_CONTRATO_APROBADO (P_IDINVERSION NUMBER, P_CODIGOGRUPO VARCHAR2 DEFAULT NULL, P_CODIGOPDV VARCHAR2 DEFAULT NULL, 
                                 P_TIPOCONTRATO NUMBER) RETURN NUMBER ; 
   FUNCTION F_CONVERSIONCLOB( P_CLOB CLOB) RETURN BLOB        ; 
        
    FUNCTION F_BuscaArchivo (P_IDCONTRATO NUMBER, P_IDINVERSION NUMBER, 
        P_CODIGOGRUPO VARCHAR2, P_CODIGOPDV VARCHAR2, P_TIPOCONTRATO VARCHAR2, 
        P_ESTADO VARCHAR2) return number ;                            
        
    FUNCTION F_ValidaConvenio (P_CODIGOPDV VARCHAR2, P_CORREO VARCHAR2, P_TELEFONO VARCHAR2 ) RETURN NUMBER ;                                 
    
    FUNCTION F_REEMPLAZO_CONVENIO_PLANTILLA (
        P_IDINVERSION IN VT_ICOM_CLIENTE_PDV.IDINVERSION%TYPE,
        P_CODIGOPDV IN VT_ICOM_CLIENTE_PDV.CODIGOPDV%TYPE,
        P_TIPO IN NUMBER, P_COMPANIA IN VARCHAR DEFAULT NULL
    ) RETURN CLOB;
END PK_ICOM_CONTRATO;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "DATA"."PK_ICOM_CONTRATO" 	 AS
/* TIPOS DE CONTRATOS:
            1 -> CLIENTE
            2 -> PUNTO DE VENTA
            3 -> ADENDUM
            4 -> CLAUSURA 
*/
	/*Procedimiento para crear o modificar el contrato
      @param P_ID  				id del contrato (tabla T_ICOM_CONTRATOS)
	  @param p_NOMBRE 			Nombre del contrato
	  @param p_TIPOINVERSION    Tipo de inversion
	  @param p_TIPOCONTRATO     Tipo de contrato 
	  @param p_ESTADO           Estado del contrato
	  @param p_AUDITORIAFECHA   Fecha de auditoria
	  @param P_AUDITORIAUSUARIO Usuario creador del contrato
    Autor: CCarrasco (NETBY)
	Fecha: Agosto 2022
	*/
    V_COMPANIA VARCHAR2(5);

    PROCEDURE SP_CONTRATOGUARDAR (P_ID  IN OUT NUMBER,P_TIPO IN NUMBER, p_NOMBRE VARCHAR,p_TIPOINVERSION VARCHAR,
                            p_TIPOCONTRATO VARCHAR,p_ESTADO NUMBER, P_CONTENIDO CLOB, P_SUBTIPO NUMBER DEFAULT 1 
                            ,  P_COMPANIA VARCHAR) AS 	
    V_TABLA VARCHAR(50);
    CONTADOR NUMBER;
	begin
        V_TABLA:= 'T_ICOM_CONTRATOS';

        IF P_ID is null then

            IF P_TIPO = 2 THEN -- Solo si es mediante notificaciÂ¿n
                SELECT COUNT(ID) INTO CONTADOR FROM DATA.T_ICOM_CONTRATOS
                WHERE TIPO = 2 AND SUBTIPOCONTRATO = P_SUBTIPO AND COMPANIA=P_COMPANIA
                  AND ESTADO = 1
                ;
                IF CONTADOR > 0 THEN
                    raise_application_error(-20000,'Ya existe una notificaciÂ¿n con este tipo de envÂ¿o');
                END IF;
            END IF;

            P_ID := PK_COMMONS.F_SECUENCIA (V_TABLA);
            insert into DATA.T_ICOM_CONTRATOS(ID,NOMBRE,TIPOINVERSION,TIPOCONTRATO,ESTADO/*, CONTENIDO*/
            , SUBTIPOCONTRATO, TIPO, COMPANIA ) values (
            P_ID,P_NOMBRE,P_TIPOINVERSION,p_TIPOCONTRATO,P_ESTADO/*,  P_CONTENIDO*/ 
            , P_SUBTIPO, P_TIPO, P_COMPANIA); --El subtipo 1 o nulo es para contrato electronico, 2 para manual (P_SUBTIPO)
        ELSE
            IF P_TIPO = 2 THEN -- Solo si es mediante notificaciÂ¿n
                SELECT COUNT(ID) INTO CONTADOR FROM DATA.T_ICOM_CONTRATOS
                WHERE TIPO = 2 AND SUBTIPOCONTRATO = P_SUBTIPO AND ID <> P_ID AND ESTADO = 1 AND COMPANIA=P_COMPANIA;
                IF CONTADOR > 0 THEN
                    raise_application_error(-20000,'Ya existe una notificaciÂ¿n con este tipo de envÂ¿o ');
                END IF;
            END IF;

            UPDATE DATA.T_ICOM_CONTRATOS SET NOMBRE=P_NOMBRE,	
            TIPOINVERSION=P_TIPOINVERSION,
            TIPOCONTRATO=p_TIPOCONTRATO,
           -- CONTENIDO=P_CONTENIDO,
            SUBTIPOCONTRATO = P_SUBTIPO,
            ESTADO=p_ESTADO WHERE ID=P_ID;	
        end if;			
    END SP_CONTRATOGUARDAR;

    PROCEDURE SP_CONTRATO_AGREGARREGISTROS(P_IDCONTRATO NUMBER) AS
        v_resultado number;
        v_libre VARCHAR2(500);
        v_sql_query VARCHAR2(300);
        v_sql_query2 VARCHAR2(300);
        v_maximo NUMBER;
        v_campos_concatenados VARCHAR2(1000);
        v_etiqueta VARCHAR2(2500);
        v_valor VARCHAR2(2500);
        v_fila NUMBER;
        v_inversion NUMBER;
        v_codigopdv NUMBER;
        v_contador NUMBER;
        v_codigoCliente  VARCHAR2(50);
    BEGIN
        /* Verifica la ultima columna de etiquetas*/
        FOR i IN 2..50 LOOP
            IF i < 10 THEN 
                v_sql_query :=   'SELECT COUNT(C0' || i || ') AS NUM FROM DATA.VT_APEX_EXCEL WHERE C01 = 1 AND C0'|| i || ' IS NOT NULL' ;
            ELSE
                v_sql_query :=   'SELECT COUNT(C' || i || ') AS NUM FROM DATA.VT_APEX_EXCEL WHERE C01 = 1 AND C'|| i || ' IS NOT NULL' ;
            END IF;
            /*Ejecuta consulta con resultado en variable*/
            EXECUTE IMMEDIATE v_sql_query INTO v_libre;
            /* Verifica si tiene contenido la celda*/
            IF v_libre = 0 THEN  
                /* Si no tiene resultado salimos del ciclo para evitar recorrer todo*/
                EXIT WHEN v_libre = 0;
            ELSE
            /* Establecemos la fila maxima*/
                v_maximo := i;
               /* IF i >= 5 AND i < 6 THEN 
                    v_campos_concatenados := 'C0'|| i;
                ELSE
                     IF i < 10 THEN 
                         v_campos_concatenados := v_campos_concatenados || ' ||'',''|| C0'|| i;
                     ELSE 
                         v_campos_concatenados := v_campos_concatenados || ' ||'',''|| C'|| i;
                     END IF;
                END IF;
                */
            END IF;
        END LOOP;
        /*Eliminar las etiquetas antiguas en base a los campos primarios*/
        FOR eliminar IN (SELECT DISTINCT TO_NUMBER(C02) IDINVERSION, TO_NUMBER(NVL(C03,'0')) CODIGOPDV, C04 CODIGOCLIENTE FROM VT_APEX_EXCEL WHERE ID > 1)
        LOOP
            DELETE FROM T_ICOM_CONTRATO_CONTENIDO
            WHERE IDCONTRATO = P_IDCONTRATO
            --AND IDINVERSION = eliminar.IDINVERSION
            --AND (CODIGOPDV = eliminar.CODIGOPDV OR CODIGOGRUPO = eliminar.CODIGOCLIENTE)
            ;
        END LOOP;
        /* Cuenta el numero de filas que existen para subir incluida la cabecera*/
        SELECT MAX(ID) INTO v_fila FROM VT_APEX_EXCEL;
        /* Recorre desde la segunda fila hasta la ultima*/
        FOR fila IN 2 .. v_fila
        LOOP
    
            SELECT COUNT(1)   INTO v_contador
            FROM VT_APEX_EXCEL
            WHERE ID = fila AND TRIM(C02) IS NOT NULL;
    
            IF(v_contador>0) THEN 
                /*Obtiene los datos principales de la fila */
                SELECT TRIM(C02), TO_NUMBER(C03), C04 
                INTO v_inversion,     v_codigopdv,    v_codigoCliente
                FROM VT_APEX_EXCEL
                WHERE ID = fila AND TRIM(C02) IS NOT NULL;
                        /* Obtiene las etiquetas desde la columna 5 hasta la columna maxima donde tiene datos de etiquetas*/
                FOR i in 5..v_maximo LOOP
                    /*Genera la consulta dinamica del campo que se va a tomar el nombre de
                    la etiqueta FILA 1 y el respectivo valor de la fila que esta recorriendo*/
                     IF i < 10 THEN 
                        v_sql_query :=   'SELECT TO_CHAR(C0' || i || ')  FROM DATA.VT_APEX_EXCEL WHERE C01 = 1' ;
                        v_sql_query2 :=  'SELECT TO_CHAR(C0' || i || ')  FROM DATA.VT_APEX_EXCEL WHERE C01 = ' || fila;
                     ELSE
                        v_sql_query :=   'SELECT TO_CHAR(C' || i || ')  FROM DATA.VT_APEX_EXCEL WHERE C01 = 1' ;
                        v_sql_query2 :=  'SELECT TO_CHAR(C' || i || ')  FROM DATA.VT_APEX_EXCEL WHERE C01 = ' || fila;
                     END IF;
                        /*Ejecuta las consultas y almacena susu resultados for fila y columna correspondiente*/
                     EXECUTE IMMEDIATE v_sql_query INTO v_etiqueta;
                     EXECUTE IMMEDIATE v_sql_query2 INTO v_valor;
                        /* Inserta los valores en la tabla donde se almacenaran para reemplazar en el formato*/
                     INSERT INTO T_ICOM_CONTRATO_CONTENIDO (IDCONTRATO, IDINVERSION, CODIGOPDV, CODIGOGRUPO, ETIQUETA, VALOR)
                     SELECT P_IDCONTRATO, v_inversion, v_codigopdv, v_codigoCliente, v_etiqueta, v_valor FROM DUAL;
    
                END LOOP;
    
            END IF;
    
        END LOOP;

    END SP_CONTRATO_AGREGARREGISTROS;

    /*INICIA PROCESO DE ENVIO DE CONTRATOS PARA LOS DISTRIBUIDORES 
        PK_ICOM_NEGOCIACION.SP_DISTRIBUIDOR_INICIO(P_IDINVERSION=>5, P_COMPANIA=>'00001')       
    */
    PROCEDURE SP_DISTRIBUIDOR_INICIO(P_IDINVERSION NUMBER,  P_COMPANIA VARCHAR)AS 
    BEGIN

        IF( PK_ICOM_COMMONS.F_TIENECLIENTE(P_IDINVERSION)=1) THEN 
            RETURN ;
        END IF;

        FOR CLIENTE IN ( SELECT DISTINCT CODIGOGRUPO FROM T_ICOM_CLIENTE_PDV WHERE IDINVERSION=P_IDINVERSION) LOOP 
            PK_ICOM_CRUD.SP_CLIENTEAGREGAR(P_ID =>P_IDINVERSION,P_CLIENTE =>CLIENTE.CODIGOGRUPO,
            P_ALCANCE=>'G', P_COMPANIA =>P_COMPANIA, P_ANALISIS=>0);
        END LOOP;

    END SP_DISTRIBUIDOR_INICIO;

    /*Procedimiento que envÃ­a notificacion de un contrato via correo electrÃ³nico a cliente 
      @param P_IDCONTRATO  	 id del contrato (tabla T_ICOM_CONTRATOS)
	  @param P_IDINVERSION   id de inversion
	  @param p_CODGRUPO      CÃ³digo de Cliente 
	  @param p_CODPDV        CÃ³digo PDV
    Autor: CCarrasco (NETBY)
	Fecha: Agosto 2022
	*/   
    
    PROCEDURE SP_CONTRATO_DISTRIBUIDOR (P_IDINVERSION NUMBER, P_CODGRUPO VARCHAR2) AS

    v_contratorepresentante  DATA.T_ICOM_INVERSION_CLIENTE_G.CONTRATOREPRESENTANTE%TYPE;
    v_contratocorreo			DATA.T_ICOM_INVERSION_CLIENTE_G.CONTRATOCORREO%TYPE;
    v_nombrecliente			DATA.T_ICOM_INVERSION_CLIENTE_G.NOMBRES%TYPE;
    v_correos				VARCHAR2(1000);
    v_mensaje				CLOB;
    v_link                  VARCHAR2(500);
    v_urlServidor            VARCHAR2(100);
    v_asunto                 VARCHAR2(100);
    v_correoContacto         VARCHAR2(100);
    v_periodo                VARCHAR2(50);
    v_compania               VARCHAR2(5);
    BEGIN
        --APEX_DEBUG.ENABLE(apex_debug.c_log_level_info);
		SELECT CONTRATOREPRESENTANTE, CONTRATOCORREO, NOMBRES, TO_CHAR(FECHAINICIO, 'DD/MM/YYYY') || ' - ' ||   TO_CHAR(FECHAFIN, 'DD/MM/YYYY')
		INTO v_contratorepresentante, v_contratocorreo, v_nombrecliente, v_periodo
		FROM DATA.T_ICOM_INVERSION_CLIENTE_G I
		WHERE IDINVERSION = P_IDINVERSION
		AND I.CODIGOGRUPO = P_CODGRUPO;
        
        SELECT max(compania)
		INTO v_compania
		FROM DATA.T_ICOM_INVERSIONES I
		WHERE ID = P_IDINVERSION
        AND ROWNUM=1;
        
        IF(v_contratorepresentante IS NULL  OR v_contratocorreo IS NULL) THEN 
            raise_application_error(-20000,'InformaciÃ³n incompleta para el envio de correo');
        END IF;
    
        SELECT DOMINIO || RUTAMODULO INTO v_urlServidor FROM DATA.T_ADMI_MODULO WHERE CODIGO = 'ICOM';

        v_correoContacto:=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '5', v_compania );

        v_correos := v_contratocorreo;
    
        v_link := APEX_UTIL.PREPARE_URL(p_url => v_urlServidor || ':315:::NO:315:P315_HASH:' || DATA.PK_COMMONS.F_ENCRYPT('P315_IDINVERSION,P315_CODCLIENTE:'||P_IDINVERSION || ',' ||P_CODGRUPO) ) ;

        v_asunto := 'Solicitud de firma Convenio de Crecimiento Zaimella';
        --FORMATO APROBACIÃ“N CONVENIOS DISTRIBUIDOR  
        v_mensaje := '<p>Estimado cliente <strong>' || UPPER(v_nombrecliente) ||'</strong></p>
            <p>Los Convenios Comerciales para el periodo '|| v_periodo ||' se han emitido y requieren su revisi&oacute;n. Debe hacer clic en el enlace <a href = "'||v_link||'">Presione aqu&iacute;</a> y seguir las siguientes instrucciones:</p>
            <ol>
                <li>Revise los datos asociados a los convenios.</li>
                <li>Seleccione de manera individual o masiva para aceptar y enviar al punto de venta.</li>
                <li>Hacer clic en ACEPTAR</li>
            </ol>
            <p>Cualquier duda o consulta relacionada a esta comunicaci&oacute;n cont&aacute;ctenos al correo <a href="mailto:'|| v_correoContacto ||'">'|| v_correoContacto ||'</a></p>
            <p>&nbsp;</p>
            <p>Atentamente,</p>
            <p>&nbsp;</p>
            <p>ZAIMELLA DEL ECUADOR S.A.</p>';
        
        PK_CORP_CORREO.SP_ENVIO(
                    P_MODULO => 'ICOM',
                    P_TO => v_correos,
                    P_FROM => 'infocomercial@zaimella.com',
                    P_SUBJECT => v_asunto,
                    P_BODY => v_mensaje
                  );
                  
                UPDATE DATA.T_ICOM_CLIENTE_PDV
                SET CONTRATOAPROBAR = 1
                WHERE IDINVERSION = P_IDINVERSION
                AND CODIGOGRUPO = P_CODGRUPO
                AND ESTADO IS NULL
                AND CONTRATOAPROBAR IS NULL;

    END SP_CONTRATO_DISTRIBUIDOR;
    
    
    PROCEDURE SP_DISTRIBUIDOR_GESTION(P_IDINVERSION NUMBER, P_CLIENTE VARCHAR) AS
        V_CONTADOR NUMBER;
    BEGIN 
        -- SI EXISTE ALGUN PDV QUE NO HAYA SIDO GESTIONADO POR EL DISTRIBUIDOR NO HACE NADA
        SELECT COUNT(1) INTO  V_CONTADOR FROM VT_ICOM_CLIENTE_PDV cli_pdv 
        WHERE IDINVERSION = P_IDINVERSION AND CODIGODISTRIBUIDOR = P_CLIENTE
        AND CONTRATOAPROBAR = 1;

        IF (V_CONTADOR=0) THEN 
            -- SI TODOS LOS PDV FUERON GESTIONADOS CAMBIAR ESTADOS
            UPDATE t_icom_inversion_cliente_G SET ESTADO=2, NEGOCIACION=3
            where IDINVERSION=P_IDINVERSION AND CODIGOGRUPO=P_CLIENTE;

        END IF;

    END SP_DISTRIBUIDOR_GESTION;


    /*Procedimiento que envÃ­a correo electrÃ³nico a cliente de contrato
      @param P_IDCONTRATO  	 id del contrato (tabla T_ICOM_CONTRATOS)
      @param P_TIPOINVERSION Tipo de inversion
      @param P_IDINVERSION   CÃ³digo de Inversion 
      @param P_CODIGOCLIENTE CÃ³digo Cliente SI ES NULL ENVIA A VARIOS, CASO CONTRATIO ENVIA A UN SOLO CLIENTE
    Autor: CCarrasco (NETBY)
    Fecha: Agosto 2022
    */   
    PROCEDURE SP_CONTRATO_ENVIAR (P_IDINVERSION VARCHAR, P_CODIGOCLIENTE VARCHAR2 DEFAULT NULL, 
                                  P_CODIGOPDV VARCHAR2 DEFAULT NULL, P_TIPOCONTRATO NUMBER, P_USUARIO VARCHAR2 ) AS
    
    v_etapa  NUMBER;
    v_contadorNegociacion NUMBER;
    v_urlServidor VARCHAR2(100);
    v_correoContacto varchar2(100);
    v_link 					varchar2(500);
    v_contenido				number;
    v_hash					varchar2(1000);
    v_mensaje				varchar2(5000);
    v_asunto                 VARCHAR2(100);
    v_nombre					varchar2(200);
    v_nombreComercial        VARCHAR2(100);
    v_correo_notificacion	varchar2(200);
    v_inversion  			t_icom_inversiones.id%type;
    v_idcontrato             NUMBER;
    v_idTipoContrato         NUMBER;
    v_tipoContrato           DATA."T_CORP_UDC".DESCRIPCION%TYPE;
    v_fechainicio			DATE;
    v_fechafin				DATE;
    v_tipoInversionNombre    VARCHAR2(100);
    v_correos				VARCHAR2(1000);
    V_CONTRATOREPRESENTANTE  DATA.T_ICOM_INVERSION_CLIENTE_G.CONTRATOREPRESENTANTE%TYPE;
    V_CONTRATOCORREO			DATA.T_ICOM_INVERSION_CLIENTE_G.CONTRATOCORREO%TYPE;
    v_nombreDistribuidor     VARCHAR2(200);
    v_compania 					varchar2(5);
    v_contrato_notificacion    NUMBER;
    
    v_contenido_notificacion CLOB;
    
    v_correos_copia				VARCHAR2(1000);
   
    BEGIN

        SELECT max(compania)
		INTO v_compania
		FROM DATA.T_ICOM_INVERSIONES I
		WHERE ID = P_IDINVERSION
        AND ROWNUM=1;

        v_correoContacto:=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '5', v_compania );
        
--         SELECT VALOR
--         INTO v_contrato_notificacion
--         FROM DATA.T_CORP_UDC WHERE ID_CABECERA LIKE 'ICOM_PARAM' AND VALOR2 LIKE 'CONTRATO_NOTIFICACIONES';

        v_contrato_notificacion := PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '35', V_COMPANIA);
        
        SELECT DOMINIO || RUTAMODULO INTO v_urlServidor FROM DATA.T_ADMI_MODULO WHERE CODIGO = 'ICOM';
        
        SELECT FECHAINICIO , FECHAFIN , INVERSIONTIPO, IDETAPA
        INTO v_fechainicio, v_fechafin, v_tipoInversionNombre, v_etapa
        FROM DATA.VT_ICOM_INVERSIONES  
        WHERE ID = P_IDINVERSION;  --IDETAPA in (2,5,6) AND 

        begin
            v_tipoContrato:=PK_ICOM_COMMONS.f_traervalorudc('TIPOCONTRA', NULL, null,'DESCRIPCION', P_TIPOCONTRATO,'1');
        exception when no_Data_found then
            v_tipoContrato := 'No hay tipo contrato';
        end ;
        
        v_correo_notificacion:=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '17', v_compania);
        
        DBMS_OUTPUT.PUT_LINE ( 'tipo contrato    : '||P_TIPOCONTRATO );
        
        IF P_TIPOCONTRATO = 1  THEN 
            
            FOR clientes IN (SELECT CODIGOGRUPO FROM DATA.T_ICOM_INVERSION_CLIENTE_G WHERE ESTADO IN (0,1) AND NEGOCIACION=0 
                AND IDINVERSION = P_IDINVERSION  AND ((P_CODIGOCLIENTE IS NOT NULL AND CODIGOGRUPO=P_CODIGOCLIENTE OR
                 P_CODIGOCLIENTE IS NULL)  AND  CODIGOGRUPO IN (SELECT DISTINCT CODIGOGRUPO FROM DATA.T_ICOM_CONTRATO_CONTENIDO 
                                WHERE IDINVERSION = P_IDINVERSION ))--  AND (CONTRATOCORREO IS NOT NULL OR CONTRATOCORREO <> '') 
                      )
            LOOP
                BEGIN 
                    SELECT NVL(NOMBRES,'NOMBRE ESTABLECIMIENTO'), NVL(NOMBRES ,'NOMBRE PRUEBA COMERCIAL'), CONTRATOCORREO  
                    INTO v_nombre, v_nombreComercial, v_correos FROM DATA.T_ICOM_INVERSION_CLIENTE_G 
                    WHERE IDINVERSION = P_IDINVERSION AND CODIGOGRUPO = clientes.CODIGOGRUPO;
                    
                    IF(v_correos IS NULL) THEN 
                         raise_application_error(-20000,'InformaciÃ³n incompleta para el envio de correo');
                    END IF;
                  
                    SELECT PK_ICOM_CONTRATO.F_OBTENER_IDCONTRATO(P_IDINVERSION , clientes.CODIGOGRUPO , P_CODIGOPDV , P_TIPOCONTRATO ) INTO v_idcontrato FROM DUAL;

                    v_link := APEX_UTIL.PREPARE_URL(p_url => v_urlServidor || ':314:::NO:314:P314_HASH:' ||
                    DATA.PK_COMMONS.F_ENCRYPT('P314_ID,P314_IDINVERSION,P314_TIPOCONTRATO,P314_CODCLIENTE,P314_CODPDV:'
                    ||v_idcontrato||',' ||P_IDINVERSION || ',' || P_TIPOCONTRATO || ',' || clientes.CODIGOGRUPO || ', ' ||NULL) ) ;
                    DBMS_OUTPUT.PUT_LINE ( 'v_link  : ' || v_link );

                EXCEPTION WHEN NO_DATA_FOUND THEN
                    RAISE_APPLICATION_ERROR(-20000, 'Error en la busqueda de datos');
                    v_fechainicio:=NULL;
                    v_fechafin:=NULL;
                    v_nombre := ' ';
                    v_nombreComercial := ' ';
                    v_tipoInversionNombre := ' ';
                    v_link:= ' ';
                END;	
                --  PEDIENTE FORMATO APROBACIÃ“N CONTRATOS (PLANES) 
                v_asunto := 'Solicitud de firma Acuerdo Comercial Zaimella';
                
                v_mensaje := '<p>Estimado cliente <strong>' || UPPER(v_nombre) ||'</strong></p>
                                <p>&nbsp;</p>
                                <p>El Acuerdo Comercial <strong>' || TO_CHAR(SYSDATE, 'RRRR') || '</strong> est&aacute; listo para ser firmado. Solo debe hacer clic en el siguiente link <a href = "'|| v_link ||'"> Presione aqu&iacute; </a> 
                                y seguir las siguientes instrucciones:</p>
                                <ol>
                                <li>Revise el Acuerdo y los datos que se incluyen (Per&iacute;odo, metas, condiciones particulares)</li>
                                <li>Seleccione el casillero He leÃ­do y acepto los tÃ©rminos y condiciones de uso y de clic en ACEPTAR</li>
                                </ol>
                                <p>Cualquier duda o consulta relacionada a esta comunicaci&oacute;n cont&aacute;ctenos al correo <a href="mailto:'|| v_correoContacto||'">'|| v_correoContacto ||'</a></p>
                                <p>&nbsp;</p>
                                <p>Atentamente,</p>
                                <p>&nbsp;</p>
                                <p>ZAIMELLA DEL ECUADOR S.A.</p>';
                DBMS_OUTPUT.PUT_LINE ( 'Correo ' || v_asunto );
                PK_CORP_CORREO.SP_ENVIO(
                        P_MODULO => 'ICOM',
                        P_TO =>v_correos,
                        P_FROM => 'infocomercial@zaimella.com',
                        P_SUBJECT => v_asunto,
                        P_BODY => v_mensaje
                      );
                      
                UPDATE T_ICOM_INVERSION_CLIENTE_G
                SET ESTADO = 1      WHERE IDINVERSION =  P_IDINVERSION
                AND CODIGOGRUPO = clientes.CODIGOGRUPO;
                
                DATA.PK_ICOM_CONTRATO.SP_CONTRATOAUDITORIA(
                    P_IDINVERSION => P_IDINVERSION,
                    P_CODIGOGRUPO => clientes.CODIGOGRUPO,
                    P_CODIGOPDV => null,
                    P_IDCONTRATO => v_idcontrato,
                    P_USUARIO => P_USUARIO,
                    P_TIPOCONTRATO => P_TIPOCONTRATO,
                    P_COMENTARIO => null,
                    P_AUDITORIATIPO => 3
                ); 
                DBMS_OUTPUT.PUT_LINE ( 'Auditoria ' );
                --Se envia la notificaciÃ³n de solicitud de firma de contrato
                v_asunto := 'Notificacion envio de contrato';
                
                v_mensaje := '<p><strong> Notificaci&oacute;n env&iacute;o de contrato ' || UPPER(v_tipoContrato) ||'</strong></p>
                                <p>&nbsp;</p>
                                <p>Estimado Usuario</p>
                                <p>&nbsp;</p>
                                <p>Ha sido enviado el correo de notificaci&oacute;n para la solicitud de firma de '||v_tipoInversionNombre||'
                                con el documento legal '||UPPER(v_tipoContrato) ||'del per&iacute;odo: '||to_char(v_fechainicio,'dd/mm/yyyy')||' al 
                                '||to_char(v_fechafin,'dd/mm/yyyy')||' numero de ID '||P_IDINVERSION||' 
                                del cliente '||clientes.CODIGOGRUPO||'-'||UPPER(v_nombre)||'. </p>
                                <p>&nbsp;</p>
                                <p>Atentamente,</p>
                                <p>&nbsp;</p>
                                <p>ZAIMELLA DEL ECUADOR S.A.</p>';
                
                PK_CORP_CORREO.SP_ENVIO(
                        P_MODULO => 'ICOM',
                        P_TO => v_correo_notificacion,
                        P_FROM => 'infocomercial@zaimella.com',
                        P_SUBJECT => v_asunto,
                        P_BODY => v_mensaje
                      );
                DBMS_OUTPUT.PUT_LINE ( 'Correo ' || v_asunto );      
            END LOOP;
        /* VALIDACION DE TIPO DE CONTRATO  2 - PUNTO DE VENTA*/
        ELSIF P_TIPOCONTRATO = 2  THEN 

                /* ENVIO MASIVO DE CONTRATOS PUNTO DE VENTA */
                /* ENVIO UNICO DE CONTRATOS PUNTO DE VENTA*/
                
                FOR pdv IN (SELECT CODIGOPDV  FROM DATA.T_ICOM_CLIENTE_PDV  WHERE CONTRATOAPROBAR = 3 
                            AND IDINVERSION = P_IDINVERSION 
                            AND ((P_CODIGOPDV IS NOT NULL AND CODIGOPDV =  P_CODIGOPDV ) OR ( IDINVERSION = P_IDINVERSION AND P_CODIGOPDV IS NULL  ) )
                            AND (CODIGOPDV IN (SELECT CODIGOPDV FROM DATA.T_ICOM_CONTRATO_CONTENIDO WHERE IDINVERSION = P_IDINVERSION) OR v_contrato_notificacion = 0)) --SI ESTAN CONFIGURADO LAS NOTIFICACIONES (0) NO SE VALIDA CONTENIDO
                    LOOP
                        BEGIN 
                            DBMS_OUTPUT.PUT_LINE ( 'pdv.CODIGOPDV  : ' || pdv.CODIGOPDV );
                            SELECT RAZONSOCIAL AS NOMBRE, RAZONSOCIAL AS NOMBRECOMERCIAL, CORREO
                            INTO v_nombre, v_nombreComercial, v_correos
                            FROM DATA.VT_TRAD_CLIENTE 
                            WHERE CODIGOPDV = pdv.CODIGOPDV;
                            
                            SELECT DISTRIBUIDOR INTO  v_nombreDistribuidor
                            FROM VT_ICOM_CLIENTE_PDV
                            WHERE IDINVERSION = P_IDINVERSION
                            AND CODIGOPDV = pdv.CODIGOPDV;

                            SELECT PK_ICOM_CONTRATO.F_OBTENER_IDCONTRATO(P_IDINVERSION , P_CODIGOCLIENTE , pdv.CODIGOPDV , P_TIPOCONTRATO ) INTO v_idcontrato FROM DUAL;

                        EXCEPTION WHEN NO_DATA_FOUND THEN 
                            RAISE_APPLICATION_ERROR(-20000, 'Error en la busqueda de datos');
                        END;
                        
                        -- 1 = CONTRATO, 0 NOTIFICACION CONTRATO
                        IF v_contrato_notificacion = 1 THEN
                        
                            IF v_correos IS NOT NULL THEN 
                                --  PEDIENTE FORMATO APROBACIÃ“N CONVENIOS PDVC
                                v_link := APEX_UTIL.PREPARE_URL(p_url => v_urlServidor || ':314:::NO:314:P314_HASH:' || DATA.PK_COMMONS.F_ENCRYPT('P314_ID,P314_IDINVERSION,P314_TIPOCONTRATO,P314_CODCLIENTE,P314_CODPDV:'||v_idcontrato||',' ||P_IDINVERSION || ',' || P_TIPOCONTRATO || ',' || NULL || ',' ||pdv.CODIGOPDV) ) ;
                                DBMS_OUTPUT.PUT_LINE ( 'v_link  : ' || v_link );
                                v_asunto := 'Solicitud de firma Convenio de Crecimiento Zaimella';
                                -- v_mensaje := '<table style="height: 171px; width: 122.159%;" border="0"><tbody><tr style="height: 18px;"><td style="width: 33.3333%; height: 18px;">;</td><td style="width: 33.3333%; height: 18px;">;</td><td style="width: 33.3333%; height: 18px;">Quito, '|| SYSDATE ||'</td></tr><tr style="height: 18px;"><td style="width: 33.3333%; height: 18px;" colspan="3">;</td></tr><tr style="height: 18px;"><td style="width: 33.3333%; height: 27px;" colspan="3"><p>Estimado(a),</p><p>' || UPPER(v_nombre) || '</p><p>' || UPPER(v_nombreComercial) || '</p></td></tr><tr style="height: 18px;"><td style="width: 33.3333%; height: 18px;" colspan="3">;</td></tr><tr style="height: 18px;"><td style="width: 33.3333%; height: 18px;" colspan="3"><p>La Empresa Zaimella del Ecuador S.A., ha emitido el siguiente contrato por ' || v_tipoInversionNombre ||' para el per;odo ' || v_fechainicio || ' - ' || v_fechafin || '.</p><p>Para lo cual solicitamos ingresar en el siguiente link: <a href= ">' || v_link || '"> Presione aquÃ­</a> para gestionar su aceptaci;n ha dicho contrato.</p><p>Cualquier duda o consulta relacionada a esta comunicaci;n, por favor comunicarse al correo electr;nico <strong>' || v_correoContacto || '</strong></p><p>Saludos Cordiales,</p></td></tr><tr style="height: 18px;"><td style="width: 33.3333%; height: 18px;" colspan="3">;</td></tr><tr style="height: 18px;"><td style="width: 33.3333%; height: 18px;" colspan="3"><strong>ZAIMELLA DEL ECUADOR S.A.</strong></td></tr></tbody></table>';
                                v_mensaje := '<p>Estimado cliente <strong>'|| v_nombreComercial || '</strong></p>
                                                    <p>&nbsp;</p>
                                                    <p>La empresa Zaimella del Ecuador S.A. en conjunto con su Distribuidor <strong>' || v_nombreDistribuidor ||' </strong>ha emitido el siguiente contrato por <strong>' || v_tipoInversionNombre ||'</strong> para el per&iacute;odo <strong>'|| v_fechainicio || ' - ' || v_fechafin ||'</strong>.</p>
                                                    <p>Debe hacer clic en el link <a href ="'|| v_link ||'">Presione aqu&iacute;</a> y seguir las siguientes instrucciones:</p>
                                                    <p>&nbsp;</p>
                                                    <ol>
                                                        <li>Revise el convenio y datos que se incluyen (Per&iacute;odo, metas, condiciones particulares)</li>
                                                        <li>En caso de estar de acuerdo con la informaci&oacute;n hacer clic en el bot&oacute;n ACEPTAR</li>
                                                    </ol>
                                                    <p>&nbsp;</p>
                                                    <p>Cualquier duda o consulta relacionada a esta comunicaci&oacute;n cont&aacute;ctenos al correo <a href="mailto:'|| v_correoContacto || '">' || v_correoContacto ||'</a></p>
                                                    <p>&nbsp;</p>
                                                    <p>Atentamente,</p>
                                                    <p>&nbsp;</p>
                                                    <p>ZAIMELLA DEL ECUADOR S.A.</p>';
                                                    
                                PK_CORP_CORREO.SP_ENVIO(
                                        P_MODULO => 'ICOM',
                                        P_TO => v_correos,
                                        P_FROM => 'infocomercial@zaimella.com',
                                        P_SUBJECT => v_asunto,
                                        P_BODY => v_mensaje
                                      );
                               
                               DATA.PK_ICOM_CONTRATO.SP_CONTRATOAUDITORIA(
                                    P_IDINVERSION => P_IDINVERSION,
                                    P_CODIGOGRUPO => null,
                                    P_CODIGOPDV => pdv.codigopdv,
                                    P_IDCONTRATO => v_idcontrato,
                                    P_USUARIO => P_USUARIO,
                                    P_TIPOCONTRATO => P_TIPOCONTRATO,
                                    P_COMENTARIO => null,
                                    P_AUDITORIATIPO => 3
                               ); 
                               --Se envia la notificaciÃ³n de solicitud de firma de contrato
                                v_asunto := 'Notificacion envio de contrato';
                                
                                v_mensaje := '<p><strong> Notificaci&oacute;n env&iacute;o de contrato ' || UPPER(v_tipoContrato) ||'</strong></p>
                                                <p>&nbsp;</p>
                                                <p>Estimado Usuario</p>
                                                <p>&nbsp;</p>
                                                <p>Ha sido enviado el correo de notificaci&oacute;n para la solicitud de firma de '||v_tipoInversionNombre||'
                                                con el documento legal '||UPPER(v_tipoContrato) ||'del per&iacute;odo: '||to_char(v_fechainicio,'dd/mm/yyyy')||' al 
                                                '||to_char(v_fechafin,'dd/mm/yyyy')||' numero de ID '||P_IDINVERSION||' 
                                                del punto de venta '||pdv.codigopdv||'-'||UPPER(v_nombreComercial)||'. </p>
                                                <p>&nbsp;</p>
                                                <p>Atentamente,</p>
                                                <p>&nbsp;</p>
                                                <p>ZAIMELLA DEL ECUADOR S.A.</p>';
                                
                                PK_CORP_CORREO.SP_ENVIO(
                                        P_MODULO => 'ICOM',
                                        P_TO => v_correo_notificacion,
                                        P_FROM => 'infocomercial@zaimella.com',
                                        P_SUBJECT => v_asunto,
                                        P_BODY => v_mensaje
                                      );       
                                
                            END IF;
                              
                        ELSIF v_contrato_notificacion = 0 THEN
                        
                            IF v_correos IS NOT NULL THEN
                            
                                v_contenido_notificacion := PK_ICOM_CONTRATO.F_REEMPLAZO_CONVENIO_PLANTILLA(
                                    P_IDINVERSION => P_IDINVERSION,
                                    P_CODIGOPDV => pdv.codigopdv,
                                    P_TIPO => 1,
                                    P_COMPANIA=>v_compania);
                                                            
                                v_asunto := 'NotificaciÃ³n de participaciÃ³n';
                                
                               -- data.pk_commons.sp_apex_correohtml(v_asunto,v_asunto);
                                
                                v_correos_copia := PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '37', v_compania );
                                
                                v_correos := v_correos||','||v_correos_copia ;
                            
                                PK_CORP_CORREO.SP_ENVIO(
                                            P_MODULO => 'ICOM',
                                            P_TO => v_correos, --antes v_correo_notificacion
                                            P_FROM => 'infocomercial@zaimella.com',
                                            P_SUBJECT => v_asunto,
                                            P_BODY => v_contenido_notificacion
                                          );  
                                          
                                PK_ICOM_CONTRATO.SP_CONTRATO_ACEPTAR(
                                    P_IDINVERSION => P_IDINVERSION,
                                    P_CODIGOCLIENTE => P_CODIGOCLIENTE,
                                    P_CODIGOPDV => pdv.codigopdv,
                                    P_ACEPTA => 1,
                                    P_TIPOCONTRATO => P_TIPOCONTRATO, 
                                    P_USUARIO => P_USUARIO
                                );
                            END IF;
                            
                        END IF;  
                    END LOOP;
        --ADEDUM 
        ELSIF P_TIPOCONTRATO = 3  THEN 
            FOR clientes IN (SELECT G.CODIGOGRUPO FROM DATA.T_ICOM_INVERSION_CLIENTE_G G
                                INNER JOIN DATA.T_ICOM_INVERSIONES I ON (G.IDINVERSION = I.ID AND I.ESTADO = 3)
                             WHERE G.NEGOCIACION in (1,3) 
                             AND G.IDINVERSION = P_IDINVERSION
                             )
            LOOP
                   BEGIN 
                        
                        SELECT NVL(NOMBRES,'NOMBRE ESTABLECIMIENTO'), NVL(NOMBRES ,'NOMBRE PRUEBA COMERCIAL'), CONTRATOCORREO  
                        INTO v_nombre, v_nombreComercial, v_correos 
                        FROM DATA.T_ICOM_INVERSION_CLIENTE_G 
                        WHERE IDINVERSION = P_IDINVERSION 
                        AND CODIGOGRUPO = clientes.CODIGOGRUPO;

                        SELECT PK_ICOM_CONTRATO.F_OBTENER_IDCONTRATO(P_IDINVERSION , clientes.CODIGOGRUPO , P_CODIGOPDV , P_TIPOCONTRATO ) INTO v_idcontrato FROM DUAL;
                        --DBMS_OUTPUT.PUT_LINE ( 'v_link  : ' || v_urlServidor || ':314:::NO:314:P314_HASH:' || 'P314_ID,P314_IDINVERSION,P314_TIPOCONTRATO,P314_CODCLIENTE,P314_CODPDV:'||v_idcontrato||',' ||P_IDINVERSION || ',' || v_idTipoContrato || ',' || clientes.CODIGOGRUPO || ', ' ||NULL );
                        v_link := APEX_UTIL.PREPARE_URL(p_url => v_urlServidor || ':314:::NO:314:P314_HASH:' || DATA.PK_COMMONS.F_ENCRYPT('P314_ID,P314_IDINVERSION,P314_TIPOCONTRATO,P314_CODCLIENTE,P314_CODPDV:'||v_idcontrato||',' ||P_IDINVERSION || ',' || P_TIPOCONTRATO || ',' || clientes.CODIGOGRUPO || ', ' ||NULL) ) ;
                        DBMS_OUTPUT.PUT_LINE ( 'v_link  : '|| v_link );
                        v_correoContacto:=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '5',V_COMPANIA );
                    EXCEPTION WHEN NO_DATA_FOUND THEN
                        RAISE_APPLICATION_ERROR(-20000, 'Error en la busqueda de datos');
                    END;	
                    -- PENDIENTE FORMATO APROBACIÃ“N ADENDUM 
                    v_asunto := 'Solicitud de firma Adendum Plan Comercial';
                    --- v_mensaje := '<table style="height: 171px; width: 122.159%;" border="0"><tbody><tr style="height: 18px;"><td style="width: 33.3333%; height: 18px;">;</td><td style="width: 33.3333%; height: 18px;">;</td><td style="width: 33.3333%; height: 18px;">Quito, '|| SYSDATE ||'</td></tr><tr style="height: 18px;"><td style="width: 33.3333%; height: 18px;" colspan="3">;</td></tr><tr style="height: 18px;"><td style="width: 33.3333%; height: 27px;" colspan="3"><p>Estimado(a),</p><p>' || UPPER(v_nombre) || '</p><p>' || UPPER(v_nombreComercial) || '</p></td></tr><tr style="height: 18px;"><td style="width: 33.3333%; height: 18px;" colspan="3">;</td></tr><tr style="height: 18px;"><td style="width: 33.3333%; height: 18px;" colspan="3"><p>La Empresa Zaimella del Ecuador S.A., ha emitido el siguiente contrato por ' || v_tipoInversionNombre ||' para el per;odo ' || v_fechainicio || ' - ' || v_fechafin || '.</p><p>Para lo cual solicitamos ingresar en el siguiente link: <a href= ">' || v_link || '"> Presione aquÃ­</a> para gestionar su aceptaci;n ha dicho contrato.</p><p>Cualquier duda o consulta relacionada a esta comunicaci;n, por favor comunicarse al correo electr;nico <strong>' || v_correoContacto || '</strong></p><p>Saludos Cordiales,</p></td></tr><tr style="height: 18px;"><td style="width: 33.3333%; height: 18px;" colspan="3">;</td></tr><tr style="height: 18px;"><td style="width: 33.3333%; height: 18px;" colspan="3"><strong>ZAIMELLA DEL ECUADOR S.A.</strong></td></tr></tbody></table>';
                    v_mensaje := '<p>Estimado <strong>' || UPPER(v_nombre) || '</strong></p>
                                    <p>&nbsp;</p>
                                    <p>Ha sido emitido el Adendum a su Acuerdo Comercial <strong>'
                                    || TO_CHAR(SYSDATE , 'RRRR') ||'</strong>, y est&aacute; listo para ser firmado. Solo debe hacer clic en el link  <a href ="'
                                    || v_link || '">Presione aqu&iacute;</a> y seguir las siguientes instrucciones:</p>
                                    <p>&nbsp;</p>
                                    <ol>
                                    <li>Revise el documento y los datos que incluyen los periodos pagados.</li>
                                    <li>Seleccione el casillero He leÃ­do y acepto los tÃ©rminos y condiciones de uso y de clic en ACEPTAR</li>
                                    </ol>
                                    <p>&nbsp;</p>
                                    <p>Cualquier duda o consulta relacionada a esta comunicaci&oacute;n cont&aacute;ctenos al correo <a href="mailto:'|| v_correoContacto || '">'|| v_correoContacto || '</a></p>
                                    <p>&nbsp;</p>
                                    <p>Atentamente,</p>
                                    <p>&nbsp;</p>
                                    <p>ZAIMELLA DEL ECUADOR S.A.</p>';
                    PK_CORP_CORREO.SP_ENVIO(
                            P_MODULO => 'ICOM',
                            P_TO => v_correos,
                            P_FROM => 'infocomercial@zaimella.com',
                            P_SUBJECT => v_asunto,
                            P_BODY => v_mensaje
                          );
                
                    DATA.PK_ICOM_CONTRATO.SP_CONTRATOAUDITORIA(
                                P_IDINVERSION => P_IDINVERSION,
                                P_CODIGOGRUPO => clientes.CODIGOGRUPO,
                                P_CODIGOPDV => null,
                                P_IDCONTRATO => v_idcontrato,
                                P_USUARIO => P_USUARIO,
                                P_TIPOCONTRATO => P_TIPOCONTRATO,
                                P_COMENTARIO => null,
                                P_AUDITORIATIPO => 3
                           );       
                --Se envia la notificaciÃ³n de solicitud de firma de contrato
                v_asunto := 'Notificacion envio de contrato';
                
                v_mensaje := '<p><strong> Notificaci&oacute;n env&iacute;o de contrato ' || UPPER(v_tipoContrato) ||'</strong></p>
                                <p>&nbsp;</p>
                                <p>Estimado Usuario</p>
                                <p>&nbsp;</p>
                                <p>Ha sido enviado el correo de notificaci&oacute;n para la solicitud de firma de '||v_tipoInversionNombre||'
                                con el documento legal '||UPPER(v_tipoContrato) ||'del per&iacute;odo: '||to_char(v_fechainicio,'dd/mm/yyyy')||' al 
                                '||to_char(v_fechafin,'dd/mm/yyyy')||' numero de ID '||P_IDINVERSION||' 
                                del cliente '||clientes.CODIGOGRUPO||'-'||UPPER(v_nombre)||'. </p>
                                <p>&nbsp;</p>
                                <p>Atentamente,</p>
                                <p>&nbsp;</p>
                                <p>ZAIMELLA DEL ECUADOR S.A.</p>';
                
                PK_CORP_CORREO.SP_ENVIO(
                        P_MODULO => 'ICOM',
                        P_TO => v_correo_notificacion,
                        P_FROM => 'infocomercial@zaimella.com',
                        P_SUBJECT => v_asunto,
                        P_BODY => v_mensaje
                      );
            END LOOP; 
        --CLAUSURA    
        ELSIF P_TIPOCONTRATO = 4  THEN 
            -- SELECCIONAR TODOS LOS PUNTOS QUE FUERON APROBADAS LA CLAUSURA

            v_correo_notificacion:=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '18', v_compania );
            
            FOR punto IN (SELECT CODIGOPDV FROM DATA.T_ICOM_CLIENTE_PDV 
            WHERE IDINVERSION = P_IDINVERSION AND (CODIGOPDV=P_CODIGOPDV or P_CODIGOPDV is null) 
            and CONTRATOCLAUSURA in (1,2,3) )
            LOOP
                -- ACTUALIZA EL ESTADO DE CLAUSURA FECHA POR PUNTO
                UPDATE DATA.T_ICOM_CLIENTE_PDV 
                SET CONTRATOCLAUSURA = 1, CLAUSURAFECHA = SYSDATE
                WHERE IDINVERSION = P_IDINVERSION  AND CODIGOPDV = punto.CODIGOPDV ;
                
                -- COMPRUEBA QUE LA EJECUCION SEA EXITOSA Y SE ACTUALICE AL MENOS 1 REGISTRO DE LA ACTUALIZACION ANTERIOR
                IF SQL%ROWCOUNT > 0 THEN
                

                      SELECT NVL(RAZONSOCIAL,'NOMBRE ESTABLECIMIENTO'), NVL(RAZONSOCIAL,'NOMBRE PRUEBA COMERCIAL'), CORREO  
                        INTO v_nombre, v_nombreComercial, v_correos FROM DATA.VT_ICOM_CLIENTE_PDV 
                        WHERE IDINVERSION = P_IDINVERSION AND CODIGOPDV = punto.CODIGOPDV;
                        
                    IF v_contrato_notificacion = 1 THEN
                    
                        SELECT DOMINIO || RUTAMODULO INTO v_urlServidor FROM DATA.T_ADMI_MODULO WHERE CODIGO = 'ICOM';
                        SELECT DATA.PK_ICOM_CONTRATO.F_OBTENER_IDCONTRATO(P_IDINVERSION => P_IDINVERSION, 
                               P_CODIGOGRUPO => NULL , P_CODIGOPDV => punto.CODIGOPDV , P_TIPOCONTRATO=> 4 ) 
                        INTO v_idcontrato FROM DUAL;
                        
                        v_link := APEX_UTIL.PREPARE_URL(p_url => v_urlServidor || ':314:::NO:314:P314_HASH:' || DATA.PK_COMMONS.F_ENCRYPT('P314_ID,P314_IDINVERSION,P314_TIPOCONTRATO,P314_CODCLIENTE,P314_CODPDV:'||v_idcontrato||',' ||P_IDINVERSION || ',' || 4 || ',' || NULL || ',' ||punto.CODIGOPDV) ) ; 
                        
                        v_correoContacto :=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '5', v_compania );
                    
                        IF v_correos IS NULL THEN
                            v_correos:=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '7', v_compania );
                            --v_tipoCorreo := 2;  -- CORREO DE NOTIFICACION DE FALTA DE INFORMACION
                            v_asunto := 'NotificaciÃ³n de informaciÃ³n de cliente';
                            v_mensaje := '<table style="height: 140px; width: 667px;"><thead><tr style="height: 18px;"><td style="height: 18px; width: 657px; text-align: right;" colspan="3">Quito, ' || TO_CHAR(SYSDATE, 'DD-MM-YYYY') ||'</td></tr></thead><tbody><tr style="height: 24px;"><td style="height: 24px; width: 657px;" colspan="3">&nbsp;</td></tr><tr style="height: 22px;"><td style="height: 22px; width: 229.344px;" colspan="3"><p> Se notifica que el cliente  <strong>' || v_nombre || '</strong> no pudo ser notificado por el sistema debido a la falta de informaci&oacute;n correspondiente al correo electr&oacute;nico, por lo que solicitamos se ingrese dicha informaciÃ³n.</p><p>Saludos Cordiales,</p></td></tr></tbody></table><p><strong>&nbsp;</strong></p><p><strong>ZAIMELLA DEL ECUADOR S.A.</strong></p>';
                        ELSE 
                            --v_tipoCorreo := 1;  -- CORREO DE NOTIFICACION DE FINIQUITO CLIENTE
                            v_asunto := 'NotificaciÃ³n de finiquito';
                            v_mensaje := '<p>Estimado Cliente <strong>'|| UPPER(v_nombreComercial) ||'</strong></p>
                                            <p>&nbsp;</p>
                                            <p>Ha sido emitido el FINIQUITO al CONVENIO que firm&oacute; 
                                            con Zaimella y su distribuidor para el <strong>'|| TO_CHAR(SYSDATE, 'RRRR') ||
                                            '</strong>. Solo debe hacer clic en el link <a href = "'||v_link||'">Presione aqu&iacute;</a> y seguir las siguientes instrucciones:</p>
                                            <p>&nbsp;</p>
                                            <ol>
                                            <li>Revise el documento y los datos que incluyen los periodos pagados.</li>
                                            <li>Seleccione el casillero: He leÃ­do y acepto los tÃ©rminos y condiciones de uso y de clic en ACEPTAR</li>
                                            </ol>
                                            <p>&nbsp;</p>
                                            <p>Cualquier duda o consulta relacionada a esta comunicaci&oacute;n cont&aacute;ctenos al correo <a href="mailto:'|| v_correoContacto|| '">'|| v_correoContacto|| '</a></p>
                                            <p>&nbsp;</p>
                                            <p>Atentamente,</p>
                                            <p>&nbsp;</p>
                                            <p>ZAIMELLA DEL ECUADOR S.A.</p>';
                        
                        END IF;                                 
                        
                        -- ASIGNA VALORES GENERALES DE ENVIO DE CORREO
                        -- COMPRUEBA EL TIPO DE CORREO PARA ASIGNARL EL MENSAJE
                        
                        data.pk_commons.sp_apex_correohtml(v_mensaje,v_mensaje);    -- Permite sustituir carÃ¡cteres especiales/acentos.
                        
                        DATA.PK_CORP_CORREO.SP_ENVIO(
                            P_MODULO => 'ICOM',
                            P_TO => v_correos,
                            P_FROM => 'infocomercial@zaimella.com',
                            P_SUBJECT => v_asunto,
                            P_BODY => v_mensaje
                        );
                        
                        DATA.PK_ICOM_CONTRATO.SP_CONTRATOAUDITORIA(
                                    P_IDINVERSION => P_IDINVERSION,
                                    P_CODIGOGRUPO => null,
                                    P_CODIGOPDV => punto.CODIGOPDV,
                                    P_IDCONTRATO => v_idcontrato,
                                    P_USUARIO => P_USUARIO,
                                    P_TIPOCONTRATO => P_TIPOCONTRATO,
                                    P_COMENTARIO => null,
                                    P_AUDITORIATIPO => 3
                               );
                    ELSE 
                        IF v_correos IS NULL THEN
                            v_correos:=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '7', v_compania );
                            --v_tipoCorreo := 2;  -- CORREO DE NOTIFICACION DE FALTA DE INFORMACION
                            v_asunto := 'NotificaciÃ³n de informaciÃ³n de cliente';
                            v_mensaje := '<table style="height: 140px; width: 667px;"><thead><tr style="height: 18px;"><td style="height: 18px; width: 657px; text-align: right;" colspan="3">Quito, ' 
                            || TO_CHAR(SYSDATE, 'DD-MM-YYYY') ||'</td></tr></thead><tbody><tr style="height: 24px;"><td style="height: 24px; width: 657px;" colspan="3">&nbsp;</td></tr><tr style="height: 22px;"><td style="height: 22px; width: 229.344px;" colspan="3">
                            <p> Se notifica que el cliente  <strong>' || v_nombre || '</strong> no pudo ser notificado por el sistema debido a la falta de informaci&oacute;n correspondiente al correo electr&oacute;nico, por lo que solicitamos se ingrese dicha informaciÃ³n.</p><p>Saludos Cordiales,</p></td></tr></tbody></table><p><strong>&nbsp;</strong></p><p><strong>ZAIMELLA DEL ECUADOR S.A.</strong></p>';
                            
                            PK_CORP_CORREO.SP_ENVIO(
                                        P_MODULO => 'ICOM',
                                        P_TO => v_correos,
                                        P_FROM => 'infocomercial@zaimella.com',
                                        P_SUBJECT => v_asunto,
                                        P_BODY => v_mensaje
                                      ); 
                        ELSE 
                            v_contenido_notificacion := PK_ICOM_CONTRATO.F_REEMPLAZO_CONVENIO_PLANTILLA(
                                P_IDINVERSION => P_IDINVERSION,
                                P_CODIGOPDV => punto.codigopdv,
                                P_TIPO => 2,
                                P_COMPANIA=>v_compania);
                                
                            v_asunto := 'NotificaciÃ³n de finalizaciÃ³n';
                            
                            v_correos_copia := PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '37', v_compania );
                                
                            v_correos := v_correos||','||v_correos_copia;
                            
                            PK_CORP_CORREO.SP_ENVIO(
                                        P_MODULO => 'ICOM',
                                        P_TO => v_correos,
                                        P_FROM => 'infocomercial@zaimella.com',
                                        P_SUBJECT => v_asunto,
                                        P_BODY => v_contenido_notificacion
                                      ); 
                            
                            PK_ICOM_CONTRATO.SP_CONTRATO_ACEPTAR(
                                P_IDINVERSION => P_IDINVERSION,
                                P_CODIGOCLIENTE => P_CODIGOCLIENTE,
                                P_CODIGOPDV => punto.codigopdv,
                                P_ACEPTA => 1,
                                P_TIPOCONTRATO => P_TIPOCONTRATO, 
                                P_USUARIO => P_USUARIO
                            );
                            
                        END IF;
                    END IF;
                END IF;
            END LOOP;
        END IF;
       
    END SP_CONTRATO_ENVIAR;


    /*Procedimiento que realiza la lÃ³gica para aceptaciÃ³n de un contrato
	  @param P_IDINVERSION   CÃ³digo de Inversion 
	  @param P_CODIGOCLIENTE CÃ³digo Cliente
	  @param P_CODIGOCLIENTE Bandera Acepta o No Acepta el contrato
      Autor: CCarrasco (NETBY)
	  Fecha: Agosto 2022
	*/   
    PROCEDURE SP_CONTRATO_ACEPTAR (P_IDINVERSION NUMBER, P_CODIGOCLIENTE VARCHAR2 DEFAULT NULL, P_CODIGOPDV VARCHAR2 DEFAULT NULL,  
                                   P_ACEPTA NUMBER, P_TIPOCONTRATO NUMBER, P_USUARIO VARCHAR2, P_SUBTIPO NUMBER DEFAULT 1, 
                                   P_COMENTARIO VARCHAR2 DEFAULT NULL ) AS
        v_idpadre data.t_icom_inversiones.idpadre%type ;
        V_CONTADOR NUMBER; 
        v_idcontrato             NUMBER;
        v_fechainicio			DATE;
        v_fechafin				DATE;
        v_tipoInversionNombre    VARCHAR2(100);
        v_nombre					varchar2(200);
        v_tipoContrato           DATA."T_CORP_UDC".DESCRIPCION%TYPE;
        v_mensaje				varchar2(5000);
        v_asunto                 VARCHAR2(100);
        v_correo_notificacion	varchar2(200);
        v_contrato_notificacion NUMBER;
    BEGIN
    

    
        select  max(COMPANIA) into  V_COMPANIA from data.t_icom_inversiones where id = P_IDINVERSION and rownum=1;

--         SELECT VALOR
--         INTO v_contrato_notificacion
--         FROM DATA.T_CORP_UDC WHERE ID_CABECERA LIKE 'ICOM_PARAM' AND VALOR2 LIKE 'CONTRATO_NOTIFICACIONES' AND CODIGOCOMPANIA = V_COMPANIA;

        v_contrato_notificacion := PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '35', V_COMPANIA);

        IF P_ACEPTA = 1   THEN  --ACEPTA CONTRATO
            
            --APROBACION auditoria            
            PK_ICOM_COMMONS.SP_AUDITORIA(
                        P_USUARIO => P_USUARIO,
                        P_IDINVERSION => P_IDINVERSION,
                        P_IDETAPA => NULL,
                        P_CODIGOGRUPO => CASE WHEN P_CODIGOCLIENTE IS NOT NULL THEN P_CODIGOCLIENTE 
                                              WHEN P_CODIGOPDV IS NOT NULL THEN P_CODIGOPDV 
                                              ELSE NULL END ,
                        P_IDACCION => 6,
                        P_DESCRIPCION => 'SE APRUEBA EL CONTRATO DE LA INVERSION' );
                        
            IF P_TIPOCONTRATO = 1 THEN 

                UPDATE DATA.T_ICOM_INVERSION_CLIENTE_G 
                SET NEGOCIACION = 3,         /*  ESTADO = 2,  */     FECHACONTRATO = SYSDATE
                WHERE IDINVERSION=P_IDINVERSION
                AND CODIGOGRUPO=P_CODIGOCLIENTE;	
                
                --agrego fechas para validaciones
                 --V_CONTADOR
                 select  count(1) into V_CONTADOR from 
                 t_icom_cliente_fechas where idinversion=P_IDINVERSION and codigogrupo=P_CODIGOCLIENTE;
                 
                if(V_CONTADOR=0) then  
                    
                    INSERT INTO data.t_icom_cliente_fechas (idinversion,codigogrupo,tipo,numero,fechainicio,
                                fechafin,    estado,    auditoriafecha) 
                     select  P_IDINVERSION ,  codigogrupo, 1,1, fechainicio,  fechafin, 1, sysdate from 
                     T_ICOM_INVERSION_CLIENTE_G  WHERE IDINVERSION=P_IDINVERSION and NEGOCIACION=3  AND CODIGOGRUPO=P_CODIGOCLIENTE;
                
                end if;
                
                SELECT COUNT(1) INTO V_CONTADOR FROM T_ICOM_INVERSION_CLIENTE_G 
                WHERE IDINVERSION=P_IDINVERSION  AND CODIGOGRUPO=P_CODIGOCLIENTE
                AND NEGOCIACION <> 3;
                
                IF(V_CONTADOR=0) THEN  -- TODOS LOS CLIENTES APRUEBAN EL CONTRATO, PASA A IMPLEMENTACION
                    update data.t_icom_inversiones  set estado = 1,  idetapa = 3, idetapa2 = null 
                    where id = P_IDINVERSION ; 
                    --CAMBIO DE ETAPA auditoria            
                    PK_ICOM_COMMONS.SP_AUDITORIA(
                                P_USUARIO => P_USUARIO,
                                P_IDINVERSION => P_IDINVERSION,
                                P_IDETAPA => 3,
                                P_CODIGOGRUPO => null,
                                P_IDACCION => 2,
                                P_DESCRIPCION => 'SE CAMBIO DE ETAPA IMPLMENTACION TODOS LOS CLIENTES APRUEBAN EL CONTRATO '    );
                                
                    select id into v_idpadre from data.t_icom_inversiones
                    where ID = p_idinversioN ;
                   
                    
                    select COUNT(1) INTO V_CONTADOR from data.t_icom_inversiones
                    where idpadre = v_idpadre and idetapa=2;
                   
                    IF(V_CONTADOR=0) THEN --TODAS LAS INVERSIONES PASARON A IMPLEMENTACION     
                        update data.t_icom_inversiones  set estado = 1,  idetapa = 3, idetapa2 = null 
                        where id = v_idpadre ; 
                        --CAMBIO DE ETAPA auditoria            
                        PK_ICOM_COMMONS.SP_AUDITORIA(
                                P_USUARIO => P_USUARIO,
                                P_IDINVERSION => P_IDINVERSION,
                                P_IDETAPA => 3,
                                P_CODIGOGRUPO => null,
                                P_IDACCION => 2,
                                P_DESCRIPCION => 'SE CAMBIO DE ETAPA IMPLMENTACION TODAS LAS HIJAS PASARON A IMPLEMENTACION '    );
                                
                    END IF;
                    
                END IF;            
                
            ELSIF  P_TIPOCONTRATO = 2 THEN
    
                UPDATE DATA.T_ICOM_CLIENTE_PDV 
                SET CONTRATOAPROBAR = 4,    ESTADO = 1,          FECHACONTRATO = SYSDATE
                WHERE IDINVERSION=P_IDINVERSION
                AND CODIGOPDV=P_CODIGOPDV;
                
                ---
                SELECT COUNT(1) INTO V_CONTADOR FROM  T_ICOM_CLIENTE_PDV  
                WHERE IDINVERSION=P_IDINVERSION  AND nvl(CONTRATOAPROBAR,0) NOT IN  (4, 5); --- APROBADOS /RECHAZADOS 
                
                -- todos los convenios gestionados 
                IF(V_CONTADOR=0) THEN 
                    UPDATE t_icom_inversiones SET IDETAPA=3, ESTADO=0 WHERE ID=P_IDINVERSION;
                    --CAMBIO DE ETAPA auditoria            
                    PK_ICOM_COMMONS.SP_AUDITORIA(
                                P_USUARIO => P_USUARIO,
                                P_IDINVERSION => P_IDINVERSION,
                                P_IDETAPA => 3,
                                P_CODIGOGRUPO => null,
                                P_IDACCION => 2,
                                P_DESCRIPCION => 'SE CAMBIO DE ETAPA IMPLMENTACION TODOS LOS CONVENIOS HAN SIDO GESTIONADOS '    );
                                
                                
                    UPDATE DATA.T_ICOM_INVERSION_CLIENTE_G 
                    SET      ESTADO = 0 WHERE IDINVERSION = P_IDINVERSION;
                END IF;
                
                
            --- TIPO=3
            --SWAP INTERCAMBIO  ADENDUM
            ELSIF  P_TIPOCONTRATO = 3 THEN
    
                select id into v_idpadre from data.t_icom_inversiones
                where idpadre = p_idinversion and idetapa = 5 and estado = 1 and rownum=1;
                
                --Intercambio el id(1) original por el id(2) de la replanificaciÃ³n
                --para que la principal sea la replanificada
                DATA.PK_ICOM_CRUD.SP_INTERCAMBIOID (
                        P_ID => P_IDINVERSION, --id(2) original
                        P_IDPADRE => v_idpadre,--id(1) replanificada
                        P_USUARIO =>  P_USUARIO                   
                      );
                commit;      
                --actualizo los valores id(2) es el que esta con los datos de la replanificacio
                update data.t_icom_inversiones
                set estado = 1, 
                    (idgrupo, idetapa) = (select idgrupo, idetapa from data.t_icom_inversiones where id = v_idpadre ), 
                    idetapa2 = null, idpadre = null
                where id = P_IDINVERSION ;
                --actualizo los valores a la replanificada id(2) esta los datos del original
                update data.t_icom_inversiones
                set estado = 1,  idetapa = 5, idetapa2 = null, idpadre = P_IDINVERSION, idgrupo = null
                where id = v_idpadre ;
                
            ELSIF P_TIPOCONTRATO = 4 THEN ---CLAUSURA
    
                UPDATE T_ICOM_CLIENTE_PDV 
                SET CONTRATOCLAUSURA = 3,
                ESTADO = 3,  
                FECHACONTRATO = SYSDATE
                WHERE IDINVERSION = P_IDINVERSION
                AND CODIGOPDV = P_CODIGOPDV;
                
            END IF;
            
        ELSIF P_ACEPTA = 0 THEN -- RECHAZA CONTRATO
            
            --RECHAZO auditoria            
            PK_ICOM_COMMONS.SP_AUDITORIA(
                        P_USUARIO => P_USUARIO,
                        P_IDINVERSION => P_IDINVERSION,
                        P_IDETAPA => NULL,
                        P_CODIGOGRUPO => CASE WHEN P_CODIGOCLIENTE IS NOT NULL THEN P_CODIGOCLIENTE 
                                              WHEN P_CODIGOPDV IS NOT NULL THEN P_CODIGOPDV 
                                              ELSE NULL END ,
                        P_IDACCION => 6,
                        P_DESCRIPCION => 'SE RECHAZO EL CONTRATO DE LA INVERSION' );
                        
           IF P_TIPOCONTRATO = 1 THEN  
           
                UPDATE DATA.T_ICOM_INVERSION_CLIENTE_G 
                SET NEGOCIACION = 2,
                    ESTADO = 3,
                    FECHACONTRATO = SYSDATE
                WHERE IDINVERSION = P_IDINVERSION
                AND CODIGOGRUPO = P_CODIGOCLIENTE;	
    
            ELSIF  P_TIPOCONTRATO = 2 THEN
            
                UPDATE DATA.T_ICOM_CLIENTE_PDV 
                SET CONTRATOAPROBAR = 5,   ESTADO = 0,   FECHACONTRATO = SYSDATE
                WHERE IDINVERSION = P_IDINVERSION   AND CODIGOPDV = P_CODIGOPDV;
              
                SELECT COUNT(1) INTO V_CONTADOR FROM  T_ICOM_CLIENTE_PDV  
                WHERE IDINVERSION=P_IDINVERSION  AND nvl(CONTRATOAPROBAR,0) NOT IN  (4, 5); --- APROBADOS /RECHAZADOS 
                
                -- todos los convenios gestionados 
                IF(V_CONTADOR=0) THEN 
                    UPDATE t_icom_inversiones SET IDETAPA=3, ESTADO=0 WHERE ID=P_IDINVERSION;
                    --CAMBIO DE ETAPA auditoria            
                    PK_ICOM_COMMONS.SP_AUDITORIA(
                                P_USUARIO => P_USUARIO,
                                P_IDINVERSION => P_IDINVERSION,
                                P_IDETAPA => 3,
                                P_CODIGOGRUPO => null,
                                P_IDACCION => 2,
                                P_DESCRIPCION => 'SE CAMBIO DE ETAPA IMPLMENTACION TODOS LOS CONVENIOS HAN SIDO GESTIONADOS '    );
                     
                    UPDATE DATA.T_ICOM_INVERSION_CLIENTE_G 
                    SET      ESTADO = 0 WHERE IDINVERSION = P_IDINVERSION;
                END IF;
                
             --- TIPO=3 ADENDUM
           ELSIF  P_TIPOCONTRATO = 3 THEN  
               -- ORIINAL ESTADO=1 
               -- REPLANIFICADA=-2
               select id into v_idpadre from data.t_icom_inversiones
                where idpadre = p_idinversion and idetapa = 5 and estado = 1 ;
               --en caso de rechazo la replanificaciÃ³n 
               UPDATE T_ICOM_INVERSIONES SET ESTADO=-2, idetapa = 0  
                WHERE (ID =v_idpadre OR IDGRUPO=v_idpadre);
               
               --CAMBIO DE ETAPA auditoria            
               PK_ICOM_COMMONS.SP_AUDITORIA(
                                P_USUARIO => P_USUARIO,
                                P_IDINVERSION => v_idpadre,
                                P_IDETAPA => 0,
                                P_CODIGOGRUPO => null,
                                P_IDACCION => 2,
                                P_DESCRIPCION => 'SE CAMBIO DE ETAPA A PROPUESTA POR RECHAZO DE REPLANIFICACION '    );
               
               --actualizo la inversiÃ³n original
               update data.t_icom_inversiones set estado = 1, idetapa2 = null
                where id = p_idinversion ;    
               
            ELSIF P_TIPOCONTRATO = 4 THEN 
               UPDATE T_ICOM_CLIENTE_PDV 
                SET CONTRATOCLAUSURA = NULL    ---- SEGUN RECUERDO DEBERIA SER 0 / RECHAZADO EL 2 SIGNIFICA POR APROBAR
                WHERE IDINVERSION = P_IDINVERSION
                AND CODIGOPDV = P_CODIGOPDV;
    
            END IF;
        END IF;
        
        --Se envia la notificaciÃ³n de correo electronico
        SELECT FECHAINICIO , FECHAFIN , INVERSIONTIPO
        INTO v_fechainicio, v_fechafin, v_tipoInversionNombre
        FROM DATA.VT_ICOM_INVERSIONES  
        WHERE ID = P_IDINVERSION;  --IDETAPA in (2,5,6) AND 

        begin
            v_tipoContrato:=PK_ICOM_COMMONS.f_traervalorudc('TIPOCONTRA', '', null,'DESCRIPCION', P_TIPOCONTRATO,1);
        exception when no_Data_found then
            v_tipoContrato := 'No hay tipo contrato';
        end ;    
        --busco el correo al que se debe notificar la aceptaciÃ³n/rechazo del contrato
        v_correo_notificacion :=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '18', V_COMPANIA );
           
        if P_TIPOCONTRATO in (1,2,4) and p_subtipo = 1 then  --- GESTION POR CORRERO
            SELECT DATA.PK_ICOM_CONTRATO.F_OBTENER_IDCONTRATO(P_IDINVERSION => P_IDINVERSION, 
                       P_CODIGOGRUPO => CASE WHEN P_TIPOCONTRATO IN (1,3) THEN P_CODIGOCLIENTE ELSE NULL END, 
                       P_CODIGOPDV => CASE WHEN P_TIPOCONTRATO IN (2,4) THEN P_CODIGOPDV ELSE NULL END, 
                       P_TIPOCONTRATO=> P_TIPOCONTRATO, P_SUBTIPO => P_SUBTIPO ) 
            INTO v_idcontrato FROM DUAL;
            
            DATA.PK_ICOM_CONTRATO.SP_CONTRATOAUDITORIA(
                    P_IDINVERSION => P_IDINVERSION,
                    P_CODIGOGRUPO => CASE WHEN P_TIPOCONTRATO IN (1,3) THEN P_CODIGOCLIENTE ELSE NULL END,
                    P_CODIGOPDV => CASE WHEN P_TIPOCONTRATO IN (2,4) THEN P_CODIGOPDV ELSE NULL END,
                    P_IDCONTRATO => v_idcontrato,
                    P_USUARIO => P_USUARIO,
                    P_TIPOCONTRATO => P_TIPOCONTRATO,
                    P_COMENTARIO => P_COMENTARIO,
                    P_AUDITORIATIPO => CASE WHEN P_ACEPTA = 1 THEN 2 ELSE 1 END  
                );
            
            if P_TIPOCONTRATO in (1) then      
            
                SELECT P_CODIGOCLIENTE||'-'||NVL(NOMBRES,'NOMBRE ESTABLECIMIENTO') INTO v_nombre
                FROM DATA.T_ICOM_INVERSION_CLIENTE_G 
                WHERE IDINVERSION = P_IDINVERSION 
                AND CODIGOGRUPO = P_CODIGOCLIENTE ;
                
            /*elsif P_TIPOCONTRATO in (2,4) then       
            
                SELECT P_CODIGOPDV||'-'||NVL(RAZONSOCIAL,' ') AS NOMBRECOMERCIAL, 
                v_correo_notificacion||','||CORREO INTO v_nombre, v_correo_notificacion
                FROM DATA.VT_TRAD_CLIENTE 
                WHERE CODIGOPDV = P_CODIGOPDV;*/
                
            end if;
            
            
            --Se envia la notificaciÃ³n de aceptacion/rechazo de contrato
            v_asunto := 'Notificacion '||CASE WHEN P_ACEPTA = 1 THEN ' aprobacion' ELSE 'rechazo' END||' del contrato';
                
            v_mensaje := '<p><strong> Notificaci&oacute;n estatus de firma del ' || UPPER(v_tipoContrato) ||'</strong></p>
                          <p>&nbsp;</p>
                          <p>Estimado Usuario</p>
                          <p>&nbsp;</p>
                          <p>El cliente '||UPPER(v_nombre)||' ha 
                             '||CASE WHEN P_ACEPTA = 1 THEN 'aprobado' ELSE 'rechazado' END||' el documento legal '||UPPER(v_tipoContrato) ||' de la inversi&oacute;n 
                             '||v_tipoInversionNombre||' del per&iacute;odo: '||to_char(v_fechainicio,'dd/mm/yyyy')||' al 
                             '||to_char(v_fechafin,'dd/mm/yyyy')||' n&uacute;mero de ID '||P_IDINVERSION||' . </p>
                          <p>&nbsp;</p>
                          <p>Atentamente,</p>
                          <p>&nbsp;</p>
                          <p>ZAIMELLA DEL ECUADOR S.A.</p>';
                
            PK_CORP_CORREO.SP_ENVIO(
                        P_MODULO => 'ICOM',
                        P_TO => v_correo_notificacion,
                        P_FROM => 'infocomercial@zaimella.com',
                        P_SUBJECT => v_asunto,
                        P_BODY => v_mensaje
            );
            
            if p_acepta = 1 AND v_contrato_notificacion = 1 then  --ACEPTA CONTRATO
                --En caso de ser aceptaciÃ³n graba el contenido del contrato
                DATA.PK_ICOM_CONTRATO.SP_CONTRATOCONTENIDO(
                    P_IDCONTRATO => v_idcontrato,
                    P_IDINVERSION => P_IDINVERSION,
                    P_CODIGOGRUPO => P_CODIGOCLIENTE,
                    P_CODIGOPDV => P_CODIGOPDV,
                    P_TIPOCONTRATO => P_TIPOCONTRATO,
                    P_ESTADO => 'CONTRATO',
                    P_USUARIO => P_USUARIO,
                    P_NOMBRE => UPPER(v_nombre)
                  );
            end if;
            
        elsif P_TIPOCONTRATO in (3) and p_subtipo = 1 then --- ADEMDUN POR CORREO
            FOR clientes IN (SELECT G.CODIGOGRUPO FROM DATA.T_ICOM_INVERSION_CLIENTE_G G
                                 INNER JOIN DATA.T_ICOM_INVERSIONES I ON (G.IDINVERSION = I.ID AND I.ESTADO = 3)/*******************/
                                 WHERE G.NEGOCIACION in (1,3)  AND G.IDINVERSION = P_IDINVERSION   )
                LOOP
                    SELECT NVL(NOMBRES,'NOMBRE ESTABLECIMIENTO') INTO v_nombre
                    FROM DATA.T_ICOM_INVERSION_CLIENTE_G 
                    WHERE IDINVERSION = P_IDINVERSION 
                    AND CODIGOGRUPO = clientes.CODIGOGRUPO;

                    SELECT PK_ICOM_CONTRATO.F_OBTENER_IDCONTRATO(P_IDINVERSION , clientes.CODIGOGRUPO , P_CODIGOPDV , P_TIPOCONTRATO ) 
                    INTO v_idcontrato FROM DUAL;
                    
                    DATA.PK_ICOM_CONTRATO.SP_CONTRATOAUDITORIA(
                        P_IDINVERSION => P_IDINVERSION,
                        P_CODIGOGRUPO => clientes.CODIGOGRUPO,
                        P_CODIGOPDV => null,
                        P_IDCONTRATO => v_idcontrato,
                        P_USUARIO => P_USUARIO,
                        P_TIPOCONTRATO => P_TIPOCONTRATO,
                        P_COMENTARIO => P_COMENTARIO,
                        P_AUDITORIATIPO => CASE WHEN P_ACEPTA = 1 THEN 2 ELSE 1 END 
                    );
               
                    --Se envia la notificaciÃ³n de aceptacion de contrato
                    v_asunto := 'Notificacion '||CASE WHEN P_ACEPTA = 1 THEN 'aprobacion' ELSE 'rechazo' END||' del contrato';
                    
                    v_mensaje := '<p><strong> Notificaci&oacute;n estatus de firma del ' || UPPER(v_tipoContrato) ||'</strong></p>
                                    <p>&nbsp;</p>
                                    <p>Estimado Usuario</p>
                                    <p>&nbsp;</p>
                                    <p>El cliente '||clientes.CODIGOGRUPO||'-'||UPPER(v_nombre)||' ha 
                                    '||CASE WHEN P_ACEPTA = 1 THEN 'aprobado' ELSE 'rechazado' END||' el documento legal 
                                    '||UPPER(v_tipoContrato) ||' de la inversi&oacute;n 
                                    '||v_tipoInversionNombre||' del per&iacute;odo: '||to_char(v_fechainicio,'dd/mm/yyyy')||' al 
                                    '||to_char(v_fechafin,'dd/mm/yyyy')||' n&uacute;mero de ID '||P_IDINVERSION||' . </p>
                                    <p>&nbsp;</p>
                                    <p>Atentamente,</p>
                                    <p>&nbsp;</p>
                                    <p>ZAIMELLA DEL ECUADOR S.A.</p>';
                    
                    PK_CORP_CORREO.SP_ENVIO(
                            P_MODULO => 'ICOM',
                            P_TO => v_correo_notificacion,
                            P_FROM => 'infocomercial@zaimella.com',
                            P_SUBJECT => v_asunto,
                            P_BODY => v_mensaje
                          );
                    
                    if p_acepta = 1 then  --ACEPTA CONTRATO
                        --En caso de ser aceptaciÃ³n graba el contenido del contrato
                        DATA.PK_ICOM_CONTRATO.SP_CONTRATOCONTENIDO(
                            P_IDCONTRATO => v_idcontrato,
                            P_IDINVERSION => P_IDINVERSION,
                            P_CODIGOGRUPO => clientes.CODIGOGRUPO,
                            P_CODIGOPDV => NULL,
                            P_TIPOCONTRATO => P_TIPOCONTRATO,
                            P_ESTADO => 'CONTRATO',
                            P_USUARIO => P_USUARIO,
                            P_NOMBRE => UPPER(v_nombre)
                          );
                    end if;      
                END LOOP;
        elsif p_acepta = 2  AND p_subtipo = 2 then      ---RECHAZO MANUAL   
            --Es un contrato manual que esta enviado a ser aprobado
             SELECT DATA.PK_ICOM_CONTRATO.F_OBTENER_IDCONTRATO(P_IDINVERSION => P_IDINVERSION, 
                       P_CODIGOGRUPO => CASE WHEN P_TIPOCONTRATO IN (1,3) THEN P_CODIGOCLIENTE ELSE NULL END, 
                       P_CODIGOPDV => CASE WHEN P_TIPOCONTRATO IN (2,4) THEN P_CODIGOPDV ELSE NULL END, 
                       P_TIPOCONTRATO=> P_TIPOCONTRATO, P_SUBTIPO => P_SUBTIPO 
                       ) 
            INTO v_idcontrato FROM DUAL;
            
            if nvl(v_idcontrato,0) =  0 then
                raise_application_error(-20000,'No se ha encontrado el idContrato manual');
            end if;
            DATA.PK_ICOM_CONTRATO.SP_CONTRATOAUDITORIA(
                    P_IDINVERSION => P_IDINVERSION,
                    P_CODIGOGRUPO => CASE WHEN P_TIPOCONTRATO IN (1,3) THEN P_CODIGOCLIENTE ELSE NULL END,
                    P_CODIGOPDV => CASE WHEN P_TIPOCONTRATO IN (4, 2) THEN P_CODIGOPDV ELSE NULL END,
                    P_IDCONTRATO => v_idcontrato,
                    P_USUARIO => P_USUARIO,
                    P_TIPOCONTRATO => P_TIPOCONTRATO,
                    P_COMENTARIO => P_COMENTARIO,
                    P_AUDITORIATIPO => 4
                );
            
            if P_TIPOCONTRATO in (1,3) then      
                SELECT P_CODIGOCLIENTE||'-'||NVL(NOMBRES,'NOMBRE ESTABLECIMIENTO') INTO v_nombre
                FROM DATA.T_ICOM_INVERSION_CLIENTE_G 
                WHERE IDINVERSION = P_IDINVERSION 
                AND CODIGOGRUPO = P_CODIGOCLIENTE ;
            elsif P_TIPOCONTRATO in (2,4) then         
                SELECT P_CODIGOPDV||'-'||NVL(RAZONSOCIAL,' ') AS NOMBRECOMERCIAL INTO v_nombre
                FROM DATA.VT_TRAD_CLIENTE 
                WHERE CODIGOPDV = P_CODIGOPDV;
            end if;
            --Se envia la notificaciÃ³n de aceptacion/rechazo de contrato
            v_asunto := 'Notificacion recepcion contrato manual';
                
            v_mensaje := '<p><strong> Notificaci&oacute;n recepci&oacute;n  contrato manual para aprobaci&oacute;n</strong></p>
                          <p>&nbsp;</p>
                          <p>Estimado Usuario</p>
                          <p>&nbsp;</p>
                          <p>Se ha registrado el documento legal '||UPPER(v_tipoContrato) ||' de la inversi&oacute;n 
                             '||v_tipoInversionNombre||' del per&iacute;odo: '||to_char(v_fechainicio,'dd/mm/yyyy')||' al 
                             '||to_char(v_fechafin,'dd/mm/yyyy')||' n&uacute;mero de ID '||P_IDINVERSION||' del cliente 
                             '||UPPER(v_nombre)||' para su revisi&oacute;n y aprobaci&oacute;n.  </p>
                          <p>&nbsp;</p>
                          <p>Atentamente,</p>
                          <p>&nbsp;</p>
                          <p>ZAIMELLA DEL ECUADOR S.A.</p>';
                
            PK_CORP_CORREO.SP_ENVIO(
                        P_MODULO => 'ICOM',
                        P_TO => v_correo_notificacion,
                        P_FROM => 'infocomercial@zaimella.com',
                        P_SUBJECT => v_asunto,
                        P_BODY => v_mensaje
            );
        elsif p_acepta = 3  AND p_subtipo = 2 then     
            
            --Es un contrato manual que se esta rechazando el contrato ingresado
            SELECT DATA.PK_ICOM_CONTRATO.F_OBTENER_IDCONTRATO(P_IDINVERSION => P_IDINVERSION, 
                       P_CODIGOGRUPO => CASE WHEN P_TIPOCONTRATO IN (1,3) THEN P_CODIGOCLIENTE ELSE NULL END, 
                       P_CODIGOPDV => CASE WHEN P_TIPOCONTRATO IN (2,4) THEN P_CODIGOPDV ELSE NULL END, 
                       P_TIPOCONTRATO=> P_TIPOCONTRATO, P_SUBTIPO => P_SUBTIPO 
                       ) 
            INTO v_idcontrato FROM DUAL;
            
            if nvl(v_idcontrato,0) =  0 then
                raise_application_error(-20000,'No se ha encontrado el idContrato manual');
            end if;
            DATA.PK_ICOM_CONTRATO.SP_CONTRATOAUDITORIA(
                    P_IDINVERSION => P_IDINVERSION,
                    P_CODIGOGRUPO => CASE WHEN P_TIPOCONTRATO IN (1,3) THEN P_CODIGOCLIENTE ELSE NULL END,
                    P_CODIGOPDV => CASE WHEN P_TIPOCONTRATO IN (4, 2) THEN P_CODIGOPDV ELSE NULL END,
                    P_IDCONTRATO => v_idcontrato,
                    P_USUARIO => P_USUARIO,
                    P_TIPOCONTRATO => P_TIPOCONTRATO,
                    P_COMENTARIO => P_COMENTARIO,
                    P_AUDITORIATIPO => 1  
                );
            --busco el correo al que se debe notificar la aceptaciÃ³n/rechazo del contrato
            select email INTO v_correo_notificacion from data.vt_corp_usuario where nombreusuario = P_USUARIO ;
            
            if P_TIPOCONTRATO in (1,3) then      
                SELECT P_CODIGOCLIENTE||'-'||NVL(NOMBRES,'NOMBRE ESTABLECIMIENTO') INTO v_nombre
                FROM DATA.T_ICOM_INVERSION_CLIENTE_G 
                WHERE IDINVERSION = P_IDINVERSION 
                AND CODIGOGRUPO = P_CODIGOCLIENTE ;
            elsif P_TIPOCONTRATO in (2,4) then         
                SELECT P_CODIGOPDV||'-'||NVL(RAZONSOCIAL,' ') AS NOMBRECOMERCIAL INTO v_nombre
                FROM DATA.VT_TRAD_CLIENTE 
                WHERE CODIGOPDV = P_CODIGOPDV;
            end if;
            --Se envia la notificaciÃ³n de aceptacion/rechazo de contrato
            v_asunto := 'Notificacion rechazo contrato manual';
                
            v_mensaje := '<p><strong> Notificaci&oacute;n rechazo  contrato manual </strong></p>
                          <p>&nbsp;</p>
                          <p>Estimado Usuario</p>
                          <p>&nbsp;</p>
                          <p>Ha sido rechazado el  documento legal '||UPPER(v_tipoContrato) ||' de la inversi&oacute;n 
                             '||v_tipoInversionNombre||' del per&iacute;odo: '||to_char(v_fechainicio,'dd/mm/yyyy')||' al 
                             '||to_char(v_fechafin,'dd/mm/yyyy')||' n&uacute;mero de ID '||P_IDINVERSION||' del cliente 
                             '||UPPER(v_nombre)||' por '|| P_COMENTARIO||' . </p>
                          <p>&nbsp;</p>
                          <p>Atentamente,</p>
                          <p>&nbsp;</p>
                          <p>ZAIMELLA DEL ECUADOR S.A.</p>';
                
            PK_CORP_CORREO.SP_ENVIO(
                        P_MODULO => 'ICOM',
                        P_TO => v_correo_notificacion,
                        P_FROM => 'infocomercial@zaimella.com',
                        P_SUBJECT => v_asunto,
                        P_BODY => v_mensaje
            );
        elsif p_acepta = 0  AND p_subtipo = 2 then         
            --recha el contrato sin ingresar un archivo manual solo se guarda para auditoria
            SELECT DATA.PK_ICOM_CONTRATO.F_OBTENER_IDCONTRATO(P_IDINVERSION => P_IDINVERSION, 
                       P_CODIGOGRUPO => CASE WHEN P_TIPOCONTRATO IN (1,3) THEN P_CODIGOCLIENTE ELSE NULL END, 
                       P_CODIGOPDV => CASE WHEN P_TIPOCONTRATO IN (2,4) THEN P_CODIGOPDV ELSE NULL END, 
                       P_TIPOCONTRATO=> P_TIPOCONTRATO, P_SUBTIPO => P_SUBTIPO 
                       ) 
            INTO v_idcontrato FROM DUAL;
            
            if nvl(v_idcontrato,0) =  0 then
                raise_application_error(-20000,'No se ha encontrado el idContrato manual');
            end if;
            
            DATA.PK_ICOM_CONTRATO.SP_CONTRATOAUDITORIA(
                    P_IDINVERSION => P_IDINVERSION,
                    P_CODIGOGRUPO => CASE WHEN P_TIPOCONTRATO IN (1,3) THEN P_CODIGOCLIENTE ELSE NULL END,
                    P_CODIGOPDV => CASE WHEN P_TIPOCONTRATO IN (4, 2) THEN P_CODIGOPDV ELSE NULL END,
                    P_IDCONTRATO => v_idcontrato,
                    P_USUARIO => P_USUARIO,
                    P_TIPOCONTRATO => P_TIPOCONTRATO,
                    P_COMENTARIO => P_COMENTARIO,
                    P_AUDITORIATIPO => 1  
            );
        elsif p_acepta = 1 AND p_subtipo = 2 then         
            --Es un contrato manual que esta aprobado 
             SELECT DATA.PK_ICOM_CONTRATO.F_OBTENER_IDCONTRATO(P_IDINVERSION => P_IDINVERSION, 
                       P_CODIGOGRUPO => CASE WHEN P_TIPOCONTRATO IN (1,3) THEN P_CODIGOCLIENTE ELSE NULL END, 
                       P_CODIGOPDV => CASE WHEN P_TIPOCONTRATO IN (2,4) THEN P_CODIGOPDV ELSE NULL END, 
                       P_TIPOCONTRATO=> P_TIPOCONTRATO, P_SUBTIPO => P_SUBTIPO 
                       ) 
            INTO v_idcontrato FROM DUAL;
            
            if nvl(v_idcontrato,0) =  0 then
                raise_application_error(-20000,'No se ha encontrado el idContrato manual');
            end if;
            
            DATA.PK_ICOM_CONTRATO.SP_CONTRATOAUDITORIA(
                    P_IDINVERSION => P_IDINVERSION,
                    P_CODIGOGRUPO => CASE WHEN P_TIPOCONTRATO IN (1,3) THEN P_CODIGOCLIENTE ELSE NULL END,
                    P_CODIGOPDV => CASE WHEN P_TIPOCONTRATO IN (4, 2) THEN P_CODIGOPDV ELSE NULL END,
                    P_IDCONTRATO => v_idcontrato,
                    P_USUARIO => P_USUARIO,
                    P_TIPOCONTRATO => P_TIPOCONTRATO,
                    P_COMENTARIO => P_COMENTARIO,
                    P_AUDITORIATIPO => 2
                );    
        end if;
        
    END SP_CONTRATO_ACEPTAR;
    
    
    PROCEDURE SP_ENVAR_NOTIFICACION(P_IDINVERSION VARCHAR, P_CODIGOCLIENTE VARCHAR2 DEFAULT NULL, 
                                  P_CODIGOPDV VARCHAR2 DEFAULT NULL, P_TIPOCONTRATO NUMBER, P_USUARIO VARCHAR2) AS
                                  
    v_nombre				varchar2(200);
    v_nombreComercial       VARCHAR2(100);
    v_correos				VARCHAR2(1000);
    v_mensaje				varchar2(5000);
    v_asunto                 VARCHAR2(100);
    v_compania 					varchar2(5);
    v_contenido_notificacion CLOB;
    v_correos_copia				VARCHAR2(1000);
    BEGIN 
        
        SELECT max(compania)
		INTO v_compania
		FROM DATA.T_ICOM_INVERSIONES I
		WHERE ID = P_IDINVERSION
        AND ROWNUM=1;
        
        IF (P_TIPOCONTRATO = 2) THEN
            FOR pdv IN (SELECT CODIGOPDV  FROM DATA.T_ICOM_CLIENTE_PDV  WHERE CONTRATOAPROBAR IN (3,4) 
            AND IDINVERSION = P_IDINVERSION 
            AND ((P_CODIGOPDV IS NOT NULL AND CODIGOPDV =  P_CODIGOPDV ) OR ( IDINVERSION = P_IDINVERSION AND P_CODIGOPDV IS NULL  ) ))
            LOOP
                
                SELECT RAZONSOCIAL AS NOMBRE, RAZONSOCIAL AS NOMBRECOMERCIAL, CORREO
                INTO v_nombre, v_nombreComercial, v_correos
                FROM DATA.VT_TRAD_CLIENTE 
                WHERE CODIGOPDV = pdv.CODIGOPDV;
            
                 v_contenido_notificacion := PK_ICOM_CONTRATO.F_REEMPLAZO_CONVENIO_PLANTILLA(
                    P_IDINVERSION => P_IDINVERSION,
                    P_CODIGOPDV => pdv.codigopdv,
                    P_TIPO => 1, 
                    P_COMPANIA=>v_compania);

                    v_asunto := 'NotificaciÃ³n de participaciÃ³n';

                    --data.pk_commons.sp_apex_correohtml(v_asunto,v_asunto);

                    v_correos_copia := PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '37', v_compania );
                                
                    v_correos := v_correos||','||v_correos_copia;
                        
                    PK_CORP_CORREO.SP_ENVIO(
                        P_MODULO => 'ICOM',
                        P_TO => v_correos,
                        P_FROM => 'infocomercial@zaimella.com',
                        P_SUBJECT => v_asunto,
                        P_BODY => v_contenido_notificacion
                    );
                    
            END LOOP;
        ELSIF (P_TIPOCONTRATO = 4) THEN
            FOR punto IN (SELECT CODIGOPDV FROM DATA.T_ICOM_CLIENTE_PDV 
            WHERE IDINVERSION = P_IDINVERSION AND (CODIGOPDV=P_CODIGOPDV or P_CODIGOPDV is null) 
            and CONTRATOCLAUSURA in (1,2,3))
            LOOP
                SELECT NVL(RAZONSOCIAL,'NOMBRE ESTABLECIMIENTO'), NVL(RAZONSOCIAL,'NOMBRE PRUEBA COMERCIAL'), CORREO  
                INTO v_nombre, v_nombreComercial, v_correos FROM DATA.VT_ICOM_CLIENTE_PDV 
                WHERE IDINVERSION = P_IDINVERSION AND CODIGOPDV = punto.CODIGOPDV;
                
                IF v_correos IS NULL THEN
                    v_correos:=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '7', v_compania );
                    --v_tipoCorreo := 2;  -- CORREO DE NOTIFICACION DE FALTA DE INFORMACION
                    v_asunto := 'NotificaciÃ³n de informaciÃ³n de cliente';
                    v_mensaje := '<table style="height: 140px; width: 667px;"><thead><tr style="height: 18px;"><td style="height: 18px; width: 657px; text-align: right;" colspan="3">Quito, ' || TO_CHAR(SYSDATE, 'DD-MM-YYYY') ||'</td></tr></thead><tbody><tr style="height: 24px;"><td style="height: 24px; width: 657px;" colspan="3">&nbsp;</td></tr><tr style="height: 22px;"><td style="height: 22px; width: 229.344px;" colspan="3"><p> Se notifica que el cliente  <strong>' || v_nombre || '</strong> no pudo ser notificado por el sistema debido a la falta de informaci&oacute;n correspondiente al correo electr&oacute;nico, por lo que solicitamos se ingrese dicha informaciÃ³n.</p><p>Saludos Cordiales,</p></td></tr></tbody></table><p><strong>&nbsp;</strong></p><p><strong>ZAIMELLA DEL ECUADOR S.A.</strong></p>';
                            
                    PK_CORP_CORREO.SP_ENVIO(
                                        P_MODULO => 'ICOM',
                                        P_TO => v_correos,
                                        P_FROM => 'infocomercial@zaimella.com',
                                        P_SUBJECT => v_asunto,
                                        P_BODY => v_mensaje
                    ); 
                ELSE
                    v_contenido_notificacion := PK_ICOM_CONTRATO.F_REEMPLAZO_CONVENIO_PLANTILLA(
                                P_IDINVERSION => P_IDINVERSION,
                                P_CODIGOPDV => punto.codigopdv,
                                P_TIPO => 2, 
                                P_COMPANIA=>v_compania
                    );
                                
                    v_asunto := 'NotificaciÃ³n de finalizaciÃ³n';
                    
                    v_correos_copia := PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '37', v_compania );
                                
                    v_correos := v_correos||','||v_correos_copia;
                            
                    PK_CORP_CORREO.SP_ENVIO(
                                        P_MODULO => 'ICOM',
                                        P_TO => v_correos,
                                        P_FROM => 'infocomercial@zaimella.com',
                                        P_SUBJECT => v_asunto,
                                        P_BODY => v_contenido_notificacion
                   ); 
                            
                   END IF;
            END LOOP;
        END IF;
    
    END SP_ENVAR_NOTIFICACION;
    
    
    
     /*Procedimiento que guarda la auditoria de los contratos de las inversiones*/
    PROCEDURE SP_CONTRATOAUDITORIA ( P_IDINVERSION NUMBER, P_CODIGOGRUPO VARCHAR2, P_CODIGOPDV VARCHAR2, 
                                     P_IDCONTRATO NUMBER, P_USUARIO VARCHAR2, P_TIPOCONTRATO VARCHAR2, 
                                     P_COMENTARIO VARCHAR2, P_AUDITORIATIPO VARCHAR2 ) AS
    BEGIN
        --verificamos que los datos necesarios no tengan nulo
       /* DBMS_OUTPUT.PUT_LINE ( ' Idinversion : '|| nvl(p_idinversion,0)|| ' grupo '|| nvl(p_codigogrupo,'c') ||
        ' pcv '|| nvl(p_codigopdv,'p') || ' contrato '||nvl(p_idcontrato,0) ||' usua '|| nvl(p_usuario,'u')||
        ' tipo '|| nvl(p_tipocontrato,'tc') );*/
        
        if( nvl(p_idinversion,0) = 0 
            or ( p_codigogrupo is null and p_codigopdv is null ) 
            --or nvl(p_idcontrato,0) = 0 
            or p_usuario is null 
            or p_tipocontrato is null ) then
        
            raise_application_error(-20000,'Existen datos nulos para la auditoria ');
        end if;
        
        insert into data.t_icom_contratoauditoria 
        (idinversion, codigogrupo, codigopdv, idcontrato, usuario, tipocontrato, 
        comentario, fecha, auditoriatipo )
        values
        (p_idinversion, p_codigogrupo, p_codigopdv, nvl(p_idcontrato,0), p_usuario, p_tipocontrato, 
         p_comentario, sysdate, p_auditoriatipo );
        commit;
    END SP_CONTRATOAUDITORIA;   
    
    /*Procedimiento para guardar el contenido del contrato*/
    PROCEDURE SP_ContratoContenido ( P_IDCONTRATO NUMBER, P_IDINVERSION NUMBER, 
        P_CODIGOGRUPO VARCHAR2, P_CODIGOPDV VARCHAR2, P_TIPOCONTRATO VARCHAR2, 
        P_ESTADO VARCHAR2, P_USUARIO VARCHAR2, P_NOMBRE VARCHAR2 ) AS
       v_contrato clob; 
       v_numero number;
       v_nombre varchar2(200); 
    BEGIN
    
        DELETE FROM DATA.T_ICOM_ARCHIVOS 
        WHERE idinversion = p_idinversion
        AND NVL(CODIGOGRUPO,'0') = NVL(P_CODIGOGRUPO,'0')
        AND NVL(CODIGOPDV,'0') = NVL(P_CODIGOPDV,'0')
        AND IDCONTRATO = P_IDCONTRATO
        AND ESTADO = 'TEMPORAL' ;
        COMMIT;
               
        select contenido into v_contrato
        from data.t_icom_contratos  where id = p_idcontrato ;
        
        for linea in ( select etiqueta, valor from data.t_icom_contrato_contenido 
                       where idcontrato = p_idcontrato and idinversion = p_idinversion 
                       and ( codigopdv = p_codigopdv or codigogrupo = p_codigogrupo ) )
        loop
            v_contrato := REPLACE(v_contrato, '${'||linea.etiqueta||'}', linea.valor);
        end loop ;
        
        DATA.PK_ICOM_CRUD.SP_CREARARCHIVO(
            P_CLOBCONTENIDO => v_contrato,
            P_IDINVERSION => p_idinversion,
            P_CODIGOGRUPO => p_codigogrupo,
            P_CODIGOPDV => p_codigopdv,
            P_NOMBRE => p_nombre,
            P_IDCONTRATO => p_idcontrato,
            P_TIPOCONTRATO => p_tipocontrato,
            P_ESTADO => p_estado,
            P_NOMBREUSUARIO => p_usuario
          );
        DBMS_OUTPUT.PUT_LINE ( ' Numero de archivo : '|| v_numero );
    END SP_ContratoContenido;
    
    /*Procedimiento que actualiza el correo y representante del grupo para el envio de contratos*/
    PROCEDURE SP_Act_CorreoRepresentante ( P_IDINVERSION NUMBER, P_CODIGOGRUPO VARCHAR2, P_CORREO VARCHAR2, 
                                                P_REPRESENTANTE VARCHAR2 ) AS
    BEGIN
    
        update data.t_icom_inversion_cliente_g
        set contratocorreo = p_correo, contratorepresentante = p_representante
        where idinversion = p_idinversion
        and codigogrupo = p_codigogrupo ;
        
    END SP_Act_CorreoRepresentante ;
    

    /*Funcion que devuelve si existe un contrato para la visualizacion con sus etiquetas ingresadas
      Autor: NETBY3 (NETBY3)
	  Fecha: Septiembre 2022
	*/ 
    FUNCTION F_TIENECONTRATOGENERADO(P_IDINVERSION  NUMBER, P_CODIGOCLIENTE NUMBER, P_CODIGOGRUPO NUMBER) RETURN NUMBER
    AS
    v_contador NUMBER;
    BEGIN 

        SELECT COUNT(contenido.IDCONTRATO) INTO  v_contador
        FROM DATA.T_ICOM_CONTRATO_CONTENIDO contenido
        WHERE contenido.IDINVERSION = P_IDINVERSION
            AND (contenido.CODIGOPDV =  P_CODIGOCLIENTE
                OR
                 contenido.CODIGOGRUPO = P_CODIGOGRUPO);

        RETURN v_contador;
    END F_TIENECONTRATOGENERADO;

    FUNCTION F_URLCONTRATO(P_IDINVERSION  NUMBER, P_CODIGOCLIENTE VARCHAR2, P_CODIGOGRUPO VARCHAR2, P_PAGINA VARCHAR2, 
                           P_SESION VARCHAR2, P_CACHE NUMBER, P_PRIVADO NUMBER) RETURN VARCHAR2 AS
        v_url VARCHAR2(200);
        v_enlace VARCHAR2(1000);
        v_cache VARCHAR2(10);
        v_paramPrivado VARCHAR2(15);
        v_idcontrato NUMBER;
        v_tipoContrato NUMBER;
    BEGIN 

		SELECT DOMINIO || RUTAMODULO INTO v_url
		FROM T_ADMI_MODULO WHERE CODIGO = G_MODULO;
		DBMS_OUTPUT.PUT_LINE ( ' v_url : '|| v_url );
		IF P_CACHE = 1 THEN v_cache := P_PAGINA;  ELSE v_cache := NULL; END IF;
		IF P_PRIVADO = 1 THEN v_paramPrivado := 'P' ||P_PAGINA || '_HASH'; END IF;

		BEGIN 

            IF P_IDINVERSION IS NOT NULL AND ( P_CODIGOCLIENTE IS NOT NULL OR P_CODIGOGRUPO IS NOT NULL) THEN
                SELECT DISTINCT IDCONTRATO INTO v_idcontrato 
                FROM DATA.T_ICOM_CONTRATO_CONTENIDO
                WHERE IDINVERSION = P_IDINVERSION
                AND (CODIGOGRUPO = P_CODIGOCLIENTE   OR CODIGOPDV = P_CODIGOGRUPO )
                AND ROWNUM = 1;
                DBMS_OUTPUT.PUT_LINE ( ' v_idcontrato : '|| v_idcontrato );
                BEGIN 
                    SELECT TIPOCONTRATO INTO v_tipoContrato 
                    FROM  T_ICOM_CONTRATOS WHERE ID = v_idcontrato;
                EXCEPTION WHEN NO_DATA_FOUND THEN 
                    DBMS_OUTPUT.PUT_LINE ( ' v_tipoContrato : '|| v_tipoContrato );
                    v_tipoContrato := NULL ;
                END ;
            ELSE
                V_IDCONTRATO := NULL;
            END IF;
		EXCEPTION WHEN NO_DATA_FOUND THEN 
            DBMS_OUTPUT.PUT_LINE ( ' v_idcontrato : '|| v_idcontrato );
            V_IDCONTRATO := NULL;
		END;

		IF (V_IDCONTRATO IS NOT NULL AND V_TIPOCONTRATO IS NOT NULL ) THEN
            IF P_PRIVADO = 1  THEN 
             v_enlace:= APEX_UTIL.PREPARE_URL(p_url => v_url || ':'|| P_PAGINA || ':' || P_SESION || '::NO:' || v_cache || ':' ||v_paramPrivado || ':'  || PK_COMMONS.F_ENCRYPT('P314_ID,P314_TIPOCONTRATO,P314_IDINVERSION,P314_CODCLIENTE,P314_CODPDV:' || v_idcontrato || ',' || v_tipoContrato || ',' || P_IDINVERSION || ',' || P_CODIGOCLIENTE || ',' || P_CODIGOGRUPO));
            ELSE 
             v_enlace := APEX_UTIL.PREPARE_URL(p_url => v_url || ':'|| P_PAGINA || ':' || P_SESION|| '::NO:' || v_cache || ':P314_ID,P314_TIPOCONTRATO,P314_IDINVERSION,P314_CODCLIENTE,P314_CODPDV:' || v_idcontrato || ',' || v_tipoContrato || ',' || P_IDINVERSION || ',' || P_CODIGOCLIENTE || ',' || P_CODIGOGRUPO);
            END  IF;
            --v_enlace := v_enlace || '\u0026p_dialog_cs=9UhUbD7Jetx09Cc_9ny-SudzYsE',{title:'Preview de Contratos',height:'auto',width:'720',maxWidth:'960',modal:false,dialog:null},'t-Dialog-page--standard '+'',apex.jQuery('#R71834812551593127'));'
        ELSE
            V_ENLACE := V_URL|| ':'|| P_PAGINA || ':' || P_SESION || '::NO:' || v_cache || ':' ;
        END IF;
        RETURN v_enlace;

    END F_URLCONTRATO;
    
    FUNCTION F_URLCONTRATO( P_PAGINA VARCHAR2, P_SESION VARCHAR2, P_CACHE NUMBER, P_PRIVADO NUMBER, 
                            P_PARAMETROS VARCHAR2) RETURN VARCHAR2 AS
        v_url VARCHAR2(200);
        v_enlace VARCHAR2(1000);
        v_cache VARCHAR2(10);
        v_paramPrivado VARCHAR2(15);
        v_idcontrato NUMBER;
        v_tipoContrato NUMBER;
    BEGIN 

		SELECT DOMINIO || RUTAMODULO INTO v_url
		FROM T_ADMI_MODULO WHERE CODIGO = G_MODULO;
		DBMS_OUTPUT.PUT_LINE ( ' v_url : '|| v_url );
		IF P_CACHE = 1 THEN
           v_cache := P_PAGINA;  
        ELSE 
            v_cache := NULL; 
        END IF;
		
        
		IF P_PRIVADO = 1  THEN 
            v_paramPrivado := 'P' ||P_PAGINA || '_HASH'; 
            v_enlace:= APEX_UTIL.PREPARE_URL(p_url => v_url || ':'|| P_PAGINA || ':' || P_SESION || '::NO:' || v_cache || ':' 
            ||v_paramPrivado || ':' || PK_COMMONS.F_ENCRYPT(P_PARAMETROS)) ;
        ELSE 
            v_enlace := V_URL|| ':'|| P_PAGINA || ':' || P_SESION || '::NO:' || v_cache || ':' ||P_PARAMETROS ;
        END  IF;
        RETURN v_enlace;
    END F_URLCONTRATO;

    FUNCTION F_OBTENER_IDCONTRATO(P_IDINVERSION NUMBER, P_CODIGOGRUPO VARCHAR2 DEFAULT NULL, P_CODIGOPDV VARCHAR2 DEFAULT NULL, 
                                    P_TIPOCONTRATO NUMBER, P_SUBTIPO NUMBER DEFAULT 1 ) RETURN NUMBER     AS 
        v_idcontrato NUMBER;
    BEGIN 

            SELECT DISTINCT contenido.IDCONTRATO --contratos.TIPOCONTRATO
            INTO v_idcontrato
            FROM T_ICOM_CONTRATO_CONTENIDO contenido,
                 T_ICOM_CONTRATOS contratos
                 WHERE contenido.IDCONTRATO = contratos.ID
                 AND contenido.IDINVERSION = P_IDINVERSION
                 AND (contenido.CODIGOGRUPO = P_CODIGOGRUPO 
                      OR
                      contenido.CODIGOPDV = P_CODIGOPDV)
                 AND contratos.TIPOCONTRATO = P_TIPOCONTRATO
                 AND contratos.estado = 1 
                 AND NVL(contratos.SUBTIPOCONTRATO,1) = P_SUBTIPO ;
                 --Aumentar el subtipo agregado en la T_ICOM_CONTRATOS 1 Electronico 2 Manual

        RETURN v_idcontrato;
    END F_OBTENER_IDCONTRATO;

    FUNCTION F_MOSTRAR_BOTONES_CONTRATO(P_IDINVERSION NUMBER, P_CODIGOGRUPO VARCHAR2 DEFAULT NULL, P_CODIGOPDV VARCHAR2 DEFAULT NULL, 
                                        P_TIPOCONTRATO NUMBER ) RETURN NUMBER  AS
        estNegociacion NUMBER;
        estadoContrato NUMBER;
        estadoClausura NUMBER;
    BEGIN 

         IF P_TIPOCONTRATO = 1 AND P_CODIGOGRUPO IS NOT NULL THEN 
    
             BEGIN 
                SELECT 1 INTO estNegociacion
                FROM T_ICOM_INVERSION_CLIENTE_G
                WHERE IDINVERSION = P_IDINVERSION
                AND CODIGOGRUPO = P_CODIGOGRUPO
                AND NEGOCIACION = 0       AND ESTADO = 1;
    
                RETURN estNegociacion;
              EXCEPTION WHEN NO_DATA_FOUND THEN 
                RETURN 0;
              END;
    
         ELSIF P_TIPOCONTRATO = 2  AND P_CODIGOPDV IS NOT NULL THEN
    
            BEGIN 
                SELECT 1 INTO estadoContrato 
                FROM T_ICOM_CLIENTE_PDV
                WHERE IDINVERSION = P_IDINVERSION
                AND CODIGOPDV = P_CODIGOPDV
                AND CONTRATOAPROBAR = 3;
    
                RETURN estadoContrato;
            EXCEPTION WHEN NO_DATA_FOUND THEN 
                 RETURN 0;
            END;
         ---- IF TIPO=3  ADENDUM
        --T_ICOM_INVERSION ESTADO=3 AND ID=P_ID
         ELSIF P_TIPOCONTRATO = 3  AND P_CODIGOGRUPO IS NOT NULL THEN 
            BEGIN 
                SELECT 1 INTO estNegociacion
                FROM T_ICOM_INVERSION_CLIENTE_G G
                INNER JOIN DATA.T_ICOM_INVERSIONES I ON (G.IDINVERSION = I.ID AND I.ESTADO = 3 )
                WHERE IDINVERSION = P_IDINVERSION
                AND CODIGOGRUPO = P_CODIGOGRUPO
                --AND NEGOCIACION = 0
                ;
    
                RETURN estNegociacion;
              EXCEPTION WHEN NO_DATA_FOUND THEN 
                RETURN 0;
              END;
         ELSIF P_TIPOCONTRATO = 4  AND P_CODIGOPDV IS NOT NULL THEN --CLAUSURA
    
            BEGIN
                SELECT 1 INTO estadoClausura
                FROM T_ICOM_CLIENTE_PDV
                WHERE IDINVERSION = P_IDINVERSION
                AND CODIGOPDV = P_CODIGOPDV
                AND CONTRATOCLAUSURA = 1;
    
                RETURN estadoClausura;
            EXCEPTION WHEN NO_DATA_FOUND THEN 
                RETURN 0;
            END;
    
         END IF;
    END F_MOSTRAR_BOTONES_CONTRATO;

    /*Funcion que valida si el contrato fue aprobado o no*/
    FUNCTION F_CONTRATO_APROBADO (P_IDINVERSION NUMBER, P_CODIGOGRUPO VARCHAR2 DEFAULT NULL, 
                                    P_CODIGOPDV VARCHAR2 DEFAULT NULL, P_TIPOCONTRATO NUMBER) RETURN NUMBER AS
        V_CONTADOR NUMBER;
    BEGIN 
            
            IF(P_TIPOCONTRATO=1) THEN -- CONTRATO CLIENTE
                 
                  SELECT CASE WHEN ESTADO=2 THEN 1 
                            WHEN ESTADO=3 THEN 0 ELSE 2 END ESTADO INTO V_CONTADOR
                    FROM T_ICOM_INVERSION_CLIENTE_G 
                    WHERE IDINVERSION = P_IDINVERSION  AND CODIGOGRUPO = P_CODIGOGRUPO;
           
             ELSIF P_TIPOCONTRATO = 2 THEN -- CONTRATO PDV
            
                SELECT CASE WHEN CONTRATOAPROBAR=4 THEN 1 
                            WHEN CONTRATOAPROBAR=5 THEN 0 ELSE 2 END ESTADO INTO V_CONTADOR
                FROM T_ICOM_CLIENTE_PDV 
                WHERE IDINVERSION = P_IDINVERSION AND CODIGOPDV = P_CODIGOPDV;
        
            ELSIF  P_TIPOCONTRATO = 4 THEN  --- CLAUSURA DE PDV
                
                 SELECT CASE WHEN CONTRATOCLAUSURA=3 THEN 1 
                             ELSE 2 END ESTADO INTO V_CONTADOR
                FROM T_ICOM_CLIENTE_PDV 
                WHERE IDINVERSION = P_IDINVERSION AND CODIGOPDV = P_CODIGOPDV;
                
            END IF;
        RETURN V_CONTADOR;
    exception when no_data_found then
        return 3 ;
    END F_CONTRATO_APROBADO; 
    
    /*Funcion que convierte un Clob a un Blob*/
    FUNCTION F_CONVERSIONCLOB( P_CLOB CLOB) RETURN BLOB IS
        v_tgt_blob BLOB;
        v_amount INTEGER := DBMS_LOB.lobmaxsize;
        v_dest_offset INTEGER := 1;
        v_src_offset INTEGER  := 1;
        v_blob_csid INTEGER := nls_charset_id('UTF8');
        v_lang_context INTEGER := DBMS_LOB.default_lang_ctx;
        warning INTEGER := 0;
    begin
        if p_clob is null then
            return null;
        end if;
    
        DBMS_LOB.CreateTemporary(v_tgt_blob, true);
        DBMS_LOB.ConvertToBlob(v_tgt_blob, p_clob, v_amount, v_dest_offset, v_src_offset, v_blob_csid, v_lang_context, warning);
        return v_tgt_blob;
    END F_CONVERSIONCLOB ;
    
    /*Funcion que busca el archivo si encuentra retorna 1 caso contrario 0*/
    FUNCTION F_BuscaArchivo (P_IDCONTRATO NUMBER, P_IDINVERSION NUMBER, 
        P_CODIGOGRUPO VARCHAR2, P_CODIGOPDV VARCHAR2, P_TIPOCONTRATO VARCHAR2, 
        P_ESTADO VARCHAR2) RETURN NUMBER IS
    v_cuenta number ;
    BEGIN
        select count(1) into v_cuenta from data.t_icom_archivos
        where idinversion = p_idinversion 
        and ( p_codigogrupo is null or codigogrupo = p_codigogrupo )
        and ( p_codigopdv is null or codigopdv = p_codigopdv)
        and idcontrato = p_idcontrato
        and tipocontrato = p_tipocontrato ;
        if nvl(v_cuenta,0) > 0 then
            return 1 ;
        else
            return 0 ;
        end if;
    exception when no_data_found then
        return 0 ;
    END F_BuscaArchivo;
    
    /* Funcion que verifica que el correo y el telefono del pdv sean los mismo 
       en caso de que sean igual retorn 1 caso contrario 0 */
    FUNCTION F_ValidaConvenio (P_CODIGOPDV VARCHAR2, P_CORREO VARCHAR2, P_TELEFONO VARCHAR2 ) RETURN NUMBER IS
        v_correo varchar2(200);
        v_telefono varchar2(200);
    BEGIN
        select correo, telefono into v_correo, v_telefono
        from data.Vt_trad_cliente 
        where codigopdv = p_codigopdv ;
        
        if nvl(trim(upper(v_correo)),'-') != nvl(trim(upper(p_correo)),'-') then
            return 0 ;
        end if;
        
        if  p_telefono is not null and (nvl(trim(upper(v_telefono)),'-') != nvl(trim(upper(p_telefono)),'-')) then
            return 0 ;
        end if;
        
        return 1 ;
    EXCEPTION WHEN NO_DATA_FOUND THEN
        return 0 ;
    END F_ValidaConvenio ;
    
    FUNCTION F_REEMPLAZO_CONVENIO_PLANTILLA (
        P_IDINVERSION IN VT_ICOM_CLIENTE_PDV.IDINVERSION%TYPE,
        P_CODIGOPDV   IN VT_ICOM_CLIENTE_PDV.CODIGOPDV%TYPE,
        P_TIPO IN NUMBER, P_COMPANIA IN VARCHAR
    ) RETURN CLOB
    IS
        v_html_base   CLOB;
        v_html_final  CLOB;
    
        v_cursor      INTEGER;
        v_col_cnt     INTEGER;
        v_desc        DBMS_SQL.DESC_TAB;
        v_value_vc    VARCHAR2(4000);
        v_value_num   NUMBER;
        v_value_date  DATE;
        v_col_name    VARCHAR2(200);
        v_col_type    NUMBER;
    BEGIN
        -- 1. Obtener plantilla
        SELECT contenido
        INTO v_html_base
        FROM DATA.T_ICOM_CONTRATOS
        WHERE TIPO = 2 AND COMPANIA=P_COMPANIA
          AND SUBTIPOCONTRATO = P_TIPO
          AND ESTADO = 1;
    
        v_html_final := v_html_base;
    
        -- 2. Construir cursor dinÃ¡mico con la fila del cliente
        v_cursor := DBMS_SQL.OPEN_CURSOR;
        DBMS_SQL.PARSE(v_cursor,
                       'SELECT * FROM VT_ICOM_CLIENTE_PDV WHERE IDINVERSION = :1 AND CODIGOPDV = :2',
                       DBMS_SQL.NATIVE);
    
        DBMS_SQL.BIND_VARIABLE(v_cursor, ':1', P_IDINVERSION);
        DBMS_SQL.BIND_VARIABLE(v_cursor, ':2', P_CODIGOPDV);
    
        -- 3. Describir columnas
        DBMS_SQL.DESCRIBE_COLUMNS(v_cursor, v_col_cnt, v_desc);
    
        -- Definir columnas dinÃ¡micamente
        FOR i IN 1 .. v_col_cnt LOOP
            CASE v_desc(i).col_type
                WHEN 1 THEN -- VARCHAR2
                    DBMS_SQL.DEFINE_COLUMN(v_cursor, i, v_value_vc, 4000);
                WHEN 2 THEN -- NUMBER
                    DBMS_SQL.DEFINE_COLUMN(v_cursor, i, v_value_num);
                WHEN 12 THEN -- DATE
                    DBMS_SQL.DEFINE_COLUMN(v_cursor, i, v_value_date);
                ELSE
                    DBMS_SQL.DEFINE_COLUMN(v_cursor, i, v_value_vc, 4000);
            END CASE;
        END LOOP;
    
        -- 4. Ejecutar y obtener valores
        IF DBMS_SQL.EXECUTE_AND_FETCH(v_cursor) > 0 THEN
            FOR i IN 1 .. v_col_cnt LOOP
                v_col_name := v_desc(i).col_name;
                v_col_type := v_desc(i).col_type;
    
                CASE v_col_type
                    WHEN 1 THEN -- VARCHAR2
                        DBMS_SQL.COLUMN_VALUE(v_cursor, i, v_value_vc);
                        v_html_final := REPLACE(v_html_final,
                                                 '{{' || v_col_name || '}}',
                                                 NVL(v_value_vc, ''));
                    WHEN 2 THEN -- NUMBER
                        DBMS_SQL.COLUMN_VALUE(v_cursor, i, v_value_num);
                        v_html_final := REPLACE(v_html_final,
                                                 '{{' || v_col_name || '}}',
                                                 TO_CHAR(NVL(v_value_num, 0), 'FM999G999G999D00'));
                    WHEN 12 THEN -- DATE
                        DBMS_SQL.COLUMN_VALUE(v_cursor, i, v_value_date);
                        v_html_final := REPLACE(v_html_final,
                                                 '{{' || v_col_name || '}}',
                                                 CASE WHEN v_value_date IS NOT NULL
                                                      THEN TO_CHAR(v_value_date, 'DD/MM/YYYY')
                                                      ELSE '' END);
                    ELSE -- Otros tipos Â¿ convertir a texto
                        DBMS_SQL.COLUMN_VALUE(v_cursor, i, v_value_vc);
                        v_html_final := REPLACE(v_html_final,
                                                 '{{' || v_col_name || '}}',
                                                 NVL(v_value_vc, ''));
                END CASE;
            END LOOP;
        END IF;
    
        DBMS_SQL.CLOSE_CURSOR(v_cursor);
    
        RETURN v_html_final;
    
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN 'No se encontrÃ³ inversiÃ³n ' || P_IDINVERSION || ' para el PDV ' || P_CODIGOPDV;
        WHEN OTHERS THEN
            IF DBMS_SQL.IS_OPEN(v_cursor) THEN
                DBMS_SQL.CLOSE_CURSOR(v_cursor);
            END IF;
            RETURN 'Error al generar contrato: ' || SQLERRM;
    END F_REEMPLAZO_CONVENIO_PLANTILLA;
    
END PK_ICOM_CONTRATO;
/
/

