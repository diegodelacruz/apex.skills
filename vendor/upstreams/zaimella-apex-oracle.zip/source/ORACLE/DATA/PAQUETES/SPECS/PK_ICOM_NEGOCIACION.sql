﻿prompt Esquema DATA para codigo PL/SQL
alter session set current_schema=DATA;

prompt PROD PACKAGE DATA.PK_ICOM_NEGOCIACION

  CREATE OR REPLACE EDITIONABLE PACKAGE PK_ICOM_NEGOCIACION as

    G_MODULO VARCHAR(4):='ICOM';
    G_MENSAJE	CLOB;

    PROCEDURE SP_GUARDAR(P_ID NUMBER,  P_GRUPO VARCHAR, P_GASTOCOMPARTIDO NUMBER,
                        P_RECONOCIMIENTO VARCHAR, P_OBSERVACION VARCHAR, P_TIPO NUMBER DEFAULT 0);

    PROCEDURE SP_RECHAZO_NEGOCIACION(P_ID NUMBER, P_GRUPO VARCHAR, P_MOTIVO VARCHAR);
    
    PROCEDURE SP_CLIENTES_SINFECHA(P_ID NUMBER);

         PROCEDURE SP_FECHA_INGRESO(P_ID NUMBER,  P_GRUPO VARCHAR, P_NUMERO NUMBER DEFAULT NULL, P_DESDE DATE,
      P_HASTA DATE, P_TIPOLOCAL VARCHAR DEFAULT NULL, P_ESTABLECIMINETO VARCHAR DEFAULT NULL, 
      P_REPLANIFICADO NUMBER DEFAULT 0, P_FECHAS VARCHAR2 DEFAULT NULL , P_USUARIO VARCHAR2 DEFAULT NULL, 
      P_COMPANIA VARCHAR2 DEFAULT '0',
      P_PORCENTAJE NUMBER DEFAULT NULL,P_TIPO_DESCUENTO VARCHAR2 DEFAULT NULL,P_DESCCRIPCION VARCHAR2 DEFAULT NULL);
    
    PROCEDURE SP_ELIMINAFECHA (P_ID NUMBER,  P_GRUPO VARCHAR, P_NUMERO NUMBER );

    PROCEDURE SP_ENVIAR_FLUJO (P_ID NUMBER,P_USUARIO VARCHAR, P_FINALIZAR NUMBER DEFAULT 0,
                            P_NEGOCIADOR NUMBER , P_COMPANIA VARCHAR, P_EXITO OUT NUMBER); 

    PROCEDURE SP_APROBACION (P_ID NUMBER,P_GRUPO VARCHAR,P_ESTADO NUMBER, P_COMENTARIO VARCHAR,P_USUARIO VARCHAR, P_COMPANIA VARCHAR2,
	    P_COMENTARIO_DIRIGIDO VARCHAR2 DEFAULT NULL, P_FLUJO NUMBER DEFAULT 1);

    PROCEDURE SP_CAMBIOMASIVO (P_ID NUMBER, P_CANAL VARCHAR, P_ESTADO NUMBER, P_GASTO NUMBER, P_TIPORECONOCIMIENTO VARCHAR,
								P_OBSERVACION VARCHAR , P_MOTIVO VARCHAR,P_FINICIO DATE, P_FFIN DATE, P_USUARIO VARCHAR2, 
                                P_COMPANIA VARCHAR2 );


  /*Procedimiento para actualizar el campo ESTADOMODIFICADO en la tabla T_ICOM_INVERSION_CLIENTE_G
  @param P_ID  				id de la inversion
  @param P_GRUPO			id grupo cliente
    Autor: CCarrasco (NETBY)
	Fecha: Agosto 2022
	*/
   PROCEDURE SP_ACTUALIZA_ESTADOMODIFICADO(P_ID NUMBER, P_GRUPO VARCHAR);


   /*Funcion que identifica el tipo de negociacion realizada en la inversion
    Autor: NETBY3 (NETBY3)
	Fecha: Septiembre 2022
	*/   
   FUNCTION F_IDENTIFICANEGOCIACION( P_ID NUMBER ) RETURN NUMBER;

   FUNCTION F_validaFechaMasivo (P_ID NUMBER, P_IDGRUPO NUMBER, P_FEC_INI DATE, P_FEC_FIN DATE, P_GRUPOFEC_INI DATE, P_GRUPOFEC_FIN DATE) RETURN NUMBER ;
   
   FUNCTION F_validaFechaInversion (P_ID NUMBER, P_CODIGOGRUPO VARCHAR2 DEFAULT 0)  RETURN NUMBER ;
   
   FUNCTION F_BUSCAID_UDC ( P_IDCABECERA VARCHAR2, P_DESCRIPCION VARCHAR2,P_COMPANIA VARCHAR2)  RETURN VARCHAR2 ;
   
   PROCEDURE SP_ValidaClienteMaterial(P_ID NUMBER, P_NEGOCIAR NUMBER ) ;
   
   FUNCTION F_FechasAprobadas(P_ID NUMBER, P_CODIGOGRUPO VARCHAR2)  RETURN NUMBER ;
   
   PROCEDURE SP_CLIENTEMATERIAL(P_ID NUMBER, P_NEGOCIAR NUMBER ) ;
   
   PROCEDURE SP_VACIARMATERIALPOP ( P_IDINVERSION NUMBER , P_ETAPA NUMBER, P_EJECUTIVO NUMBER, P_NEGOCIADOR NUMBER, P_USUARIO VARCHAR2,P_REPLANIFICA NUMBER DEFAULT 0,P_GRUPO VARCHAR2 DEFAULT null);
   
   PROCEDURE SP_AGREGARMATERIAL( P_ID NUMBER, P_CODIGOGRUPO VARCHAR2, P_IDMATERIAL VARCHAR2, P_DESCRIPCION VARCHAR2, 
        P_CANTIDAD NUMBER, P_ESTADO NUMBER, P_COSTO NUMBER, P_NEGOCIACION NUMBER, P_TIPO NUMBER, P_CODIGOPDV VARCHAR2,
        P_CANTIDADPDV NUMBER, P_CLASIFICACION VARCHAR2, P_MEDIBLE NUMBER, P_IMPLEMENTACION VARCHAR, P_FECHAINICIO DATE, 
        P_FECHAFIN DATE, P_OBSERVACIONES VARCHAR2, P_FORMATO VARCHAR2, P_MODO NUMBER DEFAULT 0  ) ;
   
   PROCEDURE SP_FechaDiaSemana( P_ID NUMBER, P_GRUPO VARCHAR2, P_DESDE DATE,
        P_HASTA DATE, P_DIA NUMBER, P_TIPOLOCAL VARCHAR2, P_ESTABLECIMINETO VARCHAR2,
        P_PORCENTAJE NUMBER DEFAULT NULL,P_TIPO_DESCUENTO VARCHAR2 DEFAULT NULL,P_DESCCRIPCION VARCHAR2 DEFAULT NULL
   );
        
   PROCEDURE SP_INVERSION_ENCUENTAS_TOMALOCAL(P_IDINVERSION NUMBER,P_CODIGOGRUPO VARCHAR2 DEFAULT NULL,P_COMPANIA VARCHAR2,P_MENSAJE OUT VARCHAR2) ;
   
   PROCEDURE SP_INVERSION_ENCUENTAS_EXIBICION(P_IDINVERSION NUMBER,P_CODIGOGRUPO VARCHAR2 DEFAULT NULL,P_COMPANIA VARCHAR2,P_MENSAJE OUT VARCHAR2) ;
  
   PROCEDURE SP_INVERSION_ENCUENTAS_DESCUENTO(P_IDINVERSION NUMBER,P_CODIGOGRUPO VARCHAR2 DEFAULT NULL,P_COMPANIA VARCHAR2,P_MENSAJE OUT VARCHAR2) ;
  
   PROCEDURE SP_INVERSION_ENCUENTAS (P_IDINVERSION NUMBER,P_CODIGOGRUPO VARCHAR2 DEFAULT NULL,P_COMPANIA VARCHAR2,P_MENSAJE OUT VARCHAR2) ;
   
   FUNCTION F_INVERSION_ENCUENTAS_NOMBRES(P_IDINVERSION NUMBER,P_CODIGOGRUPO VARCHAR2 DEFAULT NULL,P_COMPANIA VARCHAR2, P_PRESTAERROR NUMBER DEFAULT 1
   ,P_EJECUTIVO VARCHAR2 DEFAULT NULL) return clob ;
   
   PROCEDURE SP_NOTIFICACION_KAM_PROMOCIONES_POP(p_idinversion number default null)  ;

END PK_ICOM_NEGOCIACION;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "DATA"."PK_ICOM_NEGOCIACION" 	 AS
     V_COMPANIA VARCHAR2(5);
     /*MODIFICA LOS DATOS DEL CLIENTE 
     PK_ICOM_NEGOCIACION.SP_GUARDAR(P_ID =>:P300_ID, P_GRUPO =>:P300_GRUPO, P_GASTOCOMPARTIDO =>:P300_GASTOCOMPARTIDO, 
     P_RECONOCIMIENTO =>:P300_RECONOCIMIENTO, P_OBSERVACION =>:P300_OBSERVACION);*/
     PROCEDURE SP_GUARDAR(P_ID NUMBER, P_GRUPO VARCHAR, P_GASTOCOMPARTIDO NUMBER,
        P_RECONOCIMIENTO VARCHAR, P_OBSERVACION VARCHAR , P_TIPO NUMBER DEFAULT 0)AS
     BEGIN 
        UPDATE data.T_ICOM_INVERSION_CLIENTE_G SET 
            GASTOCOMPARTIDO= CASE WHEN (P_TIPO=0 OR (P_TIPO=1 AND P_GASTOCOMPARTIDO IS NOT NULL)) THEN P_GASTOCOMPARTIDO ELSE GASTOCOMPARTIDO  END ,
            IDTIPORECONOCIMIENTO= CASE WHEN (P_TIPO=0 OR (P_TIPO=1 AND P_RECONOCIMIENTO IS NOT NULL)) THEN P_RECONOCIMIENTO ELSE IDTIPORECONOCIMIENTO  END ,
            OBSERVACION= CASE WHEN (P_TIPO=0 OR (P_TIPO=1 AND P_OBSERVACION IS NOT NULL)) THEN P_OBSERVACION ELSE OBSERVACION  END 
		WHERE codigogrupo	= P_GRUPO 		and   idinversion	= P_ID ;

     END SP_GUARDAR;

     /*
	 Procedimiento para actualizar registro en la tabla T_ICOM_INVERSION_CLIENTE_G
      @param P_ID  				id de la inversion
      @param P_GASTO_COMPARTIDO Tiene o no gasto compartido
	  @param P_CANAL			id canal
	  @param P_GRUPO			id grupo cliente
    Autor: CCarrasco (NETBY)
	Fecha: Agosto 2022
	*/   
   PROCEDURE SP_RECHAZO_NEGOCIACION(P_ID NUMBER, P_GRUPO VARCHAR, P_MOTIVO VARCHAR) AS
   V_CONTADOR NUMBER;
   BEGIN

		UPDATE data.T_ICOM_INVERSION_CLIENTE_G SET NEGOCIACION=2 ,MOTIVORECHAZO=P_MOTIVO
        ,FECHAGESTION=SYSDATE
		WHERE codigogrupo	= P_GRUPO 		and   idinversion	= P_ID ;
        
         DELETE t_icom_cliente_fechas 
         WHERE idinversion=P_ID AND codigogrupo=P_GRUPO AND ESTADO=0;
        
        sp_actualiza_estadomodificado(p_id=>P_ID,p_grupo=>P_GRUPO);

   END SP_RECHAZO_NEGOCIACION;
   
   PROCEDURE SP_CLIENTES_SINFECHA(P_ID NUMBER) AS
   BEGIN
        UPDATE  T_ICOM_INVERSION_CLIENTE_G C SET NEGOCIACION=0, ESTADO=0 
        WHERE IDINVERSION=P_ID AND NEGOCIACION IN (1,3) AND ESTADO=1 AND 
        NOT EXISTS (SELECT 1 FROM t_icom_cliente_fechas CF WHERE CF.IDINVERSION=C.IDINVERSION AND C.codigogrupo=CF.codigogrupo);
   END SP_CLIENTES_SINFECHA;

    /*INGRESA LA FECHA DE UN CLIENTE
    */
  PROCEDURE SP_FECHA_INGRESO(P_ID NUMBER,  P_GRUPO VARCHAR, P_NUMERO NUMBER DEFAULT NULL, P_DESDE DATE,
  P_HASTA DATE, P_TIPOLOCAL VARCHAR DEFAULT NULL, P_ESTABLECIMINETO VARCHAR DEFAULT NULL, 
  P_REPLANIFICADO NUMBER DEFAULT 0, P_FECHAS VARCHAR2 DEFAULT NULL , P_USUARIO VARCHAR2 DEFAULT NULL, 
  P_COMPANIA VARCHAR2 DEFAULT '0',
  P_PORCENTAJE NUMBER DEFAULT NULL,P_TIPO_DESCUENTO VARCHAR2 DEFAULT NULL,P_DESCCRIPCION VARCHAR2 DEFAULT NULL) AS
  V_NUMERO NUMBER;
  BEGIN 
  
    IF (trunc(P_HASTA)<trunc(P_DESDE)) THEN 
          raise_application_error(-20000,'Fecha hasta debe ser mayor a fecha desde');
    END IF; 
    
    IF P_REPLANIFICADO IN ( 0,1 ) THEN 
        SELECT NVL(max(numero),0)+1 INTO V_NUMERO FROM t_icom_cliente_fechas 
            WHERE idinversion=P_ID AND codigogrupo=P_GRUPO;
    
        IF(P_NUMERO IS NULL) THEN --- NUEVO
            INSERT INTO data.t_icom_cliente_fechas (idinversion,codigogrupo,tipo,numero  ,fechainicio,
             fechafin,estado,auditoriafecha,tipolocal  ,establecimiento  ,DESCUENTO  ,Productos ) VALUES (
             P_ID       ,P_GRUPO    ,1   ,V_NUMERO,P_DESDE    ,P_HASTA ,0     ,SYSDATE       ,P_TIPOLOCAL,P_ESTABLECIMINETO,P_PORCENTAJE,P_DESCCRIPCION);
        ELSE  -- MODIFICO  negociado o replanificado
            UPDATE data.t_icom_cliente_fechas 
            SET 
                fechainicio=P_DESDE, 
                fechafin=P_HASTA,
                tipolocal=P_TIPOLOCAL,
                establecimiento=P_ESTABLECIMINETO,
                REPLANIFICADO= P_REPLANIFICADO,
                DESCUENTO=case when P_REPLANIFICADO=1 then DESCUENTO  else P_PORCENTAJE end,
                Productos =case when P_REPLANIFICADO=1 then Productos  else P_DESCCRIPCION end 
            WHERE idinversion=P_ID AND codigogrupo=P_GRUPO AND NUMERO=P_NUMERO; 
        END IF;
    ELSIF P_REPLANIFICADO = 2 THEN
        --MODIFICACION replanificacion de fechas masivo
        UPDATE data.t_icom_cliente_fechas 
           SET fechainicio=P_DESDE, fechafin=P_HASTA, REPLANIFICADO= 1
            WHERE idinversion=P_ID 
              AND PK_ICOM_COMMONS.F_EJECUTIVONEGOCIADOR( P_CODIGOGRUPO => CODIGOGRUPO, 
                    P_USUARIO => P_USUARIO, P_COMPANIA => P_COMPANIA ) = 1 
              AND to_char(fechainicio,'dd/mm/yyyy')||' - '||to_char(fechafin,'dd/mm/yyyy') = P_FECHAS ; 
        --ACTUALIZA LAS FECHAS GENERALES
         UPDATE T_ICOM_INVERSION_CLIENTE_G g
         SET ( fechainicio, fechafin) = (select min(f.fechainicio), max(f.fechafin) from T_ICOM_CLIENTE_FECHAS F
                                        where g.idinversion = f.idinversion and g.codigogrupo = f.codigogrupo
                                        and estado = 1)
         WHERE idinversion=P_ID 
         AND PK_ICOM_COMMONS.F_EJECUTIVONEGOCIADOR( P_CODIGOGRUPO => CODIGOGRUPO, 
                    P_USUARIO => P_USUARIO, P_COMPANIA => P_COMPANIA ) = 1 ;
    END IF;
    
    if p_replanificado = 0 then --- solo negociacion 

        sp_actualiza_estadomodificado(p_id=>P_ID,p_grupo=>P_GRUPO);
        Update data.T_ICOM_INVERSION_CLIENTE_G 
        SET NEGOCIACION=1, fechagestion = NVL(fechagestion, SYSDATE)
		where IDINVERSION = P_ID 	AND CODIGOGRUPO=P_GRUPO;
        
    elsif p_replanificado IN (1 ) then -- solo replanificacion

        UPDATE T_ICOM_INVERSION_CLIENTE_G g
        SET ( fechainicio, fechafin) = (select min(f.fechainicio), max(f.fechafin) from T_ICOM_CLIENTE_FECHAS F
                                        where g.idinversion = f.idinversion and g.codigogrupo = f.codigogrupo
                                        and estado = 1)
        WHERE idinversion=P_ID AND codigogrupo=P_GRUPO ;                                

    end if;
  END SP_FECHA_INGRESO;
  
  /* Procedimiento para eliminar una fecha que no este aprobada
  
  */
    PROCEDURE SP_ELIMINAFECHA (P_ID NUMBER,  P_GRUPO VARCHAR, P_NUMERO NUMBER ) AS
    BEGIN
        delete from data.t_icom_cliente_fechas
        where idinversion = p_id
        and codigogrupo = p_grupo
        and tipo = 1
        and numero = case when nvl(p_numero,0) = 0 then numero else p_numero end 
        and estado = 0 ;
    END;
     /*
	 Procedimiento para envio a flujo de aprobacion de un cliente (PAGINA 303 - ICOM)
	*/

   PROCEDURE SP_ENVIAR_FLUJO (P_ID NUMBER,P_USUARIO VARCHAR, P_FINALIZAR NUMBER DEFAULT 0, 
    P_NEGOCIADOR NUMBER ,P_COMPANIA VARCHAR,P_EXITO OUT NUMBER) AS
    V_CONTADOR NUMBER;
    V_OBJETO VARCHAR(50):= 'CLIENTE_INVERSION_COMERCIAL';
    V_EXITO NUMBER(1);
    V_AREA VARCHAR(10);
    V_ETAPA VARCHAR(10);
    V_ORIGEN VARCHAR(10);
    V_CANAL VARCHAR(50);
    V_AGRUPADO VARCHAR(10);
    V_TIPOINVERSION VARCHAR(10);
    V_TIPO VARCHAR(50);
    V_IDETAPA NUMBER;
	BEGIN

		--	Verifica si el cliente tiene material, estos deben estar gestionados (SI/No).
            SELECT COUNT(1) INTO V_CONTADOR  from data.VT_ICOM_INVERSION_CLIENTE g
            INNER JOIN T_ICOM_CLIENTE_MATERIAL M on (g.idinversion=M.idinversion and g.CODIGOGRUPO=M.CODIGOGRUPO )
            where g.idinversion =P_ID and estadonegociacion in (1,3)
            and (ejecutivo in (select numeroidentificacion from data.VT_CORP_USUARIO where nombreusuario= P_USUARIO) or P_NEGOCIADOR=1)
            AND g.ESTADO=1 AND (M.NEGOCIACION IS NULL or M.NEGOCIACION = -1);  

            IF (V_CONTADOR>0 and P_FINALIZAR = 1 ) THEN 
                  raise_application_error(-20000,'EXISTEN CLIENTE CON MATERIAL SIN NEGOCIAR');
            END IF;

		-- VERIFICA SI UN CLIENTE NO NEOGOCIO QUE EXISTA EL MOTIVO
            select COUNT(1) INTO V_CONTADOR  from data.VT_ICOM_INVERSION_CLIENTE g
            where  g.idinversion =P_ID and estadonegociacion=2  
            and (ejecutivo in (select numeroidentificacion from data.VT_CORP_USUARIO where nombreusuario= P_USUARIO) or P_NEGOCIADOR=1)
            AND g.ESTADO=1 AND  MOTIVORECHAZO IS NULL ;  

            IF (V_CONTADOR>0) THEN 
                  raise_application_error(-20000,'EXISTEN CLIENTE RECHAZADOS SIN MOTIVO DE RECHAZO');
            END IF;
            
        G_MENSAJE :='';
        P_EXITO :=1;

           SELECT IDINVERSIONTIPO, INVERSIONTIPO , IDAREA, IDORIGEN, GRUPAL, IDETAPA
            INTO  V_TIPOINVERSION, V_TIPO,V_AREA, V_ORIGEN, V_AGRUPADO, V_IDETAPA
            FROM VT_ICOM_INVERSIONES WHERE ID=P_ID;
            
        --validar las fechas aprobadas de los clientes para que no esten duplicadas.
            if f_validaFechaInversion (P_ID => P_ID ) = 0 then
                raise_application_error(-20000,'EXISTEN FECHAS NEGOCIADAS DE CLIENTES QUE NOS SON CORRECTAS');
            end if;
            
        FOR CLIENTE IN ( select *  from data.VT_ICOM_INVERSION_CLIENTE g
                            where  g.idinversion =P_ID 
                            and (ejecutivo in (select numeroidentificacion from data.VT_CORP_USUARIO where nombreusuario= P_USUARIO) 
                                 or P_NEGOCIADOR=1) AND g.ESTADO=1) LOOP
          
                PK_CORP_FLUJOAPROBACION.SP_FLUJOENVIAR(
                p_id=>P_ID||'-'||CLIENTE.CODIGOGRUPO,
                p_objeto=>V_OBJETO,
                p_objetodescripcion=>'INVERSION #: '||P_ID|| ' Cliente: '||CLIENTE.CODIGOGRUPO||'-'||CLIENTE.NOMBRES,
                P_ETAPA=>'NEGOCIACION',
                p_usuario=>P_USUARIO,
                p_modulo=>G_MODULO,
                p_compania=>P_COMPANIA,
                P_TIPO1=>2,  -- etapa
                p_exito=>V_EXITO);
                
                G_MENSAJE:=PK_CORP_FLUJOAPROBACION.G_MENSAJE ;
            
            IF (v_exito = 1) THEN -- MODIFICO LOS CLIENTES QUE SE ENVIARON CON EXITO

                UPDATE t_icom_inversion_cliente_g SET  ESTADO=2 , 
                NEGOCIACION= (CASE WHEN NEGOCIACION=1 AND P_FINALIZAR= 1 THEN 3 ELSE NEGOCIACION END )
                WHERE idinversion=P_ID AND codigogrupo=CLIENTE.CODIGOGRUPO;

                UPDATE T_ICOM_INVERSIONES SET ESTADO=2 WHERE ID=P_ID;
                
                --ENVIAR A RUTA auditoria            
               PK_ICOM_COMMONS.SP_AUDITORIA(
                                P_USUARIO => P_USUARIO,
                                P_IDINVERSION => P_ID,
                                P_IDETAPA => NULL,
                                P_CODIGOGRUPO => CLIENTE.CODIGOGRUPO,
                                P_IDACCION => 5,
                                P_DESCRIPCION => 'SE ENVIA A RUTA DE APROBACIÃ“N EL CLIENTE DE LA INVERSION'    );
            ELSE-- Guarda los Id que NO SE ENVIAR Y DA ERROR
                P_EXITO :=0;
                IF (length(G_MENSAJE) > 0) THEN
                    G_MENSAJE := G_MENSAJE||' ,'||CLIENTE.CODIGOGRUPO;
                else
                    G_MENSAJE := PK_CORP_FLUJOAPROBACION.G_MENSAJE;--CLIENTE.CODIGOGRUPO;
                    raise_application_error(-20000,G_MENSAJE);
                end if;
            END IF;
        END LOOP;

   END SP_ENVIAR_FLUJO;

   	 /*APROBACION/RECHAZO DE CLIENTE EN FLUJO DE APROBACIOMN
        P_ESTADO 1  aprueba / 0 rechaza
	*/
   PROCEDURE SP_APROBACION (P_ID NUMBER,P_GRUPO VARCHAR,P_ESTADO NUMBER,
   P_COMENTARIO VARCHAR,P_USUARIO VARCHAR, P_COMPANIA VARCHAR2,
	    P_COMENTARIO_DIRIGIDO VARCHAR2 DEFAULT NULL , P_FLUJO NUMBER DEFAULT 1) AS
	v_contador number;
    v_contador2 number;
    v_exito 			number;
    v_termino 			number;
    V_OBJETO VARCHAR(50):= 'CLIENTE_INVERSION_COMERCIAL';
    P_MENSAJE VARCHAR2(3999);
    v_estado  number:=1;

	BEGIN
    
       IF(P_FLUJO=1) THEN 
            IF(P_ESTADO=1) THEN
                  pk_corp_flujoaprobacion.sp_flujoaprobar(
                            p_id 					=> P_ID||'-'||P_GRUPO
                            , p_objeto				=> V_OBJETO
                            ,P_ORDENMONTO => NULL
                            ,P_USUARIOFLUJO=>P_USUARIO
                            , p_usuario				=> P_USUARIO
                            , p_comentario			=> P_COMENTARIO
                            , P_COMENTARIO_USUARIOS => P_COMENTARIO_DIRIGIDO
                            , p_modulo				=> G_MODULO
                            , p_compania			=> P_COMPANIA
                            , p_exito				=> v_exito
                            , p_terminoflujo		=> v_termino);
        
              ELSE
                  PK_CORP_FLUJOAPROBACION.SP_FLUJORECHAZAR(
                        p_id 					=> P_ID||'-'||P_GRUPO,
                        p_objeto				=> V_OBJETO,
                        P_USUARIOFLUJO          =>P_USUARIO,
                        p_usuario				=> P_USUARIO,
                        P_COMENTARIO            => P_COMENTARIO,
                        P_COMENTARIO_USUARIOS => P_COMENTARIO_DIRIGIDO,
                        P_MODULO                => G_MODULO,
                        P_COMPANIA              => P_COMPANIA,
                        P_EXITO                 => v_exito
                    );
                    v_termino :=1;
              END IF;
       ELSE 
             v_termino :=1;
             v_exito:=1;
       END IF;

    IF(v_exito=0) THEN
         raise_application_error(-20000,pk_corp_flujoaprobacion.G_MENSAJE);
    END IF;

    --APROBACION auditoria
    PK_ICOM_COMMONS.SP_AUDITORIA(
                    P_USUARIO => P_USUARIO,
                    P_IDINVERSION => P_ID,
                    P_IDETAPA => NULL,
                    P_CODIGOGRUPO => P_GRUPO,
                    P_IDACCION => 6,
                    P_DESCRIPCION => CASE WHEN P_ESTADO=1 THEN 'SE APRUEBA LOS CLIENTES DE LA INVERSION' ELSE 'SE RECHAZA LOS CLIENTES DE LA INVERSION' END  );


    IF v_termino = 1 THEN

        v_contador := PK_ICOM_NEGOCIACION.F_FechasAprobadas(P_ID=>P_ID, P_CODIGOGRUPO=>P_GRUPO);

        UPDATE T_ICOM_INVERSION_CLIENTE_G
            SET ESTADO=0, NEGOCIACION=CASE
            WHEN P_ESTADO=0 and nvl(v_contador,0) = 0 THEN 0 ---RECHAZA Y NO TIENE FECHAS APROBADOS -> ESTADO PENDIENTE POR NEGOCIAR
            WHEN P_ESTADO=0 and v_contador> 0 THEN 1  --- RECHAZA Y TIENE FECHAS APROBADOS -> ESTADO ACEPTO
            ELSE NEGOCIACION END   --- APRUEBA -> ESTADO EL QUE ESTA SOLICITANDO (ACEPTO, ACEPTA Y FINALIZA , RECHAZA)
			WHERE codigogrupo	= P_GRUPO and   idinversion	= P_ID;


        --Verificar en caso de aprobacion p_estado = 1 se debe actualizar las fechas del cliente


        if p_estado = 1 then --aprobacion

           /*
                se llama al procedimiento para la generacion de las encuestas
           */
            SP_INVERSION_ENCUENTAS (P_ID ,P_GRUPO ,P_COMPANIA ,P_MENSAJE );

            UPDATE t_icom_cliente_fechas set
            estado=1 ,
            ENCUESTA=1
            WHERE idinversion=P_ID AND codigogrupo=P_GRUPO AND ESTADO=0 ;

            UPDATE T_ICOM_INVERSION_CLIENTE_G g
            SET ( fechainicio, fechafin) = (select min(f.fechainicio), max(f.fechafin) from T_ICOM_CLIENTE_FECHAS F
                                            where g.idinversion = f.idinversion and g.codigogrupo = f.codigogrupo
                                            and estado = 1)
            WHERE idinversion=P_ID AND codigogrupo=P_GRUPO ;

           ---aprueba material
           update  T_ICOM_CLIENTE_MATERIAL m
                set
                    m.estado= 1
                where idinversion=P_ID AND codigogrupo=P_GRUPO
                and exists  ( select 1  from t_icom_inversion_cliente_g g where  g.idinversion=m.idinversion and g.codigogrupo=m.codigogrupo and  g.estado=0 and g.negociacion in (1,3) );

        ELSE -- RECHAZO

            UPDATE T_ICOM_INVERSION_CLIENTE_G g
            SET motivoRechazo=null
            WHERE idinversion=P_ID AND codigogrupo=P_GRUPO and NEGOCIACION=2;

           DELETE t_icom_cliente_fechas
           WHERE idinversion=P_ID AND codigogrupo=P_GRUPO AND ESTADO=0;
        end if;

        --Verificar si existe algun cliente en ruta
        select count(1) into v_contador
        from data.T_ICOM_INVERSION_CLIENTE_G
        where idinversion = P_ID and estado =2 ;

        IF 	v_contador = 0 then
            update data.t_icom_inversiones SET  estado=1
            where id = P_ID;
        END IF;

        --Verificar si todos los clientes esten negociados, SI NO EXISTE NEGOCIACION EN 0,1(PENDIENTE O ACEPTA)
        select count(1) into v_contador
        from data.T_ICOM_INVERSION_CLIENTE_G
        where idinversion = P_ID
        AND (estado != 0 OR NEGOCIACION not in (2,3) );

        if 	v_contador = 0 then
            update data.t_icom_inversiones SET idetapa = 3, estado=1
            where id = P_ID;
            --CAMBIO DE ETAPA auditoria
           PK_ICOM_COMMONS.SP_AUDITORIA(
                            P_USUARIO => P_USUARIO,
                            P_IDINVERSION => P_ID,
                            P_IDETAPA => 3,
                            P_CODIGOGRUPO => null,
                            P_IDACCION => 2,
                            P_DESCRIPCION => 'SE CAMBIO DE ETAPA NEGOCIACION - IMPLEMENTACION POR APROBACION DE INVERSION CON TODOS LOS CLIENTES NEGOCIADOS '    );
        end if;
        --TERMINO EL FLUJO DE APROBACION auditoria
        PK_ICOM_COMMONS.SP_AUDITORIA(
                    P_USUARIO => P_USUARIO,
                    P_IDINVERSION => P_ID,
                    P_IDETAPA => NULL,
                    P_CODIGOGRUPO => P_GRUPO,
                    P_IDACCION => 6,
                    P_DESCRIPCION => CASE WHEN P_ESTADO=1 THEN 'SE TERMINA EL FLUJO DE APROBACION DE LOS CLIENTES DE LA INVERSION'
                                         ELSE 'SE TERMINO EL FLUJO DE RECHAZO DE LOS CLIENTES DE LA INVERSION' END  );
    END IF;

   END SP_APROBACION;

   /*Procedimiento para actualizar informacion de clientes de forma masiva a la tabla T_ICOM_INVERSION_CLIENTE_G
      @param P_ID  					id de la inversion
	  @param P_CANAL				canal del cliente
	  @param P_ESTADO				estado del cliente
	  @param P_GASTO				columna gasto compartido
	  @param P_TIPORECONOCIMIENTO	columna tipo reconocimiento
	  @param P_OBSERVACION			columna observacion
	  @param P_MOTIVO    			columna motivo rechazo

    Autor: CCarrasco (NETBY)
	Fecha: Agosto 2022
	*/
   PROCEDURE SP_CAMBIOMASIVO (P_ID NUMBER, P_CANAL VARCHAR, P_ESTADO NUMBER, P_GASTO NUMBER, P_TIPORECONOCIMIENTO VARCHAR,
								P_OBSERVACION VARCHAR , P_MOTIVO VARCHAR, P_FINICIO DATE, P_FFIN DATE, P_USUARIO VARCHAR2,
                                P_COMPANIA VARCHAR2) AS

	begin

        FOR CLIENTE IN (SELECT CODIGOGRUPO, fechainicio, fechafin
                          FROM t_icom_inversion_cliente_g
                          where idinversion =P_ID AND (codigocanal   =P_CANAL or P_CANAL IS NULL
                            AND PK_ICOM_COMMONS.F_EJECUTIVONEGOCIADOR(
                                    P_CODIGOGRUPO => CODIGOGRUPO,
                                    P_USUARIO => P_USUARIO,
                                    P_COMPANIA => P_COMPANIA
                                    ) = 1 )
			                AND (NEGOCIACION IN (0,1)  OR ESTADO=1)) LOOP

              /*UPDATE t_icom_cliente_material SET NEGOCIACION= CASE WHEN P_ESTADO=2 THEN 0 ELSE 1 END
              WHERE idinversion=P_ID AND codigogrupo=CLIENTE.CODIGOGRUPO;*/

            IF(P_ESTADO=2) THEN --RECHAZO
                SP_RECHAZO_NEGOCIACION(P_ID =>P_ID,
                                        P_GRUPO =>CLIENTE.CODIGOGRUPO,
                                        P_MOTIVO =>P_MOTIVO);

            ELSE
                SP_GUARDAR(P_ID =>P_ID,
                            P_GRUPO =>CLIENTE.CODIGOGRUPO,
                            P_GASTOCOMPARTIDO =>P_GASTO,
                            P_RECONOCIMIENTO =>P_TIPORECONOCIMIENTO,
                            P_OBSERVACION =>P_OBSERVACION,
                            P_TIPO=>1);

                IF(P_FINICIO IS NOT NULL AND  P_FFIN IS NOT NULL )  THEN
                    if ( f_validaFechaMasivo (P_ID =>P_ID, P_IDGRUPO =>CLIENTE.CODIGOGRUPO, P_FEC_INI =>P_FINICIO, P_FEC_FIN =>P_FFIN,
                        P_GRUPOFEC_INI =>CLIENTE.fechainicio, P_GRUPOFEC_FIN =>CLIENTE.fechafin) = 1  ) then
                        SP_FECHA_INGRESO(P_ID  =>P_ID,
                                P_GRUPO  =>CLIENTE.CODIGOGRUPO,
                                P_DESDE  =>P_FINICIO,
                                P_HASTA  =>P_FFIN );
                    else
                        RAISE_APPLICATION_ERROR(-20000, 'Error las fechas estan fuera de rango');
                    end if;
                END IF;

            END IF;

        END LOOP;

   END SP_CAMBIOMASIVO;


    /*Funcion que valida las fechas por grupo retorna 1 en caso que validan*/
    Function f_validaFechaMasivo (P_ID NUMBER, P_IDGRUPO NUMBER, P_FEC_INI DATE, P_FEC_FIN DATE,
        P_GRUPOFEC_INI DATE, P_GRUPOFEC_FIN DATE) RETURN NUMBER AS
        v_return number := 1 ;
        v_diasAdicionales number ;
        v_cuenta number ;
        v_fechaMin date;
        V_fehcaMAx Date;
    BEGIN
        select
            FECHAINICIO - nvl(pk_commons.safe_to_number(PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '1', COMPANIA )),0) FECHAINICIO,
            FECHAFIN    + nvl(pk_commons.safe_to_number(PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '1', COMPANIA )),0)  FECHAFIN
        into v_fechaMin, V_fehcaMAx
        from t_icom_inversiones where id=p_id;

        if p_fec_ini is null or p_fec_fin is null then
            v_return := 0 ;
        elsif p_fec_ini < v_fechaMin or p_fec_ini > V_fehcaMAx
            or p_fec_fin < v_fechaMin or p_fec_fin> V_fehcaMAx then
            v_return := 0 ;
        end if;
        begin
            if v_return = 1 then
                --verifica que las fechas no existan
                select count(1) into v_cuenta
                from data.t_icom_cliente_fechas
                where idinversion = p_id and estado = 1
                and codigogrupo = p_idgrupo
                and ( trunc(p_fec_ini) between trunc(fechainicio) and trunc(fechafin)
                   or trunc(p_fec_fin) between trunc(fechainicio) and trunc(fechafin) ) ;

            end if;
        exception when no_Data_found then v_cuenta := 0 ;
        end ;
        if v_cuenta > 0 then
            v_return := 0 ;
        end if;
        return v_return ;
    END;

    /*Funcion que valida las fechas por inversion retorna 1 en caso que validan*/
    Function f_validaFechaInversion (P_ID NUMBER, P_CODIGOGRUPO varchar2 DEFAULT 0) RETURN NUMBER AS
        v_cuenta number := 0 ;
        v_diasAdicionales number ;
        v_fechaMin date;
        V_fehcaMAx Date;

    BEGIN

        select
            FECHAINICIO - nvl(pk_commons.safe_to_number(PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '1', COMPANIA )),0) FECHAINICIO,
            FECHAFIN    + nvl(pk_commons.safe_to_number(PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '1', COMPANIA )),0)  FECHAFIN
        into v_fechaMin, V_fehcaMAx
        from t_icom_inversiones where id=p_id;

        for inv in (select codigogrupo from data.t_icom_inversion_cliente_g
                    where idinversion = p_id
                    and codigogrupo = case when nvl(p_codigogrupo,0) = 0  then codigogrupo else p_codigogrupo end
                    and estado =1)
        loop

                select count(1) into v_cuenta
                from data.t_icom_cliente_fechas
                where idinversion = p_id and estado = 0
                and codigogrupo = inv.codigogrupo
                and ( fechainicio < v_fechaMin or fechainicio > V_fehcaMAx
                or fechafin < v_fechaMin or fechafin > V_fehcaMAx) ;

                if nvl(v_cuenta,0) > 1 then
                    return 0 ;
                end if;

        end loop;
        return 1 ;
    END;

    /*Procedimiento para actualizar el campo ESTADOMODIFICADO en la tabla T_ICOM_INVERSION_CLIENTE_G
      @param P_ID  				id de la inversion
	  @param P_GRUPO			id grupo cliente
    Autor: CCarrasco (NETBY)
	Fecha: Agosto 2022
	*/
   PROCEDURE SP_ACTUALIZA_ESTADOMODIFICADO(P_ID NUMBER, P_GRUPO VARCHAR) AS
    begin
		update data.T_ICOM_INVERSION_CLIENTE_G SET ESTADO=1
		where IDINVERSION = P_ID 	AND CODIGOGRUPO=P_GRUPO and ESTADO=0;

	end SP_ACTUALIZA_ESTADOMODIFICADO;


	/*Procedimiento para actualizar el campo ESTADOMODIFICADO en la tabla T_ICOM_INVERSION_CLIENTE_G
      @param P_ID  				id del contrato (tabla T_ICOM_CONTRATOS)
	  @param p_NOMBRE 			Nombre del contrato
	  @param p_TIPOINVERSION    Tipo de inversion
	  @param p_TIPOCONTRATO     Tipo de contrato
	  @param p_ESTADO           Estado del contrato
	  @param p_AUDITORIAFECHA   Fecha de auditoria
	  @param P_AUDITORIAUSUARIO Usuario creador del contrato

    Autor: CCarrasco (NETBY)
	Fecha: Agosto 2022
	*/


   /*Procedimiento que realiza la lÃ³gica de cambio de etapa (PROCESOS AUTOM??TICOS) de un contrato
    Autor: CCarrasco (NETBY)
	Fecha: Agosto 2022
	*/
   PROCEDURE SP_NE_CAMBIOESTADO AS
   v_CONTADOR NUMBER;
   begin

        --- NEGOCIACION -  IMPLEMENTACION
		FOR datos in (select c.idinversion, c.codigogrupo , c.NEGOCIACION
                from DATA.T_ICOM_INVERSION_CLIENTE_G c, DATA.T_ICOM_INVERSIONES t
                WHERE c.idinversion = t.id AND T.IDETAPA=2 AND c.NEGOCIACION IN (0,1)
                AND (t.FECHAFIN+nvl(pk_commons.safe_to_number(PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '1', T.COMPANIA )),0) )<sysdate)LOOP

           IF(datos.NEGOCIACION=0) THEN
                UPDATE DATA.T_ICOM_INVERSION_CLIENTE_G SET NEGOCIACION=2, ESTADO=0,
                MOTIVORECHAZO='Cliente sin negociar, sistema cancela de forma automÃ¡tica'
                WHERE IDINVERSION=datos.idinversion
                AND CODIGOGRUPO=datos.codigogrupo;

                DELETE  T_ICOM_CLIENTE_FECHAS WHERE ESTADO=0 AND CODIGOGRUPO=datos.codigogrupo AND IDINVERSION=datos.idinversion;
            ELSE
                UPDATE DATA.T_ICOM_INVERSION_CLIENTE_G SET NEGOCIACION=3, ESTADO=0
                WHERE IDINVERSION=datos.idinversion AND CODIGOGRUPO=datos.codigogrupo;
            END IF;

                --Verificar si todos los clientes estan con ESTADO=0
                select count(1) into v_contador
                from data.T_ICOM_INVERSION_CLIENTE_G
                where idinversion = datos.idinversion
                AND (estado != 0 OR NEGOCIACION not in (2,3) );

                --Solo si todos los clientes de la inversion estÃ¡n en estado 0 (APROBADO) se cambia la etapa de la inversion
                if 	v_contador = 0 then
                    update data.t_icom_inversiones SET idetapa = 3, estado=1
                    where id = datos.idinversion;
                    --crear la auditoria
                    PK_ICOM_COMMONS.SP_AUDITORIA(
                        P_USUARIO => 'PROCESO AUTOMATICO',
                        P_IDINVERSION => datos.idinversion,
                        P_IDETAPA => 3,
                        P_CODIGOGRUPO => datos.codigogrupo,
                        P_IDACCION => 1,
                        P_DESCRIPCION => 'CAMBIO A ETAPA NEGOCIACION - IMPLEMENTACION CUANDO TODOS LOS CLIENTES ESTAN APROBADOS'
                      );
                end if;

        END LOOP;

        --- IMPLEMENTACION - CLAUSURA
          FOR datos in (select c.idinversion, c.codigogrupo , c.NEGOCIACION
                from DATA.T_ICOM_INVERSION_CLIENTE_G c, DATA.T_ICOM_INVERSIONES t
                WHERE c.idinversion = t.id AND T.IDETAPA=3 AND c.NEGOCIACION = 2)LOOP

                SELECT COUNT(1) INTO v_CONTADOR FROM T_ICOM_INVERSION_CLIENTE_G
                WHERE idinversion=DATOS.idinversion AND NEGOCIACION NOT IN (2);

                IF(v_CONTADOR=0) THEN
                    UPDATE DATA.T_ICOM_INVERSIONES    SET ESTADO = 4,  IDETAPA = 4, IDETAPA2 = 6,
                    MOTIVOCLAUSURA='NINGUN CLIENTE ACEPTO'
                    WHERE ID = DATOS.idinversion;
                    --crear la auditoria
                    PK_ICOM_COMMONS.SP_AUDITORIA(
                        P_USUARIO => 'PROCESO AUTOMATICO',
                        P_IDINVERSION => datos.idinversion,
                        P_IDETAPA => 4,
                        P_CODIGOGRUPO => datos.codigogrupo,
                        P_IDACCION => 1,
                        P_DESCRIPCION => 'CAMBIO A ETAPA CIERRE CUANDO NINGUN CLIENTE ACEPTO'
                      );
                END IF;

        END LOOP;

        --- IMPLEMENTACION - VALIDACION
        FOR datos in (select c.idinversion, c.FECHAFIN, C.CODIGOGRUPO
                from DATA.T_ICOM_INVERSION_CLIENTE_G c, DATA.T_ICOM_INVERSIONES t
                WHERE c.idinversion = t.id AND T.IDETAPA=3 AND c.NEGOCIACION = 3
                GROUP BY idinversion, c.FECHAFIN  HAVING  MAX(C.FECHAFIN)<sysdate)LOOP

                 UPDATE DATA.T_ICOM_INVERSIONES    SET ESTADO = 1,  IDETAPA = 7
                    WHERE ID = DATOS.idinversion;
                 --crear la auditoria
                 PK_ICOM_COMMONS.SP_AUDITORIA(
                    P_USUARIO => 'PROCESO AUTOMATICO',
                    P_IDINVERSION => datos.idinversion,
                    P_IDETAPA => 7,
                    P_CODIGOGRUPO => DATOS.CODIGOGRUPO,
                    P_IDACCION => 1,
                    P_DESCRIPCION => 'CAMBIO A ETAPA IMPLEMENTACION - VALIDACION TODOS LOS CLIENTES NEGOCIADOS'
                  );
        END LOOP;



        FOR datos in ( SELECT ID FROM DATA.T_ICOM_INVERSIONES I
                    WHERE IDETAPA=3  AND NOT EXISTS (
                    SELECT 1 FROM T_ICOM_INVERSION_CLIENTE_G  WHERE IDINVERSION=I.ID) ) LOOP
           --crear la auditoria
           PK_ICOM_COMMONS.SP_AUDITORIA(
                    P_USUARIO => 'PROCESO AUTOMATICO',
                    P_IDINVERSION => datos.id,
                    P_IDETAPA => 4,
                    P_CODIGOGRUPO => NULL,
                    P_IDACCION => 1,
                    P_DESCRIPCION => 'CAMBIO A ETAPA IMPLEMENTACION - CIERRE NO TIENE CLIENTES'
                  );
        END LOOP;

        --- implementacion a cierre los que no tienen cliente
        UPDATE DATA.T_ICOM_INVERSIONES I   SET   IDETAPA = 4
                    WHERE IDETAPA=3  AND NOT EXISTS (
                    SELECT 1 FROM T_ICOM_INVERSION_CLIENTE_G  WHERE IDINVERSION=I.ID) ;


        --- VALIDACION - CIERRE
        ---- si no se valida se pasa a cierra


    end SP_NE_CAMBIOESTADO;

    /*Procedimiento que realiza la lÃ³gica de cambio de etapa (PROCESOS AUTOM??TICOS) de un contrato
    Autor: CCarrasco (NETBY)
	Fecha: Agosto 2022
	*/
   PROCEDURE SP_CAMBIARETAPA AS
   begin

        ---NEGOCIACION
		for datos in (select t.id
		from DATA.T_ICOM_INVERSIONES t
		WHERE t.idetapa = 2
		AND t.FECHAFIN<sysdate)
		loop
			null;
		end loop;

    end SP_CAMBIARETAPA;


   /*Procedimiento que se calendariza y se ejecuta todos los dÃ­as a las 8:00 AM
    Autor: CCarrasco (NETBY)
	Fecha: Agosto 2022
	*/
   PROCEDURE SP_NE_PROCESOS AS
   BEGIN

	 SP_NE_CAMBIOESTADO;
	 SP_CAMBIARETAPA;

   END SP_NE_PROCESOS;

   /*Funcion que identifica el tipo de negociacion realizada en la inversion
    Autor: NETBY3 (NETBY3)
	Fecha: Septiembre 2022
	*/
   FUNCTION F_IDENTIFICANEGOCIACION( P_ID NUMBER ) RETURN NUMBER
   AS
   v_tipoInversion NUMBER;
   BEGIN

   SELECT CASE
            WHEN FIRMACONTRATO IS NULL THEN 1
            WHEN FIRMACONTRATO = 1 THEN 2
            WHEN FIRMACONTRATO = 2 THEN 3
           END AS TIPO INTO v_tipoInversion
    FROM (
       SELECT inversion.ID, vista.IDINVERSIONTIPO, vista.FIRMACONTRATO
       FROM DATA.VT_ICOM_INVERSIONTIPO vista,
       T_ICOM_INVERSIONES inversion
       WHERE vista.IDINVERSIONTIPO = inversion.IDINVERSIONTIPO
       AND inversion.ID = P_ID
   );

   RETURN v_tipoInversion;
   END  F_IDENTIFICANEGOCIACION;

    /*Busca el id de las tablas generales en base a la cabecera y la descripcion, si no ecuentra pone blanco*/
    FUNCTION F_BUSCAID_UDC ( P_IDCABECERA VARCHAR2, P_DESCRIPCION VARCHAR2,P_COMPANIA VARCHAR2) RETURN VARCHAR2  AS
        v_idtabla data.t_corp_udc.id_tabla%type;
    BEGIN
       V_IDTABLA := '';
       select id_tabla into v_idtabla
       from data.T_CORP_UDC where upper(trim(ID_CABECERA)) = upper(trim(p_idcabecera))
       AND ACTIVO='1'  and upper(trim(descripcion)) = upper(trim(p_descripcion)) AND CODIGOCOMPANIA=P_COMPANIA and rownum = 1 ;
       RETURN V_IDTABLA;
    EXCEPTION WHEN NO_DATA_FOUND THEN
        return '';
    END F_BUSCAID_UDC ;

    /*Valida los materiales de la inversion subidos desde archivo excel
    JAsanza
    */
    PROCEDURE sp_validaclientematerial (
        p_id       NUMBER,
        p_negociar NUMBER
    ) AS

        v_max number := 500 ;
        v_grupos varchar2(500);
        v_error varchar2(4500);
        v_diasAdicionales number ;
        v_fechainicio date;
        v_fechafin date;
        v_diasinicio date;
        v_cuenta number ;
        TYPE typ_varray IS VARRAY(20) OF VARCHAR2(250);
        v_listaerror     typ_varray;
        CURSOR  c_error IS
            SELECT descripcion
            FROM data.VT_ICOM_ERRORVALIDACION_MP
            where estado = '1'
            ORDER BY  to_number(id) ;
        v_counter   NUMBER :=  1;
    BEGIN
        --fecha para asignar dato de fecha en Excel
        v_diasinicio := to_date('1899-12-30', 'YYYY-MM-DD');
        --Busco los dÃ­as adicionales
        --busco las fechas de la inversion
        select fechainicio, fechafin,COMPANIA
        into v_fechainicio, v_fechafin,v_COMPANIA
        from data.t_icom_inversiones
        where id = P_id;
        v_diasAdicionales:= nvl(pk_commons.safe_to_number(PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '1', v_COMPANIA )),0);

        --treae la lista de errores
        v_listaerror      :=    typ_varray();
        FOR i IN c_error LOOP
            v_listaerror.EXTEND;
            v_listaerror(v_counter)  :=  i.descripcion;
            EXIT WHEN c_error%notfound ;  ---Limitamos el LOOP a solo 5 vueltas.
            v_counter :=  v_counter+1;
        END LOOP;

        if (p_negociar = 0) then --en caso de que sea en propuesta
            begin
                --se valida que exista al menos un canal, grupo o cliente
                update DATA.VT_APEX_EXCEL
                set C16 = v_listaerror(1),
                    C17 = 1
                where
                ( TRIM(C02) IS NULL /*CANAL*/ AND TRIM(C03) IS NULL /*GRUPO*/ AND TRIM(C04) IS NULL /*CLIENTE*/);

                --se valida que no esten ingresados dos codigos en la misma linea
                update DATA.VT_APEX_EXCEL
                set
                    C16 = v_listaerror(2),
                    C17 = 1
                WHERE
                ( TRIM(c02) IS NOT NULL /*CANAL*/ AND TRIM(c03) IS NOT NULL  /*GRUPO*/ AND TRIM(c04) IS NULL )       /*CLIENTE*/
                OR ( TRIM(c02) IS NOT NULL /*CANAL*/ AND TRIM(c03) IS NULL      /*GRUPO*/ AND TRIM(c04) IS NOT NULL )   /*CLIENTE*/
                OR ( TRIM(c02) IS NULL     /*CANAL*/ AND TRIM(c03) IS NOT NULL  /*GRUPO*/ AND TRIM(c04) IS NOT NULL     /*CLIENTE*/ );

                --se valida en caso de elegir canal que al menos exista un codigo de grupo en la inversion
                update DATA.VT_APEX_EXCEL
                set
                    C16 = case when C16 is null then v_listaerror(3) else C16||'; '||v_listaerror(3) end,
                    C17 = 1
                WHERE
                TRIM(c02) IS NOT NULL /*CANAL*/
                AND NOT EXISTS (
                    SELECT 1 FROM data.t_icom_inversion_cliente_g
                    WHERE idinversion = p_id
                    AND codigogrupo IN ( SELECT DISTINCT codigogrupo FROM data.vt_gzm_cliente WHERE upper(TRIM(canal)) = upper(TRIM(c02)) )
                );

                --se valida en caso de elegir grupo que exista en la inversion
                update DATA.VT_APEX_EXCEL
                SET
                    c16 = CASE WHEN c16 IS NULL THEN v_listaerror(4) ELSE c16 || '; ' || v_listaerror(4) END,
                    c17 = 1
                WHERE
                TRIM(c03) IS NOT NULL /*grupo*/
                AND NOT EXISTS (
                    SELECT 1 FROM data.t_icom_inversion_cliente_g
                    WHERE idinversion = p_id
                    AND codigogrupo = TRIM(c03)
                );

                --se valida en caso de elegir cliente que exista en la inversion
                update DATA.VT_APEX_EXCEL
                SET
                    c16 = CASE WHEN c16 IS NULL THEN v_listaerror(5) ELSE c16 || '; ' || v_listaerror(5) END,
                    c17 = 1
                WHERE
                TRIM(c04) IS NOT NULL /*cliente*/
                AND NOT EXISTS (
                    SELECT 1 FROM data.t_icom_inversion_cliente
                    WHERE idinversion = p_id
                    AND codigocliente = TRIM(c04)
                );

                --se valida en caso de que exista los codigos PDV
                update DATA.VT_APEX_EXCEL
                SET
                    c16 = CASE WHEN c16 IS NULL THEN v_listaerror(6) ELSE c16 || '; ' || v_listaerror(6) END,
                    c17 = 1
                WHERE nvl(TRIM(c05), '0') != '0' /*PDV*/
                AND NOT EXISTS (
                    SELECT 1 FROM data.t_trad_clientelocal
                    WHERE estado = 1 AND TIPOVISITA  =1 and to_char(codigopdv) || '-' || to_char(numero) = TRIM(c05)
                );

                --se valida el material
                update DATA.VT_APEX_EXCEL
                SET
                    c16 = CASE WHEN c16 IS NULL THEN v_listaerror(7) ELSE c16 || '; ' || v_listaerror(7) END,
                    c17 = 1
                WHERE
                ( TRIM(c08) IS NOT NULL
                AND NOT EXISTS (
                    SELECT 1 FROM data.vt_icom_materialpop m
                    WHERE TRIM(m.descripcion) = TRIM(upper(TRIM(c08))) AND m.estado = '1'  AND M.COMPANIA=V_COMPANIA
                )
                ) OR ( TRIM(c08) IS NULL );

                --se valida las fechas de la inversion
                v_error:= v_listaerror(8)||'FI: '||TO_CHAR(v_fechainicio - v_diasadicionales, 'DD/MM/YYYY')
                ||'FF: '||TO_CHAR(v_fechafin + v_diasadicionales, 'DD/MM/YYYY');
                update DATA.VT_APEX_EXCEL
                SET
                    c16 = CASE WHEN c16 IS NULL THEN v_error ELSE c16 || '; ' ||v_error END,
                    c17 = 1
                WHERE
                ( TRIM(c10) IS NOT NULL
                AND TRIM(c11) IS NOT NULL
                AND ( ( v_diasinicio + c10 ) < TRUNC(v_fechainicio - v_diasadicionales)
                OR ( v_diasinicio + c10 ) > TRUNC(v_fechafin + v_diasadicionales)  /*FECHAINICIO*/
                OR ( v_diasinicio + c11 ) < TRUNC(v_fechainicio - v_diasadicionales)
                OR ( v_diasinicio + c11 ) > TRUNC(v_fechafin + v_diasadicionales) )
                )
                OR ( TRIM(c10) IS NULL OR TRIM(c11) IS NULL );

                --se valida la cantidad
                update DATA.VT_APEX_EXCEL
                SET
                    c16 = CASE WHEN c16 IS NULL THEN v_listaerror(9) ELSE c16 || '; ' || v_listaerror(9) END,
                    c17 = 1
                WHERE
                nvl(round(replace(c12, '.', ','), 4), 0) <= 0;

                --valida que no exista informacion igual en el archivo
                update DATA.VT_APEX_EXCEL a
                SET
                    c16 = CASE WHEN c16 IS NULL THEN v_listaerror(10) ELSE c16 || '; ' || v_listaerror(10) END,
                    c17 = 1
                WHERE
                EXISTS (
                    SELECT 1 FROM data.vt_apex_excel b
                    WHERE a.c01 != b.c01
                    AND nvl(TRIM(a.c02), '0') = nvl(TRIM(b.c02), '0')
                    AND nvl(TRIM(a.c03), '0') = nvl(TRIM(b.c03), '0')
                    AND nvl(TRIM(a.c04), '0') = nvl(TRIM(b.c04), '0')
                    AND nvl(TRIM(a.c05), '0') = nvl(TRIM(b.c05), '0')
                    AND a.c10 = b.c10
                    AND a.c11 = b.c11
                    AND nvl(TRIM(a.c08), '0') = nvl(TRIM(b.c08), '0')
                );

            end;
        elsif (p_negociar = 1 ) then --en caso de negociacion
            begin
                --Se realiza las verficaciones solo para los nuevos
                --verificamos que exista los codigos de grupo
                UPDATE VT_APEX_EXCEL a  SET c10 = pk_commons.safe_to_date(a.c10)-v_diasinicio where pk_commons.F_ESNUMERO(a.c10)!=1;
                UPDATE VT_APEX_EXCEL a  SET c11 = pk_commons.safe_to_date(a.c11)-v_diasinicio where pk_commons.F_ESNUMERO(a.c11)!=1;


                update DATA.VT_APEX_EXCEL
                SET c19 = v_listaerror(4),
                    c20 = 1
                WHERE --upper(TRIM(c16)) = 'SI' AND /*Debe insertar solo los nuevos negociados*/
                nvl(TRIM(c17), '1') = '1'  /*Actualizacion Negociacion */
                AND ( (( TRIM(c02) IS NOT NULL
                        AND NOT EXISTS (
                            SELECT 1 FROM data.t_icom_inversion_cliente_g WHERE idinversion = p_id AND codigogrupo = TRIM(c02)
                            )
                        )
                    OR TRIM(c02) IS NULL
                    )
                    OR NOT EXISTS ( SELECT 1 FROM data.t_icom_cliente_material WHERE idinversion = p_id AND codigogrupo = TRIM(c02) ) /*Tiene el grupo al menos uno existente*/
                );

                --verificamos que existan todos los materiales
                update DATA.VT_APEX_EXCEL
                SET
                    c19=    CASE WHEN c19 IS NULL THEN v_listaerror(7) || ' Material: ' || TRIM(c07) ELSE   c19 || '; ' || v_listaerror(7) || ' Material: ' || TRIM(c07) END,
                    c20 = 1
                WHERE --upper(TRIM(c16)) = 'SI' AND/*Debe insertar solo los nuevos negociados*/
                nvl(TRIM(c17), '1') = '1'  /*Actualizacion Negociacion*/
                AND ( ( TRIM(c07) IS NOT NULL
                AND NOT EXISTS ( SELECT 1 FROM data.vt_icom_materialpop m WHERE TRIM(m.descripcion) = TRIM(upper(TRIM(c07) ) ) AND m.estado = '1'  AND M.COMPANIA=V_COMPANIA)
                )
                OR TRIM(c07) IS NULL
                );

                --se valida en caso de que exista los codigos PDV
                update DATA.VT_APEX_EXCEL
                SET
                    c19 = CASE WHEN c19 IS NULL THEN v_listaerror(6) ELSE c19 || '; ' || v_listaerror(6) END,
                    c20 = 1
                WHERE --upper(TRIM(c16)) = 'SI' AND--Debe insertar solo los nuevos negociados
                nvl(TRIM(c17), '1') = '1'  --Actualizacion Negociacion
                AND nvl(TRIM(c04), '0') != '0' --PDV
                AND NOT EXISTS ( SELECT 1 FROM data.t_trad_clientelocal WHERE estado = 1 AND to_char(codigopdv) || '-' || to_char(numero) = TRIM(c04) );

                --se valida las fechas de la inversion
                v_error:= v_listaerror(8)||'FI: '||TO_CHAR(v_fechainicio - v_diasadicionales, 'DD/MM/YYYY')
                ||'FF: '||TO_CHAR(v_fechafin + v_diasadicionales, 'DD/MM/YYYY');
                update DATA.VT_APEX_EXCEL
                SET
                    c19 = CASE WHEN c19 IS NULL THEN v_error ELSE c19 || '; ' || v_error END,
                    c20 = 1
                WHERE --upper(TRIM(c16)) = 'SI' AND --Debe insertar solo los nuevos negociados
                nvl(TRIM(c17), '1') = '1'  --Actualizacion Negociacion
                AND ( TRIM(c10) IS NOT NULL
                AND TRIM(c11) IS NOT NULL
                AND ( ( v_diasinicio + c10 ) < v_fechainicio - v_diasadicionales
                OR ( v_diasinicio + c10 ) > v_fechafin + v_diasadicionales --FECHAINICIO
                OR ( v_diasinicio + c11 ) < v_fechainicio - v_diasadicionales
                OR ( v_diasinicio + c11 ) > v_fechafin + v_diasadicionales ) )  --FECHAFIN
                OR ( TRIM(c10) IS NULL
                OR TRIM(c11) IS NULL );

                --se valida la cantidad
                update DATA.VT_APEX_EXCEL
                SET
                    c19 = CASE WHEN c19 IS NULL THEN v_listaerror(9) ELSE c19 || '; ' || v_listaerror(9) END,
                    c20 = 1
                WHERE --upper(TRIM(c16)) = 'SI' AND --Debe insertar solo los nuevos negociados
                nvl(TRIM(c17), '1') = '1'  --Actualizacion Negociacion
                AND nvl(round(replace(c12, '.', ','), 4), 0) <= 0;

                --valida que no exista informacion igual insertada
                update DATA.VT_APEX_EXCEL
                SET
                    c19 = CASE WHEN c19 IS NULL THEN v_listaerror(10) ELSE c19 || '; ' || v_listaerror(10) END,
                    c20 = 1
                WHERE
                -- upper(TRIM(c16)) = 'SI' and --Debe insertar solo los nuevos negociados
                nvl(TRIM(c17), '1') = '1'  --Actualizacion Negociacion
                AND EXISTS (
                    SELECT 1 FROM data.t_icom_cliente_material
                    WHERE idinversion = p_id
                    AND codigogrupo = TRIM(c02)
                    AND codigopdv = nvl(TRIM(c04), '0')
                    AND upper(TRIM(descripcion)) = upper(TRIM(c07))
                    AND fechainicio = ( v_diasinicio + c10 )
                    AND fechafin = ( v_diasinicio + c11 )
                    AND negociacion = 1
                    AND nvl(formato, '0') = nvl(TRIM(c08), '0')
                );

                --valida que no exista informacion igual en el archivo
                update DATA.VT_APEX_EXCEL a
                SET
                    c19 = CASE WHEN c19 IS NULL THEN v_listaerror(10) ELSE c19 || '; ' || v_listaerror(10) END,
                    c20 = 1
                WHERE --upper(TRIM(c16)) = 'SI' and--Debe insertar solo los nuevos negociados
                nvl(TRIM(c17), '1') = '1' --Actualizacion Negociacion
                AND EXISTS (
                    SELECT 1 FROM data.vt_apex_excel b
                    WHERE a.c01 != b.c01
                    AND TRIM(a.c02) = TRIM(b.c02)
                    AND nvl(TRIM(a.c04), '0') = nvl(TRIM(b.c04), '0')
                    AND upper(TRIM(a.c07)) = upper(TRIM(b.c07))
                    AND a.c10 = b.c10
                    AND a.c11 = b.c11
                    AND nvl(TRIM(c17), '1') = '1'
                    AND nvl(TRIM(a.c08), '0') = nvl(TRIM(b.c08), '0')
                );

            end;
        elsif (p_negociar = 2) then    --validar el total de asiganacion
            begin

                 select count(1)
                into v_cuenta from t_icom_inversiones where id=P_id and idetapa>1 ;

                if (v_cuenta<=0) then
                    return;
                end if;

                select count(1)
                into v_cuenta
                from
                ( select codigogrupo, sum(nvl(total,0)) neg_total from data.t_icom_cliente_material where idinversion = P_id and negociacion = 1 group by codigogrupo) negocia,
                ( select codigogrupo, sum(nvl(total,0)) tip_total from data.t_icom_cliente_material where idinversion = P_id and tipo = 0 group by codigogrupo ) tipo
                where negocia.codigogrupo = tipo.codigogrupo
                and tipo.tip_total < negocia.neg_total ;

                if nvl(v_cuenta,0) > 0 then
                    SELECT CASE WHEN MAX(total) > v_max
                        THEN LISTAGG(nombres, '; ') WITHIN GROUP( ORDER BY nombres ) || '...'
                        ELSE LISTAGG(nombres, '; ') WITHIN GROUP( ORDER BY nombres ) END
                    INTO v_grupos
                    FROM
                    ( /*Se obtinie los grupos y sus dimenciones para controlar el maximo permitido*/
                        SELECT negocia.codigogrupo||': Propuesta '||tip_total|| ' Negociado: '||neg_total nombres,
                            SUM(lengthb(negocia.codigogrupo) + 2)/*Se aÃ±ade 2 por los caracteres especiales.*/
                            OVER( ORDER BY negocia.codigogrupo ) cuenta,
                            SUM(lengthb(negocia.codigogrupo) + 2) OVER() total
                        FROM(
                            SELECT codigogrupo, SUM(nvl(total, 0)) neg_total
                            FROM data.t_icom_cliente_material
                            WHERE idinversion = p_id AND negociacion = 1 GROUP BY codigogrupo
                        ) negocia,
                        (
                            SELECT codigogrupo,SUM(nvl(total, 0)) tip_total
                            FROM data.t_icom_cliente_material
                            WHERE idinversion = p_id AND tipo = 0
                            GROUP BY codigogrupo
                        ) tipo
                        WHERE negocia.codigogrupo = tipo.codigogrupo
                        AND tipo.tip_total < negocia.neg_total
                    )
                    WHERE cuenta <= v_max;

                    raise_application_error(-20100, v_listaerror(11)
                    || v_grupos);
                end if;

                SELECT COUNT(1)
                INTO v_cuenta
                FROM (
                    SELECT codigogrupo, SUM(nvl(total, 0)) tip_total
                    FROM data.t_icom_cliente_material m
                    WHERE idinversion = p_id
                    AND negociacion = 1  and  m.codigogrupo is not null
                    AND NOT EXISTS (
                        SELECT 1 FROM data.t_icom_cliente_material cm
                        WHERE idinversion = p_id AND m.codigogrupo = cm.codigogrupo AND tipo = 0
                    )
                    GROUP BY codigogrupo
                ) tipo
                WHERE tipo.tip_total > 0;

                IF nvl(v_cuenta, 0) > 0 THEN
                    SELECT CASE
                            WHEN MAX(total) > v_max THEN LISTAGG(nombres, '; ') WITHIN GROUP( ORDER BY nombres ) || '...'
                            ELSE LISTAGG(nombres, '; ') WITHIN GROUP( ORDER BY nombres )
                        END
                        INTO v_grupos
                    FROM( /*Se obtinie los grupos y sus dimenciones para controlar el maximo permitido*/
                        SELECT
                            negocia.codigogrupo||': Negociacion '||negocia.tip_total nombres,
                            SUM(lengthb(negocia.codigogrupo) + 2)/*Se aÃ±ade 2 por los caracteres especiales.*/OVER( ORDER BY negocia.codigogrupo )cuenta,
                            SUM(lengthb(negocia.codigogrupo) + 2) OVER() total
                        FROM (
                            SELECT codigogrupo, SUM(nvl(total, 0)) tip_total
                            FROM data.t_icom_cliente_material m
                            WHERE idinversion = p_id AND negociacion = 1 and  m.codigogrupo is not null
                            AND NOT EXISTS (
                                SELECT 1 FROM data.t_icom_cliente_material cm
                                WHERE idinversion = p_id AND m.codigogrupo = cm.codigogrupo AND tipo = 0
                            )
                            GROUP BY codigogrupo
                        ) negocia
                        WHERE negocia.tip_total > 0
                    )
                    WHERE cuenta <= v_max;

                    raise_application_error(-20100, v_listaerror(12) || v_grupos);
                END IF;

            end;
        end if;   --fin de ver si es ingreso o negociacion

    END SP_ValidaClienteMaterial;

    /*PK_ICOM_NEGOCIACION.F_FechasAprobadas(P_ID=>1945, P_CODIGOGRUPO=>7888)*/
    FUNCTION F_FechasAprobadas(P_ID NUMBER, P_CODIGOGRUPO VARCHAR2)  RETURN NUMBER
    as
    v_contador number := 0;
    begin
        select count(1) into v_contador from t_icom_cliente_fechas
        WHERE idinversion=P_ID AND codigogrupo=P_CODIGOGRUPO AND ESTADO=1;

        return v_contador;
    end F_FechasAprobadas;

    /*Ingresa los materiales de la inversion de forma masiva*/
   PROCEDURE SP_CLIENTEMATERIAL(P_ID NUMBER, P_NEGOCIAR NUMBER ) AS
    v_cuenta number ;
    v_cantidad number ;
    v_precio number;
    v_diasAdicionales number ;
    v_fechainicio date;
    v_fechafin date;
    v_idmaterial data.vt_icom_materialpop.id%type;
    v_clasificacion data.vt_icom_materialpop.clasificacion%type;
    v_diasinicio date;
    v_material varchar2(500);
    v_esreplanificacion number:=0;

    BEGIN
        --fecha para asignar dato de fecha en Excel
        v_diasinicio := to_date('1899-12-30', 'YYYY-MM-DD');
        --Busco los dÃ­as adicionales
        --busco las fechas de la inversion
        select fechainicio, fechafin, COMPANIA
        into v_fechainicio, v_fechafin,V_COMPANIA
        from data.t_icom_inversiones
        where id = P_id;
        v_diasAdicionales :=nvl(pk_commons.safe_to_number(PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '1', V_COMPANIA )),0);

        --valida si es replanificacion
        begin
            SELECT count(distinct 1) into v_esreplanificacion FROM t_icom_inversiones WHERE ID =P_ID and IDPADRE is not null;
        exception when others then
            v_esreplanificacion :=0;
        end;

        if (p_negociar = 0) then
        begin
            --Para el ingreso de los materiales se tienen 3 casos posibles
            --Por Canal
            for canal in (
                SELECT
                    UPPER(TRIM(C02)) CANAL,
                    TRIM(C07)  FORMATO,
                    UPPER(TRIM(C08)) MATERIAL,
                    TRIM(C09)  IMPLEMENTA,
                    (v_diasinicio + C10)  FECHAINICIO,
                    (v_diasinicio + C11)  FECHAFIN,
                    ROUND(REPLACE(C12, '.', ','),4)  CANTIDAD,
                    ROUND(REPLACE(C13, '.', ','),4)  PRECIO,
                    TRIM(C14)  OBSERVACION
                FROM DATA.VT_APEX_EXCEL
                WHERE 1=1
                and TRIM(C02) IS NOT NULL --CANAL
                AND TRIM(C10) IS NOT NULL AND (v_diasinicio + C10) BETWEEN v_FECHAINICIO-v_diasAdicionales AND v_FECHAFIN+v_diasAdicionales --FECHAINICIO
                AND TRIM(C11) IS NOT NULL AND (v_diasinicio + C11) BETWEEN v_FECHAINICIO-v_diasAdicionales AND v_FECHAFIN+v_diasAdicionales --FECHAFIN
                AND NVL(ROUND(REPLACE(C12, '.', ','),4),0) > 0 --CANTIDAD
                --AND NVL(ROUND(REPLACE(C13, '.', ','),2),0) > 0 --PRECIO
                AND EXISTS ( SELECT 1  FROM DATA.T_ICOM_INVERSION_CLIENTE_G WHERE IDINVERSION=P_ID AND CODIGOGRUPO IN ( SELECT DISTINCT CODIGOGRUPO FROM DATA.VT_GZM_CLIENTE WHERE UPPER(TRIM(CANAL)) = UPPER(TRIM(C02)) ) )
            )
            loop

                --Buscamos todos los grupos que pertenecen al canal
                v_cuenta := 0 ;
                select count(1) into v_cuenta
                from DATA.T_ICOM_INVERSION_CLIENTE_G
                where IDINVERSION=P_ID
                and CODIGOGRUPO IN ( SELECT DISTINCT CODIGOGRUPO FROM DATA.VT_GZM_CLIENTE WHERE UPPER(TRIM(CANAL)) = canal.canal ) ;
                v_cantidad := round(canal.cantidad/v_cuenta,4);
                --busco el codigo de material y la clasificacion
                begin
                    select id, clasificacion
                    into v_idmaterial, v_clasificacion
                    from data.vt_icom_materialpop
                    where descripcion = UPPER(TRIM(canal.material))
                     AND COMPANIA=V_COMPANIA
                    and estado = '1' ;
                exception when no_data_found then
                    v_idmaterial := '0' ;
                end;
                if nvl(v_idmaterial,'0' ) != '0' then
                    INSERT INTO DATA.T_ICOM_CLIENTE_MATERIAL(IDINVERSION,CODIGOGRUPO,IDMATERIAL,DESCRIPCION,CANTIDAD,COSTO,CLASIFICACION,IMPLEMENTACION,FECHAINICIO,FECHAFIN,OBSERVACIONES,CODIGOPDV,FORMATO,ESTADO )
                        select
                            P_ID  IDINVERSION
                            ,codigogrupo CODIGOGRUPO
                            ,v_idmaterial IDMATERIAL
                            ,canal.material DESCRIPCION
                            ,v_cantidad CANTIDAD
                            ,canal.precio COSTO
                            ,v_clasificacion CLASIFICACION
                            ,PK_ICOM_NEGOCIACION.f_buscaid_udc('ICOM_MATIM', canal.implementa,V_COMPANIA) IMPLEMENTACION
                            ,canal.fechainicio FECHAINICIO
                            ,canal.fechafin FECHAFIN
                            ,canal.observacion OBSERVACIONES
                            ,'0' CODIGOPDV
                            ,canal.formato FORMATO
                            ,v_esreplanificacion ESTADO
                        from DATA.T_ICOM_INVERSION_CLIENTE_G
                        where IDINVERSION=P_ID
                        and CODIGOGRUPO IN ( SELECT DISTINCT CODIGOGRUPO FROM DATA.VT_GZM_CLIENTE WHERE UPPER( TRIM(CANAL) )=canal.canal ) ;
                else
                    raise_application_error(-20100, 'Error el material '||UPPER(TRIM(canal.material))||' no existe.');
                end if;

            end loop;

            --Por Grupo, no se debe hacer ningun calculo adicional solo se copia la informacion
            INSERT INTO DATA.T_ICOM_CLIENTE_MATERIAL(IDINVERSION,CODIGOGRUPO,IDMATERIAL,DESCRIPCION,CANTIDAD,COSTO,CLASIFICACION,IMPLEMENTACION,FECHAINICIO,FECHAFIN,OBSERVACIONES,CODIGOPDV,CANTIDADPDV,FORMATO,ESTADO )
            SELECT
                P_ID IDINVERSION ,
                TRIM(C03) CODIGOGRUPO,
                M.ID IDMATERIAL,
                UPPER(TRIM(C08))DESCRIPCION,
                ROUND(REPLACE(C12, '.', ','),4)CANTIDAD,
                ROUND(REPLACE(C13, '.', ','),4)COSTO,
                M.CLASIFICACION CLASIFICACION,
                PK_ICOM_NEGOCIACION.f_buscaid_udc('ICOM_MATIM',TRIM(C09) ,V_COMPANIA)IMPLEMENTACION,
                (v_diasinicio + C10)FECHAINICIO,
                (v_diasinicio + C11)FECHAFIN,
                TRIM(C14)OBSERVACIONES,
                NVL(TRIM(C05),'0')CODIGOPDV,
                NVL(ROUND(REPLACE(C06, '.', ','),4),0)CANTIDADPDV,
                TRIM(C07)FORMATO,
                v_esreplanificacion ESTADO
            FROM DATA.VT_APEX_EXCEL  E
            INNER JOIN DATA.VT_ICOM_MATERIALPOP M ON ( M.DESCRIPCION = UPPER(TRIM(C08)) AND M.ESTADO = '1'  AND M.COMPANIA=V_COMPANIA)
            WHERE 1=1
            and TRIM(C03) IS NOT NULL --CODIGOGRUPO
            AND TRIM(C10) IS NOT NULL AND  (v_diasinicio + C10)  BETWEEN v_FECHAINICIO-v_diasAdicionales AND v_FECHAFIN+v_diasAdicionales --FECHAINICIO
            AND TRIM(C11) IS NOT NULL AND  (v_diasinicio + C11)  BETWEEN v_FECHAINICIO-v_diasAdicionales AND v_FECHAFIN+v_diasAdicionales--FECHAFIN
            AND NVL(ROUND(REPLACE(C12, '.', ','),4),0) > 0 --CANTIDAD
            --AND NVL(ROUND(REPLACE(C13, '.', ','),2),0) > 0 --PRECIO
            AND EXISTS ( SELECT 1 FROM DATA.T_ICOM_INVERSION_CLIENTE_G WHERE IDINVERSION=P_ID AND CODIGOGRUPO=TRIM(C03) )
                ;

            --Por Cliente, se debe sumar todos los valores por grupo siempre que los cliente esten en la inversion,
            --en caso de existir los pdv tambien se suma solo de los que existan
            INSERT INTO DATA.T_ICOM_CLIENTE_MATERIAL(IDINVERSION,CODIGOGRUPO,IDMATERIAL,DESCRIPCION,CANTIDAD,COSTO,CLASIFICACION,IMPLEMENTACION,FECHAINICIO,FECHAFIN,OBSERVACIONES,CODIGOPDV,CANTIDADPDV,FORMATO,ESTADO   )
            SELECT
                P_ID IDINVERSION,
                c.codigogrupo CODIGOGRUPO,
                M.ID IDMATERIAL,
                UPPER(TRIM(C08)) DESCRIPCION,
                sum(ROUND(REPLACE(C13, '.', ','),4))CANTIDAD,
                AVG(ROUND(REPLACE(C14, '.', ','),4))COSTO,
                M.CLASIFICACION CLASIFICACION,
                min(PK_ICOM_NEGOCIACION.f_buscaid_udc('ICOM_MATIM', C09,V_COMPANIA ))IMPLEMENTACION,
                min(v_diasinicio + C10)FECHAINICIO,
                max(v_diasinicio + C11)FECHAFIN,
                max(TRIM(C14))OBSERVACIONES,
                NVL(TRIM(C05),'0')CODIGOPDV,
                sum(NVL(ROUND(REPLACE(C06, '.', ','),4),0))CANTIDADPDV,
                max(TRIM(C07))FORMATO,
                v_esreplanificacion ESTADO
            FROM DATA.VT_APEX_EXCEL v
                inner join data.t_icom_inversion_cliente c on ( p_id = c.idinversion and  trim(C04) = c.codigocliente )
                left join data.t_icom_cliente_pdv p on (c.idinversion = p.idinversion and c.codigogrupo = p.codigogrupo
                                                        and trim(C05) is not null and trim(C05)= p.codigopdv
                                                        and NVL(ROUND(REPLACE(C06, '.', ','),4),0) > 0 )
                INNER JOIN DATA.VT_ICOM_MATERIALPOP M ON ( M.DESCRIPCION = UPPER(TRIM(C08)) AND M.ESTADO = '1' AND M.COMPANIA=V_COMPANIA)
            WHERE TRIM(C04) IS NOT NULL --CODIGOCLIENTE
                AND TRIM(C10) IS NOT NULL AND  (v_diasinicio + C10) BETWEEN v_FECHAINICIO-v_diasAdicionales AND v_FECHAFIN+v_diasAdicionales --FECHAINICIO
                AND TRIM(C11) IS NOT NULL AND  (v_diasinicio + C11) BETWEEN v_FECHAINICIO-v_diasAdicionales AND v_FECHAFIN+v_diasAdicionales --FECHAFIN
                AND NVL(ROUND(REPLACE(C12, '.', ','),4),0) > 0 --CANTIDAD
                --AND NVL(ROUND(REPLACE(C13, '.', ','),2),0) > 0 --PRECIO
                AND EXISTS ( SELECT 1 FROM data.t_icom_inversion_cliente WHERE IDINVERSION=P_ID AND trim(C04) = codigocliente )
            GROUP BY P_ID, c.codigogrupo,  M.ID,  UPPER(TRIM(C08)), M.CLASIFICACION,
                     TRIM(C05)      ;
        end;
        elsif (p_negociar = 1 ) then
        begin
            --se debe actualizar los valores de las negociaciones de material POP
            --solo se actulizan los valores de negociacion y estado
            UPDATE data.t_icom_cliente_material cm
            set (negociacion , observaciones , estado)
            =(
                select
                    case when upper(trim(C16)) IN ('SI', 'S??') then 1 else 0 end negociacion
                    ,TRIM(C15) observaciones
                    ,v_esreplanificacion estado
                from data.VT_APEX_EXCEL v
                inner join data.vt_icom_materialpop m on (m.descripcion = upper(trim(c07)) and m.estado = '1' AND COMPANIA=V_COMPANIA)
                where TRIM(C02) IS NOT NULL --CODIGOGRUPO
                and ( UPPER(TRIM(C16)) in ('SI','S??', 'NO') AND TRIM(C17) = '0')
                and cm.codigogrupo = TRIM(C02)
                and cm.codigopdv = TRIM(C04)
                and cm.idmaterial = M.ID
                and nvl(cm.FORMATO, 0) = nvl(TRIM(C08),0)
                AND CM.FECHAINICIO=(v_diasinicio + C10)
                AND	CM.FECHAFIN=(v_diasinicio + C11)
            )
            where  1=1
            and cm.idinversion = P_ID
            and nvl(cm.negociacion, -1)  = -1
            and cm.tipo=0
            and  EXISTS (
                SELECT 1 from data.VT_APEX_EXCEL v
                inner join data.vt_icom_materialpop m on (m.descripcion = upper(trim(c07)) and m.estado = '1' AND M.COMPANIA=V_COMPANIA)
                where TRIM(C02) IS NOT NULL --CODIGOGRUPO
                and  ( UPPER(TRIM(C16)) in ('SI', 'S??','NO') AND TRIM(C17) = '0')  --Actualizacion
                and cm.codigogrupo = TRIM(C02)
                and cm.codigopdv = TRIM(C04)
                and cm.idmaterial = M.ID
                and nvl(cm.FORMATO, 0) = nvl(TRIM(C08),0)
                AND CM.FECHAINICIO=(v_diasinicio + C10)
                AND	CM.FECHAFIN=(v_diasinicio + C11)
            );
            --raise_application_error(-20100, 'Despues del update'||SQLCODE||' -ERROR- '||SQLERRM );
            COMMIT;

            --Se busca los valores que son nuevos para insertar
            INSERT INTO DATA.T_ICOM_CLIENTE_MATERIAL(IDINVERSION,CODIGOGRUPO,IDMATERIAL,DESCRIPCION,CANTIDAD,COSTO,CLASIFICACION,IMPLEMENTACION,FECHAINICIO,FECHAFIN,OBSERVACIONES,CODIGOPDV,CANTIDADPDV,NEGOCIACION,TIPO,ESTADO,FORMATO )
                SELECT
                    P_ID IDINVERSION,
                    TRIM(C02) CODIGOGRUPO,
                    M.ID IDMATERIAL,
                    TRIM(C07)DESCRIPCION,
                    ROUND(REPLACE(C12, '.', ','),4) CANTIDAD,
                    ROUND(REPLACE(C13, '.', ','),4) COSTO,
                    M.CLASIFICACION CLASIFICACION,
                    PK_ICOM_NEGOCIACION.f_buscaid_udc('ICOM_MATIM', C10 ,V_COMPANIA) IMPLEMENTACION,
                    (v_diasinicio + C10) FEC_INICIO,
                    (v_diasinicio + C11) FEC_FIN,
                    TRIM(C15) OBSERVACION,
                    TRIM(C04) CODIGOPDV,
                    ROUND(REPLACE(C05, '.', ','),4) CANTIDADPDV,
                    1 NEGOCIACION,
                    1 TIPO,
                    v_esreplanificacion ESTADO,
                TRIM(C08) FORMATO
                FROM DATA.VT_APEX_EXCEL E
                INNER JOIN DATA.VT_ICOM_MATERIALPOP M ON ( M.DESCRIPCION = UPPER(TRIM(C07)) AND M.ESTADO = '1' AND M.COMPANIA=V_COMPANIA )
                WHERE TRIM(C02) IS NOT NULL --CODIGOGRUPO
                AND TRIM(C10) IS NOT NULL AND (v_diasinicio + C10) BETWEEN V_FECHAINICIO-v_diasAdicionales AND V_FECHAFIN+v_diasAdicionales --FECHAINICIO
                AND TRIM(C11) IS NOT NULL AND (v_diasinicio + C11) BETWEEN V_FECHAINICIO-v_diasAdicionales AND V_FECHAFIN+v_diasAdicionales--FECHAFIN
                --AND UPPER(TRIM(C16)) IN ('SI', 'S??') --Debe insertar solo los nuevos negociados
                AND TRIM(NVL(C17,1)) =1  --Actualizacion Negociacion
                AND NVL(ROUND(REPLACE(C12, '.', ','),4),0) > 0 --CANTIDAD
                --AND NVL(ROUND(REPLACE(C13, '.', ','),2),0) > 0 --PRECIO
                AND EXISTS ( SELECT 1 FROM DATA.T_ICOM_CLIENTE_MATERIAL WHERE IDINVERSION=P_ID AND CODIGOGRUPO=TRIM(C02)  ) --Tiene el grupo al menos uno existente
            ;
        end;

        end if;   --fin de ver si es ingreso o negociacion
    END SP_CLIENTEMATERIAL;
    /*Procedimeinto para eliminar el material pop*/
    /* @p_idinversion
       @p_etapa para saber 0 etapa de propuesta,  1 etapa de negociacion, 5 etapa de replanificacion
       @p_ejecutivo para saber si es ejecutivo = 1 o 0 caso contrario
       @p_negociador para saber si es negociador = 1 o 0 caso contrario
    */
    PROCEDURE SP_VACIARMATERIALPOP ( P_IDINVERSION NUMBER , P_ETAPA NUMBER, P_EJECUTIVO NUMBER, P_NEGOCIADOR NUMBER, P_USUARIO VARCHAR2,P_REPLANIFICA NUMBER DEFAULT 0,P_GRUPO VARCHAR2 DEFAULT null) AS
    BEGIN
        --BORRA PARA LAS ETAPAS DE PROPUESTA Y NEGOCIACION
        delete data.T_ICOM_CLIENTE_MATERIAL
        where 1=1
        and idinversion = p_idinversion
        and tipo = p_etapa
        and (
                nvl(estado,0) = 0
            OR
                P_REPLANIFICA=1
            )
        and codigogrupo in (
            select CODIGOGRUPO
            from data.VT_ICOM_INVERSION_CLIENTE
            where idinversion = p_idinversion
            and  (codigogrupo=p_grupo or p_grupo is null )
            and (
                    (p_ejecutivo = 1  AND ejecutivo in (select numeroidentificacion from data.VT_CORP_USUARIO where nombreusuario= p_usuario) )  --- SI ES EJECUTIVO SOLO MUESTRA SUS CLIENTES
                OR
                    p_negociador = 1 --- PERMISO PARA NEGOCIAR SIN SER EJECUTIVO
                )
            AND (
                    ESTADONEGOCIACION IN (0,1)  -- ESTADOS PARA NEGOCIAR
                OR
                    P_REPLANIFICA=1
                /*OR
                    nvl(estado,0)=1*/
                )
            AND ( nvl(estado,0) in (0,1) )
          );
        if p_etapa = 1 then --etapa de negociacion
            --actualiza el estado de negociacion de los que fueron insertados en la propuesta
            update data.T_ICOM_CLIENTE_MATERIAL set negociacion = -1
            where idinversion = p_idinversion
            and (
                    tipo = 0
                OR
                    P_REPLANIFICA=1
                /*and
                    nvl(estado,0)=0*/
                )
            and codigogrupo in (
                select CODIGOGRUPO
                from data.VT_ICOM_INVERSION_CLIENTE
                where idinversion = p_idinversion
                and  (codigogrupo=p_grupo or p_grupo is null )
                and (
                        (p_ejecutivo = 1  AND ejecutivo in (select numeroidentificacion from data.VT_CORP_USUARIO where nombreusuario= p_usuario) )  --- SI ES EJECUTIVO SOLO MUESTRA SUS CLIENTES
                    OR
                        p_negociador = 1
                    )--- PERMISO PARA NEGOCIAR SIN SER EJECUTIVO
                AND (
                        ESTADONEGOCIACION IN (0,1)
                    OR
                        P_REPLANIFICA=1
                    /*OR
                        nvl(estado,0)=1*/
                    )
                AND nvl(estado,0) in (0,1)  -- ESTADOS PARA NEGOCIAR
              )  ;
        elsif p_etapa = 5 then --etapa de replanificacicion
            --borrar los que no han sido aprobados con permiso de negociador o coordinar todos los clientes
            delete data.T_ICOM_CLIENTE_MATERIAL
            where idinversion = p_idinversion --and  tipo = p_etapa
            and nvl(estado,0) = 0 ;

        end if;

    END SP_VACIARMATERIALPOP;

    PROCEDURE SP_AGREGARMATERIAL( P_ID NUMBER, P_CODIGOGRUPO VARCHAR2, P_IDMATERIAL VARCHAR2, P_DESCRIPCION VARCHAR2,
        P_CANTIDAD NUMBER, P_ESTADO NUMBER, P_COSTO NUMBER, P_NEGOCIACION NUMBER, P_TIPO NUMBER, P_CODIGOPDV VARCHAR2,
        P_CANTIDADPDV NUMBER, P_CLASIFICACION VARCHAR2, P_MEDIBLE NUMBER, P_IMPLEMENTACION VARCHAR, P_FECHAINICIO DATE,
        P_FECHAFIN DATE, P_OBSERVACIONES VARCHAR2, P_FORMATO VARCHAR2, P_MODO NUMBER DEFAULT 0 )   AS
    BEGIN
        IF P_MODO = 1 THEN --INSERTA
            --Se inserta los valores
            INSERT INTO T_ICOM_CLIENTE_MATERIAL
            (IDINVERSION, CODIGOGRUPO, IDMATERIAL, DESCRIPCION, CANTIDAD, ESTADO, COSTO, NEGOCIACION, TIPO, CODIGOPDV,
             CANTIDADPDV, CLASIFICACION, MEDIBLE, IMPLEMENTACION, FECHAINICIO, FECHAFIN, OBSERVACIONES, FORMATO)
            VALUES
            (P_ID, P_CODIGOGRUPO, P_IDMATERIAL, P_DESCRIPCION, P_CANTIDAD, P_ESTADO, P_COSTO, P_NEGOCIACION, P_TIPO, P_CODIGOPDV,
             P_CANTIDADPDV, P_CLASIFICACION, P_MEDIBLE, P_IMPLEMENTACION, P_FECHAINICIO, P_FECHAFIN, P_OBSERVACIONES, P_FORMATO);
        ELSIF P_MODO = 2 THEN --ACTUALIZA
            --Se actualiza
            UPDATE T_ICOM_CLIENTE_MATERIAL
            SET CANTIDAD = P_CANTIDAD, COSTO = P_COSTO
            WHERE IDINVERSION = P_ID AND CODIGOGRUPO = P_CODIGOGRUPO AND IDMATERIAL = P_IDMATERIAL
            AND CODIGOPDV = P_CODIGOPDV AND IDMATERIAL = P_IDMATERIAL AND FECHAINICIO = P_FECHAINICIO
            AND FECHAFIN = P_FECHAFIN AND NEGOCIACION = P_NEGOCIACION AND FORMATO = P_FORMATO ;

        END IF;
    END SP_AGREGARMATERIAL ;

    /*Agrega la negociacion de fechas por dÃ­as de la semana*/
    PROCEDURE SP_FechaDiaSemana( P_ID NUMBER, P_GRUPO VARCHAR2, P_DESDE DATE,
        P_HASTA DATE, P_DIA NUMBER, P_TIPOLOCAL VARCHAR2, P_ESTABLECIMINETO VARCHAR2,
        P_PORCENTAJE NUMBER DEFAULT NULL,P_TIPO_DESCUENTO VARCHAR2 DEFAULT NULL,P_DESCCRIPCION VARCHAR2 DEFAULT NULL) AS
        v_cuenta number;
    BEGIN
        --vemos las fechas de acuerdo al dÃ­a seleccionado
        for fecha in ( select dia from ( select P_DESDE + level - 1 dia from   dual connect by level <= (  P_HASTA - P_DESDE  + 1) )
                       where to_number(TO_CHAR(dia, 'D')) = P_DIA ) loop

            --validamos que la fecha no se encuentre activa para el cliente
            select count(1) into v_cuenta from t_icom_cliente_fechas
            where idinversion=P_ID and codigogrupo=P_GRUPO
            and estado = 1
            and fecha.dia between fechainicio and fechafin ;

            if nvl(v_cuenta,0) = 0 then
                --inserta la fecha
                SP_FECHA_INGRESO(P_ID => P_ID,
                                 P_GRUPO => P_GRUPO,
                                 P_DESDE => fecha.dia,
                                 P_HASTA => fecha.dia,
                                 P_TIPOLOCAL => P_TIPOLOCAL,
                                 P_ESTABLECIMINETO => P_ESTABLECIMINETO,
                                 P_REPLANIFICADO => 0,
                                 P_PORCENTAJE =>P_PORCENTAJE ,
                                 P_TIPO_DESCUENTO =>P_TIPO_DESCUENTO ,
                                 P_DESCCRIPCION =>P_DESCCRIPCION
                                 );
            else
                v_cuenta := 0 ;
            end if;
        end loop;
    END SP_FechaDiaSemana;

    /*Procedimeinto para generacion de las encuestas */
    /* @P_IDINVERSION numero de inversion para la que se genera el cuestionario
       @P_CODIGOGRUPO para saber a cual cliente es la encuesta
       @P_COMPANIA compania a la que pertenece la encuesta
       @P_MENSAJE variable de retorno para saber si existen errores
    */
    PROCEDURE SP_INVERSION_ENCUENTAS_DESCUENTO(P_IDINVERSION NUMBER,P_CODIGOGRUPO VARCHAR2 DEFAULT NULL,
                                               P_COMPANIA VARCHAR2,P_MENSAJE OUT VARCHAR2) AS
        V_NOMBREGRUPO VARCHAR2(500);
        V_IDTEMPLATE NUMBER;
        V_NOMBRE_TEMPLATE VARCHAR2(3999);
        V_USUARIO VARCHAR2(50);
        V_NOMBRECUESTIONARIO VARCHAR2(3999);
        V_NOMBREINVERSION VARCHAR2(3999);
        V_VALIDACION01 NUMBER;
        V_VALIDACION02 NUMBER;
        V_VALIDACION03 NUMBER;
        V_VALIDACION04 NUMBER;
        V_VALIDACION05 NUMBER;
        V_VALIDACION06 NUMBER;
        V_IDCUESTIONARIO NUMBER;
        V_ESTADO NUMBER:=0;
    BEGIN
        V_USUARIO :='ICOM';
        /*
        SE TOMAN LOS DATOS LAS FECHAS PARA GENERAR LAS ENCUESTAS CON EL TEMPLATE DISEÃ‘ADO POR OPERACIONES COMERCIALES
        */
        FOR  T_DATOS IN (
            SELECT
            F.*,
            ROW_NUMBER() OVER (PARTITION BY IDINVERSION ORDER BY f.CODIGOGRUPO DESC)  ID1,
            (SELECT C.NOMBRES FROM VT_ICOM_INVERSION_CLIENTE C WHERE C.CODIGOGRUPO=F.CODIGOGRUPO AND ROWNUM=1)NOMBREGRUPO,
            (SELECT ID_TEMPLATE FROM VT_ICOM_ENCUESTA_TEMPLATE WHERE ID_TIPO_ENCUESTA =1 )  IDTEMPLATE
            FROM T_ICOM_CLIENTE_FECHAS F
            WHERE ENCUESTA=0 AND ESTADO =0 AND IDINVERSION=P_IDINVERSION  AND (CODIGOGRUPO=P_CODIGOGRUPO OR P_CODIGOGRUPO IS NULL)
            and (nvl(TIPOLOCAL,'0')!='0' or nvl(DESCUENTO,0)!=0)
            and exists (
                select 1 FROM T_ENCT_CUESTIONARIOS WHERE TIPO = 2 AND ESTADO = 1  AND COMPANIA = P_COMPANIA AND IDCUESTIONARIO=
                    (SELECT ID_TEMPLATE FROM VT_ICOM_ENCUESTA_TEMPLATE WHERE ID_TIPO_ENCUESTA =1)
            )
            order by f.numero
        )
        LOOP

            SELECT IDCUESTIONARIO||' - '||NOMBRE INTO V_NOMBRE_TEMPLATE
                FROM T_ENCT_CUESTIONARIOS WHERE TIPO = 2 AND ESTADO = 1  AND COMPANIA = P_COMPANIA
                                            AND IDCUESTIONARIO=T_DATOS.IDTEMPLATE;

            /*SE RECUPERA EL NOMBRE DE LA INVERSION*/
            SELECT ID||' - '||NOMBRE INTO V_NOMBREINVERSION FROM VT_ICOM_INVERSIONES
                                                            WHERE ID=T_DATOS.IDINVERSION   AND COMPANIA = P_COMPANIA  AND IDETAPA IN (2,3,4,7) AND ROWNUM=1;

            /*SE RECUPERA EL NOMBRE DE LA ENCUESTA FORMATO % + CATEGORIA + MARCA + SUBMARCA + CONTEO(AGRUPADO)*/
            FOR T_PRODUCTO IN (
                SELECT
                    LISTAGG(DISTINCT NOMBRE||' '||PRESENTACION, ', ') WITHIN GROUP (ORDER BY  NOMBRE||' '||PRESENTACION) PRODUCTO
                FROM(
                    SELECT
                        A.IDINVERSION,
                        B.CATEGORIA||' - '||B.MARCA||CASE WHEN B.SUBMARCA='SIN SUB-MARCA' THEN ' ' ELSE ' - '||TO_CHAR(B.SUBMARCA)END NOMBRE,
                        LISTAGG(DISTINCT B.PRESENTACION,'/')WITHIN GROUP (ORDER BY B.PRESENTACION) PRESENTACION
                    FROM T_ICOM_INVERSION_PRODUCTO A
                    INNER JOIN VT_JDE_PRODUCTOS B ON A.CODIGOPRODUCTO= B.CODIGOPRODUCTO
                    INNER JOIN TABLE(PK_COMMONS.F_DIVIDIRTEXTO(T_DATOS.PRODUCTOS,',') ) C ON  TRIM(A.CODIGOPRODUCTO)= TRIM(C.ITEM)
                    WHERE A.IDINVERSION=T_DATOS.IDINVERSION
                    AND B.SUBMARCA IS NOT NULL
                    GROUP BY A.IDINVERSION,B.CATEGORIA,B.MARCA,B.SUBMARCA
                )
            )
            LOOP
                /***************************************************/
                V_NOMBRECUESTIONARIO:='';
                /*SE VALIDA QUE EL CUESTIONARIO A SER CREADO NO EXISTA DENTRO DE LA BASE*/
                SELECT
                    COUNT(DISTINCT 1),
                    LISTAGG(DISTINCT IDCUESTIONARIO ,',') WITHIN GROUP (ORDER BY IDCUESTIONARIO) IDCUESTIONARIO
                INTO V_VALIDACION04,V_VALIDACION03
                FROM T_ENCT_CUESTIONARIOS
                WHERE REFERENCIAID =T_DATOS.IDINVERSION
                AND   FECHADESDE =T_DATOS.FECHAINICIO AND FECHAHASTA =T_DATOS.FECHAFIN
                  AND CODIGOCLIENTE =T_DATOS.CODIGOGRUPO
                  and nombre=T_DATOS.DESCUENTO||'% '||T_PRODUCTO.PRODUCTO ;

                /***************************************************/
                /*SI NO EXISTE EN LA BASE SE PROCEDE A LA CREACIÃ“N*/
                IF (V_VALIDACION04=0)THEN

                    /*SE RECUPERA EL NOMBRE DEL TEMPLATE DE LA ENCUESTA*/
                    V_IDCUESTIONARIO:=NULL;

                    /*SEGÃšN EL TEMPLATE SE REALIZA LA COPIA DE LA ENCUESTA Y SE RECUPERA EL NUEVO ID DE LA ENCUESTA*/

                    PK_ENCT_CUESTIONARIO.SP_CUESTIONARIOCOPIA(P_ID => T_DATOS.IDTEMPLATE,P_IDNEW => V_IDCUESTIONARIO,P_USUARIO =>V_USUARIO,P_COMPANIA => P_COMPANIA);

                    /*SE RECUPERA EL NOMBRE DE LA ENCUESTA FORMATO % + CATEGORIA + MARCA + SUBMARCA + CONTEO(AGRUPADO)*/
                    V_NOMBRECUESTIONARIO :=T_DATOS.DESCUENTO||'% '||T_PRODUCTO.PRODUCTO;

                    PK_ENCT_CUESTIONARIO.SP_CUESTIONARIOGUARDAR(
                        P_ID => V_IDCUESTIONARIO ,
                        P_TIPO => 1,/*{1:NORMAL,2:TEMPLATE}*/
                        P_IDGRUPO =>  NULL,
                        P_NOMBRE => V_NOMBRECUESTIONARIO,
                        P_REFERENCIATABLA =>'INVERSION',/*{PRODUCTO_COMPETENCIA:PRODUCTO COMPETENCIA,CODIGOPDV:Punto de Venta,PRODUCTO:PRODUCTO,INVERSION:INVERSIONES COMERCIALES,CLIENTE:CLIENTES}*/
                        P_REFERENCIAID => T_DATOS.IDINVERSION ,
                        P_REFERENCIADESCRIPCION => V_NOMBREINVERSION,
                        P_REFERENCIAPOBLACION => 'PUNTOVENTA',/*{EMPLEADO:EMPLEADOS,PUNTOVENTA:PUNTOS DE VENTA}*/
                        P_FRECUENCIA => 1,/*{0:UNA VEZ,1:DIARIA,7:SEMANAL,15:QUINCENAL}*/
                        P_FECHADESDE => T_DATOS.FECHAINICIO,
                        P_FECHAHASTA =>T_DATOS.FECHAFIN,
                        P_TIPOEJECUCION => 1,/*{1:Movil Mella,2:Correo,3:Portal}*/
                        P_USUARIOCREACION => V_USUARIO,
                        P_ESTADO => 1,
                        P_COMPANIA => P_COMPANIA  ,P_CODIGOCLIENTE=>T_DATOS.CODIGOGRUPO
                    );


                    /*SE INSERTA LOS DATOS DE LA POBLACION A LA QUE VA DIRIGIDO LA ENCUESTA*/
                    INSERT INTO T_ENCT_CUESTIONARIOPERSONAS ( IDCUESTIONARIO, IDPERSONA, DESCRIPCION, CORREO, NUMERO )
                            SELECT  V_IDCUESTIONARIO IDCUESTIONARIO,
                                    TO_CHAR(CL.CODIGOPDV||'-'||CL.NUMERO) CODIGOPDV,
                                    RAZON_SOCIAL,
                                    cl.EMAIL correo,
                                    0 numero
                            FROM T_TRAD_CLIENTELOCAL CL
                            INNER JOIN T_TRAD_CLIENTE C ON (C.CODIGOPDV=CL.CODIGOPDV)
                            left join  (select distinct codigopdv, RUC, RAZON_SOCIAL, tipoidentificacion  from t_trad_clienteruc where es_principal = 1)r on c.codigopdv = r.codigopdv
                            WHERE
                            (
                                    ( T_DATOS.CODIGOGRUPO IN (5100,58321) AND CODIGOGRUPO IS NULL AND T_DATOS.TIPOLOCAL IS NULL)
                                OR
                                    (CODIGOGRUPO=T_DATOS.CODIGOGRUPO AND NOMBRECOMERCIAL IN (SELECT ITEM  FROM TABLE(PK_COMMONS.F_DIVIDIRTEXTO(T_DATOS.TIPOLOCAL,':') ) ) )
                            )

                            AND cl.TIPOVISITA  =1
                            group by TO_CHAR(CL.CODIGOPDV||'-'||CL.NUMERO), RAZON_SOCIAL,cl.EMAIL;
                        COMMIT;

                ELSE
                    /* de haber algun error se procede a almacenarlo para retornarlo en la variable p_mensaje*/
                    P_MENSAJE :=P_MENSAJE||'<li>'||V_VALIDACION03||': ['||T_DATOS.FECHAINICIO||' - '||T_DATOS.FECHAFIN||'], cliente '||T_DATOS.NOMBREGRUPO||'</li>';
                    --DBMS_OUTPUT.PUT_LINE('SP_INVERSION_ENCUENTAS_DESCUENTO:'||P_MENSAJE);
                END IF;
            END LOOP;
            END LOOP;

            IF (P_MENSAJE IS NOT NULL) THEN
                P_MENSAJE :='Encuesta(s) ya existente(s):<ul>'||P_MENSAJE ||'</ul>';
            END IF;

        END SP_INVERSION_ENCUENTAS_DESCUENTO;

    /*Procedimeinto para generacion de las encuestas */


    /* @P_IDINVERSION numero de inversion para la que se genera el cuestionario
       @P_CODIGOGRUPO para saber a cual cliente es la encuesta
       @P_COMPANIA compania a la que pertenece la encuesta
       @P_MENSAJE variable de retorno para saber si existen errores
    */
    PROCEDURE SP_INVERSION_ENCUENTAS_EXIBICION(P_IDINVERSION NUMBER,P_CODIGOGRUPO VARCHAR2 DEFAULT NULL,P_COMPANIA VARCHAR2,P_MENSAJE OUT VARCHAR2) AS
        V_NOMBREGRUPO VARCHAR2(500);
        V_IDTEMPLATE NUMBER;
        V_NOMBRE_TEMPLATE VARCHAR2(3999);
        V_USUARIO VARCHAR2(50);
        V_NOMBRECUESTIONARIO VARCHAR2(3999);
        V_NOMBREINVERSION VARCHAR2(3999);
        V_VALIDACION01 NUMBER;
        V_VALIDACION02 NUMBER;
        V_VALIDACION03 NUMBER;
        V_VALIDACION04 NUMBER;
        V_VALIDACION05 NUMBER;
        V_VALIDACION06 NUMBER;
        V_IDCUESTIONARIO NUMBER;
        V_ESTADO NUMBER:=0;
    BEGIN
        V_USUARIO :='ICOM';

        /*SE VALIDA QUE LOS DATOS DE MATERIAL POP SEAN MEDIBLES Y QUE SEAN ATADOS A UN CODIGOPDV*/
        SELECT COUNT(DISTINCT 1) INTO V_VALIDACION01 FROM T_ICOM_CLIENTE_MATERIAL WHERE IDINVERSION=P_IDINVERSION AND MEDIBLE =1 AND NVL(CODIGOPDV,'0')!='0';
        IF (V_VALIDACION01=0)THEN
            P_MENSAJE :=P_MENSAJE||'<li>'||'No Existe informacion de Material PoP</li>';

        END IF;
        /*SE VALIDA QUE LOS PROCESO OPERATIVOS "PARAMETRIZACIÃ“N EN MV DE MATERIAL POP","PARAMETRIZACIÃ“N EN MV EXHIBICIONES CONTRATADAS" SEAN ACTIVOS PARA LA INVERSION*/
        SELECT COUNT(DISTINCT 1) INTO V_VALIDACION02
        FROM VT_ICOM_PROCESO A INNER JOIN T_ICOM_INVERSION_PROCESO P
        ON A.IDPROCESO=P.IDPROCESO WHERE IDINVERSION=P_IDINVERSION
        AND A.ESTADO=1 AND p.IDPROCESO IN (12,3);
        IF (V_VALIDACION02=0)THEN
            P_MENSAJE :=P_MENSAJE||'<li>'||'Los proceso operativos "PARAMETRIZACIÃ“N EN MV DE MATERIAL POP","PARAMETRIZACIÃ“N EN MV EXHIBICIONES CONTRATADAS" no son activos'||'</li>';
        END IF;

        /*SI UNA DE LAS 2 VALIDACIONES SON VERDADERAS SE RETORNA UN ERROR EN EL PARAMETRO P_MENSAJE*/
        IF (P_MENSAJE IS NOT NULL) THEN  P_MENSAJE :='<ul>'||P_MENSAJE ||'</ul>';
            --DBMS_OUTPUT.PUT_LINE('P_MENSAJE:'||P_MENSAJE);
            RETURN;
        END IF;

        /*
            SE TOMAN LOS DATOS LAS FECHAS PARA GENERAR LAS ENCUESTAS CON EL TEMPLATE DISEÃ‘ADO POR OPERACIONES COMERCIALES
        */



        FOR  T_DATOS IN (
            WITH
            T_MATERIAL AS (
                SELECT DISTINCT
                    M.IDINVERSION, CODIGOGRUPO,M.IDMATERIAL,M.DESCRIPCION,M.CODIGOPDV,M.FECHAINICIO FECHAINICIO,M.FECHAFIN FECHAFIN,P.NOMBRECOMERCIAL,
                    (SELECT ID_TEMPLATE FROM VT_ICOM_ENCUESTA_TEMPLATE WHERE ID_TIPO_ENCUESTA =2) IDTEMPLATE
                FROM T_ICOM_CLIENTE_MATERIAL M
                INNER JOIN VT_ICOM_MATERIALPOP P ON M.IDMATERIAL=P.ID AND P.COMPANIA=P_COMPANIA
                WHERE 1=1
                AND M.IDINVERSION  =P_IDINVERSION
                AND NEGOCIACION=1
                AND (CODIGOGRUPO=P_CODIGOGRUPO OR P_CODIGOGRUPO IS NULL)
                AND NVL(P.MEDIBLE,'0')!=0
                AND NVL(M.CODIGOPDV,0)!='0'
                AND EXISTS (
                    select 1 FROM T_ENCT_CUESTIONARIOS WHERE TIPO = 2 AND ESTADO = 1  AND COMPANIA = P_COMPANIA AND IDCUESTIONARIO=
                        (SELECT ID_TEMPLATE FROM VT_ICOM_ENCUESTA_TEMPLATE WHERE ID_TIPO_ENCUESTA =2)
                )

            )
            SELECT
                ROW_NUMBER() OVER (PARTITION BY IDINVERSION ORDER BY CODIGOGRUPO DESC)  ID1,
                T.IDINVERSION,T.CODIGOGRUPO,T.IDMATERIAL,T.DESCRIPCION,
                (SELECT C.NOMBRES FROM VT_ICOM_INVERSION_CLIENTE C WHERE C.CODIGOGRUPO=T.CODIGOGRUPO AND ROWNUM=1)NOMBREGRUPO,
                LISTAGG(DISTINCT T.CODIGOPDV,',') WITHIN GROUP (ORDER BY T.CODIGOPDV) CODIGOPDV,T.FECHAINICIO,T.FECHAFIN,T.IDTEMPLATE, NULL DESCUENTO,
                LISTAGG(DISTINCT T.NOMBRECOMERCIAL ,',') WITHIN GROUP (ORDER BY T.NOMBRECOMERCIAL) PRODUCTOS,
                (select LISTAGG(DISTINCT P.LINEANEGOCIO ||' ' ||P.MARCA,',') WITHIN GROUP (ORDER BY P.LINEANEGOCIO, P.MARCA) CATEGORIA  from VT_GZM_PRODUCTO P INNER JOIN t_icom_inversion_producto IP ON (IP.CODIGOPRODUCTO=P.CODIGOPRODUCTO AND P.COMPANIA = P_COMPANIA) WHERE IDINVERSION=T.IDINVERSION AND P.SUBMARCA IS NOT NULL)CATEGORIA
            FROM T_MATERIAL T
            GROUP BY T.IDINVERSION,T.CODIGOGRUPO,T.IDMATERIAL,T.DESCRIPCION,T.FECHAINICIO,T.FECHAFIN,T.IDTEMPLATE
         )
         LOOP
            V_NOMBRECUESTIONARIO:='';
            /*SE VALIDA QUE EL CUESTIONARIO A SER CREADO NO EXISTA DENTRO DE LA BASE*/
            SELECT
                COUNT(DISTINCT 1),
                LISTAGG(DISTINCT IDCUESTIONARIO ,',') WITHIN GROUP (ORDER BY IDCUESTIONARIO) IDCUESTIONARIO
            INTO V_VALIDACION04,V_VALIDACION03
            FROM T_ENCT_CUESTIONARIOS
            WHERE REFERENCIAID =T_DATOS.IDINVERSION
            AND   FECHADESDE =T_DATOS.FECHAINICIO AND FECHAHASTA =T_DATOS.FECHAFIN AND CODIGOCLIENTE =T_DATOS.CODIGOGRUPO and NOMBRE=(TRIM(T_DATOS.PRODUCTOS)||' '||T_DATOS.CATEGORIA);

            /*SI NO EXISTE EN LA BASE SE PROCEDE A LA CREACIÃ“N*/
            IF (V_VALIDACION04=0)THEN

                /*SE RECUPERA EL NOMBRE DEL TEMPLATE DE LA ENCUESTA*/
                SELECT IDCUESTIONARIO||' - '||NOMBRE INTO V_NOMBRE_TEMPLATE  FROM T_ENCT_CUESTIONARIOS WHERE TIPO = 2 AND ESTADO = 1  AND COMPANIA = P_COMPANIA AND IDCUESTIONARIO=T_DATOS.IDTEMPLATE;


                /*SE RECUPERA EL NOMBRE DE LA INVERSION*/
                SELECT ID||' - '||NOMBRE INTO V_NOMBREINVERSION FROM VT_ICOM_INVERSIONES WHERE ID=T_DATOS.IDINVERSION   AND COMPANIA = P_COMPANIA  AND IDETAPA IN (2,3,4,7) AND ROWNUM=1;

                V_IDCUESTIONARIO:=NULL;

                /*SEGÃšN EL TEMPLATE SE REALIZA LA COPIA DE LA ENCUESTA Y SE RECUPERA EL NUEVO ID DE LA ENCUESTA*/
                PK_ENCT_CUESTIONARIO.SP_CUESTIONARIOCOPIA(P_ID => T_DATOS.IDTEMPLATE,P_IDNEW => V_IDCUESTIONARIO,P_USUARIO =>V_USUARIO,P_COMPANIA => P_COMPANIA);

                /*SE RECUPERA EL NOMBRE DE LA ENCUESTA FORMATO NOMBRE COMERCIAL POP+ LINEA NEGOCIO+ MARCA */
                V_NOMBRECUESTIONARIO := TRIM(T_DATOS.PRODUCTOS)||' '||T_DATOS.CATEGORIA;

                PK_ENCT_CUESTIONARIO.SP_CUESTIONARIOGUARDAR(
                    P_ID => V_IDCUESTIONARIO ,
                    P_TIPO => 1,/*{1:NORMAL,2:TEMPLATE}*/
                    P_IDGRUPO =>  NULL,
                    P_NOMBRE => V_NOMBRECUESTIONARIO,
                    P_REFERENCIATABLA =>'INVERSION',/*{PRODUCTO_COMPETENCIA:PRODUCTO COMPETENCIA,CODIGOPDV:Punto de Venta,PRODUCTO:PRODUCTO,INVERSION:INVERSIONES COMERCIALES,CLIENTE:CLIENTES}*/
                    P_REFERENCIAID => T_DATOS.IDINVERSION ,
                    P_REFERENCIADESCRIPCION => V_NOMBREINVERSION,
                    P_REFERENCIAPOBLACION => 'PUNTOVENTA',/*{EMPLEADO:EMPLEADOS,PUNTOVENTA:PUNTOS DE VENTA}*/
                    P_FRECUENCIA => 1,/*{0:UNA VEZ,1:DIARIA,7:SEMANAL,15:QUINCENAL}*/
                    P_FECHADESDE => T_DATOS.FECHAINICIO,
                    P_FECHAHASTA =>T_DATOS.FECHAFIN,
                    P_TIPOEJECUCION => 1,/*{1:Movil Mella,2:Correo,3:Portal}*/
                    P_USUARIOCREACION => V_USUARIO,
                    P_ESTADO => 1,
                    P_COMPANIA => P_COMPANIA  ,P_CODIGOCLIENTE=>T_DATOS.CODIGOGRUPO
                );

                /*SE INSERTA LOS DATOS DE LA POBLACION A LA QUE VA DIRIGIDO LA ENCUESTA*/
                INSERT INTO T_ENCT_CUESTIONARIOPERSONAS ( IDCUESTIONARIO, IDPERSONA, DESCRIPCION, CORREO, NUMERO)
                    with pdv as (SELECT V_IDCUESTIONARIO IDCUESTIONARIO,
                                TO_CHAR(CL.CODIGOPDV||'-'||CL.NUMERO) CODIGOPDV,
                                RAZON_SOCIAL,
                                cl.EMAIL correo,
                                0 numero
                            FROM T_TRAD_CLIENTELOCAL CL
                            INNER JOIN T_TRAD_CLIENTE C ON (C.CODIGOPDV=CL.CODIGOPDV)
                            left join  (select distinct codigopdv, RUC, RAZON_SOCIAL, tipoidentificacion  from t_trad_clienteruc where es_principal = 1)r on c.codigopdv = r.codigopdv
                            WHERE
                            (( T_DATOS.CODIGOGRUPO IN (5100,58321) AND C.CODIGOGRUPO IS NULL) --- TRADICIONAL
                            OR (C.CODIGOGRUPO=T_DATOS.CODIGOGRUPO ))      AND cl.TIPOVISITA  =1
                            --CODIGOGRUPO=T_DATOS.CODIGOGRUPO AND TIPOVISITA  =1
                            group by TO_CHAR(CL.CODIGOPDV||'-'||CL.NUMERO), RAZON_SOCIAL,cl.EMAIL
                    )
                    ,mpop as (
                            SELECT DISTINCT M.CODIGOPDV,CODIGOGRUPO,IDINVERSION
                            FROM T_ICOM_CLIENTE_MATERIAL M
                            INNER JOIN VT_ICOM_MATERIALPOP P ON M.IDMATERIAL=P.ID AND P.COMPANIA=P_COMPANIA
                            WHERE 1=1
                            AND M.ESTADO=0
                            AND M.IDINVERSION  =T_DATOS.IDINVERSION
                            AND (CODIGOGRUPO=T_DATOS.CODIGOGRUPO OR T_DATOS.CODIGOGRUPO IS NULL)
                            AND NVL(M.CODIGOPDV,'0')!='0'
                    )
                    SELECT pdv.* FROM  pdv inner join mpop on pdv.CODIGOPDV=mpop.CODIGOPDV;
                COMMIT;
            ELSE
                /* de haber algun error se procede a almacenarlo para retornarlo en la variable p_mensaje*/
                P_MENSAJE :=P_MENSAJE||'<li>'||V_VALIDACION03||': ['||T_DATOS.FECHAINICIO||' - '||T_DATOS.FECHAFIN||'], cliente '||T_DATOS.NOMBREGRUPO||'</li>';
                --DBMS_OUTPUT.PUT_LINE('SP_INVERSION_ENCUENTAS_EXIBICION:'||P_MENSAJE);
              END IF;
        END LOOP;
        IF (P_MENSAJE IS NOT NULL) THEN
            P_MENSAJE :='Encuesta(s) ya existente(s):<ul>'||P_MENSAJE ||'</ul>';
        END IF;
    END SP_INVERSION_ENCUENTAS_EXIBICION;

    /*Procedimeinto para generacion de las encuestas */
    /* @P_IDINVERSION numero de inversion para la que se genera el cuestionario
       @P_CODIGOGRUPO para saber a cual cliente es la encuesta
       @P_COMPANIA compania a la que pertenece la encuesta
       @P_MENSAJE variable de retorno para saber si existen errores
    */
    PROCEDURE SP_INVERSION_ENCUENTAS_TOMALOCAL(P_IDINVERSION NUMBER,P_CODIGOGRUPO VARCHAR2 DEFAULT NULL,P_COMPANIA VARCHAR2,P_MENSAJE OUT VARCHAR2) AS
        V_NOMBREGRUPO VARCHAR2(500);
        V_IDTEMPLATE NUMBER;
        V_NOMBRE_TEMPLATE VARCHAR2(3999);
        V_USUARIO VARCHAR2(50);
        V_NOMBRECUESTIONARIO VARCHAR2(3999);
        V_NOMBREINVERSION VARCHAR2(3999);
        V_VALIDACION01 NUMBER;
        V_VALIDACION02 NUMBER;
        V_VALIDACION03 NUMBER;
        V_VALIDACION04 NUMBER;
        V_VALIDACION05 NUMBER;
        V_VALIDACION06 NUMBER;
        V_IDCUESTIONARIO NUMBER;
        V_ESTADO NUMBER:=0;
    BEGIN
        V_USUARIO :='ICOM';
        /*
            SE TOMAN LOS DATOS LAS FECHAS PARA GENERAR LAS ENCUESTAS CON EL TEMPLATE DISEÃ‘ADO POR OPERACIONES COMERCIALES
        */
        FOR  T_DATOS IN (
            SELECT
                F.*,
                 ROW_NUMBER() OVER (PARTITION BY IDINVERSION ORDER BY f.CODIGOGRUPO DESC)  ID1,
                (SELECT C.NOMBRES FROM VT_ICOM_INVERSION_CLIENTE C WHERE C.CODIGOGRUPO=F.CODIGOGRUPO AND ROWNUM=1)NOMBREGRUPO,
                (SELECT ID_TEMPLATE FROM VT_ICOM_ENCUESTA_TEMPLATE WHERE ID_TIPO_ENCUESTA =4 )  IDTEMPLATE,
                TRIM(TO_CHAR(P_COMPANIA,'00000')) COMPANIA
            FROM T_ICOM_CLIENTE_FECHAS F
            WHERE ENCUESTA=0 AND ESTADO =0
            AND IDINVERSION=P_IDINVERSION  AND (CODIGOGRUPO=P_CODIGOGRUPO OR P_CODIGOGRUPO IS NULL)
            AND EXISTS (
                select 1 FROM T_ENCT_CUESTIONARIOS WHERE TIPO = 2 AND ESTADO = 1  AND COMPANIA = P_COMPANIA AND IDCUESTIONARIO=
                    (SELECT ID_TEMPLATE FROM VT_ICOM_ENCUESTA_TEMPLATE WHERE ID_TIPO_ENCUESTA =4)
            )
            order by f.numero
        )
        LOOP
            V_NOMBRECUESTIONARIO:='';
            /*SE VALIDA QUE EL CUESTIONARIO A SER CREADO NO EXISTA DENTRO DE LA BASE*/
            SELECT
                COUNT(DISTINCT 1),
                LISTAGG(DISTINCT IDCUESTIONARIO ,',') WITHIN GROUP (ORDER BY IDCUESTIONARIO) IDCUESTIONARIO
            INTO V_VALIDACION04,V_VALIDACION03
            FROM T_ENCT_CUESTIONARIOS
            WHERE REFERENCIAID =T_DATOS.IDINVERSION
            AND   FECHADESDE =T_DATOS.FECHAINICIO AND FECHAHASTA =T_DATOS.FECHAFIN AND CODIGOCLIENTE =T_DATOS.CODIGOGRUPO and NOMBRE=TRIM('TOMA DE LOCAL');

            /*SI NO EXISTE EN LA BASE SE PROCEDE A LA CREACIÃ“N*/
            IF (V_VALIDACION04=0)THEN

                /*SE RECUPERA EL NOMBRE DEL TEMPLATE DE LA ENCUESTA*/
                SELECT IDCUESTIONARIO||' - '||NOMBRE INTO V_NOMBRE_TEMPLATE  FROM T_ENCT_CUESTIONARIOS WHERE TIPO = 2 AND ESTADO = 1  AND COMPANIA = P_COMPANIA AND IDCUESTIONARIO=T_DATOS.IDTEMPLATE;


                /*SE RECUPERA EL NOMBRE DE LA INVERSION*/
                SELECT ID||' - '||NOMBRE INTO V_NOMBREINVERSION FROM VT_ICOM_INVERSIONES WHERE ID=T_DATOS.IDINVERSION   AND COMPANIA = P_COMPANIA  AND IDETAPA IN (2,3,4,7) AND ROWNUM=1;

                V_IDCUESTIONARIO:=NULL;

                /*SEGÃšN EL TEMPLATE SE REALIZA LA COPIA DE LA ENCUESTA Y SE RECUPERA EL NUEVO ID DE LA ENCUESTA*/
                PK_ENCT_CUESTIONARIO.SP_CUESTIONARIOCOPIA(P_ID => T_DATOS.IDTEMPLATE,P_IDNEW => V_IDCUESTIONARIO,P_USUARIO =>V_USUARIO,P_COMPANIA => P_COMPANIA);


                /*SE RECUPERA EL NOMBRE DE LA ENCUESTA FORMATO TOMA DE LOCAL (QUEMADO)*/
                V_NOMBRECUESTIONARIO :='TOMA DE LOCAL';

                PK_ENCT_CUESTIONARIO.SP_CUESTIONARIOGUARDAR(
                    P_ID => V_IDCUESTIONARIO ,
                    P_TIPO => 1,/*{1:NORMAL,2:TEMPLATE}*/
                    P_IDGRUPO =>  NULL,
                    P_NOMBRE => V_NOMBRECUESTIONARIO,
                    P_REFERENCIATABLA =>'INVERSION',/*{PRODUCTO_COMPETENCIA:PRODUCTO COMPETENCIA,CODIGOPDV:Punto de Venta,PRODUCTO:PRODUCTO,INVERSION:INVERSIONES COMERCIALES,CLIENTE:CLIENTES}*/
                    P_REFERENCIAID => T_DATOS.IDINVERSION ,
                    P_REFERENCIADESCRIPCION => V_NOMBREINVERSION,
                    P_REFERENCIAPOBLACION => 'PUNTOVENTA',/*{EMPLEADO:EMPLEADOS,PUNTOVENTA:PUNTOS DE VENTA}*/
                    P_FRECUENCIA => 1,/*{0:UNA VEZ,1:DIARIA,7:SEMANAL,15:QUINCENAL}*/
                    P_FECHADESDE => T_DATOS.FECHAINICIO,
                    P_FECHAHASTA =>T_DATOS.FECHAFIN,
                    P_TIPOEJECUCION => 1,/*{1:Movil Mella,2:Correo,3:Portal}*/
                    P_USUARIOCREACION => V_USUARIO,
                    P_ESTADO => 1,
                    P_COMPANIA => P_COMPANIA  ,P_CODIGOCLIENTE=>T_DATOS.CODIGOGRUPO
                );


                /*SE INSERTA LOS DATOS DE LA POBLACION A LA QUE VA DIRIGIDO LA ENCUESTA*/
                INSERT INTO T_ENCT_CUESTIONARIOPERSONAS ( IDCUESTIONARIO, IDPERSONA, DESCRIPCION, CORREO, NUMERO)
                    with pdv as (SELECT V_IDCUESTIONARIO IDCUESTIONARIO,
                                TO_CHAR(CL.CODIGOPDV||'-'||CL.NUMERO) CODIGOPDV,
                                RAZON_SOCIAL,
                                cl.EMAIL correo,
                                0 numero
                            FROM T_TRAD_CLIENTELOCAL CL
                            INNER JOIN T_TRAD_CLIENTE C ON (C.CODIGOPDV=CL.CODIGOPDV)
                            left join  (select distinct codigopdv, RUC, RAZON_SOCIAL, tipoidentificacion  from t_trad_clienteruc where es_principal = 1)r on c.codigopdv = r.codigopdv
                            WHERE CODIGOGRUPO=T_DATOS.CODIGOGRUPO AND TIPOVISITA  =1
                            group by TO_CHAR(CL.CODIGOPDV||'-'||CL.NUMERO), RAZON_SOCIAL,cl.EMAIL
                    )
                    ,mpop as (
                            SELECT DISTINCT M.CODIGOPDV,CODIGOGRUPO,IDINVERSION
                            FROM T_ICOM_CLIENTE_MATERIAL M
                            INNER JOIN VT_ICOM_MATERIALPOP P ON M.IDMATERIAL=P.ID AND P.COMPANIA=P_COMPANIA
                            WHERE 1=1
                            AND M.ESTADO=0
                            AND M.IDINVERSION  =T_DATOS.IDINVERSION
                            AND (CODIGOGRUPO=T_DATOS.CODIGOGRUPO OR T_DATOS.CODIGOGRUPO IS NULL)
                            AND NVL(M.CODIGOPDV,'0')!='0'
                    )
                    SELECT pdv.* FROM  pdv inner join mpop on pdv.CODIGOPDV=mpop.CODIGOPDV;
                COMMIT;
            ELSE
                /* de haber algun error se procede a almacenarlo para retornarlo en la variable p_mensaje*/
                P_MENSAJE :=P_MENSAJE||'<li>'||V_VALIDACION03||': ['||T_DATOS.FECHAINICIO||' - '||T_DATOS.FECHAFIN||'], cliente '||T_DATOS.NOMBREGRUPO||'</li>';

                --DBMS_OUTPUT.PUT_LINE('SP_INVERSION_ENCUENTAS_TOMALOCAL:'||P_MENSAJE);
            END IF;
        END LOOP;
        IF (P_MENSAJE IS NOT NULL) THEN
            P_MENSAJE :='Encuesta(s) ya existente(s):<ul>'||P_MENSAJE ||'</ul>';
        END IF;
    END SP_INVERSION_ENCUENTAS_TOMALOCAL;
    /*Procedimeinto para generacion de las encuestas */
    /* @P_IDINVERSION numero de inversion para la que se genera el cuestionario
       @P_CODIGOGRUPO para saber a cual cliente es la encuesta
       @P_COMPANIA compania a la que pertenece la encuesta
       @P_MENSAJE variable de retorno para saber si existen errores
    */
    PROCEDURE SP_INVERSION_ENCUENTAS (P_IDINVERSION NUMBER,P_CODIGOGRUPO VARCHAR2 DEFAULT NULL,P_COMPANIA VARCHAR2,P_MENSAJE OUT VARCHAR2) AS

	BEGIN
        V_COMPANIA :=trim(TO_CHAR(p_compania,'00000'));
        /*SE GENERA LAS ENCUENTAS DE DESCUENTO Y EXHIBICION SI Y SOLO SI EL TIPO DE INVERSION ES DESCUENTO*/
        if PK_ICOM_HERRAMIENTAS.F_INVERSIONVALIDATIPOINVERSION(P_IDINVERSION,'DESCUENTO' )!=0 then
            SP_INVERSION_ENCUENTAS_DESCUENTO(P_IDINVERSION,P_CODIGOGRUPO,V_COMPANIA,P_MENSAJE) ;
            SP_INVERSION_ENCUENTAS_EXIBICION(P_IDINVERSION,P_CODIGOGRUPO,V_COMPANIA,P_MENSAJE) ;
        end if;

        /*SE GENERA LAS ENCUENTAS DE EXHIBICION SI Y SOLO SI EL TIPO DE INVERSION ES EXHIBICION*/
        if PK_ICOM_HERRAMIENTAS.F_INVERSIONVALIDATIPOINVERSION(P_IDINVERSION,'EXHIBICION')!=0
            then  SP_INVERSION_ENCUENTAS_EXIBICION(P_IDINVERSION,P_CODIGOGRUPO,V_COMPANIA,P_MENSAJE) ;
        end if;

        /*SE GENERA LAS ENCUENTAS DE TOMA DE LOCAL SI Y SOLO SI EL TIPO DE INVERSION ES TOMALOCAL*/
        if PK_ICOM_HERRAMIENTAS.F_INVERSIONVALIDATIPOINVERSION(P_IDINVERSION,'TOMALOCAL' )!=0
            then  SP_INVERSION_ENCUENTAS_TOMALOCAL(P_IDINVERSION,P_CODIGOGRUPO,V_COMPANIA,P_MENSAJE) ;
        end if;

        /*SE ACTUALIZA EL ESTADO A APROBADO Y QUE SE GENERÃ“ LA ENCUESTA PARA LAS FECHAS*/
        UPDATE T_ICOM_CLIENTE_FECHAS
        SET ESTADO=1, ENCUESTA=1
        WHERE IDINVERSION=P_IDINVERSION AND (CODIGOGRUPO=P_CODIGOGRUPO or P_CODIGOGRUPO is null) AND ESTADO=3;
        COMMIT;

        /*SE ACTUALIZA EL ESTADO A APROBADO PARA LOS MATERIALES POP*/
        UPDATE  T_ICOM_CLIENTE_MATERIAL M
        SET M.ESTADO=1
        WHERE IDINVERSION=P_IDINVERSION  AND CODIGOGRUPO=P_CODIGOGRUPO AND M.ESTADO=3
        AND EXISTS  ( SELECT 1  FROM T_ICOM_INVERSION_CLIENTE_G G WHERE  G.IDINVERSION=M.IDINVERSION AND G.CODIGOGRUPO=M.CODIGOGRUPO AND  G.ESTADO=0 AND G.NEGOCIACION IN (1,3) );
        COMMIT;

    END SP_INVERSION_ENCUENTAS;

   FUNCTION F_INVERSION_ENCUENTAS_NOMBRES(P_IDINVERSION NUMBER,P_CODIGOGRUPO VARCHAR2 DEFAULT NULL,P_COMPANIA VARCHAR2,
    P_PRESTAERROR NUMBER DEFAULT 1  ,P_EJECUTIVO VARCHAR2 DEFAULT NULL) RETURN CLOB AS
        V_NOMBRE_TEMPLATE VARCHAR2(3999);
        V_NOMBRECUESTIONARIO VARCHAR2(3999);
        V_NOMBREINVERSION VARCHAR2(3999);
        V_VALIDACION01 NUMBER;
        V_VALIDACION02 NUMBER;
        V_VALIDACION03 NUMBER;
        V_CLOB CLOB;
        V_ESTRUCTURA VARCHAR2(3999);
        V_LINEA VARCHAR2(3999);
        V_CEDULA_EJECUTIVO VARCHAR2(20);
    BEGIN
        V_ESTRUCTURA:='numero;tipoencuesta;nombreencuesta;template;inversion;fechas;numPDV;nombregrupo|';


        V_NOMBRE_TEMPLATE:='. ';

        V_NOMBREINVERSION:='. ';

       --- BUSCA LA CEDULA DEL EJECUTIVO
       IF(P_EJECUTIVO is not null)
       THEN
            select numeroidentificacion INTO V_CEDULA_EJECUTIVO
            from data.VT_CORP_USUARIO where nombreusuario= P_EJECUTIVO;
       END IF;

        /*****************************************DESCUENTOS*****************************************/
        if ((PK_ICOM_HERRAMIENTAS.F_INVERSIONVALIDATIPOINVERSION(p_IDINVERSION,'DESCUENTO' )!=0  ))then
            FOR  T_DATOS IN (
                SELECT
                    F.*,
                    ROW_NUMBER() OVER (PARTITION BY IDINVERSION ORDER BY f.CODIGOGRUPO DESC)  ID1,
                    (SELECT C.NOMBRES FROM VT_ICOM_INVERSION_CLIENTE C WHERE C.CODIGOGRUPO=F.CODIGOGRUPO AND ROWNUM=1)NOMBREGRUPO,
                    (SELECT ID_TEMPLATE FROM VT_ICOM_ENCUESTA_TEMPLATE WHERE ID_TIPO_ENCUESTA =1 )  IDTEMPLATE
                FROM T_ICOM_CLIENTE_FECHAS F
                INNER JOIN vt_gzm_cliente C ON  (F.CODIGOGRUPO=C.CODIGOCLIENTE AND C.EJECUTIVO=NVL(V_CEDULA_EJECUTIVO,C.EJECUTIVO))
                WHERE ENCUESTA=0 and F.estado=0 AND IDINVERSION=P_IDINVERSION AND (F.CODIGOGRUPO=P_CODIGOGRUPO or P_CODIGOGRUPO is null )
                and  (nvl(TIPOLOCAL,'0')!='0' or nvl(DESCUENTO,0)!=0)
                )
            LOOP
                --DBMS_OUTPUT.PUT_LINE('2012:V_VALIDACION01: '||V_VALIDACION01);
                V_NOMBRECUESTIONARIO:='';
                /*SE VALIDA QUE EL CUESTIONARIO A SER CREADO NO EXISTA DENTRO DE LA BASE*/
                SELECT
                    COUNT(DISTINCT 1)
                INTO V_VALIDACION01
                FROM T_ENCT_CUESTIONARIOS
                WHERE   REFERENCIAID =T_DATOS.IDINVERSION
                AND  FECHADESDE =T_DATOS.FECHAINICIO AND FECHAHASTA =T_DATOS.FECHAFIN AND CODIGOCLIENTE =T_DATOS.CODIGOGRUPO ;
                --DBMS_OUTPUT.PUT_LINE('V_VALIDACION01: '||V_VALIDACION01);
                IF (V_VALIDACION01=0)THEN
                    FOR T_PRODUCTO IN (
                        SELECT
                            LISTAGG(DISTINCT NOMBRE||' '||PRESENTACION, ', ') WITHIN GROUP (ORDER BY  NOMBRE||' '||PRESENTACION) PRODUCTO
                        FROM(
                            SELECT
                                A.IDINVERSION,
                                B.CATEGORIA||' - '||B.MARCA||CASE WHEN B.SUBMARCA='SIN SUB-MARCA' THEN ' ' ELSE ' - '||TO_CHAR(B.SUBMARCA)END NOMBRE,
                                LISTAGG(DISTINCT B.PRESENTACION,'/')WITHIN GROUP (ORDER BY B.PRESENTACION) PRESENTACION
                            FROM T_ICOM_INVERSION_PRODUCTO A
                            INNER JOIN VT_JDE_PRODUCTOS B ON A.CODIGOPRODUCTO= B.CODIGOPRODUCTO
                            INNER JOIN TABLE(PK_COMMONS.F_DIVIDIRTEXTO(T_DATOS.PRODUCTOS,',') ) C ON  TRIM(A.CODIGOPRODUCTO)= TRIM(C.ITEM)
                            WHERE A.IDINVERSION=T_DATOS.IDINVERSION
                            AND B.SUBMARCA IS NOT NULL
                            GROUP BY A.IDINVERSION,B.CATEGORIA,B.MARCA,B.SUBMARCA
                        )
                    )
                    LOOP
                        /*SE RECUPERA EL NOMBRE DE LA ENCUESTA FORMATO % + CATEGORIA + MARCA + SUBMARCA + CONTEO(AGRUPADO)*/
                        V_NOMBRECUESTIONARIO :=T_DATOS.DESCUENTO||'% '||' '||T_PRODUCTO.PRODUCTO;
                        --DBMS_OUTPUT.PUT_LINE('V_NOMBRECUESTIONARIO : '||V_NOMBRECUESTIONARIO );

                        /*SE RECUPREA EL NUMERO DE LA POBLACION A LA QUE VA DIRIGIDO LA ENCUESTA*/
                        SELECT count( distinct
                                    TO_CHAR(CL.CODIGOPDV||'-'||CL.NUMERO)) CODIGOPDV
                        into V_VALIDACION03
                        FROM T_TRAD_CLIENTELOCAL CL
                        INNER JOIN T_TRAD_CLIENTE C ON (C.CODIGOPDV=CL.CODIGOPDV)
                        --left join  (select distinct codigopdv, RUC, RAZON_SOCIAL, tipoidentificacion
                        --from t_trad_clienteruc where es_principal = 1)r on c.codigopdv = r.codigopdv
                        WHERE
                        (
                            ( T_DATOS.CODIGOGRUPO IN (5100,58321) AND CODIGOGRUPO IS NULL AND T_DATOS.TIPOLOCAL IS NULL) --- TRADICIONAL
                            OR
                                (C.CODIGOGRUPO=T_DATOS.CODIGOGRUPO AND NOMBRECOMERCIAL IN (SELECT ITEM  FROM TABLE(PK_COMMONS.F_DIVIDIRTEXTO(T_DATOS.TIPOLOCAL,':') ) ) )
                        )
                        AND cl.TIPOVISITA  =1;

                        V_LINEA:=V_ESTRUCTURA;
                        V_LINEA:=REPLACE(V_LINEA,'numero',TRIM(T_DATOS.ID1));
                        V_LINEA:=REPLACE(V_LINEA,'tipoencuesta',TRIM('DESCUENTOS'));
                        V_LINEA:=REPLACE(V_LINEA,'nombreencuesta',TRIM(V_NOMBRECUESTIONARIO));
                        V_LINEA:=REPLACE(V_LINEA,'template',TRIM(V_NOMBRE_TEMPLATE));
                        V_LINEA:=REPLACE(V_LINEA,'inversion',TRIM(V_NOMBREINVERSION));
                        V_LINEA:=REPLACE(V_LINEA,'fechas',T_DATOS.FECHAINICIO||'-'||T_DATOS.FECHAFIN);
                        V_LINEA:=REPLACE(V_LINEA,'numPDV',NVL(V_VALIDACION03,0));
                        V_LINEA:=REPLACE(V_LINEA,'nombregrupo',T_DATOS.NOMBREGRUPO);
                        V_LINEA:=TRIM(V_LINEA);
                        V_CLOB:=V_CLOB||TRIM(V_LINEA);

                    END LOOP;
                ELSE
                    V_LINEA:=V_ESTRUCTURA;
                    V_LINEA:=REPLACE(V_LINEA,'numero',TRIM(T_DATOS.ID1));
                    V_LINEA:=REPLACE(V_LINEA,'tipoencuesta',TRIM('DESCUENTOS'));
                    V_LINEA:=REPLACE(V_LINEA,'fechas',T_DATOS.FECHAINICIO||'-'||T_DATOS.FECHAFIN);
                    V_LINEA:=REPLACE(V_LINEA,'nombreencuesta','No es posible crear la encuesta '||V_NOMBRECUESTIONARIO||' revisar fechas en las encuestas');
                    V_LINEA:=REPLACE(V_LINEA,'template',TRIM(V_NOMBRE_TEMPLATE));
                    V_LINEA:=REPLACE(V_LINEA,'inversion',TRIM(V_NOMBREINVERSION));
                    V_LINEA:=REPLACE(V_LINEA,'numPDV',NVL(V_VALIDACION03,0));
                    V_LINEA:=REPLACE(V_LINEA,'nombregrupo',T_DATOS.NOMBREGRUPO);
                    V_LINEA:=TRIM(V_LINEA);
                    IF (P_PRESTAERROR=1)THEN V_CLOB:=V_CLOB||TRIM(V_LINEA);END IF;
                END IF;
            END LOOP;
        end if;

        /*****************************************EXHIBICION*****************************************/
        if  (PK_ICOM_HERRAMIENTAS.F_INVERSIONVALIDATIPOINVERSION(p_IDINVERSION,'EXHIBICION' )!=0
            OR PK_ICOM_HERRAMIENTAS.F_INVERSIONVALIDATIPOINVERSION(p_IDINVERSION,'DESCUENTO' )!=0
        ) then

            /*SI UNA DE LAS 2 VALIDACIONES SON VERDADERAS SE RETORNA UN ERROR EN EL PARAMETRO P_MENSAJE*/
            V_VALIDACION03:=2;
            IF (PK_ICOM_HERRAMIENTAS.F_INVERSIONVALIDATIPOINVERSION(p_IDINVERSION,'EXHIBICION' )!=0)THEN
                 /*SE VALIDA QUE LOS DATOS DE MATERIAL POP SEAN MEDIBLES Y QUE SEAN ATADOS A UN CODIGOPDV*/
                SELECT COUNT(DISTINCT 1) INTO V_VALIDACION01 FROM T_ICOM_CLIENTE_MATERIAL
                WHERE IDINVERSION=P_IDINVERSION AND MEDIBLE =1
               -- AND NVL(CODIGOPDV,'0')!='0'
                ;

                /*SE VALIDA QUE LOS PROCESO OPERATIVOS "PARAMETRIZACI?N EN MV DE MATERIAL POP","PARAMETRIZACI?N EN MV EXHIBICIONES CONTRATADAS" SEAN ACTIVOS PARA LA INVERSION*/
                SELECT COUNT(DISTINCT 1) INTO V_VALIDACION02 FROM VT_ICOM_PROCESO A
                INNER JOIN T_ICOM_INVERSION_PROCESO P ON A.IDPROCESO=P.IDPROCESO
                WHERE IDINVERSION=P_IDINVERSION AND A.ESTADO=1 AND a.IDPROCESO IN (12,3);

                V_VALIDACION03:=V_VALIDACION01+V_VALIDACION02;
            END IF;

            if (V_VALIDACION03=2  )then
                FOR  T_DATOS IN (
                    WITH
                    T_MATERIAL AS (
                        SELECT DISTINCT
                            M.IDINVERSION,M.CODIGOGRUPO,M.IDMATERIAL,M.DESCRIPCION,M.CODIGOPDV,M.FECHAINICIO FECHAINICIO,M.FECHAFIN FECHAFIN,P.NOMBRECOMERCIAL,
                            (SELECT C.NOMBRES FROM VT_ICOM_INVERSION_CLIENTE C WHERE C.CODIGOGRUPO=M.CODIGOGRUPO AND ROWNUM=1)NOMBREGRUPO,
                            (SELECT ID_TEMPLATE FROM VT_ICOM_ENCUESTA_TEMPLATE WHERE ID_TIPO_ENCUESTA =2) IDTEMPLATE
                        FROM T_ICOM_CLIENTE_MATERIAL M
                        INNER JOIN VT_ICOM_MATERIALPOP P ON M.IDMATERIAL=P.ID AND P.COMPANIA=P_COMPANIA
                        INNER JOIN vt_gzm_cliente C ON  (M.CODIGOGRUPO=C.CODIGOCLIENTE AND C.EJECUTIVO=NVL(V_CEDULA_EJECUTIVO,C.EJECUTIVO))
                        WHERE 1=1
                        AND M.IDINVERSION  =P_IDINVERSION
                        AND (M.CODIGOGRUPO=P_CODIGOGRUPO or P_CODIGOGRUPO is null)
                         AND NEGOCIACION=1
                        AND NVL(P.MEDIBLE,'0')!=0
                       -- AND NVL(M.CODIGOPDV,0)!='0'
                    )
                    SELECT
                        ROW_NUMBER() OVER (PARTITION BY IDINVERSION ORDER BY CODIGOGRUPO DESC)  ID1,
                        T.IDINVERSION,T.CODIGOGRUPO,T.IDMATERIAL,T.DESCRIPCION,
                        (SELECT C.NOMBRES FROM VT_ICOM_INVERSION_CLIENTE C WHERE C.CODIGOGRUPO=T.CODIGOGRUPO AND ROWNUM=1)NOMBREGRUPO,
                        LISTAGG(DISTINCT T.CODIGOPDV,',') WITHIN GROUP (ORDER BY T.CODIGOPDV) CODIGOPDV,T.FECHAINICIO,T.FECHAFIN,T.IDTEMPLATE, NULL DESCUENTO,
                        LISTAGG(DISTINCT T.NOMBRECOMERCIAL ,',') WITHIN GROUP (ORDER BY T.NOMBRECOMERCIAL) PRODUCTOS,
                        (select LISTAGG(DISTINCT P.LINEANEGOCIO ||' ' ||P.MARCA,',') WITHIN GROUP (ORDER BY P.LINEANEGOCIO, P.MARCA) CATEGORIA  from VT_JDE_PRODUCTOS P INNER JOIN t_icom_inversion_producto IP ON (IP.CODIGOPRODUCTO=P.CODIGOPRODUCTO) WHERE IDINVERSION=T.IDINVERSION AND P.SUBMARCA IS NOT NULL)CATEGORIA
                    FROM T_MATERIAL T
                    GROUP BY T.IDINVERSION,T.CODIGOGRUPO,T.IDMATERIAL,T.DESCRIPCION,T.FECHAINICIO,T.FECHAFIN,T.IDTEMPLATE
                )
                LOOP
                    V_NOMBRECUESTIONARIO:='';
                    /*SE VALIDA QUE EL CUESTIONARIO A SER CREADO NO EXISTA DENTRO DE LA BASE*/
                    SELECT
                        COUNT(DISTINCT 1)
                    INTO V_VALIDACION02
                    FROM T_ENCT_CUESTIONARIOS
                    WHERE REFERENCIAID =T_DATOS.IDINVERSION
                    AND FECHADESDE =T_DATOS.FECHAINICIO AND FECHAHASTA =T_DATOS.FECHAFIN AND CODIGOCLIENTE =T_DATOS.CODIGOGRUPO;
                    --DBMS_OUTPUT.PUT_LINE('V_VALIDACION02: '||V_VALIDACION02);

                    /*SE RECUPERA EL NOMBRE DE LA ENCUESTA FORMATO NOMBRE COMERCIAL POP+ LINEA NEGOCIO+ MARCA */
                    V_NOMBRECUESTIONARIO := trim(T_DATOS.PRODUCTOS)||' '||T_DATOS.CATEGORIA;
                    /*SI NO EXISTE EN LA BASE SE PROCEDE A LA CREACI?N*/
                    IF (V_VALIDACION02=0)THEN


                       /*SE RECUPREA EL NUMERO DE LA POBLACION A LA QUE VA DIRIGIDO LA ENCUESTA*/
                        with pdv as (
                                SELECT
                                TO_CHAR(CL.CODIGOPDV||'-'||CL.NUMERO) CODIGOPDV,
                                r.RAZON_SOCIAL,
                                cl.EMAIL correo,
                                0 numero
                            FROM T_TRAD_CLIENTELOCAL CL
                            INNER JOIN T_TRAD_CLIENTE C ON (C.CODIGOPDV=CL.CODIGOPDV)
                            left join  (select distinct codigopdv, RUC, RAZON_SOCIAL, tipoidentificacion
                            from t_trad_clienteruc where es_principal = 1)r on c.codigopdv = r.codigopdv
                            WHERE
                            --CODIGOGRUPO=T_DATOS.CODIGOGRUPO AND cl.TIPOVISITA  =1
                              --CODIGOGRUPO=T_DATOS.CODIGOGRUPO AND cl.TIPOVISITA  =1
                            (( T_DATOS.CODIGOGRUPO IN (5100,58321) AND C.CODIGOGRUPO IS NULL) --- TRADICIONAL
                            OR (C.CODIGOGRUPO=T_DATOS.CODIGOGRUPO ))      AND cl.TIPOVISITA  =1

                            group by TO_CHAR(CL.CODIGOPDV||'-'||CL.NUMERO), RAZON_SOCIAL,cl.EMAIL

                        )
                        ,mpop as (
                                SELECT DISTINCT M.CODIGOPDV,CODIGOGRUPO,IDINVERSION
                                FROM T_ICOM_CLIENTE_MATERIAL M
                                INNER JOIN VT_ICOM_MATERIALPOP P ON M.IDMATERIAL=P.ID AND P.COMPANIA=P_COMPANIA
                                WHERE 1=1
                                AND M.ESTADO=0
                                AND M.IDINVERSION  =T_DATOS.IDINVERSION
                                AND (CODIGOGRUPO=T_DATOS.CODIGOGRUPO OR T_DATOS.CODIGOGRUPO IS NULL)
                                --AND NVL(M.CODIGOPDV,'0')!='0'
                        )
                        SELECT count(distinct mpop.CODIGOPDV)  into V_VALIDACION03
                        FROM  pdv inner join mpop on pdv.CODIGOPDV=mpop.CODIGOPDV;

                        V_LINEA:=V_ESTRUCTURA;
                        V_LINEA:=REPLACE(V_LINEA,'numero',TRIM(T_DATOS.ID1));
                        V_LINEA:=REPLACE(V_LINEA,'tipoencuesta',TRIM('EXHIBICION'));
                        V_LINEA:=REPLACE(V_LINEA,'nombreencuesta',TRIM(V_NOMBRECUESTIONARIO));
                        V_LINEA:=REPLACE(V_LINEA,'template',TRIM(V_NOMBRE_TEMPLATE));
                        V_LINEA:=REPLACE(V_LINEA,'inversion',TRIM(V_NOMBREINVERSION));
                        V_LINEA:=REPLACE(V_LINEA,'fechas',T_DATOS.FECHAINICIO||'-'||T_DATOS.FECHAFIN);
                        V_LINEA:=REPLACE(V_LINEA,'numPDV',NVL(V_VALIDACION03,0));
                        V_LINEA:=REPLACE(V_LINEA,'nombregrupo',T_DATOS.NOMBREGRUPO);
                        V_LINEA:=TRIM(V_LINEA);
                        V_CLOB:=V_CLOB||TRIM(V_LINEA);
                    ELSE
                        V_LINEA:=V_ESTRUCTURA;
                        V_LINEA:=REPLACE(V_LINEA,'numero',TRIM(T_DATOS.ID1));
                        V_LINEA:=REPLACE(V_LINEA,'tipoencuesta',TRIM('EXHIBICI?N'));
                        V_LINEA:=REPLACE(V_LINEA,'fechas',T_DATOS.FECHAINICIO||'-'||T_DATOS.FECHAFIN);
                        V_LINEA:=REPLACE(V_LINEA,'nombreencuesta','No es posible crear la encuesta '||V_NOMBRECUESTIONARIO||' revisar fechas en las encuestas');
                        V_LINEA:=REPLACE(V_LINEA,'template',TRIM(V_NOMBRE_TEMPLATE));
                        V_LINEA:=REPLACE(V_LINEA,'inversion',TRIM(V_NOMBREINVERSION));
                        V_LINEA:=REPLACE(V_LINEA,'numPDV',NVL(V_VALIDACION03,0));
                        V_LINEA:=REPLACE(V_LINEA,'nombregrupo',T_DATOS.NOMBREGRUPO);
                        V_LINEA:=TRIM(V_LINEA);
                        IF (P_PRESTAERROR=1)THEN V_CLOB:=V_CLOB||TRIM(V_LINEA);END IF;

                    END IF;
                    V_NOMBRECUESTIONARIO:='----';
                END LOOP;
            end if;
        end if;

        /*****************************************TOMA LOCAL*****************************************/
        if((PK_ICOM_HERRAMIENTAS.F_INVERSIONVALIDATIPOINVERSION(p_IDINVERSION,'TOMALOCAL' )!=0)) then
             FOR  T_DATOS IN (
                SELECT
                    F.*,
                    ROWNUM ID1,
                    (SELECT C.NOMBRES FROM VT_ICOM_INVERSION_CLIENTE C WHERE C.CODIGOGRUPO=F.CODIGOGRUPO AND ROWNUM=1)NOMBREGRUPO,
                    (SELECT ID_TEMPLATE FROM VT_ICOM_ENCUESTA_TEMPLATE WHERE ID_TIPO_ENCUESTA =4 )  IDTEMPLATE,
                    TRIM(TO_CHAR(P_COMPANIA,'00000')) COMPANIA
                FROM T_ICOM_CLIENTE_FECHAS F
                INNER JOIN vt_gzm_cliente C ON  (F.CODIGOGRUPO=C.CODIGOCLIENTE AND C.EJECUTIVO=NVL(V_CEDULA_EJECUTIVO,C.EJECUTIVO))
                WHERE ENCUESTA=0 and F.estado=0
                AND IDINVERSION=P_IDINVERSION AND (F.CODIGOGRUPO=P_CODIGOGRUPO or P_CODIGOGRUPO is null)
            )
            LOOP
                V_NOMBRECUESTIONARIO:='';
                /*SE VALIDA QUE EL CUESTIONARIO A SER CREADO NO EXISTA DENTRO DE LA BASE*/
                SELECT
                COUNT(DISTINCT 1)
                INTO V_VALIDACION01
                FROM T_ENCT_CUESTIONARIOS
                WHERE   REFERENCIAID =T_DATOS.IDINVERSION
                AND  FECHADESDE =T_DATOS.FECHAINICIO AND FECHAHASTA =T_DATOS.FECHAFIN AND CODIGOCLIENTE =T_DATOS.CODIGOGRUPO ;
                /*SI NO EXISTE EN LA BASE SE PROCEDE A LA CREACI?N*/
                IF (V_VALIDACION01=0)THEN
                    /*SE RECUPERA EL NOMBRE DE LA ENCUESTA FORMATO TOMA DE LOCAL (QUEMADO)*/
                    V_NOMBRECUESTIONARIO :='TOMA DE LOCAL';
                    
                    /*SE RECUPREA EL NUMERO DE LA POBLACION A LA QUE VA DIRIGIDO LA ENCUESTA*/    
                    with pdv as (
                            SELECT 
                            TO_CHAR(CL.CODIGOPDV||'-'||CL.NUMERO) CODIGOPDV,
                            r.RAZON_SOCIAL,
                            cl.EMAIL correo,
                            0 numero
                        FROM T_TRAD_CLIENTELOCAL CL
                        INNER JOIN T_TRAD_CLIENTE C ON (C.CODIGOPDV=CL.CODIGOPDV)
                        left join  (select distinct codigopdv, RUC, RAZON_SOCIAL, tipoidentificacion  from t_trad_clienteruc where es_principal = 1)r on c.codigopdv = r.codigopdv
                        WHERE CODIGOGRUPO=T_DATOS.CODIGOGRUPO AND cl.TIPOVISITA  =1
                        group by TO_CHAR(CL.CODIGOPDV||'-'||CL.NUMERO), RAZON_SOCIAL,cl.EMAIL
                    )
                    ,mpop as (
                            SELECT DISTINCT M.CODIGOPDV,CODIGOGRUPO,IDINVERSION
                            FROM T_ICOM_CLIENTE_MATERIAL M
                            INNER JOIN VT_ICOM_MATERIALPOP P ON M.IDMATERIAL=P.ID AND P.COMPANIA=P_COMPANIA
                            WHERE 1=1
                            AND M.ESTADO=0
                            AND M.IDINVERSION  =T_DATOS.IDINVERSION 
                            AND (CODIGOGRUPO=T_DATOS.CODIGOGRUPO OR T_DATOS.CODIGOGRUPO IS NULL)
                            --AND NVL(M.CODIGOPDV,'0')!='0'
                    )
                    SELECT count(distinct mpop.CODIGOPDV)  into V_VALIDACION03 FROM  pdv inner join mpop on pdv.CODIGOPDV=mpop.CODIGOPDV;

                    V_LINEA:=V_ESTRUCTURA;
                    V_LINEA:=REPLACE(V_LINEA,'numero',TRIM(T_DATOS.ID1));
                    V_LINEA:=REPLACE(V_LINEA,'tipoencuesta',TRIM('TOMA DE LOCAL'));
                    V_LINEA:=REPLACE(V_LINEA,'nombreencuesta',TRIM(V_NOMBRECUESTIONARIO));
                    V_LINEA:=REPLACE(V_LINEA,'template',TRIM(V_NOMBRE_TEMPLATE));
                    V_LINEA:=REPLACE(V_LINEA,'inversion',TRIM(V_NOMBREINVERSION));
                    V_LINEA:=REPLACE(V_LINEA,'fechas',T_DATOS.FECHAINICIO||'-'||T_DATOS.FECHAFIN);
                    V_LINEA:=REPLACE(V_LINEA,'numPDV',NVL(V_VALIDACION03,0));
                    V_LINEA:=REPLACE(V_LINEA,'nombregrupo',T_DATOS.NOMBREGRUPO);

                    V_LINEA:=TRIM(V_LINEA);
                ELSE
                    V_LINEA:=V_ESTRUCTURA;
                    V_LINEA:=REPLACE(V_LINEA,'numero',TRIM(T_DATOS.ID1));
                    V_LINEA:=REPLACE(V_LINEA,'tipoencuesta',TRIM('TOMA DE LOCAL'));
                    V_LINEA:=REPLACE(V_LINEA,'fechas',T_DATOS.FECHAINICIO||'-'||T_DATOS.FECHAFIN);
                    V_LINEA:=REPLACE(V_LINEA,'nombreencuesta','No es posible crear la encuesta '||V_NOMBRECUESTIONARIO||' revisar fechas en las encuestas');
                    V_LINEA:=REPLACE(V_LINEA,'template',TRIM(V_NOMBRE_TEMPLATE));
                    V_LINEA:=REPLACE(V_LINEA,'inversion',TRIM(V_NOMBREINVERSION));
                    V_LINEA:=REPLACE(V_LINEA,'numPDV',NVL(V_VALIDACION03,0));
                    V_LINEA:=REPLACE(V_LINEA,'nombregrupo',T_DATOS.NOMBREGRUPO);
                    V_LINEA:=TRIM(V_LINEA);
                    IF (P_PRESTAERROR=1)THEN V_CLOB:=V_CLOB||TRIM(V_LINEA);END IF;
                END IF;
                V_CLOB:=V_CLOB||TRIM(V_LINEA);
            END LOOP;
        END IF;
        RETURN V_CLOB;
        
    END F_INVERSION_ENCUENTAS_NOMBRES;     

    
    PROCEDURE SP_NOTIFICACION_KAM_PROMOCIONES_POP(p_idinversion number default null) AS
        V_HTML_BODY CLOB;
        V_HTML_PLATILLA1 CLOB;
        V_HTML_DETA CLOB;
        V_HTML_TOTAL number;
         
    BEGIN
       V_HTML_PLATILLA1:= '<!DOCTYPE html>
    <html>
        <head>
        <style>
            body{font-family: monospace;font-size: 13px;line-height:1em;}
            table {width: 100%;border-collapse: collapse;}
            th, td {padding: 8px;text-align: left;}
            tr {background-color: #f9f9f9;}
            th, td {border-bottom: 1px solid #ddd;}
            thead tr {border-bottom: 2px solid #ddd;}
            .tr-hover:hover {background-color: #53534b0f;color: #8bc34a !important;cursor: pointer;}
            .color-light-title{color: #000 !important;background-color: #8bc34a !important;}
            .HAlignRight{text-align: right !important;padding-right: 6px;font-size: 1em;line-height: 0.5em;}
            .HAlignCenter{text-align: center !important;font-size: 1em;line-height: 1.5em;}
            tr:nth-child(odd) {background-color: #ffffff;}
            tr:nth-child(even) {background-color: #f2f2f2;}
        </style>
        </head>
        <body>
            <p>Estimado(a) usuario: <strong>{EJECUTIVO}</strong></p>
            <p>Tiene pendiente por gestionar lo siguiente:</p>
    <table class="table-all">
                <thead> 
                    <tr class="color-light-title">
                        <th class="HAlignCenter">ID</th>
                        <th class="HAlignCenter">NOMBRE INVERSION</th>
                         <th class="HAlignCenter">CLIENTE</th>
                        <th class="HAlignCenter">MATERIAL</th>
                        <th class="HAlignCenter">MES INICIO POP</th>
                        <th class="HAlignCenter">MES FIN POP</th>
                        <th class="HAlignCenter">VALOR NEGOCIADO</th>
                        <th class="HAlignCenter">VALOR PAGADO</th>
                        <th class="HAlignCenter">TOTAL</th>
                    </tr>
                </thead>
                <tbody>
                    {TDET}
                </tbody>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td class="color-light-title"></td>
                    <td class="color-light-title"></td>
                    <td class="color-light-title HAlignRight">{T_VALORNEGOCIADO}</td>
                    <td class="color-light-title HAlignRight">{T_VALORPAGADO}</td>
                    <td class="color-light-title HAlignRight">{T_TOTAL}</td>
                </tr>
            </table>
            <p><strong>Saludos cordiales.</strong></p>
            <p>ZAIMELLA DEL ECUADOR S.A.</p>
        </body>
    </html>';

        for ejecutivo in (
            SELECT listagg(distinct g.CODIGOGRUPO,',')within group (order by  g.CODIGOGRUPO,u.NOMBRES||' '||u.APELLIDOS,u.EMAIL) codigosgrupo ,trim(u.NOMBRES)||' '||trim(u.APELLIDOS) nombre_EJECUTIVO,u.EMAIL,U.CODERP
            FROM VT_GZM_CLIENTE G 
            INNER JOIN data.VT_CORP_USUARIO U ON (U.NUMEROIDENTIFICACION=ejecutivo)   
            where  1=1
            AND g.CODIGOGRUPO !=U.CODERP
            AND U.ESTADO!=0
            AND u.EMAIL IS NOT NULL
            group by trim(u.NOMBRES)||' '||trim(u.APELLIDOS) ,u.EMAIL,U.CODERP
        )
        loop
            V_HTML_DETA:='';
            V_HTML_BODY:=V_HTML_PLATILLA1;
            V_HTML_BODY:=REPLACE(V_HTML_BODY,'{EJECUTIVO}',EJECUTIVO.nombre_EJECUTIVO);
            V_HTML_TOTAL :=0;
            FOR DETALLE IN (
                SELECT I.ID,I.NOMBRE,p.DESCRIPCION/*||DECODE(M.OBSERVACIONES,NULL,NULL,' ('||UPPER(M.OBSERVACIONES)||')')*/DESCRIPCION
                , TO_CHAR( M.FECHAINICIO, 'Mon. YYYY', 'NLS_DATE_LANGUAGE=SPANISH') FECHAINICIO, TO_CHAR( M.FECHAFIN, 'Mon. YYYY', 'NLS_DATE_LANGUAGE=SPANISH')FECHAFIN
                , SUM(M.CANTIDAD* M.COSTO) NEGOCIADO
                , SUM(M.CANTIDAD* M.COSTO)*0 PAGADO
                , SUM(M.CANTIDAD* M.COSTO) TOTAL
                ,trim(g.NOMBRES) cliente
                FROM t_icom_inversiones I 
                INNER JOIN t_icom_cliente_material M ON I.ID=M.IDINVERSION 
                inner join vt_icom_materialpop p on p.id=m.idmaterial and p.clasificacion='0'  AND P.COMPANIA=I.COMPANIA
                inner join t_icom_inversion_cliente_g g on (M.IDINVERSION=g.IDINVERSION and m.CODIGOGRUPO=g.CODIGOGRUPO)
                WHERE I.idetapa in (2,3,7)
                and (( i.id= p_idinversion or p_idinversion is null) )AND I.IDPADRE IS NULL
                AND (M.NEGOCIACION=1 and M.ESTADO=1 and m.grupo is null)
                and m.codigogrupo in (select item from Table(pk_commons.f_dividirtexto(ejecutivo.codigosgrupo,',')))
                AND (M.FECHAINICIO+nvl(pk_commons.safe_to_number(PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '29', I.COMPANIA )),0) ) <= SYSDATE
                GROUP BY I.ID,I.NOMBRE,g.NOMBRES,p.DESCRIPCION/*||DECODE(M.OBSERVACIONES,NULL,NULL,' ('||UPPER(M.OBSERVACIONES)||')')*/
                ,TO_CHAR( M.FECHAINICIO, 'Mon. YYYY', 'NLS_DATE_LANGUAGE=SPANISH'), TO_CHAR( M.FECHAFIN, 'Mon. YYYY', 'NLS_DATE_LANGUAGE=SPANISH')
                HAVING SUM(M.CANTIDAD* M.COSTO)!=0
                ORDER BY I.ID DESC,g.NOMBRES,p.DESCRIPCION
            )
            LOOP
                    V_HTML_DETA:=V_HTML_DETA||TRIM( '<tr class="tr-hover"><td>'||detalle.id||'</td><td>'||detalle.NOMBRE||'</td><td>'||detalle.cliente||'</td><td>'||detalle.DESCRIPCION||'</td><td>'||detalle.FECHAINICIO||'</td><td>'||detalle.FECHAFIN||'</td><td  class="HAlignRight">'||TO_CHAR(detalle.NEGOCIADO,'FML999G999G999G999G990D00')||'</td><td  class="HAlignRight">'||TO_CHAR(detalle.PAGADO,'FML999G999G999G999G990D00')||'</td><td  class="HAlignRight">'||TO_CHAR(detalle.TOTAL,'FML999G999G999G999G990D00')||'</td></tr>');
                V_HTML_TOTAL :=V_HTML_TOTAL +detalle.TOTAL;
            END LOOP;
            if (V_HTML_DETA is  not null)then 
                DBMS_OUTPUT.PUT_LINE( 'nombre_EJECUTIVO:'||EJECUTIVO.nombre_EJECUTIVO||',EMAIL:'||EJECUTIVO.EMAIL);
                V_HTML_BODY:=REPLACE(V_HTML_BODY,'{TDET}',V_HTML_DETA);
                V_HTML_BODY:=REPLACE(V_HTML_BODY,'{T_VALORNEGOCIADO}',TO_CHAR(V_HTML_TOTAL,'FML999G999G999G999G990D00'));
                V_HTML_BODY:=REPLACE(V_HTML_BODY,'{T_VALORPAGADO}',TO_CHAR(0,'FML999G999G999G999G990D00'));
                V_HTML_BODY:=REPLACE(V_HTML_BODY,'{T_TOTAL}',TO_CHAR(V_HTML_TOTAL,'FML999G999G999G999G990D00'));
                PK_CORP_CORREO.SP_ENVIO(
                            P_MODULO => 'ICOM',
                            P_TO => EJECUTIVO.EMAIL,
                            P_FROM => 'infocomercial@zaimella.com',
                            P_SUBJECT => 'INVERSIONES COMERCIALES / Material POP o exhibiciones pendientes de facturar',
                            P_BODY => V_HTML_BODY
                          );
            end if;
          commit;
        end loop;
    END SP_NOTIFICACION_KAM_PROMOCIONES_POP ;

END PK_ICOM_NEGOCIACION;
/
/

