create or replace package pk_trad_pedidos as
  procedure sp_ventaspromedio;
  procedure sp_registrarpedidosugerido(p_datos clob default null, p_id number);
  procedure sp_ventaspedido;

  procedure sp_guardarproductosugerido(
    p_id in out number, p_compania varchar2, p_codigobarra varchar2,
    p_codigoproducto varchar2, p_activo varchar2
  );
  procedure sp_eliminarproductosugerido(p_id number, p_compania varchar2);
end pk_trad_pedidos;
/
