﻿  CREATE OR REPLACE PACKAGE             PK_COMMONS as
	/*---- Funciones ----*/
	--- Si se hace cambios: NOTIFICAR A TODOS LOS DESARROLLADORES
	function f_jde2g(p_fecha in number) return date;

	function f_g2jde(p_fecha in date) return number;

	function f_escorreo(p_correo in varchar2) return number;

	function f_secuencia(p_key in varchar) return number;

	function f_esnumero (p_valor in varchar2) return number;

	function f_esfecha (p_valor in varchar2) return number;

	function f_sumadiaslaborables(fechainicial timestamp, diasasumar number, diaslaborables number) return timestamp;

	function f_currenttimemillis return number;

	function f_obtieneemail(p_nombreusuario in varchar) return varchar;

	function f_encrypt (p_texto in varchar2) return raw;

	function f_decrypt (p_txt_enc in raw) return varchar2;

	function f_blob_to_clob (blob_in in blob) return clob;

	function f_clob_to_blob (clob_in in clob) return blob;

	function f_cedula_supervisor (p_cedula in varchar2) return varchar2;

	function f_mesespanol (p_mes in varchar2) return varchar2;

	function f_esbisiesto (p_anno in number) return number;

	function f_add_wdays(p_fecha date,p_dias number default 0) return date;

	function f_periodo (p_tipo in varchar2,p_fecha in date) return varchar2;

	function f_clob2blob (p_clob in clob) return blob;

	function f_dividirtexto(p_cadena varchar2,p_delimitador char) return split2col_tv_t;

	function f_dividirtextov2(p_cadena clob,p_delimitador char) return split2col_tc_t;
	/*
	** PropÃ³sito:	convertir una cadena en filas y columnas 
	** ParÃ¡metros:	
	**  p_cadena	varchar2:	parametro de entrada cadena  con los datos necesarios para ser convetida
	**  p_delimitadorcolumna char:  parametro de entrada delimitador de columna puede ser un caracter especial pipe"|"
	**  p_delimitadorfila char: parametro de entrada delimitador de fila puede ser un caracter especial punto y coma";"
	*/
	function f_split2table(p_cadena in varchar2,p_delimitadorcolumna char,p_delimitadorfila char) return split2tab_tv_t;

	function f_split2tablev2(p_cadena in clob,p_delimitadorcolumna char,p_delimitadorfila char) return split2tab_tc_t;

    FUNCTION f_split_cadena_tabla (
        p_cadena             CLOB,
        p_delimitadorcolumna CHAR := '#',
        p_delimitadorfila    char := 'Â¬'
    ) return t_tabla_dato_split pipelined;

	function f_esdesarrollador(p_usuario varchar2) return number;

	function f_nombreusuario (p_usuario in varchar2) return varchar2;

	function f_correousuario (p_usuario in varchar2) return varchar2;

	function f_enlacearchivo (p_numeroarchivo in number) return varchar2;

	function f_googledocview (p_numeroarchivo in number, p_mimetype in varchar2) return varchar2;

    function f_coloralerta (p_identificador in varchar2) return varchar2;

    function f_espacios (p_texto in varchar2, p_posicion in varchar2, p_cantidad in number) return varchar2;

	/*---- Procedimientos ----*/
	procedure sp_secuencia (p_key in varchar, p_contador out number);

	procedure sp_enviarcorreo(p_to in varchar2, p_from in varchar2, p_subject in varchar2, p_body in  clob);

	procedure sp_apex_log
	(	
		p_aplicacion	in varchar,
		p_paso 			in number,
		p_descripcion 	in varchar,
		p_mensaje		in varchar2,
		p_observacion	in varchar2,
		p_query			in clob
	);

	procedure sp_apex_excepciones
	(
		p_aplicacion 	in varchar2,
		p_paso 			in number,
		p_descripcion 	in varchar2,
		p_codexcepcion 	in number,
		p_mensaje 		in varchar2,
		p_observacion 	in varchar2,
		p_correo 		in varchar2,
		p_query 		in clob
	);

	procedure sp_imagen
	(
		p_imagen out varchar2
	);

	procedure sp_apex_correohtml
	(
		p_ingreso 			in clob,
		p_salida 			out clob
	);

	procedure sp_apex_correo
	(
		p_aplicacion 		in varchar2,
		p_remitente			in varchar2,
		p_para				in varchar2,
		p_concopia			in varchar2,
		p_concopiaoculta	in varchar2,
		p_asunto			in varchar2,
		p_contenido			in clob
	);

	procedure sp_apex_imagenbase64
	(
		p_idarchivo 	in number,
		p_tipoarchivo	out varchar2,
		p_codigo		out clob
	);

    procedure sp_correo_adjunto ( 
		p_aplicacion 		in varchar2,
		p_remitente			in varchar2,
		p_para				in varchar2,
		p_concopia			in varchar2,
		p_concopiaoculta	in varchar2,
		p_asunto			in varchar2,
		p_contenido			in clob,
		p_adjuntos 			in blobs_list
    );

	procedure sp_servirarchivo (p_numeroarchivo in number);

    function f_get_json_param (
        p_tramajson in clob,
        p_etiqueta  varchar2
    ) return clob;

	function safe_to_date(p_fecha varchar2) return date;

     function safe_to_number(p_numero varchar2) return number;
     PROCEDURE raise_error(p_msg VARCHAR2);
end;
/
