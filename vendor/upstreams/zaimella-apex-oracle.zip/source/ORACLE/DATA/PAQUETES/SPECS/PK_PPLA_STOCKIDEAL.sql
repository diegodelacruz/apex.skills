CREATE OR REPLACE PACKAGE DATA.PK_PPLA_STOCKIDEAL AS

    /*
      Aplica un ajuste masivo a los parametros activos del grupo seleccionado.

      Efectos:
        - Actualiza MINIMODIAS, MAXIMODIAS y/o OBSERVACION en T_PPLA_STOCKIDEALPARAMETROS.
        - Registra cabecera y detalle del ajuste.
        - Deja el ajuste pendiente de recalculo.
    */
    PROCEDURE SP_GUARDAR_AJUSTE (
        P_COMPANIA             IN  VARCHAR2,
        P_PERIODO              IN  NUMBER,
        P_TIPO_PRODUCTO        IN  VARCHAR2,
        P_TIPO_GRUPO           IN  VARCHAR2,
        P_GRUPO                IN  VARCHAR2,
        P_CODIGO_SKU           IN  VARCHAR2 DEFAULT NULL,
        P_APLICA_MINIMO        IN  NUMBER,
        P_MINIMO_DIAS          IN  NUMBER,
        P_APLICA_MAXIMO        IN  NUMBER,
        P_MAXIMO_DIAS          IN  NUMBER,
        P_APLICA_OBSERVACION   IN  NUMBER,
        P_OBSERVACION          IN  VARCHAR2,
        P_METODO_CALCULO       IN  VARCHAR2 DEFAULT NULL,
        P_SKU_EXCLUIDOS        IN  CLOB,
        P_MOTIVO               IN  VARCHAR2,
        P_USUARIO              IN  VARCHAR2,
        P_ID_AJUSTE            OUT NUMBER,
        P_ACTUALIZADOS         OUT NUMBER,
        P_OMITIDOS             OUT NUMBER,
        P_RECHAZADOS           OUT NUMBER
    );

    /*
      Recalcula el periodo cerrado asociado con un ajuste previamente guardado.

      Efectos:
        - Invoca el calculo vigente usando el mes siguiente y modo recalculo.
        - Actualiza el estado y mensaje de auditoria.
        - Ante error revierte solamente la regeneracion parcial y conserva el ajuste fuente.
    */
    PROCEDURE SP_RECALCULAR_AJUSTE (
        P_ID_AJUSTE       IN  NUMBER,
        P_COMPANIA        IN  VARCHAR2,
        P_USUARIO         IN  VARCHAR2,
        P_EXITO           OUT NUMBER,
        P_MENSAJE         OUT VARCHAR2
    );

    /*
      Encola de forma transaccional el recalculo completo del periodo.
      La solicitud solo se ejecuta cuando APEX confirma el guardado de la pagina.
    */
    PROCEDURE SP_SOLICITAR_RECALCULO (
        P_ID_AJUSTE IN  NUMBER,
        P_COMPANIA  IN  VARCHAR2,
        P_USUARIO   IN  VARCHAR2,
        P_ID_JOB    OUT NUMBER,
        P_MENSAJE   OUT VARCHAR2
    );

    /* Punto de entrada del job Oracle. No debe invocarse desde componentes APEX. */
    PROCEDURE SP_EJECUTAR_RECALCULO_JOB (
        P_ID_AJUSTE IN NUMBER
    );

END PK_PPLA_STOCKIDEAL;
/
