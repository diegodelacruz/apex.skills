create or replace package data.pk_cntr_rpa as
    /** Crea una corrida para una configuración activa perteneciente al usuario RPA. */
    procedure crear_ejecucion(
        p_id_configuracion in number,
        p_tipo_ejecucion in varchar2,
        p_usuario_apex in varchar2,
        p_ambiente in varchar2,
        p_id_ejecucion out number);

    /** Inicia la auditoría de una combinación válida documento-sujeto de la corrida. */
    procedure iniciar_detalle(
        p_id_ejecucion in number,
        p_id_documento in number,
        p_tipo_sujeto in varchar2,
        p_id_sujeto in number,
        p_id_detalle out number,
        p_id_empresa_origen in number default null);

    /** Guarda archivo, evidencia versionada y resultado exitoso de un detalle en proceso. */
    procedure registrar_resultado(
        p_id_detalle in number,
        p_archivo in blob,
        p_nombre_archivo in varchar2,
        p_tipo_mime in varchar2,
        p_origen in varchar2,
        p_fecha_obtencion in timestamp,
        p_hash_sha256 in varchar2,
        p_usuario in varchar2,
        p_id_evidencia out number,
        p_version out number);

    /** Registra o sustituye una evidencia manual desde APEX_APPLICATION_TEMP_FILES. */
    procedure registrar_evidencia_manual(
        p_id_documento in number,
        p_tipo_sujeto in varchar2,
        p_id_sujeto in number,
        p_archivo in varchar2,
        p_usuario in varchar2,
        p_id_evidencia out number,
        p_numeroarchivo out number);

    /** Registra un estado terminal sin archivo para un detalle en proceso. */
    procedure registrar_estado(
        p_id_detalle in number,
        p_estado in varchar2,
        p_mensaje in varchar2);

    /** Registra una incidencia terminal o reintentable para un detalle en proceso. */
    procedure registrar_error(
        p_id_detalle in number,
        p_tipo_error in varchar2,
        p_mensaje in varchar2,
        p_paso_orden in number,
        p_reintentable in varchar2);

    /** Retoma un detalle reintentable y aumenta su contador de intento. */
    procedure reintentar_detalle(p_id_detalle in number);

    /** Indica si el usuario posee la accion especial VER_TODOS en el monitor RPA. */
    function tiene_ver_todos(
        p_usuario in varchar2,
        p_compania in varchar2) return number;

    /** Indica si el usuario posee la accion TODOS de la matriz documental. */
    function tiene_todos_matriz(
        p_usuario in varchar2,
        p_compania in varchar2) return number;

    /** Autoriza la consulta de una ejecucion por propietario o permiso especial. */
    function puede_ver_ejecucion(
        p_id_ejecucion in number,
        p_usuario in varchar2,
        p_compania in varchar2) return number;

    /** Autoriza una evidencia desde una configuracion propia o una ejecucion visible. */
    function puede_ver_evidencia(
        p_id_evidencia in number,
        p_usuario in varchar2,
        p_compania in varchar2,
        p_id_ejecucion in number default null,
        p_id_configuracion in number default null,
        p_mostrar_todos in varchar2 default 'N') return number;

    /** Recupera el archivo exacto capturado por un detalle visible de ejecución. */
    procedure obtener_evidencia_detalle(
        p_id_detalle in number,
        p_usuario in varchar2,
        p_compania in varchar2,
        p_archivo out blob,
        p_nombre_archivo out varchar2,
        p_tipo_mime out varchar2);

    /** Genera la matriz HTML de sujetos por documento para una configuracion propia. */
    function renderizar_matriz(
        p_id_configuracion in number,
        p_usuario in varchar2,
        p_compania in varchar2,
        p_mostrar_todos in varchar2 default 'N') return clob;

    /** Comprime las versiones vigentes de un sujeto dentro de una configuracion propia. */
    procedure obtener_zip_vigentes(
        p_id_configuracion in number,
        p_tipo_sujeto in varchar2,
        p_id_sujeto in number,
        p_usuario in varchar2,
        p_compania in varchar2,
        p_archivo out blob,
        p_nombre_archivo out varchar2,
        p_mostrar_todos in varchar2 default 'N');

    /** Comprime los archivos de detalles exitosos de una ejecucion autorizada. */
    procedure obtener_zip_ejecucion(
        p_id_ejecucion in number,
        p_tipo_sujeto in varchar2,
        p_id_sujeto in number,
        p_usuario in varchar2,
        p_compania in varchar2,
        p_archivo out blob,
        p_nombre_archivo out varchar2);
end pk_cntr_rpa;
/
