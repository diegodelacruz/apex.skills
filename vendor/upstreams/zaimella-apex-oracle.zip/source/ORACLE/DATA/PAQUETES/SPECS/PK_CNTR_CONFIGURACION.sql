/**
 * Paquete: PK_CNTR_CONFIGURACION
 * Objetivo: Gestionar configuraciones documentales CNTR.
 * Responsable: JBALCAZAR
 */
create or replace package data.pk_cntr_configuracion as
    /*
      Objetivo: centralizar la logica transaccional de administracion
      de portales, documentos y pasos RPA del modulo CNTR.
      Responsable: JBALCAZAR.
    */

    procedure guardar_portal(
        p_id_portal in out nocopy number,
        p_compania in varchar2,
        p_nombre_portal in varchar2,
        p_url_base in varchar2,
        p_descripcion in varchar2,
        p_requiere_captcha in number,
        p_requiere_login in number,
        p_estado in varchar2
    );

    -- guardar_documento: contrato p?blico del m?dulo CNTR.

    procedure guardar_documento(
        p_id_documento in out nocopy number,
        p_id_portal in number,
        p_compania in varchar2,
        p_nombre_documento in varchar2,
        p_evidencia_esperada in varchar2,
        p_modo_captura in varchar2,
        p_dato_busqueda in varchar2,
        p_prompt_ia in clob,
        p_actualizacion_minima_dias in number,
        p_estado in varchar2
    );

    -- guardar_paso: contrato p?blico del m?dulo CNTR.

    procedure guardar_paso(
        p_id_paso in out nocopy number,
        p_id_documento in number,
        p_orden in number,
        p_instruccion in varchar2,
        p_valor_entrada in varchar2,
        p_requiere_intervencion in number,
        p_estado in varchar2
    );

    /** Valida que el documento tenga pasos activos ejecutables y un terminal de evidencia. */
    procedure validar_pasos_documento(p_id_documento in number);

    -- guardar_paso: contrato p?blico del m?dulo CNTR.

    procedure guardar_paso(
        p_id_paso in out nocopy number,
        p_id_documento in number,
        p_orden in number,
        p_tipo_accion in varchar2,
        p_selector_elemento in varchar2,
        p_valor_entrada in varchar2,
        p_tiempo_espera_seg in number,
        p_requiere_intervencion in number,
        p_descripcion in varchar2,
        p_estado in varchar2,
        p_origen_valor in varchar2 default null
    );

    /*
      Guarda una persona matriculada para consultas documentales.

      Parametros:
        P_ID_PERSONA: identificador de la persona. Si es nulo crea un registro.
        P_COMPANIA: compania del registro; si es nulo toma G_COMPANIA.
        P_TIPO_IDENTIFICACION: CI, RUC o PASAPORTE.
        P_IDENTIFICACION: numero de identificacion unico por compania y tipo.

      Efectos:
        Inserta o actualiza DATA.T_CNTR_PERSONAS.
    */
    procedure guardar_persona(
        p_id_persona in out nocopy number,
        p_compania in varchar2,
        p_tipo_identificacion in varchar2,
        p_identificacion in varchar2,
        p_nombres in varchar2,
        p_correo in varchar2,
        p_telefono in varchar2,
        p_estado in varchar2
    );

    /*
      Guarda una empresa matriculada para consultas documentales.

      Efectos:
        Inserta o actualiza DATA.T_CNTR_EMPRESAS.
    */
    procedure guardar_empresa(
        p_id_empresa in out nocopy number,
        p_compania in varchar2,
        p_ruc in varchar2,
        p_razon_social in varchar2,
        p_nombre_comercial in varchar2,
        p_tipo_empresa in varchar2,
        p_estado in varchar2
    );

    /*
      Vincula una persona existente a una empresa existente con un rol funcional.

      Efectos:
        Inserta o actualiza DATA.T_CNTR_EMPRESA_PERSONAS.
    */
    procedure vincular_persona_empresa(
        p_id_empresa_persona in out nocopy number,
        p_id_empresa in number,
        p_id_persona in number,
        p_rol in varchar2,
        p_estado in varchar2,
        p_observacion in varchar2
    );

    /*
      Inactiva un vinculo persona-empresa.
    */
    procedure desvincular_persona_empresa(p_id_empresa_persona in number);

    /*
      Procesa la coleccion Excel vigente como carga masiva de personas.

      Efectos:
        Lee DATA.VT_APEX_EXCEL, inserta o actualiza personas y registra
        resultado por fila en DATA.T_CNTR_CARGAS y DATA.T_CNTR_CARGA_DETALLES.
    */
    procedure confirmar_carga_personas(
        p_compania in varchar2,
        p_id_carga out nocopy number
    );

    /*
      Procesa la coleccion Excel vigente como carga masiva de vinculos empresa-persona.
    */
    procedure confirmar_carga_vinculos(
        p_compania in varchar2,
        p_id_empresa in number,
        p_id_carga out nocopy number
    );

    /*
      Devuelve el contenido CSV esperado para carga masiva de personas.
    */
    function formato_personas return clob;

    /*
      Descarga el formato Excel esperado para carga masiva de personas.
    */
    procedure descargar_formato_personas_xlsx;

    /*
      Devuelve el contenido CSV esperado para carga masiva de vinculos empresa-persona.
    */
    function formato_vinculos return clob;

    /*
      Descarga el formato Excel esperado para carga masiva de vinculos empresa-persona.
    */
    procedure descargar_formato_vinculos_xlsx;

    /* Descarga el formato Excel para asociar sujetos existentes a una configuracion. */
    procedure descargar_formato_config_sujetos_xlsx;

    /* Descarga el formato Excel para asociar empresas y sujetos existentes a una configuracion. */
    procedure descargar_formato_config_empresa_personas_xlsx;

    /* Asocia sujetos existentes a una configuración desde VT_APEX_EXCEL. */
    procedure confirmar_carga_config_sujetos(
        p_id_configuracion in number,
        p_compania in varchar2,
        p_id_carga out nocopy number
    );

    /* Asocia empresas y sus sujetos existentes a una configuración desde VT_APEX_EXCEL. */
    procedure confirmar_carga_config_empresa_personas(
        p_id_configuracion in number,
        p_compania in varchar2,
        p_id_carga out nocopy number
    );

    -- eliminar_paso: contrato p?blico del m?dulo CNTR.

    procedure eliminar_paso(p_id_paso in number);
    -- subir_paso: contrato p?blico del m?dulo CNTR.
    procedure subir_paso(p_id_paso in number);
    -- bajar_paso: contrato p?blico del m?dulo CNTR.
    procedure bajar_paso(p_id_paso in number);

    -- guardar_configuracion: contrato p?blico del m?dulo CNTR.

    procedure guardar_configuracion(p_id_configuracion in out nocopy number, p_compania in varchar2, p_nombre in varchar2, p_estado in
    varchar2);
    -- guardar_config_sujeto: contrato p?blico del m?dulo CNTR.
    procedure guardar_config_sujeto(p_id_configuracion in number, p_tipo_sujeto in varchar2, p_id_sujeto in number, p_estado in varchar2);
    -- guardar_config_documento: contrato p?blico del m?dulo CNTR.
    procedure guardar_config_documento(p_id_configuracion in number, p_id_documento in number, p_estado in varchar2);
    -- guardar_config_empresa: contrato p?blico del m?dulo CNTR.
    procedure guardar_config_empresa(p_id_configuracion in number, p_id_empresa in number, p_incluir_todos in varchar2, p_personas_csv in
    varchar2);
    -- eliminar_config_documento: contrato p?blico del m?dulo CNTR.
    procedure eliminar_config_documento(p_id_configuracion in number, p_id_documento in number);
    -- eliminar_config_sujeto: contrato p?blico del m?dulo CNTR.
    procedure eliminar_config_sujeto(p_id_configuracion in number, p_id_sujeto in number, p_tipo_sujeto in varchar2 default 'PERSONA');
    -- eliminar_config_empresa: contrato p?blico del m?dulo CNTR.
    procedure eliminar_config_empresa(p_id_configuracion in number, p_id_config_empresa in number);
    -- cambiar_estado_config_documento: contrato p?blico del m?dulo CNTR.
    procedure cambiar_estado_config_documento(p_id_configuracion in number, p_id_documento in number, p_estado in varchar2);
    -- cambiar_estado_config_sujeto: contrato p?blico del m?dulo CNTR.
    procedure cambiar_estado_config_sujeto(p_id_configuracion in number, p_id_sujeto in number, p_estado in varchar2, p_tipo_sujeto in
    varchar2 default 'PERSONA');
    -- cambiar_estado_config_empresa: contrato p?blico del m?dulo CNTR.
    procedure cambiar_estado_config_empresa(p_id_configuracion in number, p_id_config_empresa in number, p_estado in varchar2);
    /** Comparte una configuracion con un usuario activo del mismo DEPARTAMENTO corporativo. */
    procedure compartir_configuracion(p_id_configuracion in number, p_usuario_apex in varchar2);
    /** Revoca el acceso compartido sin alterar la configuracion ni al creador. */
    procedure eliminar_usuario_compartido(p_id_configuracion in number, p_usuario_apex in varchar2);
    -- activar_configuracion: contrato p?blico del m?dulo CNTR.
    procedure activar_configuracion(p_id_configuracion in number, p_estado in varchar2);
end pk_cntr_configuracion;
/
