create or replace package data.pk_cntr_ia_analisis as
    /*
      Paquete: PK_CNTR_IA_ANALISIS
      Objetivo: administra solicitudes, cabeceras y resultados del análisis IA documental CNTR.
      Responsable: JBALCAZAR.
    */
    procedure crear_solicitud(
        p_id_configuracion in number,
        p_tipo_sujeto in varchar2 default null,
        p_id_sujeto in number default null,
        p_usuario in varchar2,
        p_compania in varchar2,
        p_id_solicitud out nocopy number,
        p_total_cabeceras out nocopy number);
    procedure notificar_solicitud(p_id_solicitud in number);
    procedure obtener_cabeceras(p_id_solicitud in number, p_resultado out sys_refcursor);
    procedure iniciar_analisis(p_id_analisis in number);
    procedure reintentar_analisis(p_id_analisis in number, p_mensaje in varchar2 default null);
    procedure registrar_documento(
        p_id_analisis in number, p_id_documento in number, p_id_evidencia in number,
        p_numero_archivo in number, p_nombre_archivo in varchar2, p_prompt_ia in clob,
        p_estado_extraccion in varchar2, p_texto_extraido in clob, p_paginas_procesadas in number,
        p_advertencias in clob, p_error_tecnico in varchar2);
    procedure finalizar_analisis(
        p_id_analisis in number, p_estado in varchar2, p_proveedor in varchar2,
        p_modelo in varchar2, p_resultado in clob, p_resumen in clob, p_confianza in number,
        p_advertencias in clob, p_error_tecnico in varchar2);
end pk_cntr_ia_analisis;
/
