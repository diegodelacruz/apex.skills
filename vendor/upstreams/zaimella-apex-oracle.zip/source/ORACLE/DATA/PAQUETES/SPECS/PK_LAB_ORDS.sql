/*
  Paquete: PK_LAB_ORDS
  Objetivo: Publicar y validar una API ORDS minima y administrar su cliente OAuth contractual.
  Responsable: JBALCAZAR
  Alcance:
    - Modulo ORDS ZAIMELLA_ORDS_LAB.
    - Privilegio ZAIMELLA_ORDS_LAB_PRIV.
    - Cliente ZAIMELLA_ORDS_LAB_CLIENT.
  Consideraciones:
    - El cliente OAuth se crea una sola vez por ambiente y no se rota durante mantenimiento ordinario.
    - Las credenciales se generan y cifran fuera de Oracle; este paquete solo las recibe mediante binds.
*/
create or replace package PK_LAB_ORDS authid definer as
    /*
      Retorna la version funcional publicada por el endpoint de salud.

      Retorna:
        Version semantica del contrato ORDS del laboratorio.
    */
    function F_VERSION return varchar2;

    /*
      Crea o actualiza idempotentemente el modulo, su ruta de salud y el privilegio.

      Efectos:
        - Publica ZAIMELLA_ORDS_LAB sin borrar el modulo existente.
        - Conserva clientes OAuth y secretos ya provisionados.
    */
    procedure APLICAR;

    /*
      Provisiona el cliente OAuth contractual solo cuando aun no existe.

      Parametros:
        P_CLIENT_ID: Identificador aleatorio generado y cifrado localmente.
        P_CLIENT_SECRET: Secreto aleatorio generado y cifrado localmente.
        P_SUPPORT_EMAIL: Correo operativo externo, no una constante del codigo.
        P_RESULTADO: Resultado CREATED o REUSED sin incluir credenciales.

      Errores:
        - Rechaza parametros vacios o un client_id distinto para el mismo nombre contractual.
    */
    procedure PROVISIONAR_OAUTH(
        P_CLIENT_ID in varchar2,
        P_CLIENT_SECRET in varchar2,
        P_SUPPORT_EMAIL in varchar2,
        P_RESULTADO out varchar2
    );

    /*
      Valida la metadata completa del modulo ORDS y su privilegio.

      Parametros:
        P_RESULTADO: Resumen tecnico sin informacion sensible.
    */
    procedure VALIDAR(P_RESULTADO out varchar2);

    /*
      Valida que el client_id local corresponde al cliente contractual y conserva el privilegio.

      Parametros:
        P_CLIENT_ID: Identificador descifrado localmente, enviado mediante bind.
        P_RESULTADO: Resultado OAUTH_OK sin incluir credenciales.
    */
    procedure VALIDAR_OAUTH(
        P_CLIENT_ID in varchar2,
        P_RESULTADO out varchar2
    );

    /*
      Recupera las credenciales existentes desde la metadata ORDS del owner.

      Seguridad:
        - Solo se invoca para recuperar un almacen local perdido.
        - No escribe logs ni retorna las credenciales a SQL de texto.
        - El acceso efectivo queda limitado a las cuentas con EXECUTE sobre este package.

      Parametros:
        P_CLIENT_ID: Identificador contractual existente.
        P_CLIENT_SECRET: Secreto existente; el cliente Python lo cifra de inmediato con DPAPI.
        P_RESULTADO: Resultado sin credenciales.
    */
    procedure RECUPERAR_OAUTH(
        P_CLIENT_ID out varchar2,
        P_CLIENT_SECRET out varchar2,
        P_RESULTADO out varchar2
    );
end PK_LAB_ORDS;
/
