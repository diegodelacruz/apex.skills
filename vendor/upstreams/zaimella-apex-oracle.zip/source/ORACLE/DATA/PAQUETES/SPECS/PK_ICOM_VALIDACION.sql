﻿prompt Esquema DATA para codigo PL/SQL
alter session set current_schema=DATA;

prompt PROD PACKAGE DATA.PK_ICOM_VALIDACION

  CREATE OR REPLACE EDITIONABLE PACKAGE PK_ICOM_VALIDACION AS 

  /* Paquete que contiene la logica de validacion de la aplicacion APEX 137 (INVERSIONES COMERCIALES).
		@author JAsanza
		@fecha Nov/2022        
	*/
    G_MODULO VARCHAR(4):='ICOM';
	FUNCTION F_VALIDACIONTIPO (P_CODIGOCATEGORIA VARCHAR2, P_IDVALIDACIONTIPO VARCHAR2 , 
                             P_IDINVERSIONTIPO NUMBER, P_COMPANIA VARCHAR2) RETURN NUMBER;
                             
    PROCEDURE SP_ELIMINAVALIDACION ( P_IDVALIDACIONTIPO VARCHAR2, P_IDAGRUPACION NUMBER );
    PROCEDURE SP_BORRAVALIDACION ( P_IDVALIDACION NUMBER, P_IDAGRUPACION NUMBER ) ;
                                   
    PROCEDURE SP_GRABAVALIDACION ( P_IDINVERSION NUMBER, P_CODIGOGRUPO VARCHAR2, P_IDVALIDACIONTIPO VARCHAR2,
                                   P_FORMAPAGO VARCHAR2, P_IDAGRUPACION IN OUT NUMBER,
                                   P_COMPANIA VARCHAR2, P_USUARIO VARCHAR2 );

    PROCEDURE SP_ACTULIZAFECHAVAL ( P_IDAGRUPACION NUMBER, P_ID NUMBER, P_FECHAINICIO DATE DEFAULT NULL, 
        P_FECHAFIN DATE DEFAULT NULL, P_VAL_FECHAINICIO DATE DEFAULT NULL, P_VAL_FECHAFIN DATE DEFAULT NULL, 
        P_IDINVERSIONTIPO NUMBER DEFAULT NULL, P_IDVALIDACIONTIPO VARCHAR2 DEFAULT NULL, 
        P_IDINVERSION NUMBER DEFAULT NULL, P_CODIGOGRUPO VARCHAR2 DEFAULT NULL );  
        
    FUNCTION F_VALIDAFECHASRANGO (P_IDAGRUPACION NUMBER, P_IDINVERSION NUMBER, P_CODIGOGRUPO VARCHAR2, 
                                  P_FECHAINICIO DATE, P_FECHAFIN DATE ) RETURN VARCHAR2 ;
                                  
    PROCEDURE SP_VALIDACION_VENTAS (P_IDAGRUPACION NUMBER, P_IDVALIDACIONTIPO NUMBER, P_COMPANIA VARCHAR2,
    P_FACTURA VARCHAR2 DEFAULT NULL, P_IDVALIDACION NUMBER DEFAULT NULL, P_CODIGOPRODUCTO VARCHAR2 DEFAULT NULL, 
    P_CODIGOBARRA VARCHAR2 DEFAULT NULL, P_FECHA DATE DEFAULT NULL, P_CANTIDAD NUMBER DEFAULT NULL, 
    P_CODIGOCLIENTE VARCHAR2 DEFAULT NULL, P_DESCUENTO NUMBER DEFAULT NULL, P_FUENTE VARCHAR2 DEFAULT NULL,
    P_USUARIO varchar2 DEFAULT NULL  , 
    p_grupocliente number default 2) ;

    FUNCTION F_VALIDAFECHASVAL (P_IDAGRUPACION NUMBER) RETURN NUMBER ;
    
    FUNCTION F_CAL_VALORCLIENTE( P_CLI_CANTIDAD NUMBER, P_SELLOUTCANTIDAD NUMBER, P_PRECIOLIS NUMBER, 
                                 P_PCTDESCUENTO NUMBER, P_SELLOUTVALOR NUMBER, P_PCT_APLICA NUMBER ) RETURN NUMBER ;
                                 
    FUNCTION F_CAL_VALORZAIMELLA(P_VALORCLIENTE NUMBER,P_SELLOUT NUMBER,P_PCTAPLICACION NUMBER,P_PRECIOLIS NUMBER,P_PCTDESCUENTO NUMBER) RETURN NUMBER;

   PROCEDURE SP_GRABA_CLIENTEVALIDACION_DET ( P_IDVALIDACION NUMBER, P_IDINVERSION NUMBER,
        P_CODIGOCLIENTE VARCHAR2, P_CODIGOPRODUCTO VARCHAR2, P_PCT_APLICACION NUMBER,
        P_CLI_CANTIDAD NUMBER, P_CLI_VALOR NUMBER, P_CLI_DESCUENTO NUMBER,
        P_VALORZAIMELLA NUMBER, P_VALIDACION_TIPO NUMBER, P_FACTURA VARCHAR2 default null ) ;

   PROCEDURE SP_ACTUALIZA_CLI_VAL_DET ( P_IDAGRUPACION NUMBER, P_VALIDACION_TIPO NUMBER, P_COMPANIA VARCHAR2) ;     

   FUNCTION F_NOTACREDITOTOTAL (P_FACTURA VARCHAR2, P_COMPANIA VARCHAR2, P_CODIGOPRODUCTO VARCHAR2) RETURN NUMBER ;

   FUNCTION F_NOTACREDIDESCRIPCION (P_FACTURA VARCHAR2, P_COMPANIA VARCHAR2, P_CODIGOPRODUCTO VARCHAR2) RETURN VARCHAR2;

   PROCEDURE SP_ACUMULAVALOR( P_IDAGRUPACION NUMBER, P_IDVALIDACION NUMBER DEFAULT 0, 
        P_CODIGOGRUPO NUMBER DEFAULT 0 );

   PROCEDURE SP_ACTUALIZACLI_VAL (P_IDVALIDACION NUMBER, P_IDAGRUPACION NUMBER, 
        P_NOMBRE VARCHAR2, P_OBSERVACION VARCHAR2, P_VALORCLIENTE NUMBER DEFAULT NULL );

   PROCEDURE SP_ENVIARRUTA (P_IDAGRUPACION NUMBER, P_NOMBREAGRUPACION VARCHAR2, P_USUARIO VARCHAR2,
        P_COMPANIA VARCHAR2 );

   PROCEDURE SP_APROBARVALIDACION (P_IDAGRUPACION NUMBER, P_TIPO NUMBER, P_USUARIO VARCHAR2, P_COMPANIA VARCHAR DEFAULT '00001' ) ;

   PROCEDURE SP_PASARCIERRE (P_IDAGRUPACION NUMBER) ;

   PROCEDURE SP_CORREOAPROBACION (P_IDAGRUPACION NUMBER );   

   PROCEDURE SP_AUTO_ETAPA ;
   
   PROCEDURE SP_ELIMINAFACTURA (P_IDVALIDACION NUMBER, P_CODIGO VARCHAR2 default null, P_CODIGOPRODUCTO VARCHAR2 default null, 
                                 P_FACTURA VARCHAR2 default null );
    FUNCTION F_BUSCACORREOPAGO (P_IDFORMAPAGO VARCHAR2 , P_COMPANIA VARCHAR2  )   RETURN VARCHAR2;
    
    PROCEDURE SP_guardaRebate (P_IDINVERSION NUMBER, P_CODIGOGRUPO VARCHAR2, P_IDVALIDACION NUMBER, P_FILA NUMBER, P_IDREBATE NUMBER,
        P_VALOR1 VARCHAR2 DEFAULT NULL, P_VALOR2 VARCHAR2 DEFAULT NULL, P_VALOR3 VARCHAR2 DEFAULT NULL, P_VALOR4 VARCHAR2 DEFAULT NULL,
        P_VALOR5 VARCHAR2 DEFAULT NULL, P_VALOR6 VARCHAR2 DEFAULT NULL, P_VALOR7 VARCHAR2 DEFAULT NULL, P_VALOR8 VARCHAR2 DEFAULT NULL,
        P_VALOR9 VARCHAR2 DEFAULT NULL, P_VALOR10 VARCHAR2 DEFAULT NULL, P_VALOR11 VARCHAR2 DEFAULT NULL, P_VALOR12 VARCHAR2 DEFAULT NULL,
        P_VALOR13 VARCHAR2 DEFAULT NULL, P_VALOR14 VARCHAR2 DEFAULT NULL, P_VALOR15 VARCHAR2 DEFAULT NULL, P_VALOR16 VARCHAR2 DEFAULT NULL,
        P_VALOR17 VARCHAR2 DEFAULT NULL, P_VALOR18 VARCHAR2 DEFAULT NULL, P_VALOR19 VARCHAR2 DEFAULT NULL, P_VALOR20 VARCHAR2 DEFAULT NULL );

    PROCEDURE SP_cambiaValidacion( P_IDAGRUPACION NUMBER, P_VALIDACIONTIPO NUMBER, P_INVERSIONTIPO NUMBER ) ;
    FUNCTION F_TRAERVALORPLANIFICADO (
        P_IDINVERSION NUMBER,
        P_SELLOUT NUMBER DEFAULT NULL,
        P_DURACION NUMBER DEFAULT NULL,
        P_CRECIMIENTO NUMBER DEFAULT NULL,
        P_CODIGOGRUPO NUMBER DEFAULT NULL,
        P_TIPO VARCHAR2 DEFAULT 'V'
        ) RETURN NUMBER ;    
    PROCEDURE SP_DISTRIBUCIONFACTURACONDESCUENTOAPROBADAS (P_IDINVERSION NUMBER DEFAULT NULL);
    
    PROCEDURE sp_validacion_subir_excel_NC (p_idagrupacion NUMBER,p_mensaje OUT varchar2);
    
   
    
    PROCEDURE SP_VALIDACION_CONTRAFACTURA (p_idagrupacion NUMBER,p_mensaje OUT varchar2) ;
    
    procedure sp_validacion_a_notascredito(P_IDAGRUPACION NUMBER,P_COMPANIA varchar2 default '00001', P_RUTA NUMBER DEFAULT 1);
   
    FUNCTION F_TRAER_TIPONOTACREDITO(
        p_AREA_NC VARCHAR2,
        p_idvalidaciontipo VARCHAR2 default null,
        P_IDINVERSIONTIPO VARCHAR2 default null,
        p_aca_marca VARCHAR2 default null,
        p_aca_linea VARCHAR2 default null,
        P_COMPANIA VARCHAR2 DEFAULT '00001'
    ) RETURN VARCHAR2;
    
    procedure SP_RECHAZA_NC(P_LOTE NUMBER);
    
END PK_ICOM_VALIDACION;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "DATA"."PK_ICOM_VALIDACION" AS 

	/* 
	* Funcion que retorna 1 si encuentra la validacion con los parametro, 0 en caso contrario
	* P_codigocliente es el codigo del cliente que se debe validar
	* P_idvalidaciontipo es el codigo de la validacion tipo que se debe buscar
	* P_idinversiontipo es el codigo de la inversion tipo que se debe buscar      jenny
	*/
	FUNCTION F_VALIDACIONTIPO (P_CODIGOCATEGORIA VARCHAR2, P_IDVALIDACIONTIPO VARCHAR2 , 
                             P_IDINVERSIONTIPO NUMBER, P_COMPANIA VARCHAR2 ) RETURN NUMBER AS
	v_cuenta number := 0 ;							
	BEGIN
		begin
			select count(1) into v_cuenta
			from data.T_ICOM_CONF_CLIENTE_TIPO_FP
			where COMPANIA = p_compania
			and CODIGOCLIENTE IN (SELECT DISTINCT C.CODIGOGRUPO 
                                  FROM DATA.T_ICOM_INVERSION_CLIENTE_G C
                                  INNER JOIN t_icom_cliente_fechas F ON (C.IDINVERSION=F.IDINVERSION AND  C.CODIGOGRUPO=F.CODIGOGRUPO AND F.ESTADO=1)
                                  WHERE C.CATEGORIA = nvl(P_CODIGOCATEGORIA,'0')
                                  AND C.NEGOCIACION in (1,2,3) )
			and nvl(IDINVERSIONTIPO,0) = nvl(p_idinversiontipo,0)
			and nvl(IDVALIDACIONTIPO,0) = nvl(p_idvalidaciontipo,'0')
			and ESTADO = 1 
			and ROWNUM = 1;
		exception when no_data_found THEN
			v_cuenta := 0 ;
		end ;
		return nvl(v_cuenta,0);		
	END ;

    
    /* Procedimiento que elimina las validacines existentes para esa agrupacion 
    *   p_idvalidaciontipo el codigo del tipo de validacion
    *   p_formapago el codigo de la forma de pago establecida
    *   p_idagrupacion el codigo que identifica a que grupo de validacion pertenece
    */
    PROCEDURE SP_ELIMINAVALIDACION ( P_IDVALIDACIONTIPO VARCHAR2, P_IDAGRUPACION NUMBER) AS
    BEGIN
        --se elimina el detalle de todas las validaciones
        DELETE FROM data.t_icom_cliente_validacion_det det
        WHERE EXISTS ( SELECT 1
            FROM data.t_icom_cliente_validacion val
            WHERE val.id = det.idvalidacion  AND val.idagrupacion = p_idagrupacion
              AND val.idvalidaciontipo = NVL(p_idvalidaciontipo, val.idvalidaciontipo)
              AND val.estado = 0        );
        COMMIT;

        --se elimina las validaciones
        delete from  data.t_icom_cliente_validacion
         where idagrupacion = p_idagrupacion and idvalidaciontipo = nvl(p_idvalidaciontipo, idvalidaciontipo)
                                                  and estado = 0 ;
        COMMIT;                                          
                                                  
    END;
    
    /* Procedimiento que elimina las validacines existentes para la inversion y tipo definod
    *   p_idvalidacion el codigo de validacion
    *   p_idagrupacion el codigo que identifica a que grupo de validacion pertenece
    */
    PROCEDURE SP_BORRAVALIDACION ( P_IDVALIDACION NUMBER, P_IDAGRUPACION NUMBER ) AS
    BEGIN
        --se elimina el detalle de las validaciones
        delete from data.t_icom_cliente_validacion_det
        where idvalidacion = p_idvalidacion ;
        --se elimina las validaciones
        delete from  data.t_icom_cliente_validacion
          where idagrupacion = p_idagrupacion and id = p_idvalidacion ;
    END;
    
    /* Procedimiento que inserta la validacion si no existe o actualiza en caso de existir con estado 0
    *   p_idinversion el codigo de la inversion
    *   p_codigogrupo el codigo del grupo de cliente que se aplica
    *   p_formapago el codigo de la forma de pago establecida
    *   p_idagrupacion el codigo que identifica a que grupo de validacion pertenece
    */
    PROCEDURE SP_GRABAVALIDACION ( P_IDINVERSION NUMBER, P_CODIGOGRUPO VARCHAR2, P_IDVALIDACIONTIPO VARCHAR2, 
                                   P_FORMAPAGO VARCHAR2, P_IDAGRUPACION IN OUT NUMBER, 
                                   P_COMPANIA VARCHAR2, P_USUARIO VARCHAR2 ) AS

    BEGIN
        --dbms_output.put_line( 'Inicia ' );
        if P_IDAGRUPACION is null then
            begin
                select max(nvl(idagrupacion,0)) + 1 into P_IDAGRUPACION
                from DATA.T_ICOM_CLIENTE_VALIDACION ;
            exception
                when no_data_found then P_IDAGRUPACION := 1 ;
                when others then P_IDAGRUPACION := 1 ;
            end ;    
            dbms_output.put_line( 'Id Agrupacion '|| p_idagrupacion );
        end if;

        --en caso de ser validacion rebate/otros se debe eliminar el detalle existente y borar los rebate 
        if (p_idvalidaciontipo in (6) ) then
            begin
                --borrar el detalle
                delete from data.t_icom_cliente_validacion_det
                where idvalidacion in ( select distinct id 
                                        from data.t_icom_cliente_validacion 
                                        where idvalidaciontipo = 6  
                                        and ( ( idagrupacion = p_idagrupacion  and  estado = 0 ) 
                                           or ( estado in (0,2) and idagrupacion != p_idagrupacion ) )
                                        and idinversion = p_idinversion and codigogrupo = p_codigogrupo  )
                                         ;
                commit;  
                --borra las cabeceras y los idrebate
                delete from data.t_icom_cliente_validacion
                where idvalidaciontipo = 6  
                  and ( ( idagrupacion = p_idagrupacion  and  estado = 0 ) 
                    or ( estado in (0,2) and idagrupacion != p_idagrupacion ))
                  and idinversion = p_idinversion and codigogrupo = p_codigogrupo ;
                commit;                         
            end;
        end if;
        
        --if (p_idvalidaciontipo in (1,3) ) then
        MERGE INTO DATA.T_ICOM_CLIENTE_VALIDACION v
            USING (select i.id, i.idinversiontipo, g.codigogrupo, p_idvalidaciontipo idvalidaciontipo, p_formapago idformapago, 
                           g.fechainicio, g.fechafin, i.compania
                    from data.t_icom_inversiones i 
                        inner join data.t_icom_inversion_cliente_g g on (i.id = g.idinversion and g.negociacion in (1,3) )
                    where i.id = p_idinversion 
                    and g.codigogrupo = p_codigogrupo
                    ) i
            ON ( v.idinversion = i.id and v.idinversiontipo = i.idinversiontipo
                and v.codigogrupo = i.codigogrupo and v.idvalidaciontipo = i.idvalidaciontipo 
                and v.idformapago = i.idformapago and v.fechainicio = i.fechainicio 
                and v.fechafin = i.fechafin and v.compania = i.compania 
                and ( v.estado = 0 or ( v.estado = 2 and v.idagrupacion != p_idagrupacion ) ) ) 
            WHEN MATCHED THEN
                UPDATE SET val_fechainicio = null, val_fechafin = null, idagrupacion = p_idagrupacion, 
                        estado = 0, nombreagrupacion = null, observaciones = null, tot_venta = null,
                        tot_valorcliente= null, tot_valorzaimella= null, tot_valorexcepcion = null,
                        tot_valor = null, tot_cantidad = null, fechacreacion = sysdate, usuariocreacion = p_usuario
            WHEN NOT MATCHED THEN    
                INSERT (ID, IDINVERSION, IDINVERSIONTIPO, CODIGOGRUPO, 
                IDVALIDACIONTIPO, IDFORMAPAGO, FECHAINICIO, FECHAFIN, ESTADO, IDAGRUPACION, COMPANIA,
                FECHACREACION, USUARIOCREACION )
                VALUES (data.PK_COMMONS.F_SECUENCIA ('T_ICOM_CLIENTE_VALIDACION'), i.id, i.idinversiontipo, i.codigogrupo, 
                i.idvalidaciontipo, i.idformapago, i.fechainicio, i.fechafin, 0, P_IDAGRUPACION, p_compania,
                sysdate, p_usuario) ; 
         commit; 
    exception 
        when others then
            RAISE_APPLICATION_ERROR(-20100,'Error grabar validacion:'||sqlerrm);
    END ;

    /* Procedimiento para asignar las fechas de validacion
    * p_idagrupacion es el codigo de identificacion del grupo que esta actualizado si es nulo es solo uno
    * p_id es el codigo de la validacion si no es nulo es la actualizacion por cada registro
    * p_fechainicio es la fecha de inicio 
    *Ã‚Â´p_fechafin es la fecha fin
    */

    PROCEDURE SP_ACTULIZAFECHAVAL ( P_IDAGRUPACION NUMBER, P_ID NUMBER, P_FECHAINICIO DATE, 
        P_FECHAFIN DATE, P_VAL_FECHAINICIO DATE, P_VAL_FECHAFIN DATE, P_IDINVERSIONTIPO NUMBER DEFAULT NULL,
        P_IDVALIDACIONTIPO VARCHAR2 DEFAULT NULL, P_IDINVERSION NUMBER DEFAULT NULL, P_CODIGOGRUPO VARCHAR2 DEFAULT NULL ) AS
        V_ERROR VARCHAR2(200);
    BEGIN
        --Se verifica el tipo de actualizacion
        if (nvl(p_idagrupacion,0) > 0) then 
            if ( nvl(p_idinversiontipo,0) > 0  and p_idvalidaciontipo is not null ) then
                --la actulizacion es por archivo excel
                for reg in ( SELECT C02 idinversion, C03 codigogrupo, C04 fechainicio, C05 fechafin
                               FROM VT_APEX_EXCEL 
                                WHERE TRIM(C02) IS NOT NULL AND TRIM(C03) IS NOT NULL 
                                AND TRIM(C04) IS NOT NULL 
                                AND TRIM(C05) IS NOT NULL )
                loop
                    if ( to_date(reg.fechainicio,'dd/mm/yyyy') <= to_date(reg.fechafin,'dd/mm/yyyy') ) then
                        update data.t_icom_cliente_validacion
                        set val_fechainicio = reg.fechainicio, val_fechafin = reg.fechafin
                        where idinversion = reg.idinversion and idinversiontipo = p_idinversiontipo
                        and codigogrupo = reg.codigogrupo and idvalidaciontipo = p_idvalidaciontipo
                        and idagrupacion = p_idagrupacion and estado = 0 
                        and to_date(reg.fechainicio,'dd/mm/yyyy') between trunc(fechainicio) and trunc(fechafin)
                        and to_date(reg.fechafin,'dd/mm/yyyy') between trunc(fechainicio) and trunc(fechafin) ;
                    else
                            --no se puede actualizar
                            RAISE_APPLICATION_ERROR(-20100,'Error las fechas '||reg.fechainicio||'-'||reg.fechafin|| ' no son correctas ');
                        end if;     
                end loop;
            else
                --no se puede actualizar
                RAISE_APPLICATION_ERROR(-20100,'Error en los parametros ');
            end if;    

        elsif (nvl(p_id,0) > 0 ) then
            --la actualizacion es por registro
            if ( trunc(p_val_fechainicio) between trunc(p_fechainicio) and trunc(p_fechafin)
                and trunc(p_val_fechafin) between trunc(p_fechainicio) and trunc(p_fechafin) ) then
                
                if p_idinversion is not null and p_codigogrupo is not null then
                    V_ERROR := F_VALIDAFECHASRANGO (P_IDAGRUPACION => p_idagrupacion, 
                                     P_IDINVERSION => P_IDINVERSION, 
                                     P_CODIGOGRUPO => P_CODIGOGRUPO , 
                                     P_FECHAINICIO => p_val_fechainicio, 
                                     P_FECHAFIN => p_val_fechafin ) ;
                     dbms_output.put_line( 'Error '|| v_error );                 
                    if v_error != 'OK' then
                        RAISE_APPLICATION_ERROR(-20100,v_error);
                    end if; 
                end if;
                 dbms_output.put_line( 'cuenta actualiza' );
                update data.t_icom_cliente_validacion
                set val_fechainicio = p_val_fechainicio, val_fechafin = p_val_fechafin
                where id = p_id
                and estado = 0;
            else
                --no se puede actualizar
                RAISE_APPLICATION_ERROR(-20100,'Error las fechas deben ser ingresadas en el rango de la inversion ');
            end if;
        else
            --no se puede actualizar
            RAISE_APPLICATION_ERROR(-20100,'Error no se tiene datos que actualizar ');
        end if;
    END;
    
    /*funcion que verifica que las fechas ingresadas no esten dentro de otras validaciones
    * Retorna ok si bien o el error
    */
    FUNCTION F_VALIDAFECHASRANGO (P_IDAGRUPACION NUMBER, P_IDINVERSION NUMBER, P_CODIGOGRUPO VARCHAR2, 
                                  P_FECHAINICIO DATE, P_FECHAFIN DATE ) RETURN VARCHAR2 AS
        v_cuenta number := 0 ;
        
    BEGIN
        if p_fechainicio is null or p_fechafin is null then
            return 'Error las fechas no deben ser nulas';
        end if;  
        
        begin
            select count(1) into v_cuenta 
            from data.t_icom_cliente_validacion
            where idagrupacion != p_idagrupacion
            and idinversion = p_idinversion
            and codigogrupo = p_codigogrupo
            and (  p_fechainicio between val_fechainicio and val_fechafin
                or p_fechafin between val_fechainicio and val_fechafin )
            and estado in (1,3)    ;
        exception when no_data_found then
            return 'OK';
        end;
        if nvl(v_cuenta,0) > 0 then
            return 'Error, existe otra validacion para las mismas fechas';
        end if;
        return 'OK';
    END;
    
    /*Procedimiento para ingresar las ventas dependiendo del tipo de validacion
    * P_IDAGRUPACION Codigo que tienen todos los registros que deben ser procesados
    * P_IDVALIDACIONTIPO Codigo del tipo de validacion que se debe realizar
    */
    PROCEDURE SP_VALIDACION_VENTAS (P_IDAGRUPACION NUMBER, P_IDVALIDACIONTIPO NUMBER, P_COMPANIA VARCHAR2,
    P_FACTURA VARCHAR2 DEFAULT NULL, P_IDVALIDACION NUMBER DEFAULT NULL, P_CODIGOPRODUCTO VARCHAR2 DEFAULT NULL, 
    P_CODIGOBARRA VARCHAR2 DEFAULT NULL, P_FECHA DATE DEFAULT NULL, P_CANTIDAD NUMBER DEFAULT NULL, 
    P_CODIGOCLIENTE VARCHAR2 DEFAULT NULL, P_DESCUENTO NUMBER DEFAULT NULL, P_FUENTE VARCHAR2 DEFAULT NULL, 
    P_USUARIO varchar2 DEFAULT NULL, 
    P_GRUPOCLIENTE number default 2 /*{MODO DE AGRUPACIÃƒâ€œN>> 1:grupo,2:cliente}*/
    ) AS
 
    v_cuenta number ;
    reg data.t_icom_cliente_validacion%ROWTYPE;
    V_PRODUCTO number ;
    v_valor_nc number ;
    v_preciolista number;
    v_nc_descripcion varchar2(2500);
    v_cont number;
    BEGIN
        --segun el tipo de validacion se debe ingresar los datos
        dbms_output.put_line('Inicia' || to_char(sysdate,'dd/mm/yyyy hh24:mi:ss '));
        CASE P_IDVALIDACIONTIPO 
            WHEN 1 THEN --Contra Sell Out
                --borro el detalle existente
                dbms_output.put_line('Inicia Borra el existente' || to_char(sysdate,'dd/mm/yyyy hh24:mi:ss '));
                begin
                    delete from data.t_icom_cliente_validacion_det 
                    where idvalidacion in ( select distinct id 
                                            from data.t_icom_cliente_validacion  
                                            where idagrupacion = p_idagrupacion
                                            and idvalidaciontipo = 1 and estado = 0  ) ;
                     commit;                         
                end;
                
                INSERT INTO DATA.T_ICOM_CLIENTE_VALIDACION_DET (IDVALIDACION,CODIGOGRUPO,CODIGOCLIENTE,CODIGOPRODUCTO,CODIGOBARRAS,VALORVENTA,
                    VAL_VENTAUND,PRECIOLISTA,CLI_DESCUENTO, VAL_VENTADIA, VAL_VENTADIAUND )
                    WITH datos AS (
                        SELECT DISTINCT
                            'DATA_INICIAL' flag,
                            cv.id idvalidacion,
                            cv.idagrupacion,
                            cv.idinversion,
                            CASE WHEN p_grupocliente = 1 THEN cv.codigogrupo ELSE NULL END codigogrupo_org,
                            ic.codigocliente codigocliente_org,
                            decode(p_grupocliente, 1, cv.codigogrupo, ic.codigocliente) codigogrupo,
                            decode(p_grupocliente, 1, cv.codigogrupo, ic.codigocliente) codigocliente,
                            vd.codigoproducto,
                            vd.codigobarra codigobarras,
                            cv.compania,
                            sum(nvl(vd.valortotal, 0)) valortotal,
                            sum(nvl(vd.valorunidad, 0)) valorunidad,
                            vd.descuentocalculado * 100 cli_descuento,
                            cv.val_fechainicio,
                            cv.val_fechafin,
                            p_grupocliente grupocliente,
                            sum( case when vd.fecha between cv.val_fechainicio and cv.val_fechafin then nvl(vd.valortotal,0) else 0 end ) val_ventadia,
                            sum( case when vd.fecha between cv.val_fechainicio and cv.val_fechafin then nvl(vd.valorunidad,0) else 0 end ) val_ventadiaund
                        FROM data.t_icom_cliente_validacion cv
                        INNER JOIN data.t_icom_inversion_cliente ic ON ( cv.idinversion = ic.idinversion AND cv.codigogrupo = ic.codigogrupo )
                        INNER JOIN (
                            SELECT d.idinversion,d.codigoproducto,d.codigobarra,d.codigogrupo,d.codigocliente,d.descuentocalculado descuentocalculado,
                                v.fecha,nvl(v.valortotal,0) valortotal,nvl(v.valorunidad,0) valorunidad
                            FROM data.vt_icom_val_producto_descuento d 
                                INNER JOIN data.t_trad_sellout v ON ( d.codigocliente = v.codigocliente AND d.codigogrupo = v.codigogrupo 
                                    AND d.codigobarra = v.codigobarra ) 
                        ) vd ON ( cv.idinversion = vd.idinversion AND ic.codigocliente = vd.codigocliente )
                        WHERE cv.idagrupacion = p_idagrupacion AND cv.idvalidaciontipo = 1 AND cv.estado = 0 
                            AND vd.fecha BETWEEN trunc(cv.val_fechainicio, 'MM') AND last_day(cv.val_fechafin)
                        GROUP BY
                            cv.id,cv.idagrupacion,cv.idinversion,CASE WHEN p_grupocliente = 1 THEN cv.codigogrupo ELSE NULL END ,ic.codigocliente,decode(p_grupocliente, 1, cv.codigogrupo, ic.codigocliente),
                            decode(p_grupocliente, 1, cv.codigogrupo, ic.codigocliente),vd.codigoproducto,vd.codigobarra,cv.compania,vd.descuentocalculado * 100,cv.val_fechainicio,cv.val_fechafin
                    )
                    SELECT IDVALIDACION,CODIGOGRUPO,CODIGOCLIENTE,CODIGOPRODUCTO,CODIGOBARRAS,sum(VALORVENTA)VALORVENTA,sum(val_ventaund)val_ventaund,
                    PRECIOLISTA,CLI_DESCUENTO,  sum(val_ventadia) val_ventadia, sum(val_ventadiaund) val_ventadiaund
                    FROM  (
                    SELECT IDINVERSION, idvalidacion, IDAGRUPACION,/* CODIGOGRUPO_ORG, CODIGOCLIENTE_ORG,*/ 
                           CODIGOGRUPO, CODIGOCLIENTE, CODIGOPRODUCTO, CODIGOBARRAS, COMPANIA, VALORTOTAL valorventa, VALORUNIDAD val_ventaund
                           ,data.pk_gzm_ventas.f_prodcutoprecio(
                                p_codigogrupo => CODIGOGRUPO_ORG , 
                                p_codigocliente =>  CODIGOCLIENTE_ORG , 
                                p_codigoproducto =>codigoproducto, 
                                p_eanproducto => NULL, 
                                p_cia => compania,
                                p_fechaini => VAL_FECHAINICIO, 
                                p_fechafin => val_fechafin 
                            ) preciolista, cli_descuento, val_ventadia, val_ventadiaund --, VAL_FECHAINICIO, VAL_FECHAFIN, GRUPOCLIENTE
                    FROM datos
                    )
                    group by IDINVERSION, IDVALIDACION, IDAGRUPACION, CODIGOGRUPO, CODIGOCLIENTE, CODIGOPRODUCTO, CODIGOBARRAS, COMPANIA,                                                        PRECIOLISTA, CLI_DESCUENTO;

                dbms_output.put_line('Termina' || to_char(sysdate,'dd/mm/yyyy hh24:mi:ss '));
            WHEN 2 THEN --Contra Sell In
                --borro el detalle existente
                dbms_output.put_line('Inicia Borra el existente' || to_char(sysdate,'dd/mm/yyyy hh24:mi:ss '));
                begin
                    delete from data.t_icom_cliente_validacion_det
                    where idvalidacion in ( select distinct id 
                                            from data.t_icom_cliente_validacion 
                                            where idagrupacion = p_idagrupacion 
                                            and idvalidaciontipo = 2 and estado = 0 ) ;
                    commit;                         
                end;
                for reg in (select * from data.t_icom_cliente_validacion 
                            where idagrupacion = p_idagrupacion and idvalidaciontipo = 2 and estado = 0 )
                loop
                    V_PRODUCTO :=PK_ICOM_COMMONS.F_PRODUCTO_TODOS(reg.idinversion);
                    insert into data.t_icom_cliente_validacion_det
                    (idvalidacion, codigogrupo, codigocliente,  
                    codigoproducto, 
                    valorventa, cli_descuento, valorzaimella )
                    SELECT id, codigogrupo, codigocliente,codigoproducto, VENTA, DESCUENTO
                    , round(VENTA*(nvl(DESCUENTO/100, 1)),4 )
                    FROM (
                    select reg.id, reg.codigogrupo, cp.codigocliente,  
                        decode(cp.codigoproducto,'TODOS', v.codigoproducto, cp.codigoproducto) codigoproducto, 
                        round(case P_FUENTE 
                            when '1' then sum(v.VALORVENTA)
                            when '2' then sum(v.VALORVENTA2)
                            when '3' then sum(v.VALORVENTA3)
                        end,4) VENTA,  round(decode(nvl(p_descuento,0), 0, d.DESCUENTOCALCULADO, p_descuento),4) DESCUENTO
                      -- , round(sum(v.VALORVENTA)*(nvl(p_descuento/100, 1)),2 )
                    from data.vt_icom_inversion_cli_pro cp
                         left join data.vt_trad_sellIN v
                            on ( cp.codigocliente = v.codigocliente 
                              and decode(cp.codigoproducto,'TODOS',v.codigoproducto, cp.codigoproducto) = v.codigoproducto
                              and v.fecha  between reg.val_fechainicio and reg.val_fechafin )
                         left join data.t_icom_producto_descuento  d 
                            on ( d.idinversion=cp.idinversion 
                                 and v.codigoproducto= d.codigoproducto and v.codigocliente = d.codigocliente )      
                    where cp.idinversion = reg.idinversion
                    and cp.codigogrupo = reg.codigogrupo
                    group by reg.id, reg.codigogrupo, cp.codigocliente,  
                        decode(cp.codigoproducto,'TODOS', v.codigoproducto, cp.codigoproducto), 
                        round(decode(nvl(p_descuento,0), 0, d.DESCUENTOCALCULADO, p_descuento),4)
                    order by reg.id, reg.codigogrupo, cp.codigocliente,  
                        decode(cp.codigoproducto,'TODOS', v.codigoproducto, cp.codigoproducto), 
                        round(decode(nvl(p_descuento,0), 0, d.DESCUENTOCALCULADO, p_descuento),4) ) V WHERE VENTA!=0;
                    commit;
                end loop;
                dbms_output.put_line('Termina' || to_char(sysdate,'dd/mm/yyyy hh24:mi:ss '));    
            WHEN 3 THEN --Contra Factura
                --se debe insertar el detalle de acuerdo a lo seleccionado
                if nvl( p_idvalidacion, 0) >0 then 
                    begin
                        delete from data.t_icom_cliente_validacion_det
                        where idvalidacion = p_idvalidacion 
                        and factura = p_factura
                        and codigocliente = p_codigocliente
                        and codigoproducto = p_codigoproducto ;
                        commit;                         
                    end;
                    select * into reg 
                    from data.t_icom_cliente_validacion 
                    where idagrupacion = p_idagrupacion 
                    --and estado = 0 
                    and id = p_idvalidacion ; 

                    v_valor_nc := DATA.PK_ICOM_VALIDACION.F_NOTACREDITOTOTAL(    P_FACTURA => P_FACTURA,
                            P_COMPANIA => P_COMPANIA,
                            P_CODIGOPRODUCTO => P_CODIGOPRODUCTO
                          );
                    v_preciolista := DATA.PK_GZM_VENTAS.F_PRODCUTOPRECIO( P_CODIGOCLIENTE => p_codigocliente,
                                P_CODIGOPRODUCTO => p_codigoproducto,
                                P_EANPRODUCTO => null,
                                P_CIA => P_COMPANIA,
                                p_FECHAINI =>REG.VAL_FECHAINICIO,
                                p_FECHAFIN => REG.VAL_FECHAFIN
                           );

                    if ( v_valor_nc != 0 or v_preciolista > 0 ) then --No se deben insertar negativos
                        insert into data.t_icom_cliente_validacion_det
                        (idvalidacion, codigogrupo, codigocliente,  codigoproducto, codigobarras,  
                         valorventa, VALORZAIMELLA,
                         preciolista, cli_descuento, VAL_VENTAUND, factura, fac_fecha, nc_valor, nc_descripcion )
                         values
                         ( reg.id, reg.codigogrupo, p_codigocliente, p_codigoproducto, p_codigobarra, 
                          round((v_preciolista*p_cantidad),4),
                           round(decode(v_valor_nc, 0,(v_preciolista*(nvl(P_descuento,1))*p_cantidad) ,0),4),
                           round(v_preciolista,4), round(P_descuento*100,4), round(p_cantidad,4), p_factura, P_FECHA, 
                           round(v_valor_nc,4) , 
                           DATA.PK_ICOM_VALIDACION.F_NOTACREDIDESCRIPCION(    P_FACTURA => P_FACTURA,
                                P_COMPANIA => P_COMPANIA,
                                P_CODIGOPRODUCTO => P_CODIGOPRODUCTO
                              )   ) ;
                    end if;
                end if;
            WHEN 4 THEN --Descuento Sistema  este va hacer automatico
                --borro el detalle existente
                dbms_output.put_line('Inicia Borra el existente' || to_char(sysdate,'dd/mm/yyyy hh24:mi:ss '));
                begin
                    delete from data.t_icom_cliente_validacion_det
                    where idvalidacion in ( select distinct id 
                                            from data.t_icom_cliente_validacion 
                                            where idagrupacion = p_idagrupacion 
                                            and idvalidaciontipo = 4 and estado = 0) ;
                    commit;                         
                end;
                INSERT INTO DATA.T_ICOM_CLIENTE_VALIDACION_DET
                (IDVALIDACION, CODIGOGRUPO, CODIGOCLIENTE,  CODIGOPRODUCTO, CODIGOBARRAS,  
                 FACTURA, FAC_FECHA, CLI_CANTIDAD, VAL_VENTAUND,
                 PRECIOLISTA, NC_DESCRIPCION, CLI_DESCUENTO,
                 CLI_VALOR, VALORVENTA,VALORZAIMELLA )   ----PASAR TEST 
                 SELECT
                    V.ID, V.CODIGOGRUPO, I.CODIGOCLIENTE, F.CODIGOPRODUCTO, F.CODIGOBARRA,
                    F.FACTURA, F.FAC_FECHA, ROUND(F.CANTIDAD,4),   ROUND(D.DESCUENTOCALCULADO*100,4),
                    ROUND(DATA.PK_GZM_VENTAS.F_PRODCUTOPRECIO( P_CODIGOCLIENTE => F.CODIGOCLIENTE,
                            P_CODIGOPRODUCTO => F.CODIGOPRODUCTO,
                            P_EANPRODUCTO => null,
                            P_CIA => P_COMPANIA ,
                            p_FECHAINI =>V.VAL_FECHAINICIO,
                            p_FECHAFIN =>V.VAL_FECHAFIN
                        )
                    ,4), 
                    F.FECHADESDE||' - '||F.FECHAHASTA ,
                    ROUND(F.DESCUENTO*-1,4), ROUND(F.PRECIO_DES,4), 
                    PRECIO_DES * ROUND(F.CANTIDAD,4),
                    --ROUND( ( F.PRECIO-F.PRECIO_DES)*F.CANTIDAD,4 )
                    ROUND(TOTAL_DESCUENTO+TOTAL_DEVOLUCION,4)
                FROM DATA.T_ICOM_CLIENTE_VALIDACION V
                INNER JOIN DATA.VT_ICOM_INVERSION_CLI_PRO I ON (V.IDINVERSION = I.IDINVERSION AND V.CODIGOGRUPO = I.CODIGOGRUPO)
                INNER JOIN DATA.VT_ICOM_DESCUENTOFACTURA F ON ( (I.IDINVERSION = F.IDINVERSION1 ) AND I.CODIGOCLIENTE = F.CODIGOCLIENTE  AND TRIM(DECODE( I.CODIGOPRODUCTO, 'TODOS', F.CODIGOPRODUCTO, I.CODIGOPRODUCTO )) = TRIM(F.CODIGOPRODUCTO) )
                LEFT JOIN DATA.t_icom_producto_descuento D  ON ( D.IDINVERSION = I.IDINVERSION  AND I.CODIGOPRODUCTO = D.CODIGOPRODUCTO AND I.CODIGOCLIENTE = D.CODIGOCLIENTE )
                WHERE V.IDAGRUPACION = P_IDAGRUPACION  AND IDVALIDACIONTIPO = 4 AND ESTADO = 0; 

                dbms_output.put_line('444 Sqlerror '||sqlerrm);            
                commit;
                dbms_output.put_line('Termina' || to_char(sysdate,'dd/mm/yyyy hh24:mi:ss '));
            WHEN 6 THEN --Otro Rebate
                --Cargo los codigos Rebate
                MERGE INTO DATA.T_ICOM_CLIENTE_VALIDACION v
                USING ( select cv.idinversion, cv.idinversiontipo, cv.codigogrupo, cv.idvalidaciontipo, cv.idformapago, 
                               cv.fechainicio, cv.fechafin, cv.val_fechainicio, cv.val_fechafin,  --cv.idrebate , 
                               r.idrebate idRebateNew, r.nombrerebate, cv.compania, r.periodo 
                        from data.t_icom_cliente_validacion cv
                            left join data.vt_icom_inversionrebate r 
                                on ( ( cv.idrebate is null and cv.idinversion = r.idinversion 
                                      and ( r.idtiporebate = 2 --automatico 
                                       or ( r.idtiporebate = 1 --manual
                                             and trunc(r.fechainicio) between trunc(cv.val_fechainicio) and trunc(cv.val_fechafin)  
                                             and trunc(r.fechafin)  between trunc(cv.val_fechainicio) and trunc(cv.val_fechafin) ) )  
                                    ) or ( cv.idrebate = r.idrebate and cv.idinversion = r.idinversion and cv.periodo = r.periodo ))	
                        where cv.idagrupacion  = p_idagrupacion and cv.idvalidaciontipo = 6 and cv.estado = 0  ) i
                   ON ( v.idinversion = i.idinversion  and v.idinversiontipo = i.idinversiontipo
                    and v.codigogrupo = i.codigogrupo and v.idvalidaciontipo = i.idvalidaciontipo 
                    and v.idformapago = i.idformapago and v.fechainicio = i.fechainicio 
                    and v.fechafin = i.fechafin and v.compania = i.compania 
                    and i.idRebateNew = v.idrebate
                    and ( v.estado = 0 or ( v.estado = 2 and v.idagrupacion != p_idagrupacion ) ) ) 
                WHEN MATCHED THEN
                    UPDATE SET idagrupacion = p_idagrupacion, estado = 0, fechacreacion = sysdate, usuariocreacion = p_usuario
                WHEN NOT MATCHED THEN    
                    INSERT (ID, IDINVERSION, IDINVERSIONTIPO, CODIGOGRUPO, 
                    IDVALIDACIONTIPO, IDFORMAPAGO, FECHAINICIO, FECHAFIN, ESTADO, IDAGRUPACION, COMPANIA,
                    FECHACREACION, USUARIOCREACION, IDREBATE, VAL_FECHAINICIO, VAL_FECHAFIN, PERIODO )
                    VALUES (PK_COMMONS.F_SECUENCIA ('T_ICOM_CLIENTE_VALIDACION'), i.idinversion, i.idinversiontipo, i.codigogrupo, 
                    i.idvalidaciontipo, i.idformapago, i.fechainicio, i.fechafin, 0, P_IDAGRUPACION, p_compania,
                    sysdate, p_usuario, i.idRebateNew, i.val_fechainicio, i.val_fechafin, i.periodo ) ; 
                    
                --Una vez asignado los rebate borra los que no tienen rebate
                delete from DATA.T_ICOM_CLIENTE_VALIDACION 
                where idagrupacion = p_idagrupacion and idvalidaciontipo = 6 and estado = 0 and idrebate is null ;   
                
            ELSE
                null; --luego se debe poner los otros casos
        END CASE;     

    END;

    /*funcion que verifica que todas las fechas de la validacion se encuentren ingresadas correctamente
    * Retorna 1 si estÃƒÂ¡n todas 0 si falla alguna
    * P_IDAGRUPACION el codigo de identificacion para todas las validaciones a procesar
    */
    FUNCTION F_VALIDAFECHASVAL (P_IDAGRUPACION NUMBER) RETURN NUMBER AS
        v_cuenta number := 0 ;
    BEGIN
        begin     
            select count(1) into v_cuenta 
            from data.t_icom_cliente_validacion 
            where idagrupacion = p_idagrupacion
            and estado = 0 
            and (val_fechainicio is null or val_fechafin is null 
                 or val_fechainicio < fechainicio 
                  or val_fechainicio > fechafin 
                  or val_fechafin < fechainicio 
                  or val_fechafin > fechafin )  ;
            dbms_output.put_line( 'cuenta '|| v_cuenta );
            if nvl(v_cuenta,0) > 0 then
                return 0;
            end if;
       exception when no_data_found then 
            v_cuenta := 0 ;                  
       end;
       
       begin
            --busca las inversiones que se encuentre en otras validaciones con las mismas fechas
            select count(1) into v_cuenta 
            from data.t_icom_cliente_validacion a,  
                 data.t_icom_cliente_validacion b
            where a.idagrupacion = p_idagrupacion
            and a.estado = 0 
            and a.idagrupacion != b.idagrupacion
            and a.idinversion = b.idinversion
            and a.codigogrupo = b.codigogrupo
            and (  a.val_fechainicio between b.val_fechainicio and b.val_fechafin
                or a.val_fechafin between b.val_fechainicio and b.val_fechafin )
            and b.estado in (1,3) ;
            dbms_output.put_line( 'cuenta '|| v_cuenta );
            if nvl(v_cuenta,0) > 0 then
                return 0;
            end if;
        exception when no_data_found then
            v_cuenta := 0 ;    
        end;
        return 1;

    END;
    
    /* Funcion que retorna el valor de Cliente para el caso de sellout a traves de la formula
    VALOR CLIENTE=SI((CANTIDAD CLIENTE<CANTIDAD SELL OUT);(PRECIO*%DSCTO)*(SELL OUT*%APLICACIÃƒâ€œN);0)
    */
    FUNCTION F_CAL_VALORCLIENTE( P_CLI_CANTIDAD NUMBER, P_SELLOUTCANTIDAD NUMBER, P_PRECIOLIS NUMBER, 
                                 P_PCTDESCUENTO NUMBER, P_SELLOUTVALOR NUMBER, P_PCT_APLICA NUMBER ) RETURN NUMBER AS
    BEGIN
        if ( p_cli_cantidad is null or p_selloutcantidad is null or p_pct_aplica is null or p_preciolis is null
             or p_selloutvalor is null ) then
            return 0 ;
        end if;
        if (p_cli_cantidad < p_selloutcantidad ) then
            return round(((p_preciolis -(p_preciolis * nvl((p_pctdescuento/100),1)))*(nvl((p_pct_aplica/100),1)*p_selloutvalor)),4);
        else
            return 0 ;
        end if;
    END;

    /* Funcion que retorna el valor de Zaimella para el caso de sellout a traves de la formula
    */
    FUNCTION F_CAL_VALORZAIMELLA(P_VALORCLIENTE NUMBER,P_SELLOUT NUMBER,P_PCTAPLICACION NUMBER,P_PRECIOLIS NUMBER,P_PCTDESCUENTO NUMBER) RETURN NUMBER AS
        v_retorno number;
    BEGIN
        v_retorno :=0;
        if ( p_valorcliente is null or p_sellout is null or p_pctaplicacion is null or p_preciolis is null ) then
            return v_retorno  ;
        end if;
        if (P_VALORCLIENTE <=P_SELLOUT )then 
            v_retorno :=((P_PRECIOLIS *(P_PCTDESCUENTO/100))*P_VALORCLIENTE );
        else
            v_retorno :=((P_PRECIOLIS *(P_PCTDESCUENTO/100))*P_SELLOUT );
        end if;
        return v_retorno ;
    END;

    /*Procedmiento que actualiza el detalle de la validacion con los datos ingresados por el cliente*/
    PROCEDURE SP_GRABA_CLIENTEVALIDACION_DET ( P_IDVALIDACION NUMBER, P_IDINVERSION NUMBER,
        P_CODIGOCLIENTE VARCHAR2, P_CODIGOPRODUCTO VARCHAR2, P_PCT_APLICACION NUMBER,
        P_CLI_CANTIDAD NUMBER, P_CLI_VALOR NUMBER, P_CLI_DESCUENTO NUMBER,
        P_VALORZAIMELLA NUMBER, P_VALIDACION_TIPO NUMBER, P_FACTURA VARCHAR2 default null) AS

    v_cuenta number;
    v_valorcliente number;
    v_valorzaimella number;
    v_venta number;

    BEGIN 
        if P_VALIDACION_TIPO in (5,6) and P_CLI_CANTIDAD = -1 then -- (Manual,Rebate) Actualizacion
            
            update data.t_icom_cliente_validacion_det cv
            set nc_descripcion = P_FACTURA, valorzaimella = P_VALORZAIMELLA
            where cv.idvalidacion = P_IDVALIDACION
            and cv.codigocliente = P_CODIGOCLIENTE
            and cv.codigoproducto = P_CODIGOPRODUCTO
            ;
            --RAISE_APPLICATION_ERROR(-20100,'codigocliente:'||p_codigocliente||' codigoproducto: '||P_CODIGOPRODUCTO||' idvalidacion: '||P_IDVALIDACION);
        elsif P_VALIDACION_TIPO in( 5,6) and P_CLI_CANTIDAD is null then --Manual distribucion
            --se encuentra los productos de la inversion
                v_valorcliente := nvl(P_CLI_VALOR,0) ;
                v_valorzaimella := nvl(P_VALORZAIMELLA,0) ;
                
                --busca en el detalle si existe actualiza si no inserta
                delete t_icom_cliente_validacion_det where idvalidacion=p_idvalidacion;
                
                INSERT into data.t_icom_cliente_validacion_det(idvalidacion, codigogrupo, codigocliente, codigoproducto, cli_valor, valorzaimella)
                with t_validacion as (
                    select 
                        IDAGRUPACION,cv.id idvalidacion,cv.IDINVERSION,cv.CODIGOGRUPO,nvl(v.codigocliente, cv.CODIGOGRUPO) codigocliente,v_VALORZAIMELLA TOT_VALORZAIMELLA,v_valorcliente TOT_VALORCLIENTE,c.codigoproducto,nvl(sum(VALORVENTA), 1) venta
                    from data.t_icom_cliente_validacion cv
                    inner join data.t_icom_inversion_producto c on (cv.idinversion = c.idinversion) 
                    left join data.t_trad_sellIN v on ( cv.CODIGOGRUPO=v.CODIGOGRUPO and c.codigoproducto=v.codigoproducto and v.fecha between trunc(val_fechainicio) and trunc(val_fechafin) )
                    where cv.ID = P_IDVALIDACION
                    and  cv.idinversion = p_idinversion
                    group by IDAGRUPACION,cv.id,cv.IDINVERSION,cv.CODIGOGRUPO,nvl(v.codigocliente, cv.CODIGOGRUPO),c.codigoproducto
                    having nvl(sum(VALORVENTA), 1)>0
                )
                ,t_resumen as (
                    select 
                        IDAGRUPACION,
                        idvalidacion,
                        IDINVERSION,
                        codigogrupo,
                        codigocliente,
                        CODIGOPRODUCTO,
                        VENTA VALORVENTA,
                        TOT_VALORZAIMELLA,
                        round(TOT_VALORZAIMELLA*(VENTA / NULLIF(SUM(VENTA) OVER (partition by IDAGRUPACION,idvalidacion ), 0 ) ), 15) valorzaimella, 
                        round(tot_valorcliente *(VENTA / NULLIF(SUM(VENTA) OVER (partition by IDAGRUPACION,idvalidacion ), 0 ) ), 15) valorcliente, 
                        SUM(VENTA) OVER (partition by IDAGRUPACION,idvalidacion) venta_total, 
                        ROUND(VENTA / NULLIF(SUM(VENTA) OVER (partition by IDAGRUPACION,idvalidacion ), 0), 15) AS peso_venta
                    from t_validacion
                    order by IDAGRUPACION, IDVALIDACION, CODIGOCLIENTE,CODIGOPRODUCTO
                )
                SELECT idvalidacion, codigogrupo, codigocliente,codigoproducto, valorcliente,  valorzaimella  FROM t_resumen;
        else
            BEGIN
                update data.t_icom_cliente_validacion_det
                set pct_aplicacion = round(p_pct_aplicacion,4), 
                cli_cantidad = round(p_cli_cantidad,4), 
                cli_valor = round(p_cli_valor,4),
                cli_descuento = case when round(p_cli_descuento,4)<= cli_descuento then round(p_cli_descuento,4) else cli_descuento end  , 
                valorzaimella = round(p_valorzaimella,4),
                valorventa = --case p_validacion_tipo 
                                    --when 3 then round((preciolista*nvl(p_cli_descuento,1)/100*nvl(p_cli_cantidad,0) ),2)
                                   /* else*/  round(valorventa,4)
                                 /*end*/ ,
                    nc_descripcion = case p_validacion_tipo 
                                    when 5 then p_factura
                                    else  nc_descripcion
                                 end                 
                where idvalidacion = p_idvalidacion
                and NVL(codigoproducto,'T0D0S') = NVL(p_codigoproducto,'T0D0S')
                and codigocliente = p_codigocliente 
                and decode(P_VALIDACION_TIPO, 3, factura, 4, factura, 1 ) = decode(P_VALIDACION_TIPO,3, p_factura, 4, p_factura, 1) ;
            EXCEPTION when others then
                RAISE_APPLICATION_ERROR(-20100,'Error al actualizar:'||sqlerrm);
            end;     
        end if;        
    END;
    
    
    /*Procedmiento que actualiza desde archivo el detalle de la validacion */
    PROCEDURE SP_ACTUALIZA_CLI_VAL_DET ( P_IDAGRUPACION NUMBER , P_VALIDACION_TIPO NUMBER, P_COMPANIA VARCHAR2 ) AS
    v_cuenta number;
    v_valorcliente number;
    v_valorzaimella number;
    v_finalcliente number;
    v_finalzaimella number;
    v_venta number ;
    v_registro varchar2(3000);
    plsql_block clob;
    BEGIN 
        if (p_validacion_tipo = 1) then --Contra SellOut actualiza los valores correspondientes
            /*Homologa las codigos de producto*/
            MERGE INTO data.t_icom_cliente_validacion_det cv
            USING ( SELECT C.ID IDVALIDACION, W.IDINVERSION, W.CODIGOGRUPO, W.CODIGOCLIENTE, 
                           TRIM( case when W.CODIGOPRODUCTO is not null then 
                              ( select ih.producto_zm codigoProducto from data.T_GPW_ITEMSHOMOLOGACION ih 
                              where p_compania = ih.cia and W.CODIGOGRUPO = ih.codigo_cliente and ih.estado=1 
                                and W.CODIGOPRODUCTO = ih.producto_cliente   and rownum = 1 ) 
                             when W.CODIGOBARRA is not null then 
                               ( select pro.codigoproducto from data.VT_GZM_PRODUCTO pro 
                                where pro.compania = p_compania
                                  and pro.codigobarra = W.CODIGOBARRA and rownum = 1 ) 
                              end )  CODIGOPRODUCTO,CODIGOBARRA, W.CLI_CANTIDAD, W.CLI_VALOR, W.CLI_DESCUENTO  
                    FROM ( SELECT v.C02 IDINVERSION, v.C03 CODIGOGRUPO, v.C04 CODIGOCLIENTE, trim(v.C05) CODIGOPRODUCTO, trim(v.C06) CODIGOBARRA, 
                                   /*(NVL(ROUND(REPLACE(v.C07, '.', ','),2),0)) CLI_CANTIDAD, 
                                   NVL(ROUND(REPLACE(v.C08, '.', ','),2),0) CLI_VALOR,
                                   ROUND(REPLACE(v.C09, '.', ','),2) CLI_DESCUENTO*/
                                   SUM (NVL(ROUND(REPLACE(v.C07, '.', ','),4),0)) CLI_CANTIDAD, 
                                   SUM(NVL(ROUND(REPLACE(v.C08, '.', ','),4),0)) CLI_VALOR,
                                   MAX(case when trim(v.C09) is null then null else ROUND(REPLACE(v.C09, '.', ','),4) end) CLI_DESCUENTO    
                           FROM VT_APEX_EXCEL v        
                           WHERE TRIM(C02) IS NOT NULL AND TRIM(C03) IS NOT NULL 
                            AND TRIM(C04) IS NOT NULL 
                            AND ( TRIM(C05) IS NOT NULL or TRIM(C06) IS NOT NULL )
                           GROUP BY  v.C02 , v.C03 , v.C04 , trim(v.C05), trim(v.C06) 
                           ORDER BY v.C02 , v.C03 , v.C04 , trim(v.C05), trim(v.C06) ) W 
                    inner join data.t_icom_cliente_validacion c 
                        on ( W.IDINVERSION = c.idinversion and W.CODIGOGRUPO = c.codigogrupo and c.idagrupacion = p_idagrupacion and c.estado = 0 )       
                  ) dat
            ON ( cv.idvalidacion = dat.idvalidacion and cv.codigogrupo = dat.codigogrupo 
                and cv.codigocliente = dat.codigocliente and /*cv.codigoproducto = dat.codigoproducto*/ cv.CODIGOBARRAS = dat.CODIGOBARRA)        
            WHEN MATCHED THEN  
            UPDATE SET cv.pct_aplicacion = round((dat.cli_cantidad/decode(nvl(cv.val_ventaund,0),0,1, cv.val_ventaund)*100),4), 
                       cv.cli_cantidad = dat.cli_cantidad,
                       cv.cli_valor = dat.cli_valor, 
                       cv.cli_descuento = case when dat.cli_descuento is not null and dat.cli_descuento <= cv.cli_descuento then dat.cli_descuento else cv.cli_descuento end ,
                       cv.valorzaimella = round(DATA.PK_ICOM_VALIDACION.F_CAL_VALORZAIMELLA(
                                            P_VALORCLIENTE => dat.cli_cantidad,
                                            P_SELLOUT => cv.VAL_VENTAUND,
                                            P_PCTAPLICACION => round((dat.cli_cantidad/decode(nvl(cv.val_ventaund,0),0,1, cv.val_ventaund))*100,4),
                                            P_PRECIOLIS => cv.preciolista,
                                            P_PCTDESCUENTO => case when dat.cli_descuento is not null and dat.cli_descuento <= cv.cli_descuento then dat.cli_descuento else cv.cli_descuento end
                                          ),4) ;                   
                                          
        elsif (p_validacion_tipo in (3,4) ) then --Tipo: Contra Factura / Descuento del Sistema
            --se sube por archivo el valor del descuento del sistema a las facturas
            MERGE INTO data.t_icom_cliente_validacion_det cv
            USING ( SELECT C02 IDINVERSION, C03 CODIGOGRUPO, C04 CODIGOCLIENTE, 
                           C05 CODIGOPRODUCTO, C06 FACTURA,
                           NVL(ROUND(REPLACE(C07, '.', ','),4),0) CLI_DESCUENTO,
                           c.id idvalidacion
                    FROM VT_APEX_EXCEL v
                       inner join data.t_icom_cliente_validacion c 
                        on ( v.C02 = c.idinversion and v.C03 = c.codigogrupo and c.idagrupacion = p_idagrupacion 
                            and c.estado = 0 )
                    WHERE TRIM(C02) IS NOT NULL AND TRIM(C03) IS NOT NULL 
                    AND TRIM(C04) IS NOT NULL  AND TRIM(C05) IS NOT NULL 
                    AND TRIM(C06) IS NOT NULL) dat
            ON ( cv.idvalidacion = dat.idvalidacion and cv.codigogrupo = dat.codigogrupo 
                and cv.codigocliente = dat.codigocliente and cv.codigoproducto = dat.codigoproducto
                and cv.factura = dat.factura)        
            WHEN MATCHED THEN 
            UPDATE SET cv.cli_descuento = case when dat.cli_descuento is not null  then dat.cli_descuento else cv.cli_descuento end ,
            cv.valorzaimella = case when p_validacion_tipo = 3 then 
                                        case when nvl(dat.cli_descuento,0 ) != 0 then  
                                                round(decode(cv.nc_valor, 0,(cv.preciolista*(dat.cli_descuento/100))*nvl(cv.VAL_VENTAUND,0) ,0),4)
                                            when nvl(cv.cli_descuento,0) != 0 then
                                                round(decode(cv.nc_valor, 0,(cv.preciolista*(dat.cli_descuento/100))*nvl(cv.VAL_VENTAUND,0) ,0),4)
                                            else
                                                round(decode(cv.nc_valor, 0,cv.preciolista*nvl(cv.VAL_VENTAUND,0) ,0),4)    
                                        end    
                                    else  cv.valorzaimella end    ;

            
    elsif (p_validacion_tipo = 5) then --Manual se debe inserta lo que subio por archivo
          
          delete t_icom_cliente_validacion_det D where
          EXISTS (SELECT 1 FROM t_icom_cliente_validacion V WHERE V.ID=D.idvalidacion 
           and V.idagrupacion = p_idagrupacion and V.estado = 0 ) ;

          for reg in (SELECT TRIM(C02) IDINVERSION, TRIM(C04) CODIGOGRUPO, TRIM(C05) CODIGOCLIENTE, 
                           REPLACE(C06, '.', ',') VALORCLIENTE, REPLACE(C07, '.', ',') VALORZAIMELLA,
                           c.id IDVALIDACION
                    FROM data.VT_APEX_EXCEL v
                       inner join data.t_icom_cliente_validacion c 
                        on ( trim(v.C02) = trim(c.idinversion) and trim(v.C04) = trim(c.codigogrupo) 
                             and c.idagrupacion = p_idagrupacion and c.estado IN ( 0,2 ) )
                    WHERE TRIM(C02) IS NOT NULL  AND TRIM(C04) IS NOT NULL AND TRIM(C05) IS NOT NULL 
                    AND EXISTS ( select 1 from data.T_ICOM_INVERSION_CLIENTE
                            where idinversion = TRIM(C02) and codigogrupo = TRIM(C04) and codigocliente = TRIM(C05) ) )
            loop 
                --busco el valor total de venta sellIn                    
                begin                    
                    --busca en el detalle si existe actualiza si no inserta
                    insert INTO data.t_icom_cliente_validacion_det  (idvalidacion, codigogrupo, codigocliente, 
                            codigoproducto, VALORVENTA, VAL_VENTAUND, cli_valor, valorzaimella) 
                        with t_validacion as (
                            select 
                                IDAGRUPACION,cv.id idvalidacion,cv.IDINVERSION,cv.CODIGOGRUPO,reg.codigocliente, reg.valorzaimella TOT_VALORZAIMELLA,
                                reg.valorcliente TOT_VALORCLIENTE,c.codigoproducto,nvl(sum(VALORVENTA), 1) venta
                            from data.t_icom_cliente_validacion cv
                            inner join data.t_icom_inversion_producto c on (cv.idinversion = c.idinversion) 
                            left join data.t_trad_sellIN v on ( cv.CODIGOGRUPO=v.CODIGOGRUPO and c.codigoproducto=v.codigoproducto and v.codigocliente=reg.codigocliente and v.fecha between trunc(val_fechainicio) and trunc(val_fechafin) )
                            where 1=1
                            and cv.ID =  reg.idvalidacion 
                            group by IDAGRUPACION,cv.id,cv.IDINVERSION,cv.CODIGOGRUPO,v.codigocliente,c.codigoproducto
                            having nvl(sum(VALORVENTA), 1)>0
                        )
                        ,t_resumen as (
                            select 
                                IDAGRUPACION,idvalidacion,IDINVERSION,codigogrupo,
                                codigocliente,CODIGOPRODUCTO,VENTA VALORVENTA,TOT_VALORZAIMELLA,
                                round(TOT_VALORZAIMELLA*(VENTA / NULLIF(SUM(VENTA) OVER (partition by IDAGRUPACION,idvalidacion ), 0 ) ), 15) valorzaimella, 
                                round(TOT_VALORCLIENTE *(VENTA / NULLIF(SUM(VENTA) OVER (partition by IDAGRUPACION,idvalidacion ), 0 ) ), 15) valorcliente, 
                                SUM(VENTA) OVER (partition by IDAGRUPACION,idvalidacion) venta_total, 
                                ROUND(VENTA / NULLIF(SUM(VENTA) OVER (partition by IDAGRUPACION,idvalidacion ), 0), 15) AS peso_venta
                            from t_validacion
                            order by IDAGRUPACION, IDVALIDACION, CODIGOCLIENTE,CODIGOPRODUCTO
                        )
                        SELECT idvalidacion, codigogrupo, codigocliente, codigoproducto, VALORVENTA, venta_total VAL_VENTAUND, valorcliente cli_valor, valorzaimella FROM t_resumen; 
                    commit;
                exception
                    when others then
                        RAISE_APPLICATION_ERROR(-20100,'Error al grabar:'||sqlerrm);
                end;
            end loop;
        elsif (p_validacion_tipo = 6) then --Otros rebate se debe inserta lo que se tenga en la formula
            --borro todos los datos de los que existan
            delete t_icom_cliente_validacion_det D where
            EXISTS (SELECT 1 FROM t_icom_cliente_validacion V 
                    inner join data.vt_icom_inversionrebate re on (v.idrebate = re.idrebate and nvl(re.usaformula,0) = 1 )
                    WHERE V.ID=D.idvalidacion and v.idvalidaciontipo  = 6 
                    and V.idagrupacion = p_idagrupacion and V.estado = 0 ) ;
            commit;
              
            --Cargo los valores ejecutando la formula para distribuir por cliente y producto   
            for val in (select cv.id idvalidacion,  cv.idinversion, cv.codigogrupo, cv.val_fechainicio, cv.val_fechafin,
                               cv.idrebate, re.formula, re.valor, re.valorporcentaje, i.fechainicio, i.fechafin
                        from data.t_icom_cliente_validacion cv
                             inner join data.t_icom_inversiones i on (cv.idinversion = i.id )
                             inner join data.vt_icom_inversionrebate re on 
                            ( cv.idinversion = re.idinversion and  cv.idrebate = re.idrebate 
                              and nvl(cv.periodo,'0') = nvl(re.periodo,'0')
                              and nvl(re.usaformula,0) = 1 )
                        where cv.idagrupacion = P_IDAGRUPACION and cv.idvalidaciontipo = 6
                        and cv.estado = 0 ) 
            loop 
                dbms_output.put_line( 'idvalidacion: '||val.idvalidacion||' idinversion:'||val.idinversion
                ||' codigogrupo:'||val.codigogrupo||' val_fechainicio:'||val.val_fechainicio||' val_fechafin:'
                ||val.val_fechafin||' idrebate:'||val.idrebate||' valor:'||val.valor
                ||' valorporcentaje:'||val.valorporcentaje||' fechainicio:'||val.fechainicio||' fechafin:'||val.fechafin);
                
                dbms_output.put_line( 'Ingresa Formula: '||val.formula );    
                apex_debug.message('Ingresa Formula: '||val.formula);
                --se pasa las fechas de validacion y tambien las fechas del rebate
                EXECUTE IMMEDIATE val.formula USING val.idvalidacion, val.idinversion, val.codigogrupo, val.val_fechainicio,  
                                                    val.val_fechafin, val.idrebate, val.valor, val.valorporcentaje, 
                                                    val.fechainicio, val.fechafin ;
                
                --hace la distribucion de los valores actualizados
                v_cuenta := 0 ;
                v_venta := 0;
                --busco el valor total de venta sellIn para el grupo   
                INSERT INTO data.t_icom_cliente_validacion_det (idvalidacion, codigogrupo, codigocliente,codigoproducto, cli_valor, valorzaimella, VALORVENTA )
                with t_validacion as (
                    select 
                        IDAGRUPACION,cv.id idvalidacion,cv.IDINVERSION,cv.CODIGOGRUPO,
                        v.codigocliente,TOT_VALORZAIMELLA,tot_valorcliente,v.codigoproducto,sum(VALORVENTA) venta
                    from data.t_icom_cliente_validacion cv
                    --inner join data.t_icom_inversion_producto c on (cv.idinversion = c.idinversion) 
                    inner join data.t_trad_sellIN v on ( cv.CODIGOGRUPO=v.CODIGOGRUPO --and c.codigoproducto=v.codigoproducto 
                    and v.fecha between trunc(val_fechainicio) and trunc(val_fechafin) )
                    where cv.ID = val.idvalidacion
                    group by IDAGRUPACION,cv.id,cv.IDINVERSION,cv.CODIGOGRUPO,v.codigocliente,
                    TOT_VALORZAIMELLA,tot_valorcliente,v.codigoproducto
                    having sum(VALORVENTA)>0
                )
                ,t_resumen as (
                    select 
                        IDAGRUPACION,
                        idvalidacion,
                        IDINVERSION,
                        codigogrupo,
                        codigocliente,
                        CODIGOPRODUCTO,
                        VENTA VALORVENTA,
                        TOT_VALORZAIMELLA,
                        round(TOT_VALORZAIMELLA*(VENTA / NULLIF(SUM(VENTA) OVER (partition by IDAGRUPACION,idvalidacion ), 0 ) ), 15) valorzaimella, 
                        round(tot_valorcliente *(VENTA / NULLIF(SUM(VENTA) OVER (partition by IDAGRUPACION,idvalidacion ), 0 ) ), 15) valorcliente, 
                        SUM(VENTA) OVER (partition by IDAGRUPACION,idvalidacion) venta_total, 
                        ROUND(VENTA / NULLIF(SUM(VENTA) OVER (partition by IDAGRUPACION,idvalidacion ), 0), 15) AS peso_venta
                    from t_validacion
                    order by IDAGRUPACION, IDVALIDACION, CODIGOCLIENTE,CODIGOPRODUCTO
                )
                SELECT idvalidacion, codigogrupo, codigocliente,codigoproducto, valorcliente,  valorzaimella, valorventa  FROM t_resumen;
                commit;
            end loop;
        elsif (p_validacion_tipo = -1) then --Valor excepcion de todos los tipos se debe actualizar por archivo
            --busca en el detalle si existe actualiza el valor de excecion
            MERGE INTO data.t_icom_cliente_validacion_det cv
            USING ( SELECT C02 IDINVERSION, C03 CODIGOGRUPO, C04 CODIGOCLIENTE, C05 CODIGOPRODUCTO,
                           NVL(ROUND(REPLACE(C06, '.', ','),4),0) VALOREXCEPCION,
                           c.id idvalidacion
                    FROM VT_APEX_EXCEL v
                       inner join data.t_icom_cliente_validacion c 
                        on ( v.C02 = c.idinversion and v.C03 = c.codigogrupo and c.idagrupacion = p_idagrupacion and c.estado = 2 )
                    WHERE TRIM(C02) IS NOT NULL AND TRIM(C03) IS NOT NULL 
                    AND TRIM(C04) IS NOT NULL 
                    AND TRIM(C05) IS NOT NULL ) dat
            ON ( cv.idvalidacion = dat.idvalidacion and cv.codigogrupo = dat.codigogrupo 
                and cv.codigocliente = dat.codigocliente and cv.codigoproducto = dat.codigoproducto )        
            WHEN MATCHED THEN 
            UPDATE SET cv.valorexcepcion = dat.valorexcepcion ;
            commit;
        end if;
    END;

    /*Funcion que busca las notas de credito para una factura dada
    * p_factura es el nÃƒÂºmero de documento
    */
    FUNCTION F_NOTACREDITOTOTAL (P_FACTURA VARCHAR2, P_COMPANIA VARCHAR2, P_CODIGOPRODUCTO VARCHAR2) RETURN NUMBER AS
    val_notacredito number ;
    BEGIN
        if (p_compania = '00001') then --Ecuador
            select sum((TO_NUMBER(NVL(SDLPRC,0)/10000) - TO_NUMBER(NVL(SDUPRC,0)/10000)) * TO_NUMBER(NVL(SDPQOR,0)/10000) )
            into val_notacredito
            from F42119@JDEDTADL 
            where to_char(trim(SDKCOO)) = p_compania 
            and SDDCT = 'D1' AND SDODOC = P_FACTURA 
            AND SDLITM = P_CODIGOPRODUCTO AND SDODCT = 'FN' ;
            return nvl(round(val_notacredito,4),0) ;
        else 
            return 0;
        end if;
    exception   
        when no_data_found then
            return 0 ;
    END;

    /* Funcion que busca las observaciones de la nota de credito de una factura
    * p_factura es el nÃƒÂºmero de documento
    */
    FUNCTION F_NOTACREDIDESCRIPCION (P_FACTURA VARCHAR2, P_COMPANIA VARCHAR2, P_CODIGOPRODUCTO VARCHAR2) RETURN VARCHAR2 AS
    val_notacredito VARCHAR2(2500) ;
    BEGIN
        if (p_compania = '00001') then --Ecuador
            select LISTAGG(SDDSC2, '; ') WITHIN GROUP (ORDER BY SDDSC2) 
            into val_notacredito
            from F42119@JDEDTADL 
            where to_char(trim(SDKCOO)) = p_compania 
            and SDDCT = 'D1' AND SDODOC = P_FACTURA 
            AND SDLITM = P_CODIGOPRODUCTO AND SDODCT = 'FN' ;
            return nvl(val_notacredito,' ') ;
        else 
            return ' ' ;
        end if;
    exception   
        when no_data_found then
            return ' ' ;
    END;

    /*Procedimeinto que graba en la tabla los valores totales y cambia el estado 
      a las validaciones */
    PROCEDURE SP_ACUMULAVALOR( P_IDAGRUPACION NUMBER, P_IDVALIDACION NUMBER DEFAULT 0, 
        P_CODIGOGRUPO NUMBER DEFAULT 0 ) AS
        v_nombre data.t_icom_cliente_validacion.nombreagrupacion%type;
    BEGIN
    
        if (nvl(p_idvalidacion,0) = 0 ) then --- AQUI
            
            --Actualizamos los valores en base a los detalles de toda la agrupacion
            update data.t_icom_cliente_validacion cv
            set ( ESTADO, TOT_VENTA, TOT_CANTIDAD, TOT_VALORCLIENTE, TOT_VALORZAIMELLA, TOT_VENTAUND, TOT_VENTADIA, TOT_VENTADIAUND ) =
                ( SELECT 2, 
                    round(SUM(VALORVENTA),4),  --TOT_VENTA
                    round(SUM(NVL(CLI_CANTIDAD,0)),4), --TOT_CANTIDAD
                    case when idvalidaciontipo in (1,5) then round(SUM(NVL(CLI_VALOR,0)),4) 
                         when idvalidaciontipo in (4) then round(SUM(NVL(VALORZAIMELLA,0)),4) 
                         else round(SUM(NVL(CLI_VALOR,0)),4) end , --TOT_VALORCLIENTE
                    round(SUM(NVL(VALORZAIMELLA,0)),4) , --TOT_VALORZAIMELLA
                        round(SUM(NVL(val_ventaund,0)),4), --TOT_VENTAUND
                        round(SUM(NVL(val_ventadia,0)),4), --TOT_VENTADIA
                        round(SUM(NVL(val_ventadiaund,0)),4) --TOT_VENTADIAUND
                  FROM data.t_icom_cliente_validacion_det cd
                  where cv.id = cd.idvalidacion
                  and cv.codigogrupo = cd.codigogrupo
                )
            where cv.idagrupacion = p_idagrupacion 
            and cv.estado = 0 ;
            
            begin
                select a.NOMBREAGRUPACION
                into v_nombre
                from data.t_icom_cliente_validacion a
                where a.idagrupacion = p_idagrupacion
                and a.nombreagrupacion is not null
                and estado = 2
                and rownum = 1 ; 
            exception
                when no_data_found then
                     v_nombre := null ;
            end ;
            if v_nombre is not null then
                --actualizo el nombre de la agrupacion
                update data.t_icom_cliente_validacion
                set nombreagrupacion = v_nombre
                where idagrupacion = p_idagrupacion
                and nombreagrupacion is null
                and estado = 2 ;
            end if;
         else
            --Actualizamos los valores en base a los detalles de de una sola idvalidacion
            update data.t_icom_cliente_validacion cv
            set ( TOT_VALOREXCEPCION, TOT_VALOR  ) =
                ( SELECT round(SUM(NVL(VALOREXCEPCION,0)),4), round(SUM(NVL(VALORZAIMELLA,0))+SUM(NVL(VALOREXCEPCION,0)),4)
                  FROM data.t_icom_cliente_validacion_det cd
                  where cv.id = cd.idvalidacion
                  and cv.codigogrupo = cd.codigogrupo
                )
            where cv.idagrupacion = p_idagrupacion 
            and cv.id = p_idvalidacion
            and cv.codigogrupo = p_codigogrupo
            and cv.estado = 2 ;
            --RAISE_APPLICATION_ERROR(-20100,'Ejecuta update '||sqlerrm);
         end if;
         
         --RAISE_APPLICATION_ERROR(-20100,'variables idvalidacion: '||p_idvalidacion||', idagrupacion: '||p_idagrupacion||', codigo: '||p_codigogrupo||', '||sqlerrm);
    END ;

  
    /*Procedimeinto que actualiza la observacion y el nombre de la agrupacion en la cabecera de la validacion*/
    PROCEDURE SP_ACTUALIZACLI_VAL (P_IDVALIDACION NUMBER, P_IDAGRUPACION NUMBER, 
        P_NOMBRE VARCHAR2, P_OBSERVACION VARCHAR2, P_VALORCLIENTE NUMBER DEFAULT NULL ) AS
    BEGIN
        if p_nombre is not null and nvl(p_idagrupacion,0) > 0   then
            --se actualiza el nombre de la agrupacion para todos los registros
            update data.t_icom_cliente_validacion
            set nombreagrupacion = p_nombre
            where idagrupacion = p_idagrupacion 
            and estado = 2             ;
        end if;
        update data.t_icom_cliente_validacion
            set observaciones = P_OBSERVACION, 
                tot_valorcliente = decode(nvl(p_valorcliente,0),0, tot_valorcliente, p_valorcliente)
            where id = P_IDVALIDACION 
            and estado = 2 
            ;

    END;

    /*Procedimiento que valida y envia a ruta la agrupacion de validaciones
    PK_ICOM_VALIDACION.SP_ENVIARRUTA (P_IDAGRUPACION =>123, P_NOMBREAGRUPACION =>'XXXX', P_USUARIO =>'JBALCAZAR',
        P_COMPANIA =>'00001' )
    */
    PROCEDURE SP_ENVIARRUTA (P_IDAGRUPACION NUMBER, P_NOMBREAGRUPACION VARCHAR2, P_USUARIO VARCHAR2,
        P_COMPANIA VARCHAR2 ) AS 
    v_sumaexcepcion number;
    v_resultado number;
    V_TIPOINVERSION VARCHAR2(100);
    V_AREA VARCHAR2(100);
     V_ETAPA VARCHAR(10);
     V_ORIGEN VARCHAR2(100);
     V_CANAL VARCHAR2(500);
     V_AGRUPADO VARCHAR2(100);
     V_TIPO VARCHAR2(500);
    V_ERROR varchar2(500);
    BEGIN

        --Se debe validar que el valor de excepcion
        begin
            select sum(nvl(TOT_VALOREXCEPCION,0))
            into v_sumaexcepcion
            from data.t_icom_cliente_validacion
            where estado = 2
            and idagrupacion = p_idagrupacion ;
        exception
            when no_data_found then
                v_sumaexcepcion := 0 ;
            when others then
                v_sumaexcepcion := 0 ;

        end;
        V_AGRUPADO := '0';
        if nvl(v_sumaexcepcion,0) > 0 then
            --en caso de existir valor verifica que exista adjuntos
            V_AGRUPADO := 1 ;
            v_sumaexcepcion := 0 ;
            begin
                select  count(1) into v_sumaexcepcion FROM  FILES.T_APEX_ARCHIVOS 
                WHERE  TABLA = 'T_ICOM_CLIENTE_VALIDACION'
                AND  ID_TABLA = p_idagrupacion ;
            exception
                when no_data_found then
                    v_sumaexcepcion := 0 ;
                when others then
                    v_sumaexcepcion := 0 ;
            end;    
            if nvl(v_sumaexcepcion,0) = 0 then
                RAISE_APPLICATION_ERROR(-20100,'No se puede enviar a ruta sin adjuntar archivos '||p_idagrupacion);
            end if;
        end if;
        
        if P_NOMBREAGRUPACION is not null and nvl(p_idagrupacion,0) > 0   then
            --se actualiza el nombre de la agrupacion para todos los registros
            update data.t_icom_cliente_validacion
            set nombreagrupacion = P_NOMBREAGRUPACION
            where idagrupacion = P_IDAGRUPACION 
            and estado = 2  ;
        end if;
        --se debe validar que no existas otras inversiones en las misma fechas
        for inv in (select idagrupacion, idinversion, codigogrupo, val_fechainicio, val_fechafin 
                    from  data.t_icom_cliente_validacion where idagrupacion = P_IDAGRUPACION  and estado = 2  )
        loop                    
            V_ERROR := F_VALIDAFECHASRANGO (P_IDAGRUPACION => inv.idagrupacion, 
                                 P_IDINVERSION => inv.idinversion, 
                                 P_CODIGOGRUPO => inv.codigogrupo , 
                                 P_FECHAINICIO => inv.val_fechainicio, 
                                 P_FECHAFIN => inv.val_fechafin ) ;
            --dbms_output.put_line( 'Error '|| v_error );                 
            if v_error != 'OK' then
                RAISE_APPLICATION_ERROR(-20100,v_error);
            end if; 
        end loop;
        --Se debe verificar que exista alguna inversines que se deba enviar a ruta
        select count(1) into v_resultado
            from data.t_icom_cliente_validacion
            where estado = 2
            and idagrupacion = p_idagrupacion
            and tot_valorzaimella+nvl(tot_valorexcepcion,0) > 0 
            and idvalidaciontipo in ( select id_tabla from data.T_CORP_UDC 
                                     where id_cabecera = 'ICOM_RVAL' and activo = 1 and to_number(valor) = 1
                                     --and codigocompania=P_COMPANIA
                                     );
      
        dbms_output.put_line( 'Tipo de inversion va a ruta: '||v_resultado);
        
        if nvl(v_resultado,0) > 0 then
            v_resultado := 1 ;
            
            --enviar a flujo
            SELECT LISTAGG(A.IDINVERSIONTIPO, ',') WITHIN GROUP (ORDER BY A.IDINVERSIONTIPO)
            INTO V_TIPOINVERSION
            FROM ( SELECT DISTINCT IDINVERSIONTIPO FROM DATA.VT_ICOM_INVERSIONES 
                   WHERE  ID IN ( SELECT CV.IDINVERSION from data.t_icom_cliente_validacion CV 
                                  where  cv.idagrupacion = P_IDAGRUPACION  and cv.estado = 2 )
                  ) A ;
          
             --OBTIENE:  LOS CANALAS DE LA INVERSION V_CANAL
            SELECT LISTAGG(CODIGOCANAL, ',') WITHIN GROUP (ORDER BY CODIGOCANAL) CANAL
            INTO V_CANAL
            FROM ( SELECT distinct CODIGOCANAL FROM DATA.VT_ICOM_INVERSION_CLIENTE 
                   WHERE  TRIM(CODIGOCANAL) IS NOT NULL AND
                    idinversion in (select distinct cv.IDINVERSION from data.t_icom_cliente_validacion cv 
                                    where  cv.idagrupacion = P_IDAGRUPACION  and cv.estado = 2 ) and 
                    codigoGrupo in (select distinct cv.CODIGOGRUPO from data.t_icom_cliente_validacion cv 
                                    where  cv.idagrupacion = P_IDAGRUPACION  and cv.estado = 2 )
            GROUP BY CODIGOCANAL);    
            
            DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJOENVIAR(
                p_id=> p_idagrupacion,
                p_objeto=> 'VALIDACION_INVERSION',
                p_objetodescripcion=>p_nombreagrupacion ,
                p_usuario=> P_USUARIO,
                p_modulo=>G_MODULO,
                p_compania=>P_COMPANIA,
                P_ETAPA=>'VALIDACION',
                P_TIPO1=>7,  -- etapa
                p_exito =>  v_resultado); 
                
            if v_resultado = 0 then
                RAISE_APPLICATION_ERROR(-20100,PK_CORP_FLUJOAPROBACION.G_MENSAJE);
            else
                --si se envio a ruta se modifica el estado
                update data.t_icom_cliente_validacion
                set estado = 3
                where idagrupacion = p_idagrupacion
                and estado = 2 
                and tot_valorzaimella+nvl(tot_valorexcepcion,0) > 0 
                and idvalidaciontipo in ( select id_tabla from data.T_CORP_UDC 
                                          where id_cabecera = 'ICOM_RVAL' and activo = 1 and to_number(valor) = 1  
                                          --and codigocompania=P_COMPANIA
                                          );
                                          
                
                for inversion in (select idinversion, codigogrupo from data.t_icom_cliente_validacion  
                                  where idagrupacion = p_idagrupacion and estado = 3 ) loop
                    --se graba la auditoria 
                    --ENVIAR A RUTA auditoria            
                    PK_ICOM_COMMONS.SP_AUDITORIA(
                                P_USUARIO => P_USUARIO,
                                P_IDINVERSION => inversion.idinversion,
                                P_IDETAPA => 7,
                                P_CODIGOGRUPO => inversion.codigogrupo,
                                P_IDACCION =>5,
                                P_DESCRIPCION => 'SE ENVIA A RUTA DE APROBACION LA VALIDACION '||p_idagrupacion||'  QUE CONTIENE A LA INVERSION' );
                    
                end loop;                  
                                
                --se modifica la etapa de las inversiones que se estan enviado a ruta
                update data.t_icom_inversiones
                set idetapa2 = 7 --etapa de validacion
                where id in ( select id 
                              from data.t_icom_cliente_validacion 
                              where idagrupacion = p_idagrupacion and estado = 3 ) ;
            end if;
        end if;
        
        --Se debe verificar que tenga inversines que NO se deben enviar a ruta
        begin
            select count(1) into v_resultado
            from data.t_icom_cliente_validacion
            where estado = 2
            and idagrupacion = p_idagrupacion 
            and ( nvl(tot_valorzaimella+nvl(tot_valorexcepcion,0),0) = 0   
                  or idvalidaciontipo in ( select id_tabla from data.T_CORP_UDC
                                     where id_cabecera = 'ICOM_RVAL' and activo = 1 and to_number(valor) = 0  
                                     --and codigocompania=P_COMPANIA
                                     )) ;
        exception 
            when no_data_found then 
               v_resultado := 0 ;
        end;
        
        if nvl(v_resultado,0) > 0 then
            SP_APROBARVALIDACION (P_IDAGRUPACION => p_idagrupacion , P_TIPO => 3, P_USUARIO => P_USUARIO ); --aprobacion directa
        end if;                         
        
    END ;

    /*Procedimiento que aprueba o rechaza la validacion
    
    PK_ICOM_VALIDACION.SP_APROBARVALIDACION()
    */
    PROCEDURE SP_APROBARVALIDACION (P_IDAGRUPACION NUMBER, P_TIPO NUMBER, P_USUARIO  VARCHAR2, P_COMPANIA VARCHAR) AS
    v_contador number;
    BEGIN
        /*Se verifica de tipo es*/
        if (p_tipo = 1) then --es aprobacion       
           
                 select  MAX(IDFORMAPAGO) into V_CONTADOR
                    from data.t_icom_cliente_validacion
                    where idagrupacion = P_IDAGRUPACION ;
           
            --- PASA DE VALIDACION AL SISTEMA DE NOTAS DE CREDITO  
            BEGIN 
                IF(V_CONTADOR=3 and P_COMPANIA='00001') THEN --- FORMA DE PAGO NC
                    sp_validacion_a_notascredito(P_IDAGRUPACION =>p_idagrupacion,P_COMPANIA=>P_COMPANIA);
                END IF;
                
            EXCEPTION
            WHEN OTHERS THEN 
           --- En el caso que de Error debe hacer un rollback de la aprobacion                     
                SELECT max(ID) INTO  v_contador 
                FROM t_flujo_aprobacion_cab WHERE entidad_id=P_IDAGRUPACION AND ENTIDAD_CLASE='VALIDACION_INVERSION';
                
                update t_flujo_aprobacion_cab set estado='EN_PROCESO', FECHA_FIN=NULL  WHERE ID=v_contador;
                UPDATE t_flujo_aprobacion_DET SET estado='EN_PROCESO', FECHA_HASTA=NULL WHERE FLUJO_ID=v_contador AND USERID=P_USUARIO;
                
                COMMIT; 
                RAISE_APPLICATION_ERROR(-20100,SQLERRM);
           END ; 
           
           --se actualiza el estado de la validacion a aprobado
           update data.t_icom_cliente_validacion  set estado = 1
           where estado = 3 and idagrupacion = p_idagrupacion ;
                      
           --se realiza el cierre de las inversiones
           SP_PASARCIERRE (p_idagrupacion) ;

           --se envia el correo de aprobacion
           SP_CORREOAPROBACION (p_idagrupacion) ;
           
                --se busca todas las inversiones de la validacion para la auditoria
           for inv in ( select distinct idinversion, idinversiontipo, idvalidaciontipo, codigogrupo --, codigogrupo, val_fechainicio, val_fechafin 
                         from data.t_icom_cliente_validacion 
                         where estado = 3 and idagrupacion = p_idagrupacion ) 
           loop
               --APROBACION auditoria            
               PK_ICOM_COMMONS.SP_AUDITORIA(
                        P_USUARIO => P_USUARIO,
                        P_IDINVERSION => inv.idinversion,
                        P_IDETAPA => 7,
                        P_CODIGOGRUPO => inv.codigogrupo,
                        P_IDACCION => 6,
                        P_DESCRIPCION => 'SE APRUEBA LA VALIDACION '|| P_IDAGRUPACION ||' QUE CONTIENE LA INVERSION' );
           end loop;
           
        elsif (p_tipo = 3) then --es aprobacion directa
           
           --se busca todas las inversiones de la validacion
           for inv in ( select distinct idinversion, idinversiontipo, idvalidaciontipo, codigogrupo --, codigogrupo, val_fechainicio, val_fechafin 
                         from data.t_icom_cliente_validacion 
                         where estado = 2 and idagrupacion = p_idagrupacion ) 
           loop
               --APROBACION auditoria            
               PK_ICOM_COMMONS.SP_AUDITORIA(
                        P_USUARIO => P_USUARIO,
                        P_IDINVERSION => inv.idinversion,
                        P_IDETAPA => 7,
                        P_CODIGOGRUPO => inv.codigogrupo,
                        P_IDACCION => 6,
                        P_DESCRIPCION => 'SE APRUEBA DIRECTAMENTE LA VALIDACION '|| P_IDAGRUPACION ||' QUE CONTIENE LA INVERSION' );
           end loop;
           
           --se actualiza el estado de la validacion a aprobado
           update data.t_icom_cliente_validacion
           set estado = 1
           where estado = 2
           and idagrupacion = p_idagrupacion 
           and ( nvl(tot_valorzaimella+nvl(tot_valorexcepcion,0),0) = 0   
                  or idvalidaciontipo in ( select id_tabla idValidacion from data.T_CORP_UDC
                                     where id_cabecera = 'ICOM_RVAL' and activo = 1 and to_number(valor) = 0 
                                     --and codigocompania=COMPANIA
                                     )) ;
           
           --se realiza el cierre de las inversiones
           data.PK_ICOM_VALIDACION.SP_PASARCIERRE (p_idagrupacion) ;

        else -- es rechazo
             --se busca todas las inversiones de la validacion
           for inv in ( select distinct idinversion, idinversiontipo, idvalidaciontipo, codigogrupo --, codigogrupo, val_fechainicio, val_fechafin 
                         from data.t_icom_cliente_validacion 
                         where estado = 3 and idagrupacion = p_idagrupacion ) 
           loop
               --RECHAZO auditoria            
               PK_ICOM_COMMONS.SP_AUDITORIA(
                        P_USUARIO => P_USUARIO,
                        P_IDINVERSION => inv.idinversion,
                        P_IDETAPA => 7,
                        P_CODIGOGRUPO => inv.codigogrupo,
                        P_IDACCION => 6,
                        P_DESCRIPCION => 'SE RECHAZO LA VALIDACION '|| P_IDAGRUPACION ||' QUE CONTIENE LA INVERSION' );
           end loop;
           
            --se actualiza el estado de la validacion 
           update data.t_icom_cliente_validacion
           set estado = 2
           where idagrupacion = p_idagrupacion ;
       
        end if;
    END;

    /*Procedimieto que pasa a cierre las inversiones que cumplan con la condicion de fechas.*/
    PROCEDURE SP_PASARCIERRE (P_IDAGRUPACION NUMBER) AS
        v_fechafin date;
        v_cuentaclientes number ;
        v_cuentavalidaciones number;
        v_cuenta number;
    BEGIN
    
        RETURN;
        --se busca todas las inversiones de la validacion
        for inv in ( select distinct idinversion, idinversiontipo, idvalidaciontipo, codigogrupo --, codigogrupo, val_fechainicio, val_fechafin 
                     from data.t_icom_cliente_validacion 
                     where estado = 1 and idagrupacion = p_idagrupacion ) 
        loop
        
            --para cada una de las inversiones se debe verificar
            --que todos los clientes tienen las validacines en su fecha maxima
            v_cuentaclientes := 0  ;
            v_cuentavalidaciones := 0 ;
            
             select count(1) into v_cuentaclientes
                         from data.t_icom_inversion_cliente_g
                         where idinversion = inv.idinversion and negociacion in (1,3);
            
            for cli in ( select codigogrupo, fechainicio, fechafin 
                         from data.t_icom_inversion_cliente_g
                         where idinversion = inv.idinversion and negociacion in (3))
            loop

                begin
                    select count(1) into v_cuenta 
                    from data.t_icom_cliente_validacion 
                    where idinversion = inv.idinversion
                    and codigogrupo = cli.codigogrupo
                    and trunc(val_fechafin) >= trunc(cli.fechafin)
                    and estado = 1 ;
                exception 
                    when no_data_found then
                        v_cuenta := 0 ;
                end;
                if nvl(v_cuenta,0) > 0 then
                    v_cuentavalidaciones := v_cuentavalidaciones + 1 ;
                end if;    
            end loop;
            
            if (v_cuentaclientes = v_cuentavalidaciones) then
                --si todos los clientes tienen validacion para la fecha maxima pasa a cierre la inversion
                update data.t_icom_inversiones
                set idetapa = 4, idetapa2 = null --etapa 4 cierre
                where id = inv.idinversion ;
                
                PK_ICOM_PROCESOSTAREAS.SP_ActualizarPDV(inv.idinversion);
                
                PK_ICOM_COMMONS.SP_AUDITORIA(
                        P_USUARIO => 'ICOM',
                        P_IDINVERSION => inv.idinversion,
                        P_IDETAPA => 4,
                        P_CODIGOGRUPO => inv.codigogrupo,
                        P_IDACCION => 6,
                        P_DESCRIPCION => 'PASA A CIERRE POR APROBACION DE VALIDACION QUE CONTIENEN TODOS LOS CLIENTES VALIDADOS' );
                
            end if;
        end loop;
    END;

    /* Procedimiento que envia el correo de aprobacion de la validacion*/
    PROCEDURE SP_CORREOAPROBACION (P_IDAGRUPACION NUMBER ) AS
        V_OBJETO_DES clob :='';
        V_OBJETO_CAB varchar2(2000) :='';
        v_correo varchar2(4500);
        v_correoejecutivo varchar2(4500);
        v_codigogrupo number := -1;
        v_idformapago number := -1;
        v_formapago data.T_CORP_UDC.descripcion%type;
        v_grupo data.vt_icom_cli_val_inversion.nombregrupo%type;
        v_total number := 0 ;
        v_totalzaimella number := 0 ;
        v_valor number := 0 ;
        v_valortotal number := 0 ;
        v_excepcion number := 0 ;
        v_excepciontotal number := 0 ;
        v_nombre data.t_icom_cliente_validacion.nombreagrupacion%type;
        v_inicio varchar2(500) ;
        v_link varchar2(500) ;
        v_compania data.t_icom_cliente_validacion.compania%type;
    BEGIN

        select nombreagrupacion, compania into v_nombre, v_compania 
        from data.t_icom_cliente_validacion where idagrupacion = p_idagrupacion and rownum = 1 ;
        
        begin
            v_link:=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '16',v_compania,'','','1' );
        exception when no_data_found then
            v_link := '';
        end;

        --Genero los datos para enviar el correo 
        V_OBJETO_CAB := '<table border=''1'' style=''width:100%; padding:0px; border-spacing:0px;''>';
		V_OBJETO_CAB := V_OBJETO_CAB || '<tr BGCOLOR=''lightgrey''>  ';
        V_OBJETO_CAB := V_OBJETO_CAB ||'<th  ALIGN=CENTER width=''3%''><strong>ID </strong></th>';
        V_OBJETO_CAB := V_OBJETO_CAB ||'<th  ALIGN=CENTER width=''20%''><strong>CLIENTE </strong></th>';
        V_OBJETO_CAB := V_OBJETO_CAB ||'<th  ALIGN=CENTER width=''8%''><strong>FORMA DE PAGO </strong></th>';
        V_OBJETO_CAB := V_OBJETO_CAB ||'<th  ALIGN=CENTER width=''18%''><strong>INVERSION </strong></th>';
        V_OBJETO_CAB := V_OBJETO_CAB ||'<th  ALIGN=CENTER width=''9%''><strong>AREA </strong></th>';
        V_OBJETO_CAB := V_OBJETO_CAB ||'<th  ALIGN=CENTER width=''6%''><strong>VALOR CLIENTE </strong></th>';
        V_OBJETO_CAB := V_OBJETO_CAB ||'<th  ALIGN=CENTER width=''6%''><strong>VALOR ZAIMELLA </strong></th>';
        V_OBJETO_CAB := V_OBJETO_CAB ||'<th  ALIGN=CENTER width=''6%''><strong>DIFERENCIA </strong></th>';
        V_OBJETO_CAB := V_OBJETO_CAB ||'<th  ALIGN=CENTER width=''6%''><strong>VALOR EXCEPCION </strong></th>';
        V_OBJETO_CAB := V_OBJETO_CAB ||'<th  ALIGN=CENTER width=''6%''><strong>VALOR TOTAL</strong></th>';
        V_OBJETO_CAB := V_OBJETO_CAB ||'<th  ALIGN=CENTER width=''12%''><strong>OBSERVACION </strong></th></tr>';
       
        V_OBJETO_DES := '';
        FOR INVERSION IN (SELECT IDINVERSION, CODIGOGRUPO, NOMBREGRUPO, IDFORMAPAGO, FORMAPAGO, NOMBRE, AREA, TOT_VALORCLIENTE, 
                TOT_VALORZAIMELLA, TOT_VALOREXCEPCION, TOT_VALOR, OBSERVACIONES
                FROM data.vt_icom_cli_val_inversion WHERE estado = 1 and idagrupacion = p_idagrupacion
                order by IDFORMAPAGO, CODIGOGRUPO ) LOOP 
            --detalle llenar
            if (v_codigogrupo = -1 ) then --es la primera vez que ingresa
                --se asigna los valores a las variables
                v_codigogrupo := inversion.codigogrupo ;
                v_idformapago := inversion.idformapago ;
                v_total := nvl(inversion.tot_valorcliente,0) ;
                v_totalzaimella := nvl(inversion.tot_valorzaimella,0) ;
                v_formapago := inversion.formapago ;
                v_grupo := inversion.nombregrupo;
                v_valortotal := inversion.tot_valor ;
                v_excepciontotal := inversion.tot_valorexcepcion ; 
                V_OBJETO_DES := V_OBJETO_CAB;
            elsif (v_codigogrupo = inversion.codigogrupo and v_idformapago = inversion.idformapago ) then 
                --se verifica si es el mismo cliente y forma de pago se suma el total
                v_total := v_total + nvl(inversion.tot_valorcliente,0) ;
                v_totalzaimella := v_totalzaimella + nvl(inversion.tot_valorzaimella,0) ;
                v_valortotal := v_valortotal + inversion.tot_valor ;
                v_excepciontotal := v_excepciontotal + inversion.tot_valorexcepcion ; 
            elsif (v_codigogrupo != inversion.codigogrupo and v_idformapago = inversion.idformapago ) then 
                --es un grupo diferente se inserta un subtotal 
                V_OBJETO_DES:= V_OBJETO_DES||'<tr> <td ALIGN=LEFT > </td>';
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT ><strong>TOTAL '||v_grupo||' </strong></td>';
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER > </td>';
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER > </td>';
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER > </td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER ><strong> '	|| to_char( round(  v_total ,2) )	||' </strong></td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER ><strong> '	|| to_char( round(  v_totalzaimella ,2) )	||'</strong></td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER ><strong> '	|| to_char( round(  v_totalzaimella - v_total ,2) ) 	||'<strong></td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER ><strong> '	|| to_char( round(  v_excepciontotal ,2) )	||'</strong></td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER ><strong> '	|| to_char( round(  v_valortotal ,2) )	||'</strong></td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER > </td></tr>';
                v_codigogrupo := inversion.codigogrupo ;
                v_idformapago := inversion.idformapago ;
                v_total := nvl(inversion.tot_valorcliente,0) ;
                v_totalzaimella := nvl(inversion.tot_valorzaimella,0) ;
                v_formapago := inversion.formapago ;
                v_grupo := inversion.nombregrupo;
                v_valortotal := inversion.tot_valor ;
                v_excepciontotal := inversion.tot_valorexcepcion ; 
            elsif ( v_idformapago != inversion.idformapago ) then 
                --es una forma de pago diferente diferente se inserta un subtotal 
                V_OBJETO_DES:= V_OBJETO_DES||'<tr> <td ALIGN=LEFT > </td>';
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT ><strong>TOTAL '||v_grupo||' </strong></td>';
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER > </td>';
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER > </td>';
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER > </td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER ><strong> '	||  round( v_total ,2) 	||' </strong></td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER ><strong> '	||  round( v_totalzaimella ,2) 	||'</strong></td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER ><strong> '	||  to_char(round( v_totalzaimella - v_total ,2) ) 	||'<strong></td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER ><strong> '	||  round( v_excepciontotal ,2) 	||'</strong></td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER ><strong> '	||  round( v_valortotal ,2) 	||'</strong></td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER > </td></tr>';
                V_OBJETO_DES := V_OBJETO_DES||'</table>' ;
                --Se inserta la despedida
                V_OBJETO_DES := V_OBJETO_DES||' <p> <br/><br/> Gracias por su atencion </p>';
                v_inicio := ' <p> Se ha aprobado lo siguiente:  <a href ='''
                    ||v_link||DATA.PK_COMMONS.F_ENCRYPT('P266_IDAGRUPACION,P266_IDFORMAPAGO:'||P_IDAGRUPACION || ',' ||V_IDFORMAPAGO|| ',')||'''> '||v_nombre||';</a> <br/></p>';
                 V_OBJETO_DES := V_INICIO||V_OBJETO_DES ;
                --busco el correo al que se debe enviar
                v_correo := F_BUSCACORREOPAGO (P_IDFORMAPAGO => v_idformapago, P_COMPANIA => v_compania ) ;
                --BUSAR ORREO EJEUTIVO
                v_correoejecutivo:=PK_ICOM_HERRAMIENTAS.F_CORREOEJECUTIVO(P_CODIGOGRUPO=>inversion.codigogrupo) ;
                v_correo:=v_correo||v_correoejecutivo;

                dbms_output.put_line( 'v_correo: '||v_correo ||' V_OBJETO_DES: '||V_OBJETO_DES );
                --se envia el correo
                PK_CORP_CORREO.SP_ENVIO(
                    P_MODULO => G_MODULO,
                    P_TO => v_correo,
                    P_FROM => 'notificacion@zaimella.com',
                    P_SUBJECT => 'Aprobacion de Validacion - '||v_nombre,
                    P_BODY => V_OBJETO_DES
                  );    
                  
                v_codigogrupo := inversion.codigogrupo ;
                v_idformapago := inversion.idformapago ;
                v_total := nvl(inversion.tot_valorcliente,0) ;
                v_totalzaimella := nvl(inversion.tot_valorzaimella,0) ;
                v_formapago := inversion.formapago ;
                v_grupo := inversion.nombregrupo;
                v_valortotal := inversion.tot_valor ;
                v_excepciontotal := inversion.tot_valorexcepcion ; 
                V_OBJETO_DES := V_OBJETO_CAB;
            end if;
            
            V_OBJETO_DES:= V_OBJETO_DES||'<tr> <td ALIGN=LEFT >'|| to_char(INVERSION.idinversion)		||'</td>';
			V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT >'	|| INVERSION.nombregrupo		||'</td>';
			V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT >'	|| INVERSION.formapago	||'</td>';
			V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT >'	|| INVERSION.nombre		||'</td>';
			V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT >'	|| INVERSION.area	||'</td>' ;
            V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER >'	|| to_char( round( INVERSION.tot_valorcliente ,2) )	||'</td>' ;
            V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER >'	|| to_char( round( INVERSION.tot_valorzaimella ,2) )	||'</td>' ;
            V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER >'	|| to_char( round( INVERSION.tot_valorzaimella - INVERSION.tot_valorcliente ,2) )	||'</td>' ;
            V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER >'	|| to_char( round( INVERSION.tot_valorexcepcion ,2) )||'</td>' ;
            V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER >'	|| to_char( round( INVERSION.tot_valor ,2) )||'</td>' ;
            V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT >'	|| INVERSION.observaciones	||'</td></tr>';
        --- termino llenar detalle
        END LOOP;  
        
        --se inserta el ultimo total 
        V_OBJETO_DES:= V_OBJETO_DES||'<tr> <td ALIGN=LEFT > </td>';
        V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER > <strong>TOTAL '||v_grupo||' '||v_formapago||'</strong></td>';
        V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER > </td>';
        V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER > </td>';
        V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER > </td>' ;
        V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER ><strong>'	|| to_char( round( v_total ,2) )	||'</strong></td>' ;
        V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER ><strong>'	|| to_char( round( v_totalzaimella ,2) )	||'</strong></td>' ;
        V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER ><strong>'	|| to_char( round( v_totalzaimella   - v_total ,2) ) ||'</strong></td>' ;
        V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER ><strong>'	|| to_char( round( v_excepciontotal ,2) )	||'</strong></td>' ;
        V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER ><strong>'	|| to_char( round( v_valortotal ,2) )	||'</strong></td>' ;
        V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER > </td></tr>';
        V_OBJETO_DES:= V_OBJETO_DES||'</table>' ;
        --Se inserta la despedida
        V_OBJETO_DES := V_OBJETO_DES||' <p> <br/><br/> Gracias por su atencion </p>';
        --dbms_output.put_line( 'objeto '||V_OBJETO_DES );
        v_inicio := ' <p> Se ha aprobado lo siguiente:  <a href ='''
                    ||v_link||DATA.PK_COMMONS.F_ENCRYPT('P266_IDAGRUPACION,P266_IDFORMAPAGO:'||P_IDAGRUPACION || ',' ||V_IDFORMAPAGO)||'''> '||v_nombre||';</a> <br/></p>';
        V_OBJETO_DES := V_INICIO||V_OBJETO_DES ;
        v_correo := F_BUSCACORREOPAGO (P_IDFORMAPAGO => v_idformapago, P_COMPANIA => v_compania ) ;
        --BUSAR ORREO EJEUTIVO
        v_correoejecutivo:=PK_ICOM_HERRAMIENTAS.F_CORREOEJECUTIVO(P_CODIGOGRUPO=>v_codigogrupo) ;
        v_correo:=v_correo||v_correoejecutivo;
        dbms_output.put_line( 'v_correo: '||v_correo ||' V_OBJETO_DES: '||V_OBJETO_DES );
        --se envia el correo
        PK_CORP_CORREO.SP_ENVIO(
                    P_MODULO => G_MODULO,
                    P_TO => v_correo,
                    P_FROM => 'notificacion@zaimella.com',
                    P_SUBJECT => 'Aprobacion de Validacion - '||v_nombre,
                    P_BODY => V_OBJETO_DES
                  );    

    END;
   
    /*Procedimiento de ejecucion diaria para modificar a la etapa de validacion en caso de cumplir las condiciones*/
    PROCEDURE SP_AUTO_ETAPA as
    BEGIN
        update data.t_icom_inversiones
        set idetapa = 7, idetapa2 = null  --validacion
        where idetapa = 3 and estado<>2
        and fechafin <= trunc(sysdate) ;
        commit;
    END;
    
    /*Procedimiento que elimina una factua o todas del detalle de validacion contra factura
    * p_idvalidacion es el idvalidacion del detalla en caso de borrar una sola o es el idagrupacion en caso de borrar todas
    * p_codigo es el idcodigocliente de la factura en caso de borrar una sola o es el idvalidaciontipo en caso de borrar todas
    * p_codigoproducto es el codigo del producto de la factura
    * p_factura es el numero de factura
    */
    PROCEDURE SP_ELIMINAFACTURA (P_IDVALIDACION NUMBER, P_CODIGO VARCHAR2 default null, P_CODIGOPRODUCTO VARCHAR2 default null, 
                                 P_FACTURA VARCHAR2 default null ) AS
    BEGIN
        if p_codigoproducto is not null and p_factura is not null then
            --BORRA UNA FACTURA
            delete from data.t_icom_cliente_validacion_det
            where idvalidacion = p_idvalidacion 
            and factura = p_factura
            and codigocliente = p_codigo
            and codigoproducto = p_codigoproducto ;
            --commit;                        
        else
            --BORRA TODAS LAS FACTURAS
             --se elimina el detalle de todas las validaciones
            delete from data.t_icom_cliente_validacion_det
            where (idvalidacion, codigogrupo) in ( select id, codigogrupo from data.t_icom_cliente_validacion
                                                where idagrupacion = p_idvalidacion 
                                                  and idvalidaciontipo = p_codigo
                                                  and estado = 0 ) ;
            --commit;                        
        end if;
    END;
    
    /*Funcion que busca el correo al que se debe enviar la notificacion de aprobacion de la validacion
      de acuerdo a la forma de pago*/
    FUNCTION F_BUSCACORREOPAGO (P_IDFORMAPAGO VARCHAR2, P_COMPANIA VARCHAR2 )   RETURN VARCHAR2 AS
        v_correo varchar2(250);
    BEGIN
        --busco el correo por forma de pago
        SELECT LISTAGG(email, ', ') WITHIN GROUP (ORDER BY email) LISTA
        into v_correo
        FROM data.VT_ICOM_FORMAPAGONOTIFICA
        where idformapago = p_idformapago and compania = p_compania ;
        
        dbms_output.put_line( 'primer intento v_correo: '||v_correo||' length:'||length(nvl(trim(v_correo),' ')));
        if trim(v_correo) is null then
            --en caso de que no encuentre el correo busca uno general
            v_correo:=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '9',P_COMPANIA,'','','1' );
             dbms_output.put_line( 'segundo intento v_correo: '||v_correo);
        end if;
        return v_correo ;
    EXCEPTION   
        WHEN NO_DATA_FOUND THEN
        dbms_output.put_line( 'NO_DATA_FOUND: ');
            --en caso de que no encuentre el correo busca uno general
            v_correo:=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '9',P_COMPANIA,'','','1' );
            return v_correo ;
        WHEN OTHERS THEN
        dbms_output.put_line( 'OTHERS: ');
            return '' ;
    END F_BUSCACORREOPAGO;
    
    /*Procedimiento que inserta el detalle del rebate*/
    PROCEDURE SP_guardaRebate (P_IDINVERSION NUMBER, P_CODIGOGRUPO VARCHAR2, P_IDVALIDACION NUMBER, P_FILA NUMBER, P_IDREBATE NUMBER,
        P_VALOR1 VARCHAR2 DEFAULT NULL, P_VALOR2 VARCHAR2 DEFAULT NULL, P_VALOR3 VARCHAR2 DEFAULT NULL, P_VALOR4 VARCHAR2 DEFAULT NULL,
        P_VALOR5 VARCHAR2 DEFAULT NULL, P_VALOR6 VARCHAR2 DEFAULT NULL, P_VALOR7 VARCHAR2 DEFAULT NULL, P_VALOR8 VARCHAR2 DEFAULT NULL,
        P_VALOR9 VARCHAR2 DEFAULT NULL, P_VALOR10 VARCHAR2 DEFAULT NULL, P_VALOR11 VARCHAR2 DEFAULT NULL, P_VALOR12 VARCHAR2 DEFAULT NULL,
        P_VALOR13 VARCHAR2 DEFAULT NULL, P_VALOR14 VARCHAR2 DEFAULT NULL, P_VALOR15 VARCHAR2 DEFAULT NULL, P_VALOR16 VARCHAR2 DEFAULT NULL,
        P_VALOR17 VARCHAR2 DEFAULT NULL, P_VALOR18 VARCHAR2 DEFAULT NULL, P_VALOR19 VARCHAR2 DEFAULT NULL, P_VALOR20 VARCHAR2 DEFAULT NULL ) AS
    BEGIN
        DELETE FROM DATA.T_ICOM_CLIENTEREBATEDET WHERE IDVALIDACION = P_IDVALIDACION AND FILA = P_FILA ;
        
        INSERT INTO DATA.T_ICOM_CLIENTEREBATEDET
        (IDINVERSION, CODIGOGRUPO, IDVALIDACION, FILA, IDREBATE, VALOR1, VALOR2, VALOR3, VALOR4, VALOR5, VALOR6, VALOR7, VALOR8,
         VALOR9, VALOR10,VALOR11, VALOR12 , VALOR13, VALOR14, VALOR15, VALOR16, VALOR17, VALOR18, VALOR19, VALOR20 )
        VALUES
        (P_IDINVERSION, P_CODIGOGRUPO, P_IDVALIDACION, P_FILA, P_IDREBATE, P_VALOR1, P_VALOR2, P_VALOR3, P_VALOR4, P_VALOR5, P_VALOR6, P_VALOR7, P_VALOR8,
         P_VALOR9, P_VALOR10, P_VALOR11, P_VALOR12 , P_VALOR13, P_VALOR14, P_VALOR15, P_VALOR16, P_VALOR17, P_VALOR18, P_VALOR19, P_VALOR20 );
         COMMIT;
    END SP_guardaRebate ;
    
    /*Procedimiemto que actualiza el estado de la validacion para regresar a la pantalla de valores*/
    PROCEDURE SP_cambiaValidacion( P_IDAGRUPACION NUMBER, P_VALIDACIONTIPO NUMBER, P_INVERSIONTIPO NUMBER ) AS
    BEGIN
        update data.t_icom_cliente_validacion
        set estado = 0 
        where idagrupacion = p_idagrupacion
        and idinversiontipo = p_inversiontipo
        and idvalidaciontipo = p_validaciontipo ;
        
    END SP_cambiaValidacion ;
    
    
    /* trae valor planificado de los valores gasto fijo y gasto variable.*/
    FUNCTION F_TRAERVALORPLANIFICADO (
        P_IDINVERSION NUMBER,
        P_SELLOUT NUMBER DEFAULT NULL,
        P_DURACION NUMBER DEFAULT NULL,
        P_CRECIMIENTO NUMBER DEFAULT NULL,
        P_CODIGOGRUPO NUMBER DEFAULT NULL,
        P_TIPO VARCHAR2 DEFAULT 'V'
        ) RETURN NUMBER AS
    V_RETORNO NUMBER;
    
    v_totalMeta number;
        v_totalMetaGasto number;
        v_gasto number;
    
    
    BEGIN
        IF (P_TIPO='V') THEN
 
        BEGIN
			select sum(nvl(((sellout*p_duracion)*(1+nvl((selloutcrecimiento/100),0))),0))
            into v_totalMeta
            from data.vt_icom_inversion_cliente
            where idinversion IN (select I.id from data.t_icom_inversiones i where i.idpadre = P_IDINVERSION and I.estado=1)
            having sum(nvl(((sellout*p_duracion)*(1+nvl((selloutcrecimiento/100),0))),0))!=0
             ; 
		EXCEPTION WHEN NO_DATA_FOUND THEN
			 v_totalMeta:=0;
		END;
        if nvl(v_totalMeta,0) = 0 then 
            v_totalMeta := 1 ;
        end if;
        
        BEGIN            
            with datos as(
                SELECT
                row_number() over(order by idinversion) rn,
                meta,idinversion
                FROM(
                    SELECT sum(nvl(VALORMETA,0)) meta ,idinversion
                    FROM DATA.T_ICOM_INVERSION_GASTO
                    WHERE  GASTOTIPO = 'GASTO' AND TIPO='VARIABLE'
                    and idinversion IN (select I.id from data.t_icom_inversiones i where i.idpadre = P_IDINVERSION and I.estado=1)
                    group by idinversion
                    having sum(nvl(VALORMETA,0)) !=0
                ) 
            )
            select meta INTO v_totalMetaGasto
            from datos
            where rn =1;
        EXCEPTION WHEN NO_DATA_FOUND THEN
			 v_totalMetaGasto:=0;
		END;  
        
        if nvl(v_totalMetaGasto,0) = 0 then 
            v_totalMetaGasto := 0 ;
        end if;
        
        V_RETORNO := ((nvl(((p_sellout*p_duracion)*(1+nvl((p_crecimiento/100),0))),0))/v_totalMeta)*v_totalMetaGasto;
        
        ELSIF (P_TIPO='F') THEN
            with gastosfIJOS as(
                select ROW_NUMBER() OVER (ORDER BY idinversion) ID,idinversion,codigogrupo,sum(m.total)total,negociacion,estado   
                from data.t_icom_cliente_material m  
                where(m.negociacion = 1 and m.estado = 1  )
                and (M.idinversion IN (select I.id from data.t_icom_inversiones i 
                where i.idpadre = P_IDINVERSION and I.estado=1) )
                AND m.codigogrupo=P_CODIGOGRUPO
                group by idinversion, codigogrupo ,  negociacion,estado
                having sum(m.total)!=0
            )
            SELECT  NVL(SUM(total),0)VALORV INTO V_RETORNO
            FROM gastosfIJOS
            where id =1
            ;
        
        ELSIF (P_TIPO='O') THEN
            WITH gastosOtros AS ( 
                select 
                    ROW_NUMBER() OVER (ORDER BY g.idinversion) ID,
                    sum(gd.valor) total,
                    g.idinversion 
                from t_icom_inversion_gasto g 
                inner join t_icom_inversion_gastodistribucion gd on (g.IDINVERSION=gd.IDINVERSION and  g.IDGASTO=gd.IDGASTO)
                where g.TIPO='FIJO' and g.GASTOTIPO='GASTO' and g.CALCULADO=0 and  gd.CODIGOGRUPO=P_CODIGOGRUPO
                and g.idinversion IN (select I.id from data.t_icom_inversiones i where i.idpadre = P_IDINVERSION and I.estado=1) 
                GROUP BY g.idinversion
                HAVING sum(VALORINICIAL)!=0
            )
            SELECT  NVL(SUM(total),0)VALORV INTO V_RETORNO
            FROM gastosOtros
            where id =1            ;                             
           
        END IF;
        
        RETURN V_RETORNO;
        DBMS_OUTPUT.PUT_LINE(' EXITO V_RETORNO '||P_TIPO||':'||V_RETORNO );
   
    EXCEPTION WHEN OTHERS THEN 
        V_RETORNO :=0;
        RETURN V_RETORNO;
        DBMS_OUTPUT.PUT_LINE(' ERROR V_RETORNO :'||V_RETORNO );
    END F_TRAERVALORPLANIFICADO;    
    
    PROCEDURE SP_DISTRIBUCIONFACTURACONDESCUENTOAPROBADAS (P_IDINVERSION NUMBER DEFAULT NULL)AS 
        V_IDGASTO NUMBER;
        V_TABLASECUENCIA VARCHAR2(499);
        V_IDDETALLEGASTO NUMBER;
    BEGIN
    
        --- AGREGAR FECHA ACTIVIDAD
         V_TABLASECUENCIA :='DATA.T_ICOM_INVERSION_GASTODISTRIBUCION';
        /*recupera los datos de todas las faturas existentes */
        for gastos in(
            select
                ROW_NUMBER() OVER (ORDER BY ID ) rn,
                id IDINVERSION,
                'GASTO' GASTOTIPO,
                'AUTOMATICO' TIPO,
                null PERIODO,
                'DESCUENTO EN FACTURA' FUENTE,
                NULL VALOR,
                'DESCUENTO DIRECTO EN FACTURA: '|| lpad(COUNT(1),6,' ')||' FACTURAS' OBSERVACION,
                0 VALORPEQ,
                0 VALORMETA,
                SUM(TOTAL_DESCUENTO+TOTAL_DEVOLUCION)VALORREAL,
                0 CALCULADO,
                null CALCULO,
                null VALORPORCENTAJE
            from data.t_icom_inversiones i
            inner join data.VT_ICOM_DESCUENTOFACTURA f on i.id=IDINVERSION1
            where IDETAPA in (2,3,7,4) and estado=1 AND ESTADOCIERRE=0
            and (id= p_idinversion or p_idinversion is null)
            GROUP BY id
        )
        loop 
            /*se revisa que no exista un gasto ingresado para las faturas ingresadas, se revisa por IDINVERSION,GASTOTIPO,TIPO,FUENTE*/
            BEGIN        
                SELECT IDGASTO INTO V_IDGASTO FROM T_ICOM_INVERSION_GASTO WHERE IDINVERSION=gastos.IDINVERSION AND GASTOTIPO= gastos.GASTOTIPO AND TIPO=gastos.TIPO and FUENTE= gastos.FUENTE AND ROWNUM=1;
            EXCEPTION WHEN OTHERS THEN 
                V_IDGASTO :=NULL;             
            END;
            /*si no existe un gasto ingresado anteriormente se le inserta en la tabla T_ICOM_INVERSION_GASTO caso contrario se le actualiza el valor de numero de faturas y el valor a ser distrinuido.*/
            if (V_IDGASTO is null)then
                V_IDGASTO:=PK_COMMONS.F_SECUENCIA ('DATA.T_ICOM_INVERSION_GASTO');
                INSERT into T_ICOM_INVERSION_GASTO (        IDINVERSION,       GASTOTIPO,        TIPO,        PERIODO,        FUENTE,        VALOR,        OBSERVACION,        VALORMETA,        VALORPEQ,       VALORREAL,        CALCULADO,   IDGASTO)
                VALUES                             ( gastos.IDINVERSION,gastos.GASTOTIPO, gastos.TIPO, gastos.PERIODO, gastos.FUENTE, gastos.VALOR, gastos.OBSERVACION, gastos.VALORMETA, gastos.VALORPEQ,gastos.VALORREAL, gastos.CALCULADO, V_IDGASTO);
            else
                update T_ICOM_INVERSION_GASTO cli
                 SET
                    cli.OBSERVACION=gastos.OBSERVACION,
                    cli.VALORREAL=gastos.VALORREAL
                    where cli.IDGASTO=V_IDGASTO;
            end if;
           -- DBMS_OUTPUT.PUT_LINE(V_IDGASTO||'   IDINVERSION:'||gastos.IDINVERSION);
            
            /*se elimina el detalle de la distribucion para volver a ingresarlo*/
            if (V_IDGASTO is not null)then
                delete from T_ICOM_INVERSION_GASTODISTRIBUCION where IDGASTO=V_IDGASTO;
            end if;
    
            /*se ingresa los registros */
            V_IDDETALLEGASTO:=PK_COMMONS.F_SECUENCIA (V_TABLASECUENCIA);
    
    
    ------- VT_ICOM_DESCUENTOFACTURA --TRUNC(MIN(FAC_FECHA), 'MM'), LAST_DAY(MAX(FAC_FECHA), 'MM')  FECHADESDE -> FECAH DE ACTIVIDAD
            insert into T_ICOM_INVERSION_GASTODISTRIBUCION( ID,             IDINVERSION,    TIPO,               CODIGOGRUPO,        CODIGOCLIENTE,  CODIGOPRODUCTO, CODIGOBARRA,        DESCRIPCION,
                                                            COMPANIA,       VALORINICIAL,   VALORDISTRIBUCION,  PESODISTRIBUCION,   VALOR,          TABLAID,        TABLADESCRIPCION,
                                                            DOCUMENTOTIPO,  DOCUMENTO,      FECHA,              OBSERVACION,        ESELIMINAR,     IDGASTO, FECHA_ACTIVIDAD, FECHA_ACTIVIDAD_FIN)
                with detalle as (    
                    select
                        V_IDDETALLEGASTO ID,
                        I.ID IDINVERSION,
                        3 TIPO,
                        C.CODIGOGRUPO CODIGOGRUPO,
                        F.CODIGOCLIENTE CODIGOCLIENTE,
                        F.CODIGOPRODUCTO CODIGOPRODUCTO,
                        NULL CODIGOBARRA,
                        'GASTO EN CIERRE:Facturas con los descuentos aprobados' DESCRIPCION,
                        I.COMPANIA COMPANIA,
                        SUM(TOTAL_DESCUENTO+TOTAL_DEVOLUCION) VALORINICIAL,
                        gastos.VALORREAL VALORDISTRIBUCION,
                        (SUM(TOTAL_DESCUENTO+TOTAL_DEVOLUCION)/gastos.VALORREAL) *100 PESODISTRIBUCION,
                        SUM(TOTAL_DESCUENTO+TOTAL_DEVOLUCION) VALOR,
                        'T_ICOM_DESCUENTOFACTURA' TABLAID,
                        'GASTO EN CIERRE' TABLADESCRIPCION,
                        'FN' DOCUMENTOTIPO,
                        F.FACTURA DOCUMENTO,
                        SYSDATE FECHA, 
                        NULL OBSERVACION, 
                        0 ESELIMINAR,
                        V_IDGASTO IDGASTO,
                        TRUNC(MIN(f.FAC_FECHA), 'MM') FECHA_ACTIVIDAD,
                        LAST_DAY(MAX(FAC_FECHA)) FECHA_ACTIVIDAD_FIN
                    from data.t_icom_inversiones i
                    inner join data.VT_ICOM_DESCUENTOFACTURA f on i.id=IDINVERSION1
                    LEFT JOIN DATA.T_ICOM_INVERSION_CLIENTE C ON F.CODIGOCLIENTE=C.CODIGOCLIENTE  and c.idinversion=f.IDINVERSION1
                    where IDETAPA in (2,3,7,4) and estado=1 AND I.ID=gastos.IDINVERSION
                    GROUP BY I.ID,C.CODIGOGRUPO,F.CODIGOCLIENTE,F.CODIGOPRODUCTO,I.COMPANIA,F.FACTURA,gastos.VALORREAL
                )
                SELECT  
                    ID,             IDINVERSION,    TIPO,               CODIGOGRUPO,        CODIGOCLIENTE,  CODIGOPRODUCTO, CODIGOBARRA,        DESCRIPCION,
                    COMPANIA,       VALORINICIAL,   VALORDISTRIBUCION,  PESODISTRIBUCION,   VALOR,          TABLAID,        TABLADESCRIPCION,
                    DOCUMENTOTIPO,  DOCUMENTO,      FECHA,              OBSERVACION,        ESELIMINAR,     IDGASTO,        FECHA_ACTIVIDAD,     FECHA_ACTIVIDAD_FIN
                FROM detalle;
            COMMIT;    
        end loop;
        
     ---INGRESAR LAS VALIDACIONES DE FORMA AUTOMATICA 
           MERGE INTO DATA.T_ICOM_CLIENTE_VALIDACION v
            USING (select    I.id IDINVERSION, G.CODIGOGRUPO,I.COMPANIA, G.FECHAINICIO, G.FECHAFIN, 
            I.IDINVERSIONTIPO,   TRUNC(MIN(FAC_FECHA), 'MM') FECHADESDE, TRUNC(LAST_DAY(MAX(FAC_FECHA))) FECHAHASTA,
                SUM(TOTAL_DESCUENTO+TOTAL_DEVOLUCION) VALOR,  SUM(CANTIDAD) CANTIDAD,   SUM(PRECIO*CANTIDAD) VENTA, 
                to_char(FAC_FECHA, 'MM/YYYY') MES,  'VALIDACION AUTOMATICA: '||TRIM(G.NOMBRES)||' - '||to_char(FAC_FECHA, 'MM/YYYY') NOMBREAGRUPACION, 
                4 idvalidaciontipo, 2 idformapago, 1 ESTADO, 0 IDAGRUPACION, 'ICOM' USUARIOCREACION
            from data.t_icom_inversiones i
            INNER JOIN t_icom_inversion_cliente_g G ON (I.ID=G.IDINVERSION)
            INNER JOIN t_icom_inversion_cliente C ON (G.IDINVERSION=C.IDINVERSION AND G.CODIGOGRUPO=C.CODIGOGRUPO)
            inner join data.VT_ICOM_DESCUENTOFACTURA f on (i.id=IDINVERSION1 AND C.CODIGOCLIENTE=F.CODIGOCLIENTE)
            where I.IDETAPA in (2,3,7,4) and I.estado=1 AND I.ESTADOCIERRE=0 AND I.IDPADRE IS NULL   -- and (id= p_idinversion or p_idinversion is null)                   
            GROUP BY  I.id, G.CODIGOGRUPO, G.NOMBRES, I.COMPANIA, G.FECHAINICIO, G.FECHAFIN, I.IDINVERSIONTIPO, to_char(FAC_FECHA, 'MM/YYYY')
            ) i
            ON ( v.idinversion = i.idinversion and v.codigogrupo = i.codigogrupo and v.idvalidaciontipo =I.idvalidaciontipo
                AND val_fechainicio = I.FECHADESDE AND val_fechafin = I.FECHAHASTA
                and v.idformapago = i.idformapago and v.compania = i.compania AND v.estado=I.ESTADO AND V.idagrupacion=I.idagrupacion
                AND V.USUARIOCREACION=I.USUARIOCREACION)
            WHEN MATCHED THEN
                UPDATE SET 
                        tot_venta = I.VENTA,tot_valorcliente= I.VALOR, tot_valorzaimella= I.VALOR, tot_valorexcepcion = 0,
                        tot_valor = I.VENTA, tot_cantidad = I.CANTIDAD, TOT_VENTAUND=I.CANTIDAD
            WHEN NOT MATCHED THEN    
                INSERT (ID, IDINVERSION, IDINVERSIONTIPO, CODIGOGRUPO, 
                IDVALIDACIONTIPO, IDFORMAPAGO, FECHAINICIO, FECHAFIN,val_fechainicio,val_fechafin, ESTADO, IDAGRUPACION, COMPANIA,
                FECHACREACION, USUARIOCREACION,nombreagrupacion, 
                tot_venta, tot_valorcliente,tot_valorzaimella,tot_valorexcepcion,tot_valor,tot_cantidad,TOT_VENTAUND  )
                VALUES (data.PK_COMMONS.F_SECUENCIA ('T_ICOM_CLIENTE_VALIDACION'), i.IDINVERSION, i.idinversiontipo, i.codigogrupo, 
                i.idvalidaciontipo, i.idformapago, i.fechainicio, i.fechafin,I.FECHADESDE, I.FECHAHASTA, 1, 0, i.compania,
                sysdate, 'ICOM', I.NOMBREAGRUPACION,
                 I.VENTA,I.VALOR,  I.VALOR,  0, I.VENTA, I.CANTIDAD, I.CANTIDAD) ; 
        
    EXCEPTION WHEN OTHERS THEN 
        ROLLBACK;
    END SP_DISTRIBUCIONFACTURACONDESCUENTOAPROBADAS;
    
    /* valida informacion el excel para distribuir las notas de credito*/
    PROCEDURE SP_VALIDACION_SUBIR_EXCEL_NC (p_idagrupacion NUMBER,p_mensaje OUT varchar2) AS
        v_codigogrupo varchar2(250);
        V_tot_valorzaimella NUMBER;
        V_ach_valorzaimella NUMBER;
        V_validacion01 NUMBER;
        V_validacion02 NUMBER;
        v_compania varchar2(5);
        v_cont NUMBER;
    BEGIN
    
        --obtengo el valor total a pagar
        select SUM(ROUND(a.tot_valorzaimella+nvl(TOT_VALOREXCEPCION,0),2) ) tot_valorzaimella, codigogrupo,compania
        INTO V_tot_valorzaimella,v_codigogrupo,v_compania
        from t_icom_cliente_validacion a    
        where 1=1
        and a.idagrupacion = p_idagrupacion 
        group by codigogrupo, compania;        
        
        --transformo los valores del archivo del excel 
        update vt_apex_excel set 
            c11 = p_idagrupacion  ,C03 = round(pk_commons.safe_to_number(C03),4) 
            ,c12=V_tot_valorzaimella ,c14 = v_codigogrupo 
            WHERE C02 IS NOT NULL AND  C03 IS NOT NULL ;
       
       --valida que el codigo del cliente sea correcto      
        select max(c01) into v_validacion01 from 
        vt_apex_excel where trim(C02) IS NOT NULL 
        and not exists (  SELECT 1 FROM  vt_gzm_cliente where codigogrupo =v_codigogrupo and codigocliente=TRIM(c02));

        if (v_validacion01!=0)then
            p_mensaje:='<li>Codigo de cliente no corresponde al de la validacion, en la linea: '||v_validacion01||'</li>';
        end if;
        
        --valida que el total de los valores del excel sean igual al total a pagar         
        select round(sum(nvl(c03,0)),2) into V_ach_valorzaimella from vt_apex_excel ;

        if ((V_tot_valorzaimella-V_ach_valorzaimella)!=0)then
            p_mensaje:=p_mensaje||'<li>La suma de valores del archivo: '||ROUND(V_ach_valorzaimella,2)||
            ' es diferente del valor zaimella: '||ROUND(V_tot_valorzaimella,2)||'</li>';
        end if;

        ---Si hay errores retorna para mostrar los mensajes
        IF(p_mensaje IS NOT NULL)THEN 
            RETURN;
        END IF;        
        
        delete T_ICOM_CLIENTE_VALIDACION_NC where IDAGRUPACION=p_idagrupacion;
        delete T_ICOM_CLIENTE_VALIDACION_NCDET where IDAGRUPACION=p_idagrupacion;       
            
        update vt_apex_excel set c13 = (c03/c12) ;
        
        INSERT INTO T_ICOM_CLIENTE_VALIDACION_NC(IDAGRUPACION,CODIGOGRUPO,CODIGOCLIENTE,NUMERO_NCS,VALOR,PORCENTAJE,NUMERO_FACTURA,OBSERVACION)
        SELECT C11,c14,C02,ID-1 ID,C03,C13,C04,C05 FROM vt_apex_excel
        WHERE C02 IS NOT NULL AND  C03 IS NOT NULL ;
        
  
        INSERT INTO T_ICOM_CLIENTE_VALIDACION_NCDET(IDCLIENTEVALIDANC,IDAGRUPACION,IDINVERSION,CODIGOPRODUCTO,
        NUMERO_NC,VALORZAMELADISTR,valor)
            SELECT N.ID,C.IDAGRUPACION,C.IDINVERSION,D.CODIGOPRODUCTO,N.NUMERO_NCS,D.VALORZAIMELLA+nvl(VALOREXCEPCION,0), (D.VALORZAIMELLA+nvl(VALOREXCEPCION,0))*PORCENTAJE VALORZM_NCM
            FROM t_icom_cliente_validacion C 
            INNER JOIN t_icom_cliente_validacion_det D ON C.ID=D.IDVALIDACION
            INNER JOIN T_ICOM_CLIENTE_VALIDACION_NC N ON N.CODIGOGRUPO=C.CODIGOGRUPO AND  N.IDAGRUPACION=C.IDAGRUPACION
            WHERE C.IDAGRUPACION=p_idagrupacion
            AND N.ESTADO=9 and nvl(D.VALORZAIMELLA,0)>0
            ORDER BY N.ID,IDAGRUPACION, IDINVERSION;
        
    END SP_VALIDACION_SUBIR_EXCEL_NC;
    

    /*Genera por cada factura validada una NC*/
    PROCEDURE SP_VALIDACION_CONTRAFACTURA (p_idagrupacion NUMBER,p_mensaje OUT varchar2) AS
        v_cont number;
        V_COMPANIA	varchar2(5);
    begin
    
            delete from T_ICOM_CLIENTE_VALIDACION_NC where IDAGRUPACION= p_idagrupacion ;
            delete from T_ICOM_CLIENTE_VALIDACION_NCDET where IDAGRUPACION= p_idagrupacion;
            /*OBTENER LA COMPANIA DE LA INVERSION*/
            select  max(compania) into  v_compania from data.t_icom_cliente_validacion where IDAGRUPACION =p_idagrupacion and rownum=1;
            
            INSERT INTO T_ICOM_CLIENTE_VALIDACION_NC(IDAGRUPACION,CODIGOGRUPO,CODIGOCLIENTE,NUMERO_NCS,VALOR,PORCENTAJE,NUMERO_FACTURA,OBSERVACION)
                SELECT 
                    IDAGRUPACION, CODIGOGRUPO, CODIGOCLIENTE,ROW_NUMBER() OVER ( ORDER BY  CODIGOGRUPO, CODIGOCLIENTE,NUMERO_FACTURA  ) NUMERO_NCS, valorzaimella VALOR,
                    round(valorzaimella/sum(valorzaimella) over(),5) PORCENTAJE,NUMERO_FACTURA, OBSERVACION 
                FROM(
                    SELECT 
                        c.IDAGRUPACION,d.CODIGOGRUPO,d.CODIGOCLIENTE,
                        SUM(d.valorzaimella) valorzaimella,
                        d.FACTURA NUMERO_FACTURA,' 'OBSERVACION
                    from t_icom_cliente_validacion c
                    inner join t_icom_cliente_validacion_det d on c.id= d.idvalidacion
                    WHERE 1=1
                    and IDAGRUPACION =p_idagrupacion
                    GROUP BY  c.IDAGRUPACION , d.FACTURA , d.CODIGOCLIENTE, d.CODIGOGRUPO
                    
                );

            commit;
            INSERT INTO T_ICOM_CLIENTE_VALIDACION_NCDET(IDCLIENTEVALIDANC,IDAGRUPACION,IDINVERSION,CODIGOPRODUCTO,NUMERO_NC,VALORZAMELADISTR,valor)
                SELECT N.ID,C.IDAGRUPACION,C.IDINVERSION,D.CODIGOPRODUCTO,N.NUMERO_NCS, sum (VALORZAIMELLA)over(partition by  n.NUMERO_FACTURA) VALORZAIMELLA,   VALORZAIMELLA VALORZM_NCM
                FROM t_icom_cliente_validacion C 
                INNER JOIN t_icom_cliente_validacion_det D ON C.ID=D.IDVALIDACION
                INNER JOIN T_ICOM_CLIENTE_VALIDACION_NC N ON N.CODIGOGRUPO=C.CODIGOGRUPO AND  N.IDAGRUPACION=C.IDAGRUPACION and d.FACTURA= n.NUMERO_FACTURA
                WHERE C.IDAGRUPACION=p_idagrupacion
                AND N.ESTADO=9
                ORDER BY N.ID,IDAGRUPACION, IDINVERSION;    
      
    end SP_VALIDACION_CONTRAFACTURA;
    
    /*
    *** PK_ICOM_VALIDACION.sp_validacion_a_notascredito(P_IDAGRUPACION=>111,P_RUTA=>0);
    
    */
    procedure sp_validacion_a_notascredito(P_IDAGRUPACION NUMBER,P_COMPANIA varchar2 default '00001', P_RUTA NUMBER DEFAULT 1) as
        v_comentario    varchar2(250);
        v_usuario       varchar2(50);
        v_modulo        varchar2(50):='BACK';
        V_LOTE          NUMBER:=484;
        v_exito 		number;
        v_id_error 		varchar(500);
        v_id_exito 		varchar(500);
        v_usrkam		varchar2(25);
        v_usrger		varchar2(25);
        v_usrfin		varchar2(25);
        v_app_objeto    VARCHAR2(50):='GENERACION_NOTA_CREDITO';    
    BEGIN
        /*se recupera el lote siempre y cuando ya se haya proesado antes el id de agrupacion*/
        BEGIN
            SELECT max(LOTENC) INTO V_LOTE FROM T_ICOM_CLIENTE_VALIDACION_NC WHERE IDAGRUPACION =P_IDAGRUPACION;
        EXCEPTION WHEN OTHERS THEN            
            V_LOTE:=null;
        END;
        ---REINICIO VALORES DE NOTA DE CREDITO 
        UPDATE t_icom_cliente_validacion_nc SET ESTADO=9, DOCUMENTOTIPO=NULL, DOCUMENTONUMERO=NULL
        where idagrupacion=P_IDAGRUPACION;
        
        /*se recupera el secuencial de lote en caso de que no se haya procesado con anterioridad*/
        if (nvl(V_LOTE,0) =0)then V_LOTE:=pk_commons.f_secuencia('T_BACK_NOTASDECREDITO_LOTE'); end if;
        
        DBMS_OUTPUT.PUT_LINE('V_LOTE:'||V_LOTE);
        
        /*se actualiza el lote en los datos de la cabecera de las notas de crÃƒÂ©dito*/
        UPDATE T_ICOM_CLIENTE_VALIDACION_NC SET LOTENC = V_LOTE WHERE IDAGRUPACION =P_IDAGRUPACION;
        
        DELETE t_back_notasdecredito WHERE LOTE=V_LOTE;
        DELETE FILES.T_APEX_ARCHIVOS  WHERE  TABLA= 'T_BACK_NOTASDECREDITO' AND ID_TABLA = V_LOTE;   
        
        /*se inserta la data de las notas de credito apartir de la data de la distrinuion de las notas de credito, se lo acumula por los ACAS  {MARCA,CLIENTE,LINEA,CANAL}*/
        INSERT INTO t_back_notasdecredito(IDPROMOCION,AREA,TIPONOTACREDITO,MERCADO,MARCA,VALORMARCA,CLIENTE,
        CODIGOCLIENTE,LINEA,CODIGOLINEA,CANAL,CODIGOCANAL,ESTADO,VALOR,CUENTACONTABLE,OBSERVACION,
        FECHACREA,USERCRE,COMPANIA,CODIGOAUXILIAR,LOTE,MOTIVO,GENERACION,NUMERNC,AGRUPADOR)
            WITH DATOS AS (
               SELECT 
                     cas.IDAGRUPACION,cas.idinversion IDPROMOCION
                    ,case WHEN CODIGOORIGEN='EXT' THEN 'ARE3' ELSE  are.AREA_NC END    AREA
                    ,case WHEN CODIGOORIGEN='EXT' THEN 'TNC2' ELSE  PK_ICOM_VALIDACION.F_TRAER_TIPONOTACREDITO(
                        ARE.AREA_NC,CAS.idvalidaciontipo,INV.IDINVERSIONTIPO,
                        CAS.marca,CAS.linea,P_COMPANIA
                    ) END  TIPONOTACREDITO, case WHEN CODIGOORIGEN='EXT' THEN 'MER3' ELSE  'MER1' END  MERCADO
                    ,'4' MARCA,cas.MARCA VALORMARCA ,'C' CLIENTE ,cas.CLIENTE CODIGOCLIENTE
                    ,'7' LINEA,cas.LINEA CODIGOLINEA ,'4' CANAL ,cas.CANAL CODIGOCANAL
                    ,'I' ESTADO ,cas.VALOR_REAL VALOR ,NULL CUENTACONTABLE,'OB2' OBSERVACION
                    ,SYSDATE FECHACREA ,'ICOM' USERCRE,'00001' COMPANIA,NULL CODIGOAUXILIAR
                    ,V_LOTE  LOTE,SUBSTR(CAS.NOMBRE, 1,49) MOTIVO,'C' GENERACION,CAS.NUMERO_NCS NUMERNC            
                FROM VT_ICOM_VALIDACION_ACAS cas
                left join t_icom_inversiones inv on cas.idinversion= inv.id
                left join vt_icom_area are on inv.IDAREA=are.IDAREA
                left join vt_icom_inversiontipo tip on inv.IDINVERSIONTIPO=tip.IDINVERSIONTIPO 
                WHERE IDAGRUPACION=  P_IDAGRUPACION )
            SELECT IDPROMOCION, AREA, TIPONOTACREDITO, MERCADO, MARCA, VALORMARCA, CLIENTE, CODIGOCLIENTE, LINEA, CODIGOLINEA, CANAL, CODIGOCANAL, ESTADO, SUM(VALOR)VALOR, CUENTACONTABLE, OBSERVACION, FECHACREA, 
            USERCRE, COMPANIA, CODIGOAUXILIAR, LOTE, MOTIVO, GENERACION, NUMERNC, NUMERNC
            FROM DATOS
            GROUP BY IDPROMOCION, AREA, TIPONOTACREDITO, MERCADO, MARCA, VALORMARCA, CLIENTE, CODIGOCLIENTE, LINEA, CODIGOLINEA, CANAL, CODIGOCANAL, ESTADO, CUENTACONTABLE, OBSERVACION, FECHACREA, USERCRE, COMPANIA, CODIGOAUXILIAR, LOTE, MOTIVO, GENERACION, NUMERNC
            ;
            
             DELETE t_back_notasdecredito WHERE LOTE=V_LOTE AND  VALOR=0;
            
        SELECT max(NOMBRE) into v_comentario FROM VT_ICOM_VALIDACION_ACAS where  IDAGRUPACION= P_IDAGRUPACION  ;

        dbms_output.put_line( 'SP_CUENTACONTABLE ' ); 
        PK_BACK_NOTADECREDITO.SP_CUENTACONTABLE(V_LOTE,'I',P_COMPANIA);
        
        SELECT COUNT(1)INTO v_exito FROM  t_back_notasdecredito WHERE LOTE=V_LOTE AND  
        CUENTACONTABLE IS NULL ;
        
        IF (v_exito >0) THEN 
             RAISE_APPLICATION_ERROR(-20100,'No se generaron las cuentas contables');
        END IF;
        --se envia a flujo
              
            /*se recupera el usuario iniciador del flujo*/
            v_usuario:=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '30',P_COMPANIA ); 
    
            /*se se reuepra los datos para el envio a flujo para la aprobacion*/
            
            dbms_output.put_line( 'Enviar  a ruta ' ); 
            FOR NOTA IN ( 
                with validanc as(
                SELECT distinct idagrupacion, LOTENC,codigogrupo,codigocliente,estado 
                FROM T_ICOM_CLIENTE_VALIDACION_NC where estado =9)
                SELECT 
                    n.LOTE,max(v.codigocliente) codigocliente, codigogrupo,ROUND(SUM(n.VALOR),4) VALOR
                FROM  validanc v
                inner join t_back_notasdecredito n on (v.LOTENC=n.lote and v.codigocliente=n.codigocliente and n.ESTADO = 'I' AND LOTE = V_LOTE)
                inner join T_CORP_UDC u on (n.MERCADO = u.ID_TABLA AND (u.ID_CABECERA = 'VARIOSNC' AND TRIM(u.DESCRIPCION2) = 'MERCADO') and codigocompania=P_COMPANIA )            
                group by n.LOTE,v.codigogrupo
            ) loop
                    
                    dbms_output.put_line('Enviar  a ruta cliente: '||NOTA.codigocliente); 
                    --- busco usuario para ruta de aprobacion 
                    select max(id_tabla) into v_usrger from t_corp_udc
                        where id_cabecera = 'BACK_RTNCS' 
                       and (valor = to_char(nota.codigocliente) or valor = to_char(nota.codigogrupo))
                        --and to_char(valor) = to_char(nota.codigocliente) 
                        and rownum = 1;
                        
                    if (v_usrger is null) then 
                        select b.nombreusuario usrkam,c.nombreusuario usrger into v_usrkam,v_usrger
                        from vt_jde_cliente a
                        inner join vt_corp_usuario b on codigoejecutivo = coderp
                        inner join vt_corp_usuario c on dp.f_cedula_supervisor(a.ejecutivo) = c.numeroidentificacion
                        where a.codigo = nota.codigocliente and rownum = 1;
                    end if;
                 
                    DBMS_OUTPUT.PUT_LINE('nota.codigocliente: '||nota.codigocliente|| ' usuario fin: '||v_usrger);
                    IF(P_RUTA=1) THEN 
                        pk_corp_flujoaprobacion.sp_flujoenviar(
                            p_id 					=> NOTA.LOTE
                            , p_objeto				=> v_app_objeto
                            , p_objetodescripcion	=> 'NOTA(s) DE CREDITO AUTOMATICA(s)'
                            , p_usuario				=> v_usuario
                            , p_modulo				=> v_modulo
                            , P_COMPANIA			=> P_COMPANIA
                            , p_comentario			=> v_comentario||'<p> Valor NC $ '||NOTA.VALOR
                            , p_codigopagina		=> 'BACK210'
                            , p_tipo1				=> 'NOTA_CREDITO'
                            , p_tipo2				=> 'BACK'
                            , p_tipo3				=> v_usrger
                            , p_exito				=> v_exito
                        );
                   ELSE 
                        v_exito:=1;
                   END IF;
                    DBMS_OUTPUT.PUT_LINE('v_exito: '||v_exito||' G_MENSAJE: '||pk_corp_flujoaprobacion.G_MENSAJE);
                    
                    if v_exito = 1 then
                        v_id_exito := v_id_exito;
                        -- se envÃƒÂ­a a flujo de aprobacion 
                        -- 1. se actualiza el estado de I=ingresada a R=En Ruta de Aprobacion
                        update t_back_notasdecredito SET ESTADO = 'R' WHERE ESTADO = 'I' AND LOTE = NOTA.LOTE;
                        update T_ICOM_CLIENTE_VALIDACION_NC SET ESTADO = 8 WHERE ESTADO = 9 AND LOTENC = NOTA.LOTE; 
                        
                        --- PASO LOS ADJUNTOS DE VALIDACION A NOTA CREDITO 
                        INSERT INTO FILES.T_APEX_ARCHIVOS (NUMEROARCHIVO, FILENAME, BLOBCONTENT, MIMETYPE, FECHA, NOMBREUSUARIO, TIPO, ESTADO, TABLA, ID_TABLA)
                        SELECT    PK_COMMONS.F_SECUENCIA ('T_APEX_ARCHIVOS') , FILENAME, BLOBCONTENT, MIMETYPE,
                        FECHA, NOMBREUSUARIO USUARIO, TIPO , NVL(ESTADO,0) ESTADO  ,
                        'T_BACK_NOTASDECREDITO' TABLA , V_LOTE ID_TABLA 
                        FROM FILES.T_APEX_ARCHIVOS 
                        WHERE  TABLA= 'T_ICOM_CLIENTE_VALIDACION'
                        AND ID_TABLA = P_IDAGRUPACION;            
                    else
                        RAISE_APPLICATION_ERROR(-20100,'Error al enviar a ruta las NC: '||pk_corp_flujoaprobacion.G_MENSAJE);
                    end if;
                    
                end loop;
                            
    END sp_validacion_a_notascredito;
    
    
    FUNCTION F_TRAER_TIPONOTACREDITO(
        p_AREA_NC VARCHAR2,
        p_idvalidaciontipo VARCHAR2 default null,
        P_IDINVERSIONTIPO VARCHAR2 default null,
        p_aca_marca VARCHAR2 default null,
        p_aca_linea VARCHAR2 default null,
        P_COMPANIA VARCHAR2 DEFAULT '00001'
    ) RETURN VARCHAR2 AS
        v_retorno VARCHAR2(20);
    begin
    
         DBMS_OUTPUT.PUT_LINE('p_AREA_NC: '||p_AREA_NC||' p_idvalidaciontipo: '||p_idvalidaciontipo
         ||'P_IDINVERSIONTIPO: '||P_IDINVERSIONTIPO||' p_aca_marca: '||p_aca_marca||' p_aca_linea: '||p_aca_linea
         ||'P_COMPANIA: '||P_COMPANIA);
         
        --AREA DE MERCADEO  
        if (p_AREA_NC='ARE1')THEN 
            SELECT 
                MAX(CASE WHEN P_IDVALIDACIONTIPO = ARE1.TIP_VALIDA THEN ARE1.TIPO_NC_1 ELSE  ARE1.TIP0_NC_2  END )TIPO_NC
            INTO V_RETORNO  
            FROM  VT_ICOM_ACANC_AREA1 ARE1 
            WHERE 1=1
            AND ARE1.MARCA=P_ACA_MARCA
            AND ARE1.LINEA=P_ACA_LINEA
            AND ARE1.COMPANIA=P_COMPANIA 
            AND ARE1.ACTIVO='1' 
            ;
        END iF;
        
        ---AREA DE VENTAS
        if (p_AREA_NC='ARE2')THEN 
        
            v_retorno := 
            CASE WHEN P_IDVALIDACIONTIPO=1 THEN 'TNC18'
            
            ELSE 
                    CASE WHEN P_IDINVERSIONTIPO=2 THEN 'TNC3'
                    WHEN P_IDINVERSIONTIPO=1 THEN 'TNC2'
                    WHEN P_IDINVERSIONTIPO=4 THEN 'TNC1'
                    WHEN P_IDINVERSIONTIPO=5 THEN 'TNC4'
                    ELSE NULL END
           
            END;
            IF (V_RETORNO IS NULL)THEN
                RAISE_APPLICATION_ERROR(-20100,'Error al recuperar tipo de notas de crÃƒÂ©dito');
            END IF;
        END iF;
        
        DBMS_OUTPUT.PUT_LINE('v_retorno: '||v_retorno);
        
        RETURN v_retorno;
        
    end F_TRAER_TIPONOTACREDITO;
    
    /* Se rechaza la nota de credito, por lo cual tienen que volver a validar
    PK_ICOM_VALIDACION.SP_RECHAZA_NC();
    */
      procedure SP_RECHAZA_NC(P_LOTE NUMBER) AS
    v_contador number;
    BEGIN 
        
        select max(idagrupacion) into v_contador from T_ICOM_CLIENTE_VALIDACION_NC where LOTENC = P_LOTE;
        
        update t_icom_cliente_validacion  set estado=2 where idagrupacion=v_contador; 
        update T_ICOM_CLIENTE_VALIDACION_NC SET ESTADO = 7 WHERE estado=8 and LOTENC = P_LOTE;
        
          ---si la inversion paso a cierre debe regresar a validacion 
        update t_icom_inversiones set idetapa=7 where idetapa=4 AND id IN (
         SELECT DISTINCT IDINVERSION FROM t_icom_cliente_validacion where idagrupacion=v_contador );
         
    END SP_RECHAZA_NC;
    
END PK_ICOM_VALIDACION ;
/
/

