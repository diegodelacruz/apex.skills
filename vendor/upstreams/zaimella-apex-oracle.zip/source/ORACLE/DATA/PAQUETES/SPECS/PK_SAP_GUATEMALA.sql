CREATE OR REPLACE EDITIONABLE PACKAGE PK_SAP_GUATEMALA AS

  --
  -- Consulta los clientes de SAP Guatemala para la carga corporativa de maestros.
  -- Retorna el contrato T_GZM_CLIENTE_GTM_TAB consumido por PK_TRAD_MULTICOMPANIA.
  --
  FUNCTION FN_GET_CLIENTES_GTM_P
    RETURN T_GZM_CLIENTE_GTM_TAB PIPELINED;

  --
  -- Consulta los productos de SAP Guatemala para la carga corporativa de maestros.
  -- Retorna el contrato T_GZM_PRODUCTO_GTM_TAB consumido por SP_CARGA_ERPGUATEMALA.
  --
  FUNCTION FN_GET_PRODUCTOS_GTM_P
    RETURN T_GZM_PRODUCTO_GTM_TAB PIPELINED;

END PK_SAP_GUATEMALA;
/
