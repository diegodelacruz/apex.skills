﻿prompt Esquema DATA para codigo PL/SQL
alter session set current_schema=DATA;

prompt PROD PACKAGE DATA.PK_ICOM_PROCESOSTAREAS

  CREATE OR REPLACE EDITIONABLE PACKAGE PK_ICOM_PROCESOSTAREAS as
 
	/* Paquete que contiene la logica de los procesos operativos aplicaciÃ³n APEX 137 (INVERSIONES COMERCIALES).
		@author jasanza/NETBY
		@fecha 05/2023 
	*/
    G_MODULO VARCHAR(4):='ICOM';
    
    PROCEDURE SP_EJECUTAR_TAREA(P_PROCESO NUMBER);
    
    PROCEDURE SP_tareaCodigoPromocional ;
    
    PROCEDURE SP_tareaDisenoArte ;
    
    PROCEDURE SP_tareaReferenciaCruzada;
  
    PROCEDURE SP_tareaCodificacionProducto ;    
    
     PROCEDURE SP_tareaPalnificacionProducto ;   
      
    PROCEDURE SP_TareaCompraMaterialPop;
    
    PROCEDURE SP_ActualizarPDV(P_ID NUMBER);
    
    procedure sp_ejecutarAnalisis(p_id number);
    
    PROCEDURE SP_EJECUTAR_TAREAMANUAL(P_TAREA VARCHAR2);
   
END PK_ICOM_PROCESOSTAREAS;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "DATA"."PK_ICOM_PROCESOSTAREAS" AS  
    /*PK_ICOM_PROCESOSTAREAS.SP_EJECUTAR_TAREA*/
    PROCEDURE SP_EJECUTAR_TAREA(P_PROCESO NUMBER)  
    AS 
    V_PROCESO VARCHAR(500);
    BEGIN
      
        FOR T IN (select * from VT_ICOM_PROCESO where
            (IDPROCESO=P_PROCESO or (P_PROCESO is null and TAREA is not null) )) LOOP

            BEGIN
                dbms_output.put_line( 'INICIA TAREA: '||T.TAREA);
                execute immediate 'BEGIN '||T.TAREA||' END;';
            EXCEPTION WHEN OTHERS THEN 
                dbms_output.put_line('Error en ejecuciÃ³n. SQLERRM: '||SQLERRM||' TRACE: '||DBMS_UTILITY.format_error_backtrace);
            END;
        END LOOP;
        
        IF(P_PROCESO IS NULL) THEN
                EXECUTE IMMEDIATE 'ALTER SESSION SET NLS_TERRITORY = ''ECUADOR''';
            --SE EJECUTA SI Y SOLO SI ES LUNES
                IF((TO_CHAR(trunc(SYSDATE), 'D'))=1) THEN 
                dbms_output.put_line( 'Inicia PROCESO: SP_NOTIFICACION_KAM_PROMOCIONES_POP');
                PK_ICOM_NEGOCIACION.SP_NOTIFICACION_KAM_PROMOCIONES_POP();
                
                  dbms_output.put_line( 'Inicia PROCESO: sp_icom_notificacionestemporalidad'); 
                PK_ICOM_PROCESOS.sp_icom_notificacionestemporalidad();
           
            END IF;
             dbms_output.put_line( 'Inicia PROCESO: SP_ActualizarTodosProductos'); 
              PK_ICOM_COMMONS.SP_ActualizarTodosProductos() ;
            
               dbms_output.put_line( 'Inicia PROCESO: sp_icom_notificacionestemporalidadEscalable'); 
                PK_ICOM_PROCESOS.sp_icom_notificacionestemporalidadEscalable(); 
                
            dbms_output.put_line( 'Inicia PROCESO: SP_CAMBIO_ETAPA');    
            PK_ICOM_COMMONS.SP_CAMBIO_ETAPA();
            
            dbms_output.put_line( 'Inicia PROCESO: SP_actualizaAnalista'); 
            PK_ICOM_COMMONS.SP_actualizaAnalista();
            
            dbms_output.put_line( 'Inicia PROCESO: SP_TareaCompraMaterialPop'); 
            PK_ICOM_PROCESOSTAREAS.SP_TareaCompraMaterialPop();
            
          
            --- PROCESOS DEL GASTO DE DISTRIBUCION 
            dbms_output.put_line( 'Inicia PROCESO: SP_DISTRIBUCIONNOTASDECREDITOAPROBADAS'); 
            PK_ICOM_CIERRE.SP_DISTRIBUCIONNOTASDECREDITOAPROBADAS ();
            
            dbms_output.put_line( 'Inicia PROCESO: SP_DISTRIBUCIONFACTURACONDESCUENTOAPROBADAS');    
            PK_ICOM_VALIDACION.SP_DISTRIBUCIONFACTURACONDESCUENTOAPROBADAS();
            
            dbms_output.put_line( 'Inicia PROCESO: SP_DISTRIBUCIONORENDESCOMPRARECIBIDAS');    
            PK_ICOM_CIERRE.SP_DISTRIBUCIONORENDESCOMPRARECIBIDAS();
            
            dbms_output.put_line( 'Inicia PROCESO: SP_DISTRIBUCIONAUTOCONSUMOSREGALO');    
             PK_ICOM_CIERRE.SP_DISTRIBUCIONAUTOCONSUMOSREGALO(); 
             
             dbms_output.put_line( 'Inicia PROCESO: SP_DISTRIBUCIONAUTOCONSUMOSMUESTRAS');    
             PK_ICOM_CIERRE.SP_DISTRIBUCIONAUTOCONSUMOSMUESTRAS();
            
            
            
            delete  T_ICOM_INVERSION_GASTOdistribucion b
            where exists (
            SELECT 1 FROM T_ICOM_INVERSION_GASTO a WHERE TIPO='AUTOMATICO' AND FUENTE='NOTAS DE CREDITO' AND 
            exists (select 1 from data.t_icom_inversiones i where fechaFin<='31/12/2025' 
            and i.estado=1 and i.idetapa=4 and i.id=a.IDINVERSION  and a.IDINVERSION=b.IDINVERSION and  a.IDGASTO=b.IDGASTO)
            )
            ;
            
            
            delete T_ICOM_INVERSION_GASTO WHERE TIPO='AUTOMATICO' AND FUENTE='NOTAS DE CREDITO' AND 
            exists (select * from data.t_icom_inversiones where fechaFin<='31/12/2025' 
            and estado=1 and idetapa=4 and id=IDINVERSION)
            ;
            
        END IF;

    END SP_EJECUTAR_TAREA;
    
    /*Procedimiento para obtener los procesos operativos de codigo promocional*/
    PROCEDURE SP_tareaCodigoPromocional AS
        V_OBJETO_DES			clob;
        v_asunto                 VARCHAR2(100);
        v_correo_notificacion	varchar2(200);
        v_nombres   varchar2(500);
        v_cuenta number;
        v_mailejecutivo varchar2(3999);
        v_coordinador varchar2(3999);
        v_objeto_des_ejecutivo			clob;
        v_objeto_ejecutivo_det			clob;
        v_produccion number;
   BEGIN
     
        v_produccion := case when PK_CORP_COMMONS.F_ISPRODUCCION then 1 else 0 end; 
        dbms_output.put_line( 'Inicia Notificacion Codigo Promocional Pendiente');
        for usu in ( select distinct UPPER(TRIM(p.usuario)) USUARIO,idinversion from data.vt_icom_procesoCodigoPromo  p
                     where p.porcentaje < 100 
                     and not EXISTS ( select 1 from data.vt_gzm_producto v where v.codigoproducto = p.codigoproducto  ) )
        loop
            --se debe mandar un correo a cada usuario
            --busco el correo al que se debe notificar 
            select email, nombres||' '||apellidos INTO v_correo_notificacion, v_nombres
            from data.vt_corp_usuario where nombreusuario = usu.usuario ;
            --Se envia la notificaciÃ³n 
            v_asunto := 'Codigo Promocional Pendiente';
  
            V_OBJETO_DES := '<p>&nbsp;</p>
                          <p>Estimado Usuario</p>
                          <p>&nbsp;</p>
                          <p>'||v_nombres||'</p>
                          <p>&nbsp;</p>
                          <p>Tiene pendiente la creaciÃ³n de cÃ³digo/s promocional/es: </p> <p>&nbsp;</p>' ;
            
            --cabecera de la tabla
            V_OBJETO_DES := V_OBJETO_DES || '<table border=''1'' style=''width:100%; padding:0px; border-spacing:0px;''>';
            V_OBJETO_DES := V_OBJETO_DES || ' <tr BGCOLOR=''lightgrey''>  ';
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''15%''><strong>ID INVERSION</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''20%''><strong>CODIGO BORRADOR</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''35%''><strong>NOMBRE BORRADOR</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''15%''><strong>FECHA INICIO</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''15%''><strong>FECHA FIN</strong></th></tr>';

            for inv in ( select p.descripcion, p.idinversion, p.inversion, p.fec_InicioInv fechainicio, p.fec_FinInv fechafin, 
                           listagg( trim(codigoproducto), ' / ' ) within group (order by trim(codigoproducto) ) codigoproducto,  
                           listagg( trim(producto), ' / ' ) within group (order by trim(codigoproducto) )  producto 
                         from data.vt_icom_procesoCodigoPromo p 
                         where nvl(p.porcentaje,0) < 100 and UPPER(TRIM(p.usuario)) = usu.usuario
                         and not EXISTS ( select 1 from data.vt_gzm_producto v where v.codigoproducto = p.codigoproducto  )
                         group by p.descripcion, p.idinversion, p.inversion, p.fec_InicioInv, p.fec_FinInv
                         order by p.descripcion, p.idinversion, p.inversion, p.fec_InicioInv, p.fec_FinInv )
            loop
                V_OBJETO_DES := V_OBJETO_DES ||'<tr> <td ALIGN=LEFT >'	|| inv.idinversion ||'</td>';
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER >'	|| inv.codigoproducto	||'</td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT >'	|| inv.producto	||'</td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER >'	|| inv.fechainicio ||'</td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER >'	|| inv.fechafin	||'</td></tr>';
            end loop;
            
             V_OBJETO_DES:= V_OBJETO_DES||'</table>' ;
            --Se inserta la despedida
            V_OBJETO_DES := V_OBJETO_DES||'<p>Gracias por su atenci&oacute;n </p>
                                            <p>Saludos Cordiales </p>
                                            <p>Portal de Inversiones Comerciales </p>';
            
            PK_CORP_CORREO.SP_ENVIO(
                        P_MODULO => 'ICOM',
                        P_TO => v_correo_notificacion,
                        P_FROM => 'notificacion@zaimella.com',
                        P_SUBJECT => v_asunto,
                        P_BODY => V_OBJETO_DES
            );
        end loop;
        dbms_output.put_line( 'Fin Notificacion Codigo Promocional Pendiente');
        
        --verifico que existe inversiones que cumplan la condicion
        select count(1) into v_cuenta
        from data.vt_icom_procesoCodigoPromo p 
        left join data.vt_icom_inversion_cliente g on (p.idinversion = g.idinversion and g.estadonegociacion = 3)
        where p.porcentaje = 100
        and (nvl(DATA.PK_JDE_INVENTARIO.F_STOCKPRODUCTO(p.codigoproducto, '17003'),0) > 0 or v_produccion=0 )
        AND NOT EXISTS (SELECT 1 FROM vt_icom_referenciacruzada R WHERE TRIM(R.CODIGOPRODUCTO)=p.codigoproducto AND R.CODIGOGRUPO=G.CODIGOGRUPO)
        AND EXISTS (SELECT 1 from data.vt_icom_inversionProcesoActivo ip where ip.idproceso = 10 AND IP.IDINVERSION=p.idinversion)
        ;
        
        if nvl(v_cuenta,0) > 0 then
            dbms_output.put_line( 'Inicia Referencias Cruzadas');
            --busco el correo de notificaciÃ³n del proceso 
            select notificacion_imp into v_correo_notificacion
            from data.vt_icom_proceso
            where idproceso = 10 and estado = '1'  ;
            
            v_asunto := 'Referencias Cruzadas de Promociones';
            /*Primer Correo notificacion_imp*/
            ---1 correo para notificacion_imp
            --- 2 correo para notificar a los ejecutivos
            --- cabecera del 1 correo    V_OBJETO_DES          

            V_OBJETO_DES := '<p>&nbsp;</p>
                          <p>Estimado Usuario</p>
                          <p>&nbsp;</p>
                          <p>A continuaciÃ³n se detallan las referencias que deben ser cruzadas por promociones aprobadas: </p>
                          </p> <p>&nbsp;</p> ' ;

            V_OBJETO_DES := V_OBJETO_DES || '<table border=''1'' style=''width:100%; padding:0px; border-spacing:0px;''>';
            V_OBJETO_DES := V_OBJETO_DES || ' <tr BGCOLOR=''lightgrey''>  ';
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''6%''><strong>ID</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''16%''><strong>NOMBRE DE LA PROMOCION</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''8%''><strong>CODIGO PADRE</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''8%''><strong>CODIGO HIJO</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''12%''><strong>DESCRIPCION</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''8%''><strong>CANAL</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''8%''><strong>GRUPO</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''9%''><strong>STOCK PADRE</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''9%''><strong>STOCK HIJO</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''8%''><strong>FECHA INICIO</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''8%''><strong>FECHA FIN</strong></th></tr>';
            V_OBJETO_DES_ejecutivo:=V_OBJETO_DES;
            /*detalle del primer correo */

            for inv in (select p.idinversion, p.inversion, p.codigoproducto, p.codigoproductopadre, p.producto, 
                            p.fec_InicioInv fechainicio, p.fec_FinInv fechafin, g.nombres, g.canal,
                            nvl(DATA.PK_JDE_INVENTARIO.F_STOCKPRODUCTO(p.codigoproducto, '17003'),0) stockProducto,
                            nvl(DATA.PK_JDE_INVENTARIO.F_STOCKPRODUCTO(p.codigoproductopadre, '17003'),0) stockPadre
                        from data.vt_icom_procesoCodigoPromo p 
                            left join data.vt_icom_inversion_cliente g on (p.idinversion = g.idinversion and g.estadonegociacion = 3)
                        where p.porcentaje = 100
                        and (nvl(DATA.PK_JDE_INVENTARIO.F_STOCKPRODUCTO(p.codigoproducto, '17003'),0) > 0 or v_produccion=0)
                        AND NOT EXISTS (SELECT 1 FROM vt_icom_referenciacruzada R WHERE TRIM(R.CODIGOPRODUCTO)=p.codigoproducto AND R.CODIGOGRUPO=G.CODIGOGRUPO)
                         AND EXISTS (SELECT 1 from data.vt_icom_inversionProcesoActivo ip where ip.idproceso = 10 AND IP.IDINVERSION=p.idinversion)
                         ) 
            loop
                
                V_OBJETO_DES:= V_OBJETO_DES||'<tr> <td ALIGN=LEFT >'|| to_char(inv.idinversion) ||'</td>';
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT >'	|| to_char(inv.inversion) ||'</td>';
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT >'	|| to_char(inv.codigoproductopadre)   ||'</td>';
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER >'	|| to_char(inv.codigoproducto)	||'</td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT >'	|| to_char(inv.producto)	||'</td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT >'	|| to_char(inv.canal)	||'</td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT >'	|| to_char(inv.nombres)	||'</td>' ;
                   V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT >'	|| to_char(inv.stockPadre)  ||'</td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT >'	|| to_char(inv.stockProducto)	||'</td>' ;
             
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER >'	|| to_char(inv.fechainicio) ||'</td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER >'	|| to_char(inv.fechafin)	||'</td></tr>';
             
                
            end loop;
                                   
            ----Enviar el primer correo 
            V_OBJETO_DES:= V_OBJETO_DES||'</table>' ;
            --Se inserta la despedida
            V_OBJETO_DES := V_OBJETO_DES||'<p>Gracias por su atenci&oacute;n </p>
                                            <p>Saludos Cordiales </p>
                                            <p>Portal de Inversiones Comerciales </p>';
            dbms_output.put_line( 'Notifica a :'||v_correo_notificacion);
            PK_CORP_CORREO.SP_ENVIO(
                        P_MODULO => 'ICOM',
                        P_TO => v_correo_notificacion,
                        P_FROM => 'notificacion@zaimella.com',
                        P_SUBJECT => v_asunto,
                        P_BODY => V_OBJETO_DES||' notifica a: '||v_correo_notificacion  
            );
            
            /*inicia el segundo correo por ejecutivo*/
                        
            for ejecutivo in (
                SELECT DISTINCT g.EJECUTIVO,u.EMAIL EJECUTIVOEMAIL,s.EMAIL COORDINADOREMAIL
                FROM data.vt_icom_procesoCodigoPromo p
                left join data.vt_icom_inversion_cliente i on (p.idinversion = i.idinversion and i.estadonegociacion = 3)
                left join VT_GZM_CLIENTE G   on i.codigogrupo =g.codigogrupo 
                INNER JOIN data.VT_CORP_USUARIO U ON (U.NUMEROIDENTIFICACION=g.ejecutivo)
                left join data.vt_corp_usuario s on  s.nombreusuario = p.usuario                  
            )
            loop 
                v_objeto_ejecutivo_det:=V_OBJETO_DES_ejecutivo;
                for inv in (
                    select 
                        p.idinversion, p.inversion, p.codigoproducto, p.codigoproductopadre, p.producto,
                        p.fec_InicioInv fechainicio, p.fec_FinInv fechafin, g.nombres, g.canal,
                        nvl(DATA.PK_JDE_INVENTARIO.F_STOCKPRODUCTO(p.codigoproducto, '17003'),0) stockProducto,
                        nvl(DATA.PK_JDE_INVENTARIO.F_STOCKPRODUCTO(p.codigoproductopadre, '17003'),0) stockPadre
                    from data.vt_icom_procesoCodigoPromo p
                    left join data.vt_icom_inversion_cliente g on (p.idinversion = g.idinversion and g.estadonegociacion = 3)
                    left join data.VT_GZM_CLIENTE a on A.Codigogrupo=g.Codigogrupo and g.EJECUTIVO=ejecutivo.EJECUTIVO
                    where p.porcentaje = 100
                    and (nvl(DATA.PK_JDE_INVENTARIO.F_STOCKPRODUCTO(p.codigoproducto, '17003'),0) > 0 or v_produccion=0)
                    AND NOT EXISTS (SELECT 1 FROM vt_icom_referenciacruzada R WHERE TRIM(R.CODIGOPRODUCTO)=p.codigoproducto AND R.CODIGOGRUPO=G.CODIGOGRUPO)
                    AND EXISTS (SELECT 1 from data.vt_icom_inversionProcesoActivo ip where ip.idproceso = 10 AND IP.IDINVERSION=p.idinversion)
                ) 
                loop
                    v_objeto_ejecutivo_det := v_objeto_ejecutivo_det ||'<tr> <td ALIGN=LEFT >'|| to_char(inv.idinversion) ||'</td>';
                    v_objeto_ejecutivo_det := v_objeto_ejecutivo_det ||'<td ALIGN=LEFT >'	|| to_char(inv.inversion) ||'</td>';
                    v_objeto_ejecutivo_det := v_objeto_ejecutivo_det ||'<td ALIGN=LEFT >'	|| to_char(inv.codigoproductopadre)   ||'</td>';
                    v_objeto_ejecutivo_det := v_objeto_ejecutivo_det ||'<td ALIGN=CENTER >'	|| to_char(inv.codigoproducto)	||'</td>' ;
                    v_objeto_ejecutivo_det := v_objeto_ejecutivo_det ||'<td ALIGN=LEFT >'	|| to_char(inv.producto)	||'</td>' ;
                    v_objeto_ejecutivo_det := v_objeto_ejecutivo_det ||'<td ALIGN=LEFT >'	|| to_char(inv.canal)	||'</td>' ;
                    v_objeto_ejecutivo_det := v_objeto_ejecutivo_det ||'<td ALIGN=LEFT >'	|| to_char(inv.nombres)	||'</td>' ;
                    v_objeto_ejecutivo_det := v_objeto_ejecutivo_det ||'<td ALIGN=LEFT >'	|| to_char(inv.stockPadre)  ||'</td>' ;
                    v_objeto_ejecutivo_det := v_objeto_ejecutivo_det ||'<td ALIGN=LEFT >'	|| to_char(inv.stockProducto)	||'</td>' ;
                    v_objeto_ejecutivo_det := v_objeto_ejecutivo_det ||'<td ALIGN=CENTER >'	|| to_char(inv.fechainicio) ||'</td>' ;
                    v_objeto_ejecutivo_det := v_objeto_ejecutivo_det ||'<td ALIGN=CENTER >'	|| to_char(inv.fechafin)	||'</td></tr>';
                end loop;
            ----Enviar el primer correo 
                v_objeto_ejecutivo_det:= v_objeto_ejecutivo_det||'</table>' ;
                --Se inserta la despedida
                v_objeto_ejecutivo_det := v_objeto_ejecutivo_det||'<p>Gracias por su atenci&oacute;n </p>
                                                <p>Saludos Cordiales </p>
                                                <p>Portal de Inversiones Comerciales </p>';
                dbms_output.put_line( 'Notifica a :'||v_correo_notificacion);
                PK_CORP_CORREO.SP_ENVIO(
                            P_MODULO => 'ICOM',
                            P_TO => v_correo_notificacion||','||ejecutivo.EJECUTIVOEMAIL||','||ejecutivo.COORDINADOREMAIL,
                            P_FROM => 'notificacion@zaimella.com',
                            P_SUBJECT => v_asunto,
                            P_BODY => v_objeto_ejecutivo_det
                );
            end loop;

            dbms_output.put_line( 'Fin Referencias Cruzadas');
        end if;    
        
    END SP_tareaCodigoPromocional; 
    
    /*Procedimiento para obtener los procesos operativos de diseÃ±o arte*/
    PROCEDURE SP_tareaDisenoArte AS
        V_OBJETO_CAB				varchar2(5000);
        V_OBJETO_DES				varchar2(5000);
        v_asunto                 VARCHAR2(100);
        v_correo_notificacion	varchar2(200);
        v_nombres   varchar2(500);
        v_cuenta number;
    BEGIN
    
        for usu in ( select distinct UPPER(TRIM(p.usuario)) USUARIO from data.vt_icom_procesoDisenoArte  p
                     where p.porcentaje = 0  )
        loop
            --se debe mandar un correo a cada usuario
            v_correo_notificacion:= null; 
            v_nombres:= null;
            --busco el correo al que se debe notificar 
            select email, nombres||' '||apellidos INTO v_correo_notificacion, v_nombres
            from data.vt_corp_usuario where UPPER(TRIM(nombreusuario)) = usu.usuario ;
            --Se envia la notificaciÃ³n 
            v_asunto := 'DiseÃ±o Arte Pendiente';
  
            V_OBJETO_CAB := '<p>&nbsp;</p>
                          <p>Estimado Usuario</p>
                          <p>&nbsp;</p>
                          <p>'||v_nombres||'</p>
                          <p>&nbsp;</p>
                          <p>Tiene pendiente el envÃ­o de caso de diseÃ±o de arte de los ID: ' ;
            
                V_OBJETO_DES := '<table border=''1'' style=''width:100%; padding:0px; border-spacing:0px;''>';
                V_OBJETO_DES := V_OBJETO_DES || ' <tr BGCOLOR=''lightgrey''>  ';
                V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''10%''><strong>ID INVERSION</strong></th>';               
                V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''34%''><strong>NOMBRE DE LA PROMOCION</strong></th>';               
                V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''20%''><strong>ORIGEN</strong></th>';               
                V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''12%''><strong>TIPO</strong></th>';               
                V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''12%''><strong>FECHA INICIO</strong></th>';               
                V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''12%''><strong>FECHA FIN</strong></th></tr>';
                
            for inv in ( select p.descripcion, p.idinversion, p.inversion, p.fec_InicioInv fechainicio, p.fec_FinInv fechafin, 
                            p.origen, p.tipo--, p.pro_fechainicio, p.pro_fechafin, round(nvl((p.fechainicio - sysdate),0)) dias
                         from data.vt_icom_procesoDisenoArte p 
                         where nvl(p.porcentaje,0) = 0 and UPPER(TRIM(p.usuario)) = usu.usuario  )
            loop
                V_OBJETO_CAB := V_OBJETO_CAB ||inv.idinversion||', ';
                --dbms_output.put_line( 'objeto '||V_OBJETO_DES );
                V_OBJETO_DES := V_OBJETO_DES ||'<tr> <td ALIGN=LEFT >'	|| inv.idinversion ||'</td>';
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT >'	|| inv.inversion   ||'</td>';
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER >'	|| inv.origen	||'</td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT >'	|| inv.tipo	||'</td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER >'	|| inv.fechainicio ||'</td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER >'	|| inv.fechafin	||'</td></tr>';
                
            end loop;
            
            V_OBJETO_CAB := substr(V_OBJETO_CAB, 1, instr(V_OBJETO_CAB, ',',-1)-1)|| ' </p> <p>&nbsp;</p>' ;
            V_OBJETO_DES:= V_OBJETO_DES||'</table>' ;
            --Se inserta la despedida
            V_OBJETO_DES := V_OBJETO_CAB||' '||
            V_OBJETO_DES||'<p>Gracias por su atenci&oacute;n </p>
                                            <p>Saludos Cordiales </p>
                                            <p>Portal de Inversiones Comerciales </p>';
            
            PK_CORP_CORREO.SP_ENVIO(
                        P_MODULO => 'ICOM',
                        P_TO => v_correo_notificacion,
                        P_FROM => 'notificacion@zaimella.com',
                        P_SUBJECT => v_asunto,
                        P_BODY => V_OBJETO_DES
            );            
        end loop;
        
    END SP_tareaDisenoArte; 
    
    /*Procedimiento para finalizar el proceso de planificacion de productos*/
    PROCEDURE SP_tareaPalnificacionProducto AS
        v_cuenta number;
    BEGIN
        --Se busa las inversiones que tengan el proceso de planificacion de productos  
        for inv in ( select distinct ip.idinversion 
                       from data.vt_icom_inversionprocesoactivo ip
                            inner join data.t_icom_producto_cantidad pc 
                                on ( ip.idinversion = pc.idinversion  and pc.cantidad > 0 
                                    --and DATA.PK_JDE_INVENTARIO.F_STOCKPRODUCTO(pc.codigoproducto, '17003') > 0 
                                    )
                       where ip.idproceso = 9 and ip.porcentaje = 0  )
        loop
            select count(1) into v_cuenta from data.t_icom_producto_cantidad
             where idinversion = inv.idinversion and cantidad > 0 
               and nvl(DATA.PK_JDE_INVENTARIO.F_STOCKPRODUCTO(codigoproducto, '17003'),0) <= 0 ;
            --Ya no existen productos sin stock se actualiza el proceso
            if nvl(v_cuenta,0) = 0 then   
                update data.t_icom_inversion_proceso
                set porcentaje = 100, fechafin = sysdate
                where idinversion = inv.idinversion 
                and idproceso = 9
                and estado = 1 ; 
                
            end if ;    
            v_cuenta := 0 ;
        end loop;
    END SP_tareaPalnificacionProducto;
    
    /*Procedimiento para realizar la tarea del proceso referencia cruzada*/
    PROCEDURE SP_tareaReferenciaCruzada AS
        v_ndias number;
        v_asunto varchar2(200);
        V_OBJETO_DES clob ;
    BEGIN
        --busco las inversiones con los dÃ­as
        for pro in ( select idinversion, round(inv_fechafin - sysdate) dias, inversion, inv_fechainicio fec_inicioinv, inv_fechafin fec_fininv, notificacion_imp    
                       from data.vt_icom_procesoRef_cruzada rc where 
                       round(inv_fechafin - sysdate)  between 0 and nvl(pk_commons.safe_to_number(PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '24', COMPANIA )),0)
                       and EXISTS (select 1 from data.vt_icom_inversionProductoRef pr
                          where pr.idinversion = rc.idinversion and pr.stockProducto > 0) )
        loop
            --Se debe enviar el correo de notificaciÃ³n
            v_asunto := 'Promociones por finalizar';
            V_OBJETO_DES := '<p>&nbsp;</p> <p>Estimado Usuario</p> <p>&nbsp;</p>
                          <p>La promoci&oacute;n est&aacute; por finalizar en ('||pro.dias||' d&iacute;as)  </p>  
                          </p> <p>&nbsp;</p> ' ;

            V_OBJETO_DES := V_OBJETO_DES || '<table border=''1'' style=''width:100%; padding:0px; border-spacing:0px;''>';
            V_OBJETO_DES := V_OBJETO_DES || ' <tr BGCOLOR=''lightgrey''>  ';
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''6%''><strong>ID</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''16%''><strong>PROMOCION</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''8%''><strong>CODIGO PADRE</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''8%''><strong>CODIGO HIJO</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''12%''><strong>DESCRIPCION</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''8%''><strong>CANAL</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''8%''><strong>GRUPO</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''9%''><strong>STOCK PADRE</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''9%''><strong>STOCK HIJO</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''8%''><strong>FECHA INICIO</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''8%''><strong>FECHA FIN</strong></th></tr>';
                              
            for inv in ( select pr.codigoproducto, pr.codigoproductopadre, pr.producto, pr.stockProducto,pr.stockPadre,
                            pr.nombres, pr.canal 
                           from data.vt_icom_inversionProductoRef pr
                          where pr.idinversion = pro.idinversion and pr.stockProducto > 0   )
            loop
                V_OBJETO_DES:= V_OBJETO_DES||'<tr> <td ALIGN=LEFT >'|| pro.idinversion ||'</td>';
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT >'	|| pro.inversion ||'</td>';
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT >'	|| inv.codigoproductopadre   ||'</td>';
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER >'	|| inv.codigoproducto	||'</td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT >'	|| inv.producto	||'</td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT >'	|| inv.canal	||'</td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT >'	|| inv.nombres	||'</td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT >'	|| inv.stockPadre  ||'</td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT >'	|| inv.stockProducto	||'</td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER >'	|| pro.fec_inicioinv ||'</td>' ;
                V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER >'	|| pro.fec_fininv	||'</td></tr>';
            end loop;
            V_OBJETO_DES:= V_OBJETO_DES||'</table>' ;
            --Se inserta la despedida
            V_OBJETO_DES := V_OBJETO_DES||'<p>Gracias por su atenci&oacute;n </p>
                                            <p>Saludos Cordiales </p>
                                            <p>Portal de Inversiones Comerciales </p>';
            
            PK_CORP_CORREO.SP_ENVIO(
                        P_MODULO => 'ICOM',
                        P_TO => pro.notificacion_imp,
                        P_FROM => 'notificacion@zaimella.com',
                        P_SUBJECT => v_asunto,
                        P_BODY => V_OBJETO_DES
            );
        end loop;
        
    END SP_tareaReferenciaCruzada;
    
    /*Procedimeinto que realiza la tarea para envio de correo del Codificacion de Productos */
    PROCEDURE SP_tareaCodificacionProducto AS 
        v_correo varchar2(100) ;
         V_OBJETO_DES				varchar2(5000);
        v_asunto                 VARCHAR2(100);
        v_correo_notificacion	varchar2(200);
        v_codigoproducto varchar2(1000);
        v_producto varchar2(1000);
    BEGIN

       --busco todas las inversiones que cumplan las condiciones
       for inv in ( select pa.descripcion, pa.idinversion, pa.inversion, pa.fec_InicioInv fechainicio, 
                           pa.fec_finInv fechafin, pa.notificacion_imp 
                      from data.vt_icom_inversionProcesoActivo pa
                        inner join data.t_icom_inversion_producto pro  on ( pa.idinversion = pro.idinversion )
                        inner join data.t_icom_inversion_cliente cli on ( pa.idinversion = cli.idinversion )
                        where pa.idproceso = 13 
                       -- and pa.idorigen = 3 --fabrica
                        and pa.fec_finInv < sysdate
                        and nvl(DATA.PK_JDE_INVENTARIO.F_STOCKPRODUCTO(pro.codigoproducto, '17003'),0) > 0
                        and not exists (select 1  from data.vt_gzm_facturadetalle fac 
                                        where ( pro.codigoproducto = fac.codigoproducto and cli.codigocliente = fac.codigocliente 
                                        --and fac.fecha > pa.fec_InicioInv 
                                        ))
                        group  by pa.descripcion, pa.idinversion, pa.inversion, pa.fec_InicioInv, pa.fec_finInv, pa.notificacion_imp  )
        loop
            --buscamos los correos de todos los ejecutivos.
            select listagg( trim(email), '; ' ) within group (order by trim(email) )  
            INTO v_correo_notificacion
            from data.vt_corp_usuario 
            where UPPER(TRIM(nombreusuario)) in (           
                                select UPPER(TRIM(ejecutivo))
                                from data.vt_icom_inversion_cliente 
                                where estadonegociacion  in (1,3) 
                                and idinversion = inv.idinversion ) ;
            if inv.notificacion_imp is not null then
                v_correo_notificacion := inv.notificacion_imp||';'||v_correo_notificacion ;
            end if ;
            
            --buscamos los productos de la inversion
            select listagg( trim(codigoproducto), ' / ' ) within group (order by trim(codigoproducto) ) codigoproducto,  
                           listagg( trim(producto), ' / ' ) within group (order by trim(codigoproducto) )  producto 
            into v_codigoproducto, v_producto               
            from data.t_icom_inversion_producto
            where idinversion = inv.idinversion 
            and nuevo in (1,2) and tipo in (1,3) ;
            
            --Se envia la notificaciÃ³n 
            v_asunto := 'Productos con nuevo EAN';
  
            V_OBJETO_DES := '<p>&nbsp;</p>
                          <p>Estimado Usuario</p>
                          <p>&nbsp;</p>
                          <p>Se tiene pendiente la codificaciÃ³n de producto(s) de la(s) siguiente(s) inversiÃ³n(es): ' ;
            
            V_OBJETO_DES := V_OBJETO_DES ||inv.idinversion||' '||inv.inversion|| '</p> <p>&nbsp;</p> ';
            V_OBJETO_DES := V_OBJETO_DES || '<table border=''1'' style=''width:100%; padding:0px; border-spacing:0px;''>';
            V_OBJETO_DES := V_OBJETO_DES || ' <tr BGCOLOR=''lightgrey''>  ';
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''12%''><strong>PROCESO</strong></th>';
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''10%''><strong>ID INVERSION</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''22%''><strong>NOMBRE DE LA PROMOCION</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''12%''><strong>CODIGO</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''20%''><strong>PRODUCTO</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''12%''><strong>FECHA INICIO</strong></th>';               
            V_OBJETO_DES := V_OBJETO_DES || '<th  ALIGN=CENTER width=''12%''><strong>FECHA FIN</strong></th></tr>';
            V_OBJETO_DES:= V_OBJETO_DES||'<tr> <td ALIGN=LEFT >'|| inv.descripcion ||'</td>';
            V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT >'	|| inv.idinversion ||'</td>';
            V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT >'	|| inv.inversion   ||'</td>';
            V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER >'	|| v_codigoproducto	||'</td>' ;
            V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=LEFT >'	|| v_producto	||'</td>' ;
            V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER >'	|| inv.fechainicio ||'</td>' ;
            V_OBJETO_DES := V_OBJETO_DES ||'<td ALIGN=CENTER >'	|| inv.fechafin	||'</td></tr>';
            V_OBJETO_DES:= V_OBJETO_DES||'</table>' ;
            
            --Se inserta la despedida
            V_OBJETO_DES := V_OBJETO_DES||'<p>Gracias por su atenci&oacute;n </p>
                                            <p>Saludos Cordiales </p>
                                            <p>Portal de Inversiones Comerciales </p>';
            
            PK_CORP_CORREO.SP_ENVIO(
                        P_MODULO => 'ICOM',
                        P_TO => v_correo_notificacion,
                        P_FROM => 'notificacion@zaimella.com',
                        P_SUBJECT => v_asunto,
                        P_BODY => V_OBJETO_DES
            );
        end loop;

    END SP_tareaCodificacionProducto;
    
    PROCEDURE SP_TareaCompraMaterialPop
    AS
    V_GRUPO NUMBER;
    V_LINEA NUMBER;
    V_CONTADOR NUMBER;
    V_CONTADOR2 NUMBER;
    V_ACA_CANAL VARCHAR(250);
    V_USUARIO VARCHAR(250);
    V_COMPANIA VARCHAR(250);
    BEGIN 
    

        --ACTUALIZAR ORDENES DE COMPRA
        dbms_output.put_line( 'ACTUALIZA ORDENES DE COMPRAS');
        UPDATE t_icom_cliente_materialcompra 
        SET (ORDENCOMPRA, ORDENCOMPRATIPO) =
        (SELECT PDDOCO, PDDCTO FROM F4311@jdedtadl
        WHERE  PDOORN=REQUISICION AND PDOCTO=REQUISICIONTIPO AND ROWNUM=1)
        where estadoruta=1  AND  REQUISICION IS NOT NULL AND ORDENCOMPRA IS NULL
        AND EXISTS (SELECT 1 FROM F4311@jdedtadl WHERE PDOORN=REQUISICION AND PDOCTO=REQUISICIONTIPO);

        /*ACTUALIZAR LAS REQUICIONES RECHAZAS*/
        UPDATE t_icom_cliente_materialcompra 
        SET REQUISICION=null, REQUISICIONTIPO =null, estadoruta=0
        where estadoruta=1 
        and REQUISICION IS NOT NULL AND ORDENCOMPRA IS NULL
        and exists(SELECT 1 FROM t_icom_inversiones where id=idinversion and  idetapa  in (2,3,4,7) and estado= 1  and idpadre is null)
        AND EXISTS (SELECT 1 FROM F4311@jdedtadl WHERE PDDOCO=REQUISICION AND PDDCTO=REQUISICIONTIPO and (PDLTTR in (980) and PDNXTR=999) );

        /*ACTUALIZAR LAS ORDENES RECHAZAS*/
        UPDATE t_icom_cliente_materialcompra 
        SET REQUISICION=null, REQUISICIONTIPO =null   ,ORDENCOMPRA=null, ORDENCOMPRATIPO =null, estadoruta=0
        where estadoruta=1 
        and ORDENCOMPRA IS not NULL
        and exists(SELECT 1 FROM t_icom_inversiones where id=idinversion and  idetapa  in (2,3,4,7) and estado= 1  and idpadre is null)
        AND EXISTS (SELECT 1 FROM F4311@jdedtadl WHERE PDDOCO=ORDENCOMPRA AND PDDCTO=ORDENCOMPRATIPO and (PDLTTR='980' and PDNXTR='999') );

        /*ACTUALIZAR LAS ORDENES RECIBIDAS*/
        UPDATE t_icom_cliente_materialcompra 
        SET ESTADORUTA = 3
        where ESTADORUTA=1 
        and ORDENCOMPRA IS not NULL
        and exists(SELECT 1 FROM t_icom_inversiones where id=idinversion and  idetapa  in (2,3,4,7) and estado= 1  and idpadre is null)
        AND EXISTS (SELECT 1 FROM F4311@jdedtadl WHERE PDDOCO=ORDENCOMPRA AND PDDCTO=ORDENCOMPRATIPO and ((PDLTTR='400' and PDNXTR='400') or (PDLTTR='400' and PDNXTR='999')) );

        /*INGRESAR AL GASTO LAS ORDENES RECHAZAS*/
                
         --ACTUALIZO PORCENTAJE 75
         update data.t_icom_inversion_proceso p  set porcentaje = 75 
         where porcentaje<75 and  idproceso = 6
         and exists (select 1 from t_icom_cliente_materialcompra m 
         where m.idinversion=p.idinversion and m.ORDENCOMPRA is not null);
         
         --ACTUALIZO PORCENTAJE 100  A LAS INVERSIONES QUE COMPRARON TODO
         update data.t_icom_inversion_proceso p  set porcentaje = 100 
         where porcentaje=75 and  idproceso = 6
         AND NOT EXISTS ( SELECT 1 FROM DATA.VT_ICOM_CLIENTE_MATERIALNEGOCIADO M
             WHERE  m.idinversion=p.idinversion  AND TOTAL_PENDIENTE <>0);
                
    END SP_TareaCompraMaterialPop;

       /*
       PK_ICOM_PROCESOSTAREAS.SP_ActualizarPDV(21897);
       reemplace la informaciÃ³n de los puntos de venta de la tabla  t_icom_cliente_pdv, debe traer los puntos de ventas de la 
       tabla t_icom_productodistribucionDet PARA  analizar que las ventas Sellout tomen con los nuevos puntos de venta en el cierre*/
      
      PROCEDURE SP_ActualizarPDV(P_ID NUMBER)
      AS
      v_contador number;
      BEGIN 
        --se valida que existan registros a ser eliminados y volver a porterior creacion.
        select count( distinct 1) into v_contador  from t_icom_productodistribucionDet b where  b.idinversion=P_ID and b.ESTADO=1;
        if (v_contador=1)then
            --elimina los pdv existentes
            delete  t_icom_cliente_pdv a where idinversion=p_id and
            exists (select 1 from t_icom_productodistribucionDet b where a.idinversion=b.idinversion and b.ESTADO=1);
            
            --inserta los pdv
            insert into t_icom_cliente_pdv (IDINVERSION, CODIGOPDV, FECHAINICIO, FECHAFIN, ESTADO)
            select distinct idinversion, CODIGOPDV, FECHAINICIO, FECHAFIN, 1 estado
            from t_icom_productodistribucionDet a
            inner join  t_icom_inversiones b on b.id=a.idinversion
            where idinversion=p_id and a.estado=1;
            sp_ejecutarAnalisis(p_id);
        end if;
      END SP_ActualizarPDV;     
      
    /*
       PK_ICOM_PROCESOSTAREAS.sp_ejecutarAnalisis(21897);
       Actualizar los puntos de ventas en el caso de la distribuciÃ³n del producto regalo. 
       Cambia el valor de situaciÃ³n. Inicial y meta*/
    procedure sp_ejecutarAnalisis(p_id number) as
        --p_id number:=18998;
        V_GRUPAL  NUMBER;
        V_PERIODO  NUMBER;
        V_ANIO_ANALISIS NUMBER;
        V_TIPO_GRAFICO NUMBER;
        V_SITUACIONACTUALMES VARCHAR2(5);
        V_COMPANIA  VARCHAR2(5);
    begin
        SELECT 
               GRUPAL,ANALISISPERIODO,   ANALISISANIO, ANALISISVISTA,  SITUACIONACTUALMES,  COMPANIA
        into V_GRUPAL,      V_PERIODO,V_ANIO_ANALISIS,V_TIPO_GRAFICO,V_SITUACIONACTUALMES,V_COMPANIA
        FROM DATA.t_icom_inversiones where id =p_id;
        
        SELECT ID_TABLA  
        into v_SITUACIONACTUALMES
        FROM data.T_CORP_UDC where ID_CABECERA ='ICOM_A1G1' and valor = v_SITUACIONACTUALMES;
        
        PK_ICOM_ANALISIS.SP_GUARDAR_ANALISIS( 
            P_ID => p_id, P_GRUPAL  => v_GRUPAL,  P_ANIO => v_ANIO_ANALISIS, 
            P_PERIODO => v_PERIODO,P_GRAFICO =>  v_TIPO_GRAFICO, P_TIPOEJECUCION =>1
        );
        data.PK_ICOM_ANALISIS.SP_SELEC_ANALIS_SELL_IN_OUT(
            P_ID => p_id, P_IDTABLA => v_SITUACIONACTUALMES,
            P_ANALISISTIPO=> 'R_SELLIN_SELLOUT', P_TIPOEJECUCION =>1
        );
        
    end;

      --PK_ICOM_PROCESOSTAREAS.SP_EJECUTAR_TAREAMANUAL();
       PROCEDURE SP_EJECUTAR_TAREAMANUAL(P_TAREA VARCHAR2) AS
       BEGIN 
            dbms_output.put_line( 'P_TAREA: '||P_TAREA);
            execute immediate 'BEGIN '||P_TAREA||' END;';
       END SP_EJECUTAR_TAREAMANUAL;

END PK_ICOM_PROCESOSTAREAS ;
/
/

