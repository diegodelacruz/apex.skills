﻿prompt Esquema DATA para codigo PL/SQL
alter session set current_schema=DATA;

prompt PROD PACKAGE_BODY DATA.PK_ICOM_CRUD

  CREATE OR REPLACE EDITIONABLE PACKAGE BODY PK_ICOM_CRUD AS  
   
     /*Procedimiento para guardar o editar la relacion entre un tipo de inversion y un elemento
      @param P_ID VARCHAR id registro, si es null insert caso contrario update
      @param P_INVERSIONTIPO VARCHAR id tipo de inversion
      @param P_ELEMENTO VARCHAR id de elemento
      @param P_OBLIGATORIO VARCHAR bandera que indica si es obligatorio 1/0
      @param P_ESTADO VARCHAR bandera que indica su estado 1/0
      @param P_COMPANIA VARCHAR codigo de compania
    */    
    V_COMPANIA	varchar2(5);
    PROCEDURE SP_CONF_ELEM_INVERSION(P_ID NUMBER DEFAULT NULL, P_INVERSIONTIPO VARCHAR,
             P_ELEMENTO VARCHAR,P_OBLIGATORIO NUMBER,P_ESTADO NUMBER, P_COMPANIA VARCHAR, P_AYUDA NUMBER)
    AS 
    V_TABLA VARCHAR(50) := 'T_ICOM_CONF_INVER_ETAPA_ELEM';
    BEGIN 
 
        IF(P_ID IS NULL) THEN
            INSERT INTO data.T_ICOM_CONF_INVER_ETAPA_ELEM 
            (ID, idinversiontipo, idelemento, OBLIGATORIO,compania, estado,AYUDA) VALUES 
            (DATA.PK_COMMONS.F_SECUENCIA (V_TABLA), P_INVERSIONTIPO,P_ELEMENTO,P_OBLIGATORIO,P_COMPANIA,1, P_AYUDA );
        ELSE
            UPDATE data.T_ICOM_CONF_INVER_ETAPA_ELEM SET 
            ESTADO=P_ESTADO, OBLIGATORIO=P_OBLIGATORIO,AYUDA=P_AYUDA WHERE ID=P_ID;
        END IF;
 
    END SP_CONF_ELEM_INVERSION;
 
 
    /*Procedimiento para guardar o editar la relacion entre un tipo de inversion origen y tipo*/
 
    PROCEDURE SP_CONF_INVER_ORIGEN_TIPO(P_ID NUMBER DEFAULT NULL, P_INVERSIONTIPO VARCHAR,
             P_ORIGEN VARCHAR,P_TIPO NUMBER,P_NEGOCIACION NUMBER,P_ESTADO NUMBER, P_COMPANIA VARCHAR) AS
    V_TABLA VARCHAR(50) := 'T_ICOM_CONF_INVER_ORIG_TIPO';
    BEGIN 
        IF(P_ID IS NULL) THEN
            INSERT INTO data.T_ICOM_CONF_INVER_ORIG_TIPO 
            (ID, idinversiontipo, idORIGEN, IDTIPO,COMPANIA, ESTADO, NEGOCIACION) 
            VALUES 
            (data.PK_COMMONS.F_SECUENCIA (V_TABLA), P_INVERSIONTIPO,P_ORIGEN,P_TIPO, P_COMPANIA,1, P_NEGOCIACION );
        ELSE
            UPDATE data.T_ICOM_CONF_INVER_ORIG_TIPO SET 
            ESTADO=P_ESTADO, NEGOCIACION=P_NEGOCIACION WHERE ID=P_ID;
        END IF;
    END SP_CONF_INVER_ORIGEN_TIPO;
 
    /*Procedimiento para guardar o editar la relacion entre AREA OBJETIVO Y KPI*/
   PROCEDURE SP_CONF_AREA_OBJ_KPI(P_ID NUMBER DEFAULT NULL, P_AREA VARCHAR,
             P_OBJETIVO NUMBER,P_KPI NUMBER,P_VALOR NUMBER,P_ESTADO NUMBER, P_COMPANIA VARCHAR) AS
    V_TABLA VARCHAR(50) := 'T_ICOM_CONF_AREA_OBJ_KPI';
    BEGIN 
        IF(P_ID IS NULL) THEN
            INSERT INTO data.T_ICOM_CONF_AREA_OBJ_KPI 
            (ID, IDAREA, IDOBJETIVO, IDKPI, VALOR,  COMPANIA, ESTADO) VALUES 
            (data.PK_COMMONS.F_SECUENCIA (V_TABLA), P_AREA,P_OBJETIVO,P_KPI,P_VALOR, P_COMPANIA,1 );
        ELSE
            UPDATE data.T_ICOM_CONF_AREA_OBJ_KPI SET 
            ESTADO=P_ESTADO , VALOR=P_VALOR WHERE ID=P_ID;
        END IF;
    END SP_CONF_AREA_OBJ_KPI;
 
    /*Procedimiento para guardar o editar la relacion entre CLIENTE, TIPO, FORMA DE PAGO y validacion*/
    PROCEDURE SP_CONF_CLIENTE_TIPO_FP(P_ID NUMBER DEFAULT NULL, P_INVERSIONTIPO NUMBER,
             P_CLIENTE NUMBER,P_TIPO NUMBER,P_FORMAPAGO NUMBER,P_ESTADO NUMBER, P_COMPANIA VARCHAR,
             P_IDVALIDACIONTIPO VARCHAR2, P_IDORIGEN NUMBER ) AS
    V_TABLA VARCHAR(50) := 'T_ICOM_CONF_CLIENTE_TIPO_FP';
    BEGIN 
         IF(P_ID IS NULL) THEN
            INSERT INTO data.T_ICOM_CONF_CLIENTE_TIPO_FP 
            (ID, idinversiontipo, CODIGOCLIENTE, IDTIPO, IDFORMAPAGO,  COMPANIA, 
            ESTADO, IDVALIDACIONTIPO, IDORIGEN ) VALUES 
            (data.PK_COMMONS.F_SECUENCIA (V_TABLA), P_INVERSIONTIPO,P_CLIENTE,P_TIPO,P_FORMAPAGO, P_COMPANIA,
            1,P_IDVALIDACIONTIPO, P_IDORIGEN  );
        ELSE
            UPDATE data.T_ICOM_CONF_CLIENTE_TIPO_FP SET 
            ESTADO=P_ESTADO  WHERE ID=P_ID;
        END IF;
    END SP_CONF_CLIENTE_TIPO_FP;
 
 
    /*Procedimiento para guardar o editar la relacion entre ANALISTA, INVERSION TIPO Y AREA*/
    PROCEDURE SP_CONF_ANALIST_INV_AREA(P_ID NUMBER DEFAULT NULL, P_INVERSIONTIPO NUMBER,
            P_USUARIO VARCHAR,P_AREA VARCHAR,P_ESTADO NUMBER, P_COMPANIA VARCHAR) AS
    V_TABLA VARCHAR(50) := 'T_ICOM_CONF_ANALIST_INV_AREA';
    BEGIN 
        IF(P_ID IS NULL) THEN
            INSERT INTO data.T_ICOM_CONF_ANALIST_INV_AREA 
            (ID, idinversiontipo, IDANALISTA, IDAREA, COMPANIA, ESTADO) VALUES 
            (data.PK_COMMONS.F_SECUENCIA (V_TABLA), P_INVERSIONTIPO,P_USUARIO,P_AREA, P_COMPANIA,1 );
        ELSE
            UPDATE data.T_ICOM_CONF_ANALIST_INV_AREA SET 
            ESTADO=P_ESTADO  WHERE ID=P_ID;
        END IF;
    END SP_CONF_ANALIST_INV_AREA;         
 
    /*Procedimiento para guardar o editar la relacion entre PROCESO Y ORIGEN*/
    PROCEDURE SP_CONF_PROCESO_ORIGEN(P_ID NUMBER DEFAULT NULL, P_PROCESO NUMBER, P_ORIGEN NUMBER, P_ESTADO NUMBER,P_COMPANIA VARCHAR) AS
    V_TABLA VARCHAR(50) := 'T_ICOM_CONF_PROCESO_ORIGEN';
    BEGIN
        IF(P_ID IS NULL) THEN
            INSERT INTO DATA.T_ICOM_CONF_PROCESO_ORIGEN 
            (ID, IDPROCESO, IDORIGEN, COMPANIA, ESTADO) VALUES 
            (DATA.PK_COMMONS.F_SECUENCIA (V_TABLA), P_PROCESO,P_ORIGEN,P_COMPANIA,1 );
        ELSE
            UPDATE DATA.T_ICOM_CONF_PROCESO_ORIGEN SET 
            ESTADO=P_ESTADO  WHERE ID=P_ID;
        END IF;
 
    END SP_CONF_PROCESO_ORIGEN;
 
   /*Guarda lista de precios que se sube por excel*/
    PROCEDURE SP_LISTAPRECIO_PVP(P_COMPANIA VARCHAR) AS
    BEGIN
 
        --DELETE DATA.T_ICOM_PRECIOS_PVP;
        --Se modifica para que no borre, si no existe inserta caso contrario actualiza
        MERGE INTO DATA.T_ICOM_PRECIOS_PVP PP
        USING ( SELECT TRIM(c02) codigobarra, TRIM(c03) codigocliente,
                        ROUND( REPLACE(nvl(c04,0), '.', ','),4) preciomayorista, 
                        ROUND( REPLACE(nvl(c05,0), '.', ','),4) preciominorista, 
                        ROUND( REPLACE(nvl(c06,0), '.', ','),4) preciosugeridoiva_s, 
                        ROUND( REPLACE(nvl(c07,0), '.', ','),4) preciosugeridoiva_c
                    FROM DATA.VT_APEX_EXCEL 
                    WHERE TRIM(c02) IS NOT NULL AND TRIM(c03) IS NOT NULL) DAT
        ON ( PP.CODIGOBARRA = DAT.CODIGOBARRA  AND PP.COMPANIA = P_COMPANIA AND PP.CODIGOCLIENTE = DAT.CODIGOCLIENTE )
        WHEN MATCHED THEN 
            UPDATE SET PP.PRECIOMAYORISTA = DAT.PRECIOMAYORISTA, PRECIOMINORISTA = DAT.PRECIOMINORISTA,
                       PP.PRECIOSUGERIDOIVA_S = DAT.PRECIOSUGERIDOIVA_S, PP.PRECIOSUGERIDOIVA_C = DAT.preciosugeridoiva_c
        WHEN NOT MATCHED THEN
            INSERT  (CODIGOBARRA, codiGocliente, preciomayorista,    preciominorista, 
                    preciosugeridoiva_s,    preciosugeridoiva_c,    compania) 
                    VALUES (DAT.CODIGOBARRA, trim(DAT.codigocliente), DAT.preciomayorista,    DAT.preciominorista, 
                    DAT.preciosugeridoiva_s,    DAT.preciosugeridoiva_c,    P_compania )  ;
                
    END;
 
    /*INGRESO INICIAL DE LA INVERSION COMERCIAL, GUARDA LA INFORMACION DE LA SECCION DATOS GENERALES
    PK_ICOM_CRUD.SP_INVERSION_GUARDAR
    */
    PROCEDURE SP_INVERSION_GUARDAR_GENERALES(P_ID IN OUT NUMBER, P_INVERSIONTIPO NUMBER DEFAULT NULL, P_GRUPAL NUMBER DEFAULT NULL, 
        P_NOMBRE VARCHAR DEFAULT NULL, P_AREA VARCHAR DEFAULT NULL, P_ANALISTA VARCHAR DEFAULT NULL, P_ANTECEDENTE CLOB DEFAULT NULL,
        P_PROBLEMAS VARCHAR DEFAULT NULL,P_OPORTUNIDADES VARCHAR DEFAULT NULL, P_USUARIO VARCHAR, P_COMPANIA VARCHAR,
        P_ORIGEN NUMBER DEFAULT NULL, P_TIPO NUMBER DEFAULT NULL, P_FECHA_INICIO DATE DEFAULT NULL, P_FECHA_FIN DATE DEFAULT NULL,
        P_CONFIDENCIAL VARCHAR DEFAULT NULL, P_ANALISISPERIODO VARCHAR DEFAULT NULL,
        P_ANALISISANIO NUMBER DEFAULT NULL,P_ANALISISVENTA VARCHAR DEFAULT NULL, P_ANALISISVISTA NUMBER DEFAULT NULL,
		P_GASTOAPLICACION NUMBER DEFAULT NULL, P_GASTOUNITARIO NUMBER DEFAULT NULL, P_GASTOCALCULO NUMBER DEFAULT NULL,
        P_SELLINCRECIMIENTO NUMBER DEFAULT NULL,  P_PRODUCTOTODO NUMBER DEFAULT NULL, P_EDITAR NUMBER DEFAULT 1, P_OBJETIVO CLOB DEFAULT NULL)
        AS
        V_TABLA VARCHAR(50) := 'T_ICOM_INVERSIONES';
        V_ETAPA_INICIAL NUMBER :=1;
        V_IDPADRE NUMBER;
        V_ESTADO NUMBER;
        
    BEGIN
        
        IF(P_ID IS NULL) THEN
            --NUEVA INVERSION
            P_ID := DATA.PK_COMMONS.F_SECUENCIA (V_TABLA);
            INSERT INTO DATA.T_ICOM_INVERSIONES (
            --DATOS GENERALES
            ID, IDINVERSIONTIPO, IDAREA, NOMBRE, IDANALISTA, IDETAPA, GRUPAL,
            ANTECEDENTES, PROBLEMA, OPORTUNIDAD, auditoriausuario, auditoriaFECHA, COMPANIA,
            --DATOS ESPECIFICOS
            IDORIGEN, IDTIPO ,FECHAINICIO , FECHAFIN ,CONFIDENCIAL, --COMENTARIO,
            --DATOS ANALISIS
            ANALISISPERIODO, ANALISISANIO,ANALISISVENTA,ANALISISVISTA,
			--DATOS GASTO VARIABLE
			GASTOCALCULO, GASTOAPLICACION, GASTOUNITARIO
			,SELLINCRECIMIENTO, DURACION, ESTADO, USUARIO, OBJETIVO
            )
            VALUES (
            --DATOS GENERALES
            P_ID, P_INVERSIONTIPO, P_AREA, UPPER(P_NOMBRE), P_ANALISTA, V_ETAPA_INICIAL,P_GRUPAL,
            P_ANTECEDENTE, P_PROBLEMAS, P_OPORTUNIDADES, P_USUARIO, SYSDATE,P_COMPANIA,
            --DATOS ESPECIFICOS
            P_ORIGEN, P_TIPO ,  P_FECHA_INICIO , P_FECHA_FIN , nvl(P_CONFIDENCIAL,0), --P_COMENTARIO,
            --DATOS ANALISIS
            P_ANALISISPERIODO, P_ANALISISANIO,P_ANALISISVENTA,P_ANALISISVISTA,
			--DATOS GASTO VARIABLE
			P_GASTOAPLICACION , P_GASTOUNITARIO , P_GASTOCALCULO
			,P_SELLINCRECIMIENTO,
            DATA.PK_ICOM_COMMONS.F_DURACION(P_FECHA_INICIO => P_FECHA_INICIO, P_FECHA_FIN => P_FECHA_FIN), 0, P_USUARIO,P_OBJETIVO
            );
            
            --crear la auditoria            
            PK_ICOM_COMMONS.SP_AUDITORIA(
                P_USUARIO => P_USUARIO,
                P_IDINVERSION => P_ID,
                P_IDETAPA => V_ETAPA_INICIAL,
                P_CODIGOGRUPO => null,
                P_IDACCION => 1,
                P_DESCRIPCION => 'CREAR UNA NUEVA INVERSION ID :'||P_ID 
              );
        ELSE
            IF(P_EDITAR=1) THEN
                --ACTUALIZACION DATA INVERSION 
                UPDATE DATA.T_ICOM_INVERSIONES SET
                --DATOS GENERALES
                IDAREA=P_AREA, IDANALISTA=P_ANALISTA, NOMBRE=UPPER(P_NOMBRE),
                /*ANTECEDENTES=P_ANTECEDENTE ,*/ PROBLEMA=P_PROBLEMAS,
                OPORTUNIDAD= P_OPORTUNIDADES, auditoriaFECHA=SYSDATE, auditoriausuario=P_USUARIO,
                --DATOS ESPECIFICOS
                IDORIGEN=P_ORIGEN, IDTIPO=P_TIPO, FECHAINICIO=P_FECHA_INICIO,
                FECHAFIN=P_FECHA_FIN, CONFIDENCIAL=nvl(P_CONFIDENCIAL,0), --COMENTARIO=P_COMENTARIO, 
                DURACION= DATA.PK_ICOM_COMMONS.F_DURACION(P_FECHA_INICIO => P_FECHA_INICIO, P_FECHA_FIN => P_FECHA_FIN),
                --DATA ANALISIS
                ANALISISPERIODO=P_ANALISISPERIODO, ANALISISANIO=P_ANALISISANIO,
                ANALISISVENTA=P_ANALISISVENTA,ANALISISVISTA=P_ANALISISVISTA,   
                --DATOS GASTO VARIABLE
                GASTOAPLICACION=P_GASTOAPLICACION , GASTOUNITARIO=P_GASTOUNITARIO,
                GASTOCALCULO=P_GASTOCALCULO, SELLINCRECIMIENTO=P_SELLINCRECIMIENTO,PRODUCTOTODO=P_PRODUCTOTODO,OBJETIVO=P_OBJETIVO
                WHERE ID=P_ID;
                
                 --ACTUALIZO INFROMACION DE HIJAS
                UPDATE DATA.T_ICOM_INVERSIONES SET 
                 PROBLEMA=P_PROBLEMAS, OPORTUNIDAD=P_OPORTUNIDADES,OBJETIVO=P_OBJETIVO
                ,IDAREA=P_AREA, IDANALISTA=P_ANALISTA
                WHERE IDGRUPO=P_ID;   
                
            ELSE 
                
                
                UPDATE DATA.T_ICOM_INVERSIONES SET
                PROBLEMA=P_PROBLEMAS,NOMBRE = UPPER(P_NOMBRE), OBJETIVO = P_OBJETIVO,
                OPORTUNIDAD= P_OPORTUNIDADES, auditoriaFECHA=SYSDATE, auditoriausuario=P_USUARIO
                WHERE ID=P_ID;
                
                --ACTUALIZO INFROMACION DE HIJAS
                UPDATE DATA.T_ICOM_INVERSIONES SET 
                 PROBLEMA=P_PROBLEMAS, OPORTUNIDAD=P_OPORTUNIDADES,OBJETIVO = P_OBJETIVO WHERE IDGRUPO=P_ID;
               
               SELECT estado INTO v_estado FROM DATA.T_ICOM_INVERSIONES WHERE ID=P_ID;
               
               if v_estado = 2 then
                    --inversion en ruta
                    for dato in (select id, idetapa from data.t_icom_inversiones where id = p_id or idgrupo = p_id) loop
                        --MODIFICAR EN RUTA auditoria            
                        PK_ICOM_COMMONS.SP_AUDITORIA(
                                P_USUARIO => P_USUARIO,
                                P_IDINVERSION => dato.id,
                                P_IDETAPA => dato.idetapa,
                                P_CODIGOGRUPO => null,
                                P_IDACCION => 3,
                                P_DESCRIPCION => 'SE ACTUALIZA LA INFORMACION DE LA INVERSION EN RUTA '    );
                   end loop;             
               end if;
            END IF;
            
        END IF;
        
        
        SELECT IDGRUPO INTO V_IDPADRE FROM DATA.T_ICOM_INVERSIONES WHERE ID=P_ID;
  
         IF(P_EDITAR=1) THEN
          -- ACTUALIZO FECHA DEL PADRE
            UPDATE DATA.T_ICOM_INVERSIONES SET 
            (FECHAINICIO, FECHAFIN) =(SELECT MIN(FECHAINICIO), MAX(FECHAFIN) FROM DATA.T_ICOM_INVERSIONES WHERE IDGRUPO=V_IDPADRE)
            WHERE ID=V_IDPADRE;
            
            UPDATE DATA.T_ICOM_INVERSIONES SET 
            DURACION = DATA.PK_ICOM_COMMONS.F_DURACION(P_FECHA_INICIO => FECHAINICIO, P_FECHA_FIN => FECHAFIN)
            WHERE ID=V_IDPADRE;   
         END IF;   
        
    END SP_INVERSION_GUARDAR_GENERALES;        
 
    /*INGRESA LOS PROCESOS OPERATIVOS PARA UNA INVERSION
    PK_ICOM_CRUD.SP_INVERSION_GUARDAR_PROCESO(P_ID =>P_ID,P_ORIGEN =>P_ORIGEN, P_COMPANIA =>P_COMPANIA);
    */
    PROCEDURE SP_INVERSION_GUARDAR_PROCESO(P_ID NUMBER,P_ORIGEN NUMBER, P_COMPANIA VARCHAR) AS
    BEGIN 
 
        DELETE DATA.T_ICOM_INVERSION_PROCESO WHERE IDINVERSION=P_ID;        
 
        INSERT INTO DATA.T_ICOM_INVERSION_PROCESO  (IDINVERSION, IDPROCESO, ESTADO)
        SELECT P_ID, IDPROCESO, 0 FROM DATA.T_ICOM_CONF_PROCESO_ORIGEN WHERE IDORIGEN=P_ORIGEN AND COMPANIA=P_COMPANIA and ESTADO=1;
 
    END SP_INVERSION_GUARDAR_PROCESO; 
 
    /*AGREGA PRODUCTO REGALO DESDE UN ARCCHIVO EXCEL */
     PROCEDURE SP_PRODUCTOREGALOAGREGAR(P_ID NUMBER,  P_COMPANIA VARCHAR, P_TIPO NUMBER default 2) AS
        V_CODIGOS   apex_application_global.vc_arr2; 
        V_PRODUCTOS VARCHAR(2500);
        V_CUENTA NUMBER;
     BEGIN 
        
        if P_TIPO = 3 then --materia prima
            --valida que los productos sean materia prima
            select count(1) into v_cuenta 
              from DATA.VT_APEX_EXCEL V
             where TRIM(C02) IS NOT NULL 
               and not EXISTS (select p.codigoproducto from data.VT_GZM_PRODUCTO p 
                                WHERE p.COMPANIA=P_COMPANIA AND p.codigoproducto = trim(C02) and TEXTOBUSQUEDA  like 'MATERIA PRIMA' );
            if nvl(v_cuenta,0) > 0 then
                raise_application_error(-20100, 'Error existen productos en el archivo que no son Materia Prima.'); 
            end if;
        end if;
        DELETE DATA.T_ICOM_INVERSION_PRODUCTO WHERE IDINVERSION=P_ID AND  TIPO=P_TIPO ;
        DELETE DATA.T_ICOM_PRODUCTO_CANTIDAD  WHERE IDINVERSION=P_ID AND  TIPO=P_TIPO ;
        
        select DISTINCT TRIM(C02) bulk collect  INTO V_CODIGOS FROM DATA.VT_APEX_EXCEL 
        WHERE TRIM(C02) IS NOT NULL;
            
        V_PRODUCTOS  := apex_util.table_to_string (p_table => V_CODIGOS, p_string => ':'); 
        
        SP_PRODUCTOAGREGAR(P_ID =>P_ID,
                            P_PRODUCTO =>V_PRODUCTOS,
                            P_ALCANCE =>'P', 
                            P_TIPO =>P_TIPO,
                            P_COMPANIA =>P_COMPANIA);     
                                    
       FOR PRODUCTO IN (SELECT TRIM(C02) CODIGO, to_date('1899-12-30', 'YYYY-MM-DD') + C04 FECHA,  ROUND(REPLACE(c05, '.', ','),2) CANTIDAD 
                                               FROM DATA.VT_APEX_EXCEL WHERE TRIM(C02) IS NOT NULL) LOOP
    
                    UPDATE DATA.T_ICOM_PRODUCTO_CANTIDAD SET CANTIDAD=PRODUCTO.CANTIDAD 
                    WHERE IDINVERSION=P_ID AND CODIGOPRODUCTO=PRODUCTO.CODIGO AND  
                    TIPO=P_TIPO AND TRUNC(FECHA)=TRUNC(PRODUCTO.FECHA); 
        END LOOP;
     
     END SP_PRODUCTOREGALOAGREGAR; 
 
    /*AGREGAR PRODUCTOS SELECCIONADOS
    PK_ICOM_CRUD.SP_PRODUCTOAGREGAR(P_ID =>P_ID,P_PRODUCTO =>P_PRODUCTO, P_ALCANCE =>P_ALCANCE, P_COMPANIA =>P_COMPANIA);
    */
   PROCEDURE SP_PRODUCTOAGREGAR(P_ID NUMBER, P_PRODUCTO VARCHAR, P_ALCANCE VARCHAR, 
   P_COMPANIA VARCHAR, P_TIPO NUMBER DEFAULT 1, P_ANALISIS_R NUMBER DEFAULT 1) AS
   BEGIN 
        
        IF(P_ALCANCE IS NOT NULL) THEN 
            MERGE INTO DATA.T_ICOM_INVERSION_PRODUCTO producto 
            USING (SELECT CODIGOPRODUCTO, NOMBREPRODUCTO, LINEANEGOCIO, MARCA, SUBMARCA, CODIGOBARRA, CODIGOPRODUCTOPADRE 
                    FROM VT_GZM_PRODUCTO  WHERE COMPANIA=P_COMPANIA --AND ESTADO=1
                        AND (
                            (P_ALCANCE = 'P' AND CODIGOPRODUCTO IN (SELECT Column_Value  FROM TABLE(Apex_String.Split(P_PRODUCTO, ':'))))
                            OR (P_ALCANCE = 'S' AND CODIGOSUBMARCA IN (SELECT Column_Value  FROM TABLE(Apex_String.Split(P_PRODUCTO, ':'))))
                            OR (P_ALCANCE = 'M' AND CODIGOMARCA IN (SELECT Column_Value  FROM TABLE(Apex_String.Split(P_PRODUCTO, ':'))))
                            OR (P_ALCANCE = 'L' AND CODIGOLINEA IN (SELECT Column_Value  FROM TABLE(Apex_String.Split(P_PRODUCTO, ':'))))
                        )
                    ) linea
            ON (producto.IDINVERSION=P_ID AND linea.CODIGOPRODUCTO=producto.CODIGOPRODUCTO AND producto.tipo=P_TIPO ) 
             WHEN NOT MATCHED THEN
                INSERT(producto.IDINVERSION,producto.CODIGOPRODUCTO, producto.PRODUCTO,producto.tipo, producto.NUEVO,
                producto.LINEANEGOCIO,producto.MARCA,producto.SUBMARCA, producto.CODIGOBARRA, producto.CODIGOPRODUCTOPADRE)
                VALUES(P_ID,linea.CODIGOPRODUCTO,linea.NOMBREPRODUCTO,P_TIPO, 0,
                LINEA.LINEANEGOCIO, LINEA.MARCA, LINEA.SUBMARCA, linea.CODIGOBARRA, linea.CODIGOPRODUCTOPADRE);
            commit;
        END IF;
 
 
        IF(P_TIPO in (2,3)) THEN 
           FOR PRODUCTO IN (SELECT CODIGOPRODUCTO FROM DATA.T_ICOM_INVERSION_PRODUCTO  
                WHERE IDINVERSION=P_ID  AND  TIPO=P_TIPO) LOOP
 
                SP_PRODUCTOCANTIDADES(P_ID, PRODUCTO.CODIGOPRODUCTO, P_TIPO);
 
           END LOOP;
        END IF;
        
        IF(P_ANALISIS_R=1) THEN 
            DATA.PK_ICOM_ANALISIS.SP_REINICIARANALISIS(P_ID);
        END IF;
 
   END SP_PRODUCTOAGREGAR; 
 
   /*AGREGAR PRODUCTOS NUEVO
    PK_ICOM_CRUD.SP_PRODUCTONUEVO(P_ID =>P_ID,P_PRODUCTO =>P_PRODUCTO);
    */
  PROCEDURE SP_PRODUCTONUEVO(P_ID NUMBER, P_PRODUCTO VARCHAR, P_TIPO NUMBER default 1) AS
  V_TABLA VARCHAR(50) := 'T_ICOM_INVERSION_PRODUCTO';
  v_codigo number ;
  BEGIN 
        v_codigo :=  DATA.PK_COMMONS.F_SECUENCIA (V_TABLA) ;
        INSERT INTO DATA.T_ICOM_INVERSION_PRODUCTO (IDINVERSION, CODIGOPRODUCTO,PRODUCTO, TIPO, NUEVO)
                                        VALUES (P_ID,v_codigo,P_PRODUCTO, P_TIPO, 1);
        
        --En el caso de ser materia prima inserta el producto cantidad
        IF(P_TIPO in (2,3)) THEN 
            SP_PRODUCTOCANTIDADES(P_ID, v_codigo, P_TIPO);
        END IF;                                        
  END SP_PRODUCTONUEVO;  
 
 
  /*ELIMINA UN PRODUCTO Y SUS CANTIDADES
    PK_ICOM_CRUD.SP_PRODUCTOCANTIDADES(P_ID =>P_ID,P_PRODUCTO =>P_PRODUCTO, P_TIPO=>P_TIPO);
    */
  PROCEDURE SP_PRODUCTOCANTIDADES(P_ID NUMBER, P_PRODUCTO VARCHAR, P_TIPO NUMBER) AS
  V_CONTADOR NUMBER :=0;
  V_FECHADESDE DATE;
  V_FECHAHASTA DATE;
  BEGIN
    SELECT COUNT(1) INTO V_CONTADOR FROM DATA.T_ICOM_PRODUCTO_CANTIDAD 
    WHERE IDINVERSION=P_ID AND CODIGOPRODUCTO=P_PRODUCTO AND  TIPO=P_TIPO;
 
    IF(V_CONTADOR= 0) THEN 
        SELECT FECHAINICIO, FECHAFIN INTO V_FECHADESDE, V_FECHAHASTA
            FROM DATA.T_ICOM_INVERSIONES WHERE ID =P_ID;
 
        INSERT INTO DATA.T_ICOM_PRODUCTO_CANTIDAD    
        SELECT P_ID, P_PRODUCTO, P_TIPO, TRUNC(add_months (V_FECHADESDE,  level - 1)) as FECHA, 0  from   dual  
        connect by level <= months_between (V_FECHAHASTA, V_FECHADESDE) + 1;    
 
    END IF;
 
  END SP_PRODUCTOCANTIDADES; 
 
  /*AGREGA CLIENTES
    PK_ICOM_CRUD.SP_CLIENTEAGREGAR(P_ID =>P_ID,P_CLIENTE =>P_CLIENTE, P_ALCANCE=>P_ALCANCE, P_COMPANIA =>P_COMPANIA, P_ANALISIS=>0);
    */
  PROCEDURE SP_CLIENTEAGREGAR(P_ID NUMBER, P_CLIENTE VARCHAR, P_ALCANCE VARCHAR, 
  P_COMPANIA VARCHAR, P_ANALISIS NUMBER DEFAULT 1)
  AS
  V_FECHAINICIO DATE;
  V_FECHAFIN DATE;
  V_INVERSIONTIPO VARCHAR(5);
  V_FORMAPAGO VARCHAR(5);
  V_TIPO VARCHAR(5);
  V_IDORIGEN NUMBER;
  
  BEGIN 
        IF(P_ALCANCE IS NOT NULL) THEN 
        
        IF(P_ANALISIS=1) THEN 
            DATA.PK_ICOM_ANALISIS.SP_REINICIARANALISIS(P_ID);
        END IF;
        
        SELECT FECHAINICIO, FECHAFIN, IDINVERSIONTIPO , IDTIPO, IDORIGEN 
            INTO  V_FECHAINICIO, V_FECHAFIN, V_INVERSIONTIPO , V_TIPO, V_IDORIGEN
            FROM DATA.T_ICOM_INVERSIONES WHERE ID=P_ID;
 
        ---GUARDA GRUPO CLIENTE
            MERGE INTO DATA.T_ICOM_INVERSION_CLIENTE_G CLIENTE 
            USING (SELECT CODIGOGRUPO,GRUPO NOMBRES,
                    ( SELECT CODIGOCANAL FROM VT_GZM_CLIENTE B  WHERE 
                    B.CODIGOGRUPO=B.CODIGOCLIENTE AND G.CODIGOGRUPO=B.CODIGOGRUPO AND B.COMPANIA=P_COMPANIA) CODIGOCANAL
                            FROM DATA.VT_GZM_CLIENTE  G WHERE COMPANIA=P_COMPANIA 
                               --AND ESTADO=1
                                AND (
                                (P_ALCANCE = 'C' AND CODIGOCANAL IN (SELECT Column_Value   FROM TABLE(Apex_String.Split(P_CLIENTE, ':'))))
                                OR (P_ALCANCE = 'G' AND CODIGOGRUPO IN (SELECT Column_Value  FROM TABLE(Apex_String.Split(P_CLIENTE, ':'))))
                                OR (P_ALCANCE = 'CL' AND CODIGOCLIENTE IN (SELECT Column_Value   FROM TABLE(Apex_String.Split(P_CLIENTE, ':'))))
                                ) 
                                GROUP BY CODIGOGRUPO,GRUPO) GRUPO
            ON (CLIENTE.IDINVERSION=P_ID AND GRUPO.CODIGOGRUPO=CLIENTE.CODIGOGRUPO ) 
             WHEN NOT MATCHED THEN
                ---BUSCAR CATEGORIA, EN EL CASO QUE NO ENCUENTRE DEBE PONER EL MISMO NOMBRE DEL CLIENTE 
                INSERT(CLIENTE.IDINVERSION,CLIENTE.CODIGOCANAL, CLIENTE.CODIGOGRUPO,CLIENTE.NOMBRES,
                CLIENTE.CATEGORIA, CLIENTE.FECHAINICIO, CLIENTE.FECHAFIN,
                CLIENTE.IDFORMAPAGO)
                VALUES(P_ID,GRUPO.CODIGOCANAL,GRUPO.CODIGOGRUPO,GRUPO.NOMBRES,
                data.PK_ICOM_CRUD.F_CLIENTECATEGORIA(P_COMPANIA,P_CLIENTE=>GRUPO.CODIGOGRUPO),
                V_FECHAINICIO+PK_ICOM_CRUD.F_DIASPECHA( P_CODIGOCANAL => GRUPO.CODIGOCANAL, P_IDORIGEN => V_IDORIGEN, P_IDTIPO => V_TIPO, P_CODIGOGRUPO => GRUPO.CODIGOGRUPO), 
                V_FECHAFIN+PK_ICOM_CRUD.F_DIASPECHA( P_CODIGOCANAL => GRUPO.CODIGOCANAL, P_IDORIGEN => V_IDORIGEN, P_IDTIPO => V_TIPO, P_CODIGOGRUPO => GRUPO.CODIGOGRUPO),
                DATA.PK_ICOM_COMMONS.F_FORMAPAGO(P_INVERSIONTIPO => V_INVERSIONTIPO, P_TIPO => V_TIPO, P_CLIENTE=>GRUPO.CODIGOGRUPO,
                                                 P_COMPANIA=>P_COMPANIA, P_IDORIGEN => V_IDORIGEN ));
 
 
 
 
  MERGE INTO DATA.T_ICOM_INVERSION_CLIENTE CLIENTE 
            USING (SELECT CODIGOGRUPO, CODIGOCLIENTE 
                            FROM DATA.VT_GZM_CLIENTE  G WHERE COMPANIA=P_COMPANIA --AND ESTADO=1
                                AND (
                                (P_ALCANCE = 'C' AND CODIGOCANAL IN (SELECT Column_Value   FROM TABLE(Apex_String.Split(P_CLIENTE, ':'))))
                                OR (P_ALCANCE = 'G' AND CODIGOGRUPO IN (SELECT Column_Value  FROM TABLE(Apex_String.Split(P_CLIENTE, ':'))))
                                OR (P_ALCANCE = 'CL' AND CODIGOCLIENTE IN (SELECT Column_Value   FROM TABLE(Apex_String.Split(P_CLIENTE, ':'))))
                                )  ) GRUPO
            ON (CLIENTE.IDINVERSION=P_ID AND GRUPO.CODIGOCLIENTE=CLIENTE.CODIGOCLIENTE ) 
             WHEN NOT MATCHED THEN
                ---BUSCAR CATEGORIA, EN EL CASO QUE NO ENCUENTRE DEBE PONER EL MISMO NOMBRE DEL CLIENTE 
                INSERT(CLIENTE.IDINVERSION, CLIENTE.CODIGOGRUPO,CLIENTE.CODIGOCLIENTE)
                VALUES(P_ID,GRUPO.CODIGOGRUPO,GRUPO.CODIGOCLIENTE);
 
 
 
        END IF;
 
  END SP_CLIENTEAGREGAR; 
      
    PROCEDURE SP_CLIENTEVACIAR(P_ID NUMBER) AS
    BEGIN 
        DELETE DATA.T_ICOM_INVERSION_CLIENTE_G WHERE IDINVERSION=P_ID;
        DELETE DATA.T_ICOM_INVERSION_CLIENTE WHERE IDINVERSION=P_ID;
        DELETE DATA.T_ICOM_CLIENTE_PDV_LOCAL WHERE IDINVERSION=P_ID;
        DATA.PK_ICOM_ANALISIS.SP_REINICIARANALISIS(P_ID); 
        
    END SP_CLIENTEVACIAR; 
 
    /*Proceso que verifica en caso de que se haya elminado algun grupo eliminar los pdv locales */
    PROCEDURE SP_COMPROBARLOCAL(P_ID NUMBER) AS
    BEGIN
        delete from data.t_icom_cliente_pdv_local
        where idinversion = p_id 
        and codigogrupo not in ( select codigogrupo from data.t_icom_inversion_cliente_g where idinversion = p_id);
    END SP_COMPROBARLOCAL ;
   /*
   Procedimiento que crea una agrupaciÃ³n de una inversiÃ³n existente.
   La informaciÃ³n se almacena en la tabla T_ICOM_INVERSIONES
   Por: Christian Carrasco
   Fecha: 20220615
   */
   PROCEDURE SP_GRUPOAGREGAR(
		P_ID IN OUT NUMBER, P_INVERSIONTIPO NUMBER, P_IDPADRE NUMBER,
		P_GRUPAL NUMBER, P_NOMBRE VARCHAR, P_AREA VARCHAR, 
		P_ANALISTA VARCHAR, P_ANTECEDENTE CLOB,P_PROBLEMAS VARCHAR,
		P_OPORTUNIDADES VARCHAR, P_USUARIO VARCHAR,P_COMPANIA VARCHAR,
		P_ORIGEN NUMBER, P_TIPO NUMBER, P_FECHA_INICIO DATE, 
		P_FECHA_FIN DATE, P_CONFIDENCIAL VARCHAR, P_ANALISISVISTA NUMBER,
        P_OBJETIVO CLOB DEFAULT NULL
		) AS
		-- obtiene secuencial para la tabla 
		V_TABLA VARCHAR(50) := 'T_ICOM_INVERSIONES';
		V_ETAPA_INICIAL NUMBER :=1;
        V_ANTECEDENTES CLOB;
        V_PERIODO VARCHAR(50) ;
        V_ANIO_ANALISIS VARCHAR(50) ; 
        V_TIPO_GRAFICO VARCHAR(50) ;
	BEGIN
 
			P_ID :=data.PK_COMMONS.F_SECUENCIA (V_TABLA);
 
            SELECT descripcion2,valor,valor2
            into V_PERIODO,V_ANIO_ANALISIS,V_TIPO_GRAFICO
            FROM data.T_CORP_UDC where ID_CABECERA ='ICOM_TINV'
            and id_tabla = P_INVERSIONTIPO;
 
            SELECT ANTECEDENTES INTO V_ANTECEDENTES FROM  DATA.T_ICOM_INVERSIONES WHERE ID=P_IDPADRE;
            
			INSERT INTO data.T_ICOM_INVERSIONES (
			--DATOS GENERALES
			ID, IDGRUPO, IDINVERSIONTIPO, IDAREA, NOMBRE, IDANALISTA, IDETAPA, GRUPAL,
			ANTECEDENTES, PROBLEMA, OPORTUNIDAD, auditoriausuario, auditoriaFECHA, COMPANIA,
			--DATOS ESPECIFICOS
			IDORIGEN, IDTIPO ,FECHAINICIO , FECHAFIN ,CONFIDENCIAL, ESTADO, USUARIO,
            -- ANALISIS VENTA 
             ANALISISPERIODO, ANALISISANIO,ANALISISVISTA,OBJETIVO
			)
			VALUES (
			--DATOS GENERALES
			P_ID, P_IDPADRE,P_INVERSIONTIPO, P_AREA, P_NOMBRE, P_ANALISTA, V_ETAPA_INICIAL,P_GRUPAL,
			V_ANTECEDENTES, P_PROBLEMAS, P_OPORTUNIDADES, P_USUARIO, SYSDATE,P_COMPANIA,
			--DATOS ESPECIFICOS
			P_ORIGEN, P_TIPO ,  P_FECHA_INICIO , P_FECHA_FIN , nvl(P_CONFIDENCIAL,0), 0, P_USUARIO,
             -- ANALISIS VENTA 
             V_PERIODO,V_ANIO_ANALISIS,V_TIPO_GRAFICO,P_OBJETIVO
			);
            
            --crear la auditoria            
            PK_ICOM_COMMONS.SP_AUDITORIA(
                P_USUARIO => P_USUARIO,
                P_IDINVERSION => P_ID,
                P_IDETAPA => V_ETAPA_INICIAL,
                P_CODIGOGRUPO => null,
                P_IDACCION => 1,
                P_DESCRIPCION => 'CREAR UNA NUEVA AGRUPACION DE UNA INVERSION EXISTENTE CUYO IDPADRE ES:'||P_IDPADRE
              );
	END SP_GRUPOAGREGAR;  
 
  
 
	/*
	Procedimiento que permite la ingesta masiva de informacion de Puntos de Venta a la tabla T_ICOM_CLIENTE_PDV
	Por: CCarrasco
	Fecha: 20220621
	*/
	PROCEDURE SP_PDVAGREGAR(P_ID NUMBER, P_PDV VARCHAR, P_ALCANCE VARCHAR, P_COMPANIA VARCHAR, P_USUARIO VARCHAR2 ) AS
	V_TABLA VARCHAR(50) := 'T_ICOM_CLIENTE_PDV';
	V_CODIGOPDV 	DATA.T_ICOM_CLIENTE_PDV.CODIGOPDV%TYPE;
    V_FECHAINICIO   DATA.T_ICOM_INVERSIONES.FECHAINICIO%TYPE;
    V_FECHAFIN      DATA.T_ICOM_INVERSIONES.FECHAFIN%TYPE;
    V_INVERSIONTIPO DATA.T_ICOM_INVERSIONES.IDINVERSIONTIPO%TYPE;
    V_TIPO          DATA.T_ICOM_INVERSIONES.IDTIPO%TYPE;
    V_CODIGOS       DATA.T_ICOM_CLIENTE_PDV.CODIGOGRUPO%type;
	BEGIN 
		    V_CODIGOPDV := data.PK_COMMONS.F_SECUENCIA (V_TABLA);
            
			SELECT FECHAINICIO, FECHAFIN, IDINVERSIONTIPO , IDTIPO
			INTO  V_FECHAINICIO, V_FECHAFIN, V_INVERSIONTIPO , V_TIPO
			FROM DATA.T_ICOM_INVERSIONES WHERE ID=P_ID;
 
			-- BUSCA LOS PUNTO DE VENTA EN T_TRAD_CLIENTE E INSERTA EN T_ICOM_CLIENTE_PDV	
				MERGE INTO DATA.T_ICOM_CLIENTE_PDV PDV
                USING (SELECT TTC.CODIGOGRUPO,TTC.CODIGOPDV                                
                        FROM DATA.T_TRAD_CLIENTE TTC  WHERE TTC.COMPANIA=P_COMPANIA
                        AND TTC.CODIGOPDV IN (SELECT trim(Column_Value) FROM TABLE(Apex_String.Split(P_PDV, ':')))        
                        ) CLIPDV
                ON (PDV.IDINVERSION=P_ID and PDV.CODIGOPDV=CLIPDV.CODIGOPDV)
                 WHEN NOT MATCHED THEN
                    insert(IDINVERSION, CODIGOPDV, FECHAINICIO,FECHAFIN,	ESTADO,NUMEROCONTRATO)
					values ( P_ID, CLIPDV.CODIGOPDV,V_FECHAINICIO,V_FECHAFIN, 1, V_CODIGOPDV);
                    
			--Guardar los rucs activos de la tabla T_TRAD_CLIENTE_RUC a la tabla T_ICOM_CLIENTE_PDV_RUCS
           /* INSERT INTO T_ICOM_CLIENTE_PDV_RUCS 
            (codigopdv, ruc, auditoriafecha, auditoriausuario, idinversion )
            select CODIGOPDV, RUC, sysdate, P_USUARIO, P_ID 
            from T_TRAD_CLIENTERUC 
            where sysdate between fechadesde and nvl(fechahasta, sysdate)
            and estado = 1 
            and CODIGOPDV in ( SELECT trim(Column_Value) FROM TABLE(Apex_String.Split(P_PDV, ':')) ) ; */
 
   --EXCEPTION WHEN OTHERS THEN
		--raise_application_error(-20100, 'Error en proceso Puntos de Venta - SP_PDVAGREGAR');      
   END SP_PDVAGREGAR; 
	/*
	Funcion que retorna la categoria de un cliente
	Por: CCarrasco
	Fecha: Julio 2022
	*/
   FUNCTION F_CLIENTECATEGORIA(P_COMPANIA VARCHAR, P_CLIENTE VARCHAR) RETURN VARCHAR
    AS
        V_CATEGORIA  DATA.VT_GZM_CLIENTE.CANAL%TYPE;
    BEGIN
		BEGIN
			SELECT DECODE(CODIGOCANAL, 'C02','POTOTIN', TRIM(GRUPO)) 
			INTO V_CATEGORIA
			FROM  DATA.VT_GZM_CLIENTE
			WHERE CODIGOCLIENTE=CODIGOGRUPO 
			AND CODIGOCLIENTE=P_CLIENTE
			AND COMPANIA = P_COMPANIA;
		EXCEPTION WHEN NO_DATA_FOUND THEN
			V_CATEGORIA:=' ';
		when others then	
			V_CATEGORIA:=' ';
		END;
		RETURN V_CATEGORIA;
    END F_CLIENTECATEGORIA;   
 
	
	/*
	Procedimiento que duplica la inversion segÃºn especificaciones
	Por: CCarrasco Modificado: JAsanza
	Fecha: Octubre 2022
    P_ID ID DE INVERSION A COPIAR
    P_ID_NEW NUEVO ID GENERADO en caso de ser nulo
    P_NUEVO BANDERA QUE INDICA SI ES UNA COPIA EXACTA 0 O COPIA QUE INICIA COMO BORRADOR 1
    P_PADRE BANDERA QUE INDICA SI VA DENTRO DEL PADRE O NO.
 	*/
 
	PROCEDURE SP_PRO_COPIAR(P_ID NUMBER, P_ID_NEW IN OUT NUMBER, p_usuario varchar2, 
    P_NUEVO NUMBER DEFAULT 0, P_PADRE NUMBER DEFAULT 0) AS
	V_ID NUMBER;
	V_TABLA VARCHAR(50) := 'T_ICOM_INVERSIONES';
    v_idnew data.t_icom_inversiones.id%type;
    
	BEGIN
        if p_id_new is null then
            V_ID := DATA.PK_COMMONS.F_SECUENCIA (V_TABLA);
            P_ID_NEW:=V_ID;
        else
            V_ID := P_ID_NEW ;
        end if;
        INSERT INTO DATA.t_icom_inversiones 
        (id,    idgrupo,    idinversiontipo,    idetapa,
        idetapa2,    idorigen,    idtipo,    idobjetivo,
        idarea,    grupal,    idanalista,    nombre, antecedentes,
        problema,    oportunidad,    fechainicio,    fechafin,
        duracion,    confidencial,    auditoriausuario,    auditoriafecha,
        alcanceproducto,    alcancecliente,    analisisperiodo,    analisisanio,
        analisisvista,    analisisventa,    compania,    ruta,
        estado,    motivoclausura,    gastocalculo,    gastoaplicacion,
        gastounitario,    sellin,    sellinund,    sellincosto,
        sellincrecimiento,    sellout,    selloutund, productotodo, usuario,
        replanificacionmotivo, replanificaciondescripcion, regalocrecimiento, regaloaplicacion, 
        estadocierre, cierretipo, cierrenivel, fechaanalisis, situacionactualmes, sellinreal, sellinundreal, sellincostoreal, 
        selloutreal, selloutundreal, selloutcostoreal, repetir, cierreobservacion, margenbrutoestandar, 
        motivocambiomargen, ventaundmeta, ventausdmeta, comentario, comentariocierre, vistapedido )
        SELECT V_ID, CASE WHEN (P_PADRE=1 OR P_NUEVO=0) THEN IDGRUPO ELSE NULL END IDGRUPO,
            IDINVERSIONTIPO, decode(p_nuevo, 0, IDETAPA, 1) IDETAPA, decode(p_nuevo, 0, IDETAPA2, NULL) IDETAPA2,
            IDORIGEN,IDTIPO,IDOBJETIVO,IDAREA,GRUPAL,
            IDANALISTA,NOMBRE,ANTECEDENTES,PROBLEMA,OPORTUNIDAD,
            FECHAINICIO,FECHAFIN,DURACION,CONFIDENCIAL, p_usuario,
            sysdate,ALCANCEPRODUCTO,ALCANCECLIENTE,ANALISISPERIODO,ANALISISANIO,
            ANALISISVISTA,ANALISISVENTA,COMPANIA,RUTA,
            decode(p_nuevo, 0, estado, 0) ESTADO,MOTIVOCLAUSURA,GASTOCALCULO,GASTOAPLICACION,GASTOUNITARIO,SELLIN,
            SELLINUND,SELLINCOSTO,SELLINCRECIMIENTO,SELLOUT,SELLOUTUND, productotodo, decode(p_nuevo, 0, usuario, p_usuario)  ,
            replanificacionmotivo, replanificaciondescripcion, regalocrecimiento, regaloaplicacion, 
            estadocierre, cierretipo, cierrenivel, fechaanalisis, situacionactualmes, sellinreal, sellinundreal, sellincostoreal, 
            selloutreal, selloutundreal, selloutcostoreal, repetir, cierreobservacion, margenbrutoestandar, 
            motivocambiomargen, ventaundmeta, ventausdmeta, comentario, comentariocierre, vistapedido
        FROM DATA.t_icom_inversiones	
        WHERE ID =P_ID;			
		--commit;
        
        --crear la auditoria            
        PK_ICOM_COMMONS.SP_AUDITORIA(
            P_USUARIO => p_usuario,
            P_IDINVERSION => V_ID,
            P_IDETAPA => null,
            P_CODIGOGRUPO => null,
            P_IDACCION => 1,
            P_DESCRIPCION => 'CREAR UNA NUEVA INVERSION QUE COPIA LA INVERSION '||P_ID 
          );
        
        INSERT INTO "DATA"."T_ICOM_INVERSION_ANALISIS" 
        (IDINVERSION, ANALISISTIPO, TIPO, PERIODO, fecha, VALOR, VALORUND, VALORCOSTO, SELECCION, TIPO1, orden) 
        select V_ID, ANALISISTIPO, TIPO, PERIODO, fecha, VALOR, VALORUND, VALORCOSTO, SELECCION, TIPO1, orden
        from "DATA"."T_ICOM_INVERSION_ANALISIS" 
        where IDINVERSION = P_ID;		
 
        INSERT INTO "DATA"."T_ICOM_INVERSION_CLIENTE_G" 
            (IDINVERSION, CODIGOCANAL, NOMBRES, CODIGOGRUPO, CATEGORIA, FECHAINICIO, FECHAFIN, FECHAINICIO_R, FECHAFIN_R, 
            IDFORMAPAGO,SELLOUT, SELLOUTUND,   SELLIN, SELLINUND, 
            SELLOUTCRECIMIENTO, SELLOUTCRECIMIENTOUND, 
            SELLINCRECIMIENTO, GASTOCOMPARTIDO, FECHAGESTION, USUARIOGESTION, IDTIPORECONOCIMIENTO, OBSERVACION, 
            MOTIVORECHAZO, NEGOCIACION, ESTADO, CONTRATOREPRESENTANTE, CONTRATOCORREO,
            FECHACONTRATO, SELLINREAL, SELLINUNDREAL, SELLOUTREAL, SELLOUTUNDREAL ) 
            select V_ID, CODIGOCANAL, NOMBRES, CODIGOGRUPO, CATEGORIA, FECHAINICIO, FECHAFIN, FECHAINICIO_R, FECHAFIN_R, 
            IDFORMAPAGO, SELLOUT, SELLOUTUND,   SELLIN, SELLINUND, 
            SELLOUTCRECIMIENTO, SELLOUTCRECIMIENTOUND, 
            SELLINCRECIMIENTO, GASTOCOMPARTIDO, FECHAGESTION, USUARIOGESTION, IDTIPORECONOCIMIENTO, OBSERVACION, 
            MOTIVORECHAZO, decode(p_nuevo, 0, NEGOCIACION, 0) NEGOCIACION, 0 ---decode(p_nuevo, 0, estado, 0) 
            ,CONTRATOREPRESENTANTE, CONTRATOCORREO, FECHACONTRATO, SELLINREAL, SELLINUNDREAL, SELLOUTREAL, SELLOUTUNDREAL
            FROM "DATA"."T_ICOM_INVERSION_CLIENTE_G" 
            where IDINVERSION = P_ID;
        
        INSERT INTO "DATA"."T_ICOM_INVERSION_CLIENTE" 
        (IDINVERSION, CODIGOGRUPO, CODIGOCLIENTE) 
        select V_ID, CODIGOGRUPO, CODIGOCLIENTE
        from "DATA"."T_ICOM_INVERSION_CLIENTE" 
        where IDINVERSION = P_ID;
        --commit;
        
          
         
        INSERT INTO "DATA"."T_ICOM_INVERSION_KPI" 
        (IDINVERSION, IDKPI, VALORINICIAL, META, PONDERACION, IDOBJETIVO, VALORREAL, CALIFICACION) 
        select V_ID, IDKPI, VALORINICIAL, META, PONDERACION, IDOBJETIVO, VALORREAL, CALIFICACION
        FROM "DATA"."T_ICOM_INVERSION_KPI" 
        where IDINVERSION = P_ID;
 
        INSERT INTO "DATA"."T_ICOM_INVERSION_PROCESO" 
        (IDINVERSION, IDPROCESO, ESTADO, CUMPLIMIENTO, OBSERVACION, PORCENTAJE, FECHAINICIO, FECHAFIN) 
        select V_ID, IDPROCESO,  decode(p_nuevo, 0, estado, 0), ---------------------
            CUMPLIMIENTO, OBSERVACION, decode(p_nuevo, 0, PORCENTAJE, 0) , decode(p_nuevo, 0, FECHAINICIO, null), decode(p_nuevo, 0, FECHAFIN, null)
        FROM "DATA"."T_ICOM_INVERSION_PROCESO" 
        where IDINVERSION = P_ID;
        
        INSERT INTO "DATA"."T_ICOM_INVERSION_PRODUCTO" 
        (IDINVERSION, TIPO, CODIGOPRODUCTO, PRODUCTO, LINEANEGOCIO, MARCA, SUBMARCA, NUEVO, 
        CODIGOBARRA, PRECIOPROMO, DESCUENTOMANUAL, CODIGOPRODUCTOPADRE ) 
        select V_ID, TIPO, CODIGOPRODUCTO, PRODUCTO, LINEANEGOCIO, MARCA, SUBMARCA, NUEVO, 
        CODIGOBARRA, PRECIOPROMO, DESCUENTOMANUAL, CODIGOPRODUCTOPADRE
        FROM "DATA"."T_ICOM_INVERSION_PRODUCTO" 
        where IDINVERSION = P_ID;
        --commit;
        
        INSERT INTO "DATA"."T_ICOM_PRODUCTO_CANTIDAD" 
        (IDINVERSION, CODIGOPRODUCTO, TIPO, fecha, CANTIDAD)
        select V_ID, CODIGOPRODUCTO, TIPO, fecha, CANTIDAD
        FROM "DATA"."T_ICOM_PRODUCTO_CANTIDAD" 
        where IDINVERSION = P_ID;
        
         INSERT INTO "DATA"."T_ICOM_PRODUCTO_DESCUENTO" 
        (IDINVERSION, CODIGOPRODUCTO, CODIGOCLIENTE, PRECIO, DESCUENTO, CODIGOBARRA, CODIGOGRUPO, CODIGOCANAL, LINEANEGOCIO, PRODUCTO, CANAL, 
        CLIENTE, PRECIOLISTA, ICE, PRECIOMAYORISTA, MGR, PRECIOSUGERIDOSINIVA, PRECIOSUGERIDOCONIVA, PRECIOPROMO, MGPDV, PRECIOPROMOPDV, 
        PRECIOPROMOIVA_S, PRECIOPROMOCLIENTE, DESCUENTOCLIENTE, MARCA, SUBMARCA, VENTA, DESCUENTOPROYECCION, DESCUENTOCALCULADO, CLIENTEGRUPO) 
        select V_ID, CODIGOPRODUCTO, CODIGOCLIENTE, PRECIO, DESCUENTO, CODIGOBARRA, CODIGOGRUPO, CODIGOCANAL, LINEANEGOCIO, PRODUCTO, CANAL,
        CLIENTE, PRECIOLISTA, ICE, PRECIOMAYORISTA, MGR, PRECIOSUGERIDOSINIVA, PRECIOSUGERIDOCONIVA, PRECIOPROMO, MGPDV, PRECIOPROMOPDV, 
        PRECIOPROMOIVA_S, PRECIOPROMOCLIENTE, DESCUENTOCLIENTE, MARCA, SUBMARCA, VENTA, DESCUENTOPROYECCION, DESCUENTOCALCULADO, CLIENTEGRUPO
        FROM "DATA"."T_ICOM_PRODUCTO_DESCUENTO" 
        where IDINVERSION = P_ID;
        
       INSERT INTO "DATA"."T_ICOM_PRODUCTO_DIS_PARAMETRO" 
       (IDINVERSION, CODIGOPRODUCTO, CODIGOREGALO, MINIMO, DISPONIBLE, SELLOUT, CANTIDAD) 
       select V_ID, CODIGOPRODUCTO, CODIGOREGALO, MINIMO, DISPONIBLE, SELLOUT, CANTIDAD
        FROM "DATA"."T_ICOM_PRODUCTO_DIS_PARAMETRO"
        where IDINVERSION = P_ID;
       
       INSERT INTO "DATA"."T_ICOM_PRODUCTODISTRIBUCION" 
       (IDINVERSION, CODIGOPRODUCTO, PRODUCTO, CODIGOREGALO, REGALO, CODIGOPDV, NOMBREPDV, TOTAL, CANTIDADONPACKS, 
        SELLOUT, MINIMO, DISPONIBLE, DISPONIBLEONPACKS, MINIMOBULTO, BULTOAJUSTADO, PAQUETESFINAL, CANTIDADDISTRIBUCION, 
        TIPO, VALORVA, CANAL) 
       select V_ID, CODIGOPRODUCTO, PRODUCTO, CODIGOREGALO, REGALO, CODIGOPDV, NOMBREPDV, TOTAL, CANTIDADONPACKS, 
        SELLOUT, MINIMO, DISPONIBLE, DISPONIBLEONPACKS, MINIMOBULTO, BULTOAJUSTADO, PAQUETESFINAL, CANTIDADDISTRIBUCION, 
        TIPO, VALORVA, CANAL
        FROM "DATA"."T_ICOM_PRODUCTODISTRIBUCION"
        where IDINVERSION = P_ID;
        
       IF(p_nuevo=0) THEN 
           INSERT INTO "DATA"."T_ICOM_CLIENTE_FECHAS" 
           (IDINVERSION, CODIGOGRUPO, TIPO, NUMERO, TIPOLOCAL, FECHAINICIO, FECHAFIN, ESTADO, AUDITORIAFECHA, ESTABLECIMIENTO, REPLANIFICADO
           ,DESCUENTO, PRODUCTOS) 
           select V_ID, CODIGOGRUPO, TIPO, NUMERO, TIPOLOCAL, FECHAINICIO, FECHAFIN, ESTADO, AUDITORIAFECHA, ESTABLECIMIENTO, REPLANIFICADO
           ,DESCUENTO, PRODUCTOS
            FROM "DATA"."T_ICOM_CLIENTE_FECHAS" 
            where IDINVERSION = P_ID;
            
            INSERT INTO "DATA"."T_ICOM_CLIENTE_MATERIAL" 
           (IDINVERSION, CODIGOGRUPO, IDMATERIAL, DESCRIPCION, CANTIDAD, ESTADO, COSTO,  NEGOCIACION, TIPO, 
           CODIGOPDV, CANTIDADPDV, CLASIFICACION, MEDIBLE, IMPLEMENTACION, FECHAINICIO, FECHAFIN, OBSERVACIONES, FORMATO
           ) 
           select V_ID,  CODIGOGRUPO, IDMATERIAL, DESCRIPCION, CANTIDAD, ESTADO, COSTO,  NEGOCIACION, TIPO,
           CODIGOPDV, CANTIDADPDV, CLASIFICACION, MEDIBLE, IMPLEMENTACION, FECHAINICIO, FECHAFIN, OBSERVACIONES, FORMATO
           
            FROM "DATA"."T_ICOM_CLIENTE_MATERIAL" 
            where IDINVERSION = P_ID;  
            
               INSERT INTO "DATA"."T_ICOM_INVERSION_GASTO" 
                (IDINVERSION, GASTOTIPO, TIPO, PERIODO, FUENTE, VALOR, OBSERVACION, VALORPEQ, VALORMETA, VALORREAL, CALCULADO, CALCULO, VALORPORCENTAJE,IDGASTO) 
                select V_ID, GASTOTIPO, TIPO, PERIODO, FUENTE, VALOR, OBSERVACION, VALORPEQ, VALORMETA, VALORREAL, CALCULADO, CALCULO, VALORPORCENTAJE,IDGASTO
                FROM "DATA"."T_ICOM_INVERSION_GASTO" 
                where IDINVERSION = P_ID;
         
                ---T_ICOM_INVERSION_GASTODISTRIBUCION
                 INSERT INTO "DATA"."T_ICOM_INVERSION_GASTODISTRIBUCION" 
                (IDINVERSION, IDGASTO, TIPO, DESCRIPCION, CODIGOGRUPO, CODIGOCLIENTE, CODIGOPRODUCTO, CODIGOBARRA, COMPANIA, CANTIDAD, VALORINICIAL, VALORDISTRIBUCION, PESODISTRIBUCION, VALOR, TABLAID, TABLADESCRIPCION, DOCUMENTOTIPO, DOCUMENTO, FECHA, OBSERVACION, ESTADO, ESELIMINAR, USERCREA, FECHCREA, USERMODI, FECHMODI) 
                select V_ID, IDGASTO, TIPO, DESCRIPCION, CODIGOGRUPO, CODIGOCLIENTE, CODIGOPRODUCTO, CODIGOBARRA, COMPANIA, CANTIDAD, VALORINICIAL, VALORDISTRIBUCION, PESODISTRIBUCION, VALOR, TABLAID, TABLADESCRIPCION, DOCUMENTOTIPO, DOCUMENTO, FECHA, OBSERVACION, ESTADO, ESELIMINAR, USERCREA, FECHCREA, USERMODI, FECHMODI
                FROM "DATA"."T_ICOM_INVERSION_GASTODISTRIBUCION" 
                where IDINVERSION = P_ID;
        
            
       END IF;
       
     
 
       INSERT INTO "DATA"."T_ICOM_CLIENTE_PDV" 
       (IDINVERSION, CODIGOPDV, CODIGOGRUPO, NUMEROCONTRATO, RUC, fechainicio, fechafin, ESCALA, VENTA, METAMENSUAL, 
       GASTO, CLAUSURAMOTIVO, CLAUSURAFECHA, CRITERIO, CLAUSURA, ESTADO, DISTRIBUCIONAPLICACION, 
       DISTRIBUCIONCRECIMIENTO, OBSERVACION, CONTRATOAPROBAR, CONTRATOCLAUSURA, OBSERVACIONRECHAZO, FECHACONTRATO, SECUENCIAL ) 
       select V_ID, CODIGOPDV, CODIGOGRUPO, NUMEROCONTRATO, RUC, fechainicio, fechafin, ESCALA, VENTA, METAMENSUAL, 
         GASTO, CLAUSURAMOTIVO, CLAUSURAFECHA, CRITERIO, CLAUSURA, decode(p_nuevo, 0, estado, NULL), ---------------------
         DISTRIBUCIONAPLICACION, DISTRIBUCIONCRECIMIENTO, OBSERVACION, decode(p_nuevo, 0, CONTRATOAPROBAR, NULL) CONTRATOAPROBAR, 
         decode(p_nuevo, 0, CONTRATOCLAUSURA, NULL)CONTRATOCLAUSURA, OBSERVACIONRECHAZO, FECHACONTRATO, SECUENCIAL
        FROM "DATA"."T_ICOM_CLIENTE_PDV" 
        where IDINVERSION = P_ID;
       --commit;
             
       INSERT INTO "DATA"."T_ICOM_CLIENTE_PDV_RUCS" 
       (CODIGOPDV, RUC, AUDITORIAUSUARIO, auditoriafecha, IDINVERSION) 
       select CODIGOPDV, RUC, p_usuario, sysdate, V_ID 
        FROM "DATA"."T_ICOM_CLIENTE_PDV_RUCS"
        where IDINVERSION = P_ID;
        
       INSERT INTO DATA.T_ICOM_CLIENTE_PDV_LOCAL
       (IDINVERSION, CODIGOGRUPO, CODIGOPDV, NOMBRECLIENTE, NUMERO, CODIGOLOCAL, NOMBRECOMERCIAL, COMPANIA)
       SELECT  V_ID , CODIGOGRUPO, CODIGOPDV, NOMBRECLIENTE, NUMERO, CODIGOLOCAL, NOMBRECOMERCIAL, COMPANIA
       FROM DATA.T_ICOM_CLIENTE_PDV_LOCAL
       where IDINVERSION = P_ID; 
       
       insert into T_ICOM_INVERSION_VENTAS  ( IDINVERSION, TIPO, CODIGOCLIENTE, CODIGOGRUPO, CODIGOBARRA, CODIGOPRODUCTO, 
       COMPANIA, PRECIOLISTA, VENTAINICIAL, CANTIDADINICIAL, COSTOINICIAL, VENTAREAL, CANTIDADREAL, COSTOREAL, PESO, ESTADO)
        select  V_ID, TIPO, CODIGOCLIENTE, CODIGOGRUPO, CODIGOBARRA, CODIGOPRODUCTO, 
        COMPANIA, PRECIOLISTA, VENTAINICIAL, CANTIDADINICIAL, COSTOINICIAL, VENTAREAL, CANTIDADREAL, COSTOREAL, PESO, ESTADO
        from  T_ICOM_INVERSION_VENTAS  where IDINVERSION = P_ID ;
        
        -- En caso de que se copie un inversion que es padre se deben tambien copiar las hijas.
        for inv in (select id from data.t_icom_inversiones where idgrupo = p_id ) 
        loop
            v_idnew := null;
            DATA.PK_ICOM_CRUD.SP_PRO_COPIAR( P_ID => inv.id ,
                P_ID_NEW => v_idnew,
                P_USUARIO => P_USUARIO,
                P_NUEVO => P_NUEVO  );
            update data.t_icom_inversiones set idgrupo = V_ID where id = v_idnew ;
        end loop;
        
	END SP_PRO_COPIAR;
    
    
    /*ENVIA A RUTA DE APROBACION*/
    PROCEDURE SP_ENVIAR_RUTA(P_ID NUMBER, P_USUARIO VARCHAR, P_COMPANIA VARCHAR, P_ETAPA VARCHAR DEFAULT NULL)
     AS
     V_OBJETO VARCHAR(100):='INVERSION_COMERCIAL';
     V_OBJETO_DES VARCHAR(4500) :='';
     V_EXITO NUMBER;
     V_TIPOINVERSION VARCHAR(10);
     V_AREA VARCHAR(10);
     V_ETAPA VARCHAR(10);
     V_ORIGEN VARCHAR(10);
     V_CANAL VARCHAR(50);
     V_AGRUPADO VARCHAR(10);
     V_TIPO VARCHAR(50);
     V_IDPADRE NUMBER;
     V_ID NUMBER;
     V_IDETAPA NUMBER;
     v_cuenta number;
     v_nombre varchar2(500);
     v_fechainicio varchar2(40);
     v_fechafin varchar2(40);
     v_etapades varchar2(125);
     
    BEGIN 
     
        SELECT IDINVERSIONTIPO, INVERSIONTIPO , IDAREA, NVL(P_ETAPA, IDETAPA), IDORIGEN, GRUPAL, IDETAPA, IDPADRE
              , nombre, fechainicio, fechafin, etapa
            INTO  V_TIPOINVERSION, V_TIPO,V_AREA,V_ETAPA, V_ORIGEN, V_AGRUPADO, V_IDETAPA, V_IDPADRE
           , v_nombre, v_fechainicio, v_fechafin, v_etapades
            FROM DATA.VT_ICOM_INVERSIONES WHERE ID=P_ID;
           
        IF( NVL(P_ETAPA, V_ETAPA) NOT IN (6)) THEN 
            --validacion de campos obligatorios
            DATA.PK_ICOM_COMMONS.SP_VALIDA_OBLIGATORIO(P_ID =>P_ID, P_IDETAPA=>P_ETAPA);
        END IF ; 
      
        IF( abs(NVL(P_ETAPA, V_ETAPA)) IN (1,5) ) THEN --propuesta, replanificacion
        
            DATA.PK_ICOM_COMMONS.SP_VALIDA_INVERSION(P_ID =>P_ID);
            
            --validacion de descuento de todos los productos
            DATA.PK_ICOM_HERRAMIENTAS.SP_DESCUENTOVALIDACION(P_ID =>P_ID);
                    
            --validacion que los productos regalo sean correctos
            DATA.PK_ICOM_HERRAMIENTAS.SP_PRODUCTOVALIDACION(P_ID =>P_ID);
            
            --Validar que tenga ingressado la forma de pago de los clientes 
            select count(1) into v_cuenta
            from T_ICOM_INVERSION_CLIENTE_G C
            INNER JOIN T_ICOM_INVERSIONES I ON (C.IDINVERSION=I.ID)
            where (I.ID=p_id  OR I.IDGRUPO=p_id) AND GRUPAL=0
            --idinversion = p_id 
            and C.idformapago is null; 
           -- and PK_ICOM_COMMONS.F_EJECUTIVONEGOCIADOR(
            --                                        P_CODIGOGRUPO => C.CODIGOGRUPO, P_USUARIO => P_USUARIO,
           --                                         P_COMPANIA => P_COMPANIA ) = 1                                                    ;
            
            if nvl(v_cuenta,0) > 0 then
                RAISE_APPLICATION_ERROR(-20000, 'Existen clientes que no tienen asignada la forma de pago');    
            end if;
            
        v_id := 0 ; 
        v_cuenta := 0 ;
        FOR I IN (select * from t_icom_inversiones where (id=P_ID or IDGRUPO=P_ID) AND GRUPAL=0 )  LOOP
            
            select count(1) into v_id from data.T_ICOM_INVERSION_PROCESO 
                WHERE IDINVERSION=I.ID and estado = 1 AND IDPROCESO IN (7,6);
            select count(1) into v_cuenta from data.t_icom_cliente_material 
                where IDINVERSION=I.ID  ;
            
            if nvl(v_id,0) > 0 and nvl(v_cuenta,0) = 0 then
                RAISE_APPLICATION_ERROR(-20000, 'Existen procesos operativos que necesitan se ingresÃ© material POP en el id: '||I.ID );    
            end if;
        
        END LOOP;
        END IF ;   
       
        --OBTIENE LOS ORIGENES DE LA INVERSION V_ORIGEN
        SELECT LISTAGG(IDORIGEN, ',') WITHIN GROUP (ORDER BY IDORIGEN) CANAL INTO V_ORIGEN
        FROM (SELECT IDORIGEN FROM DATA.VT_ICOM_INVERSIONES WHERE (ID=P_ID or IDGRUPO=P_ID) GROUP BY IDORIGEN);  
            
        --OBTIENE LOS CANALAS DE LA INVERSION V_CANAL
        SELECT LISTAGG(CODIGOCANAL, ',') WITHIN GROUP (ORDER BY CODIGOCANAL) CANAL INTO V_CANAL
        FROM (SELECT CODIGOCANAL FROM DATA.VT_ICOM_INVERSION_CLIENTE WHERE 
        TRIM(CODIGOCANAL) IS NOT NULL AND
        (idinversion=P_ID or IDGRUPO=P_ID) GROUP BY CODIGOCANAL);    
       
        V_ID := P_ID;
        IF abs(P_ETAPA) = 5 THEN --en caso de que sea replanificacion se debe actualizar el estado del padre
              SELECT max(IDPADRE) INTO V_ID FROM DATA.T_ICOM_INVERSIONES WHERE ID=P_ID ;
        END IF;        
        
        V_OBJETO_DES := '<p>  La Inversion - '||V_TIPO||' #'||V_ID||' - '||v_nombre|| 
                        ' en la etapa '||v_etapades||' con fecha inicio '||v_fechainicio||' y fecha fin '||
                         v_fechafin ||' </p> '; 	
        
            DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJOENVIAR(
            p_id=>V_ID,
            p_objeto=>V_OBJETO,
            p_objetodescripcion=> V_OBJETO_DES,
            P_ETAPA=> CASE WHEN V_ETAPA=1 THEN 'PROPUESTA' WHEN V_ETAPA=4 THEN 'CIERRE' WHEN abs(NVL(P_ETAPA, V_ETAPA))=5 THEN 'REPLANIFICACION'
            WHEN V_ETAPA=6 THEN 'CLAUSURA' ELSE '' END,
            p_usuario=>P_USUARIO,
            p_modulo=>G_MODULO,
            p_compania=>P_COMPANIA,
            P_TIPO1=>(NVL(P_ETAPA, V_ETAPA)),  -- etapa
            p_exito=>V_EXITO);
            
        IF(V_EXITO=0) THEN
            RAISE_APPLICATION_ERROR(-20100, DATA.PK_CORP_FLUJOAPROBACION.G_MENSAJE);
        END IF;    
        
        UPDATE DATA.T_ICOM_INVERSIONES SET  ESTADO=2 WHERE (ID=P_ID or IDGRUPO=P_ID) AND ESTADO IN (1,0);
        --CAMBIO DE ETAPA auditoria            
        PK_ICOM_COMMONS.SP_AUDITORIA(
                        P_USUARIO => P_USUARIO,
                        P_IDINVERSION => P_ID,
                        P_IDETAPA => V_ETAPA,
                        P_CODIGOGRUPO => null,
                        P_IDACCION => 5,
                        P_DESCRIPCION => 'SE ENVIA A RUTA DE APROBACION LA INVERSION'    );
        
        IF V_IDETAPA = 5 THEN --en caso de que sea replanificacion se debe actualizar el estado del padre
            UPDATE DATA.T_ICOM_INVERSIONES SET  ESTADO=2 , IDETAPA2 = 5 WHERE ID=V_IDPADRE;
        END IF;        
        
        
    END SP_ENVIAR_RUTA;
    
    
    
    /*PROCESO PARA APROBAR O RECHAZAR UNA INVERSION 
    PK_ICOM_CRUD.SP_APROBAR(P_ID => 1, P_ETAPA => 1, P_ESTADO => 1, P_USUARIO => 1, P_COMPANIA => 1);
    */
    PROCEDURE SP_APROBAR(P_ID NUMBER, P_ETAPA NUMBER, P_ESTADO NUMBER, P_USUARIO VARCHAR, P_COMPANIA VARCHAR, 
                         P_COMENTARIO VARCHAR2, P_COMENTARIO_DIRIGIDO VARCHAR2 DEFAULT NULL, 
                         P_IDPADRE NUMBER DEFAULT 0, P_RUTA NUMBER DEFAULT 1 ) AS
    --v_idpadre data.t_icom_inversiones.idpadre%type;
    v_idetapa data.t_icom_inversiones.idetapa%type;
    v_tipoademdum number;
    v_inversiontipo data.t_icom_inversiones.idinversiontipo%type;
    --V_ORIGEN VARCHAR(100);
    V_TIPO VARCHAR(100);
    v_exito NUMBER := 0 ;
    V_ESTADO NUMBER := P_ESTADO ;
    V_CONTADOR NUMBER ;
    V_NEGOCIACION NUMBER ;
    v_objeto VARCHAR(100):='INVERSION_COMERCIAL';
    v_terminaFlujo NUMBER;
    v_mensaje varchar2(250);
       
    BEGIN
        --Se realiza la aprobacion/rechazo
        IF(P_RUTA=1) THEN
       
            IF V_ESTADO = 1 THEN --APROBADO
                DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJOAPROBAR(
                        P_ID            => case when p_etapa= 5 then P_IDPADRE else P_ID end ,
                        P_OBJETO        => v_objeto, 
                        P_ORDENMONTO    => NULL, 
                        P_USUARIOFLUJO  => P_USUARIO, 
                        P_USUARIO       => P_USUARIO, 
                        P_COMENTARIO    => regexp_replace(P_COMENTARIO, '<[^>]+>') ,
                        P_COMENTARIO_USUARIOS => P_COMENTARIO_DIRIGIDO,
                        P_MODULO        => G_MODULO, 
                        P_COMPANIA      => P_COMPANIA,
                        P_EXITO         => v_exito ,
                        P_TERMINOFLUJO  => v_terminaFlujo
                );
                    
                IF v_exito = 0 THEN  
                    RAISE_APPLICATION_ERROR(-20000, DATA.PK_CORP_FLUJOAPROBACION.G_MENSAJE); 
                END IF;
                
                --APROBACION auditoria            
                PK_ICOM_COMMONS.SP_AUDITORIA(
                            P_USUARIO => P_USUARIO,
                            P_IDINVERSION => P_ID,
                            P_IDETAPA => P_ETAPA,
                            P_CODIGOGRUPO => NULL,
                            P_IDACCION => 6,
                            P_DESCRIPCION => 'SE APRUEBA LA INVERSION' );
            ELSIF V_ESTADO = 0 THEN     --RECHAZADO
            
                DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJORECHAZAR(
                    P_ID  => case when p_etapa= 5 then P_IDPADRE else P_ID end ,
                    P_OBJETO => v_objeto,
                    P_USUARIOFLUJO => P_USUARIO,
                    P_USUARIO => P_USUARIO,
                    P_COMENTARIO => P_COMENTARIO,
                    P_COMENTARIO_USUARIOS => P_COMENTARIO_DIRIGIDO, 
                    P_MODULO => G_MODULO, 
                    P_COMPANIA => P_COMPANIA,
                    P_EXITO => v_exito
                );
                
                IF v_exito = 0 THEN  
                    RAISE_APPLICATION_ERROR(-20000, DATA.PK_CORP_FLUJOAPROBACION.G_MENSAJE); 
                END IF;
                --v_terminaFlujo := 0 ;
                ----RECHAZO auditoria            
                PK_ICOM_COMMONS.SP_AUDITORIA(
                            P_USUARIO => P_USUARIO,
                            P_IDINVERSION => case when p_etapa= 5 then P_IDPADRE else P_ID end,
                            P_IDETAPA => P_ETAPA,
                            P_CODIGOGRUPO => NULL,
                            P_IDACCION => 6,
                            P_DESCRIPCION => 'SE RECHAZA LA INVERSION' );
            END IF;
           
        ELSE 
            v_terminaFlujo := 1;
        END IF;
       
        IF ( v_terminaFlujo = 1 ) THEN
            ----APROBACION / RECHAZO auditoria            
            PK_ICOM_COMMONS.SP_AUDITORIA(
                        P_USUARIO => P_USUARIO,
                        P_IDINVERSION => case when p_etapa= 5 then P_IDPADRE else P_ID end,
                        P_IDETAPA => P_ETAPA,
                        P_CODIGOGRUPO => NULL,
                        P_IDACCION => 6,
                        P_DESCRIPCION => 'SE TERMINA EL FLUJO DE LA INVERSION' );
        END IF;
        
        IF ( v_terminaFlujo = 1 or V_ESTADO = 0 ) THEN   
        
            /*SELECT IDORIGEN, IDTIPO INTO  V_ORIGEN, V_TIPO 
            FROM DATA.T_ICOM_INVERSIONES WHERE ID=P_ID;*/
            
           if p_etapa = 5 then 
                --es una replanificacion
                select idetapa, idinversiontipo into v_idetapa, v_inversiontipo 
                from data.t_icom_inversiones    where id = p_idpadre ;
                
                if (V_ESTADO = 0 ) then
                    --en caso de rechazo la replanificacion 
                    UPDATE DATA.T_ICOM_INVERSIONES SET ESTADO= -1 , idetapa = 5 
                    WHERE (ID =P_ID OR IDGRUPO=P_ID);
                    
                    FOR inversion in ( select id from data.t_icom_inversiones where (ID =p_idpadre OR IDGRUPO=p_idpadre) ) loop
                        --CAMBIO DE ETAPA auditoria            
                        PK_ICOM_COMMONS.SP_AUDITORIA(
                                P_USUARIO => P_USUARIO,
                                P_IDINVERSION => inversion.id,
                                P_IDETAPA => 5,
                                P_CODIGOGRUPO => null,
                                P_IDACCION => 2,
                                P_DESCRIPCION => 'SE CAMBIO DE ETAPA A REPLANIFICACION POR RECHAZO DE LA REPLANIFICACION '    );
                    end loop;
                    
                    --actualizo la inversion original
                    update data.t_icom_inversiones set estado = 1, idetapa2 = null
                    where id = p_idpadre ;
                    
                else   --es una aprobacion de la replanificacion
                    --busco el tipo de inversion que se puede replanificar contrato ademdum
                    v_tipoademdum:=nvl(pk_commons.safe_to_number(PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '11', P_COMPANIA,'','','1' )),0);

                    SELECT FIRMACONTRATO into v_tipoademdum
                    FROM DATA.vt_icom_inversiontipo WHERE IDINVERSIONTIPO=v_inversiontipo ;
                   
                   SELECT count(1) INTO V_CONTADOR
                   FROM T_ICOM_INVERSION_CLIENTE_G WHERE IDINVERSION=p_idpadre AND NVL(NEGOCIACION,0) =0;
                   
                    if (v_tipoademdum is null OR (v_tipoademdum IS NOT NULL AND V_CONTADOR>0)) then 
                        --No tiene adendum
                        --Intercambio el id(1) original por el id(2) de la replanificacion
                        --para que la principal se la replanificada
                        DATA.PK_ICOM_CRUD.SP_INTERCAMBIOID (
                                P_ID => p_id, --id(2) replanificada
                                P_IDPADRE => p_idpadre, --id(1) original
                                P_USUARIO => P_USUARIO
                              );
                        --actualizo los valores id(1) es el que esta con los datos de la replanificacion
                        update data.t_icom_inversiones
                        set estado = 1, 
                            (idgrupo, idetapa) = (select idgrupo, idetapa from data.t_icom_inversiones where id = p_id ), 
                            idetapa2 = null, idpadre = null
                        where id = p_idpadre ;
                      
                        --actualizo los valores a la replanificada id(2) esta los datos del original
                        update data.t_icom_inversiones
                        set estado = 1,  idetapa = 5, idetapa2 = null, idpadre = p_idpadre, idgrupo = null 
                        where id = p_id ;
                        
                        --- si tiene clientes nuevos valida si se deben negociar o no 
                        select PK_ICOM_COMMONS.F_TIENENEGOCIACION(P_INVERSIONTIPO=> INVERSION.IDINVERSIONTIPO, 
                        P_ORIGEN =>INVERSION.IDORIGEN, P_TIPO =>INVERSION.IDTIPO, P_COMPANIA =>INVERSION.COMPANIA)
                        into V_NEGOCIACION
                        from  t_icom_inversiones inversion where id=p_idpadre; 
                       
                        IF(V_NEGOCIACION=0 ) THEN 
                           
                            
                            INSERT INTO data.t_icom_cliente_fechas (idinversion,codigogrupo,tipo,numero,fechainicio,
                                fechafin,    estado,    auditoriafecha) 
                             select  p_idpadre ,  codigogrupo, 1,1, fechainicio,  fechafin, 1, sysdate from 
                             T_ICOM_INVERSION_CLIENTE_G  WHERE IDINVERSION=p_idpadre and NEGOCIACION=0;
                             
                            update t_icom_cliente_material set ESTADO=1, NEGOCIACION=1
                            where idinversion=p_idpadre;
                            
                             UPDATE T_ICOM_INVERSION_CLIENTE_G C SET NEGOCIACION=3 
                             WHERE IDINVERSION=p_idpadre and  NEGOCIACION=0 ;
                            
                        END IF;  
                      
                        
                        
                        ----ACEPTO auditoria            
                        PK_ICOM_COMMONS.SP_AUDITORIA(
                                P_USUARIO => P_USUARIO,
                                P_IDINVERSION => p_idpadre,
                                P_IDETAPA => v_idetapa,
                                P_CODIGOGRUPO => NULL,
                                P_IDACCION => 6,
                                P_DESCRIPCION => 'SE APRUEBA LA REPLANIFICACION DE LA INVERSION '||p_idpadre|| ' SIN ADEMDUM ' );
                    else
                        --en caso de que si tenga un ademdum
                        update data.t_icom_inversiones
                        set estado = 3, --pendiente ademdum 
                            idetapa2 = null
                        where id = p_idpadre ;
                        
                        update data.t_icom_inversiones
                        set estado = 1
                        where id = p_id ;
                        
                        ----ACEPTO auditoria            
                        PK_ICOM_COMMONS.SP_AUDITORIA(
                                P_USUARIO => P_USUARIO,
                                P_IDINVERSION => p_idpadre,
                                P_IDETAPA => v_idetapa,
                                P_CODIGOGRUPO => NULL,
                                P_IDACCION => 6,
                                P_DESCRIPCION => 'SE APRUEBA LA REPLANIFICACION DE LA INVERSION '||p_idpadre|| ' CON ADEMDUM Y ENVIA EL CONTRATO' );
                                
                        --llamar al contrato
                        DATA.PK_ICOM_CONTRATO.SP_CONTRATO_ENVIAR(
                            P_IDINVERSION => p_idpadre,
                            P_CODIGOCLIENTE => null,
                            P_CODIGOPDV => null,
                            P_TIPOCONTRATO => 3, --tipo de ademdum
                            P_USUARIO => P_USUARIO
                          );
                    end if;
                    
                end if;    
            
            ELSIF(P_ETAPA = 1) THEN    
    
                UPDATE DATA.T_ICOM_INVERSIONES SET ESTADO=V_ESTADO WHERE (ID =P_ID OR IDGRUPO=P_ID);
    
                IF(V_ESTADO=1) THEN  ---APRUEBA
                    
                    FOR INVERSION  IN (SELECT * FROM T_ICOM_INVERSIONES WHERE (ID =P_ID OR IDGRUPO=P_ID)) LOOP
                        
                        V_NEGOCIACION := PK_ICOM_COMMONS.F_TIENENEGOCIACION(P_INVERSIONTIPO=> INVERSION.IDINVERSIONTIPO, 
                        P_ORIGEN =>INVERSION.IDORIGEN, P_TIPO =>INVERSION.IDTIPO, P_COMPANIA =>INVERSION.COMPANIA);
                    
                        UPDATE DATA.T_ICOM_INVERSIONES SET IDETAPA=
                        CASE WHEN GRUPAL=0 AND V_NEGOCIACION=1 THEN  
                            2 --NEGOCIACION
                        ELSE 
                            3 -- IMPLEMENTACION
                        END WHERE ID=INVERSION.ID;
                        
                        v_mensaje := CASE WHEN INVERSION.GRUPAL=0 AND V_NEGOCIACION=1 
                                            THEN   'SE CAMBIO DE ETAPA PROPUESTA A NEGOCIACION POR FINALIZAR FLUJO DE APROBACION'
                                          ELSE 
                                            'SE CAMBIO DE ETAPA PROPUESTA A IMPLEMENTACION POR FINALIZAR FLUJO DE APROBACION'
                                     END ;
                       --CAMBIO DE ETAPA auditoria            
                       PK_ICOM_COMMONS.SP_AUDITORIA(
                                P_USUARIO => P_USUARIO,
                                P_IDINVERSION => INVERSION.ID,
                                P_IDETAPA => CASE WHEN INVERSION.GRUPAL=0 AND V_NEGOCIACION=1 THEN   2
                                                    ELSE 3  END,
                                P_CODIGOGRUPO => null,
                                P_IDACCION => 2,
                                P_DESCRIPCION =>  v_mensaje );
                        
                         -- si es convenio o plan agrega las fechas para la validacion 
                       IF(INVERSION.IDINVERSIONTIPO IN (4,5)) THEN 
                            INSERT INTO data.t_icom_cliente_fechas (idinversion,codigogrupo,tipo,numero,fechainicio,
                                fechafin,    estado,    auditoriafecha) 
                             select  INVERSION.ID ,  codigogrupo, 1,1, fechainicio,  fechafin, 1, sysdate from 
                             T_ICOM_INVERSION_CLIENTE_G  WHERE IDINVERSION=INVERSION.ID; 
                       END IF;
                       
                       -- si no tiene negociacion aprueba los clientes y agrega fechas  y material pop
                       IF(V_NEGOCIACION=0 or INVERSION.GRUPAL=1 ) THEN 
                            UPDATE T_ICOM_INVERSION_CLIENTE_G C SET NEGOCIACION=3 WHERE IDINVERSION=INVERSION.ID;
                            
                            INSERT INTO data.t_icom_cliente_fechas (idinversion,codigogrupo,tipo,numero,fechainicio,
                                fechafin,    estado,    auditoriafecha) 
                             select  INVERSION.ID ,  codigogrupo, 1,1, fechainicio,  fechafin, 1, sysdate from 
                             T_ICOM_INVERSION_CLIENTE_G  WHERE IDINVERSION=INVERSION.ID and NEGOCIACION=3;
                             
                            update t_icom_cliente_material set ESTADO=1, NEGOCIACION=1 where idinversion=INVERSION.ID;
                        END IF;
                        
                        --En caso de que se termino el flujo de aprobacion se actuliza el inicio del proceso
                        update data.t_icom_inversion_proceso
                        set fechainicio = sysdate
                        where idinversion = INVERSION.ID
                        and estado = 1 ;
                    END LOOP;
                    
                       --En caso de que el idorigen = 3 (fabrica) se envia notificacion por correo a los procesos = 9 planificacion de la produccion
                        DATA.PK_ICOM_PROCESOS.SP_CORREOPLANIFICACION(
                            P_IDINVERSION => p_id,
                            P_ESTADO => V_ESTADO,
                            P_USUARIO => P_USUARIO
                          );
                  
                END IF;
                
             
            ELSIF(P_ETAPA = 4) THEN    --Cierre
    
                ---- ETAPA = 4  ESTADO= 1   INICIAN CIERRA
                --- ETAPA = 4  ESTADO= 2   RUTA CIERRA
                --- ETAPA = 4  ESTADO= 4   FINALIZA
    
                UPDATE DATA.T_ICOM_INVERSIONES 
                SET ESTADO= decode(V_ESTADO,0,1, 1,4),
                    FECHACIERRE = CASE
                                      WHEN V_ESTADO = 0 THEN NVL(FECHACIERRE, SYSDATE)
                                      ELSE FECHACIERRE
                                   END,
                    FECHACIERREFIN = CASE
                                         WHEN V_ESTADO = 1 THEN NVL(FECHACIERREFIN, SYSDATE)
                                         ELSE FECHACIERREFIN
                                      END
                --,                    ESTADOCIERRE =P_ESTADO 
                WHERE ID =P_ID;
                
            END IF;  
            
        END IF;        
    END SP_APROBAR;
    
    
    FUNCTION F_PUEDECLAUSURAR(P_ID NUMBER, P_USUARIOACTUAL VARCHAR2, P_PAGE_ID NUMBER, 
    P_CODIGOMODULO VARCHAR2, P_CLAUSURA VARCHAR2) RETURN NUMBER
    AS 
    v_etapaCondiciones NUMBER;
    v_enrutaAprob NUMBER;
    v_accesoClausura NUMBER;
    v_usuarioCreador VARCHAR2(25);
    v_resultado NUMBER;
    v_firmaContrato NUMBER;
    BEGIN 
 
    /* COMPRUEBA QUE LOS ESTADOS DE LA ETAPA SEA 2 O 3 Y LA ETAPA2 SEA NULL*/
        BEGIN 
            SELECT 1 INTO v_etapaCondiciones 
            FROM DATA.T_ICOM_INVERSIONES
            WHERE ID = P_ID
            AND IDETAPA IN (2,3) AND IDETAPA2 IS NULL;
        EXCEPTION WHEN NO_DATA_FOUND THEN
            v_etapaCondiciones := -1;
        END;

        /*OBTENER LA COMPANIA DE LA INVERSION*/
            select  max(compania) into  v_compania from data.t_icom_inversiones where id = P_ID and rownum=1;

        /* OBTENER SI LA INVERSION FIRMA CONTRATO*/
        BEGIN 
            SELECT VALOR3 INTO v_firmaContrato
            FROM DATA.T_CORP_UDC UDC
            WHERE UDC.ID_CABECERA = 'ICOM_TINV'
            AND ID_TABLA = (SELECT IDINVERSIONTIPO FROM DATA.T_ICOM_INVERSIONES WHERE ID = P_ID);
         EXCEPTION WHEN NO_DATA_FOUND THEN 
            v_firmaContrato := NULL;
         END;       
 
        /*OBTIENE EL USUARIO CREADOR*/
        BEGIN 
            SELECT USUARIO INTO v_usuarioCreador 
            FROM DATA.T_ICOM_INVERSIONES
            WHERE ID = P_ID;
        END;
        
        
        /* VERIFICA QUE NO SE ENCUENTRA EN RUTA DE APROBACION ACTIVA */
        BEGIN         
            SELECT DATA.PK_ICOM_CRUD.F_CLAUSURAACTIVA(P_ID => P_ID, P_ESTADO => 'EN_PROCESO' , P_ENTIDAD => 'INVERSION_COMERCIAL' , P_ETAPA => 'CLAUSURA' ) INTO v_enrutaAprob FROM DUAL;
        END;
            
        /* COMPRUEBA SI EL USUARIO TIENE EL ACCESO PARA REALIZAR LA CLAUSURA DE LA INVERSION MEDIANTE PERMISO ACCIONES*/
            v_accesoClausura :=  DATA.PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES ( 
                  P_CODIGOMODULO => P_CODIGOMODULO
                , P_CODIGOUSUARIO => P_USUARIOACTUAL
                , P_RUTAPAGINA => P_PAGE_ID
                , P_CODIGOACCION => P_CLAUSURA
            );
            
            -->  v_etapaCondiciones / cuenta el numero de procesos que cumplen > 0
            -->  v_enrutaAprob / cuenta si esta en ruta de aprobacion < 1 o = 0
            -->  v_accesoClausura / consulta si tiene acceso a la accion de clausurar = 1
            -->  v_usuarioCreador / verifica que sea quien creo
            
        IF      v_etapaCondiciones > 0 AND v_enrutaAprob < 1 AND (v_accesoClausura  = 1 OR v_usuarioCreador = P_USUARIOACTUAL )   THEN 
                IF v_firmaContrato IS NULL THEN
                        v_resultado := 10;   --- > para la aprobacion de clausura de CLAUSURA_INVERSIONES > 0
                 ELSE 
                        v_resultado := -10;  ---- > para la aprobacion de clausura de CLAUSURA_INVERSIONES < 0
                 END IF;
        END IF; 
        
        IF v_resultado IS NOT NULL THEN 
            RETURN v_resultado;  
        END IF;
 
    RETURN 0;
    
END F_PUEDECLAUSURAR;
    
    FUNCTION F_CLAUSURAACTIVA(P_ID NUMBER, P_ESTADO VARCHAR2, P_ENTIDAD VARCHAR2,
    P_ETAPA VARCHAR2, P_USUARIOACTIVO VARCHAR2 DEFAULT NULL  ) RETURN NUMBER
   AS
   contador NUMBER;
   BEGIN 
    IF P_USUARIOACTIVO IS NULL THEN 
        SELECT COUNT(ENTIDAD_ID) INTO contador FROM DATA.T_FLUJO_APROBACION_CAB WHERE CODMODULO = G_MODULO AND ESTADO = P_ESTADO AND ENTIDAD_CLASE = P_ENTIDAD
        AND ETAPA = P_ETAPA AND ENTIDAD_ID = P_ID;
    ELSE 
        SELECT COUNT(ENTIDAD_ID) INTO contador FROM DATA.T_FLUJO_APROBACION_CAB WHERE CODMODULO = G_MODULO AND ESTADO = P_ESTADO AND ENTIDAD_CLASE = P_ENTIDAD
        AND ETAPA = P_ETAPA AND ENTIDAD_ID = P_ID AND USUARIOACTUAL = P_USUARIOACTIVO;
    END IF;
 
    RETURN contador ;
   END F_CLAUSURAACTIVA;
   
    PROCEDURE SP_CL_INVERSION (P_ID NUMBER, P_MOTIVOCLAUSURA VARCHAR2, P_USUARIOACTUAL VARCHAR2, P_COMPANIA VARCHAR2 )
    AS 
     V_OBJETO VARCHAR(100):='INVERSION_COMERCIAL';
     V_OBJETO_DES VARCHAR(4500) :='';
     V_EXITO NUMBER;
     V_TIPOINVERSION VARCHAR(10);
     V_TIPO VARCHAR(50);
     v_cuenta number ;
     v_contrato_notificacion number;
     v_compania varchar2(5);
    BEGIN

        select COMPANIA into v_compania from data.t_icom_inversiones where id = P_ID and rownum=1;

        v_contrato_notificacion := PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '35', v_compania);

        if v_contrato_notificacion = 1 then
            /*Validar que existan los contratos de finiquito*/
            select count(1) into v_cuenta
            from (  SELECT DATA.PK_ICOM_CONTRATO.F_OBTENER_IDCONTRATO(P_IDINVERSION => P_ID,
                               P_CODIGOGRUPO => NULL , P_CODIGOPDV => CODIGOPDV , P_TIPOCONTRATO=> 4 ) idcontrato
                    FROM DATA.T_ICOM_CLIENTE_PDV WHERE IDINVERSION = P_ID AND CONTRATOCLAUSURA = 2 ) c
            where c.idcontrato is null ;
            if nvl(v_cuenta,0) > 0 then
                RAISE_APPLICATION_ERROR(-20000, 'No se puede enviar a ruta existen puntos de venta sin contrato de finiquito');
            end if;
        end if;
        
        UPDATE DATA.T_ICOM_INVERSIONES 
        SET IDETAPA2 = 6,   MOTIVOCLAUSURA = P_MOTIVOCLAUSURA  WHERE ID = P_ID; 
        
        SP_ENVIAR_RUTA(P_ID =>P_ID, P_USUARIO =>P_USUARIOACTUAL, P_COMPANIA =>P_COMPANIA, P_ETAPA =>6);
    
    END SP_CL_INVERSION;
    
    PROCEDURE SP_CL_INVERSIONGESTION (P_ID NUMBER, P_ACCION NUMBER, P_USUARIO VARCHAR2, P_COMENTARIO VARCHAR2, P_COMENTARIOUSUARIO VARCHAR2, P_COMPANIA VARCHAR2)
    AS 
    v_exito NUMBER;
    v_objeto VARCHAR(100):='INVERSION_COMERCIAL';
    v_terminaFlujo NUMBER;
    BEGIN 
 
        IF P_ACCION > 0 THEN --APROBADO
                DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJOAPROBAR(
                    P_ID            => P_ID,
                    P_OBJETO        => v_objeto, 
                    P_ORDENMONTO    => NULL, 
                    P_USUARIOFLUJO  => P_USUARIO, 
                    P_USUARIO       => P_USUARIO, 
                    P_COMENTARIO    => P_COMENTARIO,
                    P_COMENTARIO_USUARIOS => P_COMENTARIOUSUARIO,
                    P_MODULO        => G_MODULO, 
                    P_COMPANIA      => P_COMPANIA,
                    P_EXITO         => v_exito ,
                    P_TERMINOFLUJO  => v_terminaFlujo
                );
                
                IF v_exito = 0 THEN  RAISE_APPLICATION_ERROR(-20000, DATA.PK_CORP_FLUJOAPROBACION.G_MENSAJE); END IF;
                
                --APROBAR auditoria            
                PK_ICOM_COMMONS.SP_AUDITORIA(
                        P_USUARIO => P_USUARIO,
                        P_IDINVERSION => P_ID,
                        P_IDETAPA => NULL,
                        P_CODIGOGRUPO => NULL,
                        P_IDACCION => 6,
                        P_DESCRIPCION => 'SE APRUEBA LA INVERSION ' );
                        
                IF v_terminaFlujo = 1 THEN   
                        UPDATE DATA.T_ICOM_INVERSIONES
                           SET ESTADO = 1,
                               IDETAPA = 4,
                               FECHACIERRE = NVL(FECHACIERRE, SYSDATE)
                        WHERE ID = P_ID;
                       --CAMBIO DE ETAPA auditoria            
                       PK_ICOM_COMMONS.SP_AUDITORIA(
                                P_USUARIO => P_USUARIO,
                                P_IDINVERSION => p_id,
                                P_IDETAPA => 4,
                                P_CODIGOGRUPO => null,
                                P_IDACCION => 2,
                                P_DESCRIPCION => 'SE CAMBIO DE ETAPA CIERRE POR TERMINAR FLUJO DE APROBACION DE CLAUSURA'    );
                        --Notificacion de procesos operativos 
                        DATA.PK_ICOM_CRUD.SP_NOTIFICACION_PROCESOS(
                            P_IDINVERSION => P_ID,
                            P_MOTIVO => P_COMENTARIO
                        );
                END IF;
 
        ELSE    --RECHAZADO
        
            DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJORECHAZAR(
                P_ID  => P_ID,
                P_OBJETO => v_objeto,
                P_USUARIOFLUJO => P_USUARIO,
                P_USUARIO => P_USUARIO,
                P_COMENTARIO => P_COMENTARIO,
                P_COMENTARIO_USUARIOS => P_COMENTARIOUSUARIO, 
                P_MODULO => G_MODULO, 
                P_COMPANIA => P_COMPANIA,
                P_EXITO => v_exito
            );
            
            IF v_exito = 0 THEN  RAISE_APPLICATION_ERROR(-20000, DATA.PK_CORP_FLUJOAPROBACION.G_MENSAJE); END IF;
            
            --RECHAZAR auditoria            
            PK_ICOM_COMMONS.SP_AUDITORIA(
                    P_USUARIO => P_USUARIO,
                    P_IDINVERSION => P_ID,
                    P_IDETAPA => NULL,
                    P_CODIGOGRUPO => NULL,
                    P_IDACCION => 6,
                    P_DESCRIPCION => 'SE RECHAZA LA INVERSION ' );
                        
            UPDATE DATA.T_ICOM_INVERSIONES
                SET ESTADO = 1,      IDETAPA2 = NULL,    MOTIVOCLAUSURA = NULL
                WHERE ID = P_ID;
        END IF;
        
    END SP_CL_INVERSIONGESTION;
    
    /*Envia  a ruta de aprobacion la clausuara de contratos de los convenios comerciales */    
    PROCEDURE SP_CL_CONTRATO(P_ID NUMBER,  P_USUARIOACTUAL IN VARCHAR2, P_COMPANIA VARCHAR2, P_MOTIVOCLAUSURA VARCHAR2 )
    AS
    V_OBJETO VARCHAR(100):='INVERSION_COMERCIAL';
    V_OBJETO_DES VARCHAR(4500) :='';
     V_EXITO NUMBER;
     V_TIPOINVERSION VARCHAR(100);
     V_AREA VARCHAR(100);
     V_ETAPA VARCHAR(100);
     V_ORIGEN VARCHAR(100);
     V_CANAL VARCHAR(500);
     V_AGRUPADO VARCHAR(100);
     V_TIPO VARCHAR(50);
     V_IDPADRE NUMBER;
     V_IDETAPA NUMBER;
    BEGIN 
    
      SELECT IDINVERSIONTIPO,  IDAREA, IDORIGEN, GRUPAL, IDETAPA, IDPADRE
            INTO  V_TIPOINVERSION, V_AREA, V_ORIGEN, V_AGRUPADO, V_IDETAPA, V_IDPADRE
            FROM DATA.VT_ICOM_INVERSIONES WHERE ID=P_ID;
            
        --OBTIENE LOS CANALAS DE LA INVERSION V_CANAL
        SELECT LISTAGG(CODIGOCANAL, ',') WITHIN GROUP (ORDER BY CODIGOCANAL) CANAL INTO V_CANAL
        FROM (SELECT CODIGOCANAL FROM DATA.VT_ICOM_INVERSION_CLIENTE WHERE (idinversion=P_ID) GROUP BY CODIGOCANAL);    
        
           DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJOENVIAR(
            p_id=>P_ID,
            p_objeto=>V_OBJETO,
            p_objetodescripcion=> 'Clausura de convenios en la inversion # '||P_ID,
            P_ETAPA =>'CLAUSURA',
            p_usuario=>P_USUARIOACTUAL,
            p_modulo=>G_MODULO,
            p_compania=>P_COMPANIA,
            P_TIPO1=>6,  -- etapa
            p_exito=>V_EXITO);
        
        /*        
         DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJOENVIAR(
            p_id=>P_ID,
            p_objeto=>V_OBJETO,
            p_objetodescripcion=>'Clausura de convenios en la inversion # '||P_ID,
            P_ETAPA =>'CLAUSURA',
            p_usuario=>P_USUARIOACTUAL,
            p_modulo=>G_MODULO,
            p_compania=>P_COMPANIA,
            P_TIPO1=>V_TIPOINVERSION,  -- tipo inversion
            P_TIPO2=>V_AREA,  -- area
            P_TIPO3=>6,  -- etapa
            P_TIPO4=>V_ORIGEN,  -- origen
            P_TIPO5=>V_CANAL,  -- canal
            P_TIPO6=>0,  -- agrupado
            p_exito=>V_EXITO);
 */
--   ****   FLUJO ENVIADO  ***
        IF V_EXITO = 0 THEN
            RAISE_APPLICATION_ERROR(-20100, DATA.PK_CORP_FLUJOAPROBACION.G_MENSAJE);
        END IF;   
    
     --FOR DE PUNTO DE VENTA SELECCIONADO      
     FOR pVenta IN (SELECT c001 idInversion, c002 codigoPunto, RUC, METAMENSUAL, c003 fechafiniquito
                         FROM APEX_collections , DATA.T_ICOM_CLIENTE_PDV clientePDV
                         WHERE collection_name = 'INVERSION_CODIGOPDV' 
                         and clientePDV.IDINVERSION = c001
                         AND clientePDV.CODIGOPDV = c002)
     LOOP
        --ACTUALIZA ESTADO CLAUSURA EN PUNTO DE VENTA CORRESPONDIENTES A LA INVERSION 
            UPDATE DATA.T_ICOM_CLIENTE_PDV puntoVenta
            SET puntoVenta.CONTRATOCLAUSURA = 2,
                puntoVenta.CLAUSURAMOTIVO = P_MOTIVOCLAUSURA,
                puntoVenta.CLAUSURAFEC_FINIQUITO = pVenta.fechafiniquito
            WHERE puntoVenta.IDINVERSION = P_ID
            AND puntoVenta.CODIGOPDV = pVenta.codigoPunto;
     
     END LOOP;
     
    --  ACTUALIZA EL ESTADO A 2 Y LA ETAPA2 A 6 DE LA INVERSION
        UPDATE DATA.T_ICOM_INVERSIONES inversion
        SET inversion.ESTADO = 2,   inversion.IDETAPA2 =6
        WHERE inversion.ID = P_ID;
        
        --ENVIA A RUTA auditoria            
        PK_ICOM_COMMONS.SP_AUDITORIA(
                        P_USUARIO => P_USUARIOACTUAL,
                        P_IDINVERSION => P_ID,
                        P_IDETAPA => 6,
                        P_CODIGOGRUPO => null,
                        P_IDACCION => 5,
                        P_DESCRIPCION => 'SE ENVIA A RUTA DE APROBACION LA CLAUSURA DE CONVENIOS DE LA INVERSION '    );
                        
    END SP_CL_CONTRATO;
    
        /*Aprobar/rechazar  la clausuara de contratos de los convenios comerciales */    
    PROCEDURE SP_CL_CONTRATOGESTION (P_ID NUMBER, P_ACCION NUMBER, P_USUARIO VARCHAR2, P_COMPANIA VARCHAR2,
    P_COMENTARIO VARCHAR DEFAULT NULL  )
    AS
    v_exito NUMBER;
    v_objeto VARCHAR(100):='INVERSION_COMERCIAL';
    v_terminaFlujo NUMBER;
    v_mensaje clob;
    v_cor_rem varchar2(100);
    v_cor_des varchar2(100);
    v_cor_asun VARCHAR2(100);
    v_correoContacto VARCHAR2(300);
    v_nombre VARCHAR2(250);
    v_nombreComercial VARCHAR2(250);
    v_tipoCorreo NUMBER;
    v_urlServidor VARCHAR2(200);
    v_enlace VARCHAR2(1000);
    v_idcontrato NUMBER;
    v_cuenta number;
    v_contrato_notificacion    NUMBER;
    
    BEGIN 
    
    IF P_ACCION > 0 THEN --APROBADO

        v_contrato_notificacion := PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '35', P_COMPANIA);

        IF v_contrato_notificacion = 1 THEN
            /*Validar que existan los contratos de finiquito*/
            select count(1) into v_cuenta
            from (  SELECT DATA.PK_ICOM_CONTRATO.F_OBTENER_IDCONTRATO(P_IDINVERSION => P_ID,
                               P_CODIGOGRUPO => NULL , P_CODIGOPDV => CODIGOPDV , P_TIPOCONTRATO=> 4 ) idcontrato
                    FROM DATA.T_ICOM_CLIENTE_PDV WHERE IDINVERSION = P_ID AND CONTRATOCLAUSURA = 2 ) c
            where c.idcontrato is null ;

            if nvl(v_cuenta,0) > 0 then
                RAISE_APPLICATION_ERROR(-20000, 'No se puede enviar a ruta existen puntos de venta sin contrato de finiquito');
            end if;
        END IF;
        
                DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJOAPROBAR(
                    P_ID            => P_ID,
                    P_OBJETO        => v_objeto, 
                     P_ORDENMONTO    => NULL, 
                    P_USUARIOFLUJO  => P_USUARIO, 
                    P_USUARIO       => P_USUARIO, 
                    P_COMENTARIO    => P_COMENTARIO,
                    P_MODULO        => G_MODULO, 
                    P_COMPANIA      => P_COMPANIA,
                    P_EXITO         => v_exito ,
                    P_TERMINOFLUJO  => v_terminaFlujo
                );
--                    COMPROBAR EXITO DE LA APROBACION
                   IF v_exito = 0 THEN  RAISE_APPLICATION_ERROR(-20000, DATA.PK_CORP_FLUJOAPROBACION.G_MENSAJE); END IF;
                   --APROBAR auditoria            
                   PK_ICOM_COMMONS.SP_AUDITORIA(
                                P_USUARIO => P_USUARIO,
                                P_IDINVERSION => P_ID,
                                P_IDETAPA => NULL,
                                P_CODIGOGRUPO => NULL,
                                P_IDACCION =>6,
                                P_DESCRIPCION => 'SE APRUEBA LA INVERSION ' );
                                
--                   COMPROBAR SI TERMINA EL FLUJO
                   IF v_terminaFlujo = 1 THEN   
--                 
                       UPDATE DATA.T_ICOM_INVERSIONES
                       SET IDETAPA2 = NULL,       ESTADO = 1
                       WHERE ID = P_ID;
                       
                       --APROBAR / RECHAZAR  auditoria            
                       PK_ICOM_COMMONS.SP_AUDITORIA(
                                P_USUARIO => P_USUARIO,
                                P_IDINVERSION => P_ID,
                                P_IDETAPA => NULL,
                                P_CODIGOGRUPO => NULL,
                                P_IDACCION =>6,
                                P_DESCRIPCION => 'SE TERMINA EL FLUJO DE APROBACION DE LA INVERSION ' );
                       
                       --enviar el correo de notificacion     
                       DATA.PK_ICOM_CONTRATO.SP_CONTRATO_ENVIAR(
                            P_IDINVERSION => P_ID,
                            P_TIPOCONTRATO => 4,
                            P_USUARIO => P_USUARIO
                       );   
                   END IF; 
        ELSE    --RECHAZADO
        
            DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJORECHAZAR(
                P_ID  => P_ID,
                P_OBJETO => v_objeto,
                P_USUARIOFLUJO => P_USUARIO,
                P_USUARIO => P_USUARIO,
                P_COMENTARIO => NULL,
                P_COMENTARIO_USUARIOS => NULL, 
                P_MODULO => G_MODULO, 
                P_COMPANIA => P_COMPANIA,
                P_EXITO => v_exito
            );
            
            IF v_exito = 0 THEN  RAISE_APPLICATION_ERROR(-20000, DATA.PK_CORP_FLUJOAPROBACION.G_MENSAJE); END IF;
            
            --RECHAZO auditoria            
           PK_ICOM_COMMONS.SP_AUDITORIA(
                        P_USUARIO => P_USUARIO,
                        P_IDINVERSION => P_ID,
                        P_IDETAPA => NULL,
                        P_CODIGOGRUPO => NULL,
                        P_IDACCION =>6,
                        P_DESCRIPCION => 'SE RECHAZO LA INVERSION ' );
                                
                UPDATE DATA.T_ICOM_INVERSIONES
                SET IDETAPA2 = NULL,       ESTADO = 1
                WHERE ID = P_ID;
        
                UPDATE DATA.T_ICOM_CLIENTE_PDV
                SET CONTRATOCLAUSURA = NULL,           CLAUSURAMOTIVO = NULL
                WHERE IDINVERSION = P_ID     AND CONTRATOCLAUSURA= 2;
        END IF;
    
    END SP_CL_CONTRATOGESTION;
   
    /*funcion que retorna 0 en caso de no tener permiso para replanificar, :1 en caso de que se pueda
    * :2 si es el usuario creador, :3 si tiene permisos especiales, :4 si es el ejecutivo
    Por: JAsanza
	Fecha: Octubre 2022
    *p_idinversion codigo de la inversion para replanificar
    *p_usuario nombre del usuario logedo
    */ 
    FUNCTION F_PUEDEREPLANIFICAR(p_idinversion number, p_usuario varchar2) RETURN NUMBER AS
    v_puede number := 0 ;
    v_ejecutivo number := 0 ;
    v_inversion data.t_icom_inversiones%rowtype;
    BEGIN
    
        if nvl(p_idinversion,0) > 0 then
            --busco la inversion
            select * into v_inversion
            from data.t_icom_inversiones
            where id = p_idinversion ;
           
            --se verifica los estados de la inversion
            if v_inversion.estado = 1 and v_inversion.idetapa in (2,3)
            /*and v_inversion.idgrupo is null*/ then
                if p_usuario = v_inversion.usuario  then   
                    v_puede := 2 ; -- COORDINAR O CREAADOR DE LA INVERSION 
                elsif (DATA.PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES (
                          P_CODIGOMODULO => G_MODULO, 
                         P_CODIGOUSUARIO => P_USUARIO,
                         P_RUTAPAGINA => 200,
                         P_CODIGOACCION => 'RE_PLANIFICAR')) = 1 then
                    v_puede := 3 ;     --- PERMISO ESPECIAL 
                else --verifica si es el ejecutivo del cliente    
                   for cli in (select codigogrupo, negociacion from data.T_ICOM_INVERSION_CLIENTE_G where IDINVERSION = p_idinversion)
                   loop
                       if cli.negociacion in ( 0,1,3 ) then
                           v_ejecutivo := DATA.PK_ICOM_COMMONS.F_ESEJECUTIVO( 
                               P_USUARIO => P_USUARIO,
                               P_CLIENTE => cli.codigogrupo,
                               P_COMPANIA => v_inversion.compania
                               ); 
                       end if;
                       if v_ejecutivo = 1 then
                           v_puede := 4;  --- EJECUTIVO DE LA INVERSION 
                           exit;
                       end if;
                   end loop;           
                end if;
            end if;    
        end if;    
        return v_puede ;
    END F_PUEDEREPLANIFICAR;
    
    /*Procedimiento para la validacion de requerimiento para la replanificacion
    Por: JAsanza
	Fecha: Octubre 2022
    *p_idinversion el codigo de la inversion replanificada
    *p_tipo el codigo para el tipo de validacion 1 es inicial y 2 es la final
    *p_valida retorna 0 si tiene cualquier error 1 en caso de todo ok
    *p_error para los casos necesarios envia una descripcion del error encontrado
    */
    PROCEDURE SP_REPLANIFICARVALIDAR(p_idinversion number, p_tipo number, p_valida out number, p_error out varchar2) AS
    v_tipopago number ;
    v_inversion data.t_icom_inversiones%rowtype;
    v_inversionpadre data.t_icom_inversiones%rowtype;
     v_diasAdicionales number ;
    v_cuenta number := 0;
    V_NEGOCIACION number := 0;
    BEGIN
        --busco la inversion
        select * into v_inversion
        from data.t_icom_inversiones
        where id = p_idinversion ;
        
        v_diasAdicionales:=nvl(pk_commons.safe_to_number(PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '1', v_inversion.COMPANIA )),0);
        
        --busco el tipo de inversion que se puede replanificar sin pagos
        v_tipopago:=nvl(pk_commons.safe_to_number(PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '10', v_inversion.COMPANIA,'','','1' )),0);
        
        p_valida := 0 ;
        if p_tipo = 1 then --valida el momento de crear la replanificacion
            --p_valida := 1 ; return;
            if v_inversion.idinversiontipo != v_tipopago then 
                begin
                    select count(1) into v_cuenta from DATA.T_ICOM_CLIENTE_VALIDACION
                    where idinversion = p_idinversion and VAL_FECHAINICIO is not null ;
                exception 
                    when no_data_found then
                        v_cuenta := 0 ;
                end;
                
                 p_valida := 1;
                 /*
                if v_cuenta = 0 then
                    p_valida := 1;
                else
                    p_error := 'Ya tienen registro de pago';
                end if;
                */
            else 
                p_valida := 1;
            end if;
        
        elsif p_tipo = 2 then --valida el momento de grabar la replanificacion
            --busco la inversion padre
                select * into v_inversionpadre
                from data.t_icom_inversiones
                where id = v_inversion.idpadre ;
           /* if v_inversion.fechainicio <= trunc(sysdate) then
                if v_inversion.fechainicio != v_inversionpadre.fechainicio 
                    or v_inversion.fechafin  != v_inversionpadre.fechafin then
                    p_error := 'La fecha inicio es menor que hoy y no se pueden modificar las fechas';
                    return ;
                end if;    
            end if;    */
            --valida que esten todos los clientes necesarios
            v_cuenta := 0 ;
            
               V_NEGOCIACION:= PK_ICOM_COMMONS.F_TIENENEGOCIACION(P_INVERSIONTIPO=> v_inversion.IDINVERSIONTIPO, 
                P_ORIGEN =>v_inversion.IDORIGEN, P_TIPO =>v_inversion.IDTIPO,
                P_COMPANIA =>v_inversion.COMPANIA);
            
            if(V_NEGOCIACION>0) THEN 
                for cli in (select codigogrupo from data.T_ICOM_INVERSION_CLIENTE_G 
                            where IDINVERSION = v_inversionpadre.id and negociacion in (2,3))
                loop
                    begin
                        select count(1) into v_cuenta from data.T_ICOM_INVERSION_CLIENTE_G 
                        where IDINVERSION = v_inversion.id and codigogrupo = cli.codigogrupo ;
                    exception 
                        when no_data_found then
                            v_cuenta := 0 ;
                    end ;
                    if v_cuenta = 0 then
                        p_error := 'Existen clientes que no pueden ser eliminados por su estado de negociacion';
                        return ;
                    end if;    
                end loop;    
             end if;   
     
            
            --valida que todas las fechas sean las corrects
            v_cuenta := 0 ;  
               select count(1) into v_cuenta from data.t_icom_cliente_fechas
               where idinversion = v_inversion.id 
               and ( trunc(fechainicio) < trunc(v_inversion.fechainicio-v_diasAdicionales) 
               or trunc(fechafin) > trunc(v_inversion.fechafin+v_diasAdicionales) ) ;
          
          
            if v_cuenta > 0 and V_NEGOCIACION=1 then
                p_error := 'Existen fechas fuera del rango';
                return  ;
            end if;
        
        
            p_valida := 1;
        end if;
        
    END ;
    
    /*Procedimiento para la validacion de presentacion de la region
    Por: JAsanza
	Fecha: Octubre 2022
    *p_tipo el codigo para el tipo de region que se debe presentar
    *p_id el codigo de la inversion replanificada
    *p_idpadre el codigo de la inversion de la cual se copio la replanificacion 
    * retorno 1: si son iguales los datos 0: si tienen alguna diferencia
    */
    FUNCTION F_ELEMENTOREPLANIFICADO (P_TIPO VARCHAR2, P_ID NUMBER, P_IDPADRE NUMBER, P_CODIGOGRUPO VARCHAR2 DEFAULT NULL ) RETURN NUMBER as
    v_regTabla data.T_CORP_UDC%rowtype ;
    TYPE CurTyp IS REF CURSOR;
    v_curInversion   CurTyp;
    v_curInversionPadre   CurTyp;
    v_cadena clob;
    v_cadenaPadre clob ;
    v_sql varchar2(5000);
    v_sqlpadre varchar2(5000);
    BEGIN

        /*OBTENER LA COMPANIA DE LA INVERSION*/
        select  max(compania) into  v_compania from data.t_icom_inversiones where id = P_ID and rownum=1;
        begin
            SELECT * into v_regTabla 
            from data.T_CORP_UDC 
            where ID_CABECERA = 'ICOM_VAL'
            and ID_TABLA = p_tipo
           -- AND codigocompania=v_compania
            and activo = 1 ;
        exception when others then 
            raise_application_error(-20100, 'No existe la tabla general ICOM_VAL para la empresa '||v_compania);
        end;
        dbms_output.put_line( 'v_regTabla.descripcion: '||v_regTabla.descripcion   );
        if (v_regTabla.descripcion = 'TABLA' OR v_regTabla.descripcion = 'CAMPOS') then
            if p_codigogrupo is null then
                v_sql := v_regTabla.valor || p_id;
                v_sqlpadre := v_regTabla.valor || p_idpadre;
            else
                v_sql := v_regTabla.valor || p_id||' and codigogrupo = '||p_codigogrupo;
                v_sqlpadre := v_regTabla.valor || p_idpadre||' and codigogrupo = '||p_codigogrupo ;
            end if;    
        elsif (v_regTabla.descripcion = 'TABLA1' ) then    
           v_sql := v_regTabla.valor;
           v_sql := replace(v_sql, ':ID',  p_id ) ;
           v_sql := replace(v_sql, ':TIPO',  p_codigogrupo ) ;
           
           v_sqlpadre := v_regTabla.valor; 
           v_sqlpadre := replace(v_sqlpadre, ':ID',  p_idpadre ) ;
           v_sqlpadre := replace(v_sqlpadre, ':TIPO',  p_codigogrupo ) ;
        else
            v_sql := v_regTabla.VALOR||nvl(v_regTabla.DESCRIPCION2,' ')||nvl(v_regTabla.VALOR2,' ')||nvl(v_regTabla.valor3,' ');
            v_sql := replace(upper(v_sql), ':ID',  p_id ) ;
            v_sqlpadre := v_regTabla.VALOR||nvl(v_regTabla.DESCRIPCION2,' ')||nvl(v_regTabla.VALOR2,' ')||nvl(v_regTabla.valor3,' ');
            v_sqlpadre := replace(upper(v_sqlpadre), ':ID',  p_idpadre ) ;
        end if;
        
       dbms_output.put_line( 'v_sql: '||v_sql   );
       dbms_output.put_line( 'v_sqlpadre: '||v_sqlpadre   );
       
        OPEN v_curInversion FOR v_sql ;
        OPEN v_curInversionPadre FOR v_sqlpadre ; 
        
        LOOP
            FETCH v_curInversion INTO v_cadena;
            FETCH v_curInversionPadre INTO v_cadenaPadre;
            
           -- dbms_output.put_line( 'DATOPADRE '|| v_CADENAPADRE  );
            if v_curInversion%NOTFOUND and v_curInversionPadre%NOTFOUND then
                CLOSE v_curInversion;
                CLOSE v_curInversionPadre;
                RETURN 1 ;
            elsif v_curInversion%NOTFOUND or v_curInversionPadre%NOTFOUND or trim(NVL(v_cadena,'0')) != trim(NVL(v_cadenaPadre,'0')) then    
                CLOSE v_curInversion;
                CLOSE v_curInversionPadre;
                --dbms_output.put_line( 'SALE '  );
                RETURN 0 ;
            end if;    
        END LOOP;
    END; 
    
    /* Procedmiento que verifica copia y actualiza para replanificar una inversion
    Por: JAsanza
	Fecha: Octubre 2022
    *p_id_padre el id de la inversion que se va ha replanificar
    *p_idmotivo es el codigo del motivo de replanificacion
    *p_descripcion es la razon de la replanificacion
    *p_usuari es el usurio que esta realizando la accion
    *p_id es el id de la replanificacion
    */
    PROCEDURE SP_REPLANIFICAR ( P_IDPADRE NUMBER, P_IDMOTIVO VARCHAR2, P_DESCRIPCION VARCHAR2, P_USUARIO VARCHAR2, P_ID OUT NUMBER) AS
    v_id number;
    BEGIN
        
		--Si existen replanificaciones anteriores se deben eliminar
		for inv in ( select id from data.t_icom_inversiones where idpadre = p_idpadre and estado = 0  and idetapa = 5 )
        loop
            --elimina
            DATA.PK_ICOM_CRUD.SP_BORRAR_INVERSION (P_ID => inv.id, P_USUARIO => P_USUARIO ) ;
        end loop;
		--Se crea la nueva replanificacion
        DATA.PK_ICOM_CRUD.SP_PRO_COPIAR( P_ID => P_IDPADRE,
                P_ID_NEW => P_ID,
                P_USUARIO => P_USUARIO,
                P_NUEVO => 0       );
        --actualiza los datos para que sea replanificacion
        update data.t_icom_inversiones
        set idpadre = p_idpadre, replanificacionmotivo = p_idmotivo, 
            replanificaciondescripcion = p_descripcion, estado = 0, idetapa = 5
        where id = p_id ;
 
    END;
    
    /* Procedimiento que cambia el p_id y lo pasa a se el pd_idpadre con todos los hijos
    *P_ID   Codigo de la inversion replanificada
    *P_IDPADRE Codigo de la inversion original
    */
    PROCEDURE SP_INTERCAMBIOID ( P_ID NUMBER, P_IDPADRE NUMBER, P_USUARIO VARCHAR2 ) AS
    
    v_idtemp number ;
    v_idpadre number; 
    v_id number;
    v_regidpadre data.t_icom_inversiones%rowtype;
    v_regid data.t_icom_inversiones%rowtype;
    BEGIN
        --cargamos los registros del id y de idpadre
        select * into v_regid from data.t_icom_inversiones where id = p_id ;
        select * into v_regidpadre from data.t_icom_inversiones where id = p_idpadre ;
        --creamos un temporal para el idadre
        select MAX(id)+TO_NUMBER(TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS')) into v_idtemp from data.t_icom_inversiones ;
        --copiamos el idpadre(1) al temporal (-1)
        DATA.PK_ICOM_CRUD.SP_PRO_COPIAR( P_ID => P_IDPADRE,
                P_ID_NEW => v_idtemp,
                P_USUARIO => v_regidpadre.usuario,
                P_NUEVO => 0       );
        --elimino el idpadre (1)
        DATA.PK_ICOM_CRUD.SP_BORRAR_INVERSION (P_ID => P_IDPADRE, P_USUARIO => P_USUARIO) ;        
        --copiamos el id(2) al idpadre(1)
        v_idpadre := p_idpadre ;
        v_id := p_id;
        DATA.PK_ICOM_CRUD.SP_PRO_COPIAR( P_ID => P_ID,
                P_ID_NEW => v_idpadre,
                P_USUARIO => v_regid.usuario,
                P_NUEVO => 0       );
        --elimino el id(2)
        DATA.PK_ICOM_CRUD.SP_BORRAR_INVERSION (P_ID => P_ID, P_USUARIO => P_USUARIO) ;
        --copiamos el temporal al id(2)
        DATA.PK_ICOM_CRUD.SP_PRO_COPIAR( P_ID => v_idtemp,
                P_ID_NEW => v_id,
                P_USUARIO => v_regidpadre.usuario,
                P_NUEVO => 0       );        
        --elimino el temporal(-1)
        DATA.PK_ICOM_CRUD.SP_BORRAR_INVERSION (P_ID => v_idtemp, P_USUARIO => P_USUARIO) ;        
    END ;
    
    /*
    * Procedemiento que borra fisicamente la inversion
    * p_id es la clave principal de la inversion
    */
    PROCEDURE SP_BORRAR_INVERSION (P_ID NUMBER, P_USUARIO VARCHAR2) AS
    BEGIN
        --se debe borrar todas las hijas en caso de que existan
        for inv in (select id from data.t_icom_inversiones where idgrupo = p_id ) 
        loop
            sp_borrar_inversion (P_ID => inv.id, P_USUARIO => P_USUARIO ) ;
        end loop;
        
        
        for deleted in (
            SELECT 
                PK_FINZ_SRI_GESTION.f_trimetiqueta(ID)ID,
                upper(PK_FINZ_SRI_GESTION.f_trimetiqueta(CAMPO1))TABLA,
                p_id idinversion
            FROM pk_commons.f_split2table(
            '|T_ICOM_PRODUCTO_DIS_PARAMETRO;|T_ICOM_PRODUCTO_DESCUENTO;|T_ICOM_PRODUCTO_CANTIDAD;|T_ICOM_PRODUCTODISTRIBUCION;
            |T_ICOM_INVERSION_PRODUCTO;|T_ICOM_INVERSION_PROCESO;|T_ICOM_INVERSION_KPI;|T_ICOM_INVERSION_GASTO;|T_ICOM_CLIENTE_PDV_RUCS;
            |T_ICOM_CLIENTE_PDV_LOCAL;|T_ICOM_CLIENTE_PDV;|T_ICOM_CLIENTE_MATERIAL;|T_ICOM_CLIENTE_FECHAS;|T_ICOM_INVERSION_CLIENTE;
            |T_ICOM_INVERSION_CLIENTE_G;|T_ICOM_INVERSION_ANALISIS;|T_ICOM_INVERSION_VENTAS;|T_ICOM_INVERSION_KPI;|T_ICOM_INVERSION_GASTODISTRIBUCION;
            ',';','|')
        )
        loop
            DBMS_OUTPUT.PUT_LINE('delete from '||deleted.TABLA||'  where IDINVERSION = '||deleted.idinversion||' ;');
            execute immediate 'delete from '||deleted.TABLA||'  where IDINVERSION = '||deleted.idinversion||'';
            commit;
        end loop;
        
        
        delete from data.t_icom_inversiones   where ID = p_id ;
        
        --crear la auditoria            
        PK_ICOM_COMMONS.SP_AUDITORIA(
            P_USUARIO => P_USUARIO,
            P_IDINVERSION => p_id,
            P_IDETAPA => null,
            P_CODIGOGRUPO => null,
            P_IDACCION => 4,
            P_DESCRIPCION => 'BORRA LA INVERSION ID :'||P_ID 
          );
    END;
    
    
    
    PROCEDURE SP_OBSERVACIONRECHAZOPDV(P_IDINVERSION NUMBER)
    AS 
    v_codigoPDV NUMBER;
    CURSOR OBSERVACIONES IS
         SELECT C02 AS CODIGOPDV, C03 AS MOTIVO 
         FROM DATA.VT_APEX_EXCEL WHERE C03 IS NOT NULL
         AND C02 IS NOT NULL
         AND TRIM(UPPER(C02)) <> 'NOMBRE';
    BEGIN 
    
    APEX_DEBUG_MESSAGE.ENABLE_DEBUG_MESSAGES(p_level => 3);
        FOR registro IN OBSERVACIONES
        LOOP
        
            BEGIN
            
           
           
                select  TO_NUMBER(TRIM(SUBSTR(registro.CODIGOPDV, 1, INSTR(registro.CODIGOPDV, '-', 1, 1)-1 )))
                 INTO v_codigoPDV FROM DUAL; 
 
                UPDATE DATA.T_ICOM_CLIENTE_PDV
                SET OBSERVACIONRECHAZO =  registro.MOTIVO
                WHERE IDINVERSION = P_IDINVERSION
                AND CODIGOPDV = v_codigoPDV;
               
            EXCEPTION WHEN OTHERS THEN
                v_codigoPDV := NULL;
            END;
        
        END LOOP;
    END;
    
    /*Procedimiento que graba la modificacion manual de los datos del analisis*/
    PROCEDURE SP_GUARDARANALISIS (P_IDINVERSION NUMBER, P_MargenBrutoEstandar NUMBER, P_MotivoCambioMargen VARCHAR2, 
                                  P_VentaUndMeta NUMBER, P_VentaUsdMeta NUMBER ) AS
    BEGIN
        update data.t_icom_inversiones
        set MargenBrutoEstandar = P_MargenBrutoEstandar, MotivoCambioMargen = P_MotivoCambioMargen,
            VentaUndMeta = P_VentaUndMeta, VentaUsdMeta = P_VentaUsdMeta
        where id = P_idinversion ;    
        --borra los objetivos KPI
        PK_ICOM_ANALISIS.SP_BORRAROBJETIVOKPI( P_ID => P_IDINVERSION );
    END;
    
    
    /* Crear un archivo de contrato */
    PROCEDURE SP_CREARARCHIVO (P_CLOBCONTENIDO CLOB, P_IDINVERSION  NUMBER, P_CODIGOGRUPO VARCHAR2, P_CODIGOPDV VARCHAR2, 
                               P_NOMBRE VARCHAR2, P_IDCONTRATO NUMBER, P_TIPOCONTRATO VARCHAR2, P_ESTADO VARCHAR2, 
                               P_NOMBREUSUARIO VARCHAR2, P_ARCHIVO IN VARCHAR DEFAULT NULL ) AS
        V_NUMEROARCHIVO NUMBER ;
        V_CANTIDAD NUMBER;
        V_MULTIPLE_ARCHIVO APEX_APPLICATION_GLOBAL.vc_arr2;
    BEGIN
        dbms_output.put_line( 'Ingresa '  );
        --borra todos los anteriores ya que debe existir solo uno
        SP_BORRARARCHIVO(
            P_IDCONTRATO => P_IDCONTRATO,
            P_IDINVERSION => P_IDINVERSION,
            P_CODIGOGRUPO => P_CODIGOGRUPO,
            P_CODIGOPDV => P_CODIGOPDV,
            P_TIPOCONTRATO => P_TIPOCONTRATO
        );
        -- GENERO CODIGO UNICO
        PK_COMMONS.SP_SECUENCIA ('T_ICOM_ARCHIVOS', V_NUMEROARCHIVO);
        
        IF P_ARCHIVO IS NULL THEN
            dbms_output.put_line( 'Inserta clob '  );
            INSERT INTO DATA.T_ICOM_ARCHIVOS 
            ( NUMEROARCHIVO, CLOBCONTENIDO , IDINVERSION , CODIGOGRUPO , CODIGOPDV , 
              NOMBRE , IDCONTRATO , TIPOCONTRATO , ESTADO , FECHA , NOMBREUSUARIO )
            VALUES 
            ( V_NUMEROARCHIVO, P_CLOBCONTENIDO , P_IDINVERSION , P_CODIGOGRUPO , P_CODIGOPDV , 
              P_NOMBRE , P_IDCONTRATO , P_TIPOCONTRATO , P_ESTADO , SYSDATE , P_NOMBREUSUARIO );
        ELSE
            dbms_output.put_line( 'Inserta archivo Blob '  );
            V_MULTIPLE_ARCHIVO := apex_util.string_to_table(P_ARCHIVO);
            FOR i in 1..V_MULTIPLE_ARCHIVO.count 
            LOOP
                dbms_output.put_line( 'Recorre archivo '  );
                SELECT COUNT(*)  INTO V_CANTIDAD FROM APEX_APPLICATION_TEMP_FILES WHERE name = V_MULTIPLE_ARCHIVO(i);
                
                IF V_CANTIDAD >=1 AND V_MULTIPLE_ARCHIVO(i) IS NOT NULL THEN
                    dbms_output.put_line( 'Genera archivo en tabla '  );
                    INSERT INTO DATA.T_ICOM_ARCHIVOS 
                    ( NUMEROARCHIVO, BLOBCONTENIDO , IDINVERSION , CODIGOGRUPO , CODIGOPDV , 
                      NOMBRE , IDCONTRATO , TIPOCONTRATO , ESTADO , FECHA , NOMBREUSUARIO, NOMBREARCHIVO, MIMETYPE )
                    SELECT V_NUMEROARCHIVO, blob_content, P_IDINVERSION , P_CODIGOGRUPO , P_CODIGOPDV , 
                            P_NOMBRE , P_IDCONTRATO , P_TIPOCONTRATO , P_ESTADO , SYSDATE , P_NOMBREUSUARIO, 
                            REPLACE(FILENAME, ',', ' ') , mime_type
                    FROM APEX_APPLICATION_TEMP_FILES 
                    WHERE name = V_MULTIPLE_ARCHIVO(i) AND ROWNUM=1;
                    --commit;
                END IF;
             END LOOP;
        END IF;
    END ;
    
    PROCEDURE SP_ModificaEstadoArc (P_IDCONTRATO NUMBER DEFAULT 0, P_IDINVERSION NUMBER DEFAULT 0, 
        P_CODIGOGRUPO VARCHAR2 DEFAULT NULL, P_CODIGOPDV VARCHAR2 DEFAULT NULL, P_TIPOCONTRATO VARCHAR2 DEFAULT NULL, 
        P_ESTADO VARCHAR2, P_NUMEROARCHIVO NUMBER DEFAULT 0 ) AS
    BEGIN
        if nvl(p_numeroarchivo,0) = 0 then
            update data.t_icom_archivos
            set estado = p_estado
            where idinversion = p_idinversion 
            and ( p_codigogrupo is null or codigogrupo = p_codigogrupo )
            and ( p_codigopdv is null or codigopdv = p_codigopdv)
            and idcontrato = p_idcontrato
            and tipocontrato = p_tipocontrato ;
        else
            update data.t_icom_archivos
            set estado = p_estado
            where numeroarchivo = p_numeroarchivo ;
        end if;
    END SP_ModificaEstadoArc;
    
    PROCEDURE SP_BorrarArchivo (P_NUMEROARCHIVO NUMBER DEFAULT 0, P_IDCONTRATO NUMBER DEFAULT NULL, P_IDINVERSION NUMBER DEFAULT NULL, 
        P_CODIGOGRUPO VARCHAR2 DEFAULT NULL, P_CODIGOPDV VARCHAR2 DEFAULT NULL, P_TIPOCONTRATO VARCHAR2 DEFAULT NULL ) AS
    BEGIN
        
        if nvl(p_numeroarchivo,0) > 0 then
            delete from data.t_icom_archivos
            where numeroarchivo = p_numeroarchivo ;
        elsif ( nvl(p_idcontrato,0)> 0  and nvl(p_idinversion,0) > 0 and length(p_tipocontrato) > 0  ) then
            delete from data.t_icom_archivos
            where idinversion = p_idinversion 
            and ( p_codigogrupo is null or codigogrupo = p_codigogrupo )
            and ( p_codigopdv is null or codigopdv = p_codigopdv)
            and idcontrato = p_idcontrato
            and tipocontrato = p_tipocontrato ;
        end if;
        
    END SP_BorrarArchivo;
    
       
     /*Procedimiento para buscar los correos y enviarlos de acuerdo a los procesos*/
     PROCEDURE SP_NOTIFICACION_PROCESOS ( P_IDINVERSION NUMBER, P_MOTIVO VARCHAR2 ) AS
        v_correos varchar2(600);
        v_inversiontipo varchar2(100);
        v_asunto varchar2(100);
        v_mensaje				CLOB;
        v_fechainicio date;
        v_fechafin date ;
     BEGIN
        select  max(compania) into  v_compania from data.t_icom_inversiones where id = p_idinversion and rownum=1;
        --se busca los correos de los usuarios a ser notificados
        begin
            select LISTAGG(valor, '; ') WITHIN GROUP (ORDER BY valor )  
            into v_correos
            from data.T_CORP_UDC 
            where ID_CABECERA = 'ICOM_PROCE' 
            AND codigocompania=v_compania
            and ID_TABLA in ( select distinct idproceso
                            from data.T_ICOM_INVERSION_PROCESO p
                            where p.idinversion = p_idinversion
                            and estado = 1 ) ;
        exception when no_data_found then
            raise_application_error(-20000, 'Error no tienen usuarios asignados a los procesos');   
        end ; 
        
        select inversiontipo, fechainicio, fechafin
        into v_inversiontipo, v_fechainicio, v_fechafin
        from data.vt_icom_inversiones
        where id = p_idinversion ;
        
        v_asunto := 'Notificacion clausura inversion procesos operativos';
          
        v_mensaje := '<p>Estimado Usuario </p>
            <p>&nbsp;</p>
            <p> Se ha clausurado el n&uacute;mero de ID '|| p_idinversion||' de la inversi&oacute;n '
            ||v_inversiontipo ||' del per&iacute;odo '|| v_fechainicio ||' al '|| v_fechafin
            || ' por '|| p_motivo||' por favor considerar los procesos operativos que se activaron con est&aacute; promoci&oacute;n : </p> ' ;
        
        for pro in (select distinct p.idproceso, v.descripcion
                            from data.T_ICOM_INVERSION_PROCESO p
                                inner join data.VT_ICOM_PROCESO v on (p.idproceso = v.idproceso ) 
                            where p.idinversion = p_idinversion
                            and p.estado = 1 order by p.idproceso  ) loop
            v_mensaje := v_mensaje || '<li>'|| pro.idproceso|| ' - ' || pro.descripcion ||'.</li>' ;
        end loop;                            
        v_mensaje := v_mensaje ||'
            <p>&nbsp;</p>
            <p>Atentamente,</p>
            <p>&nbsp;</p>
            <p>ZAIMELLA DEL ECUADOR S.A.</p>';
        
        PK_CORP_CORREO.SP_ENVIO(
                    P_MODULO => 'ICOM',
                    P_TO => v_correos,
                    P_FROM => 'notificacion@zaimella.com',
                    P_SUBJECT => v_asunto,
                    P_BODY => v_mensaje
                  );
        
     END SP_NOTIFICACION_PROCESOS ;
     
     PROCEDURE SP_CIERRENEGOCIACION ( P_IDINVERSION NUMBER, P_CODIGOGRUPO VARCHAR2 ) AS
     BEGIN
        update data.t_icom_inversion_cliente_g 
        set negociacion=3
        where idinversion = p_idinversion
        and codigogrupo = p_codigogrupo
        ;
 
     END SP_CIERRENEGOCIACION ;
     
    /*Procedimiento para guardar o editar la configuracion rebate */
    PROCEDURE SP_CONF_REBATE(P_ID IN OUT NUMBER, P_NOMBRE VARCHAR,
             P_INVERSIONTIPO VARCHAR, P_TIPOREBATE NUMBER, P_ESTADO NUMBER, P_COMPANIA VARCHAR, P_USAFORMULA NUMBER ) AS
        V_TABLA VARCHAR(50) := 'T_ICOM_CONF_REBATE';
        V_INICIOSCRIP CLOB;
    BEGIN 
        IF P_USAFORMULA = 1 THEN
            --Busca el valor por defecto que se debe poner en la formula
            select descripcion||' '||valor||' '||valor2||' '||descripcion2
            into v_inicioscrip
            from data.T_CORP_UDC            
            where id_cabecera = 'ICOM_PARAM' and id_tabla = 21 
            AND codigocompania=p_compania;
        ELSE
            v_inicioscrip := NULL ;
        END IF;
        
        IF(P_ID IS NULL) THEN
            P_ID := data.PK_COMMONS.F_SECUENCIA (V_TABLA);
            INSERT INTO data.t_icom_conf_rebate 
            (id, nombre, idinversiontipo, tiporebate, estado, compania, formula, usaformula ) 
            VALUES 
            (P_ID, P_NOMBRE, P_INVERSIONTIPO, P_TIPOREBATE, P_ESTADO, P_COMPANIA, v_inicioscrip, P_USAFORMULA );
        ELSE
            UPDATE data.t_icom_conf_rebate 
            SET nombre = p_nombre, idinversiontipo = p_inversiontipo, tiporebate = p_tiporebate, estado = p_estado,
                formula = case when formula is null and p_usaformula = 1 then v_inicioscrip else formula end,
                usaformula = P_USAFORMULA
            WHERE ID = P_ID ;
        END IF;
    END SP_CONF_REBATE;
    
    /*Procedimiento para copiar un rebate */
    PROCEDURE SP_COPIAR_REBATE(P_ID NUMBER ) AS
        V_TABLA VARCHAR(50) := 'T_ICOM_CONF_REBATE';
    BEGIN 
        IF(P_ID IS NOT NULL) THEN
            INSERT INTO data.t_icom_conf_rebate 
            (id, nombre, idinversiontipo, tiporebate, estado, compania ) 
            select data.PK_COMMONS.F_SECUENCIA (V_TABLA), nombre, idinversiontipo, tiporebate, estado, compania 
            from data.t_icom_conf_rebate
            where id = P_ID;
        END IF;
    END SP_COPIAR_REBATE; 
    
    /*Procedimiento para copiar un gasto rebate */
    PROCEDURE SP_CopiarGastoRebate(P_ID NUMBER, P_IDREBATE VARCHAR2, P_FUENTE VARCHAR2, 
        P_VALOR NUMBER, P_OBSERVA VARCHAR2, P_CALCULO VARCHAR2, P_VALORPORCENTAJE NUMBER ) AS
        
    BEGIN 
      insert into t_icom_inversion_gasto 
      ( idinversion, gastotipo, tipo, periodo, fuente, valor, observacion, calculo, valorporcentaje )
      values
      (P_ID, 'GASTOREBATE', P_IDREBATE, NULL, P_FUENTE, P_VALOR, P_OBSERVA, P_CALCULO, P_VALORPORCENTAJE ) ;
    
    END SP_CopiarGastoRebate; 
    
    /*Procedimiento para subri informacion masiva de inversiones desde un archivo excel*/
    PROCEDURE SP_INVERSIONMASIVAGRUPAL (P_COMPANIA VARCHAR2, P_USUARIO VARCHAR2 ) AS
        v_periodo varchar2(500);
        v_anioAnalisis varchar2(500);
        v_tipoGrafico varchar2(500);
        v_idpadre number ;
        v_diasinicio date ;
        v_analista varchar2(500);
    BEGIN
        --fecha para asignar dato de fecha en Excel
        v_diasinicio := to_date('1899-12-30', 'YYYY-MM-DD');
        
        --Se busca todas las inversiones que sea padres
        for pa in (SELECT v.C02 idPadre, v.C05 idInversionTipo, UPPER(TRIM(v.C06)) nombre, v.C07 idArea, 
                       v.C13 objetivo, v.C14 origen, v.C15 tipo, (v_diasinicio + v.C16) fechaInicio, (v_diasinicio + v.C17) fechaFin,
                        UPPER(TRIM(v.C18)) comentario,  UPPER(TRIM(v.C19)) problema, v.C20 oportunidad
                   FROM VT_APEX_EXCEL v        
                   WHERE TRIM(C02) IS NOT NULL --tiene codigo padre
                   AND TRIM(C05) IS NOT NULL AND TRIM(C06) IS NOT NULL AND TRIM(C07) IS NOT NULL ) -- AND TRIM(C16) IS NOT NULL AND TRIM(C17) IS NOT NULL ) 
        loop
            --busco los datos de acuerdo al idinversiontipo
            SELECT descripcion2,valor,valor2
            into v_periodo, v_anioAnalisis, v_tipoGrafico
            FROM data.T_CORP_UDC where ID_CABECERA ='ICOM_TINV' and id_tabla = pa.idInversionTipo;
            
            --busco el analista
            v_analista :=  PK_ICOM_COMMONS.F_ANALISTA(P_INVERSIONTIPO => pa.idInversionTipo, 
                                                      P_AREA => pa.idArea, 
                                                      P_COMPANIA => p_compania);
            
            v_idpadre := null;            
            --Inserta el padre
            SP_INVERSION_GUARDAR_GENERALES(p_id=>v_idpadre,
                                  p_inversiontipo=>pa.idInversionTipo,
                                  p_grupal=>1,
                                  p_nombre=>pa.nombre,
                                  p_area=>pa.idArea,
                                  p_analista=>v_analista,
                                  P_PROBLEMAS=> pa.problema,
                                  P_OPORTUNIDADES=>pa.oportunidad,  
                                  P_USUARIO=> p_usuario,
                                  p_compania=>p_compania,
                                  P_ORIGEN => pa.origen, 
                                  P_TIPO =>pa.tipo, 
                                  P_FECHA_INICIO =>pa.fechaInicio,
                                  P_FECHA_FIN =>pa.fechaFin,
                                  P_ANALISISPERIODO => v_periodo,
								  P_ANALISISANIO => v_anioAnalisis,
                                  P_ANALISISVISTA => v_tipoGrafico
                                            
            );
            --commit;
            --actualiza comentario y antecedentes
            if nvl(v_idpadre,0) > 0 then
            
                if pa.comentario is not null then
                    --se actualiza el comentario
                    update data.t_icom_inversiones 
                    set comentario = pa.comentario
                    where id = v_idpadre ;
                end if;
                
                --crea los procesos
                SP_INVERSION_GUARDAR_PROCESO(P_ID =>v_idpadre,
                                             P_ORIGEN =>pa.origen, 
                                             P_COMPANIA =>p_compania);
                                             
                --crea los KPI del objetivo
                PK_ICOM_ANALISIS.SP_CREAOBJETIVOKPI(P_ID =>v_idpadre,
                                                    P_AREA=>pa.idArea,
                                                    P_IDOBJETIVO=>pa.objetivo,
                                                    P_COMPANIA=>p_compania);
                --Se buscan las inversiones hijas
                SP_INVERSIONMASIVA(
                    P_COMPANIA => P_COMPANIA,
                    P_USUARIO => P_USUARIO,
                    P_IDPADRE => pa.idpadre,
                    P_IDINVERSION => v_idpadre
                  );
            end if;
            --v_idpadre := null;
            
        end loop;
        --Se buscan las inversiones normales
        SP_INVERSIONMASIVA(
            P_COMPANIA => P_COMPANIA,
            P_USUARIO => P_USUARIO
          );
    END SP_INVERSIONMASIVAGRUPAL;
    
    /*Procedimiento para subri informacion masiva de inversiones desde un archivo excel*/
    PROCEDURE SP_INVERSIONMASIVA (P_COMPANIA VARCHAR2, P_USUARIO VARCHAR2, 
        P_IDPADRE NUMBER DEFAULT NULL, P_IDINVERSION NUMBER DEFAULT NULL ) AS
        v_periodo varchar2(500);
        v_anioAnalisis varchar2(500);
        v_tipoGrafico varchar2(500);
        v_idInversion number ;
        v_diasinicio date ;
        v_analista varchar2(500);
    BEGIN
        --fecha para asignar dato de fecha en Excel
        v_diasinicio := to_date('1899-12-30', 'YYYY-MM-DD');
        
        --Se busca todas las inversiones que no sea padres
        for pa in (SELECT v.C05 idInversionTipo, UPPER(TRIM(v.C06)) nombre, v.C07 idArea, 
                       RTRIM(TRIM(REPLACE(C08, ',', ':')),':') producto, RTRIM(TRIM(REPLACE(C09, ',', ':')),':') regalo,
                       RTRIM(TRIM(REPLACE(C10, ',', ':')),':') grupo, RTRIM(TRIM(REPLACE(C11, ',', ':')),':') cliente, 
                       RTRIM(TRIM(REPLACE(C12, ',', ':')),':') pdv,
                       v.C13 objetivo, UPPER(TRIM(v.C18)) comentario,  UPPER(TRIM(v.C19)) problema, v.C20 oportunidad,
                       v.C14 origen, v.C15 tipo, (v_diasinicio + v.C16) fechaInicio, (v_diasinicio + v.C17) fechaFin
                   FROM VT_APEX_EXCEL v        
                   WHERE ( ( P_IDPADRE IS NULL AND TRIM(C03) IS NULL ) OR (TRIM(C03) = P_IDPADRE ) )  --tiene codigo padre
                   AND TRIM(C05) IS NOT NULL AND TRIM(C06) IS NOT NULL AND TRIM(C07) IS NOT NULL AND TRIM(C16) IS NOT NULL AND TRIM(C17) IS NOT NULL
                   --AND TRIM(C08) IS NOT NULL 
                   AND ( TRIM(C10) IS NOT NULL OR TRIM(C11) IS NOT NULL ) ) 
        loop
            --busco los datos de acuerdo al idinversiontipo
            SELECT descripcion2,valor,valor2
            into v_periodo, v_anioAnalisis, v_tipoGrafico
            FROM data.T_CORP_UDC where ID_CABECERA ='ICOM_TINV' and id_tabla = pa.idInversionTipo;
            --busco el analista
            v_analista :=  PK_ICOM_COMMONS.F_ANALISTA(P_INVERSIONTIPO => pa.idInversionTipo, 
                                                      P_AREA => pa.idArea, 
                                                      P_COMPANIA => p_compania);
            --Inserta la inversion
            v_idInversion := null;
            SP_INVERSION_GUARDAR_GENERALES(p_id=>v_idInversion,
                                  p_inversiontipo=>pa.idInversionTipo,
                                  p_grupal=> 0,
                                  p_nombre=>pa.nombre,
                                  p_area=>pa.idArea,
                                  p_analista=>v_analista,
                                  P_PROBLEMAS=> pa.problema,
                                  P_OPORTUNIDADES=>pa.oportunidad,  
                                  P_USUARIO=> p_usuario,
                                  p_compania=>p_compania,
                                  P_ORIGEN => pa.origen, 
                                  P_TIPO =>pa.tipo, 
                                  P_FECHA_INICIO =>pa.fechaInicio,
                                  P_FECHA_FIN =>pa.fechaFin,
                                  P_ANALISISPERIODO => v_periodo,
								  P_ANALISISANIO => v_anioAnalisis,
                                  P_ANALISISVISTA => v_tipoGrafico
                                            
            );
            --commit;
            --actualiza los demas valores
            if nvl(v_idInversion,0) > 0 then
                if pa.comentario is not null or P_IDINVERSION is not null then
                    --se actualiza el comentario
                    update data.t_icom_inversiones 
                    set comentario = pa.comentario, idgrupo = P_IDINVERSION
                    where id = v_idInversion ;
                    
                    UPDATE DATA.T_ICOM_INVERSIONES SET 
                    (FECHAINICIO, FECHAFIN) =(SELECT MIN(FECHAINICIO), MAX(FECHAFIN) FROM DATA.T_ICOM_INVERSIONES WHERE IDGRUPO=P_IDINVERSION)
                    WHERE ID=P_IDINVERSION;
                    
                    UPDATE DATA.T_ICOM_INVERSIONES SET 
                    DURACION = DATA.PK_ICOM_COMMONS.F_DURACION(P_FECHA_INICIO => FECHAINICIO, P_FECHA_FIN => FECHAFIN)
                    WHERE ID=P_IDINVERSION;   
                end if;
                
                --crea los procesos
                SP_INVERSION_GUARDAR_PROCESO(P_ID =>v_idInversion,
                                             P_ORIGEN =>pa.origen, 
                                             P_COMPANIA =>p_compania);
                --crea los KPI del objetivo
                PK_ICOM_ANALISIS.SP_CREAOBJETIVOKPI(P_ID =>v_idInversion,
                                                    P_AREA=>pa.idArea,
                                                    P_IDOBJETIVO=>pa.objetivo,
                                                    P_COMPANIA=>p_compania);
                
              
                
                --Se crea los grupos o los clientes
                SP_CLIENTEAGREGAR(P_ID =>v_idInversion,
                                        P_CLIENTE =>case when pa.cliente is null then pa.grupo else pa.cliente end ,
                                        P_ALCANCE =>case when pa.cliente is null then 'G' else 'CL' end , 
                                        P_COMPANIA => p_compania);
               
                --Se crean los PDV
                if pa.pdv is not null then
                    SP_PDVAGREGAR(P_ID =>v_idInversion,
                                        P_PDV =>pa.pdv,
                                        P_ALCANCE =>'P', 
                                        P_COMPANIA =>p_compania,
                                        P_USUARIO => P_USUARIO);   
                end if;
                
                  if(pa.producto is not null) then 
                --Se crean los productos
                SP_PRODUCTOAGREGAR(P_ID =>v_idInversion,
                                    P_PRODUCTO =>pa.producto,
                                    P_ALCANCE =>'P', 
                                    P_TIPO => 1 ,
                                    P_COMPANIA =>p_compania);
                                    
                   
                else 
                     update data.t_icom_inversiones 
                    set PRODUCTOTODO = 1
                    where id = v_idInversion ;
                    
                    sp_todosproductos (P_IDINVERSION  =>v_idInversion, P_TIPO  =>1, P_COMPANIA =>p_compania);
               
                end if;    
                
                 --Se crean los productos regalo    
                    if pa.regalo is not null then
                        SP_PRODUCTOAGREGAR(P_ID =>v_idInversion,
                                        P_PRODUCTO =>pa.regalo,
                                        P_ALCANCE =>'P', 
                                        P_TIPO => 2 ,
                                        P_COMPANIA =>p_compania);
                    end if;
                
                --commit;
            end if;
        end loop;
        
    END SP_INVERSIONMASIVA;
    
    /*Procedimiento para vaciar el producto de materia prima, */
    PROCEDURE SP_PRODUCTOVACIAR (P_ID NUMBER, P_TIPO NUMBER ) AS
        
    BEGIN
        DELETE DATA.t_icom_inversion_producto WHERE idinversion=P_ID AND TIPO=P_TIPO; 
        
    END SP_PRODUCTOVACIAR;
    
    /*Procedimiento que actualiza las fechas a la inversion y a los grupos*/
    PROCEDURE SP_cambiarFecha (P_IDINVERSION NUMBER, P_FECHAINICIO DATE, P_FECHAFIN DATE) AS
    V_NEGOCIACION NUMBER ;
    v_idetapa number;
    BEGIN
        --Actualiza las fechas de la inversion
        UPDATE DATA.T_ICOM_INVERSIONES 
        SET FECHAINICIO = P_FECHAINICIO, FECHAFIN = P_FECHAFIN, 
            DURACION = DATA.PK_ICOM_COMMONS.F_DURACION(P_FECHA_INICIO => P_FECHAINICIO, P_FECHA_FIN => P_FECHAFIN)
        WHERE ID = P_IDINVERSION ;
        
        ---TIENE NEGOCIACION 
        SELECT PK_ICOM_COMMONS.F_TIENENEGOCIACION(P_INVERSIONTIPO=> IDINVERSIONTIPO, 
                        P_ORIGEN =>IDORIGEN, P_TIPO =>IDTIPO,
                        P_COMPANIA =>COMPANIA) INTO V_NEGOCIACION
                        FROM T_ICOM_INVERSIONES WHERE ID=P_IDINVERSION;
        
        --Actualiza las fechas de los grupos
        UPDATE  T_ICOM_INVERSION_CLIENTE_G cl
           SET ( cl.FECHAINICIO, cl.FECHAFIN ) = 
               ( select CASE WHEN i.IDETAPA =1 OR (i.IDETAPA =5 AND V_NEGOCIACION=0) or cl.NEGOCIACION=0 THEN  P_FECHAINICIO+nvl(d.dias,0) ELSE cl.FECHAINICIO END FECHAINICIO,
                        CASE WHEN i.IDETAPA =1 OR (i.IDETAPA =5 AND V_NEGOCIACION=0) or cl.NEGOCIACION=0 THEN  P_FECHAFIN+nvl(d.dias,0) ELSE cl.FECHAFIN END FECHAFIN
                 from t_icom_inversiones i
                    inner join t_icom_inversion_cliente_g g on 
                        ( i.id = g.idinversion and g.codigogrupo = cl.codigogrupo )
                    left join vt_icom_diaspercha d on
                        ( nvl(i.idorigen,0) = nvl(d.idorigen, nvl(i.idorigen,0)) and nvl(i.idtipo,0) = nvl(d.tipo, nvl(i.idtipo,0)) 
                          and g.codigocanal = d.idcanal 
                          )
                 where i.id = cl.idinversion )
           WHERE IDINVERSION = P_IDINVERSION;
           
        -- si no tiene negociacion aprueba los clientes y agrega fechas  
        IF(V_NEGOCIACION=0) THEN 
            select idetapa into v_idetapa from data.t_icom_inversiones where id = p_idinversion ;
            
                UPDATE t_icom_cliente_fechas F SET (fechainicio,  fechafin, replanificado)=
                    (SELECT fechainicio,  fechafin, CASE WHEN v_idetapa =5 THEN 1 else 0 end  
                       FROM t_icom_inversion_cliente_g C 
                      WHERE C.CODIGOGRUPO=F.CODIGOGRUPO AND C.IDINVERSION=F.IDINVERSION)
                WHERE IDINVERSION=P_IDINVERSION;
        END IF;             
        
        --borro las cantidades que existan y genero unas nuevas
        delete from DATA.T_ICOM_PRODUCTO_CANTIDAD    
        where idinversion = P_IDINVERSION ;
        --cambia las cantidad de los productos
        FOR PRODUCTO IN (SELECT CODIGOPRODUCTO, TIPO FROM DATA.T_ICOM_INVERSION_PRODUCTO  
                         WHERE IDINVERSION=P_IDINVERSION  ) LOOP
                SP_PRODUCTOCANTIDADES(P_IDINVERSION, PRODUCTO.CODIGOPRODUCTO, PRODUCTO.TIPO);
        END LOOP;                        
        
    END SP_cambiarFecha;
    
    /*Funcion que busca los dÃ­as que tiene en percha*/
    FUNCTION F_diasPecha(P_CODIGOCANAL VARCHAR2, P_IDORIGEN NUMBER, P_IDTIPO NUMBER, P_CODIGOGRUPO VARCHAR2 ) RETURN NUMBER AS 
    v_dias number;
    BEGIN
        --se busca los dÃ­as adicionales en la tabla general
        select nvl(dias,0) into v_dias 
        from data.vt_icom_diaspercha
        where idcanal = p_codigocanal
        and nvl(idorigen,P_IDORIGEN) = P_IDORIGEN 
        and nvl(tipo, P_IDTIPO) = P_IDTIPO ;
        return nvl(v_dias,0) ;
    exception when others then
            return 0 ;
    END F_diasPecha; 
    
    /*
	Procedimiento que permite el ingreso masivo de Puntos de Venta y local a la tabla T_ICOM_CLIENTE_PDV_LOCAL
	Por: JAsanza
	*/
	PROCEDURE SP_PDVLOCALAGREGAR(P_ID NUMBER, P_PDV VARCHAR, P_COMPANIA VARCHAR, P_USUARIO VARCHAR2 ) AS
	BEGIN 
			-- BUSCA LOS PUNTO DE VENTA CON SUS LOCALES EN vt_icom_clientepdv_local E INSERTA EN T_ICOM_CLIENTE_PDV_LOCAL
			MERGE INTO DATA.T_ICOM_CLIENTE_PDV_LOCAL P
            USING (SELECT CODIGOPDV, NUMERO, NOMBRECLIENTE, CODIGOLOCAL, NOMBRECOMERCIAL, NOMBRECONOCIDO, L.CODIGOGRUPO
                   FROM DATA.VT_ICOM_CLIENTEPDV_LOCAL L  
                        INNER JOIN DATA.T_ICOM_INVERSION_CLIENTE_G G ON (G.IDINVERSION = P_ID AND G.CODIGOGRUPO = L.CODIGOGRUPO )
                   WHERE L.COMPANIA=P_COMPANIA AND L.ESTADO = 1
                   AND L.CODIGOPDV||'-'||L.NUMERO IN (SELECT trim(Column_Value) FROM TABLE(Apex_String.Split(P_PDV, ':')))        
                        ) D
           ON (P.IDINVERSION=P_ID AND P.CODIGOGRUPO = D.CODIGOGRUPO AND P.CODIGOPDV=D.CODIGOPDV AND P.NUMERO = D.NUMERO )
           WHEN NOT MATCHED THEN
                  insert(IDINVERSION, CODIGOGRUPO, CODIGOPDV, NOMBRECLIENTE, NUMERO, CODIGOLOCAL, NOMBRECOMERCIAL, COMPANIA )
				  values (P_ID, D.CODIGOGRUPO, D.CODIGOPDV, D.NOMBRECLIENTE, D.NUMERO, D.CODIGOLOCAL, D.NOMBRECOMERCIAL, P_COMPANIA);
   END SP_PDVLOCALAGREGAR; 
   
   /*
	Procedimiento que permite la eliminicion o vaciado del pdv local
	Por: JAsanza
	*/
	PROCEDURE SP_PDVLOCALBORRAR (P_IDINVERSION NUMBER, P_PDV VARCHAR, P_COMPANIA VARCHAR ) AS
	BEGIN 
        if p_pdv is null then             --es vaciar los pdv local
            delete t_icom_cliente_pdv_local where IDINVERSION=P_IDINVERSION and compania = p_compania;
        else             --borrar un pdv local
            delete t_icom_cliente_pdv_local where IDINVERSION=P_IDINVERSION and compania = p_compania and trim(codigopdv||'-'||numero) = trim(p_pdv) ;
        end if;    
    END SP_PDVLOCALBORRAR; 
   
    /*Procedmiento para subir las fechas de finiquito de Pdv desde archivo*/
    PROCEDURE SP_PDVFECHAFINIQUITO (P_ID NUMBER) AS
        v_codigo number; 
    BEGIN
        FOR pVenta in ( select v.C02 codigoPdv, v.C03 fecha from VT_APEX_EXCEL v where TRIM(v.C02) IS NOT NULL and TRIM(v.C03) IS NOT NULL )
        LOOP
            begin   --Buscamos si existe en la coleccion
                select SEQ_ID into v_codigo 
                from APEX_collections
                WHERE collection_name = 'INVERSION_CODIGOPDV' 
                and c001 = P_ID and c002 = pVenta.codigoPdv and rownum = 1;
            exception when no_data_found then  v_codigo := 0 ;
                when others then  v_codigo := 0 ;
            end ;    
            if nvl(v_codigo,0) > 0 then --Actualizamos el valor en la coleccion
                 APEX_COLLECTION.UPDATE_MEMBER (
                    p_collection_name => 'INVERSION_CODIGOPDV',
                    p_seq => v_codigo,
                    p_c001 => P_ID,
                    p_c002 => pVenta.codigoPdv,
                    p_c003 => pVenta.fecha );
            end if;
        END LOOP;
    END SP_PDVFECHAFINIQUITO;
    
    /*Procedimiento para modificar la forma de pago de una inversion*/
    PROCEDURE SP_ModificaFormaPago (P_ID NUMBER, P_IDINVERSIONTIPO NUMBER, P_IDTIPO NUMBER, P_IDORIGEN NUMBER, P_COMPANIA VARCHAR ) as
    BEGIN
		update DATA.T_ICOM_INVERSION_CLIENTE_G
		set IDFORMAPAGO = DATA.PK_ICOM_COMMONS.F_FORMAPAGO(P_INVERSIONTIPO => P_IDINVERSIONTIPO, P_TIPO => P_IDTIPO, 
		                                                   P_CLIENTE=>CODIGOGRUPO, 
                                                           P_COMPANIA=>P_COMPANIA, 
														   P_IDORIGEN => P_IDORIGEN )
		where IDINVERSION = P_ID ;
		
    END SP_ModificaFormaPago; 
    
    procedure sp_todosproductos (P_IDINVERSION number, P_TIPO NUMBER, P_COMPANIA VARCHAR) AS
        v_tipo number;
        v_fechaini date;
        v_fechafin date;
        v_numeromeses number;
        v_cont number;
    begin
    
          delete t_icom_inversion_producto where tipo=1 and idinversion=P_IDINVERSION;
          
          DATA.PK_ICOM_ANALISIS.SP_REINICIARANALISIS(P_IDINVERSION);
          
          IF(P_TIPO=0) THEN 
            RETURN;
          END IF;
    
        v_tipo          :=1;
        v_numeromeses   :=24;
        v_fechafin      :=TRUNC(LAST_DAY(sysdate));
        v_fechaini      := trunc(add_months(v_fechafin,-v_numeromeses),'Month');
        
        INSERT INTO DATA.T_ICOM_INVERSION_PRODUCTO (IDINVERSION,CODIGOPRODUCTO, PRODUCTO,tipo, NUEVO,
                LINEANEGOCIO,MARCA,SUBMARCA, CODIGOBARRA, CODIGOPRODUCTOPADRE)
         SELECT DISTINCT P_IDINVERSION,   P.CODIGOPRODUCTO, P.NOMBREPRODUCTO, 1,0,P.LINEANEGOCIO, P.MARCA,
         P.SUBMARCA, P.CODIGOBARRA, P.CODIGOPRODUCTOPADRE  
         from t_trad_sellin S
         INNER JOIN T_ICOM_INVERSION_CLIENTE C ON (S.codigogrupo=C.codigogrupo AND  C.IDINVERSION=P_IDINVERSION)
         INNER JOIN VT_GZM_PRODUCTO P ON (P.CODIGOPRODUCTO=S.CODIGOPRODUCTO)
         where TRUNC(fecha) between v_fechaini  and v_fechafin and VALORVENTA>0 AND P.COMPANIA=P_COMPANIA AND S.compania=P_COMPANIA;

    end sp_todosproductos;

    /*
      Completa fechas historicas de Cierre usando exclusivamente eventos existentes
      en DATA.VT_ICOM_AUDITORIA para una compania y un mes de control.

      Responsable: Codex / usuario solicitante.
      Consideraciones:
        - La ejecucion se realiza mes a mes para limitar filas bloqueadas.
        - No contiene COMMIT ni ROLLBACK; el proceso invocador controla la transaccion.
    */
    PROCEDURE SP_REPROCESAR_FECHAS_CIERRE(
        P_ANIO                   NUMBER,
        P_MES                    NUMBER,
        P_COMPANIA               VARCHAR2,
        P_REGISTROS_ENCONTRADOS  OUT NUMBER,
        P_REGISTROS_ACTUALIZADOS OUT NUMBER
    ) AS
        V_FECHA_INICIO DATE;
        V_FECHA_FIN    DATE;
    BEGIN
        P_REGISTROS_ENCONTRADOS := 0;
        P_REGISTROS_ACTUALIZADOS := 0;

        -- Validar el lote antes de consultar auditoria o modificar inversiones.
        IF P_ANIO IS NULL OR P_ANIO NOT BETWEEN 2000 AND 2100 THEN
            RAISE_APPLICATION_ERROR(-20000, 'El anio del reproceso debe estar entre 2000 y 2100.');
        END IF;

        IF P_MES IS NULL OR P_MES NOT BETWEEN 1 AND 12 THEN
            RAISE_APPLICATION_ERROR(-20000, 'El mes del reproceso debe estar entre 1 y 12.');
        END IF;

        IF P_COMPANIA IS NULL OR TRIM(P_COMPANIA) IS NULL THEN
            RAISE_APPLICATION_ERROR(-20000, 'La compania es obligatoria para el reproceso de cierre.');
        END IF;

        V_FECHA_INICIO := TO_DATE(P_ANIO || LPAD(P_MES, 2, '0'), 'YYYYMM');
        V_FECHA_FIN := ADD_MONTHS(V_FECHA_INICIO, 1);

        /*
          Seleccionar solo inversiones con un evento de auditoria en el mes.
          Para cada una se calcula la primera entrada historica a Cierre y el
          primer fin de flujo posterior; asi se evita usar finales previos de
          replanificaciones u otros ciclos de la misma inversion.
        */
        FOR DATOS IN (
            WITH EVENTOS_LOTE AS (
                SELECT DISTINCT AUD.IDINVERSION
                  FROM DATA.VT_ICOM_AUDITORIA AUD
                  JOIN DATA.T_ICOM_INVERSIONES INV
                    ON INV.ID = AUD.IDINVERSION
                 WHERE AUD.FECHA >= V_FECHA_INICIO
                   AND AUD.FECHA < V_FECHA_FIN
                   AND INV.COMPANIA = P_COMPANIA
                   AND AUD.IDETAPA = 4
                   AND (   (AUD.IDACCION = 2 AND (UPPER(AUD.DESCRIPCION) LIKE '%CIERRE%'
                                                OR UPPER(AUD.DESCRIPCION) LIKE '%CLAUSURA%'))
                        OR (AUD.IDACCION = 6 AND UPPER(AUD.DESCRIPCION) LIKE 'PASA A CIERRE%')
                        OR (AUD.IDACCION = 6 AND UPPER(AUD.DESCRIPCION) = 'SE TERMINA EL FLUJO DE LA INVERSION')
                   )
            ),
            ENTRADA_CIERRE AS (
                SELECT AUD.IDINVERSION,
                       MIN(AUD.FECHA) AS FECHACIERRE
                  FROM DATA.VT_ICOM_AUDITORIA AUD
                  JOIN EVENTOS_LOTE LOTE
                    ON LOTE.IDINVERSION = AUD.IDINVERSION
                 WHERE AUD.IDETAPA = 4
                   AND (   (AUD.IDACCION = 2 AND (UPPER(AUD.DESCRIPCION) LIKE '%CIERRE%'
                                                OR UPPER(AUD.DESCRIPCION) LIKE '%CLAUSURA%'))
                        OR (AUD.IDACCION = 6 AND UPPER(AUD.DESCRIPCION) LIKE 'PASA A CIERRE%')
                   )
                 GROUP BY AUD.IDINVERSION
            ),
            CIERRE_CERRADO AS (
                SELECT AUD.IDINVERSION,
                       MIN(AUD.FECHA) AS FECHACIERREFIN
                  FROM DATA.VT_ICOM_AUDITORIA AUD
                  JOIN ENTRADA_CIERRE ENTRADA
                    ON ENTRADA.IDINVERSION = AUD.IDINVERSION
                   AND AUD.FECHA >= ENTRADA.FECHACIERRE
                 WHERE AUD.IDETAPA = 4
                   AND AUD.IDACCION = 6
                   AND UPPER(AUD.DESCRIPCION) = 'SE TERMINA EL FLUJO DE LA INVERSION'
                 GROUP BY AUD.IDINVERSION
            )
            SELECT INV.ID,
                   ENTRADA.FECHACIERRE,
                   CASE
                       WHEN INV.IDETAPA = 4 AND INV.ESTADO = 4
                       THEN CERRADO.FECHACIERREFIN
                   END AS FECHACIERREFIN
              FROM DATA.T_ICOM_INVERSIONES INV
              JOIN ENTRADA_CIERRE ENTRADA
                ON ENTRADA.IDINVERSION = INV.ID
              LEFT JOIN CIERRE_CERRADO CERRADO
                ON CERRADO.IDINVERSION = INV.ID
             WHERE INV.COMPANIA = P_COMPANIA
               AND INV.IDETAPA = 4
               AND INV.ESTADO IN (1, 4)
               AND (INV.FECHACIERRE IS NULL
                    OR (INV.FECHACIERREFIN IS NULL AND CERRADO.FECHACIERREFIN IS NOT NULL))
        ) LOOP
            P_REGISTROS_ENCONTRADOS := P_REGISTROS_ENCONTRADOS + 1;

            -- Completar exclusivamente fechas nulas sin alterar etapa, estado ni otros datos.
            UPDATE DATA.T_ICOM_INVERSIONES
               SET FECHACIERRE = NVL(FECHACIERRE, DATOS.FECHACIERRE),
                   FECHACIERREFIN = CASE
                                       WHEN FECHACIERREFIN IS NULL
                                            AND DATOS.FECHACIERREFIN IS NOT NULL
                                       THEN DATOS.FECHACIERREFIN
                                       ELSE FECHACIERREFIN
                                    END
             WHERE ID = DATOS.ID
               AND (FECHACIERRE IS NULL
                    OR (FECHACIERREFIN IS NULL AND DATOS.FECHACIERREFIN IS NOT NULL));

            IF SQL%ROWCOUNT > 0 THEN
                P_REGISTROS_ACTUALIZADOS := P_REGISTROS_ACTUALIZADOS + 1;
            END IF;
        END LOOP;
    END SP_REPROCESAR_FECHAS_CIERRE;

END PK_ICOM_CRUD;
/
/

