create or replace package body data.pk_cntr_rpa as
    /** Consolida la cabecera solo cuando todos sus detalles llegaron a un estado terminal. */
    procedure finalizar_ejecucion(p_id_ejecucion in number) is
        v_pendientes number;
        v_errores number;
    begin
        select count(*)
          into v_pendientes
          from data.t_cntr_rpa_ejecuciones_detalle
         where id_ejecucion = p_id_ejecucion
           and estado in ('EN_PROCESO', 'PENDIENTE_INTERVENCION', 'REINTENTABLE');

        if v_pendientes = 0 then
            select count(*)
              into v_errores
              from data.t_cntr_rpa_ejecuciones_detalle
             where id_ejecucion = p_id_ejecucion
               and estado = 'ERROR';

            update data.t_cntr_rpa_ejecuciones
               set fecha_fin = systimestamp,
                   estado = case when v_errores > 0 then 'FINALIZADA_CON_ERROR' else 'COMPLETADA' end
             where id_ejecucion = p_id_ejecucion
               and estado = 'EN_PROCESO';
        end if;
    end finalizar_ejecucion;

    /** Verifica que el sujeto pertenezca a la configuración, directo o como integrante de una empresa. */
    procedure validar_asignacion(
        p_id_configuracion in number,
        p_id_documento in number,
        p_tipo_sujeto in varchar2,
        p_id_sujeto in number) is
        v_documento number;
        v_sujeto number;
    begin
        select count(*)
          into v_documento
          from data.t_cntr_config_documentos cd
         where cd.id_configuracion = p_id_configuracion
           and cd.id_documento = p_id_documento
           and cd.estado = 'ACTIVO';

        if v_documento = 0 then
            raise_application_error(-20101, 'El documento no pertenece a la configuracion activa.');
        end if;

        select count(*)
          into v_sujeto
          from dual
         where exists (
                    select 1
                      from data.t_cntr_config_sujetos cs
                     where cs.id_configuracion = p_id_configuracion
                       and cs.tipo_sujeto = upper(trim(p_tipo_sujeto))
                       and cs.id_sujeto = p_id_sujeto
                       and cs.estado = 'ACTIVO')
            or (upper(trim(p_tipo_sujeto)) = 'EMPRESA' and exists (
                    select 1
                      from data.t_cntr_config_empresas ce
                     where ce.id_configuracion = p_id_configuracion
                       and ce.id_empresa = p_id_sujeto
                       and ce.estado = 'ACTIVO'))
            or (upper(trim(p_tipo_sujeto)) = 'PERSONA' and exists (
                    select 1
                      from data.t_cntr_config_empresas ce
                      join data.t_cntr_empresa_personas ep
                        on ep.id_empresa = ce.id_empresa
                       and ep.estado = 'ACTIVO'
                      left join data.t_cntr_config_empresa_personas cep
                        on cep.id_config_empresa = ce.id_config_empresa
                       and cep.id_persona = ep.id_persona
                       and cep.estado = 'ACTIVO'
                     where ce.id_configuracion = p_id_configuracion
                       and ce.estado = 'ACTIVO'
                       and ep.id_persona = p_id_sujeto
                       and (ce.incluir_todos = 'S' or cep.id_config_empresa_persona is not null)));

        if v_sujeto = 0 then
            raise_application_error(-20102, 'El sujeto no pertenece a la configuracion activa.');
        end if;
    end validar_asignacion;

    /** Crea una corrida y hereda compañía únicamente desde la configuración validada. */
    procedure crear_ejecucion(
        p_id_configuracion in number,
        p_tipo_ejecucion in varchar2,
        p_usuario_apex in varchar2,
        p_ambiente in varchar2,
        p_id_ejecucion out number) is
        v_compania data.t_cntr_configuraciones.compania%type;
    begin
        if upper(trim(p_tipo_ejecucion)) not in ('MANUAL', 'AUTOMATICA') then
            raise_application_error(-20103, 'Tipo de ejecucion invalido.');
        end if;

        select compania
          into v_compania
          from data.t_cntr_configuraciones
         where id_configuracion = p_id_configuracion
           and estado = 'ACTIVO'
           and upper(usuario_creacion) = upper(trim(p_usuario_apex));

        insert into data.t_cntr_rpa_ejecuciones (
            id_configuracion, compania, tipo_ejecucion, usuario_apex, ambiente, usuario_creacion)
        values (
            p_id_configuracion, v_compania, upper(trim(p_tipo_ejecucion)), upper(trim(p_usuario_apex)),
            upper(trim(p_ambiente)), upper(trim(p_usuario_apex)))
        returning id_ejecucion into p_id_ejecucion;
    exception
        when no_data_found then
            raise_application_error(-20100, 'La configuracion activa no pertenece al usuario indicado.');
    end crear_ejecucion;

    /** Crea el detalle solo para una corrida abierta y una asignación vigente de su configuración. */
    procedure iniciar_detalle(
        p_id_ejecucion in number,
        p_id_documento in number,
        p_tipo_sujeto in varchar2,
        p_id_sujeto in number,
        p_id_detalle out number,
        p_id_empresa_origen in number default null) is
        v_configuracion number;
        v_empresa_configurada number;
    begin
        if upper(trim(p_tipo_sujeto)) not in ('PERSONA', 'EMPRESA') then
            raise_application_error(-20104, 'Tipo de sujeto invalido.');
        end if;

        select id_configuracion
          into v_configuracion
          from data.t_cntr_rpa_ejecuciones
         where id_ejecucion = p_id_ejecucion
           and estado = 'EN_PROCESO'
         for update;

        validar_asignacion(v_configuracion, p_id_documento, p_tipo_sujeto, p_id_sujeto);
        if p_id_empresa_origen is not null then
            select count(*) into v_empresa_configurada
              from data.t_cntr_config_empresas
             where id_configuracion = v_configuracion
               and id_empresa = p_id_empresa_origen
               and estado = 'ACTIVO';
            if v_empresa_configurada = 0 then
                raise_application_error(-20113, 'La empresa de origen no pertenece a la configuracion activa.');
            end if;
        end if;

        insert into data.t_cntr_rpa_ejecuciones_detalle (
            id_ejecucion, id_documento, tipo_sujeto, id_sujeto, id_empresa_origen)
        values (
            p_id_ejecucion, p_id_documento, upper(trim(p_tipo_sujeto)), p_id_sujeto, p_id_empresa_origen)
        returning id_ejecucion_detalle into p_id_detalle;
    exception
        when no_data_found then
            raise_application_error(-20105, 'La ejecucion no existe o ya finalizo.');
    end iniciar_detalle;

    /** Registra evidencia desde RPA y mantiene una cabecera por propietario. */
    procedure registrar_resultado(
        p_id_detalle in number,
        p_archivo in blob,
        p_nombre_archivo in varchar2,
        p_tipo_mime in varchar2,
        p_origen in varchar2,
        p_fecha_obtencion in timestamp,
        p_hash_sha256 in varchar2,
        p_usuario in varchar2,
        p_id_evidencia out number,
        p_version out number) is
        v_documento number;
        v_tipo varchar2(20);
        v_sujeto number;
        v_archivo number;
        v_ejecucion number;
        v_observacion varchar2(500);
        v_mime varchar2(100) := lower(trim(p_tipo_mime));
        v_firma raw(8);
        v_tamano number;
        v_final_pdf raw(8192);
    begin
        if p_archivo is null then
            raise_application_error(-20106, 'El archivo de evidencia es obligatorio.');
        end if;
        v_tamano := dbms_lob.getlength(p_archivo);
        if v_tamano = 0 then
            raise_application_error(-20106, 'El archivo de evidencia es obligatorio.');
        end if;
        if upper(trim(p_origen)) not in ('AUTOMATICA', 'ASISTIDA', 'MANUAL') then
            raise_application_error(-20107, 'Origen de evidencia invalido.');
        end if;
        if p_nombre_archivo is null or p_tipo_mime is null or p_usuario is null then
            raise_application_error(-20108, 'Nombre, tipo MIME y usuario son obligatorios.');
        end if;
        if v_mime not in ('application/pdf', 'image/png', 'image/jpeg') then
            raise_application_error(-20118, 'La evidencia debe ser PDF, PNG o JPEG.');
        end if;
        v_firma := dbms_lob.substr(p_archivo, 8, 1);
        if (v_mime = 'application/pdf' and substr(utl_raw.cast_to_varchar2(v_firma), 1, 5) <> '%PDF-')
           or (v_mime = 'image/png' and v_firma <> hextoraw('89504E470D0A1A0A'))
           or (v_mime = 'image/jpeg' and substr(rawtohex(v_firma), 1, 6) <> 'FFD8FF') then
            raise_application_error(-20119, 'El contenido no corresponde al tipo MIME de evidencia.');
        end if;
        if v_mime = 'application/pdf' then
            v_final_pdf := dbms_lob.substr(p_archivo, least(8192, v_tamano), greatest(1, v_tamano - 8191));
            if v_tamano < 100
               or dbms_lob.instr(p_archivo, utl_raw.cast_to_raw('startxref'), 1, 1) = 0
               or instr(rawtohex(v_final_pdf), '2525454F46') = 0 then
                raise_application_error(-20138, 'La evidencia PDF no tiene una estructura válida.');
            end if;
        end if;

        select id_ejecucion, id_documento, tipo_sujeto, id_sujeto
          into v_ejecucion, v_documento, v_tipo, v_sujeto
          from data.t_cntr_rpa_ejecuciones_detalle
         where id_ejecucion_detalle = p_id_detalle
           and estado = 'EN_PROCESO'
         for update;

        begin
            select id_evidencia
              into p_id_evidencia
              from data.t_cntr_evidencias
             where id_documento = v_documento
               and tipo_sujeto = v_tipo
               and id_sujeto = v_sujeto
             for update;
        exception
            when no_data_found then
                insert into data.t_cntr_evidencias (id_documento, tipo_sujeto, id_sujeto, usuario_creacion)
                values (v_documento, v_tipo, v_sujeto, upper(trim(p_usuario)))
                returning id_evidencia into p_id_evidencia;
        end;

        update files.t_apex_archivos
           set estado = 'REEMPLAZADO'
         where tabla = 'T_CNTR_EVIDENCIAS'
           and id_tabla = to_char(p_id_evidencia)
           and tipo = 'EVIDENCIA_CNTR'
           and nvl(estado, 'ACTIVO') = 'ACTIVO';

        select count(*) + 1 into p_version
          from files.t_apex_archivos
         where tabla = 'T_CNTR_EVIDENCIAS'
           and id_tabla = to_char(p_id_evidencia)
           and tipo = 'EVIDENCIA_CNTR';

        v_observacion := 'Version=' || p_version || '; Origen=' || upper(trim(p_origen)) ||
                         '; Detalle=' || p_id_detalle || '; Hash=' || nvl(p_hash_sha256, 'N/D');
        data.pk_apex_archivos.sp_creararchivomanual(
            p_archivo => p_archivo,
            p_archivonombre => p_nombre_archivo,
            p_archivotype => v_mime,
            p_ride => null,
            p_tabla => 'T_CNTR_EVIDENCIAS',
            p_idtabla => to_char(p_id_evidencia),
            p_tipo => 'EVIDENCIA_CNTR',
            p_observacion => v_observacion,
            p_usuario => upper(trim(p_usuario)),
            p_numeroarchivo => v_archivo);

        update files.t_apex_archivos
           set estado = 'ACTIVO'
         where numeroarchivo = v_archivo;

        update data.t_cntr_rpa_ejecuciones_detalle
           set estado = 'COMPLETADO', fecha_fin = systimestamp, id_evidencia = p_id_evidencia,
               numeroarchivo_evidencia = v_archivo
         where id_ejecucion_detalle = p_id_detalle;
        finalizar_ejecucion(v_ejecucion);
    end registrar_resultado;

    /** Registra una carga manual de APEX y conserva las versiones anteriores en FILES. */
    procedure registrar_evidencia_manual(
        p_id_documento in number,
        p_tipo_sujeto in varchar2,
        p_id_sujeto in number,
        p_archivo in varchar2,
        p_usuario in varchar2,
        p_id_evidencia out number,
        p_numeroarchivo out number) is
        v_tipo varchar2(20) := upper(trim(p_tipo_sujeto));
        v_modo varchar2(30);
        v_existe number;
        v_version number;
        v_blob blob;
        v_nombre_archivo varchar2(255);
        v_mime varchar2(255);
        v_archivos apex_application_global.vc_arr2;
    begin
        if trim(p_archivo) is null then
            raise_application_error(-20130, 'Seleccione el archivo de evidencia manual.');
        end if;

        select modo_captura
          into v_modo
          from data.t_cntr_documentos
         where id_documento = p_id_documento
           and estado = 'ACTIVO';
        if v_modo not in ('MANUAL', 'SEMIAUTOMATICO') then
            raise_application_error(-20131, 'El documento seleccionado no admite evidencia manual.');
        end if;

        if v_tipo = 'PERSONA' then
            select count(*) into v_existe from data.t_cntr_personas where id_persona = p_id_sujeto and estado = 'ACTIVO';
        elsif v_tipo = 'EMPRESA' then
            select count(*) into v_existe from data.t_cntr_empresas where id_empresa = p_id_sujeto and estado = 'ACTIVO';
        else
            raise_application_error(-20132, 'El tipo de sujeto debe ser PERSONA o EMPRESA.');
        end if;
        if v_existe = 0 then
            raise_application_error(-20133, 'El sujeto seleccionado no existe o esta inactivo.');
        end if;

        begin
            select id_evidencia into p_id_evidencia
              from data.t_cntr_evidencias
             where id_documento = p_id_documento
               and tipo_sujeto = v_tipo
               and id_sujeto = p_id_sujeto;
        exception
            when no_data_found then
                insert into data.t_cntr_evidencias (id_documento, tipo_sujeto, id_sujeto, usuario_creacion)
                values (p_id_documento, v_tipo, p_id_sujeto, upper(trim(p_usuario)))
                returning id_evidencia into p_id_evidencia;
        end;

        update files.t_apex_archivos
           set estado = 'REEMPLAZADO'
         where tabla = 'T_CNTR_EVIDENCIAS'
           and id_tabla = to_char(p_id_evidencia)
           and tipo = 'EVIDENCIA_CNTR'
           and nvl(estado, 'ACTIVO') = 'ACTIVO';

        select count(*) + 1 into v_version
          from files.t_apex_archivos
         where tabla = 'T_CNTR_EVIDENCIAS'
           and id_tabla = to_char(p_id_evidencia)
           and tipo = 'EVIDENCIA_CNTR';

        -- APEX 24 puede devolver el identificador temporal o el nombre del
        -- archivo según el componente `a-file-upload` y su modo de carga.
        v_archivos := apex_util.string_to_table(p_archivo);
        if v_archivos.count = 0 then
            raise_application_error(-20134, 'No se recibio un archivo temporal APEX valido.');
        end if;
        select blob_content, filename, mime_type
          into v_blob, v_nombre_archivo, v_mime
          from apex_application_temp_files
         where name = v_archivos(1)
           and rownum = 1;

        data.pk_apex_archivos.sp_creararchivomanual(
            p_archivo => v_blob,
            p_archivonombre => v_nombre_archivo,
            p_archivotype => v_mime,
            p_ride => null,
            p_tabla => 'T_CNTR_EVIDENCIAS',
            p_idtabla => to_char(p_id_evidencia),
            p_tipo => 'EVIDENCIA_CNTR',
            p_observacion => 'Version=' || v_version || '; Origen=MANUAL',
            p_usuario => upper(trim(p_usuario)),
            p_numeroarchivo => p_numeroarchivo);

        update files.t_apex_archivos
           set estado = 'ACTIVO'
         where numeroarchivo = p_numeroarchivo
           and tabla = 'T_CNTR_EVIDENCIAS'
           and id_tabla = to_char(p_id_evidencia)
           and tipo = 'EVIDENCIA_CNTR';
    end registrar_evidencia_manual;

    /** Finaliza sin archivo únicamente en los estados de negocio permitidos. */
    procedure registrar_estado(
        p_id_detalle in number,
        p_estado in varchar2,
        p_mensaje in varchar2) is
        v_ejecucion number;
        v_estado varchar2(30) := upper(trim(p_estado));
    begin
        if v_estado not in ('SIN_RESULTADO', 'NO_APLICA', 'CANCELADO') then
            raise_application_error(-20109, 'Estado terminal invalido.');
        end if;
        select id_ejecucion into v_ejecucion
          from data.t_cntr_rpa_ejecuciones_detalle
         where id_ejecucion_detalle = p_id_detalle
           and estado = 'EN_PROCESO'
         for update;
        update data.t_cntr_rpa_ejecuciones_detalle
           set estado = v_estado, mensaje = p_mensaje, fecha_fin = systimestamp
         where id_ejecucion_detalle = p_id_detalle;
        finalizar_ejecucion(v_ejecucion);
    exception
        when no_data_found then
            raise_application_error(-20110, 'El detalle no existe o no esta en proceso.');
    end registrar_estado;

    /** Guarda una incidencia; los reintentos no cierran la ejecución hasta resolverse. */
    procedure registrar_error(
        p_id_detalle in number,
        p_tipo_error in varchar2,
        p_mensaje in varchar2,
        p_paso_orden in number,
        p_reintentable in varchar2) is
        v_ejecucion number;
        v_estado varchar2(30);
    begin
        if p_tipo_error is null or p_mensaje is null then
            raise_application_error(-20111, 'Tipo y mensaje de error son obligatorios.');
        end if;
        v_estado := case when upper(trim(p_reintentable)) = 'S' then 'REINTENTABLE' else 'ERROR' end;
        select id_ejecucion into v_ejecucion
          from data.t_cntr_rpa_ejecuciones_detalle
         where id_ejecucion_detalle = p_id_detalle
           and estado = 'EN_PROCESO'
         for update;
        update data.t_cntr_rpa_ejecuciones_detalle
           set estado = v_estado,
               tipo_error = upper(trim(p_tipo_error)),
               mensaje = p_mensaje,
               paso_orden = p_paso_orden,
               fecha_fin = case when v_estado = 'ERROR' then systimestamp else null end
         where id_ejecucion_detalle = p_id_detalle;
        if v_estado = 'ERROR' then
            finalizar_ejecucion(v_ejecucion);
        end if;
    exception
        when no_data_found then
            raise_application_error(-20110, 'El detalle no existe o no esta en proceso.');
    end registrar_error;

    /** Devuelve un detalle reintentable a proceso sin crear una auditoría duplicada. */
    procedure reintentar_detalle(p_id_detalle in number) is
    begin
        update data.t_cntr_rpa_ejecuciones_detalle
           set estado = 'EN_PROCESO',
               intento = intento + 1,
               mensaje = null,
               tipo_error = null,
               paso_orden = null,
               fecha_fin = null
         where id_ejecucion_detalle = p_id_detalle
           and estado = 'REINTENTABLE';
        if sql%rowcount = 0 then
            raise_application_error(-20112, 'El detalle no existe o no esta reintentable.');
        end if;
    end reintentar_detalle;

    /** Centraliza la accion especial del monitor sin asumir compania ni usuario. */
    function tiene_ver_todos(
        p_usuario in varchar2,
        p_compania in varchar2) return number is
    begin
        if p_usuario is null or p_compania is null then
            return 0;
        end if;

        return case
            when data.pk_admi_gestionparametros.f_admi_accesoacciones(
                     p_codigomodulo => 'BACK',
                     p_codigousuario => upper(trim(p_usuario)),
                     p_rutapagina => '319',
                     p_codigoaccion => 'VER_TODOS',
                     p_compania => trim(p_compania)) = 1
            then 1
            else 0
        end;
    exception
        when others then
            return 0;
    end tiene_ver_todos;

    /** Centraliza la accion TODOS de la matriz sin usar valores fijos de compania. */
    function tiene_todos_matriz(
        p_usuario in varchar2,
        p_compania in varchar2) return number is
    begin
        if p_usuario is null or p_compania is null then
            return 0;
        end if;

        return case
            when data.pk_admi_gestionparametros.f_admi_accesoacciones(
                     p_codigomodulo => 'BACK',
                     p_codigousuario => upper(trim(p_usuario)),
                     p_rutapagina => '320',
                     p_codigoaccion => 'TODOS',
                     p_compania => trim(p_compania)) = 1
            then 1
            else 0
        end;
    exception
        when others then
            return 0;
    end tiene_todos_matriz;

    /** Aisla el monitor por compania y propietario, salvo autorizacion explicita. */
    function puede_ver_ejecucion(
        p_id_ejecucion in number,
        p_usuario in varchar2,
        p_compania in varchar2) return number is
        v_total number;
    begin
        if p_id_ejecucion is null or p_usuario is null or p_compania is null then
            return 0;
        end if;

        select count(*)
          into v_total
          from data.t_cntr_rpa_ejecuciones e
         where e.id_ejecucion = p_id_ejecucion
           and e.compania = trim(p_compania)
           and (upper(e.usuario_apex) = upper(trim(p_usuario))
                or tiene_ver_todos(p_usuario, p_compania) = 1);

        return case when v_total > 0 then 1 else 0 end;
    end puede_ver_ejecucion;

    /** Protege versiones por ejecucion visible, configuracion propia o matriz global autorizada. */
    function puede_ver_evidencia(
        p_id_evidencia in number,
        p_usuario in varchar2,
        p_compania in varchar2,
        p_id_ejecucion in number default null,
        p_id_configuracion in number default null,
        p_mostrar_todos in varchar2 default 'N') return number is
        v_total number;
        v_modo_todos varchar2(1) := case when upper(trim(nvl(p_mostrar_todos, 'N'))) = 'S' then 'S' else 'N' end;
    begin
        if p_id_evidencia is null or p_usuario is null or p_compania is null then
            return 0;
        end if;

        select count(*)
          into v_total
          from dual
         where exists (
                   select 1
                     from data.t_cntr_evidencias ev
                     join data.t_cntr_documentos doc
                       on doc.id_documento = ev.id_documento
                      and doc.compania = trim(p_compania)
                     join data.vt_cntr_matriculados mat
                       on mat.compania = doc.compania
                      and mat.tipo_sujeto = ev.tipo_sujeto
                      and mat.id_sujeto = ev.id_sujeto
                    where ev.id_evidencia = p_id_evidencia
                      and v_modo_todos = 'S'
                      and nvl(p_id_configuracion, -1) = -1
                      and tiene_todos_matriz(p_usuario, p_compania) = 1)
            or exists (
                   select 1
                     from data.vt_cntr_matriz_documental m
                    where m.id_evidencia = p_id_evidencia
                      and m.id_configuracion = p_id_configuracion
                      and m.compania = trim(p_compania)
                      and upper(m.usuario_propietario) = upper(trim(p_usuario))
                      and v_modo_todos = 'N')
            or (p_id_ejecucion is not null and exists (
                   select 1
                     from data.t_cntr_rpa_ejecuciones_detalle d
                    where d.id_ejecucion = p_id_ejecucion
                      and d.id_evidencia = p_id_evidencia
                      and puede_ver_ejecucion(p_id_ejecucion, p_usuario, p_compania) = 1));

        return case when v_total > 0 then 1 else 0 end;
    end puede_ver_evidencia;

    /** Obtiene solo el archivo que fue registrado por el detalle solicitado. */
    procedure obtener_evidencia_detalle(
        p_id_detalle in number,
        p_usuario in varchar2,
        p_compania in varchar2,
        p_archivo out blob,
        p_nombre_archivo out varchar2,
        p_tipo_mime out varchar2) is
        v_id_evidencia number;
        v_numeroarchivo number;
        v_id_ejecucion number;
    begin
        select id_evidencia, numeroarchivo_evidencia, id_ejecucion
          into v_id_evidencia, v_numeroarchivo, v_id_ejecucion
          from data.t_cntr_rpa_ejecuciones_detalle
         where id_ejecucion_detalle = p_id_detalle;

        if v_id_evidencia is null or v_numeroarchivo is null then
            raise_application_error(-20139, 'El detalle no tiene una evidencia puntual disponible.');
        end if;
        if puede_ver_evidencia(v_id_evidencia, p_usuario, p_compania, v_id_ejecucion) <> 1 then
            raise_application_error(-20140, 'No esta autorizado para descargar la evidencia de este detalle.');
        end if;

        select blobcontent, filename, mimetype
          into p_archivo, p_nombre_archivo, p_tipo_mime
          from files.t_apex_archivos
         where numeroarchivo = v_numeroarchivo
           and tabla = 'T_CNTR_EVIDENCIAS'
           and id_tabla = to_char(v_id_evidencia)
           and tipo = 'EVIDENCIA_CNTR';

        if p_archivo is null or dbms_lob.getlength(p_archivo) = 0 then
            raise_application_error(-20141, 'El archivo de evidencia puntual no está disponible.');
        end if;
    exception
        when no_data_found then
            raise_application_error(-20139, 'El detalle no tiene una evidencia puntual disponible.');
    end obtener_evidencia_detalle;

    /** Agrega fragmentos pequenos a un CLOB temporal. */
    procedure agregar_html(
        p_html in out nocopy clob,
        p_texto in varchar2) is
    begin
        dbms_lob.writeappend(p_html, length(p_texto), p_texto);
    end agregar_html;

    /** Construye la matriz propia o la matriz global autorizada de matriculados por documento. */
    function renderizar_matriz(
        p_id_configuracion in number,
        p_usuario in varchar2,
        p_compania in varchar2,
        p_mostrar_todos in varchar2 default 'N') return clob is
        v_html clob;
        v_total number;
        v_url varchar2(4000);
        v_clase varchar2(100);
        v_icono varchar2(100);
        v_etiqueta varchar2(200);
        v_modo_todos varchar2(1) := case when upper(trim(nvl(p_mostrar_todos, 'N'))) = 'S' then 'S' else 'N' end;
    begin
        if p_id_configuracion is null then
            return '<div class="t-Alert t-Alert--horizontal t-Alert--defaultIcons t-Alert--info"><div class="t-Alert-wrap"><div class="t-Alert-content"><div class="t-Alert-header"><h2 class="t-Alert-title">Seleccione una configuracion para consultar la matriz documental.</h2></div></div></div></div>';
        end if;

        if p_id_configuracion = -1 and v_modo_todos = 'N' then
            if tiene_todos_matriz(p_usuario, p_compania) = 0 then
                raise_application_error(-20117, 'El usuario no posee autorizacion para consultar todos los matriculados.');
            end if;
            return '<div class="t-Alert t-Alert--horizontal t-Alert--defaultIcons t-Alert--info"><div class="t-Alert-wrap"><div class="t-Alert-content"><div class="t-Alert-header"><h2 class="t-Alert-title">Marque Mostrar todos para consultar todos los sujetos y empresas matriculados.</h2></div></div></div></div>';
        elsif v_modo_todos = 'S' and p_id_configuracion = -1 then
            if tiene_todos_matriz(p_usuario, p_compania) = 0 then
                raise_application_error(-20117, 'El usuario no posee autorizacion para consultar todos los matriculados.');
            end if;
        else
            v_modo_todos := 'N';
            select count(*)
              into v_total
              from data.t_cntr_configuraciones c
             where c.id_configuracion = p_id_configuracion
               and c.compania = trim(p_compania)
               and exists (
                    select 1
                      from data.v_cntr_rpa_configuraciones vc
                     where vc.id_configuracion = c.id_configuracion
                       and upper(vc.usuario_apex) = upper(trim(p_usuario))
               )
               and c.estado = 'ACTIVO';

            if v_total = 0 then
                raise_application_error(-20114, 'La configuracion activa no pertenece al usuario autenticado.');
            end if;
        end if;

        dbms_lob.createtemporary(v_html, true);
        agregar_html(v_html, '<div class="t-Report-wrap"><div class="t-Report-tableWrap"><table class="t-Report-report" aria-label="Matriz documental"><thead><tr><th class="t-Report-colHead">Identificación</th><th class="t-Report-colHead">Sujeto</th><th class="t-Report-colHead">Tipo</th>');

        for doc in (
            select d.id_documento,
                   p.nombre_portal portal,
                   d.nombre_documento documento
              from data.t_cntr_documentos d
              join data.t_cntr_portales p
                on p.id_portal = d.id_portal
             where d.compania = trim(p_compania)
               and d.estado = 'ACTIVO'
               and (v_modo_todos = 'S' or exists (
                       select 1
                         from data.t_cntr_config_documentos cd
                        where cd.id_configuracion = p_id_configuracion
                          and cd.id_documento = d.id_documento
                          and cd.estado = 'ACTIVO'))
             order by p.nombre_portal, d.nombre_documento
        ) loop
            agregar_html(v_html, '<th class="t-Report-colHead" title="' ||
                apex_escape.html_attribute(doc.portal || ' - ' || doc.documento) || '" aria-label="' ||
                apex_escape.html_attribute(doc.portal || ' - ' || doc.documento) || '">' ||
                apex_escape.html(doc.portal) || '</th>');
        end loop;
        agregar_html(v_html, '<th class="t-Report-colHead">Descargar</th><th class="t-Report-colHead">Ver análisis IA</th><th class="t-Report-colHead">Generar análisis IA</th></tr></thead><tbody>');

        for suj in (
            select tipo_sujeto, id_sujeto, identificacion, sujeto
              from (
                    select m.tipo_sujeto, m.id_sujeto, m.identificacion, m.sujeto
                      from data.vt_cntr_matriculados m
                     where v_modo_todos = 'S'
                       and m.compania = trim(p_compania)
                    union all
                    select distinct m.tipo_sujeto, m.id_sujeto, m.identificacion, m.sujeto
                      from data.vt_cntr_matriz_documental m
                     where v_modo_todos = 'N'
                       and m.id_configuracion = p_id_configuracion
                       and m.compania = trim(p_compania)
                       and exists (
                            select 1
                              from data.v_cntr_rpa_configuraciones vc
                             where vc.id_configuracion = m.id_configuracion
                               and upper(vc.usuario_apex) = upper(trim(p_usuario))
                       )
                   )
             order by tipo_sujeto, sujeto
        ) loop
            agregar_html(v_html, '<tr><td class="t-Report-cell" title="' ||
                apex_escape.html_attribute(suj.identificacion) || '">' || apex_escape.html(suj.identificacion) ||
                '</td><td class="t-Report-cell" title="' || apex_escape.html_attribute(suj.sujeto) || '">' ||
                apex_escape.html(suj.sujeto) || '</td><td class="t-Report-cell">' ||
                apex_escape.html(suj.tipo_sujeto) || '</td>');

            for celda in (
                select d.id_documento,
                       ev.id_evidencia,
                       (select max(det.mensaje) keep (
                                    dense_rank last order by det.fecha_inicio, det.id_ejecucion_detalle)
                          from data.t_cntr_rpa_ejecuciones eje
                          join data.t_cntr_rpa_ejecuciones_detalle det
                            on det.id_ejecucion = eje.id_ejecucion
                         where eje.compania = trim(p_compania)
                           and det.id_documento = d.id_documento
                           and det.tipo_sujeto = suj.tipo_sujeto
                           and det.id_sujeto = suj.id_sujeto
                           and (v_modo_todos = 'S' or eje.id_configuracion = p_id_configuracion)) mensaje_error,
                       case
                           when exists (
                                select 1
                                  from files.t_apex_archivos fa
                                 where fa.tabla = 'T_CNTR_EVIDENCIAS'
                                   and fa.id_tabla = to_char(ev.id_evidencia)
                                   and fa.tipo = 'EVIDENCIA_CNTR'
                                   and fa.estado = 'ACTIVO') then 'LISTO'
                           when (select max(det.estado) keep (
                                        dense_rank last order by det.fecha_inicio, det.id_ejecucion_detalle)
                                   from data.t_cntr_rpa_ejecuciones eje
                                   join data.t_cntr_rpa_ejecuciones_detalle det
                                     on det.id_ejecucion = eje.id_ejecucion
                                  where eje.compania = trim(p_compania)
                                    and det.id_documento = d.id_documento
                                    and det.tipo_sujeto = suj.tipo_sujeto
                                    and det.id_sujeto = suj.id_sujeto
                                    and (v_modo_todos = 'S' or eje.id_configuracion = p_id_configuracion)) in ('ERROR', 'FINALIZADA_CON_ERROR')
                                then 'ERROR'
                           when (select max(det.estado) keep (
                                        dense_rank last order by det.fecha_inicio, det.id_ejecucion_detalle)
                                   from data.t_cntr_rpa_ejecuciones eje
                                   join data.t_cntr_rpa_ejecuciones_detalle det
                                     on det.id_ejecucion = eje.id_ejecucion
                                  where eje.compania = trim(p_compania)
                                    and det.id_documento = d.id_documento
                                    and det.tipo_sujeto = suj.tipo_sujeto
                                    and det.id_sujeto = suj.id_sujeto
                                    and (v_modo_todos = 'S' or eje.id_configuracion = p_id_configuracion)) = 'NO_APLICA'
                                then 'NO_APLICA'
                           else 'PENDIENTE'
                       end estado_documental
                  from data.t_cntr_documentos d
                  join data.t_cntr_portales p
                    on p.id_portal = d.id_portal
                  left join data.t_cntr_evidencias ev
                    on ev.id_documento = d.id_documento
                   and ev.tipo_sujeto = suj.tipo_sujeto
                   and ev.id_sujeto = suj.id_sujeto
                 where d.compania = trim(p_compania)
                   and d.estado = 'ACTIVO'
                   and (v_modo_todos = 'S' or exists (
                           select 1
                             from data.t_cntr_config_documentos cd
                            where cd.id_configuracion = p_id_configuracion
                              and cd.id_documento = d.id_documento
                              and cd.estado = 'ACTIVO'))
                 order by p.nombre_portal, d.nombre_documento
            ) loop
                if celda.estado_documental = 'LISTO' then
                    v_url := apex_page.get_url(
                        p_page => 321,
                        p_items => 'P321_ID_EVIDENCIA,P321_TIPO_SUJETO,P321_ID_SUJETO,P321_ID_CONFIGURACION,P321_MOSTRAR_TODOS',
                        p_values => to_char(celda.id_evidencia) || ',' || suj.tipo_sujeto || ',' ||
                                    to_char(suj.id_sujeto) || ',' || to_char(p_id_configuracion) || ',' || v_modo_todos);
                    v_clase := 't-Button t-Button--noLabel t-Button--icon t-Button--link t-Button--success';
                    v_icono := 't-Icon fa fa-check-circle-o';
                    v_etiqueta := 'Ver versiones del documento';
                    agregar_html(v_html, '<td class="t-Report-cell u-textCenter"><a class="' || v_clase ||
                        '" href="' || apex_escape.html_attribute(v_url) || '" title="' || v_etiqueta ||
                        '" aria-label="' || v_etiqueta || '"><span class="' || v_icono || '" aria-hidden="true"></span></a></td>');
                elsif celda.estado_documental = 'ERROR' then
                    v_url := apex_page.get_url(
                        p_page => 321,
                        p_items => 'P321_TIPO_SUJETO,P321_ID_SUJETO,P321_ID_CONFIGURACION,P321_MOSTRAR_TODOS',
                        p_values => suj.tipo_sujeto || ',' || to_char(suj.id_sujeto) || ',' ||
                                    to_char(p_id_configuracion) || ',' || v_modo_todos);
                    v_etiqueta := nvl(celda.mensaje_error, 'La ultima ejecucion no fue exitosa.');
                    agregar_html(v_html, '<td class="t-Report-cell u-textCenter"><a class="t-Button t-Button--noLabel t-Button--icon t-Button--link t-Button--warning" href="' ||
                        apex_escape.html_attribute(v_url) || '" title="' || apex_escape.html_attribute(v_etiqueta) ||
                        '" aria-label="Error: ' || apex_escape.html_attribute(v_etiqueta) || '"><span class="t-Icon fa fa-exclamation-triangle" aria-hidden="true"></span></a></td>');
                else
                    v_clase := case celda.estado_documental
                        when 'NO_APLICA' then 't-Badge t-Badge--warning'
                        else 't-Badge t-Badge--default'
                    end;
                    v_icono := case celda.estado_documental
                        when 'NO_APLICA' then 'fa fa-minus'
                        else 'fa fa-clock-o'
                    end;
                    v_etiqueta := case celda.estado_documental
                        when 'NO_APLICA' then 'No aplica'
                        else 'Pendiente'
                    end;
                    agregar_html(v_html, '<td class="t-Report-cell u-textCenter"><span class="' || v_clase || case when celda.estado_documental = 'PENDIENTE' then '" style="color:#000' else '' end ||
                        '" title="' || v_etiqueta || '"><span class="' || v_icono ||
                        '" aria-hidden="true"></span><span class="u-VisuallyHidden">' || v_etiqueta || '</span></span></td>');
                end if;
            end loop;

            select count(*)
              into v_total
              from data.t_cntr_evidencias ev
              join data.t_cntr_documentos d
                on d.id_documento = ev.id_documento
               and d.compania = trim(p_compania)
               and d.estado = 'ACTIVO'
             where ev.tipo_sujeto = suj.tipo_sujeto
               and ev.id_sujeto = suj.id_sujeto
               and (v_modo_todos = 'S' or exists (
                       select 1
                         from data.t_cntr_config_documentos cd
                        where cd.id_configuracion = p_id_configuracion
                          and cd.id_documento = ev.id_documento
                          and cd.estado = 'ACTIVO'))
               and exists (
                       select 1
                         from files.t_apex_archivos fa
                        where fa.tabla = 'T_CNTR_EVIDENCIAS'
                          and fa.id_tabla = to_char(ev.id_evidencia)
                          and fa.tipo = 'EVIDENCIA_CNTR'
                          and fa.estado = 'ACTIVO');

            if v_total > 0 then
                v_url := apex_page.get_url(
                    p_page => 321,
                    p_items => 'P321_TIPO_SUJETO,P321_ID_SUJETO,P321_ID_CONFIGURACION,P321_MOSTRAR_TODOS',
                    p_values => suj.tipo_sujeto || ',' || to_char(suj.id_sujeto) || ',' ||
                                to_char(p_id_configuracion) || ',' || v_modo_todos);
                v_url := apex_page.get_url(
                    p_page => 320,
                    p_request => 'DESCARGAR_ZIP',
                    p_items => 'P320_ID_CONFIGURACION,P320_TIPO_SUJETO,P320_ID_SUJETO',
                    p_values => to_char(p_id_configuracion) || ',' || suj.tipo_sujeto || ',' ||
                                to_char(suj.id_sujeto));
                agregar_html(v_html, '<td class="t-Report-cell u-textCenter"><a class="t-Button t-Button--noLabel t-Button--icon t-Button--link" href="' ||
                    apex_escape.html_attribute(v_url) || '" title="Descargar documentos vigentes" aria-label="Descargar documentos vigentes"><span class="t-Icon fa fa-download" aria-hidden="true"></span></a></td>');
            else
                agregar_html(v_html, '<td class="t-Report-cell"></td>');
            end if;
            if v_modo_todos = 'N' and p_id_configuracion <> -1 then
                v_url := apex_page.get_url(
                    p_page => 320,
                    p_request => 'ANALISIS_IA_SUJETO',
                    p_items => 'P320_ID_CONFIGURACION,P320_TIPO_SUJETO,P320_ID_SUJETO',
                    p_values => to_char(p_id_configuracion) || ',' || suj.tipo_sujeto || ',' || to_char(suj.id_sujeto));
                agregar_html(v_html, '<td class="t-Report-cell u-textCenter"><a class="t-Button t-Button--noLabel t-Button--icon t-Button--link" href="' ||
                    apex_escape.html_attribute(apex_page.get_url(
                        p_page => 323,
                        p_items => 'P323_ID_CONFIGURACION,P323_TIPO_SUJETO,P323_ID_SUJETO',
                        p_values => to_char(p_id_configuracion) || ',' || suj.tipo_sujeto || ',' || to_char(suj.id_sujeto))) ||
                    '" title="Ver análisis IA" aria-label="Ver análisis IA"><span class="t-Icon fa fa-eye" aria-hidden="true"></span></a></td>');
                agregar_html(v_html, '<td class="t-Report-cell u-textCenter"><a class="t-Button t-Button--noLabel t-Button--icon t-Button--link t-Button--success" href="' ||
                    apex_escape.html_attribute(v_url) || '" title="Solicitar análisis IA" aria-label="Solicitar análisis IA"><span class="t-Icon fa fa-magic" aria-hidden="true"></span></a></td>');
            else
                agregar_html(v_html, '<td class="t-Report-cell"></td>');
            end if;
            agregar_html(v_html, '</tr>');
        end loop;

        agregar_html(v_html, '</tbody></table></div></div>');
        return v_html;
    end renderizar_matriz;

    /** Comprime una sola version ACTIVO por documento dentro del alcance autorizado. */
    procedure obtener_zip_vigentes(
        p_id_configuracion in number,
        p_tipo_sujeto in varchar2,
        p_id_sujeto in number,
        p_usuario in varchar2,
        p_compania in varchar2,
        p_archivo out blob,
        p_nombre_archivo out varchar2,
        p_mostrar_todos in varchar2 default 'N') is
        v_total number := 0;
        v_identificacion varchar2(300);
        v_nombre varchar2(400);
        v_modo_todos varchar2(1) := case when upper(trim(nvl(p_mostrar_todos, 'N'))) = 'S' then 'S' else 'N' end;
    begin
        if v_modo_todos = 'S' and p_id_configuracion = -1 then
            if tiene_todos_matriz(p_usuario, p_compania) = 0 then
                raise_application_error(-20117, 'El usuario no posee autorizacion para consultar todos los matriculados.');
            end if;

            select max(m.identificacion)
              into v_identificacion
              from data.vt_cntr_matriculados m
             where m.compania = trim(p_compania)
               and m.tipo_sujeto = upper(trim(p_tipo_sujeto))
               and m.id_sujeto = p_id_sujeto;
        else
            v_modo_todos := 'N';
            select max(m.identificacion)
              into v_identificacion
              from data.vt_cntr_matriz_documental m
             where m.id_configuracion = p_id_configuracion
               and m.tipo_sujeto = upper(trim(p_tipo_sujeto))
               and m.id_sujeto = p_id_sujeto
               and m.compania = trim(p_compania)
               and upper(m.usuario_propietario) = upper(trim(p_usuario));
        end if;

        if v_identificacion is null then
            raise_application_error(-20115, 'El sujeto no pertenece al alcance documental autorizado.');
        end if;

        dbms_lob.createtemporary(p_archivo, true);
        for arc in (
            select id_documento, documento, numeroarchivo, filename, blobcontent
              from (
                    select d.id_documento,
                           d.nombre_documento documento,
                           fa.numeroarchivo,
                           fa.filename,
                           fa.blobcontent,
                           row_number() over (
                               partition by d.id_documento
                               order by fa.fecha desc nulls last, fa.numeroarchivo desc) orden
                      from data.t_cntr_documentos d
                      join data.t_cntr_evidencias ev
                        on ev.id_documento = d.id_documento
                       and ev.tipo_sujeto = upper(trim(p_tipo_sujeto))
                       and ev.id_sujeto = p_id_sujeto
                      join files.t_apex_archivos fa
                        on fa.tabla = 'T_CNTR_EVIDENCIAS'
                       and fa.id_tabla = to_char(ev.id_evidencia)
                       and fa.tipo = 'EVIDENCIA_CNTR'
                       and fa.estado = 'ACTIVO'
                     where d.compania = trim(p_compania)
                       and d.estado = 'ACTIVO'
                       and (v_modo_todos = 'S' or exists (
                               select 1
                                 from data.t_cntr_config_documentos cd
                                where cd.id_configuracion = p_id_configuracion
                                  and cd.id_documento = d.id_documento
                                  and cd.estado = 'ACTIVO'))
                   )
             where orden = 1
             order by documento
        ) loop
            v_nombre := lpad(arc.id_documento, 6, '0') || '_' ||
                        regexp_replace(arc.documento, '[^[:alnum:]_. -]', '_') || '_' ||
                        regexp_replace(arc.filename, '[^[:alnum:]_. -]', '_');
            apex_zip.add_file(
                p_zipped_blob => p_archivo,
                p_file_name => v_nombre,
                p_content => arc.blobcontent);
            v_total := v_total + 1;
        end loop;

        if v_total = 0 then
            raise_application_error(-20116, 'El sujeto no tiene documentos vigentes para descargar.');
        end if;

        apex_zip.finish(p_zipped_blob => p_archivo);
        p_nombre_archivo := 'documentos_' || regexp_replace(v_identificacion, '[^[:alnum:]_-]', '_') || '.zip';
    end obtener_zip_vigentes;

    /** Comprime los archivos activos relacionados con detalles COMPLETADO de una ejecucion. */
    procedure obtener_zip_ejecucion(
        p_id_ejecucion in number,
        p_tipo_sujeto in varchar2,
        p_id_sujeto in number,
        p_usuario in varchar2,
        p_compania in varchar2,
        p_archivo out blob,
        p_nombre_archivo out varchar2) is
        v_total number := 0;
        v_nombre varchar2(400);
        v_sufijo varchar2(300);
    begin
        if puede_ver_ejecucion(p_id_ejecucion, p_usuario, p_compania) = 0 then
            raise_application_error(-20118, 'El usuario no esta autorizado para descargar documentos de esta ejecucion.');
        end if;

        if p_tipo_sujeto is not null or p_id_sujeto is not null then
            if upper(trim(p_tipo_sujeto)) not in ('PERSONA', 'EMPRESA') or p_id_sujeto is null then
                raise_application_error(-20119, 'El sujeto solicitado para la descarga no es valido.');
            end if;
            v_sufijo := '_' || upper(trim(p_tipo_sujeto)) || '_' || to_char(p_id_sujeto);
        else
            v_sufijo := null;
        end if;

        dbms_lob.createtemporary(p_archivo, true);
        for arc in (
            select d.id_ejecucion_detalle,
                   d.id_documento,
                   doc.nombre_documento,
                   fa.filename,
                   fa.blobcontent
              from data.t_cntr_rpa_ejecuciones_detalle d
              join data.t_cntr_documentos doc
                on doc.id_documento = d.id_documento
              join files.t_apex_archivos fa
                on fa.tabla = 'T_CNTR_EVIDENCIAS'
               and fa.id_tabla = to_char(d.id_evidencia)
               and fa.tipo = 'EVIDENCIA_CNTR'
               and fa.estado = 'ACTIVO'
             where d.id_ejecucion = p_id_ejecucion
               and d.estado = 'COMPLETADO'
               and (p_tipo_sujeto is null or (d.tipo_sujeto = upper(trim(p_tipo_sujeto)) and d.id_sujeto = p_id_sujeto))
             order by d.id_ejecucion_detalle, fa.numeroarchivo
        ) loop
            v_nombre := lpad(arc.id_ejecucion_detalle, 8, '0') || '_' ||
                        lpad(arc.id_documento, 6, '0') || '_' ||
                        regexp_replace(arc.nombre_documento, '[^[:alnum:]_. -]', '_') || '_' ||
                        regexp_replace(arc.filename, '[^[:alnum:]_. -]', '_');
            apex_zip.add_file(
                p_zipped_blob => p_archivo,
                p_file_name => v_nombre,
                p_content => arc.blobcontent);
            v_total := v_total + 1;
        end loop;

        if v_total = 0 then
            raise_application_error(-20120, 'No existen documentos exitosos para descargar en el alcance seleccionado.');
        end if;

        apex_zip.finish(p_zipped_blob => p_archivo);
        p_nombre_archivo := 'ejecucion_' || to_char(p_id_ejecucion) || v_sufijo || '.zip';
    end obtener_zip_ejecucion;
end pk_cntr_rpa;
/
