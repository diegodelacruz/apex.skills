﻿prompt TEST PACKAGE_BODY DATA.PK_VTAS_PEDIDOS

  CREATE OR REPLACE EDITIONABLE PACKAGE BODY PK_VTAS_PEDIDOS AS 

  /* 
  * sp_guardaconfigordencompra : Procedimiento para crear o actualizar conf de orden de compra
      @param P_ID IN OUT NUMBER null -> creaciÃ³n, tienevalor -> actualizaciÃ³n
      @param P_CODIGOCLIENTE IN VARCHAR2 -> Como solo va a ser por Grupo, se usa el mismo codigo de Grupo
      @param P_CODIGOGRUPO IN VARCHAR2
      @param P_TIPOARCHIVO IN NUMBER
      @param P_SEPARADOR IN VARCHAR2
      @param P_INICIOFILADETALLE IN NUMBER
      @param P_FILA_OC IN NUMBER
      @param P_COLUMNA_OC IN NUMBER
      @param P_FORMATO_NUM IN VARCHAR2
      @param P_TIPOUNIDAD IN NUMBER
      @param P_ESTADO IN NUMBER
      @param P_EJECUTIVO IN VARCHAR2
      @param P_COMPANIA IN CHAR
      @param P_RESULTADO OUT NUMBER 1 -> CREACION, 2 ->ACTUALIZACION
    */ 
    procedure sp_guardaconfigordencompra
    (   P_ID IN OUT NUMBER, P_CODIGOCLIENTE IN VARCHAR2, P_CODIGOGRUPO IN VARCHAR2,
        P_TIPOARCHIVO IN NUMBER, P_SEPARADOR IN VARCHAR2, P_INICIOFILADETALLE IN NUMBER,
        P_FILA_OC IN NUMBER, P_COLUMNA_OC IN NUMBER, P_FORMATO_NUM IN VARCHAR2,
        P_TIPOUNIDAD IN NUMBER, P_ESTADO IN NUMBER, P_EJECUTIVO IN VARCHAR2, P_COMPANIA IN CHAR,
        P_RESULTADO OUT NUMBER)
    is
    begin

    /* La combinacion cliente/grupo es unica. Si APEX abre el dialogo sin
       P_ID pero la configuracion ya existe, reutiliza su cabecera. */
    if P_ID is null then
        begin
            select id into P_ID
              from data.T_VTAS_PEDIDO_CONF_OC
             where CODIGOCLIENTE = P_CODIGOCLIENTE
               and CODIGOGRUPO = P_CODIGOGRUPO;
        exception
            when no_data_found then null;
        end;
    end if;

    if P_ID is null then --es creaciÃ³n
        P_ID := data.PK_COMMONS.F_SECUENCIA ('T_VTAS_PEDIDO_CONF_OC');
        insert into 
        data.T_VTAS_PEDIDO_CONF_OC (
            ID, CODIGOCLIENTE, CODIGOGRUPO, TIPOARCHIVO, SEPARADOR,
            INICIOFILADETALLE, POSICION_OC, FORMATO_NUM, TIPOUNIDAD,
            EJECUTIVO, COMPANIA, ESTADO)
        values (P_ID, P_CODIGOCLIENTE, P_CODIGOGRUPO, P_TIPOARCHIVO, P_SEPARADOR,
                P_INICIOFILADETALLE, P_FILA_OC || ';' ||P_COLUMNA_OC, P_FORMATO_NUM, P_TIPOUNIDAD,
                P_EJECUTIVO, P_COMPANIA, 1);
        P_RESULTADO := 1;
    else
        update data.T_VTAS_PEDIDO_CONF_OC
        set TIPOARCHIVO = P_TIPOARCHIVO, SEPARADOR = P_SEPARADOR, INICIOFILADETALLE = P_INICIOFILADETALLE,
            POSICION_OC = P_FILA_OC || ';' ||P_COLUMNA_OC, FORMATO_NUM = P_FORMATO_NUM, 
            TIPOUNIDAD = P_TIPOUNIDAD, EJECUTIVO = P_EJECUTIVO
        where ID = P_ID;
        P_RESULTADO := 2;
    end if;
    
      PK_VTAS_PEDIDOS.SP_CLIENTE_NUEVO( P_CODIGOGRUPO => P_CODIGOGRUPO, P_COMPANIA => P_COMPANIA );
    
    end sp_guardaconfigordencompra;

    /* Actualiza una fila de mapeo desde la grilla APEX. */
    procedure sp_actualizamapeoconfig
    (
        P_ID       IN NUMBER,
        P_COLUMNA  IN VARCHAR2,
        P_FORMULA  IN VARCHAR2
    )
    is
    begin
        update data.T_VTAS_PEDIDO_CONF_OC_MAPEO
           set COLUMNA = P_COLUMNA,
               FORMULA = P_FORMULA
         where ID = P_ID;
    end sp_actualizamapeoconfig;

    /* Conserva los valores iniciales del mapeo creados en la coleccion APEX. */
    procedure sp_crearmapeoconfig
    (
        P_ID_CABECERA IN NUMBER
    )
    is
    begin
        insert into data.T_VTAS_PEDIDO_CONF_OC_MAPEO (ID_CABECERA, VALOR, COLUMNA)
        select P_ID_CABECERA, c001, c002
          from apex_collections
         where collection_name = 'COL_VTAS_OC_CONF';
    end sp_crearmapeoconfig;
    
    
    /*
    * 
    */
    
    procedure sp_not_productosnuevos
    is
    cursor c_productosnuevos 
    is select   A.CODIGOPRODUCTO,A.NOMBREPRODUCTO,A.LINEANEGOCIO,A.ESTADO,A.EAN13,A.EAN14 
    from VT_VTAS_PRODUCTOSNUEVOS A;
               
    v_correo    clob;
    v_asunto                VARCHAR2(100);
    v_correo_notificacion	varchar2(200);
    
    begin
     select valor into v_correo_notificacion
        from t_corp_udc where id_cabecera = 'VTAS_PARAM' and id_tabla = '4';

    
    v_asunto := 'NotificaciÃ³n Productos Nuevos';
    
    --Creo la primera parte del correo
    v_correo := v_correo || 
                            '<p>Estimado usuario,</p>
                            <p>&nbsp;</p>
                            <p>Se han incluido nuevos productos al portafolio de Zaimella.
                            <p>&nbsp;</p>';
    
    --Cabecera de tabla de productos nuevos
    v_correo := v_correo || '<table border=''1'' style=''width:100%; padding:0px; border-spacing:0px;''>';
    v_correo := v_correo || '<tr BGCOLOR=''lightgrey''>';
    v_correo := v_correo || '<th  ALIGN=CENTER><strong>CÃ³digo Producto</strong></th>';
    v_correo := v_correo || '<th  ALIGN=CENTER><strong>DescripciÃ³n</strong></th>';
    v_correo := v_correo || '<th  ALIGN=CENTER><strong>Linea de Negocio</strong></th>';
    v_correo := v_correo || '<th  ALIGN=CENTER><strong>EAN 13</strong></th>';
    v_correo := v_correo || '<th  ALIGN=CENTER><strong>EAN 14</strong></th>';
    v_correo := v_correo || '</tr>';
    
    for produc in c_productosnuevos loop
        v_correo := v_correo || '<tr> <td ALIGN=LEFT >'	|| produc.CODIGOPRODUCTO ||'</td>';
        v_correo := v_correo || '<td ALIGN=LEFT >' || produc.NOMBREPRODUCTO ||'</td>';
        v_correo := v_correo || '<td ALIGN=LEFT >' || produc.LINEANEGOCIO ||'</td>';
        v_correo := v_correo || '<td ALIGN=LEFT >' || produc.EAN13 ||'</td>';
        v_correo := v_correo || '<td ALIGN=LEFT >' || produc.EAN14 ||'</td> </tr>';
    end loop;
    --Cierro la etiqueta de tabla
    v_correo := v_correo || '</table>';
    
    v_correo := v_correo || '<p>&nbsp;</p>
                            <p>&nbsp;</p>
                            <p>Saludos cordiales</p>';
                            
                            
    PK_CORP_CORREO.SP_ENVIO(
                        P_MODULO => 'VTAS',
                        P_TO => v_correo_notificacion,
                        P_FROM => 'notificacion@zaimella.com',
                        P_SUBJECT => v_asunto,
                        P_BODY => v_correo);
    
    
    end sp_not_productosnuevos;
    
    /*
    ======================================================
    SP_PRODUCTO_ESTADO
    ======================================================
    */
    procedure sp_producto_estado (  P_CODIGOPRODUCTO VARCHAR2, P_CODIGOGRUPO VARCHAR2, P_CODIGOCLIENTE VARCHAR2, P_TIPO NUMBER,
                                    P_USUARIO VARCHAR2, P_FECHA DATE DEFAULT NULL, P_UNIDADES NUMBER DEFAULT NULL, 
                                    P_OBSERVACION VARCHAR2 DEFAULT NULL)
    is
    v_numero number;
    begin
        --Inactivo todos los registros con ese cÃ³digo de producto y cliente
        UPDATE T_VTAS_PRODUCTO_ESTADOS SET ESTADO = 0
        WHERE CODIGOPRODUCTO = P_CODIGOPRODUCTO 
        AND CODIGOCLIENTE = P_CODIGOCLIENTE AND CODIGOGRUPO = P_CODIGOGRUPO;
        
        --Obtengo la secuencia que tiene ese producto-cliente
        select nvl(max(NUMERO),0) + 1 into v_numero from T_VTAS_PRODUCTO_ESTADOS
        where CODIGOPRODUCTO = P_CODIGOPRODUCTO 
        AND CODIGOCLIENTE = P_CODIGOCLIENTE AND CODIGOGRUPO = P_CODIGOGRUPO AND TIPO = P_TIPO;
        
        --Inserto en la tabla de productos estados
        insert into T_VTAS_PRODUCTO_ESTADOS 
        (CODIGOPRODUCTO, CODIGOGRUPO, CODIGOCLIENTE, TIPO, NUMERO, FECHACREACION, USUARIO, FECHA, UNIDADES, OBSERVACION, ESTADO) values
        (P_CODIGOPRODUCTO, P_CODIGOGRUPO, P_CODIGOCLIENTE, P_TIPO, v_numero, SYSDATE, P_USUARIO, P_FECHA, P_UNIDADES, P_OBSERVACION, 1);
        
    end sp_producto_estado;
    
    
    /*
    ===================================
    sp_producos_enviar
    ===================================
    */
    procedure sp_producos_enviar(P_CODIGOPRODUCTOS IN VARCHAR2, P_USUARIO IN VARCHAR2, P_COMPANIA IN VARCHAR2 DEFAULT NULL)
    is
    v_compania T_VTAS_CLIENTE_PRODUCTO.COMPANIA%TYPE := trim(P_COMPANIA);
    --Cliente seleccionados
    cursor c_clientes_selec is SELECT COL.SEQ_ID,
                                      COL.C001 AS COD_GRUPO,
                                      COL.C002 AS COD_CLIENTE
                                 FROM APEX_COLLECTIONS COL
                                 JOIN VT_GZM_CLIENTE CLI
                                   ON CLI.CODIGOGRUPO = COL.C001
                                  AND CLI.CODIGOCLIENTE = COL.C002
                                WHERE COL.COLLECTION_NAME = 'CLIENTES_SELECCIONADOS'
                                  AND (v_compania IS NULL OR CLI.COMPANIA = v_compania);
    v_arreglo_prods apex_t_varchar2;
    begin
    
        v_arreglo_prods := apex_string.split(P_CODIGOPRODUCTOS, ':');
        
        for i in 1 .. v_arreglo_prods.count loop
            --Inserto en la tabla T_VTAS_CLIENTE_PRODUCTO limitado a la compania recibida desde APEX.
            insert into T_VTAS_CLIENTE_PRODUCTO 
            (CODIGOGRUPO, CODIGOCLIENTE, CODIGOPRODUCTO, ESTADO, ESTADOCICLO, PRESENTACION, codigoean, PS_PERIODOS, PS_DIAS_INVENTARIO, COMPANIA)
            SELECT CLI.CODIGOGRUPO, CLI.CODIGOCLIENTE, v_arreglo_prods(i),
                    CASE WHEN COLL.C001 IS NOT NULL THEN 1 ELSE 0 END, CASE WHEN COLL.C001 IS NOT NULL THEN 1 ELSE NULL END,
                    pk_vtas_pedidos.f_cantidadpresentacion (p_codigoproducto => v_arreglo_prods(i)),
                    (select max(codigobarra)
                       from vt_gzm_producto b
                      where b.codigobarra is not null
                        and b.codigoproducto = v_arreglo_prods(i)
                        and (v_compania is null or b.compania = v_compania)),
                    '1:2:3', '30', CLI.COMPANIA
                    FROM VT_GZM_CLIENTE CLI 
                    LEFT JOIN APEX_COLLECTIONS COLL ON (CLI.CODIGOGRUPO = COLL.C001 
                                        AND CLI.CODIGOCLIENTE = COLL.C002 AND COLL.COLLECTION_NAME = 'CLIENTES_SELECCIONADOS')
                   WHERE (v_compania IS NULL OR CLI.COMPANIA = v_compania);
            --inserto estados
            for cliente in c_clientes_selec loop
                pk_vtas_pedidos.sp_producto_estado (P_CODIGOPRODUCTO => v_arreglo_prods(i), 
                                        P_CODIGOGRUPO => cliente.COD_GRUPO,
                                        P_CODIGOCLIENTE => cliente.COD_CLIENTE, 
                                        P_TIPO => 3, P_USUARIO => P_USUARIO); --ACTIVAR
                pk_vtas_pedidos.sp_producto_estado (P_CODIGOPRODUCTO => v_arreglo_prods(i), 
                                        P_CODIGOGRUPO => cliente.COD_GRUPO,
                                        P_CODIGOCLIENTE => cliente.COD_CLIENTE, 
                                        P_TIPO => 1, P_USUARIO => P_USUARIO); --COMPROMISO
            end loop;
        end loop;
    
    end sp_producos_enviar;
    
    /*
    ================================================
    * sp_not_productoejecutivo
    ================================================
    */
    procedure sp_not_productoejecutivo(p_codigoproducto in varchar2, P_COMPANIA IN VARCHAR2 DEFAULT NULL)
    is
    v_compania T_VTAS_CLIENTE_PRODUCTO.COMPANIA%TYPE := trim(P_COMPANIA);
    cursor c_clientes_selec is select
                                distinct usr.email, usr.numeroidentificacion
                               from apex_collections cli_sel
                                inner join vt_gzm_cliente cli
                                    on (cli_sel.c001 = cli.codigogrupo and cli_sel.c002 = cli.codigocliente)
                                inner join vt_corp_usuario usr
                                    on (cli.ejecutivo = usr.numeroidentificacion)
                                where collection_name = 'CLIENTES_SELECCIONADOS'
                                  and (v_compania is null or cli.compania = v_compania);
    cursor c_clientes_coord(ejecut varchar2) is select 
                                cli.codigogrupo || ' - ' || cli.grupo as grupo, 
                                cli.codigocliente || ' - ' || cli.nombres as cliente
                                from apex_collections col
                                inner join vt_gzm_cliente cli
                                    on (col.c001 = cli.codigogrupo and col.c002 = cli.codigocliente)
                                where cli.ejecutivo = ejecut
                                      and (v_compania is null or cli.compania = v_compania);
    v_texto_correo clob;
    v_linea_negocio vt_gzm_producto.lineanegocio%type;
    v_ean13 vt_gzm_producto.codigobarra%type;
    v_ean14 vt_gzm_producto.codigobarra%type;
    v_descripcion vt_gzm_producto.nombreproducto%type;
    v_estado vt_gzm_producto.estado%type;
    v_asunto varchar2(200) := 'NUEVO PRODUCTO AGREGADO A PORTAFOLIO';
    begin
        --Obtengo la informaciÃ³n del producto
        select lineanegocio, codigobarra, codigobarra, nombreproducto, estado
        into v_linea_negocio, v_ean13, v_ean14, v_descripcion, v_estado
        from vt_gzm_producto
        where codigoproducto = p_codigoproducto
          and (v_compania is null or compania = v_compania)
        fetch first 1 rows only;
        
        --Envio a todos los interesados
        for usuario in c_clientes_selec loop
            --CreaciÃ³n de correo
            v_texto_correo := '<p>Estimado usuario,</p>
                            <p>&nbsp;</p>
                            <p>Se incluyÃ³ un nuevo producto al portafolio de Zaimella.
                            <p>&nbsp;</p>';
                            
            v_texto_correo := v_texto_correo || '<p><strong>LINEA DE NEGOCIO: </strong>'|| v_linea_negocio ||'</p>';
            v_texto_correo := v_texto_correo || '<p><strong>EAN 13: </strong>'|| v_ean13 ||'</p>';
            v_texto_correo := v_texto_correo || '<p><strong>EAN 14: </strong>'|| v_ean14 ||'</p>';
             v_texto_correo := v_texto_correo || '<p><strong>CODIGO JDE: </strong>'|| p_codigoproducto ||'</p>';
            v_texto_correo := v_texto_correo || '<p><strong>DESCRIPCION: </strong>'|| v_descripcion ||'</p>';
            v_texto_correo := v_texto_correo || '<p><strong>ESTADO: </strong>'|| case when v_estado = 1 then 'Activo' else 'Inactivo' end ||'</p>';
            v_texto_correo := v_texto_correo || '<p><strong>CONDICIÃ“N: </strong>Por codificar</p>';
            
            --Tabla de clientes
            v_texto_correo := v_texto_correo || '<table border=''1'' style=''width:100%; padding:0px; border-spacing:0px;''>';
            v_texto_correo := v_texto_correo || '<tr BGCOLOR=''lightgrey''>';
            v_texto_correo := v_texto_correo || '<th  ALIGN=CENTER><strong>Grupo</strong></th>';
            v_texto_correo := v_texto_correo || '<th  ALIGN=CENTER><strong>Cliente</strong></th>';
            v_texto_correo := v_texto_correo || '</tr>';
            
            --Lista de clientes del ejecutivo que fueron seleccionados
            for cli in c_clientes_coord(usuario.numeroidentificacion) loop
                v_texto_correo := v_texto_correo || '<tr> <td ALIGN=LEFT >'	|| cli.grupo ||'</td>';
                v_texto_correo := v_texto_correo || '<td ALIGN=LEFT >' || cli.cliente ||'</td> </tr>';
            end loop;
            
            v_texto_correo := v_texto_correo || '</table><p>&nbsp;<p>';
            v_texto_correo := v_texto_correo || '<p>Por favor su actualizaciÃ³n en el portafolio de productos de su(s) cliente(s).</p>
                                            <p>&nbsp;</p>
                                            <p>Saludos cordiales.</p>';
        
            pk_corp_correo.sp_envio(
                        p_modulo => 'VTAS',
                        p_to => usuario.email,
                        p_from => 'notificacion@zaimella.com',
                        p_subject => v_asunto,
                        p_body => v_texto_correo);
        end loop;
    end sp_not_productoejecutivo;
    
    /*
    -- sp_guardarestadomasivo
    * Proceso para actualiza la tabla T_VTAS_PRODUCTO_ESTADOS
      cuando todavÃ­a no tienen fecha de compromiso. Proceso que hace a nivel de grupo
        @param P_TIPO IN NUMBER
        @param P_FECHA IN DATE DEFAULT NULL
        @param P_UNIDADES NUMBER DEFAULT NULL
        @param P_OBSERVACION IN VARCHAR2 DEFAULT NULL
        @param P_GRUPO IN VARCHAR2
    */
    procedure sp_guardarestadomasivo
    (
        P_FECHA IN DATE DEFAULT NULL, P_UNIDADES NUMBER DEFAULT NULL,
        P_OBSERVACION IN VARCHAR2 DEFAULT NULL, P_GRUPO IN VARCHAR2
    )
    is
    begin
        UPDATE T_VTAS_PRODUCTO_ESTADOS SET FECHA = P_FECHA, UNIDADES = P_UNIDADES,
            OBSERVACION = P_OBSERVACION
            WHERE TIPO = 1 AND ESTADO = 1 AND CODIGOGRUPO = P_GRUPO
            AND FECHA IS NULL;
    end sp_guardarestadomasivo;
    
    /*
    =====================================
    sp_actualizainfocod
    * Proceso para actualizar la informaciÃ³n de compromiso
      cuando ya tienen una fecha
    =====================================
    */
    procedure sp_actualizainfocod
    (
        P_CODIGOGRUPO IN VARCHAR2, P_CODIGOCLIENTE IN VARCHAR2 DEFAULT NULL,
        P_CODIGOPRODUCTO IN VARCHAR2, P_FECHA IN DATE, P_UNIDADES IN NUMBER, 
        P_OBSERVACION IN VARCHAR2 DEFAULT NULL, P_USUARIO IN VARCHAR2
    )
    is
    cursor c_clientesproducto is select distinct codigogrupo, codigocliente, codigoproducto 
                from t_vtas_producto_estados
                where codigogrupo = P_CODIGOGRUPO
                and (codigocliente = P_CODIGOCLIENTE or P_CODIGOCLIENTE is null)
                and codigoproducto = P_CODIGOPRODUCTO
                and fecha is not null;
    begin
        for clienteproducto in c_clientesproducto loop
            pk_vtas_pedidos.sp_producto_estado
            (
                P_CODIGOPRODUCTO    => clienteproducto.CODIGOPRODUCTO, 
                P_CODIGOGRUPO       => clienteproducto.CODIGOGRUPO, 
                P_CODIGOCLIENTE     => clienteproducto.CODIGOCLIENTE, 
                P_TIPO              => 1,
                P_USUARIO           => P_USUARIO, 
                P_FECHA             => P_FECHA, 
                P_UNIDADES          => P_UNIDADES, 
                P_OBSERVACION       => P_OBSERVACION
            );
        end loop;
    end sp_actualizainfocod;
    
    /*
    ===============================
    --sp_act_productocliente_est
    
    P_TIPO I: INACTIVAR -> SE DEBE ENVIAR A EST
    ===============================
    */
    procedure sp_guardaproductocliente_est
    (
        P_CODIGOGRUPO IN VARCHAR2, P_CODIGOCLIENTE IN VARCHAR2 DEFAULT NULL,
        P_CODIGOPRODUCTO IN VARCHAR2, P_FECHA IN DATE DEFAULT NULL, P_UNIDADES IN NUMBER DEFAULT NULL,
        P_OBSERVACION IN VARCHAR2 DEFAULT NULL, P_USUARIO IN VARCHAR2, P_TIPO IN CHAR
    )
    is
    cursor c_productosc(P_EST NUMBER) is 
    select codigogrupo, codigocliente, codigoproducto
    from t_vtas_cliente_producto
    where codigogrupo = P_CODIGOGRUPO
        and (codigocliente = P_CODIGOCLIENTE or (P_CODIGOCLIENTE is null))
        and codigoproducto = P_CODIGOPRODUCTO
        and estado = P_EST;
        
    V_ESTADO_SET NUMBER;
    begin
        --Cuando es I: Busco todos los que estÃ¡n activos para inactivarlos
        --Cuando es A: Busco todos los inactivos para inactivarlos
        select decode(P_TIPO, 'I', 1, 'A', 0) into V_ESTADO_SET from dual;
        
        
        if P_TIPO = 'I' then --Inactivar
            for prod in c_productosc(V_ESTADO_SET) loop
                pk_vtas_pedidos.sp_producto_estado
                (
                    P_CODIGOPRODUCTO    => prod.CODIGOPRODUCTO, 
                    P_CODIGOGRUPO       => prod.CODIGOGRUPO, 
                    P_CODIGOCLIENTE     => prod.CODIGOCLIENTE, 
                    P_TIPO              => 2,
                    P_USUARIO           => P_USUARIO, 
                    P_FECHA             => P_FECHA, 
                    P_UNIDADES          => P_UNIDADES, 
                    P_OBSERVACION       => P_OBSERVACION
                );
            end loop;
            
            pk_vtas_pedidos.sp_not_productoinactivar
                ( 
                    P_CODIGOGRUPO       => P_CODIGOGRUPO,
                    P_CODIGOCLIENTE     => P_CODIGOCLIENTE, 
                    P_CODIGOPRODUCTO    => P_CODIGOPRODUCTO, 
                    P_OBSERVACION       => P_OBSERVACION, 
                    P_USUARIO           => P_USUARIO
                );
    
        else --Activar
            for prod in c_productosc(V_ESTADO_SET) loop
                pk_vtas_pedidos.sp_producto_estado
                (
                    P_CODIGOPRODUCTO    => prod.CODIGOPRODUCTO, 
                    P_CODIGOGRUPO       => prod.CODIGOGRUPO, 
                    P_CODIGOCLIENTE     => prod.CODIGOCLIENTE, 
                    P_TIPO              => 3,
                    P_USUARIO           => P_USUARIO, 
                    P_FECHA             => NULL, 
                    P_UNIDADES          => NULL, 
                    P_OBSERVACION       => 'PRODUCTO ACTIVADO'
                );
                pk_vtas_pedidos.sp_producto_estado
                (
                    P_CODIGOPRODUCTO    => prod.CODIGOPRODUCTO, 
                    P_CODIGOGRUPO       => prod.CODIGOGRUPO, 
                    P_CODIGOCLIENTE     => prod.CODIGOCLIENTE, 
                    P_TIPO              => 1,
                    P_USUARIO           => P_USUARIO, 
                    P_FECHA             => P_FECHA, 
                    P_UNIDADES          => P_UNIDADES, 
                    P_OBSERVACION       => P_OBSERVACION
                );
            end loop;
        end if;
        
        
        update t_vtas_cliente_producto set estado = decode(V_ESTADO_SET, 1, 0, 1), 
                                        estadociclo = decode(V_ESTADO_SET, 0, 1, estadociclo)
        where codigogrupo = P_CODIGOGRUPO
        and (codigocliente = P_CODIGOCLIENTE or (P_CODIGOCLIENTE is null))
        and codigoproducto = P_CODIGOPRODUCTO
        and estado = V_ESTADO_SET;
        
    end sp_guardaproductocliente_est;
    
    /*
    =================================================
    sp_not_productoejecutivo2
    * Correo que notifica de todos los productos que han sido agregados a clientes, y que
        no han llenado informaciÃ³n de compromiso
    =================================================
    */
    procedure sp_not_productoejecutivo2
    is
    cursor c_ejecutivos is select
                        ejecutivo, email
                        from vt_vtas_ejec_nocodif;
    cursor c_prod_cli(p_ejec varchar2) is select 
                        grupo, cliente, codigoproducto, nombreproducto, ean13, ean14, lineanegocio, ejecutivo, marca
                        from vt_vtas_productos_nocodif
                        where ejecutivo = p_ejec;
    v_texto_correo clob;
    v_asunto varchar2(200) := 'NOTIFICACION PRODUCTO NUEVO';
    begin
        for eject in c_ejecutivos loop
            v_texto_correo := '<p>Estimado usuario,</p>
                                    <p>&nbsp;</p>
                                    <p>Se le recuerda que tiene productos que debe llenarle informacion de codificacion.
                                    <p>&nbsp;</p>';
             
            v_texto_correo := v_texto_correo || '<table border=''1'' style=''width:100%; padding:0px; border-spacing:0px;''>';
            v_texto_correo := v_texto_correo || '<tr BGCOLOR=''lightgrey''>';
            v_texto_correo := v_texto_correo || '<th  ALIGN=CENTER><strong>CÃ³digo Producto</strong></th>';
            v_texto_correo := v_texto_correo || '<th  ALIGN=CENTER><strong>DescripciÃ³n</strong></th>';
            v_texto_correo := v_texto_correo || '<th  ALIGN=CENTER><strong>EAN13</strong></th>';
            v_texto_correo := v_texto_correo || '<th  ALIGN=CENTER><strong>EAN14</strong></th>';
            v_texto_correo := v_texto_correo || '<th  ALIGN=CENTER><strong>Linea de Negocio</strong></th>';
            v_texto_correo := v_texto_correo || '<th  ALIGN=CENTER><strong>Marca</strong></th>';
            v_texto_correo := v_texto_correo || '<th  ALIGN=CENTER><strong>Grupo</strong></th>';
            v_texto_correo := v_texto_correo || '<th  ALIGN=CENTER><strong>Cliente</strong></th>';
            v_texto_correo := v_texto_correo || '</tr>';
            
            for producto_cliente in c_prod_cli(eject.ejecutivo) loop
                v_texto_correo := v_texto_correo || '<tr>';
                v_texto_correo := v_texto_correo || '<td>' || producto_cliente.codigoproducto || '</td>';
                v_texto_correo := v_texto_correo || '<td>' || producto_cliente.nombreproducto || '</td>';
                v_texto_correo := v_texto_correo || '<td>' || producto_cliente.ean13 || '</td>';
                v_texto_correo := v_texto_correo || '<td>' || producto_cliente.ean14 || '</td>';
                v_texto_correo := v_texto_correo || '<td>' || producto_cliente.lineanegocio || '</td>';
                v_texto_correo := v_texto_correo || '<td>' || producto_cliente.marca || '</td>';
                v_texto_correo := v_texto_correo || '<td>' || producto_cliente.grupo || '</td>';
                v_texto_correo := v_texto_correo || '<td>' || producto_cliente.cliente || '</td>';
                v_texto_correo := v_texto_correo || '<tr>';
            end loop;
            
            v_texto_correo := v_texto_correo || '</table><p>&nbsp;</p><p>Saludos Cordiales</p>';
            
            --un solo correo por ejecutivo lista de productos - clientes
            pk_corp_correo.sp_envio(
                        p_modulo => 'VTAS',
                        p_to => eject.email,
                        p_from => 'notificacion@zaimella.com',
                        p_subject => v_asunto,
                        p_body => v_texto_correo);
                        
        end loop;
    end sp_not_productoejecutivo2;
    
    /*
    ===============================================
    sp_not_productocodificacion
    * Procedimiento que envÃ­a un correo a todos los ejecutivos
        con los clientes y productos cuya fecha de compromiso de codificaciÃ³n ya haya pasado (mayor a sysdate)
    ===============================================
    */
    procedure sp_not_productocodificacion
    is
    --Cursor que trae NÃºmero de IdentificaciÃ³n y Correo de los ejecutivos
    --que tienen 
    cursor c_ejecutivos is select 
                            distinct cli.ejecutivo, usr.email from t_vtas_producto_estados proest
                                inner join vt_gzm_cliente cli on (proest.codigogrupo = cli.codigogrupo and proest.codigocliente = cli.codigocliente)
                                inner join vt_corp_usuario usr on (cli.ejecutivo = usr.numeroidentificacion)
                            where proest.estado = 1 and proest.tipo = 1 and proest.fecha < sysdate;
    v_correo clob;
    v_contador NUMBER;
    v_asunto varchar2(200) := 'Recordatorio Codificacion';
    begin
        
        for ejecutivo in c_ejecutivos loop
        
            select count(1) into v_contador
                    from t_vtas_producto_estados proest
                    inner join t_vtas_cliente_producto CP ON proest.codigocliente=CP.codigocliente AND  CP.CODIGOPRODUCTO=proest.codigoproducto 
                    AND CP.ESTADO=1 AND CP.ESTADOCICLO=1
                    inner join vt_gzm_cliente cli  on (proest.codigogrupo = cli.codigogrupo and proest.codigocliente = cli.codigocliente)
                    inner join vt_gzm_producto prod on (proest.codigoproducto = prod.codigoproducto)
                    where proest.estado = 1 and proest.tipo = 1 and proest.fecha < sysdate and cli.ejecutivo = ejecutivo.ejecutivo;
        
            IF(v_contador>0) THEN 
            
                v_correo := '<p>Estimado(a) usuario,</p>
                                            <p>&nbsp;</p>
                                            <p>Se notifica que se cumpliÃ³ la fecha de compromiso de codificaciÃ³n. Por favor actualizar
                                            <p>&nbsp;</p>';
                --Cabecera de la tabla
                v_correo := v_correo || '<table border=''1'' style=''width:100%; padding:0px; border-spacing:0px;''>';
                v_correo := v_correo || '<tr BGCOLOR=''lightgrey''>';
                
                v_correo := v_correo || '<th  style="text-align: center "><strong>lÃ­nea de Negocio</strong></th>';
                v_correo := v_correo || '<th  style="text-align: center "><strong>CÃ³digo Producto</strong></th>';
                v_correo := v_correo || '<th  style="text-align: center "><strong>DescripciÃ³n</strong></th>';
                v_correo := v_correo || '<th  style="text-align: center "><strong>EAN 13</strong></th>';
                v_correo := v_correo || '<th  style="text-align: center "><strong>EAN 14</strong></th>';
                
                v_correo := v_correo || '<th  style="text-align: center "><strong>Grupo</strong></th>';
                v_correo := v_correo || '<th  style="text-align: center "><strong>Cliente</strong></th>';
                
                v_correo := v_correo || '<th  style="text-align: center "><strong>Fecha Compromiso</strong></th>';
                v_correo := v_correo || '<th  style="text-align: center "><strong>Unidades proyectadas</strong></th>';
                v_correo := v_correo || '<th  style="text-align: center "><strong>Observacion</strong></th>';
                
                v_correo := v_correo || '</tr>';
                --Cuerpo de la tabla
                for clipro in (select cli.canal,cli.codigogrupo || ' - ' || cli.grupo as grupo,
                                cli.codigocliente || ' - ' || cli.nombres as cliente,
                                prod.codigoproducto,prod.nombreproducto,prod.codigobarra as ean13,prod.codigobarra as ean14,
                                prod.lineanegocio,prod.marca,proest.fecha,proest.unidades,proest.observacion
                                from t_vtas_producto_estados proest
                                inner join t_vtas_cliente_producto CP ON proest.codigocliente=CP.codigocliente AND  CP.CODIGOPRODUCTO=proest.codigoproducto 
                                AND CP.ESTADO=1 AND CP.ESTADOCICLO=1
                                inner join vt_gzm_cliente cli  on (proest.codigogrupo = cli.codigogrupo and proest.codigocliente = cli.codigocliente)
                                inner join vt_gzm_producto prod on (proest.codigoproducto = prod.codigoproducto)
                                where proest.estado = 1 and proest.tipo = 1 and proest.fecha < sysdate and cli.ejecutivo = ejecutivo.ejecutivo
                                    order by prod.codigoproducto, proest.codigogrupo, proest.codigocliente)loop
                                    
                        v_correo := v_correo || '<tr>';
                        v_correo := v_correo || '<td ALIGN=LEFT >' || clipro.lineanegocio ||'</td>';
                        v_correo := v_correo || '<td ALIGN=LEFT >' || clipro.codigoproducto ||'</td>';
                        v_correo := v_correo || '<td ALIGN=LEFT >' || clipro.nombreproducto ||'</td>';
                        v_correo := v_correo || '<td ALIGN=LEFT >' || clipro.ean13 ||'</td>';
                        v_correo := v_correo || '<td ALIGN=LEFT >' || clipro.ean14 ||'</td>';
                        v_correo := v_correo || '<td ALIGN=LEFT >' || clipro.grupo ||'</td>';
                        v_correo := v_correo || '<td ALIGN=LEFT >' || clipro.cliente ||'</td>';
                        v_correo := v_correo || '<td ALIGN=LEFT >' || clipro.fecha ||'</td>';
                        v_correo := v_correo || '<td ALIGN=LEFT >' || clipro.unidades ||'</td>';
                        v_correo := v_correo || '<td ALIGN=LEFT >' || clipro.observacion ||'</td>';
                        v_correo := v_correo || '<tr>';
      
                end loop;
        
                --Cierro la etiqueta de tabla
                v_correo := v_correo || '</table><p>&nbsp;</p><p>Saludos Cordiales</p>';
            
                PK_CORP_CORREO.SP_ENVIO(
                            P_MODULO => 'VTAS',
                            P_TO => ejecutivo.email,
                            P_FROM => 'notificacion@zaimella.com',
                            P_SUBJECT => v_asunto,
                            P_BODY => v_correo);
            END IF;
            
        end loop;
    
    end sp_not_productocodificacion;
    
    
    procedure sp_not_productoinactivar
    ( 
        P_CODIGOGRUPO IN VARCHAR2, P_CODIGOCLIENTE IN VARCHAR2 DEFAULT NULL, P_CODIGOPRODUCTO IN VARCHAR2, 
        P_OBSERVACION IN VARCHAR2, P_USUARIO IN VARCHAR2
    )
    is
    v_correo clob;
    v_correo_dest vt_corp_usuario.email%type;
    v_nombre varchar2(300);
    v_cliente varchar2(300);
    v_asunto varchar2(500);
    v_codean13 varchar2(200);
    v_codigojde varchar2(200);
    v_nombreproducto varchar2(200);
    cursor c_clientes is select
                        cli.codigocliente || ' - ' || cli.nombres as cliente, 
                        cli.codigogrupo || ' - '  || cli.grupo as grupo,
                        cli.canal
                        from t_vtas_cliente_producto clipro
                        inner join vt_gzm_cliente cli 
                            on (clipro.codigocliente = cli.codigocliente and clipro.codigogrupo = cli.codigogrupo)
                        where clipro.codigogrupo = P_CODIGOGRUPO 
                        and (clipro.codigocliente = P_CODIGOCLIENTE or P_CODIGOCLIENTE is null)
                        and clipro.codigoproducto = P_CODIGOPRODUCTO
                        and clipro.estado = 1;
    begin
        --Obtengo el correo del supervisor
        select EMAIL into v_correo_dest
        from vt_corp_usuario where nombreusuario=PK_EVOLUTION_EMPLEADO.F_RETORNASUPERVISOR(P_USUARIO);
        --Obtengo el nombre del usuario que hizo la inactivaciÃ³n
        select NOMBRES || ' ' || APELLIDOS into v_nombre
        from vt_corp_usuario where nombreusuario=P_USUARIO;
        --Obtengo la info del producto
        select CODIGOBARRA, CODIGOPRODUCTO, NOMBREPRODUCTO INTO v_codean13, v_codigojde, v_nombreproducto
        from vt_gzm_producto where codigoproducto = P_CODIGOPRODUCTO;
        --Creo el asunto
        v_asunto := 'VENTAS / INACTIVACION PRODUCTO DE ';
        
        --Primera parte del Correo
        v_correo := '<p>Estimado(a) usuario,</p>
                                    <p>&nbsp;</p>
                                    <p>Se realizÃ³ la inactivaciÃ³n del siguiente producto
                                    <p>&nbsp;</p>';
        v_correo := v_correo || '<p><strong>ObservaciÃ³n: </strong>'|| P_OBSERVACION ||'</p>';
        v_correo := v_correo || '<p><strong>Usuario: </strong>'|| v_nombre ||'</p><p>&nbsp;</p>';
        
        --Info del producto
        v_correo := v_correo || '<p><strong>EAN 13: </strong>'|| v_codean13 ||'</p>';
        v_correo := v_correo || '<p><strong>CÃ³digo JDE: </strong>'|| v_codigojde ||'</p>';
        v_correo := v_correo || '<p><strong>DescripciÃ³n: </strong>'|| v_nombreproducto ||'</p><p>&nbsp;</p>';
        
        
        --Obtengo el nombre del Cliente o Grupo
        if P_CODIGOCLIENTE is null then --Es grupo
        --=============================================
            select CODIGOGRUPO || ' - ' || GRUPO INTO v_cliente
            FROM VT_GZM_CLIENTE WHERE CODIGOGRUPO = CODIGOCLIENTE AND CODIGOGRUPO = P_CODIGOGRUPO;
            
            v_asunto := v_asunto || 'GRUPO ' || v_cliente;
            
            --Lista de clientes
            v_correo := v_correo || '<table border=''1'' style=''width:100%; padding:0px; border-spacing:0px;''>';
            v_correo := v_correo || '<tr BGCOLOR=''lightgrey''>';
            v_correo := v_correo || '<th  ALIGN=CENTER><strong>Grupo</strong></th>';
            v_correo := v_correo || '<th  ALIGN=CENTER><strong>Cliente</strong></th>';
            v_correo := v_correo || '</tr>';
            for cliente in c_clientes loop
                v_correo := v_correo || '<tr>';
                v_correo := v_correo || '<td ALIGN=LEFT >' || cliente.grupo ||'</td>';
                v_correo := v_correo || '<td ALIGN=LEFT >' || cliente.cliente ||'</td>';
                v_correo := v_correo || '<tr>';
            end loop;
            v_correo := v_correo || '</table>';
        --===============================================    
        else --Es cliente
        
            select CODIGOCLIENTE || ' - ' || NOMBRES INTO v_cliente
            FROM VT_GZM_CLIENTE WHERE CODIGOCLIENTE = P_CODIGOCLIENTE;
            
            v_asunto := v_asunto || 'CLIENTE ' || v_cliente;
            
            for infocli in c_clientes loop
                v_correo := v_correo || '<p><strong>Canal: </strong>'|| infocli.canal ||'</p>';
                v_correo := v_correo || '<p><strong>Grupo: </strong>'|| infocli.grupo ||'</p>';
                v_correo := v_correo || '<p><strong>Cliente: </strong>'|| infocli.cliente ||'</p>';
            end loop;
        end if;
        
        v_correo := v_correo || '<p>&nbsp;</p><p>Saludos Cordiales.</p>';
        
        
        PK_CORP_CORREO.SP_ENVIO(
                        P_MODULO => 'VTAS',
                        P_TO => v_correo_dest,
                        P_FROM => 'notificacion@zaimella.com',
                        P_SUBJECT => v_asunto,
                        P_BODY => v_correo);
                        
    end sp_not_productoinactivar;
    
    /*
    ==================================================
    
    ==================================================
    */
    procedure sp_agotamiento
    (
        P_CODIGOPRODUCTO IN VARCHAR2, P_FECHAAGOTAMIENTO IN DATE, 
        P_OBSERVACION IN VARCHAR2 , P_USUARIO IN VARCHAR2, P_COMPANIA IN VARCHAR2
    )
    is
    v_nombreproducto vt_gzm_producto.nombreproducto%type;
    v_resultado number;
    begin
        --Obtengo el nombre del producto
        select nombreproducto into v_nombreproducto
        from vt_gzm_producto where codigoproducto = P_CODIGOPRODUCTO;
        
        --EnvÃ­o a flujo
        data.pk_corp_flujoaprobacion.sp_flujoenviar(
            p_id => P_CODIGOPRODUCTO,
            p_modulo => 'VTAS',
            p_objeto => 'AGOTAMIENTO_PRODUCTO',
            p_objetodescripcion => 'AGOTAMIENTO PRODUCTO: ' || P_CODIGOPRODUCTO || ' - ' || v_nombreproducto,
            p_usuario => P_USUARIO,
            p_compania => P_COMPANIA,
            p_tipo1 => 'AGOTAMIENTO_PRODUCTO',
            p_exito => v_resultado
        );
        
        --Si el resultado es 0, es error
        if v_resultado = 0 then
            raise_application_error(-20100, data.pk_corp_flujoaprobacion.G_MENSAJE);
        end if;
        
        --Si resultado es 1, continÃºa el proceso
        insert into T_VTAS_PRODUCTOAGOTAMIENTO 
        (CODIGOPRODUCTO, FECHA_AGOTAMIENTO, AUDITORIAUSUARIO, AUDITORIAFECHA, OBSERVACION, ESTADO)
        values
        (P_CODIGOPRODUCTO, P_FECHAAGOTAMIENTO, P_USUARIO, sysdate, P_OBSERVACION, 2);


    end sp_agotamiento;
    
    /*
    =============================================================
    sp_agotamientoaprobar
    =============================================================
    */
    procedure sp_agotamientoaprobar
    (
        P_CODIGOPRODUCTO IN VARCHAR2, P_COMENTARIO IN VARCHAR2, P_USUARIO IN VARCHAR2, 
        P_COMPANIA IN VARCHAR2, P_ESTADO IN NUMBER
    )
    is
    v_exito number;
    v_terminaflujo number;
    begin
        IF P_ESTADO = 1 THEN --APROBAR
            DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJOAPROBAR(
                    P_ID            => P_CODIGOPRODUCTO ,
                    P_OBJETO        => 'AGOTAMIENTO_PRODUCTO',
                    P_ORDENMONTO    => NULL,
                    P_USUARIOFLUJO  => P_USUARIO, 
                    P_USUARIO       => P_USUARIO, 
                    P_COMENTARIO    => P_COMENTARIO,
                    P_MODULO        => 'VTAS', 
                    P_COMPANIA      => P_COMPANIA,
                    P_EXITO         => v_exito ,
                    P_TERMINOFLUJO  => v_terminaflujo
            );
            
            if v_exito = 0 then
                    raise_application_error(-20101, data.pk_corp_flujoaprobacion.G_MENSAJE);
            end if;
                
            if v_exito = 1 and v_terminaflujo = 1 then
                    --Actualizo la tabla de agotamiento
                    update t_vtas_productoagotamiento set estado = 1
                    where codigoproducto = P_CODIGOPRODUCTO and estado = 2;
                    
                    --Actualizo la tabla cliente_producto con ese codigo de producto
                    update t_vtas_cliente_producto set estadociclo = 4
                    where codigoproducto = P_CODIGOPRODUCTO;                    
                   commit; 
                   sp_not_agotamientoprod(P_CODIGOPRODUCTO, P_COMENTARIO);
                   
            end if;
        
        ELSE --RECHAZAR
            
            DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJORECHAZAR(
                    P_ID  => P_CODIGOPRODUCTO,
                    P_OBJETO => 'AGOTAMIENTO_PRODUCTO',
                    P_USUARIOFLUJO => P_USUARIO,
                    P_USUARIO => P_USUARIO,
                    P_COMENTARIO => P_COMENTARIO, 
                    P_MODULO => 'VTAS', 
                    P_COMPANIA => P_COMPANIA,
                    P_EXITO => v_exito
                );
            
            if v_exito = 0 then
                raise_application_error(-20101, data.pk_corp_flujoaprobacion.G_MENSAJE);
            end if;
            
            if v_exito = 1 then
                update t_vtas_productoagotamiento set estado = 0
                where codigoproducto = P_CODIGOPRODUCTO and estado = 2;
            end if;
            
        END IF;
        
    end sp_agotamientoaprobar;
    
    procedure sp_not_agotamientoprod  (P_CODIGOPRODUCTO IN VARCHAR2 , P_COMENTARIO IN VARCHAR2 DEFAULT NULL  )is
    
    cursor c_ejecutivos is 
            select distinct usr.email, cli.ejecutivo
            from t_vtas_cliente_producto clipro
            inner join vt_gzm_cliente cli on (clipro.codigocliente = cli.codigocliente and clipro.codigogrupo = cli.codigogrupo)
            inner join vt_corp_usuario usr on (cli.ejecutivo = usr.numeroidentificacion)
            where clipro.codigoproducto = P_CODIGOPRODUCTO
                and clipro.estadociclo = 4 and clipro.estado = 1;
                        
    cursor c_clientes(p_ejecut varchar2 default null) is
            select  cli.codigogrupo || ' ' || cli.grupo as grupo, cli.codigocliente || ' ' || cli.nombres as cliente
            from t_vtas_cliente_producto clipro
            inner join vt_gzm_cliente cli on (clipro.codigogrupo = cli.codigogrupo and clipro.codigocliente = cli.codigocliente)
            where clipro.codigoproducto = P_CODIGOPRODUCTO
                and clipro.estado = 1 and clipro.estadociclo = 4 and (cli.ejecutivo = p_ejecut or p_ejecut is null);     
                
    v_correo clob;
    v_correo_ejecutivo clob;
    v_asunto varchar2(200) := 'AGOTAMIENTO PRODUCTO DESCONTINUADO';
    v_ean13 varchar2(100);
    v_ean14 varchar2(100);
    v_descripcion varchar2(200);
    v_notificar varchar2(500);
     v_observacion varchar2(1500);
      v_solicitante varchar2(500);
    v_lineanegocio varchar2(200);
    v_fecha varchar2(30);
    
    begin
        --Info de agotamiento
        select to_char(FECHA_AGOTAMIENTO, 'DD/MM/YYYY'), u.EMAIL, u.NOMBRES||u.APELLIDOS, OBSERVACION 
        into v_fecha, v_notificar, v_solicitante, v_observacion
            from t_vtas_productoagotamiento  a  
            left join vt_corp_usuario u on (AUDITORIAUSUARIO=NOMBREUSUARIO)
            where codigoproducto = P_CODIGOPRODUCTO and a.estado = 1;
       
        --Info del producto
        select codigobarra, codigobarra,   nombreproducto,   lineanegocio into
            v_ean13,v_ean14,v_descripcion,v_lineanegocio
            from vt_gzm_producto where codigoproducto = P_CODIGOPRODUCTO;            
       
            --Hago primera parte del correo
            v_correo := '<p>Estimado(a) usuario,</p></br>';
            v_correo := v_correo || '<p>Se comunica la salida del siguiente producto del portafolio de Zaimella y su fecha tentativa de agotamiento:</p></br>
             <table border=''1'' style=''width:100%; padding:0px; border-spacing:0px;''>
                <tr BGCOLOR=''lightgrey''>
                <th  ALIGN=CENTER><strong>EAN 13</strong></th>
                <th  ALIGN=CENTER><strong>CÃ³digo JDE</strong></th>
                <th  ALIGN=CENTER><strong>Nombre del producto</strong></th>
                <th  ALIGN=CENTER><strong>LÃ­nea de Negocio</strong></th>
                <th  ALIGN=CENTER><strong>Fecha de agotamiento</strong></th>
                <th  ALIGN=CENTER><strong>ObservaciÃ³n</strong></th>
             </tr>
             <tr> <td ALIGN=LEFT >'	|| v_ean14 ||'</td>
                  <td ALIGN=LEFT >' || P_CODIGOPRODUCTO ||'</td>
                  <td ALIGN=LEFT >' || v_descripcion ||'</td>
                  <td ALIGN=LEFT >' || v_lineanegocio ||'</td>
                  <td ALIGN=LEFT >' || v_fecha ||'</td>
                  <td ALIGN=LEFT >' || v_observacion ||'</td>
            </tr></table></br>';
       IF(P_COMENTARIO IS NOT NULL) THEN 
       
            v_correo := v_correo || '<P>Comentario: '||P_COMENTARIO||'</p>';
       
       END IF;
            
       for ejecutivo in c_ejecutivos loop     

            v_correo_ejecutivo := v_correo;
              --Cabecera de la tabla de clientes
            v_correo_ejecutivo := v_correo_ejecutivo||
            '<table border=''1'' style=''width:100%; padding:0px; border-spacing:0px;''>
            <tr BGCOLOR=''lightgrey''>
            <th  ALIGN=CENTER><strong>Grupo</strong></th>
            <th  ALIGN=CENTER><strong>Cliente</strong></th></tr>';
            
            for cliente in c_clientes(ejecutivo.ejecutivo) loop
                v_correo_ejecutivo := v_correo_ejecutivo||
                     '<tr><td ALIGN=LEFT >' || cliente.grupo ||'</td>
                        <td ALIGN=LEFT >' || cliente.cliente ||'</td></tr>';
            end loop;
            
            v_correo_ejecutivo := v_correo_ejecutivo||
            ' </table></br>
            <p>&nbsp;</p><p>Saludos Cordiales.</p>';
            
            PK_CORP_CORREO.SP_ENVIO(
                        P_MODULO => 'VTAS',
                        P_TO => ejecutivo.email,
                        P_FROM => 'notificacion@zaimella.com',
                        P_SUBJECT => v_asunto,
                        P_BODY => v_correo_ejecutivo);
            
        end loop;
        
         select v_notificar||','||max(VALOR) into v_notificar from t_corp_udc 
                    where id_cabecera = 'VTAS_PARAM' and ID_TABLA = '5';
        
        PK_CORP_CORREO.SP_ENVIO(
                        P_MODULO => 'VTAS',
                        P_TO => v_notificar,
                        P_FROM => 'notificacion@zaimella.com',
                        P_SUBJECT => v_asunto,
                        P_BODY => v_correo);
        
    end sp_not_agotamientoprod;
    
    /*
    ============================================
    sp_producto_ciclo
    * Procedimiento que se ejecutarÃ¡ de manera periÃ³dica para actualizar el estado ciclo de 
        la tabla t_vtas_cliente_producto
    ============================================
    */
    procedure sp_producto_ciclo
    is
    V_NUMDIAS number;
    begin
        --Selecciono el nÃºmero de dÃ­as de clientes de la tabla general
        select to_number(valor) into V_NUMDIAS
        from t_corp_udc where id_cabecera = 'VTAS_PARAM' and id_tabla = '3';

        
        --1 era condiciÃ³n POR CODIFICAR A SIEMBRA
        UPDATE T_VTAS_CLIENTE_PRODUCTO CLIP SET CLIP.ESTADOCICLO = 2
        WHERE   CLIP.ESTADO = 1 AND    CLIP.ESTADOCICLO = 1 AND
        EXISTS ( SELECT 1 FROM F42119@JDEDTADL
                    INNER JOIN T_VTAS_PRODUCTO_ESTADOS PROEST ON
                    (sdan8= PROEST.CODIGOCLIENTE  and SDLITM=rpad(PROEST.CODIGOPRODUCTO, 25,' ') and TO_DATE(sdivd + 1900000,'yyyyddd')>=PROEST.FECHA)
                    WHERE   PROEST.CODIGOGRUPO = CLIP.CODIGOGRUPO AND PROEST.CODIGOCLIENTE = CLIP.CODIGOCLIENTE
                            AND PROEST.CODIGOPRODUCTO = CLIP.CODIGOPRODUCTO AND PROEST.ESTADO=1);
      
        --2 da condiciÃ³n
        UPDATE T_VTAS_CLIENTE_PRODUCTO CLIP SET CLIP.ESTADOCICLO = 3
        WHERE CLIP.ESTADO = 1 AND CLIP.ESTADOCICLO = 2 AND
         EXISTS ( SELECT 1 FROM  F42119@JDEDTADL  
                    WHERE   CLIP.CODIGOCLIENTE = sdan8 and rpad(CLIP.CODIGOPRODUCTO, 25,' ') = SDLITM
                    AND TO_DATE(sdivd + 1900000,'yyyyddd')+ V_NUMDIAS <= SYSDATE);
        
        --3 era condiciÃ³n
        update   t_vtas_cliente_producto a set a.estado = 0
        where  estado = 1 and estadociclo = 4 and pK_JDE_VENTAS.F_STOCKXPRODUCTO(
                                                    P_CODIGOPRODUCTO => a.codigoproducto,
                                                    P_BODEGA => '17003'
                                                  ) <= 0;
                                                  
    end sp_producto_ciclo;
    
    procedure sp_guardaordencompra (p_idpedido in out number,p_grupo in varchar2, p_cliente in varchar2,  p_OrdenCompra in varchar2,
                p_tipo in number, p_ordenpadre in number default null, p_fechaentrega in date default null,
                p_licitacion in number default null, p_observacion in varchar2 default null,
                P_Contenedor varchar2 default null, P_Negociacion varchar2 default null, P_Ruta varchar2 default null, P_Partida varchar2 default null,
                P_Transporte varchar2 default null, p_infoadicional varchar2 default null,  p_oc_cliente varchar2 default null, 
                p_usuario in varchar2, p_compania in varchar2)
                
    is
    v_tipounidad varchar2(5);
    V_PADRE NUMBER;
    V_contador NUMBER;
    v_ORDEN_COMPRA varchar2(100);
    begin
        
       v_tipounidad := PK_VTAS_PEDIDOS_COMMONS.F_UNIDAD_PRESENTACION(p_grupo, p_compania);
        V_PADRE :=p_ordenpadre;
        V_ORDEN_COMPRA :=   p_OrdenCompra;
        
        IF(p_tipo=2 AND p_OrdenCompra IS NULL) THEN  --- EXTERIOR
        
            V_PADRE := NULL;
            V_ORDEN_COMPRA := TO_CHAR(SYSDATE , 'MM/YYYY');
            
        ELSIF (p_tipo=3 AND p_ordenpadre IS NOT NULL) THEN  --- EXTERIOR HIJA
            
            SELECT ORDENCOMPRA INTO V_ORDEN_COMPRA
            FROM T_VTAS_PEDIDOS_CAB WHERE IDPEDIDO=p_ordenpadre;
            
            SELECT COUNT(1)+CASE WHEN p_idpedido IS NULL THEN 1 ELSE 0 END  INTO  V_contador 
            FROM T_VTAS_PEDIDOS_CAB WHERE IDPADRE=p_ordenpadre;
            V_ORDEN_COMPRA := V_ORDEN_COMPRA||'_'|| case WHEN V_contador=0 THEN 1 ELSE V_contador END;
            
        END IF;
            
        --Si p_idpedido es null: Es una insersiÃ³n
        if p_idpedido is null then
            
            p_idpedido := data.PK_COMMONS.F_SECUENCIA ('T_VTAS_PEDIDOS_CAB');
            
            insert into T_VTAS_PEDIDOS_CAB (IDPEDIDO,IDPADRE,TIPO,CODIGOCLIENTE,CODIGOGRUPO,ORDENCOMPRA,
            FECHAENTREGA,AUDITORIAFECHA,AUDITORIAUSUARIO,COMPANIA,LICITACION,ESTADO,OBSERVACION,PRESENTACION_OC,
             exp_contenedor,    EXP_NEGOCIACION,    exp_ruta,    exp_transporte,    exp_partida, INFORMACIONADICIONAL, EXP_ORDENCOMPRA)
            values (p_idpedido, V_PADRE, p_tipo, p_cliente, 
                    p_grupo, V_ORDEN_COMPRA, p_fechaentrega, sysdate, p_usuario,
                    p_compania, p_licitacion, 0, p_observacion, v_tipounidad, 
                     P_Contenedor  , P_Negociacion  , P_Ruta   ,P_Transporte , P_Partida  , p_infoadicional,p_oc_cliente);
        else
        --Si p_idpedido no es null: es una actualizaciÃ³n
            update T_VTAS_PEDIDOS_CAB set 
            IDPADRE = V_PADRE, ORDENCOMPRA= case when p_tipo=3 and ORDENCOMPRA is not null then  ORDENCOMPRA else  V_ORDEN_COMPRA end,
            TIPO = p_tipo,CODIGOCLIENTE = p_cliente,
            CODIGOGRUPO = p_grupo,FECHAENTREGA = p_fechaentrega,
            AUDITORIAFECHA = sysdate,AUDITORIAUSUARIO = p_usuario,
            COMPANIA = p_compania,LICITACION = p_licitacion,
            PRESENTACION_OC = v_tipounidad,OBSERVACION = p_observacion,
            exp_contenedor=P_Contenedor,    EXP_NEGOCIACION=P_Negociacion,    exp_ruta=P_Ruta,  EXP_ORDENCOMPRA=p_oc_cliente,
            exp_transporte=P_Transporte,    exp_partida=P_Partida, INFORMACIONADICIONAL=p_infoadicional
            where IDPEDIDO = p_idpedido and estado in (0,-1);
            
            update  t_vtas_pedidos set CODIGOCLIENTE=nvl(p_cliente, CODIGOCLIENTE) WHERE IDPEDIDO=p_idpedido;
            
        end if;
        
    end sp_guardaordencompra;
    
    
    procedure sp_eliminarOrdenCompra(p_idpedido number, p_usuario in varchar2) as 
    begin 
        delete t_vtas_pedidos where idpedido=p_idpedido
        and exists (select 1 from t_vtas_pedidos_cab 
        where idpedido=p_idpedido and auditoriaUsuario=p_usuario and estado in (0,-1 ));
        
        
        delete t_vtas_pedidos_cab 
        where idpedido=p_idpedido and auditoriaUsuario=p_usuario and estado in (0,-1 );
        
    end sp_eliminarOrdenCompra;
    
    /*iNGRESO DE PEDIDO MANUAL MEDIANTE UN ARCHIVO EXCEL
    pk_vtas_pedidos.sp_lecturaOrdenCompraManual(55);
    */
    procedure sp_lecturaOrdenCompraManual (p_idpedido in number) 
    as
        v_pedidos T_VTAS_PEDIDOS_CAB%ROWTYPE;
    begin 
        
        select *  into v_pedidos from T_VTAS_PEDIDOS_CAB cab   where cab.idpedido = p_idpedido;
        
        -- INSERTE DETALLE DEL EXCEL
        DELETE T_VTAS_PEDIDOS WHERE idpedido = p_idpedido;

        insert into T_VTAS_PEDIDOS
        (IDPEDIDO, LINEA, CODIGOPRODUCTO,  ESTADO,   CANTIDADORI, CANTIDAD, CANTIDAD_OC, CODIGOCLIENTE)
        select p_idpedido, MIN(C01), trim(C02),1, SUM(C04) ,SUM(C04),SUM(C04), v_pedidos.CODIGOCLIENTE
        from VT_APEX_EXCEL  where C01 > 1 AND TRIM(C02) IS NOT NULL
        GROUP BY C02;
        
        sp_homologacion (p_idpedido => p_idpedido); 
        --- ACTULIZO INFORMACION DE OC PARA QUE SEA IGUAL PEDIDO
        UPDATE T_VTAS_PEDIDOS SET 
        PRECIO_OC=PRECIO+ICE,        DESCUENTO_OC=DESCUENTO
        WHERE IDPEDIDO=p_idpedido;      
        
        
        sp_inactivacion(p_idpedido => p_idpedido);    --Inactivo Los Productos de forma automatica

        COMMIT;
    
    end sp_lecturaOrdenCompraManual;
    
    /* =======================================================================
    Procedimiento que se ejecuta al momento de subir una Orden de compra
    Procesa el excel subido y lo inserta en la tabla T_VTAS_PEDIDOS (Detalle)
    ParÃ¡metros:
        P_IDPEDIDO number -> CÃ³digo de la cabecera del pedido
    ========================================================================== */
    procedure sp_lecturaoc (p_idpedido in number)
    is
    cursor c_mapeo(P_CODIGOGRUPO VARCHAR2, P_COMPANIA VARCHAR2) is
        SELECT MA.ORDEN VALOR, MA.COLUMNA, ma.formula, COLUMNA_VARIABLE
          FROM DATA.VT_VTAS_PEDIDO_CONF_OC MA
         WHERE CODIGOGRUPO = P_CODIGOGRUPO
           AND COMPANIA = P_COMPANIA;

    v_codigogrupo T_VTAS_PEDIDOS_CAB.codigogrupo%type;
    v_codigocliente T_VTAS_PEDIDOS_CAB.codigocliente%type;
    v_compania T_VTAS_PEDIDOS_CAB.compania%type;
    v_formato_num T_VTAS_PEDIDO_CONF_OC.formato_num%type;
    v_mensaje varchar2(2000);
    v_fila number;
    v_columna number;
    v_tipo number;
    v_fila_inicio number;
    v_tipounidad number;
    v_query clob;
    v_query2 clob;
    v_colum varchar2(100);
    v_arreglo_descs apex_t_number;
    v_contador number;
    v_error number;

    begin
        v_query := null;
        delete from t_vtas_auditoriaoc where idpedido = p_idpedido;
        delete from t_tmp_b;
        delete from t_vtas_pedidos where idpedido = p_idpedido;

        select codigogrupo, codigocliente, CASE WHEN tipo IN (2,3) THEN 2 ELSE TIPO END, compania
          into v_codigogrupo, v_codigocliente, v_tipo, v_compania
          from T_VTAS_PEDIDOS_CAB cab
         where cab.idpedido = p_idpedido;

        select substr(conf.POSICION_OC, 1, instr(conf.POSICION_OC, ';') - 1),
               substr(conf.POSICION_OC, instr(conf.POSICION_OC, ';') + 1),
               conf.FORMATO_NUM,
               conf.INICIOFILADETALLE,
               conf.TIPOUNIDAD
          into v_fila, v_columna, v_formato_num, v_fila_inicio, v_tipounidad
          from T_VTAS_PEDIDO_CONF_OC conf
         where conf.codigogrupo = v_codigogrupo
           and conf.compania = v_compania;

        DBMS_OUTPUT.PUT_LINE('Fila: ' || nvl(v_fila,-1) || ' / Columna: ' || nvl(v_columna,-2));

        if v_fila is not null and v_columna is not null then
            v_query := 'update T_VTAS_PEDIDOS_CAB set ORDENCOMPRA = (';
            v_query := v_query || 'select regexp_replace( UPPER(C'|| lpad(v_columna + 1,2,'0') || '),''ORDEN|DE|COMPRA'','''' ) from VT_APEX_EXCEL WHERE ID = ' || v_fila;
            v_query := v_query || ') where idpedido = ' || p_idpedido;
            EXECUTE IMMEDIATE v_query;
        end if;

        insert into t_tmp_b (num01,TXT04,flag)
        select C01, CASE WHEN v_codigocliente IS NULL THEN C02 ELSE v_codigocliente END, 'FINAL'
          from VT_APEX_EXCEL
         where C01 >= v_fila_inicio;

        -- SP_LECTURAOC es invocado por el lector PDF. Las observaciones del PDF pueden
        -- concentrarse en una celda; se conservan hasta 1000 bytes, limite de T_TMP_B.
        insert into t_tmp_b (flag, num01,TXT01, TXT02, TXT03, TXT04, TXT05, TXT06, TXT07, TXT08, TXT09, TXT10,
                             TXT11, TXT12, TXT13, TXT14, TXT15, TXT16, TXT17, TXT18, TXT19, TXT20, TXT21, TXT22, TXT23,
                             TXT24, TXT25, TXT26)
        select 'EXCEL', SUBSTRB(REPLACE(C01, UNISTR('\00A0'), ''), 1, 1000), SUBSTRB(REPLACE(C02, UNISTR('\00A0'), ''), 1, 1000), SUBSTRB(REPLACE(C03, UNISTR('\00A0'), ''), 1, 1000),
               SUBSTRB(REPLACE(C04, UNISTR('\00A0'), ''), 1, 1000), SUBSTRB(REPLACE(C05, UNISTR('\00A0'), ''), 1, 1000), SUBSTRB(REPLACE(C06, UNISTR('\00A0'), ''), 1, 1000),
               SUBSTRB(REPLACE(C07, UNISTR('\00A0'), ''), 1, 1000), SUBSTRB(REPLACE(C08, UNISTR('\00A0'), ''), 1, 1000), SUBSTRB(REPLACE(C09, UNISTR('\00A0'), ''), 1, 1000),
               SUBSTRB(REPLACE(C10, UNISTR('\00A0'), ''), 1, 1000), SUBSTRB(REPLACE(C11, UNISTR('\00A0'), ''), 1, 1000), SUBSTRB(REPLACE(C12, UNISTR('\00A0'), ''), 1, 1000),
               SUBSTRB(REPLACE(C13, UNISTR('\00A0'), ''), 1, 1000), SUBSTRB(REPLACE(C14, UNISTR('\00A0'), ''), 1, 1000), SUBSTRB(REPLACE(C15, UNISTR('\00A0'), ''), 1, 1000),
               SUBSTRB(REPLACE(C16, UNISTR('\00A0'), ''), 1, 1000), SUBSTRB(REPLACE(C17, UNISTR('\00A0'), ''), 1, 1000), SUBSTRB(REPLACE(C18, UNISTR('\00A0'), ''), 1, 1000),
               SUBSTRB(REPLACE(C19, UNISTR('\00A0'), ''), 1, 1000), SUBSTRB(REPLACE(C20, UNISTR('\00A0'), ''), 1, 1000), SUBSTRB(REPLACE(C21, UNISTR('\00A0'), ''), 1, 1000),
               SUBSTRB(REPLACE(C22, UNISTR('\00A0'), ''), 1, 1000), SUBSTRB(REPLACE(C23, UNISTR('\00A0'), ''), 1, 1000), SUBSTRB(REPLACE(C24, UNISTR('\00A0'), ''), 1, 1000),
               SUBSTRB(REPLACE(C25, UNISTR('\00A0'), ''), 1, 1000), SUBSTRB(REPLACE(C26, UNISTR('\00A0'), ''), 1, 1000), SUBSTRB(REPLACE(C27, UNISTR('\00A0'), ''), 1, 1000)
          from VT_APEX_EXCEL
         where C01 >= v_fila_inicio;

        select COUNT(1) INTO v_contador from t_tmp_b where FLAG ='EXCEL';

        insert into t_vtas_auditoriaoc(IDPEDIDO,FILA,ESTADO,MENSAJE,FECHA,USUARIO)
        values (p_idpedido,0,1,'Lectura de datos desde la fila :'||v_fila_inicio||' Cantidad registro: '||v_contador,sysdate,'VTAS');

        COMMIT;

        FOR excel in (select * from t_tmp_b where FLAG ='EXCEL') loop
            BEGIN
                FOR config in (SELECT MA.ORDEN VALOR, MA.COLUMNA, ma.formula, COLUMNA_VARIABLE
                                 FROM DATA.VT_VTAS_PEDIDO_CONF_OC MA
                                WHERE CODIGOGRUPO = v_codigogrupo
                                  AND COMPANIA = v_compania) loop
                    v_query := 'update data.t_tmp_b a set ';

                    if TRIM(config.columna) IS NOT NULL then
                        case config.valor
                            when 1 then
                                v_query := v_query || ' (a.TXT01) = (select b.TXT' || lpad(config.columna,2,'0');
                            when 2 then
                                if v_compania = '00003' then
                                    v_query := v_query || ' (a.TXT02) = (select nvl(regexp_substr(b.TXT' || lpad(config.columna,2,'0') || ',''[0-9]{13}''), b.TXT' || lpad(config.columna,2,'0') || ')';
                                else
                                    if v_compania = '00003' then
                                    v_query := v_query || ' (a.TXT02) = (select nvl(regexp_substr(b.TXT' || lpad(config.columna,2,'0') || ',''[0-9]{13}''), b.TXT' || lpad(config.columna,2,'0') || ')';
                                else
                                    v_query := v_query || ' (a.TXT02) = (select b.TXT' || lpad(config.columna,2,'0');
                                end if;
                                end if;
                            when 3 then
                                v_query := v_query || ' (a.TXT03) = (select b.TXT' || lpad(config.columna,2,'0');
                            when 4 then
                                v_query := v_query || ' (a.NUM02) = (select to_number(';
                                if v_compania = '00003' then
                                    v_query := v_query || 'nullif(replace(regexp_replace(b.TXT' || lpad(config.columna,2,'0') || ',''[^0-9,.-]'',''''),'','',''''),''''), ''999999999999990D999999'', ''NLS_NUMERIC_CHARACTERS=.,''';
                                elsif (v_formato_num is not null) then
                                    v_query := v_query || 'b.TXT' || lpad(config.columna,2,'0') || ', ''' || v_formato_num || '''';
                                else
                                    -- APEX_DATA_PARSER puede entregar numeros XLSX con notacion cientifica.
                                    -- Se convierte de forma explicita sin eliminar el separador decimal.
                                    v_query := v_query || 'case when regexp_like(trim(b.TXT' || lpad(config.columna,2,'0') || '), ''^[+-]?[0-9]+([.,][0-9]+)?[Ee][+-]?[0-9]+$'') then to_number(replace(trim(b.TXT' || lpad(config.columna,2,'0') || '), ''.'', '',''), ''9D999999999999999999EEEE'', ''NLS_NUMERIC_CHARACTERS=,.'') else to_number(replace(trim(b.TXT' || lpad(config.columna,2,'0') || '), ''.'', '',''), ''999999999999990D999999999999999999'', ''NLS_NUMERIC_CHARACTERS=,.'') end';
                                end if;
                                v_query := v_query || ')';
                            when 5 then
                                if v_compania = '00003' then
                                    -- El precio puede llegar con S/, S/., SOL o SOL S/. APEX_DATA_PARSER
                                    -- puede exponer su representacion binaria completa; se toma el importe
                                    -- final, se convierte con precision suficiente y se normaliza a 4 decimales.
                                    v_query := v_query || ' (a.NUM03) = (select round(to_number(nullif(replace(regexp_substr(b.TXT' || lpad(config.columna,2,'0') || ',''[0-9]+([.,][0-9]+)?$''),'','',''''),''''), ''999999999999999999D999999999999999999'', ''NLS_NUMERIC_CHARACTERS=.,''), 4';
                                elsif (v_formato_num is not null) then
                                    v_query := v_query || ' (a.NUM03) = (select to_number(';
                                    v_query := v_query || 'b.TXT' || lpad(config.columna,2,'0') || ', ''' || v_formato_num || '''';
                                else
                                    -- Mantiene el mismo criterio numerico para precio y cantidad.
                                    v_query := v_query || ' (a.NUM03) = (select to_number(';
                                    v_query := v_query || 'case when regexp_like(trim(b.TXT' || lpad(config.columna,2,'0') || '), ''^[+-]?[0-9]+([.,][0-9]+)?[Ee][+-]?[0-9]+$'') then to_number(replace(trim(b.TXT' || lpad(config.columna,2,'0') || '), ''.'', '',''), ''9D999999999999999999EEEE'', ''NLS_NUMERIC_CHARACTERS=,.'') else to_number(replace(trim(b.TXT' || lpad(config.columna,2,'0') || '), ''.'', '',''), ''999999999999990D999999999999999999'', ''NLS_NUMERIC_CHARACTERS=,.'') end';
                                end if;
                                v_query := v_query || ')';
                            when 6 then
                                v_arreglo_descs := apex_string.split_numbers(config.columna, ':');
                                v_query2 := null;
                                for i in 1 .. v_arreglo_descs.count loop
                                    v_colum := v_arreglo_descs(i);
                                    if v_compania = '00003' then
                                        v_query2 := v_query2 || case when v_query2 is not null then ' + ' end || 'nvl(to_number(nullif(replace(regexp_replace(b.TXT' || lpad(v_colum,2,'0') || ',''[^0-9,.-]'',''''),'','',''''),''''), ''999999999999990D999999'', ''NLS_NUMERIC_CHARACTERS=.,''),0)';
                                    else
                                        if v_compania = '00003' then
                                        v_query2 := v_query2 || case when v_query2 is not null then ' + ' end || 'nvl(to_number(nullif(replace(regexp_replace(b.TXT' || lpad(v_colum,2,'0') || ',''[^0-9,.-]'',''''),'','',''''),''''), ''999999999999990D999999'', ''NLS_NUMERIC_CHARACTERS=.,''),0)';
                                    else
                                        if v_compania = '00003' then
                                        v_query2 := v_query2 || case when v_query2 is not null then ' + ' end || 'nvl(to_number(nullif(replace(regexp_replace(b.TXT' || lpad(v_colum,2,'0') || ',''[^0-9,.-]'',''''),'','',''''),''''), ''999999999999990D999999'', ''NLS_NUMERIC_CHARACTERS=.,''),0)';
                                    else
                                        v_query2 := v_query2 || case when v_query2 is not null then ' + ' end || 'to_number(replace(trim(nvl(b.TXT' || lpad(v_colum,2,'0') || ',0)), ''.'', '',''), ''999999999999990D999999999999999999'', ''NLS_NUMERIC_CHARACTERS=,.'')';
                                    end if;
                                    end if;
                                    end if;
                                end loop;
                                v_query := v_query || ' (a.NUM04) = (select ' || v_query2;
                        end case;

                        if length(v_query) > 0 then
                            v_query := v_query || ' from t_tmp_b b WHERE B.FLAG=''EXCEL'' AND b.NUM01= a.NUM01) WHERE FLAG=''FINAL'' AND NUM01='||excel.NUM01;
                            EXECUTE IMMEDIATE v_query;
                            commit;
                        end if;
                    end if;
                end loop;
            exception when others then
                v_mensaje := 'Error al mapear SQLERRM: ' || SQLERRM || ' - query: ' || v_query;
                insert into t_vtas_auditoriaoc(IDPEDIDO,FILA,ESTADO,MENSAJE,FECHA,USUARIO) values
                (p_idpedido,excel.NUM01,2,'Mensaje Error: '||v_mensaje||' -> TXT01: '|| excel.TXT01 || ', TXT02: '|| excel.TXT02 ||
                 ', TXT03: '|| excel.TXT03 || ', TXT04: '|| excel.TXT04 || ', TXT05: '|| excel.TXT05,sysdate,'VTAS');
            end;
        end loop;

        insert into T_VTAS_PEDIDOS
        (IDPEDIDO, LINEA, CODIGOPRODUCTOCLIENTE, NOMBREPRODUCTO,
         CODIGOBARRA, CODIGOPRODUCTO, ESTADO,
         CANTIDAD_OC, PRECIO_OC, DESCUENTO_OC, CODIGOCLIENTE)
        SELECT p_idpedido, NUM01, TXT01,
               SUBSTRB(TXT03, 1, 200),
               case when v_tipo=2 then null else TXT02 end,
               case when v_tipo=2 then TXT02 else null end,
               1, nvl(NUM02,0), nvl(NUM03,0), nvl(NUM04,0), nvl(v_codigocliente, TXT04)
          FROM t_tmp_b
         where FLAG='FINAL'
           AND NUM02>0
           AND ((TXT01 IS NOT NULL and length(TXT01)>2) OR TRIM(REPLACE(UPPER(TXT02), 'TOTAL', '')) IS NOT NULL)
           AND (v_compania <> '00003' OR UPPER(TRIM(NVL(TXT01, '-'))) NOT IN ('TOTAL', 'SUBTOTAL', 'OTRO', 'IGV'))
           -- Los totales pueden llegar en cualquier columna del Excel convertido.
           -- Se excluyen solo para Perú y sin asociarlos a un cliente específico.
           AND (v_compania <> '00003' OR NOT REGEXP_LIKE(
                   UPPER(NVL(TXT01, '') || ' ' || NVL(TXT02, '') || ' ' || NVL(TXT03, '') || ' ' ||
                         NVL(TXT04, '') || ' ' || NVL(TXT05, '') || ' ' || NVL(TXT06, '') || ' ' ||
                         NVL(TXT07, '') || ' ' || NVL(TXT08, '') || ' ' || NVL(TXT09, '') || ' ' ||
                         NVL(TXT10, '') || ' ' || NVL(TXT11, '') || ' ' || NVL(TXT12, '') || ' ' ||
                         NVL(TXT13, '') || ' ' || NVL(TXT14, '') || ' ' || NVL(TXT15, '') || ' ' ||
                         NVL(TXT16, '') || ' ' || NVL(TXT17, '') || ' ' || NVL(TXT18, '') || ' ' ||
                         NVL(TXT19, '') || ' ' || NVL(TXT20, '') || ' ' || NVL(TXT21, '') || ' ' ||
                         NVL(TXT22, '') || ' ' || NVL(TXT23, '') || ' ' || NVL(TXT24, '') || ' ' ||
                         NVL(TXT25, '') || ' ' || NVL(TXT26, '')),
                   '(^|[[:space:]])(TOTAL[[:space:]]+(UNIDADES|SIN[[:space:]]+IMPUESTOS)|SUB[[:space:]]+TOTAL)([[:space:]]|$)'))
           -- La revisión se repite sobre la fila EXCEL original para incluir
           -- columnas no mapeadas a la fila FINAL.
           AND (v_compania <> '00003' OR NOT EXISTS (
               SELECT 1
                 FROM t_tmp_b b
                WHERE b.FLAG = 'EXCEL'
                  AND b.NUM01 = t_tmp_b.NUM01
                  AND REGEXP_LIKE(
                      UPPER(NVL(b.TXT01, '') || ' ' || NVL(b.TXT02, '') || ' ' || NVL(b.TXT03, '') || ' ' ||
                            NVL(b.TXT04, '') || ' ' || NVL(b.TXT05, '') || ' ' || NVL(b.TXT06, '') || ' ' ||
                            NVL(b.TXT07, '') || ' ' || NVL(b.TXT08, '') || ' ' || NVL(b.TXT09, '') || ' ' ||
                            NVL(b.TXT10, '') || ' ' || NVL(b.TXT11, '') || ' ' || NVL(b.TXT12, '') || ' ' ||
                            NVL(b.TXT13, '') || ' ' || NVL(b.TXT14, '') || ' ' || NVL(b.TXT15, '') || ' ' ||
                            NVL(b.TXT16, '') || ' ' || NVL(b.TXT17, '') || ' ' || NVL(b.TXT18, '') || ' ' ||
                            NVL(b.TXT19, '') || ' ' || NVL(b.TXT20, '') || ' ' || NVL(b.TXT21, '') || ' ' ||
                            NVL(b.TXT22, '') || ' ' || NVL(b.TXT23, '') || ' ' || NVL(b.TXT24, '') || ' ' ||
                            NVL(b.TXT25, '') || ' ' || NVL(b.TXT26, '')),
                      '(^|[[:space:]])(TOTAL[[:space:]]+(UNIDADES|SIN[[:space:]]+IMPUESTOS)|SUB[[:space:]]+TOTAL)([[:space:]]|$)')
           ));
        COMMIT;

        delete from t_tmp_b;

        sp_homologacion (p_idpedido => p_idpedido);

        FOR config in (SELECT MA.ORDEN VALOR, MA.COLUMNA, ma.formula, COLUMNA_VARIABLE
                         FROM DATA.VT_VTAS_PEDIDO_CONF_OC MA
                        WHERE CODIGOGRUPO = v_codigogrupo
                          AND COMPANIA = v_compania
                          AND TRIM(formula) IS NOT NULL
                        order by ORDEN asc) LOOP
            v_query := 'update data.T_VTAS_PEDIDOS set '||config.COLUMNA_VARIABLE||' = ' ||config.formula||' WHERE IDPEDIDO='||p_idpedido;
            EXECUTE IMMEDIATE v_query;
            commit;
        END LOOP;

        sp_inactivacion(p_idpedido => p_idpedido);

    end sp_lecturaoc;
    
    function f_cantidadpresentacion (
        p_codigoproducto in varchar2
    ) return number
    is
        v_cantidad number;
    begin
        SELECT (UMCONV/10000000) into v_cantidad
         FROM F4101@JDEDTADL,F41002@JDEDTADL
         WHERE UMITM=IMITM
           AND UMUM(+)=IMUOM2
           AND UMRUM(+)=IMUOM1
           AND RTRIM(IMLITM)=RTRIM(p_codigoproducto)
           AND ROWNUM = 1;
        return v_cantidad;
    end f_cantidadpresentacion;
    
    
    /*
    ==============================
    Realiza la homologaciÃ³n por lÃ­nea de la OC,
    ParÃ¡metros
    Obligatorios:
        p_pedido : llave primaria - cÃ³digo del pedido
    No obligatorios:
        p_codigobarra
        p_codigoproductocli
        *Nota: Si no se envÃ­an los dos Ãºltimos parÃ¡metros, se actualizan todas las lÃ­neas de ese pedido
    ==============================
    */
    procedure sp_homologacion (p_idpedido in number,p_linea in number default null)
    is
        v_codigogrupo t_vtas_pedidos_cab.codigogrupo%type;
        v_codigocliente t_vtas_pedidos_cab.codigocliente%type;
        v_tipounidad t_vtas_pedidos_cab.PRESENTACION_OC%type;
        v_compania t_vtas_pedidos_cab.compania%type;
        v_error number;
        v_tipo number;
        v_codproducto t_vtas_pedidos.codigoproducto%type;
    begin
        select codigogrupo, codigocliente, presentacion_oc, TIPO, compania
          into v_codigogrupo, v_codigocliente, v_tipounidad, v_tipo, v_compania
          from T_VTAS_PEDIDOS_CAB
         where idpedido = p_idpedido;

        UPDATE T_VTAS_PEDIDOS a set (CODIGOPRODUCTO, CODIGOPRODUCTOCLIENTE)=
        (select max(b.CODIGOPRODUCTO), MAX(b.CODIGOPRODUCTOCLIENTE)
           from T_VTAS_CLIENTE_PRODUCTO b
          where a.CODIGOBARRA = nvl(b.CODIGOEAN, b.CODIGOPRODUCTO)
            and b.CODIGOCLIENTE=a.CODIGOCLIENTE
            and b.compania = v_compania
            and b.estado=1)
         WHERE A.IDPEDIDO = p_idpedido
           and A.LINEA = nvl(p_linea, A.LINEA)
           AND a.CODIGOBARRA IS NOT NULL;

        UPDATE T_VTAS_PEDIDOS a set (CODIGOPRODUCTO, CODIGOPRODUCTOCLIENTE)=
        (select max(b.CODIGOPRODUCTO), MAX(b.CODIGOPRODUCTOCLIENTE)
           from T_VTAS_CLIENTE_PRODUCTO b
          where a.CODIGOBARRA = nvl(b.CODIGOEAN, b.CODIGOPRODUCTO)
            and b.CODIGOCLIENTE=a.CODIGOCLIENTE
            and b.compania = v_compania)
         WHERE A.IDPEDIDO = p_idpedido
           and A.LINEA = nvl(p_linea, A.LINEA)
           AND a.CODIGOBARRA IS NOT NULL
           and CODIGOPRODUCTO is null;

        UPDATE T_VTAS_PEDIDOS a set CODIGOPRODUCTO=
        (select max(b.CODIGOPRODUCTO)
           from vt_gzm_producto b
          where a.CODIGOBARRA = nvl(b.CODIGOBARRA,b.CODIGOPRODUCTO)
            and b.CODIGOPRODUCTO=b.CODIGOPRODUCTOPADRE
            and b.compania = v_compania)
         WHERE A.IDPEDIDO = p_idpedido
           and A.LINEA = nvl(p_linea, A.LINEA)
           AND a.CODIGOBARRA IS NOT NULL
           AND CODIGOPRODUCTO IS NULL
           and exists (select 1
                         from vt_gzm_producto b
                        where a.CODIGOBARRA = b.CODIGOBARRA
                          and b.CODIGOPRODUCTO=b.CODIGOPRODUCTOPADRE
                          and b.compania = v_compania);

        UPDATE T_VTAS_PEDIDOS a set (CODIGOPRODUCTO, CODIGOBARRA)=
        (select max(b.CODIGOPRODUCTO),MAX(CODIGOEAN)
           from T_VTAS_CLIENTE_PRODUCTO b
          where a.CODIGOPRODUCTOCLIENTE = b.CODIGOPRODUCTOCLIENTE
            and b.CODIGOCLIENTE=a.CODIGOCLIENTE
            and b.compania = v_compania
            AND B.ESTADO=1)
         WHERE A.IDPEDIDO = p_idpedido
           and A.LINEA = nvl(p_linea, A.LINEA)
           AND a.CODIGOPRODUCTOCLIENTE IS NOT NULL
           AND CODIGOPRODUCTO IS NULL;

        UPDATE T_VTAS_PEDIDOS a set (CODIGOPRODUCTO, CODIGOBARRA)=
        (select max(b.CODIGOPRODUCTO),MAX(CODIGOEAN)
           from T_VTAS_CLIENTE_PRODUCTO b
          where a.CODIGOPRODUCTOCLIENTE = b.CODIGOPRODUCTOCLIENTE
            and b.CODIGOCLIENTE=a.CODIGOCLIENTE
            and b.compania = v_compania)
         WHERE A.IDPEDIDO = p_idpedido
           and A.LINEA = nvl(p_linea, A.LINEA)
            AND a.CODIGOPRODUCTOCLIENTE IS NOT NULL
            AND CODIGOPRODUCTO IS NULL;

        -- Para Peru, algunas plantillas informan Codigo SAP pero no EAN.
        -- Si no existio homologacion por cliente, usar ese codigo como respaldo.
        UPDATE T_VTAS_PEDIDOS a SET CODIGOPRODUCTO =
        (select max(b.CODIGOPRODUCTO)
           from vt_gzm_producto b
          where trim(a.CODIGOPRODUCTOCLIENTE) = trim(b.CODIGOPRODUCTO)
            and b.CODIGOPRODUCTO = b.CODIGOPRODUCTOPADRE
            and b.compania = v_compania)
         WHERE a.IDPEDIDO = p_idpedido
           and a.LINEA = nvl(p_linea, a.LINEA)
           and a.CODIGOPRODUCTOCLIENTE IS NOT NULL
           and a.CODIGOPRODUCTO IS NULL
           and v_compania = '00003'
           and exists (select 1
                         from vt_gzm_producto b
                        where trim(a.CODIGOPRODUCTOCLIENTE) = trim(b.CODIGOPRODUCTO)
                          and b.CODIGOPRODUCTO = b.CODIGOPRODUCTOPADRE
                          and b.compania = v_compania);

        -- Peru: si el valor mapeado como EAN no encontró homologación ni barra,
        -- se acepta como código SAP de producto sin alterar la lógica de Ecuador.
        UPDATE T_VTAS_PEDIDOS a set CODIGOPRODUCTO=
        (select max(b.CODIGOPRODUCTO)
           from vt_gzm_producto b
          where a.CODIGOBARRA = b.CODIGOPRODUCTO
            and b.CODIGOPRODUCTO=b.CODIGOPRODUCTOPADRE
            and b.compania = v_compania)
         WHERE A.IDPEDIDO = p_idpedido
           and A.LINEA = nvl(p_linea, A.LINEA)
           AND a.CODIGOBARRA IS NOT NULL
           AND CODIGOPRODUCTO IS NULL
           AND v_compania = '00003'
           and exists (select 1
                         from vt_gzm_producto b
                        where a.CODIGOBARRA = b.CODIGOPRODUCTO
                          and b.CODIGOPRODUCTO=b.CODIGOPRODUCTOPADRE
                          and b.compania = v_compania);

        UPDATE T_VTAS_PEDIDOS a set CODIGOBARRA=
        (select max(b.CODIGOBARRA)
           from vt_gzm_producto b
          where A.CODIGOPRODUCTO=b.CODIGOPRODUCTO
            and b.compania = v_compania)
         WHERE A.IDPEDIDO = p_idpedido
           and A.LINEA = nvl(p_linea, A.LINEA)
           AND CODIGOBARRA IS NULL
           AND CODIGOPRODUCTO IS NOT NULL;

        IF v_compania = '00003' THEN
            UPDATE T_VTAS_PEDIDOS pe SET
                   CODIGOPRODUCTOREFERENCIA = pe.CODIGOPRODUCTO,
                   pe.CANTIDADPRESENTACION = PK_SAP_VENTAS.F_FACTOR_BULTO_PAQUETE(pe.CODIGOPRODUCTO),
                   pe.NOMBREPRODUCTO = NVL(PK_SAP_VENTAS.F_NOMBREPRODUCTO(pe.CODIGOPRODUCTO), pe.NOMBREPRODUCTO),
                   pe.UNIDAD_MEDIDA = PK_SAP_VENTAS.F_UNIDADMEDIDA(pe.CODIGOPRODUCTO)
             where pe.IDPEDIDO = p_idpedido
               and pe.LINEA = nvl(p_linea, pe.LINEA)
               and pe.CODIGOPRODUCTO is not null;

            UPDATE T_VTAS_PEDIDOS pe SET
                   CANTIDADORI = CASE WHEN v_tipounidad = 2 THEN pe.CANTIDAD_OC * NVL(NULLIF(CANTIDADPRESENTACION,0),1) ELSE pe.CANTIDAD_OC END,
                   -- La OC en bulto/caja se convierte al mismo paquete que la cantidad.
                   -- Se divide por el factor SAP para conservar el importe de la linea.
                   PRECIO_OC = CASE WHEN v_tipounidad = 2 THEN ROUND(pe.PRECIO_OC / NVL(NULLIF(CANTIDADPRESENTACION,0),1), 4) ELSE pe.PRECIO_OC END,
                   pe.ICE = PK_SAP_VENTAS.F_ICEXPRODUCTO(pe.CODIGOPRODUCTO),
                   pe.PRECIO = NVL(NULLIF(PK_SAP_VENTAS.F_PRECIOXPRODUCTO(codigocliente, pe.CODIGOPRODUCTO), 0), pe.PRECIO_OC),
                   pe.DESCUENTO = nvl(PK_SAP_VENTAS.F_DESCUENTOXPRODUCTO(codigocliente, pe.CODIGOPRODUCTO),0),
                   pe.CANTIDAD = TRUNC(CASE WHEN v_tipounidad = 2 THEN pe.CANTIDAD_OC * NVL(NULLIF(CANTIDADPRESENTACION,0),1) ELSE pe.CANTIDAD_OC END)
             where pe.IDPEDIDO = p_idpedido
               and pe.LINEA = nvl(p_linea, pe.LINEA)
               and pe.CODIGOPRODUCTO is not null;
        ELSE
            UPDATE T_VTAS_PEDIDOS pe SET
                   CODIGOPRODUCTOREFERENCIA=trim(PK_JDE_VENTAS.F_REFERENCIACRUZADA(codigocliente,pe.CODIGOPRODUCTO)),
                   pe.CANTIDADPRESENTACION = pk_vtas_pedidos.f_cantidadpresentacion (p_codigoproducto => pe.CODIGOPRODUCTO)
             where pe.IDPEDIDO = p_idpedido
               and pe.LINEA = nvl(p_linea, pe.LINEA)
               and pe.CODIGOPRODUCTO is not null;

            UPDATE T_VTAS_PEDIDOS pe SET
                   (NOMBREPRODUCTO,UNIDAD_MEDIDA)=( SELECT IMDSC1,IMUOM2 FROM F4101@JDEDTADL WHERE trim(IMLITM)=nvl(CODIGOPRODUCTOREFERENCIA, CODIGOPRODUCTO))
             where pe.IDPEDIDO = p_idpedido
               and pe.LINEA = nvl(p_linea, pe.LINEA)
               and pe.CODIGOPRODUCTO is not null;

            UPDATE T_VTAS_PEDIDOS pe SET
                   CANTIDADORI= CASE WHEN v_tipounidad = 1 THEN pe.CANTIDAD_OC/CANTIDADPRESENTACION ELSE pe.CANTIDAD_OC END,
                   pe.ICE = PK_JDE_VENTAS.F_ICEXPRODUCTO(pe.CODIGOPRODUCTO,NULL),
                   pe.PRECIO = PK_JDE_VENTAS.F_PRECIOXPRODUCTO(codigocliente,nvl(CODIGOPRODUCTOREFERENCIA, CODIGOPRODUCTO),NULL,v_compania),
                   pe.DESCUENTO = nvl(PK_JDE_VENTAS.F_DESCUENTOXPRODUCTO(codigocliente,pe.CODIGOPRODUCTO,NULL,v_compania)*-1,0),
                   pe.CANTIDAD = TRUNC(CASE WHEN v_tipounidad = 1 THEN pe.CANTIDAD_OC/CANTIDADPRESENTACION ELSE pe.CANTIDAD_OC END)
             where pe.IDPEDIDO = p_idpedido
               and pe.LINEA = nvl(p_linea, pe.LINEA)
               and pe.CODIGOPRODUCTO is not null;

            IF(v_tipo IN (2,3)) THEN
                UPDATE T_VTAS_PEDIDOS pe SET
                       METROSCUBICOS=(SELECT MAX(ROUND((DPAN01/100000)*(DPAN02/100000)*(DPAN03/100000),5))
                                        FROM F5541D01@JDEDTADL
                                       WHERE trim(DPLITM)=CODIGOPRODUCTO
                                         AND trim(DPLV01)= UNIDAD_MEDIDA)
                 where pe.IDPEDIDO = p_idpedido
                   and pe.LINEA = nvl(p_linea, pe.LINEA)
                   and pe.CODIGOPRODUCTO is not null;
            END IF;
        END IF;

        commit;
    end sp_homologacion;
    
    /*
    =========================================
    sp_inactivacion
    Procedimiento que permite inactivar una o todas las lÃ­neas
    Tipos de InactivaciÃ³n
    1 Producto Obsoleto
    2 Emergencia Sanitaria
    3 Inactivo en la tabla T_VTAS_CLIENTE_PRODUCTO
    4 Cancelado por el usuario
    =========================================
    */
    procedure sp_inactivacion (p_idpedido in number,p_linea in number default null,
    P_TIPO NUMBER DEFAULT NULL, p_observacion in varchar2 default null)
    is
        v_compania t_vtas_pedidos_cab.compania%type;
    begin
        select compania
          into v_compania
          from t_vtas_pedidos_cab
         where idpedido = p_idpedido;

        if (P_TIPO =1 OR P_TIPO IS NULL) THEN
             UPDATE T_VTAS_PEDIDOS PE set estado = 0, tipoinactivo = 1
              WHERE pe.idpedido = p_idpedido
                and pe.estado = 1
                AND EXISTS (SELECT 1
                              FROM VT_GZM_PRODUCTO pro
                             where pro.CODIGOPRODUCTO = PE.CODIGOPRODUCTO
                               AND pro.estado = 0
                               AND pro.compania = v_compania);
        END IF;

        if (P_TIPO =2 OR P_TIPO IS NULL) THEN
             UPDATE T_VTAS_PEDIDOS PE set estado = 0, tipoinactivo = 2
              WHERE pe.idpedido = p_idpedido
                and pe.estado = 1
                AND EXISTS (select 1
                              from data.t_corp_udc
                             where id_cabecera='LISTAPRODU'
                               and ACTIVO='1'
                               and VALOR=CODIGOPRODUCTO);
        END IF;

        if (P_TIPO =3 OR P_TIPO IS NULL) THEN
             UPDATE T_VTAS_PEDIDOS PE set estado = 0, tipoinactivo = 3
              WHERE pe.idpedido = p_idpedido
                and pe.estado = 1
                and PE.CODIGOPRODUCTO is not null
                AND NOT EXISTS (
                    SELECT 1
                      FROM t_vtas_cliente_producto pro
                     where pro.CODIGOPRODUCTO = PE.CODIGOPRODUCTO
                       AND pro.codigocliente = PE.codigocliente
                       AND pro.compania = v_compania
                       AND pro.estado = 1 );
        end if;

        if (P_TIPO =4) then
            update t_vtas_pedidos
               set estado = 0, tipoinactivo = P_TIPO, observacion = p_observacion
             where idpedido = p_idpedido
               and linea = p_linea;
        end if;
    end sp_inactivacion;
    
    /*
    ===================================
    sp_agregarcodigoproducto
    Permite actualizar el CODIGOEAN y CODIGOPRODUCTOCLIENTE
    de la tabla T_VTAS_CLIENTE_PRODUCTO
    ===================================
    */
    procedure sp_agregarcodigoproducto(p_codigogrupo in varchar2,p_codigoproductocliente in varchar2,p_codigoproducto in varchar2)
    is
    begin
        update t_vtas_cliente_producto set 
        CODIGOPRODUCTOCLIENTE = p_codigoproductocliente
        where CODIGOGRUPO = p_codigogrupo  and CODIGOPRODUCTO = p_codigoproducto;
    end sp_agregarcodigoproducto;
    
    /*Proceso que envia a flujo*/
    procedure sp_envioocflujo    (p_idpedido in number,p_usuario in varchar2,p_compania in varchar2,p_comentario in varchar default null)
    is
        v_cliente vt_gzm_cliente.nombres%type;
        v_grupo vt_gzm_cliente.grupo%type;
        v_grupoCODIGO T_VTAS_PEDIDOS_CAB.CODIGOGRUPO%TYPE;
        v_resultado number;
        v_numerr number;
        v_numdet number;
        v_TIPO number;
        v_contador number;
        v_ordenCompra varchar(200);
        v_validacion_oc number;
        v_mensaje_oc varchar2(2500);
    begin
    
        --Verifico que haya subio la OC
        select count(1) into v_numdet 
        from t_vtas_pedidos   where idpedido = p_idpedido and estado = 1;
        
        if v_numdet = 0 then
            raise_application_error(-20100, 'La Orden de Compra no tiene productos activos en el detalle');
        end if;
        
        --Obtengo la informaciÃ³n del cliente
        select cli.codigogrupo, cli.codigogrupo || ' - ' || cli.grupo,  cli.codigocliente || ' - ' || cli.nombres, ORDENCOMPRA, TIPO
                into  v_grupoCODIGO,v_grupo,v_cliente, v_ordenCompra, v_TIPO
        from t_vtas_pedidos_cab cab
            inner join vt_gzm_cliente cli   on (nvl(cab.codigocliente, cab.codigogrupo) = cli.codigocliente
                                      and cli.compania = cab.compania)
        where idpedido = p_idpedido
          and cab.compania = p_compania;
        
        
        
        IF(V_TIPO=2) THEN  --- EXTERIOR PADRE
             update t_vtas_pedidos_cab set estado = 1, ESTADO_CUBICAJE=2 where idpedido = p_idpedido;     
            RETURN;
        END IF;
        
        IF (PK_VTAS_PEDIDOS_COMMONS.F_PEDIDO_MANUAL(p_usuario)>0) THEN 
            sp_aprobarflujo_oc(p_idpedido=>p_idpedido,p_TIPO =>1, p_compania =>p_compania );
            --SP_ENVIAR_CUBICAJE( p_pedido =>p_idpedido , p_compania =>p_compania );
            RETURN;
        END IF;
        
        PK_VTAS_PEDIDOS_COMMONS.SP_VALIDAR_OC(
            P_PEDIDO => p_idpedido,
            P_ORDENCOMPRA => v_ordenCompra,
            P_CLIENTE => v_grupoCODIGO,
            P_RESULTADO => v_validacion_oc,
            P_MENSAJE_ERROR => v_mensaje_oc,
            P_COMPANIA => p_compania
        );

        IF NVL(v_validacion_oc, 0) = 0 THEN
            raise_application_error(-20100, v_mensaje_oc);
        END IF;

        --EXTERIOR 
        SELECT count(1) into v_numerr  
        FROM vt_gzm_cliente WHERE CODIGOORIGEN='EXT' AND CODIGOCLIENTE=v_grupoCODIGO AND COMPANIA=p_compania;
        v_numerr:= case when v_numerr> 0 then 3 else 0 end;
        
        --- descuentos en factura NACIONAL 
        IF(v_numerr=0) THEN 
            select count(1) into v_numerr  
            from vt_vtas_pedidos where idpedido = p_idpedido and DESCUENTO>0 and estado=1;
            
            v_numerr:= case when v_numerr> 0 then 1 else 0 end;
        END IF;
        
        data.pk_corp_flujoaprobacion.sp_flujoenviar(
            p_id => p_idpedido,
            p_modulo => 'VTAS',
            p_objeto => 'PEDIDO',
            p_objetodescripcion => 'NUEVA ORDEN DE COMPRA: GRUPO ' 
            || v_grupo || '  CLIENTE: ' || v_cliente
            ||'<p>Orden Compra: '||v_ordenCompra|| '</p>',
            p_usuario => P_USUARIO,
            P_COMENTARIO =>p_comentario,
            p_compania => P_COMPANIA,
            p_tipo1 => 'PEDIDOS',
            p_tipo2 => v_numerr,
            p_exito => v_resultado);
       
        
        --Si el resultado es 0, es error
        if v_resultado = 0 then
            raise_application_error(-20100, data.pk_corp_flujoaprobacion.G_MENSAJE);
        end if;
        
        --Si no hubo erroes
        update t_vtas_pedidos_cab set estado = 2
        where idpedido = p_idpedido;
        
    end sp_envioocflujo;
    
    /*
    ============================
    sp_aprobarflujo_oc
    ============================
    Proceso que se ejecuta al aprobar una orden de compra
    p_idpedido pk
    p_TIPO number -> 1 APROBAR
                      0 RECHAZAR
                      pk_vtas_pedidos.sp_aprobarflujo_oc(p_idpedido=>130,p_TIPO =>1, p_compania =>'00001' );
    */
    procedure sp_aprobarflujo_oc    (p_idpedido in number,p_TIPO in number, p_compania varchar )
    is
    v_cliente varchar(100);
    v_USUARIO varchar(100);
    v_orden varchar(100);
    v_correo varchar(500);
    v_clientenombre varchar(300);
    v_texto_correo clob;
    begin
 
        update t_vtas_pedidos_cab
           set estado = CASE WHEN p_TIPO=1 THEN 1 ELSE -1 END,
               estado_cubicaje = CASE WHEN p_TIPO=1 AND p_compania = '00003' THEN 2 ELSE estado_cubicaje END
         where idpedido = p_idpedido;

        ---envio a cubicaje 
        if(p_TIPO=1 and p_compania <> '00003') then 
            SP_ENVIAR_CUBICAJE( p_pedido =>p_idpedido , p_compania =>p_compania );
        end if; 

        ---envio a SAP Peru
        if(p_TIPO=1 and p_compania = '00003') then
            declare
                v_sap_exito number;
                v_sap_mensaje varchar2(4000);
            begin
                DATA.PK_SAP_VENTAS_WS.SP_CREAR_PEDIDO(
                    P_IDPEDIDO => p_idpedido,
                    P_USUARIO => NVL(V('APP_USER'), USER),
                    P_EXITO => v_sap_exito,
                    P_MENSAJE => v_sap_mensaje
                );
            end;
        end if;

    end sp_aprobarflujo_oc;
    
    
    function f_retornadiferencia     (        p_valor1 in number default null,        p_valor2 in number default null
    ) return number
    is
    begin
        if p_valor1 <> p_valor2 then
            return 1;
        else
            return 0;
        end if;
    end;
    
    
    /*
    ===============================================
    
    ==============================================
    FunciÃ³n que retorna la cantidad de errores
    0 No hay errores
    */
    function f_numerrores   (p_idpedido in number, p_linea in number,
    p_tipo in number default null,    p_ruta number default 0) return number
    is
        v_errores number;
    begin
        if(p_tipo is null) then 
            select 
            case when (cantidadori <> cantidad and p_ruta=0)  then 1 else 0 end +
            -- Peru compara precios a cuatro decimales; las demas companias conservan dos.
            case
                when exists (select 1 from t_vtas_pedidos_cab cab where cab.idpedido = p_idpedido and cab.compania = '00003')
                    then case when round(precio_oc,4) <> round(precio+ice,4) then 1 else 0 end
                else case when round(precio_oc,2) <> round(precio+ice,2) then 1 else 0 end
            end +
            case when  round(descuento,2) <> round(descuento_oc,2)  then 1 else 0 end
            into v_errores
            from t_vtas_pedidos where idpedido = p_idpedido
            and linea = p_linea and estado=1 ;
        end if;
    
        --Cantidades diferentes
        if (p_tipo=1 and p_ruta=0) then 
        
            select count(1) into v_errores
            from t_vtas_pedidos where idpedido = p_idpedido
            and linea = p_linea and estado=1 and CODIGOPRODUCTO is not null and cantidadori <> cantidad;
            
        end if;
        
        --Precios diferentes
        if (p_tipo=2) then 
        
            select nvl(v_errores, 0) + count(1)  into v_errores from Vt_vtas_pedidos
            where idpedido = p_idpedido and linea = p_linea and estado=1 and CODIGOPRODUCTO is not null and precio_final <> precio_oc_final;   
       
        end if;
        
        --Descuentos diferentes
        if (p_tipo=3) then 
        
            select nvl(v_errores, 0) + count(1)  into v_errores
            from t_vtas_pedidos where idpedido = p_idpedido
            and linea = p_linea and estado=1 and CODIGOPRODUCTO is not null and round(descuento,2) <> round(descuento_oc,2);   
      
        end if;
        
        --Producto por codificar
        /*if (nvl(p_tipo,4)=4) then 
        
            select nvl(v_errores, 0) + count(1)  into v_errores
            from t_vtas_pedidos pe
                inner join t_vtas_pedidos_cab cab
                on (pe.idpedido = cab.idpedido)
                left join t_vtas_cliente_producto clipro
                on (cab.codigogrupo = clipro.codigogrupo 
                    and cab.codigocliente = clipro.codigocliente 
                    and pe.codigoproducto = clipro.codigoproducto)
            where pe.idpedido = p_idpedido
            and pe.linea = p_linea and pe.estado=1 and pe.CODIGOPRODUCTO is not null
            and clipro.estadociclo = 1;   
            
        end if;*/
        
        --Producto No Homologado
         if (nvl(p_tipo,5)=5) then 
            select nvl(v_errores, 0) + count(1)  into v_errores from t_vtas_pedidos
            where idpedido = p_idpedido and linea = p_linea and estado=1 and codigoproducto is null;   
        end if;
        
        return v_errores;
        
    end f_numerrores;
    
    function f_mensaje_errores    (p_idpedido in number,p_linea in number) return varchar2
    is
    v_msg_lista varchar2(500);
    v_msg_errores varchar2(500);
    begin
        --Cantidades diferentes
         v_msg_errores := case when  f_numerrores(p_idpedido=>p_idpedido, p_linea=>p_linea, p_tipo=>1) >0 then
            '<li>Cantidad</li>' else '' end;
        --Precios diferentes
         v_msg_errores := v_msg_errores ||case when  f_numerrores(p_idpedido=>p_idpedido, p_linea=>p_linea, p_tipo=>2) >0 then
            '<li>Precio</li>' else '' end;
            --Descuentos diferentes
         v_msg_errores := v_msg_errores ||case when  f_numerrores(p_idpedido=>p_idpedido, p_linea=>p_linea, p_tipo=>3) >0 then
            '<li>Descuento</li>' else '' end;
            --Estado Ciclo por Codificar
         v_msg_errores := v_msg_errores ||case when  f_numerrores(p_idpedido=>p_idpedido, p_linea=>p_linea, p_tipo=>4) >0 then
            '<li>Estado Ciclo por codificar</li>' else '' end;
            --Producto No Homologado
         v_msg_errores := v_msg_errores ||case when  f_numerrores(p_idpedido=>p_idpedido, p_linea=>p_linea, p_tipo=>5) >0 then
            '<li>Producto No Homologado</li>' else '' end;
            
         if(trim(v_msg_errores) is not null) then 
            v_msg_lista := '<ul>'||v_msg_errores || '</ul>';
         end if;
        
        return v_msg_lista;
    
    end f_mensaje_errores;
    
    /*
    =========================================
    f_cantidadpadre
    =========================================
    Funcion que retorna la cantidad de productos del pedido padre
    p_idpedido id del pedido padre
    */
    function f_cantidadpadre    (        p_idpedido in number default null,        p_codigoproducto in varchar2 default null
    ) return number
    is 
    v_cantidad number;
    begin
        
        if p_codigoproducto is null or p_idpedido is null then --Si no tiene cÃ³digo de producto, retorna null
            return null;
        end if;
        
        select nvl(cantidad, 0) into v_cantidad
        from t_vtas_pedidos
        where idpedido = p_idpedido
            and codigoproducto = p_codigoproducto
            and estado = 1;
        
        return v_cantidad; --Retorna la cantidad de producto
        
    exception when no_data_found then --En caso de que no lo encuentre, retorna null
        return null;
    end f_cantidadpadre;
    
    /*
    =========================================
    f_cantidadtotalhijas
    =========================================
    Funcion que retorna la cantidad total de todas las hijas
    p_idpedido id del pedido padre
    */
    function f_cantidadtotalhijas    (        p_idpedido in number default null,        p_codigoproducto in varchar2 default null
    ) return number
    is
    v_cantidad number;
    begin
        
        if p_codigoproducto is null or p_idpedido is null then
            return null;
        end if;
        
        select sum(cantidad) into v_cantidad 
        from t_vtas_pedidos det
        inner join t_vtas_pedidos_cab cab
        on (det.idpedido = cab.idpedido)
        where cab.idpadre = p_idpedido
        and det.codigoproducto = p_codigoproducto;
        
    exception when no_data_found then
        return null;
    end f_cantidadtotalhijas;
    
    /*
    =========================================
    sp_guardainfoadicional
    =========================================
    Procedimiento que guarda los campos informacionadicional e informacionadicional2
    en la cabecera del pedido
    */
    procedure sp_guardainfoadicional(p_idpedido in number,        P_FECHAENTREGA IN DATE,
        p_infoadicional in varchar2 default null,        p_infoaficional2 in varchar2 default null)
    is
    begin
        update t_vtas_pedidos_cab set   
        FECHAENTREGA=P_FECHAENTREGA,
        INFORMACIONADICIONAL = RPAD( p_infoadicional, 30,' ')||RPAD( p_infoaficional2, 30,' ') 
        where idpedido = p_idpedido;
    end sp_guardainfoadicional;
    
    /*
    =========================================
    sp_inserta_pedsug_tmp
    =========================================
    Procedimiento que inserta en la tabla t_tmp_b
    Lo filtrado de la tabla t_vtas_cliente_producto
    para enviar a ruta de pedido sugerido
    */
    procedure sp_inserta_pedsug_tmp
    (
        p_codigogrupo in varchar2,
        p_codigocliente in varchar2 default null,
        p_lineanegocio in varchar2 default null,
        p_marca in varchar2 default null,
        p_submarca in varchar2 default null,
        p_codproducto in varchar2 default null
    )
    is
    v_maxsec number;
    begin
        
        select NVL(max(NUM01),0) into v_maxsec
        from t_tmp_b;
        
        merge into t_tmp_b t
        using (
            select clipro.codigogrupo, clipro.codigocliente, clipro.codigoproducto,
                    pro.CODIGOLINEA, pro.CODIGOMARCA, pro.CODIGOSUBMARCA,
                    clipro.PS_PERIODOS, clipro.PS_DIAS_INVENTARIO, rownum + v_maxsec AS SECUENCIA
                from t_vtas_cliente_producto clipro
                inner join vt_gzm_producto pro
                on (clipro.codigoproducto = pro.codigoproducto)
                where clipro.codigogrupo = p_codigogrupo
                    and (clipro.codigocliente = p_codigocliente or p_codigocliente is null)
                    and (pro.codigolinea = p_lineanegocio or p_lineanegocio is null)
                    and (pro.codigomarca = p_marca or p_marca is null)
                    and (pro.codigosubmarca = p_submarca or p_submarca is null)
                    and (pro.codigoproducto = p_codproducto or p_codproducto is null)
            ) lista
        on (lista.codigogrupo = t.TXT01 and lista.codigocliente = t.TXT02 and lista.codigoproducto = t.TXT03)
        WHEN NOT MATCHED THEN
            INSERT (t.FLAG, t.NUM01, t.TXT01, t.TXT02, t.TXT03, 
                    t.TXT04, t.NUM02, t.TXT05, t.TXT06, t.TXT07)
            VALUES ('N', lista.SECUENCIA, lista.codigogrupo, lista.codigocliente, lista.codigoproducto, 
                    lista.PS_PERIODOS, lista.PS_DIAS_INVENTARIO, lista.CODIGOLINEA, lista.CODIGOMARCA, lista. CODIGOSUBMARCA);
            
    end sp_inserta_pedsug_tmp;
    
    /*
    =========================================
    sp_inserta_pedsug_tmp
    =========================================
    Procedimiento que actualiza la tabla t_tmp_b
    cuando se hace un cambio en el IG de la APP 112 P616
    */
    procedure sp_guardalinea_pedsug
    (
        p_linea in number,
        p_periodos in varchar2,
        p_diasinventario in number
    )
    is
    begin
        update t_tmp_b
        set TXT04 = p_periodos,
            NUM02 = p_diasinventario,
            FLAG = 'S' --S -> Significa que se editÃ³
        where NUM01 = p_linea;
    end sp_guardalinea_pedsug;
    
    /*
    =========================================
    sp_guardado_pedsug
    =========================================
    Procedimiento que actualiza la tabla t_tmp_b
    de forma masiva cuando se da click en guardar y llenaron los items
    num_dias_inventario y periodos de la APP 112 P616
    */
    procedure sp_guardado_pedsug
    (
        p_grupo in varchar2,
        p_cliente in varchar2 default null,
        p_lineanegocio in varchar2 default null,
        p_marca in varchar2 default null,
        p_submarca in varchar2 default null,
        p_producto in varchar2 default null,
        p_periodos in varchar2,
        p_diasinv in number
    )
    is
    begin
        update t_tmp_b set TXT04 = p_periodos, NUM02 = p_diasinv, FLAG = 'S'
        where TXT01 = p_grupo
              and (TXT02 = p_cliente or p_cliente is null)
              and (TXT05 = p_lineanegocio or p_lineanegocio is null)
              and (TXT06 = p_marca or p_marca is null)
              and (TXT07 = p_submarca or p_submarca is null);
    end;
    
    procedure sp_envio_pedidosug
    (
        p_compania in varchar2,
        p_usuario in varchar2,
        p_motivo in varchar2
    )
    is
    v_numbero number;
    v_exito number;
    v_contador number;
    begin
        
        select count(1) into v_contador
        from t_tmp_b t
            where t.flag = 'S';
            
        if v_contador = 0 then
            raise_application_error(-20102, 'No tiene registros para actualizar');
        end if;
        
        --Obtengo Secuencia
        v_numbero := data.PK_COMMONS.F_SECUENCIA ('T_VTAS_PEDIDOSUGERIDO_CAMBIO');
        
        --EnvÃ­o a Flujo
        data.pk_corp_flujoaprobacion.sp_flujoenviar(
            p_id => v_numbero,
            p_modulo => 'VTAS',
            p_objeto => 'PEDIDOSUGERIDO',
            p_objetodescripcion => 'NUEVO CAMBIO DE PEDIDO SUGERIDO POR USUARIO: ' || p_usuario,
            p_usuario => P_USUARIO,
            p_compania => P_COMPANIA,
            p_tipo1 => 'ACT',
            p_exito => v_exito);
            
        --Si retorna 0 quiere decir que hubo un error
        if v_exito = 0 then
            raise_application_error(-20103, data.pk_corp_flujoaprobacion.G_MENSAJE);
        end if;
        
        --Si no hubo errores
        --Inserto cabecera
        insert into T_VTAS_PEDIDOSUGERIDO_CAMBIO
        (IDPEDIDOSUG, AUDITORIAUSUARIO, AUDITORIAFECHA, JUSTIFICACION, ESTADO) values 
        (v_numbero, p_usuario, sysdate, p_motivo, 2);
        
        --Inserto el detalle
        insert into T_VTAS_PEDIDO_CONF_SUGERIDO
        (IDPEDIDOSUG, CODIGOGRUPO, CODIGOCLIENTE, CODIGOPRODUCTO, PERIODOS, DIAS_INVENTARIO)
        select v_numbero, t.txt01, t.txt02, t.txt03, t.txt04, t.num02
            from t_tmp_b t
            where t.flag = 'S';
            
        delete from t_tmp_b;
        
    end sp_envio_pedidosug;
    
    
    procedure sp_aprobar_pedidosug
    (
        p_idpedidosug in number,
        p_compania in varchar2,
        p_usuario in varchar2,
        p_comentario in varchar2
    )
    is
    v_exito number;
    v_terminaflujo number;
    begin
    
        DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJOAPROBAR(
                    P_ID            => p_idpedidosug ,
                    P_OBJETO        => 'PEDIDOSUGERIDO',
                    P_ORDENMONTO    => NULL,
                    P_USUARIOFLUJO  => P_USUARIO, 
                    P_USUARIO       => P_USUARIO, 
                    P_COMENTARIO    => P_COMENTARIO,
                    P_MODULO        => 'VTAS', 
                    P_COMPANIA      => P_COMPANIA,
                    P_EXITO         => v_exito ,
                    P_TERMINOFLUJO  => v_terminaflujo
            );
            
        if v_exito = 0 then
                raise_application_error(-20104, data.pk_corp_flujoaprobacion.G_MENSAJE);
        end if;
            
        if v_exito = 1 and v_terminaflujo = 1 then
            update( select 
            ped.periodos  as periodos_desp, 
            ped.dias_inventario as dias_inv_desp,
            clipro.ps_periodos as periodos_antes,
            clipro.ps_dias_inventario as dias_inv_antes
            from t_vtas_cliente_producto clipro
                inner join t_vtas_pedido_conf_sugerido ped
                on (clipro.codigogrupo = ped.codigogrupo and clipro.codigocliente = ped.codigocliente and clipro.codigoproducto = ped.codigoproducto)
            where ped.idpedidosug = p_idpedidosug) set periodos_antes = periodos_desp, dias_inv_antes = dias_inv_desp;
            
            update t_vtas_pedidosugerido_cambio set estado = 1
            where idpedidosug = p_idpedidosug;
            
        end if;
    end sp_aprobar_pedidosug;
    
    procedure sp_rechazar_pedidosug
    (
        p_idpedidosug in number,
        p_compania in varchar2,
        p_usuario in varchar2,
        p_comentario in varchar2
    )
    is
    v_exito number;
    begin
        DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJORECHAZAR(
                    P_ID  => p_idpedidosug,
                    P_OBJETO => 'PEDIDOSUGERIDO',
                    P_USUARIOFLUJO => P_USUARIO,
                    P_USUARIO => P_USUARIO,
                    P_COMENTARIO => P_COMENTARIO, 
                    P_MODULO => 'VTAS', 
                    P_COMPANIA => P_COMPANIA,
                    P_EXITO => v_exito
                );
            
            if v_exito = 0 then
                raise_application_error(-20101, data.pk_corp_flujoaprobacion.G_MENSAJE);
            end if;
            
            if v_exito = 1 then
                update t_vtas_pedidosugerido_cambio set estado = 0
                    where idpedidosug = p_idpedidosug;
            end if;
    end sp_rechazar_pedidosug;
    
    
    /*
    =========================================
    f_fecha_inventario
    =========================================
    Retorna la fecha mÃ¡xima de inventario
    */
    function f_fecha_inventario(p_codigocliente in varchar2 DEFAULT NULL, P_CODIGOGRUPO in varchar2 DEFAULT NULL) 
    return date
    is
        v_fecha date;
    begin
        select max(fecha) into v_fecha
        from t_vtas_inventario
        where codigocliente = NVL(p_codigocliente, codigocliente) AND CODIGOGRUPO=NVL(P_CODIGOGRUPO, CODIGOGRUPO);
        
        return v_fecha;
    end f_fecha_inventario;
    
    /*
    =========================================
    f_inventario
    =========================================
    Retorna la cantidad de inventario de ese cliente con ese producto,
    de la ultima fecha
    */
    function f_inventario(p_codigocliente in varchar2, p_codigobarra in varchar2, p_fecha date default null ) 
    return number
    is
        v_inventario number;
        v_fecha date;
    begin
        v_fecha:=p_fecha;
        if(p_fecha is null) then 
             v_fecha:= f_fecha_inventario(p_codigocliente=>p_codigocliente);
        end if;
        
        select sum(inv.cantidad) into v_inventario
        from t_vtas_inventario inv
        where inv.CODIGOCLIENTE = p_codigocliente and inv.CODIGOBARRA = p_codigobarra
            and inv.fecha = v_fecha;
        
        return v_inventario;
    end;
    
    function f_pedido_transito(p_codigocliente in varchar2, p_codigoproducto in varchar2) 
    return number
    is
        v_valor number;
    begin
        SELECT nvl(SUM(SDUORG/10000),0) into v_valor
            FROM F4211@JDEDTADL WHERE  SDAN8 = p_codigocliente
            AND SDNXTR NOT IN (999) and SDLTTR not in (520)
            AND SDDCTO ='VN'  AND rpad(trim(p_codigoproducto), 25,' ') = SDLITM
            GROUP BY SDLITM;
            
        return v_valor;
    end f_pedido_transito;
    
    /*
    =================================================
    sp_simular_pedidosugerido
    =================================================
    procedimiento que inserta en la tabla t_tmp_b una simulaciÃ³n de pedido
    @param p_bandera char
        1 Es el submit que se hace al inicio, cuando se elige al cliente
        2 Es el submit que se hace cuando se edita los datos de la tabla temporal
    @param p_codigoproducto varchar2 default null
        Se debe enviar el cÃ³digo del producto cuando se lo usa en la homologaciÃ³n 
        en la lectura del pedido
        pk_vtas_pedidos.sp_simular_pedidosugerido(p_codigogrupo=>'')
    */
    procedure sp_simular_pedidosugerido(p_codigogrupo in varchar2, p_codigocliente in varchar2 default null, 
    p_IDPEDIDO NUMBER default null, p_tipo in number default 1)
    is
    v_periodos apex_t_number;
    v_tipounidad number; --1 Unidad/Paquete 2 Bulto/Caja
    v_total_mes number; --Variable para tomar el total por periodo
    v_suma_meses number; --Variable para acumular el total de los periodos
    v_meses_cont number := 0; --Variable para contar el num de meses que si cuentan
    v_contador number := 0;
    v_fechainicio date;
    v_fecha_fin date;
    v_fecha_inventario date;
    
    BEGIN
      
        dbms_output.put_line(TO_CHAR(SYSTIMESTAMP, 'HH24:MI:SS')||'Inicia ');
        
       -- v_tipounidad := CASE WHEN p_codigogrupo='5100' THEN 2 ELSE 1 END ; 
        v_tipounidad :=1;
        --PK_VTAS_PEDIDOS_COMMONS.F_UNIDAD_PRESENTACION(p_codigogrupo);        
        v_fecha_inventario:= pk_vtas_pedidos.f_fecha_inventario(P_CODIGOGRUPO=>p_codigogrupo);
        
        if p_tipo = 1 then
            
            dbms_output.put_line(TO_CHAR(SYSTIMESTAMP, 'HH24:MI:SS')||'Trae valores de confiuracion ');
            DELETE T_VTAS_PEDIDOSUGERIDO WHERE CODIGOGRUPO=p_codigogrupo;
            
            IF(P_IDPEDIDO IS NULL) THEN 
                INSERT INTO T_VTAS_PEDIDOSUGERIDO (
                codigogrupo,    codigocliente, CODIGOproducto,    codigobarra,  CODIGOPRODUCTOCLIENTE,
                presentacion,   conf_periodos,    conf_dias_inventario)
                select CODIGOGRUPO, CODIGOCLIENTE, max(CODIGOPRODUCTO), CODIGOEAN, max(CODIGOPRODUCTOCLIENTE),
                -- CASE WHEN v_tipounidad = 2 THEN max(PRESENTACION) else 1 end,
                pk_vtas_pedidos.f_cantidadpresentacion(p_codigoproducto => max(CODIGOPRODUCTO))  ,
                max(PS_PERIODOS), max(PS_DIAS_INVENTARIO)
                from t_vtas_cliente_producto C where  codigogrupo = p_codigogrupo AND CODIGOCLIENTE=NVL(p_codigocliente, CODIGOCLIENTE)
                AND estado = 1 AND codigoean IS NOT NULL
                group by CODIGOGRUPO, CODIGOCLIENTE,CODIGOEAN;
            ELSE 
            
                INSERT INTO T_VTAS_PEDIDOSUGERIDO (
                codigogrupo,    codigocliente, CODIGOproducto,    codigobarra,  CODIGOPRODUCTOCLIENTE,
                presentacion,   conf_periodos,    conf_dias_inventario)
                select C.CODIGOGRUPO, C.CODIGOCLIENTE, C.CODIGOPRODUCTO, C.CODIGOEAN, C.CODIGOPRODUCTOCLIENTE,
                 pk_vtas_pedidos.f_cantidadpresentacion(p_codigoproducto => max(C.CODIGOPRODUCTO))  PRESENTACION
                --CASE WHEN v_tipounidad = 2 THEN C.PRESENTACION else 1 end 
                ,C.PS_PERIODOS, C.PS_DIAS_INVENTARIO
                from t_vtas_cliente_producto C 
                INNER JOIN T_VTAS_PEDIDOS P  ON (IDPEDIDO=p_IDPEDIDO AND P.CODIGOPRODUCTO=C.CODIGOPRODUCTO  ) 
                where  C.codigogrupo = p_codigogrupo AND C.CODIGOCLIENTE=NVL(p_codigocliente, C.CODIGOCLIENTE)
                AND C.estado = 1 AND C.codigoean IS NOT NULL
                ORDER BY C.CODIGOCLIENTE,C.CODIGOPRODUCTO;
                
            END IF;
            
        end if;
        
       
        dbms_output.put_line(TO_CHAR(SYSTIMESTAMP, 'HH24:MI:SS')||'busca venta de # registro: ' || v_contador);
         
        --Recorro cada uno de los productos del cliente  
        for produ in (select  codigogrupo, codigocliente,  codigoproducto,  codigoBarra,PRESENTACION,
                            conf_periodos  ps_periodos, conf_dias_inventario  ps_num_diasinv
                            from T_VTAS_PEDIDOSUGERIDO WHERE CODIGOGRUPO=p_codigogrupo) loop
                            
            v_suma_meses := 0;
            v_meses_cont := 0;
            v_periodos := apex_string.split_numbers(produ.ps_periodos, ':');
            
            --Recorro los periodos de ese producto
            for i in 1 .. v_periodos.count loop
            
                v_fechainicio :=trunc(ADD_MONTHS(sysdate, -1 * v_periodos(i)),'MM');
                v_fecha_fin := LAST_DAY(ADD_MONTHS(sysdate, -1 * v_periodos(i)));
                
                --busca la venta del cliente y producto
                select nvl(sum(VALORUNIDAD),0) into v_total_mes 
                from MVT_trad_sellout   where COMPANIA='00001' AND  codigocliente = produ.codigocliente
                and CODIGOBARRA = produ.codigoBarra and fecha  between v_fechainicio and v_fecha_fin;
                
                v_suma_meses := round(v_suma_meses + v_total_mes,2);
                
                if v_total_mes > 0 then
                    v_meses_cont := v_meses_cont + 1;
                end if;
                
            end loop;                
                
                ---actualiza la venta y el promedio de las ventas
                v_suma_meses:= CASE WHEN v_tipounidad = 2 THEN v_suma_meses/produ.PRESENTACION ELSE v_suma_meses END;
                UPDATE T_VTAS_PEDIDOSUGERIDO SET PERIODOS=v_meses_cont, VENTA=v_suma_meses, 
                PROMEDIO=ROUND(v_suma_meses/(CASE WHEN v_meses_cont=0 THEN 1 ELSE v_meses_cont END),2)
                WHERE codigocliente = produ.codigocliente AND CODIGOBARRA = produ.codigoBarra;
         
        end loop;
        
        dbms_output.put_line(TO_CHAR(SYSTIMESTAMP, 'HH24:MI:SS')||'busca informacion del producto: ');
        --Sacar inventario 
        UPDATE T_VTAS_PEDIDOSUGERIDO SET INVENTARIO=nvl(pk_vtas_pedidos.f_inventario(
        p_codigocliente => codigocliente, p_codigobarra => codigobarra, p_fecha=> v_fecha_inventario),0)
        WHERE CODIGOGRUPO=p_codigogrupo;
        
         UPDATE T_VTAS_PEDIDOSUGERIDO SET 
         DIASSTOCK= round(case when PROMEDIO <> 0 then (INVENTARIO/PROMEDIO) * 30 else (INVENTARIO / 0.01) * 30 end, 2)
         WHERE CODIGOGRUPO=p_codigogrupo;
       
         UPDATE T_VTAS_PEDIDOSUGERIDO SET 
         CANTIDADSUGERIDA= ROUND(case when  DIASSTOCK>conf_dias_inventario then 0 else round((PROMEDIO/30) * (conf_dias_inventario - DIASSTOCK), 0) end),
         TRANSITO=nvl(f_pedido_transito(p_codigocliente => codigocliente, p_codigoproducto => codigoproducto),0),
         PRECIO=round(PK_JDE_VENTAS.F_PRECIOXPRODUCTO(codigocliente, codigoproducto, NULL, '00001') , 2),
         DESCUENTO=(PK_JDE_VENTAS.F_DESCUENTOXPRODUCTO(CODIGOCLIENTE, CODIGOPRODUCTO, NULL, '00001')*-1)
         WHERE CODIGOGRUPO=p_codigogrupo;  
        
         UPDATE T_VTAS_PEDIDOSUGERIDO SET CANTIDADSUGERIDA_PEDIR= CANTIDADSUGERIDA
         WHERE CODIGOGRUPO=p_codigogrupo;  
            
        ---ACTUALIZAR PEDIDOS CANTIDADSUGERIDA
        IF(P_IDPEDIDO IS NULL) THEN 
            UPDATE T_VTAS_PEDIDOS P SET CANTIDADSUGERIDA=(SELECT CANTIDADSUGERIDA FROM 
            T_VTAS_PEDIDOSUGERIDO S WHERE S.CODIGOGRUPO=p_codigogrupo 
            AND S.CODIGOCLIENTE=NVL(p_codigocliente, S.CODIGOCLIENTE) AND S.CODIGOPRODUCTO=P.CODIGOPRODUCTO )
            WHERE IDPEDIDO=P_IDPEDIDO AND EXISTS (
            SELECT 1 FROM T_VTAS_PEDIDOSUGERIDO S WHERE S.CODIGOGRUPO=p_codigogrupo 
            AND S.CODIGOCLIENTE=NVL(p_codigocliente, S.CODIGOCLIENTE) AND S.CODIGOPRODUCTO=P.CODIGOPRODUCTO);
            
        END IF;
        
    end sp_simular_pedidosugerido;
    
    /*Genera alcance de un pedido y orden de venta */
    procedure sp_guarda_alcance(p_idpedido number, p_fecha date, p_usuario in varchar2,
    p_cliente in varchar default null ,p_compania in varchar2)
    is
        v_idpedido number;
        v_contador number;
        v_cantidad number;
        v_linea VARCHAR(250);
        v_pedidos T_VTAS_PEDIDOS_CAB%ROWTYPE;
    begin
        
        IF APEX_APPLICATION.G_F01.COUNT = 0 THEN
            raise_application_error(-20100, 'Debe seleccionar al menos un producto');
        END IF;
        
        ---Valida cantidad que no sea mayor 
        for i in (select rownum numero, FALTANTE, CODIGOPRODUCTO from 
                        (select FALTANTE, a.CODIGOPRODUCTO FROM VT_VTAS_IMCUMPLIMIENTO_ALCANC A
                            INNER JOIN VT_GZM_PRODUCTO P  ON (A.codigoproducto=P.codigoproducto)
                            WHERE  idpedido = p_idpedido AND  CODIGOCLIENTE=nvl(p_cliente, CODIGOCLIENTE) AND FALTANTE>0
                            AND PK_JDE_VENTAS.F_STOCKXPRODUCTO(P_CODIGOPRODUCTO =>  a.CODIGOPRODUCTO,P_BODEGA => '17003')>0
                            order by a.CODIGOPRODUCTO)  ) loop
                    
                v_cantidad :=  APEX_APPLICATION.G_F02(i.numero);     

                if(v_cantidad>i.FALTANTE) then 
                --if(i.numero=2) then
                     raise_application_error(-20100, 'Cantidad a enviar: '||v_cantidad ||
                     ' no puede ser mayor al fantante: '||i.FALTANTE||' en el producto:'||i.CODIGOPRODUCTO);
                end if;

        end loop;
               
         SELECT * INTO v_pedidos FROM T_VTAS_PEDIDOS_CAB WHERE idpedido = p_idpedido; 
         SELECT count(1) INTO v_contador FROM T_VTAS_PEDIDOS_CAB WHERE (idpedido = p_idpedido or IDPADRE=p_idpedido) and estado=1;

        --Secuencia de Cabecera
        v_idpedido := data.PK_COMMONS.F_SECUENCIA ('T_VTAS_PEDIDOS_CAB');
        
        --Inserto cabecera
            insert into T_VTAS_PEDIDOS_CAB (
            IDPEDIDO,IDPADRE,TIPO,CODIGOCLIENTE,CODIGOGRUPO,AUDITORIAFECHA,
            AUDITORIAUSUARIO,COMPANIA,ESTADO,OBSERVACION, 
            ORDENCOMPRA, INFORMACIONADICIONAL,  FECHAENTREGA)
            values (v_idpedido, p_idpedido,4, v_pedidos.CODIGOCLIENTE,v_pedidos.CODIGOGRUPO, sysdate,
            p_usuario, p_compania, 1, v_pedidos.OBSERVACION,  
            v_pedidos.ORDENCOMPRA||'_'||v_contador, v_pedidos.INFORMACIONADICIONAL,  p_fecha);

        --Inserto detalle        
        for i in (select rownum numero, FALTANTE, CODIGOPRODUCTO from  
                        (select  FALTANTE, a.CODIGOPRODUCTO FROM VT_VTAS_IMCUMPLIMIENTO_ALCANC A
                        INNER JOIN VT_GZM_PRODUCTO P  ON (A.codigoproducto=P.codigoproducto)
                        WHERE  idpedido = p_idpedido AND  CODIGOCLIENTE=nvl(p_cliente, CODIGOCLIENTE) AND FALTANTE>0
                        AND PK_JDE_VENTAS.F_STOCKXPRODUCTO(P_CODIGOPRODUCTO =>  a.CODIGOPRODUCTO,P_BODEGA => '17003')>0
                        order by a.CODIGOPRODUCTO)  ) loop
                    
                v_cantidad :=  APEX_APPLICATION.G_F02(i.numero);   
                
                for j in 1 .. APEX_APPLICATION.G_F01.COUNT loop
                    v_linea := APEX_APPLICATION.G_F01(j);
                    
                    if(v_linea=i.CODIGOPRODUCTO) then 
                
                        insert into t_vtas_pedidos (IDPEDIDO,CODIGOCLIENTE, NOMBREPRODUCTO, CODIGOBARRA, 
                        CODIGOPRODUCTO,CODIGOPRODUCTOREFERENCIA,UNIDAD_MEDIDA, CANTIDAD,CANTIDADPRESENTACION,
                        DESCUENTO, PRECIO, ICE, LINEA, ESTADO)
                        SELECT v_idpedido, CODIGOCLIENTE, A.PRODUCTO, CODIGOBARRA,
                        a.CODIGOPRODUCTO, a.CODIGOPRODUCTO, UNIDAD_MEDIDA,v_cantidad, P.PRESENTACION,
                        PK_JDE_VENTAS.F_DESCUENTOXPRODUCTO(CODIGOCLIENTE, a.CODIGOPRODUCTO, NULL, p_compania),
                        round(PK_JDE_VENTAS.F_PRECIOXPRODUCTO(CODIGOCLIENTE, a.CODIGOPRODUCTO, NULL, p_compania) , 2),
                        PK_JDE_VENTAS.F_ICEXPRODUCTO(a.CODIGOPRODUCTO,NULL), i.numero, 1
                        FROM VT_VTAS_IMCUMPLIMIENTO_ALCANC A
                        INNER JOIN VT_GZM_PRODUCTO P  ON (A.codigoproducto=P.codigoproducto)
                        WHERE  idpedido = p_idpedido AND  CODIGOCLIENTE=nvl(p_cliente, CODIGOCLIENTE) and a.CODIGOPRODUCTO=v_linea;
                        
                    end if;
                
                end loop;
                
                

        end loop;
        
        ---envio a cubicaje 
        SP_ENVIAR_CUBICAJE( p_pedido =>v_idpedido , p_compania =>p_compania );
        
    end sp_guarda_alcance;
    
    
    procedure sp_guarda_devolucioncab(  p_codigodevolucion in out number, 
                                        p_codigogrupo in varchar2,
                                        p_codigocliente in varchar2,
                                        p_observacion in varchar2,
                                        p_usuario in varchar2,
                                        p_ordennumero in varchar2 default null,
                                        p_ordentipo in varchar2 default null)
                                        
    is
    v_cliente varchar2(200);
    begin
    
    select nombres into v_cliente
    from vt_gzm_cliente
    where codigogrupo = p_codigogrupo and codigocliente = p_codigocliente;
    
    if p_codigodevolucion is null then
        p_codigodevolucion := data.PK_COMMONS.F_SECUENCIA ('T_VTAS_DEVOLUCION');
        --Inserto
        insert into T_VTAS_DEVOLUCION_CAB        (IDdevolucion, CODIGOGRUPO, CODIGOCLIENTE,     
        CLIENTE, OBSERVACION, AUDITORIAUSUARIO, AUDITORIAFECHA, ESTADO, ORDENNUMERO, ORDENTIPO        ) values 
        (p_codigodevolucion, p_codigogrupo, p_codigocliente,
            v_cliente, p_observacion, p_usuario,sysdate, 0, p_ordennumero, p_ordentipo);
    else
        --Actualizo
        update T_VTAS_DEVOLUCION_CAB
        set CODIGOGRUPO = p_codigogrupo, CODIGOCLIENTE = p_codigocliente,
            CLIENTE = v_cliente, OBSERVACION = p_observacion, 
            ORDENNUMERO = p_ordennumero, ORDENTIPO = p_ordentipo
        where IDdevolucion = p_codigodevolucion;
    end if;
    
    
    end sp_guarda_devolucioncab;
    
    
    procedure sp_guarda_detalledevolucion ( p_linea in out number, p_codigodevolucion in varchar2, p_codigoproducto in varchar2, p_cantidad in number, p_motivo in varchar2, p_tipo in varchar2, p_compania in varchar2)
    is
    v_codigobarra vt_gzm_producto.codigobarra%type;
    v_nombreproducto vt_gzm_producto.nombreproducto%type;
    v_precio T_VTAS_DEVOLUCION.PRECIO%type :=0;
    v_codigocliente T_VTAS_DEVOLUCION_CAB.CODIGOCLIENTE%type;
    V_UNIDAD_MEDIDA VARCHAR(3);
    v_existe number := 0;
    begin
        if(p_tipo in ('C', 'U')) THEN 
    
            --InformaciÃ³n del producto
            select codigobarra, nombreproducto, UNIDADPRINCIPAL into v_codigobarra , v_nombreproducto, V_UNIDAD_MEDIDA
            from vt_gzm_producto where codigoproducto = p_codigoproducto;
            
            --CÃ³digo del cliente
            select codigocliente into v_codigocliente
            from t_vtas_devolucion_CAB where IDdevolucion = p_codigodevolucion;
            --ICE Producto
         /*   select nvl(PK_JDE_VENTAS.F_ICEXPRODUCTO(p_codigoproducto,NULL),0) into v_precio
            from dual;*/
            --Precio + ICE
            select PK_JDE_VENTAS.F_PRECIOXPRODUCTO(v_codigocliente,p_codigoproducto,NULL,p_compania) + v_precio into v_precio
            from dual;
            
             if v_existe = v_precio then --Existe
                raise_application_error(-20100, 'Producto no tiene precio');
            end if;
            
        END IF;
        CASE p_tipo --C CREATED U UPDATED D DELETED
        WHEN 'C' THEN --CREATED
            --Verifico que ese codigo no se repita
            
            select count(1) into v_existe
            from T_VTAS_DEVOLUCION
            where IDdevolucion = p_codigodevolucion and codigoproducto = p_codigoproducto;
            
            if v_existe > 0 then --Existe
                raise_application_error(-20100, 'El producto ya ha sido ingresado');
            end if;
            
            select nvl(max(LINEA), 1)+1 into p_linea from T_VTAS_DEVOLUCION where IDdevolucion =p_codigodevolucion;
            --p_linea := data.PK_COMMONS.F_SECUENCIA ('T_VTAS_DEVOLUCION');
            
            insert into T_VTAS_DEVOLUCION
            (LINEA ,CODIGOEAN,CODIGOPRODUCTO ,PRODUCTO ,UNIDAD_MEDIDA,
                CANTIDAD, PRECIO,MOTIVO, IDdevolucion)
            values (  p_linea, v_codigobarra,p_codigoproducto, v_nombreproducto,V_UNIDAD_MEDIDA,
                        p_cantidad, v_precio, p_motivo, p_codigodevolucion);
                        
        WHEN 'U' THEN --UPDATED
            --Verificio que el cÃ³digo al que se actualiza no sea uno ya ingresado
            select count(1) into v_existe
            from T_VTAS_DEVOLUCION
            where IDdevolucion = p_codigodevolucion
                and codigoproducto = p_codigoproducto
                and linea <> p_linea;
            
            if v_existe > 0 then --Existe
                raise_application_error(-20101, 'El producto ya ha sido ingresado');
            end if;
            
            --Actualizo el registro en devolucion_detalle
            update T_VTAS_DEVOLUCION set 
                CODIGOEAN = v_codigobarra, CODIGOPRODUCTO = p_codigoproducto, PRODUCTO = v_nombreproducto,
                CANTIDAD = p_cantidad,  MOTIVO = p_motivo,UNIDAD_MEDIDA=V_UNIDAD_MEDIDA
                where IDdevolucion = p_codigodevolucion and linea = p_linea;
                
        WHEN 'D' THEN --DELETED
        --Se elimina con el numero lÃ­nea
            delete from T_VTAS_DEVOLUCION where IDdevolucion = p_codigodevolucion and  linea = p_linea;
        END CASE;
    end sp_guarda_detalledevolucion;
    
    
    procedure sp_enviarflujo_devolucion( p_codigodevolucion in number, p_usuario in varchar2, p_compania in varchar2)
    is
    v_exito number;
    v_CANAL VARCHAR(10);
    v_observacion T_VTAS_DEVOLUCION_CAB.observacion%type;
    v_nombrecliente T_VTAS_DEVOLUCION_CAB.cliente%type;
    v_filas number;
    begin
    
    --Cuento los registros en el detalle
    select count(1) into v_filas
    from T_VTAS_DEVOLUCION
    where IDdevolucion = p_codigodevolucion;
    
    if v_filas = 0 then
        raise_application_error(-20100, 'Debe elegir al menos un producto');
    end if;
    
    --Traer el cliente y el motivo
    select D.cliente,  REGEXP_REPLACE( D.observacion, '[[:cntrl:]]', '') observacion, CODIGOCANAL into v_nombrecliente, v_observacion, v_CANAL
        from t_vtas_devolucion_CAB D 
        LEFT JOIN VT_GZM_CLIENTE C ON (D.CODIGOCLIENTE=C.CODIGOCLIENTE)
        where IDdevolucion = p_codigodevolucion;
    
         --EnvÃ­o a Flujo
        data.pk_corp_flujoaprobacion.sp_flujoenviar(
            p_id => p_codigodevolucion,
            p_modulo => 'VTAS',
            p_objeto => 'DEVOLUCION',
            p_objetodescripcion => 'NUEVA DEVOLUCION CLIENTE: ' || v_nombrecliente || ' Motivo: '|| v_observacion,
            p_usuario => P_USUARIO,
            P_CODIGOPAGINA =>'VTASP636',
            p_compania => P_COMPANIA,
            p_tipo1 => 'DEV',
            p_tipo2 => CASE WHEN v_CANAL='C04' THEN 'IND' ELSE 'MT' END,
            p_exito => v_exito);
       
       if v_exito = 0 then
            raise_application_error(-20101, data.pk_corp_flujoaprobacion.G_MENSAJE);
        end if;
        
        --Si resultado es 1, continÃºa el proceso
        --Actualizo el estado a 2: En ruta
        update T_VTAS_DEVOLUCION_CAB set  estado = 2   where IDdevolucion = p_codigodevolucion;
        
    end sp_enviarflujo_devolucion;
    
    
    procedure sp_aprobarflujo_devolucion (p_codigodevolucion in number, p_usuario in varchar2, p_tipo in number,
    p_comentario in varchar2, p_compania in varchar2, p_flujo in number default 1)    is
    v_codigobatch varchar2(20);
    v_contadortablaz number;
    v_exito number := 0;
    v_terminaflujo number:=0;
      V_BODEGA VARCHAR(50) := '       17018';
       V_NUMERO VARCHAR(50);
      V_TIPO VARCHAR(50);
    v_codigocliente T_VTAS_DEVOLUCION_CAB.codigocliente%type;
    vfechag number;
    v_body clob;
    v_xml_respuesta XMLTYPE;
    v_url t_corp_udc.valor%type;
    begin
    
        IF(p_flujo=1) THEN --envia a flujo 
            
            IF(p_tipo=1) THEN ---aprobar
            
                DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJOAPROBAR(
                            P_ID            => p_codigodevolucion ,
                            P_OBJETO        => 'DEVOLUCION',
                            P_ORDENMONTO    => NULL,
                            P_USUARIOFLUJO  => P_USUARIO, 
                            P_USUARIO       => P_USUARIO, 
                            P_COMENTARIO    => P_COMENTARIO,
                            P_MODULO        => 'VTAS', 
                            P_COMPANIA      => P_COMPANIA,
                            P_EXITO         => v_exito ,
                            P_TERMINOFLUJO  => v_terminaflujo
                    );
                
           
            ELSE  --- rechazar
            
                DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJORECHAZAR(
                        P_ID  => p_codigodevolucion,
                        P_OBJETO => 'DEVOLUCION',
                        P_USUARIOFLUJO => P_USUARIO,
                        P_USUARIO => P_USUARIO,
                        P_COMENTARIO => P_COMENTARIO, 
                        P_MODULO => 'VTAS', 
                        P_COMPANIA => P_COMPANIA,
                        P_EXITO => v_exito
                    );
            END IF; 
            
            IF v_exito = 0 then ---Error en el flujo
                    raise_application_error(-20100, data.pk_corp_flujoaprobacion.G_MENSAJE);
            END IF;
            
        END IF;
        
        if  p_tipo=0  then --- rechaza 
        
            update T_VTAS_DEVOLUCION_CAB set  estado = -1
            where IDdevolucion = p_codigodevolucion and estado = 2;
            
        elsif  p_tipo=1 and (v_terminaflujo = 1 OR p_flujo=0) then  ----aprueba y termina el flujo
        
            update T_VTAS_DEVOLUCION_CAB set  estado = 1
            where IDdevolucion = p_codigodevolucion and estado = 2;
            
            select codigocliente into v_codigocliente
            from t_vtas_devolucion_CAB where IDdevolucion = p_codigodevolucion;
            
             --CABECERA
              PK_JDE_VENTAS_WS.SP_CREARORDEN_CAB(P_TIPODOCUMENTO=>'EZ',
                                              P_SHIPTO=>v_codigocliente,
                                              P_SOLDTO=>v_codigocliente,
                                              P_BODEGA => V_BODEGA,
                                              P_COMPANIA=>p_compania,
                                              P_VERSION=>'ERP0180');
            ---DETALLE 
            FOR PRODUCTO IN (SELECT * FROM T_VTAS_DEVOLUCION WHERE  IDdevolucion = p_codigodevolucion) LOOP
                
                PK_JDE_VENTAS_WS.SP_CREARORDEN_DET(P_PRODUCTO=>PRODUCTO.CODIGOPRODUCTO,
                                              P_CANTIDAD=>PRODUCTO.CANTIDAD,  
                                              P_UNIDAD=>PRODUCTO.UNIDAD_MEDIDA,  
                                             -- P_UBICACION=>PRODUCTO.UBICACION,
                                              --P_NUMEROSERIE=>PRODUCTO.ESTADO,
                                              P_BODEGADESTINO=>V_BODEGA);
            END LOOP;
            
            --EJECUTO WS
                PK_JDE_VENTAS_WS.SP_CREARORDEN(P_USUARIO=>p_usuario,
                                            P_NUMERO=>V_NUMERO, 
                                            P_TIPO=>V_TIPO,
                                            P_EXITO=>V_EXITO);
                IF(V_EXITO=0) THEN 
                    RAISE_APPLICATION_ERROR(-20000,'Error al generar orden');
                END IF;
                dbms_output.put_line('resultado:'|| V_NUMERO||V_TIPO );

            update T_VTAS_DEVOLUCION_CAB set  ORDENNUMERO=V_NUMERO, ORDENTIPO=V_TIPO
            where IDdevolucion = p_codigodevolucion ;
            
            --actualiozo motivos devolucion 
            FOR d IN (SELECT * FROM T_VTAS_DEVOLUCION WHERE  IDdevolucion = p_codigodevolucion) LOOP
                UPDATE  F4211@JDEDTADL set SDEUSE=D.MOTIVO, SDNXTR=560
                where SDDOCO=V_NUMERO and SDDCTO=V_TIPO AND SDLITm= rpad(D.CODIGOPRODUCTO, 25,' ') ;
            END LOOP;
            
            pk_vtas_pedidos.sp_correo_devolucion ( p_codigodevolucion => p_codigodevolucion );
       
        end if;
    
    end sp_aprobarflujo_devolucion;
    
    /*Envio de correo de aprobacion de la devolucion */
    procedure sp_correo_devolucion ( p_codigodevolucion in number )
    is
    v_asunto varchar(500):='Devolucion Post-Entrega ';
    v_correo varchar(2500);
    v_total number;
    v_observacion varchar(2500);
     v_body clob;
    v_nombrecliente varchar2(300);
    
    cursor c_productos is select CODIGOEAN, CODIGOPRODUCTO, PRODUCTO, UNIDAD_MEDIDA, CANTIDAD, PRECIO, TOTAL, MOTIVO
                          from vt_vtas_devoluciones 
                          where IDdevolucion = p_codigodevolucion;
                          
 
    begin
      
        select cli.codigocliente || ' - ' || cli.nombres , v_asunto|| ORDENTIPO ||' - '||ORDENNUMERO , observacion
        into v_nombrecliente, v_asunto, v_observacion
        from t_vtas_devolucion_CAB dev, vt_gzm_cliente cli
        where dev.codigogrupo = cli.codigogrupo and dev.codigocliente = cli.codigocliente
        and dev.IDdevolucion = p_codigodevolucion;
        
        v_body := v_body || 
                        '<p>Estimado(s),</p>
                        <p>&nbsp;</p>
                        <p>Se ha generado la devolucion para el cliente:
                        <p>' || v_nombrecliente || '</p>
                        <p>observaciÃ³n: '|| v_observacion||'</p>
                        ';
        
        --Cabecera de tabla de productos nuevos
        v_body := v_body || '<table border=''1'' style=''width:100%; padding:0px; border-spacing:0px;''>
            <tr BGCOLOR=''lightgrey''>
               <th  ALIGN=CENTER><strong>CÃ³digo Producto</strong></th>
               <th  ALIGN=CENTER><strong>EAN 13</strong></th>
               <th  ALIGN=CENTER><strong>DescripciÃ³n</strong></th>
               <th  ALIGN=CENTER><strong>Unidad</strong></th>
               <th  ALIGN=CENTER><strong>Cantidad</strong></th>
               <th  ALIGN=CENTER><strong>Total</strong></th>
               <th  ALIGN=CENTER><strong>Motivo</strong></th>
            </tr>';
            
        --Tabla de productos
        for produc in c_productos loop
            v_body := v_body || 
            '<tr> <td ALIGN=LEFT >'	|| produc.CODIGOPRODUCTO ||'</td>
                <td ALIGN=LEFT >' || produc.CODIGOEAN ||'</td>
                <td ALIGN=LEFT >' || produc.PRODUCTO ||'</td>                 
                <td ALIGN=LEFT >' || produc.unidad_medida ||'</td>
                <td ALIGN=LEFT >' || to_char(produc.cantidad) ||'</td>
                <td ALIGN=LEFT > $' || to_char(produc.total) ||'</td>
                <td ALIGN=LEFT >' || produc.motivo ||'</td>
            </tr>';
        end loop;
        
        select sum( TOTAL) into v_total
                          from vt_vtas_devoluciones 
                          where IDdevolucion = p_codigodevolucion;
                          
        v_body := v_body || 
            '<tr> <td ALIGN=LEFT colspan="5" >total</td>
                <td ALIGN=LEFT > $' || to_char(v_total) ||'</td>
                <td ALIGN=LEFT ></td>
            </tr>';
        
        --EnvÃ­o a todos los indicados en la tabla general
           select  max(valor) into v_correo from t_corp_udc
                        where id_cabecera = 'VTAS_PARAM' and ID_TABLA = '6';
                        
          dbms_output.put_line('envio correo :'|| v_correo );                
        PK_CORP_CORREO.SP_ENVIO(
                        P_MODULO => 'VTAS',
                        P_TO => v_correo,
                        P_FROM => 'notificacion@zaimella.com',
                        P_SUBJECT => v_asunto,
                        P_BODY => v_body);
                        
    end sp_correo_devolucion;
    
    
    procedure sp_inserta_reportepedidos (p_canal in varchar2, p_codigogrupo in varchar2, p_codigocliente in varchar2 default null, p_fechainicio in date, p_fechafin in date)
    is
    v_fechainicio number;
    v_fechafin number;
    begin
    
    select TO_CHAR(p_fechainicio, 'YYYYDDD')-1900000 INTO v_fechainicio from dual;
    select TO_CHAR(p_fechafin, 'YYYYDDD')-1900000 INTO v_fechafin from dual;
    
    INSERT INTO T_TMP_B (TXT01, TXT02, TXT03, TXT04, TXT05,
                TXT06, TXT07, TXT08, TXT09,
                NUM01, NUM02, NUM03, DTE01, 
                DTE02, TXT10, TXT11)
    SELECT  CODIGOCANAL AS CODIGOCANAL, SLPA8 AS CODIGOGRUPO, ABAN8 AS CODIGOCLIENTE, SLDSC1 DESCRIPCION , SLLITM CODIGOJDE, 
            SLAITM EAN, SLDOCO PEDIDOJDE, ORDEN_COMPRA, (CASE WHEN SLDOC = 0 THEN 'SIN FACTURA' ELSE TO_CHAR(SLDOC) END)  FACTURA, 
            (SLSOQS/10000) CANTIDAD, (SLPQOR/10000) CANTIDADPQUN, (ROUND(SLAEXP/100,0)) TOTAL,  
            (CASE WHEN SHURDT = 0 THEN NULL ELSE TO_DATE(SHURDT + 1900000,'yyyyddd') END) FECHAENTREGA, 
    TO_date(SLTRDJ + 1900000,'yyyyddd') FECHAORDEN, SHURRF HORAENTREGA, ESTADO
     FROM (
            SELECT DISTINCT CODIGOCANAL, SLPA8, ABAN8, SLDSC1, SLLITM, SLAITM, SLDOCO, SHVR01 ORDEN_COMPRA,
                            SLSOQS, SLPQOR, SLDOC, SLAEXP, SHURDT, SLTRDJ,SHURRF,
            (SELECT DRDL01 FROM VT_JDE_UDC
                WHERE TRIM(DRKY) = TRIM(SLLTTR) AND TRIM(DRRT)= 'AT'  AND TRIM(DRSY) = '40') ESTADO
            FROM F42199@JDEDTADL, F0101@JDEDTADL, F4201@JDEDTADL, VT_GZM_CLIENTE
                WHERE  SLDCTO = 'VN'
                AND SLNXTR  in ('540')
                AND SLLTTR  in ('520')
                AND SLDOCO NOT IN (SELECT SHDOCO FROM F4201@JDEDTADL WHERE  SHDEL1 = 'CANCELADO')
                AND ABAN8 = SLAN8
                AND ABAC03 = 'NAC'
                AND SLPA8 = CODIGOGRUPO
                AND ABAN8 = CODIGOCLIENTE
                AND (p_codigogrupo IS NULL OR SLPA8 = p_codigogrupo)
                AND (P_CODIGOCLIENTE IS NULL OR ABAN8 = P_CODIGOCLIENTE)
                AND SHDOCO = SLDOCO
                AND (CODIGOCANAL = P_CANAL OR P_CANAL IS NULL)
                AND SLTRDJ BETWEEN v_fechainicio AND v_fechafin
                AND SLUSER <> 'CGUALOTUNA'
            union
            SELECT DISTINCT CODIGOCANAL, SLPA8, ABAN8, SLDSC1, SLLITM, SLAITM, SLDOCO , SHVR01 ORDEN_COMPRA,
            SLSOQS, SLPQOR,SLDOC,SLAEXP,SHURDT, SLTRDJ,SHURRF,
            (SELECT DRDL01 FROM VT_JDE_UDCJDE
                WHERE TRIM(DRKY) = TRIM(SLLTTR) AND TRIM(DRRT)= 'AT'  AND TRIM(DRSY) = '40') ESTADO
            FROM F42199@JDEDTADL, F0101@JDEDTADL, F42019@JDEDTADL, VT_GZM_CLIENTE
                WHERE  SLDCTO = 'VN'
            AND SLNXTR  in ('540')
            AND SLLTTR  in ('520')
            AND SLDOCO NOT IN (SELECT SHDOCO FROM F4201@JDEDTADL WHERE  SHDEL1 = 'CANCELADO')
            AND ABAN8 = SLAN8
            AND ABAC03 = 'NAC'
            AND SLPA8 = CODIGOGRUPO
            AND ABAN8 = CODIGOCLIENTE
            AND (p_codigogrupo IS NULL OR SLPA8 = p_codigogrupo)
            AND (P_CODIGOCLIENTE IS NULL OR ABAN8 = P_CODIGOCLIENTE)
            AND SHDOCO = SLDOCO
            AND (CODIGOCANAL = P_CANAL OR P_CANAL IS NULL)
            AND SLTRDJ BETWEEN v_fechainicio AND v_fechafin
            AND SLUSER <> 'CGUALOTUNA'
    );
    end sp_inserta_reportepedidos;
    
    function f_obteneridentificacion (p_codigogrupo in varchar2, p_codigocliente in varchar2 default null, p_compania in varchar2)
    return varchar2
    is
    v_identificacion vt_gzm_cliente.ruc%type;
    begin
        if p_codigocliente is not null then
            select RUC into v_identificacion
            from vt_gzm_cliente 
            where codigogrupo = p_codigogrupo and codigocliente = p_codigocliente;
            
            return v_identificacion;
        end if;
        
        select RUC into v_identificacion
            from vt_gzm_cliente 
            where codigogrupo = p_codigogrupo and codigocliente = p_codigogrupo;
        
        return v_identificacion;
        
    end f_obteneridentificacion;
    
    
    procedure sp_inserta_pedidosmenstrim(   p_canal in varchar2, 
                                            p_codigogrupo in varchar2 default null, 
                                            p_codigocliente in varchar2 default null, 
                                            p_fechainicio in date default null, 
                                            p_fechafin in date default null,
                                            p_trimestre in number default null)
    is
    v_fechainicio number;
    v_fechafin number;
    begin
        --Elimino todo de la tabla temporal
        delete from t_tmp_b;
        
        if p_trimestre is not null then --BUSCO LAS FECHAS DE INICIO Y FIN DE ESE TRIMESTRE
            null;
        else  
            select TO_CHAR(p_fechainicio, 'YYYYDDD')-1900000 INTO v_fechainicio from dual;
            select TO_CHAR(p_fechafin, 'YYYYDDD')-1900000 INTO v_fechafin from dual; 
        end if;
        /*TXT01 = CODIGOCANAL,
        TXT02 = CODIGOGRUPO,
        TXT03 = CODIGOCLIENTE,
        NUM01 = CANTIDAD
        NUM02 = CANTIDADUNIDADES
        NUM03 = TOTAL
        DTE01 = FECHAORDEN
        */
        INSERT INTO T_TMP_B (TXT01, TXT02, TXT03,
                        NUM01, NUM02, NUM03, DTE01)
            SELECT  CODIGOCANAL AS CODIGOCANAL, SLPA8 AS CODIGOGRUPO, ABAN8 AS CODIGOCLIENTE, 
                    (SLSOQS/10000) CANTIDAD, (SLPQOR/10000) CANTIDADPQUN, (ROUND(SLAEXP/100,0)) TOTAL, 
                    TO_date(SLTRDJ + 1900000,'yyyyddd') FECHAORDEN
             FROM (
                    SELECT DISTINCT CODIGOCANAL, SLPA8, ABAN8,
                                    SLSOQS, SLPQOR, SLAEXP, SLTRDJ
                    FROM F42199@JDEDTADL, F0101@JDEDTADL, F4201@JDEDTADL, VT_GZM_CLIENTE
                        WHERE  SLDCTO = 'VN'
                        AND SLNXTR  in ('540')
                        AND SLLTTR  in ('520')
                        AND SLDOCO NOT IN (SELECT SHDOCO FROM F4201@JDEDTADL WHERE  SHDEL1 = 'CANCELADO')
                        AND ABAN8 = SLAN8
                        AND ABAC03 = 'NAC'
                        AND SLPA8 = CODIGOGRUPO
                        AND ABAN8 = CODIGOCLIENTE
                        AND (p_codigogrupo IS NULL OR SLPA8 = p_codigogrupo)
                        AND (P_CODIGOCLIENTE IS NULL OR ABAN8 = P_CODIGOCLIENTE)
                        AND SHDOCO = SLDOCO
                        AND (CODIGOCANAL = P_CANAL OR P_CANAL IS NULL)
                        AND SLTRDJ BETWEEN v_fechainicio AND v_fechafin
                        AND SLUSER <> 'CGUALOTUNA'
                    union
                    SELECT DISTINCT CODIGOCANAL, SLPA8, ABAN8,
                    SLSOQS, SLPQOR, SLAEXP, SLTRDJ
                    FROM F42199@JDEDTADL, F0101@JDEDTADL, F42019@JDEDTADL, VT_GZM_CLIENTE
                        WHERE  SLDCTO = 'VN'
                    AND SLNXTR  in ('540')
                    AND SLLTTR  in ('520')
                    AND SLDOCO NOT IN (SELECT SHDOCO FROM F4201@JDEDTADL WHERE  SHDEL1 = 'CANCELADO')
                    AND ABAN8 = SLAN8
                    AND ABAC03 = 'NAC'
                    AND SLPA8 = CODIGOGRUPO
                    AND ABAN8 = CODIGOCLIENTE
                    AND (p_codigogrupo IS NULL OR SLPA8 = p_codigogrupo)
                    AND (P_CODIGOCLIENTE IS NULL OR ABAN8 = P_CODIGOCLIENTE)
                    AND SHDOCO = SLDOCO
                    AND (CODIGOCANAL = P_CANAL OR P_CANAL IS NULL)
                    AND SLTRDJ BETWEEN v_fechainicio AND v_fechafin
                    AND SLUSER <> 'CGUALOTUNA');
    end;
    

    PROCEDURE SP_ENVIAR_CUBICAJE( p_pedido number, p_compania VARCHAR2 ) as
    v_cliente varchar(100);
    v_USUARIO varchar(100);
    v_orden varchar(100);
    v_correo varchar(500);
    v_clientenombre varchar(300);
    v_texto_correo clob;
    begin 
    
        select p.codigogrupo, p.AUDITORIAUSUARIO,p.ORDENCOMPRA, trim(c.NOMBRES)
        into v_cliente, v_USUARIO, v_orden, v_clientenombre 
        from t_vtas_pedidos_cab p
        inner join vt_gzm_cliente c on (p.codigogrupo=c.codigocliente)
        where idpedido = p_pedido;
        
        PK_RCDP_RECEPCIONYCUBICAJE.SP_CUBICAPEDIDOS(P_BODEGA=>'17003',  
             P_CIA=>p_compania, 
             P_USUARIO=>v_USUARIO, 
             P_CLIENTE =>v_cliente );

        v_texto_correo := '<p>Estimados</p>
                            <strong>Se notifica que se ha ingresado un pedido para ser cubicado.</strong>
                            <p><strong>Cliente: </strong>'||v_clientenombre ||'  </p>
                            <p><strong>Orden de compra: '||v_orden ||'</strong></p>
                            Atentamente:<br>
                            <span><strong>Sistema de Cubicaje</strong></span><br>
                            <span><strong>Zaimella del Ecuador S.A.</strong></span>';
                            
            --EnvÃ­o a todos los indicados en la tabla general
           select  max(valor) into v_correo from t_corp_udc
                        where id_cabecera = 'VTAS_PARAM' and ID_TABLA = '7';
                        
            --un solo correo por ejecutivo lista de productos - clientes
            pk_corp_correo.sp_envio(
                        p_modulo => 'VTAS',
                        p_to => v_correo,
                        p_from => 'notificacion@zaimella.com',
                        p_subject => 'Recepcion y Cubicaje de Pedidos',
                        p_body => v_texto_correo);
    
    end SP_ENVIAR_CUBICAJE;
    
    PROCEDURE SP_CLIENTE_NUEVO( p_codigogrupo in varchar2, p_compania in varchar2 default '00001' ) AS
    v_contador number;
    BEGIN
        select count(1)
          into v_contador
          from t_vtas_cliente_producto
         where CODIGOGRUPO = p_codigogrupo
           and COMPANIA = p_compania;

        IF p_compania = '00003' THEN
            insert into t_vtas_cliente_producto
            (COMPANIA, CODIGOGRUPO, CODIGOCLIENTE, CODIGOPRODUCTO, CODIGOEAN,
             CODIGOPRODUCTOCLIENTE, PS_PERIODOS, PS_DIAS_INVENTARIO, ESTADO, ESTADOCICLO,
             CLASIFICACION, PRECIOMAYORISTA, PRECIOMINORISTA, PRECIOSUGERIDOSINIVA,
             PRECIOSUGERIDOCONIVA, ICE, FECHACODIFICACION, FECHAPRECIO, OBSERVACION,
             PRESENTACION, PRECIOLISTA)
            select p_compania, p_codigogrupo, p_codigogrupo, pro.CODIGOPRODUCTO, pro.CODIGOBARRA,
                   null, '1:2:3', 30, 1, 3,
                   null, null, null, null, null, null,
                   null, null, null, null, 0
              from vt_gzm_producto pro
             where pro.compania = p_compania
               and pro.estado = 1
               and pro.codigoproducto is not null
               and not exists (
                    select 1
                      from t_vtas_cliente_producto b
                     where b.compania = p_compania
                       and b.codigocliente = p_codigogrupo
                       and b.codigoproducto = pro.codigoproducto
               );
        ELSE
            IF(v_contador=0) THEN
                insert into t_vtas_cliente_producto
                (COMPANIA, CODIGOGRUPO, CODIGOCLIENTE,CODIGOPRODUCTO, CODIGOEAN, CODIGOPRODUCTOCLIENTE,
                 PS_PERIODOS, PS_DIAS_INVENTARIO, ESTADO, ESTADOCICLO, CLASIFICACION,
                 PRECIOMAYORISTA, PRECIOMINORISTA, PRECIOSUGERIDOSINIVA, PRECIOSUGERIDOCONIVA,
                 ICE, FECHACODIFICACION, FECHAPRECIO, OBSERVACION, PRESENTACION, PRECIOLISTA)
                select DISTINCT p_compania, p_codigogrupo, p_codigogrupo, CODIGOPRODUCTO, CODIGOEAN, null,
                       '1:2:3', 30, 1, 3, null, null, null, null, null, null,
                       null, null, null, PRESENTACION, 0
                  from t_vtas_cliente_producto
                 WHERE ESTado=1
                   and compania = p_compania;
            else
                insert into t_vtas_cliente_producto
                (COMPANIA, CODIGOGRUPO, CODIGOCLIENTE,CODIGOPRODUCTO, CODIGOEAN, CODIGOPRODUCTOCLIENTE,
                 PS_PERIODOS, PS_DIAS_INVENTARIO, ESTADO, ESTADOCICLO, CLASIFICACION,
                 PRECIOMAYORISTA, PRECIOMINORISTA, PRECIOSUGERIDOSINIVA, PRECIOSUGERIDOCONIVA,
                 ICE, FECHACODIFICACION, FECHAPRECIO, OBSERVACION, PRESENTACION, PRECIOLISTA)
                select DISTINCT p_compania, p_codigogrupo, p_codigogrupo, CODIGOPRODUCTO, CODIGOEAN, null,
                       '1:2:3', 30, 1, 3, null, null, null, null, null, null,
                       null, null, null, PRESENTACION, 0
                  from t_vtas_cliente_producto a
                 WHERE ESTado=1
                   and compania = p_compania
                   and CODIGOGRUPO<>p_codigogrupo
                   and not exists (
                        select 1
                          from t_vtas_cliente_producto b
                         where b.compania = p_compania
                           and b.CODIGOGRUPO=p_codigogrupo
                           and a.CODIGOPRODUCTO=b.CODIGOPRODUCTO
                   );
            END IF;
        END IF;
    END SP_CLIENTE_NUEVO;

end pk_vtas_pedidos;
/
