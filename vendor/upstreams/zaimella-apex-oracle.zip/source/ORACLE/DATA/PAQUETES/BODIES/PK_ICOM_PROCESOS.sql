﻿prompt Esquema DATA para codigo PL/SQL
alter session set current_schema=DATA;

prompt PROD PACKAGE_BODY DATA.PK_ICOM_PROCESOS

  CREATE OR REPLACE PACKAGE BODY PK_ICOM_PROCESOS AS

    V_COMPANIA VARCHAR2(5);

    /*Funcion que retorna 1 si el usuario conectado esta en la cadena de usuarios*/
    FUNCTION F_buscaUsuario ( p_usuario varchar2, p_cadena varchar2 ) return number as
    BEGIN
        if instr(p_cadena, upper(p_usuario)) > 0 then
            return 1 ;
        else
            return 0 ;
        end if;
    END F_buscaUsuario;
    
     /*Funcion que retorna 1 el codigo existe 0 caso contrario*/
    FUNCTION F_buscaCodigoPro ( p_codigo varchar2, p_compania varchar2 ) return number as
    v_cuenta number;
    BEGIN
        select count(1) into v_cuenta 
        from data.vt_gzm_producto 
        where codigoproducto = p_codigo
        and compania = p_compania;
        if nvl(v_cuenta,0) > 0 then
            return 1 ;
        end if;
        return 0 ;
        exception 
            when others then
                return 0 ;
    END F_buscaCodigoPro;
    
     /*Procedimiento que actuliza el codigo borrador de un producto por un codigo existente.*/
    PROCEDURE SP_agregarProducto ( p_idinversion number, p_codigoanterior varchar2, p_codigonuevo varchar2, p_compania varchar2,
        P_PRECIOPROMO NUMBER default null, P_DESCUENTOMANUAL NUMBER default null ) AS
        v_cuenta number;
    BEGIN 
        --verifico que el codigo nuevo no exista en la inversion actual
        select count(1) into v_cuenta
        from data.t_icom_inversion_producto
        where idinversion = p_idinversion
        and codigoproducto = p_codigonuevo
        and nuevo != 1 ;
        
        if nvl(v_cuenta,0) > 0 then
            raise_application_error(-20000,'El codigo del producto '||p_codigonuevo||' ya existe en la inversion' );
        end if;
        --elimino los datos de cantidad del codigo anterior
        delete from data.t_icom_producto_cantidad
        where idinversion = p_idinversion
        and codigoproducto = p_codigoanterior ;
        --actualizo los valores en la tabla de inversion producto
        update data.t_icom_inversion_producto
        set ( codigoproducto, producto, lineanegocio, marca, submarca, codigobarra, codigoproductopadre, nuevo, preciopromo, descuentomanual) =
            ( select codigoproducto, nombreproducto, lineanegocio, marca, submarca, codigobarra, codigoproductopadre, 2,
                case when p_preciopromo is not null then p_preciopromo else preciopromo end ,
                case when p_descuentomanual is not null then p_descuentomanual else descuentomanual end 
                from data.vt_gzm_producto
                where codigoproducto = p_codigonuevo
                and compania = p_compania )
        where idinversion = p_idinversion
        and codigoproducto = p_codigoanterior
        and nuevo = 1 ;
        
        
        --verifico si todos los productos ya tienen codigos validos para actualizar el proceso operativo
        v_cuenta := 0 ;
        select count(1) into v_cuenta
        from data.t_icom_inversion_producto p
        where p.idinversion = p_idinversion
        and nuevo = 1 ;
        --and NOT EXISTS ( select 1 from data.vt_gzm_producto v where codigoproducto = p.codigoproducto and compania = p_compania ) ;
        
        if nvl(v_cuenta,0) = 0 then                    
            --si ya no existe pendientes actuliza el proceso operativo
            update data.t_icom_inversion_proceso
            set porcentaje = 100, fechafin = sysdate
            where idinversion = p_idinversion
            and idproceso = 8 
            and estado = 1  ;
        elsif nvl(v_cuenta,0) > 0 then     
            --si todavÃƒÂ­a tiene pendientes 
            update data.t_icom_inversion_proceso
            set porcentaje = 50, fechafin = sysdate
            where idinversion = p_idinversion
            and idproceso = 8 
            and estado = 1  ;
            
        end if;
        
    END SP_agregarProducto ;
    
      
    /*Procedimeinto para actualizar el proceso diseÃƒÂ±o de arte al crear un caso 
     @P_FECHA es una bandera para saber si se debe actualizar la fecha fin en caso de que sea 1 o nada en caso de que sea 0*/
    PROCEDURE Sp_actualizaPct_DisenoArte ( P_IDINVERSION NUMBER, P_PORCENTAJE NUMBER, P_FECHA NUMBER DEFAULT 0) AS
    BEGIN
        update data.t_icom_inversion_proceso
            set porcentaje = p_porcentaje, fechafin = case when p_fecha = 1 then sysdate else fechafin end
            where idinversion = p_idinversion
            and idproceso = 5 
            and estado = 1  
            and porcentaje < p_porcentaje ;
            
    END Sp_actualizaPct_DisenoArte;
    
    /*Procedimiento para enviar correo del idproceso = 9 cuando se aprueba la inversion*/
    PROCEDURE SP_correoPlanificacion ( P_IDINVERSION NUMBER, P_ESTADO NUMBER, P_USUARIO VARCHAR2 ) AS
        V_OBJETO_CAB CLOB;
        V_URL VARCHAR(2500);
        v_nombre varchar2(250);
        v_cuenta number;
        v_notifica varchar2(500);
    BEGIN
        v_cuenta := 0 ;
        for inv in ( select i.idinversiontipo, i.inversiontipo, i.nombre, i.origen, 
                            i.tipo, i.fechainicio, i.fechafin, i.usuario coordinador, vp.notificacion_imp, 
                            vp.usuariogestion 
                     From data.vt_icom_inversiones i
                        inner join data.t_icom_inversion_proceso p 
                            on ( i.id = p.idinversion and p.estado = 1 and p.idproceso = 9  )
                        inner join data.vt_icom_proceso vp 
                            on ( p.idproceso = vp.idproceso and vp.notificacion_imp is not null  )
                     where (i.id = P_IDINVERSION or i.idgrupo = P_IDINVERSION)  and i.idorigen = 3 ) 
        loop
            v_cuenta := v_cuenta + 1 ;
            if v_cuenta = 1 then 
                --Genero los datos para enviar el correo el inicio
                V_OBJETO_CAB := ' <p></p> <p>&nbsp;</p> <p>Estimado(a) Usuario</p> <p>&nbsp;</p> <p>&nbsp;</p> ';
                V_OBJETO_CAB := V_OBJETO_CAB ||'<table border=''0'' style=''width:100%; padding:0px; border-spacing:0px;''>';
                V_OBJETO_CAB := V_OBJETO_CAB ||'<tr BGCOLOR=''#33FF5E;'' >  ';
                V_OBJETO_CAB := V_OBJETO_CAB ||'<th COLSPAN=4 ALIGN=center width=''100%''><strong>'||Case p_estado when 1 then 'APROBADO' when 0 then 'RECHAZADO' else ' ' end||'</strong></th></tr>';
                V_OBJETO_CAB := V_OBJETO_CAB ||'<tr BGCOLOR=''lightgrey''>  ';
                V_OBJETO_CAB := V_OBJETO_CAB ||'<th  ALIGN=CENTER width=''10%''><strong>ID </strong></th>';
                V_OBJETO_CAB := V_OBJETO_CAB ||'<th  ALIGN=CENTER width=''50%''><strong>DESCRIPCION</strong></th>';
                V_OBJETO_CAB := V_OBJETO_CAB ||'<th  ALIGN=CENTER width=''20%''><strong>FECHA APROBACION</strong></th>';
                V_OBJETO_CAB := V_OBJETO_CAB ||'<th  ALIGN=CENTER width=''20%''><strong>USUARIO</strong></th></tr>';
                V_OBJETO_CAB := V_OBJETO_CAB||'<tr> <td ALIGN=LEFT >'||P_IDINVERSION||'</td>';
                V_OBJETO_CAB := V_OBJETO_CAB ||'<td ALIGN=LEFT >La inversion #'||P_IDINVERSION||', contiene los siguientes datos </td>';
                V_OBJETO_CAB := V_OBJETO_CAB ||'<td ALIGN=CENTER >'	|| to_char(sysdate, 'dd/mm/yyyy')||'</td>' ;
                V_OBJETO_CAB := V_OBJETO_CAB ||'<td ALIGN=CENTER >'	|| P_USUARIO||'</td></tr></table>' ;
                V_OBJETO_CAB := V_OBJETO_CAB ||' <p>&nbsp;</p>';
                V_OBJETO_CAB := V_OBJETO_CAB ||'<table border=''1'' style=''width:100%; padding:0px; border-spacing:0px;''>';
                V_OBJETO_CAB := V_OBJETO_CAB ||'<tr><th  ALIGN=CENTER width=''10%''><strong>TIPO DE INVERSION</strong></th>';
                V_OBJETO_CAB := V_OBJETO_CAB ||'<th  ALIGN=CENTER width=''25%''><strong>NOMBRE</strong></th>';
                V_OBJETO_CAB := V_OBJETO_CAB ||'<th  ALIGN=CENTER width=''10%''><strong>ORIGEN</strong></th>';
                V_OBJETO_CAB := V_OBJETO_CAB ||'<th  ALIGN=CENTER width=''10%''><strong>TIPO</strong></th>';
                V_OBJETO_CAB := V_OBJETO_CAB ||'<th  ALIGN=CENTER width=''15%''><strong>FECHA INICIO</strong></th>';
                V_OBJETO_CAB := V_OBJETO_CAB ||'<th  ALIGN=CENTER width=''15%''><strong>FECHA FIN</strong></th>';
                V_OBJETO_CAB := V_OBJETO_CAB ||'<th  ALIGN=CENTER width=''15%''><strong>COORDINADOR</strong></th></tr>';
                v_notifica := inv.notificacion_imp; 
            end if;
            
            --Pongo los detalles de la inversion --si son hijas puede ser varias
            V_OBJETO_CAB := V_OBJETO_CAB ||'<tr> <td ALIGN=LEFT >'||inv.inversiontipo||'</td>';
			V_OBJETO_CAB := V_OBJETO_CAB ||'<td ALIGN=LEFT >'||inv.nombre||'</td>';
            V_OBJETO_CAB := V_OBJETO_CAB ||'<td ALIGN=LEFT >'||inv.origen||'</td>';
            V_OBJETO_CAB := V_OBJETO_CAB ||'<td ALIGN=LEFT >'||inv.tipo||'</td>';
            V_OBJETO_CAB := V_OBJETO_CAB ||'<td ALIGN=CENTER >'	|| to_char(inv.fechainicio, 'dd/mm/yyyy')||'</td>' ;
            V_OBJETO_CAB := V_OBJETO_CAB ||'<td ALIGN=CENTER >'	|| to_char(inv.fechafin, 'dd/mm/yyyy')||'</td>' ;
            V_OBJETO_CAB := V_OBJETO_CAB ||'<td ALIGN=CENTER >'	|| inv.coordinador||'</td></tr> ' ;
            
        end loop ;    
        
        if v_cuenta  > 0 then
            SELECT DOMINIO || RUTAMODULO||':501::::::' INTO V_URL FROM DATA.T_ADMI_MODULO WHERE CODIGO = 'ICOM';
            
            --Se inserta la despedida
            V_OBJETO_CAB := V_OBJETO_CAB||'</table> 
            <p> Revisar el siguiente link para mas detalle <a href = "'||V_URL||'">Presione aqu&iacute;</a> para ver el reporte de planificacion.</p>
            <p>Gracias por su atenci&oacute;n </p>
                                            <p>Saludos Cordiales </p>
                                            <p>Portal de Inversiones Comerciales </p>';
            --dbms_output.put_line( 'objeto '||V_OBJETO_DES );
            --se envia el correo
            PK_CORP_CORREO.SP_ENVIO(
                    P_MODULO => G_MODULO,
                    P_TO => v_notifica,
                    P_FROM => 'infocomercial@zaimella.com',
                    P_SUBJECT => 'Notificacion Proceso Planificacion de la Produccion  ',
                    P_BODY => V_OBJETO_CAB
                  );    
        end if;
        
    END SP_correoPlanificacion;
    
   
    
    /*Proceso para insertar las referencias cruzadas*/
    PROCEDURE SP_agregarReferencia (P_COMPANIA VARCHAR2, P_FECHADESDE DATE, P_FECHAHASTA DATE, P_PRODUCTO VARCHAR2, 
            P_REFERENCIA VARCHAR2, P_ALCANCE NUMBER, P_CLIENTE VARCHAR2, P_IDINVERSION NUMBER, P_USUARIO VARCHAR2 ) AS
       
        v_codigocortoref number;
        v_nombreproductoref varchar2(400); 
        v_CODIGOBARRA varchar2(400); 
        v_cuenta number ;
        v_cuentaCliente number ;
        v_producto number;
        v_referencia number;
        
    BEGIN
        --Validacion de precios del producto referencia
        v_cuenta := 0 ;
        
        select count(1)
        into v_cuenta
        from (SELECT CODIGOCLIENTE,
                     DATA.PK_GZM_VENTAS.F_PRODCUTOPRECIO ( P_CODIGOCLIENTE => codigocliente,
                                P_CODIGOPRODUCTO => P_PRODUCTO,
                                P_EANPRODUCTO =>  null,
                                P_CIA => P_COMPANIA    ) pro_precio,
                     DATA.PK_GZM_VENTAS.F_PRODCUTOPRECIO ( P_CODIGOCLIENTE => codigocliente,
                                P_CODIGOPRODUCTO => P_REFERENCIA,
                                P_EANPRODUCTO =>  null,
                                P_CIA => P_COMPANIA    ) ref_precio           
                            FROM DATA.VT_GZM_CLIENTE  G WHERE COMPANIA=P_COMPANIA AND ESTADO=1 AND (
                             (P_ALCANCE = 1 AND CODIGOCANAL IN (SELECT Column_Value   FROM TABLE(Apex_String.Split(P_CLIENTE, ':'))))
                                OR (P_ALCANCE = 2 AND CODIGOGRUPO IN (SELECT Column_Value  FROM TABLE(Apex_String.Split(P_CLIENTE, ':'))))
                                OR (P_ALCANCE = 3 AND CODIGOCLIENTE IN (SELECT Column_Value   FROM TABLE(Apex_String.Split(P_CLIENTE, ':'))))) ) cli
        where cli.pro_precio != cli.ref_precio ; 
        
        if nvl(v_cuenta,0) > 0  then
            raise_application_error(-20000,'Error los precios de lista son diferentes para el producto de referencia ' );
        end if;
        
        v_cuenta := 0 ;
        --Validar que no existan fechas vigentes 
        select count(1) into v_cuenta
        from F4104@JDEDTADL   f 
            --left join F554104@JDEDTADL  f2 on (f.IVAN8=f2.IVAN8 
            --    and  f.IVXRT=f2.IVXRT and  f.IVITM=f2.IVITM  and f.IVEXDJ=f2.IVEXDJ and f.IVCITM=f2.IVCITM )
        where trim(f.IVLITM) = P_REFERENCIA
            and f.IVAN8 in (SELECT CODIGOCLIENTE
                            FROM DATA.VT_GZM_CLIENTE  G WHERE COMPANIA=P_COMPANIA AND ESTADO=1 AND (
                             (P_ALCANCE = 1 AND CODIGOCANAL IN (SELECT Column_Value   FROM TABLE(Apex_String.Split(P_CLIENTE, ':'))))
                                OR (P_ALCANCE = 2 AND CODIGOGRUPO IN (SELECT Column_Value  FROM TABLE(Apex_String.Split(P_CLIENTE, ':'))))
                                OR (P_ALCANCE = 3 AND CODIGOCLIENTE IN (SELECT Column_Value   FROM TABLE(Apex_String.Split(P_CLIENTE, ':'))))) ) 
            and ( P_FECHADESDE between TO_DATE(f.IVEFTJ + 1900000,'YYYYDDD') and TO_DATE(f.IVEXDJ + 1900000,'YYYYDDD')
                 or P_FECHAHASTA between TO_DATE(f.IVEFTJ + 1900000,'YYYYDDD') and TO_DATE(f.IVEXDJ + 1900000,'YYYYDDD') )
            --and f2.IVPFN1 is not null   
            ;
        if nvl(v_cuenta,0) > 0 then
            raise_application_error(-20000,'Error existe ya referencias para el producto de referencia seleccionado' );
        end if;
        v_cuenta := 0 ;
        
        --busco los datos de la referencia
        select  nombreproducto 
        into  v_nombreproductoref 
        from data.vt_jde_productos where codigoproducto = P_PRODUCTO;
        
        select codigocorto,  CODIGOBARRA 
        into v_codigocortoref, v_CODIGOBARRA
        from data.vt_jde_productos where codigoproducto = P_REFERENCIA;
        
        for cli in (SELECT CODIGOCANAL, CODIGOCLIENTE
            FROM DATA.VT_GZM_CLIENTE  G WHERE COMPANIA=P_COMPANIA AND ESTADO=1 AND (
                 (P_ALCANCE = 1 AND CODIGOCANAL IN (SELECT Column_Value   FROM TABLE(Apex_String.Split(P_CLIENTE, ':'))))
                    OR (P_ALCANCE = 2 AND CODIGOGRUPO IN (SELECT Column_Value  FROM TABLE(Apex_String.Split(P_CLIENTE, ':'))))
                    OR (P_ALCANCE = 3 AND CODIGOCLIENTE IN (SELECT Column_Value   FROM TABLE(Apex_String.Split(P_CLIENTE, ':'))))) 
            GROUP BY CODIGOCANAL, CODIGOCLIENTE ) 
        loop
            dbms_output.put_line( 'Ingresa ' );
            --Inserto la referencia para todos los clientes seleccionados
            insert into F4104@JDEDTADL ( IVAN8, IVXRT, IVITM, IVEXDJ, IVEFTJ, IVMCU, 
                IVCITM, IVDSC1, IVDSC2, IVALN, 
                IVLITM, IVAITM, IVURCD, IVURDT, IVURAT, IVURAB,IVURRF, IVUSER, 
                IVPID, IVJOBN, IVUPMJ, IVTDAY, IVRATO, IVAPSP, IVIDEM, 
                IVAPSS, IVCIRV, IVADIND, IVBPIND, IVCARDNO)
                values
                ( cli.CODIGOCLIENTE, 'SP', v_codigocortoref, TO_CHAR(p_fechahasta,'YYYYDDD')-1900000, TO_CHAR(p_fechadesde,'YYYYDDD')-1900000,'            ',
                P_PRODUCTO, v_nombreproductoref, P_REFERENCIA, p_producto,
                    P_REFERENCIA, nvl(v_CODIGOBARRA,'  '), '  ', 0, 0,0,  cli.CODIGOCANAL , P_USUARIO,--usuario  
                    'P554104', 'WEBSERVERJ', TO_CHAR(SYSDATE,'YYYYDDD')-1900000, TO_CHAR(SYSDATE,'hh24mi'), 0,0,' ',  
                    'Y', '                    ', 2, 2, '    '
            ) ;
            
            SELECT COUNT(1) INTO v_cuenta FROM F554104@JDEDTADL WHERE 
            IVITM=v_codigocortoref AND IVXRT='SP' AND IVAN8=CLI.CODIGOCLIENTE AND
            trim(IVCITM)=trim(P_PRODUCTO) AND IVEXDJ=TO_CHAR(p_fechahasta,'YYYYDDD')-1900000 ;
             
            IF(v_cuenta=0) THEN 
                dbms_output.put_line( 'inserta ' );
                insert into F554104@JDEDTADL (IVAN8, IVXRT, IVITM, IVEXDJ, 
                IVCITM, IVCIRV, IVPFN1, IVPFN2, IVPFN3, IVPFN4, IVPFN5, IVPFN6)
                VALUES (CLI.CODIGOCLIENTE, 'SP', v_codigocortoref, TO_CHAR(p_fechahasta,'YYYYDDD')-1900000, 
                    P_PRODUCTO, '                    ', p_idinversion, 0, 0, 0, 0, 0 );
            END IF;
            
        end loop;
        
        --Valido si existe un cliente para actualizar el % del proceso
        begin
            --cuento los grupos que existen con referencia
          select count(1) into v_cuenta 
            from data.t_icom_inversion_cliente_g g
                inner join data.vt_icom_referenciacruzada rc on ( g.idinversion = rc.idinversion and g.codigogrupo = rc.codigogrupo) 
            where g.idinversion = p_idinversion 
            and g.negociacion in (3) ;
            
            --cuento todos los grupos de la inversion
            select count(1) into v_cuentaCliente
            from data.t_icom_inversion_cliente_g g
            where g.idinversion = p_idinversion 
            and g.negociacion in (3) ;
            
            if ( nvl(v_cuentaCliente,0) > 0 and  nvl(v_cuenta,0) > 0 ) then
                --tienes clientes en la referencia cruzada actualiza al 50 %
                update data.t_icom_inversion_proceso
                set porcentaje = 50
                where idinversion = p_idinversion
                and idproceso = 10
                and estado = 1 ;
            end if ;
            
            if ( nvl(v_cuentaCliente,0) > 0 and  nvl(v_cuenta,0) > 0 and v_cuentaCliente = v_cuenta ) then
                --todos los clientes tienen referencia cruzada actualiza al 100 %
                update data.t_icom_inversion_proceso
                set porcentaje = 100, fechafin = sysdate 
                where idinversion = p_idinversion
                and idproceso = 10
                and estado = 1 ;
            end if ;
            
        end ;
       
    END SP_agregarReferencia;
    
    /*PROCEDIMIENTO QUE AGRUPA POR NUMERO DE LINEA POR MATERIAL POP
        PK_ICOM_PROCESOS.SP_seleccionarMaterialPop(P_IDINVERSION=>P_IDINVERSION);
    */
     PROCEDURE SP_MaterialPop_Selecionar(P_IDINVERSION NUMBER, P_GRUPO NUMBER  )
     AS 
         V_LINEA NUMBER;
     BEGIN 
        FOR MATERIAL IN (SELECT DISTINCT IDMATERIAL,REQUISICIONLINEA FROM T_ICOM_CLIENTE_MATERIAL WHERE
            idinversion=P_IDINVERSION and REQUISICIONLINEA<=0 AND GRUPO IS NULL  ) LOOP

            UPDATE T_ICOM_CLIENTE_MATERIAL SET REQUISICIONLINEA=ABS(REQUISICIONLINEA), GRUPO=P_GRUPO
           -- , CLASIFICACION=1
            WHERE IDINVERSION=P_IDINVERSION AND REQUISICIONLINEA=MATERIAL.REQUISICIONLINEA
            AND GRUPO IS NULL AND IDMATERIAL=MATERIAL.IDMATERIAL;

            INSERT INTO T_ICOM_CLIENTE_MATERIALCOMPRA(
                IDINVERSION, CODIGOGRUPO, IDMATERIAL, CANTIDAD, COSTO, OBSERVACIONES, REQUISICIONLINEA, GRUPO, 
                ERP_UNIDADNEGOCIO,ERP_SOLICITANTE,ERP_AREA,JUSTIFICACION,AUDITORIAFECHA,AUDITORIAUSUARIO
            )
            SELECT 
                a.IDINVERSION,a.CODIGOGRUPO,a.IDMATERIAL,a.CANTIDAD,a.COSTO,a.OBSERVACIONES,a.REQUISICIONLINEA,a.GRUPO,
                ' 'ERP_UNIDADNEGOCIO,' 'ERP_SOLICITANTE,' 'ERP_AREA,' 'JUSTIFICACION,SYSDATE AUDITORIAFECHA,nvl(v('user'),'ORCL') AUDITORIAUSUARIO
            FROM T_ICOM_CLIENTE_MATERIAL a left join T_ICOM_CLIENTE_MATERIALCOMPRA b on a.IDINVERSION=b.IDINVERSION and a.CODIGOGRUPO=b.CODIGOGRUPO and  a.IDMATERIAL=b.IDMATERIAL and a.GRUPO=b.GRUPO
            WHERE 1=1
            and a.idinversion=P_IDINVERSION 
            AND a.GRUPO =P_GRUPO
            and (b.IDINVERSION is null and b.CODIGOGRUPO is null and b.IDMATERIAL is null and b.GRUPO is null);
        END LOOP;
     
     END SP_MaterialPop_Selecionar;
     
     /*
     Procedimiento que ingresa el resumen de material/servicio
     SP_MaterialPop_Insertar(P_IDINVERSION=>P_IDINVERSION, P_LINEA=>P_LINEA, P_TIPO=>P_TIPO)
     */
     PROCEDURE SP_MaterialPop_Insertar(
             P_IDINVERSION NUMBER
            ,P_CODIGOGRUPO NUMBER
            ,P_IDMATERIAL VARCHAR
            ,P_JUSTIFICACION VARCHAR2
            ,P_GRUPO NUMBER
            ,P_ICA VARCHAR2 DEFAULT NULL
            ,P_DESCRIPCION2 VARCHAR2 DEFAULT NULL
            ,P_INFORMACION VARCHAR2 DEFAULT NULL
            ,P_ACA_MARCA VARCHAR2 DEFAULT NULL
            ,P_ACA_LINEA VARCHAR2 DEFAULT NULL
            ,P_ACA_CLIENTE VARCHAR2 DEFAULT NULL
            ,P_ACA_CANAL VARCHAR2 DEFAULT NULL
            ,P_CANTIDAD NUMBER DEFAULT NULL
            ,P_COSTO NUMBER DEFAULT NULL
            ,P_DISTRIBUCION NUMBER DEFAULT 0
            ,P_FECHA_ACTIVIDAD DATE DEFAULT NULL
            ,P_COMPANIA VARCHAR2 
    ) AS
        V_REQUISICIONLINEA number;
        V_CONTADOR number;
        V_TOTAL number;
         V_MATERIAL VARCHAR(250);
    BEGIN 
        begin
            SELECT MAX(REQUISICIONLINEA)+1 INTO V_REQUISICIONLINEA FROM T_ICOM_CLIENTE_MATERIALCOMPRA
            WHERE IDINVERSION=P_IDINVERSION AND GRUPO=P_GRUPO;
        exception when others then 
            V_REQUISICIONLINEA :=1;
        end;
    
        INSERT INTO T_ICOM_CLIENTE_MATERIALCOMPRA
              (  IDINVERSION,  CODIGOGRUPO,  IDMATERIAL,  REQUISICIONLINEA,ERP_UNIDADNEGOCIO,ERP_SOLICITANTE,ERP_AREA, 
              JUSTIFICACION,  GRUPO,  ICA,  DESCRIPCION2,  INFORMACION,  ACA_MARCA,  ACA_LINEA,  ACA_CLIENTE,  
              ACA_CANAL,  CANTIDAD,  COSTO,  DISTRIBUCION,AUDITORIAFECHA,     AUDITORIAUSUARIO,
              ESTADORUTA, FECHA_ACTIVIDAD,  COMPANIA)
        VALUES(P_IDINVERSION,P_CODIGOGRUPO,P_IDMATERIAL,V_REQUISICIONLINEA,' ',' ',' ',' ',P_GRUPO,P_ICA,P_DESCRIPCION2,
        P_INFORMACION,P_ACA_MARCA,P_ACA_LINEA,P_ACA_CLIENTE,P_ACA_CANAL,P_CANTIDAD,P_COSTO,P_DISTRIBUCION,  
        SYSDATE,nvl(v('user'),'ORCL'),case when P_ACA_MARCA is null then -1 else 0 end, P_FECHA_ACTIVIDAD,P_COMPANIA);

        select TOTAL_PENDIENTE,TOTAL_BORRADOR,MATERIAL INTO  V_CONTADOR ,V_TOTAL,V_MATERIAL
        from VT_ICOM_CLIENTE_MATERIALNEGOCIADO WHERE ID =P_IDINVERSION||'_'||P_CODIGOGRUPO||'_'||P_IDMATERIAL;
        
        if(V_TOTAL>V_CONTADOR)then 
        
           RAISE_APPLICATION_ERROR(-20000,  REPLACE(
           'Error al ingresar, el total ingresado:'|| V_TOTAL
            ||' del material o Servicio: '||V_MATERIAL||' debe ser menor o igual a: '||V_CONTADOR,'/', ' '));

        end if;
  
    END SP_MaterialPop_Insertar;
    
      /*
     Procedimiento que modifica el compra del resumen de material/servicio
     SP_MaterialPop_Modificar(P_IDINVERSION=>P_IDINVERSION, P_LINEA=>P_LINEA, P_TIPO=>P_TIPO)
     */
     PROCEDURE SP_MaterialPop_Modificar(P_IDINVERSION NUMBER, P_LINEA NUMBER, P_GRUPO NUMBER, P_TIPO NUMBER
            ,P_ICA VARCHAR2 DEFAULT NULL, P_DESCRIPCION2 VARCHAR2 DEFAULT NULL, P_INFORMACION VARCHAR2 DEFAULT NULL,
            P_ACA_MARCA VARCHAR2 DEFAULT NULL, P_ACA_LINEA VARCHAR2 DEFAULT NULL, 
            P_ACA_CLIENTE VARCHAR2 DEFAULT NULL, P_ACA_CANAL VARCHAR2 DEFAULT NULL, 
            P_CANTIDAD NUMBER DEFAULT NULL,P_COSTO NUMBER DEFAULT NULL,
            P_FECHA_ACTIVIDAD DATE DEFAULT NULL, P_COMPANIA VARCHAR2 DEFAULT NULL) AS
       V_ID VARCHAR(250);
       V_GRUPO VARCHAR(50);
       V_MATERIAL VARCHAR(250);
       V_CONTADOR NUMBER;
       V_TOTAL NUMBER;
    BEGIN 
        -- ACTUALIZA INFORMACION 
        IF(P_TIPO=1) THEN 
            UPDATE T_ICOM_CLIENTE_MATERIALCOMPRA SET 
            ICA=P_ICA, ACA_MARCA=P_ACA_MARCA,ACA_LINEA=P_ACA_LINEA,ACA_CLIENTE=P_ACA_CLIENTE,ACA_CANAL=P_ACA_CANAL,
            DESCRIPCION2=P_DESCRIPCION2, INFORMACION=P_INFORMACION,
            CANTIDAD=P_CANTIDAD,COSTO=P_COSTO,ESTADORUTA=0,FECHA_ACTIVIDAD=P_FECHA_ACTIVIDAD
            WHERE IDINVERSION=P_IDINVERSION AND GRUPO =P_GRUPO AND REQUISICIONLINEA=P_LINEA;
            
            SELECT MAX(CODIGOGRUPO), MAX(IDMATERIAL)  INTO  V_GRUPO, V_MATERIAL FROM T_ICOM_CLIENTE_MATERIALCOMPRA 
            WHERE IDINVERSION=P_IDINVERSION AND GRUPO =P_GRUPO AND REQUISICIONLINEA=P_LINEA;
            
            V_ID:=P_IDINVERSION||'_'||V_GRUPO||'_'||V_MATERIAL;
            
            select TOTAL_PENDIENTE,TOTAL_BORRADOR,MATERIAL INTO  V_CONTADOR ,V_TOTAL,V_MATERIAL
            from VT_ICOM_CLIENTE_MATERIALNEGOCIADO WHERE ID =V_ID;

            if(V_TOTAL>V_CONTADOR)then 
            
                RAISE_APPLICATION_ERROR(-20000, replace(
               'Error al modificar, el total ingresado:'|| V_TOTAL
                ||' del material o Servicio: '||V_MATERIAL||' debe ser menor o igual a: '||V_CONTADOR ||' ID: '||V_ID,'/', ' '));
            end if;
            
        -- ELIMINAR DEL RESUMEN 
        ELSE
                  
            delete from T_ICOM_CLIENTE_MATERIALCOMPRA 
            WHERE IDINVERSION=P_IDINVERSION 
            AND GRUPO =P_GRUPO AND REQUISICIONLINEA=P_LINEA  ;
        END IF;

    END SP_MaterialPop_Modificar;
    
   /* Indica que el usuario ya no va a comprar el material o servicio pendiente
    PK_ICOM_PROCESOS.SP_MATERIALPOP_CANCELARCOMPRA(P_ID=>1234, P_USUARIO=>'JBALCAZAR');
   */
   PROCEDURE SP_MATERIALPOP_CANCELARCOMPRA(P_ID VARCHAR, P_USUARIO VARCHAR, P_OBSERVACION VARCHAR, P_COMPANIA VARCHAR) AS
   BEGIN
        
         INSERT INTO T_ICOM_CLIENTE_MATERIALCOMPRA(
                IDINVERSION, CODIGOGRUPO, IDMATERIAL,CANTIDAD,COSTO,
                REQUISICIONLINEA,OBSERVACIONES,GRUPO,  
                JUSTIFICACION,AUDITORIAFECHA,AUDITORIAUSUARIO,DISTRIBUCION,ESTADORUTA ,
                ERP_UNIDADNEGOCIO,ERP_SOLICITANTE, ERP_AREA, COMPANIA)
        SELECT m.IDINVERSION,m.CODIGOGRUPO,m.IDMATERIAL,
            cantidad_pendiente,  costo_PENDIENTE,  0 REQUISICIONLINEA,P_OBSERVACION,0 GRUPO ,
            'CANCELACION DE COMPRAS POR USUARIO',SYSDATE AUDITORIAFECHA, P_USUARIO AUDITORIAUSUARIO,DISTRIBUCION,3 ESTADORUTA
            ,' ',' ',' ',P_COMPANIA
        FROM VT_ICOM_CLIENTE_MATERIALNEGOCIADO m 
        WHERE 1=1    and id=P_ID;
   END;
   
    /*Procedimiento para enviar a ruta de aprobacion la compra de material POP
    SP_MaterialPop_Enviar(P_IDINVERSION =>P_IDINVERSION, P_GRUPO =>P_GRUPO, 
    P_USUARIO=>P_USUARIO, P_COMPANIA =>P_COMPANIA)*/
    PROCEDURE SP_MaterialPop_Enviar(P_IDINVERSION NUMBER, P_GRUPO NUMBER, P_USUARIO VARCHAR,
    P_DISTRIBUCION NUMBER DEFAULT 1,P_JUSTIFICACION VARCHAR,P_FECHA_ACTIVIDAD DATE DEFAULT NULL,P_FECHA_ACTIVIDAD_FIN DATE DEFAULT NULL, P_COMPANIA VARCHAR)
    AS
     V_OBJETO VARCHAR(100):='COMPRA_MATERIAL_POP';
     V_OBJETO_DES VARCHAR(2500) :='';    
     V_BODEA VARCHAR(100);
     V_SOLICITANTE VARCHAR(100);
     V_USUARIO VARCHAR(100);
     V_AREA VARCHAR(100);
     V_EXITO NUMBER;
     V_CONTADOR NUMBER;

     V_CANAL VARCHAR2(100);
    BEGIN
        ---BUSCOS DATOS PARA CREAR CABECERA T_ICOM_CLIENTE_MATERIALCOMPRA
        V_USUARIO :=P_USUARIO;

        SELECT a.AREA_ERP, u.coderp
            INTO V_AREA, V_SOLICITANTE
            FROM T_ICOM_INVERSIONES  I
            LEFT JOIN VT_ICOM_AREA A ON (A.IDAREA=I.IDAREA)
            LEFT JOIN VT_CORP_USUARIO U ON (U.NOMBREUSUARIO=V_USUARIO)
            WHERE I.ID =P_IDINVERSION ;

        SELECT COUNT(1) INTO V_CONTADOR  FROM T_ICOM_CLIENTE_MATERIALCOMPRA
            WHERE IDINVERSION=P_IDINVERSION AND GRUPO =P_GRUPO ;

         IF (V_CONTADOR=0) THEN
           RAISE_APPLICATION_ERROR(-20002, 'GRUPO NO TIENE DETALLE PARA EL ENVIO A FLUJO DE APROBACION');
         END IF;

        --- OMAR
        ---tabla general -> ICOM_RTOC  --> VALOR -> AREA -  VALOR2 -> CANAL, VALOR3-> RUTA(V_BODEA)
        ----  V_BODEA busca en una tabla general T_ICOM_CLIENTE_MATERIALCOMPRA  area (I.IDAREA) y canal FILTRAR A  (ACA_CLIENTE-> vt_gzm_cliente -> codcanal)
        --- SI V_BODEA IS NULL BUSCA EN -> VT_ICOM_AREA

        SELECT MAX(r.RUTA)
        INTO  V_BODEA
        FROM DATA.VT_ICOM_RTOC r
        INNER JOIN (SELECT
                    M.ERP_UNIDADNEGOCIO,C.CODIGOCANAL, A.IDAREA, M.IDINVERSION
                    FROM DATA.T_ICOM_CLIENTE_MATERIALCOMPRA M
                    INNER JOIN DATA.VT_GZM_CLIENTE C ON (C.CODIGOCLIENTE = M.ACA_CLIENTE)
                    INNER JOIN DATA.T_ICOM_INVERSIONES I ON (I.ID = M.IDINVERSION)
                    LEFT JOIN VT_ICOM_AREA A ON (A.IDAREA=I.IDAREA)
                    WHERE M.GRUPO = P_GRUPO
                    AND M.IDINVERSION = P_IDINVERSION
                    AND M.COMPANIA = P_COMPANIA AND C.COMPANIA = P_COMPANIA
                    GROUP BY M.ERP_UNIDADNEGOCIO,C.CODIGOCANAL, A.IDAREA, M.IDINVERSION
                    ) CANAL ON (CANAL.CODIGOCANAL = R.CANAL AND CANAL.IDAREA = R.IDAREA)
        WHERE R.COMPANIA = P_COMPANIA
        ;

        IF trim(V_BODEA) is null THEN
             SELECT A.UNIDADNEGOCIO
                INTO V_BODEA
                FROM T_ICOM_INVERSIONES  I
                LEFT JOIN VT_ICOM_AREA A ON (A.IDAREA=I.IDAREA)
                LEFT JOIN VT_CORP_USUARIO U ON (U.NOMBREUSUARIO=V_USUARIO)
                WHERE I.ID =P_IDINVERSION ;
        END IF;
         
          IF trim(V_BODEA) is null THEN  
                RAISE_APPLICATION_ERROR(-20000, 'No existe UNIDAD NEGOCIO para el area de la inversion'); 
          END IF;
          
          IF trim(V_SOLICITANTE) is null THEN  
                RAISE_APPLICATION_ERROR(-20001, 'El usuario: '||V_USUARIO||' no tiene configurado el codigo ERP en Evolution, comunicarse con RRHH'); 
          END IF;
         
         ---VALIDACION ACAS OBIGATORIAS
         SP_MaterialPop_VALIDAR_ACAS(P_IDINVERSION =>P_IDINVERSION, P_GRUPO=>P_GRUPO);
        
         DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJOENVIAR(
            p_id=>P_IDINVERSION||'-'||P_GRUPO,
            p_objeto=>V_OBJETO,
            p_objetodescripcion=> P_JUSTIFICACION,
            p_usuario=>P_USUARIO,
            p_modulo=>G_MODULO,
            p_compania=>P_COMPANIA,
            P_ETAPA => 'PROCESO_COMPRA_MATERIAL_POP',
            P_TIPO1 =>'PROCESO_OPERATIVO',
            --COMPRA_DE_MATERIAL_DE_COMUNICACION
            --P_TIPO2 => 'COMPRA_DE_MATERIAL_DE_COMUNICACION',
            P_TIPO2 => CASE WHEN P_DISTRIBUCION=1 THEN 'COMPRA_DE_MATERIAL_DE_COMUNICACION' ELSE 'PAGO_ESPACIOS_CONTRATADOS' END,
            p_exito=>V_EXITO);
            
        IF(V_EXITO=0) THEN
            RAISE_APPLICATION_ERROR(-20100, DATA.PK_CORP_FLUJOAPROBACION.G_MENSAJE);
        END IF;    
       
        SELECT COUNT(1) INTO V_CONTADOR FROM T_ICOM_CLIENTE_MATERIALCOMPRA 
         WHERE  IDINVERSION=P_IDINVERSION AND GRUPO =P_GRUPO ;
        
         IF (V_CONTADOR)>0 THEN --- MODIFICA
            UPDATE t_icom_cliente_materialcompra SET DISTRIBUCION=P_DISTRIBUCION,
            erp_unidadnegocio=V_BODEA,    erp_solicitante=V_SOLICITANTE,    erp_area=V_AREA,
            justificacion=P_JUSTIFICACION, fecha_actividad=P_FECHA_ACTIVIDAD, fecha_actividad_fin=P_FECHA_ACTIVIDAD_FIN,    auditoriafecha=SYSDATE,    auditoriausuario=P_USUARIO
            WHERE IDINVERSION=P_IDINVERSION AND GRUPO =P_GRUPO;
        ELSE -- CREAR
            INSERT INTO t_icom_cliente_materialcompra (
            idinversion,    grupo,DISTRIBUCION,    erp_unidadnegocio,    erp_solicitante,    erp_area,
            justificacion, fecha_actividad, fecha_actividad_fin,  auditoriafecha,    auditoriausuario) VALUES (
            P_IDINVERSION,P_GRUPO,P_DISTRIBUCION,V_BODEA, V_SOLICITANTE, V_AREA,P_JUSTIFICACION,P_FECHA_ACTIVIDAD,P_FECHA_ACTIVIDAD_FIN,SYSDATE, P_USUARIO);
        END IF;
        
        UPDATE T_ICOM_CLIENTE_MATERIALCOMPRA SET ESTADORUTA=2
            WHERE IDINVERSION=P_IDINVERSION AND GRUPO =P_GRUPO ;
        
        --actualiza el % del proceso operativo enviado a ruta de aprobacion    
        update data.t_icom_inversion_proceso set porcentaje = 10 where idinversion = p_idinversion and idproceso = 6  and estado = 1 ;
            
    END SP_MaterialPop_Enviar;
    
    /*procedimiento para aprobar la compra de material Pop
    P_TIPO bandera que indica si aprueba/rechaza 1/0
    SP_DESCUENTO_APROBAR.SP_MaterialPop_Aprobar
    */
    PROCEDURE SP_MaterialPop_Aprobar(P_IDINVERSION NUMBER, P_GRUPO NUMBER, P_USUARIO VARCHAR, P_JUSTIFICACION VARCHAR DEFAULT NULL,
    P_TIPO NUMBER,  P_COMENTARIO VARCHAR2, P_COMENTARIO_DIRIGIDO VARCHAR2 DEFAULT NULL,P_COMPANIA VARCHAR,
    P_RUTA NUMBER DEFAULT 1) AS
    
     V_OBJETO VARCHAR(100):='COMPRA_MATERIAL_POP';
     V_EXITO NUMBER;
     V_CONTADOR NUMBER;
     v_terminaFlujo NUMBER;       
    BEGIN 
         IF P_TIPO = 1 THEN --APROBADO
          
          SP_MaterialPop_VALIDAR_ACAS(P_IDINVERSION =>P_IDINVERSION, P_GRUPO=>P_GRUPO);
         IF(P_RUTA=1) THEN  
                DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJOAPROBAR(
                    P_ID            => P_IDINVERSION||'-'||P_GRUPO,
                    P_OBJETO        => V_OBJETO, 
                    P_ORDENMONTO    => NULL, 
                    P_USUARIOFLUJO  => P_USUARIO, 
                    P_USUARIO       => P_USUARIO, 
                    P_COMENTARIO    => P_COMENTARIO,
                    P_COMENTARIO_USUARIOS => P_COMENTARIO_DIRIGIDO,
                    P_MODULO        => G_MODULO, 
                    P_COMPANIA      => P_COMPANIA,
                    P_EXITO         => v_exito ,
                    P_TERMINOFLUJO  => v_terminaFlujo
                );
            
            ELSE 
                v_exito :=1;
                v_terminaFlujo:=1;
            END IF; 
            
            IF v_exito = 0 THEN  
                RAISE_APPLICATION_ERROR(-20001, DATA.PK_CORP_FLUJOAPROBACION.G_MENSAJE); 
            END IF;
            
            UPDATE t_icom_cliente_materialcompra 
                SET justificacion=P_JUSTIFICACION 
            WHERE IDINVERSION=P_IDINVERSION AND GRUPO =P_GRUPO;
            
            IF ( v_terminaFlujo = 1 ) THEN
                UPDATE t_icom_cliente_materialcompra 
                SET ESTADORUTA=1,
                    justificacion=P_JUSTIFICACION
                WHERE IDINVERSION=P_IDINVERSION AND GRUPO =P_GRUPO;
                
                  ---GENERA REQUISICION  
                  SP_MaterialPop_Requisicion(P_IDINVERSION =>P_IDINVERSION,
                    P_GRUPO =>P_GRUPO,P_COMPANIA =>P_COMPANIA); 
                   
                  --ACTUALIZA PORCENTAJES  
                  SELECT COUNT(1) INTO V_CONTADOR FROM DATA.VT_ICOM_CLIENTE_MATERIAL_NEGOCIADO 
                  c WHERE IDINVERSION=P_IDINVERSION and (ESTADORUTA IS NULL OR ESTADORUTA=2);
                  
                 update data.t_icom_inversion_proceso
                    set porcentaje =  CASE WHEN V_CONTADOR=0 THEN 50 --- SE APROBO TODO
                                        ELSE 25 END -- EXISTEN MATERIAL POR APROBAR
                    where idinversion = p_idinversion and idproceso = 6;
                
            END IF;
            
        ELSIF P_TIPO = 0 THEN     --RECHAZADO
        
            DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJORECHAZAR(
                    P_ID            => P_IDINVERSION||'-'||P_GRUPO,
                    P_OBJETO        => V_OBJETO, 
                    P_USUARIO       => P_USUARIO, 
                    P_USUARIOFLUJO  => P_USUARIO,
                    P_COMENTARIO    => P_COMENTARIO,
                    P_COMENTARIO_USUARIOS => P_COMENTARIO_DIRIGIDO,
                    P_MODULO        => G_MODULO, 
                    P_COMPANIA      => P_COMPANIA,
                    P_EXITO         => v_exito
            );
            
            IF v_exito = 0 THEN  
                RAISE_APPLICATION_ERROR(-20000, DATA.PK_CORP_FLUJOAPROBACION.G_MENSAJE); 
            END IF;
            
            UPDATE T_ICOM_CLIENTE_MATERIAL  SET ESTADORUTA=NULL, GRUPO=NULL,
                REQUISICIONLINEA=NULL
            WHERE IDINVERSION=P_IDINVERSION AND GRUPO =P_GRUPO;
            
            UPDATE T_ICOM_CLIENTE_MATERIALCOMPRA 
            SET ESTADORUTA=-1,REQUISICIONLINEA=NULL,ICA=NULL,
                DESCRIPCION2=NULL,INFORMACION=NULL,ACA_MARCA=NULL,ACA_LINEA=NULL,ACA_CLIENTE=NULL,ACA_CANAL=NULL
            WHERE IDINVERSION=P_IDINVERSION AND GRUPO =P_GRUPO;
                
        END IF;
        
       
    END SP_MaterialPop_Aprobar;
    
    /*Genere requisicion del material POP en el ERP JDE
    SP_MaterialPop_Requisicion(P_IDINVERSION =>P_IDINVERSION,
    P_GRUPO =>P_GRUPO,P_COMPANIA =>P_COMPANIA);
    */
    PROCEDURE SP_MaterialPop_Requisicion (P_IDINVERSION NUMBER, P_GRUPO NUMBER,P_COMPANIA VARCHAR) 
    as
    V_BODEA VARCHAR(100);
     V_SOLICITANTE VARCHAR(100);
     V_AREA VARCHAR(100);
     V_JUSTIFICACION VARCHAR(2500);
     V_NUMERO VARCHAR(50);
     V_TIPO VARCHAR(50);   
    BEGIN 
        SELECT MAX(erp_unidadnegocio)erp_unidadnegocio,MAX(erp_solicitante)erp_solicitante,MAX(erp_area)erp_area, MAX(JUSTIFICACION)JUSTIFICACION
        INTO  V_BODEA,    V_SOLICITANTE,  V_AREA, V_JUSTIFICACION
        FROM t_icom_cliente_materialcompra
        WHERE IDINVERSION=P_IDINVERSION AND GRUPO =P_GRUPO;     
      
        --- GENERAR REQUISICION para la orden de compra
         dbms_output.put_line( 'V_AREA: '||V_AREA||' V_SOLICITANTE '|| V_SOLICITANTE||' V_BODEA '||V_BODEA  );
        
        pk_jde_compras_ws.sp_crearorden_cab(
            P_COMPANIA      => P_COMPANIA,
            p_version=>'ERP0040',
            P_BODEGA=>V_BODEA,
            p_comprador=>0,
            p_envia=>V_AREA,
            p_proveedor=>V_SOLICITANTE,
            p_fechaprometida=>SYSDATE
        );
        FOR I IN (
            SELECT * 
            FROM VT_ICOM_CLIENTE_MATERIAL_COMPRA
            LEFT JOIN F4101@jdedtadl ON (ICA=TRIM(IMLITM))
            WHERE IDINVERSION=P_IDINVERSION AND GRUPO =P_GRUPO
        ) LOOP
            pk_jde_compras_ws.sp_crearorden_det(
                P_COMPANIA      => P_COMPANIA,
                P_Originator => 'METODO    ', 
                p_codigocorto=>I.IMITM,
                p_cantidad=>I.CANTIDAD,
                p_um=>'UN',
                p_preciounitario=>I.COSTO,
                p_linea=>I.REQUISICIONLINEA
            );
        END LOOP;
        
        pk_jde_compras_ws.sp_crearorden();
        
        V_NUMERO	:= pk_jde_compras_ws.g_numero;
        V_TIPO		:= pk_jde_compras_ws.g_tipo;
        
        dbms_output.put_line( 'Se genero la orden V_TIPO: '||V_TIPO||' V_NUMERO '|| V_NUMERO  );
        ---AGREGAR JUSTIFICACION
        insert into f564310@jdedtadl (iakcoo,iadcto,iadoco,ialnid,ialongmsg)
        VALUES (P_COMPANIA,V_TIPO,V_NUMERO, 0, V_JUSTIFICACION );
        dbms_output.put_line( 'AGREGAR JUSTIFICACION  AGREGAR JUSTIFICACION : '||V_JUSTIFICACION );
        
        UPDATE T_ICOM_CLIENTE_MATERIALCOMPRA  SET REQUISICION=V_NUMERO, REQUISICIONTIPO=V_TIPO
        WHERE IDINVERSION=P_IDINVERSION AND GRUPO =P_GRUPO;
        
        ---actualiza descripcion
        FOR COMPRA IN ( SELECT *  FROM VT_ICOM_CLIENTE_MATERIAL_COMPRA
            WHERE IDINVERSION=P_IDINVERSION AND GRUPO =P_GRUPO) LOOP

            UPDATE f4311@jdedtadl  SET PDDSC1=SUBSTR(COMPRA.MATERIAL,0,30), PDDSC2=NVL(SUBSTR(COMPRA.DESCRIPCION2,0,30), PDDSC2)
            where TO_CHAR(PDDOCO)=COMPRA.REQUISICION AND PDDCTO=COMPRA.REQUISICIONTIPO AND PDLNID=COMPRA.LINEA;

            --- JUSTIFICACION POR LINEA
            IF(TRIM(COMPRA.INFORMACION) IS NOT NULL) THEN
                insert into f564310@jdedtadl (iakcoo,iadcto,iadoco,ialnid,ialongmsg)
                VALUES (P_COMPANIA,COMPRA.REQUISICIONTIPO,COMPRA.REQUISICION,
                COMPRA.LINEA, COMPRA.INFORMACION );
            END IF;

            /*---ACTUALIZAR  
                select * from f1620 where trim(CTABT1) in ('4', 'C', '7', '3')
                4	Marca de Producto ,  C	Cliente,   7	LÃƒÂ­nea de Negocio,   3	Canal Cliente
                PDABT1, PDABR1, PDABT2, PDABR2, PDABT3, PDABR3, PDABT4, PDABR4
                4	    T08    	C	    999    	7    	001    	3	     DIN         */
            UPDATE f4311t@jdedtadl  SET 
                    PDABT1= CASE WHEN COMPRA.ACA_MARCA IS  NULL THEN ' ' ELSE '4' END,
                    PDABR1=NVL(COMPRA.ACA_MARCA,PDABR1 ),
                    PDABT2= CASE WHEN COMPRA.ACA_CLIENTE IS NULL THEN ' ' ELSE 'C' END,
                    PDABR2=NVL(COMPRA.ACA_CLIENTE,PDABR2 ),
                    PDABT3= CASE WHEN COMPRA.ACA_LINEA IS NULL THEN ' ' ELSE '7' END,
                    PDABR3=NVL(COMPRA.ACA_LINEA,PDABR3 ),
                    PDABT4= CASE WHEN COMPRA.ACA_CANAL IS NULL THEN ' ' ELSE '3' END, 
                    PDABR4=NVL(COMPRA.ACA_CANAL,PDABR4 )
            where TO_CHAR(PDDOCO)=COMPRA.REQUISICION AND PDDCTO=COMPRA.REQUISICIONTIPO AND PDLNID=COMPRA.LINEA;
            
            --- INSERTA INVERSIONES
            INSERT INTO F554X11@jdedtadl (ACKCOO, ACDCTO, ACDOCO, ACLNID,
            ACPFN1, ACPFN2, ACPFN3, ACPFN4, ACPFN5, ACPFN6, ACUSER, ACUPMJ) VALUES  
            ('00001', COMPRA.REQUISICIONTIPO, COMPRA.REQUISICION, COMPRA.LINEA, P_IDINVERSION, '0', '0', '0', '0', '0', 'METODO    ', '123299');

        END LOOP;
        --- INGRESAR ADJUNTOS EN LA REQUISICION DESDE VT_ICOM_CLIENTE_MATERIAL_COMPRA A 
        INSERT INTO FILES.T_APEX_ARCHIVOS
            SELECT  PK_COMMONS.F_SECUENCIA ('T_APEX_ARCHIVOS') NUMEROARCHIVO, BLOBCONTENT, FILENAME, MIMETYPE,
                'T_COMP_ORDENES' TABLA,  V_NUMERO ID_TABLA, V_TIPO TIPO,
                OBSERVACION,ESTADO,FECHA,NOMBREUSUARIO,RIDE
            FROM   FILES.T_APEX_ARCHIVOS  WHERE   
            TABLA='VT_ICOM_CLIENTE_MATERIAL_COMPRA' AND ID_TABLA=P_IDINVERSION||'-'||P_GRUPO;

    END SP_MaterialPop_Requisicion;
    
    /*Funcion que crea la justificacion para la requisicion
        PK_ICOM_PROCESOS.F_MaterialPop_JUSTIFICACION(P_IDINVERSION=>P_IDINVERSION, P_GRUPO=>P_GRUPO )
    */
    FUNCTION F_MaterialPop_JUSTIFICACION(P_IDINVERSION NUMBER, P_GRUPO NUMBER) RETURN VARCHAR
   
    AS
    V_JUSTIFICACION VARCHAR(4500);
    V_CLIENTE VARCHAR(4500);
    V_MATERIAL VARCHAR(4500);
    V_MARCA VARCHAR(4500);
    V_FECHA VARCHAR2(3999);
    BEGIN 
         --  ID + CLIENTE +MATERIAL+ MARCA + MES + AÃƒâ€˜O
         --INVERSION 
         SELECT ID||' $CLIENTE$ $MATERIAL$ $MARCA$ $FECHA$'
         INTO V_JUSTIFICACION
         FROM T_ICOM_INVERSIONES WHERE ID=P_IDINVERSION;
  
         
        SELECT REPLACE(TO_CHAR(MIN(FECHAINICIO),'MONTH/YYYY'),' ','') ||' - '||REPLACE(TO_CHAR(MAX(FECHAFIN),'MONTH/YYYY') ,' ','')
        INTO V_FECHA
        FROM T_ICOM_CLIENTE_MATERIAL        M 
        INNER JOIN    VT_ICOM_CLIENTE_MATERIAL_COMPRA C ON M.IDINVERSION=C.IDINVERSION AND M.CODIGOGRUPO=C.CODIGOGRUPO AND M.IDMATERIAL=C.IDMATERIAL 
        WHERE C.IDINVERSION=P_IDINVERSION AND  C.GRUPO=P_GRUPO;

         --MATERIAL 
         SELECT LISTAGG(MATERIAL, ', ')  WITHIN GROUP (ORDER BY MATERIAL) MATERIAL INTO V_MATERIAL
         FROM (SELECT MATERIAL FROM VT_ICOM_CLIENTE_MATERIAL_COMPRA M
         WHERE M.IDINVERSION=P_IDINVERSION AND  M.GRUPO=P_GRUPO  GROUP BY MATERIAL);
        
         -- CLIENTES
          SELECT  LISTAGG(CATEGORIA, ',')  
                    WITHIN GROUP (ORDER BY CATEGORIA)CATEGORIA INTO  V_CLIENTE
                    FROM (SELECT CATEGORIA FROM VT_ICOM_CLIENTE_MATERIAL_COMPRA M
                    INNER JOIN T_ICOM_INVERSION_CLIENTE_G G ON (M.IDINVERSION=G.IDINVERSION AND M.CODIGOGRUPO=G.CODIGOGRUPO)
                    WHERE M.IDINVERSION=P_IDINVERSION AND  M.GRUPO=P_GRUPO GROUP BY CATEGORIA);
         
        ---ACA_MARCA
         SELECT  LISTAGG(MARCA, ',')  
                    WITHIN GROUP (ORDER BY MARCA) MARCA INTO  V_MARCA
                    FROM ( SELECT MARCA FROM (SELECT CODIGOMARCA , MARCA  FROM VT_ICOM_INVERSION_MARCA
                             WHERE idinversion=P_IDINVERSION UNION 
                            SELECT  '999',	'999-APLICA A TODAS' FROM DUAL) M
                          INNER JOIN  VT_ICOM_CLIENTE_MATERIAL_COMPRA M  ON (M.ACA_MARCA=M.CODIGOMARCA)
                          WHERE M.IDINVERSION=P_IDINVERSION AND  M.GRUPO=P_GRUPO GROUP BY MARCA);
         
         V_JUSTIFICACION :=  REPLACE(V_JUSTIFICACION, '$CLIENTE$', TRIM(V_CLIENTE));   
         V_JUSTIFICACION :=  REPLACE(V_JUSTIFICACION, '$MATERIAL$', TRIM(V_MATERIAL)); 
         V_JUSTIFICACION :=  REPLACE(V_JUSTIFICACION, '$MARCA$', TRIM(V_MARCA)); 
         V_JUSTIFICACION :=  REPLACE(V_JUSTIFICACION, '$FECHA$', TRIM(V_FECHA)); 
         
         V_JUSTIFICACION:=REPLACE(V_JUSTIFICACION,' / ','/');
        RETURN V_JUSTIFICACION;
    
    END F_MaterialPop_JUSTIFICACION;
    
    /*pORCESO PARA VALIDAR QUE INGRESE LAS ACAS DE FORMA OBLIGATORIA 
    SP_MaterialPop_VALIDAR_ACAS(P_IDINVERSION =>P_IDINVERSION, P_GRUPO=>P_GRUPO)
    */
    PROCEDURE SP_MaterialPop_VALIDAR_ACAS(P_IDINVERSION NUMBER, P_GRUPO NUMBER)AS
    V_CONTADOR NUMBER;
    V_AREA VARCHAR(100);
    V_MENSAJE VARCHAR(2500);
    V_ACA1 VARCHAR(100);
    V_ACA2 VARCHAR(100);
    V_ACA3 VARCHAR(100);
    V_ACA4 VARCHAR(100);
    BEGIN 
    
         SELECT COUNT(1) INTO V_CONTADOR FROM VT_ICOM_CLIENTE_MATERIAL_COMPRA 
          LEFT JOIN F4101@jdedtadl ON (ICA=TRIM(IMLITM)) --IMITM, IMLITM
          WHERE IDINVERSION=P_IDINVERSION AND GRUPO =P_GRUPO AND IMITM IS NULL;
          
          IF V_CONTADOR>0 THEN  
                RAISE_APPLICATION_ERROR(-20001, 'ICA esta nulo o no existe en JDE'); 
          END IF;
          
          SELECT AREA_ERP INTO V_AREA
            FROM T_ICOM_INVERSIONES  I
            LEFT JOIN VT_ICOM_AREA A ON (A.IDAREA=I.IDAREA)
            WHERE I.ID =P_IDINVERSION;
            
        FOR I IN (SELECT * FROM VT_ICOM_CLIENTE_MATERIAL_COMPRA 
                   WHERE IDINVERSION=P_IDINVERSION AND GRUPO =P_GRUPO) LOOP
            ---ACAS ACA_MARCA, ACA_CLIENTE, ACA_LINEA, ACA_CANAL   ('4', 'C', '7', '3')
            SELECT  GMCEC1, GMCEC2, GMCEC3, GMCEC4 
            INTO V_ACA1, V_ACA2, V_ACA3, V_ACA4
                FROM     vt_icom_icas I
            LEFT JOIN  f0901@JDEDTADL J ON (trim(GMMCU)||'.'||trim(GMOBJ)||'.'||trim(GMSUB)=V_AREA||'.'||CUENTA)
            WHERE ID=I.ICA;
            
            
            IF((TRIM(V_ACA1) IS NOT NULL AND I.ACA_MARCA IS NULL) OR
                (TRIM(V_ACA2) IS NOT NULL AND I.ACA_CLIENTE IS NULL) OR
                (TRIM(V_ACA3) IS NOT NULL AND I.ACA_LINEA IS NULL) OR
                (TRIM(V_ACA4) IS NOT NULL AND I.ACA_CANAL IS NULL)) THEN 
                V_MENSAJE:= 'El material: '||I.ICA||'-'||I.MATERIAL||' se debe ingresar de forma obligatoria 
                los valores para las ACAS: '|| 
                CASE WHEN TRIM(V_ACA1) IS NOT NULL THEN ' MARCA ' ELSE '' END
                ||CASE WHEN TRIM(V_ACA2) IS NOT NULL THEN ' CLIENTE ' ELSE '' END
                ||CASE WHEN TRIM(V_ACA3) IS NOT NULL THEN ' LINEA ' ELSE '' END
                ||CASE WHEN TRIM(V_ACA2) IS NOT NULL THEN ' CANAL ' ELSE '' END
                ;  
                RAISE_APPLICATION_ERROR(-20000, V_MENSAJE); 
            END IF;
            
        END LOOP;           
    END SP_MaterialPop_VALIDAR_ACAS;
    
    /*Procedimiento para subir desde excel los datos de la distribucion de material 
     */
     PROCEDURE SP_cargaDistribucionMaterial ( P_IDINVERSION NUMBER, P_ORDENCOMPRA VARCHAR2, P_COMPANIA VARCHAR2 ) AS
        v_codigopdv varchar2(500);
        v_cantidad number ;
        v_sql varchar2(2000);
        v_numlinea number ;
     BEGIN
        --Validacion de codigos Pdv existan
        v_codigopdv := ' ';
        for mat in (  SELECT TRIM(C03) CODIGOPDV
                      FROM DATA.VT_APEX_EXCEL  E
                      WHERE TRIM(C03) IS NOT NULL --CODIGOPDV
                      AND NOT EXISTS ( SELECT 1 FROM data.t_trad_cliente WHERE compania = p_compania 
                      and estado = 1 and CODIGOPDV = TRIM(C03) )   ) 
        loop
            v_codigopdv := v_codigopdv||mat.codigopdv||', ';
        end loop;
        if (length(trim(v_codigopdv)) > 1) then
            raise_application_error(-20100, 'Error el codigo PDV '||v_codigopdv ||' no existe.');
        end if;
        --borramos la distribucion existente
        delete from data.t_icom_cliente_material_dis_det where ordencompra = p_ordencompra and idinversion = p_idinversion ;
        delete from t_icom_cliente_material_dis where ordencompra = p_ordencompra and idinversion = p_idinversion ;
        
        --buscamos los datos del archivo para ingresar la distribucion
        for pdv in (SELECT TRIM(C02) KIT, TRIM(C03) CODIGOPDV, UPPER(TRIM(C05)) PERSONA, UPPER(TRIM(C06)) ZONA, 
                        UPPER(TRIM(C07)) CIUDAD, UPPER(TRIM(C08)) DIRECCION, UPPER(TRIM(C09)) TELEFONO, 
                        ROUND(REPLACE(C10, '.', ',')) numerobulto
                    FROM DATA.VT_APEX_EXCEL  E
                    WHERE TRIM(C02) IS NOT NULL AND TRIM(C03) IS NOT NULL)
        loop
            --insertamos la distribucion 
            insert into data.t_icom_cliente_material_dis
            (ordencompra, idinversion, codigopdv, kit, personarecepcion, zona, ciudad, direccion, telefono, estado, numerobulto)
            values
            (p_ordencompra, p_idinversion, pdv.codigopdv, pdv.kit, pdv.persona, pdv.zona, pdv.ciudad, pdv.direccion, pdv.telefono, 0, pdv.numerobulto );
            v_numlinea := 0 ;
            for linea in ( select requisicionlinea numero, idmaterial
                            from vt_icom_cliente_material_negociado
                            where idinversion = p_idinversion
                            and grupo is not null 
                            and ordencompra = p_ordencompra 
                            and nvl(requisicionlinea,0) > 0 
                            group by requisicionlinea, idmaterial
                            order by requisicionlinea, idmaterial)
            loop
                v_numlinea := v_numlinea + 1 ;
                --con las lineas de la compra comparamos cada columna del excel para el kit
                v_sql := 'select NVL(ROUND(REPLACE(C'||to_char(10+v_numlinea)||', ''.'', '',''),2),0)  
                          from data.vt_apex_excel where TRIM(C02) IS NOT NULL AND TRIM(C03) IS NOT NULL and TRIM(C02) = '''||pdv.kit||''' ';
                --raise_application_error(-20100, v_sql );
                execute immediate v_sql into v_cantidad;
                --si la cantidad es mayor que cero insertamos el detalle
                if v_cantidad is not null then
                    insert into data.t_icom_cliente_material_dis_det
                    (ordencompra, idinversion, codigopdv, kit, requisicionlinea, idmaterial, cantidad)
                    values
                    (p_ordencompra, p_idinversion, pdv.codigopdv, pdv.kit, linea.numero, linea.idmaterial, v_cantidad ) ;
                end if;
            end loop;
            --commit;
        end loop;
        
	 END SP_cargaDistribucionMaterial;	
     
    /*Procedimiento para enviar a ruta de aprobacion la distribucion de material POP*/
    PROCEDURE SP_Dist_MaterialPopEnviar(P_IDINVERSION NUMBER, P_ORDENCOMPRA VARCHAR2, P_USUARIO VARCHAR2,P_COMPANIA VARCHAR) AS
     V_OBJETO VARCHAR(100):='DISTRIBUCION_MATERIAL_POP';
     V_EXITO NUMBER;
     v_cuenta number;
    BEGIN 
        
        --Validar que el total de la distribucion detalle no no sobrepase lo pedido
        select count(1) into v_cuenta
        from ( select requisicionlinea, cantidad 
               from data.VT_ICOM_CLIENTE_MATERIAL_COMPRA
               where idinversion = p_idinversion
               and ordencompra = p_ordencompra ) mat,
              ( select requisicionlinea, sum(nvl(cantidad,0)) cantidad
                from data.t_icom_cliente_material_dis_det
                where idinversion = p_idinversion
                and ordencompra = p_ordencompra
                group by requisicionlinea
              ) det
        where mat.requisicionlinea = det.requisicionlinea
        and mat.cantidad < det.cantidad ;
        
        IF(nvl(v_cuenta,0) > 0) THEN
            RAISE_APPLICATION_ERROR(-20000, 'La cantidad de material pop distribuido es superior al pedido no se puede enviar a ruta');
        END IF;    
        
        --Envia a ruta
        DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJOENVIAR(
            p_id=>P_IDINVERSION||'-'||P_ORDENCOMPRA,
            p_objeto=>V_OBJETO,
            p_objetodescripcion=> '',
            p_usuario=>P_USUARIO,
            p_modulo=>G_MODULO,
            p_compania=>P_COMPANIA,
            P_ETAPA => 'PROCESO_DISTRIBUCION_MATERIAL_POP',
            P_TIPO1 =>'PROCESO_OPERATIVO',
            P_TIPO2 =>'DISTRIBUCION_DE_MATERIAL_DE_COMUNICACION',
            p_exito=>V_EXITO);
            
        IF(V_EXITO=0) THEN
            RAISE_APPLICATION_ERROR(-20100, DATA.PK_CORP_FLUJOAPROBACION.G_MENSAJE);
        END IF;    
        
       --Actualiza el estado de la distribucion  
        UPDATE T_ICOM_CLIENTE_MATERIAL_DIS SET ESTADO=2
            WHERE IDINVERSION=P_IDINVERSION AND ORDENCOMPRA = P_ORDENCOMPRA ;
       
       --Actualiza el porcentaje del proceso operativo     
        update data.t_icom_inversion_proceso
            set porcentaje = 85
            where idinversion = p_idinversion and idproceso = 6  and estado = 1 ;
            
    END SP_Dist_MaterialPopEnviar;
    
    /*Procedimiento para aprobar/rechar la distribucion de material pop*/
    PROCEDURE SP_Dist_MaterialPop_Aprobar(P_IDINVERSION NUMBER, P_ORDENCOMPRA VARCHAR2, 
        P_TIPO NUMBER, P_USUARIO VARCHAR2, P_COMPANIA VARCHAR ) AS
    BEGIN 
        /*Se verifica de que tipo es*/
        if (p_tipo = 1) then --es aprobacion
           --Actualiza el estado de la distribucion  
           UPDATE T_ICOM_CLIENTE_MATERIAL_DIS SET ESTADO=1
               WHERE IDINVERSION=P_IDINVERSION AND ORDENCOMPRA = P_ORDENCOMPRA ;
           
           --Actualiza el porcentaje del proceso operativo     
           update data.t_icom_inversion_proceso
               set porcentaje = 90--, fechafin = sysdate
               where idinversion = p_idinversion and idproceso = 6  and estado = 1 ;
           
           --se envia el correo de aprobacion
           SP_CORREOAPROBACION (P_IDINVERSION => P_IDINVERSION, 
                                P_ORDENCOMPRA => P_ORDENCOMPRA, 
                                P_USUARIO => P_USUARIO, 
                                P_COMPANIA => P_COMPANIA) ;
        
        else -- es rechazo
           --Actualiza el estado de la distribucion  
           UPDATE T_ICOM_CLIENTE_MATERIAL_DIS SET ESTADO=0
               WHERE IDINVERSION=P_IDINVERSION AND ORDENCOMPRA = P_ORDENCOMPRA ;
           
           --Actualiza el porcentaje del proceso operativo     
           update data.t_icom_inversion_proceso
               set porcentaje = 75
               where idinversion = p_idinversion and idproceso = 6  and estado = 1 ;
               
        end if;
    END SP_Dist_MaterialPop_Aprobar;
    
    /* Procedimiento que envia el correo de aprobacion de la distribucion de material pop*/
    PROCEDURE SP_CORREOAPROBACION (P_IDINVERSION NUMBER, P_ORDENCOMPRA VARCHAR2, P_USUARIO VARCHAR2, P_COMPANIA VARCHAR ) AS
        v_link varchar2(500) ;        
        v_correo varchar2(100);
        v_asunto  VARCHAR2(100);
        V_OBJETO_DES clob :='';
        v_nombre data.t_icom_inversiones.nombre%type;
        v_aprobador varchar2(500) ;  
    
    BEGIN
        --Genero los datos para enviar el correo 
        Select nombre into v_nombre from data.t_icom_inversiones where id = p_idinversion ;
        --busco el nombre del ultimo aprobador 
        select Upper(nombres||' '||apellidos) INTO v_aprobador from data.vt_corp_usuario where nombreusuario = P_USUARIO ;
            
        begin
            v_link:=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '25', P_COMPANIA,'', '',1);
        exception when no_data_found then
            v_link := '';
        end;
        
        v_correo:=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '26', P_COMPANIA);
        --en el link se pasa como estado = 3 para saber que es cuando se mira desde link
        v_link := APEX_UTIL.PREPARE_URL(p_url => v_link||'P607_ID,P607_ESTADO,P607_EDITAR:'||P_IDINVERSION|| '-' ||P_ORDENCOMPRA|| ',3,0' ) ;

        v_asunto := 'APROBACIoN, Proceso Distribucion Material POP';
               
        --FORMATO APROBACIoN 
        V_OBJETO_DES := '<p>Estimado(a) Usuario, </p>
            <p>&nbsp;</p>
            <p>Es necesario distribuir el siguiente material de comunicacion de acuerdo al siguiente detalle:</p>
            <p> Ingresar al siguiente <a href = "'||v_link||'">link</a> </p>
            <p>Descripci&oacute;n: Id:'||P_IDINVERSION||' '||v_nombre||' </p>
            <p>Solicitante : '|| v_aprobador||' </p>
            <p>Gracias por su atenci&oacute;n </p>
                                            <p>Saludos Cordiales </p>
                                            <p>Portal de Inversiones Comerciales </p>';
        
        PK_CORP_CORREO.SP_ENVIO(
                    P_MODULO => 'ICOM',
                    P_TO => v_correo,
                    P_FROM => 'infocomercial@zaimella.com',
                    P_SUBJECT => v_asunto,
                    P_BODY => V_OBJETO_DES
                  );
    END SP_CORREOAPROBACION;
    
    /*Procedimiento para verificar si es promocional asignar valor*/  
    PROCEDURE SP_verPromo_Dis_ProductoRegalo ( P_IDINVERSION NUMBER, P_PORCENTAJE NUMBER ) AS
       
    BEGIN
         if nvl(p_porcentaje,-1) = 0 then
            --Si el porcentaje es cero actualiza la cantidad de distribucion
            update data.t_icom_productodistribucion pd
            set cantidaddistribucion = ( select case nvl(cl.promocional,0) when 1 then pd.paquetesfinal else 0 end 
                                         from data.t_trad_clientelocal cl
                                         where pd.codigopdv = cl.codigopdv 
                                         and cl.matriz = 1 and cl.estado = 1 )
            where idinversion = p_idinversion ;
        end if;
    END SP_verPromo_Dis_ProductoRegalo;
    
PROCEDURE SP_subirDis_ProductoRegalo_Locales ( P_IDINVERSION in NUMBER, p_GRUPODISTRIBUCION in out number, p_exito out number, p_mensaje out varchar2) AS
    V_CONTADOR NUMBER;
    V_Pdvs VARCHAR2(3999);
    V_PRODUCTOS VARCHAR2(3999);
    V_GRUPODISTRIBUCION NUMBER;
    V_COMPANIA VARCHAR2(5);
BEGIN
    --borrar todas las que se insertaron en esta etapa
    delete from data.t_icom_productodistribucion  where idinversion = P_IDINVERSION and nvl(tipo,0) = 1  ;

    delete from data.t_icom_productodistribuciondet  where idinversion = P_IDINVERSION and nvl(estado,0) = 0  and (GRUPODISTRIBUCION=p_GRUPODISTRIBUCION or p_GRUPODISTRIBUCION is null);
        

    SELECT count(distinct 1),listagg(distinct '<li>'||trim(ex.c07)||'</li>',' ') into V_CONTADOR,V_Pdvs
    from data.VT_APEX_EXCEL  EX where data.pk_commons.safe_to_number(trim(c23))<0 AND ex.C01 > 1;

    IF (V_CONTADOR=1) THEN
        p_exito:=0;
        P_MENSAJE:=('Revisar cantidades de bultos ponderados no pueden ser negativos.'||V_Pdvs); 
        return;
    END IF;

    SELECT COMPANIA INTO V_COMPANIA FROM DATA.T_ICOM_INVERSIONES WHERE ID=P_IDINVERSION;

    select LISTAGG(DISTINCT '<li>'||CODIGOPRODUCTO||' - '||PRODUCTO||'</li>',' ') WITHIN GROUP (ORDER BY PRODUCTO) INTO V_PRODUCTOS
    from (
        select DATA.PK_ICOM_PROCESOS.f_validatotaldistribucion(
            P_CANTIDADDISTRIBUCION=>EX.CANTIDAD_PDV,
            P_IDINVERSION=>trim(EX.IDINVERSION),
            P_CODIGOPRODUCTO=>trim(EX.CODIGO_PRODUCTO),
            P_CODIGOREGALO=>trim(EX.CODIGO_PRODUCTOREGALO))validatotaldistribucion,
            EX.IDINVERSION, EX.CODIGO_PRODUCTO, EX.CODIGO_PRODUCTOREGALO, EX.CANTIDAD_PDV,PR.PRODUCTO,PR.CODIGOPRODUCTO
            from (
                SELECT P_IDINVERSION IDINVERSION,trim(c03) CODIGO_PRODUCTO,trim(c05) CODIGO_PRODUCTOREGALO,SUM(data.pk_commons.safe_to_number(trim(c23))) CANTIDAD_PDV
                FROM DATA.VT_APEX_EXCEL  EX 
                WHERE EX.C01 > 1
                GROUP BY  trim(c03), trim(c05)
            )EX  
            INNER JOIN DATA.T_ICOM_INVERSION_PRODUCTO   IP ON ( IP.IDINVERSION = EX.IDINVERSION AND IP.CODIGOPRODUCTO=EX.CODIGO_PRODUCTO       AND IP.TIPO = 1 ) --PRODUCTO
            INNER JOIN DATA.T_ICOM_INVERSION_PRODUCTO   PR ON ( PR.IDINVERSION = EX.IDINVERSION AND PR.CODIGOPRODUCTO=EX.CODIGO_PRODUCTOREGALO AND PR.TIPO = 2 ) --REGALO) 
        )     
    WHERE validatotaldistribucion=0;

    if(V_PRODUCTOS is not null)then 
        p_exito:=0;
        P_MENSAJE:='La cantidad de distribucion de los productos es mayor a la cantidad disponible de la propuesta.'||V_PRODUCTOS; 
        return;
    end if;

    V_GRUPODISTRIBUCION:=p_GRUPODISTRIBUCION;
    IF (V_GRUPODISTRIBUCION IS NULL)THEN
        SELECT (NVL(MAX(GRUPODISTRIBUCION),100)+1 )INTO V_GRUPODISTRIBUCION FROM data.t_icom_productodistribuciondet where nvl(estado,0) != 2 ;
    END IF;
     
    execute IMMEDIATE 'truncate table data.t_tmp_b drop storage';
    
    insert into data.t_tmp_b(
        num01,num02,dte01,dte02,dte03,txt01,
        txt02,num03,txt03,txt04,txt05,txt06,
        num04,num05,num06,txt07,txt08,txt09,
        txt10,txt11,txt12,txt13,txt14,num07)
        
        with t_excel as (
            SELECT P_IDINVERSION IDINVERSION,
            SUBSTR(EX.c07, 1, INSTR(EX.c07, '-') - 1) AS CODIGOPDV,
            SUBSTR(EX.c07, INSTR(EX.c07, '-') + 1) AS NUMERO,
            EX.c03 CODIGOPRODUCTO,EX.c04 PRODUCTO,
            EX.c05 CODIGOREGALO,EX.c06 REGALO,
            round((EX.c17/100),4) PORCENTAJEPROMO, EX.c23 CANTIDADDISTRIBUCION, SUM(EX.c23) OVER (PARTITION BY SUBSTR(EX.c07, 1, INSTR(EX.c07, '-') - 1)) AS CANTIDADDISTRIBUIR_PDV,
            VG.COORDINADOR,VG.IDZONA,VG.ZONA,CL.ENVIO_DIRECCION DIRECCION,CL.IDGEOGRAFICO UBICACION,CL.NOMBRECONOCIDO,to_number(TC.ENVIOTIPO)ENVIOTIPO
            FROM DATA.VT_APEX_EXCEL  EX
            LEFT JOIN DATA.T_TRAD_CLIENTE TC ON (SUBSTR(EX.c07, 1, INSTR(EX.c07, '-') - 1) = TC.CODIGOPDV AND TC.COMPANIA = V_COMPANIA)
            LEFT JOIN DATA.T_TRAD_CLIENTELOCAL CL ON ( EX.c07=CL.CODIGOPDV||'-'||CL.NUMERO )
            LEFT JOIN DATA.VT_TRAD_GEOGRAFICO_NIVEL VG ON ( CL.idgeografico = VG.id)
            WHERE EX.C01 > 1
        )
        
    SELECT 
        IDINVERSION,TO_NUMBER(V_GRUPODISTRIBUCION) GRUPODISTRIBUCION,SYSDATE FECHADISTRIBUCION, NULL FECHAINIENCUESTA, NULL FECHAFINENCUESTA, NULL NOMBREENCUESTA,
        CODIGOPDV CODIGOPDV,TO_NUMBER(NUMERO) CODIGOLOCAL,CODIGOPRODUCTO,PRODUCTO, CODIGOREGALO,REGALO,
        round((PORCENTAJEPROMO/100),4)PORCENTAJEPROMO, CANTIDADDISTRIBUCION,CANTIDADDISTRIBUIR_PDV,
        COORDINADOR,IDZONA,ZONA,DIRECCION, NULL TIPODOCUMENTO,NULL NUMERODOCUMENTO, UBICACION,NOMBRECONOCIDO,ENVIOTIPO
    FROM t_excel
    WHERE PORCENTAJEPROMO > 0 AND CANTIDADDISTRIBUCION > 0
    ORDER BY CODIGOPDV,CODIGOLOCAL;
    
    insert into data.t_icom_productodistribucionDet(IDINVERSION, GRUPODISTRIBUCION, FECHADISTRIBUCION, FECHAINIENCUESTA, FECHAFINENCUESTA, NOMBREENCUESTA, 
    CODIGOPDV, CODIGOLOCAL, CODIGOPRODUCTO, PRODUCTO, CODIGOREGALO, REGALO, CANTIDADDISTRIBUCION, CANTIDADDISTRIBUIR, COORDINADOR, IDZONA,ZONA,
    DIRECCION, TIPODOCUMENTO, NUMERODOCUMENTO, UBICACION, NOMBRECONOCIDO, ENVIOTIPO)
        
    SELECT 
        num01 IDINVERSION,num02 GRUPODISTRIBUCION,
        dte01 FECHADISTRIBUCION,dte02 FECHAINIENCUESTA,dte03 FECHAFINENCUESTA,txt01 NOMBREENCUESTA,
        txt02 CODIGOPDV,nvl(num03,0) CODIGOLOCAL,txt03 CODIGOPRODUCTO,txt04 PRODUCTO,
        txt05 CODIGOREGALO,txt06 REGALO,num05 CANTIDADDISTRIBUCION,num06 
        CANTIDADDISTRIBUIR,txt07 COORDINADOR,txt08 IDZONA,txt09 ZONA,txt10 
        DIRECCION,txt11 TIPODOCUMENTO,txt12 NUMERODOCUMENTO,txt13 UBICACION,txt14
        NOMBRECONOCIDO,num07 ENVIOTIPO
    FROM data.t_tmp_b
    ORDER BY CODIGOPDV,  txt03,txt05 ,num04 DESC;
    
    P_GRUPODISTRIBUCION:=V_GRUPODISTRIBUCION;
    
    SELECT count(distinct 1) into V_CONTADOR
    FROM DATA.t_tmp_ejmc  EX 
    INNER JOIN DATA.T_TRAD_CLIENTE TC ON (to_char(TC.CODIGOPDV)=trim(to_char(c02)) ) AND TC.ESTADO = 1  AND TC.COMPANIA = V_COMPANIA
    WHERE nvl(Tc.ENVIOTIPO,0) =0;
    
    p_exito:=1;
    IF (V_CONTADOR=1) THEN
        p_mensaje:=('Para los pdv con configuracion tipo de envio NO ENVIAR no se cargan los registros');
        return;
    END IF;
    p_mensaje:=('Datos cargados correctamente');

END SP_subirDis_ProductoRegalo_Locales;


    /*Procedimiento para subir los productos y regalos desde el archivo para la distribucion*/
PROCEDURE SP_subirDis_ProductoRegalo ( P_IDINVERSION NUMBER, p_GRUPODISTRIBUCION in out number, p_exito out number, p_mensaje out varchar2) AS
--declare  P_IDINVERSION NUMBER:=21475; p_GRUPODISTRIBUCION number:=101; p_exito   number:=null; p_mensaje   varchar2(3999):=null;
        V_GRUPODISTRIBUCION NUMBER;
        V_PRODUCTOS VARCHAR2(3999);
        V_CONTADOR NUMBER;
        V_CONT NUMBER;     
        V_Pdvs VARCHAR2(3999);
        V_PDV_SUPERVISOR_INVALIDOS VARCHAR2(3999);
        v_sum NUMBER := 0;
        v_residuo NUMBER;
        V_COMPANIA VARCHAR2(5);

    BEGIN
        SELECT count(distinct 1),listagg(distinct '<li>'||trim(ex.c04)||'</li>',' ') into V_CONTADOR,V_Pdvs
        from data.VT_APEX_EXCEL  EX where data.pk_commons.safe_to_number(trim(c05))<0;

        IF (V_CONTADOR=1) THEN
            p_exito:=0;
            P_MENSAJE:=('Revisar cantidades no pueden ser negativos.'||V_Pdvs); 
            return;
        END IF;

        SELECT COMPANIA INTO V_COMPANIA FROM DATA.T_ICOM_INVERSIONES WHERE ID=P_IDINVERSION;

        /*
           El envío Supervisor se entrega al supervisor Trade de la matriz del
           PDV. Una matriz ambigua o incompleta se reporta sin usar un local hijo.
        */
        SELECT LISTAGG(DISTINCT '<li>' || TRIM(EX.C04) || '</li>', ' ')
                 WITHIN GROUP (ORDER BY '<li>' || TRIM(EX.C04) || '</li>')
          INTO V_PDV_SUPERVISOR_INVALIDOS
          FROM DATA.VT_APEX_EXCEL EX
          INNER JOIN DATA.T_TRAD_CLIENTE TC
            ON TC.CODIGOPDV = TRIM(EX.C04)
           AND TC.COMPANIA = V_COMPANIA
          LEFT JOIN (
              SELECT CODIGOPDV,
                     COUNT(*) CANTIDAD_MATRICES,
                     MAX(ENVIO_UBICACION) ENVIO_UBICACION
                FROM DATA.T_TRAD_CLIENTELOCAL
               WHERE ESTADO = 1
                 AND MATRIZ = 1
               GROUP BY CODIGOPDV
          ) CM ON CM.CODIGOPDV = TC.CODIGOPDV
          LEFT JOIN DATA.VT_TRAD_GEOGRAFICO_NIVEL VGM
            ON VGM.ID = CM.ENVIO_UBICACION
           AND VGM.COMPANIA = V_COMPANIA
         WHERE NVL(TC.ENVIOTIPO, 0) = 3
           AND NVL(CM.CANTIDAD_MATRICES, 0) <> 1;

        IF V_PDV_SUPERVISOR_INVALIDOS IS NOT NULL THEN
            p_exito := 0;
            p_mensaje := 'Los PDV con envío SUPERVISOR requieren una única matriz activa: '
                         || V_PDV_SUPERVISOR_INVALIDOS;
            RETURN;
        END IF;

        --Borrar los borradores previos solo después de validar la configuración Trade.
        delete from data.t_icom_productodistribucion where idinversion = P_IDINVERSION and nvl(tipo,0) = 1;
        delete from data.t_icom_productodistribuciondet
         where idinversion = P_IDINVERSION
           and nvl(estado,0) = 0
           and (GRUPODISTRIBUCION = p_GRUPODISTRIBUCION or p_GRUPODISTRIBUCION is null);
        
            select LISTAGG(DISTINCT '<li>'||CODIGOPRODUCTO||' - '||PRODUCTO||'</li>',' ') WITHIN GROUP (ORDER BY PRODUCTO) INTO V_PRODUCTOS
            from (
                select DATA.PK_ICOM_PROCESOS.f_validatotaldistribucion(P_CANTIDADDISTRIBUCION=>EX.CANTIDAD_PDV,P_IDINVERSION=>trim(EX.IDINVERSION),P_CODIGOPRODUCTO=>trim(EX.CODIGO_PRODUCTO),P_CODIGOREGALO=>trim(EX.CODIGO_PRODUCTOREGALO))validatotaldistribucion
                ,EX.IDINVERSION, EX.CODIGO_PRODUCTO, EX.CODIGO_PRODUCTOREGALO, EX.CANTIDAD_PDV,PR.PRODUCTO,PR.CODIGOPRODUCTO
                from (
                    SELECT P_IDINVERSION IDINVERSION,trim(c02) CODIGO_PRODUCTO,trim(c03) CODIGO_PRODUCTOREGALO,SUM(data.pk_commons.safe_to_number(trim(c05))) CANTIDAD_PDV
                    FROM DATA.VT_APEX_EXCEL  EX 
                    GROUP BY  trim(c02), trim(c03)
                )EX  
                INNER JOIN DATA.T_ICOM_INVERSION_PRODUCTO   IP ON ( IP.IDINVERSION = EX.IDINVERSION AND IP.CODIGOPRODUCTO=EX.CODIGO_PRODUCTO       AND IP.TIPO = 1 ) --PRODUCTO
                INNER JOIN DATA.T_ICOM_INVERSION_PRODUCTO   PR ON ( PR.IDINVERSION = EX.IDINVERSION AND PR.CODIGOPRODUCTO=EX.CODIGO_PRODUCTOREGALO AND PR.TIPO = 2 ) --REGALO) 
             ) WHERE validatotaldistribucion=0;

        if(V_PRODUCTOS is not null)then 
           RAISE_APPLICATION_ERROR(-20000, 'La cantidad de distribucion de los productos es mayor a la cantidad de la propuesta.'||V_PRODUCTOS); 
        end if;
--        --Se ineserta los valores segun lo indicado en la configuracion
        --se obtiene el grupo a ser procesado
        V_GRUPODISTRIBUCION:=p_GRUPODISTRIBUCION;
        IF (V_GRUPODISTRIBUCION IS NULL)THEN
            SELECT (NVL(MAX(GRUPODISTRIBUCION),100)+1 )INTO V_GRUPODISTRIBUCION FROM data.t_icom_productodistribuciondet where nvl(estado,0) != 2 ;
        END IF;

        execute IMMEDIATE 'truncate table data.t_tmp_b drop storage';

        insert into data.t_tmp_b(num01,num02,dte01,dte02,dte03,txt01,
        txt02,num03,txt03,txt04,txt05,txt06,
        num04,num05,num06,txt07,txt08,txt09,txt10,txt11,txt12,txt13,txt14,num07) 
            with 
            t_excel as(
                SELECT ROW_NUMBER() OVER (ORDER BY   trim(c02) , trim(c03), trim(c04)) rn , 
                P_IDINVERSION IDINVERSION,trim(c02) CODIGO_PRODUCTO,trim(c03) CODIGO_PRODUCTOREGALO,trim(c04) CODIGOPDV,data.pk_commons.safe_to_number(trim(c05)) CANTIDAD_PDV
                    , nvl(ENVIOTIPO,0)ENVIOTIPO
                FROM DATA.VT_APEX_EXCEL  EX INNER JOIN DATA.T_TRAD_CLIENTE TC ON ( (TC.CODIGOPDV=trim(c04) and TC.COMPANIA = V_COMPANIA ) /*AND TC.ESTADO = 1 */)
                order by ENVIOTIPO,CODIGOPDV,CODIGO_PRODUCTO, CODIGO_PRODUCTOREGALO
            )
            ,t_resumen as(
                    select rn,EX.IDINVERSION,EX.CODIGOPDV,EX.CODIGO_PRODUCTO,IP.PRODUCTO, EX.CODIGO_PRODUCTOREGALO,PR.PRODUCTO REGALO, EX.CANTIDAD_PDV,EX.ENVIOTIPO
                     ,case when   to_char(EX.ENVIOTIPO )  in ('2') then 
                                case to_char(cl.promocional)  when '1' then 
                                    100 
                                else 
                                    0 
                                end 
                            when   to_char(EX.ENVIOTIPO )  =('0') then 
                                0
                            else 
                                nvl(CL.PORCENTAJEPROMO,0)
                            end PORCENTAJEPROMO
                     ,case
                        when   to_char(EX.ENVIOTIPO )  =('2') then 
                            case to_char(cl.promocional) when '1' then to_char(cl.NUMERO) else null end 
                         when   to_char(EX.ENVIOTIPO )  =('0') then '0'
                        else case when EX.ENVIOTIPO = 3 then to_char(CLM.NUMERO) else to_char(cl.NUMERO) end
                     end NUMERO
                     ,vg.COORDINADOR COORDINADOR, vg.idzona,vg.zona
                     ,case when EX.ENVIOTIPO = 3 then CLM.ENVIO_DIRECCION else CL.ENVIO_DIRECCION end DIRECCION
                     ,case when EX.ENVIOTIPO = 3 then CLM.ENVIO_UBICACION else CL.IDGEOGRAFICO end IDGEOGRAFICO
                     ,0 ESTADO
                     ,case when EX.ENVIOTIPO = 3 then CLM.NOMBRECONOCIDO else CL.NOMBRECONOCIDO end NOMBRECONOCIDO
                from 
                    t_excel EX 
                    INNER JOIN DATA.T_TRAD_CLIENTELOCAL         CL ON (  EX.CODIGOPDV=CL.CODIGOPDV /*AND CL.ESTADO = 1 */)
                    LEFT JOIN DATA.T_TRAD_CLIENTELOCAL          CLM ON ( EX.CODIGOPDV=CLM.CODIGOPDV AND CLM.MATRIZ = 1 AND CLM.ESTADO = 1 )
                    INNER JOIN DATA.T_ICOM_INVERSION_PRODUCTO   IP ON ( IP.IDINVERSION = EX.IDINVERSION AND IP.CODIGOPRODUCTO=EX.CODIGO_PRODUCTO       AND IP.TIPO = 1 ) --PRODUCTO
                    INNER JOIN DATA.T_ICOM_INVERSION_PRODUCTO   PR ON ( PR.IDINVERSION = EX.IDINVERSION AND PR.CODIGOPRODUCTO=EX.CODIGO_PRODUCTOREGALO AND PR.TIPO = 2 ) --REGALO
                    LEFT JOIN data.VT_TRAD_GEOGRAFICO_NIVEL     vg ON ((case when EX.ENVIOTIPO = 3 then CLM.ENVIO_UBICACION else CL.ENVIO_UBICACION end) = vg.id AND vg.compania = V_COMPANIA)
            )
            SELECT  
                IDINVERSION,TO_NUMBER(V_GRUPODISTRIBUCION) GRUPODISTRIBUCION,SYSDATE FECHADISTRIBUCION, NULL FECHAINIENCUESTA, NULL FECHAFINENCUESTA, NULL NOMBREENCUESTA,
                CODIGOPDV CODIGOPDV,TO_NUMBER(NUMERO) CODIGOLOCAL,CODIGO_PRODUCTO CODIGOPRODUCTO,PRODUCTO,CODIGO_PRODUCTOREGALO CODIGOREGALO,REGALO,
                round((PORCENTAJEPROMO/100),2)PORCENTAJEPROMO,round(CANTIDAD_PDV*round((PORCENTAJEPROMO/100),4),4)  CANTIDADDISTRIBUCION,CANTIDAD_PDV CANTIDADDISTRIBUIR,
                COORDINADOR,IDZONA,ZONA,DIRECCION, NULL TIPODOCUMENTO,NULL NUMERODOCUMENTO, IDGEOGRAFICO UBICACION,NOMBRECONOCIDO,to_number(ENVIOTIPO)ENVIOTIPO
            FROM t_resumen R
            where PORCENTAJEPROMO>0
            ORDER BY RN,IDINVERSION, CODIGOPDV, CODIGOLOCAL
            ;
        
        for datos1 in (
            SELECT  num01 IDINVERSION,num02 GRUPODISTRIBUCION,txt02 CODIGOPDV,txt03 CODIGOPRODUCTO,txt05 CODIGOREGALO,max(num06) CANTIDADDISTRIBUIR
            FROM data.t_tmp_b
            where num07 in (1,3)
            group by num01,num02,txt02,txt03,txt05 
            ORDER BY CODIGOPDV, CODIGOPRODUCTO, CODIGOREGALO
        )loop
            DBMS_OUTPUT.PUT_LINE('datos1.CANTIDADDISTRIBUIR:'||datos1.CANTIDADDISTRIBUIR);
            --Primera distribucion: asignar la parte entera de cada porcentaje
            FOR r IN (
                SELECT num01 IDINVERSION,num02 GRUPODISTRIBUCION,txt02 CODIGOPDV,txt03 CODIGOPRODUCTO,txt05 CODIGOREGALO
                FROM data.T_TMP_B 
                where 1=1
                and num01=datos1.IDINVERSION
                and num02=datos1.GRUPODISTRIBUCION
                and txt02=datos1.CODIGOPDV
                and txt03=datos1.CODIGOPRODUCTO
                and txt05=datos1.CODIGOREGALO
            ) LOOP
                UPDATE data.T_TMP_B
                SET NUM05 = TRUNC(datos1.CANTIDADDISTRIBUIR * (num04))
                WHERE  1=1
                and num01=datos1.IDINVERSION
                and num02=datos1.GRUPODISTRIBUCION
                and txt02=datos1.CODIGOPDV
                and txt03=datos1.CODIGOPRODUCTO
                and txt05=datos1.CODIGOREGALO;
            END LOOP;
            -- Calcular la suma de los valores asignados
            SELECT SUM(num05) INTO v_sum FROM data.T_TMP_B 
            where 1=1
                and num01=datos1.IDINVERSION
                and num02=datos1.GRUPODISTRIBUCION
                and txt02=datos1.CODIGOPDV
                and txt03=datos1.CODIGOPRODUCTO
                and txt05=datos1.CODIGOREGALO                ;
            -- Calcular el residuo
            v_residuo := datos1.CANTIDADDISTRIBUIR - v_sum;
            -- Distribuir el residuo en los primeros registros
            FOR r IN (
                SELECT rowid id 
                FROM data.T_TMP_B 
                where 1=1
                and num01=datos1.IDINVERSION
                and num02=datos1.GRUPODISTRIBUCION
                and txt02=datos1.CODIGOPDV
                and txt03=datos1.CODIGOPRODUCTO
                and txt05=datos1.CODIGOREGALO
                ORDER BY 1 FETCH FIRST v_residuo ROWS ONLY
            
            ) LOOP
                UPDATE data.T_TMP_B
                SET NUM05 = NUM05 + 1
                WHERE rowid = r.id;
            END LOOP;        
        end loop;
 
        insert into data.t_icom_productodistribucionDet(IDINVERSION, GRUPODISTRIBUCION, FECHADISTRIBUCION, FECHAINIENCUESTA, FECHAFINENCUESTA, NOMBREENCUESTA, 
        CODIGOPDV, CODIGOLOCAL, CODIGOPRODUCTO, PRODUCTO, CODIGOREGALO, REGALO, CANTIDADDISTRIBUCION, CANTIDADDISTRIBUIR, COORDINADOR, IDZONA,ZONA,
        DIRECCION, TIPODOCUMENTO, NUMERODOCUMENTO, UBICACION, NOMBRECONOCIDO, ENVIOTIPO)
        
        SELECT 
            num01 IDINVERSION,num02 GRUPODISTRIBUCION,
            dte01 FECHADISTRIBUCION,dte02 FECHAINIENCUESTA,dte03 FECHAFINENCUESTA,txt01 NOMBREENCUESTA,
            txt02 CODIGOPDV,nvl(num03,0) CODIGOLOCAL,txt03 CODIGOPRODUCTO,
            txt04 PRODUCTO,txt05 CODIGOREGALO,txt06 REGALO,
            num05 CANTIDADDISTRIBUCION,num06 CANTIDADDISTRIBUIR,txt07 COORDINADOR,txt08 IDZONA,txt09 ZONA,txt10 DIRECCION,txt11 TIPODOCUMENTO,txt12 NUMERODOCUMENTO,txt13 UBICACION,txt14 NOMBRECONOCIDO,num07 ENVIOTIPO
        FROM data.t_tmp_b
--        where num05<>0
        ORDER BY CODIGOPDV,  txt03,txt05 ,num04 DESC;
       
        P_GRUPODISTRIBUCION:=V_GRUPODISTRIBUCION;    
       --Actualiza el porcentaje del proceso operativo     
        --update data.t_icom_inversion_proceso set porcentaje = 10 where idinversion = P_IDINVERSION and idproceso = 4  and estado = 1 ;   
        
        SELECT count(distinct 1) into V_CONTADOR
        FROM DATA.t_tmp_ejmc  EX 
        INNER JOIN DATA.T_TRAD_CLIENTE TC ON ( 
            (
            to_char(TC.CODIGOPDV)=trim(to_char(c02)) ) 
            AND TC.ESTADO = 1 
        ) 
        WHERE nvl(Tc.ENVIOTIPO,0) =0 AND TC.COMPANIA = V_COMPANIA;

        p_exito:=1;
        IF (V_CONTADOR=1) THEN
            p_mensaje:=('Para los pdv con configuracion tipo de envio NO ENVIAR no se cargan los registros');
            return;
        END IF;
        p_mensaje:=('Datos cargados correctamente');
    END SP_subirDis_ProductoRegalo;        
    /*Funcion que calcula el sellout del mes*/
    FUNCTION F_sellOutProductoRegalo ( P_CODIGOPRODUCTO VARCHAR2, P_CODIGOPDV VARCHAR2 ) RETURN NUMBER AS
        V_VALOR NUMBER;
    BEGIN
        select SUM(NVL(S.VALORUNIDAD,0)) into v_valor
        from t_trad_sellout S 
			left JOIN t_trad_clienteruc R ON (R.ruc=S.ruc AND S.FECHA BETWEEN  R.FECHADESDE AND NVL(r.fechahasta, SYSDATE))
		where s.codigoproducto = p_codigoproducto and r.codigopdv = p_codigopdv 
        and fecha between trunc(add_months(sysdate,-1),'MM')  and last_day(add_months(sysdate,-1)) ;
        
        return nvl(v_valor,0) ;
    END F_sellOutProductoRegalo;
    
    /*Procedimiento para enviar a ruta de aprobacion la distribucion producto regalo*/
    PROCEDURE SP_Dist_ProductoRegaloEnviar(P_IDINVERSION NUMBER, P_USUARIO VARCHAR2, P_COMPANIA VARCHAR, P_DESCRIPCION VARCHAR,P_GRUPODISTRIBUCION VARCHAR) AS
     V_OBJETO VARCHAR(100):='PROCESO_PRODUCTO_REGALO';
     V_EXITO NUMBER;
     v_cuenta number;
    BEGIN 
        
        --Envia a ruta
        DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJOENVIAR(
            p_id=>P_IDINVERSION||'-'||P_GRUPODISTRIBUCION,
            p_objeto=>V_OBJETO,
            p_objetodescripcion=> P_DESCRIPCION,
            p_usuario=>P_USUARIO,
            p_modulo=>G_MODULO,
            p_compania=>P_COMPANIA,
            P_ETAPA => 'PROCESO_DISTRIBUCION_PRODUCTO_REGALO',
            P_TIPO1 =>'PROCESO_OPERATIVO',
            P_TIPO2 =>'DISTRIBUCION_DE_PRODUCTO_REGALO_AL_CLIENTE',
            p_exito=>V_EXITO);
        
        IF(V_EXITO=0) THEN
            RAISE_APPLICATION_ERROR(-20100, DATA.PK_CORP_FLUJOAPROBACION.G_MENSAJE);
        END IF;    
        --Actualiza el porcentaje del proceso operativo     
        update data.t_icom_inversion_proceso set porcentaje = 25 where idinversion = p_idinversion and idproceso = 4  and estado = 1 ;
            
        update data.T_ICOM_PRODUCTODISTRIBUCIONDET
            set estado = 2
            where idinversion = p_idinversion and estado = 0;
            
    END SP_Dist_ProductoRegaloEnviar;
    
    /*Procedimiento para aprobar/rechar la distribucion de producto regalo*/
    PROCEDURE SP_Dist_ProductoRegaloAprobar(P_IDINVERSION NUMBER, 
        P_TIPO NUMBER, P_USUARIO VARCHAR2, P_COMPANIA VARCHAR ,P_GRUPODISTRIBUCION VARCHAR) AS
        v_MENSAJE VARCHAR2(3999);v_idflujo number;
    BEGIN 
         dbms_output.put_line('SP_Dist_ProductoRegaloAprobar:P_IDINVERSION: '||P_IDINVERSION);
         dbms_output.put_line('SP_Dist_ProductoRegaloAprobar:P_TIPO: '||P_TIPO);
         dbms_output.put_line('SP_Dist_ProductoRegaloAprobar:P_USUARIO: '||P_USUARIO);
         dbms_output.put_line('SP_Dist_ProductoRegaloAprobar:P_COMPANIA: '||P_COMPANIA);
         dbms_output.put_line('SP_Dist_ProductoRegaloAprobar:P_GRUPODISTRIBUCION: '||P_GRUPODISTRIBUCION);

        /*Se verifica de que tipo es*/
        if (p_tipo = 1) then --es aprobacion
           
           --Actualiza el porcentaje del proceso operativo     
           update data.t_icom_inversion_proceso set porcentaje = 75 where idinversion = p_idinversion and idproceso = 4  and estado = 1 ;
           
           begin
                update t_icom_productodistribuciondet set estado=3 where idinversion=P_IDINVERSION and estado=2 and GRUPODISTRIBUCION= P_GRUPODISTRIBUCION;
                sp_crearordenautoconsumo(P_IDINVERSION, P_GRUPODISTRIBUCION);
                PK_ICOM_PROCESOSTAREAS.SP_ActualizarPDV(P_IDINVERSION);
           exception when others then
                ROLLBACK;
                SELECT max(ID) INTO  v_idflujo
                FROM t_flujo_aprobacion_cab WHERE entidad_id=P_IDINVERSION||'-'||P_GRUPODISTRIBUCION AND ENTIDAD_CLASE='PROCESO_PRODUCTO_REGALO';

                update t_flujo_aprobacion_cab set estado='EN_PROCESO', FECHA_FIN=NULL  WHERE ID=v_idflujo;
                UPDATE t_flujo_aprobacion_DET SET estado='EN_PROCESO', FECHA_HASTA=NULL WHERE FLUJO_ID=v_idflujo AND USERID=P_USUARIO;
                
                COMMIT; 
--                RAISE_APPLICATION_ERROR(-20100,SQLERRM);
                RAISE;
            end;
            SP_INVERSION_ENCUENTAS_AUTOCONSUMO(P_IDINVERSION =>P_IDINVERSION,P_GRUPO =>P_GRUPODISTRIBUCION ,P_COMPANIA =>P_COMPANIA,P_MENSAJE =>v_MENSAJE);
           --se envia el correo de aprobacion
           SP_correoAprobarDist_Prod_Rega (P_IDINVERSION => P_IDINVERSION, 
                                P_USUARIO => P_USUARIO, 
                                P_COMPANIA => P_COMPANIA,
                                P_GRUPODISTRIBUCION=> P_GRUPODISTRIBUCION) ;

            if (v_MENSAJE is not null)then
                RAISE_APPLICATION_ERROR(-20000,v_MENSAJE);
            end if;
            /*
               La orden usa temporalmente estado 3 y, al crearse, deja los
               detalles en estado 2. La encuesta se genera en ese estado y
               solo se consolidan a 1 cuando toda la generacion termina bien.
            */
            update t_icom_productodistribuciondet set estado=1 where idinversion=P_IDINVERSION and estado=2 and GRUPODISTRIBUCION= P_GRUPODISTRIBUCION;
        else -- es rechazo
           
           --Actualiza el porcentaje del proceso operativo     
           update data.t_icom_inversion_proceso set porcentaje = 0 where idinversion = p_idinversion and idproceso = 4  and estado = 1 ;
           
           update t_icom_productodistribuciondet
               set estado=0 
               where idinversion=P_IDINVERSION and estado=2;
            
        end if;
    END SP_Dist_ProductoRegaloAprobar;
    
    /* Procedimiento que envia el correo de aprobacion de la distribucion de producto regalo*/
    PROCEDURE SP_correoAprobarDist_Prod_Rega (P_IDINVERSION NUMBER, P_USUARIO VARCHAR2, P_COMPANIA VARCHAR ,P_GRUPODISTRIBUCION VARCHAR) AS
        v_link varchar2(500) ;        
        v_correo varchar2(100);
        v_asunto  VARCHAR2(100);
        V_OBJETO_DES clob :='';
        v_nombre data.t_icom_inversiones.nombre%type;
        v_aprobador varchar2(500) ;  
    
    BEGIN
        --Genero los datos para enviar el correo 
        Select nombre into v_nombre from data.t_icom_inversiones where id = p_idinversion ;
        --busco el nombre del ultimo aprobador 
        select Upper(nombres||' '||apellidos) INTO v_aprobador from data.vt_corp_usuario where nombreusuario = P_USUARIO ;
            
        begin
            v_link :=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '27', P_COMPANIA,'','','1');
        exception when no_data_found then
            v_link := '';
        end;
        
        v_link := APEX_UTIL.PREPARE_URL(p_url => v_link||'P608_ID,P608_EDITAR,P608_TIPO:'||P_IDINVERSION||',0,1' ) ;
        
        --busco el correo a enviar
        begin
            select vp.notificacion_imp into v_correo 
            FROM data.vt_icom_proceso vp 
            where idproceso = 4 and notificacion_imp is not null ;
        exception when no_data_found then
            v_correo := '';
        end;

        v_asunto := 'Aprobacion Proceso Distribucion Producto Regalo';
               
        --FORMATO APROBACIoN 
        V_OBJETO_DES := '<p>Estimado(a) Usuaio, </p>
            <p>&nbsp;</p>
            <p>Es necesario distribuir los siguiente productos promocionales que fueron aprobados en las siguientes ordenes:</p>
            <table border=''1'' style=''width:25%; padding:0px; border-spacing:0px;'' align="center"> 
            <tr BGCOLOR=''lightgrey''> <th  style="text-align: center;"><strong> #TRANSACCI&Oacute;N </strong></th> </tr>
            <tr> <td ALIGN=CENTER >'||P_IDINVERSION||'-'||P_GRUPODISTRIBUCION||' </td> </tr> </table>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p> Ingresar al siguiente <a href = "'||v_link||'">link</a> </p>
            <p>Descripci&oacute;n: Id:'||P_IDINVERSION||' '||v_nombre||' </p>
            <p>Ultimo usuario aprobador : '|| v_aprobador||' </p>
            <p>Gracias por su atenci&oacute;n </p>
                                            <p>Saludos Cordiales </p>
                                            <p>Portal de Inversiones Comerciales </p>';
        
        PK_CORP_CORREO.SP_ENVIO(
                    P_MODULO => 'ICOM',
                    P_TO => v_correo,
                    P_FROM => 'infocomercial@zaimella.com',
                    P_SUBJECT => v_asunto,
                    P_BODY => V_OBJETO_DES
                  );
    END SP_correoAprobarDist_Prod_Rega;
    
    /*Procedimiento que actuliza el canal y valor VA en la APROBACIoN*/
    PROCEDURE SP_GuardaDis_ProductoRegalo ( P_IDINVERSION NUMBER, P_IDZONA VARCHAR2, P_CODIGOREGALO VARCHAR2 , 
        P_VALOR NUMBER, P_CANAL NCHAR) AS
    BEGIN
        --guardo los valores en la distribucion
        update t_icom_productodistribucion 
        set valorva = p_valor, canal = p_canal
        where idinversion = p_idinversion
        and codigoregalo = p_codigoregalo
        and codigopdv in ( select codigopdv from data.vt_icom_productodistribucion
                            where idinversion = p_idinversion
                            and codigoregalo = p_codigoregalo
                            and idzona = p_idzona );
                            
    END SP_GuardaDis_ProductoRegalo ;
    
    /*Procedimiento que sube los datos de excel al proceso gestion de muestras*/
    PROCEDURE SP_subriGestionMuestra (P_IDINVERSION NUMBER) AS
        v_cuenta number ;
        v_codigosPdv varchar2(250);
        v_todos number;
    BEGIN
        --busca si la inversion tiene marcado como todos los productos
        v_todos := PK_ICOM_COMMONS.F_PRODUCTO_TODOS(P_IDINVERSION);
        
        --Validar codigo de producto exista
        select count(1) into v_cuenta 
        from  DATA.VT_APEX_EXCEL e
        where not exists ( select codigoproducto from data.t_icom_inversion_producto p 
                           where p.idinversion = p_idinversion and TRIM(C12)=P.CODIGOPRODUCTO  AND P.TIPO = 1 );
        
        /*
        Se quita validacion Solicitado por SU 08/04/2024
        IF(nvl(v_cuenta,0) > 0 and v_todos != 1 ) THEN
            RAISE_APPLICATION_ERROR(-20000, 'Existen productos que no se encuentran en la inversi?n');
        END IF;    
        */
        v_cuenta := 0 ;
        --Validar que codigo PDV exista
        select LISTAGG(TRIM(C05), '; ') WITHIN GROUP (ORDER BY TRIM(C05) ), count(1)  into v_codigosPdv, v_cuenta  
        from  DATA.VT_APEX_EXCEL e
        where TRIM(C05) is not null and not exists ( select 1 from data.t_trad_clientelocal c
                           where TRIM(C05) = C.CODIGOPDV and c.matriz = 1 );
        
        IF(nvl(v_cuenta,0) > 0) THEN
            RAISE_APPLICATION_ERROR(-20000, 'Existen codigos de PDV '||v_codigosPdv||' que no existen en la herramienta.');
        END IF;
        
        --borra los datos anteriores
        delete from T_ICOM_PRODUCTOMUESTRA
        where idinversion = P_IDINVERSION  AND ESTADO=0; 
        
        --Inserta los datos del excel en la tabla
        insert into T_ICOM_PRODUCTOMUESTRA
        (IDINVERSION, PERSONA_O, PERSONA_I, PERSONA_C, CODIGOPDV, ZONA, PROVINCIA, 
         CIUDAD, DIRECCION, TELEFONO, TELEFONO2, CODIGOPRODUCTO, CANTIDAD, ESTADO)
         SELECT P_IDINVERSION,  UPPER(TRIM(C02)), UPPER(TRIM(C03)),  UPPER(TRIM(C04)), TRIM(C05), UPPER(TRIM(C06)), UPPER(TRIM(C07)), 
                UPPER(TRIM(C08)), UPPER(TRIM(C09)), TRIM(C10), TRIM(C11), TRIM(C12), ROUND(REPLACE(C14, '.', ','),2), 0
            FROM DATA.VT_APEX_EXCEL  E
            WHERE /*TRIM(C05) IS NOT NULL AND*/ TRIM(C12) IS NOT NULL AND TRIM(C14) IS NOT NULL ;
            
    END SP_subriGestionMuestra;
    
    /*Procedimiento para enviar a ruta de aprobacion el proceso gestion de muestras */
    PROCEDURE SP_GestionMuestraEnviar(P_IDINVERSION NUMBER, P_USUARIO VARCHAR2, P_COMPANIA VARCHAR,P_FECHA_ACTIVIDAD DATE DEFAULT NULL,P_FECHA_ACTIVIDAD_FIN DATE DEFAULT NULL) AS
     V_OBJETO VARCHAR(100):='PROCESO_PRODUCTO_MUESTRA';
     V_EXITO NUMBER;
     v_cuenta number;
    BEGIN 
        
        --Envia a ruta
        DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJOENVIAR(
            p_id=>P_IDINVERSION,
            p_objeto=>V_OBJETO,
            p_objetodescripcion=> '',
            p_usuario=>P_USUARIO,
            p_modulo=>G_MODULO,
            p_compania=>P_COMPANIA,
            P_ETAPA => 'PROCESO_PRODUCTO_MUESTRA',
            P_TIPO1 =>'PROCESO_OPERATIVO',
            P_TIPO2 =>'DISTRIBUCION_DE_MUESTRAS',
            p_exito=>V_EXITO);
            
        IF(V_EXITO=0) THEN
            RAISE_APPLICATION_ERROR(-20100, DATA.PK_CORP_FLUJOAPROBACION.G_MENSAJE);
        END IF;    
        --Actualiza el porcentaje del proceso operativo     
        update data.t_icom_inversion_proceso
            set porcentaje = 50
            where idinversion = p_idinversion and idproceso = 11  and estado = 1 ;
        --Actualizar el estado de los productos de muestra    
        update data.t_icom_productomuestra
        set estado = 2, fecha_actividad = P_FECHA_ACTIVIDAD, fecha_actividad_fin = P_FECHA_ACTIVIDAD_FIN
        where idinversion = p_idinversion and estado=0 ;
        
    END SP_GestionMuestraEnviar;
    
    /*Procedimiento para aprobar/rechar el proceso de gestion muestra*/
    PROCEDURE SP_GestionMuestraAprobar(P_IDINVERSION NUMBER, 
        P_TIPO NUMBER, P_USUARIO VARCHAR2, P_COMPANIA VARCHAR, P_ORDENVENTA in out VARCHAR2 ) AS
        v_idflujo NUMBER;
    BEGIN 
        /*Se verifica de que tipo es*/
        if (p_tipo = 1) then --es aprobacion
           
           --Actualiza el porcentaje del proceso operativo     
           update data.t_icom_inversion_proceso
               set porcentaje = 75--, fechafin = sysdate
               where idinversion = p_idinversion and idproceso = 11  and estado = 1 ;
            BEGIN
            
            SP_CREARORDENAUTOCONSUMOMUESTRAS(P_IDINVERSION => P_IDINVERSION );  
           
            exception when others then
                ROLLBACK;
                SELECT max(ID) INTO  v_idflujo
                FROM t_flujo_aprobacion_cab WHERE entidad_id=P_IDINVERSION AND ENTIDAD_CLASE='PROCESO_PRODUCTO_MUESTRA';

                update t_flujo_aprobacion_cab set estado='EN_PROCESO', FECHA_FIN=NULL  WHERE ID=v_idflujo;
                UPDATE t_flujo_aprobacion_DET SET estado='EN_PROCESO', FECHA_HASTA=NULL WHERE FLUJO_ID=v_idflujo AND USERID=P_USUARIO;
                
                COMMIT; 
--                RAISE_APPLICATION_ERROR(-20100,SQLERRM);
                RAISE;
            END;
           --Actualizar el estado de los productos de muestra   
           
           SELECT 'VA-'||ORDENVENTA INTO P_ORDENVENTA FROM t_icom_productomuestra where idinversion = p_idinversion and estado=2 AND ROWNUM=1;

           update data.t_icom_productomuestra
           set estado = 1
           where idinversion = p_idinversion and estado=2 ;
        
        else -- es rechazo
           
           --Actualiza el porcentaje del proceso operativo     
       /*    update data.t_icom_inversion_proceso
               set porcentaje = 0
               where idinversion = p_idinversion and idproceso = 11  and estado = 1 ;*/
           --Actualizar el estado de los productos de muestra    
            update data.t_icom_productomuestra
            set estado = 0 
            where idinversion = p_idinversion  AND ESTADO=2;    
               
        end if;
    END SP_GestionMuestraAprobar;
    
    /* Procedimiento que envia el correo de aprobacion del proceso gestion muestra */
    PROCEDURE SP_correoAprobarGestionMuestra (P_IDINVERSION NUMBER, P_ORDENVENTA VARCHAR2, P_USUARIO VARCHAR2, P_COMPANIA VARCHAR ) AS
        v_cuenta number;
        v_link varchar2(500) ;        
        v_correo varchar2(100);
        v_asunto  VARCHAR2(100);
        V_OBJETO_DES clob :='';
        v_nombre data.t_icom_inversiones.nombre%type;
        v_aprobador varchar2(500) ;  
    
    BEGIN
    
        --valido 
        /*select count(1) into v_cuenta
        from data.t_icom_productomuestra
        where idinversion = p_idinversion
        and ordenventa is null ;
        
        IF(nvl(v_cuenta,0) > 0) THEN
            RAISE_APPLICATION_ERROR(-20000, 'No esta ingresada el nomero de orden de venta.');
        END IF;*/
        
        --Genero los datos para enviar el correo 
        Select nombre into v_nombre from data.t_icom_inversiones where id = p_idinversion ;
        
        --busco el nombre del ultimo aprobador 
        select Upper(nombres||' '||apellidos) INTO v_aprobador from data.vt_corp_usuario where nombreusuario = P_USUARIO ;
        
        --busco el link de la pagina    
        begin
             v_link :=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '26', P_COMPANIA,'','','1');
        exception when no_data_found then
            v_link := '';
        end;
        
        v_link := APEX_UTIL.PREPARE_URL(p_url => v_link||'P609_ID,P609_EDITAR,P609_ESTADO:'||P_IDINVERSION||',0,1' ) ;
        
        --busco el correo a enviar
        begin
            select vp.notificacion_imp into v_correo 
            FROM data.vt_icom_proceso vp 
            where idproceso = 11 and notificacion_imp is not null ;
        exception when no_data_found then
            v_correo := '';
        end;
        
        v_asunto := 'Aprobacion Proceso Gestion Muestra';
               
        --FORMATO APROBACIoN 
        V_OBJETO_DES := '<p>Estimado(a) Usuaio, </p>
            <p>&nbsp;</p>
            <p>Es necesario distribuir las siguientes muestras que fueron aprobados en las siguientes ordenes:</p>
            <table border=''1'' style=''width:100%; padding:0px; border-spacing:0px;''> 
            <tr BGCOLOR=''lightgrey''> <th  ALIGN=CENTER width=''25%''><strong> #TRANSACCI&Oacute;N </strong></th> </tr>
            <tr> <td ALIGN=CENTER >'||P_ORDENVENTA||' </td> </tr> </table>
            <p>&nbsp;</p>
            <p> Ingresar al siguiente <a href = "'||v_link||'">link</a> </p>
            <p>Descripci&oacute;n: Id:'||P_IDINVERSION||' '||v_nombre||' </p>
            <p>Solicitante : '|| v_aprobador||' </p>
            <p>Gracias por su atenci&oacute;n </p>
                                            <p>Saludos Cordiales </p>
                                            <p>Portal de Inversiones Comerciales </p>';
        
        PK_CORP_CORREO.SP_ENVIO(
                    P_MODULO => 'ICOM',
                    P_TO => v_correo,
                    P_FROM => 'infocomercial@zaimella.com',
                    P_SUBJECT => v_asunto,
                    P_BODY => V_OBJETO_DES
                  );
    END SP_correoAprobarGestionMuestra;
    
    /*Procedimiento que actuliza la orden de comapra y el canal en la APROBACIoN de gestion muestra */
    PROCEDURE SP_GuardaGestionMuestra ( P_IDINVERSION NUMBER, P_CODIGOPRODUCTO VARCHAR2 default null , 
        P_ORDENVENTA VARCHAR2, P_CANAL NCHAR default null ) AS
    BEGIN
        --guardo los valores en la tabla 
        if ( p_ordenventa is not null and p_codigoproducto is null  ) then
            update t_icom_productomuestra 
            set ordenventa = p_ordenventa
            where idinversion = p_idinversion AND ESTADO=2 ;
        elsif ( p_ordenventa is null and p_codigoproducto is not null  ) then    
            update t_icom_productomuestra 
            set canal = p_canal 
            where idinversion = p_idinversion and codigoproducto = p_codigoproducto  AND ESTADO=2  ;
        elsif ( p_ordenventa is not null and p_codigoproducto is not null) then    
            update t_icom_productomuestra 
            set canal = case when codigoproducto like p_codigoproducto then p_canal else canal end, 
                ordenventa = p_ordenventa
            where idinversion = p_idinversion AND ESTADO=2  ;    
        end if;
                            
    END SP_GuardaGestionMuestra;
    
     /*AGREGA REGISTROS DE DESCUENTO A TRAVEZ DE UN EXCEL Y VALIDA CADA REGISTRO
     TIPO ->  CLIENTE/ GRUPO (1/2) 
     SP_DESCUENTO_AGREGAR(P_TIPO =>P_TIPO, P_USUARIO =>P_USUARIO, P_COMPANIA =>P_COMPANIA
     )*/
     PROCEDURE SP_DESCUENTO_AGREGAR(P_TIPO NUMBER, P_USUARIO VARCHAR2, P_COMPANIA VARCHAR)
     AS
     BEGIN 
        DELETE T_ICOM_PRODUCTO_DESCUENTO_FEC WHERE GRUPO IS NULL;
        
        IF(P_TIPO='1') THEN
            INSERT INTO T_ICOM_PRODUCTO_DESCUENTO_FEC (
            FILA, idinversion,    codigocliente, CODIGOGRUPO,   codigoproducto, UNIDAD,    numero,
            grupo,    fechainicio,    fechafin,    descuento,    estado, 
            auditoriausuario,    auditoriafecha )
           SELECT C01, C02 Idinversion,	C07 codigocliente,CODIGOGRUPO,	 C12 codigoproducto,UNIDADPRINCIPAL ,
           C16 NUMERO,    NULL GRUPO,  
           decode(trim(C21), null, null, to_date(C21, 'YYYY-MM-DD')) Fecha_Neg_Inicio,
           decode(trim(C22),null, null, to_date(C22, 'YYYY-MM-DD')) Fecha_Neg_Fin,
           NVL(ROUND(REPLACE(C23, '.', ','),4),0), NULL,
           P_USUARIO, SYSDATE   FROM  DATA.VT_APEX_EXCEL 
           LEFT JOIN VT_GZM_CLIENTE C ON (C.CODIGOCLIENTE=C07)
           LEFT JOIN VT_GZM_PRODUCTO P ON (P.CODIGOPRODUCTO=C12)
           WHERE TRIM(C02) IS NOT NULL
           
           ;

        ELSE 
            INSERT INTO T_ICOM_PRODUCTO_DESCUENTO_FEC (
            FILA, idinversion,    codigocliente,  CODIGOGRUPO,  codigoproducto, UNIDAD,    numero,
            grupo,    fechainicio,    fechafin,    descuento,    estado, 
            auditoriausuario,    auditoriafecha )
           SELECT C01, C02 Idinversion,	CODIGOCLIENTE,CODIGOGRUPO,	 C10 Codigo_producto, UNIDADPRINCIPAL, C14 NUMERO,
           NULL GRUPO, /*C06 Producto,*/ 
           decode(trim(C19), null, null, to_date(C19, 'YYYY-MM-DD')) Fecha_Neg_Inicio,
           decode(trim(C20),null, null, to_date(C20, 'YYYY-MM-DD')) Fecha_Neg_Fin,
           NVL(ROUND(REPLACE(C21, '.', ','),4),0)   Descuento_Calculado, NULL,
           P_USUARIO, SYSDATE
           FROM  DATA.VT_APEX_EXCEL 
           LEFT JOIN t_icom_inversion_cliente ON (IDINVERSION=C02 AND CODIGOGRUPO=C05)
           LEFT JOIN VT_GZM_PRODUCTO P ON (P.CODIGOPRODUCTO=C10)
           WHERE TRIM(C02) IS NOT NULL;
        END IF;
        
        --- ACTULIZA ESTADO -1 A LA INFORMACION QUE NO EXISTE LAS INVERSIONES. 
        UPDATE T_ICOM_PRODUCTO_DESCUENTO_FEC DF SET ESTADO=-1
        WHERE GRUPO IS NULL AND NOT EXISTS (SELECT 1 FROM 
        VT_ICOM_INVERSION_DESCUENTO_FECHAS D WHERE --D.ESTADO IS NULL
        --AND 
        D.IDINVERSION=DF.IDINVERSION AND D.CODIGOPRODUCTO=DF.CODIGOPRODUCTO 
                                    AND D.CODIGOCLIENTE=DF.CODIGOCLIENTE);
                                    
        --- ACTUALIZA ESTADO -2 DATOS REPETIDOS
        UPDATE T_ICOM_PRODUCTO_DESCUENTO_FEC DF SET ESTADO=-2
        WHERE GRUPO IS NULL AND ESTADO IS NULL AND EXISTS (
        SELECT 1 FROM T_ICOM_PRODUCTO_DESCUENTO_FEC DF2 WHERE DF.ROWID<>DF2.ROWID
        AND  DF.CODIGOPRODUCTO=DF2.CODIGOPRODUCTO AND DF.CODIGOCLIENTE=DF2.CODIGOCLIENTE 
            AND DF2.GRUPO IS NULL AND DF2.ESTADO IS NULL
            AND (DF.fechainicio BETWEEN DF2.fechainicio AND DF2.fechafin OR 
                    DF.fechafin BETWEEN DF2.fechainicio AND DF2.fechafin ));   
        
         -- ACTUALIZO ESTADO -3 DESCUENTO INCORRECTO
         UPDATE T_ICOM_PRODUCTO_DESCUENTO_FEC DF
        SET ESTADO=-3
        WHERE GRUPO IS NULL AND ESTADO IS NULL AND EXISTS (SELECT 1 FROM 
        VT_ICOM_INVERSION_DESCUENTO_FECHAS D WHERE D.ESTADO IS NULL
        AND D.IDINVERSION=DF.IDINVERSION AND D.CODIGOPRODUCTO=DF.CODIGOPRODUCTO 
                                    AND D.CODIGOCLIENTE=DF.CODIGOCLIENTE AND DF.DESCUENTO>ROUND(D.DESCUENTO_CALCULADO,4) );
                                    
        -- ACTUALIZO ESTADO -4 FECHAS INCORRECTO
         UPDATE T_ICOM_PRODUCTO_DESCUENTO_FEC DF SET ESTADO=-4
        WHERE GRUPO IS NULL AND ESTADO IS NULL AND (TRUNC(FECHAINICIO) < TRUNC(SYSDATE) OR TRUNC(FECHAINICIO)>TRUNC(FECHAFIN)) ;
        
        -- ACTUALIZO ESTADO -5 A LOS DESCUENTOS QUE YA ESTAN VALIDOS EN JDE.
        UPDATE T_ICOM_PRODUCTO_DESCUENTO_FEC DF SET ESTADO=-5
        WHERE GRUPO IS NULL AND ESTADO IS NULL AND EXISTS (SELECT 1 FROM 
        VT_ICOM_DESCUENTOS_ACTIVOS D WHERE D.CODIGOPRODUCTO=DF.CODIGOPRODUCTO  AND D.CODIGOCLIENTE=DF.CODIGOCLIENTE
        AND ((D.FECHADESDE BETWEEN DF.fechainicio AND DF.fechafin OR 
        D.FECHAHASTA BETWEEN DF.fechainicio AND DF.fechafin) --- FECHAS JDE VS SISTEMA
        OR (DF.fechainicio BETWEEN D.FECHADESDE AND D.FECHAHASTA OR 
            DF.fechafin BETWEEN D.FECHADESDE AND D.FECHAHASTA) --- SISTEMAS  VS JDE
        )
        );
         
        ---ACTUALIZO ESTADO=1  Y EL NUMERO DE LOS REGISTROS CORRECTOS.
        UPDATE T_ICOM_PRODUCTO_DESCUENTO_FEC DF
        SET  ESTADO=1
        WHERE GRUPO IS NULL AND ESTADO IS NULL AND EXISTS (SELECT 1 FROM 
        VT_ICOM_INVERSION_DESCUENTO_FECHAS D WHERE /*D.ESTADO IS NULL
        AND*/ D.IDINVERSION=DF.IDINVERSION AND D.CODIGOPRODUCTO=DF.CODIGOPRODUCTO 
                                    AND D.CODIGOCLIENTE=DF.CODIGOCLIENTE and d.NUMERO=df.NUMERO);
        
     END SP_DESCUENTO_AGREGAR;  
    
    /*ENVIAR APROBAR LOS DESCUENTOS
    SP_DESCUENTO_ENVIAR(P_USUARIO =>P_USUARIO, P_COMPANIA =>P_COMPANIA);
    */ 
    PROCEDURE SP_DESCUENTO_ENVIAR(P_USUARIO VARCHAR2, P_COMPANIA VARCHAR)
    AS
    V_GRUPO NUMBER;
    V_EXITO NUMBER;

    BEGIN 
        
        V_GRUPO := DATA.PK_COMMONS.F_SECUENCIA ('VT_ICOM_PRODUCTO_DESCUENTO_FECHAS');
        
        DELETE T_ICOM_PRODUCTO_DESCUENTO_FEC where grupo is null and estado<0;
        
        FOR I IN(select CODIGO_GRUPO, CLIENTE_GRUPO from VT_ICOM_PRODUCTO_DESCUENTO_FECHAS 
                        where grupo is null and estado IN (0,1) GROUP BY CODIGO_GRUPO, CLIENTE_GRUPO) LOOP
        
              DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJOENVIAR(
                p_id=>I.CODIGO_GRUPO||'-'||V_GRUPO,
                p_objeto=>'PARAMETRIZACION_DESCUENTO',
                p_objetodescripcion=> 'PARAMETRIZACION DESCUENTO CLIENTE: '||I.CLIENTE_GRUPO,
                p_usuario=>P_USUARIO,
                p_modulo=>G_MODULO,
                p_compania=>P_COMPANIA,
                P_ETAPA => 'PROCESO_PARAMETRIZACION_DESCUENTO',
                P_TIPO1 =>'PROCESO_OPERATIVO',
                P_TIPO2 =>'PARAMETRIZACION_DE_DESCUENTOS',
                P_TIPO3 =>I.CODIGO_GRUPO,
                p_exito=>V_EXITO);
            
            IF(V_EXITO=0) THEN
               -- RAISE_APPLICATION_ERROR(-20100, DATA.PK_CORP_FLUJOAPROBACION.G_MENSAJE);
               -- NO SE ENVIO A RUTA DE APROBACION
               UPDATE T_ICOM_PRODUCTO_DESCUENTO_FEC DF SET ESTADO=0, OBSERVACION= DATA.PK_CORP_FLUJOAPROBACION.G_MENSAJE
               where grupo is null and estado IN (0,1)  AND DF.CODIGOGRUPO=I.CODIGO_GRUPO ; 
            ELSE 
            
                 --- ACTUALIZO ESTADO DEL PROCESO 
               UPDATE  DATA.t_icom_inversion_proceso SET PORCENTAJE=25
               WHERE IDINVERSION IN (SELECT DISTINCT IDINVERSION FROM T_ICOM_PRODUCTO_DESCUENTO_FEC DF
               where grupo is null and estado IN (0,1)  AND DF.CODIGOGRUPO=I.CODIGO_GRUPO) 
               AND IDPROCESO=1 and NVL(PORCENTAJE,0)=0;
                 
               UPDATE T_ICOM_PRODUCTO_DESCUENTO_FEC DF SET ESTADO=2, GRUPO=V_GRUPO, OBSERVACION=NULL
               where grupo is null and estado IN (0,1)  AND DF.CODIGOGRUPO=I.CODIGO_GRUPO;
               
             
            END IF;    
        END LOOP;
        
    END SP_DESCUENTO_ENVIAR;
    
    /*APROBAR O RECHAZAR LOS DESCUENTOS
    SP_DESCUENTO_APROBAR(P_ESTADO =>P_ESTADO, P_GRUPO =>P_GRUPO, P_CODIGOGRUPO =>P_CODIGOGRUPO, 
    P_USUARIO =>P_USUARIO,  P_COMENTARIO =>P_COMENTARIO, P_COMPANIA =>P_COMPANIA)
    */
    PROCEDURE SP_DESCUENTO_APROBAR(P_ESTADO NUMBER, P_GRUPO NUMBER, P_CODIGOGRUPO VARCHAR, P_USUARIO VARCHAR2,
    P_COMENTARIO CLOB, P_COMPANIA VARCHAR) AS
    v_GRUPO_DESCUENTO 			VARCHAR(20);
    v_exito 			number;
    v_CONTADOR 			number;
    v_SECUENCIAL		number;
    v_termino 			number;
    V_OBJETO VARCHAR(50):= 'PARAMETRIZACION_DESCUENTO';
    BEGIN 
        
        IF(P_ESTADO=1) THEN  --APROBAR
       
             pk_corp_flujoaprobacion.sp_flujoaprobar(
					 p_id 					=>P_CODIGOGRUPO||'-'||P_GRUPO
					, p_objeto				=> V_OBJETO
                    ,P_ORDENMONTO => NULL
                    ,P_USUARIOFLUJO=>P_USUARIO
					, p_usuario				=> P_USUARIO
					, p_comentario			=> P_COMENTARIO
					, p_modulo				=> G_MODULO
					, p_compania			=> P_COMPANIA
					, p_exito				=> v_exito
					, p_terminoflujo		=> v_termino);  
                    
            IF(v_exito=0) THEN 
                raise_application_error(-20000,pk_corp_flujoaprobacion.G_MENSAJE);
            END IF;
        
            IF v_termino = 1 THEN
            
               select CODIGOORIGEN INTO  v_GRUPO_DESCUENTO 
               from vt_gzm_cliente where codigocliente=P_CODIGOGRUPO;
               
               v_GRUPO_DESCUENTO:= CASE WHEN v_GRUPO_DESCUENTO='EXT' THEN 'DCTOEXP1' ELSE 'DESCTOST' END;
               
               UPDATE T_ICOM_PRODUCTO_DESCUENTO_FEC DF SET ESTADO=3
               where grupo=P_GRUPO and estado=2 AND  DF.CODIGOGRUPO=P_CODIGOGRUPO;
               
                 --- ACTUALIZO ESTADO DEL PROCESO 
               UPDATE  DATA.t_icom_inversion_proceso SET PORCENTAJE=50
               WHERE IDINVERSION IN (SELECT DISTINCT IDINVERSION FROM T_ICOM_PRODUCTO_DESCUENTO_FEC DF
               where grupo=P_GRUPO and estado=2 AND  DF.CODIGOGRUPO=P_CODIGOGRUPO) 
               AND IDPROCESO=1;
               
               SELECT CASE WHEN EXISTS ( SELECT 1 FROM DATA.T_ICOM_PRODUCTO_DESCUENTO P WHERE P.CODIGOGRUPO = P_CODIGOGRUPO
                          AND P.IDINVERSION IN ( SELECT DF.IDINVERSION FROM DATA.T_ICOM_PRODUCTO_DESCUENTO_FEC DF 
                                                 WHERE DF.ESTADO = 3 AND DF.GRUPO = P_GRUPO AND DF.CODIGOGRUPO = P_CODIGOGRUPO )
                          AND NOT EXISTS ( SELECT 1 FROM DATA.T_ICOM_PRODUCTO_DESCUENTO_FEC DF2 WHERE DF2.IDINVERSION = P.IDINVERSION
                                             AND DF2.CODIGOGRUPO = P_CODIGOGRUPO AND DF2.ESTADO = 3 
                                             AND DF2.CODIGOPRODUCTO = P.CODIGOPRODUCTO)
                        ) THEN 1
                            ELSE 0 END AS HAY_PENDIENTES
                into v_exito
                FROM DUAL;
                if v_exito = 0 then 
                    --todos los productos ya tienen la aprobacion del descuento
                    UPDATE  DATA.t_icom_inversion_proceso SET PORCENTAJE=100
                    WHERE IDINVERSION IN (SELECT DISTINCT IDINVERSION FROM T_ICOM_PRODUCTO_DESCUENTO_FEC DF
                    where grupo=P_GRUPO and estado=3 AND  DF.CODIGOGRUPO=P_CODIGOGRUPO) 
                    AND IDPROCESO=1;
                end if ;
                COMMIT;
              
               ---VALIDA QUE NO EXISTAN LOS DESCUENTOS EN JDE
                UPDATE T_ICOM_PRODUCTO_DESCUENTO_FEC DF SET OBSERVACION='LOS DESCUENTOS EXISTEN EN JDE'
                WHERE GRUPO=P_GRUPO  AND  DF.CODIGOGRUPO=P_CODIGOGRUPO AND ESTADO=3 AND EXISTS (SELECT 1 FROM 
                VT_ICOM_DESCUENTOS_ACTIVOS D WHERE D.CODIGOPRODUCTO=DF.CODIGOPRODUCTO  AND D.CODIGOCLIENTE=DF.CODIGOCLIENTE
                AND ((D.FECHADESDE BETWEEN DF.fechainicio AND DF.fechafin OR 
                    D.FECHAHASTA BETWEEN DF.fechainicio AND DF.fechafin) --- FECHAS JDE VS SISTEMA
                    OR (DF.fechainicio BETWEEN D.FECHADESDE AND D.FECHAHASTA OR 
                        DF.fechafin BETWEEN D.FECHADESDE AND D.FECHAHASTA) --- SISTEMAS  VS JDE
                    ));
                
                SELECT  COUNT(1) INTO v_CONTADOR FROM T_ICOM_PRODUCTO_DESCUENTO_FEC df
                WHERE GRUPO=P_GRUPO  AND  DF.CODIGOGRUPO=P_CODIGOGRUPO AND ESTADO=3 AND EXISTS (SELECT 1 FROM 
                VT_ICOM_DESCUENTOS_ACTIVOS D WHERE D.CODIGOPRODUCTO=DF.CODIGOPRODUCTO  
                AND D.CODIGOCLIENTE=DF.CODIGOCLIENTE AND        
                ((D.FECHADESDE BETWEEN DF.fechainicio AND DF.fechafin OR 
                    D.FECHAHASTA BETWEEN DF.fechainicio AND DF.fechafin) --- FECHAS JDE VS SISTEMA
                    OR (DF.fechainicio BETWEEN D.FECHADESDE AND D.FECHAHASTA OR 
                        DF.fechafin BETWEEN D.FECHADESDE AND D.FECHAHASTA) --- SISTEMAS  VS JDE
                    ));
                
                IF(v_CONTADOR>0) THEN                 
                    raise_application_error(-20000,'Existe descuentos vigentes para el cliente: '||P_CODIGOGRUPO);
                END IF;
                
                SELECT MAX(ADATID) INTO v_SECUENCIAL FROM F4072@JDEDTADL;
                 ---INGRESAR EN JDE LOS DESUENTOS p4072|zjde0001 DESCTOST
                INSERT INTO F4072@JDEDTADL 
                (ADAST, ADITM, ADLITM, ADAITM, ADAN8, ADIGID, 
                ADCGID, ADOGID, ADCRCD, ADUOM, ADMNQ, ADEFTJ, ADEXDJ, 
                ADBSCD, ADLEDG, ADFRMN, ADFVTR, ADFGY, ADATID, ADURCD,
                ADURDT, ADURAT, ADURAB, ADURRF, ADNBRORD, ADUOMVID,
                ADFVUM, ADPARTFG, ADAPRS, ADUSER, ADPID, ADJOBN, 
                ADUPMJ, ADTDAY, ADBKTPID, ADCRCDVID, ADRULENAME)  
                (SELECT  v_GRUPO_DESCUENTO ADAST, IMITM ADITM,IMLITM ADLITM,IMAITM ADAITM, CODIGOCLIENTE ADAN8, '0' ADIGID,
                '0' ADCGID, '0' ADOGID,'USD' ADCRCD,IMUOM1 ADUOM, '100000000' ADMNQ, TO_CHAR(FECHAINICIO,'YYYYDDD')-1900000 ADEFTJ, TO_CHAR(FECHAFIN,'YYYYDDD')-1900000 ADEXDJ ,
                '1' ADBSCD,'  ' ADLEDG,'          ' ADFRMN, DESCUENTO*-10000 ADFVTR ,'N' ADFGY, v_SECUENCIAL+ROWNUM ADATID,'  ' ADURCD,
                '0' ADURDT, '0' ADURAT, '0' ADURAB,'               ' ADURRF, '0' ADNBRORD,'  ' ADUOMVID,
                '  ' ADFVUM,'1' ADPARTFG,' ' ADAPRS,'ICOM ' ADUSER,'EP4072    ' ADPID,'WEBSERVERJ' ADJOBN, 
                TO_CHAR(AUDITORIAFECHA,'YYYYDDD')-1900000  ADUPMJ, '205548'ADTDAY, '0' ADBKTPID,'   ' ADCRCDVID,'          ' ADRULENAME
                FROM T_ICOM_PRODUCTO_DESCUENTO_FEC 
                INNER JOIN F4101@JDEDTADL ON (TRIM(IMLITM)=CODIGOPRODUCTO)
                where grupo=P_GRUPO AND  CODIGOGRUPO=P_CODIGOGRUPO);
                
                --- INGRESO RELACION DESCUENTO CON ID INVERSION 
                /*ALTER TABLE T_ICOM_PRODUCTO_DESCUENTO_FEC 
                RENAME TO T_ICOM_PRODUCTO_DESCUENTO_FEC;*/
                INSERT INTO F554072A@JDEDTADL 
                (ADAST, ADITM, ADLITM, ADAITM, ADAN8, ADIGID, ADCGID, ADOGID, ADCRCD, ADUOM, ADMNQ, 
                ADEXDJ, ADUPMJ, ADTDAY, ADPFN1, ADPFN2, ADPFN3, ADPFN4, ADPFN5, ADPFN6)
                SELECT  v_GRUPO_DESCUENTO ADAST, IMITM ADITM,IMLITM ADLITM,IMAITM ADAITM, CODIGOCLIENTE ADAN8, '0' ADIGID,
                '0' ADCGID, '0' ADOGID,'USD' ADCRCD,IMUOM1 ADUOM, '100000000' ADMNQ, 
                TO_CHAR(FECHAFIN,'YYYYDDD')-1900000 ADEXDJ , 
                TO_CHAR(AUDITORIAFECHA,'YYYYDDD')-1900000  ADUPMJ, '205548'ADTDAY, 
                IDINVERSION ADPFN1, '0' ADPFN2, '0' ADPFN3, '0' ADPFN4, '0' ADPFN5, '0' ADPFN6
                FROM T_ICOM_PRODUCTO_DESCUENTO_FEC 
                INNER JOIN F4101@JDEDTADL ON (TRIM(IMLITM)=CODIGOPRODUCTO)
                where grupo=P_GRUPO AND  CODIGOGRUPO=P_CODIGOGRUPO;
                -- LAS CONSULTAS DE LOS DESCUENTOS APLICADOS SE PUEDE CONSULTAR EN LA TABLA SELECT * FROM  	F4074@JDEDTADL WHERE ALDCTO='VN' AND ALDOCO>=23104188; 
           
           end if; 
           
        ELSE    --RECHAZAR
             PK_CORP_FLUJOAPROBACION.SP_FLUJORECHAZAR(
              	p_id 					=> P_CODIGOGRUPO||'-'||P_GRUPO,
                p_objeto				=> V_OBJETO,
                P_USUARIOFLUJO          =>P_USUARIO,
                p_usuario				=> P_USUARIO,
                P_COMENTARIO            => P_COMENTARIO,
                P_MODULO                => G_MODULO, 
                P_COMPANIA              => P_COMPANIA,
                P_EXITO                 => v_exito
            );     
            IF(v_exito=0) THEN 
                raise_application_error(-20000,pk_corp_flujoaprobacion.G_MENSAJE);
            END IF;
                
            DELETE T_ICOM_PRODUCTO_DESCUENTO_FEC DF 
            where grupo=P_GRUPO and estado=2 AND  DF.CODIGOGRUPO=P_CODIGOGRUPO;
        END IF;
    
    END SP_DESCUENTO_APROBAR;    

    function f_validatotaldistribucion(P_CANTIDADDISTRIBUCION number,P_IDINVERSION number,P_CODIGOPRODUCTO varchar2,P_CODIGOREGALO varchar2) return number as
--          declare P_CANTIDADDISTRIBUCION number:=30; P_IDINVERSION number:=21389; P_CODIGOPRODUCTO varchar2(29):='188400A50'; P_CODIGOREGALO varchar2(29):='488D000110';
        v_cantidad number;
        v_cantidaddistribucion number;
        v_retorno number;
    begin
        begin
            select  SUM(nvl(CAB.BULTOAJUSTADO * CANTIDAD,0)) into 
            v_cantidad
            from vt_icom_productodistribucion CAB
            where cab.IDINVERSION = P_IDINVERSION  and CODIGOPRODUCTO= P_CODIGOPRODUCTO  and CODIGOREGALO= P_CODIGOREGALO
            group by  CAB.CODIGOPRODUCTO,CAB.codigoregalo;
        exception when others then 
            v_cantidad:=0;
        end;
      
        
        begin
            select  sum (nvl(CAB.CANTIDADDISTRIBUCION,0)) cantidaddistribucion into 
            v_cantidaddistribucion
            from t_icom_productodistribuciondet CAB
            where cab.IDINVERSION = P_IDINVERSION  and CODIGOPRODUCTO= P_CODIGOPRODUCTO  and CODIGOREGALO= P_CODIGOREGALO
            group by cab.IDINVERSION,CODIGOPRODUCTO,CODIGOREGALO;
        exception when others then 
            v_cantidaddistribucion:=0;
        end;
        v_cantidaddistribucion:=pk_commons.safe_to_number(v_cantidaddistribucion)+pk_commons.safe_to_number(P_CANTIDADDISTRIBUCION);
          --DBMS_OUTPUT.PUT_LINE('v_cantidad:'||v_cantidad||' -   v_cantidaddistribucion:'||pk_commons.safe_to_number(v_cantidaddistribucion));
        v_retorno :=1;
        if(v_cantidaddistribucion>v_cantidad)then
            v_retorno :=0;
        end if;
        RETURN v_retorno;
        --DBMS_OUTPUT.PUT_LINE(v_retorno);
    end f_validatotaldistribucion;
    
    PROCEDURE sp_crearordenautoconsumo(P_IDINVERSION number, P_GRUPO number) as
--    declare P_IDINVERSION number:=21389; P_GRUPO number:=101;
        V_SHIPTO NUMBER;
        V_SOLDTO NUMBER;
        V_BODEGA VARCHAR(12);
        V_COMPANIA VARCHAR(5);
        V_VERSION VARCHAR(12);
        V_USUARIO VARCHAR(12);
        V_NUMERO NUMBER;
        V_TIPO VARCHAR(10);
        V_EXITO NUMBER;
        V_NOMBRE_INVERSION VARCHAR(3999);
        V_AREA VARCHAR(3999);
        V_IDAREA NUMBER;
        V_USUARIOCREA VARCHAR2(30);  
        V_HTML_BODY clob;
        V_HTML_DETALLE clob;
        v_fechaencuesta date;
        V_CORREO_PARA VARCHAR2(3999);
        V_CORREO_CC VARCHAR2(3999);
        v_cont number;
    BEGIN
        --ejmc:quitar 76097 para pasar a prd
        SELECT /*U.CODERP*/i.usuario, 1 , I.ID||'-'||I.NOMBRE,I.IDAREA,I.COMPANIA  INTO V_USUARIOCREA,V_SHIPTO,V_NOMBRE_INVERSION,V_IDAREA,V_COMPANIA
        FROM vt_corp_usuario U INNER JOIN T_ICOM_INVERSIONES I ON i.usuario = U.NOMBREUSUARIO WHERE I.ID= P_IDINVERSION;
        
        --- OMAR 
        ---tabla general de la vista se debe agregar una columna mas para ->  solicitante VA PARA LUEGO INSERTARLO EN V_SOLDTO
        --- ESTA LOGICA VA EN SP_CREARORDENAUTOCONSUMOMUESTRAS, SP_CREARORDENAUTOCONSUMO
        --- VALIDACION SI ESTA NULL V_SOLDTO ENVIARLE UN ERROR QUE SE DEBE LLENAR LA TABLA GENERAL
        SELECT AREA_RUTA, SOLICITANTE INTO V_AREA, V_SOLDTO FROM VT_ICOM_AREA WHERE IDAREA=V_IDAREA;

        --SELECT AREA_RUTA INTO V_AREA FROM VT_ICOM_AREA WHERE IDAREA=V_IDAREA;

        IF V_SOLDTO IS NULL THEN
            RAISE_APPLICATION_ERROR(-20000, 'No existe configurado solicitante en tabal general ICOM_AREA, por favor verificar con el administrador');
        END IF;

        SELECT FECHAINIENCUESTA INTO v_fechaencuesta
        FROM T_ICOM_PRODUCTODISTRIBUCIONDET DET 
        where DET.IDINVERSION=P_IDINVERSION and det.grupodistribucion=P_GRUPO and DET.estado=3 AND ROWNUM=1;
    
        V_BODEGA:='       17003';
        V_COMPANIA:=V_COMPANIA;
        V_VERSION:='ERP0020';
        PK_JDE_VENTAS_WS.SP_CREARORDEN_CAB(P_TIPODOCUMENTO=>'EZ',
                                                  P_SHIPTO=>V_SHIPTO,
                                                  P_SOLDTO=>V_SOLDTO,
                                                  P_BODEGA=>V_BODEGA,
                                                  P_COMPANIA=>V_COMPANIA,   
                                                  P_VERSION=>V_VERSION,
                                                  P_HORA_ENTREGA=>'OPERADOR LOGIST'
                                          );
                                          --DBMS_OUTPUT.PUT_LINE('PK_JDE_VENTAS_WS.G_DOCUMENTO'||PK_JDE_VENTAS_WS.G_DOCUMENTO);
         --DETALLE
        FOR PRODUCTO IN (
            SELECT 
                DET.IDINVERSION,DET.GRUPO,DET.CODIGOREGALO CODIGO,SUM(DET.CANTIDADDISTRIBUCION )CANTIDAD , JDP.UNIDADSECUNDARIA UNIDAD, '.'UBICACION
            FROM VT_ICOM_PRODUCTODISTRIBUCIONDET DET INNER JOIN vt_jde_productos JDP ON DET.CODIGOREGALO=JDP.CODIGOPRODUCTO
            where DET.IDINVERSION=P_IDINVERSION and DET.GRUPO=P_GRUPO and DET.estado=3
            group by DET.IDINVERSION,DET.GRUPO,DET.CODIGOREGALO,DET.REGALO, JDP.UNIDADSECUNDARIA
        ) LOOP
                        
           PK_JDE_VENTAS_WS.SP_CREARORDEN_DET(P_PRODUCTO=>PRODUCTO.CODIGO,
                                      P_CANTIDAD=>PRODUCTO.CANTIDAD,  
                                      P_UNIDAD=>PRODUCTO.UNIDAD, 
                                      P_UBICACION=>PRODUCTO.UBICACION, ---NULL .
                                      P_BODEGADESTINO=>V_BODEGA);  --- 17003
        END LOOP;
        --DBMS_OUTPUT.PUT_LINE('PK_JDE_VENTAS_WS.G_TRAMA:');
        PK_JDE_VENTAS_WS.SP_CREARORDEN(P_USUARIO=>V_USUARIO,P_NUMERO=>V_NUMERO,P_TIPO=>V_TIPO,P_EXITO=>V_EXITO);
        --DBMS_OUTPUT.PUT_LINE('v_exito: '||v_exito||':V_TIPO:'||V_TIPO||', V_NUMERO:'||V_NUMERO||'');
        if (v_exito=0)then
            RAISE_APPLICATION_ERROR(-20000, 'hubo un error al generar la orden de autoconsumo, revisar con el administrador del modulo'); 
        end if;
        
        if (V_EXITO=1)then
            ---AGREGAR JUSTIFICACION
            insert into f564310@jdedtadl (iakcoo,iadcto,iadoco,ialnid,ialongmsg)
            VALUES (v_COMPANIA,V_TIPO,V_NUMERO, 0, V_NOMBRE_INVERSION );
            v_cont:=SQL%ROWCOUNT;    --DBMS_OUTPUT.PUT_LINE('Registros afectados:insert into f564310@jdedtadl:'||v_cont);
            
            UPDATE f4211@jdedtadl
            SET SDPRAN8='999', SDOSTP ='DIN',SDSHAN=V_SOLDTO, SDZON=SDSRP1, SDSRP4 =SDSRP4
            where SDDOCO=V_NUMERO and  SDDCTO = V_TIPO;
            v_cont:=SQL%ROWCOUNT;    --DBMS_OUTPUT.PUT_LINE('Registros afectados:UPDATE f4211@jdedtadl:'||v_cont);
                     
            UPDATE data.t_icom_productodistribuciondet pd
            SET TIPODOCUMENTO=V_TIPO
                ,NUMERODOCUMENTO =V_NUMERO
                 , estado=2
            where pd.idinversion = P_IDINVERSION and GRUPODISTRIBUCION=P_GRUPO;
            v_cont:=SQL%ROWCOUNT;    --DBMS_OUTPUT.PUT_LINE('Registros afectados:UPDATE data.t_icom_productodistribuciondet:V_TIPO:'||V_TIPO||', V_NUMERO:'||V_NUMERO||''||v_cont);
         
            INSERT INTO F554X11@jdedtadl (ACKCOO,       ACDCTO,       ACDOCO,       ACLNID,               ACPFN1,  ACPFN2,  ACPFN3,  ACPFN4,  ACPFN5,  ACPFN6,       ACUSER,       ACUPMJ)
                            SELECT SDKCOO ACKCOO,SDDCTO ACDCTO,SDDOCO ACDOCO,SDLNID ACLNID,P_IDINVERSION ACPFN1,0 ACPFN2,0 ACPFN3,0 ACPFN4,0 ACPFN5,0 ACPFN6,SDUSER ACUSER,SDUPMJ ACUPMJ
            FROM F4211@JDEDTADL  WHERE SDDCTO=V_TIPO AND SDDOCO=V_NUMERO;
             v_cont:=SQL%ROWCOUNT;    --DBMS_OUTPUT.PUT_LINE('Registros afectados:INSERT INTO F554X11@jdedtadl:'||v_cont);
           
            data.pk_corp_flujoaprobacion.sp_flujoenviar(
                    p_id => V_NUMERO, --NUMERO DE VA
                    p_modulo => 'VTAS',
                    p_objeto => V_TIPO,--'PEDIDO', ---VA
                    p_objetodescripcion => V_NOMBRE_INVERSION,--- NOMBRE DE LA INVERSION ,
                    p_usuario => V_USUARIOCREA,--- USUARIOCREA
                    P_COMENTARIO =>'', 
                    p_compania => V_COMPANIA ,
                    p_tipo1 => V_AREA, ---  AREA 
                    p_tipo2 => V_TIPO,
                    p_exito => V_EXITO
            );
              ----DBMS_OUTPUT.PUT_LINE( 'pk_corp_flujoaprobacion.sp_flujoenviar - G_TRAMA: '||pk_corp_flujoaprobacion.G_TRAMA);
            if (V_EXITO=0)then
                RAISE_APPLICATION_ERROR(-20000, 'Error al enviar a ruta el autoconsumo:'||pk_corp_flujoaprobacion.G_MENSAJE); 
            end if;
           
            V_HTML_BODY:='<html>
        <head>
            <style>
            .filahdr{font-size:11pt;color:black;font-weight:700;font-family:Calibri,sans-serif;border:0.5pt solid windowtext;background:rgb(220,230,241);text-align:center;vertical-align:middle;padding:0px}
            .celda1 {font-size:11pt;color:black;font-weight:700;font-family:Calibri,sans-serif;border:0.5pt solid windowtext;text-align:center;vertical-align:middle;padding:0px}
            .celda2 {border-top:none;border-left:none;text-align:center;vertical-align:middle;border-right:0.5pt solid windowtext;border-bottom:0.5pt solid windowtext;padding:0px;color:black;font-size:11pt;font-family:Calibri,sans-serif;}
            .celda3 {border-top:none;border-left:none;text-align:right;vertical-align:middle;border-right:0.5pt solid windowtext;border-bottom:0.5pt solid windowtext;padding:0px;color:black;font-size:11pt;font-family:Calibri,sans-serif;}
            table{border-collapse:collapse;width:644pt}
         </style>
        </head>
        <body>
            <p>Estimado(a)</p>
            <p>Se ha generado la siguiente '||V_TIPO||'-'||V_NUMERO||' que se detalla, solicitamos el despacho a las bodegas de Tramaco el dia '||v_fechaencuesta||' a las 10:00 am</p>
            <table border="0" cellpadding="0" cellspacing="0" align="center">
                <tbody>
                    <tr style="height:30pt" class="filahdr">
                        <td style="width:103pt;">Codigo Regalo</td>
                        <td style="width:167pt;">Regalo</td>
                        <td style="width:86pt ;">CANTIDAD TOTAL CAJAS/ BULTOS</td>
                        <td style="width:139pt;">CANTIDAD TOTAL PAQUETES</td>
                        <td style="width:79pt ;">PESO TOTAL&nbsp; KG</td>
                    </tr>
                    {TR}
                </tbody>
            </table>
            <p>Agradezco la gestion correspondiente y quedo pendiente a los datos de los vehiculos y transportistas para comunicar oportunamente al proveedor. </p>
            <br /><p><strong>Saludos cordiales,</strong></p>
            <br /><p><strong>OPERACIONES COMERCIALES</strong></p>
            <p><strong>ZAIMELLA DEL ECUADOR S.A.</strong></p>
            <p></p>
        </body>
    </html>';
                FOR DETALLE_MAIL IN (
                SELECT 
                    TO_CHAR('<tr style="height:29pt">
                        <td class="celda1">'||TRIM(X.CODIGOPRODUCTO)||'</td>
                        <td class="celda2">'||(TRIM(DESCRIPCION)||' - '||TRIM(DESCRIPCION2))||'</td>
                        <td class="celda2">'||sum(CANTIDAD)||'</td>
                        <td class="celda2">'||to_char(sum(pk_vtas_pedidos.f_cantidadpresentacion(X.CODIGOPRODUCTO)*CANTIDAD), '999G999G999G999G990D00')||'</td>
                        <td class="celda3">'||sum(peso)||' </td>
                    </tr>')fila
                FROM VT_JDE_ORDENVENTADETALLE X, VT_JDE_PRODUCTOS V
                WHERE DOCUMENTO= V_NUMERO AND DOCUMENTOTIPO= V_TIPO 
                AND ESTADO_ANT<>980
                AND TRIM(X.CODIGOPRODUCTO)=TRIM(V.CODIGOPRODUCTO) 
                group by TRIM(X.CODIGOPRODUCTO),(TRIM(DESCRIPCION)||' - '||TRIM(DESCRIPCION2))
                UNION ALL
                SELECT 
                    TO_CHAR('<tr style="height:16pt"
                        class="filahdr">
                        <td>Total general</td>
                        <td>&nbsp;</td>
                        <td>'||SUM(CANTIDAD)||'</td>
                            <td>'||to_char(sum(pk_vtas_pedidos.f_cantidadpresentacion(X.CODIGOPRODUCTO)*CANTIDAD), '999G999G999G999G990D00')||'</td>
                        <td style="text-align:right">'||sum(peso)||' </td>
                    </tr>')fila
                FROM VT_JDE_ORDENVENTADETALLE X, VT_JDE_PRODUCTOS V
                WHERE DOCUMENTO= V_NUMERO AND DOCUMENTOTIPO= V_TIPO AND ESTADO_ANT<>980
                AND TRIM(X.CODIGOPRODUCTO)=TRIM(V.CODIGOPRODUCTO)
                HAVING NVL(sum(CANTIDAD),0)>0
            )LOOP
                V_HTML_DETALLE:=V_HTML_DETALLE||DETALLE_MAIL.fila;
            END LOOP;
            --DBMS_OUTPUT.PUT_LINE(V_HTML_DETALLE);
            IF (V_HTML_DETALLE IS NOT NULL)THEN
            V_HTML_BODY:=REPLACE(V_HTML_BODY,'{TR}',V_HTML_DETALLE);
    
            V_CORREO_PARA:= PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '31','00001','VALOR') ;
            V_CORREO_CC  :=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '31','00001','VALOR2') ;
            PK_CORP_CORREO.SP_ENVIO(
                                P_MODULO => 'ICOM',
                                P_TO => (V_CORREO_PARA ||','||V_CORREO_CC),
                                P_FROM => 'notificacion@zaimella.com',
                                P_SUBJECT => 'DISTRIBUCION PRODUCTO PROMOCIONAL '||TO_CHAR(v_fechaencuesta,'DD.MM.YYYY'),
                                P_BODY => V_HTML_BODY
                              );
        end if;
        end if;
    END sp_crearordenautoconsumo;    
    
    /*ENVIAR APROBAR LOS DESCUENTOS
    SP_DESCUENTO_ENVIAR(P_USUARIO =>P_USUARIO, P_COMPANIA =>P_COMPANIA);
    */ 
    PROCEDURE SP_DESCUENTO_CANCELAR_ENVIAR(P_USUARIO VARCHAR2, P_COMPANIA VARCHAR,P_GRUPOCANCELACION number,P_OBSERVACION VARCHAR2,p_exito OUT number, p_mensaje OUT varchar2)
    AS
        V_EXITO NUMBER;
    BEGIN
       
        FOR I IN(select CODIGO_GRUPO, CLIENTE_GRUPO from VT_ICOM_PRODUCTO_DESCUENTO_FECHAS 
                        where GRUPOCANCELACION =P_GRUPOCANCELACION GROUP BY CODIGO_GRUPO, CLIENTE_GRUPO) LOOP

              DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJOENVIAR(
                p_id=>I.CODIGO_GRUPO||'-'||P_GRUPOCANCELACION,
                p_objeto=>'PARAMETRIZACION_DESCUENTO_CANCELACION',
                p_objetodescripcion=> 'PARAMETRIZACION DESCUENTO CANCELACION CLIENTE: '||I.CLIENTE_GRUPO,
                p_usuario=>P_USUARIO,
                p_modulo=>G_MODULO,
                p_compania=>P_COMPANIA,
                P_COMENTARIO =>P_OBSERVACION, 
                P_ETAPA => 'PROCESO_PARAMETRIZACION_DESCUENTO',
                P_TIPO1 =>'PROCESO_OPERATIVO',
                P_TIPO2 =>'PARAMETRIZACION_DE_DESCUENTOS',
                P_TIPO3 =>I.CODIGO_GRUPO,
                p_exito=>V_EXITO);
            
            IF(V_EXITO=0) THEN
               -- RAISE_APPLICATION_ERROR(-20100, DATA.PK_CORP_FLUJOAPROBACION.G_MENSAJE);
               -- NO SE ENVIO A RUTA DE APROBACION
               V_EXITO:=0;
               UPDATE T_ICOM_PRODUCTO_DESCUENTO_FEC DF SET OBSERVACION= DATA.PK_CORP_FLUJOAPROBACION.G_MENSAJE
               where GRUPOCANCELACION =P_GRUPOCANCELACION and estado = 3 AND DF.CODIGOGRUPO=I.CODIGO_GRUPO ; 
            ELSE 
                V_EXITO:=1;
               UPDATE T_ICOM_PRODUCTO_DESCUENTO_FEC DF SET ESTADO=4  , OBSERVACION=NULL
               where GRUPOCANCELACION =P_GRUPOCANCELACION   and estado =3  AND DF.CODIGOGRUPO=I.CODIGO_GRUPO;
            END IF;
            P_EXITO:=V_EXITO;
            P_MENSAJE:=DATA.PK_CORP_FLUJOAPROBACION.G_MENSAJE;
        END LOOP;
    END SP_DESCUENTO_CANCELAR_ENVIAR;
    
    /*APROBAR O RECHAZAR LOS DESCUENTOS
    SP_DESCUENTO_APROBAR(P_ESTADO =>P_ESTADO, P_GRUPO =>P_GRUPO, P_CODIGOGRUPO =>P_CODIGOGRUPO, 
    P_USUARIO =>P_USUARIO,  P_COMENTARIO =>P_COMENTARIO, P_COMPANIA =>P_COMPANIA)
    */
    PROCEDURE SP_DESCUENTO_CANCELAR_APROBAR(p_idinversion number,P_ESTADO NUMBER, P_GRUPO NUMBER, P_CODIGOGRUPO VARCHAR, P_USUARIO VARCHAR2,P_COMENTARIO CLOB, P_COMPANIA VARCHAR) AS
    v_GRUPO_DESCUENTO 			VARCHAR(20);
    v_exito 			number;
    v_CONTADOR 			number;
    v_SECUENCIAL		number;
    v_termino 			number;
    V_OBJETO VARCHAR(50):= 'PARAMETRIZACION_DESCUENTO_CANCELACION';
    BEGIN 
         pk_commons.sp_apex_log('APEX.SP_DESCUENTO_CANCELAR_APROBAR',1,'PARAMETROS','SP_DESCUENTO_CANCELAR_APROBAR(p_idinversion =>'''||p_idinversion||''',P_ESTADO =>'''||P_ESTADO||''', P_GRUPO =>'''||P_GRUPO||''', P_CODIGOGRUPO =>'''||P_CODIGOGRUPO||''', P_USUARIO =>'''||P_USUARIO||''',P_COMENTARIO =>'''||P_COMENTARIO||''', P_COMPANIA =>'''||P_COMPANIA||''')',NULL,null); COMMIT;

        IF(P_ESTADO=1) THEN  --APROBAR
       
             pk_corp_flujoaprobacion.sp_flujoaprobar(
					 p_id 					=>P_CODIGOGRUPO||'-'||P_GRUPO
					, p_objeto				=> V_OBJETO
                    ,P_ORDENMONTO => NULL
                    ,P_USUARIOFLUJO=>P_USUARIO
					, p_usuario				=> P_USUARIO
					, p_comentario			=> P_COMENTARIO
					, p_modulo				=> G_MODULO
					, p_compania			=> P_COMPANIA
					, p_exito				=> v_exito
					, p_terminoflujo		=> v_termino);  
                    
            IF(v_exito=0) THEN 
                raise_application_error(-20000,pk_corp_flujoaprobacion.G_MENSAJE);
            END IF;
        
            IF v_termino = 1 THEN
                for fec in (
                        select
                             f.codigocliente ADAN8 
                            ,f.codigoproducto ADLITM 
                            ,(TO_CHAR(f.FECHAINICIO,'YYYYDDD')-1900000) ADEFTJ 
                            ,(TO_CHAR(f.FECHAFIN,'YYYYDDD')-1900000) ADEXDJ 
                            ,f.idinversion ADPFN1
                            ,(TO_CHAR(SYSDATE,'YYYYDDD')-1900000) ADFEC
                        from T_ICOM_PRODUCTO_DESCUENTO_FEC f where CODIGOGRUPO=P_CODIGOGRUPO AND GRUPOCANCELACION=P_GRUPO and idinversion=p_idinversion AND ESTADO=4
                    )
                    loop 
                        update F4072@JDEDTADL  A
                        set ADEXDJ=FEC.ADFEC
                        WHERE EXISTS (
                            SELECT DISTINCT ADAST, ADITM, ADLITM, ADAITM, ADAN8, ADIGID, ADCGID, ADOGID, ADCRCD,  ADMNQ, ADEXDJ, ADUPMJ,  ADPFN1, ADPFN2, ADPFN3, ADPFN4, ADPFN5, ADPFN6
                            FROM F554072A@JDEDTADL  B  WHERE  a.ADAST = b.ADAST and a.ADITM = b.ADITM and a.ADAN8 = b.ADAN8 and a.ADEXDJ = b.ADEXDJ and a.ADUPMJ = b.ADUPMJ and fEC.ADPFN1=NVL(B.ADPFN1,0)
                        )
                        AND (fec.ADAN8=a.ADAN8 
                        and fec.ADLITM=TRIM(a.ADLITM) 
                        and fec.ADEFTJ=A.ADEFTJ 
                        and fec.ADEXDJ=A.ADEXDJ 
                        );
                        --v_cont:=SQL%ROWCOUNT;    --DBMS_OUTPUT.PUT_LINE('Registros afectados:'||v_cont);
    
                        update F554072A@JDEDTADL  A1
                        set ADEXDJ=FEC.ADFEC
                        WHERE
                        EXISTS (
                            SELECT 1
                            FROM  F4072@JDEDTADL  A
                            LEFT join  (SELECT DISTINCT ADAST, ADITM, ADLITM, ADAITM, ADAN8, ADIGID, ADCGID, ADOGID, ADCRCD,  ADMNQ, ADEXDJ, ADUPMJ,  ADPFN1, ADPFN2, ADPFN3, ADPFN4, ADPFN5, ADPFN6
                            FROM F554072A@JDEDTADL)  B on  a.ADAST = b.ADAST and a.ADITM = b.ADITM and a.ADAN8 = b.ADAN8 and a.ADEXDJ = FEC.ADFEC and a.ADUPMJ = b.ADUPMJ and fEC.ADPFN1=NVL(B.ADPFN1,0)
                            WHERE a.ADAST = A1.ADAST and a.ADITM = A1.ADITM and a.ADAN8 = A1.ADAN8 and a.ADEXDJ = FEC.ADFEC and a.ADUPMJ = A1.ADUPMJ
                        )
                       AND (fec.ADAN8=a1.ADAN8 
                        and fec.ADLITM=TRIM(a1.ADLITM) 
                        and fec.ADEXDJ=A1.ADEXDJ 
                        );
                        --v_cont:=SQL%ROWCOUNT;    --DBMS_OUTPUT.PUT_LINE('Registros afectados:'||v_cont);
                end loop;

                 UPDATE T_ICOM_PRODUCTO_DESCUENTO_FEC DF SET ESTADO=5  ,fechafin=SYSDATE 
                 where CODIGOGRUPO= P_CODIGOGRUPO AND GRUPOCANCELACION=P_GRUPO and idinversion=p_idinversion AND ESTADO=4;

           end if; 
           
        ELSE    --RECHAZAR
             PK_CORP_FLUJOAPROBACION.SP_FLUJORECHAZAR(
              	p_id 					=> P_CODIGOGRUPO||'-'||P_GRUPO,
                p_objeto				=> V_OBJETO,
                P_USUARIOFLUJO          =>P_USUARIO,
                p_usuario				=> P_USUARIO,
                P_COMENTARIO            => P_COMENTARIO,
                P_MODULO                => G_MODULO, 
                P_COMPANIA              => P_COMPANIA,
                P_EXITO                 => v_exito
            );     
            IF(v_exito=0) THEN 
                raise_application_error(-20000,pk_corp_flujoaprobacion.G_MENSAJE);
            END IF;
                
            UPDATE T_ICOM_PRODUCTO_DESCUENTO_FEC DF SET ESTADO=3
            where CODIGOGRUPO= P_CODIGOGRUPO AND GRUPOCANCELACION=P_GRUPO and idinversion=p_idinversion AND ESTADO=4;
        END IF;
    
    END SP_DESCUENTO_CANCELAR_APROBAR;    

    procedure sp_icom_notificacionestemporalidad(p_compania varchar2 DEFAULT '00001') as
        V_HTML_BODY clob;
        V_HTML_BODY_AUX01 clob;
        V_HTML_BODY_AUX02 clob;
        V_HTML_TABLA clob;
        V_HTML_TABLA_AUX01 clob;
        V_HTML_TABLA_AUX02 clob;
        V_HTML_TABLA_AUX03 clob;
        V_HTML_DETALLE clob;
        V_HTML_DETALLE_AUX01 clob;
        V_HTML_DETALLE_AUX02 clob;
        v_stlfilahdr varchar2(3999);
        v_stlfilafila1 varchar2(3999);
        v_stlfilafila2 varchar2(3999);
        v_stltable varchar2(3999);
        v_correoAdicional varchar2(3999);
    begin
            v_stlfilahdr :='border-top:0.5pt solid slategray;border-bottom:0.5pt solid slategray;background:white;text-align:center;font-weight:700;text-wrap-mode: nowrap;color:black;';
            v_stlfilafila1:='border:0.0pt solid transparent;background:#e7e7e7;text-align:center;vertical-align:unset;';
            v_stlfilafila2:='border:0.0pt solid transparent;background:white;text-align:center;vertical-align:unset;';
            v_stltable :='border-collapse:collapse;font-family:Calibri,sans-serif;font-size:8.5pt;color:black;';
    
        V_HTML_BODY_AUX01:='<html>
        <head>
            <style>
            .filahdr{'||v_stlfilahdr||'}
            .fila1  {'||v_stlfilafila1||'}
            .fila2  {'||v_stlfilafila2||'}
            table{'||v_stltable||'}
            </style>
        </head>
        <body>
            <p><strong>Estimado(a) usuario: </strong>{usuario}</p>
            <p><strong>Tiene pendiente por gestionar lo siguiente:</strong></p>
            {TABLAS}
            <br /><p><strong>Saludos cordiales,</strong></p>
            <br /><p><strong>OPERACIONES COMERCIALES</strong></p>
            <p><strong>ZAIMELLA DEL ECUADOR S.A.</strong></p>
            <p></p>
        </body>
        </html>';
        V_HTML_TABLA_AUX01:='<p><strong style="text-decoration: underline;">{NOMBREPROCESO}</strong></p>
            <table border="1" cellpadding="2" cellspacing="1" align="center" width="1600px">
                <tbody>
                    <tr class="filahdr">
                            <td style="width:150px">ID</td>
                            <td >NOMBRE INVERSION</td>
                            <td style="width:150px">ETAPA</td>
                            <td style="width:150px">ETAPA ALTERNA</td>
                            <td style="width:150px">FECHA INICIO</td>
                            <td style="width:150px">FECHA FIN</td>
                            <td style="width:150px">APROBADOR</td>
                            <td style="width:150px">USUARIO GESTIoN</td>
                            <td style="width:150px">PORCENTAJE</td>
                            <td style="width:150px">ESTADO PROCESO</td>
                            <td style="width:150px">RUTA</td>
                    </tr>
                    {TR}
                    <tr 
                        class="filahdr">
        
                    </tr>
                </tbody>
            </table><br />
        ';
        
        v_correoAdicional := ','||DATA.PK_ICOM_COMMONS.f_traervalorudc(P_ID_CABECERA => 'ICOM_PARAM', p_id_tabla  => '34' , 
            p_COMPANIA => P_COMPANIA,tipo => 'VALOR', p_ACTIVO =>'1' ) ;
            
        for coord in (
            SELECT distinct COORDINADOR, COORD_NOMBRE , SUPERVISOR ,SUPER_NOMBRE, COORD_EMAIL, SUPER_EMAIL 
            FROM vt_icom_notificaciones_temporalidad 
            where compania=P_COMPANIA 
            order by COORDINADOR
        )
        loop 
            V_HTML_BODY_AUX02:=V_HTML_BODY_AUX01;
            V_HTML_BODY_AUX02:=REPLACE(V_HTML_BODY_AUX02,'{usuario}', COORD.COORD_NOMBRE);
        
            FOR PROC IN (SELECT DISTINCT  IDPROCESO, PROCESO FROM vt_icom_notificaciones_temporalidad T where compania=P_COMPANIA AND T.COORDINADOR=coord.COORDINADOR order by PROCESO)
            LOOP
                V_HTML_TABLA_AUX02:=V_HTML_TABLA_AUX01;
                V_HTML_TABLA_AUX02:=REPLACE(V_HTML_TABLA_AUX02,'{NOMBREPROCESO}', PROC.PROCESO);
                V_HTML_DETALLE_AUX01:='';
                FOR DETA IN (
                    SELECT '<tr class="'||DECODE(MOD(RN,2),0,'fila2','fila1')||'">'||'<td style="width:150px">'||ID||'</td><td style="width:850px;text-align:justify;">'||NOMBRE||'</td><td style="width:150px">'||ETAPA||'</td><td style="width:150px">'||ETAPAALTERNA||'</td><td style="width:150px">'||FECHAINICIO||'</td><td style="width:150px">'||FECHAFIN||'</td><td>'||APROBADOR||'</td><td style="width="350px">'||USUARIOS_GESTION||'</td><td style="width:150px">'||PORCENTAJE||'</td><td>'||ESTADOPROCESO||'</td><td style="width:150px">'||RUTA||'</td>'||'</tr>' fila
                    FROM vt_icom_notificaciones_temporalidad T
                    where compania=P_COMPANIA AND T.COORDINADOR=coord.COORDINADOR AND T.IDPROCESO=PROC.IDPROCESO order by PROCESO, rn
                )
                LOOP
                    V_HTML_DETALLE_AUX01:=V_HTML_DETALLE_AUX01||DETA.fila;
                END LOOP;
                 V_HTML_TABLA_AUX02:=REPLACE(V_HTML_TABLA_AUX02,'{TR}',V_HTML_DETALLE_AUX01);
                 V_HTML_TABLA_AUX03:=V_HTML_TABLA_AUX03||V_HTML_TABLA_AUX02;
            END LOOP;
            V_HTML_BODY_AUX02:=REPLACE(V_HTML_BODY_AUX02,'{TABLAS}',V_HTML_TABLA_AUX03);
            V_HTML_TABLA_AUX03:='';
            PK_CORP_CORREO.SP_ENVIO(
                                        P_MODULO => 'ICOM',
                                        P_TO => (coord.COORD_EMAIL||coord.SUPER_EMAIL||v_correoAdicional),
                                        P_FROM => 'infocomercial@zaimella.com',
                                        P_SUBJECT => ' INVERSIONES COMERCIALES / Gestion de procesos operativos pendientes',
                                        P_BODY => V_HTML_BODY_AUX02
                                      );
           -- --DBMS_OUTPUT.PUT_LINE(V_HTML_BODY_AUX02);
        end loop;
    
    end sp_icom_notificacionestemporalidad;
    
    procedure sp_icom_notificacionestemporalidadEscalable(p_compania varchar2 DEFAULT '00001') as
        V_HTML_BODY clob;
        V_HTML_BODY_AUX01 clob;
        V_HTML_BODY_AUX02 clob;
        V_HTML_TABLA clob;
        V_HTML_TABLA_AUX01 clob;
        V_HTML_TABLA_AUX02 clob;
        V_HTML_TABLA_AUX03 clob;
        V_HTML_DETALLE clob;
        V_HTML_DETALLE_AUX01 clob;
        V_HTML_DETALLE_AUX02 clob;
        v_stlfilahdr varchar2(3999);
        v_stlfilafila1 varchar2(3999);
        v_stlfilafila2 varchar2(3999);
        v_stltable varchar2(3999);
        v_correoAdicional varchar2(3999);
    begin
            v_stlfilahdr :='border-top:0.5pt solid slategray;border-bottom:0.5pt solid slategray;background:white;text-align:center;font-weight:700;text-wrap-mode: nowrap;color:black;';
            v_stlfilafila1:='border:0.0pt solid transparent;background:#e7e7e7;text-align:center;vertical-align:unset;';
            v_stlfilafila2:='border:0.0pt solid transparent;background:white;text-align:center;vertical-align:unset;';
            v_stltable :='border-collapse:collapse;font-family:Calibri,sans-serif;font-size:8.5pt;color:black;';
        --DBMS_OUTPUT.PUT_LINE('sp_icom_notificacionestemporalidadEscalable:V_HTML_BODY_AUX01: '||V_HTML_BODY_AUX01);
        V_HTML_BODY_AUX01:='<html>
        <head>
            <style>
            .filahdr{'||v_stlfilahdr||'}
            .fila1  {'||v_stlfilafila1||'}
            .fila2  {'||v_stlfilafila2||'}
            table{'||v_stltable||'}
            </style>
        </head>
        <body>
            <p><strong>Estimado(a) usuario: </strong>{usuario}</p>
            <p><strong>Tiene pendiente por gestionar lo siguiente:</strong></p>
            {TABLAS}
            <br /><p><strong>Saludos cordiales,</strong></p>
            <br /><p><strong>OPERACIONES COMERCIALES</strong></p>
            <p><strong>ZAIMELLA DEL ECUADOR S.A.</strong></p>
            <p></p>
        </body>
        </html>';
        V_HTML_TABLA_AUX01:='<p><strong style="text-decoration: underline;">INVERSION: {NOMBREINVERSION}</strong></p>
            <table border="1" cellpadding="2" cellspacing="1" align="center" width="100%">
                <tbody>
                    <tr class="filahdr">
                            <td>CoDIGO</td>
                            <td>CLIENTE</td>
                    </tr>
                    {TR}
                    <tr 
                        class="filahdr">
        
                    </tr>
                </tbody>
            </table><br />
        ';
        v_correoAdicional := ','||DATA.PK_ICOM_COMMONS.f_traervalorudc(P_ID_CABECERA => 'ICOM_PARAM', p_id_tabla  => '34' , 
            p_COMPANIA => P_COMPANIA,tipo => 'VALOR', p_ACTIVO =>'1' ) ;
        for coord in (
            SELECT distinct COORDINADOR, COORD_NOMBRE , SUPERVISOR ,SUPER_NOMBRE, COORD_EMAIL, SUPER_EMAIL ,compania
            FROM DATA.VT_ICOM_NOTIFICACIONES_ESCALABLE 
            where compania=P_COMPANIA 
--            AND COORDINADOR='JDESOUSA'
            order by COORDINADOR
        )
        loop 
            
            V_HTML_BODY_AUX02:=V_HTML_BODY_AUX01;
            V_HTML_BODY_AUX02:=REPLACE(V_HTML_BODY_AUX02,'{usuario}', COORD.COORD_NOMBRE);
        
            FOR PROC IN (SELECT DISTINCT  ID, NOMBRE FROM DATA.VT_ICOM_NOTIFICACIONES_ESCALABLE T where compania=coord.COMPANIA AND T.COORDINADOR=coord.COORDINADOR order by NOMBRE)
            LOOP
                V_HTML_TABLA_AUX02:=V_HTML_TABLA_AUX01;
                V_HTML_TABLA_AUX02:=REPLACE(V_HTML_TABLA_AUX02,'{NOMBREINVERSION}', PROC.ID||' - '||PROC.NOMBRE);
                V_HTML_DETALLE_AUX01:='';
                 --DBMS_OUTPUT.PUT_LINE('PROC.ID:'||PROC.ID);
                FOR DETA IN (
                    SELECT COORDINADOR,RN, '<tr class="'||DECODE(MOD(RN,2),0,'fila2','fila1')||'">'||'<td>'||CODIGOCLIENTE||'</td><td style="text-align:justify;">'||CLIENTES||'</td></tr>' fila
                    FROM DATA.VT_ICOM_NOTIFICACIONES_ESCALABLE T
                    where compania=P_COMPANIA AND T.COORDINADOR=coord.COORDINADOR AND T.ID=PROC.ID order by  rn
                )
                LOOP
                    --DBMS_OUTPUT.PUT_LINE('DETA.fila:'||DETA.fila ||'    DETA.RN:'||DETA.RN);
                    V_HTML_DETALLE_AUX01:=V_HTML_DETALLE_AUX01||DETA.fila;
                END LOOP;
                 V_HTML_TABLA_AUX02:=REPLACE(V_HTML_TABLA_AUX02,'{TR}',V_HTML_DETALLE_AUX01);
                 V_HTML_TABLA_AUX03:=V_HTML_TABLA_AUX03||V_HTML_TABLA_AUX02;
                 --DBMS_OUTPUT.PUT_LINE('********************************');
            END LOOP;
            V_HTML_BODY_AUX02:=REPLACE(V_HTML_BODY_AUX02,'{TABLAS}',V_HTML_TABLA_AUX03);
            V_HTML_TABLA_AUX03:='';
            data.PK_CORP_CORREO.SP_ENVIO(
                                        P_MODULO => 'ICOM',
                                        P_TO => (coord.COORD_EMAIL||coord.SUPER_EMAIL||v_correoAdicional),
                                        P_FROM => 'notificacion@zaimella.com',
                                        P_SUBJECT => 'INVERSIONES COMERCIALES / Cliente pendientes de negociar',
                                        P_BODY => V_HTML_BODY_AUX02
                                      );
            --DBMS_OUTPUT.PUT_LINE(V_HTML_BODY_AUX02);
        end loop;
--    
    end sp_icom_notificacionestemporalidadEscalable;
    /*
       La copia de un template crea preguntas con PK_COMMONS.F_SECUENCIA.
       El contador puede quedar atras de cargas historicas, por lo que se
       alinea con el maximo persistido antes de solicitar nuevos IDs.
    */
    PROCEDURE SP_SINCRONIZA_SECUENCIA_PREGUNTAS AS
        PRAGMA AUTONOMOUS_TRANSACTION;
        V_NEXTVALUE NUMBER;
        V_MAX_ID NUMBER;
    BEGIN
        SELECT NEXTVALUE
          INTO V_NEXTVALUE
          FROM T_SECUENCIA
         WHERE KEY = 'T_ENCT_CUESTIONARIOPREGUNTAS'
           FOR UPDATE;

        SELECT NVL(MAX(IDPREGUNTA), 0)
          INTO V_MAX_ID
          FROM T_ENCT_CUESTIONARIOPREGUNTAS;

        /* F_SECUENCIA entrega NEXTVALUE + 1. */
        IF V_NEXTVALUE <= V_MAX_ID THEN
            UPDATE T_SECUENCIA
               SET NEXTVALUE = V_MAX_ID
             WHERE KEY = 'T_ENCT_CUESTIONARIOPREGUNTAS';
        END IF;

        COMMIT;
    END SP_SINCRONIZA_SECUENCIA_PREGUNTAS;

    /* Procedimiento para la generacion de las encuestas Onpack. */
    /* @P_IDINVERSION numero de inversion para la que se genera el cuestionario
       @P_GRUPO para saber a cual grupo de distribucion es la encuesta
       @P_COMPANIA compania a la que pertenece la encuesta
       @P_MENSAJE variable de retorno para saber si existen errores
    */
    PROCEDURE SP_INVERSION_ENCUENTAS_AUTOCONSUMO(P_IDINVERSION NUMBER,P_GRUPO NUMBER ,P_COMPANIA VARCHAR2,P_MENSAJE OUT VARCHAR2) AS
--    DECLARE P_IDINVERSION NUMBER:=21475;P_GRUPO NUMBER :=101;P_COMPANIA VARCHAR2(5):='00001';P_MENSAJE VARCHAR2(3999);
        V_NOMBREGRUPO VARCHAR2(500);
        V_IDTEMPLATE NUMBER;
        V_NOMBRE_TEMPLATE VARCHAR2(3999);
        V_USUARIO VARCHAR2(50);
        V_NOMBRECUESTIONARIO VARCHAR2(3999);
        V_NOMBREINVERSION VARCHAR2(3999);
        V_VALIDACION01 NUMBER;
        V_VALIDACION02 NUMBER;
        V_VALIDACION03 NUMBER;
        V_VALIDACION04 NUMBER;
        V_VALIDACION05 NUMBER;
        V_VALIDACION06 NUMBER;
        V_IDCUESTIONARIO NUMBER;
        V_ESTADO NUMBER:=0;
    BEGIN
        V_USUARIO :='ICOM';
        /*
            SE TOMAN LOS DATOS LAS FECHAS PARA GENERAR LAS ENCUESTAS CON EL TEMPLATE DISEÃ‚Â¿ADO POR OPERACIONES COMERCIALES
        */
        FOR  T_DATOS IN (
            SELECT ROW_NUMBER() OVER (PARTITION BY IDINVERSION ORDER BY f.grupodistribucion DESC)  ID1, 
                F.*
            FROM (
                SELECT DISTINCT
                    IDINVERSION,F.GRUPODISTRIBUCION,F.FECHAINIENCUESTA FECHAINICIO,F.FECHAFINENCUESTA FECHAFIN,F.NOMBREENCUESTA,/*CODIGOPDV,*/TIPODOCUMENTO,NUMERODOCUMENTO,
                    NULL NOMBREGRUPO,
                    NULL CODIGOGRUPO,
                    (SELECT ID_TEMPLATE FROM VT_ICOM_ENCUESTA_TEMPLATE WHERE TIPO_ENCUESTA ='PRODUCTO REGALO' )  IDTEMPLATE,
                    TRIM(TO_CHAR(P_COMPANIA,'00000')) COMPANIA
                FROM T_ICOM_PRODUCTODISTRIBUCIONDET F 
                /* La creacion de la orden devuelve los detalles aprobados a 2. */
                WHERE F.IDINVERSION=P_IDINVERSION and F.grupodistribucion=P_GRUPO and F.estado=2
            ) F
        )
        LOOP
        
            /*SE RECUPERA EL NOMBRE DE LA ENCUESTA FORMATO PRODUCTO REGALO (QUEMADO)*/
            V_NOMBRECUESTIONARIO:=T_DATOS.NOMBREENCUESTA||' (Grupo Distribucion:'||T_DATOS.GRUPODISTRIBUCION||')' ;
            V_NOMBRECUESTIONARIO:=T_DATOS.NOMBREENCUESTA;
            /*SE VALIDA QUE EL CUESTIONARIO A SER CREADO NO EXISTA DENTRO DE LA BASE*/
            SELECT  
                COUNT(DISTINCT 1), 
                LISTAGG(DISTINCT IDCUESTIONARIO ,',') WITHIN GROUP (ORDER BY IDCUESTIONARIO) IDCUESTIONARIO
            INTO V_VALIDACION04,V_VALIDACION03 
            FROM T_ENCT_CUESTIONARIOS 
            WHERE REFERENCIAID =T_DATOS.IDINVERSION 
            AND   FECHADESDE =T_DATOS.FECHAINICIO AND FECHAHASTA =T_DATOS.FECHAFIN AND CODIGOCLIENTE =NVL(T_DATOS.CODIGOGRUPO,CODIGOCLIENTE) and NOMBRE=TRIM(V_NOMBRECUESTIONARIO);
 
            /*SI NO EXISTE EN LA BASE SE PROCEDE A LA CREACIoN*/
            IF (V_VALIDACION04=0)THEN
            
                /*SE RECUPERA EL NOMBRE DEL TEMPLATE DE LA ENCUESTA*/
                SELECT IDCUESTIONARIO||' - '||NOMBRE INTO V_NOMBRE_TEMPLATE  FROM T_ENCT_CUESTIONARIOS WHERE TIPO = 2 AND ESTADO = 1  AND COMPANIA = P_COMPANIA AND IDCUESTIONARIO=T_DATOS.IDTEMPLATE;
                --DBMS_OUTPUT.PUT_LINE('V_NOMBRE_TEMPLATE:'||V_NOMBRE_TEMPLATE);


                /*SE RECUPERA EL NOMBRE DE LA INVERSION*/
                SELECT ID||' - '||NOMBRE INTO V_NOMBREINVERSION FROM VT_ICOM_INVERSIONES WHERE ID=T_DATOS.IDINVERSION   AND COMPANIA = P_COMPANIA  AND IDETAPA IN (2,3,4,7) AND ROWNUM=1;
--DBMS_OUTPUT.PUT_LINE('V_NOMBREINVERSION:'||V_NOMBREINVERSION);

                V_IDCUESTIONARIO:=NULL;
--DBMS_OUTPUT.PUT_LINE('V_IDCUESTIONARIO:'||V_IDCUESTIONARIO);

                /*SEGÃ‚Â¿N EL TEMPLATE SE REALIZA LA COPIA DE LA ENCUESTA Y SE RECUPERA EL NUEVO ID DE LA ENCUESTA*/
                SP_SINCRONIZA_SECUENCIA_PREGUNTAS;
                PK_ENCT_CUESTIONARIO.SP_CUESTIONARIOCOPIA(P_ID => T_DATOS.IDTEMPLATE,P_IDNEW => V_IDCUESTIONARIO,P_USUARIO =>V_USUARIO,P_COMPANIA => P_COMPANIA);
--DBMS_OUTPUT.PUT_LINE('V_IDCUESTIONARIO:'||V_IDCUESTIONARIO);
                
                PK_ENCT_CUESTIONARIO.SP_CUESTIONARIOGUARDAR(
                    P_ID => V_IDCUESTIONARIO ,
                    P_TIPO => 1,/*{1:NORMAL,2:TEMPLATE}*/
                    P_IDGRUPO =>  NULL,
                    P_NOMBRE => V_NOMBRECUESTIONARIO,
                    P_REFERENCIATABLA =>'INVERSION',/*{PRODUCTO_COMPETENCIAPRODUCTO COMPETENCIA,CODIGOPDVPunto de Venta,PRODUCTOPRODUCTO,INVERSION:INVERSIONES COMERCIALES,CLIENTE:CLIENTES}*/
                    P_REFERENCIAID => T_DATOS.IDINVERSION ,
                    P_REFERENCIADESCRIPCION => V_NOMBREINVERSION,
                    P_REFERENCIAPOBLACION => 'PUNTOVENTA',/*{EMPLEADO:EMPLEADOS,PUNTOVENTAPUNTOS DE VENTA}*/
                    P_FRECUENCIA => 1,/*{0:UNA VEZ,1:DIARIA,7:SEMANAL,15:QUINCENAL}*/
                    P_FECHADESDE => T_DATOS.FECHAINICIO,
                    P_FECHAHASTA =>T_DATOS.FECHAFIN,
                    P_TIPOEJECUCION => 1,/*{1:Movil Mella,2:Correo,3Portal}*/
                    P_USUARIOCREACION => V_USUARIO,
                    P_ESTADO => 1,
                    P_COMPANIA => P_COMPANIA  ,P_CODIGOCLIENTE=>T_DATOS.CODIGOGRUPO
                );
                --DBMS_OUTPUT.PUT_LINE('PK_ENCT_CUESTIONARIO.SP_CUESTIONARIOGUARDAR:ok'||V_IDCUESTIONARIO);

                /*SE INSERTA LOS DATOS DE LA POBLACION A LA QUE VA DIRIGIDO LA ENCUESTA*/
                INSERT INTO T_ENCT_CUESTIONARIOPERSONAS ( IDCUESTIONARIO, IDPERSONA, DESCRIPCION, CORREO, NUMERO)
                    with pdv as (
                            SELECT V_IDCUESTIONARIO IDCUESTIONARIO,
                                TO_CHAR(CL.CODIGOPDV||'-'||CL.NUMERO) CODIGOPDV,
                                RAZON_SOCIAL,
                                cl.EMAIL correo,
                                0 numero
                            FROM T_TRAD_CLIENTELOCAL CL
                            INNER JOIN T_TRAD_CLIENTE C ON (C.CODIGOPDV=CL.CODIGOPDV)
                            left join  (select distinct codigopdv, RUC, RAZON_SOCIAL, tipoidentificacion  from t_trad_clienteruc where es_principal = 1)r on c.codigopdv = r.codigopdv
                            WHERE/* CODIGOGRUPO=T_DATOS.CODIGOGRUPO AND*/ TIPOVISITA  =1
                            group by TO_CHAR(CL.CODIGOPDV||'-'||CL.NUMERO), RAZON_SOCIAL,cl.EMAIL
                    )
                    ,mpop as (
                        SELECT DISTINCT TO_CHAR(F.CODIGOPDV||'-'||f.codigolocal)CODIGOPDV,F.IDINVERSION,F.CODIGOPDV F_CODIGOPDV
                        FROM T_ICOM_PRODUCTODISTRIBUCIONDET F 
                        WHERE F.IDINVERSION=P_IDINVERSION and F.grupodistribucion=P_GRUPO and F.estado=2
                        ORDER BY TO_NUMBER(F.CODIGOPDV)
                    )
                    SELECT pdv.* FROM  pdv inner join mpop on pdv.CODIGOPDV=mpop.CODIGOPDV;
                                    --DBMS_OUTPUT.PUT_LINE('INSERT INTO T_ENCT_CUESTIONARIOPERSONAS:ok'||V_IDCUESTIONARIO);

                
            ELSE
                /* de haber algun error se procede a almacenarlo para retornarlo en la variable p_mensaje*/
                P_MENSAJE :=P_MENSAJE||'<li>'||V_VALIDACION03||': ['||T_DATOS.FECHAINICIO||' - '||T_DATOS.FECHAFIN||'], cliente '||T_DATOS.NOMBREGRUPO||'</li>';

                DBMS_OUTPUT.PUT_LINE('SP_INVERSION_ENCUENTAS_AUTOCONSUMO:'||P_MENSAJE);
            END IF;
        END LOOP;
        IF (P_MENSAJE IS NOT NULL) THEN 
            P_MENSAJE :='Encuesta(s) ya existente(s):<ul>'||P_MENSAJE ||'</ul>';
        END IF;
    END SP_INVERSION_ENCUENTAS_AUTOCONSUMO;
    
    PROCEDURE SP_CREARORDENAUTOCONSUMOMUESTRAS(P_IDINVERSION number) as
--    declare P_IDINVERSION number:=20999;
        V_SHIPTO NUMBER;
        V_SOLDTO NUMBER;
        V_BODEGA VARCHAR(12);
        V_COMPANIA VARCHAR(5);
        V_VERSION VARCHAR(12);
        V_USUARIO VARCHAR(12);
        V_NUMERO NUMBER;
        V_TIPO VARCHAR(10);
        V_EXITO NUMBER;
        V_NOMBRE_INVERSION VARCHAR(3999);
        V_AREA VARCHAR(3999);
        V_IDAREA NUMBER;
        V_USUARIOCREA VARCHAR2(30);  
        V_HTML_BODY clob;
        V_HTML_DETALLE clob;
        v_fechaencuesta date;
        V_CORREO_PARA VARCHAR2(3999);
        V_CORREO_CC VARCHAR2(3999);
        v_cont number;
    BEGIN

        --ejmc:quitar 76097 para pasar a prd
        SELECT /*U.CODERP*/i.usuario, 1 , I.ID||'-'||I.NOMBRE,I.IDAREA,I.COMPANIA 
        INTO V_USUARIOCREA,V_SHIPTO,V_NOMBRE_INVERSION,V_IDAREA,V_COMPANIA
        FROM vt_corp_usuario U INNER JOIN T_ICOM_INVERSIONES I ON i.usuario = U.NOMBREUSUARIO WHERE I.ID= P_IDINVERSION;
        
        SELECT AREA_RUTA,SOLICITANTE INTO V_AREA, V_SOLDTO FROM VT_ICOM_AREA WHERE IDAREA=V_IDAREA;
        IF V_SOLDTO IS NULL THEN
            RAISE_APPLICATION_ERROR(-20000, 'No existe configurado solicitante en tabal general ICOM_AREA, por favor verificar con el administrador');
        END IF;

        V_BODEGA:='       17003';
        V_COMPANIA:='00001';
        V_VERSION:='ERP0020';
        PK_JDE_VENTAS_WS.SP_CREARORDEN_CAB(P_TIPODOCUMENTO=>'EZ',
                                                  P_SHIPTO=>V_SHIPTO,
                                                  P_SOLDTO=>V_SOLDTO,
                                                  P_BODEGA=>V_BODEGA,
                                                  P_COMPANIA=>V_COMPANIA,   
                                                  P_VERSION=>V_VERSION,
                                                  P_HORA_ENTREGA=>'OPERADOR LOGIST'
                                          );
                                          
                                          DBMS_OUTPUT.PUT_LINE('PK_JDE_VENTAS_WS.G_DOCUMENTO'||PK_JDE_VENTAS_WS.G_DOCUMENTO);
         --DETALLE
        FOR PRODUCTO IN (
                     SELECT
            -- IDINVERSION, PERSONA_O, PERSONA_I, PERSONA_C, CODIGOPDV, ZONA, CIUDAD, DIRECCION, TELEFONO, TELEFONO2, CODIGOPRODUCTO, CANTIDAD, ESTADO, PROVINCIA, ORDENVENTA, CANAL
            DET.IDINVERSION, DET.CODIGOPRODUCTO CODIGO, sum(DET.CANTIDAD )CANTIDAD , JDP.UNIDADPRINCIPAL UNIDAD, '.'UBICACION
         FROM t_icom_productomuestra DET INNER JOIN vt_jde_productos JDP ON TRIM(DET.CODIGOPRODUCTO)=TRIM(JDP.CODIGOPRODUCTO)
         --ON TRIM(REPLACE(DET.CODIGOPRODUCTO, CHR(160), '')) = TRIM(REPLACE(JDP.CODIGOPRODUCTO, CHR(160), ''))
         where DET.IDINVERSION=P_IDINVERSION  and DET.estado=2
            group by  DET.IDINVERSION, DET.CODIGOPRODUCTO , JDP.UNIDADPRINCIPAL
        ) LOOP
                        
           PK_JDE_VENTAS_WS.SP_CREARORDEN_DET(P_PRODUCTO=>PRODUCTO.CODIGO,
                                      P_CANTIDAD=>PRODUCTO.CANTIDAD,  
                                      P_UNIDAD=>PRODUCTO.UNIDAD, 
                                      P_UBICACION=>PRODUCTO.UBICACION, ---NULL .
                                      P_BODEGADESTINO=>V_BODEGA);  --- 17003
        END LOOP;
        DBMS_OUTPUT.PUT_LINE('PK_JDE_VENTAS_WS.G_TRAMA:'||PK_JDE_VENTAS_WS.G_TRAMA);
        PK_JDE_VENTAS_WS.SP_CREARORDEN(P_USUARIO=>V_USUARIO,P_NUMERO=>V_NUMERO,P_TIPO=>V_TIPO,P_EXITO=>V_EXITO);
    
        if (v_exito=0)then
            RAISE_APPLICATION_ERROR(-20000, 'hubo un error al generar la orden de autoconsumo');
        end if;
        if (V_EXITO=1)then
            ---AGREGAR JUSTIFICACION
            insert into f564310@jdedtadl (iakcoo,iadcto,iadoco,ialnid,ialongmsg)
            VALUES (v_COMPANIA,V_TIPO,V_NUMERO, 0, V_NOMBRE_INVERSION );
            v_cont:=SQL%ROWCOUNT;    DBMS_OUTPUT.PUT_LINE('Registros afectados:insert into f564310@jdedtadl:'||v_cont);
            
            UPDATE f4211@jdedtadl
            SET SDPRAN8='999', SDOSTP ='DIN',SDSHAN=V_SOLDTO
            where SDDOCO=V_NUMERO and  SDDCTO = V_TIPO;
            v_cont:=SQL%ROWCOUNT;    DBMS_OUTPUT.PUT_LINE('Registros afectados:UPDATE f4211@jdedtadl:'||v_cont);
                     
            UPDATE data.t_icom_productomuestra pd
            SET ORDENVENTA=V_NUMERO
            where pd.idinversion = P_IDINVERSION AND ESTADO=2;
            v_cont:=SQL%ROWCOUNT;    DBMS_OUTPUT.PUT_LINE('Registros afectados:UPDATE data.t_icom_productomuestra:'||v_cont);
         
            INSERT INTO F554X11@jdedtadl (ACKCOO,       ACDCTO,       ACDOCO,       ACLNID,               ACPFN1,  ACPFN2,  ACPFN3,  ACPFN4,  ACPFN5,  ACPFN6,       ACUSER,       ACUPMJ)
                            SELECT SDKCOO ACKCOO,SDDCTO ACDCTO,SDDOCO ACDOCO,SDLNID ACLNID,P_IDINVERSION ACPFN1,0 ACPFN2,0 ACPFN3,0 ACPFN4,0 ACPFN5,0 ACPFN6,SDUSER ACUSER,SDUPMJ ACUPMJ
            FROM F4211@JDEDTADL  WHERE SDDCTO=V_TIPO AND SDDOCO=V_NUMERO;
             v_cont:=SQL%ROWCOUNT;    DBMS_OUTPUT.PUT_LINE('Registros afectados:INSERT INTO F554X11@jdedtadl:'||v_cont);
           
            data.pk_corp_flujoaprobacion.sp_flujoenviar(
                    p_id => V_NUMERO, --NUMERO DE VA
                    p_modulo => 'VTAS',
                    p_objeto => V_TIPO,--'PEDIDO', ---VA
                    p_objetodescripcion => V_NOMBRE_INVERSION,--- NOMBRE DE LA INVERSION ,
                    p_usuario => V_USUARIOCREA,--- USUARIOCREA
                    P_COMENTARIO =>'', 
                    p_compania => V_COMPANIA ,
                    p_tipo1 => V_AREA, ---  AREA 
                    p_tipo2 => V_TIPO,
                    p_exito => V_EXITO
            );
            if (V_EXITO=0)then
                RAISE_APPLICATION_ERROR(-20000, 'Error al enviar a ruta el autoconsumo'); 
            end if;
           
           
            PK_ICOM_PROCESOS.SP_correoAprobarGestionMuestra (P_IDINVERSION => P_IDINVERSION, 
                                P_USUARIO => V_USUARIOCREA, 
                                P_ORDENVENTA => V_NUMERO,
                                P_COMPANIA => V_COMPANIA) ;
        end if;
    END SP_CREARORDENAUTOCONSUMOMUESTRAS;
    
    procedure sp_finalizarprocesodistribucion(P_IDINVERSION number,P_IDPROCESO number,p_fechaini_dist date,p_fechafin_dist date)as
    begin
        update DATA.t_icom_inversiones set fechaini_dist =p_fechaini_dist ,fechafin_dist=p_fechafin_dist  where id= P_IDINVERSION;
        update DATA.t_icom_inversion_proceso  set PORCENTAJE=100  where IDINVERSION= P_IDINVERSION and IDPROCESO=P_IDPROCESO;
    end;
    
END PK_ICOM_PROCESOS;
/

