CREATE OR REPLACE EDITIONABLE PACKAGE BODY PK_INTC_SELLOUT AS
   function minify_json(p_json in clob) return clob is
      v_out    clob := empty_clob();
      v_char   varchar2(1);
      v_in_str boolean := false;
      v_escape boolean := false;
   begin
      dbms_lob.createtemporary(v_out, true);

      for i in 1 .. dbms_lob.getlength(p_json) loop
         v_char := dbms_lob.substr(p_json, 1, i);

         if v_in_str then
            dbms_lob.writeappend(v_out, 1, v_char);

            if v_escape then
               v_escape := false;
            elsif v_char = '\' then
               v_escape := true;
            elsif v_char = '"' then
               v_in_str := false;
            end if;
         else
            if v_char in (' ', chr(10), chr(13), chr(9)) then
               null;
            else
               dbms_lob.writeappend(v_out, 1, v_char);
               if v_char = '"' then
                  v_in_str := true;
               end if;
            end if;
         end if;
      end loop;

      return v_out;
   end minify_json;

   function f_lineaproceso return number as
      v_retorno number;
      l_unit    varchar2(512) := $$plsql_unit;
   begin
      v_retorno := 0;
      if utl_call_stack.dynamic_depth >= 2 then
         l_unit := utl_call_stack.concatenate_subprogram(
                      utl_call_stack.subprogram(2)
                   );
         v_retorno := utl_call_stack.unit_line(2);
      end if;
      return v_retorno;
   end f_lineaproceso;

    /** funcion que retorna la trama para llamar al Api de correo electronico
    */
   function f_creatramacorreo(
      p_codigocliente varchar2,
      p_correo        varchar2,
      p_dominio       varchar2,
      p_archivo       varchar2,
      p_tipoarchivo   varchar2,
      p_separador     varchar2,
      p_idarchivo     varchar2,
      p_filainicio    number,
      p_tipo          in number,
      p_numerohoja    number default 0
   ) return clob is
      lv_trama         clob;
      cursor cur_datocorreo is
         select *
           from data.t_corp_udc
          where id_cabecera = 'TRAD_PARAM'
            and id_tabla in (2, 5)
          order by id_tabla;
      l_dato cur_datocorreo%rowtype;
   begin
      -- INICIO F_creatramacorreo

      lv_trama := '';

      if ((trim(p_correo) is null and trim(p_dominio) is null) or trim(p_tipoarchivo) is null) then
         -- F_creatramacorreo: retorna vacio por parametros incompletos

         return lv_trama;
      end if;

      open cur_datocorreo;
      fetch cur_datocorreo into l_dato;

      if cur_datocorreo%notfound then
         close cur_datocorreo;
         -- F_creatramacorreo: retorna vacio sin configuracion correo

         return lv_trama;
      end if;

     lv_trama := '{
             "correo": "' || l_dato.valor || '" ,
             "clave": "' || l_dato.valor2 || '" ,
             "cliente" : "' || nvl(p_correo, '') || '" ,
             "formatofecha" : "" ,
             "dominio" : "' || nvl(p_dominio, '') || '" ,
             "carpeta" : "' || nvl(l_dato.descripcion2, '') || '",
             "fecha" : "' || to_char(sysdate,'DD/MM/YYYY')|| '",
             "archivo" : "' || nvl(p_archivo, '') || '" ,
             "tipoArchivo" : "' || p_tipoarchivo || '" ,
             "sepaparadorArchivo" : "' || nvl(p_separador, '') || '" ,
             "idArchivo" : "' || p_idarchivo || '" ,
             "filaInicio" : "' || p_filainicio || '" ,
             "numeroHoja" : "' || NVL(p_numerohoja, 0) || '" ,
             "tipo" : "' || p_tipo || '" ,';


--      lv_trama := '{
--         "correo": "' || l_dato.valor || '" ,
--         "clave": "' || l_dato.valor2 || '" ,
--         "cliente" : "' || nvl(p_correo, '') || '" ,
--         "formatofecha" : "" ,
--         "dominio" : "' || nvl(p_dominio, '') || '" ,
--         "carpeta" : "' || nvl(l_dato.descripcion2, '') || '",
--         "fecha" : "' || to_char(sysdate-1) || '",
--         "archivo" : "' || nvl(p_archivo, '') || '" ,
--         "tipoArchivo" : "' || p_tipoarchivo || '" ,
--         "sepaparadorArchivo" : "' || nvl(p_separador, '') || '" ,
--         "idArchivo" : "' || p_idarchivo || '" ,
--         "filaInicio" : "' || p_filainicio || '" ,
--         "numeroHoja" : "0" ,
--         "tipo" : "' || p_tipo || '" ,';

      fetch cur_datocorreo into l_dato;

      if cur_datocorreo%notfound then
         lv_trama := '';
         close cur_datocorreo;
         -- F_creatramacorreo: retorna vacio sin configuracion conexion

         return lv_trama;
      end if;
      lv_trama := lv_trama || '
         "conexion": {
            ' || chr(10) || chr(9) || '"host": "' || l_dato.valor || '",
            ' || chr(10) || chr(9) || '"socketFactoryPort": "' || l_dato.valor2 || '",
            ' || chr(10) || chr(9) || '"socketFactoryClass": "' || l_dato.descripcion2 || '",
            ' || chr(10) || chr(9) || '"port": "' || l_dato.descripcion3 || '"
         }
      }';

      close cur_datocorreo;
      -- FIN F_creatramacorreo

      return lv_trama;
   exception
      when others then
         -- F_creatramacorreo: ERROR

         raise;
   end f_creatramacorreo;

   /** funcion que retorna la trama para llamar al Api de lectura FTP
   */
   function f_creatramaftp(
      p_codigocliente varchar2,
      p_compania      varchar2,
      p_archivo       varchar2,
      p_tipoarchivo   varchar2,
      p_separador     varchar2,
      p_idarchivo     varchar2,
      p_filainicio    number,
      p_tipo          in number,
      p_numerohoja    number default 0
   ) return clob is
      lv_trama    clob;
      lv_host     varchar2(399);
      lv_port     varchar2(399);
      lv_carpeta  varchar2(399);
      lv_usuario  varchar2(399);
      lv_clave    varchar2(399);
   begin
      -- INICIO F_creatramaftp

      lv_trama := '';

      if p_tipoarchivo is null or p_tipoarchivo = '' then
         -- F_creatramaftp: retorna vacio por tipoarchivo incompleto

         return lv_trama;
      end if;

      select descripcion, descripcion2, descripcion3, valor, valor2
        into lv_host, lv_port, lv_carpeta, lv_usuario, lv_clave
        from data.vt_trad_datossftp
       where id_tabla = p_codigocliente
         and compania = p_compania;

      lv_trama := '{
         "correo": "' || lv_usuario || '",
         "clave": "' || lv_clave || '",
         "carpeta": "/tmp",
         "formatofecha" : "" ,
         "archivo" : "' || nvl(p_archivo, '') || '" ,
         "tipoArchivo" : "' || p_tipoarchivo || '" ,
         "sepaparadorArchivo": "' || nvl(p_separador, '') || '",
         "idArchivo" : "' || p_idarchivo || '" ,
         "filaInicio" : "' || p_filainicio || '" ,
         "numeroHoja" : "' || NVL(p_numerohoja, 0) || '" ,
         "tipo" : "' || p_tipo || '",
         "conexion": {
            "host": "' || lv_host || '",
            "port": "' || lv_port || '"
         }
      }';

      -- FIN F_creatramaftp

      return lv_trama;
   exception
      when others then
         -- F_creatramaftp: ERROR

         raise;
   end f_creatramaftp;

   /*Procedmiento de lectura de datos para todos los clientes
    p_tipo 1 SELLOUT / 2 INVENTARIO
    PK_INTC_SELLOUT.SP_LECTURADATOS(p_compania=>, '00001', p_codigocliente=>58321);
   */
  /** Procedimiento que envia un correo al ejecutivo del cliente cuando no existe homologacion de un producto
  *
  *
   */
   function f_notificaejecutivo(p_id_archivo number,p_codigocliente varchar2,p_compania varchar2,p_idproceso_cargadatos number) return number is
      v_exito            number := 1;
      v_notificacion     number;
      v_ejecutivo        varchar2(250);
      v_codigo           varchar2(4000);
      v_correo           data.vt_corp_usuario.email%type;
      lv_correoadicional varchar2(250);
      v_clientenombre    data.vt_gzm_cliente.nombres%type;
      vc_body            clob;
      v_encuentra        boolean := false;
   begin
      -- INICIO F_notificaejecutivo

      select max(valor) into v_notificacion from data.t_corp_udc where id_cabecera = 'TRAD_PARAM' and id_tabla = '7';
      select max(valor) into lv_correoadicional from data.t_corp_udc where id_cabecera = 'TRAD_PARAM' and id_tabla = '1';
      -- F_notificaejecutivo: busca productos sin homologar

      for codigos in (
         select distinct trim(codigoproducto_cliente) txt45
           from data.t_trad_sellout
          where trim(codigoproducto) is null
            and trim(codigoproducto_cliente) is not null
      ) loop
         if v_encuentra then
            v_codigo := v_codigo || ', ' || codigos.txt45;
         else
            v_codigo := ' codigo de producto ' || codigos.txt45;
            v_encuentra := true;
         end if;
      end loop;
      -- F_notificaejecutivo: termina busqueda productos sin homologar

      if v_encuentra then
         -- F_notificaejecutivo: consulta ejecutivo cliente

         select vcli.nombres, vcu.nombres || ' ' || vcu.apellidos, vcu.email
           into v_clientenombre, v_ejecutivo, v_correo
           from data.vt_gzm_cliente vcli
           left join data.vt_corp_usuario vcu on vcli.ejecutivo like vcu.numeroidentificacion
          where vcli.compania = p_compania
            and vcli.codigocliente = p_codigocliente
            and vcli.estado = 1
            and vcu.estado = 1;

         vc_body := '<p>Estimado ' || v_ejecutivo || ',</p>';
         vc_body := '<p><br></p>';
         vc_body := '<p>No existe Homologacion del producto con ' || v_codigo || '  en el cliente ' || v_clientenombre || ', por favor ingresar la codificacion. </p>';
         vc_body := '<p><br></p>';
         vc_body := '<p>Atentamente,</p>';
         vc_body := '<p>Area de TRADE</p>';
         v_correo := v_correo || ',' || lv_correoadicional;
         if v_notificacion = 0 then
            v_correo := lv_correoadicional;
         end if;
         -- F_notificaejecutivo: envia correo homologacion

         pk_corp_correo.sp_envio(
            p_modulo  => 'TRAD',
            p_to      => v_correo || ',' || lv_correoadicional,
            p_from    => 'notificacion@zaimella.com',
            p_subject => 'Homologacion del producto',
            p_body    => vc_body
         );
         v_mensajeauditoria:='Existen productos sin homologar, y se notifico a los usuarios: ' || v_correo || ',' || lv_correoadicional;
         sp_archivoauditoria(p_id_archivo=> p_id_archivo,p_mensaje=> v_mensajeauditoria,p_codigocliente  => p_codigocliente);commit;
      end if;

      v_encuentra := false;
      -- F_notificaejecutivo: busca productos sin PVP

      for codigos in (
         select distinct trim(codigobarra) txt44
           from data.t_trad_sellout
          where id_proceso_cargadatos = p_idproceso_cargadatos and valorunidad is null and valortotal is null and valorunidad > 0 and length(nvl(codigobarra, ' ')) > 1
      ) loop
         if v_encuentra then
            v_codigo := v_codigo || ', ' || codigos.txt44;
         else
            v_codigo := ' codigo de barra ' || codigos.txt44;
            v_encuentra := true;
         end if;
      end loop;
      -- F_notificaejecutivo: termina busqueda productos sin PVP


      if v_encuentra then
         select max(valor) into lv_correoadicional from data.t_corp_udc where id_cabecera = 'TRAD_PARAM' and id_tabla = '8';

         vc_body := '<p>Estimado</p>';
         vc_body := '<p><br></p>';
         vc_body := '<p>No existe PVP del producto con ' || v_codigo || '  en el cliente ' || v_clientenombre || ', por favor ingresar la codificacion. </p>';
         vc_body := '<p><br></p>';
         vc_body := '<p>Atentamente,</p>';
         vc_body := '<p>area de TRADE</p>';

         -- F_notificaejecutivo: envia correo PVP

         pk_corp_correo.sp_envio(
            p_modulo  => 'TRAD',
            p_to      => lv_correoadicional,
            p_from    => 'notificacion@zaimella.com',
            p_subject => 'PVP del producto',
            p_body    => vc_body
         );
      end if;
      v_mensajeauditoria:='Termina el proceso homologacion';
      sp_archivoauditoria(p_id_archivo=> p_id_archivo,p_mensaje=> v_mensajeauditoria,p_codigocliente  => p_codigocliente);commit;
      -- FIN F_notificaejecutivo

      return v_exito;
   exception when others then
        v_mensajeauditoria:='Error al enviar correo de homologacion. SQLERRM: ' || sqlerrm || ' TRACE: ' || dbms_utility.format_error_backtrace;
        -- F_notificaejecutivo: ERROR

        sp_archivoauditoria(p_id_archivo=> p_id_archivo,p_estado => 0,p_mensaje=> v_mensajeauditoria,p_codigocliente  => p_codigocliente);commit;
        v_exito := 0;
        return v_exito;
   end f_notificaejecutivo;

   procedure sp_lecturadatos(
      p_idmapeo      in number default null,
      p_tipoproceso  in varchar2 default 'AUT',
      p_usuario      in varchar2 default 'INTC'
   ) is
      ln_resultado    varchar2(399) := '';
      ln_maximoerror  number := 0;
      v_contador      number := 0;
      v_numeroarchivo number := 0;
      v_usuario       varchar2(399) ;
      p_param01       varchar2(399);
      p_param02      clob;
      v_tipoarchivo_original varchar2(50);
      v_numerohoja_original  number;
      v_hoja_original        varchar2(255);
      v_separador_original   varchar2(50);
      v_separador_proceso    varchar2(50);
      v_tipoarchivo_proceso  varchar2(50);
      v_forzar_csv           number := 0;
      v_archivo_nombre       files.t_apex_archivos.filename%type;
      v_archivo_mimetype     files.t_apex_archivos.mimetype%type;
      v_archivo_es_excel     number := 0;
      v_url_conversion_csv   varchar2(4000);
      v_body_conversion_csv  clob;
      v_resp_conversion_csv  clob;
      v_msg_conversion_csv   varchar2(4000);
      v_numerohoja_conversion number;
      v_linea_csv            varchar2(32767);
      v_cant_coma            number;
      v_cant_pipe            number;
      v_cant_punto_coma      number;
      v_fecha_ini_delete     date;
      v_fecha_fin_delete     date;
      v_id_auditoria         number;

   begin
        l_usuario:=SUBSTR(p_usuario, 1, 20);
        v_usuario:=l_usuario;
        -- INICIO SP_lecturadatos



        for l_mapeo in (
            select * from data.t_corp_mapeo_excel cso
            where estado = 1
            and tabla_destino = 'T_TRAD_SELLOUT'
            and (cso.id = p_idmapeo or p_idmapeo is null)
            and ((p_idmapeo is null and tipo <> 'MAN') or p_idmapeo is not null )
        ) loop
            begin


            -- INC71: l_mapeo ya es la fila vigente; evita una lectura duplicada del mapeo.
            v_mapeo := l_mapeo;
            v_tipoarchivo_original := l_mapeo.tipoarchivo;
            v_numerohoja_original  := l_mapeo.numerohoja;
            v_hoja_original        := l_mapeo.hoja;
            v_separador_original   := l_mapeo.separador;
            v_separador_proceso    := l_mapeo.separador;
            v_tipoarchivo_proceso  := l_mapeo.tipoarchivo;
            v_forzar_csv           := case when upper(trim(l_mapeo.tipo)) in ('COR','FTP') then 1 else 0 end;

            if v_forzar_csv = 1 then
                v_tipoarchivo_proceso := 'CSV';
                -- SP_lecturadatos: tipo COR/FTP se procesara como CSV

            end if;
            -- SP_lecturadatos: inicia mapeo


            DELETE FROM data.t_trad_archivoauditoria
            WHERE codigocliente = v_mapeo.codigo
              AND tipo = 1  AND fecha <= TRUNC(SYSDATE) - 3;commit;
            -- SP_lecturadatos: limpia auditoria antigua


                g_compania := l_mapeo.compania;
                ln_resultado := '';
               v_id_auditoria := TO_NUMBER(TO_CHAR(SYSTIMESTAMP, 'DDMMYYHH24MISSFF3'));

               DELETE FROM data.t_intc_control_archivo
                WHERE tipo = 1
                  AND codigocliente = l_mapeo.codigo
                  AND compania = l_mapeo.compania;
               COMMIT;

               INSERT INTO data.t_intc_control_archivo(
                  idarchivo, tipo, tipocarga, codigocliente, proceso,
                  estado, mensajeerror, compania, usercrea, fechainicio
               ) VALUES (
                  v_id_auditoria, 1, l_mapeo.tipo, l_mapeo.codigo, 'INTC_CRTLP',
                  1, 'Proceso en ejecucion', l_mapeo.compania, l_usuario, SYSTIMESTAMP
               );
               COMMIT;

               v_mensajeauditoria := 'Inicio del proceso Sellout codigogrupo: '||l_mapeo.codigo||', archivo pendiente';
               sp_archivoauditoria(
                  p_id_archivo => v_id_auditoria,
                  p_columna => 0,
                  p_fila => 1,
                  p_mensaje => v_mensajeauditoria,
                  p_codigocliente => l_mapeo.codigo
               );
                if v_forzar_csv = 0 and trim(l_mapeo.tipoarchivo) = 'XLSX' and trim(nvl(l_mapeo.NUMEROHOJA, 0)) = 0 then
                    v_mensajeauditoria:='Debe definir una hoja del archivo a ser procesada';
                    sp_archivoauditoria(p_id_archivo => l_mapeo.id,p_estado => 0,p_columna => 0,p_fila => f_lineaproceso,p_mensaje => v_mensajeauditoria,p_codigocliente => l_mapeo.codigo);
                    -- SP_lecturadatos: ERROR validacion hoja XLSX

                    raise_application_error(-20001, v_mensajeauditoria);
                end if;

                begin
                    -- SP_lecturadatos: busca archivo pendiente

                    select max(numeroarchivo) into v_numeroarchivo  from files.t_apex_archivos a where tabla='T_CORP_MAPEO_EXCEL' and id_tabla=l_mapeo.id  group by id_tabla;
                    ln_resultado := 1;
                    -- SP_lecturadatos: archivo pendiente localizado


                    begin
                        select filename,
                               mimetype,
                               case
                                 when dbms_lob.substr(blobcontent, 4, 1) = hextoraw('504B0304') then 1
                                 when dbms_lob.substr(blobcontent, 8, 1) = hextoraw('D0CF11E0A1B11AE1') then 1
                                 else 0
                               end
                          into v_archivo_nombre, v_archivo_mimetype, v_archivo_es_excel
                          from files.t_apex_archivos
                         where numeroarchivo = v_numeroarchivo;
                    exception
                        when no_data_found then
                            v_archivo_nombre := null;
                            v_archivo_mimetype := null;
                            v_archivo_es_excel := 0;
                    end;

                    if upper(nvl(v_archivo_nombre, '')) like '%.CSV'
                       or upper(nvl(v_archivo_mimetype, '')) like '%CSV%' then
                        v_forzar_csv := 1;
                        v_tipoarchivo_proceso := 'CSV';
                        v_archivo_es_excel := 0;
                        -- SP_lecturadatos: archivo pendiente CSV detectado

                    end if;
                    -- INC18_SELLOUT_MAN_CSV_PENDIENTE_20260611

                    if upper(trim(l_mapeo.tipo)) in ('MAN', 'COR', 'FTP')
                       and (v_archivo_es_excel = 1
                            or upper(nvl(v_archivo_nombre, '')) like '%.XLS%'
                            or upper(nvl(v_archivo_mimetype, '')) like '%SPREADSHEET%') then
                        if v_archivo_es_excel = 1
                           and upper(nvl(v_archivo_nombre, '')) not like '%.XLS%'
                           and upper(nvl(v_archivo_mimetype, '')) not like '%SPREADSHEET%' then
                            update files.t_apex_archivos
                               set filename = case
                                                when instr(filename, '.') > 0 then regexp_replace(filename, '\.[^.]+$', '.xlsx')
                                                else filename || '.xlsx'
                                              end,
                                   mimetype = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                                   observacion = substr(nvl(observacion || ';', '') || 'CONTENIDO_XLSX_RENOMBRADO=SI', 1, 4000)
                             where numeroarchivo = v_numeroarchivo;
                            commit;

                            select filename, mimetype
                              into v_archivo_nombre, v_archivo_mimetype
                              from files.t_apex_archivos
                             where numeroarchivo = v_numeroarchivo;

                            -- SP_lecturadatos: metadata de archivo XLSX normalizada

                        end if;

                        select valor
                          into v_url_conversion_csv
                          from data.t_corp_udc
                         where id_cabecera = 'WEBSERVICE'
                           and id_tabla = '17'
                           and activo = '1';

                        v_numerohoja_conversion := case
                                                     when nvl(l_mapeo.numerohoja, 0) = 0 then 1
                                                     else l_mapeo.numerohoja
                                                   end;
                        v_body_conversion_csv := '{"numeroArchivo":' || v_numeroarchivo ||
                                                 ',"numeroHoja":' || to_char(v_numerohoja_conversion) || '}';

                        apex_web_service.g_request_headers(1).name := 'Content-Type';
                        apex_web_service.g_request_headers(1).value := 'application/json';

                        v_resp_conversion_csv := apex_web_service.make_rest_request(
                            p_url => v_url_conversion_csv,
                            p_http_method => 'POST',
                            p_body => v_body_conversion_csv
                        );

                        apex_json.parse(v_resp_conversion_csv);

                        if apex_json.get_varchar2('exito') = 'true' then
                            select filename,
                                   mimetype,
                                   case
                                     when dbms_lob.substr(blobcontent, 4, 1) = hextoraw('504B0304') then 1
                                     when dbms_lob.substr(blobcontent, 8, 1) = hextoraw('D0CF11E0A1B11AE1') then 1
                                     else 0
                                   end,
                                   regexp_substr(utl_raw.cast_to_varchar2(dbms_lob.substr(blobcontent, 2000, 1)), '^[^' || chr(10) || chr(13) || ']*')
                              into v_archivo_nombre, v_archivo_mimetype, v_archivo_es_excel, v_linea_csv
                              from files.t_apex_archivos
                             where numeroarchivo = v_numeroarchivo;

                            if v_archivo_es_excel = 1 then
                                raise_application_error(
                                    -20311,
                                    'El conversor reporto exito pero el archivo sigue en formato Excel. NumeroArchivo=' || v_numeroarchivo
                                );
                            end if;

                            v_cant_coma := length(v_linea_csv) - length(replace(v_linea_csv, ',', ''));
                            v_cant_pipe := length(v_linea_csv) - length(replace(v_linea_csv, '|', ''));
                            v_cant_punto_coma := length(v_linea_csv) - length(replace(v_linea_csv, ';', ''));

                            v_separador_proceso := case
                                                      when v_cant_coma >= v_cant_pipe and v_cant_coma >= v_cant_punto_coma and v_cant_coma > 0 then ','
                                                      when v_cant_pipe >= v_cant_coma and v_cant_pipe >= v_cant_punto_coma and v_cant_pipe > 0 then '|'
                                                      when v_cant_punto_coma > 0 then ';'
                                                      else v_separador_original
                                                    end;
                            v_forzar_csv := 1;
                            v_tipoarchivo_proceso := 'CSV';
                            v_mensajeauditoria := 'Archivo Sellout convertido a CSV antes del mapeo. NumeroArchivo=' || v_numeroarchivo;
                            sp_archivoauditoria(p_id_archivo => v_numeroarchivo,p_columna => 0,p_fila => f_lineaproceso,p_mensaje => v_mensajeauditoria,p_codigocliente => l_mapeo.codigo);
                            -- SP_lecturadatos: archivo convertido a CSV

                        else
                            if apex_json.does_exist('resultado') then
                                v_msg_conversion_csv := apex_json.get_varchar2('resultado');
                            else
                                v_msg_conversion_csv := apex_json.get_varchar2('mensaje');
                            end if;
                            raise_application_error(-20310, 'No se pudo convertir archivo manual Sellout a CSV. ' || v_msg_conversion_csv);
                        end if;
                    end if;
                exception
                    when no_data_found then
                        v_numeroarchivo:=null;
                        ln_resultado := 0;
                        -- SP_lecturadatos: no existe archivo pendiente

                    when others then
                        if v_numeroarchivo is not null then
                            ln_resultado := 0;
                            -- SP_lecturadatos: ERROR procesando archivo pendiente

                            raise;
                        else
                            v_numeroarchivo:=null;
                            ln_resultado := 0;
                            -- SP_lecturadatos: no existe archivo pendiente

                        end if;
                end;

                if (v_numeroarchivo is null )then
                    v_start_time := DBMS_UTILITY.GET_TIME;
                    if (l_mapeo.tipo <> 'MAN')then
                        -- SP_lecturadatos: llama WS lectura archivo

                        pk_intc_sellout.sp_llamar_ws(
                            p_codigocliente => to_char(l_mapeo.codigo),
                            p_compania      => to_char(l_mapeo.compania),
                            p_tipodescarga  => to_char(l_mapeo.tipo),
                            p_correo        => to_char(l_mapeo.correo),
                            p_dominio       => to_char(l_mapeo.dominio),
                            p_archivonombre => to_char(l_mapeo.nombre),
                            p_separador     => to_char(l_mapeo.separador),
                            p_id_archivo    => l_mapeo.id,
                            p_archivotipo   => to_char(l_mapeo.tipo),
                            p_mes           => l_mapeo.mesinicio,
                            p_filainicio    => l_mapeo.iniciofila,
                            p_tipo          => 1,
                            p_usuario       => v_usuario,
                            p_exito         => ln_resultado,
                            p_numeroarchivo => v_numeroarchivo
                        );
                        v_end_time := DBMS_UTILITY.GET_TIME; v_elapsed_time := (v_end_time - nvl(v_start_time,v_end_time)) / 100;
                        -- SP_lecturadatos: termina WS lectura archivo

                    else
                        v_mensajeauditoria:='NO EXISTE ARCHIVO CARGADO';
                        sp_archivoauditoria(p_id_archivo => l_mapeo.id,p_estado => 0,p_columna => 0,p_fila => f_lineaproceso,p_mensaje => v_mensajeauditoria,p_codigocliente => l_mapeo.codigo);
                        -- SP_lecturadatos: ERROR archivo manual no cargado

                        raise_application_error(-20001, v_mensajeauditoria);
                        v_numeroarchivo:=null;
                        ln_resultado := 0;
                    end if;
                end if;
                v_mensajeauditoria:='Numero de Archivo localizado:'||v_numeroarchivo;
                sp_archivoauditoria(p_id_archivo => v_numeroarchivo,p_columna => 0,p_fila => f_lineaproceso,p_mensaje => v_mensajeauditoria,p_codigocliente => l_mapeo.codigo);
                if (ln_resultado = 1) then

                    v_start_time := DBMS_UTILITY.GET_TIME;
                    v_mensajeauditoria:='Inicia lectura de archivo '||case l_mapeo.tipo when 'MAN' THEN 'Manual' when 'Correo' THEN 'Correo' when 'FTP' THEN 'FTP' END||': '||v_numeroarchivo;
                    sp_archivoauditoria(p_id_archivo => v_numeroarchivo,p_columna => 0,p_fila => f_lineaproceso,p_mensaje => v_mensajeauditoria,p_codigocliente => l_mapeo.codigo);

                    UPDATE T_CORP_MAPEO_EXCEL
                    SET ERRORCARGA = NULL,
                        ID_PROCESO_CARGADATOS = null
                    WHERE ID = l_mapeo.id;
                    COMMIT;
                    -- SP_lecturadatos: limpia estado de carga mapeo

                    -- SP_lecturadatos: inicia parser/mapeo excel

                    begin
                        if v_forzar_csv = 1 then
                            begin
                                select regexp_substr(utl_raw.cast_to_varchar2(dbms_lob.substr(blobcontent, 2000, 1)), '^[^' || chr(10) || chr(13) || ']*')
                                  into v_linea_csv
                                  from files.t_apex_archivos
                                 where numeroarchivo = v_numeroarchivo;

                                v_cant_coma := length(v_linea_csv) - length(replace(v_linea_csv, ',', ''));
                                v_cant_pipe := length(v_linea_csv) - length(replace(v_linea_csv, '|', ''));
                                v_cant_punto_coma := length(v_linea_csv) - length(replace(v_linea_csv, ';', ''));

                                v_separador_proceso := case
                                                          when v_cant_coma >= v_cant_pipe and v_cant_coma >= v_cant_punto_coma and v_cant_coma > 0 then ','
                                                          when v_cant_pipe >= v_cant_coma and v_cant_pipe >= v_cant_punto_coma and v_cant_pipe > 0 then '|'
                                                          when v_cant_punto_coma > 0 then ';'
                                                          else v_separador_original
                                                        end;
                            exception
                                when others then
                                    v_separador_proceso := v_separador_original;
                                    -- SP_lecturadatos: no se pudo detectar separador CSV

                            end;

                            update t_corp_mapeo_excel
                               set tipoarchivo = 'CSV',
                                   numerohoja = 0,
                                   hoja = null,
                                   separador = v_separador_proceso
                             where id = l_mapeo.id;
                            -- SP_lecturadatos: mapeo temporal actualizado a CSV

                        end if;

                        pk_corp_mapeo_excel.sp_procesar_mapeo_excel(l_mapeo.id,v_numeroarchivo,p_param01,p_param02,0);

                        if v_forzar_csv = 1 then
                            update t_corp_mapeo_excel
                               set tipoarchivo = v_tipoarchivo_original,
                                   numerohoja = v_numerohoja_original,
                                   hoja = v_hoja_original,
                                   separador = v_separador_original
                             where id = l_mapeo.id;
                            commit;
                            -- SP_lecturadatos: mapeo temporal CSV restaurado

                        end if;
                    exception
                        when others then
                            if v_forzar_csv = 1 then
                                update t_corp_mapeo_excel
                                   set tipoarchivo = v_tipoarchivo_original,
                                       numerohoja = v_numerohoja_original,
                                       hoja = v_hoja_original,
                                       separador = v_separador_original
                                 where id = l_mapeo.id;
                                commit;
                                -- SP_lecturadatos: mapeo temporal CSV restaurado por error

                            end if;
                            raise;
                    end;
                    -- SP_lecturadatos: termina parser/mapeo excel


                    IF REGEXP_LIKE(p_param01, '^\d+$') THEN
                        UPDATE data.t_trad_archivoauditoria
                           SET id_archivo = TO_NUMBER(p_param01)
                         WHERE codigocliente = l_mapeo.codigo
                           AND compania = l_mapeo.compania
                           AND tipo = 1
                           AND usuariocreacion = v_usuario
                           AND id_archivo <> TO_NUMBER(p_param01)
                           AND fecha >= (
                             SELECT NVL(MAX(fechainicio), SYSTIMESTAMP - INTERVAL '1' HOUR)
                               FROM data.t_intc_control_archivo
                              WHERE tipo = 1
                                AND codigocliente = l_mapeo.codigo
                                AND compania = l_mapeo.compania
                                AND fechafin IS NULL
                           );
                        COMMIT;
                        -- SP_lecturadatos: auditoria temporal reemplazada por id proceso

                    END IF;

                    ln_resultado:=case when p_param02 is null then 1 else 0 end;

                    v_end_time := DBMS_UTILITY.GET_TIME; v_elapsed_time := (v_end_time - nvl(v_start_time,v_end_time)) / 100;
                    v_mensajeauditoria:='Terimina lectura de archivo '||case when p_param02 is null then 'con exito ' else 'con error ' end||': '||v_numeroarchivo||''||case when p_param02 is not null then ' Erro: '|| p_param02 end;
                    sp_archivoauditoria(p_id_archivo => v_numeroarchivo,p_columna => 0,p_estado => case when p_param02 is null then 1 else 0 end,p_fila => f_lineaproceso,p_mensaje => v_mensajeauditoria,p_codigocliente => l_mapeo.codigo);
                    UPDATE DATA.t_trad_sellout
                        SET  usuariocreacion=nvl(v('user'),'TRAD')
                            ,fechacreacion=systimestamp
                            ,compania=l_mapeo.compania
                            ,CODIGOGRUPO=l_mapeo.codigo
                            ,valorunidad=nvl(valorunidad,0)
                            ,CODIGOCLIENTE=NVL(CODIGOCLIENTE,l_mapeo.codigo)
                    WHERE ID_PROCESO_CARGADATOS=p_param01;
                    -- SP_lecturadatos: actualiza metadata sellout cargado


                    if (ln_resultado = 1) then
                        l_mapeo.ID_PROCESO_CARGADATOS:=p_param01;
                        l_mapeo.ERRORCARGA:=p_param02;
                        v_mensajeauditoria:='Inicio del proceso Sellout codigogrupo: '||l_mapeo.codigo||', archivo='||v_numeroarchivo;
                        sp_archivoauditoria(p_id_archivo => v_id_auditoria,p_columna => 0,p_fila => 1,p_mensaje => v_mensajeauditoria,p_codigocliente => l_mapeo.codigo);


                        SELECT TRUNC(MIN(fecha), 'MM'),
                               ADD_MONTHS(TRUNC(MAX(fecha), 'MM'), 1)
                          INTO v_fecha_ini_delete,
                               v_fecha_fin_delete
                          FROM t_trad_sellout
                         WHERE id_proceso_cargadatos = p_param01;

                        v_rowafdected := 0;
                        IF v_fecha_ini_delete IS NOT NULL AND v_fecha_fin_delete IS NOT NULL THEN
                            DELETE FROM t_trad_sellout s
                             WHERE (s.id_proceso_cargadatos IS NULL OR s.id_proceso_cargadatos <> p_param01)
                               AND s.compania = l_mapeo.compania
                               AND s.codigogrupo = l_mapeo.codigo
                               AND s.fecha >= v_fecha_ini_delete
                               AND s.fecha < v_fecha_fin_delete;

                            v_rowafdected := SQL%ROWCOUNT;
                        END IF;
                        -- SP_lecturadatos: borra datos anteriores del mismo cliente/mes


                        v_mensajeauditoria:='Borrado de datos anteriores. Filas='||v_rowafdected;
                        sp_archivoauditoria(p_id_archivo => v_id_auditoria,p_columna => 0,p_fila => 2,p_mensaje => v_mensajeauditoria,p_codigocliente => l_mapeo.codigo);



                        -- SP_lecturadatos: inicia SP_procesar_sellout

                        v_start_time := DBMS_UTILITY.GET_TIME;
                        sp_procesar_sellout(
                            p_id_archivo           => v_numeroarchivo,
                            p_codigocliente        => l_mapeo.codigo,
                            p_compania             => l_mapeo.compania,
                            p_mes_procesar         => l_mapeo.mesinicio,
                            p_usuario              => v_usuario,
                            p_exito                => ln_resultado,
                            p_idproceso_cargadatos => p_param01
                        );
                        v_end_time := DBMS_UTILITY.GET_TIME; v_elapsed_time := (v_end_time - nvl(v_start_time,v_end_time)) / 100;
                        -- SP_lecturadatos: termina SP_procesar_sellout

                        v_mensajeauditoria:='Procesamiento Sellout ejecutado. Segundos='||v_elapsed_time;
                        sp_archivoauditoria(p_id_archivo => v_id_auditoria,p_columna => 0,p_fila => 3,p_mensaje => v_mensajeauditoria,p_codigocliente => l_mapeo.codigo);
                        v_mensajeauditoria:='Terminar proceso Sellout codigogrupo: '||l_mapeo.codigo;
                        sp_archivoauditoria(p_id_archivo => v_id_auditoria,p_columna => 0,p_fila => 4,p_mensaje => v_mensajeauditoria,p_codigocliente => l_mapeo.codigo);

                        UPDATE data.t_trad_archivoauditoria
                           SET id_archivo = TO_NUMBER(p_param01)
                         WHERE id_archivo = v_id_auditoria
                           AND codigocliente = l_mapeo.codigo
                           AND compania = l_mapeo.compania
                           AND tipo = 1;
                        COMMIT;

                    else
                          v_mensajeauditoria:='no sube el archivo:'||p_param02;
                        -- SP_lecturadatos: ERROR parser/mapeo devolvio error

                        sp_archivoauditoria(p_id_archivo => v_id_auditoria,p_columna => 0,p_fila => f_lineaproceso,p_estado => 0,p_mensaje => v_mensajeauditoria,p_codigocliente => l_mapeo.codigo);
                        UPDATE data.t_intc_control_archivo
                           SET estado = 0,
                               mensajeerror = SUBSTR(v_mensajeauditoria, 1, 3999),
                               fechafin = SYSTIMESTAMP,
                               usermodi = l_usuario,
                               fechmodi = SYSTIMESTAMP
                         WHERE tipo = 1
                           AND codigocliente = l_mapeo.codigo
                           AND compania = l_mapeo.compania
                           AND fechafin IS NULL;
                        COMMIT;

                        raise_application_error(-20021, v_mensajeauditoria);
                        v_numeroarchivo:=null;
                        ln_resultado := 0;

                    end if;
                end if;
                UPDATE files.t_apex_archivos SET TABLA ='T_CORP_MAPEO_EXCEL_PROCESADO'where numeroarchivo=v_numeroarchivo;
                        commit;
                -- SP_lecturadatos: marca archivo procesado

                -- SP_lecturadatos: fin mapeo

            exception when others then
                IF SQLCODE in ( -20001,-20020,-20021) THEN
                    v_mensajeauditoria:= CASE WHEN INSTR(SQLERRM, ':') > 0 THEN SUBSTR(SQLERRM, INSTR(SQLERRM, ':') + 2)ELSE SQLERRM END;
                else
                    v_mensajeauditoria:= CASE WHEN INSTR(SQLERRM, ':') > 0 THEN SUBSTR(SQLERRM, INSTR(SQLERRM, ':') + 2)ELSE SQLERRM END   || ' TRACE: ' || dbms_utility.format_error_backtrace;

                end if;
                UPDATE T_CORP_MAPEO_EXCEL
                    SET ERRORCARGA = v_mensajeauditoria,
                        FECHAULTIMACARGA = SYSTIMESTAMP,
                        USUARIOMODIFICACION=nvl(v('user'),'ORCL')
                WHERE ID = l_mapeo.id;
                sp_archivoauditoria(p_id_archivo => CASE WHEN REGEXP_LIKE(p_param01, '^\d+$') THEN TO_NUMBER(p_param01) ELSE v_numeroarchivo END,p_columna => 0,p_estado => 0,p_fila => 99,p_mensaje => v_mensajeauditoria,p_codigocliente => l_mapeo.codigo);
                -- SP_lecturadatos: ERROR mapeo/proceso


                commit;
            end;
        end loop;
        -- FIN SP_lecturadatos

    end sp_lecturadatos;

    /**
    Procedimiento que llama al api
    */
    procedure sp_llamar_ws(
        p_codigocliente varchar2,
        p_compania      varchar2,
        p_tipodescarga  varchar2,
        p_correo        varchar2,
        p_dominio       varchar2,
        p_archivonombre varchar2,
        p_separador     varchar2,
        p_id_archivo    number,
        p_archivotipo   varchar2,
        p_mes           number,
        p_filainicio    number,
        p_tipo          in number,
        p_usuario       in varchar2,
        p_exito         out number,
        p_numeroarchivo out number,
        p_numerohoja    in number default 0
    ) is
        lv_url          varchar2(399);
        lv_body         clob;
        lv_nombrearchivo varchar2(399);
        lc_resultado    clob;
   begin
      p_exito := 0;
      -- INICIO SP_llamar_ws

      select valor into lv_url from data.t_corp_udc where id_cabecera = 'WEBSERVICE' and id_tabla = 16;

        case trim(p_tipodescarga)
            when 'COR' then
                -- SP_llamar_ws: arma trama correo

                lv_url := lv_url || 'leercorreov2';
                lv_body := f_creatramacorreo(
                   p_codigocliente => p_codigocliente,
                   p_correo        => p_correo,
                   p_dominio       => p_dominio,
                   p_archivo       => p_archivonombre,
                   p_tipoarchivo   => p_archivotipo,
                   p_separador     => p_separador,
                   p_idarchivo     => p_id_archivo,
                   p_filainicio    => p_filainicio,
                   p_tipo          => p_tipo,
                   p_numerohoja    => p_numerohoja
                );
            when 'FTP' then
                -- SP_llamar_ws: arma trama ftp

                lv_url := lv_url || 'leerftpv2';
                lv_nombrearchivo := case when trim(p_archivonombre) is null then 'temporal' else p_archivonombre end;
                lv_body := f_creatramaftp(
                    p_codigocliente => p_codigocliente,
                    p_compania      => p_compania,
                    p_archivo       => lv_nombrearchivo,
                    p_tipoarchivo   => p_archivotipo,
                    p_separador     => p_separador,
                    p_idarchivo     => p_id_archivo,
                    p_filainicio    => p_filainicio,
                    p_tipo          => p_tipo,
                    p_numerohoja    => p_numerohoja
                );
            else
                lv_body := '';
                -- SP_llamar_ws: tipo descarga sin trama

        end case;
        --lv_body := minify_json(lv_body);
        f_imprimir_clob_completo(p_clob =>'lv_body:'||lv_body);
        p_exito := 1;
        if (dbms_lob.getlength(lv_body) > 1 )then
            -- SP_llamar_ws: inicia REST lectura archivo

            apex_web_service.g_request_headers(1).name  := 'Content-Type';
            apex_web_service.g_request_headers(1).value := 'application/json';

            lc_resultado := apex_web_service.make_rest_request( p_url=> lv_url,p_http_method => 'POST',p_body=> lv_body);
            -- SP_llamar_ws: termina REST lectura archivo


            f_imprimir_clob_completo(p_clob =>'lc_resultado:'||lc_resultado);

            apex_json.parse(lc_resultado);

            if apex_json.get_varchar2('exito') = 'true' then
                p_numeroarchivo := apex_json.get_varchar2('codigo');
                -- SP_llamar_ws: archivo generado por API

            else
                if apex_json.does_exist(p_path => 'resultado.mensaje') then
                    v_mensajeauditoria := 'Api de Lectura: ' || apex_json.get_varchar2(p_path => 'resultado.mensaje');
                else
                    v_mensajeauditoria := 'Api de Lectura: ' || apex_json.get_varchar2(p_path => 'mensaje');
                end if;
                -- SP_llamar_ws: ERROR API lectura

                raise_application_error(-20020, v_mensajeauditoria );
            end if;
        else
            v_mensajeauditoria := 'Error: faltan datos de configuracion del cliente en :' || p_tipodescarga;
            -- SP_llamar_ws: ERROR configuracion incompleta

            raise_application_error(-20001, v_mensajeauditoria );
        end if;
        -- FIN SP_llamar_ws

   exception
      when others then
         -- SP_llamar_ws: ERROR no controlado

         raise;
   end sp_llamar_ws;
/*****************************************************************************************************************************************************************/
--   /**
--      * Procedimiento que modifica toda la data de la temporal y la formatea de acuedo a lo parametrizado
--      * @param p_id_archivo es el id del archivo sellout donde se grabo el json
--      * @param p_codigocliente el codigo del cliente
--      * @param p_compania el codigo de la compania
--      * @param p_mes_procesar es el nomero de meses que se resta a la fecha actual para obtener la fecha de insercion
--      * @param p_exito out es 1:exito o 0:error
--      *
--      */
    procedure sp_procesar_sellout(
      p_id_archivo            number,
      p_codigocliente         varchar2,
      p_compania              varchar2,
      p_mes_procesar          number,
      p_usuario               in varchar2,
      p_exito                 out number,
      p_idproceso_cargadatos  number
   ) is
      v_tipo          number := 1;
      v_fechaini      date := null;
      v_fechafin      date := null;
      v_fechainicio_c45 timestamp := systimestamp;
   begin
      p_exito := 0;
      -- INICIO SP_procesar_sellout

      delete from data.t_trad_lectura_incorrectos
       where id_archivo = p_id_archivo
         and tipo = v_tipo
         and codigogrupo = p_codigocliente
         and compania = p_compania;
      -- SP_procesar_sellout: limpia lecturas incorrectas del archivo actual

      commit;
      -- C45_HOMOLOGACION_DETALLE_PRESERVA_ID_ARCHIVO

      -- INC71: se elimina la actualizacion precio-a-precio. Solo afectaba filas
      -- con VALORUNIDAD y VALORTOTAL nulos y asignaba VALORTOTAL = NULL * PVP,
      -- por lo que no cambiaba datos. T_TRAD_SELLOUT no tiene triggers en TEST.
      begin--ACTUALIZO EL CoDIGO DE BARRAS Y DIVIDO PARA EL FACTOR ESPECIFICADO POR CLIENTE
        v_mensajeauditoria:='Inicia proceso de homologacion';
        -- SP_procesar_sellout: inicia merge homologacion

        sp_archivoauditoria(p_id_archivo => p_id_archivo,p_columna => 0,p_fila => f_lineaproceso,p_mensaje => v_mensajeauditoria,p_codigocliente => p_codigocliente);
          MERGE INTO t_trad_sellout temp
        USING (
            SELECT rid,
                   codigobarra,
                   factor
            FROM (
                SELECT temp.rowid rid,
                       h.codigobarra,
                       h.factor,
                       ROW_NUMBER() OVER (
                           PARTITION BY temp.rowid
                           ORDER BY h.codigobarra
                       ) rn
                       ,temp.id_proceso_cargadatos
                       ,temp.valorunidad
                FROM t_trad_sellout temp
                INNER JOIN data.vt_intc_homologacion h
                    ON h.compania = p_compania
                   AND h.codigogrupo = temp.codigogrupo
                   AND h.codigoproductocliente=NVL(temp.codigoproducto_cliente,TRIM(temp.codigobarra))
                   AND h.estado = '1'
                WHERE temp.id_proceso_cargadatos=p_idproceso_cargadatos
            )
            WHERE rn = 1
        ) src
        ON (temp.rowid = src.rid)
        WHEN MATCHED THEN
            UPDATE SET  temp.codigobarra = src.codigobarra,
                        temp.valorunidad    = temp.valorunidad / NVL(src.factor, 1)
        WHERE temp.id_proceso_cargadatos = p_idproceso_cargadatos;

        v_rowafdected  := sql%rowcount;
        v_mensajeauditoria:='termina proceso de homologacion';
        -- SP_procesar_sellout: termina merge homologacion

        sp_archivoauditoria(p_id_archivo => p_id_archivo,p_columna => 0,p_fila => f_lineaproceso,p_mensaje => v_mensajeauditoria,p_codigocliente => p_codigocliente);

        -- C45: valida codigos de barra no existentes en el catalogo Zaimella.
        UPDATE data.t_trad_sellout sell
           SET sell.codigoproducto_cliente = TRIM(sell.codigobarra),
               sell.nombreproducto_cliente = NVL(sell.nombreproducto_cliente, TRIM(sell.codigobarra)),
               sell.codigoproducto = NULL,
               sell.codigobarra = NULL
         WHERE sell.id_proceso_cargadatos = p_idproceso_cargadatos
           AND sell.compania = p_compania
           AND TRIM(sell.codigobarra) IS NOT NULL
           AND NOT EXISTS (
                 SELECT 1
                   FROM data.vt_gzm_producto pro
                  WHERE pro.compania = p_compania
                    AND TRIM(pro.codigobarra) = TRIM(sell.codigobarra)
               );
        v_rowafdected := SQL%ROWCOUNT;
        -- SP_procesar_sellout: codigos de barra enviados a homologacion pendiente


      end;

      begin
         -- SP_procesar_sellout: calcula rango fechas del proceso

         select trunc(min(fecha), 'MONTH'),
                last_day(max(fecha))
           into v_fechaini, v_fechafin
           from data.t_trad_sellout
          where id_proceso_cargadatos = p_idproceso_cargadatos;
        commit;
        -- SP_procesar_sellout: inicia SP_procesar_resultados_lectura

        sp_procesar_resultados_lectura(v_tipo,p_id_archivo,p_codigocliente,p_compania,p_mes_procesar,'OK',p_usuario,f_lineaproceso,p_idproceso_cargadatos);
        UPDATE data.t_intc_control_archivo
           SET fechainicio = NVL(fechainicio, v_fechainicio_c45)
         WHERE idarchivo = p_id_archivo
           AND tipo = v_tipo
           AND codigocliente = p_codigocliente
           AND compania = p_compania;
        -- C45_FECHAS_CONTROL_SELLOUT_OK_INICIO
        -- SP_procesar_sellout: termina SP_procesar_resultados_lectura


        delete data.t_trad_sellout b
         where b.id_proceso_cargadatos = p_idproceso_cargadatos
           and round(nvl(b.valorunidad, 0), 4) = 0
           and round(nvl(b.valortotal, 0), 4) = 0;
           
        v_rowafdected := sql%rowcount;
        -- SP_procesar_sellout: elimina registros cero de tabla final

        if v_rowafdected > 0 then
          sp_archivoauditoria(
            p_id_archivo => p_id_archivo,
            p_columna => 0,
            p_fila => f_lineaproceso,
            p_mensaje => 'Se eliminan '||v_rowafdected||' registros en cero de Sellout',
            p_codigocliente => p_codigocliente
          );
        end if;
        commit;

        v_mensajeauditoria:='Inica proceso factor de conversion';
        sp_archivoauditoria(p_id_archivo=> p_id_archivo,p_mensaje=> v_mensajeauditoria,p_codigocliente  => p_codigocliente);

        -- SP_procesar_sellout: inicia factor conversion

        sp_control_factor_conversion(p_codigocliente,v_fechaini,v_fechafin,p_compania);
        v_mensajeauditoria:='termina proceso factor de conversion';
        -- SP_procesar_sellout: termina factor conversion

        sp_archivoauditoria(p_id_archivo => p_id_archivo,p_columna => 0,p_fila => f_lineaproceso,p_mensaje => v_mensajeauditoria,p_codigocliente => p_codigocliente);

        -- JBALCAZAR 2026-04-27: comentado porque eliminaba las filas validas de la carga,
        -- dejando solo registros con valorunidad y VALORTOTAL en cero.
        delete data.t_trad_sellout b
         where b.id_proceso_cargadatos = p_idproceso_cargadatos
           and b.compania = p_compania
           and (nvl(b.valorunidad,0) != 0 or nvl(b.valortotal,0) != 0)
           and exists (
                 select 1
                   from data.t_intc_producto_noregular n
                  where n.compania = b.compania
                    and n.codigogrupo = b.codigogrupo
                    and n.codigoproductocliente = b.codigoproducto_cliente
               );
        v_rowafdected  := sql%rowcount;
        -- SP_procesar_sellout: elimina no regulares con valores no cero

        UPDATE data.t_intc_control_archivo
           SET fechainicio = NVL(fechainicio, v_fechainicio_c45),
               fechafin = SYSTIMESTAMP
         WHERE idarchivo = p_id_archivo
           AND tipo = v_tipo
           AND codigocliente = p_codigocliente
           AND compania = p_compania;
        -- C45_FECHAS_CONTROL_SELLOUT_OK_FINAL

        v_mensajeauditoria:='termina proceso de sellout';
        sp_archivoauditoria(p_id_archivo => p_id_archivo,p_columna => 0,p_fila => f_lineaproceso,p_mensaje => v_mensajeauditoria,p_codigocliente => p_codigocliente);


     exception when others then
         v_mensajeauditoria :='Error al realizar la insercion en el sellout. SQLERRM: '||sqlerrm||' TRACE: '||dbms_utility.format_error_backtrace;
         -- SP_procesar_sellout: ERROR bloque post lectura

         sp_archivoauditoria(p_id_archivo=> p_id_archivo,p_estado => 0,p_mensaje=> v_mensajeauditoria,p_codigocliente  => p_codigocliente);commit;
         sp_procesar_resultados_lectura( v_tipo,p_id_archivo,p_codigocliente ,p_compania,p_mes_procesar,v_mensajeauditoria,p_usuario,f_lineaproceso,p_idproceso_cargadatos);
         UPDATE data.t_intc_control_archivo
            SET fechainicio = NVL(fechainicio, v_fechainicio_c45),
                fechafin = SYSTIMESTAMP
          WHERE idarchivo = p_id_archivo
            AND tipo = v_tipo
            AND codigocliente = p_codigocliente
            AND compania = p_compania;
         commit;
         -- C45_FECHAS_CONTROL_SELLOUT_ERROR_FINAL
         raise;
      end;
      p_exito := 1 ;
   end sp_procesar_sellout;



   /**
    * Guarda la homologacion de producto desde la pagina 308.
    * Inserta o actualiza DATA.T_INTC_HOMOLOGACION, registra FACTOR para Sellout,
    * FACTORINV para Inventario y aplica la homologacion al producto de los
    * ultimos tres meses sin reprocesar filas ya homologadas.
    */

   procedure sp_marcar_producto_noregular(
      p_idlectura             in number,
      p_idcontrol             in number,
      p_id_proceso_cargadatos in number default null,
      p_compania              in varchar2,
      p_usuario               in varchar2 default 'INTC',
      p_mensaje               out varchar2
   ) as
      v_codigogrupo           data.t_trad_lectura_incorrectos.codigogrupo%type;
      v_codigoproducto        data.t_trad_lectura_incorrectos.codigoproducto_cliente%type;
      v_compania              data.t_trad_lectura_incorrectos.compania%type;
      v_cantidad              number := 0;
      v_id_proceso            number := p_id_proceso_cargadatos;
      v_usuario               varchar2(100) := substr(nvl(p_usuario, nvl(v('USER'), user)), 1, 20);
      v_rows_sellout          number := 0;
      v_rows_inventario       number := 0;
      v_rows_lectura          number := 0;
   begin
      if p_idlectura is null then
         raise_application_error(-20101, 'Debe seleccionar el producto no regular.');
      end if;

      if p_idcontrol is null then
         raise_application_error(-20102, 'No se recibio el control del archivo.');
      end if;

      if v_id_proceso is null then
         select id_proceso_cargadatos
           into v_id_proceso
           from data.t_intc_control_archivo
          where id = p_idcontrol;
      end if;

      if v_id_proceso is null then
         raise_application_error(-20103, 'No se encontro el proceso de carga asociado al control.');
      end if;

      select l.codigogrupo,
             l.codigoproducto_cliente,
             l.compania,
             nvl(l.cantidad, nvl(l.totalcantidad, 0))
        into v_codigogrupo,
             v_codigoproducto,
             v_compania,
             v_cantidad
        from data.t_trad_lectura_incorrectos l
        join data.t_intc_control_archivo c
          on c.id = p_idcontrol
         and c.idarchivo = l.id_archivo
         and c.codigocliente = l.codigogrupo
         and c.compania = l.compania
       where l.id = p_idlectura
         and l.categoria = 'HOMOLOGACION'
         and c.id_proceso_cargadatos = v_id_proceso
         and l.compania = p_compania;

      merge into data.t_intc_producto_noregular n
      using (
         select v_codigogrupo codigogrupo,
                v_codigoproducto codigoproductocliente,
                v_compania compania
           from dual
      ) s
      on (
         n.codigogrupo = s.codigogrupo
         and n.codigoproductocliente = s.codigoproductocliente
         and n.compania = s.compania
      )
      when matched then update
         set n.estado = 1,
             n.usermodi = v_usuario,
             n.fechmodi = systimestamp
      when not matched then insert (
         id, codigogrupo, codigoproductocliente, estado, compania, usercrea, fechcrea
      ) values (
         (select nvl(max(id), 0) + 1 from data.t_intc_producto_noregular),
         s.codigogrupo, s.codigoproductocliente, 1, s.compania, v_usuario, systimestamp
      );

      delete from data.t_trad_sellout s
       where s.id_proceso_cargadatos = v_id_proceso
         and s.compania = v_compania
         and s.codigogrupo = v_codigogrupo
         and s.codigoproducto_cliente = v_codigoproducto;
      v_rows_sellout := sql%rowcount;

      delete from data.t_vtas_inventario i
       where i.id_proceso_cargadatos = v_id_proceso
         and i.compania = v_compania
         and i.codigogrupo = v_codigogrupo
         and i.codigoproducto_cliente = v_codigoproducto;
      v_rows_inventario := sql%rowcount;

      delete from data.t_trad_lectura_incorrectos
       where id = p_idlectura;
      v_rows_lectura := sql%rowcount;

      update data.t_intc_control_archivo
         set homologacion = greatest(nvl(homologacion, 0) - v_rows_lectura, 0),
             producto_no_regular = greatest(nvl(producto_no_regular, 0) - v_rows_lectura, 0),
             producto_no_regular_total = case
                when greatest(nvl(producto_no_regular, 0) - v_rows_lectura, 0) = 0 then 0
                else greatest(nvl(producto_no_regular_total, 0) - nvl(v_cantidad, 0), 0)
             end,
             id_proceso_cargadatos = v_id_proceso,
             usermodi = v_usuario,
             fechmodi = systimestamp
       where id = p_idcontrol;

      p_mensaje := 'Producto marcado como no regular. Sellout eliminados=' || v_rows_sellout ||
                   ', Inventario eliminados=' || v_rows_inventario || '.';
   exception
      when no_data_found then
         p_mensaje := 'No se encontro el producto seleccionado para el proceso de carga.';
         raise_application_error(-20104, p_mensaje);
      when others then
         p_mensaje := substr('Error al marcar producto no regular: ' || sqlerrm, 1, 3900);
         raise;
   end sp_marcar_producto_noregular;

   procedure sp_guardar_homologacion(
      p_idhomologacion        in number default null,
      p_codigogrupo           in varchar2,
      p_codigoproductocliente in varchar2,
      p_codigoproductozm      in varchar2,
      p_codigobarra           in varchar2,
      p_factor                in number default 1,
      p_factorinv             in number default 1,
      p_compania              in varchar2,
      p_idlectura             in number default null,
      p_idcontrol             in number default null,
      p_idfactor              in number default null,
      p_usuario               in varchar2 default 'INTC',
      p_idhomologacion_out    out number,
      p_mensaje               out varchar2,
      p_nombreproducto_cliente in varchar2 default null,
      p_id_proceso_cargadatos in number default null
   ) as
      v_id              number;
      v_factor          number := nvl(nullif(p_factor, 0), 1);
      v_factorinv       number := nvl(nullif(p_factorinv, 0), 1);
      v_fechainicio     date := add_months(trunc(sysdate), -3);
      v_usuario         varchar2(100) := substr(nvl(p_usuario, nvl(v('USER'), user)), 1, 20);
      v_codigoproductocliente varchar2(250) := trim(p_codigoproductocliente);
      v_codigobarra     varchar2(1270) := trim(p_codigobarra);
      v_rows_sellout    number := 0;
      v_rows_inventario number := 0;
      v_lectura_tipo    number := null;
      v_lectura_qty     number := 0;
      v_es_no_regular   number := 0;
      v_id_proceso_cargadatos number := p_id_proceso_cargadatos;
   begin
      if trim(p_codigogrupo) is null then
         raise_application_error(-20001, 'Debe seleccionar el grupo del cliente.');
      end if;

      if v_codigoproductocliente is null then
         raise_application_error(-20002, 'Debe seleccionar el producto cliente.');
      end if;

      if trim(p_codigoproductozm) is null then
         raise_application_error(-20003, 'Debe seleccionar el producto Zaimella.');
      end if;

      if v_codigobarra is null then
         raise_application_error(-20004, 'Debe seleccionar el codigo de barra del producto Zaimella.');
      end if;

      if v_factor <= 0 then
         raise_application_error(-20005, 'El Factor Sellout debe ser mayor a cero.');
      end if;

      if v_factorinv <= 0 then
         raise_application_error(-20006, 'El Factor Inventario debe ser mayor a cero.');
      end if;

      if v_id_proceso_cargadatos is null and p_idcontrol is not null then
         begin
            select id_proceso_cargadatos
              into v_id_proceso_cargadatos
              from data.t_intc_control_archivo
             where id = p_idcontrol;
         exception
            when no_data_found then
               v_id_proceso_cargadatos := null;
         end;
      end if;

      if p_idlectura is not null and v_id_proceso_cargadatos is null then
         raise_application_error(-20010, 'No se encontro el proceso de carga para homologar el producto seleccionado.');
      end if;

      -- INICIO SP_guardar_homologacion


      if p_idhomologacion is not null then
         v_id := p_idhomologacion;

         update data.t_intc_homologacion
            set codigogrupo = p_codigogrupo,
                codigoproductocliente = v_codigoproductocliente,
                codigoproductozm = p_codigoproductozm,
                codigobarra = v_codigobarra,
                producto_cliente_nombre = substr(trim(p_nombreproducto_cliente), 1, 300),
                factor = v_factor,
                factorinv = v_factorinv,
                compania = p_compania,
                estado = 1,
                usermodi = v_usuario,
                fechmodi = systimestamp
          where id = v_id;

         if sql%rowcount = 0 then
            raise_application_error(-20007, 'No se encontro la homologacion seleccionada para actualizar.');
         end if;
      else
         begin
            select id
              into v_id
              from data.t_intc_homologacion
             where compania = p_compania
               and codigogrupo = p_codigogrupo
               and codigoproductocliente = v_codigoproductocliente
               and estado = 1
               and rownum = 1;

            update data.t_intc_homologacion
               set codigoproductozm = p_codigoproductozm,
                   codigobarra = v_codigobarra,
                   producto_cliente_nombre = substr(trim(p_nombreproducto_cliente), 1, 300),
                   factor = v_factor,
                   factorinv = v_factorinv,
                   usermodi = v_usuario,
                   fechmodi = systimestamp
             where id = v_id;
         exception
            when no_data_found then
               insert into data.t_intc_homologacion (
                  codigogrupo,
                  codigoproductocliente,
                  codigoproductozm,
                  factor,
                  factorinv,
                  estado,
                  compania,
                  usercrea,
                  fechcrea,
                  codigobarra,
                  producto_cliente_nombre
               ) values (
                  p_codigogrupo,
                  v_codigoproductocliente,
                  p_codigoproductozm,
                  v_factor,
                  v_factorinv,
                  1,
                  p_compania,
                  v_usuario,
                  systimestamp,
                  v_codigobarra,
                  substr(trim(p_nombreproducto_cliente), 1, 300)
               )
               returning id into v_id;
         end;
      end if;

      update data.t_trad_sellout sell
         set sell.codigobarra = v_codigobarra,
             sell.codigoproducto = p_codigoproductozm,
             sell.valorunidad = sell.valorunidad / v_factor,
             sell.usuariomodifica = v_usuario,
             sell.fechamodifica = systimestamp
       where sell.compania = p_compania
         and sell.codigogrupo = p_codigogrupo
         and v_id_proceso_cargadatos is not null
         and sell.id_proceso_cargadatos = v_id_proceso_cargadatos
         and sell.codigoproducto_cliente = v_codigoproductocliente
         and sell.fecha >= v_fechainicio
         and (sell.codigobarra is null or sell.codigobarra <> v_codigobarra);
      v_rows_sellout := sql%rowcount;

      update data.t_vtas_inventario inv
         set inv.codigobarra = v_codigobarra,
             inv.cantidad = inv.cantidad * v_factorinv
       where inv.compania = p_compania
         and inv.codigogrupo = p_codigogrupo
         and v_id_proceso_cargadatos is not null
         and inv.id_proceso_cargadatos = v_id_proceso_cargadatos
         and inv.codigoproducto_cliente = v_codigoproductocliente
         and inv.fecha >= v_fechainicio
         and (inv.codigobarra is null or inv.codigobarra <> v_codigobarra);
      v_rows_inventario := sql%rowcount;

      if v_id is not null and p_idlectura is not null then
         begin
            select l.tipo,
                   nvl(l.cantidad, nvl(l.totalcantidad, 0)),
                   case
                     when exists (
                            select 1
                              from data.t_intc_producto_noregular nr
                             where nr.codigogrupo = l.codigogrupo
                               and nr.codigoproductocliente = l.codigoproducto_cliente
                               and nr.compania = l.compania
                               and nvl(nr.estado, 1) = 1
                          )
                     then 1
                     else 0
                   end
              into v_lectura_tipo,
                   v_lectura_qty,
                   v_es_no_regular
              from data.t_trad_lectura_incorrectos l
             where l.id = p_idlectura;
         exception
            when no_data_found then
               v_lectura_tipo := null;
               v_lectura_qty := 0;
               v_es_no_regular := 0;
         end;

         delete from data.t_trad_lectura_incorrectos
          where id = p_idlectura;

         update data.t_intc_control_archivo
            set homologacion = case
                  when v_es_no_regular = 1 then nvl(homologacion, 0)
                  else greatest(nvl(homologacion, 0) - 1, 0)
                end,
                producto_no_regular = case
                  when v_es_no_regular = 1 then greatest(nvl(producto_no_regular, 0) - 1, 0)
                  else nvl(producto_no_regular, 0)
                end,
                producto_no_regular_total = case
                  when v_es_no_regular = 1 and greatest(nvl(producto_no_regular, 0) - 1, 0) = 0 then 0
                  when v_es_no_regular = 1 then greatest(nvl(producto_no_regular_total, 0) - nvl(v_lectura_qty, 0), 0)
                  else nvl(producto_no_regular_total, 0)
                end,
                id_proceso_cargadatos = nvl(id_proceso_cargadatos, v_id_proceso_cargadatos),
                usermodi = v_usuario,
                fechmodi = systimestamp
          where id = p_idcontrol;
      elsif v_id is not null and p_idfactor is not null then
         update data.t_intc_control_factor_conversion
            set estado = 1,
                auditoriausuariomodificacion = v_usuario,
                auditoriafechamodificacion = systimestamp
          where codigobarra = p_codigobarra
            and codigoproductocli = p_codigoproductocliente
            and codigogrupo = p_codigogrupo;

         update data.t_intc_control_factor_conversion a
            set estado = 1,
                auditoriausuariomodificacion = v_usuario,
                auditoriafechamodificacion = systimestamp
          where a.codigobarra = p_codigobarra
            and a.codigoproductocli = p_codigoproductocliente
            and a.codigogrupo = p_codigogrupo
            and exists (
                  select 1
                    from data.vt_intc_homologacion b
                   where b.codigobarra = a.codigobarra
                     and b.codigogrupo = a.codigogrupo
                     and b.codigoproductozm = a.codigoproductozm
                );
      end if;

      -- INC18_NO_REGULAR_CONTROL_20260611
      commit;

      p_idhomologacion_out := v_id;
      p_mensaje := 'Homologacion guardada. Sellout actualizado: ' || v_rows_sellout ||
                   ', Inventario actualizado: ' || v_rows_inventario || '.';

      -- FIN SP_guardar_homologacion

   exception
      when others then
         rollback;
         -- SP_guardar_homologacion: ERROR

         raise;
   end sp_guardar_homologacion;
   -- INC19_P308_HOMOLOGACION_PAQUETE

    procedure sp_generadatos_tradlocalrucinfo (
       p_meses    number default 3,
       p_compania varchar2 default null
    ) as
       v_meses number := greatest(nvl(p_meses, 1), 0);
    begin
        -- INICIO SP_generadatos_tradlocalrucinfo

        merge into t_trad_local_ruc_info trad
           using (
                select CODIGOGRUPO,
                       codigocliente codcli,
                       codigolocal txt02,
                       ruc txt03,
                       max(nombrelocal) txt08,
                       UPPER(max(ciudad_cliente)) txt12,
                       UPPER(max(provdep_cliente)) txt13,
                       max(codificacion_cliente) txt14,
                       max(nombreruc) txt07,
                       max(categoria_cliente) txt15,
                       max(subcat_cliente) txt16,
                       max(segmentacion) txt17,
                       max(canal_cliente) txt18,
                       max(subcanal_cliente) txt19,
                       max(zona_cliente) txt20,
                       max(sede) txt21
                  from data.t_trad_sellout a
                 where fecha is not null
                   and (p_compania is null or a.compania = p_compania)
                   and fecha between trunc(add_months(sysdate, -v_meses), 'Month')
                   and last_day(sysdate)
                 group by CODIGOGRUPO, codigocliente, codigolocal, ruc
            ) temporal
            on (trad.codigocliente = temporal.codcli
                and nvl(trad.codigolocal, chr(0)) = nvl(temporal.txt02, chr(0))
                and nvl(trad.ruc, chr(0)) = nvl(temporal.txt03, chr(0)))
           when matched then
            update set  
            trad.nombre_local_cliente = nvl(temporal.txt08,trad.nombre_local_cliente),
                        trad.cuidad_cliente = nvl(temporal.txt12, trad.cuidad_cliente),
                        trad.prov_depto_cliente = nvl(temporal.txt13,trad.prov_depto_cliente),
                        trad.codificacion_cliente = nvl(temporal.txt14,trad.codificacion_cliente),
                        trad.nombre_cliente = nvl(temporal.txt07,trad.nombre_cliente),
                        trad.categoria_cliente = nvl(temporal.txt15, trad.categoria_cliente),
                        trad.subcategoria_cliente = nvl(temporal.txt16,trad.subcategoria_cliente),
                        trad.segmento_cliente = nvl(temporal.txt17,trad.segmento_cliente),
                        trad.canal_cliente = nvl(temporal.txt18,trad.canal_cliente),
                        trad.subcanal_cliente = nvl(temporal.txt19,trad.subcanal_cliente),
                        trad.zona_cliente = nvl(temporal.txt20,trad.zona_cliente),
                        trad.sede = nvl(temporal.txt21,trad.sede)
           when not matched then
           insert (CODIGOGRUPO, codigocliente, codigolocal, ruc, nombre_local_cliente,
                   cuidad_cliente, prov_depto_cliente, codificacion_cliente, nombre_cliente,
                   categoria_cliente, subcategoria_cliente, segmento_cliente, canal_cliente,
                   subcanal_cliente, zona_cliente, sede) values
                  (temporal.CODIGOGRUPO, temporal.codcli, temporal.txt02, temporal.txt03, temporal.txt08,
                   temporal.txt12, temporal.txt13, temporal.txt14, temporal.txt07,
                   temporal.txt15, temporal.txt16, temporal.txt17, temporal.txt18,
                   temporal.txt19, temporal.txt20, temporal.txt21);
        -- SP_generadatos_tradlocalrucinfo: termina merge local/ruc


        delete t_trad_local_ruc_info
         where codigopk in (
           select max(codigopk)
             from t_trad_local_ruc_info
            group by codigocliente, codigolocal, ruc
           having count(1) > 1
         );
        -- FIN SP_generadatos_tradlocalrucinfo
  
   end sp_generadatos_tradlocalrucinfo;

    procedure sp_archivoauditoria(
      p_id_archivo     in number,
      p_estado         in number default 1,
      p_columna        in number default null,
      p_mensaje        in varchar2,
      p_fila           number default null,
      p_codigocliente  in varchar default null
   ) is
      v_paso number;
   begin
      v_paso := p_fila;

      IF v_paso IS NULL THEN
         v_paso := CASE
                     WHEN UPPER(p_mensaje) LIKE 'INICIO DEL PROCESO%' THEN 1
                     WHEN UPPER(p_mensaje) LIKE 'BORRADO DE DATOS ANTERIORES%' THEN 2
                     WHEN UPPER(p_mensaje) LIKE 'PROCESAMIENTO SELLOUT%' THEN 3
                     WHEN UPPER(p_mensaje) LIKE 'TERMINAR PROCESO%' THEN 4
                     WHEN p_estado = 0 THEN 99
                   END;
      END IF;

      IF v_paso IS NULL OR v_paso NOT IN (1,2,3,4,99) THEN
         RETURN;
      END IF;

      UPDATE data.t_trad_archivoauditoria
         SET estado = p_estado,
             columna = p_columna,
             msg_error = p_mensaje,
             fila = v_paso,
             fecha = systimestamp,
             usuariomodifica = l_usuario,
             fechamodifica = systimestamp
       WHERE id_archivo = p_id_archivo
         AND paso = v_paso
         AND codigocliente = p_codigocliente
         AND compania = g_compania
         AND tipo = 1;

      IF SQL%ROWCOUNT = 0 THEN
         insert into data.t_trad_archivoauditoria
             (id_archivo, paso, estado, columna, msg_error, fila, fecha, codigocliente, compania, tipo, usuariocreacion, fechacreacion)
         values
             (p_id_archivo, v_paso, p_estado, p_columna, p_mensaje, v_paso, systimestamp, p_codigocliente, g_compania, 1, l_usuario, systimestamp);
      END IF;

      commit;
   end sp_archivoauditoria;

     procedure sp_procesar_resultados_lectura(p_tipodescarga varchar2,p_id_archivo number, p_codigocliente varchar2, p_compania varchar2,p_mes_procesar number, p_mensaje varchar2,p_usuario in varchar2,p_linea number,p_id_proceso_cargadatos number)as
            v_tipo number:=1;
            v_tipodescarga  varchar2(5);
            v_fecha_ini date;
            v_fecha_fin date;
            v_flagdata varchar2(25);
            v_flaghomo varchar2(25);
            v_flagcero varchar2(25);

            v_registromes1 varchar2(10) := '000000' ;
            v_registroestado number:=0;
            v_registromensaje varchar2(3999):=' ';
            v_fechaminima date;
            v_resgistronoregularescanti number:=0;
            v_resgistronoregularestotal number:=0;
            v_fechainicio_control timestamp;

    begin
         -- INICIO SP_procesar_resultados_lectura

         v_tipodescarga :=v_mapeo.TIPO;

        v_registromes1:=to_char(add_months(sysdate,-nvl(p_mes_procesar,0)),'MMYYYY');
        v_fecha_ini:=add_months(trunc(sysdate,'MM'),-1 * 2);
        v_fecha_fin:=last_day(sysdate);

        v_flagdata:='DATA_CONTROL';
        v_flaghomo:='HOMOLOGACION';
        v_flagcero:='REGISTRO_CERO';

        SELECT MIN(fechainicio)
          INTO v_fechainicio_control
          FROM data.t_intc_control_archivo
         WHERE tipo = v_tipo
           AND codigocliente = p_codigocliente
           AND compania = p_compania
           AND fechafin IS NULL;
        -- SP_procesar_resultados_lectura: conserva control vivo inicial

        -- SP_procesar_resultados_lectura: limpia lecturas incorrectas anteriores

        delete from data.t_trad_lectura_incorrectos
         where tipo = v_tipo
           and codigogrupo = p_codigocliente
           and compania = p_compania
           and (id_archivo is null or id_archivo <> p_id_archivo); commit;
        v_rowafdected  := sql%rowcount;
        -- SP_procesar_resultados_lectura: lecturas incorrectas anteriores eliminadas

        -- SP_procesar_resultados_lectura: limpia temporal t_tmp_b

        delete from t_tmp_b where flag in ( v_flagdata,v_flaghomo,v_flagcero);commit;
        v_rowafdected  := sql%rowcount;
        -- SP_procesar_resultados_lectura: temporal t_tmp_b limpiada

        -- SP_procesar_resultados_lectura: inicia carga temporal DATA_CONTROL

        insert into t_tmp_b(flag,dte01,dte02,dte03,num01,num02,num03,num04,num05,num06,txt01,txt02,txt03,txt04,txt05,txt06,txt07,txt08,txt09,txt10,txt11,txt12,txt13,txt14)
            select
                v_flagdata 											flag,
                nvl(fecha,sysdate) 									fecha,
                sysdate 											fecha_auditoria,
                TRUNC(nvl(fecha,sysdate),'month') 					fechames,
                rownum 												numerolineas,
                round(nvl(valorunidad,0),4)							cantidad,
                null 												cantidad_inicial,
                null  												cantidad_ventames,
                round(nvl(valortotal,0), 4 )		 				valortotal,
                v_tipo		                                        tipoproceso,
                codigogrupo 		                                codigogrupo,
                codigocliente 		                                codigocliente,
                codigolocal 		                                codigolocal,
                ruc 		                                        ruc,
                codigobarra 		                                codigobarra,
                nvl(trim(codigoproducto_cliente),trim(codigobarra)) codigoproducto_cliente,
                codigoproducto 										codigoproducto,
                nombreruc 											nombreruc,
                nombrelocal 										nombrelocal,
                vendedor 											vendedor,
                unidadnegocio 										unidadnegocio,
                nombreproducto_cliente 								nombreproducto_cliente,
                segmentacion 										segmentacion,
                compania 											compania
             from t_trad_sellout b
             where b.id_proceso_cargadatos = p_id_proceso_cargadatos
             and not exists (select /*+ no_unnest */ 1 from t_intc_producto_noregular n where b.codigoproducto_cliente= n.codigoproductocliente and n.codigogrupo=b.codigogrupo and n.compania = b.compania )
             order by fecha, codigogrupo, codigocliente, ruc;
            v_rowafdected  := sql%rowcount;
             -- SP_procesar_resultados_lectura: termina carga temporal DATA_CONTROL

        commit;
        -- INC71: las estadÃ­sticas de T_TMP_B son compartidas y no alteran los datos del
        -- archivo. No se recolectan dentro de cada carga; su mantenimiento queda fuera
        -- del camino transaccional para evitar un escaneo adicional de la temporal.
        if (v_rowafdected  =0)then
            v_registromensaje:= p_mensaje|| '. Control, no inserta filas en el temporal -1';
            v_rowafdected:=-1;
            -- SP_procesar_resultados_lectura: ERROR sin filas en temporal DATA_CONTROL

            DELETE FROM data.t_intc_control_archivo
             WHERE tipo = v_tipo
               AND codigocliente = p_codigocliente
               AND compania = p_compania
               AND fechafin IS NULL;
            COMMIT;
            insert into t_intc_control_archivo(idarchivo,tipo,tipocarga,codigocliente,proceso,registros_archivo,registros_base,registros_cero,cantidad,venta,venta_promedio,porcentaje_variacion,homologacion,producto_no_regular,mes,estado,mensajeerror,compania,usercrea,fechainicio,fechafin)
                VALUES (NVL(p_id_proceso_cargadatos, p_id_archivo),v_tipo,v_tipodescarga, p_codigocliente,'INTC_CRTLP',v_rowafdected ,v_rowafdected,v_rowafdected,v_rowafdected,v_rowafdected,v_rowafdected,v_rowafdected,v_rowafdected,v_rowafdected,v_registromes1,v_registroestado,v_registromensaje,p_compania,p_usuario,NVL(v_fechainicio_control,SYSTIMESTAMP),SYSTIMESTAMP);
            pk_intc_sellout.sp_archivoauditoria(
                p_id_archivo => NVL(p_id_proceso_cargadatos, p_id_archivo),
                p_estado => 0,
                p_mensaje => 'ERROR: NO SE RECUPERA LA DATA DEL ARCHIVO PARA LAS VALIDACIONES DE CONTROL',
                p_codigocliente=>p_codigocliente
            );
            -- SP_procesar_resultados_lectura: retorna por temporal sin filas

            return;
        end if;

        pk_intc_sellout.sp_archivoauditoria(
            p_id_archivo => p_id_archivo,
            p_mensaje => 'SE RECUPERA '||v_rowafdected||' REGISTROS EN EL ARCHIVO PARA LAS VALIDACIONES DE CONTROL',
            p_codigocliente=>p_codigocliente
            );
        /*SE REGISTRA LOS PRODUCTOS PARA LA HOMOLOGACION*/
        -- SP_procesar_resultados_lectura: inicia insercion homologacion incorrectos

        insert into data.t_trad_lectura_incorrectos (categoria,id_archivo,mes_procesar,tipo,fecha,codigocliente,codigolocal,ruc,codigobarra,codigoproducto,codigoproducto_cliente,compania,codigogrupo,numerolineas,nombreruc,nombrelocal,nombreproducto_cliente)
            with base as (
                select  distinct v_flaghomo categoria,    p_id_archivo id_archivo,
                (to_char(dte01,'MMYYYY')) mes_procesar,
                num06 tipo,
                null fecha,
                'TXT02' codigocliente,
                'TXT03' codigolocal,
                'TXT04' ruc,
                txt05 codigobarra,
                txt07 codigoproducto,
                txt06 codigoproducto_cliente,
                txt14 compania,txt01 codigogrupo,
                null/*'NUM01'*/ numerolineas,
                'TXT08' nombreruc,
                null/*'TXT09'*/  nombrelocal,
                txt12 nombreproducto_cliente
                from data.t_tmp_b temp
                where  (dte01 is not null and temp.flag=v_flagdata)
                and (num06 = 1 and num02 != 0) -- SELLOUT -> registra homologacion cuando tiene cantidad/valor unidad
            ),
            productos_pendientes as (
                select distinct codigogrupo, codigoproducto_cliente, codigobarra
                from base s
                where not exists (select /*+ no_unnest */ 1 from vt_jde_productos p where trim(p.codigobarra)=trim(s.codigobarra) and compania = p_compania )
                  and not exists (select /*+ no_unnest */ 1 from vt_gzm_producto  p where trim(p.codigobarra)=trim(s.codigobarra) and compania = p_compania)
                  and not exists (select /*+ no_unnest */ 1 from vt_intc_homologacion  p where trim(p.codigogrupo) = trim(s.codigogrupo) and p.compania = p_compania
                        and (trim(p.codigoproductocliente)=trim(s.codigoproducto_cliente) or trim(p.codigobarra)=trim(s.codigobarra)) )
                  and not exists (select /*+ no_unnest */ 1 from t_intc_producto_noregular  p where trim(p.codigogrupo) = trim(s.codigogrupo)
                        and (trim(p.codigoproductocliente)=trim(s.codigoproducto_cliente) ) and p.compania = p_compania )
            )
            select s.categoria,s.id_archivo,s.mes_procesar,s.tipo,s.fecha,s.codigocliente,s.codigolocal,s.ruc,s.codigobarra,s.codigoproducto,s.codigoproducto_cliente,s.compania,s.codigogrupo,s.numerolineas,s.nombreruc,s.nombrelocal,s.nombreproducto_cliente
            from base s
            inner join productos_pendientes p
              on p.codigogrupo = s.codigogrupo
             and nvl(p.codigoproducto_cliente,' ') = nvl(s.codigoproducto_cliente,' ')
             and nvl(p.codigobarra,' ') = nvl(s.codigobarra,' ');

            v_rowafdected  := sql%rowcount;
            -- SP_procesar_resultados_lectura: termina insercion homologacion incorrectos

            pk_intc_sellout.sp_archivoauditoria(
                p_id_archivo => p_id_archivo,
                p_mensaje => 'SE REGISTRA LOS PRODUCTOS PARA LA HOMOLOGACION:'||v_rowafdected,
                p_codigocliente=>p_codigocliente
            );

        /*SE REGISTRA LOS PRODUCTOS EN CERO*/
        -- SP_procesar_resultados_lectura: inicia insercion productos en cero

        insert into data.t_trad_lectura_incorrectos (categoria,id_archivo,mes_procesar,tipo,fecha,codigocliente,codigolocal,ruc,codigobarra,codigoproducto,codigoproducto_cliente,compania,codigogrupo,numerolineas,nombreruc,nombrelocal,nombreproducto_cliente)
            select  categoria,id_archivo,mes_procesar,tipo,fecha,codigocliente,codigolocal,ruc,codigobarra,codigoproducto,codigoproducto_cliente,compania,codigogrupo,numerolineas,nombreruc,nombrelocal,nombreproducto_cliente
            from (
                select  distinct v_flagcero categoria,p_id_archivo id_archivo,(to_char(dte01,'MMYYYY')) mes_procesar,num06 tipo,null fecha,txt02 codigocliente,
                txt03 codigolocal,txt04 ruc,txt05 codigobarra,txt07 codigoproducto,txt06 codigoproducto_cliente,txt14 compania,txt01 codigogrupo,
                num01 numerolineas,txt08 nombreruc,txt09 nombrelocal,txt12 nombreproducto_cliente
                from data.t_tmp_b temp
                where  (dte01 is not null and temp.flag=v_flagdata)
                and (case
                     when num06 = 1 and (nvl(num02,0) = 0  and nvl(num05,0) = 0)  then 1
                     else 0                                                      end)=1
            ) s
            where 1=1
                and
                    not exists (select /*+ no_unnest */ 1 from t_intc_producto_noregular  p where trim(p.codigogrupo) = trim(s.codigogrupo)
                        and (trim(p.codigoproductocliente)=trim(s.codigoproducto_cliente) ) and p.compania = p_compania )
            group by categoria,id_archivo,mes_procesar,tipo,fecha,codigocliente,codigolocal,ruc,codigobarra,codigoproducto,codigoproducto_cliente,compania,codigogrupo,numerolineas,nombreruc,nombrelocal,nombreproducto_cliente;

            v_rowafdected  := sql%rowcount;
            -- SP_procesar_resultados_lectura: termina insercion productos en cero

                 commit;
            pk_intc_sellout.sp_archivoauditoria(
                p_id_archivo => p_id_archivo,
                p_mensaje => 'SE REGISTRA LOS PRODUCTOS EN CERO:'||v_rowafdected,
                p_codigocliente=>p_codigocliente);
        v_registroestado :=1;
        v_registromensaje :=' ';
        v_registromensaje:=trim(v_registromensaje);

        DELETE FROM data.t_intc_control_archivo
         WHERE tipo = v_tipo
           AND codigocliente = p_codigocliente
           AND compania = p_compania
           AND fechafin IS NULL;
        COMMIT;
        -- SP_procesar_resultados_lectura: inicia insercion control archivo

        insert into  t_intc_control_archivo(idarchivo,tipo,tipocarga,codigocliente,proceso,registros_archivo,registros_base,registros_cero,cantidad,venta,venta_promedio,porcentaje_variacion,homologacion,producto_no_regular,producto_no_regular_total,mes,estado,mensajeerror,compania,usercrea,id_proceso_cargadatos,fechainicio)
            with wfechas as (
                SELECT DISTINCT /*+ MATERIALIZE */ nvl(txt01,txt02) codcliente
                , add_months(trunc( TO_DATE(to_char(dte03,'MMYYYY'),'MMYYYY'),'MONTH'),-3)fechaini
                ,last_day(add_months(trunc( TO_DATE(to_char(dte03,'MMYYYY'),'MMYYYY'),'MONTH'),-1)) fechfin ,dte03
                FROM t_tmp_b
                where flag = 'DATA_CONTROL'
            )--SELECT * FROM wfechas;
            ,PROMEDIO AS (
                select /*+ MATERIALIZE*/
                    nvl(ROUND(sum(VALORTOTAL)/3,4),0) registroVentaPromedio,dte03
                from t_trad_sellout ,wfechas
                where 1=1
                and fecha >= fechaini
                and fecha < fechfin + 1
                and nvl(codigogrupo,codigocliente)=codcliente
                group by dte03
            )--SELECT * FROM PROMEDIO;
            ,datos as (
                select   b.txt01 codigogrupo,b.num06 tipoproceso,(to_char(dte01,'MMYYYY'))mes,p.registroventapromedio,
                    COUNT(1) registroarchivo,
                    SUM( case when num06 = 1 and (nvl(num02,0) != 0 or  nvl(num05,0) != 0) then nvl(num02,0) else 0 end ) registrocantidadbase,
                    SUM( case when num06 = 1 and (nvl(num02,0) != 0 or  nvl(num05,0) != 0) then nvl(num05,0) else 0 end ) registroventabase,
                    SUM( case when num06 = 1 and (nvl(num02,0) != 0 or  nvl(num05,0) != 0) then 1 else 0 end            ) registrobase,
                    SUM( case when num06 = 1 and (nvl(num02,0)  = 0 and nvl(num05,0)  = 0) then 1 else 0 end            ) registrocero,
                    SUM(num02)                                                                                            registrocantidadarchivo,/*Total sum(cantidad) cantidad que viene en el archivo*/
                    SUM(num05)                                                                                            registroventaarchivo /*Total sum(venta) venta que viene en el archivo*/
                from t_tmp_b b
                left join PROMEDIO p on b.dte03 = p.dte03
                where b.flag = 'DATA_CONTROL'
                  and not exists (select /*+ MATERIALIZE no_unnest */ 1 from t_intc_producto_noregular  p where trim(p.codigogrupo) = trim(b.txt01)
                    and (trim(p.codigoproductocliente)=trim(b.txt06) ) and p.compania = p_compania  )
                GROUP BY b.txt01,b.num06,(to_char(dte01,'MMYYYY')),p.registroventapromedio
            )--SELECT * FROM datos;
            ,hom as(
                    select
                        count(distinct NVL(TRIM(codigoproducto_cliente), NVL(TRIM(codigobarra), TRIM(nombreproducto_cliente)))) registrohomologar,
                        mes_procesar mes,
                        codigogrupo
                    from data.t_trad_lectura_incorrectos
                    where categoria = v_flaghomo
                      and id_archivo = p_id_archivo
                      and tipo = v_tipo
                      and codigogrupo = p_codigocliente
                      and compania = p_compania
                    group by mes_procesar,codigogrupo
            )--SELECT * FROM hom;
             ,prodnoregular as (
                select
                     count(b.CODIGOPRODUCTO_CLIENTE) registroprodnoreg
                    ,to_number(to_char(b.FECHA,'MMYYYY'))mes
                    ,nvl(b.CODIGOCLIENTE, b.codigogrupo) codigogrupo
                    ,round(sum(nvl(VALORTOTAL,0)), 4 ) totalprodnoreg
                  from t_trad_sellout b
                    where b.id_proceso_cargadatos = p_id_proceso_cargadatos
                and   exists (select /*+ MATERIALIZE*/ 1
                                from t_intc_producto_noregular  p where trim(p.codigogrupo) = b.codigogrupo
                    and trim(p.codigoproductocliente)=trim(b.CODIGOPRODUCTO_CLIENTE) and p.compania = b.compania )
                group by to_number(to_char(b.FECHA,'MMYYYY')),nvl(b.CODIGOCLIENTE, b.codigogrupo)
             )--SELECT * FROM prodnoregular;
             ,resultado as (
                 select
                      d.tipoproceso
                     ,d.mes registromes
                     ,d.registroarchivo/*Cantidad de registros del archivo */
                     ,d.registrocantidadbase/*INVENTARIO Total sum(cantidad) cantidad que se inserto en base de datos */
                     ,decode(d.registroventabase,0,null,d.registroventabase) registroventabase /*Total sum(venta) venta que se inserto en base de datos, alerta si es 0*/
                     ,d.registrobase/*Cantidad de registros insertados en base de datos*/
                     ,d.registrocero/*Cantidad de registros con cantidad=0 en inventario. Y cantidad=0 y venta=0 en Sellout */
                     ,d.registrocantidadarchivo /*Total sum(cantidad) cantidad que viene en el archivo*/
                     ,decode(d.registroventaarchivo,0,null,d.registroventaarchivo) registroventaarchivo /*Total sum(venta) venta que viene en el archivo*/
                     ,decode(d.registroventabase,0,null,d.registroventapromedio)registroventapromedio
                     ,ROUND(nvl(((REGISTROVENTAARCHIVO/nullif(registroventapromedio,0))-1)*100,0),2) registroporcentajevariacion/*variacion entre Promedio_venta /Venta_Base  mostrar alerta en los 5 ultimos dias del mes.*/
                     ,h.registrohomologar
                     ,b.registroprodnoreg
                     ,b.totalprodnoreg
                from datos d
                left join hom  h on (d.mes=h.mes and d.codigogrupo=h.codigogrupo)
                left join prodnoregular b on (d.mes=b.mes and d.codigogrupo=b.codigogrupo)
            )--SELECT * FROM resultado ;
            select p_id_archivo,tipoproceso,v_tipodescarga, p_codigocliente,'INTC_CRTLP',registroarchivo+nvl(registroprodnoreg,0) registroarchivo,registrobase,registrocero,registrocantidadarchivo,registroventabase,registroventapromedio,registroporcentajevariacion,NVL(registrohomologar,0) registrohomologar,NVL(registroprodnoreg,0) registroprodnoreg,NVL(totalprodnoreg,0) totalprodnoreg,registromes,v_registroestado,v_registromensaje,p_compania,l_usuario,p_id_proceso_cargadatos,NVL(v_fechainicio_control,SYSTIMESTAMP)
            from resultado;
        -- INC18_CONTROL_SELLOUT_NVL_NOREGULAR

        v_rowafdected  := sql%rowcount;
        -- SP_procesar_resultados_lectura: termina insercion control archivo

        pk_intc_sellout.sp_archivoauditoria(
            p_id_archivo => p_id_archivo,
            p_mensaje => 'Inserta El Registro De Control Para Verlo En La Mesa De Trabajo',
            p_codigocliente=>p_codigocliente);
        -- SP_procesar_resultados_lectura: inicia limpieza final temporal

        delete from t_tmp_b where flag in ( v_flagdata,v_flaghomo,v_flagcero);commit;
        -- SP_procesar_resultados_lectura: termina limpieza final temporal

    exception when others then
             -- SP_procesar_resultados_lectura: ERROR

             pk_intc_sellout.sp_archivoauditoria(
                p_id_archivo => p_id_archivo,
                p_estado => 0,
                p_mensaje => 'Error en ejecucion. SQLERRM: '||sqlerrm||' TRACE: '||dbms_utility.format_error_backtrace,
                p_codigocliente=>p_codigocliente);
            delete from t_tmp_b where flag in ( v_flagdata,v_flaghomo,v_flagcero);commit;
            raise;
    end sp_procesar_resultados_lectura;

    procedure sp_control_factor_conversion (p_codigocliente varchar2 default null, p_fechaini date default null,
        p_fechafin date default null, p_compania varchar2 ) as
        v_meses number;
        v_variacion_menor number;
        v_variacion_mayor number;
        v_variacion_rango varchar2(25);
        v_fechaini date;
        v_fechafin date;
        v_contregis number;
    begin
        v_fechaini:= nvl(p_fechaini,add_months(sysdate,-1));
        v_fechafin:= nvl(p_fechafin,add_months(sysdate,-1));
        -- INICIO SP_control_factor_conversion


        /*RECUPERA EL VALOR DE MESES PARA BUSCAR MEDIANA*/
        select to_number(valor) into v_meses from data.t_corp_udc where id_cabecera = 'INTC_PARAM' and id_tabla = '9' and codigocompania = p_compania ;
        v_meses:= nvl(v_meses,1);
        /*RECUPERA VALORES PARA LA REVISION DE LA VARIACION DE PRECIOS*/
        select to_number(valor),to_number(valor2) into v_variacion_menor,v_variacion_mayor from data.t_corp_udc where id_cabecera = 'INTC_PARAM' and id_tabla = '10' and codigocompania = p_compania ;

        v_variacion_rango:=('{'||v_variacion_menor ||';'||v_variacion_mayor||'}');
        /*se elimina lo datos antiguos*/
        -- SP_control_factor_conversion: elimina controles antiguos

        delete from data.t_intc_control_factor_conversion
         where estado = 0
           and (p_codigocliente is null or codigogrupo = p_codigocliente);
        v_contregis := sql%rowcount;
        -- SP_control_factor_conversion: controles antiguos eliminados


        -- SP_control_factor_conversion: inicia carga temporal FACTOR_CNV

        insert into data.t_tmp_b(flag, txt01,txt02,txt04,txt05,num01,num02,num03,txt06)
        with
            wactual as (/*informaci??n del mes actual*/
                select
                    a.codigogrupo,a.codigobarra,a.codigoproducto_cliente codigoproductocli, a.codigoproducto codigoproductozm,
                    decode(a.valorunidad,0,0,round((a.valortotal/a.valorunidad),4))precio,
                    trunc(to_date(p_fechaini),'MM')fdesde,last_day(to_date(p_fechafin))fhasta
                    ,to_char(to_date(p_fechaini),'MM/YYYY')||' - '||to_char(to_date(p_fechafin),'MM/YYYY') fecha
                from data.t_trad_sellout a
                inner join vt_gzm_producto b on a.codigobarra= b.codigobarra
                where  fecha between  trunc(to_date(p_fechaini),'MM') and  last_day(to_date(p_fechafin))
                and (a.codigogrupo=p_codigocliente or p_codigocliente is null)
                group by a.codigogrupo,a.codigobarra,a.codigoproducto_cliente, a.codigoproducto,decode(a.valorunidad,0,0,round((a.valortotal/a.valorunidad),4))
                -- INC71: el INSERT posterior no depende de orden; evita un sort intermedio.
            ),
            wdatamesesatras as (/*informacion del n(v_meses) meses atras*/
                select
                    a.codigogrupo,a.codigobarra,a.codigoproducto_cliente codigoproductocli, a.codigoproducto codigoproductozm,decode(a.valorunidad,0,0,round((a.valortotal/a.valorunidad),4))precio,
                    trunc(add_months(to_date(p_fechaini),(-1*v_meses)), 'MM')fdesde,last_day(add_months(to_date(p_fechaini),-1))fhasta
                from data.t_trad_sellout a
                where  a.fecha between  trunc(add_months(to_date(p_fechaini),(-1*v_meses)),'MM') and last_day(add_months(to_date(p_fechaini),-1))
                and (a.codigogrupo=p_codigocliente or p_codigocliente is null)
                and exists (
                    select 1
                    from vt_jde_productos b
                    where b.codigobarra = a.codigobarra
                )
                group by a.codigogrupo,a.codigobarra,a.codigoproducto_cliente, a.codigoproducto,decode(a.valorunidad,0,0,round((a.valortotal/a.valorunidad),4))
                -- INC71: EXISTS evita multiplicar filas por barras repetidas en la vista remota.
            ),
            wmediana as(/*informacion de la mediana agrupado por CODIGOGRUPO,CODIGOBARRA,CODIGOPRODUCTO*/
                select
                    codigogrupo,codigobarra,codigoproductocli, codigoproductozm,round(median(precio),4) mediana
                from wdatamesesatras
                group by codigogrupo,codigobarra,codigoproductocli, codigoproductozm
            ),
            wvariacion as (/*informacion de la variacion del precio por la mediana*/
                select
                    a.codigogrupo,a.codigobarra,a.codigoproductocli, a.codigoproductozm ,a.fecha,a.precio,m.mediana,
                    decode(a.precio,0,0,round(((m.mediana/a.precio)-1)*100,2)) variacion
                from wactual a left join wmediana m on a.codigogrupo= m.codigogrupo and a.codigobarra=m.codigobarra
            )
        select
            'FACTOR_CNV'flag,codigogrupo,codigobarra,codigoproductocli,fecha fecha,precio,mediana,variacion, codigoproductozm
        from wvariacion
        where variacion <=v_variacion_menor or variacion>=v_variacion_mayor;
        -- INC71: T_TMP_B se consume como conjunto; no requiere orden fÃ­sico de inserciÃ³n.

                v_contregis := sql%rowcount;
        -- SP_control_factor_conversion: termina carga temporal FACTOR_CNV


        -- SP_control_factor_conversion: inicia insercion control factor conversion

        insert into t_intc_control_factor_conversion (codigogrupo,codigobarra,codigoproductocli,fecha,
                precio,preciomedia,variacion,variacionrango, codigoproductozm )
            select txt01 codigogrupo,txt02 codigobarra,txt04 codigoproducto,txt05 fecha,
                num01 precio,num02 preciomedia,num03 variacion ,v_variacion_rango variacionrango, txt06 codigoproductozm
            from t_tmp_b
                left join t_intc_control_factor_conversion on txt01= codigogrupo and txt02=codigobarra
                    and txt04=codigoproductocli and txt05 = codigoproductozm
            where flag ='FACTOR_CNV' and codigobarra is null;
        -- SP_control_factor_conversion: termina insercion control factor conversion



        -- SP_control_factor_conversion: inicia actualizacion codigoproductozm

        update t_intc_control_factor_conversion a
           set codigoproductozm = (
                 select max(b.codigoproducto)
                   from vt_gzm_producto b
                  where b.codigobarra = a.codigobarra
                    and b.compania = p_compania
               )
         where a.codigoproductozm is null
           and (p_codigocliente is null or a.codigogrupo = p_codigocliente);
        -- SP_control_factor_conversion: termina actualizacion codigoproductozm


        -- SP_control_factor_conversion: limpia temporal FACTOR_CNV

        delete from t_tmp_b where flag ='FACTOR_CNV';
        -- FIN SP_control_factor_conversion


        commit;

    exception
        when others then
            -- SP_control_factor_conversion: ERROR

            raise;
    end sp_control_factor_conversion;


   /**
    * Genera reglas automaticas para DATA.T_INTC_PRODUCTO_SO desde Sellin.
    * - Promocion: CODIGOPRODUCTO distinto de CODIGOPRODUCTOPADRE apunta al producto padre.
    * - Nacional/exterior: NAC queda general y EXT queda por CODIGOGRUPO.
    */
   procedure sp_generar_producto_so(
      p_compania              in varchar2 default null,
      p_fecha_desde           in date default null,
      p_usuario               in varchar2 default null
   ) as
      v_usuario_auditoria varchar2(250);
      v_fecha_desde date;
   begin
      v_fecha_desde := nvl(p_fecha_desde, add_months(trunc(sysdate, 'MM'), -24));
      v_usuario_auditoria := nullif(trim(p_usuario), '');

      if v_usuario_auditoria is null then
         begin
            v_usuario_auditoria := nullif(trim(v('APP_USER')), '');
         exception
            when others then
               v_usuario_auditoria := null;
         end;
      end if;

      v_usuario_auditoria := nvl(v_usuario_auditoria, 'INTC');

      -- Caso 1: productos promocionales. La barra del promocional apunta al producto padre.
      insert into data.t_intc_producto_so (
          codigobarra,
          codigoproducto,
          fechadesde,
          fechahasta,
          auditoriausuario,
          auditoriafecha,
          compania,
          codigogrupo,
          tipo_caso
      )
      with barra_multiple as (
          select pm.compania,
                 trim(pm.codigobarra) codigobarra
            from data.vt_gzm_producto pm
           where pm.codigobarra is not null
             and trim(pm.codigobarra) <> '0000000000000'
             and pm.tipoprodUcto in (
                    'TERMINADO',
                    'TERCEROS',
                    'PRODUCTO TERMINADO',
                    'PRODUCTO TERMINADO IMPORTADO',
                    'ENVASES'
                 )
           group by pm.compania,
                    trim(pm.codigobarra)
          having count(distinct pm.codigoproducto) > 1
      ),
      candidatos as (
          select s.compania,
                 trim(p.codigobarra) codigobarra,
                 trim(s.codigoproductopadre) codigoproducto,
                 min(trunc(s.fecha, 'MM')) fechadesde
            from data.t_trad_sellin s
            join data.vt_gzm_producto p
              on p.compania = s.compania
             and p.codigoproducto = s.codigoproducto
            join barra_multiple bm
              on bm.compania = s.compania
             and bm.codigobarra = trim(p.codigobarra)
           where (p_compania is null or s.compania = p_compania)
             and s.fecha >= v_fecha_desde
             and s.codigoproductopadre is not null
             and trim(s.codigoproducto) <> trim(s.codigoproductopadre)
             and p.codigobarra is not null
             and trim(p.codigobarra) <> '0000000000000'
             and nvl(s.valorunidad, 0) > 0
             and p.tipoprodUcto in (
                    'TERMINADO',
                    'TERCEROS',
                    'PRODUCTO TERMINADO',
                    'PRODUCTO TERMINADO IMPORTADO',
                    'ENVASES'
                 )
           group by s.compania,
                    trim(p.codigobarra),
                    trim(s.codigoproductopadre)
      )
      select c.codigobarra,
             c.codigoproducto,
             c.fechadesde,
             cast(null as date),
             v_usuario_auditoria,
             sysdate,
             c.compania,
             cast(null as varchar2(125)),
             'PRODUCTO_PROMOCIONAL'
        from candidatos c
       where not exists (
             select 1
               from data.t_intc_producto_so t
              where t.compania = c.compania
                and trim(t.codigobarra) = c.codigobarra
                and t.codigogrupo is null
       );

      -- Caso 2A: producto nacional/base. La regla queda general, sin cliente.
      insert into data.t_intc_producto_so (
          codigobarra,
          codigoproducto,
          fechadesde,
          fechahasta,
          auditoriausuario,
          auditoriafecha,
          compania,
          codigogrupo,
          tipo_caso
      )
      with barra_multiple as (
          select pm.compania,
                 trim(pm.codigobarra) codigobarra
            from data.vt_gzm_producto pm
           where pm.codigobarra is not null
             and trim(pm.codigobarra) <> '0000000000000'
             and pm.tipoprodUcto in (
                    'TERMINADO',
                    'TERCEROS',
                    'PRODUCTO TERMINADO',
                    'PRODUCTO TERMINADO IMPORTADO',
                    'ENVASES'
                 )
           group by pm.compania,
                    trim(pm.codigobarra)
          having count(distinct pm.codigoproducto) > 1
      ),
      sellin_base as (
          select s.compania,
                 trim(p.codigobarra) codigobarra,
                 trim(c.codigoorigen) codigoorigen,
                 trim(s.codigogrupo) codigogrupo,
                 trim(s.codigoproducto) codigoproducto,
                 min(trunc(s.fecha, 'MM')) min_fecha,
                 max(s.fecha) max_fecha,
                 sum(nvl(s.valorunidad, 0)) unidades
            from data.t_trad_sellin s
            join data.vt_gzm_producto p
              on p.compania = s.compania
             and p.codigoproducto = s.codigoproducto
            join barra_multiple bm
              on bm.compania = s.compania
             and bm.codigobarra = trim(p.codigobarra)
            join data.vt_gzm_cliente c
              on c.compania = s.compania
             and c.codigogrupo = s.codigogrupo
           where (p_compania is null or s.compania = p_compania)
             and s.fecha >= v_fecha_desde
             and p.codigobarra is not null
             and trim(p.codigobarra) <> '0000000000000'
             and nvl(s.valorunidad, 0) > 0
             and c.codigoorigen in ('NAC', 'EXT')
             and p.tipoprodUcto in (
                    'TERMINADO',
                    'TERCEROS',
                    'PRODUCTO TERMINADO',
                    'PRODUCTO TERMINADO IMPORTADO',
                    'ENVASES'
                 )
           group by s.compania,
                    trim(p.codigobarra),
                    trim(c.codigoorigen),
                    trim(s.codigogrupo),
                    trim(s.codigoproducto)
      ),
      nac_unico as (
          select compania,
                 codigobarra,
                 min(codigoproducto) codigoproducto,
                 min(min_fecha) fechadesde
            from sellin_base
           where codigoorigen = 'NAC'
           group by compania,
                    codigobarra
          having count(distinct codigoproducto) = 1
      ),
      ext_producto_exclusivo as (
          select e.compania,
                 e.codigobarra,
                 e.codigogrupo,
                 e.codigoproducto,
                 min(e.min_fecha) fechadesde,
                 max(e.max_fecha) max_fecha
            from sellin_base e
           where e.codigoorigen = 'EXT'
             and not exists (
                   select 1
                     from sellin_base n
                    where n.compania = e.compania
                      and n.codigobarra = e.codigobarra
                      and n.codigoproducto = e.codigoproducto
                      and n.codigoorigen = 'NAC'
                 )
           group by e.compania,
                    e.codigobarra,
                    e.codigogrupo,
                    e.codigoproducto
      ),
      candidatos as (
          select distinct
                 n.compania,
                 n.codigobarra,
                 n.codigoproducto,
                 n.fechadesde
            from nac_unico n
            join ext_producto_exclusivo e
              on e.compania = n.compania
             and e.codigobarra = n.codigobarra
           where n.codigoproducto <> e.codigoproducto
      )
      select c.codigobarra,
             c.codigoproducto,
             c.fechadesde,
             cast(null as date),
             v_usuario_auditoria,
             sysdate,
             c.compania,
             cast(null as varchar2(125)),
             'PRODUCTO_EXTERIOR'
        from candidatos c
       where not exists (
             select 1
               from data.t_intc_producto_so t
              where t.compania = c.compania
                and trim(t.codigobarra) = c.codigobarra
                and t.codigogrupo is null
       );

      -- Caso 2B: cierra reglas exteriores existentes cuando el cliente ya migro al producto base.
      merge into data.t_intc_producto_so t
      using (
          with barra_multiple as (
              select pm.compania,
                     trim(pm.codigobarra) codigobarra
                from data.vt_gzm_producto pm
               where pm.codigobarra is not null
                 and trim(pm.codigobarra) <> '0000000000000'
                 and pm.tipoprodUcto in (
                        'TERMINADO',
                        'TERCEROS',
                        'PRODUCTO TERMINADO',
                        'PRODUCTO TERMINADO IMPORTADO',
                        'ENVASES'
                     )
               group by pm.compania,
                        trim(pm.codigobarra)
              having count(distinct pm.codigoproducto) > 1
          ),
          sellin_base as (
              select s.compania,
                     trim(p.codigobarra) codigobarra,
                     trim(c.codigoorigen) codigoorigen,
                     trim(s.codigogrupo) codigogrupo,
                     trim(s.codigoproducto) codigoproducto,
                     min(trunc(s.fecha, 'MM')) min_fecha,
                     max(s.fecha) max_fecha,
                     sum(nvl(s.valorunidad, 0)) unidades
                from data.t_trad_sellin s
                join data.vt_gzm_producto p
                  on p.compania = s.compania
                 and p.codigoproducto = s.codigoproducto
                join barra_multiple bm
                  on bm.compania = s.compania
                 and bm.codigobarra = trim(p.codigobarra)
                join data.vt_gzm_cliente c
                  on c.compania = s.compania
                 and c.codigogrupo = s.codigogrupo
               where (p_compania is null or s.compania = p_compania)
                 and s.fecha >= v_fecha_desde
                 and p.codigobarra is not null
                 and trim(p.codigobarra) <> '0000000000000'
                 and nvl(s.valorunidad, 0) > 0
                 and c.codigoorigen in ('NAC', 'EXT')
                 and p.tipoprodUcto in (
                        'TERMINADO',
                        'TERCEROS',
                        'PRODUCTO TERMINADO',
                        'PRODUCTO TERMINADO IMPORTADO',
                        'ENVASES'
                     )
               group by s.compania,
                        trim(p.codigobarra),
                        trim(c.codigoorigen),
                        trim(s.codigogrupo),
                        trim(s.codigoproducto)
          ),
          nac_unico as (
              select compania,
                     codigobarra,
                     min(codigoproducto) codigoproducto
                from sellin_base
               where codigoorigen = 'NAC'
               group by compania,
                        codigobarra
              having count(distinct codigoproducto) = 1
          ),
          ext_producto_exclusivo as (
          select e.compania,
                 e.codigobarra,
                 e.codigogrupo,
                 e.codigoproducto,
                 min(e.min_fecha) fechadesde,
                 max(e.max_fecha) max_fecha
            from sellin_base e
           where e.codigoorigen = 'EXT'
             and not exists (
                   select 1
                     from sellin_base n
                    where n.compania = e.compania
                      and n.codigobarra = e.codigobarra
                      and n.codigoproducto = e.codigoproducto
                      and n.codigoorigen = 'NAC'
                 )
           group by e.compania,
                    e.codigobarra,
                    e.codigogrupo,
                    e.codigoproducto
      ),
          candidatos as (
              select e.compania,
                     e.codigobarra,
                     e.codigoproducto,
                     e.codigogrupo,
                     e.fechadesde,
                     case
                        when exists (
                              select 1
                                from sellin_base b
                               where b.compania = e.compania
                                 and b.codigobarra = e.codigobarra
                                 and b.codigogrupo = e.codigogrupo
                                 and b.codigoproducto = n.codigoproducto
                                 and b.max_fecha > e.max_fecha
                           )
                        then last_day(e.max_fecha)
                     end fechahasta
                from ext_producto_exclusivo e
                join nac_unico n
                  on n.compania = e.compania
                 and n.codigobarra = e.codigobarra
               where e.codigoproducto <> n.codigoproducto
          )
          select *
            from candidatos
      ) c
         on (    t.compania = c.compania
             and trim(t.codigobarra) = c.codigobarra
             and trim(t.codigogrupo) = c.codigogrupo
             and trim(t.codigoproducto) = c.codigoproducto)
       when matched then update
          set t.fechahasta = c.fechahasta,
              t.tipo_caso = 'PRODUCTO_EXTERIOR',
              t.auditoriausuario = v_usuario_auditoria,
              t.auditoriafecha = sysdate
        where (   (t.fechahasta is null and c.fechahasta is not null)
               or (t.fechahasta is not null and c.fechahasta is null)
               or (t.fechahasta is not null and c.fechahasta is not null and trunc(t.fechahasta) <> trunc(c.fechahasta))
               or nvl(t.tipo_caso, '-') <> 'PRODUCTO_EXTERIOR');

      -- Caso 2C: producto exterior exclusivo. La regla queda por cliente/grupo.
      insert into data.t_intc_producto_so (
          codigobarra,
          codigoproducto,
          fechadesde,
          fechahasta,
          auditoriausuario,
          auditoriafecha,
          compania,
          codigogrupo,
          tipo_caso
      )
      with barra_multiple as (
          select pm.compania,
                 trim(pm.codigobarra) codigobarra
            from data.vt_gzm_producto pm
           where pm.codigobarra is not null
             and trim(pm.codigobarra) <> '0000000000000'
             and pm.tipoprodUcto in (
                    'TERMINADO',
                    'TERCEROS',
                    'PRODUCTO TERMINADO',
                    'PRODUCTO TERMINADO IMPORTADO',
                    'ENVASES'
                 )
           group by pm.compania,
                    trim(pm.codigobarra)
          having count(distinct pm.codigoproducto) > 1
      ),
      sellin_base as (
          select s.compania,
                 trim(p.codigobarra) codigobarra,
                 trim(c.codigoorigen) codigoorigen,
                 trim(s.codigogrupo) codigogrupo,
                 trim(s.codigoproducto) codigoproducto,
                 min(trunc(s.fecha, 'MM')) min_fecha,
                 max(s.fecha) max_fecha,
                 sum(nvl(s.valorunidad, 0)) unidades
            from data.t_trad_sellin s
            join data.vt_gzm_producto p
              on p.compania = s.compania
             and p.codigoproducto = s.codigoproducto
            join barra_multiple bm
              on bm.compania = s.compania
             and bm.codigobarra = trim(p.codigobarra)
            join data.vt_gzm_cliente c
              on c.compania = s.compania
             and c.codigogrupo = s.codigogrupo
           where (p_compania is null or s.compania = p_compania)
             and s.fecha >= v_fecha_desde
             and p.codigobarra is not null
             and trim(p.codigobarra) <> '0000000000000'
             and nvl(s.valorunidad, 0) > 0
             and c.codigoorigen in ('NAC', 'EXT')
             and p.tipoprodUcto in (
                    'TERMINADO',
                    'TERCEROS',
                    'PRODUCTO TERMINADO',
                    'PRODUCTO TERMINADO IMPORTADO',
                    'ENVASES'
                 )
           group by s.compania,
                    trim(p.codigobarra),
                    trim(c.codigoorigen),
                    trim(s.codigogrupo),
                    trim(s.codigoproducto)
      ),
      nac_unico as (
          select compania,
                 codigobarra,
                 min(codigoproducto) codigoproducto
            from sellin_base
           where codigoorigen = 'NAC'
           group by compania,
                    codigobarra
          having count(distinct codigoproducto) = 1
      ),
      ext_producto_exclusivo as (
          select e.compania,
                 e.codigobarra,
                 e.codigogrupo,
                 e.codigoproducto,
                 min(e.min_fecha) fechadesde,
                 max(e.max_fecha) max_fecha
            from sellin_base e
           where e.codigoorigen = 'EXT'
             and not exists (
                   select 1
                     from sellin_base n
                    where n.compania = e.compania
                      and n.codigobarra = e.codigobarra
                      and n.codigoproducto = e.codigoproducto
                      and n.codigoorigen = 'NAC'
                 )
           group by e.compania,
                    e.codigobarra,
                    e.codigogrupo,
                    e.codigoproducto
      ),
      candidatos as (
          select e.compania,
                 e.codigobarra,
                 e.codigoproducto,
                 e.codigogrupo,
                 e.fechadesde,
                 case
                    when exists (
                          select 1
                            from sellin_base b
                           where b.compania = e.compania
                             and b.codigobarra = e.codigobarra
                             and b.codigogrupo = e.codigogrupo
                             and b.codigoproducto = n.codigoproducto
                             and b.max_fecha > e.max_fecha
                       )
                    then last_day(e.max_fecha)
                 end fechahasta
            from ext_producto_exclusivo e
            join nac_unico n
              on n.compania = e.compania
             and n.codigobarra = e.codigobarra
           where e.codigoproducto <> n.codigoproducto
      )
      select c.codigobarra,
             c.codigoproducto,
             c.fechadesde,
             c.fechahasta,
             v_usuario_auditoria,
             sysdate,
             c.compania,
             c.codigogrupo,
             'PRODUCTO_EXTERIOR'
        from candidatos c
       where not exists (
             select 1
               from data.t_intc_producto_so t
              where t.compania = c.compania
                and trim(t.codigobarra) = c.codigobarra
                and trim(t.codigogrupo) = c.codigogrupo
       );

      -- Caso 2D: clasifica reglas generales existentes asociadas a producto exterior.
      update data.t_intc_producto_so t
         set t.tipo_caso = 'PRODUCTO_EXTERIOR',
             t.auditoriausuario = v_usuario_auditoria,
             t.auditoriafecha = sysdate
       where t.codigogrupo is null
         and t.tipo_caso is null
         and exists (
               select 1
                 from data.t_intc_producto_so e
                where e.compania = t.compania
                  and trim(e.codigobarra) = trim(t.codigobarra)
                  and e.codigogrupo is not null
                  and e.tipo_caso = 'PRODUCTO_EXTERIOR'
             );

      -- Caso 3A: cambio de imagen. Actualiza rangos generales existentes.
      merge into data.t_intc_producto_so t
      using (
          with barra_multiple as (
              select pm.compania,
                     trim(pm.codigobarra) codigobarra
                from data.vt_gzm_producto pm
               where pm.codigobarra is not null
                 and trim(pm.codigobarra) <> '0000000000000'
                 and pm.tipoprodUcto in (
                        'TERMINADO',
                        'TERCEROS',
                        'PRODUCTO TERMINADO',
                        'PRODUCTO TERMINADO IMPORTADO',
                        'ENVASES'
                     )
               group by pm.compania,
                        trim(pm.codigobarra)
              having count(distinct pm.codigoproducto) > 1
          ),
          producto_rango as (
              select s.compania,
                     trim(p.codigobarra) codigobarra,
                     trim(s.codigoproducto) codigoproducto,
                     min(trunc(s.fecha, 'MM')) fechadesde,
                     max(s.fecha) max_fecha
                from data.t_trad_sellin s
                join data.vt_gzm_producto p
                  on p.compania = s.compania
                 and p.codigoproducto = s.codigoproducto
                join barra_multiple bm
                  on bm.compania = s.compania
                 and bm.codigobarra = trim(p.codigobarra)
                join data.vt_gzm_cliente c
                  on c.compania = s.compania
                 and c.codigogrupo = s.codigogrupo
               where (p_compania is null or s.compania = p_compania)
                 and s.fecha >= v_fecha_desde
                 and p.codigobarra is not null
                 and trim(p.codigobarra) <> '0000000000000'
                 and nvl(s.valorunidad, 0) > 0
                 and trim(c.codigoorigen) = 'NAC'
                 and p.tipoprodUcto in (
                        'TERMINADO',
                        'TERCEROS',
                        'PRODUCTO TERMINADO',
                        'PRODUCTO TERMINADO IMPORTADO',
                        'ENVASES'
                     )
               group by s.compania,
                        trim(p.codigobarra),
                        trim(s.codigoproducto)
          ),
          producto_ordenado as (
              select compania,
                     codigobarra,
                     codigoproducto,
                     fechadesde,
                     max_fecha,
                     row_number() over (
                        partition by compania, codigobarra
                        order by max_fecha desc, fechadesde desc, codigoproducto desc
                     ) rn,
                     count(*) over (partition by compania, codigobarra) total_productos,
                     lag(fechadesde) over (
                        partition by compania, codigobarra
                        order by max_fecha desc, fechadesde desc, codigoproducto desc
                     ) siguiente_fechadesde
                from producto_rango
          ),
          candidatos as (
              select compania,
                     codigobarra,
                     codigoproducto,
                     fechadesde,
                     case
                        when rn = 1 then cast(null as date)
                        else siguiente_fechadesde - 1
                     end fechahasta
                from producto_ordenado
               where total_productos > 1
          )
          select *
            from candidatos
      ) c
         on (    t.compania = c.compania
             and trim(t.codigobarra) = c.codigobarra
             and trim(t.codigoproducto) = c.codigoproducto
             and t.codigogrupo is null)
       when matched then update
          set t.fechadesde = c.fechadesde,
              t.fechahasta = c.fechahasta,
              t.tipo_caso = 'CAMBIO_IMAGEN',
              t.auditoriausuario = v_usuario_auditoria,
              t.auditoriafecha = sysdate
        where (   trunc(nvl(t.fechadesde, date '1900-01-01')) <> trunc(c.fechadesde)
               or (t.fechahasta is null and c.fechahasta is not null)
               or (t.fechahasta is not null and c.fechahasta is null)
               or (t.fechahasta is not null and c.fechahasta is not null and trunc(t.fechahasta) <> trunc(c.fechahasta))
               or nvl(t.tipo_caso, '-') <> 'CAMBIO_IMAGEN');

      -- Caso 3B: cambio de imagen. Inserta rangos generales faltantes.
      insert into data.t_intc_producto_so (
          codigobarra,
          codigoproducto,
          fechadesde,
          fechahasta,
          auditoriausuario,
          auditoriafecha,
          compania,
          codigogrupo,
          tipo_caso
      )
      with barra_multiple as (
          select pm.compania,
                 trim(pm.codigobarra) codigobarra
            from data.vt_gzm_producto pm
           where pm.codigobarra is not null
             and trim(pm.codigobarra) <> '0000000000000'
             and pm.tipoprodUcto in (
                    'TERMINADO',
                    'TERCEROS',
                    'PRODUCTO TERMINADO',
                    'PRODUCTO TERMINADO IMPORTADO',
                    'ENVASES'
                 )
           group by pm.compania,
                    trim(pm.codigobarra)
          having count(distinct pm.codigoproducto) > 1
      ),
      producto_rango as (
          select s.compania,
                 trim(p.codigobarra) codigobarra,
                 trim(s.codigoproducto) codigoproducto,
                 min(trunc(s.fecha, 'MM')) fechadesde,
                 max(s.fecha) max_fecha
            from data.t_trad_sellin s
            join data.vt_gzm_producto p
              on p.compania = s.compania
             and p.codigoproducto = s.codigoproducto
            join barra_multiple bm
              on bm.compania = s.compania
             and bm.codigobarra = trim(p.codigobarra)
            join data.vt_gzm_cliente c
              on c.compania = s.compania
             and c.codigogrupo = s.codigogrupo
           where (p_compania is null or s.compania = p_compania)
             and s.fecha >= v_fecha_desde
             and p.codigobarra is not null
             and trim(p.codigobarra) <> '0000000000000'
             and nvl(s.valorunidad, 0) > 0
             and trim(c.codigoorigen) = 'NAC'
             and p.tipoprodUcto in (
                    'TERMINADO',
                    'TERCEROS',
                    'PRODUCTO TERMINADO',
                    'PRODUCTO TERMINADO IMPORTADO',
                    'ENVASES'
                 )
           group by s.compania,
                    trim(p.codigobarra),
                    trim(s.codigoproducto)
      ),
      producto_ordenado as (
          select compania,
                 codigobarra,
                 codigoproducto,
                 fechadesde,
                 max_fecha,
                 row_number() over (
                    partition by compania, codigobarra
                    order by max_fecha desc, fechadesde desc, codigoproducto desc
                 ) rn,
                 count(*) over (partition by compania, codigobarra) total_productos,
                     lag(fechadesde) over (
                        partition by compania, codigobarra
                        order by max_fecha desc, fechadesde desc, codigoproducto desc
                     ) siguiente_fechadesde
            from producto_rango
      ),
      candidatos as (
          select compania,
                 codigobarra,
                 codigoproducto,
                 fechadesde,
                 case
                    when rn = 1 then cast(null as date)
                    else siguiente_fechadesde - 1
                     end fechahasta
            from producto_ordenado
           where total_productos > 1
      )
      select c.codigobarra,
             c.codigoproducto,
             c.fechadesde,
             c.fechahasta,
             v_usuario_auditoria,
             sysdate,
             c.compania,
             cast(null as varchar2(125)),
             'CAMBIO_IMAGEN'
        from candidatos c
       where not exists (
             select 1
               from data.t_intc_producto_so t
              where t.compania = c.compania
                and trim(t.codigobarra) = c.codigobarra
                and trim(t.codigoproducto) = c.codigoproducto
                and t.codigogrupo is null
       );


      -- Caso 3C: cambio de imagen por cliente. Mantiene imagen anterior si el cliente aun no recibio la nueva imagen.
      -- Regla de negocio: las fechas de T_INTC_PRODUCTO_SO se derivan de Sell In, no de Sell Out.
      -- La presentacion anterior inicia en la primera venta Sell In del cliente y solo se cierra cuando
      -- Sell In confirme la nueva presentacion para ese mismo cliente. Un Sell Out posterior no cambia
      -- por si solo esa vigencia, pues puede corresponder a inventario de la presentacion anterior.
      -- Este bloque automatico procesa clientes NAC. Para clientes EXT, cuando no exista Sell In de la
      -- nueva presentacion, se debe registrar una excepcion IMAGEN_ANTERIOR_CLIENTE por CODIGOGRUPO
      -- siguiendo la misma regla y evitando traslapes con otra excepcion del mismo cliente y barra.
      merge into data.t_intc_producto_so t
      using (
          with barra_multiple as (
              select pm.compania,
                     trim(pm.codigobarra) codigobarra
                from data.vt_gzm_producto pm
               where pm.codigobarra is not null
                 and trim(pm.codigobarra) <> '0000000000000'
                 and pm.tipoprodUcto in (
                        'TERMINADO',
                        'TERCEROS',
                        'PRODUCTO TERMINADO',
                        'PRODUCTO TERMINADO IMPORTADO',
                        'ENVASES'
                     )
               group by pm.compania,
                        trim(pm.codigobarra)
              having count(distinct pm.codigoproducto) > 1
          ),
          producto_rango as (
              select s.compania,
                     trim(p.codigobarra) codigobarra,
                     trim(s.codigoproducto) codigoproducto,
                     min(trunc(s.fecha, 'MM')) fechadesde,
                     max(s.fecha) max_fecha
                from data.t_trad_sellin s
                join data.vt_gzm_producto p
                  on p.compania = s.compania
                 and p.codigoproducto = s.codigoproducto
                join barra_multiple bm
                  on bm.compania = s.compania
                 and bm.codigobarra = trim(p.codigobarra)
                join data.vt_gzm_cliente c
                  on c.compania = s.compania
                 and c.codigogrupo = s.codigogrupo
               where (p_compania is null or s.compania = p_compania)
                 and s.fecha >= v_fecha_desde
                 and p.codigobarra is not null
                 and trim(p.codigobarra) <> '0000000000000'
                 and nvl(s.valorunidad, 0) > 0
                 and trim(c.codigoorigen) = 'NAC'
                 and p.tipoprodUcto in (
                        'TERMINADO',
                        'TERCEROS',
                        'PRODUCTO TERMINADO',
                        'PRODUCTO TERMINADO IMPORTADO',
                        'ENVASES'
                     )
               group by s.compania,
                        trim(p.codigobarra),
                        trim(s.codigoproducto)
          ),
          producto_ordenado as (
              select compania,
                     codigobarra,
                     codigoproducto,
                     fechadesde,
                     max_fecha,
                     row_number() over (
                        partition by compania, codigobarra
                        order by max_fecha desc, fechadesde desc, codigoproducto desc
                     ) rn,
                     count(*) over (partition by compania, codigobarra) total_productos,
                     first_value(codigoproducto) over (
                        partition by compania, codigobarra
                        order by max_fecha desc, fechadesde desc, codigoproducto desc
                     ) codigoproducto_nuevo,
                     first_value(fechadesde) over (
                        partition by compania, codigobarra
                        order by max_fecha desc, fechadesde desc, codigoproducto desc
                     ) fechadesde_producto_nuevo
                from producto_rango
          ),
          cliente_producto as (
              select s.compania,
                     trim(p.codigobarra) codigobarra,
                     trim(s.codigogrupo) codigogrupo,
                     trim(s.codigoproducto) codigoproducto,
                     min(trunc(s.fecha, 'MM')) min_fecha,
                     max(s.fecha) max_fecha
                from data.t_trad_sellin s
                join data.vt_gzm_producto p
                  on p.compania = s.compania
                 and p.codigoproducto = s.codigoproducto
                join barra_multiple bm
                  on bm.compania = s.compania
                 and bm.codigobarra = trim(p.codigobarra)
                join data.vt_gzm_cliente c
                  on c.compania = s.compania
                 and c.codigogrupo = s.codigogrupo
               where (p_compania is null or s.compania = p_compania)
                 and s.fecha >= v_fecha_desde
                 and nvl(s.valorunidad, 0) > 0
                 and trim(c.codigoorigen) = 'NAC'
               group by s.compania,
                        trim(p.codigobarra),
                        trim(s.codigogrupo),
                        trim(s.codigoproducto)
          ),
          candidatos as (
              select po.compania,
                     po.codigobarra,
                     po.codigoproducto,
                     cp.codigogrupo,
                     po.fechadesde_producto_nuevo fechadesde,
                     cast(null as date) fechahasta,
                     row_number() over (
                        partition by po.compania, po.codigobarra, cp.codigogrupo
                        order by cp.max_fecha desc, po.rn asc, po.codigoproducto desc
                     ) rn_cliente
                from producto_ordenado po
                join cliente_producto cp
                  on cp.compania = po.compania
                 and cp.codigobarra = po.codigobarra
                 and cp.codigoproducto = po.codigoproducto
                left join cliente_producto cn
                  on cn.compania = po.compania
                 and cn.codigobarra = po.codigobarra
                 and cn.codigogrupo = cp.codigogrupo
                 and cn.codigoproducto = po.codigoproducto_nuevo
               where po.total_productos > 1
                 and po.rn > 1
                 and cn.min_fecha is null
                 and exists (
                       select 1
                         from data.t_trad_sellout so
                        where so.compania = po.compania
                          and so.codigogrupo = cp.codigogrupo
                          and so.codigobarra = po.codigobarra
                          and so.fecha >= po.fechadesde_producto_nuevo
                    )
          )
          select *
            from candidatos where rn_cliente = 1
      ) c
         on (    t.compania = c.compania
             and trim(t.codigobarra) = c.codigobarra
             and trim(t.codigoproducto) = c.codigoproducto
             and trim(t.codigogrupo) = c.codigogrupo
             and t.tipo_caso = 'IMAGEN_ANTERIOR_CLIENTE')
       when matched then update
          set t.fechadesde = c.fechadesde,
              t.fechahasta = c.fechahasta,
              t.auditoriausuario = v_usuario_auditoria,
              t.auditoriafecha = sysdate
        where (   trunc(nvl(t.fechadesde, date '1900-01-01')) <> trunc(c.fechadesde)
               or (t.fechahasta is null and c.fechahasta is not null)
               or (t.fechahasta is not null and c.fechahasta is null)
               or (t.fechahasta is not null and c.fechahasta is not null and trunc(t.fechahasta) <> trunc(c.fechahasta)));

      -- Caso 3D: cambio de imagen por cliente. Inserta excepciones faltantes para clientes con imagen anterior.
      -- La excepcion usa la historia de Sell In para determinar producto y vigencia; no se infiere desde
      -- la fecha de Sell Out. El tratamiento automatico queda limitado a NAC; EXT requiere excepcion
      -- explicita cuando conserve la presentacion anterior.
      insert into data.t_intc_producto_so (
          codigobarra,
          codigoproducto,
          fechadesde,
          fechahasta,
          auditoriausuario,
          auditoriafecha,
          compania,
          codigogrupo,
          tipo_caso
      )
      with barra_multiple as (
          select pm.compania,
                 trim(pm.codigobarra) codigobarra
            from data.vt_gzm_producto pm
           where pm.codigobarra is not null
             and trim(pm.codigobarra) <> '0000000000000'
             and pm.tipoprodUcto in (
                    'TERMINADO',
                    'TERCEROS',
                    'PRODUCTO TERMINADO',
                    'PRODUCTO TERMINADO IMPORTADO',
                    'ENVASES'
                 )
           group by pm.compania,
                    trim(pm.codigobarra)
          having count(distinct pm.codigoproducto) > 1
      ),
      producto_rango as (
          select s.compania,
                 trim(p.codigobarra) codigobarra,
                 trim(s.codigoproducto) codigoproducto,
                 min(trunc(s.fecha, 'MM')) fechadesde,
                 max(s.fecha) max_fecha
            from data.t_trad_sellin s
            join data.vt_gzm_producto p
              on p.compania = s.compania
             and p.codigoproducto = s.codigoproducto
            join barra_multiple bm
              on bm.compania = s.compania
             and bm.codigobarra = trim(p.codigobarra)
            join data.vt_gzm_cliente c
              on c.compania = s.compania
             and c.codigogrupo = s.codigogrupo
           where (p_compania is null or s.compania = p_compania)
             and s.fecha >= v_fecha_desde
             and p.codigobarra is not null
             and trim(p.codigobarra) <> '0000000000000'
             and nvl(s.valorunidad, 0) > 0
             and trim(c.codigoorigen) = 'NAC'
             and p.tipoprodUcto in (
                    'TERMINADO',
                    'TERCEROS',
                    'PRODUCTO TERMINADO',
                    'PRODUCTO TERMINADO IMPORTADO',
                    'ENVASES'
                 )
           group by s.compania,
                    trim(p.codigobarra),
                    trim(s.codigoproducto)
      ),
      producto_ordenado as (
          select compania,
                 codigobarra,
                 codigoproducto,
                 fechadesde,
                 max_fecha,
                 row_number() over (
                    partition by compania, codigobarra
                    order by max_fecha desc, fechadesde desc, codigoproducto desc
                 ) rn,
                 count(*) over (partition by compania, codigobarra) total_productos,
                 first_value(codigoproducto) over (
                    partition by compania, codigobarra
                    order by max_fecha desc, fechadesde desc, codigoproducto desc
                 ) codigoproducto_nuevo,
                     first_value(fechadesde) over (
                        partition by compania, codigobarra
                        order by max_fecha desc, fechadesde desc, codigoproducto desc
                     ) fechadesde_producto_nuevo
            from producto_rango
      ),
      cliente_producto as (
          select s.compania,
                 trim(p.codigobarra) codigobarra,
                 trim(s.codigogrupo) codigogrupo,
                 trim(s.codigoproducto) codigoproducto,
                 min(trunc(s.fecha, 'MM')) min_fecha,
                 max(s.fecha) max_fecha
            from data.t_trad_sellin s
            join data.vt_gzm_producto p
              on p.compania = s.compania
             and p.codigoproducto = s.codigoproducto
            join barra_multiple bm
              on bm.compania = s.compania
             and bm.codigobarra = trim(p.codigobarra)
            join data.vt_gzm_cliente c
              on c.compania = s.compania
             and c.codigogrupo = s.codigogrupo
           where (p_compania is null or s.compania = p_compania)
             and s.fecha >= v_fecha_desde
             and nvl(s.valorunidad, 0) > 0
             and trim(c.codigoorigen) = 'NAC'
           group by s.compania,
                    trim(p.codigobarra),
                    trim(s.codigogrupo),
                    trim(s.codigoproducto)
      ),
      candidatos as (
          select po.compania,
                 po.codigobarra,
                 po.codigoproducto,
                 cp.codigogrupo,
                 po.fechadesde_producto_nuevo fechadesde,
                 cast(null as date) fechahasta,
                     row_number() over (
                        partition by po.compania, po.codigobarra, cp.codigogrupo
                        order by cp.max_fecha desc, po.rn asc, po.codigoproducto desc
                     ) rn_cliente
            from producto_ordenado po
            join cliente_producto cp
              on cp.compania = po.compania
             and cp.codigobarra = po.codigobarra
             and cp.codigoproducto = po.codigoproducto
            left join cliente_producto cn
              on cn.compania = po.compania
             and cn.codigobarra = po.codigobarra
             and cn.codigogrupo = cp.codigogrupo
             and cn.codigoproducto = po.codigoproducto_nuevo
           where po.total_productos > 1
             and po.rn > 1
             and cn.min_fecha is null
             and exists (
                   select 1
                     from data.t_trad_sellout so
                    where so.compania = po.compania
                      and so.codigogrupo = cp.codigogrupo
                      and so.codigobarra = po.codigobarra
                      and so.fecha >= po.fechadesde_producto_nuevo
                )
      )
      select c.codigobarra,
             c.codigoproducto,
             c.fechadesde,
             c.fechahasta,
             v_usuario_auditoria,
             sysdate,
             c.compania,
             c.codigogrupo,
             'IMAGEN_ANTERIOR_CLIENTE'
        from candidatos c
       where c.rn_cliente = 1
         and not exists (
             select 1
               from data.t_intc_producto_so t
              where t.compania = c.compania
                and trim(t.codigobarra) = c.codigobarra
                and trim(t.codigoproducto) = c.codigoproducto
                and trim(t.codigogrupo) = c.codigogrupo
                and t.tipo_caso = 'IMAGEN_ANTERIOR_CLIENTE'
       );

      commit;
   exception
      when others then
         rollback;
         raise;
   end sp_generar_producto_so;

end pk_intc_sellout;
/
