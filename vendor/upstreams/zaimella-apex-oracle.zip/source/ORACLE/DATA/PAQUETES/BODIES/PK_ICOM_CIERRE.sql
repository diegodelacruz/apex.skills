create or replace PACKAGE BODY PK_ICOM_CIERRE AS 
	
	/*
	Procedimiento que realizar el proceso de la relacion entre SELL IN y SELL OUT y la insercion de 
	data a la tabla T_ICOM_INVERSION_ANALISIS para la etapa de cierre
	Por: JAsanza
	Fecha: Diciembre 2022
	*/
   PROCEDURE SP_ANALISISSELLIN_OUT(P_ID NUMBER, P_GRUPAL NUMBER, P_FECHAINICIO DATE, P_FECHAFIN DATE, P_PERIODO NUMBER, 
	                                P_NIVEL NUMBER, P_TIPO NUMBER, P_DURACION NUMBER, P_FECHAANALISIS DATE, 
                                    P_MESANALISIS NUMBER, P_CRECIMIENTO NUMBER, P_COMPANIA VARCHAR2 ) AS  
    --Declaraciones
    V_PDV NUMBER;
	V_ATIPO DATA.T_ICOM_INVERSION_ANALISIS.ANALISISTIPO%TYPE;
	V_BTIPO DATA.T_ICOM_INVERSION_ANALISIS.ANALISISTIPO%TYPE;
	V_MESES NUMBER;
    V_DURACION NUMBER;
    CURSOR CPERIODOS IS
	SELECT ID_TABLA, VALOR 	FROM DATA.T_CORP_UDC WHERE ID_CABECERA = 'ICOM_A1G1' AND ACTIVO = 1 AND VALOR = P_MESANALISIS; --AND CODIGOCOMPANIA=P_COMPANIA;
    V_PCT_CRE_SELLOUT NUMBER;
    V_PCT_CRE_SELLOUTUND NUMBER;
    V_TOT_SELLOUT  NUMBER;
    V_TOT_METASELLOUT NUMBER; 
    V_TOT_SELLOUTUND NUMBER; 
    V_TOT_METASELLOUTUND NUMBER;
    V_PDVLOCAL NUMBER;    
    V_ID_TIPO_INVERSION number;
	BEGIN
        
        --RAISE_APPLICATION_ERROR(-20001, 'P_FECHAANALISIS: '||P_FECHAANALISIS);

        --Actualizo los valores
        UPDATE DATA.T_ICOM_INVERSIONES
        SET CIERRENIVEL = P_NIVEL, CIERRETIPO = P_TIPO 
        WHERE ID = P_ID ;
                
        SELECT IDINVERSIONTIPO INTO V_ID_TIPO_INVERSION FROM DATA.T_ICOM_INVERSIONES WHERE ID = P_ID;

		V_ATIPO:= 'CIERRE_MES_';
		--GRAFICO RELACION SELL IN - SELL OUT
		DELETE T_ICOM_INVERSION_ANALISIS WHERE IDINVERSION = P_ID AND ANALISISTIPO LIKE 'CIERRE%';
		COMMIT;

		--busco los meses que se debe buscar las ventas en la tabla de parametros
        BEGIN
            V_MESES :=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '14', P_COMPANIA );
        EXCEPTION WHEN NO_DATA_FOUND THEN
            V_MESES := 0;
        END ;    

		IF (NVL(V_MESES,0)) = 0 THEN
			V_MESES := 1 ;
		END IF;
		
        --VERIFICA SI TIENE PDV
		V_PDV := PK_ICOM_COMMONS.F_TIENEPDV(P_ID);
        V_PDVLOCAL := PK_ICOM_COMMONS.F_TIENEPDVLOCAL(P_ID);    
        
        DELETE FROM DATA.T_TMP_B;
        
        /*grabar toda la data del sellout en la tabla temporal*/
        INSERT INTO DATA.T_TMP_B (FLAG, NUM01, TXT01, TXT02, TXT03, TXT04, TXT05, 
            DTE01, TXT06, TXT07, NUM02,NUM03, NUM04, TXT08, TXT09 ) 
        with producto as ( SELECT IDINVERSION,CODIGOBARRA, LINEANEGOCIO, MARCA,MAX(CODIGOPRODUCTO) CODIGOPRODUCTO,
                                    MAX(PRODUCTO) PRODUCTO, MAX(SUBMARCA) SUBMARCA
                           FROM DATA.T_ICOM_INVERSION_PRODUCTO
                           WHERE TIPO=1 and IDINVERSION=P_ID
                           GROUP BY IDINVERSION,CODIGOBARRA, LINEANEGOCIO, MARCA
        ), cliente as (    select cli.CODIGOCLIENTE, G.CODIGOGRUPO, CASE WHEN G.NEGOCIACION IN (3,1) THEN 1 ELSE 0 END TIPOCLIENTE 
                             from DATA.T_ICOM_INVERSION_CLIENTE_G G 
                             inner join data.T_ICOM_INVERSION_CLIENTE cli on (cli.IDINVERSION=G.IDINVERSION  AND CLI.CODIGOGRUPO = G.CODIGOGRUPO)
                             where G.IDINVERSION=P_ID
        ), inversion AS (    SELECT P_ID AS IDINVERSION, c.CODIGOGRUPO, p.CODIGOPRODUCTO, p.PRODUCTO,
                            p.LINEANEGOCIO, p.MARCA, p.SUBMARCA, c.TIPOCLIENTE, P.CODIGOBARRA, C.CODIGOCLIENTE
                        FROM cliente c, producto p
        ), pdv as     (    select CODIGOPDV from DATA.T_ICOM_CLIENTE_PDV PDV where IDINVERSION=P_ID 
        ), pdv_local as (  select CODIGOGRUPO, CODIGOLOCAL from DATA.T_ICOM_CLIENTE_PDV_LOCAL PDV where IDINVERSION=P_ID 
        ), ventas as (     select TRUNC(S.FECHA,'MM') FECHA, S.CODIGOCLIENTE , S.CODIGOGRUPO , CODIGOLOCAL,  CODIGOPDV, 
                           S.RUC, S.CODIGOPRODUCTO, S.CODIGOBARRA, SUM(S.VALORUNIDAD) VALORUNIDAD, SUM(S.VALORVENTA) VALORVENTA, S.COMPANIA
                           from data.Mvt_trad_sellout S
                           --left join data.t_trad_cliente C2 on ( s.CODIGOGRUPO=C2.CODIGOGRUPO and s.COMPANIA=C2.COMPANIA) --MODERNO
                           --LEFT JOIN data.t_trad_clienteruc R ON (R.ruc=S.ruc AND S.FECHA BETWEEN  R.FECHADESDE AND NVL(r.fechahasta, SYSDATE) )
                           where S.FECHA BETWEEN 
                           TRUNC(ADD_MONTHS(P_FECHAANALISIS, - 14),'MM')
                           --TRUNC(ADD_MONTHS(P_FECHAINICIO, -1*(V_MESES)),'MM') 
                           AND LAST_DAY(ADD_MONTHS(P_FECHAFIN,1))
                           AND S.COMPANIA = P_COMPANIA
                           GROUP BY TRUNC(S.FECHA,'MM'), S.CODIGOCLIENTE , S.CODIGOGRUPO , CODIGOLOCAL,  CODIGOPDV, 
                           S.RUC, S.CODIGOPRODUCTO, S.CODIGOBARRA, S.COMPANIA
        )
        SELECT P_COMPANIA, I.IDINVERSION, I.CODIGOGRUPO, I.CODIGOPRODUCTO||'-'||I.PRODUCTO, I.LINEANEGOCIO, I.SUBMARCA, I.MARCA,
            V.FECHA, TO_CHAR(V.FECHA,'MM')MES, TO_CHAR(V.FECHA,'YYYY') ANIO, NVL(V.VALORVENTA,0) AS VALOR, NVL(V.VALORUNIDAD, 0) AS VALORUND,  
            I.TIPOCLIENTE AS TIPO1, I.CODIGOBARRA, I.CODIGOCLIENTE
        FROM INVERSION I
            LEFT JOIN VENTAS V ON ( V.CODIGOCLIENTE = I.CODIGOCLIENTE  AND V.CODIGOBARRA = I.CODIGOBARRA )
            LEFT JOIN PDV PDV ON V.CODIGOPDV = PDV.CODIGOPDV
            LEFT JOIN PDV_LOCAL PL ON PL.CODIGOGRUPO = V.CODIGOGRUPO AND PL.CODIGOLOCAL = V.CODIGOLOCAL 
        WHERE ( V_PDV = 0 OR PDV.CODIGOPDV IS NOT NULL) 
            AND (V_PDVLOCAL = 0 OR PL.CODIGOLOCAL IS NOT NULL) ; 
                    
        begin/*GRAFICO Sell In  - Ventas anteriores*/
            INSERT INTO DATA.T_ICOM_INVERSION_ANALISIS(IDINVERSION,ANALISISTIPO,TIPO,PERIODO,FECHA,VALOR,VALORUND,VALORCOSTO,SELECCION,TIPO1,ORDEN)
                SELECT  P_ID IDINVERSION, 
                        V_ATIPO||'SELLIN' ANALISISTIPO,
                        TIPO1 TIPO,
                        UDC.ANIO||' - '||PERIODODESCRIPCION PERIODO,
                        NULL FECHA,
                        SUM(NVL(V.VALORVENTA,0)) VALOR,
                        SUM(NVL(V.VALORUNIDAD,0)) VALORUND,
                        SUM(NVL(V.VALORCOSTO,0)) VALORCOSTO,
                        0 SELECCION,
                        V.TIPOCLIENTE TIPO1,
                        1+(((UDC.ANIO-2000))/100)+(UDC.MES/10000) ORDEN
                FROM (
                        SELECT A.MES, A.ANIO, UDC.PERIODODESCRIPCION
                        FROM  (
                                SELECT TO_CHAR(ADD_MONTHS(P_FECHAINICIO,-LEVEL),'MM') MES,
                                TO_CHAR(ADD_MONTHS(P_FECHAINICIO,-LEVEL ),'YYYY') ANIO 
                                FROM DUAL CONNECT BY LEVEL <= V_MESES 
                        ) A,
                        VT_ICOM_PERIODOS UDC 
                        WHERE TO_NUMBER(A.MES)=UDC.ORDEN AND UDC.CODIGO=P_PERIODO
                ) UDC
                LEFT JOIN (
                    SELECT 
                        SUM(
                            CASE V_ID_TIPO_INVERSION
                                WHEN 4 THEN (VALORVENTA3)
                                ELSE(VALORVENTA)
                            END
                        ) VALORVENTA,
                        SUM(VALORUNIDAD) VALORUNIDAD,
                        SUM(VALORCOSTO) VALORCOSTO,
                        TO_CHAR(V.FECHA,'MM')MES,
                        TO_CHAR(V.FECHA,'YYYY') ANIO,
                        CASE P_NIVEL 
                              WHEN 1 THEN C.CODIGOGRUPO --CLIENTE  
                              WHEN 2 THEN P.CODIGOPRODUCTOPADRE||'-'||P.PRODUCTO --PRODUCTO
                              WHEN 3 THEN P.LINEANEGOCIO --LINEA NEGOCIO
                              WHEN 4 THEN P.SUBMARCA --SUBMARCA
                              WHEN 5 THEN P.MARCA --MARCHA
                        END  TIPO1, 
                        CASE WHEN G.NEGOCIACION IN (3,1) THEN 1 ELSE 0 END TIPOCLIENTE
                    FROM  DATA.VT_ICOM_INVERSION_CLIENTE G       --DATA.T_ICOM_INVERSION_CLIENTE_G G
                        INNER JOIN DATA.T_ICOM_INVERSION_CLIENTE C ON (C.IDINVERSION=G.IDINVERSION AND G.CODIGOGRUPO = C.CODIGOGRUPO)
                        LEFT JOIN DATA.T_TRAD_SELLIN V ON (V.CODIGOCLIENTE=C.CODIGOCLIENTE)
                        INNER JOIN VT_ICOM_PRODUCTO_SELLIN P ON (G.IDINVERSION=P.IDINVERSION AND V.CODIGOPRODUCTOPADRE=P.CODIGOPRODUCTOPADRE  )
                    WHERE G.IDINVERSION=P_ID
                    AND (V.COMPANIA = P_COMPANIA )
                    AND V.FECHA BETWEEN TRUNC(ADD_MONTHS(P_FECHAINICIO, -(V_MESES)),'MM') AND LAST_DAY(ADD_MONTHS(P_FECHAINICIO, -1))
                    GROUP BY    
                        TO_CHAR(V.FECHA,'MM'),TO_CHAR(V.FECHA,'YYYY'), 
                        CASE P_NIVEL  
                            WHEN 1 THEN C.CODIGOGRUPO --CLIENTE
                            WHEN 2 THEN P.CODIGOPRODUCTOPADRE||'-'||P.PRODUCTO --PRODUCTO
                            WHEN 3 THEN P.LINEANEGOCIO --LINEA NEGOCIO
                            WHEN 4 THEN P.SUBMARCA --SUBMARCA
                            WHEN 5 THEN P.MARCA --MARCHA
                        END,
                        CASE WHEN G.NEGOCIACION IN (3,1) THEN 1 ELSE 0 END
                ) V ON UDC.MES=V.MES  AND UDC.ANIO=V.ANIO
                GROUP BY UDC.ANIO, UDC.MES, PERIODODESCRIPCION, V.TIPO1, V.TIPOCLIENTE;
        end;
        
        begin/*GRAFICO Sell Out - Ventas anteriores*/
            INSERT INTO DATA.T_ICOM_INVERSION_ANALISIS(IDINVERSION, ANALISISTIPO, TIPO, PERIODO, FECHA, VALOR, VALORUND, VALORCOSTO, SELECCION, TIPO1, ORDEN)
                with aniomes as ( SELECT  TO_CHAR(ADD_MONTHS(P_FECHAINICIO,-LEVEL ),'MM') MES, 
                                    TO_CHAR(ADD_MONTHS(P_FECHAINICIO,-LEVEL ),'YYYY') ANIO
                                    FROM DUAL CONNECT BY LEVEL <= V_MESES 
                ), periodo as ( select a.mes, a.anio, udc.PERIODODESCRIPCION periododes  from aniomes  a 
                     inner join DATA.VT_ICOM_PERIODOS UDC on TO_NUMBER(a.MES)=UDC.ORDEN AND UDC.CODIGO=1 
                ), ventas as (  select NUM01 IDINVERSION,  TXT01 CODIGOGRUPO, TXT02 CODIGOPRODUCTO, TXT03 LINEANEGOCIO, TXT04 SUBMARCA, TXT05 MARCA, 
                    TXT06 MES, TXT07 ANIO, NUM02 VALORVENTA, NUM03 VALORUNIDAD, NUM04 TIPOCLIENTE, TXT08 CODIGOBARRA, DTE01 FECHA
                    FROM DATA.T_TMP_B
                    WHERE FLAG = P_COMPANIA AND NUM01 = P_ID AND DTE01 BETWEEN TRUNC(ADD_MONTHS(P_FECHAINICIO, -1*(V_MESES)),'MM') AND LAST_DAY(ADD_MONTHS(P_FECHAINICIO, -1))
                )
                SELECT P_ID IDINVERSION , V_ATIPO||'SELLOUT' ANALISISTIPO,
                    CASE P_NIVEL 
                        WHEN 1 THEN V.CODIGOGRUPO --CLIENTE
                        WHEN 2 THEN V.CODIGOPRODUCTO --PRODUCTO
                        WHEN 3 THEN V.LINEANEGOCIO --LINEA NEGOCIO
                        WHEN 4 THEN V.SUBMARCA --SUBMARCA
                        WHEN 5 THEN V.MARCA --MARCHA
                    END  TIPO,
                    P.ANIO || ' - ' || P.periododes AS PERIODO, NULL AS FECHA,
                    NVL(SUM(V.VALORVENTA),0) AS VALOR, NVL(SUM(V.VALORUNIDAD),0) AS VALORUND,  0 AS VALORCOSTO, 0 AS SELECCCION,
                    V.TIPOCLIENTE AS TIPO1, 1 + (((P.ANIO - 2000)) / 100) + (P.MES / 10000) AS ORDEN
                FROM PERIODO P
                    LEFT JOIN VENTAS V ON ( (V.FECHA IS NOT NULL AND V.MES = P.MES AND V.ANIO = P.ANIO) 
                        OR( V.FECHA IS NULL )  
                        ) 
                GROUP BY  P_ID , P.ANIO, P.MES, P.periododes, CASE P_NIVEL 
                        WHEN 1 THEN V.CODIGOGRUPO --CLIENTE
                        WHEN 2 THEN V.CODIGOPRODUCTO --PRODUCTO
                        WHEN 3 THEN V.LINEANEGOCIO --LINEA NEGOCIO
                        WHEN 4 THEN V.SUBMARCA --SUBMARCA
                        WHEN 5 THEN V.MARCA --MARCHA
                    END, V.TIPOCLIENTE ; 
                
        end;
        
        V_ATIPO:= 'CIERRE_REAL_';
        --GRAFICO RELACION SELL IN - SELL OUT ventas reales
        V_MESES := ROUND(MONTHS_BETWEEN(LAST_DAY(P_FECHAFIN),TRUNC(P_FECHAINICIO,'MM')))      ;
        COMMIT;
        begin /*GRAFICO Sell In  - Ventas reales*/
            INSERT INTO DATA.T_ICOM_INVERSION_ANALISIS (IDINVERSION, ANALISISTIPO, TIPO, PERIODO, FECHA, VALOR, VALORUND, VALORCOSTO, SELECCION, TIPO1, ORDEN)
                SELECT  
                    P_ID IDINVERSION,
                    CASE WHEN TO_NUMBER(TO_CHAR(P_FECHAFIN, 'YYYYMM')) >= TO_NUMBER(UDC.ANIO||UDC.MES) THEN V_ATIPO||'SELLIN' ELSE V_ATIPO||'SELLIN_FIN' END ANALISISTIPO,
                    V.TIPO1 TIPO,
                    UDC.ANIO||' - '||PERIODODESCRIPCION PERIODO,
                    NULL FECHA,
                    SUM(NVL(V.VALORVENTA,0))VALOR,
                    SUM(NVL(V.VALORUNIDAD,0))VALORUND,
                    SUM(NVL(V.VALORCOSTO,0))VALORCOSTO,
                    0 SELECCCION,
                    V.TIPOCLIENTE TIPO1, 
                    CASE WHEN TO_NUMBER(TO_CHAR(P_FECHAFIN, 'YYYYMM')) >= TO_NUMBER(UDC.ANIO||UDC.MES)THEN 4+(((UDC.ANIO-2000))/100)+(UDC.MES/10000) ELSE 12 END ORDEN
                FROM (
                    SELECT A.MES, A.ANIO, UDC.PERIODODESCRIPCION
                    FROM  (
                            SELECT 
                                TO_CHAR(ADD_MONTHS(P_FECHAINICIO,LEVEL-1),'MM') MES,
                                TO_CHAR(ADD_MONTHS(P_FECHAINICIO,LEVEL-1 ),'YYYY') ANIO
                            FROM DUAL CONNECT BY LEVEL <= V_MESES+1 
                    ) A,
                    VT_ICOM_PERIODOS UDC
                    WHERE TO_NUMBER(A.MES)=UDC.ORDEN AND UDC.CODIGO=P_PERIODO
                ) UDC
                LEFT JOIN (
                    SELECT 
                        SUM(
                            CASE V_ID_TIPO_INVERSION
                                WHEN 4 THEN (VALORVENTA3)
                                ELSE (VALORVENTA)
                            END
                        )VALORVENTA,
                        SUM(VALORUNIDAD) VALORUNIDAD, 
                        SUM(VALORCOSTO) VALORCOSTO,
                        TO_CHAR(V.FECHA,'MM')MES,
                        TO_CHAR(V.FECHA,'YYYY') ANIO,
                        CASE P_NIVEL 
                            WHEN 1 THEN C.CODIGOGRUPO --CLIENTE
                            WHEN 2 THEN P.CODIGOPRODUCTOPADRE||'-'||P.PRODUCTO --PRODUCTO
                            WHEN 3 THEN P.LINEANEGOCIO --LINEA NEGOCIO
                            WHEN 4 THEN P.SUBMARCA --SUBMARCA
                            WHEN 5 THEN P.MARCA --MARCHA
                        END  TIPO1,
                        CASE WHEN G.NEGOCIACION IN (3,1) THEN 1 ELSE 0 END TIPOCLIENTE
                    FROM  DATA.VT_ICOM_INVERSION_CLIENTE G-- DATA.T_ICOM_INVERSION_CLIENTE_G G
                    INNER JOIN DATA.T_ICOM_INVERSION_CLIENTE C ON (C.IDINVERSION=G.IDINVERSION AND G.CODIGOGRUPO = C.CODIGOGRUPO)
                    LEFT JOIN DATA.T_TRAD_SELLIN V ON (V.CODIGOCLIENTE=C.CODIGOCLIENTE)
                    INNER JOIN ( 
                            SELECT IDINVERSION, MAX(PRODUCTO) PRODUCTO, CODIGOPRODUCTOPADRE, LINEANEGOCIO, MARCA,SUBMARCA 
                            FROM DATA.T_ICOM_INVERSION_PRODUCTO P 
                            WHERE TIPO=1 
                            GROUP BY IDINVERSION,  CODIGOPRODUCTOPADRE, LINEANEGOCIO, MARCA,SUBMARCA 
                    )P ON (G.IDINVERSION=P.IDINVERSION AND V.CODIGOPRODUCTOPADRE=P.CODIGOPRODUCTOPADRE   )
                    WHERE G.IDINVERSION=P_ID
                    AND (V.COMPANIA = P_COMPANIA)
                    AND V.FECHA BETWEEN TRUNC(P_FECHAINICIO,'MM') AND  LAST_DAY(ADD_MONTHS(P_FECHAFIN,1)) --se aniade un mes al final
                    
                    GROUP BY TO_CHAR(V.FECHA,'MM'), TO_CHAR(V.FECHA,'YYYY'), 
                        CASE P_NIVEL 
                            WHEN 1 THEN C.CODIGOGRUPO --CLIENTE
                            WHEN 2 THEN P.CODIGOPRODUCTOPADRE||'-'||P.PRODUCTO --PRODUCTO
                            WHEN 3 THEN P.LINEANEGOCIO --LINEA NEGOCIO
                            WHEN 4 THEN P.SUBMARCA --SUBMARCA
                            WHEN 5 THEN P.MARCA --MARCHA
                        END, 
                        CASE WHEN G.NEGOCIACION IN (3,1) THEN 1 ELSE 0 END
                ) V ON UDC.MES=V.MES  AND UDC.ANIO=V.ANIO
                GROUP BY CASE WHEN TO_NUMBER(TO_CHAR(P_FECHAFIN, 'YYYYMM')) >= TO_NUMBER(UDC.ANIO||UDC.MES) THEN V_ATIPO||'SELLIN' ELSE V_ATIPO||'SELLIN_FIN' END,
                UDC.ANIO, UDC.MES, PERIODODESCRIPCION, V.TIPO1, V.TIPOCLIENTE;
        end;
        
        COMMIT;
      
        begin /*GRAFICO Sell Out - Ventas reales*/
            INSERT INTO DATA.T_ICOM_INVERSION_ANALISIS (IDINVERSION, ANALISISTIPO, TIPO, PERIODO, FECHA, VALOR, VALORUND, VALORCOSTO, SELECCION, TIPO1, ORDEN)
                with aniomes as ( SELECT TO_CHAR(ADD_MONTHS(P_FECHAINICIO,LEVEL-1),'MM') MES,
                                         TO_CHAR(ADD_MONTHS(P_FECHAINICIO,LEVEL-1 ),'YYYY') ANIO
                                  FROM DUAL CONNECT BY LEVEL <= V_MESES+1 
                ), periodo as ( select a.mes, a.anio, udc.PERIODODESCRIPCION periododes  from aniomes  a 
                     inner join DATA.VT_ICOM_PERIODOS UDC on TO_NUMBER(a.MES)=UDC.ORDEN AND UDC.CODIGO=1 
                ), ventas as (  select TXT01 CODIGOGRUPO, TXT02 CODIGOPRODUCTO, TXT03 LINEANEGOCIO, TXT04 SUBMARCA, TXT05 MARCA, 
                        TXT06 MES, TXT07 ANIO, NUM02 VALORVENTA, NUM03 VALORUNIDAD, NUM04 TIPOCLIENTE, TXT08 CODIGOBARRA, DTE01 FECHA
                    FROM DATA.T_TMP_B
                    WHERE FLAG = P_COMPANIA AND NUM01 = P_ID AND DTE01 BETWEEN TRUNC(P_FECHAINICIO,'MM') AND  LAST_DAY(ADD_MONTHS(P_FECHAFIN,1)) --SE AÃ‚Â¿ADE UN MES
                )
                SELECT P_ID IDINVERSION,
                    CASE WHEN TO_NUMBER(TO_CHAR(P_FECHAFIN, 'YYYYMM')) >= TO_NUMBER(P.ANIO||P.MES) THEN V_ATIPO||'SELLOUT' ELSE V_ATIPO||'SELLOUT_FIN' END ANALISISTIPO,
                    CASE P_NIVEL 
                        WHEN 1 THEN V.CODIGOGRUPO --CLIENTE
                        WHEN 2 THEN V.CODIGOPRODUCTO --PRODUCTO
                        WHEN 3 THEN V.LINEANEGOCIO --LINEA NEGOCIO
                        WHEN 4 THEN V.SUBMARCA --SUBMARCA
                        WHEN 5 THEN V.MARCA --MARCHA
                    END  TIPO,
                    P.ANIO || ' - ' || P.periododes AS PERIODO, NULL AS FECHA,
                    NVL(SUM(V.VALORVENTA),0) AS VALOR, NVL(SUM(V.VALORUNIDAD),0) AS VALORUND,  0 AS VALORCOSTO, 0 AS SELECCCION, V.TIPOCLIENTE AS TIPO1, 
                    CASE WHEN TO_NUMBER(TO_CHAR(P_FECHAFIN, 'YYYYMM')) >= TO_NUMBER(P.ANIO||P.MES) THEN 4+(((P.ANIO-2000))/100)+(P.MES/10000) ELSE 12 END ORDEN
                FROM PERIODO P
                    LEFT JOIN VENTAS V ON ( (V.FECHA IS NOT NULL AND V.MES = P.MES AND V.ANIO = P.ANIO)
                    OR ( V.FECHA IS NULL )
                    ) 
                GROUP BY P_ID , --P_ID,CASE WHEN TO_NUMBER(TO_CHAR(P_FECHAFIN, 'YYYYMM')) >= TO_NUMBER(PER.ANIO||PER.MES) THEN V_ATIPO||'SELLOUT' ELSE V_ATIPO||'SELLOUT_FIN' END, 
                    P.ANIO, P.MES, P.periododes, 
                    CASE P_NIVEL 
                        WHEN 1 THEN V.CODIGOGRUPO --CLIENTE
                        WHEN 2 THEN V.CODIGOPRODUCTO --PRODUCTO
                        WHEN 3 THEN V.LINEANEGOCIO --LINEA NEGOCIO
                        WHEN 4 THEN V.SUBMARCA --SUBMARCA
                        WHEN 5 THEN V.MARCA --MARCHA
                    END, V.TIPOCLIENTE ; 
        end;

        V_DURACION := PK_ICOM_COMMONS.F_DURACION(P_FECHA_INICIO => TRUNC(P_FECHAINICIO,'MM'), P_FECHA_FIN => LAST_DAY(P_FECHAFIN));
        IF NVL(V_DURACION,0) = 0 THEN --se valida para que la divisiÃ‚Â¿n no tenga error
            V_DURACION := 1; 
        END IF;       

        BEGIN/*Actualiza los valores sellin  reales por cliente */
            MERGE INTO T_ICOM_INVERSION_VENTAS cli
            USING (
                SELECT 
                    V.COMPANIA,1 TIPO /*{1:SELLIN,2:SELLOUT}*/,
                    G.IDINVERSION,G.CODIGOGRUPO,G.CODIGOCLIENTE,p.CODIGOPRODUCTOPADRE CODIGOPRODUCTO,
                    NVL(
                        SUM(
                            CASE V_ID_TIPO_INVERSION
                                WHEN 4 THEN V.VALORVENTA3
                                ELSE V.VALORVENTA
                            END
                        )
                    ,0) VENTAREAL,NVL(SUM(V.VALORUNIDAD),0) CANTIDADREAL,NVL(SUM(V.VALORCOSTO),0) COSTOREAL
                FROM T_ICOM_INVERSION_CLIENTE G 
                LEFT JOIN T_TRAD_SELLIN V ON (V.CODIGOCLIENTE=G.CODIGOCLIENTE)
                inner JOIN ( 
                    SELECT IDINVERSION,MAX(trim(PRODUCTO))PRODUCTO,CODIGOPRODUCTOPADRE,trim(LINEANEGOCIO)LINEANEGOCIO,trim(MARCA)MARCA,trim(SUBMARCA)SUBMARCA
                    FROM DATA.T_ICOM_INVERSION_PRODUCTO P 
                    WHERE TIPO=1 
                    GROUP BY IDINVERSION,CODIGOPRODUCTOPADRE,trim(LINEANEGOCIO),trim(MARCA),trim(SUBMARCA) 
                ) 
                P ON (G.IDINVERSION=P.IDINVERSION AND V.CODIGOPRODUCTOPADRE=P.CODIGOPRODUCTOPADRE )
                WHERE v.FECHA  BETWEEN  TRUNC(to_date(P_FECHAINICIO),'MM') AND  LAST_DAY(to_date(P_FECHAFIN))
                AND (G.IDINVERSION=P_ID )
                AND (V.COMPANIA = P_COMPANIA)
                GROUP BY V.COMPANIA,G.IDINVERSION,G.CODIGOGRUPO,G.CODIGOCLIENTE,p.CODIGOPRODUCTOPADRE
            ) arc
            ON (
                CLI.TIPO            =ARC.TIPO 
            AND CLI.IDINVERSION     =ARC.IDINVERSION 
            AND cli.codigocliente   =arc.codigocliente 
            and cli.CODIGOGRUPO     =ARC.CODIGOGRUPO 
            and cli.CODIGOPRODUCTO  =ARC.CODIGOPRODUCTO 
            and cli.compania        =ARC.compania
            )
            WHEN MATCHED THEN
                UPDATE SET
                    cli.VENTAREAL = (arc.VENTAREAL/NVL(V_DURACION,1))*P_DURACION, 
                    cli.CANTIDADREAL=(arc.CANTIDADREAL/NVL(V_DURACION,1))*P_DURACION,
                    cli.COSTOREAL= (arc.COSTOREAL/NVL(V_DURACION,1))*P_DURACION;
        END;
        BEGIN/*Actualizao los valores sell out reales por cliente*/
            MERGE INTO T_ICOM_INVERSION_VENTAS cli
            USING ( select FLAG compania, 2 TIPO, NUM01 IDINVERSION, TXT01 CODIGOGRUPO, TXT09 CODIGOCLIENTE, TXT08 CODIGOBARRA,  
                         NVL(SUM(NUM02),0) VENTAREAL, NVL(SUM(NUM03),0) CANTIDADREAL, 0 COSTOREAL 
                    FROM DATA.T_TMP_B
                    WHERE FLAG = P_COMPANIA AND NUM01 = P_ID AND DTE01 BETWEEN TRUNC(TO_DATE(P_FECHAINICIO),'MM') AND  LAST_DAY(TO_DATE(P_FECHAFIN))
                    GROUP BY FLAG, NUM01, TXT01, TXT09, TXT08  
            ) arc
            ON (CLI.TIPO=ARC.TIPO AND CLI.IDINVERSION=ARC.IDINVERSION AND  cli.codigocliente = arc.codigocliente and cli.CODIGOGRUPO=ARC.CODIGOGRUPO and cli.CODIGOBARRA =ARC.CODIGOBARRA and cli.compania=ARC.compania )
            WHEN MATCHED THEN
                UPDATE SET
                    cli.VENTAREAL = (arc.VENTAREAL/NVL(V_DURACION,1))*P_DURACION, 
                    cli.CANTIDADREAL=(arc.CANTIDADREAL/NVL(V_DURACION,1))*P_DURACION,
                    cli.COSTOREAL= (arc.COSTOREAL/NVL(V_DURACION,1))*P_DURACION;        
        END;

        --- Cierre - SituaciÃ‚Â¿n Planteada
        V_ATIPO:= 'CIERRE_SITUACION_';
        COMMIT;

        FOR PERIODO IN CPERIODOS LOOP    
            --valores sellin
            INSERT INTO DATA.T_ICOM_INVERSION_ANALISIS (IDINVERSION, ANALISISTIPO, TIPO, PERIODO, FECHA, VALOR, VALORUND, VALORCOSTO, SELECCION, TIPO1, ORDEN)
                SELECT  P_ID IDINVERSION,
                        V_ATIPO||'SELLIN' ANALISISTIPO, 
                        CASE P_NIVEL 
                            WHEN 1 THEN C.CODIGOGRUPO --CLIENTE
                            WHEN 2 THEN P.CODIGOPRODUCTOPADRE||'-'||P.PRODUCTO --PRODUCTO
                            WHEN 3 THEN P.LINEANEGOCIO --LINEA NEGOCIO
                            WHEN 4 THEN P.SUBMARCA --SUBMARCA
                            WHEN 5 THEN P.MARCA --MARCHA
                        END TIPO,  
                        'SITUACION PLANTEADA' TIPO,
                        NULL FECHA,
                        NVL(
                            SUM(
                                CASE V_ID_TIPO_INVERSION
                                    WHEN 4 THEN V.VALORVENTA3
                                    ELSE V.VALORVENTA
                                END
                            )/PERIODO.VALOR,0
                        ) *P_DURACION
                        VALOR,
                        ROUND(NVL(SUM(V.VALORUNIDAD)/PERIODO.VALOR,0)*P_DURACION,0) VALOR,
                        NVL(SUM(V.VALORCOSTO)/PERIODO.VALOR,0)*P_DURACION VALORCOSTO, 
                        0 SELECCION,
                        CASE WHEN G.NEGOCIACION IN (3,1) THEN 1 ELSE 0 END TIPO1,
                        2 ORDEN
                FROM  DATA.T_ICOM_INVERSION_CLIENTE_G G
                INNER JOIN DATA.T_ICOM_INVERSION_CLIENTE C ON (C.IDINVERSION=G.IDINVERSION AND G.CODIGOGRUPO = C.CODIGOGRUPO)
                LEFT JOIN DATA.T_TRAD_SELLIN V ON (V.CODIGOCLIENTE=C.CODIGOCLIENTE)
                INNER JOIN ( 
                        SELECT IDINVERSION, MAX(PRODUCTO) PRODUCTO, CODIGOPRODUCTOPADRE, LINEANEGOCIO, MARCA,SUBMARCA 
                        FROM
                        DATA.T_ICOM_INVERSION_PRODUCTO P 
                        WHERE TIPO=1 
                        GROUP BY IDINVERSION,CODIGOPRODUCTOPADRE, LINEANEGOCIO, MARCA,SUBMARCA 
                )P ON (G.IDINVERSION=P.IDINVERSION AND V.CODIGOPRODUCTOPADRE=P.CODIGOPRODUCTOPADRE )
                WHERE G.IDINVERSION=P_ID
                AND V.FECHA  BETWEEN TRUNC(ADD_MONTHS(P_FECHAANALISIS, - (PERIODO.VALOR)),'MM') AND LAST_DAY(ADD_MONTHS(P_FECHAANALISIS, -1))
                AND (V.COMPANIA = P_COMPANIA)
                GROUP BY CASE P_NIVEL 
                            WHEN 1 THEN C.CODIGOGRUPO
                            WHEN 2 THEN P.CODIGOPRODUCTOPADRE||'-'||P.PRODUCTO
                            WHEN 3 THEN P.LINEANEGOCIO
                            WHEN 4 THEN P.SUBMARCA
                            WHEN 5 THEN P.MARCA 
                        END,
                        CASE WHEN G.NEGOCIACION IN (3,1) THEN 1 ELSE 0 END
            ;

            --VALORES SELL OUT PDV
            
            INSERT INTO DATA.T_ICOM_INVERSION_ANALISIS (IDINVERSION, ANALISISTIPO, TIPO, PERIODO, FECHA, VALOR, VALORUND, VALORCOSTO, SELECCION, TIPO1, ORDEN)
                WITH ventas as (  select TXT01 CODIGOGRUPO, TXT02 CODIGOPRODUCTO, TXT03 LINEANEGOCIO, TXT04 SUBMARCA, TXT05 MARCA, 
                        TXT06 MES, TXT07 ANIO, NUM02 VALORVENTA, NUM03 VALORUNIDAD, NUM04 TIPOCLIENTE, TXT08 CODIGOBARRA
                    FROM DATA.T_TMP_B
                    WHERE FLAG = P_COMPANIA AND NUM01 = P_ID AND DTE01 BETWEEN TRUNC(ADD_MONTHS(P_FECHAANALISIS, - (PERIODO.VALOR)),'MM')  AND LAST_DAY(ADD_MONTHS(P_FECHAANALISIS, -1))
                )   
                SELECT P_ID IDINVERSION , V_ATIPO||'SELLOUT' ANALISISTIPO, 
                    CASE P_NIVEL 
                        WHEN 1 THEN V.CODIGOGRUPO --CLIENTE
                        WHEN 2 THEN V.CODIGOPRODUCTO --PRODUCTO
                        WHEN 3 THEN V.LINEANEGOCIO --LINEA NEGOCIO
                        WHEN 4 THEN V.SUBMARCA --SUBMARCA
                        WHEN 5 THEN V.MARCA --MARCHA
                    END  TIPO, 'SITUACION PLANTEADA' PERIODO, NULL FECHA, NVL(SUM(V.VALORVENTA)/PERIODO.VALOR,0)*P_DURACION VALOR,
                    ROUND(NVL(SUM(V.VALORUNIDAD)/PERIODO.VALOR,0)*P_DURACION,0) VALORUND, 0 VALORCOSTO, 0 SELECCION, V.TIPOCLIENTE TIPO1, 2 ORDEN
                FROM VENTAS V 
                GROUP BY P_ID , CASE P_NIVEL 
                        WHEN 1 THEN V.CODIGOGRUPO --CLIENTE
                        WHEN 2 THEN V.CODIGOPRODUCTO --PRODUCTO
                        WHEN 3 THEN V.LINEANEGOCIO --LINEA NEGOCIO
                        WHEN 4 THEN V.SUBMARCA --SUBMARCA
                        WHEN 5 THEN V.MARCA --MARCHA
                    END, V.TIPOCLIENTE ;                        
        END LOOP;

        --- Cierre - Meta Planteada
        V_ATIPO:= 'CIERRE_META_';

        COMMIT;
        --Para sellin 
        INSERT INTO DATA.T_ICOM_INVERSION_ANALISIS
        (IDINVERSION, ANALISISTIPO, TIPO, PERIODO, FECHA, VALOR, VALORUND, VALORCOSTO, SELECCION, TIPO1, ORDEN)
        (SELECT IDINVERSION, V_ATIPO||'SELLIN', TIPO, 'META PLANTEADA', FECHA, 
            (VALOR*(1+(P_CRECIMIENTO/100))), ROUND(VALORUND*(1+(P_CRECIMIENTO/100)),0), (VALORCOSTO*(1+(P_CRECIMIENTO/100))), 
            0, TIPO1, 3      
         FROM DATA.T_ICOM_INVERSION_ANALISIS
         WHERE IDINVERSION = P_ID
         AND ANALISISTIPO IN ('CIERRE_SITUACION_SELLIN') ) ;
        
        IF P_NIVEL = 1 THEN
            --el %de crecimiento se lo realiza por cada cliente
            --Para Sellout
            INSERT INTO DATA.T_ICOM_INVERSION_ANALISIS(IDINVERSION, ANALISISTIPO, TIPO, PERIODO, FECHA, VALOR, VALORUND, VALORCOSTO, SELECCION, TIPO1, ORDEN)
            (
                SELECT 
                    A.IDINVERSION TIPO1,
                    V_ATIPO||'SELLOUT' TIPO1,
                    A.TIPO TIPO1, 
                    'META PLANTEADA' TIPO1, 
                    A.FECHA FECHA,
                    (A.VALOR*(1+(NVL(G.SELLOUTCRECIMIENTO,0)/100)))VALOR,
                    ROUND(A.VALORUND*(1+(NVL(G.SELLOUTCRECIMIENTOUND,0)/100)),0) VALORUND,
                    (A.VALORCOSTO*(1+(NVL(G.SELLOUTCRECIMIENTO,0)/100)))VALORCOSTO, 
                    0 SELECCION, 
                    TIPO1 TIPO1,
                    3 TIPO1
                FROM DATA.T_ICOM_INVERSION_ANALISIS A
                INNER JOIN DATA.T_ICOM_INVERSION_CLIENTE C ON (C.IDINVERSION=A.IDINVERSION  AND A.TIPO=C.CODIGOCLIENTE)
                INNER JOIN DATA.T_ICOM_INVERSION_CLIENTE_G G ON (C.IDINVERSION = G.IDINVERSION  AND C.CODIGOGRUPO = G.CODIGOGRUPO )
                WHERE A.IDINVERSION = P_ID AND A.ANALISISTIPO IN ('CIERRE_SITUACION_SELLOUT') 
            ) ;
                
            --Se actualiza los nombres de los clientes
            FOR CLI IN (SELECT DISTINCT TIPO FROM DATA.T_ICOM_INVERSION_ANALISIS 
                        WHERE IDINVERSION = P_ID AND P_NIVEL = 1 AND ANALISISTIPO LIKE 'CIERRE%' ) 
            LOOP
                UPDATE DATA.T_ICOM_INVERSION_ANALISIS
                SET TIPO = ( SELECT  CODIGOCLIENTE||'-'||NOMBRES FROM VT_GZM_CLIENTE 
                             WHERE COMPANIA = P_COMPANIA AND CODIGOCLIENTE = CLI.TIPO )
                WHERE IDINVERSION = P_ID AND TIPO = NVL(CLI.TIPO,0) AND ANALISISTIPO LIKE 'CIERRE%' ;
            END LOOP; 
        ELSE   
            --Para buscar el %creaciiento del SELLOUT en base a los totales de clientes grabado
            BEGIN
                SELECT SUM(NVL(SELLOUT,0)), SUM( NVL(SELLOUT,0) *(1+NVL(SELLOUTCRECIMIENTO/100,0)) ), 
                       SUM(NVL(SELLOUTUND,0)), SUM( NVL(SELLOUTUND,0) *(1+NVL(SELLOUTCRECIMIENTOUND/100,0)) ) 
                INTO V_TOT_SELLOUT, V_TOT_METASELLOUT,
                     V_TOT_SELLOUTUND, V_TOT_METASELLOUTUND
                FROM VT_ICOM_INVERSION_CLIENTE--data.t_icom_inversion_cliente_g
                WHERE IDINVERSION = P_ID ;
                V_PCT_CRE_SELLOUT := CASE WHEN NVL(V_TOT_SELLOUT,0) =0 THEN 0 ELSE (V_TOT_METASELLOUT / CASE WHEN V_TOT_SELLOUT = 0 THEN 0 ELSE V_TOT_SELLOUT END )  -1 END;
                V_PCT_CRE_SELLOUTUND := CASE WHEN NVL(V_TOT_SELLOUTUND,0) =0 THEN 0 ELSE  (V_TOT_METASELLOUTUND / CASE WHEN NVL(V_TOT_SELLOUTUND,0) = 0 THEN 0 ELSE V_TOT_SELLOUTUND END ) -1  END;
            END;
            
            --Para Sellout
            INSERT INTO DATA.T_ICOM_INVERSION_ANALISIS
            (IDINVERSION, ANALISISTIPO, TIPO, PERIODO, FECHA, VALOR, VALORUND, VALORCOSTO, SELECCION, TIPO1, ORDEN)
            (SELECT IDINVERSION, V_ATIPO||'SELLOUT' , TIPO, 'META PLANTEADA', FECHA, 
                (VALOR*(1+V_PCT_CRE_SELLOUT)), ROUND(VALORUND*(1+V_PCT_CRE_SELLOUTUND),0), (VALORCOSTO*(1+V_PCT_CRE_SELLOUT)), 
                0, TIPO1, 3      
             FROM DATA.T_ICOM_INVERSION_ANALISIS
             WHERE IDINVERSION = P_ID
             AND ANALISISTIPO IN ('CIERRE_SITUACION_SELLOUT') ) ;
             
        END IF;         
         
         --- Cierre - TOTAL REAL
        V_ATIPO:= 'CIERRE_TOTAL_REAL_';
        --commit;

        --TOTAL REAL Para sellin 
        V_DURACION := PK_ICOM_COMMONS.F_DURACION(P_FECHA_INICIO => TRUNC(P_FECHAINICIO,'MM'), P_FECHA_FIN => LAST_DAY(P_FECHAFIN));
        IF NVL(V_DURACION,0) = 0 THEN --se valida para que la divisiÃ‚Â¿n no tenga error
            V_DURACION := 1; 
        END IF;       
        INSERT INTO DATA.T_ICOM_INVERSION_ANALISIS(IDINVERSION,ANALISISTIPO,TIPO,PERIODO,FECHA,VALOR,VALORUND,VALORCOSTO,SELECCION,TIPO1,ORDEN)
        (
            SELECT 
                P_ID IDINVERSION,
                V_ATIPO||CASE WHEN ANALISISTIPO = 'CIERRE_REAL_SELLIN' THEN 'SELLIN' ELSE 'SELLOUT' END ANALISISTIPO,
                TIPO TIPO,
                'TOTAL REAL' PERIODO,
                NULL FECHA,
                (SUM(VALOR)/V_DURACION)*P_DURACION VALOR,
                ROUND((SUM(VALORUND)/V_DURACION)*P_DURACION,0) VALORUND,
                (SUM(VALORCOSTO)/V_DURACION)*P_DURACION VALORCOSTO,
                0 SELECCION,
                TIPO1 TIPO1,
                5 ORDEN
            FROM DATA.T_ICOM_INVERSION_ANALISIS
            WHERE IDINVERSION = P_ID
            AND ANALISISTIPO IN ('CIERRE_REAL_SELLIN', 'CIERRE_REAL_SELLOUT' ) 
            GROUP BY V_ATIPO||CASE WHEN ANALISISTIPO = 'CIERRE_REAL_SELLIN' THEN 'SELLIN' ELSE 'SELLOUT' END,  TIPO, TIPO1       
         ) ;
        COMMIT;
        
        --JASANZA 
        --Cargar los valores sell in totales de la inversion en la tabla
        UPDATE DATA.T_ICOM_INVERSIONES
            SET (SELLINREAL, SELLINUNDREAL, SELLINCOSTOREAL) =
        ( SELECT SUM(NVL(VALOR,0)), SUM(NVL(VALORUND,0)), SUM(NVL(VALORCOSTO,0))
          FROM DATA.T_ICOM_INVERSION_ANALISIS
          WHERE IDINVERSION = P_ID
          AND ANALISISTIPO = 'CIERRE_TOTAL_REAL_SELLIN'
          AND TIPO1 IN (0,1) )   WHERE ID = P_ID;
        --Cargar los valores sell out totales de la inversion en la tabla
        UPDATE DATA.T_ICOM_INVERSIONES
        SET (SELLOUTREAL, SELLOUTUNDREAL, SELLOUTCOSTOREAL) =
        ( SELECT SUM(NVL(VALOR,0)), SUM(NVL(VALORUND,0)), SUM(NVL(VALORCOSTO,0))
          FROM DATA.T_ICOM_INVERSION_ANALISIS
          WHERE IDINVERSION = P_ID
          AND ANALISISTIPO = 'CIERRE_TOTAL_REAL_SELLOUT'
          AND TIPO1 IN (1) ) WHERE ID = P_ID;
          
        
	END SP_ANALISISSELLIN_OUT;


	/*
	Procedimiento que inserta los gasto dependiendo de las validacione y la seleccion de la inversion
	Por: JAsanza
	Fecha: Diciembre 2022
	*/
	PROCEDURE SP_AGREGAGASTOVALIDACION ( P_IDINVERSION NUMBER, P_IDSELECCION NUMBER) AS
	BEGIN
		MERGE INTO DATA.T_ICOM_INVERSION_GASTO G
            USING (select  inv.id, 'VALIDACION' tipo, f.descripcion fuente,sum(nvl(cv.TOT_VALORZAIMELLA,0)+ nvl(cv.TOT_VALOREXCEPCION,0)) valor
                    from data.t_icom_inversiones inv
						inner join data.t_icom_cliente_validacion cv on (inv.id = cv.idinversion and cv.estado = 1  AND CV.idvalidaciontipo<>4 )
                        inner join data.VT_ICOM_FORMAPAGO F ON (cv.IDFORMAPAGO= F.IDFORMAPAGO)
                    where ((inv.id = P_IDINVERSION or inv.idgrupo = P_IDINVERSION ) and P_IDSELECCION is null) 
					   	or (inv.id = P_IDSELECCION and P_IDSELECCION is not null) 
                    group by inv.id, 'VALIDACION', f.descripcion ) i
            ON ( g.idinversion = i.id  and g.tipo = i.tipo and g.fuente = i.fuente and g.gastotipo = 'GASTO' ) 
            WHEN MATCHED THEN
                UPDATE SET G.VALORREAL = i.valor 
            WHEN NOT MATCHED THEN    
                INSERT (IDINVERSION,GASTOTIPO,TIPO,PERIODO,VALOR,FUENTE,OBSERVACION,
				VALORMETA,VALORPEQ,VALORREAL, IDGASTO )
                VALUES ( i.id, 'GASTO', i.tipo, null, null, i.fuente, i.fuente,
				0, 0, i.valor, PK_COMMONS.F_SECUENCIA ('DATA.T_ICOM_INVERSION_GASTO') ); 
	END;

	/*
	Procedimiento graba los valores del KPI de la inversion
	Por: JAsanza
	*/
	PROCEDURE SP_KPIVALORES (P_IDINVERSION NUMBER) AS
	v_inversion data.t_icom_inversiones%ROWTYPE ;
	v_valor number;
	v_meta number;
	v_valorreal number;
    v_calificacion number;
    v_valorinicialAprobado number;
    v_valorinicialRechazado number;
    v_metaAprobado number;
    v_metaRechazado number;
    v_valorrealAprobado number;
    v_ValorRealRechazado number;

    BEGIN

		for v_inversion in (select inv.id, nvl(inv.idetapa,1) idetapa, inv.sellin, inv.sellincrecimiento, inv.sellinreal, inv.sellincosto,  inv.sellincostoreal, 
                                inv.duracion, inv.sellout, inv.selloutreal,
                                kpi.idkpi, des.descripcion, kpi.valorinicial, kpi.meta, kpi.valorreal, kpi.ponderacion,
                                kpi.valorinicialAprobado, kpi.valorinicialRechazado, kpi.metaAprobado, kpi.MetaRechazado, kpi.valorrealAprobado,
                                kpi.ValorRealRechazado, kpi.calificacionAprobado, kpi.calificacionRechazado
                            from data.t_icom_inversiones inv
                               inner join data.t_icom_inversion_kpi kpi on (inv.id = kpi.idinversion )
                               inner join data.vt_icom_kpi des on (kpi.idkpi = des.idkpi and  inv.compania = des.compania ) 
                            where inv.id = P_IDINVERSION  or inv.idpadre = p_idinversion ) 
		loop 
			v_valor := v_inversion.valorinicial ;
			v_meta := v_inversion.meta;
			v_valorreal := v_inversion.valorreal ;
            v_calificacion := 0;
            --valores del cierre por cliente
            v_valorinicialAprobado := v_inversion.valorinicialAprobado;
            v_valorinicialRechazado := v_inversion.valorinicialRechazado;
            v_metaAprobado := v_inversion.metaAprobado;
            v_metaRechazado := v_inversion.MetaRechazado;
            v_valorrealAprobado:= v_inversion.valorrealAprobado;
            v_ValorRealRechazado := v_inversion.ValorRealRechazado;
			--Dependiendo del tipo de kpi y la etapa se deben llenar los valores
			if (v_inversion.descripcion = 'VENTA SELL IN') then 
				if v_inversion.idetapa in (1, 5) then  --etapa de negociacion
					v_valor := data.PK_ICOM_FORMULAS.F_VENTAUSDSITUACION (P_ID => v_inversion.id );
					v_meta := data.PK_ICOM_FORMULAS.F_VentaUsdMeta (P_ID => v_inversion.id );
				elsif v_inversion.idetapa = 4 then --etapa de cierre
					v_valorreal := data.PK_ICOM_FORMULAS.F_TOTALREAL ( P_ID => v_inversion.id );
                    v_valorinicialAprobado :=  data.PK_ICOM_FORMULAS.F_ventaUsdSituacionCliente (P_ID => v_inversion.id,  
                                                                                                 P_TIPO => 1 );
                    v_valorinicialRechazado := data.PK_ICOM_FORMULAS.F_ventaUsdSituacionCliente (P_ID => v_inversion.id,  
                                                                                                 P_TIPO => 0 );
                    v_metaAprobado := data.PK_ICOM_FORMULAS. F_VentaUsdMetaCliente (P_ID => v_inversion.id,  
                                                                                                 P_TIPO => 1 ) ;
                    v_metaRechazado := data.PK_ICOM_FORMULAS. F_VentaUsdMetaCliente (P_ID => v_inversion.id,  
                                                                                                 P_TIPO => 0 ) ;
                    v_valorrealAprobado:= data.PK_ICOM_FORMULAS. F_TotalRealCliente (P_ID => v_inversion.id,  
                                                                                                 P_TIPO => 1 ) ;
                    v_ValorRealRechazado := data.PK_ICOM_FORMULAS. F_TotalRealCliente (P_ID => v_inversion.id,  
                                                                                                 P_TIPO => 0 ) ;
				end if;
			elsif (v_inversion.descripcion = 'VENTA SELL OUT') then 
				if v_inversion.idetapa in (1, 5)then  --etapa de negociacion
					v_valor := data.PK_ICOM_FORMULAS.F_VENTAUSDSITUACIONSELLOUT (P_ID => v_inversion.id );
					v_meta := data.PK_ICOM_FORMULAS.F_VentaUsdMetaSellOut (P_ID => v_inversion.id,  P_DURACION => v_inversion.duracion );
				elsif v_inversion.idetapa = 4 then --etapa de cierre
					/*SELECT SUM(SELLOUTREAL) INTO  v_valorreal FROM T_ICOM_INVERSION_CLIENTE_G
                     WHERE  IDINVERSION=v_inversion.id ;*/
                    v_valorreal :=  data.PK_ICOM_FORMULAS.F_totalRealSellOutCliente (P_ID => v_inversion.id,
                                                                                                  P_TIPO => 2 );
                    v_valorinicialAprobado := data.PK_ICOM_FORMULAS.F_ventaUsdSit_SelloutCliente (P_ID => v_inversion.id,
                                                                                                  P_TIPO => 1 );
                    v_valorinicialRechazado := data.PK_ICOM_FORMULAS.F_ventaUsdSit_SelloutCliente (P_ID => v_inversion.id,
                                                                                                  P_TIPO => 0 );
                    v_metaAprobado := data.PK_ICOM_FORMULAS.F_VentaUsdMetaSellOutCliente (P_ID => v_inversion.id,
                                                                                                  P_TIPO => 1 );
                    v_metaRechazado :=  data.PK_ICOM_FORMULAS.F_VentaUsdMetaSellOutCliente (P_ID => v_inversion.id,
                                                                                                  P_TIPO => 0 );
                    v_valorrealAprobado:= data.PK_ICOM_FORMULAS.F_totalRealSellOutCliente (P_ID => v_inversion.id,
                                                                                                  P_TIPO => 1 );
                    v_ValorRealRechazado := data.PK_ICOM_FORMULAS.F_totalRealSellOutCliente (P_ID => v_inversion.id,
                                                                                                  P_TIPO => 0 );
				end if;
			elsif (v_inversion.descripcion = 'MARGEN') then 
				if v_inversion.idetapa in (1, 5) then  --etapa de negociacion

					    --v_valor := data.PK_ICOM_FORMULAS.F_VAL_TOTALMARGENSITUACION ( v_inversion.sellin, v_inversion.duracion, v_inversion.sellincosto);
						v_valor := data.PK_ICOM_FORMULAS.F_MargenBrutoSituacion (v_inversion.id);
                       --v_meta := data.PK_ICOM_FORMULAS.F_VAL_TOTALMARGENMETA ( v_inversion.id, v_inversion.sellincrecimiento, v_inversion.sellin, v_inversion.duracion, v_inversion.sellincosto);
                     v_meta := data.PK_ICOM_FORMULAS.F_MargenDespuesGastoMeta ( v_inversion.id);    

                elsif v_inversion.idetapa = 4 then --etapa de cierre
					v_valorreal := data.PK_ICOM_FORMULAS.F_VAL_TOTALMARGENREAL ( v_inversion.id, v_inversion.sellinreal, v_inversion.sellincostoreal );
                    
                    v_valorinicialAprobado := data.PK_ICOM_FORMULAS.F_val_totalMargenSit_Cliente ( P_ID => v_inversion.id, 
                                                                                                   P_TIPO => 1, 
                                                                                                   P_DURACION => v_inversion.duracion ) ;
                    v_valorinicialRechazado := data.PK_ICOM_FORMULAS.F_val_totalMargenSit_Cliente ( P_ID => v_inversion.id, 
                                                                                                   P_TIPO => 0, 
                                                                                                   P_DURACION => v_inversion.duracion ) ;
                    v_metaAprobado := data.PK_ICOM_FORMULAS.F_val_totalMargenMetaCliente ( P_ID => v_inversion.id, 
                                                                                                   P_TIPO => 1, 
                                                                                                   P_DURACION => v_inversion.duracion )  ;
                    v_metaRechazado := data.PK_ICOM_FORMULAS.F_val_totalMargenMetaCliente ( P_ID => v_inversion.id, 
                                                                                                   P_TIPO => 0, 
                                                                                                   P_DURACION => v_inversion.duracion ) ;
                    v_valorrealAprobado:= data.PK_ICOM_FORMULAS.F_val_totalMargenRealCliente ( P_ID => v_inversion.id, 
                                                                                                   P_TIPO => 1, 
                                                                                                   P_DURACION => v_inversion.duracion )  ;
                    v_ValorRealRechazado := data.PK_ICOM_FORMULAS.F_val_totalMargenRealCliente ( P_ID => v_inversion.id, 
                                                                                                   P_TIPO => 0, 
                                                                                                   P_DURACION => v_inversion.duracion )  ;
                    
				end if;
			elsif (v_inversion.descripcion = 'GASTO') then 
				if v_inversion.idetapa in (1, 5) then  --etapa de negociacion
					v_valor := 0;
					--F_GastoInversionMeta(ID)v_meta := data.PK_ICOM_FORMULAS.F_VAL_TOTALMARGENMETA ( v_inversion.id, v_inversion.sellincrecimiento, v_inversion.sellin, v_inversion.duracion, v_inversion.sellincosto);
                    v_meta := data.PK_ICOM_FORMULAS.F_GastoInversionMeta(v_inversion.id);
				elsif v_inversion.idetapa = 4 then --etapa de cierre
					v_valorreal := data.PK_ICOM_FORMULAS.F_VAL_TOTALMARGENREAL ( v_inversion.id, v_inversion.sellinreal, v_inversion.sellincostoreal );
                    v_valorinicialAprobado := 0 ;
                    v_valorinicialRechazado := 0 ;
                    v_metaAprobado := data.PK_ICOM_FORMULAS.F_GastoInversionMetaCliente ( P_ID => v_inversion.id, 
                                                                                        P_TIPO => 1)  ;
                    v_metaRechazado := data.PK_ICOM_FORMULAS.F_GastoInversionMetaCliente ( P_ID => v_inversion.id, 
                                                                                        P_TIPO => 0)  ;
                    v_valorrealAprobado:= data.PK_ICOM_FORMULAS.F_val_totalMargenRealCliente ( P_ID => v_inversion.id, 
                                                                                                   P_TIPO => 1, 
                                                                                                   P_DURACION => v_inversion.duracion )  ;
                    v_ValorRealRechazado := data.PK_ICOM_FORMULAS.F_val_totalMargenRealCliente ( P_ID => v_inversion.id, 
                                                                                                   P_TIPO => 0, 
                                                                                                   P_DURACION => v_inversion.duracion )  ;
                    
				end if;			
			end if;
			--actualizo el valor
			update data.t_icom_inversion_kpi
			set valorinicial = v_valor,
				meta = v_meta ,
				valorreal = v_valorreal,
                calificacion = data.pk_icom_cierre.SP_KPICALIFICACION 
                                 (P_IDINVERSION => v_inversion.id, 
                                  P_KPIS => v_inversion.idkpi, 
                                  P_VALORINICIAL => v_valor, 
                                  P_META => v_meta, 
                                  P_VALORREAL => v_valorreal,
                                  P_PONDERACION => v_inversion.ponderacion/100),
                valorinicialAprobado = v_valorinicialAprobado,
                valorinicialRechazado = v_valorinicialRechazado,
                metaAprobado = v_metaAprobado,
                MetaRechazado = v_MetaRechazado,
                valorrealAprobado = v_valorrealAprobado,
                ValorRealRechazado = v_ValorRealRechazado,
                calificacionAprobado = data.pk_icom_cierre.SP_KPICALIFICACION 
                                 (P_IDINVERSION => v_inversion.id, 
                                  P_KPIS => v_inversion.idkpi, 
                                  P_VALORINICIAL => v_valorinicialAprobado, 
                                  P_META => v_metaAprobado, 
                                  P_VALORREAL => v_valorrealAprobado,
                                  P_PONDERACION => v_inversion.ponderacion/100),
                calificacionRechazado = data.pk_icom_cierre.SP_KPICALIFICACION 
                                 (P_IDINVERSION => v_inversion.id, 
                                  P_KPIS => v_inversion.idkpi, 
                                  P_VALORINICIAL => v_valorinicialRechazado, 
                                  P_META => v_MetaRechazado, 
                                  P_VALORREAL => v_ValorRealRechazado,
                                  P_PONDERACION => v_inversion.ponderacion/100)
			where idinversion = v_inversion.id and idkpi = v_inversion.idkpi ;

		end loop ;

	END ;

    /*
	Funcion que calcula el valor de la calificacion
	Por: JAsanza
	Fecha: Diciembre 2022
	*/
        FUNCTION SP_KPICALIFICACION (P_IDINVERSION NUMBER, P_KPIS NUMBER, P_VALORINICIAL NUMBER, P_META NUMBER, P_VALORREAL NUMBER, P_PONDERACION NUMBER) RETURN NUMBER AS 
    v_factor number ;
    BEGIN
        --busco la ponderacion        
        select  nvl(pk_commons.safe_to_number(PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '8', COMPANIA )),0)/100 
        into  v_factor from data.t_icom_inversiones where id = P_IDINVERSION and rownum=1;
        
        if ( nvl(p_meta,0) > 0 ) then
            if nvl(p_valorreal,0) > nvl(p_meta,0)  then
                return p_ponderacion * 100 ;
            elsif (nvl(p_valorreal,0)/nvl(p_meta,1))<= v_factor  then
                return 0;
            else
                return ((((nvl(p_valorreal,0)/nvl(p_meta,1))-v_factor)*2)*p_ponderacion*100) ;
            end if;
        elsif ( nvl(p_meta,0) < 0 ) then
            
            if nvl(p_valorreal,0) >= nvl(p_meta,0)  then
                return p_ponderacion * 100 ;
            elsif (nvl(p_valorreal,0)/nvl(p_meta,1))>= (1+v_factor)  then
                return 0;
            else
                return ((((nvl(p_valorreal,0)/nvl(p_meta,1))-(1+v_factor))*(-2))*p_ponderacion*100) ;
            end if;
        else
            
            if nvl(p_valorreal,0) <= nvl(p_meta,0)  then
                return p_ponderacion*100 ;
            elsif (( nvl(p_valorinicial,0)- nvl(p_valorreal,0) )/case when nvl(p_valorinicial,0) = 0 then 1 else p_valorinicial end )<= v_factor  then
                return 0;
            else
                return ((( nvl(p_valorinicial,0)- nvl(p_valorreal,0) )/case when nvl(p_valorinicial,0) = 0 then 1 else p_valorinicial end)-v_factor )*2*p_ponderacion*100 ;
            end if;
        end if;
	END;

    /*Procedimiento que actualiza el valor real y el valor de la calificacion del KPI
    Por: JAsanza
	*/
    PROCEDURE SP_ACTUALIZAKPI (P_IDINVERSION NUMBER, P_KPIS NUMBER, P_VALORINICIAL NUMBER, P_META NUMBER, P_VALORREAL NUMBER, 
                               P_PONDERACION NUMBER, P_TIPO NUMBER DEFAULT 0) AS
    BEGIN
        --actualizo el valor
        if p_tipo = 0 then -- Propuesta
            update data.t_icom_inversion_kpi
            set valorinicial = P_VALORINICIAL,
                meta = P_META ,
                valorreal = P_VALORREAL,
                calificacion = data.pk_icom_cierre.SP_KPICALIFICACION 
                                 (P_IDINVERSION => P_IDINVERSION, 
                                  P_KPIS => P_KPIS, 
                                  P_VALORINICIAL => P_VALORINICIAL, 
                                  P_META => P_META, 
                                  P_VALORREAL => P_VALORREAL,
                                      P_PONDERACION => p_ponderacion)
            where idinversion = P_IDINVERSION and idkpi = P_KPIS ;
        elsif p_tipo = 1 then -- Cierr, clientes aprobados
            update data.t_icom_inversion_kpi
            set valorinicialaprobado = P_VALORINICIAL,
                metaaprobado = P_META ,
                valorrealaprobado = P_VALORREAL,
                calificacionaprobado = data.pk_icom_cierre.SP_KPICALIFICACION 
                                 (P_IDINVERSION => P_IDINVERSION, 
                                  P_KPIS => P_KPIS, 
                                  P_VALORINICIAL => P_VALORINICIAL, 
                                  P_META => P_META, 
                                  P_VALORREAL => P_VALORREAL,
                                  P_PONDERACION => p_ponderacion)
            where idinversion = P_IDINVERSION and idkpi = P_KPIS ;    
        elsif p_tipo = 2 then -- Cierre, clientes rechazados
            update data.t_icom_inversion_kpi
            set valorinicialrechazado = P_VALORINICIAL,
                metarechazado = P_META ,
                valorrealrechazado = P_VALORREAL,
                calificacionrechazado = data.pk_icom_cierre.SP_KPICALIFICACION 
                                 (P_IDINVERSION => P_IDINVERSION, 
                                  P_KPIS => P_KPIS, 
                                  P_VALORINICIAL => P_VALORINICIAL, 
                                  P_META => P_META, 
                                  P_VALORREAL => P_VALORREAL,
                                      P_PONDERACION => p_ponderacion)
            where idinversion = P_IDINVERSION and idkpi = P_KPIS ;    
        end if;    
    END;

    /*Procedimiento inserta si no existe los tipos de ejecuciÃ‚Â¿n para las inversiones
    Por: JAsanza
	Fecha: Diciembre 2022
	*/
    PROCEDURE SP_ACTUALIZAINVERSIONEJECUCION (P_ID NUMBER) AS
    BEGIN
        merge into data.t_icom_inversionejecucion inv 
            using ( select i.id idinversion, e.id, e.descripcion 
                    from data.t_icom_inversiones i, data.VT_ICOM_EJECUCION e
                    where (i.id = p_id or i.idgrupo = p_id AND I.ESTADO=1) and e.estado = 1 ) dat
            on (inv.idinversion = dat.idinversion and inv.idejecucion = dat.id )
            WHEN MATCHED THEN
                UPDATE SET inv.DESCRIPCION = dat.descripcion
            when not matched then insert (idinversion, idejecucion, descripcion, cumplimiento) 
                values(dat.idinversion, dat.id, dat.descripcion, null) ;
    END;

    /*Procedimiento inserta si no existe las lecciones de la tabla general para las inversiones
    Por: JAsanza
	Fecha: Diciembre 2022
	*/
    PROCEDURE SP_ACTUALIZAINVERSIONLECCION (P_ID NUMBER) AS
    BEGIN
        merge into data.t_icom_inversionleccion inv 
            using ( select i.id idinversion, e.id, e.descripcion 
                    from data.t_icom_inversiones i, data.vt_icom_leccionaprendida e
                    where (i.id = p_id or i.idgrupo = p_id) and e.estado = 1 ) dat
            on (inv.idinversion = dat.idinversion and inv.idleccion = dat.id )
            when not matched then insert (idinversion, idleccion, descripcion, respuesta) 
                values(dat.idinversion, dat.id, dat.descripcion, null) ;
    END;

    /*Procedimiento que actualiza la venta real
    Por: JAsanza
	Fecha: Diciembre 2022
	*/
    PROCEDURE SP_ActualizarVentaReal (P_ID NUMBER, P_PERIODO VARCHAR2) AS
    BEGIN
        update data.t_icom_inversiones
        set sellinreal = data.PK_ICOM_FORMULAS.F_VentaReal 
                        ( P_ID => id, 
                          P_PERIODO => NVL(P_PERIODO,'N'), 
                          P_FECHAINICIO => fechainicio, 
                          P_MESES => situacionactualmes )
        where id = p_id or idgrupo = p_id ;
    END;

    /*Procedimiento que elimina el gasto validaciÃ‚Â¿n
    Por: JAsanza
	Fecha: Junio 2023
	*/
    PROCEDURE SP_eliminaGastoValidacion (P_ID NUMBER ) AS
    BEGIN
        delete from DATA.T_ICOM_INVERSION_GASTO
        where idinversion = P_ID     and gastotipo = 'GASTO'   and tipo = 'CIERRE' ;
        
    END SP_eliminaGastoValidacion;
    
    /*Procedimiento que actualiza a la inversion en el cierre que tipo de vista tiene para los pedidos*/
    PROCEDURE SP_ActualInv_VistaPedido (P_ID NUMBER, P_VISTA VARCHAR2 ) AS
    BEGIN
        update data.t_icom_inversiones 
        set VISTAPEDIDO = p_vista 
        where id = P_ID   ;
        
    END SP_ActualInv_VistaPedido ;
    
    
    PROCEDURE SP_DISTRIBUCION_GASTOS(P_IDINVERSION NUMBER,P_TIPO NUMBER,P_COMPANIA varchar2,
    P_DOCUMENTOTIPO VARCHAR2 DEFAULT NULL,P_DOCUMENTO VARCHAR2 DEFAULT NULL,P_DESCRIPCION VARCHAR2 DEFAULT NULL,P_OBSERVACION VARCHAR2 DEFAULT NULL,
    P_GAPLICACION NUMBER DEFAULT NULL,P_GUNITARIO NUMBER DEFAULT NULL,P_GCALCULO NUMBER DEFAULT NULL,P_GELIMINA NUMBER DEFAULT 1,
    P_GTODOSCLIENTES NUMBER DEFAULT 1,P_IDGASTO NUMBER DEFAULT NULL) AS 
        V_ID NUMBER:=P_IDINVERSION;
        V_TIPO NUMBER:=P_TIPO;
        V_COMPANIA VARCHAR2(5):=trim(P_COMPANIA);
        V_APLICACION	    NUMBER:=0;
        V_UNITARIO			NUMBER:=0;
        V_TABLAID           VARCHAR2(200);
        V_TABLADESCRIPCION  VARCHAR2(3999);
        v_cont number;
        V_TABLASECUENCIA VARCHAR2(499);
        V_APPLOG VARCHAR2(499);
        V_SEELIMINA number;
        V_MESSAGE varchar2(3999);
        V_IDGASTO NUMBER;
    BEGIN
        V_IDGASTO :=P_IDGASTO ;
        V_TABLASECUENCIA :='DATA.T_ICOM_INVERSION_GASTODISTRIBUCION';
        V_APPLOG:='APEX.T_ICOM_INVERSION_GASTODISTRIBUCION';
        v_message:='1035::';
        v_message:=v_message||'{P_IDINVERSION:'||P_IDINVERSION||',P_TIPO:'||P_TIPO||',P_COMPANIA:'||P_COMPANIA||',P_DOCUMENTOTIPO:'||P_DOCUMENTOTIPO;
        v_message:=v_message||',P_DOCUMENTO:'||P_DOCUMENTO||',P_DESCRIPCION:'||P_DESCRIPCION||',P_OBSERVACION:'||P_OBSERVACION||',P_GAPLICACION:'||P_GAPLICACION||',P_GUNITARIO:'||P_GUNITARIO;
        v_message:=v_message||',P_GCALCULO:'||P_GCALCULO||',P_GELIMINA:'||P_GELIMINA||',P_GTODOSCLIENTES:'||P_GTODOSCLIENTES||',V_IDGASTO :'||V_IDGASTO ||'}';

        --DBMS_OUTPUT.PUT_LINE('v_message:'||v_message);
        --conocer el tipo de gasto meta,punto de equilibrio/real
        V_TIPO:= 
            CASE 
                 WHEN P_TIPO IN (4) THEN 3 --CIERRE
            END;
        
        V_TABLAID:= 
            CASE P_TIPO 
                WHEN 2 THEN 'T_CIERRE_F4211'
                WHEN 3 THEN 'T_CIERRE_F4311'
            END;
        V_SEELIMINA :=
            CASE P_TIPO 
                WHEN 2 THEN 1
                WHEN 3 THEN 1
            END;

        V_TABLADESCRIPCION:= 
            CASE P_TIPO 
                WHEN 2 THEN 'GASTO FIJO'
                WHEN 3 THEN 'GASTO FIJO'
            END;
        IF (P_GELIMINA=1)THEN
            DELETE T_ICOM_INVERSION_GASTO g where exists (SELECT 1 FROM T_ICOM_INVERSION_GASTODISTRIBUCION d WHERE (G.IDINVERSION=V_ID ) AND (G.IDINVERSION=D.IDINVERSION) AND G.IDGASTO=D.IDGASTO AND TABLAID=V_TABLAID AND COMPANIA=V_COMPANIA AND (IDGASTO=V_IDGASTO  OR V_IDGASTO  IS NULL)  );COMMIT;
            DELETE FROM T_ICOM_INVERSION_GASTODISTRIBUCION  WHERE (IDINVERSION=V_ID ) AND TABLAID=V_TABLAID AND COMPANIA=V_COMPANIA AND (IDGASTO=V_IDGASTO  OR V_IDGASTO  IS NULL);COMMIT;
        END IF;

        if (P_TIPO IN (2,3)) then/*GASTOS FIJOS - GASTO REAL*/
            if (V_IDGASTO is null) then
                V_IDGASTO:=PK_COMMONS.F_SECUENCIA ('DATA.T_ICOM_INVERSION_GASTO');
            end if;
--            insert into T_ICOM_INVERSION_GASTO
--                     (   IDINVERSION,GASTOTIPO,  TIPO,PERIODO,FUENTE,VALOR,  OBSERVACION,VALORPEQ,  VALORMETA,VALORREAL, CALCULADO, CALCULO, VALORPORCENTAJE,   IDGASTO )
--               VALUES( P_IDINVERSION,  'GASTO','FIJO',   NULL,  NULL, NULL,         null,       0,         30,       20,        10,    null,             100, V_IDGASTO );
----               VALUES( IDINVERSION,  'GASTO','FIJO',   NULL, NULL,  NULL,P_OBSERVACION,        0,       0,P_GUNITARIO,         0,V_IDGASTO );
            PK_ICOM_CIERRE.SP_GASTOS_MATERIA_SERVICIO(
                P_ID =>PK_COMMONS.F_SECUENCIA (V_TABLASECUENCIA),
                P_IDINVERSION =>P_IDINVERSION,
                P_TIPO =>3,
                P_GRUPO =>NULL,
                P_CLIENTE =>NULL,
                P_CODIGOPRODUCTO =>NULL,
                P_GASTO =>P_GAPLICACION,
                P_COMPANIA =>V_COMPANIA,
                P_TABLAID =>V_TABLAID,
                P_TABLADESCRIPCION =>V_TABLADESCRIPCION,
                P_DOCUMENTOTIPO =>P_DOCUMENTOTIPO,
                P_DOCUMENTO =>P_DOCUMENTO,
                P_DESCRIPCION=>P_DESCRIPCION ,
                P_SEELIMINA=>V_SEELIMINA ,
                P_OBSERVACION=>P_OBSERVACION,
                P_IDGASTO=>V_IDGASTO                
            );
        end if;
 
        
     END SP_DISTRIBUCION_GASTOS;
    
    PROCEDURE SP_GASTOS_MATERIA_SERVICIO(
                 P_ID NUMBER,P_IDINVERSION NUMBER,P_TIPO NUMBER,P_GRUPO NUMBER DEFAULT NULL,P_CLIENTE NUMBER DEFAULT NULL,P_CODIGOPRODUCTO varchar2 DEFAULT NULL
                ,P_GASTO NUMBER,P_COMPANIA varchar2,P_TABLAID VARCHAR2,P_TABLADESCRIPCION VARCHAR2
                ,P_DOCUMENTOTIPO VARCHAR2,P_DOCUMENTO VARCHAR2,P_DESCRIPCION VARCHAR2 DEFAULT NULL,P_SEELIMINA NUMBER DEFAULT 0
                ,P_OBSERVACION VARCHAR2 DEFAULT NULL
                ,P_IDGASTO NUMBER DEFAULT NULL) AS
    v_cont NUMBER;
     V_MESSAGE varchar2(3999);
    BEGIN
        V_MESSAGE:='1184>>';
        V_MESSAGE:=V_MESSAGE||'P_ID :'||P_ID||',P_IDINVERSION :'||P_IDINVERSION||',P_TIPO :'||P_TIPO||',P_GRUPO :'||P_GRUPO||',P_CLIENTE :'||P_CLIENTE;
        V_MESSAGE:=V_MESSAGE||' ,P_GASTO :'||P_GASTO||',P_COMPANIA :'''||P_COMPANIA||''',P_TABLAID :'''||P_TABLAID||''',P_TABLADESCRIPCION :'''||P_TABLADESCRIPCION||'''';
        V_MESSAGE:=V_MESSAGE||' ,P_DOCUMENTOTIPO :'''||P_DOCUMENTOTIPO||''',P_DOCUMENTO :'''||P_DOCUMENTO||''',P_DESCRIPCION :'''||P_DESCRIPCION||''''||''',P_ESELIMNIAR :'''||P_SEELIMINA||'''';
        V_MESSAGE:=V_MESSAGE||' ,P_IDGASTO:'||P_IDGASTO;
        
        --DBMS_OUTPUT.PUT_LINE('parametros >>P_ID :'||P_ID||',P_IDINVERSION :'||P_IDINVERSION||',P_TIPO :'||P_TIPO||',P_GRUPO :'||P_GRUPO||',P_CLIENTE :'||P_CLIENTE||' ,P_GASTO :'||P_GASTO||',P_COMPANIA :'''||P_COMPANIA||''',P_TABLAID :'''||P_TABLAID||''',P_TABLADESCRIPCION :'''||P_TABLADESCRIPCION||''',P_DOCUMENTOTIPO :'''||P_DOCUMENTOTIPO||''',P_DOCUMENTO :'''||P_DOCUMENTO||''',P_DESCRIPCION :'''||P_DESCRIPCION||''''||''',P_SEELIMINA:'''||P_SEELIMINA||'''');
        insert into T_ICOM_INVERSION_GASTODISTRIBUCION( ID,IDINVERSION,  TIPO,CODIGOGRUPO,CODIGOCLIENTE,CODIGOPRODUCTO,CODIGOBARRA,DESCRIPCION,  COMPANIA,VALORINICIAL,VALORDISTRIBUCION ,PESODISTRIBUCION,VALOR,  TABLAID,  TABLADESCRIPCION,DOCUMENTOTIPO,DOCUMENTO,  FECHA,  OBSERVACION, ESELIMINAR,IDGASTO)
            SELECT 
                P_ID ID,
                p_IDINVERSION,
                P_TIPO TIPO,
                P_GRUPO CODIGOGRUPO,
                P_CLIENTE CODIGOCLIENTE, 
                P_CODIGOPRODUCTO CODIGOPRODUCTO,
                NULL CODIGOBARRA,
                P_DESCRIPCION DESCRIPCION,
                P_COMPANIA COMPANIA,
                1 VALORINICIAL,
                P_GASTO VALORDISTRIBUCION ,
                NVL(ROUND(1 /NULLIF(SUM(1) OVER (), 0),  15),0) *100 PESODISTRIBUCION,
                P_GASTO *  NVL(ROUND(1 /NULLIF(SUM(1) OVER (), 0),  15),0) VALOR,
                P_TABLAID TABLAID,
                P_TABLADESCRIPCION TABLADESCRIPCION,
                case P_TIPO 
                    when 3 then P_DOCUMENTOTIPO
                    else null
                end DOCUMENTOTIPO,
                case P_TIPO 
                    when 3 then P_DOCUMENTO
                    else null
                end  DOCUMENTO,
                SYSDATE FECHA,
                P_OBSERVACION OBSERVACION,
                P_SEELIMINA,
                P_IDGASTO
            FROM 
                dual;
        v_cont:=SQL%ROWCOUNT;    --DBMS_OUTPUT.PUT_LINE('*****************************************************************Registros afectados:'||v_cont||'*****************************************************************');
            commit;
    END SP_GASTOS_MATERIA_SERVICIO;

    
    /*
    
    PK_ICOM_CIERRE.SP_DISTRIBUCIONNOTASDECREDITOAPROBADAS();
    */
    PROCEDURE SP_DISTRIBUCIONNOTASDECREDITOAPROBADAS (P_IDINVERSION NUMBER default null) AS 
        V_IDGASTO NUMBER;
        V_TABLASECUENCIA VARCHAR2(499);
        V_IDDETALLEGASTO NUMBER;
    BEGIN
         V_TABLASECUENCIA :='DATA.T_ICOM_INVERSION_GASTODISTRIBUCION';
         ---AGREGAR FECHA DE ACTIVIDAD
        
         ---
         
        /*recupera los datos de todas las faturas existentes */
        FOR GASTOS IN(
           SELECT D.IDINVERSION,
                'GASTO' GASTOTIPO,'AUTOMATICO' TIPO,'NOTAS DE CREDITO' FUENTE,'NOTAS DE CREDITO POR VALIDACION'OBSERVACION,
                SUM(D.VALOR) VALORREAL, I.COMPANIA
            FROM T_ICOM_CLIENTE_VALIDACION_NC C
            INNER JOIN T_ICOM_CLIENTE_VALIDACION_NCDET D ON C.ID=D.IDCLIENTEVALIDANC
            INNER join t_icom_inversiones i on d.IDINVERSION=i.id 
            WHERE  ((idetapa in (2,3,4,7) and i.estado= 1 and P_IDINVERSION is null) or i.id=P_IDINVERSION)
            and DOCUMENTONUMERO IS NOT NULL
            GROUP BY D.IDINVERSION, I.COMPANIA
        )
        LOOP 
            --DBMS_OUTPUT.PUT_LINE('DISTRIBUCION GASTO NC IDINVERSION:'||GASTOS.IDINVERSION);
        
            /*se revisa que no exista un gasto ingresado para las faturas ingresadas, se revisa por IDINVERSION,GASTOTIPO,TIPO,FUENTE*/
            BEGIN        
                SELECT IDGASTO INTO V_IDGASTO FROM T_ICOM_INVERSION_GASTO WHERE IDINVERSION=GASTOS.IDINVERSION 
                AND GASTOTIPO= GASTOS.GASTOTIPO AND TIPO=GASTOS.TIPO AND FUENTE= GASTOS.FUENTE AND ROWNUM=1;
            EXCEPTION WHEN OTHERS THEN 
                V_IDGASTO :=NULL;             
            END;
            /*si no existe un gasto ingresado anteriormente se le inserta en la tabla T_ICOM_INVERSION_GASTO caso contrario se le actualiza el valor de numero de faturas y el valor a ser distrinuido.*/
            IF (V_IDGASTO IS NULL)THEN
                V_IDGASTO:=PK_COMMONS.F_SECUENCIA ('DATA.T_ICOM_INVERSION_GASTO');
                INSERT INTO T_ICOM_INVERSION_GASTO (        IDINVERSION,       GASTOTIPO,        TIPO,      
                PERIODO,        FUENTE,        VALOR,        OBSERVACION,        VALORMETA,        VALORPEQ,       VALORREAL,        CALCULADO,   IDGASTO)
                VALUES ( GASTOS.IDINVERSION,GASTOS.GASTOTIPO, GASTOS.TIPO, 
                NULL, GASTOS.FUENTE, 0, GASTOS.OBSERVACION, 0,
                0,GASTOS.VALORREAL, 0, V_IDGASTO);
            ELSE
                UPDATE T_ICOM_INVERSION_GASTO CLI
                 SET
                    CLI.OBSERVACION=GASTOS.OBSERVACION,
                    CLI.VALORREAL=GASTOS.VALORREAL
                    WHERE CLI.IDGASTO=V_IDGASTO;
            END IF;
            
            /*se elimina el detalle de la distribucion para volver a ingresarlo*/
            IF (V_IDGASTO IS NOT NULL)THEN
                DELETE FROM T_ICOM_INVERSION_GASTODISTRIBUCION WHERE IDGASTO=V_IDGASTO;
            END IF;
    
            /*se ingresa los registros */
            V_IDDETALLEGASTO:=PK_COMMONS.F_SECUENCIA (V_TABLASECUENCIA);
    
            INSERT INTO T_ICOM_INVERSION_GASTODISTRIBUCION( ID,             IDINVERSION,    TIPO,               CODIGOGRUPO,        CODIGOCLIENTE,  CODIGOPRODUCTO, CODIGOBARRA,        DESCRIPCION,
                                                            COMPANIA,       VALORINICIAL,   VALORDISTRIBUCION,  PESODISTRIBUCION,   VALOR,          TABLAID,        TABLADESCRIPCION,
                                                            DOCUMENTOTIPO,  DOCUMENTO,      FECHA,              OBSERVACION,        ESELIMINAR,     IDGASTO, FECHA_ACTIVIDAD, FECHA_ACTIVIDAD_FIN)
               WITH DETALLE AS (    
                    SELECT
                        V_IDDETALLEGASTO ID,
                        D.IDINVERSION IDINVERSION,
                        3 TIPO,
                        C.CODIGOGRUPO CODIGOGRUPO,C.CODIGOCLIENTE CODIGOCLIENTE,
                        D.CODIGOPRODUCTO CODIGOPRODUCTO,
                        NULL CODIGOBARRA,
                        'Notas de credito automaticas' DESCRIPCION,
                        GASTOS.COMPANIA COMPANIA,
                        SUM(C.VALOR) VALORINICIAL,
                        C.VALOR  VALORDISTRIBUCION,
                        (SUM(D.VALOR)/C.VALOR) *100 PESODISTRIBUCION,
                        SUM(D.VALOR) VALOR,
                        'T_ICOM_CLIENTE_VALIDACION_NC' TABLAID,
                        'GASTO EN CIERRE NOTAS DE CREDITO' TABLADESCRIPCION,
                        C.DOCUMENTOTIPO DOCUMENTOTIPO,
                        C.DOCUMENTONUMERO DOCUMENTO,
                        TRUNC(SYSDATE) FECHA, 
                        'NOTAS DE CREDITO => IDAGRUPACION:'||LPAD(C.IDAGRUPACION,6,' ')||' Lote:'||LPAD(C.LOTENC,6,' ')||' #NotaCredito:'|| LPAD(C.NUMERO_NCS,6,' ') OBSERVACION, 
                        0 ESELIMINAR,
                        V_IDGASTO IDGASTO ,
                        C.NUMERO_NCS,
                        (SELECT MIN(VAL.VAL_FECHAINICIO) 
                        FROM DATA.T_ICOM_CLIENTE_VALIDACION VAL WHERE VAL.IDAGRUPACION=C.IDAGRUPACION
                        ) FECHA_ACTIVIDAD,
                        (SELECT MAX(VAL.VAL_FECHAFIN) 
                        FROM DATA.T_ICOM_CLIENTE_VALIDACION VAL WHERE VAL.IDAGRUPACION=C.IDAGRUPACION
                        ) FECHA_ACTIVIDAD_FIN
                    FROM DATA.T_ICOM_CLIENTE_VALIDACION_NC C
                    INNER JOIN DATA.T_ICOM_CLIENTE_VALIDACION_NCDET D ON C.ID=D.IDCLIENTEVALIDANC AND C.IDAGRUPACION=D.IDAGRUPACION
                    WHERE D.IDINVERSION= GASTOS.IDINVERSION  AND C.DOCUMENTONUMERO IS NOT NULL
                    GROUP BY C.IDAGRUPACION, D.IDINVERSION,C.CODIGOGRUPO,C.CODIGOCLIENTE,D.CODIGOPRODUCTO,C.VALOR,C.DOCUMENTOTIPO,C.DOCUMENTONUMERO,TRUNC(SYSDATE),
                             'NOTAS DE CREDITO => IDAGRUPACION:'||LPAD(C.IDAGRUPACION,6,' ')||' Lote:'||LPAD(C.LOTENC,6,' ')||' #NotaCredito:'|| LPAD(C.NUMERO_NCS,6,' '),C.NUMERO_NCS
                )
                SELECT  
                    ID,             IDINVERSION,    TIPO,               CODIGOGRUPO,        CODIGOCLIENTE,  CODIGOPRODUCTO, CODIGOBARRA,        DESCRIPCION,
                    COMPANIA,       VALORINICIAL,   VALORDISTRIBUCION,  PESODISTRIBUCION,   VALOR,          TABLAID,        TABLADESCRIPCION,
                    DOCUMENTOTIPO,  DOCUMENTO,      FECHA,              OBSERVACION,        ESELIMINAR,     IDGASTO, FECHA_ACTIVIDAD, FECHA_ACTIVIDAD_FIN
                FROM DETALLE
                 ORDER BY NUMERO_NCS,CODIGOPRODUCTO;
                 
            COMMIT;         
        END LOOP;
    END SP_DISTRIBUCIONNOTASDECREDITOAPROBADAS;   
    
-------------------------------------------------------------------------------
-- Procedimiento: SP_DISTRIBUCIONORENDESCOMPRARECIBIDAS
-- Objetivo:
--   Distribuir gastos de inversiones comerciales en dos frentes:
--     1) Ã‚Â¿rdenes de compra (POP / Servicios).
--     2) Negociaciones recurrentes (con OC de JDE).
-- Notas:
--   - Inserta/actualiza informaciÃ‚Â¿n en T_ICOM_INVERSION_GASTO.
--   - Borra e inserta detalles en T_ICOM_INVERSION_GASTODISTRIBUCION.
--   - Usa secuencias internas de PK_COMMONS para generar IDs.
-------------------------------------------------------------------------------
    PROCEDURE SP_DISTRIBUCIONORENDESCOMPRARECIBIDAS(P_REPROCESA_CERRADAS NUMBER DEFAULT 0, P_IDINVERSION NUMBER DEFAULT NULL) AS 
        V_IDGASTO         NUMBER;         -- Identificador del gasto (cabecera)    
        V_TABLASECUENCIA  VARCHAR2(499);  -- Tabla destino de la distribuciÃ‚Â¿n   
        V_IDDETALLEGASTO  NUMBER;         -- Identificador del detalle de gasto
    BEGIN
        V_TABLASECUENCIA :='DATA.T_ICOM_INVERSION_GASTODISTRIBUCION';
    
        ----------------------------------------------------------------------
        -- BLOQUE 1: DISTRIBUCIÃ‚Â¿N POR Ã‚Â¿RDENES DE COMPRA (POP / Servicios)
        ----------------------------------------------------------------------
        
        ---AGREGAR FECHA DE ACTIDAD
        
        FOR GASTOS IN(
            SELECT
                C.IDINVERSION,
                'GASTO' GASTOTIPO,
                'AUTOMATICO' TIPO,
                NULL PERIODO,
                'ORDENES DE COMPRA' FUENTE,
                NULL VALOR,
                'ORDENES DE COMPRA MATERIAL POP / SERVICIOS' OBSERVACION,
                0 VALORPEQ,
                0 VALORMETA,
                --C.VALOR VALORREAL, -- monto consolidado
                SUM(ocd.pdaexp/100) VALORREAL,
                0 CALCULADO,
                NULL CALCULO,
                100 VALORPORCENTAJE,
                i.compania,
                I.IDINVERSIONTIPO
            FROM (
                -- ConsolidaciÃ‚Â¿n de valores por inversiÃ‚Â¿n
                SELECT IDINVERSION,
                       REQUISICION,
                       ORDENCOMPRATIPO
                       --,FECHA_ACTIVIDAD,
                       --FECHA_ACTIVIDAD_FIN
                FROM VT_ICOM_CLIENTE_MATERIAL_COMPRA
                WHERE GRUPO > 100 AND ESTADO=3
                  AND UPPER(TRIM(REQUISICIONTIPO)) = 'H2'
                  AND (P_IDINVERSION IS NULL OR IDINVERSION = P_IDINVERSION)
                GROUP BY IDINVERSION,REQUISICION,ORDENCOMPRATIPO--,FECHA_ACTIVIDAD,FECHA_ACTIVIDAD_FIN
            ) C
            INNER JOIN t_icom_inversiones i
                    ON C.IDINVERSION = i.id
                    AND idetapa IN (2,3,4,7)
                    AND (estado = 1 OR (NVL(P_REPROCESA_CERRADAS, 0) = 1 AND estado = 4))
                    AND (P_IDINVERSION IS NULL OR C.IDINVERSION = P_IDINVERSION)
            INNER JOIN f4311@jdedtadl ocd
                    ON ocd.PDOORN = c.REQUISICION
                   -- PDOCTO identifica el tipo de orden de la requisición JDE;
                   -- PDDCTO es el tipo documental de la OC y no debe ampliar el universo.
                   AND ocd.pdocto = 'H2'
                   AND ocd.pdlttr = 400
                   AND ocd.pdnxtr = 999
            GROUP BY C.IDINVERSION , i.compania, I.IDINVERSIONTIPO
        )
        LOOP
            --DBMS_OUTPUT.PUT_LINE('DISTRIBUCION GASTO OC IDINVERSION:'||GASTOS.IDINVERSION);

            -- Buscar si ya existe cabecera de gasto para la inversiÃ‚Â¿n
            BEGIN
                SELECT idgasto INTO V_IDGASTO
                FROM t_icom_inversion_gasto
                WHERE idinversion = GASTOS.idinversion
                  AND gastotipo  = GASTOS.gastotipo
                  AND tipo       = GASTOS.tipo
                  AND fuente     = GASTOS.fuente
                  AND ROWNUM=1;
            EXCEPTION WHEN OTHERS THEN
                V_IDGASTO := NULL; -- si no existe, se genera nuevo
            END;

            -- Insertar o actualizar cabecera
            IF V_IDGASTO IS NULL THEN
                V_IDGASTO := pk_commons.f_secuencia('DATA.T_ICOM_INVERSION_GASTO');
                INSERT INTO t_icom_inversion_gasto(
                    idinversion,gastotipo,tipo,periodo,fuente,valor,
                    observacion,valormeta,valorpeq,valorreal,calculado,idgasto
                ) VALUES (
                    GASTOS.idinversion,GASTOS.gastotipo,GASTOS.tipo,GASTOS.periodo,
                    GASTOS.fuente,GASTOS.valor,GASTOS.observacion,GASTOS.valormeta,
                    GASTOS.valorpeq,GASTOS.valorreal,GASTOS.calculado,V_IDGASTO
                );
            ELSE
                UPDATE t_icom_inversion_gasto cli
                   SET cli.observacion = GASTOS.observacion,
                       cli.valorreal   = GASTOS.valorreal
                 WHERE cli.idgasto = V_IDGASTO
                   AND idinversion = GASTOS.idinversion;
            END IF;

            -- Eliminar distribuciÃ‚Â¿n previa
            IF V_IDGASTO IS NOT NULL THEN
                DELETE FROM t_icom_inversion_gastodistribucion WHERE idgasto = V_IDGASTO;
            END IF;

            V_IDDETALLEGASTO := pk_commons.f_secuencia(V_TABLASECUENCIA);

            FOR DETALLES IN (
                SELECT V_IDDETALLEGASTO id, d.idinversion, 3 tipo, NULL codigogrupo, NULL codigocliente,
                       NULL codigoproducto,
                       NULL codigobarra,
                       'ORDENES DE COMPRA AUTOMATICAS' descripcion,
                       GASTOS.compania compania, SUM(NVL(ocd.pdaexp,0)/100) valorinicial,
                        SUM(ocd.pdaexp/100) valordistribucion,
                       0 pesodistribucion,
                       0 valor,
                       --SUM(ocd.pdaexp/100),--SUM(d.total),
                       'VT_ICOM_CLIENTE_MATERIAL_COMPRA' tablaid,
                       'GASTO EN CIERRE CLIENTE MATERIAL COMPRA' tabladescripcion,
                       d.ordencompratipo documentotipo,ocd.pddoco documento,TRUNC(SYSDATE) fecha,
                       'ORDENES DE COMPRA' observacion,0 eseliminar,V_IDGASTO idgasto,
                       d.fecha_actividad,
                       d.fecha_actividad_fin,
                       d.requisicion
                --FROM data.vt_icom_cliente_material_compra d
                FROM (
                    -- Base unica por requisicion para no duplicar el valor de la OC por cliente.
                    SELECT DISTINCT
                        vcmp.idinversion,
                        vcmp.ordencompratipo,
                        vcmp.requisicion,
                        vcmp.fecha_actividad,
                        vcmp.fecha_actividad_fin
                    FROM data.vt_icom_cliente_material_compra vcmp
                    WHERE vcmp.grupo > 100 AND vcmp.estado = 3
                      AND UPPER(TRIM(vcmp.requisiciontipo)) = 'H2'
                      AND (P_IDINVERSION IS NULL OR vcmp.idinversion = P_IDINVERSION)
                ) d
                INNER JOIN f4311@jdedtadl ocd
                        ON ocd.PDOORN = d.REQUISICION
                       -- Mantener exclusivamente las OCs originadas en requisiciones H2.
                       AND ocd.pdocto = 'H2'
                       AND ocd.pdlttr = 400
                       AND ocd.pdnxtr = 999
                WHERE
                    d.idinversion = GASTOS.idinversion
                GROUP BY d.idinversion,GASTOS.compania,
                         GASTOS.valor,d.ordencompratipo,ocd.pddoco,d.fecha_actividad,d.fecha_actividad_fin,d.requisicion
            )
            LOOP
                FOR DETALLES_DIST IN (
                    WITH clientes_validos AS (
                        SELECT DISTINCT vcmp.codigogrupo
                          FROM data.vt_icom_cliente_material_compra vcmp
                         WHERE vcmp.idinversion = DETALLES.idinversion
                           AND vcmp.requisicion = DETALLES.requisicion
                           AND vcmp.grupo > 100
                           AND vcmp.estado = 3
                           AND UPPER(TRIM(vcmp.requisiciontipo)) = 'H2'
                           AND vcmp.codigogrupo IS NOT NULL
                           AND EXISTS (
                               SELECT 1
                                 FROM data.t_icom_inversion_cliente_g cg
                                WHERE cg.idinversion = vcmp.idinversion
                                  AND cg.codigogrupo = vcmp.codigogrupo
                           )
                    ),
                    clientes_dist AS (
                        SELECT codigogrupo
                          FROM clientes_validos
                        UNION ALL
                        SELECT cg.codigogrupo
                          FROM data.t_icom_inversion_cliente_g cg
                         WHERE cg.idinversion = DETALLES.idinversion
                           AND NOT EXISTS (SELECT 1 FROM clientes_validos)
                           AND EXISTS (
                               SELECT 1
                                 FROM data.t_icom_inversiones inv_fallback
                                WHERE inv_fallback.id = DETALLES.idinversion
                                  AND EXTRACT(YEAR FROM inv_fallback.fechainicio) = 2026
                           )
                    ),
                    ventas_base AS (
                        SELECT cd.codigogrupo,
                               s.codigoproducto,
                               SUM(
                                   CASE GASTOS.IDINVERSIONTIPO
                                       WHEN 4 THEN s.valorventa3
                                       ELSE s.valorventa
                                   END
                               ) venta
                          FROM data.t_trad_sellin s
                          INNER JOIN clientes_dist cd
                                  ON cd.codigogrupo = s.codigogrupo
                          INNER JOIN data.t_icom_inversion_producto p
                                  ON p.codigoproducto = s.codigoproducto
                                 AND p.idinversion = DETALLES.idinversion
                                 AND p.tipo = 1
                         WHERE s.compania = DETALLES.compania
                           -- Usar el mes completo de la actividad para cubrir ventas registradas al inicio del mes.
                           AND s.fecha BETWEEN TRUNC(DETALLES.fecha_actividad, 'MM') AND LAST_DAY(DETALLES.fecha_actividad_fin)
                           AND CASE GASTOS.IDINVERSIONTIPO
                                   WHEN 4 THEN s.valorventa3
                                   ELSE s.valorventa
                               END > 0
                         GROUP BY cd.codigogrupo, s.codigoproducto
                    )
                    SELECT DETALLES.id, DETALLES.idinversion, DETALLES.tipo, vb.codigogrupo, NULL codigocliente,
                           vb.codigoproducto, NULL codigobarra, DETALLES.descripcion,
                           DETALLES.compania, DETALLES.valorinicial, DETALLES.valordistribucion,
                           -- Conservar precisión: el redondeo por fila altera el
                           -- total de una línea JDE al distribuirla entre productos.
                           (vb.venta * 100) / SUM(vb.venta) OVER(PARTITION BY DETALLES.documento) pesodistribucion,
                           (vb.venta / SUM(vb.venta) OVER(PARTITION BY DETALLES.documento)) * DETALLES.valordistribucion valor,
                           DETALLES.tablaid, DETALLES.tabladescripcion,
                           DETALLES.documentotipo, DETALLES.documento, DETALLES.fecha,
                           DETALLES.observacion, DETALLES.eseliminar, DETALLES.idgasto,
                           DETALLES.fecha_actividad, DETALLES.fecha_actividad_fin
                      FROM ventas_base vb
                    UNION ALL
                    SELECT DETALLES.id, DETALLES.idinversion, DETALLES.tipo, cd.codigogrupo, NULL codigocliente,
                           p.codigoproducto, NULL codigobarra, DETALLES.descripcion,
                           DETALLES.compania, DETALLES.valorinicial, DETALLES.valordistribucion,
                           100 / COUNT(*) OVER() pesodistribucion,
                           DETALLES.valordistribucion / COUNT(*) OVER() valor,
                           DETALLES.tablaid, DETALLES.tabladescripcion,
                           DETALLES.documentotipo, DETALLES.documento, DETALLES.fecha,
                           DETALLES.observacion, DETALLES.eseliminar, DETALLES.idgasto,
                           DETALLES.fecha_actividad, DETALLES.fecha_actividad_fin
                      FROM clientes_dist cd
                      CROSS JOIN data.t_icom_inversion_producto p
                     WHERE p.idinversion = DETALLES.idinversion
                       AND p.tipo = 1
                       AND NOT EXISTS (SELECT 1 FROM ventas_base)
                )
                LOOP
                    INSERT INTO t_icom_inversion_gastodistribucion(
                        id,idinversion,tipo,codigogrupo,codigocliente,codigoproducto,codigobarra,
                        descripcion,compania,valorinicial,valordistribucion,pesodistribucion,valor,
                        tablaid,tabladescripcion,documentotipo,documento,fecha,observacion,eseliminar,idgasto,
                        fecha_actividad, fecha_actividad_fin
                    ) VALUES (
                        DETALLES_DIST.id, DETALLES_DIST.idinversion, DETALLES_DIST.tipo, DETALLES_DIST.codigogrupo, DETALLES_DIST.codigocliente,
                        DETALLES_DIST.codigoproducto, DETALLES_DIST.codigobarra, DETALLES_DIST.descripcion,
                        DETALLES_DIST.compania, DETALLES_DIST.valorinicial, DETALLES_DIST.valordistribucion, DETALLES_DIST.pesodistribucion,
                        DETALLES_DIST.valor, DETALLES_DIST.tablaid, DETALLES_DIST.tabladescripcion,
                        DETALLES_DIST.documentotipo, DETALLES_DIST.documento, DETALLES_DIST.fecha,
                        DETALLES_DIST.observacion, DETALLES_DIST.eseliminar, DETALLES_DIST.idgasto,
                        DETALLES_DIST.fecha_actividad, DETALLES_DIST.fecha_actividad_fin
                    );
                END LOOP;

                -- Cada línea JDE se distribuye de forma independiente. No se
                -- aplica compensación global por documento, porque una OC puede
                -- contener varias líneas válidas asociadas a requisiciones distintas.
            END LOOP;
            COMMIT;
        END LOOP;
    
        ----------------------------------------------------------------------
        -- BLOQUE 2: DISTRIBUCIÃ‚Â¿N POR NEGOCIACIONES RECURRENTES (con OC JDE)
        ----------------------------------------------------------------------
        V_IDGASTO := null;
        FOR NEG IN (
            SELECT 
                inv.id idinversion,
                'GASTO' GASTOTIPO,
                'AUTOMATICO' TIPO,
                NULL PERIODO,
                --'NEGOCIACIONES RECURRENTES' FUENTE,
                'NEGOCIACIONES RECURRENTES NO: '||pgr.IDPAGO FUENTE,
                NULL VALOR,
                'ORDENES DE COMPRA POR NEGOCIACIONES' OBSERVACION,
                0 VALORPEQ,
                0 VALORMETA,
                SUM(ocd.pdaexp/100) VALORREAL,  -- monto real desde F4311
                0 CALCULADO,
                NULL CALCULO,
                100 VALORPORCENTAJE,
                inv.compania,
                pgr.IDPAGO PAGO_RECURRENTE,
                inv.IDINVERSIONTIPO,
                inv.FECHAINICIO,
                inv.FECHAFIN
            FROM data.t_comp_negociacion a
            INNER JOIN data.t_comp_negociacioncab b 
                    ON a.id = b.idneg
            INNER JOIN data.vt_comp_pagosrecurrentes p
                    ON p.idneg = a.id
            INNER JOIN f4311@jdedtadl ocd
                    ON ocd.pddoco = p.numorden
                   AND ocd.pddcto = p.tipoorden
                   AND ((ocd.PDLTTR='400' AND ocd.PDNXTR='400') OR (ocd.PDLTTR='400' AND ocd.PDNXTR='999'))
            INNER JOIN data.vt_icom_inversion_pago_recurrente pgr
                    ON pgr.IDPAGO = a.id
            INNER JOIN data.t_icom_inversiones inv
                    ON inv.ID = pgr.IDINVERSION
            WHERE a.recurrente = 'SI'
              AND a.estadoflujo = 'APROBADO'
              AND b.unidadnegocio IN ('BUSINESSINT','TRADE','VTSIE6')
              and inv.idetapa in (2,3,4,7) and (inv.estado = 1 OR (NVL(P_REPROCESA_CERRADAS, 0) = 1 AND inv.estado = 4))
              and (P_IDINVERSION IS NULL OR inv.id = P_IDINVERSION)
              and p.FECHAFACTURA BETWEEN inv.FECHAINICIO and inv.FECHAFIN
            GROUP BY inv.id, inv.compania,pgr.IDPAGO,inv.IDINVERSIONTIPO,inv.FECHAINICIO,inv.FECHAFIN
        )
        LOOP
            --DBMS_OUTPUT.PUT_LINE('DISTRIBUCION GASTO NEG RECURRENTE IDINVERSION:'||NEG.IDINVERSION);
    
            -- Buscar cabecera de gasto existente
            BEGIN
                SELECT idgasto INTO V_IDGASTO
                FROM t_icom_inversion_gasto
                WHERE idinversion = NEG.idinversion
                  AND gastotipo  = NEG.gastotipo
                  AND tipo       = NEG.tipo
                  AND fuente     = NEG.fuente
                  AND ROWNUM=1;
            EXCEPTION WHEN OTHERS THEN
                V_IDGASTO := NULL;
            END;
            
             -- Insertar o actualizar cabecera
            IF V_IDGASTO IS NULL THEN
                V_IDGASTO := pk_commons.f_secuencia('DATA.T_ICOM_INVERSION_GASTO');
                INSERT INTO t_icom_inversion_gasto(
                    idinversion,gastotipo,tipo,periodo,fuente,valor,
                    observacion,valormeta,valorpeq,valorreal,calculado,idgasto
                ) VALUES (
                    NEG.idinversion,NEG.gastotipo,NEG.tipo,NEG.periodo,
                    NEG.fuente,NEG.valor,NEG.observacion,NEG.valormeta,
                    NEG.valorpeq,NEG.valorreal,NEG.calculado,V_IDGASTO
                );
            ELSE
                UPDATE t_icom_inversion_gasto cli
                   SET cli.observacion = NEG.observacion,
                       cli.valorreal   = NEG.valorreal
                 WHERE cli.idgasto = V_IDGASTO
                   AND idinversion = NEG.idinversion;
            END IF;
            
            -- Borrar detalle previo
            IF V_IDGASTO IS NOT NULL THEN
                DELETE FROM t_icom_inversion_gastodistribucion WHERE idgasto = V_IDGASTO;
            END IF;
            
            V_IDDETALLEGASTO := pk_commons.f_secuencia(V_TABLASECUENCIA);
            
            -- Iterar por detalles de la OC JDE vinculada
            FOR DETALLES IN (
                SELECT V_IDDETALLEGASTO ID, NEG.idinversion IDINVERSION, 3 TIPO, NULL CODIGOGRUPO,NULL CODIGOCLIENTE, ocd.pditm CODIGOPRODUCTO,NULL CODIGOBARRA,
                'NEGOCIACION RECURRENTE' DESCRIPCION,NEG.compania COMPANIA,SUM(NVL(ocd.pdaexp,0)/100) VALORINICIAL,NEG.valorreal VALORDISTRIBUCION,0 PESODISTRIBUCION,0 VALOR,
                'F4311' TABLAID, 'GASTO DE NEGOCIACION RECURRENTE' TABLADESCRIPCION, ocd.pddcto DOCUMENTOTIPO, ocd.pddoco DOCUMENTO,TRUNC(SYSDATE) FECHA,'NEGOCIACION RECURRENTE' OBSERVACION, 0 ESELIMINAR, V_IDGASTO IDGASTO,
                --MAX(p.FECHAFACTURA) FECHAFACTURA
                CASE WHEN (UDC.VALOR) IS NULL THEN ADD_MONTHS(MAX(p.FECHAFACTURA), -1) ELSE MAX(p.FECHAFACTURA) END FECHAFACTURA
                FROM f4311@jdedtadl ocd
                INNER JOIN data.vt_comp_pagosrecurrentes p
                    ON ocd.pddoco = p.numorden
                   AND ocd.pddcto = p.tipoorden
                   AND ((ocd.PDLTTR='400' AND ocd.PDNXTR='400') OR (ocd.PDLTTR='400' AND ocd.PDNXTR='999'))
                LEFT JOIN T_CORP_UDC UDC ON (UDC.ID_CABECERA='ICOM_CEFD' AND CODPROVEEDOR=UDC.VALOR)
                WHERE p.idneg = NEG.pago_recurrente
                AND p.FECHAFACTURA BETWEEN NEG.FECHAINICIO AND NEG.FECHAFIN
                GROUP BY NEG.compania, NEG.idinversion, NEG.valorreal, ocd.pddcto, ocd.pddoco, ocd.pditm,UDC.VALOR
            )
            LOOP

                FOR DETALLES_DIST IN (
                    SELECT V_IDDETALLEGASTO ID, NEG.idinversion IDINVERSION, 3 TIPO, s.CODIGOGRUPO CODIGOGRUPO,NULL CODIGOCLIENTE,NULL CODIGOPRODUCTO,NULL CODIGOBARRA,
                       'NEGOCIACION RECURRENTE' DESCRIPCION,NEG.compania COMPANIA,DETALLES.VALORINICIAL VALORINICIAL,NEG.valorreal VALORDISTRIBUCION,
                       ROUND((SUM(
                                CASE NEG.IDINVERSIONTIPO
                                    WHEN 4 THEN s.VALORVENTA3
                                    ELSE s.VALORVENTA
                                END
                                ) * 100) /
                                SUM(SUM(
                                CASE NEG.IDINVERSIONTIPO
                                    WHEN 4 THEN s.VALORVENTA3
                                    ELSE s.VALORVENTA
                                END
                                )) OVER (PARTITION BY s.CODIGOGRUPO),2) PESODISTRIBUCION,

                       ROUND((SUM(
                                CASE NEG.IDINVERSIONTIPO
                                    WHEN 4 THEN s.VALORVENTA3
                                    ELSE s.VALORVENTA
                                END
                                )) /
                                SUM(SUM(
                                CASE NEG.IDINVERSIONTIPO
                                    WHEN 4 THEN s.VALORVENTA3
                                    ELSE s.VALORVENTA
                                END
                                )) OVER (PARTITION BY s.CODIGOGRUPO),2) * DETALLES.VALORINICIAL VALOR,
                       'F4311' TABLAID, 'GASTO DE NEGOCIACION RECURRENTE' TABLADESCRIPCION, DETALLES.DOCUMENTOTIPO, DETALLES.DOCUMENTO,TRUNC(SYSDATE) FECHA,'NEGOCIACION RECURRENTE' OBSERVACION, 0 ESELIMINAR, V_IDGASTO IDGASTO,
                       TRUNC(DETALLES.FECHAFACTURA, 'MM') FECHA_ACTIVIDAD, LAST_DAY(DETALLES.FECHAFACTURA) FECHA_ACTIVIDAD_FIN
                    FROM DATA.T_TRAD_SELLIN s
                    INNER JOIN DATA.t_icom_inversion_cliente_g c
                        ON c.CODIGOGRUPO = s.CODIGOGRUPO AND c.idinversion = NEG.idinversion
                    INNER JOIN DATA.t_icom_inversion_producto p
                            ON p.CODIGOPRODUCTO = s.CODIGOPRODUCTO AND p.idinversion = NEG.idinversion
                            AND p.tipo = 1
                    WHERE s.COMPANIA = NEG.compania AND s.FECHA BETWEEN TRUNC(ADD_MONTHS(DETALLES.FECHAFACTURA, -1), 'MM')
                      AND LAST_DAY(ADD_MONTHS(DETALLES.FECHAFACTURA, -1))
                      AND CASE NEG.IDINVERSIONTIPO
                              WHEN 4 THEN s.VALORVENTA3
                              ELSE s.VALORVENTA
                          END > 0
                    GROUP BY s.CODIGOGRUPO,DETALLES.VALORINICIAL, DETALLES.VALORDISTRIBUCION,
                         DETALLES.DOCUMENTOTIPO, DETALLES.DOCUMENTO, NEG.idinversion,
                         NEG.compania, DETALLES.FECHAFACTURA, DETALLES.CODIGOPRODUCTO
                    )
                LOOP
                    --LOG
                    --DBMS_OUTPUT.PUT_LINE('DISTRIBUCION PONDERADA GASTO NEG RECURRENTE IDDETALLEGASTO:'||DETALLES_DIST.ID||'IDINVERSION:'||DETALLES_DIST.IDINVERSION||'DOCUMENTOTIPO'||DETALLES_DIST.DOCUMENTOTIPO||'DOCUMENTO:'||DETALLES_DIST.DOCUMENTO||' CODIGOGRUPO:'||DETALLES_DIST.CODIGOGRUPO||' PESODISTRIBUCION:'||DETALLES_DIST.PESODISTRIBUCION||' VALOR:'||DETALLES_DIST.VALOR);

                    INSERT INTO t_icom_inversion_gastodistribucion(
                    id,idinversion,tipo,codigogrupo,codigocliente,codigoproducto,codigobarra,
                    descripcion,compania,valorinicial,valordistribucion,pesodistribucion,valor,
                    tablaid,tabladescripcion,documentotipo,documento,fecha,observacion,eseliminar,idgasto,
                    fecha_actividad, fecha_actividad_fin
                    ) VALUES (
                        DETALLES_DIST.ID, DETALLES_DIST.IDINVERSION, DETALLES_DIST.TIPO, DETALLES_DIST.CODIGOGRUPO, DETALLES_DIST.CODIGOCLIENTE,
                        DETALLES_DIST.CODIGOPRODUCTO, DETALLES_DIST.CODIGOBARRA, DETALLES_DIST.DESCRIPCION,
                        DETALLES_DIST.COMPANIA, DETALLES_DIST.VALORINICIAL, DETALLES_DIST.VALORDISTRIBUCION, DETALLES_DIST.PESODISTRIBUCION, DETALLES_DIST.VALOR,
                        DETALLES_DIST.TABLAID, DETALLES_DIST.TABLADESCRIPCION, DETALLES_DIST.DOCUMENTOTIPO, DETALLES_DIST.DOCUMENTO, DETALLES_DIST.FECHA, DETALLES_DIST.OBSERVACION, DETALLES_DIST.ESELIMINAR, DETALLES_DIST.IDGASTO,
                        DETALLES_DIST.FECHA_ACTIVIDAD, DETALLES_DIST.FECHA_ACTIVIDAD_FIN
                    );
                END LOOP;

            END LOOP;
            
        END LOOP;
        
        COMMIT;
    
    END SP_DISTRIBUCIONORENDESCOMPRARECIBIDAS;

    PROCEDURE SP_DISTRIBUCIONAUTOCONSUMOSREGALO(P_REPROCESA_CERRADAS NUMBER DEFAULT 0)  AS 
        V_IDGASTO NUMBER;
        V_TABLASECUENCIA VARCHAR2(499);
        V_IDDETALLEGASTO NUMBER;
    BEGIN
    
    ---AGREGAR FECHA DE ACTVIDAD
            V_TABLASECUENCIA :='DATA.T_ICOM_INVERSION_GASTODISTRIBUCION';
            FOR GASTOS IN(
               SELECT 
                    C.IDINVERSION IDINVERSION,
                    'GASTO' GASTOTIPO,
                    'AUTOMATICO' TIPO,
                    NULL PERIODO,
                    'AUTOCONSUMOS' FUENTE,
                    C.VALOR,
                    'AUTOCONSUMO APROBADO'OBSERVACION,
                    0 VALORPEQ,
                    0 VALORMETA,
                    C.VALOR VALORREAL,
                    0 CALCULADO,
                    NULL CALCULO,
                    100  VALORPORCENTAJE
                    ,i.compania COMPANIA
                    ,idetapa   ,estado
                FROM (
                    SELECT DET.IDINVERSION,SUM(SDAEXP/100) VALOR ,DET.TIPODOCUMENTO,DET.NUMERODOCUMENTO
                    FROM (SELECT DISTINCT IDINVERSION,TIPODOCUMENTO, NUMERODOCUMENTO, estado,CODIGOREGALO  FROM DATA.t_icom_productodistribuciondet WHERE  estado=1 AND CANTIDADDISTRIBUCION!=0 AND NUMERODOCUMENTO IS NOT NULL ) DET
                    INNER JOIN f42119@jdedtadl ON SDDOCO= DET.NUMERODOCUMENTO AND SDDCTO= DET.TIPODOCUMENTO AND SDLITM= RPAD(DET.CODIGOREGALO,25,' ')
                    GROUP BY DET.IDINVERSION,DET.TIPODOCUMENTO,DET.NUMERODOCUMENTO
                    HAVING SUM(SDAEXP) !=0         
                ) C
                inner join t_icom_inversiones i on C.IDINVERSION=i.id and idetapa in (2,3,4,7) and (i.estado = 1 OR (NVL(P_REPROCESA_CERRADAS, 0) = 1 AND i.estado = 4))
            )
            LOOP 
                /*se revisa que no exista un gasto ingresado para las faturas ingresadas, se revisa por IDINVERSION,GASTOTIPO,TIPO,FUENTE*/
                BEGIN        
                    SELECT IDGASTO INTO V_IDGASTO FROM T_ICOM_INVERSION_GASTO WHERE IDINVERSION=GASTOS.IDINVERSION AND GASTOTIPO= GASTOS.GASTOTIPO AND TIPO=GASTOS.TIPO AND FUENTE= GASTOS.FUENTE AND ROWNUM=1;
                EXCEPTION WHEN OTHERS THEN 
                    V_IDGASTO :=NULL;             
                END;
                /*si no existe un gasto ingresado anteriormente se le inserta en la tabla T_ICOM_INVERSION_GASTO caso contrario se le actualiza el valor de numero de faturas y el valor a ser distrinuido.*/
                IF (V_IDGASTO IS NULL)THEN
                    V_IDGASTO:=PK_COMMONS.F_SECUENCIA ('DATA.T_ICOM_INVERSION_GASTO');
                    INSERT INTO T_ICOM_INVERSION_GASTO (        IDINVERSION,       GASTOTIPO,        TIPO,        PERIODO,        FUENTE,        VALOR,        OBSERVACION,        VALORMETA,        VALORPEQ,       VALORREAL,        CALCULADO,   IDGASTO)
                    VALUES                             ( GASTOS.IDINVERSION,GASTOS.GASTOTIPO, GASTOS.TIPO, GASTOS.PERIODO, GASTOS.FUENTE, GASTOS.VALOR, GASTOS.OBSERVACION, GASTOS.VALORMETA, GASTOS.VALORPEQ,GASTOS.VALORREAL, GASTOS.CALCULADO, V_IDGASTO);
                ELSE
                    UPDATE T_ICOM_INVERSION_GASTO CLI
                     SET
                        CLI.OBSERVACION=GASTOS.OBSERVACION,
                        CLI.VALORREAL=GASTOS.VALORREAL
                        WHERE CLI.IDGASTO=V_IDGASTO and  IDINVERSION=GASTOS.IDINVERSION;
                END IF;
                --DBMS_OUTPUT.PUT_LINE(V_IDGASTO||'   IDINVERSION:'||GASTOS.IDINVERSION);
                /*se elimina el detalle de la distribucion para volver a ingresarlo*/
                IF (V_IDGASTO IS NOT NULL)THEN
                    DELETE FROM T_ICOM_INVERSION_GASTODISTRIBUCION WHERE IDGASTO=V_IDGASTO;
                END IF;
        
                /*se ingresa los registros */
                V_IDDETALLEGASTO:=PK_COMMONS.F_SECUENCIA (V_TABLASECUENCIA);
    
                INSERT INTO T_ICOM_INVERSION_GASTODISTRIBUCION( ID,             IDINVERSION,    TIPO,               CODIGOGRUPO,        CODIGOCLIENTE,  CODIGOPRODUCTO, CODIGOBARRA,        DESCRIPCION,
                                                                COMPANIA,       VALORINICIAL,   VALORDISTRIBUCION,  PESODISTRIBUCION,   VALOR,          TABLAID,        TABLADESCRIPCION,
                                                                DOCUMENTOTIPO,  DOCUMENTO,      FECHA,              OBSERVACION,        ESELIMINAR,     IDGASTO,
                                                                FECHA_ACTIVIDAD, FECHA_ACTIVIDAD_FIN)
                    WITH BASE AS ( 
                        SELECT 
                            D.IDINVERSION,
                            D.TIPODOCUMENTO DOCUMENTOTIPO,   
                            D.NUMERODOCUMENTO DOCUMENTO,
                            D.fecha_actividad,
                            D.fecha_actividad_fin,
                            SUM(SDAEXP/100) AS TOTAL_SDAEXP
                        FROM (SELECT DISTINCT IDINVERSION,TIPODOCUMENTO, NUMERODOCUMENTO, estado,CODIGOREGALO, FECHA_ACTIVIDAD, FECHA_ACTIVIDAD_FIN FROM DATA.t_icom_productodistribuciondet WHERE  estado=1 AND CANTIDADDISTRIBUCION!=0 AND NUMERODOCUMENTO IS NOT NULL ) D
                        INNER JOIN f42119@jdedtadl ON SDDOCO= D.NUMERODOCUMENTO AND SDDCTO= D.TIPODOCUMENTO AND SDLITM= RPAD(D.CODIGOREGALO,25,' ')
                        WHERE 1=1
                        and d.IDINVERSION= GASTOS.IDINVERSION
                        GROUP BY  D.fecha_actividad, D.fecha_actividad_fin, D.IDINVERSION,D.TIPODOCUMENTO,D.NUMERODOCUMENTO
                        HAVING SUM(SDAEXP) !=0       
                    ),
                    DETALLE AS ( 
                        SELECT 
                            V_IDDETALLEGASTO ID,
                            B.IDINVERSION IDINVERSION,
                            3 TIPO,
                            C.CODIGOGRUPO CODIGOGRUPO,
                            C.CODIGOGRUPO CODIGOCLIENTE,
                            P.CODIGOPRODUCTO CODIGOPRODUCTO,
                            NULL CODIGOBARRA,
                            'AUTOCONSUMOS AUTOMATICOS' DESCRIPCION,
                            GASTOS.COMPANIA COMPANIA,
                            SUM(GASTOS.VALOR) VALORINICIAL,
                            GASTOS.VALOR VALORDISTRIBUCION,
                            ROUND( (B.TOTAL_SDAEXP / COUNT(P.CODIGOPRODUCTO) OVER (PARTITION BY B.DOCUMENTO)) / GASTOS.VALOR * 100, 2) PESODISTRIBUCION,
                            ROUND( B.TOTAL_SDAEXP / COUNT(P.CODIGOPRODUCTO) OVER (PARTITION BY B.DOCUMENTO), 2) VALOR,
                            'T_AUTOCONSUMOS' TABLAID,
                            'GASTO EN CIERRE AUTOCONSUMOS' TABLADESCRIPCION,
                            B.DOCUMENTOTIPO,   
                            B.DOCUMENTO,
                            TRUNC(SYSDATE) FECHA, 
                            'AUTO CONSUMOS' OBSERVACION, 
                            0 ESELIMINAR,
                            V_IDGASTO IDGASTO,
                            B.fecha_actividad,
                            B.fecha_actividad_fin
                        FROM BASE B
                        INNER JOIN DATA.T_ICOM_INVERSION_PRODUCTO P ON P.IDINVERSION = B.IDINVERSION AND P.TIPO = 1
                        INNER JOIN DATA.T_ICOM_INVERSION_CLIENTE_G C ON C.IDINVERSION = B.IDINVERSION
                        GROUP BY B.fecha_actividad, B.fecha_actividad_fin, GASTOS.COMPANIA, GASTOS.VALOR, B.IDINVERSION, C.CODIGOGRUPO, B.DOCUMENTOTIPO, B.DOCUMENTO, TRUNC(SYSDATE), B.TOTAL_SDAEXP, P.CODIGOPRODUCTO
                    )
                    SELECT  
                        ID,             IDINVERSION,    TIPO,               CODIGOGRUPO,        CODIGOCLIENTE,  CODIGOPRODUCTO, CODIGOBARRA,        DESCRIPCION,
                        COMPANIA,       VALORINICIAL,   VALORDISTRIBUCION,  PESODISTRIBUCION,   VALOR,          TABLAID,        TABLADESCRIPCION,
                        DOCUMENTOTIPO,  DOCUMENTO,      FECHA,              OBSERVACION,        ESELIMINAR,     IDGASTO,
                        FECHA_ACTIVIDAD, FECHA_ACTIVIDAD_FIN
                    FROM DETALLE;
            END LOOP;
    END SP_DISTRIBUCIONAUTOCONSUMOSREGALO;


    PROCEDURE SP_DISTRIBUCIONAUTOCONSUMOSMUESTRAS(P_REPROCESA_CERRADAS NUMBER DEFAULT 0, P_IDINVERSION NUMBER DEFAULT NULL) AS
        V_IDGASTO NUMBER;
        V_TABLASECUENCIA VARCHAR2(499);
        V_IDDETALLEGASTO NUMBER;
    BEGIN
            --AGREGAR FECHA DE ACTIVIDAD
            
            V_TABLASECUENCIA :='DATA.T_ICOM_INVERSION_GASTODISTRIBUCION';
            FOR GASTOS IN(
               SELECT 
                    C.IDINVERSION IDINVERSION,
                    'GASTO' GASTOTIPO,
                    'AUTOMATICO' TIPO,
                    NULL PERIODO,
                    'AUTOCONSUMOS' FUENTE,
                    NULL VALOR,
                    'AUTOCONSUMO APROBADO'OBSERVACION,
                    0 VALORPEQ,
                    0 VALORMETA,
                    C.VALOR VALORREAL,
                    0 CALCULADO,
                    NULL CALCULO,
                    100  VALORPORCENTAJE
                    ,i.compania COMPANIA
                    ,idetapa   ,estado
                FROM (
                    SELECT DET.IDINVERSION,SUM(SDAEXP/100) VALOR-- ,DET.TIPODOCUMENTO,DET.NUMERODOCUMENTO
                    FROM (SELECT DISTINCT IDINVERSION,'VA' TIPODOCUMENTO, ORDENVENTA NUMERODOCUMENTO,
                    estado,CODIGOPRODUCTO  FROM DATA.t_icom_productomuestra WHERE  estado=1 AND CANTIDAD!=0 AND CODIGOPRODUCTO IS NOT NULL ) DET
                    INNER JOIN f42119@jdedtadl ON SDDOCO= DET.NUMERODOCUMENTO AND SDDCTO= DET.TIPODOCUMENTO AND SDLITM= RPAD(DET.CODIGOPRODUCTO,25,' ')
                    GROUP BY DET.IDINVERSION--,DET.TIPODOCUMENTO,DET.NUMERODOCUMENTO
                    HAVING SUM(SDAEXP) !=0         
                ) C
                inner join t_icom_inversiones i on C.IDINVERSION=i.id and (P_IDINVERSION IS NULL or P_IDINVERSION = i.id) and idetapa in (3,4,7) and (i.estado = 1 OR (NVL(P_REPROCESA_CERRADAS, 0) = 1 AND i.estado = 4))
            )
            LOOP 
                /*se revisa que no exista un gasto ingresado para las faturas ingresadas, se revisa por IDINVERSION,GASTOTIPO,TIPO,FUENTE*/
                BEGIN        
                    SELECT IDGASTO INTO V_IDGASTO FROM T_ICOM_INVERSION_GASTO WHERE IDINVERSION=GASTOS.IDINVERSION AND GASTOTIPO= GASTOS.GASTOTIPO AND TIPO=GASTOS.TIPO AND FUENTE= GASTOS.FUENTE AND ROWNUM=1;
                EXCEPTION WHEN OTHERS THEN 
                    V_IDGASTO :=NULL;             
                END;
                /*si no existe un gasto ingresado anteriormente se le inserta en la tabla T_ICOM_INVERSION_GASTO caso contrario se le actualiza el valor de numero de faturas y el valor a ser distrinuido.*/
                IF (V_IDGASTO IS NULL)THEN
                    V_IDGASTO:=PK_COMMONS.F_SECUENCIA ('DATA.T_ICOM_INVERSION_GASTO');
                    INSERT INTO T_ICOM_INVERSION_GASTO (        IDINVERSION,       GASTOTIPO,        TIPO,        PERIODO,        FUENTE,        VALOR,        OBSERVACION,        VALORMETA,        VALORPEQ,       VALORREAL,        CALCULADO,   IDGASTO)
                    VALUES                             ( GASTOS.IDINVERSION,GASTOS.GASTOTIPO, GASTOS.TIPO, GASTOS.PERIODO, GASTOS.FUENTE, GASTOS.VALOR, GASTOS.OBSERVACION, GASTOS.VALORMETA, GASTOS.VALORPEQ,GASTOS.VALORREAL, GASTOS.CALCULADO, V_IDGASTO);
                ELSE
                    UPDATE T_ICOM_INVERSION_GASTO CLI
                     SET
                        CLI.OBSERVACION=GASTOS.OBSERVACION,
                        CLI.VALORREAL=GASTOS.VALORREAL
                        WHERE CLI.IDGASTO=V_IDGASTO and  IDINVERSION=GASTOS.IDINVERSION;
                END IF;
                --DBMS_OUTPUT.PUT_LINE(V_IDGASTO||'   IDINVERSION:'||GASTOS.IDINVERSION);
                /*se elimina el detalle de la distribucion para volver a ingresarlo*/
                IF (V_IDGASTO IS NOT NULL)THEN
                    DELETE FROM T_ICOM_INVERSION_GASTODISTRIBUCION WHERE IDGASTO=V_IDGASTO;
                END IF;
        
                /*se ingresa los registros */
                V_IDDETALLEGASTO:=PK_COMMONS.F_SECUENCIA (V_TABLASECUENCIA);
    
                INSERT INTO T_ICOM_INVERSION_GASTODISTRIBUCION( ID,             IDINVERSION,    TIPO,               CODIGOGRUPO,        CODIGOCLIENTE,  CODIGOPRODUCTO, CODIGOBARRA,        DESCRIPCION,
                                                                COMPANIA,       VALORINICIAL,   VALORDISTRIBUCION,  PESODISTRIBUCION,   VALOR,          TABLAID,        TABLADESCRIPCION,
                                                                DOCUMENTOTIPO,  DOCUMENTO,      FECHA,              OBSERVACION,        ESELIMINAR,     IDGASTO,
                                                                FECHA_ACTIVIDAD, FECHA_ACTIVIDAD_FIN)
                    WITH BASE AS ( 
                        SELECT 
                            D.IDINVERSION,
                            'VA' DOCUMENTOTIPO,   
                            D.ORDENVENTA DOCUMENTO,
                            D.FECHA_ACTIVIDAD,
                            D.FECHA_ACTIVIDAD_FIN,
                            D.PERSONA_C,
                            D.CODIGOPRODUCTO,
                            SUM(D.CANTIDAD) AS TOTAL_CANTIDAD,
                            SUM(SDAEXP/100) AS TOTAL_SDAEXP,
                            SUM(SUM(D.CANTIDAD)) OVER (PARTITION BY D.ORDENVENTA, D.CODIGOPRODUCTO) AS DOC_TOTAL_CANTIDAD,
                            SUM(SUM(D.CANTIDAD)) OVER () AS GLOBAL_TOTAL_CANTIDAD
                        FROM DATA.t_icom_productomuestra D
                        INNER JOIN f42119@jdedtadl ON SDDOCO= D.ORDENVENTA AND SDDCTO= 'VA' AND SDLITM= RPAD(D.CODIGOPRODUCTO,25,' ')
                        WHERE D.estado=1 AND D.CANTIDAD!=0 AND D.CODIGOPRODUCTO IS NOT NULL
                          AND D.IDINVERSION= GASTOS.IDINVERSION
                        GROUP BY D.FECHA_ACTIVIDAD, D.FECHA_ACTIVIDAD_FIN, D.IDINVERSION, D.ORDENVENTA, D.PERSONA_C, D.CODIGOPRODUCTO
                        HAVING SUM(SDAEXP) != 0       
                    ),
                    DETALLE AS (
                        SELECT 
                            V_IDDETALLEGASTO ID,
                            B.IDINVERSION IDINVERSION,
                            3 TIPO,
                            NVL(B.PERSONA_C, C.CODIGOGRUPO) CODIGOGRUPO,
                            NVL(B.PERSONA_C, C.CODIGOGRUPO) CODIGOCLIENTE,
                            TRIM(B.CODIGOPRODUCTO) CODIGOPRODUCTO,
                            NULL CODIGOBARRA,
                            'AUTOCONSUMOS AUTOMATICOS' DESCRIPCION,
                            GASTOS.COMPANIA COMPANIA,
                            GASTOS.VALOR VALORINICIAL,
                            GASTOS.VALOR VALORDISTRIBUCION,
                            ROUND((B.TOTAL_CANTIDAD / COUNT(*) OVER (PARTITION BY B.DOCUMENTO, B.PERSONA_C, B.CODIGOPRODUCTO)) / NULLIF(B.GLOBAL_TOTAL_CANTIDAD, 0) * 100, 4) PESODISTRIBUCION,
                            ROUND((B.TOTAL_SDAEXP * B.TOTAL_CANTIDAD / B.DOC_TOTAL_CANTIDAD) / COUNT(*) OVER (PARTITION BY B.DOCUMENTO, B.PERSONA_C, B.CODIGOPRODUCTO), 4) VALOR,
                            'T_AUTOCONSUMOS' TABLAID,
                            'GASTO EN CIERRE AUTOCONSUMOS' TABLADESCRIPCION,
                            B.DOCUMENTOTIPO DOCUMENTOTIPO,   
                            B.DOCUMENTO DOCUMENTO,
                            TRUNC(SYSDATE) FECHA, 
                            'AUTO CONSUMOS' OBSERVACION, 
                            0 ESELIMINAR,
                            V_IDGASTO IDGASTO,
                            B.FECHA_ACTIVIDAD,
                            B.FECHA_ACTIVIDAD_FIN
                        FROM BASE B
                        LEFT JOIN DATA.T_ICOM_INVERSION_CLIENTE_G C ON C.IDINVERSION = B.IDINVERSION AND B.PERSONA_C IS NULL
                    )
                    SELECT  
                        ID,             IDINVERSION,    TIPO,               CODIGOGRUPO,        CODIGOCLIENTE,  CODIGOPRODUCTO, CODIGOBARRA,        DESCRIPCION,
                        COMPANIA,       VALORINICIAL,   VALORDISTRIBUCION,  PESODISTRIBUCION,   VALOR,          TABLAID,        TABLADESCRIPCION,
                        DOCUMENTOTIPO,  DOCUMENTO,      FECHA,              OBSERVACION,        ESELIMINAR,     IDGASTO,
                        FECHA_ACTIVIDAD, FECHA_ACTIVIDAD_FIN
                    FROM DETALLE;
            END LOOP;
            
    END SP_DISTRIBUCIONAUTOCONSUMOSMUESTRAS;


        

    PROCEDURE SP_VENTAS_CIERRE(P_ID NUMBER) AS
    v_fechainicio date;
    v_fechafin date;
    v_cont number;
    v_id_tipo_inversion number;
    v_compania varchar2(10);
    begin
        select fechainicio,fechafin,idinversiontipo,compania into v_fechainicio,v_fechafin,v_id_tipo_inversion,v_compania from data.t_icom_inversiones where id=P_ID;
        --DBMS_OUTPUT.PUT_LINE('v_fechainicio:'||v_fechainicio||',v_fechafin:'||v_fechafin);
        
        DELETE FROM DATA.T_ICOM_INVERSION_VENTAS WHERE IDINVERSION= P_ID and tipo in (3,4);
        
        EXECUTE IMMEDIATE 'truncate table data.t_tmp_b  drop storage';
        insert into data.t_tmp_b (num01,num02,txt01,txt02,txt03,txt04,txt05,dte01,dte02,dte03,num03,num04,num05,num06)
            SELECT
                g.idinversion idinversion,
                3 tipo,--'{3:SELLIN EN CIERRE,4:SELLOUT EN CIERRE}';
                v.CODIGOCLIENTE,v.CODIGOGRUPO,NULL codigobarra,v.codigoproducto,v.COMPANIA,
                TRUNC(V.fecha) FECHAVENTA,TRUNC(V.fecha,'MONTH')FECHAVENTA_ini_mes,last_day(V.fecha)FECHAVENTA_fin_mes,
                null PRECIOLISTA,
                CASE v_id_tipo_inversion
                    WHEN 4 THEN (v.valorventa3)
                    ELSE (v.valorventa)
                END ventainicial,
                (v.valorunidad) cantidadinicial,
                (v.valorcosto) costoinicial 
            FROM DATA.T_TRAD_SELLIN V
            INNER JOIN data.t_icom_inversion_cliente g  ON g.idinversion=P_ID AND v.CODIGOGRUPO=g.CODIGOGRUPO and v.codigocliente =g.codigocliente  and v.compania=v_compania
            WHERE 1=1          
            AND TRUNC(V.fecha) BETWEEN trunc(TO_DATE(v_fechainicio)) AND TRUNC(TO_DATE(v_fechafin));

        insert into data.t_tmp_b (num01,num02,txt01,txt02,txt03,txt04,txt05,dte01,dte02,dte03,num03,num04,num05,num06)
            SELECT
                g.IDINVERSION idinversion,
                4 tipo,--'{3:SELLIN EN CIERRE,4:SELLOUT EN CIERRE}';
                v.CODIGOCLIENTE,v.CODIGOGRUPO,v.codigobarra,NULL codigoproducto,v.COMPANIA,
                TRUNC(V.fecha) FECHAVENTA,TRUNC(V.fecha,'MONTH')FECHAVENTA_ini_mes,last_day(V.fecha)FECHAVENTA_fin_mes,
                null  preciolista,
                sum(v.VALORVENTA) ventainicial,
                sum(v.VALORUNIDAD) cantidadinicial,
                0 costoinicial
            FROM data.mvt_trad_sellout V
            INNER JOIN data.t_icom_inversion_cliente g ON g.idinversion=P_ID AND v.CODIGOGRUPO=g.CODIGOGRUPO and v.codigocliente =g.codigocliente
            WHERE 1=1
            AND TRUNC(V.fecha) BETWEEN trunc(TO_DATE(v_fechainicio)) AND TRUNC(TO_DATE(v_fechafin))
            group by g.IDINVERSION,v.CODIGOCLIENTE,v.CODIGOGRUPO,v.codigobarra,v.COMPANIA,TRUNC(V.fecha) ,TRUNC(V.fecha,'MONTH'),last_day(V.fecha)
          ;
/*
        for datos in (select distinct v.txt02 CODIGOGRUPO,V.txt01 CODIGOCLIENTE,V.txt04 CODIGOPRODUCTO,v.txt03 EANPRODUCTO,v.txt05 CIA,v.dte02 FECHAINI,v.dte03 FECHAFIN,v.num02 tipo from data.t_tmp_b v )
        loop 
            update data.t_tmp_b v 
            set num03  =round(
                    DATA.PK_GZM_VENTAS.F_PRODCUTOPRECIO(
                        P_CODIGOGRUPO =>datos.CODIGOGRUPO,
                        P_CODIGOCLIENTE =>datos.CODIGOCLIENTE,
                        P_CODIGOPRODUCTO=>datos.CODIGOPRODUCTO,
                        P_EANPRODUCTO =>datos.CIA,
                        P_CIA =>datos.CODIGOGRUPO,
                        p_FECHAINI =>datos.FECHAINI,
                        p_FECHAFIN =>datos.FECHAFIN
                    ) 
                , 2)
            where  num03 is null  
            and(     num02 =datos.tipo
                AND  nvl(v.txt02,' ')= nvl(datos.CODIGOGRUPO,' ')
                and nvl(v.txt01,' ')= nvl(datos.CODIGOCLIENTE,' ')
                and nvl(v.txt04,' ')=nvl(datos.CODIGOPRODUCTO,' ')
                and nvl(v.txt03,' ')= nvl(datos.EANPRODUCTO,' ')
                and v.txt05= datos.CIA
                and v.dte02= datos.FECHAINI
                and v.dte03= datos.FECHAFIN
            );
        end loop;   
*/
        INSERT INTO DATA.T_ICOM_INVERSION_VENTAS(IDINVERSION, TIPO, CODIGOCLIENTE, CODIGOGRUPO, CODIGOBARRA, CODIGOPRODUCTO, COMPANIA,PRECIOLISTA, VENTAREAL, CANTIDADREAL, COSTOREAL,FECHAVENTA)
            SELECT num01 IDINVERSION,num02 TIPO,txt01 CODIGOCLIENTE,txt02 CODIGOGRUPO,txt03 CODIGOBARRA,txt04 CODIGOPRODUCTO,txt05 COMPANIA,num03 PRECIOLISTA,sum(num04) VENTAREAL,sum(num05) CANTIDADREAL,sum(num06) COSTOREAL,dte01 FECHAVENTA
            FROM data.t_tmp_b
            group by num01,num02,txt01,txt02,txt03,txt04,txt05,num03,dte01;                 

	END SP_VENTAS_CIERRE;
    
    FUNCTION F_NOAPLICA_EJECUCION (P_IDINVERSION NUMBER,P_IDEJECUCION NUMBER,P_COMPANIA VARCHAR2 ) RETURN NUMBER AS
        V_IDIMPLEMENTACION NUMBER;
        V_RETORNO NUMBER;
    BEGIN    
        V_IDIMPLEMENTACION :=0;    
        IF (P_IDEJECUCION =1)THEN
            V_IDIMPLEMENTACION :=PK_ICOM_COMMONS.F_TRAERVALORUDCBYDESC(P_ID_CABECERA =>'ICOM_MATIM',TIPO=>'ID_TABLA',P_DESCRIPCION =>'CLIENTE',P_ACTIVO =>1);
            SELECT COUNT(DISTINCT 1) CODIGOGRUPO INTO V_RETORNO FROM T_ICOM_CLIENTE_MATERIAL  WHERE IMPLEMENTACION= V_IDIMPLEMENTACION AND IDINVERSION=P_IDINVERSION GROUP BY IDINVERSION ;
        END IF;
        IF (P_IDEJECUCION =2)THEN             
            SELECT COUNT(DISTINCT 1) 
            INTO V_RETORNO 
            FROM  DATA.T_ICOM_INVERSION_CLIENTE_G C 
            WHERE C.NEGOCIACION IN (1,3) AND C.IDINVERSION = P_IDINVERSION
            AND  NOT EXISTS(SELECT VALOR CODIGOGRUPO FROM "DATA"."T_CORP_UDC" G WHERE ID_CABECERA='TRAD_CLVIS' AND   G.VALOR=C.CODIGOGRUPO );
        END IF;
        IF (P_IDEJECUCION =3)THEN
            SELECT COUNT( DISTINCT 1) 
            INTO V_RETORNO 
            FROM  DATA.T_ICOM_INVERSION_CLIENTE_G C 
            WHERE C.NEGOCIACION IN (1,3) AND C.IDINVERSION = P_IDINVERSION
            AND NOT EXISTS(SELECT * FROM  T_ICOM_PRODUCTODISTRIBUCIONDET G WHERE G.IDINVERSION = P_IDINVERSION );
        END IF;
    
        IF (P_IDEJECUCION =4)THEN
            V_IDIMPLEMENTACION :=PK_ICOM_COMMONS.F_TRAERVALORUDCBYDESC(P_ID_CABECERA =>'ICOM_MATIM',TIPO=>'ID_TABLA',P_DESCRIPCION =>'ZAIMELLA',P_ACTIVO =>1);
            SELECT COUNT(DISTINCT 1) CODIGOGRUPO INTO V_RETORNO FROM T_ICOM_CLIENTE_MATERIAL  WHERE IMPLEMENTACION= V_IDIMPLEMENTACION AND IDINVERSION=P_IDINVERSION GROUP BY IDINVERSION ;
        END IF;
        RETURN V_RETORNO;
    EXCEPTION WHEN OTHERS THEN 
        V_RETORNO:=0;
        RETURN V_RETORNO;
    END F_NOAPLICA_EJECUCION;
    PROCEDURE SP_AUTOMATIZAR_VALOR_CALIFICACION(P_IDINVERSION NUMBER,P_COMPANIA VARCHAR2) AS
    --DECLARE P_IDINVERSION NUMBER:=21363;P_COMPANIA VARCHAR2(5):='00001';
    V_NA_1 NUMBER;
    V_NA_2 NUMBER;
    V_NA_3 NUMBER;
    V_NA_4 NUMBER;
    
    V_ID_1 NUMBER:=1;
    V_ID_2 NUMBER:=2;
    V_ID_3 NUMBER:=3;
    V_ID_4 NUMBER:=4;
    
    V_CLIENTES_EJECUCION_CONFIRMADOS  NUMBER;
    V_CLIENTES_CONFIRMADOS  NUMBER;
    V_CLIENTES_ATIEMPO  NUMBER;
    V_CUMPLIMIENTO_PORC NUMBER;
    V_CUMPLIMIENTO_SINO VARCHAR2(5);
    V_NO_CUMPLE NUMBER:=0;
    V_NA_CUMPLE NUMBER:=3;
    V_SI_CUMPLE NUMBER:=2;
    
    BEGIN
        SELECT 
         F_NOAPLICA_EJECUCION (P_IDINVERSION =>P_IDINVERSION,P_IDEJECUCION =>V_ID_1,P_COMPANIA =>P_COMPANIA)IDEJECUCION_1
        ,F_NOAPLICA_EJECUCION (P_IDINVERSION =>P_IDINVERSION,P_IDEJECUCION =>V_ID_2,P_COMPANIA =>P_COMPANIA)IDEJECUCION_2
        ,F_NOAPLICA_EJECUCION (P_IDINVERSION =>P_IDINVERSION,P_IDEJECUCION =>V_ID_3,P_COMPANIA =>P_COMPANIA)IDEJECUCION_3
        ,F_NOAPLICA_EJECUCION (P_IDINVERSION =>P_IDINVERSION,P_IDEJECUCION =>V_ID_4,P_COMPANIA =>P_COMPANIA)IDEJECUCION_4
        INTO V_NA_1,V_NA_2,V_NA_3,V_NA_4
        FROM DUAL;
        --DBMS_OUTPUT.PUT_LINE('V_NA_1  =>'||V_NA_1||',   V_NA_2  =>'||V_NA_2||',   V_NA_3  =>'||V_NA_3||',   V_NA_4  =>'||V_NA_4);
        
        IF (V_NA_1=0)THEN UPDATE T_ICOM_INVERSIONEJECUCION SET CUMPLIMIENTO=V_NA_CUMPLE, CALIFICACION=0 WHERE   idinversion = P_IDINVERSION AND IDEJECUCION=V_ID_1; END IF;
        IF (V_NA_2=0)THEN UPDATE T_ICOM_INVERSIONEJECUCION SET CUMPLIMIENTO=V_NA_CUMPLE, CALIFICACION=0 WHERE   idinversion = P_IDINVERSION AND IDEJECUCION=V_ID_2; END IF;
        IF (V_NA_3=0)THEN UPDATE T_ICOM_INVERSIONEJECUCION SET CUMPLIMIENTO=V_NA_CUMPLE, CALIFICACION=0 WHERE   idinversion = P_IDINVERSION AND IDEJECUCION=V_ID_3; END IF;
        IF (V_NA_4=0)THEN UPDATE T_ICOM_INVERSIONEJECUCION SET CUMPLIMIENTO=V_NA_CUMPLE, CALIFICACION=0 WHERE   idinversion = P_IDINVERSION AND IDEJECUCION=V_ID_4; END IF;
        
        V_CLIENTES_EJECUCION_CONFIRMADOS := F_CLIENTES_EJECUCION_CONFIRMADOS(P_IDINVERSION  =>P_IDINVERSION);
        --DBMS_OUTPUT.PUT_LINE('P_IDINVERSION  =>'||P_IDINVERSION||', V_CLIENTES_EJECUCION_CONFIRMADOS  =>'||V_CLIENTES_EJECUCION_CONFIRMADOS );
        
        /*Monitoreo de comunicacion*/
        IF (V_NA_1=1)THEN /*INICIO DE EJECUCION TIPO 1 */
            V_CLIENTES_CONFIRMADOS := F_CLIENTESCONFIRMADOS (P_IDINVERSION =>P_IDINVERSION,P_IDEJECUCION =>V_ID_1,P_COMPANIA =>P_COMPANIA)  ;
            BEGIN
                WITH T_MOBILMELLA AS (
                    SELECT REFERENCIATABLA, REFERENCIAID, MIN(FECHACREACION)FECHACREACION, USUARIOCREACION, CODIGOCLIENTE FROM DATA.T_ENCT_CUESTIONARIOS 
                    WHERE 1=1 
                    AND REFERENCIAID = P_IDINVERSION 
                    AND UPPER(REFERENCIATABLA)= 'INVERSION' AND TRIM(REFERENCIAID) IS NOT NULL AND USUARIOCREACION='ICOM'
                    GROUP BY REFERENCIATABLA, REFERENCIAID, USUARIOCREACION, CODIGOCLIENTE 
                )
                ,T_MATERIAL AS (
                    SELECT DISTINCT M.IDINVERSION, M.CODIGOGRUPO, M.FECHAINICIO FROM T_ICOM_CLIENTE_MATERIAL M 
                    INNER JOIN (SELECT * FROM VT_ICOM_MATERIALPOP WHERE NVL(MEDIBLE,0)=1) P ON M.IDMATERIAL=P.ID AND M.CODIGOGRUPO IS NOT NULL
                )
                SELECT COUNT(DISTINCT MM.CODIGOCLIENTE) INTO V_CLIENTES_ATIEMPO
                FROM T_MOBILMELLA MM INNER JOIN T_MATERIAL MP ON MM.REFERENCIAID=MP.IDINVERSION AND  MM.CODIGOCLIENTE=MP.CODIGOGRUPO 
                AND MM.FECHACREACION <= MP.FECHAINICIO;
            EXCEPTION WHEN OTHERS THEN 
                V_CLIENTES_ATIEMPO:=0;
            END;
            
            V_CUMPLIMIENTO_PORC :=V_CLIENTES_ATIEMPO/NULLIF(V_CLIENTES_CONFIRMADOS,0);
            V_CUMPLIMIENTO_SINO :=CASE WHEN V_CUMPLIMIENTO_PORC>80 THEN V_SI_CUMPLE ELSE V_NO_CUMPLE END;
            UPDATE T_ICOM_INVERSIONEJECUCION SET CUMPLIMIENTO=V_CUMPLIMIENTO_SINO, CALIFICACION=NVL(V_CUMPLIMIENTO_PORC,0) WHERE   IDINVERSION = P_IDINVERSION AND IDEJECUCION=V_ID_1;
        END IF;  /*FIN DE EJECUCION TIPO 1 */
        
        /*Monitoreo mecanica pdv*/
        IF (V_NA_2=1)THEN /*INICIO DE EJECUCION TIPO 2*/
                V_CLIENTES_CONFIRMADOS := F_CLIENTESCONFIRMADOS (P_IDINVERSION =>P_IDINVERSION,P_IDEJECUCION =>V_ID_2,P_COMPANIA =>P_COMPANIA)  ;
            BEGIN
                WITH T_MOBILMELLA AS (
                    SELECT REFERENCIATABLA, REFERENCIAID, MIN(FECHACREACION)FECHACREACION, USUARIOCREACION, CODIGOCLIENTE FROM DATA.T_ENCT_CUESTIONARIOS 
                    WHERE 1=1 
                    AND REFERENCIAID = P_IDINVERSION 
                    AND UPPER(REFERENCIATABLA)= 'INVERSION' AND TRIM(REFERENCIAID) IS NOT NULL AND USUARIOCREACION='ICOM'
                    GROUP BY REFERENCIATABLA, REFERENCIAID, USUARIOCREACION, CODIGOCLIENTE 
                )
                ,T_FECHAS AS (
                    SELECT DISTINCT M.IDINVERSION, M.CODIGOGRUPO, MIN(M.FECHAINICIO)FECHAINICIO FROM T_ICOM_CLIENTE_FECHAS  M 
                     WHERE M.IDINVERSION =P_IDINVERSION AND M.CODIGOGRUPO IS NOT NULL
                     GROUP BY M.IDINVERSION, M.CODIGOGRUPO
                )
                SELECT COUNT(DISTINCT MM.CODIGOCLIENTE) INTO V_CLIENTES_ATIEMPO
                FROM T_MOBILMELLA MM INNER JOIN T_FECHAS MP ON MM.REFERENCIAID=MP.IDINVERSION AND  MM.CODIGOCLIENTE=MP.CODIGOGRUPO 
                AND MM.FECHACREACION <= MP.FECHAINICIO;
            EXCEPTION WHEN OTHERS THEN 
                V_CLIENTES_ATIEMPO:=0;
            END;
            
            V_CUMPLIMIENTO_PORC :=V_CLIENTES_ATIEMPO/NULLIF(V_CLIENTES_CONFIRMADOS,0);
            V_CUMPLIMIENTO_SINO :=CASE WHEN V_CUMPLIMIENTO_PORC>80 THEN V_SI_CUMPLE ELSE V_NO_CUMPLE END;
            UPDATE T_ICOM_INVERSIONEJECUCION SET CUMPLIMIENTO=V_CUMPLIMIENTO_SINO, CALIFICACION=NVL(V_CUMPLIMIENTO_PORC,0) WHERE   IDINVERSION = P_IDINVERSION AND IDEJECUCION=V_ID_2;
        END IF; /*FIN DE EJECUCION TIPO 2*/
    
        /*Producto promocional a tiempo */
        IF (V_NA_3=1)THEN /*INICIO DE EJECUCION TIPO 3*/
                V_CLIENTES_CONFIRMADOS := F_CLIENTESCONFIRMADOS (P_IDINVERSION =>P_IDINVERSION,P_IDEJECUCION =>V_ID_3,P_COMPANIA =>P_COMPANIA)  ;
            BEGIN
                WITH 
                 T_INVERSION AS(SELECT ID , FECHAFIN_DIST FROM DATA.T_ICOM_INVERSIONES I WHERE ID  =P_IDINVERSION)
                ,T_FECHAS AS( SELECT IDINVERSION,CODIGOGRUPO,MIN(FECHAINICIO)FECHAINICIO FROM T_ICOM_CLIENTE_FECHAS WHERE IDINVERSION  =P_IDINVERSION GROUP BY IDINVERSION,CODIGOGRUPO)
                SELECT COUNT(DISTINCT CODIGOGRUPO) INTO V_CLIENTES_ATIEMPO 
                FROM T_INVERSION I INNER JOIN T_FECHAS F ON I.ID=F.IDINVERSION 
                AND I.FECHAFIN_DIST<=F.FECHAINICIO;
            EXCEPTION WHEN OTHERS THEN 
                V_CLIENTES_ATIEMPO:=0;
            END;
            
            V_CUMPLIMIENTO_PORC :=V_CLIENTES_ATIEMPO/NULLIF(V_CLIENTES_CONFIRMADOS,0);
            V_CUMPLIMIENTO_SINO :=CASE WHEN V_CUMPLIMIENTO_PORC>80 THEN V_SI_CUMPLE ELSE V_NO_CUMPLE END;
            UPDATE T_ICOM_INVERSIONEJECUCION SET CUMPLIMIENTO=V_CUMPLIMIENTO_SINO, CALIFICACION=NVL(V_CUMPLIMIENTO_PORC,0) WHERE   IDINVERSION = P_IDINVERSION AND IDEJECUCION=V_ID_3;
        END IF; /*FIN DE EJECUCION TIPO 3*/
    
        /*Material de comunicacion a tiempo en los clientes */
        IF (V_NA_4=1)THEN /*INICIO DE EJECUCION TIPO 4*/
                V_CLIENTES_CONFIRMADOS := F_CLIENTESCONFIRMADOS (P_IDINVERSION =>P_IDINVERSION,P_IDEJECUCION =>V_ID_4,P_COMPANIA =>P_COMPANIA)  ;
            BEGIN
                WITH 
                 T_INVERSION AS(SELECT ID , FECHAFIN_DIST FROM DATA.T_ICOM_INVERSIONES I WHERE ID  =P_IDINVERSION)
                ,T_FECHAS AS( SELECT IDINVERSION,CODIGOGRUPO,MIN(FECHAINICIO)FECHAINICIO FROM T_ICOM_CLIENTE_MATERIAL WHERE IDINVERSION  =P_IDINVERSION GROUP BY IDINVERSION,CODIGOGRUPO)
                SELECT COUNT(DISTINCT CODIGOGRUPO) INTO V_CLIENTES_ATIEMPO 
                FROM T_INVERSION I INNER JOIN T_FECHAS F ON I.ID=F.IDINVERSION 
                AND I.FECHAFIN_DIST<=F.FECHAINICIO;
            EXCEPTION WHEN OTHERS THEN 
                V_CLIENTES_ATIEMPO:=0;
            END;
            
            V_CUMPLIMIENTO_PORC :=V_CLIENTES_ATIEMPO/NULLIF(V_CLIENTES_CONFIRMADOS,0);
            V_CUMPLIMIENTO_SINO :=CASE WHEN V_CUMPLIMIENTO_PORC>80 THEN V_SI_CUMPLE ELSE V_NO_CUMPLE END;
            UPDATE T_ICOM_INVERSIONEJECUCION SET CUMPLIMIENTO=V_CUMPLIMIENTO_SINO, CALIFICACION=NVL(V_CUMPLIMIENTO_PORC,0) WHERE   IDINVERSION = P_IDINVERSION AND IDEJECUCION=V_ID_4;
        END IF; /*FIN DE EJECUCION TIPO 4*/
    
    END SP_AUTOMATIZAR_VALOR_CALIFICACION;
    FUNCTION F_CLIENTES_EJECUCION_CONFIRMADOS(P_IDINVERSION NUMBER) RETURN NUMBER AS
        V_RETORNO NUMBER;
    BEGIN
        SELECT COUNT(DISTINCT CODIGOGRUPO) CODIGOGRUPO 
        INTO V_RETORNO 
        FROM T_ICOM_INVERSION_CLIENTE_G 
        WHERE NEGOCIACION IN (1,3) AND IDINVERSION=P_IDINVERSION 
        GROUP BY IDINVERSION ;
        RETURN V_RETORNO;
    EXCEPTION WHEN OTHERS THEN 
        V_RETORNO:=0;
        RETURN V_RETORNO;
    END F_CLIENTES_EJECUCION_CONFIRMADOS;
    FUNCTION F_CLIENTESCONFIRMADOS (P_IDINVERSION NUMBER,P_IDEJECUCION NUMBER,P_COMPANIA VARCHAR2 ) RETURN NUMBER AS
        V_IDIMPLEMENTACION NUMBER;
        V_RETORNO NUMBER;
    BEGIN
    
        V_IDIMPLEMENTACION :=0;
    
        IF (P_IDEJECUCION =1)THEN
            V_IDIMPLEMENTACION :=PK_ICOM_COMMONS.F_TRAERVALORUDCBYDESC(P_ID_CABECERA =>'ICOM_MATIM',TIPO=>'ID_TABLA',P_DESCRIPCION =>'CLIENTE',P_ACTIVO =>1);
            SELECT COUNT(DISTINCT 1) CODIGOGRUPO INTO V_RETORNO FROM T_ICOM_CLIENTE_MATERIAL  WHERE  ESTADO=1 AND IMPLEMENTACION= V_IDIMPLEMENTACION AND IDINVERSION=P_IDINVERSION GROUP BY IDINVERSION ;
        END IF;
        IF (P_IDEJECUCION =2)THEN             
            SELECT COUNT(DISTINCT 1) 
            INTO V_RETORNO 
            FROM  DATA.T_ICOM_INVERSION_CLIENTE_G C 
            WHERE C.NEGOCIACION IN (1,3) AND C.IDINVERSION = P_IDINVERSION
            AND  EXISTS(SELECT VALOR CODIGOGRUPO FROM "DATA"."T_CORP_UDC" G WHERE ID_CABECERA='TRAD_CLVIS' AND G.VALOR=C.CODIGOGRUPO );
        END IF;
    --    IF (P_IDEJECUCION =3)THEN
    --        SELECT COUNT( DISTINCT 1) 
    --        INTO V_RETORNO 
    --        FROM  DATA.t_icom_inversion_cliente_g C 
    --        WHERE C.negociacion in (1,3) AND C.IDINVERSION = P_IDINVERSION
    --        AND NOT EXISTS(SELECT * FROM  t_icom_productodistribuciondet G WHERE G.IDINVERSION = P_IDINVERSION );
    --    END IF;
    
        IF (P_IDEJECUCION =4)THEN
            V_IDIMPLEMENTACION :=PK_ICOM_COMMONS.F_TRAERVALORUDCBYDESC(P_ID_CABECERA =>'ICOM_MATIM',TIPO=>'ID_TABLA',P_DESCRIPCION =>'ZAIMELLA',P_ACTIVO =>1);
            SELECT COUNT(DISTINCT 1) CODIGOGRUPO INTO V_RETORNO FROM T_ICOM_CLIENTE_MATERIAL  WHERE  ESTADO=1 AND IMPLEMENTACION= V_IDIMPLEMENTACION AND IDINVERSION=P_IDINVERSION GROUP BY IDINVERSION ;
        END IF;
        RETURN V_RETORNO;
    EXCEPTION WHEN OTHERS THEN 
        V_RETORNO:=0;
    --    DBMS_OUTPUT.PUT_LINE('ERROR:'||SQLERRM ||'>>  P_IDINVERSION =>'||P_IDINVERSION||',P_IDEJECUCION  =>'||P_IDEJECUCION||',P_COMPANIA  =>'''||P_COMPANIA||'''');
    --    DBMS_OUTPUT.PUT_LINE('No aplica :'||V_RETORNO );
        RETURN V_RETORNO;
    END F_CLIENTESCONFIRMADOS;

END PK_ICOM_CIERRE;
/
