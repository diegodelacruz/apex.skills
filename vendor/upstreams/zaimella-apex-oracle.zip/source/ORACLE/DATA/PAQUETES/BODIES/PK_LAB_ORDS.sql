/*
  Implementacion del publicador ORDS y del bootstrap OAuth estable del laboratorio.
  Responsable: JBALCAZAR
*/
create or replace package body PK_LAB_ORDS as
    C_MODULO constant varchar2(128) := 'ZAIMELLA_ORDS_LAB';
    C_BASE_PATH constant varchar2(128) := '/zaimella-ords-lab/';
    C_PRIVILEGIO constant varchar2(128) := 'ZAIMELLA_ORDS_LAB_PRIV';
    C_CLIENTE constant varchar2(128) := 'ZAIMELLA_ORDS_LAB_CLIENT';
    C_VERSION constant varchar2(30) := '1.1.0';

    /* Retorna la version semantica vigente del contrato ORDS. */
    function F_VERSION return varchar2 is
    begin
        return C_VERSION;
    end F_VERSION;

    /* Publica el modulo y reemplaza solo las definiciones declaradas, sin eliminarlo. */
    procedure APLICAR is
    begin
        -- Mantener el modulo y el contrato HTTP mediante operaciones idempotentes.
        ords.define_module(
            p_module_name => C_MODULO,
            p_base_path => C_BASE_PATH,
            p_items_per_page => 25,
            p_status => 'PUBLISHED',
            p_comments => 'API minima para validar despliegue ORDS y continuidad OAuth.'
        );

        ords.define_template(
            p_module_name => C_MODULO,
            p_pattern => 'health',
            p_etag_type => 'NONE',
            p_comments => 'Estado tecnico y version publicada del laboratorio ORDS.'
        );

        ords.define_handler(
            p_module_name => C_MODULO,
            p_pattern => 'health',
            p_method => 'GET',
            p_source_type => ords.source_type_query_one_row,
            p_source => q'[
                select
                    'OK' estado,
                    data.pk_lab_ords.f_version version,
                    to_char(systimestamp, 'YYYY-MM-DD"T"HH24:MI:SS.FF3TZH:TZM') fecha_servidor
                from dual
            ]',
            p_comments => 'No devuelve datos funcionales ni sensibles.'
        );

        -- Proteger el modulo completo; el cliente contractual recibe este privilegio al crearse.
        ords.define_privilege(
            p_privilege_name => C_PRIVILEGIO,
            p_roles => sys.owa.vc_arr(),
            p_patterns => sys.owa.vc_arr(),
            p_modules => sys.owa.vc_arr(C_MODULO),
            p_label => 'Zaimella ORDS Lab',
            p_description => 'Protege el laboratorio ORDS usado para validar publicacion y OAuth estable.',
            p_comments => 'Privilegio contractual del cliente ZAIMELLA_ORDS_LAB_CLIENT.'
        );

    end APLICAR;

    /* Crea una sola vez el cliente con credenciales generadas fuera de Oracle. */
    procedure PROVISIONAR_OAUTH(
        P_CLIENT_ID in varchar2,
        P_CLIENT_SECRET in varchar2,
        P_SUPPORT_EMAIL in varchar2,
        P_RESULTADO out varchar2
    ) is
        V_TOTAL number;
        V_CLIENT_ID user_ords_clients.client_id%type;
    begin
        if trim(P_CLIENT_ID) is null or trim(P_CLIENT_SECRET) is null or trim(P_SUPPORT_EMAIL) is null then
            raise_application_error(-20081, 'El client_id, client_secret y support_email son obligatorios.');
        end if;

        select count(*)
          into V_TOTAL
          from user_ords_clients
         where name = C_CLIENTE;

        if V_TOTAL = 0 then
            oauth.import_client(
                p_name => C_CLIENTE,
                p_client_id => P_CLIENT_ID,
                p_client_secret => P_CLIENT_SECRET,
                p_grant_type => 'client_credentials',
                p_owner => 'ZAIMELLA',
                p_description => 'Cliente estable del laboratorio ORDS; no recrear por release.',
                p_support_email => P_SUPPORT_EMAIL,
                p_privilege_names => C_PRIVILEGIO
            );
            P_RESULTADO := 'CREATED';
        else
            select client_id
              into V_CLIENT_ID
              from user_ords_clients
             where name = C_CLIENTE;

            if V_CLIENT_ID <> P_CLIENT_ID then
                raise_application_error(
                    -20082,
                    'El cliente contractual ya existe con otro client_id. No recrear ni rotar automaticamente.'
                );
            end if;
            P_RESULTADO := 'REUSED';
        end if;

    end PROVISIONAR_OAUTH;

    /* Comprueba modulo, template, handler, privilegio y asociacion sin ejecutar HTTP. */
    procedure VALIDAR(P_RESULTADO out varchar2) is
        V_MODULOS number;
        V_TEMPLATES number;
        V_HANDLERS number;
        V_PRIVILEGIOS number;
        V_ASOCIACIONES number;
    begin
        select count(*)
          into V_MODULOS
          from user_ords_modules
         where name = C_MODULO
           and uri_prefix = C_BASE_PATH
           and status = 'PUBLISHED';

        select count(*)
          into V_TEMPLATES
          from user_ords_modules modulo
          join user_ords_templates plantilla on plantilla.module_id = modulo.id
         where modulo.name = C_MODULO
           and plantilla.uri_template = 'health';

        select count(*)
          into V_HANDLERS
          from user_ords_modules modulo
          join user_ords_templates plantilla on plantilla.module_id = modulo.id
          join user_ords_handlers manejador on manejador.template_id = plantilla.id
         where modulo.name = C_MODULO
           and plantilla.uri_template = 'health'
           and manejador.method = 'GET';

        select count(*)
          into V_PRIVILEGIOS
          from user_ords_privileges
         where name = C_PRIVILEGIO;

        select count(*)
          into V_ASOCIACIONES
          from user_ords_privilege_modules
         where privilege_name = C_PRIVILEGIO
           and module_name = C_MODULO;

        if V_MODULOS <> 1 or V_TEMPLATES <> 1 or V_HANDLERS <> 1
           or V_PRIVILEGIOS <> 1 or V_ASOCIACIONES <> 1 then
            raise_application_error(-20083, 'La metadata ORDS no coincide con el contrato esperado.');
        end if;

        P_RESULTADO := 'ORDS_OK;VERSION=' || C_VERSION;
    end VALIDAR;

    /* Comprueba la identidad y el privilegio del cliente sin leer ni devolver su secreto. */
    procedure VALIDAR_OAUTH(
        P_CLIENT_ID in varchar2,
        P_RESULTADO out varchar2
    ) is
        V_TOTAL number;
    begin
        select count(*)
          into V_TOTAL
          from user_ords_clients cliente
          join user_ords_client_privileges privilegio
            on privilegio.client_name = cliente.name
         where cliente.name = C_CLIENTE
           and cliente.client_id = P_CLIENT_ID
           and privilegio.name = C_PRIVILEGIO;

        if V_TOTAL <> 1 then
            raise_application_error(-20084, 'El cliente OAuth o su privilegio no coincide con el contrato.');
        end if;

        P_RESULTADO := 'OAUTH_OK;CLIENT=' || C_CLIENTE || ';PRIVILEGE=' || C_PRIVILEGIO;
    end VALIDAR_OAUTH;

    /* Recupera el cliente existente para reconstruir exclusivamente una cache local perdida. */
    procedure RECUPERAR_OAUTH(
        P_CLIENT_ID out varchar2,
        P_CLIENT_SECRET out varchar2,
        P_RESULTADO out varchar2
    ) is
    begin
        -- Leer solo el cliente contractual del owner; no registrar ni transformar los valores recuperados.
        select client_id, client_secret
          into P_CLIENT_ID, P_CLIENT_SECRET
          from user_ords_clients
         where name = C_CLIENTE;

        -- Rechazar metadata incompleta antes de que el cliente Python cree su cache DPAPI.
        if trim(P_CLIENT_ID) is null or trim(P_CLIENT_SECRET) is null then
            raise_application_error(-20086, 'La metadata ORDS no contiene credenciales recuperables para el cliente contractual.');
        end if;

        P_RESULTADO := 'RECOVERED;CLIENT=' || C_CLIENTE;
    exception
        when no_data_found then
            raise_application_error(-20087, 'No existe el cliente OAuth contractual que se desea recuperar.');
    end RECUPERAR_OAUTH;
end PK_LAB_ORDS;
/
