﻿prompt TEST PACKAGE_BODY DATA.PK_ENCT_CUESTIONARIO

  CREATE OR REPLACE EDITIONABLE PACKAGE BODY PK_ENCT_CUESTIONARIO AS

    /*Funcion que retorna el select para traer los datos de la tabla referencia dependiendo del tipo de tabla*/
    FUNCTION F_SQLReferenciaTabla (p_IdTabla varchar2, p_compania varchar2 ) return varchar2 IS
        lr_referenciatabla data.vt_enct_referenciatabla%rowtype;
        lv_sql varchar2(5000) := '' ;
    BEGIN
        /*busca en la tabla general los datos para el query*/
        select * into lr_referenciatabla from data.vt_enct_referenciatabla
        where trim(id) = trim(p_idTabla) and estado = '1' and compania = p_compania ;

         /*Armar el query para la consulta */
        lv_sql := ' Select '||lr_referenciatabla.id_nombre||' from '||lr_referenciatabla.tabla||' where compania = '''||p_compania||''' ' ;
        if length(trim(lr_referenciatabla.condicion)) > 5 then
            lv_sql := lv_sql||' and '||lr_referenciatabla.condicion||' order by 1 ';
        else
            lv_sql := lv_sql||' order by 1 ';
        end if;

        return lv_sql ;
    EXCEPTION WHEN NO_DATA_FOUND THEN
		return 'Select ''Null'', 0 from dual ' ;
    END F_SQLReferenciaTabla ;


	/*Procedimiento para guardar los datos del cuestionario */
	PROCEDURE SP_CUESTIONARIOGUARDAR ( P_ID IN OUT NUMBER, P_TIPO VARCHAR2, P_IDGRUPO VARCHAR2, P_NOMBRE VARCHAR2, P_REFERENCIATABLA VARCHAR2,
		P_REFERENCIAID VARCHAR2, P_REFERENCIADESCRIPCION VARCHAR2, P_REFERENCIAPOBLACION VARCHAR2, P_FRECUENCIA VARCHAR2, P_FECHADESDE DATE,
		P_FECHAHASTA DATE, P_TIPOEJECUCION VARCHAR2, P_USUARIOCREACION VARCHAR2, P_ESTADO VARCHAR2, P_COMPANIA VARCHAR2,
        P_TPENCUESTA NUMBER DEFAULT 1, P_CODIGOCLIENTE VARCHAR DEFAULT NULL ) IS

	BEGIN
		/*Se realiza las validaciones de los datos*/
		if p_tipo is null or p_nombre is null then
			RAISE_APPLICATION_ERROR(-20000,'No puede ser nulo los campos de Tipo o Nombre');
		end if ;

		/*Si el ID es nulo es una inserciÃƒÂ³n*/
		if p_id is null then
			p_id := data.PK_COMMONS.F_SECUENCIA ('T_ENCT_CUESTIONARIOS');
			insert into DATA.T_ENCT_CUESTIONARIOS (IDCUESTIONARIO, TIPO, IDGRUPO, NOMBRE, REFERENCIATABLA, REFERENCIAID, REFERENCIADESCRIPCION,
				REFERENCIAPOBLACION, FRECUENCIA, FECHADESDE, FECHAHASTA, TIPOEJECUCION, FECHAEJECUCION, FECHACREACION, USUARIOCREACION,
				ESTADO, COMPANIA, TIPOENCUESTA, CODIGOCLIENTE )
			values ( P_ID, P_TIPO, P_IDGRUPO, P_NOMBRE, P_REFERENCIATABLA, P_REFERENCIAID, P_REFERENCIADESCRIPCION,
				P_REFERENCIAPOBLACION, P_FRECUENCIA, P_FECHADESDE, p_fechahasta, P_TIPOEJECUCION, NULL, SYSDATE, P_USUARIOCREACION,
				P_ESTADO, P_COMPANIA, P_TPENCUESTA, P_CODIGOCLIENTE ) ;
		else
			UPDATE DATA.T_ENCT_CUESTIONARIOS
			SET TIPO = P_TIPO, IDGRUPO = P_IDGRUPO, NOMBRE = P_NOMBRE, REFERENCIATABLA = P_REFERENCIATABLA,
				REFERENCIAID = P_REFERENCIAID, REFERENCIADESCRIPCION = P_REFERENCIADESCRIPCION, REFERENCIAPOBLACION = P_REFERENCIAPOBLACION,
				FRECUENCIA = P_FRECUENCIA, FECHADESDE = P_FECHADESDE, FECHAHASTA = p_fechahasta, TIPOEJECUCION = P_TIPOEJECUCION,
				ESTADO = P_ESTADO, COMPANIA = P_COMPANIA, CODIGOCLIENTE = P_CODIGOCLIENTE
			WHERE IDCUESTIONARIO = P_ID ;
		end if;
	END;

	/*Prodecimiento para copiar un cuestionario existente a uno nuevo*/
	PROCEDURE SP_CUESTIONARIOCOPIA (P_ID IN NUMBER, P_IDNEW OUT NUMBER , P_USUARIO VARCHAR2, P_COMPANIA VARCHAR2 ) IS
		lv_cuestionario data.t_enct_cuestionarios%rowtype;
		ln_idpregunta number ;

	BEGIN
		/*Busco los datos anteriores*/
		select * into lv_cuestionario from data.t_enct_cuestionarios where IDCUESTIONARIO = p_id and compania = p_compania  ;
		/*creo el nuevo cuestionario*/
		PK_ENCT_CUESTIONARIO.SP_CUESTIONARIOGUARDAR(
			P_ID => P_IDNEW,
			P_TIPO => 1 ,
			P_IDGRUPO => NULL,
			P_NOMBRE => lv_cuestionario.nombre ,
			P_REFERENCIATABLA => lv_cuestionario.referenciatabla ,
			P_REFERENCIAID => lv_cuestionario.referenciaid,
			P_REFERENCIADESCRIPCION => lv_cuestionario.referenciadescripcion ,
			P_REFERENCIAPOBLACION => lv_cuestionario.REFERENCIAPOBLACION,
			P_FRECUENCIA => lv_cuestionario.frecuencia ,
			P_FECHADESDE => lv_cuestionario.fechadesde,
			P_FECHAHASTA => lv_cuestionario.fechahasta ,
			P_TIPOEJECUCION => lv_cuestionario.tipoejecucion ,
			P_USUARIOCREACION => P_USUARIO,
			P_ESTADO => 0,
			P_COMPANIA => P_COMPANIA );

		--copiamos las preguntas padre e hijas
		for c in (select * from T_ENCT_CUESTIONARIOPREGUNTAS WHERE IDCUESTIONARIO = p_id and idpadre is null order by orden)
		LOOP
			--inserta la padre
			ln_idpregunta := data.PK_COMMONS.F_SECUENCIA ('T_ENCT_CUESTIONARIOPREGUNTAS');
			Insert into T_ENCT_CUESTIONARIOPREGUNTAS (IDPREGUNTA, IDCUESTIONARIO, ORDEN, ORDENHIJA, IDPADRE,
				RESPUESTAPADRE, REFERENCIATABLA, REFERENCIAID, REFERENCIADESCRIPCION, DESCRIPCION,
				TIPORESPUESTA, RESPUESTA, EVIDENCIA )
			values (ln_idpregunta, P_IDNEW, c.orden, c.ordenhija, c.idpadre,
				c.respuestapadre, c.referenciatabla, c.referenciaid, c.referenciadescripcion, c.descripcion,
				c.tiporespuesta, c.respuesta, c.evidencia	);
			--inserta todas las hijas
			Insert into T_ENCT_CUESTIONARIOPREGUNTAS (IDPREGUNTA, IDCUESTIONARIO, ORDEN, ORDENHIJA, IDPADRE,
				RESPUESTAPADRE, REFERENCIATABLA, REFERENCIAID, REFERENCIADESCRIPCION, DESCRIPCION,
				TIPORESPUESTA, RESPUESTA, EVIDENCIA )
			select data.PK_COMMONS.F_SECUENCIA ('T_ENCT_CUESTIONARIOPREGUNTAS'), P_IDNEW, orden, ordenhija, ln_idpregunta,
				respuestapadre, referenciatabla, referenciaid, referenciadescripcion, descripcion,
				tiporespuesta, respuesta, evidencia
			from T_ENCT_CUESTIONARIOPREGUNTAS
			WHERE IDCUESTIONARIO = p_id
			and idpadre = c.idpregunta ;

		end LOOP;

		--copiamos la poblaciÃƒÂ³n
		INSERT INTO data.T_ENCT_CUESTIONARIOPERSONAS ( IDCUESTIONARIO, DESCRIPCION, CORREO, NUMERO, IDPERSONA )
		SELECT P_IDNEW, DESCRIPCION, CORREO, NUMERO, IDPERSONA
		FROM T_ENCT_CUESTIONARIOPERSONAS
                where idcuestionario = p_id  ;

	END SP_CUESTIONARIOCOPIA ;

	/*Procedimeinto para subir encuestas de forma masiva*/
	PROCEDURE SP_subirEncuestas (P_USUARIO VARCHAR2, P_COMPANIA VARCHAR2 ) IS
		ln_cuenta number ;
		lv_ref data.vt_enct_referenciatabla%rowtype;
        lv_sql varchar2(5000);
		v_diasinicio date ;
		ln_idcuestionario number ;
		lv_descripcin varchar2(1500);
		ln_idpregunta number ;

	BEGIN
		/*Realiza Validaciones del archivo*/
		--Codigos nulos
		select count(1) into ln_cuenta from DATA.VT_APEX_EXCEL
		where TRIM(C02) IS NULL ---  nombre de encuesta
        or TRIM(C03) IS NULL or TRIM(C04) IS NULL  --- tipo de referencia / id referencia (Inversion, Producto)
        or TRIM(C05) IS NULL or TRIM(C06) IS NULL  --- fecha desde hasta
		or ( TRIM(C07) IS NULL and TRIM(C08) IS NULL and nvl(TRIM(C10),'5') NOT IN ('3', '4') ) -- codigo cliente o codigo pdv que no sea tipo 3,4 (onpack,tradicional)
        or TRIM(C09) IS NULL; --template;

		if nvl(ln_cuenta,0) > 0 then
			RAISE_APPLICATION_ERROR(-20100,'Error en el archivo existe valores nulos que no se pueden subir');
		end if ;
		ln_cuenta := 0;
		--ln_linea := 1;
		--Referencia tabla codigo exista
		select count(1) into ln_cuenta from DATA.VT_APEX_EXCEL
		where not exists ( select 1 from data.vt_enct_referenciatabla v
							where v.id = upper(TRIM(C03)) and v.estado = '1' and v.compania = p_compania ) ;
		--ln_linea := 2;
		if nvl(ln_cuenta,0) > 0 then
			RAISE_APPLICATION_ERROR(-20100,'Error en el archivo existen tipos de referencia que no existen');
		end if ;
		ln_cuenta := 0;

		--Idreferencia tabla codigo exista
		for r in ( select distinct upper(TRIM(C03)) referencia from DATA.VT_APEX_EXCEL )
		LOOP

			select * into lv_ref
			from data.vt_enct_referenciatabla v
			where v.id = r.referencia and v.estado = '1'  and v.compania = p_compania ;

			/*Armar el query para la consulta */
			lv_sql := ' select count(1) from DATA.VT_APEX_EXCEL
			            where upper(TRIM(C03)) = '''||r.referencia ||'''  and not exists ( Select 1 from ' || lv_ref.tabla
                        ||' where '||substr(lv_ref.id_nombre, instr(lv_ref.id_nombre,',')+1 )||' = trim(C04) and compania = '''||p_compania||''' ' ;

			if length(trim(lv_ref.condicion)) > 2 then
				lv_sql := lv_sql||' and '||lv_ref.condicion ;
			end if;

			lv_sql := lv_sql||' ) ' ;

			--se hace la actualizacion
			execute immediate lv_sql into ln_cuenta ;

			if nvl(ln_cuenta,0) > 0 then
				RAISE_APPLICATION_ERROR(-20100,'Error en el archivo existen codigos de referencia '||r.referencia ||' que no existen '||ln_cuenta);
			end if;
			ln_cuenta := 0;
		end LOOP;

		--fecha para asignar dato de fecha en Excel
        v_diasinicio := to_date('1899-12-30', 'YYYY-MM-DD');

        --Fechas incorrectas
		select  max(C01) into  ln_cuenta from DATA.VT_APEX_EXCEL
		where PK_CORP_COMMONS.F_ISNUMBER2(C06)=0 or PK_CORP_COMMONS.F_ISNUMBER2(C05)=0 ;

        if nvl(ln_cuenta,0) > 0 then
			RAISE_APPLICATION_ERROR(-20100,'Error en el archivo existen fechas incorrectas en la linea: '||ln_cuenta);
		end if ;

		--Fechas mayores que hoy
		select count(1) into ln_cuenta from DATA.VT_APEX_EXCEL
		where --trunc(v_diasinicio + C05) < trunc(sysdate) or
		 trunc(v_diasinicio + C06) < trunc(v_diasinicio + C05) ;

		if nvl(ln_cuenta,0) > 0 then
			RAISE_APPLICATION_ERROR(-20100,'Error en el archivo las fecha no son correctas');
		end if ;

		ln_cuenta := 0;
		--Exista el codigo de cliente
		select max(c01) into ln_cuenta from DATA.VT_APEX_EXCEL
		where trim(C07) is not null AND  trim(C08) IS NULL
		and nvl(TRIM(C10),'5') NOT IN ('3', '4')
        and exists ( select 1 from (SELECT trim(Column_Value) col
									FROM TABLE(Apex_String.Split(trim(C07), ';'))) cod
									where not exists ( select 1
														from t_trad_cliente cl
														where   cod.col = cl.CODIGOGRUPO and cl.estado = 1 and cl.compania = p_compania ) ) ;

		if nvl(ln_cuenta,0) > 0 then
			RAISE_APPLICATION_ERROR(-20100,'Error en el archivo existen clientes ZM sin PDV en la linea: '||ln_cuenta);
		end if ;
		ln_cuenta := 0;

		--Exista el codigo de PDV
		select max(C01), MAX(C08) into ln_cuenta, lv_sql from DATA.VT_APEX_EXCEL
		where trim(C08) is not null
        and nvl(TRIM(C10),'5') NOT IN ('3')
		and exists ( select 1 from (SELECT trim(Column_Value) col
									FROM TABLE(Apex_String.Split(trim(C08), ';'))) cod
									where not exists ( select 1
														from t_trad_clientelocal cl
                                                            inner join t_trad_cliente cli on ( cli.codigopdv = cl.codigopdv and cli.compania = p_compania )
														where   cod.col = cl.CODIGOPDV||'-'||cl.NUMERO /*and cl.estado = 1*/  ) ) ;

		if nvl(ln_cuenta,0) > 0 then

            select MAX(cod.col) INTO lv_descripcin
            from  (SELECT trim(Column_Value) col FROM TABLE(Apex_String.Split(trim(lv_sql), ';'))) cod
                        where not exists ( select 1
                            from t_trad_clientelocal cl
                            inner join t_trad_cliente cli on ( cli.codigopdv = cl.codigopdv and cli.compania = p_compania )
                            where   cod.col = cl.CODIGOPDV||'-'||cl.NUMERO /*and cl.estado = 1*/  );

			RAISE_APPLICATION_ERROR(-20100,'Error en el archivo existen codigo de PDV: '||lv_descripcin||' que no existen en la linea: '||ln_cuenta);
		end if ;
		ln_cuenta := 0;
		--Exista el codigo template
		select count(1) into ln_cuenta from DATA.VT_APEX_EXCEL
		where not exists ( select 1 from T_ENCT_CUESTIONARIOS c where c.IDCUESTIONARIO = TRIM(C09) and c.TIPO = 2 and c.estado = 1 and c.compania = p_compania  ) ;

		if nvl(ln_cuenta,0) > 0 then
			RAISE_APPLICATION_ERROR(-20100,'Error en el archivo el codigo cuestionario template no existe ');
		end if;
        ln_cuenta := 0;
		--La frecuencia tenga  valores correctos
		select count(1) into ln_cuenta from DATA.VT_APEX_EXCEL
		where TRIM(C11) is not null and TRIM(C11) not in ( '0','1','7','15' ) ;

		if nvl(ln_cuenta,0) > 0 then
			RAISE_APPLICATION_ERROR(-20100,'Error la frecuencia debe ser nula o tener los valores 0, 1, 7, 15 ');
		end if;
		ln_cuenta := 0;

		--Idreferencia actualiza todas las descripciones de las referencias
		for r in ( select distinct upper(TRIM(C03)) referencia from DATA.VT_APEX_EXCEL )
		LOOP

			select * into lv_ref
			from data.vt_enct_referenciatabla v
			where v.id = r.referencia and v.estado = '1' and v.compania = p_compania ;

			/*Armar el query para la consulta */
			lv_sql := ' update DATA.VT_APEX_EXCEL
			            set C12 =  ( Select '||substr(lv_ref.id_nombre, 1, instr(lv_ref.id_nombre,',')-1 )||' from ' || lv_ref.tabla
									||' where '||substr(lv_ref.id_nombre, instr(lv_ref.id_nombre,',')+1 )||' = TRIM(C04) and compania = '''||p_compania||'''  ' ;

			if length(trim(lv_ref.condicion)) > 2 then
				lv_sql := lv_sql||' and '||lv_ref.condicion ;
			end if;

			lv_sql := lv_sql||' ) ' ;

			--se hace la actualizacion
			execute immediate lv_sql ;

		end LOOP;

        /*Inserta la informacion a la base si pasa las validaciones*/
		/*creo el nuevo cuestionario*/
		for cue in (select TRIM(C02) nombre, TRIM(C03) referencia, TRIM(C04) referenciaid, trunc(v_diasinicio + C05) fechadesde,
						trunc(v_diasinicio + C06) fechahasta, TRIM(C07) codigocliente, TRIM(C08) codigopdv, TRIM(C09) idtemplate,
						nvl(TRIM(C10),'5') tipo, nvl(TRIM(C11),'1') frecuencia, TRIM(C12) referenciadescripcion
					from DATA.VT_APEX_EXCEL
					where TRIM(C02) is not null
                    and not exists ( select 1 from t_enct_cuestionarios
                                     where (( nvl(codigocliente,0) > 0 and  nvl(codigocliente,0) = nvl(TRIM(C07),0))
                                             or ( nvl(codigocliente,0) = 0 and trim(upper(nombre)) = upper(TRIM(C02)) ))
                                         and  referenciatabla =   TRIM(C03)
                                         and referenciaid = TRIM(C04) and trunc(v_diasinicio + C05) = trunc(fechadesde)
                                         and trunc(v_diasinicio + C06) = trunc(fechahasta)
                                         and estado = 1 and compania = p_compania ) )
		loop
            --Si es tipo 3 verificar si existe un cuestionario
            if cue.tipo = 3 then
                ln_cuenta := 0;
                Select count(1) into ln_cuenta
                from t_enct_cuestionarios
                where referenciatabla = cue.referencia
                and referenciaid = cue.referenciaid
                and trunc(fechadesde) =  cue.fechadesde
                and trunc(fechahasta) = cue.fechahasta
                and tipoencuesta = 3
                and estado = 1 and compania = p_compania ;
            else
                ln_cuenta := 0 ;
            end if;

            continue when ln_cuenta >  0 ;
			--crea el cuestionario
			ln_idcuestionario := NULL ;
			PK_ENCT_CUESTIONARIO.SP_CUESTIONARIOGUARDAR(
				P_ID => ln_idcuestionario,
				P_TIPO => 1 ,
				P_IDGRUPO => NULL,
				P_NOMBRE => cue.nombre ,
				P_REFERENCIATABLA => cue.referencia ,
				P_REFERENCIAID => cue.referenciaid,
				P_REFERENCIADESCRIPCION => cue.referenciadescripcion ,
				P_REFERENCIAPOBLACION => 'PUNTOVENTA',
				P_FRECUENCIA => cue.frecuencia ,
				P_FECHADESDE => cue.fechadesde,
				P_FECHAHASTA => cue.fechahasta ,
				P_TIPOEJECUCION => 1 ,
				P_USUARIOCREACION => P_USUARIO,
				P_ESTADO => 1,
				P_COMPANIA => P_COMPANIA,
                P_TPENCUESTA => cue.tipo,
                P_CODIGOCLIENTE => cue.codigocliente )				;

			--copiamos las preguntas padre e hijas
			for c in (select * from T_ENCT_CUESTIONARIOPREGUNTAS WHERE IDCUESTIONARIO = cue.idtemplate and idpadre is null order by orden)
			LOOP
				--inserta la padre
				ln_idpregunta := data.PK_COMMONS.F_SECUENCIA ('T_ENCT_CUESTIONARIOPREGUNTAS');
				Insert into T_ENCT_CUESTIONARIOPREGUNTAS (IDPREGUNTA, IDCUESTIONARIO, ORDEN, ORDENHIJA, IDPADRE,
					RESPUESTAPADRE, REFERENCIATABLA, REFERENCIAID, REFERENCIADESCRIPCION, DESCRIPCION,
					TIPORESPUESTA, RESPUESTA, EVIDENCIA )
				values (ln_idpregunta, ln_idcuestionario, c.orden, c.ordenhija, c.idpadre,
					c.respuestapadre, c.referenciatabla, c.referenciaid, c.referenciadescripcion, c.descripcion,
					c.tiporespuesta, c.respuesta, c.evidencia	);

				--inserta todas las hijas
				Insert into T_ENCT_CUESTIONARIOPREGUNTAS (IDPREGUNTA, IDCUESTIONARIO, ORDEN, ORDENHIJA, IDPADRE,
					RESPUESTAPADRE, REFERENCIATABLA, REFERENCIAID, REFERENCIADESCRIPCION, DESCRIPCION,
					TIPORESPUESTA, RESPUESTA, EVIDENCIA )
				select data.PK_COMMONS.F_SECUENCIA ('T_ENCT_CUESTIONARIOPREGUNTAS'), ln_idcuestionario, orden, ordenhija, ln_idpregunta,
					respuestapadre, referenciatabla, referenciaid, referenciadescripcion, descripcion,
					tiporespuesta, respuesta, evidencia
				from T_ENCT_CUESTIONARIOPREGUNTAS
				WHERE IDCUESTIONARIO = cue.idtemplate
				and idpadre = c.idpregunta ;

			end LOOP;

			--insertamos la poblacion
			if cue.codigocliente is not null and cue.codigopdv is null and cue.tipo not in ('3','4') then
				INSERT INTO data.T_ENCT_CUESTIONARIOPERSONAS ( IDCUESTIONARIO, DESCRIPCION, CORREO, NUMERO, IDPERSONA )
				select ln_idcuestionario, clruc.razon_social ||' / '||NOMBRECONOCIDO, cl.EMAIL, 0 , cl.CODIGOPDV||'-'||cl.NUMERO
				from t_trad_cliente c
				   inner join t_trad_clientelocal cl on (c.codigopdv=cl.codigopdv and cl.estado=1)
				   left join  (select distinct codigopdv, RUC, RAZON_SOCIAL, tipoidentificacion
								from t_trad_clienteruc where es_principal = 1) clruc  on c.codigopdv = clruc.codigopdv
				where c.CODIGOgrupo in (SELECT trim(Column_Value) FROM TABLE(Apex_String.Split(cue.codigocliente, ';')))
				and c.estado=1 and c.compania = p_compania ;

			elsif cue.codigopdv is not null and cue.tipo not in ('3','4') then
				INSERT INTO data.T_ENCT_CUESTIONARIOPERSONAS ( IDCUESTIONARIO, DESCRIPCION, CORREO, NUMERO, IDPERSONA )
				select ln_idcuestionario, v.razon_social, v.CORREO, 0, v.codigopdv
				from VT_ENCT_CLIENTEPDV v
				where v.codigopdv in (SELECT trim(Column_Value) FROM TABLE(Apex_String.Split(cue.codigopdv, ';')))
				--and estado = 1
                and compania = p_compania ;
			elsif cue.tipo IN ('3') then
                --se debe crear la poblaciÃ³n en base al query
                INSERT INTO data.T_ENCT_CUESTIONARIOPERSONAS ( IDCUESTIONARIO, DESCRIPCION, CORREO, NUMERO, IDPERSONA )
                select distinct ln_idcuestionario, cll.NOMBRECONOCIDO, cll.EMAIL, 0, cll.codigopdv||'-'||cll.numero
                from data.t_icom_productodistribucion pd
                    inner join data.T_TRAD_CLIENTELOCAL cll ON ( pd.codigopdv = cll.codigopdv /*and cll.estado=1*/ )
                    inner join data.t_trad_cliente c on ( c.codigopdv = cll.codigopdv and c.compania = p_compania )
                where CANTIDADDISTRIBUCION>0 and pd.idinversion = cue.referenciaid;
			end if;
		end loop;
		--RAISE_APPLICATION_ERROR(-20100,'Fin .*'||SQLERRM);
        PK_ENCT_ENCUESTA.SP_EncuestaGenerar();

	END SP_subirEncuestas ;

	/*Procedimiento para copiar del parametro general el formato del correo*/
	PROCEDURE SP_FORMATOCOPIAR( P_ID IN NUMBER, P_COMPANIA VARCHAR2) is
	BEGIN
		UPDATE DATA.T_ENCT_CUESTIONARIOS
		SET FORMATOCORREO = ( SELECT VALOR FROM DATA.VT_ENCT_PARAMETROS WHERE ID = '1' AND ESTADO = '1' AND COMPANIA = P_COMPANIA )
		WHERE IDCUESTIONARIO = P_ID AND COMPANIA = P_COMPANIA ;

	END SP_FORMATOCOPIAR;

	/*PROCEDIMIENTO PARA GRABAR LAS PREGUNTAS*/
	PROCEDURE SP_PREGUNTACREAR (P_ID OUT NUMBER, P_IDCUESTIONARIO NUMBER ) IS
	BEGIN

		p_id := data.PK_COMMONS.F_SECUENCIA ('T_ENCT_CUESTIONARIOPREGUNTAS');
		Insert into T_ENCT_CUESTIONARIOPREGUNTAS (IDPREGUNTA, IDCUESTIONARIO, ORDEN )
			values (p_id, P_IDCUESTIONARIO,0 );

	END SP_PREGUNTACREAR;

	/*PROCEDIMIENTO PARA GRABAR LAS PREGUNTAS*/
	PROCEDURE SP_PREGUNTAGUARDAR (P_ID NUMBER, P_IDCUESTIONARIO NUMBER , P_IDPADRE NUMBER  , P_RESPUESTAPADRE VARCHAR2 ,
		P_REFERENCIATABLA VARCHAR2, P_REFERENCIAID VARCHAR2, P_REFERENCIADESCRIPCION VARCHAR2, P_DESCRIPCION VARCHAR2, P_TIPORESPUESTA VARCHAR2,
		P_RESPUESTA VARCHAR2, P_VALIDA NUMBER DEFAULT 0 ) IS
		lv_orden number;
		lv_ordenhija number;
		ln_existe number := 0;
		lv_error varchar2(2500);
	BEGIN

		/*Validar la pregunta */
		if p_valida = 1 then
			--si ya termina la pregunta valida la informacion
			if p_tiporespuesta is null then
				ln_existe :=  1;
				lv_error := 'El tipo de respuesta no puede ser nulo';
			end if;

			if p_idpadre is not null and p_respuestapadre is null then
				lv_error := CASE ln_existe
								when 1 then lv_error||', se debe elegir una respuesta de la pregunta que depende'
								else 'Se debe elegir una respuesta de la pregunta que depende' end ;
				ln_existe :=  1 ;
			end if;
			IF(ln_existe = 1) THEN
				RAISE_APPLICATION_ERROR(-20000,lv_error);
			END IF;

		end if ;
		/*Verifico si el orden esta nulo */
		select orden, ordenhija
		into lv_orden, lv_ordenhija
		from t_enct_cuestionariopreguntas
		where idpregunta  = p_id and idcuestionario = p_idcuestionario ;

		--dbms_output.put_line( 'ordse 1'||lv_orden );
		/*si el orden de la pregunta estan con un valor menor o igual a cero buscamos un valor*/
		if ( nvl(lv_orden,0) <=0 ) then
			select max(orden)+1 into lv_orden
			from t_enct_cuestionariopreguntas
			where idcuestionario = p_idcuestionario ;
		end if;
		/*en caso de que tenga un idpadre busca el orden de la hija*/
		if ( nvl(lv_ordenhija,0) <=0  and P_IDPADRE is not null ) then
			select max(ordenhija)+1 into lv_ordenhija
			from t_enct_cuestionariopreguntas
			where idcuestionario = p_idcuestionario
			and idpadre = p_idpadre ;
			if lv_ordenhija is null then
				lv_ordenhija := 1 ;
			end if;
			/* Se debe poner el mismo orden del padre*/
			select orden into lv_orden
			from t_enct_cuestionariopreguntas
			where idcuestionario = p_idcuestionario
			and idpregunta = p_idpadre ;

		end if;

        --dbms_output.put_line( 'ordse 1'||lv_orden||' orcden hija '||lv_ordenhija );
		/*se actualiza la pregunta */
		update T_ENCT_CUESTIONARIOPREGUNTAS
		set ORDEN = lv_orden , ORDENHIJA = lv_ordenhija,
			IDPADRE = P_IDPADRE, RESPUESTAPADRE = P_RESPUESTAPADRE, REFERENCIATABLA= P_REFERENCIATABLA,
			REFERENCIAID = P_REFERENCIAID, REFERENCIADESCRIPCION = P_REFERENCIADESCRIPCION, DESCRIPCION = P_DESCRIPCION,
			TIPORESPUESTA = P_TIPORESPUESTA, EVIDENCIA = 0, RESPUESTA = case when length(trim ( both ':' from  P_RESPUESTA )) > 1 then trim ( both ':' from  P_RESPUESTA )||':'
			                                              else null end
		where idpregunta = p_id and IDCUESTIONARIO = P_IDCUESTIONARIO ;

	END SP_PREGUNTAGUARDAR;

	/*PROCEDIMIENTO ELIMINAR PREGUNTAS EN CASO DE NO INGRESAR LA INFORMACIÃƒâ€œN*/
	PROCEDURE SP_PREGUNTAELIMINAR ( P_IDCUESTIONARIO NUMBER ) IS
	BEGIN
		DELETE FROM T_ENCT_CUESTIONARIOPREGUNTAS
		WHERE IDCUESTIONARIO = P_IDCUESTIONARIO
		AND DESCRIPCION IS NULL AND ORDEN = 0  ;

	END SP_PREGUNTAELIMINAR;

	/* Procedimiento que borra una pregunta*/
	PROCEDURE SP_PREGUNTABORRAR (P_ID varchar2) IS
	BEGIN

		delete from T_ENCT_CUESTIONARIOPREGUNTAS
		where idpregunta = to_number(p_id) ;

	END;

	/*Procedimiento para cambiar el orden de una pregunta*/
	PROCEDURE SP_PREGUNTACAMBIAORDEN (P_ID NUMBER, P_TIPO NUMBER DEFAULT 1 ) IS
		lv_orden number ;
		lv_id number;
		lv_ordenant number ;
		lv_ordenhijaant number ;
		lv_idcuestionario number;
		lv_idpadre number ;
	BEGIN
		-- busco los datos de la pregunta
		select orden, ordenhija, idcuestionario, idpadre
		into lv_ordenant, lv_ordenhijaant, lv_idcuestionario, lv_idpadre
		from T_ENCT_CUESTIONARIOPREGUNTAS
		where idpregunta = p_id ;

		-- P_TIPO = 1 subir orden
		if (p_tipo = 1 ) then
			--Busco el orden maximo anterior
			select max(orden) into lv_orden
			from T_ENCT_CUESTIONARIOPREGUNTAS
			where idpregunta != P_ID
			and idcuestionario = lv_idcuestionario
			and orden < lv_ordenant ;

			if (lv_orden is not null) then --si encontro uno menor busco el id
				select max(idpregunta) into lv_id
				from T_ENCT_CUESTIONARIOPREGUNTAS
				where idcuestionario = lv_idcuestionario
				and idpadre is null
				and orden = lv_orden;
			end if;

		elsif (p_tipo = 2  ) then -- P_TIPO = 2 bajar
			--Busco el orden minimo siguiente
			select min(orden) into lv_orden
			from T_ENCT_CUESTIONARIOPREGUNTAS
			where idpregunta != P_ID
			and idcuestionario = lv_idcuestionario
			and orden > lv_ordenant ;

			if (lv_orden is not null) then --si encontro uno mayor busco el id
				select max(idpregunta) into lv_id
				from T_ENCT_CUESTIONARIOPREGUNTAS
				where idcuestionario = lv_idcuestionario
				and idpadre is null
				and orden = lv_orden;
			end if;
		elsif (p_tipo = 3 and lv_idpadre is not null ) then --sube hija
			--Busco el orden maximo anterior
			select max(ordenhija) into lv_orden
			from T_ENCT_CUESTIONARIOPREGUNTAS
			where idpregunta != P_ID
			and idcuestionario = lv_idcuestionario
			and idpadre = lv_idpadre
			and ordenhija < lv_ordenhijaant ;

			if (lv_orden is not null) then --si encontro uno menor busco el id
				select max(idpregunta) into lv_id
				from T_ENCT_CUESTIONARIOPREGUNTAS
				where idcuestionario = lv_idcuestionario
				and idpadre = lv_idpadre
				and ordenhija = lv_orden;
			end if;

		elsif (p_tipo = 4 and lv_idpadre is not null ) then -- P_TIPO = 4 bajar hija
			--Busco el orden minimo siguiente
			select min(orden) into lv_orden
			from T_ENCT_CUESTIONARIOPREGUNTAS
			where idpregunta != P_ID
			and idcuestionario = lv_idcuestionario
			and idpadre = lv_idpadre
			and ordenhija > lv_ordenhijaant ;

			if (lv_orden is not null) then --si encontro uno mayor busco el id
				select max(idpregunta) into lv_id
				from T_ENCT_CUESTIONARIOPREGUNTAS
				where idcuestionario = lv_idcuestionario
				and idpadre = lv_idpadre
				and ordenhija = lv_orden;
			end if;
		end if;

		--Cambio el orden si encontro el id de la pregunta
		if ( nvl(lv_id,0) != 0 and p_tipo in (1,2) ) then
			--actualizo el cuestionario
			update T_ENCT_CUESTIONARIOPREGUNTAS
				set orden = lv_ordenant
				where idpregunta = lv_id
				and idcuestionario = lv_idcuestionario;
			--actualizo las hijas del cuestionario
			update T_ENCT_CUESTIONARIOPREGUNTAS
				set orden = lv_ordenant
				where idpadre = lv_id
				and idcuestionario = lv_idcuestionario;
			--actualizo el nuevo cuestionario
			update T_ENCT_CUESTIONARIOPREGUNTAS
				set orden = lv_orden
				where idpregunta = p_id
				and idcuestionario = lv_idcuestionario;
			--actualizo las hijas del nuevo cuestionario
			update T_ENCT_CUESTIONARIOPREGUNTAS
				set orden = lv_orden
				where idpadre = p_id
				and idcuestionario = lv_idcuestionario;

		elsif ( nvl(lv_id,0) != 0 and p_tipo in (3,4) ) then
			update T_ENCT_CUESTIONARIOPREGUNTAS
				set ordenhija = lv_ordenhijaant
				where idpregunta = lv_id
				and idcuestionario = lv_idcuestionario
				and idpadre = lv_idpadre;

			update T_ENCT_CUESTIONARIOPREGUNTAS
				set ordenhija = lv_orden
				where idpregunta = p_id
				and idcuestionario = lv_idcuestionario
				and idpadre = lv_idpadre;
		end if;
	END SP_PREGUNTACAMBIAORDEN;

	/*Procedimeinto para mostrar las preguntas*/
	PROCEDURE SP_PREGUNTAVISUALIZA ( P_NOMBRE VARCHAR2 DEFAULT NULL, P_ORDEN VARCHAR2 DEFAULT NULL, P_DESCRIPCION VARCHAR2 DEFAULT NULL,
        P_ORDENHIJA VARCHAR2 DEFAULT NULL, P_TIPO NUMBER DEFAULT NULL, P_PREGUNTA OUT VARCHAR2 ) IS

	BEGIN
		if p_tipo = 0 then
			--es el primero y se inserta el encabezado
			P_PREGUNTA := '<div class="ck-content"><h3 style="text-align:center;"><strong>'||P_NOMBRE||'</strong></h3>&nbsp; ' ;
		elsif p_tipo = 1 then
			--se inserta el texto de la pregunta
			P_PREGUNTA := '<p style="text-align:justify"><strong>  '||p_orden||'. '||p_descripcion||'</strong> </p>';
		elsif p_tipo = 2 then
			--se inserta el texto de la pregunta hija
			P_PREGUNTA := '<p style="text-align:justify"><strong>          '||p_orden||'.'||p_ordenhija||' . '||p_descripcion||'</strong> </p>';
		elsif p_tipo = 3 then
			--se inserta el los tab para la respuesta
			P_PREGUNTA := '<div class="container">
			                 <div class="row">
							 <div class="col col-12 apex-col-auto">';
		elsif p_tipo = 4 then
			--se inserta el los tab para cerrar la respuesta
			P_PREGUNTA := '</div></div></div></div>';
		elsif p_tipo = -1 then
			--se inserta la parte final
			P_PREGUNTA := '<p>&nbsp;</p></div>';
		end if;

	END SP_PREGUNTAVISUALIZA ;


	/*Funcion que retorna el select para traer los datos de la tabla referencia dependiendo del tipo de tabla*/
    PROCEDURE SP_SQLReferenciaPoblacion (p_IdTabla varchar2, p_compania varchar2, P_SQL OUT VARCHAR2, P_FILTRO OUT VARCHAR2 )  IS
        lr_referenciapoblacion data.vt_enct_referenciapoblacion%rowtype;
        lv_sql varchar2(5000);
    BEGIN
        /*busca en la tabla general los datos para el query*/
        select * into lr_referenciapoblacion from data.vt_enct_referenciapoblacion
        where trim(id) = trim(p_idTabla) and estado = '1' and compania = p_compania ;


         /*Armar el query para la consulta */
        lv_sql := ' Select '||lr_referenciapoblacion.ID_NOMBRE_CORREO ;

		if length(trim(lr_referenciapoblacion.filtros)) > 2 then
            lv_sql := lv_sql||', '||lr_referenciapoblacion.filtros ;
			P_FILTRO := trim(lr_referenciapoblacion.filtros) ;
		end if;
		lv_sql := lv_sql||' from '||lr_referenciapoblacion.tabla ;

		if length(trim(lr_referenciapoblacion.condicion)) > 5 then
            lv_sql := lv_sql||' where '||lr_referenciapoblacion.condicion||' order by 1 ';
        else
            lv_sql := lv_sql||' order by 1 ';
        end if;

		P_SQL := lv_sql ;

    END SP_SQLReferenciaPoblacion ;

	/*PROCEDIMIENTO QUE BORRA LA POBLACIÃƒâ€œN EXISTENTE*/
	PROCEDURE SP_POBLACIONBORRAR (P_IDCUESTIONARIO NUMBER) IS
	BEGIN
		DELETE FROM T_ENCT_CUESTIONARIOPERSONAS WHERE IDCUESTIONARIO = P_IDCUESTIONARIO ;

	END SP_POBLACIONBORRAR;

	/*PROCEDIMIENTO QUE BORRA LA POBLACIÃƒâ€œN SELECCIONADA */
	PROCEDURE SP_POBLACIONBORRAR (P_IDCUESTIONARIO NUMBER, P_SELECCION VARCHAR2) IS
	BEGIN
		DELETE FROM T_ENCT_CUESTIONARIOPERSONAS
		WHERE IDCUESTIONARIO = P_IDCUESTIONARIO
		AND IDPERSONA IN  	( SELECT Column_Value FROM TABLE(Apex_String.Split(P_SELECCION, ':')))	;

	END SP_POBLACIONBORRAR;

	/*Procedimeinto para agregar poblacion*/
	PROCEDURE SP_POBLACIONAGREGAR (P_IDCUESTIONARIO NUMBER, P_SELECCION VARCHAR2 ) IS
    BEGIN

		INSERT INTO T_ENCT_CUESTIONARIOPERSONAS ( IDCUESTIONARIO, IDPERSONA, DESCRIPCION, CORREO, NUMERO )
		( SELECT P_IDCUESTIONARIO, c001 IDPERSONA, c002 NOMBRE, c003 CORREO, 0
			FROM APEX_collections
			WHERE collection_name = 'POBLACION'
			AND c001 IN ( SELECT Column_Value FROM TABLE(Apex_String.Split(P_SELECCION, ':')))
			AND c001 not in ( select idpersona from T_ENCT_CUESTIONARIOPERSONAS where idcuestionario = p_idcuestionario )	);

	END SP_POBLACIONAGREGAR;

	/*Procedimeinto para subir de excel poblacion*/
	PROCEDURE SP_PoblacionSubir (P_IDCUESTIONARIO NUMBER, p_IdTabla VARCHAR2 ) IS
		lr_referenciapoblacion data.vt_enct_referenciapoblacion%rowtype;
        lv_sql varchar2(5000);
        v_COMPANIA varchar2(50);
    BEGIN

        SELECT COMPANIA  INTO v_COMPANIA
        FROM T_ENCT_CUESTIONARIOS WHERE IDCUESTIONARIO=P_IDCUESTIONARIO;

        /*busca en la tabla general los datos para el query*/
        select * into lr_referenciapoblacion from data.vt_enct_referenciapoblacion
        where trim(id) = trim(p_idTabla) and estado = '1' AND COMPANIA=v_COMPANIA;

         /*Armar el query para la consulta */
        lv_sql := ' INSERT INTO T_ENCT_CUESTIONARIOPERSONAS ( IDCUESTIONARIO, IDPERSONA, DESCRIPCION, CORREO, NUMERO )  ( Select '
			||p_idcuestionario||','||lr_referenciapoblacion.ID_NOMBRE_CORREO||', 0 from '||lr_referenciapoblacion.tabla ;


		if length(trim(lr_referenciapoblacion.condicion)) > 5 then
            lv_sql := lv_sql||' where '||lr_referenciapoblacion.condicion||' and ';
        else
            lv_sql := lv_sql||' where ';
        end if;

		lv_sql := lv_sql||substr(lr_referenciapoblacion.ID_NOMBRE_CORREO,0, instr(lr_referenciapoblacion.ID_NOMBRE_CORREO,',')-1 )
		         ||' in ( select TRIM(C02) from DATA.VT_APEX_EXCEL  where TRIM(C02) is not null ) ) ';

		--dbms_output.put_line( lv_sql );
		--se hace la inserciÃƒÂ³n
		execute immediate lv_sql ;

	END SP_PoblacionSubir;


	/*Procedimiento para enviar a ruta de aprobaciÃƒÂ³n el cuestionario*/
	PROCEDURE SP_EnviaRutaAprobacion ( P_ID NUMBER, P_USUARIO VARCHAR2, P_COMPANIA VARCHAR2, P_NOMBRE VARCHAR2,
		P_REFERENCIAPOBLACION VARCHAR2 ) IS  --enviar a flujo
		l_resultado number ;
		lr_dato data.t_enct_cuestionarios%rowtype ;
		ln_existe number := 0;
		lv_error varchar2(2500);
		lv_cuenta number ;
		lv_ruta varchar2(500);

	BEGIN
		/*Valida los datos antes de enviar a ruta de aprobaciÃƒÂ³n el cuestionario*/
		select * into lr_dato from data.t_enct_cuestionarios where idcuestionario = p_id and compania = p_compania;

		if lr_dato.tipo is null then
			ln_existe :=  1 ;
			lv_error := ' El tipo de cuestionario no puede ser nulo ' ;
		end if;

		if lr_dato.nombre is null then
			lv_error := CASE ln_existe
							when 1 then lv_error||', el nombre del cuestionario no puede ser nulo'
							else 'El nombre del cuestionario no puede ser nulo' end ;
			ln_existe :=  1 ;
		end if;

		if lr_dato.frecuencia is null and lr_dato.TIPO = 1 then
			lv_error := CASE ln_existe
							when 1 then lv_error||', la frecuencia del cuestionario no puede ser nulo'
							else 'La frecuencia del cuestionario no puede ser nulo' end ;
			ln_existe :=  1 ;
		end if;

		if (lr_dato.fechadesde is null or lr_dato.fechahasta is null) and  lr_dato.TIPO = 1 then
			lv_error := CASE ln_existe
							when 1 then lv_error||', las fechas del cuestionario no puede ser nulo'
							else 'Las fechas del cuestionario no puede ser nulo' end ;
			ln_existe :=  1 ;
		elsif lr_dato.fechadesde < trunc(sysdate) and lr_dato.TIPO = 1 then
			lv_error := CASE ln_existe
							when 1 then lv_error||', la fechas desde del cuestionario no puede ser menor que hoy'
							else 'La fecha desde del cuestionario no puede ser menor que hoy' end ;
			ln_existe :=  1 ;
		elsif lr_dato.fechadesde > lr_dato.fechahasta and lr_dato.TIPO = 1 then
			lv_error := CASE ln_existe
							when 1 then lv_error||', la fechas desde no puede ser mayor que la fecha hasta '
							else 'La fechas desde no puede ser mayor que la fecha hasta' end ;
			ln_existe :=  1 ;
		end if;

		if lr_dato.tipoejecucion is null and lr_dato.TIPO = 1 then
			lv_error := CASE ln_existe
							when 1 then lv_error||', el tipo de ejecucion del cuestionario no puede ser nulo'
							else 'El tipo de ejecucion del cuestionario no puede ser nulo' end ;
			ln_existe :=  1 ;
		end if;

		if lr_dato.referenciapoblacion is null and lr_dato.TIPO = 1 then
			lv_error := CASE ln_existe
							when 1 then lv_error||', la referencia a la poblacion del cuestionario no puede ser nulo'
							else 'La referencia a la poblacio del cuestionario no puede ser nulo' end ;
			ln_existe :=  1 ;
		end if;

		lv_cuenta := 0;
		select count(1) into lv_cuenta from T_ENCT_CUESTIONARIOPREGUNTAS where idcuestionario = p_id ;

		if nvl(lv_cuenta,0)= 0 and lr_dato.TIPO = 1 then
			lv_error := CASE ln_existe
							when 1 then lv_error||', el cuestionario debe tener al menos una pregunta'
							else 'El cuestionario debe tener al menos una pregunta' end ;
			ln_existe :=  1 ;
		end if;

		lv_cuenta := 0;
		select count(1) into lv_cuenta from T_ENCT_CUESTIONARIOPERSONAS where idcuestionario = p_id ;

		if nvl(lv_cuenta,0)= 0 and lr_dato.TIPO = 1 then
			lv_error := CASE ln_existe
							when 1 then lv_error||', el cuestionario debe tener al menos una persona '
							else 'El cuestionario debe tener al menos una persona' end ;
			ln_existe :=  1 ;
		end if;

		/*Si encontro algun error envia el error*/
		IF(ln_existe = 1) THEN
            RAISE_APPLICATION_ERROR(-20000,lv_error);
        END IF;

		/*Verifica si se debe enviar a ruta*/
		/*busca en la tabla general los datos para el query*/
        if lr_dato.TIPO = 1 then
            begin
                select ruta into lv_ruta from data.vt_enct_referenciapoblacion
                where trim(id) = trim(lr_dato.referenciapoblacion) and estado = '1'
                and compania = p_compania ;
                exception
                    when others then lv_ruta := '0' ;
            end;
        else
           lv_ruta := '0' ;
        end if;
		if lv_ruta = '1' then
			DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJOENVIAR(
                p_id=> P_ID,
                p_objeto=> 'T_ENCT_CUESTIONARIOS',
                p_objetodescripcion=>'Cuestionario: '||P_NOMBRE ,
                p_usuario=> P_USUARIO,
                p_modulo=>G_MODULO,
                p_compania=>P_COMPANIA,
				P_TIPO1=> 'CUESTIONARIO',
                P_TIPO2=> P_REFERENCIAPOBLACION,
                p_exito =>  l_resultado);

			IF(l_resultado=0) THEN
				RAISE_APPLICATION_ERROR(-20100,data.PK_CORP_FLUJOAPROBACION.G_MENSAJE);
			END IF;

			update 	T_ENCT_CUESTIONARIOS
			set estado = 2 --enviado a ruta
			where idcuestionario = p_id and compania = p_compania;
		else
			/*No se debe enviar a ruta se aprueba*/
			--se actualiza el estado de los resgistors
			update data.T_ENCT_CUESTIONARIOS
			set estado = 1
			where idcuestionario = p_id and compania = p_compania ;

			DATA.PK_ENCT_ENCUESTA.SP_EncuestaGenerar  (  p_idcuestionario => p_id );
		end if ;

	END SP_EnviaRutaAprobacion ;

	/*Procedimiento para aprobar los cuestionarios */
	PROCEDURE SP_AprobarCuestionario ( P_IDCUESTIONARIO NUMBER, P_USUARIO VARCHAR2, P_COMPANIA VARCHAR2, P_COMENTARIO VARCHAR2,
	                             P_COMENTARIO_DIRIGIDO VARCHAR2 DEFAULT NULL, P_ESTADO NUMBER ) IS
		v_exito number;
		v_terminaflujo  number ;
	BEGIN
		--Se realiza la aprobacion/rechazo
        if p_estado = 1 then --aprobado
            data.pk_corp_flujoaprobacion.sp_flujoaprobar(
                    p_id            => 	p_idcuestionario ,
                    p_objeto        =>  'T_ENCT_CUESTIONARIOS',
                    p_ordenmonto    => null,
                    p_usuarioflujo  => p_usuario,
                    p_usuario       => p_usuario,
                    p_comentario    => p_comentario,
                    p_comentario_usuarios => p_comentario_dirigido,
                    p_modulo        => g_modulo,
                    p_compania      => p_compania,
                    p_exito         => v_exito ,
                    p_terminoflujo  => v_terminaflujo
            );

            If v_exito = 0 then
                raise_application_error(-20000, data.pk_corp_flujoaprobacion.g_mensaje);
            end if;
			--si terminaron las aprobaciones
			if (v_terminaflujo = 1 ) then
				--se actualiza el estado de los resgistors
				update data.T_ENCT_CUESTIONARIOS
				set estado = 1
				where idcuestionario = p_idcuestionario and compania = p_compania ;

				DATA.PK_ENCT_ENCUESTA.SP_EncuestaGenerar  (  p_idcuestionario => P_IDCUESTIONARIO );
			end if;

        elsif p_estado = -1 then     --rechazado

            Data.pk_corp_flujoaprobacion.sp_flujorechazar(
                p_id  => p_idcuestionario ,
                p_objeto => 'T_ENCT_CUESTIONARIOS',
                p_usuarioflujo => p_usuario,
                p_usuario => p_usuario,
                p_comentario => p_comentario,
                p_comentario_usuarios => p_comentario_dirigido,
                p_modulo => g_modulo,
                p_compania => p_compania,
                p_exito => v_exito
            );

            If v_exito = 0 then
                raise_application_error(-20000, data.pk_corp_flujoaprobacion.g_mensaje);
            end if;

			update data.T_ENCT_CUESTIONARIOS
				set estado = -1
				where idcuestionario = p_idcuestionario and compania = p_compania ;

        end if;

	END SP_AprobarCuestionario ;

    /*Procedimeinto para agregar poblacion*/
	PROCEDURE SP_ENCUESTADORAGREGAR (P_IDCUESTIONARIO NUMBER, P_SELECCION VARCHAR2 ) IS
    BEGIN

		INSERT INTO T_ENCT_CUESTIONARIOENCUESTADOR ( IDCUESTIONARIO, USUARIO, NOMBRES, FECHACREACION )
		( SELECT P_IDCUESTIONARIO, USUARIO, NOMBREUSUARIO, SYSDATE
			FROM DATA.VT_MVZM_USUARIO
			WHERE ESTADOUSUARIO = 1
			AND USUARIO IN ( SELECT Column_Value FROM TABLE(Apex_String.Split(P_SELECCION, ':')))
			AND USUARIO not in ( select USUARIO from T_ENCT_CUESTIONARIOENCUESTADOR where IDCUESTIONARIO = p_idcuestionario )	);

	END SP_ENCUESTADORAGREGAR;

	 /*PROCEDIMIENTO QUE BORRA LOS ENCUENSTADORES EXISTENTE*/
	PROCEDURE SP_ENCUESTADORBORRAR (P_IDCUESTIONARIO NUMBER) IS
	BEGIN
		DELETE FROM T_ENCT_CUESTIONARIOENCUESTADOR WHERE IDCUESTIONARIO = P_IDCUESTIONARIO ;

	END SP_ENCUESTADORBORRAR;

    /*PROCEDIMIENTO QUE BORRA LOS ENCUESTADORES SELECCIONADOS */
	PROCEDURE SP_ENCUESTADORBORRAR (P_IDCUESTIONARIO NUMBER, P_SELECCION VARCHAR2) IS
	BEGIN
		DELETE FROM T_ENCT_CUESTIONARIOENCUESTADOR
		WHERE IDCUESTIONARIO = P_IDCUESTIONARIO
		AND USUARIO IN  	( SELECT Column_Value FROM TABLE(Apex_String.Split(P_SELECCION, ':')))	;

	END SP_ENCUESTADORBORRAR;

	 PROCEDURE SP_SUBIRBANCOPREGUNTAS(P_IDCUESTIONARIO NUMBER,P_EXITO OUT NUMBER,P_MENSAJE OUT VARCHAR2)as
    v_contador number;
    v_existe number;
    v_cont number;
    begin
        select count(1) into v_contador FROM vt_apex_excel ;
        if (v_contador>0)then
            select count(distinct 1) into v_existe from all_objects where object_name ='T_TMP_EJMC';
            if (v_existe=0)then execute IMMEDIATE 'create table T_TMP_EJMC as select  E.* from vt_apex_excel E';DBMS_OUTPUT.PUT_LINE('creada');end if;
            select count(distinct 1) into v_existe from all_objects where object_name ='T_TMP_EJMC';
            if (v_existe=1)then
                EXECUTE IMMEDIATE 'TRUNCATE TABLE T_TMP_EJMC DROP STORAGE';
                EXECUTE IMMEDIATE 'insert into T_TMP_EJMC select  E.* from vt_apex_excel E';commit;
                DBMS_OUTPUT.PUT_LINE('insertada');
            end if;

            select count(distinct 1 ) INTO v_contador from vt_apex_excel where C05 in ('SUNI','SMULT') AND C06 IS NULL;
            IF (V_CONTADOR=1) THEN
                P_MENSAJE :=' Si los tipos de respuesta son SUNI Ã³ SMULT en la columna respuesta debe tener un valor.';
                P_EXITO :=0;
                RETURN;
            END IF;
            select count(distinct 1) into v_contador from  vt_apex_excel where c02   not in (select distinct c02  from  vt_apex_excel where c03 is null);
            IF (V_CONTADOR=1) THEN
                P_MENSAJE :='Debe parametrizar una pregunta padre';
                P_EXITO :=0;
                RETURN;
            END IF;
            begin
                for prg_pad in (
                    select IDPREGUNTA,  data.PK_COMMONS.F_SECUENCIA ('T_ENCT_CUESTIONARIOPREGUNTAS') p_idp,
                    P_IDCUESTIONARIO IDCUESTIONARIO,rownum orden_padre
                    from (SELECT distinct to_number(c02) IDPREGUNTA FROM  vt_apex_excel ORDER BY to_number(c02)   )
                    order by IDPREGUNTA
                )
                loop

                    DBMS_OUTPUT.PUT_LINE('IDPREGUNTA:'||prg_pad.IDPREGUNTA||', p_idp:'||prg_pad.p_idp||', IDCUESTIONARIO:'||prg_pad.IDCUESTIONARIO ||', orden_padre:'||prg_pad.orden_padre);
                    Insert into T_ENCT_CUESTIONARIOPREGUNTAS (IDPREGUNTA, IDCUESTIONARIO, ORDEN, ORDENHIJA, IDPADRE, RESPUESTAPADRE, REFERENCIATABLA, REFERENCIAID, REFERENCIADESCRIPCION, DESCRIPCION, TIPORESPUESTA, RESPUESTA, EVIDENCIA)
                        select
                            prg_pad.p_idp IDPREGUNTA, prg_pad.IDCUESTIONARIO IDCUESTIONARIO, prg_pad.orden_padre ORDEN,null ORDENHIJA,null IDPADRE,null RESPUESTAPADRE,C08  REFERENCIATABLA,
                            C09 REFERENCIAID,C10 REFERENCIADESCRIPCION,c04 DESCRIPCION,C05 TIPORESPUESTA,C06 RESPUESTA,0  EVIDENCIA
                        from vt_apex_excel
                        where to_number(c02) = prg_pad.IDPREGUNTA and nvl(C03,0)=0
                        ORDER BY to_number(c02);
                    v_cont:=SQL%ROWCOUNT;
                    DBMS_OUTPUT.PUT_LINE('Registros afectados:'||v_cont);

                    Insert into T_ENCT_CUESTIONARIOPREGUNTAS (IDPREGUNTA, IDCUESTIONARIO, ORDEN, ORDENHIJA, IDPADRE, RESPUESTAPADRE, REFERENCIATABLA, REFERENCIAID, REFERENCIADESCRIPCION, DESCRIPCION, TIPORESPUESTA, RESPUESTA, EVIDENCIA)
                        select
                            data.PK_COMMONS.F_SECUENCIA ('T_ENCT_CUESTIONARIOPREGUNTAS') IDPREGUNTA, prg_pad.IDCUESTIONARIO IDCUESTIONARIO, prg_pad.orden_padre ORDEN,
                            --ROW_NUMBER() OVER (PARTITION BY C02 ORDER BY  C03 )
                           ROWNUM ORDENHIJA, prg_pad.p_idp  IDPADRE,C07 RESPUESTAPADRE,C08  REFERENCIATABLA,
                            C09 REFERENCIAID,C10 REFERENCIADESCRIPCION,c04 DESCRIPCION,C05 TIPORESPUESTA,C06 RESPUESTA,0  EVIDENCIA
                        from vt_apex_excel
                        where to_number(c02) = prg_pad.IDPREGUNTA and nvl(C03,0)!=0
                        ORDER BY to_number(C03);
                    v_cont:=SQL%ROWCOUNT;
                    DBMS_OUTPUT.PUT_LINE('Registros afectados:'||v_cont);
                    DBMS_OUTPUT.PUT_LINE(':::::::::::::::::::::::::::::::::::::::::::');
                    commit;
                end loop;
                P_MENSAJE :='Datos Importados con exito.';
                P_EXITO :=1;
            exception when  others then
                P_MENSAJE :='error al importar datos de banco de preguntas.';
                P_EXITO :=0;
            end;
        else
            P_MENSAJE :='Debe seleccionar archivo con datos para la importaciÃ³n.';
            P_EXITO :=0;
        end if;
    end SP_SUBIRBANCOPREGUNTAS;
















/* Reemplaza las preguntas de precio del cuestionario con los codigos del Excel cargado. */
PROCEDURE SP_SUBIR_PREGUNTAS_PRECIO(P_IDCUESTIONARIO NUMBER,P_COMPANIA VARCHAR2,P_USUARIO VARCHAR2,P_EXITO OUT NUMBER,P_MENSAJE OUT VARCHAR2) IS
  V_CANTIDAD NUMBER := 0;
  V_ORDEN_BASE NUMBER := 0;
  V_ID_BASE NUMBER := 0;
  V_CODIGOS NUMBER := 0;
  V_VALIDOS NUMBER := 0;
  V_PRODUCTO VARCHAR2(1500);
  V_FALTANTES VARCHAR2(3000) := NULL;
  V_CODIGOBARRA VARCHAR2(100);
  TYPE T_TEXT IS TABLE OF VARCHAR2(1500) INDEX BY PLS_INTEGER;
  TYPE T_NUMBER IS TABLE OF NUMBER INDEX BY PLS_INTEGER;
  V_CODIGOS_VALIDOS T_TEXT;
  V_PRODUCTOS_VALIDOS T_TEXT;
  V_FILAS_ORIGEN_VALIDAS T_NUMBER;
BEGIN
  P_EXITO := 0;
  P_MENSAJE := NULL;

  IF P_IDCUESTIONARIO IS NULL THEN
    P_MENSAJE := 'No se recibio el cuestionario para cargar preguntas de precio.';
    RETURN;
  END IF;

  IF NULLIF(TRIM(P_COMPANIA), '') IS NULL THEN
    P_MENSAJE := 'No se recibio la compania activa para cargar preguntas de precio.';
    RETURN;
  END IF;

  /* Valida los codigos antes de reemplazar las preguntas actuales. */
  FOR R IN (
    SELECT TRIM(C02) CODIGOBARRA,
           MIN(TO_NUMBER(C01)) FILA_ORIGEN
      FROM DATA.VT_APEX_EXCEL
     WHERE NULLIF(TRIM(C02), '') IS NOT NULL
       AND UPPER(TRIM(C02)) NOT IN ('CODIGOBARRA', 'CODIGO_BARRA', 'CODIGO BARRA')
     GROUP BY TRIM(C02)
     ORDER BY MIN(TO_NUMBER(C01))
  ) LOOP
    V_CODIGOS := V_CODIGOS + 1;
    V_CODIGOBARRA := R.CODIGOBARRA;
    BEGIN
      SELECT NOMBREPRODUCTO
        INTO V_PRODUCTO
        FROM (
          SELECT TRIM(NOMBREPRODUCTO) NOMBREPRODUCTO, 1 PRIORIDAD
            FROM DATA.VT_GZM_PRODUCTO
           WHERE TRIM(CODIGOBARRA) = V_CODIGOBARRA
             AND TRIM(COMPANIA) = TRIM(P_COMPANIA)
          UNION ALL
          SELECT TRIM(NOMBREPRODUCTO) NOMBREPRODUCTO, 2 PRIORIDAD
            FROM DATA.T_INTC_COMPETENCIA_PRODUCTO
           WHERE TRIM(CODIGOBARRA) = V_CODIGOBARRA
             AND TRIM(COMPANIA) = TRIM(P_COMPANIA)
        )
      WHERE NOMBREPRODUCTO IS NOT NULL
       ORDER BY PRIORIDAD
       FETCH FIRST 1 ROW ONLY;
      V_CANTIDAD := V_CANTIDAD + 1;
      V_CODIGOS_VALIDOS(V_CANTIDAD) := V_CODIGOBARRA;
      V_PRODUCTOS_VALIDOS(V_CANTIDAD) := V_PRODUCTO;
      V_FILAS_ORIGEN_VALIDAS(V_CANTIDAD) := R.FILA_ORIGEN;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        V_FALTANTES := SUBSTR(V_FALTANTES || CASE WHEN V_FALTANTES IS NULL THEN '' ELSE ', ' END || V_CODIGOBARRA, 1, 3000);
    END;
  END LOOP;

  IF V_CODIGOS = 0 THEN
    P_MENSAJE := 'El archivo no contiene codigos de barra para cargar preguntas de precio.';
    RETURN;
  END IF;

  IF V_CANTIDAD = 0 THEN
    P_MENSAJE := 'No se encontraron productos validos para cargar preguntas de precio.';
    IF V_FALTANTES IS NOT NULL THEN
      P_MENSAJE := P_MENSAJE || ' Codigos sin producto para la compania activa: ' || V_FALTANTES;
    END IF;
    RETURN;
  END IF;

  /* Conserva preguntas de otros tipos y reemplaza solo las asociadas a precios. */
  DELETE FROM DATA.T_ENCT_CUESTIONARIOPREGUNTAS
   WHERE IDCUESTIONARIO = P_IDCUESTIONARIO
     AND UPPER(TRIM(REFERENCIATABLA)) = 'PRECIOS';

  SELECT NVL(MAX(ORDEN), 0)
    INTO V_ORDEN_BASE
    FROM DATA.T_ENCT_CUESTIONARIOPREGUNTAS
   WHERE IDCUESTIONARIO = P_IDCUESTIONARIO;

  SELECT NVL(MAX(IDPREGUNTA), 0)
    INTO V_ID_BASE
    FROM DATA.T_ENCT_CUESTIONARIOPREGUNTAS;

  /* Inserta las preguntas validadas en la posición original del Excel. */
  V_VALIDOS := V_CANTIDAD;
  V_CANTIDAD := 0;
  FOR I IN 1 .. V_VALIDOS LOOP
    V_CANTIDAD := V_CANTIDAD + 1;
    INSERT INTO DATA.T_ENCT_CUESTIONARIOPREGUNTAS
    (
      IDPREGUNTA, IDCUESTIONARIO, ORDEN, ORDENHIJA, IDPADRE, RESPUESTAPADRE,
      REFERENCIATABLA, REFERENCIAID, REFERENCIADESCRIPCION, DESCRIPCION,
      TIPORESPUESTA, RESPUESTA, EVIDENCIA
    )
    VALUES
    (
      V_ID_BASE + V_CANTIDAD,
      P_IDCUESTIONARIO, V_ORDEN_BASE + V_FILAS_ORIGEN_VALIDAS(I), NULL, NULL, NULL,
      'PRECIOS', V_CODIGOS_VALIDOS(I), V_PRODUCTOS_VALIDOS(I),
      'Cual es el precio del producto ' || V_PRODUCTOS_VALIDOS(I) || '?',
      'NUM', NULL, 0
    );
  END LOOP;

  COMMIT;
  P_EXITO := 1;
  P_MENSAJE := 'Preguntas de precio reemplazadas: ' || V_CANTIDAD || '.';
  IF V_FALTANTES IS NOT NULL THEN
    P_MENSAJE := P_MENSAJE || ' Codigos sin producto: ' || V_FALTANTES;
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    P_EXITO := 0;
    P_MENSAJE := 'Error al cargar preguntas de precio: ' || SQLERRM;
END SP_SUBIR_PREGUNTAS_PRECIO;


END PK_ENCT_CUESTIONARIO;
/
