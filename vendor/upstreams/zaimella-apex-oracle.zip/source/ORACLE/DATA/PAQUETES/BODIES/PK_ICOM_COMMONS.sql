﻿prompt Esquema DATA para codigo PL/SQL
alter session set current_schema=DATA;

prompt PROD PACKAGE_BODY DATA.PK_ICOM_COMMONS

  CREATE OR REPLACE EDITIONABLE PACKAGE BODY PK_ICOM_COMMONS AS

    /*Busca aprobador para la aprobacion en la ruta
    */
    
    V_COMPANIA	varchar2(5);    
    
    procedure sp_supervisor(P_ID NUMBER, P_TIPO NUMBER DEFAULT 1) AS
    BEGIN 
          DELETE T_TMP_B;
         insert into T_TMP_B (txt01, txt02)
                      SELECT NOMBREUSUARIO EJECUTIVO, PK_EVOLUTION_EMPLEADO.F_RETORNASUPERVISOR(NOMBREUSUARIO) SUPERVISOR
                        FROM DATA.T_ICOM_INVERSIONES  I
                        INNER JOIN T_ICOM_INVERSION_CLIENTE_G C ON (I.ID=C.IDINVERSION)
                        INNER JOIN VT_GZM_CLIENTE G ON (C.CODIGOGRUPO=G.CODIGOCLIENTE)
                        INNER JOIN VT_CORP_USUARIO U ON (U.NUMEROIDENTIFICACION=ejecutivo)
                        WHERE (
                        (P_TIPO=1 AND (I.ID=P_ID or I.IDGRUPO=P_ID))
                        OR (P_TIPO=2 AND I.ID=P_ID)
                        ); 
                        
         COMMIT;               
    
    END;
    
    FUNCTION F_BUSCAR_APROBADOR(P_ETAPA NUMBER, P_NIVEL NUMBER , P_ID VARCHAR,
    P_USUARIOINICIADOR VARCHAR, P_USUARIOACTUAL VARCHAR) RETURN VARCHAR 
    is pragma autonomous_transaction;
    V_USUARIO VARCHAR(250);
    V_CREADOR VARCHAR(250);
    V_DEPARTAMENTO VARCHAR(250);
    V_ANALISTA VARCHAR(250);
    V_ORIGEN VARCHAR(250);
    V_AREA VARCHAR(250);
    V_INVERSIONTIPO VARCHAR(250);
    V_ID VARCHAR(250);
    V_CODIGOGRUPO VARCHAR(250);
    V_CONTADOR NUMBER;
    V_FORMA_PAGO NUMBER;
    BEGIN
        commit;
        /*OBTENER LA COMPANIA DE LA INVERSION*/
        IF(P_ETAPA IN (1,4,5,6)) THEN 
            select  max(compania) into  v_compania from data.t_icom_inversiones
            where id = P_ID and rownum=1;
        
        ELSIF (P_ETAPA=7) THEN 
            select  max(i.compania) into  v_compania from 
            data.t_icom_inversiones I
            INNER JOIN t_icom_cliente_validacion v on (i.id=v.idinversion) 
            where v.idagrupacion = P_ID and rownum=1;
        
        ELSIF (P_ETAPA=2) THEN 
            select  max(i.compania) into  v_compania from 
            data.t_icom_inversiones I
            INNER JOIN T_ICOM_INVERSION_CLIENTE_G C on (i.id=C.idinversion) 
            where C.idinversion||'-'||C.codigogrupo  = P_ID and rownum=1;
        END IF;
        
        IF(P_ETAPA=1) THEN  --PROPUESTA 
        
            SELECT USUARIO,CODDEPARTAMENTO, F_ANALISTA(idInversionTipo, idArea,i.COMPANIA), IDORIGEN, IDINVERSIONTIPO, IDAREA
            INTO V_CREADOR, V_DEPARTAMENTO,V_ANALISTA,V_ORIGEN, V_INVERSIONTIPO, V_AREA
            FROM T_ICOM_INVERSIONES i
            LEFT JOIN VT_CORP_USUARIO U ON (USUARIO=NOMBREUSUARIO)
            WHERE ID=P_ID;
        
            --- P_NIVEL=1 SUPERVISOR DEL CREADOR (GERENTE O JEFE DEL AREA DE MERCADEO)
            --- P_NIVEL=2 SI ES DEL AREA DE MERCADEO SUPERVISOR DEL NIVEL 1 (GERENTE DE MERCADEO)
            IF(P_NIVEL in (1,2) and V_COMPANIA='00001') THEN 
            
                SELECT NVL(MAX(u2.nombreusuario),P_USUARIOINICIADOR) INTO V_USUARIO 
                FROM VT_CORP_USUARIO U
                    LEFT JOIN Evolution.hr_1 A ON (U.CODIGOSISTEMA=A.codigo)
                    LEFT JOIN Evolution.hr_1 B ON (B.codigo=A.ID_SUPERVISOR)
                    LEFT JOIN VT_CORP_USUARIO U2 ON  (U2.CODIGOSISTEMA=B.codigo)
                    WHERE NVL(B.ID_SUPERVISOR,0) NOT IN (0,1) AND
                    U.nombreusuario=
                    CASE
                        WHEN P_NIVEL=1 THEN
                            V_CREADOR
                        WHEN P_NIVEL=2 AND V_DEPARTAMENTO='DCO226' THEN
                            P_USUARIOACTUAL
                        ELSE
                            ''
                        END
                    AND U.COMPANIA = V_COMPANIA;
                    
            ELSIF (P_NIVEL=3) THEN-- EVALUADOR
                V_USUARIO := V_ANALISTA;
            
            ELSIF (P_NIVEL BETWEEN 4 AND 8 and V_COMPANIA='00001') THEN-- ORIGEN
                
                --- (ECUADOR) GERENTE ORIGEN TRADE O FABRICA, (PERU) GERENTE DE PERU U OPERACIONES COMERCIALES
                SELECT  NVL(MAX(APROBADOR),P_USUARIOINICIADOR) 
                INTO V_USUARIO 
                FROM DATA.T_ICOM_INVERSIONES  I
                INNER JOIN VT_ICOM_APROBADOR_RUTA U ON (ETAPA=P_ETAPA AND U.IDORIEN=I.IDORIGEN AND U.compania=i.compania)
                WHERE (I.ID=P_ID or I.IDGRUPO=P_ID)  AND  NIVEL=P_NIVEL;
                
                SELECT COUNT(1) INTO V_CONTADOR  FROM VT_ICOM_AREA 
                WHERE (DESCRIPCION LIKE 'VENTA%' OR DESCRIPCION LIKE 'TRAD%' ) AND IDAREA=V_AREA AND compania=V_COMPANIA;
                
                ---GERENTE DE VENNTA Y TRADE
                IF (P_NIVEL = 6 AND V_CONTADOR>0 and V_COMPANIA='00001') THEN 
                    select APROBADOR INTO V_USUARIO
                    from VT_ICOM_APROBADOR_RUTA WHERE NIVEL=P_NIVEL AND ETAPA=1 AND COMPANIA=V_COMPANIA;
                END IF;
                
                IF(V_USUARIO=P_USUARIOINICIADOR)   THEN  
                ---GERENTE DEL EJECUTIVO DEL CLIENTE
                     dbms_output.put_line( 'P_USUARIOINICIADOR '|| P_USUARIOINICIADOR
                     || ' P_ID '|| P_ID || ' P_ETAPA '|| P_ETAPA || ' P_NIVEL '|| P_NIVEL||' V_COMPANIA '||V_COMPANIA );
                  -- sp_supervisor(P_ID); 
                    DELETE  T_TMP_B;
                    insert into T_TMP_B (txt01, txt02)
                      SELECT NOMBREUSUARIO EJECUTIVO, PK_EVOLUTION_EMPLEADO.F_RETORNASUPERVISOR(NOMBREUSUARIO) SUPERVISOR
                        FROM DATA.T_ICOM_INVERSIONES  I
                        INNER JOIN T_ICOM_INVERSION_CLIENTE_G C ON (I.ID=C.IDINVERSION)
                        INNER JOIN VT_GZM_CLIENTE G ON (C.CODIGOGRUPO=G.CODIGOCLIENTE)
                        INNER JOIN VT_CORP_USUARIO U ON (U.NUMEROIDENTIFICACION=ejecutivo)
                        WHERE I.ID=P_ID; 
                    COMMIT; 
                  
                   WITH INVERSION_EJECUTIVOS AS (
                       SELECT txt01 EJECUTIVO, txt02 SUPERVISOR
                        FROM DATA.T_TMP_B 
                   )
                   select NVL(MAX(APROBADOR),P_USUARIOINICIADOR)  INTO V_USUARIO
                   from VT_ICOM_APROBADOR_RUTA A
                   INNER JOIN INVERSION_EJECUTIVOS B ON (APROBADOR=SUPERVISOR) 
                   WHERE ETAPA=P_ETAPA AND NIVEL=P_NIVEL AND compania=V_COMPANIA;
                    
                  
                END IF;
                
             ELSIF (P_NIVEL=9) THEN-- SI EXISTE CLIENTE DE REPUBLICA DOMINICANA APRUEBA 
             
                SELECT  NVL(MAX(APROBADOR),P_USUARIOINICIADOR)  APROBADOR INTO V_USUARIO
                FROM VT_ICOM_APROBADOR_RUTA WHERE ETAPA=P_ETAPA AND  NIVEL=P_NIVEL AND compania=V_COMPANIA AND EXISTS (
                        SELECT 1
                            FROM DATA.T_ICOM_INVERSIONES  I
                            INNER JOIN T_ICOM_INVERSION_CLIENTE_G C ON (I.ID=C.IDINVERSION)
                            INNER JOIN VT_GZM_CLIENTE G ON (C.CODIGOGRUPO=G.CODIGOCLIENTE)
                            WHERE (I.ID=P_ID or I.IDGRUPO=P_ID) AND CODIGOPAIS='DO');
                            
            ELSIF (P_NIVEL=12) THEN-- SI ES PLAN COMERCIAL/CONVENIOS APRUEBA PRESIDENTE
            --    V_USUARIO := CASE WHEN V_INVERSIONTIPO IN (4,5) THEN 'GDIMELLA' ELSE P_USUARIOINICIADOR END;
                V_USUARIO:=P_USUARIOINICIADOR;
            END IF;
            
            IF(V_COMPANIA='00003' AND P_NIVEL<>3)   THEN  
            
                        select nvl(MAX(APROBADOR), P_USUARIOINICIADOR) INTO V_USUARIO
                        from VT_ICOM_APROBADOR_RUTA WHERE NIVEL=P_NIVEL AND ETAPA=P_ETAPA 
                        AND (NVL(IDORIEN,0)=NVL(V_ORIGEN,0) ) AND COMPANIA=V_COMPANIA ;
                        
            END IF;
            
       
        ELSIF(P_ETAPA IN (2,4,7) AND P_NIVEL IN (1,2)) THEN  --COORDINADOR TABLA  GENERAL PARA NEOCIACION, CIERRE Y VALIDACION.
             
            SELECT  NVL(MAX(APROBADOR),P_USUARIOINICIADOR)  APROBADOR INTO V_USUARIO
            FROM VT_ICOM_APROBADOR_RUTA WHERE ETAPA=P_ETAPA AND  NIVEL=P_NIVEL AND compania=V_COMPANIA; 
            
        ELSIF(P_ETAPA=2 AND P_NIVEL=3) THEN  --NEGOCIACION 
                       
             IF (P_NIVEL=3) THEN-- 
                
                SELECT ELEMENTO INTO V_CODIGOGRUPO
                FROM (  WITH datos AS ( SELECT P_ID AS cadena_texto FROM dual)
                SELECT REGEXP_SUBSTR(cadena_texto, '[^-]+', 1, LEVEL) AS elemento, LEVEL NIVEL
                FROM datos CONNECT BY REGEXP_SUBSTR(cadena_texto, '[^-]+', 1, LEVEL) IS NOT NULL) WHERE NIVEL=2;
             
                SELECT max(NOMBREUSUARIO) into V_USUARIO
                FROM VT_GZM_CLIENTE G 
                INNER JOIN VT_CORP_USUARIO U ON (U.NUMEROIDENTIFICACION=ejecutivo)
                WHERE CODIGOCLIENTE=V_CODIGOGRUPO;
                
                SELECT NVL(MAX(u2.nombreusuario),P_USUARIOINICIADOR) INTO V_USUARIO 
                FROM VT_CORP_USUARIO U
                    LEFT JOIN Evolution.hr_1 A ON (U.CODIGOSISTEMA=A.codigo)
                    LEFT JOIN Evolution.hr_1 B ON (B.codigo=A.ID_SUPERVISOR)
                    LEFT JOIN VT_CORP_USUARIO U2 ON  (U2.CODIGOSISTEMA=B.codigo)
                    WHERE NVL(B.ID_SUPERVISOR,0) NOT IN (0,1) AND
                    U.nombreusuario=V_USUARIO;
                
                IF(V_USUARIO IS NULL) THEN 
                    RAISE_APPLICATION_ERROR(-20000, 'Error en configuracion de ejecutivo en cliente');  
                END IF;
        
             END IF;
             
        ELSIF(P_ETAPA IN (5,6) and  V_COMPANIA='00001') THEN  --REPLANIFICACION, CLAUSURA
            
            SELECT USUARIO,CODDEPARTAMENTO, F_ANALISTA(idInversionTipo, idArea,i.COMPANIA), IDORIGEN, IDINVERSIONTIPO INTO
            V_CREADOR, V_DEPARTAMENTO,V_ANALISTA,V_ORIGEN, V_INVERSIONTIPO
            FROM T_ICOM_INVERSIONES i
            LEFT JOIN VT_CORP_USUARIO U ON (USUARIO=NOMBREUSUARIO)
            WHERE ID=P_ID;
            
            IF(P_NIVEL in (2,3)) THEN 
            
                SELECT NVL(MAX(u2.nombreusuario),P_USUARIOINICIADOR) INTO V_USUARIO 
                FROM VT_CORP_USUARIO U
                    LEFT JOIN Evolution.hr_1 A ON (U.CODIGOSISTEMA=A.codigo)
                    LEFT JOIN Evolution.hr_1 B ON (B.codigo=A.ID_SUPERVISOR)
                    LEFT JOIN VT_CORP_USUARIO U2 ON  (U2.CODIGOSISTEMA=B.codigo)
                    WHERE NVL(B.ID_SUPERVISOR,0) NOT IN (0,1) AND
                    U.nombreusuario=
                    CASE WHEN P_NIVEL=2 THEN 
                        V_CREADOR 
                    WHEN P_NIVEL=3 AND V_DEPARTAMENTO='DCO226' THEN 
                        P_USUARIOACTUAL 
                    END;
                    
             ELSIF (P_NIVEL BETWEEN 4 AND 7) THEN-- ORIGEN
                
                --- GERENTE ORIGEN TRADE O FABRICA
                SELECT  NVL(MAX(APROBADOR),P_USUARIOINICIADOR) 
                INTO V_USUARIO 
                FROM DATA.T_ICOM_INVERSIONES  I
                INNER JOIN VT_ICOM_APROBADOR_RUTA U ON (ETAPA=P_ETAPA AND U.IDORIEN=I.IDORIGEN AND u.compania=i.COMPANIA)
                WHERE I.ID=P_ID  AND  NIVEL=P_NIVEL;
                
                IF(V_USUARIO=P_USUARIOINICIADOR)   THEN  
                ---GERENTE DEL EJECUTIVO DEL CLIENTE
                  dbms_output.put_line( 'P_USUARIOINICIADOR '|| P_USUARIOINICIADOR
                     || ' P_ID '|| P_ID || ' P_ETAPA '|| P_ETAPA || ' P_NIVEL '|| P_NIVEL||' V_COMPANIA '||V_COMPANIA );
                     --sp_supervisor(P_ID,2); 
                    DELETE  T_TMP_B;
                    insert into T_TMP_B (txt01, txt02)
                      SELECT NOMBREUSUARIO EJECUTIVO, PK_EVOLUTION_EMPLEADO.F_RETORNASUPERVISOR(NOMBREUSUARIO) SUPERVISOR
                        FROM DATA.T_ICOM_INVERSIONES  I
                        INNER JOIN T_ICOM_INVERSION_CLIENTE_G C ON (I.ID=C.IDINVERSION)
                        INNER JOIN VT_GZM_CLIENTE G ON (C.CODIGOGRUPO=G.CODIGOCLIENTE)
                        INNER JOIN VT_CORP_USUARIO U ON (U.NUMEROIDENTIFICACION=ejecutivo)
                        WHERE I.ID=P_ID; 
                    COMMIT; 
                    
                    SELECT COUNT(1) INTO V_CONTADOR FROM T_TMP_B;
                     dbms_output.put_line( 'V_CONTADOR '|| V_CONTADOR);
                     
                     WITH INVERSION_EJECUTIVOS AS (
                       SELECT txt01 EJECUTIVO, txt02 SUPERVISOR
                        FROM T_TMP_B 
                   )
                   select NVL(MAX(APROBADOR),P_USUARIOINICIADOR)   INTO V_USUARIO
                   from VT_ICOM_APROBADOR_RUTA A
                   INNER JOIN INVERSION_EJECUTIVOS B ON (APROBADOR=SUPERVISOR) 
                   WHERE ETAPA=P_ETAPA AND NIVEL=P_NIVEL AND compania=V_COMPANIA;                       
            
                END IF;

            END IF;
        ELSIF(P_ETAPA IN (5,6) and  V_COMPANIA='00003') THEN  --REPLANIFICACION, CLAUSURA
             select nvl(MAX(APROBADOR), P_USUARIOINICIADOR) INTO V_USUARIO
                        from VT_ICOM_APROBADOR_RUTA WHERE NIVEL=P_NIVEL AND ETAPA=P_ETAPA 
                        AND (IDORIEN=V_ORIGEN ) AND COMPANIA=V_COMPANIA ;
                        
        ELSIF(P_ETAPA=7) THEN  --VALIDACION
        
            select sum(nvl(TOT_VALOREXCEPCION,0)), MAX(IDFORMAPAGO) 
                    into V_CONTADOR, V_FORMA_PAGO
                    from data.t_icom_cliente_validacion
                    where idagrupacion = P_ID ;
            
            IF (P_NIVEL IN (3,4) ) THEN -- SI TIENE EXEPCION SI NO SALTA RUTA 
                SELECT  NVL(MAX(APROBADOR),P_USUARIOINICIADOR)  APROBADOR INTO V_USUARIO
                FROM VT_ICOM_APROBADOR_RUTA WHERE ETAPA=P_ETAPA AND  NIVEL=P_NIVEL AND compania=v_compania
                AND V_CONTADOR>0; 
            END IF;
            
            --- SI ES FORMA DE PAGO NC DEBE APROBAR FINANZAS 
            IF (P_NIVEL=5) THEN 
                IF(V_FORMA_PAGO=3) THEN 
                    V_USUARIO:= PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '30',v_compania ); 
                ELSE 
                    V_USUARIO:=P_USUARIOINICIADOR;
                END IF;
            END IF;

        -- Si es cierre, nivel 3 y es PERU, se asigna el coordinador de operaciones comerciales
        ELSIF (P_ETAPA = 4 AND P_NIVEL = 3 and V_COMPANIA = '00003') THEN
            SELECT  NVL(MAX(APROBADOR),P_USUARIOINICIADOR)  APROBADOR INTO V_USUARIO
            FROM VT_ICOM_APROBADOR_RUTA WHERE ETAPA=P_ETAPA AND  NIVEL=P_NIVEL AND compania=v_compania;
        END IF;

        IF(V_USUARIO IS NULL) THEN 
             RAISE_APPLICATION_ERROR(-20000, 'Error al buscar aprobador'); 
             commit;
        END IF;
        commit;
        
    RETURN V_USUARIO; 
    --EXCEPTION WHEN OTHERS THEN
    --            RAISE_APPLICATION_ERROR(-20000, 'Error al buscar aprobador');    
    END F_BUSCAR_APROBADOR;

    /*Funcion para identificar si el elemento es visible o no. tambien si es obligatorio o no
      @param P_ELEMENTO VARCHAR id elemento
      @param P_INVERSIONTIPO VARCHAR id tipo de inversion
      @param P_TIPO VARCHAR bandera para identificar si es visible 1 o si es obligatorio 2
      @param P_COMPANIA VARCHAR codigo de compania
      RETURN 1 como true y 0 como false
      Modo de uso:
      PK_ICOM_COMMONS.F_ELEMENTO(P_ELEMENTO => P_ELEMENTO, P_INVERSIONTIPO => P_INVERSIONTIPO, P_TIPO => P_TIPO, P_COMPANIA => P_COMPANIA);

    */   
     FUNCTION F_ELEMENTO(P_ELEMENTO VARCHAR, P_INVERSIONTIPO VARCHAR,
        P_TIPO NUMBER DEFAULT 1 , P_COMPANIA VARCHAR) RETURN NUMBER
     AS
     V_CONTADOR NUMBER:=0;
     BEGIN

        SELECT COUNT(1)  INTO  V_CONTADOR FROM VT_ICOM_CONF_INVER_ETAPA_ELEM
            WHERE COMPANIA=P_COMPANIA AND IDINVERSIONTIPO=P_INVERSIONTIPO AND  IDELEMENTO=P_ELEMENTO
            AND ESTADO=1 AND (P_TIPO=1 OR (P_TIPO=2 AND OBLIGATORIO=1));

        IF(V_CONTADOR>0) THEN 
            RETURN 1;
        END IF;

        RETURN V_CONTADOR;

     END F_ELEMENTO;

    /*
    PK_ICOM_COMMONS.F_ANALISTA(P_INVERSIONTIPO => P_INVERSIONTIPO, P_AREA => P_AREA, P_COMPANIA => P_COMPANIA);
    */
    FUNCTION F_ANALISTA(P_INVERSIONTIPO VARCHAR, P_AREA NUMBER, P_COMPANIA VARCHAR) RETURN VARCHAR
    AS
    V_ANALISTA VARCHAR(50);
    BEGIN

        SELECT MAX(IDANALISTA) INTO V_ANALISTA  FROM T_ICOM_CONF_ANALIST_INV_AREA 
        WHERE COMPANIA=P_COMPANIA AND IDAREA=P_AREA AND IDINVERSIONTIPO=P_INVERSIONTIPO
        AND ESTADO = 1 ;

    RETURN V_ANALISTA;

    END F_ANALISTA;

    /*VERIFICA SI LA INVERSION APLICA A TODOS LOS PRODUCTOS
    PK_ICOM_COMMONS.F_PRODUCTO_TODOS(1);
    */
    FUNCTION F_PRODUCTO_TODOS(P_ID NUMBER) RETURN NUMBER
    AS 
    V_CONTADOR NUMBER;
    BEGIN 
      SELECT COUNT(1) INTO V_CONTADOR FROM T_ICOM_INVERSIONES WHERE ID=P_ID AND PRODUCTOTODO=1;

      RETURN V_CONTADOR;
    END  F_PRODUCTO_TODOS;
    /*CALCULA LA DURACION ENTRE FECHAS 
    PK_ICOM_COMMONS.F_DURACION(P_FECHA_INICIO => P_FECHA_INICIO, P_FECHA_FIN => P_FECHA_FIN);
    */
    FUNCTION F_DURACION(P_FECHA_INICIO DATE, P_FECHA_FIN DATE) RETURN NUMBER
    AS
    V_DURACION NUMBER:=0;
    BEGIN
        IF(P_FECHA_INICIO IS NOT NULL AND P_FECHA_FIN IS NOT NULL) THEN 

            V_DURACION := CEIL((P_FECHA_FIN - P_FECHA_INICIO)/31);
         RETURN V_DURACION;

        END IF;

        RETURN V_DURACION;
    END F_DURACION;     

     /*VERIFICA SI TIENE PROCESOS OPERATIVOS
    PK_ICOM_COMMONS.F_TIENEPROCESOS(P_ID => P_ID);
    */
    FUNCTION F_TIENEPROCESOS(P_ID NUMBER)  RETURN NUMBER
    AS
    V_CONTADOR NUMBER;
    BEGIN 
        SELECT COUNT(1) INTO V_CONTADOR FROM T_ICOM_INVERSION_PROCESO WHERE IDINVERSION=P_ID;
        V_CONTADOR := CASE WHEN V_CONTADOR>1 THEN 1 ELSE V_CONTADOR END;

        RETURN V_CONTADOR;

    END F_TIENEPROCESOS;

    /*VERIFICA SI TIENE UN PROCESOS ACTIVO
    PK_ICOM_COMMONS.F_TIENEPROCESOACTIVO(P_ID => P_ID, P_PROCESO => P_PROCESO);
    */
    FUNCTION F_TIENEPROCESOACTIVO(P_ID NUMBER, P_PROCESO NUMBER)  RETURN NUMBER
    AS
    V_CONTADOR NUMBER;
    BEGIN 
        SELECT COUNT(1) INTO V_CONTADOR FROM T_ICOM_INVERSION_PROCESO WHERE IDINVERSION=P_ID AND IDPROCESO=P_PROCESO AND  ESTADO=1;
        V_CONTADOR := CASE WHEN V_CONTADOR>1 THEN 1 ELSE V_CONTADOR END;

        RETURN V_CONTADOR;

    END F_TIENEPROCESOACTIVO;

    /*VERIFICA SI LA INVERSION TIENE NEGOCIACION*/
    FUNCTION F_TIENENEGOCIACION(P_INVERSIONTIPO VARCHAR, P_ORIGEN NUMBER, P_TIPO NUMBER, P_COMPANIA VARCHAR)  RETURN NUMBER
   AS
    V_CONTADOR NUMBER;
    BEGIN 

            SELECT COUNT(*) INTO V_CONTADOR FROM VT_ICOM_CONF_INVER_ORIG_TIPO
            WHERE (IDORIGEN=P_ORIGEN OR (P_ORIGEN IS NULL AND IDORIGEN IS NULL))
            and (IDTIPO=P_TIPO OR (P_TIPO IS NULL AND IDTIPO IS NULL))
            AND (IDINVERSIONTIPO=P_INVERSIONTIPO)
            AND COMPANIA= P_COMPANIA AND NEGOCIACION=1;

        RETURN CASE WHEN V_CONTADOR=0 THEN 0 ELSE 1 END;

    END F_TIENENEGOCIACION; 

     /*OBTIENE FORMA DE PAGO DE UN CLIENTE 
    PK_ICOM_COMMONS.F_FORMAPAGO(P_INVERSIONTIPO => P_INVERSIONTIPO, P_TIPO => P_TIPO, P_CLIENTE=>P_CLIENTE,P_COMPANIA=>P_COMPANIA );
    */
    FUNCTION F_FORMAPAGO(P_INVERSIONTIPO VARCHAR, P_TIPO VARCHAR,
        P_CLIENTE VARCHAR , P_COMPANIA VARCHAR, P_IDORIGEN NUMBER) RETURN VARCHAR 
    AS
    V_FORMAPAGO VARCHAR(5);
    BEGIN 

        SELECT MAX(idformapago) INTO V_FORMAPAGO FROM vt_icom_conf_cliente_tipo_fp  FP
            WHERE compania= P_COMPANIA AND idinversiontipo=P_INVERSIONTIPO 
                AND codigogrupo=P_CLIENTE  AND NVL(FP.IDTIPO, 0)=NVL(P_TIPO, 0) 
                AND  NVL(FP.idorigen, 0)=NVL(P_IDORIGEN, 0) and estado=1 ;

        RETURN V_FORMAPAGO;

    END F_FORMAPAGO;

    /*VERIFICCA SI UNA INVERSION TIENE PDV RETORNA 1/0 (Si/no) 
        PK_ICOM_COMMONS.F_TIENEPDV(124);
    */
    FUNCTION F_TIENEPDV(P_ID NUMBER)  RETURN NUMBER as
    V_CONTADOR NUMBER;
    BEGIN 

    select count(*) 	into v_contador
	from data.t_icom_cliente_pdv where idinversion = P_ID;

    RETURN   CASE WHEN V_CONTADOR > 0 THEN 1 ELSE  0 END;

    END F_TIENEPDV ;

    /*VERIFICCA SI UNA INVERSION TIENE PDV RETORNA 1/0 (Si/no) 
        PK_ICOM_COMMONS.F_TIENEPDV(124);
    */
    FUNCTION F_TIENEPDVLOCAL(P_ID NUMBER)  RETURN NUMBER as
    V_CONTADOR NUMBER;
    BEGIN 

    select count(*) 	into v_contador
	from data.t_icom_cliente_pdv_local where idinversion = P_ID;

    RETURN   CASE WHEN V_CONTADOR > 0 THEN 1 ELSE  0 END;

    END F_TIENEPDVLOCAL ;
    
    /*VERIFICCA SI UNA INVERSION TIENE CLIENTES 1/0 (Si/no) 
        PK_ICOM_COMMONS.F_TIENECLIENTE(124);
    */
    FUNCTION F_TIENECLIENTE(P_ID NUMBER)  RETURN NUMBER
    AS 
     V_CONTADOR NUMBER;
    BEGIN
      select count(*) 	into v_contador
	from data.t_icom_inversion_cliente_g where idinversion = P_ID;

    RETURN   CASE WHEN V_CONTADOR > 0 THEN 1 ELSE  0 END;


    END F_TIENECLIENTE;

    /*VERIFICA SI ES UNA INVERSION PADRE  PK_ICOM_COMMONS.F_ESPADRE(124);*/
    FUNCTION F_ESPADRE(P_ID NUMBER)  RETURN NUMBER AS
     V_CONTADOR NUMBER;
    BEGIN 
        SELECT count(*)  INTO V_CONTADOR FROM T_ICOM_INVERSIONES WHERE ID=P_ID AND GRUPAL=1;

         RETURN   CASE WHEN V_CONTADOR > 0 THEN 1 ELSE  0 END;

    END F_ESPADRE;

   /* CUENTA EL NUMERO DE CONTRATOS QUE CUENTAN CON ETIQUETAS PARA LA GENERACIÃ“N DEL DOCUMENTO BASADO EN EL ID DEL FORMATO DE CONTRATO*/

    FUNCTION F_CONTADORCONTRATOSINVERSION(P_ID NUMBER) RETURN NUMBER
    AS
        v_contador NUMBER;
    BEGIN

        SELECT COUNT(IDCONTRATO) INTO v_contador FROM (
        SELECT DISTINCT IDCONTRATO, IDINVERSION, CODIGOPDV, CODIGOGRUPO
        FROM T_ICOM_CONTRATO_CONTENIDO 
        WHERE IDCONTRATO = P_ID
        GROUP BY IDCONTRATO, IDINVERSION, CODIGOPDV, CODIGOGRUPO)
        GROUP BY IDCONTRATO;

    RETURN v_contador;

    END;

    FUNCTION F_ESEJECUTIVO_INVERSION( P_USUARIO VARCHAR, P_INVERSION NUMBER, P_COMPANIA VARCHAR, P_APROBADOR NUMBER DEFAULT 0) RETURN NUMBER
    AS
    V_CEDULA VARCHAR (100); 
    V_CONTADOR NUMBER;
    BEGIN
        select MAX(NUMEROIDENTIFICACION) INTO V_CEDULA
        from data.VT_CORP_USUARIO where NOMBREUSUARIO=P_USUARIO;


        select count(1) into v_contador
        from T_ICOM_INVERSIONES I 
        INNER JOIN T_ICOM_INVERSION_CLIENTE_G C ON (I.ID=C.idinversion 
        AND (P_APROBADOR=0 OR (P_APROBADOR=1 AND (C.NEGOCIACION IN (0,1) AND C.ESTADO IN (0,1)) )))
        where I.ID = p_inversion AND I.IDETAPA2 IS NULL
        and exists ( select codigocliente from data.VT_GZM_CLIENTE a 
                     where compania = P_COMPANIA
                       and c.codigogrupo=a.codigocliente
                       and ejecutivo = V_CEDULA );
        /*select COUNT(1) Into V_CONTADOR
		from data.VT_GZM_CLIENTE a
        INNER JOIN T_ICOM_INVERSION_CLIENTE_G C ON (C.idinversion = P_INVERSION AND c.codigogrupo=a.codigocliente)
		where ejecutivo = V_CEDULA AND compania = P_COMPANIA;*/

        RETURN   CASE WHEN V_CONTADOR > 0 THEN 1 ELSE  0 END;
    END F_ESEJECUTIVO_INVERSION;

    /*VERIFICA SI EL USUARIO ES EJEUTIVO EN GENERAL O DE UN CLIENTE ESPECIFICO
    PK_ICOM_COMMONS.F_ESEJECUTIVO(P_USUARIO=>JBALCAZAR, P_COMPANIA=>G_COMPANIA)
    */

     FUNCTION F_ESEJECUTIVO( P_USUARIO VARCHAR, P_CLIENTE VARCHAR DEFAULT NULL, P_COMPANIA VARCHAR) RETURN NUMBER
     AS
     V_CONTADOR    NUMBER;
     BEGIN 
        select COUNT(1) Into V_CONTADOR
		from data.VT_GZM_CLIENTE a
		where ejecutivo in (select NUMEROIDENTIFICACION from data.VT_CORP_USUARIO where NOMBREUSUARIO=P_USUARIO)
		and (codigocliente = P_CLIENTE OR P_CLIENTE IS NULL)
		and compania = P_COMPANIA;

         RETURN   CASE WHEN V_CONTADOR > 0 THEN 1 ELSE  0 END;

     END F_ESEJECUTIVO;

      /*VERIFICA SI LOS CAMPOS SON OBLIGATORIOS*/
    PROCEDURE SP_VALIDA_OBLIGATORIO(P_ID NUMBER, P_IDETAPA NUMBER DEFAULT 1) AS
    V_TIPOINVERSION NUMBER;
    V_COMPANIA NUMBER;
    V_QUERY     VARCHAR2 (2500);
    V_CONTADOR    NUMBER;
    BEGIN 

       SELECT IDINVERSIONTIPO, COMPANIA INTO  V_TIPOINVERSION, V_COMPANIA
       FROM T_ICOM_INVERSIONES WHERE ID=P_ID;

        FOR VALIDA IN (SELECT VALOR, ELEMENTO, TIPO FROM VT_ICOM_CONF_INVER_ETAPA_ELEM
        WHERE IDINVERSIONTIPO=V_TIPOINVERSION  AND OBLIGATORIO=1 AND ESTADO=1 AND 
        COMPANIA=V_COMPANIA AND VALOR IS NOT NULL AND IDETAPA=P_IDETAPA) LOOP 

            CONTINUE WHEN VALIDA.VALOR='T_ICOM_INVERSION_PRODUCTO' ;

            IF(VALIDA.TIPO='T') THEN 
                V_QUERY:= 'SELECT count (*) FROM T_ICOM_INVERSIONES 
                WHERE ((ID='||P_ID||' AND GRUPAL=0 ) OR IDGRUPO='||P_ID||' )
                 AND '||VALIDA.VALOR||' IS NOT NULL' ;
            ELSE
                 V_QUERY:= 'SELECT count (*) FROM '|| VALIDA.VALOR|| 
                ' T WHERE EXISTS (SELECT 1 FROM T_ICOM_INVERSIONES I WHERE I.ID =T.IDINVERSION AND 
                 ((ID='||P_ID||' AND GRUPAL=0  ) OR IDGRUPO='||P_ID||' )  )';
            END IF;
            dbms_output.put_line( 'ELEMENTO: '||VALIDA.ELEMENTO ||' query '||v_query  );
            EXECUTE IMMEDIATE V_QUERY INTO V_CONTADOR; 

            IF (V_CONTADOR=0) THEN 
                  raise_application_error(-20000,'Valor obligatorio en: '||VALIDA.ELEMENTO);
            END IF;

        END LOOP;

    END SP_VALIDA_OBLIGATORIO;

    /*
	Procedimiento que valida la existencia de inversiones con los mismos datos  
	Por: CCarrasco
	Fecha: Julio 2022
	*/

	PROCEDURE SP_VALIDA_INVERSION(P_ID NUMBER) AS
	V_CONTADOR		NUMBER;
	BEGIN
        SELECT COUNT(1) into V_CONTADOR from data.t_icom_inversiones A
        WHERE (ID=P_ID OR IDGRUPO=P_ID) AND EXISTS 
        (SELECT 1 FROM T_ICOM_INVERSIONES B WHERE A.ID  <> B.ID AND A.IDTIPO  = B.IDTIPO AND A.IDINVERSIONTIPO  = B.IDINVERSIONTIPO 
        AND   A.IDORIGEN	= A.IDORIGEN AND A.FECHAINICIO	=A.FECHAINICIO 	AND A.FECHAFIN	= A.FECHAINICIO);

        IF(V_CONTADOR>0) THEN
            raise_application_error(-20100, 'Existen inversiones con los mismos datos: TIPO, ORIGEN, FECHAS');
        END IF;

        V_CONTADOR := 0; 
        
        SELECT count(1) into V_CONTADOR
        FROM vt_icom_cliente_pdv v 
             inner join vt_icom_cliente_pdv a on (a.idinversion = P_ID and v.codigopdv = a.codigopdv and v.ruc = a.ruc and  v.CODIGODISTRIBUIDOR = a.CODIGODISTRIBUIDOR   )
        WHERE v.IDETAPA IN (1,2,3)
            AND  v.IDINVERSION <> P_ID
            and nvl(V.CONTRATOAPROBAR,0)<>5
            and v.idinversiontipo = 5 
            and (v.fechainicio between a.fechainicio and a.fechafin 
                 or v.fechafin between a.fechainicio and a.fechafin );

       IF(nvl(V_CONTADOR,0) >0) THEN
            raise_application_error(-20100, 'Existen PDV que se encuentran en otras inversiones');
        END IF;
        
        --si tiene material Pop valida que el proceso este activo
       FOR I IN (select id,compania from t_icom_inversiones I where (I.ID=p_id  OR I.IDGRUPO=p_id) AND GRUPAL=0) LOOP
            
            SELECT COUNT(1) INTO V_CONTADOR FROM t_icom_cliente_material WHERE IDINVERSION=I.ID;
            
            IF(V_CONTADOR>0 and i.compania <> '00003')  THEN --Excluye PERU
            
                SELECT COUNT(1) INTO V_CONTADOR FROM t_icom_inversion_proceso WHERE IDPROCESO=6 AND ESTADO=0 AND IDINVERSION=I.ID; 
                
                 IF(V_CONTADOR>0)  THEN 
                    raise_application_error(-20100, 'La inversion: '||I.ID||' tiene material pop y el proceso de compra esta inactivo.');
                 END IF;
                 
            END IF;
            
       END LOOP;

	END SP_VALIDA_INVERSION;

    /* Funcion que retorna en una cadena de caracteres los productos de la inversion
    * P_ID codigo de la inversion para buscar los productos
    */
    FUNCTION F_PRODUCTOSINVERSION ( P_ID NUMBER ) RETURN VARCHAR2 AS
    v_listanombres varchar2(4000);
    v_todo data.t_icom_inversiones.productotodo%type;
    v_max number ;
    BEGIN
        select productotodo,compania into v_todo,v_compania from data.t_icom_inversiones where id = p_id ;
        if (nvl(v_todo,0) != 1 ) then
            v_max :=nvl(pk_commons.safe_to_number(PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '20', v_COMPANIA ,'','','1')),0);
            if ( v_max > 3990)  then --el limite de sql es 4000
                v_max := 3990;
            end if;    
            select  case when max(total) > v_max then
                        listagg(producto, '; ') within group (order by producto)||'...'
                    else
                        listagg(producto, '; ') within group (order by producto) 
                    end     
            into v_listanombres     
            from ( --Se obtinie los nombres y sus dimenciones para controlar el maximo permitido 
                select producto,
                    --Se aÃ±ade 2 por los caracteres especiales.
                    sum(lengthb(producto) + 2) over (order by producto) cuenta,
                    sum(lengthb(producto) + 2) over () total
                from data.T_ICOM_INVERSION_PRODUCTO
                where idinversion = p_id 
                order by producto
            )
            where cuenta <= v_max;  
            dbms_output.put_line( 'PRODUCTOS '|| V_LISTANOMBRES  );
            return v_listanombres;   
        else
            return 'TODOS';
        end if;
    END;


    /* Funcion que retorna en una cadena de caracteres los clientes de la inversion
    * P_ID codigo de la inversion para buscar los productos
    */
    FUNCTION F_CLIENTESINVERSION ( P_ID NUMBER ) RETURN VARCHAR2 AS
    v_listanombres varchar2(4000);
    v_todo data.t_icom_inversiones.productotodo%type;
    v_max number ;
    BEGIN
        select  compania into v_compania from data.t_icom_inversiones where id = p_id and rownum=1;
        v_max :=nvl(pk_commons.safe_to_number(PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM','20', v_COMPANIA ,'','','1')),0);
        if ( v_max > 3990)  then --el limite de sql es 4000
            v_max := 3990;
        end if;    
        select  case when max(total) > v_max then
                    listagg(NOMBRES, '; ') within group (order by nombres)||'...'
                else
                    listagg(nombres, '; ') within group (order by nombres) 
                end     
        into v_listanombres     
        from ( --Se obtinie los nombres y sus dimenciones para controlar el maximo permitido 
            select nombres,
                --Se aÃ±ade 2 por los caracteres especiales.
                sum(lengthb(nombres) + 2) over (order by nombres) cuenta,
                sum(lengthb(nombres) + 2) over () total
            from data.T_ICOM_INVERSION_CLIENTE_G
            where idinversion = p_id 
            order by nombres
        )
        where cuenta <= v_max;  
        dbms_output.put_line( 'clientes '|| V_LISTANOMBRES  );
        return v_listanombres;   
    END;
    
    /*  Funcion PARA IDENTIFICAR SI LA INVERSION ESTA EN GESTION DEL USUARIO LOGEADDO, PARA MOSTRAR EN MIS PENDIENTES
    */
    FUNCTION F_INVERSION_GESTOR(P_IDINVERSION NUMBER, P_IDETAPA NUMBER,
                                P_ESTADO NUMBER, P_ANALISTA VARCHAR2, P_USUARIO VARCHAR2,
                                P_LOGEADO VARCHAR2, P_COMPANIA VARCHAR2) RETURN NUMBER AS
    BEGIN 
        
        IF p_idetapa = 1 AND P_ESTADO=0 and P_USUARIO=p_logeado THEN  --- CREADOR DE LA INVERSION
               return 1;
        elsif p_idetapa = 4 AND P_ESTADO = 1 and P_ANALISTA = p_logeado then --- EVALUADOR DE LA INVERSION
               return 1;
        elsif p_idetapa = 2 and --- EJECUTIVO DE LA INVERSION
            PK_ICOM_COMMONS.F_ESEJECUTIVO_INVERSION( P_USUARIO => P_LOGEADO,
            P_INVERSION =>p_idinversion, 
            P_COMPANIA => p_compania, P_APROBADOR=>1) = 1  then
             return 1;
         end if;
         return 0;
    END;

    /*  Funcion que retorna el codigo de color para mesa de trabajo 
	    en el caso del cierre y negociacion
    */
    FUNCTION F_INVERSION_COLOR (P_IDINVERSION NUMBER, P_IDETAPA NUMBER,
                                P_ESTADO NUMBER, P_ANALISTA VARCHAR2, P_USUARIO VARCHAR2,
                                P_LOGEADO VARCHAR2, P_APROBADOR VARCHAR2, P_COMPANIA VARCHAR2, 
                                P_TIPOINVERSION NUMBER DEFAULT NULL ) RETURN VARCHAR2    AS 
    V_COLOR VARCHAR2(500);   
    v_firmacontrato number ; 
    
    BEGIN
    
        V_COLOR:=PK_CORP_FLUJOAPROBACION.F_GESTIONCOLOR(P_LOGEADO, P_APROBADOR,P_ESTADO, P_COMPANIA, 'ICOM');
        IF(V_COLOR IN ( 'mesaPendiente','mesaOtro' )) THEN 
             RETURN V_COLOR;
        END IF;
        
        IF(F_INVERSION_GESTOR (P_IDINVERSION => P_IDINVERSION, P_IDETAPA =>P_IDETAPA, 
                            P_ESTADO => P_ESTADO, P_ANALISTA =>P_ANALISTA,
                            P_USUARIO=> P_USUARIO, P_LOGEADO => P_LOGEADO,
                            P_COMPANIA =>P_COMPANIA)=1) THEN
            return 'mesaPendiente' ;
        END IF;
        
        IF PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES (P_CODIGOMODULO => G_MODULO, P_CODIGOUSUARIO => P_LOGEADO, 
            P_RUTAPAGINA => 330, P_CODIGOACCION => 'GESTION_TODOS')=1 THEN
            --Tiene permiso para gestionar contratos cliente y pdvs
            BEGIN
                SELECT firmacontrato INTO v_firmacontrato 
                FROM  data.vt_icom_inversiontipo
                WHERE IDINVERSIONTIPO = NVL(P_TIPOINVERSION,-1) 
                AND ESTADO = 1 ;
            EXCEPTION WHEN NO_DATA_FOUND THEN 
                v_firmacontrato := 0 ;
            END  ;    
            IF (p_idetapa = 2 AND NVL(v_firmacontrato,0) in (1,2) ) THEN
                return 'mesaPendiente' ;
            END IF;
        END IF;
        
        return 'mesaNinguno';
    END;

 
    /*Funcion que verifica si existe modificacion manual de analisis*/
    FUNCTION F_ModificaAnalisis( P_IDINVERSION NUMBER) RETURN NUMBER AS
        v_VentaUndMeta number;
        v_VentaUsdMeta number;
    BEGIN
        select VentaUndMeta, VentaUsdMeta into v_VentaUndMeta , v_VentaUsdMeta 
        from data.t_icom_inversiones
        where id = P_idinversion ;
        if nvl(v_VentaUndMeta,0) != 0 or nvl(v_VentaUsdMeta,0) != 0 then
            return 1 ;
        end if;
        return 0 ;
    END;


   
   /*Procedimiento que realiza la lÃ³gica de cambio de etapa (PROCESOS AUTOMATICOS) de un contrato
    Autor: CCarrasco (NETBY)
	Fecha: Agosto 2022 
    PK_ICOM_COMMONS.SP_CAMBIO_ETAPA();
	*/   
   PROCEDURE SP_CAMBIO_ETAPA AS
   v_CONTADOR NUMBER;
   v_idorigen number ;
   v_cuentaclientes NUMBER  ;
   v_cuentavalidaciones NUMBER  ;
   begin 

         ---***************** Cambio de Estado del cliente en etapa Negociacion
       -- update  T_ICOM_INVERSION_CLIENTE_G set estado=0 where NEGOCIACION=2 and estado=1;
   -------------------------------------------------------------------
   -- Cambio de estado de clientes en etapa NegociaciÃ³n
   -------------------------------------------------------------------
        FOR datos in (
            select c.idinversion, c.codigogrupo , c.NEGOCIACION
                from DATA.T_ICOM_INVERSION_CLIENTE_G c, DATA.T_ICOM_INVERSIONES t
                WHERE c.idinversion = t.id AND T.IDETAPA=2 AND T.IDETAPA2 is null  AND (c.NEGOCIACION IN (0,1) or (c.NEGOCIACION=2 and c.estado=1)) 
                AND (t.FECHAFIN+nvl(pk_commons.safe_to_number(PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '1', T.COMPANIA )),0))<sysdate)
        LOOP
                
           IF(datos.NEGOCIACION in (0,2)) THEN      
                UPDATE DATA.T_ICOM_INVERSION_CLIENTE_G SET NEGOCIACION=2, ESTADO=0, 
                MOTIVORECHAZO='Cliente sin negociar, sistema cancela de forma automÃ¡tica'
                WHERE IDINVERSION=datos.idinversion AND CODIGOGRUPO=datos.codigogrupo;
                
                DELETE  T_ICOM_CLIENTE_FECHAS WHERE ESTADO=0 AND CODIGOGRUPO=datos.codigogrupo AND IDINVERSION=datos.idinversion;
                
                PK_ICOM_COMMONS.SP_AUDITORIA(
                    P_USUARIO => 'PROCESO AUTOMATICO',
                    P_IDINVERSION => datos.idinversion,
                    P_IDETAPA => 2,
                    P_CODIGOGRUPO => datos.codigogrupo,
                    P_IDACCION => 7,
                    P_DESCRIPCION => 'SE CAMBIO ESTADO DE SIN NEGOCIAR - NO ACEPTO / EJECUTIVO NO NEGOCIO CLIENTE');
                
            ELSIF  (datos.NEGOCIACION=1)  THEN
            
                UPDATE DATA.T_ICOM_INVERSION_CLIENTE_G SET NEGOCIACION=3, ESTADO=0
                WHERE IDINVERSION=datos.idinversion AND CODIGOGRUPO=datos.codigogrupo;
                
                 PK_ICOM_COMMONS.SP_AUDITORIA(
                    P_USUARIO => 'PROCESO AUTOMATICO',
                    P_IDINVERSION => datos.idinversion,
                    P_IDETAPA => 2,
                    P_CODIGOGRUPO => datos.codigogrupo,
                    P_IDACCION => 7,
                    P_DESCRIPCION => 'SE CAMBIO ESTADO DE ACEPTA - ACEPTA Y FINALIZA');
                
            END IF;
            
        END LOOP;
        
         ---***************NEGOCIACION - IMPLEMENTACION****** No existen clientes
   -------------------------------------------------------------------
   -- NegociaciÃ³n ? ImplementaciÃ³n (sin clientes)
   -------------------------------------------------------------------
        FOR datos in (
            select ID idinversion FROM T_ICOM_INVERSIONES I 
            WHERE  IDETAPA=2  
            AND  (NOT EXISTS (SELECT 1 FROM T_ICOM_INVERSION_CLIENTE_G G WHERE G.IDINVERSION=I.ID) 
                OR GRUPAL=1)
        )LOOP
            
            update data.t_icom_inversiones 
                SET idetapa = 3, estado=1 
            where id = datos.idinversion;
            --CAMBIO DE ETAPA auditoria            
            PK_ICOM_COMMONS.SP_AUDITORIA(
                    P_USUARIO => 'PROCESO AUTOMATICO',
                    P_IDINVERSION => datos.idinversion,
                    P_IDETAPA => 3,
                    P_IDACCION => 2,
                    P_DESCRIPCION => 'SE CAMBIO DE ETAPA  NEGOCIACION - IMPLMENTACION SIN CLIENTES'      );
           
        end loop ;
               
        ---***************** NEGOCIACION - IMPLEMENTACION 
        -- Todos los clientes de la inversion debe estar con estado negociacion= NO ACEPTO / ACEPTA Y FINALIZA
   -------------------------------------------------------------------
   -- NegociaciÃ³n ? ImplementaciÃ³n (todos los clientes gestionados)
   -------------------------------------------------------------------
        FOR datos in ( 
        select * 
        from DATA.T_ICOM_INVERSIONES t  
        WHERE T.IDETAPA=2 and IDETAPA2 is null 
        and not exists ( 
                select 1 from data.T_ICOM_INVERSION_CLIENTE_G c  
                where c.idinversion = t.id
                    AND (estado != 0 OR NEGOCIACION not in (2,3) ) ) ) 
        loop 
                    
             update data.t_icom_inversiones 
                SET idetapa = 3, estado=1 
             where id = datos.ID;
             
        ---v_CONTADOR
        select count(1) into v_CONTADOR
        from t_icom_inversion_producto where idinversion=datos.ID;
        
        IF(v_CONTADOR=0 AND datos.IDINVERSIONTIPO=4) THEN  
            
            PK_ICOM_CRUD.sp_todosproductos(datos.ID, 1, '00001');
            
        END IF;
             
            PK_ICOM_COMMONS.SP_AUDITORIA(
                P_USUARIO => 'PROCESO AUTOMATICO',
                P_IDINVERSION => datos.ID,
                P_IDETAPA => 3,
                P_IDACCION => 2,
                P_DESCRIPCION => 'SE CAMBIO DE ETAPA  NEGOCIACION - IMPLMENTACION TODOS LOS CLIENTES APROBADOS');
        end loop;         
           
           
        
         ---*************  NEGOCIACION - IMPLEMENTACION Todos los contartos de los pdv aprobados/rechazados
    -------------------------------------------------------------------
    -- NegociaciÃ³n ? ImplementaciÃ³n (cuando contratos PDV ya estÃ¡n gestionados)
    -------------------------------------------------------------------
        FOR datos in (
            select ID idinversion, IDINVERSIONTIPO 
            FROM VT_ICOM_INVERSIONES  
            WHERE  IDETAPA=2  
                AND FIRMACONTRATO=2 )
        LOOP
                
                 SELECT COUNT(1) INTO V_CONTADOR FROM  T_ICOM_CLIENTE_PDV  
                        WHERE IDINVERSION=DATOS.idinversion  AND nvl(CONTRATOAPROBAR ,0) NOT IN  (4, 5); --- APROBADOS /RECHAZADOS 
                        
                -- todos los convenios gestionados 
                IF(V_CONTADOR=0) THEN 
                    UPDATE t_icom_inversiones SET IDETAPA =3, ESTADO=1 WHERE ID=DATOS.idinversion;
                   
                    ---v_CONTADOR
                    select count(1) into v_CONTADOR
                    from t_icom_inversion_producto where idinversion=datos.idinversion;
                    
                    IF(v_CONTADOR=0 AND datos.IDINVERSIONTIPO=4) THEN  
                        
                        PK_ICOM_CRUD.sp_todosproductos(datos.idinversion, 1, '00001');
                        
                    END IF;
                   
                    --CAMBIO DE ETAPA auditoria            
                    PK_ICOM_COMMONS.SP_AUDITORIA(
                            P_USUARIO => 'PROCESO AUTOMATICO',
                            P_IDINVERSION => datos.idinversion,
                            P_IDETAPA => 3,
                            P_CODIGOGRUPO => null,
                            P_IDACCION => 2,
                            P_DESCRIPCION => 'SE CAMBIO DE ETAPA  NEGOCIACION - IMPLMENTACION INVERSION DE CONTRATOS PDV, TODOS LOS PDV  APROBADOS'  );
                END IF;
        
        END LOOP;
            
            
    -------------------------------------------------------------------
    -- ImplementaciÃ³n ? Clausura (ningÃºn cliente aceptÃ³)
    -------------------------------------------------------------------
        ---**************  IMPLEMENTACION - CLAUSURA Cuanto todos los clientes no aceptaron la inversion
        FOR datos in (
            select * 
            from t_icom_inversiones i 
            where IDETAPA =3 
                and exists (select 1 from T_ICOM_INVERSION_CLIENTE_G c where c.idinversion=i.id ) 
                and not exists (select 1 from T_ICOM_INVERSION_CLIENTE_G c where c.idinversion=i.id and nvl(c.NEGOCIACION,0) NOT IN (2)))
        LOOP
               
            UPDATE DATA.T_ICOM_INVERSIONES
                SET ESTADO = 4,
                    IDETAPA = 4,
                    IDETAPA2 = 6,
                    FECHACIERREFIN = NVL(FECHACIERREFIN, SYSDATE),
                    MOTIVOCLAUSURA='NINGUN CLIENTE ACEPTO'
            WHERE ID = DATOS.id;
            
            --CAMBIO DE ETAPA auditoria            
            PK_ICOM_COMMONS.SP_AUDITORIA(
                    P_USUARIO => 'PROCESO AUTOMATICO',
                    P_IDINVERSION => datos.id,
                    P_IDETAPA => 4,
                    P_IDACCION => 2,
                    P_DESCRIPCION => 'SE CAMBIO DE ETAPA IMPLMENTACION - CLAUSURA NINGUN CLIENTE ACEPTO');
                
        END LOOP;

   -------------------------------------------------------------------
   -- ImplementaciÃ³n ? Cierre / Cierre no tiene clientes
   -------------------------------------------------------------------
        -- ********** IMPLEMENTACION - CIERRE  los que no tienen cliente y la fecha fin de la inveersion es menor al dia de hoy
        FOR DATOS IN (SELECT * FROM T_ICOM_INVERSIONES I
        WHERE IDETAPA=3 AND GRUPAL =0 AND FECHAFIN<sysdate AND NOT EXISTS (
        SELECT 1 FROM T_ICOM_INVERSION_CLIENTE_G WHERE IDINVERSION=I.ID)) LOOP

            UPDATE DATA.T_ICOM_INVERSIONES
               SET ESTADO = 1,
                   IDETAPA = 4,
                   FECHACIERRE = NVL(FECHACIERRE, SYSDATE)
             WHERE ID = DATOS.ID;
             --CAMBIO DE ETAPA auditoria
            PK_ICOM_COMMONS.SP_AUDITORIA(
                            P_USUARIO => 'PROCESO AUTOMATICO',
                            P_IDINVERSION => datos.id,
                            P_IDETAPA => 4,
                            P_CODIGOGRUPO => null,
                            P_IDACCION => 2,
                            P_DESCRIPCION => 'SE CAMBIO DE ETAPA IMPLMENTACION - CIERRE SIN CLIENTES '    );

        END LOOP;


    ---************ IMPLEMENTACION - VALIDACION SEGUN PAIS
    -- deben estar en etapa implementacion, la fecha fin de la inversion menor al dia de hoy
    -- el origen de la inversion debe ser diferente a fÃ¡brica
    -- la mÃ¡xima fecha fin de los clientes aprobados debe ser menor al dÃ­a de hoy.
    -- la negociacion de los clientes debe estar en estado finalizada
    -- no debe tener saldo pendiente
    FOR datos IN (
        SELECT i.id AS idinversion,
           i.compania,
           NVL(i.idorigen,0) AS idorigen,
           COUNT(CASE WHEN c.idformapago = 3 THEN 1 END) AS clientes_nc,
           SUM(NVL(m.total_pendiente,0)) AS total_pendiente
        FROM   T_ICOM_INVERSIONES i
        INNER JOIN T_ICOM_INVERSION_CLIENTE_G c
                ON i.id = c.idinversion
        LEFT JOIN VT_ICOM_CLIENTE_MATERIALNEGOCIADO m
               ON i.id = m.idinversion
        WHERE  i.idetapa = 3
          AND  i.fechafin < SYSDATE
          AND  i.grupal = 0
          AND  i.estado <> 2 -- (INVERSION NO CLAUSURADA)
          AND  NVL(I.idorigen,0) != 3 -- (ORIGEN DIFERENTE A FABRICA)
          AND c.negociacion = 3 -- (NEGOCIACION FINALIZADA)
        GROUP BY i.id,
                 i.compania,
                 NVL(i.idorigen,0)
        HAVING TRUNC(MAX(c.fechafin)) < TRUNC(SYSDATE) -- (MAXIMA FECHA FIN DE LOS CLIENTES APROBADOS MENOR AL DIA DE HOY)
      --  AND SUM(NVL(m.total_pendiente,0)) = 0
        )
    LOOP
        IF datos.compania = '00001' THEN
            IF datos.clientes_nc > 0 THEN
                UPDATE T_ICOM_INVERSIONES
                   SET idetapa = 7, estado = 1
                WHERE id = datos.idinversion;
                PK_ICOM_COMMONS.SP_AUDITORIA(
                   p_usuario     => 'PROCESO AUTOMATICO',
                   p_idinversion => datos.idinversion,
                   p_idetapa     => 7,
                   p_idaccion    => 2,
                   p_descripcion => 'ECUADOR: CLIENTES CON NOTA DE CRÃ‰DITO, PASA A VALIDACION');
            END IF;
        END IF;
        IF datos.compania = '00003' THEN
            UPDATE T_ICOM_INVERSIONES
               SET idetapa = 7, estado = 1
            WHERE id = datos.idinversion;
            PK_ICOM_COMMONS.SP_AUDITORIA(
                p_usuario     => 'PROCESO AUTOMATICO',
                p_idinversion => datos.idinversion,
                p_idetapa     => 7,
                p_idaccion    => 2,
                p_descripcion => 'PERU: ORIGEN NO FABRICA, PASA A VALIDACION');
        END IF;
    END LOOP;

    ---************ IMPLEMENTACION - CIERRE SEGUN PAIS
    -- deben estar en etapa implementacion, la fecha fin de la inversion menor al dia de hoy
    -- el origen de la inversion debe ser igual a fÃ¡brica o tipo onpack
    -- la mÃ¡xima fecha fin de los clientes aprobados debe ser menor al dÃ­a de hoy.
    -- la negociacion de los clientes debe estar en estado finalizada
    -- no debe tener saldo pendiente
    FOR datos IN (
        SELECT i.id AS idinversion,
           i.compania,
           NVL(i.idorigen,0) AS idorigen,
           COUNT(CASE WHEN c.idformapago = 3 THEN 1 END) AS clientes_nc,
           SUM(NVL(m.total_pendiente,0)) AS total_pendiente
        FROM   T_ICOM_INVERSIONES i
        INNER JOIN T_ICOM_INVERSION_CLIENTE_G c
                ON i.id = c.idinversion
        LEFT JOIN VT_ICOM_CLIENTE_MATERIALNEGOCIADO m
               ON i.id = m.idinversion
        WHERE  i.idetapa = 3
          AND  i.fechafin < SYSDATE
          AND  i.grupal = 0
          AND  i.estado <> 2 -- (INVERSION NO CLAUSURADA)
          AND ( (compania = '00003' and   
              NVL(i.idorigen,0) = 3) -- (ORIGEN IGUAL A FABRICA)
              OR  compania <> '00003'
              --OR exists (select 1 from VT_ICOM_CLIENTE_MATERIALNEGOCIADO  b where b.idinversion=i.id ) -- (tipo onpack)
          )
          AND c.negociacion = 3 -- (NEGOCIACION FINALIZADA)
        GROUP BY i.id,
                 i.compania,
                 NVL(i.idorigen,0)
        HAVING TRUNC(MAX(c.fechafin)) < TRUNC(SYSDATE) -- (MAXIMA FECHA FIN DE LOS CLIENTES APROBADOS MENOR AL DIA DE HOY)
        AND SUM(NVL(m.total_pendiente,0)) = 0
        )
    LOOP
        IF datos.compania = '00001' THEN
            IF datos.clientes_nc = 0 THEN
                UPDATE T_ICOM_INVERSIONES
                     SET idetapa = 4,
                         estado = 1,
                         fechacierre = NVL(fechacierre, SYSDATE)
                 WHERE id = datos.idinversion;
                 PK_ICOM_COMMONS.SP_AUDITORIA(
                     p_usuario     => 'PROCESO AUTOMATICO',
                     p_idinversion => datos.idinversion,
                     p_idetapa     => 4,
                     p_idaccion    => 2,
                     p_descripcion => 'ECUADOR: SIN CLIENTES CON NOTA DE CRÃ‰DITO, PASA A CIERRE');
            end if;
        END IF;
        IF datos.compania = '00003' THEN
            UPDATE T_ICOM_INVERSIONES
               SET idetapa = 4,
                   estado = 1,
                   fechacierre = NVL(fechacierre, SYSDATE)
            WHERE id = datos.idinversion;
            PK_ICOM_COMMONS.SP_AUDITORIA(
                p_usuario     => 'PROCESO AUTOMATICO',
                p_idinversion => datos.idinversion,
                p_idetapa     => 4,
                p_idaccion    => 2,
                p_descripcion => 'PERU: ORIGEN FABRICA O TIPO ONPACK, PASA DIRECTO A CIERRE');
        END IF;
    END LOOP;
           
    -------------------------------------------------------------------
    -- ValidaciÃ³n ? Cierre
    -------------------------------------------------------------------
    ---PROCESO PARA PASAR DE LA ETAPA DE VALIDACION  A CIERRE 
    --se busca todas las inversiones EN ETAPA DE validacion
    --DBMS_OUTPUT.PUT_LINE('Validacion a Cierre');
    for inv in ( select ID idinversion FROM T_ICOM_INVERSIONES I WHERE IDETAPA=7 and idetapa2 is null ) 
        loop
            --POR CADA inversiones se debe validar que todos sus clientes se hayan validado con la fecha fin maxima
            
            select count(1) into v_cuentaclientes
                         from data.t_icom_inversion_cliente_g
                         where idinversion = inv.idinversion and negociacion in (1,3);
           
            
            -- Contar las validaciones correctas para los clientes
            WITH descuentos as (
                    select IDINVERSION, CODIGOGRUPO, max(FECHAFIN) FECHAFIN
                    from t_icom_producto_descuento_fec
                    where estado in (3,5)
                    group by IDINVERSION , CODIGOGRUPO ),
            validaciones as (
                    select IDINVERSION, CODIGOGRUPO, max(VAL_FECHAFIN) FECHAFIN, max(IDVALIDACIONTIPO)  IDVALIDACIONTIPO
                    from t_icom_cliente_validacion
                    where estado=1
                    group by IDINVERSION , CODIGOGRUPO)
                SELECT  count(1)   INTO v_cuentavalidaciones
                FROM data.t_icom_inversion_cliente_g cli
                INNER JOIN DATA.T_ICOM_INVERSIONES I ON (I.ID=CLI.IDINVERSION)
                left join descuentos d on (cli.idinversion = d.idinversion and cli.CODIGOGRUPO = d.CODIGOGRUPO)
                left JOIN validaciones val  ON  cli.idinversion = val.idinversion and cli.codigogrupo = val.codigogrupo  
                WHERE cli.idinversion = inv.idinversion  AND cli.negociacion IN (3) AND ( 
                trunc(val.FECHAFIN) >= trunc(nvl(d.fechafin, cli.fechafin)) -- FECHAS VALIDACIONES MAYOR O IGUAL A LA NEGOCIACION DEL CLIENTE 
                OR (val.IDVALIDACIONTIPO=4 AND SYSDATE > d.fechafin AND SYSDATE >  cli.fechafin) --- DESCUENTO DIRECTO EN FACTURA
                OR (cli.idformapago=2 and val.idinversion is null and d.idinversion is null and SYSDATE >  cli.fechafin)--- ES UNA ACTIIVIDA COMERCIAL QUE NO SE VALIDO NADA Y LA FECHA FIN DE LA INVERSION YA PASO                      
                );
            
            --DBMS_OUTPUT.PUT_LINE('Inversion ID: ' || inv.idinversion ||' - Clientes: ' || v_cuentaclientes ||' - Validaciones: ' || v_cuentavalidaciones);
            
            if (v_cuentaclientes = v_cuentavalidaciones) then
                --si todos los clientes tienen validacion para la fecha maxima pasa a cierre la inversion
                update data.t_icom_inversiones
                   set idetapa = 4,
                       fechacierre = NVL(fechacierre, SYSDATE) --etapa 4 cierre
                where id = inv.idinversion ;
                PK_ICOM_PROCESOSTAREAS.SP_ActualizarPDV(inv.idinversion);
                
                update data.t_icom_inversion_proceso
               set porcentaje = 100 , fechafin = sysdate
               where idinversion = inv.idinversion and idproceso = 1  and estado = 1 ;
               
                --CAMBIO DE ETAPA auditoria            
                PK_ICOM_COMMONS.SP_AUDITORIA(
                            P_USUARIO => 'PROCESO AUTOMATICO',
                            P_IDINVERSION => inv.idinversion,
                            P_IDETAPA => 4,
                            P_IDACCION => 2,
                            P_DESCRIPCION => 'SE CAMBIO DE ETAPA VALIDACION - CIERRE  : TODOS LOS CLIENTES APROBADOS YA FUERON VALIDADOS '    );
            end if;
    end loop;
        
    -------------------------------------------------------------------
    -- Cierre automÃ¡tico de inversiones padre cuando todas las hijas cierran
    -------------------------------------------------------------------
    ---PASA A CIERRE LAS INVERSIONES PADRE
    UPDATE DATA.T_ICOM_INVERSIONES A 
        SET IDETAPA=4,
            FECHACIERRE = CASE
                              WHEN ESTADO = 1 THEN NVL(FECHACIERRE, SYSDATE)
                              ELSE FECHACIERRE
                           END
    WHERE 
        ESTADO<>4 
        AND GRUPAL=1 
        AND IDPADRE IS NULL   AND IDETAPA=3 
        AND EXISTS (
            SELECT 1 
            FROM DATA.T_ICOM_INVERSIONES B 
            WHERE A.ID=B.IDGRUPO  AND B.IDETAPA=4 AND B.ESTADO=4 AND   B.IDPADRE IS NULL )
         AND NOT EXISTS(
            SELECT 1 
            FROM DATA.T_ICOM_INVERSIONES B 
            WHERE 
                A.ID=B.IDGRUPO 
                AND B.IDETAPA<>4 
                AND B.ESTADO not in (1,2,4) AND 
                B.IDPADRE IS NULL);
        
    
    
    --- SE CIERRA LAS CLAUSURADAS
    -------------------------------------------------------------------
    -- Clausura de inversiones
    -------------------------------------------------------------------
    UPDATE T_ICOM_INVERSIONES
        SET ESTADO=4,
            FECHACIERREFIN = NVL(FECHACIERREFIN, SYSDATE)
    WHERE  --ID=19625 AND
        IDETAPA in (4,7) 
        AND ESTADO=1 
        AND IDETAPA2=6;
        
        --- SI TODAS TODAS LAS HIJAS SE CLAUSURAN EL PADRE TAMBIEN 
    UPDATE T_ICOM_INVERSIONES A 
        SET ESTADO=4,
            IDETAPA2=6,
            FECHACIERREFIN = NVL(FECHACIERREFIN, SYSDATE)
    WHERE  --ID=19625 AND
        IDETAPA=4
        AND ESTADO=1 
        AND GRUPAL=1
        AND NOT EXISTS (
            SELECT 1 
            FROM T_ICOM_INVERSIONES B 
            WHERE 
                B.IDGRUPO=A.ID 
                AND IDPADRE IS NULL 
                AND IDETAPA2 IS NULL 
                AND IDETAPA>1);
        
    end SP_CAMBIO_ETAPA;
    
    /*Funcion que retorna todas las lineas de negocio de una inversion */
    FUNCTION F_VerLineaNegocio (P_ID number) RETURN VARCHAR2 AS 
        v_limite number;
        v_cadena clob;
    BEGIN
        /*buscamos en las tablas generales el limite de la cadena*/
        select  compania into  v_compania from data.t_icom_inversiones where id = P_ID and rownum=1;
        v_limite:=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '20',v_compania,'','','1');
        
        select LISTAGG(trim(lineanegocio), '; ') WITHIN GROUP (ORDER BY lineanegocio)
        into v_cadena
        from (select distinct lineanegocio lineanegocio
                from data.t_icom_inversion_producto
                where idinversion = p_id and tipo = 1  )  ;
        
        if ( nvl(v_limite, 0) = 0 or v_limite > 3500 ) then
            v_limite := 3500 ;
        end if ;
        
        return substr(trim(NVL(v_cadena,' ')), 1, v_limite);
        
    END F_VerLineaNegocio;
    
    /*Funcion que retorna todas las marcas de una inversion */
    FUNCTION F_VerMarca (P_ID number) RETURN VARCHAR2 AS 
        v_limite number;
        v_cadena clob;
    BEGIN
        /*buscamos en las tablas generales el limite de la cadena*/
        select  compania into  v_compania from data.t_icom_inversiones where id = P_ID and rownum=1;
        v_limite:=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '20',v_compania,'','','1');
        
        select LISTAGG(trim(marca), '; ') WITHIN GROUP (ORDER BY marca)
        into v_cadena
        from (select distinct marca marca
                from data.t_icom_inversion_producto
                where idinversion = p_id and tipo = 1   )  ;
        
        if ( nvl(v_limite, 0) = 0 or v_limite > 3500 ) then
            v_limite := 3500 ;
        end if ;
        
        return substr(trim(NVL(v_cadena,' ')), 1, v_limite);
    END F_VerMarca;

    /*Funcion que retorna todas las submarcas de una inversion */
    FUNCTION F_VerSubMarca (P_ID number) RETURN VARCHAR2 AS 
        v_limite number;
        v_cadena clob;
    BEGIN
        /*buscamos en las tablas generales el limite de la cadena*/
        select  compania into  v_compania from data.t_icom_inversiones where id = P_ID and rownum=1;
        v_limite:=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '20',v_compania,'','','1');
        
        select 
         rtrim(xmlagg(xmlelement(e, submarca,',').extract('//text()')
            order by submarca).GetClobVal(),',') 
--        LISTAGG(trim(submarca), '; ') WITHIN GROUP (ORDER BY submarca)
        into v_cadena
        from (select distinct submarca submarca
                from data.t_icom_inversion_producto
                where idinversion = p_id and tipo = 1   )  ;
        
        if ( nvl(v_limite, 0) = 0 or v_limite > 3500 ) then
            v_limite := 3500 ;
        end if ;
        
        return substr(trim(NVL(v_cadena,' ')), 1, v_limite);
    END F_VerSubMarca;
    
    /*Funcion que retorna todos los productos de una inversion */
    FUNCTION F_VerProducto (P_ID number) RETURN VARCHAR2 AS 
        v_limite number;
        v_cadena clob;
    BEGIN
        begin
            select  compania into  v_compania from data.t_icom_inversiones where id = P_ID and rownum=1;
            v_limite:=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '20',v_compania,'','','1');
        exception when others   then
            v_limite:=null;
        end;
    
        if ( nvl(v_limite, 0) = 0 or v_limite > 3999 ) then
            v_limite := 3999 ;
        end if ;
        
            v_cadena:='';
            DBMS_OUTPUT.PUT_LINE(P_ID);
            FOR PRODUCTOS IN (
                select  idinversion,producto
                from data.t_icom_inversion_producto
                where 1=1 and idinversion =P_ID  and tipo = 1
                group by idinversion,producto
                order by 1 desc, idinversion,producto
            )
            LOOP 
                v_cadena:=v_cadena||PRODUCTOS.producto||';';
                IF (DBMS_LOB.GETLENGTH(v_cadena)>=v_limite)  THEN  v_cadena :=v_cadena||'.......'; END IF;
                EXIT WHEN (DBMS_LOB.GETLENGTH(v_cadena)>=v_limite) ;
            END LOOP;

--        DBMS_OUTPUT.PUT_LINE('...'||v_limite);
--        DBMS_OUTPUT.PUT_LINE('...'||v_cadena);
        return v_cadena;
    END F_VerProducto;

    FUNCTION F_VerProducto2 (P_ID number) RETURN VARCHAR2 AS 
        v_limite number;
        v_cadena clob;
    BEGIN
      
        /*buscamos en las tablas generales el limite de la cadena*/
        select  compania into  v_compania from data.t_icom_inversiones where id = P_ID and rownum=1;
        v_limite:=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '20',v_compania,'','','1');
        
        select RTRIM(XMLAGG(XMLELEMENT(E,REGEXP_REPLACE(trim(producto), '[^[:print:]]', ''), ';').EXTRACT('//text()') ORDER BY producto).GetClobVal(),';')
        --select LISTAGG(trim(producto), ';') WITHIN GROUP (ORDER BY producto)
        into v_cadena
        from (select distinct producto
                from data.t_icom_inversion_producto
                where idinversion = p_id and tipo = 1   )  ;
        
        if ( nvl(v_limite, 0) = 0 or v_limite > 3000 ) then
            v_limite := 3000 ;
        end if ;
        
        return substr(trim(NVL(v_cadena,' ')), 1, v_limite);
    END F_VerProducto2;
    
    /*Funcion que retorna todos los clientes de una inversion para un grupo*/
    FUNCTION F_VerCliente (P_ID number, P_CODIGOGRUPO VARCHAR2, P_COMPANIA VARCHAR2 ) RETURN VARCHAR2 AS 
        v_limite number;
        v_cadena clob;
    BEGIN
        /*buscamos en las tablas generales el limite de la cadena*/
        select  compania into  v_compania from data.t_icom_inversiones where id = P_ID and rownum=1;
        v_limite:=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '20',v_compania,'','','1');
        
        select RTRIM(XMLAGG(XMLELEMENT(E,REGEXP_REPLACE(trim(cliente), '[^[:print:]]', ''), ';').EXTRACT('//text()') ORDER BY cliente).GetClobVal(),';')
        --select LISTAGG(trim(producto), ';') WITHIN GROUP (ORDER BY producto)
        into v_cadena
        from (select distinct nombres as cliente
                from data.t_icom_inversion_cliente cl
                    inner join data.vt_gzm_cliente v on
                    ( v.compania = p_compania and cl.codigogrupo = v.codigogrupo and cl.codigocliente = v.codigocliente )
                where cl.idinversion = p_id and cl.codigogrupo = p_codigogrupo  )  ;
        
        if ( nvl(v_limite, 0) = 0 or v_limite > 3000 ) then
            v_limite := 3000 ;
        end if ;
        
        return substr(trim(NVL(v_cadena,' ')), 1, v_limite);
    END F_VerCliente;
    
    /*Funcion que retorna todas los canales de una inversion */
    FUNCTION F_VerCanal (P_ID number) RETURN VARCHAR2 AS 
        v_limite number;
        v_cadena clob;
    BEGIN
        /*buscamos en las tablas generales el limite de la cadena*/
        select  compania into  v_compania from data.t_icom_inversiones where id = P_ID and rownum=1;
        v_limite:=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '20',v_compania,'','','1');
        
        select LISTAGG(trim(canal), '; ') WITHIN GROUP (ORDER BY canal)
        into v_cadena
        from (select distinct v.canal canal
                from data.t_icom_inversiones i 
                    inner join data.t_icom_inversion_cliente_g g on (g.idinversion = i.id )
                    inner join data.vt_gzm_cliente v on (i.compania = v.compania and g.codigogrupo = v.codigocliente )
                where i.id = p_id )  ;
        
        if ( nvl(v_limite, 0) = 0 or v_limite > 3500 ) then
            v_limite := 3500 ;
        end if ;
        
        return substr(trim(NVL(v_cadena,' ')), 1, v_limite);
        
    END F_VerCanal;
    
    /*Funcion que retorna todas los canales de una inversion */
    FUNCTION F_VerPaisGrupo (P_ID number) RETURN VARCHAR2 AS 
        v_limite number;
        v_cadena clob;
    BEGIN
        /*buscamos en las tablas generales el limite de la cadena*/
        select  compania into  v_compania from data.t_icom_inversiones where id = P_ID and rownum=1;
        v_limite:=PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '20',v_compania,'','','1');
        
        select LISTAGG(trim(pais), '; ') WITHIN GROUP (ORDER BY pais)
        into v_cadena
        from (select distinct v.codigopais pais
                from data.t_icom_inversiones i 
                    inner join data.t_icom_inversion_cliente_g g on (g.idinversion = i.id )
                    inner join data.vt_gzm_cliente v on (i.compania = v.compania and g.codigogrupo = v.codigocliente )
                where i.id = p_id )  ;
        
        if ( nvl(v_limite, 0) = 0 or v_limite > 3500 ) then
            v_limite := 3500 ;
        end if ;
        
        return substr(trim(NVL(v_cadena,' ')), 1, v_limite);
        
    END F_VerPaisGrupo;
    
    /*Funcion que verifica si existe simulaclion 1 caso contrario 0*/
    FUNCTION F_ExisteSimulacion ( P_ID NUMBER ) RETURN NUMBER AS
    v_cuenta number;
    v_distribucion number;
    BEGIN
    
        SELECT count (1) into v_cuenta 
        FROM t_icom_producto_descuento D 
        WHERE D.IDINVERSION = P_ID
        AND nvl(round(DESCUENTOCALCULADO,2),0) > 0 ;
        
       
        if v_cuenta > 0  then    
            --se debe mostrar la simulacion
            return 1 ;
        end if;
        
        --no se debe mostrar la simulacion
        return 0 ;
    END F_ExisteSimulacion ;
    
    /*Funcion que verifica si LA INVERSION TINENE LAS HERRAMIENTAS DE DISTRIBUCION O PRODUCTO REGALO
    RETORNA 1/0 Tiene/No tiene  PK_ICOM_COMMONS.F_TieneHerramienta(17895,1)*/
     FUNCTION F_TieneHerramienta( P_ID NUMBER, P_HERRAMIENTA NUMBER ) RETURN NUMBER
     AS
     V_CONTADOR NUMBER:=0;
     BEGIN 
     
     IF(P_HERRAMIENTA=1) THEN ---HERRAMIENTA DESCUENTO
     
        SELECT count (1) into V_CONTADOR 
        FROM t_icom_producto_descuento D 
        WHERE D.IDINVERSION = P_ID;
        
     ELSIF (P_HERRAMIENTA=2) THEN ---- HERRAMIENTA PRODUCTO REGALO
        
         SELECT count (1) into V_CONTADOR 
        FROM t_icom_productodistribucion D 
        WHERE D.IDINVERSION = P_ID;
        
     END IF;
     
     IF V_CONTADOR>0 THEN 
        RETURN 1;
     ELSE 
        RETURN 0;
     END IF;
     
     END F_TieneHerramienta;
    
    /*Funcion que verifica si existe gasto material 1 caso contrario 0*/
    FUNCTION F_ExisteGastoMaterial( P_ID NUMBER ) RETURN NUMBER AS
    v_cuenta number;
    BEGIN
        select count(1) into v_cuenta
        from data.T_ICOM_CLIENTE_MATERIAL
        where idinversion = P_ID ;
        
        if v_cuenta > 0 then    
            return 1 ;
        end if;
        return 0 ;
    END F_ExisteGastoMaterial ;
    
    /*Funcion que retorna 1 en caso de que sea el ejecutivo o el negociador 0 si no lo es*/
    FUNCTION F_EjecutivoNegociador(P_CODIGOGRUPO VARCHAR2, P_USUARIO VARCHAR2, P_COMPANIA VARCHAR2) RETURN NUMBER AS
        v_ejecutivo number;
        v_negociador number ;
        v_cuenta number := 0  ;
    BEGIN
        v_negociador := PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES ( P_CODIGOMODULO => G_MODULO, 
                                                                          P_CODIGOUSUARIO => P_USUARIO , 
                                                                          P_RUTAPAGINA => 300    , 
                                                                          P_CODIGOACCION => 'NEGOCIADOR');
        if v_negociador = 1 then
            return 1 ;
        end if;
        
        v_ejecutivo := CASE WHEN v_negociador=1 THEN 0 
                            ELSE PK_ICOM_COMMONS.F_ESEJECUTIVO(P_USUARIO=> P_USUARIO , P_COMPANIA=> P_COMPANIA) END;

        select count(1) into v_cuenta
        from data.vt_gzm_cliente v 
        where v.compania = p_compania 
        and v.codigocliente = P_CODIGOGRUPO
        and ( v.ejecutivo = (select NUMEROIDENTIFICACION from data.VT_CORP_USUARIO where NOMBREUSUARIO=P_USUARIO ));
        
        return CASE WHEN nvl(v_cuenta,0) > 0 THEN 1 ELSE  0 END;
    END F_EjecutivoNegociador;
    
    /*Funcion que retorna el estado del grupo de cliente */
    FUNCTION F_EstadoGrupo (P_CODIGOGRUPO VARCHAR2, P_ID NUMBER ) RETURN NUMBER AS
        V_ESTADO NUMBER;
    BEGIN
        SELECT ESTADO INTO V_ESTADO 
        FROM DATA.T_ICOM_INVERSION_CLIENTE_G
        WHERE IDINVERSION = P_ID
        AND CODIGOGRUPO = P_CODIGOGRUPO;
        
        RETURN V_ESTADO;
    END F_EstadoGrupo;
    
    /*Funcion que retorna 1 si el cliente, fechas o material pop fue modificado*/
    /* P_ID id de la inversion donde se esta haciendo la replanificacion
       P_IDPARE id de la inversion a la que se quiere replanificar
       P_TIPO 0 original 1 replanificada*/
    FUNCTION F_EsClienteReplanificado (P_ID NUMBER, P_IDPADRE NUMBER, P_CODIGOGRUPO VARCHAR2) RETURN NUMBER AS
        v_cuenta number;
    BEGIN 
        --primero veriricamos que los clientes no sean diferentes
        if DATA.PK_ICOM_CRUD.F_ELEMENTOREPLANIFICADO( P_TIPO => 'CLI_SELECCION',
                                                    P_ID => P_ID,
                                                    P_IDPADRE => P_IDPADRE,
                                                    P_CODIGOGRUPO => P_CODIGOGRUPO
                                                  ) = 0 then return 1 ;
        end if;
        
        --se verifica que las fechas no sean diferentes
        if DATA.PK_ICOM_CRUD.F_ELEMENTOREPLANIFICADO( P_TIPO => 'CLIENTEFECHAS',
                                                    P_ID => P_ID,
                                                    P_IDPADRE => P_IDPADRE,
                                                    P_CODIGOGRUPO => P_CODIGOGRUPO
                                                  ) = 0  then return 1 ;
        end if;
        
        --se verifica que el material pop no sea diferente
        if DATA.PK_ICOM_CRUD.F_ELEMENTOREPLANIFICADO( P_TIPO => 'CLI_MATERIALPOP',
                                                    P_ID => P_ID,
                                                    P_IDPADRE => P_IDPADRE,
                                                    P_CODIGOGRUPO => P_CODIGOGRUPO
                                                  ) = 0  then return 1 ;
        end if;
        
        return 0 ;
    END F_EsClienteReplanificado ;
    
    /* Procedimiento para grabar la auditoria de las inversiones*/
	PROCEDURE SP_Auditoria ( P_USUARIO VARCHAR2, P_IDINVERSION NUMBER, P_IDETAPA NUMBER, P_CODIGOGRUPO VARCHAR2 DEFAULT NULL,
							P_IDACCION VARCHAR2, P_DESCRIPCION VARCHAR2) AS
		V_TABLA VARCHAR(50) := 'T_ICOM_AUDITORIA|';					
    BEGIN
		--BUSCAMOS EL ID
		
		INSERT INTO T_ICOM_AUDITORIA (idauditoria, fecha, usuario, idinversion, idetapa, codigogrupo, idaccion, descripcion)
		VALUES (DATA.PK_COMMONS.F_SECUENCIA (V_TABLA), sysdate, P_USUARIO, P_IDINVERSION, P_IDETAPA, P_CODIGOGRUPO, P_IDACCION, P_DESCRIPCION) ;
		
	EXCEPTION
		when others then
			v_tabla := '';
	END SP_Auditoria;
							
    /*Proceso automatico para modificar el analista de la inverciones que no esten cerradas
        PK_ICOM_COMMONS.SP_actualizaAnalista();
    */
    PROCEDURE SP_actualizaAnalista AS
    BEGIN
        --buscamos todas las inversiones que cumplan la condicion y actualizamos
        update T_ICOM_INVERSIONES
        set IDANALISTA = F_ANALISTA(P_INVERSIONTIPO => IDINVERSIONTIPO , P_AREA => IDAREA , P_COMPANIA => compania)
        where IDETAPA IN (1,2,3,4) AND ESTADO IN (1) AND idpadre is null
        AND F_ANALISTA(P_INVERSIONTIPO => IDINVERSIONTIPO , P_AREA => IDAREA , P_COMPANIA => compania) IS NOT NULL;
        commit;
    END SP_actualizaAnalista;
    /*Funcion para identificar si el elemento tiene informacion de ayuda o no.
      @param P_ELEMENTO VARCHAR id elemento
      @param P_INVERSIONTIPO VARCHAR id tipo de inversion
      @param P_TIPO VARCHAR bandera para identificar {1:si; 2:no}
      @param P_COMPANIA VARCHAR codigo de compania
      RETURN 1 como true y 0 como false
      Modo de uso:
      PK_ICOM_COMMONS.F_ELEMENTO(P_ELEMENTO => P_ELEMENTO, P_INVERSIONTIPO => P_INVERSIONTIPO, P_TIPO => P_TIPO, P_COMPANIA => P_COMPANIA);
    */   
     FUNCTION F_ELEMENTO_INFORMACION (P_ELEMENTO VARCHAR, P_COMPANIA VARCHAR,P_INVERSIONTIPO NUMBER DEFAULT NULL) RETURN NUMBER
     AS
     V_CONTADOR NUMBER:=0;
     BEGIN
        --SELECT COUNT(DISTINCT 1) FROM VT_ICOM_ELEMENTOS_INFORMACION EEI WHERE EEI.IDOBJETO=E.IDELEMENTO AND IEE.COMPANIA=EEI.COMPANIA
        SELECT COUNT(distinct 1)  INTO  V_CONTADOR 
        FROM VT_ICOM_CONF_INVER_ETAPA_ELEM IEE
        INNER JOIN VT_ICOM_ELEMENTOS_INFORMACION EEI  ON EEI.IDOBJETO=IEE.IDELEMENTO AND IEE.COMPANIA=EEI.COMPANIA
        WHERE 1=1
        AND (IEE.COMPANIA=P_COMPANIA )
        AND (IEE.IDELEMENTO=P_ELEMENTO)
        AND (IEE.IDINVERSIONTIPO=P_INVERSIONTIPO OR P_INVERSIONTIPO IS NULL)
        AND (IEE.ESTADO=1)
        and (IEE.AYUDA=1)
        ;
        RETURN V_CONTADOR;
     END F_ELEMENTO_INFORMACION;  
     
    procedure SP_ActualizarTodosProductos (P_IDINVERSION number default null, P_TIPO NUMBER default 1, P_COMPANIA VARCHAR default '00001') AS
--    declare  P_IDINVERSION number:=21394; P_TIPO NUMBER :=1;P_COMPANIA VARCHAR(5) :='00001';
        v_tipo number;
        v_fechaini date;
        v_fechafin date;
        v_numeromeses number;
        v_cont number;

    begin
        v_tipo :=P_TIPO;

        begin
            v_numeromeses:=nvl( PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '6',p_compania),0);
        exception when others then
            v_numeromeses :=12;
        end;
        --DBMS_OUTPUT.PUT_LINE(' v_numeromeses):'||v_numeromeses);
        v_fechafin    :=TRUNC(LAST_DAY(sysdate));
        
        v_fechaini    := trunc(add_months(v_fechafin,-v_numeromeses),'Month');

        --DBMS_OUTPUT.PUT_LINE(' v_fechaini :'||v_fechaini||' v_fechafin :'||v_fechafin);

        FOR INVERSION IN (SELECT distinct i.id idinversion FROM T_ICOM_INVERSIONES I 
        WHERE  (I.ID=P_IDINVERSION or (PRODUCTOTODO=1 and P_IDINVERSION is null))  AND I.IDETAPA IN (2,3,7))
        LOOP
            --DBMS_OUTPUT.PUT_LINE(' INVERSION.idinversion :'||INVERSION.idinversion);
            INSERT INTO DATA.T_ICOM_INVERSION_PRODUCTO 
                           (  IDINVERSION,  CODIGOPRODUCTO,        PRODUCTO,  tipo,NUEVO,  LINEANEGOCIO,  MARCA,  SUBMARCA,  CODIGOBARRA,  CODIGOPRODUCTOPADRE)
            SELECT DISTINCT C.IDINVERSION,P.CODIGOPRODUCTO,P.NOMBREPRODUCTO,v_tipo,    0,P.LINEANEGOCIO,P.MARCA,P.SUBMARCA,P.CODIGOBARRA,P.CODIGOPRODUCTOPADRE
                from t_trad_sellin S
                INNER JOIN T_ICOM_INVERSION_CLIENTE C ON (S.codigogrupo=C.codigogrupo AND  C.IDINVERSION=INVERSION.IDINVERSION and s.compania=p_compania)
                INNER JOIN VT_GZM_PRODUCTO P ON (P.CODIGOPRODUCTO=S.CODIGOPRODUCTO)
                where TRUNC(fecha) between v_fechaini  and v_fechafin and VALORVENTA>0
                AND NOT EXISTS (SELECT 1 FROM T_ICOM_INVERSION_PRODUCTO P1 WHERE P1.IDINVERSION=C.IDINVERSION AND P1.CODIGOPRODUCTO=P.CODIGOPRODUCTO);
            
            PK_ICOM_HERRAMIENTAS.SP_SIMULADORDESCUENTO_CALCULAR(P_ID => INVERSION.IDINVERSION, P_MESES=>v_numeromeses,P_TIPO_CALCULO=>2);
        commit;
        END LOOP;
       
     EXCEPTION WHEN OTHERS THEN
         dbms_output.put_line('Error en ejecucion. SQLERRM: '||SQLERRM||' TRACE: '||DBMS_UTILITY.format_error_backtrace);

    end SP_ActualizarTodosProductos;

    function f_traervalorudc(P_ID_CABECERA varchar2, p_id_tabla  varchar2 , p_COMPANIA varchar2,tipo  varchar2 DEFAULT 'VALOR',p_VALOR varchar2 DEFAULT NULL,p_ACTIVO varchar2 DEFAULT NULL) return varchar2 as
     V_RETURNO varchar2(3999);
    begin
         SELECT
            case upper(nvl(trim(tipo),'VALOR' ))  
                when 'DESCRIPCION' THEN DESCRIPCION 
                when 'VALOR' THEN VALOR 
                when 'VALOR2' THEN VALOR2 
                when 'ACTIVO' THEN ACTIVO 
                when 'DESCRIPCION2' THEN DESCRIPCION2 
                when 'VIGENCIADESDE' THEN TO_CHAR(VIGENCIADESDE,'DD/MM/YYYY' )
                when 'VIGENCIAHASTA' THEN TO_CHAR(VIGENCIAHASTA,'DD/MM/YYYY' )
                when 'DESCRIPCION3' THEN DESCRIPCION3 
                when 'VALOR3' THEN VALOR3 
            END 
            INTO V_RETURNO
         FROM DATA.T_CORP_UDC
         WHERE (ID_CABECERA=P_ID_CABECERA)
         and (id_tabla =p_id_tabla OR p_id_tabla IS NULL)
         and (CODIGOCOMPANIA=p_COMPANIA or p_COMPANIA IS NULL)
         AND (VALOR = p_VALOR OR p_VALOR IS NULL)
         AND (ACTIVO = p_ACTIVO OR p_ACTIVO IS NULL)
         ;
         RETURN V_RETURNO;
    EXCEPTION WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20000, 'No existe tabla general '||p_id_tabla ||' en '||P_ID_CABECERA||' se debe llenar esa tabla general.'); 
         
    end f_traervalorudc;

function f_traervalorudcbydesc(P_ID_CABECERA varchar2, p_id_tabla  varchar2 DEFAULT NULL, p_COMPANIA varchar2 DEFAULT NULL,tipo  varchar2 DEFAULT 'VALOR',p_DESCRIPCION varchar2 DEFAULT NULL,p_ACTIVO varchar2 DEFAULT NULL) return varchar2 as
     V_RETURNO varchar2(3999);
    begin
         SELECT
            case upper(nvl(trim(tipo),'VALOR' ))  
                when 'DESCRIPCION' THEN DESCRIPCION 
                when 'ID_TABLA' THEN ID_TABLA 
                when 'VALOR' THEN VALOR 
                when 'VALOR2' THEN VALOR2 
                when 'ACTIVO' THEN ACTIVO 
                when 'DESCRIPCION2' THEN DESCRIPCION2 
                when 'VIGENCIADESDE' THEN TO_CHAR(VIGENCIADESDE,'DD/MM/YYYY' )
                when 'VIGENCIAHASTA' THEN TO_CHAR(VIGENCIAHASTA,'DD/MM/YYYY' )
                when 'DESCRIPCION3' THEN DESCRIPCION3 
                when 'VALOR3' THEN VALOR3 
            END 
            INTO V_RETURNO
         FROM DATA.T_CORP_UDC
         WHERE (ID_CABECERA=P_ID_CABECERA)
         and (id_tabla =p_id_tabla OR p_id_tabla IS NULL)
         and (CODIGOCOMPANIA=p_COMPANIA or p_COMPANIA IS NULL)
         AND (descripcion = p_DESCRIPCION OR p_DESCRIPCION IS NULL)
         AND (ACTIVO = p_ACTIVO OR p_ACTIVO IS NULL)
         ;
         RETURN V_RETURNO;
    EXCEPTION WHEN OTHERS THEN
        V_RETURNO:=NULL;
        RAISE;
    end f_traervalorudcbydesc;

END PK_ICOM_COMMONS;
/
/

