CREATE OR REPLACE EDITIONABLE PACKAGE BODY PK_SAP_GUATEMALA AS

  -- Consulta los clientes de SAP Guatemala sin alterar el contrato vigente.
  FUNCTION FN_GET_CLIENTES_GTM_P
    RETURN T_GZM_CLIENTE_GTM_TAB PIPELINED
  IS
  BEGIN
    FOR c IN (
      SELECT
        c."DocEntry",
        c."CardCode",
        c."U_AGRUPACION",
        c."CardName",
        c."City",
        c."U_CANAL",
        c."Country",
        c."validFor",
        c."LicTradNum",
        c."SlpCode",
        o."SlpName"
      FROM OCRD@HANA_ABX c
      LEFT JOIN OSLP@HANA_ABX o
        ON c."SlpCode" = o."SlpCode"
      WHERE c."CardType" = 'C'
    ) LOOP
      PIPE ROW(
        T_GZM_CLIENTE_GTM_OBJ(
          c."DocEntry",
          c."CardCode",
          CASE
            WHEN c."U_AGRUPACION" IS NULL
              OR TRIM(c."U_AGRUPACION") = ''
              OR UPPER(TRIM(c."U_AGRUPACION")) = 'NO APLICA'
            THEN TO_CHAR(c."CardCode")
            ELSE c."U_AGRUPACION"
          END,
          c."CardName",
          CASE
            WHEN c."U_AGRUPACION" IS NULL
              OR TRIM(c."U_AGRUPACION") = ''
              OR UPPER(TRIM(c."U_AGRUPACION")) = 'NO APLICA'
            THEN c."CardName"
            ELSE c."U_AGRUPACION"
          END,
          c."City",
          c."U_CANAL",
          c."U_CANAL",
          c."Country",
          CASE WHEN c."Country" = 'GT' THEN 'NAC' ELSE 'EXT' END,
          CASE WHEN c."validFor" = 'Y' THEN 1 ELSE 0 END,
          c."LicTradNum",
          c."SlpName",
          c."SlpCode",
          c."U_CANAL",
          '00015'
        )
      );
    END LOOP;
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN;
  END FN_GET_CLIENTES_GTM_P;

  --
  -- Publica el maestro de productos de SAP Guatemala con las reglas vigentes del
  -- job de dimensión: código de barras preferido, marca descriptiva, tipo de
  -- producto y estado comercial. Conserva los dieciocho atributos consumidos por
  -- SP_CARGA_ERPGUATEMALA.
  --
  FUNCTION FN_GET_PRODUCTOS_GTM_P
    RETURN T_GZM_PRODUCTO_GTM_TAB PIPELINED
  IS
  BEGIN
    FOR p IN (
      WITH tipo_producto AS (
        SELECT
          t1."FldValue",
          t1."Descr"
        FROM CUFD@HANA_ABX t0
        INNER JOIN UFD1@HANA_ABX t1
          ON t0."TableID" = t1."TableID"
         AND t0."FieldID" = t1."FieldID"
        WHERE t0."TableID" = 'OITM'
          AND t0."AliasID" = 'Item'
      )
      SELECT
        i."DocEntry",
        i."ItemCode",
        i."ItemName",
        i."CodeBars",
        i."InvntryUom",
        i."U_Agrupador01",
        i."U_MarcaF",
        m."Name" AS "Name_U_Marca",
        i."U_SUBMARCA",
        i."validFor",
        i."U_Item",
        cb."Name" AS "CodigoBarraPreferido",
        tp."Descr" AS "DescripcionTipo"
      FROM OITM@HANA_ABX i
      LEFT JOIN "@FACMARCA"@HANA_ABX m
        ON i."U_MarcaF" = m."Code"
      LEFT JOIN "@CODBAR"@HANA_ABX cb
        ON cb."Code" = i."ItemCode"
      LEFT JOIN tipo_producto tp
        ON tp."FldValue" = i."U_Item"
      WHERE i."ItemCode" IS NOT NULL
    ) LOOP
      PIPE ROW(
        T_GZM_PRODUCTO_GTM_OBJ(
          p."DocEntry",
          p."ItemCode",
          p."ItemCode",
          p."ItemCode",
          NVL(UPPER(p."ItemName"), 'NA'),
          NVL(NULLIF(TRIM(p."CodigoBarraPreferido"), ''), NVL(NULLIF(TRIM(p."CodeBars"), ''), p."ItemCode")),
          SUBSTR(NVL(UPPER(p."ItemName"), p."ItemCode"), 1, 60),
          NVL(UPPER(p."InvntryUom"), 'NA'),
          NVL(UPPER(p."U_Agrupador01"), 'NA'),
          NVL(UPPER(p."U_Agrupador01"), 'NA'),
          NVL(UPPER(p."U_MarcaF"), 'NA'),
          NVL(UPPER(p."Name_U_Marca"), 'NA'),
          NVL(UPPER(p."U_SUBMARCA"), 'NA'),
          NVL(UPPER(p."U_SUBMARCA"), 'NA'),
          CASE WHEN p."validFor" = 'Y' THEN 1 ELSE 0 END,
          NVL(UPPER(p."DescripcionTipo"), NVL(UPPER(p."U_Item"), 'NA')),
          '00015',
          p."ItemCode"
        )
      );
    END LOOP;
    RETURN;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN;
  END FN_GET_PRODUCTOS_GTM_P;

END PK_SAP_GUATEMALA;
/
