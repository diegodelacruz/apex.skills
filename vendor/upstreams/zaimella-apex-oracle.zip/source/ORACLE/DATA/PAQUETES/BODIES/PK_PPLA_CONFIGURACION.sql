CREATE OR REPLACE PACKAGE BODY DATA.PK_PPLA_CONFIGURACION AS

-- funciÃƒÂ³n para determinar si el producto estÃƒÂ¡ en agotamiento
-- tabla T_VTAS_PRODUCTOAGOTAMIENTO
FUNCTION F_VERIFICAAGOTAMIENTO(P_ITEM IN VARCHAR)
                RETURN NUMBER
IS
V_EXISTE NUMBER;
BEGIN
BEGIN
  SELECT 1 INTO V_EXISTE FROM T_VTAS_PRODUCTOAGOTAMIENTO
  WHERE TRIM(P_ITEM)=TRIM(CODIGOPRODUCTO);
   dbms_output.put_line(V_EXISTE);
EXCEPTION
     WHEN no_data_found THEN
     V_EXISTE:=0;
     dbms_output.put_line('Item no estÃƒÂ¡ en agotamiento: '|| P_ITEM);
END;
    RETURN V_EXISTE;

END F_VERIFICAAGOTAMIENTO;

-- funciÃƒÂ³n para determinar si el producto estÃƒÂ¡ inactivo
-- vista VT_GZM_PRODUCTO
FUNCTION F_VERIFICAINACTIVO(P_ITEM IN VARCHAR)
                RETURN NUMBER
IS
V_EXISTE NUMBER;

BEGIN

BEGIN
  SELECT 1 INTO V_EXISTE FROM VT_GZM_PRODUCTO
  WHERE TRIM(P_ITEM)=TRIM(CODIGOPRODUCTO) AND ESTADO=0;
   dbms_output.put_line(V_EXISTE);
EXCEPTION
     WHEN no_data_found THEN
     V_EXISTE:=0;
     dbms_output.put_line('Item no estÃƒÂ¡ en agotameinto: '|| P_ITEM);
END;
    RETURN V_EXISTE;

END F_VERIFICAINACTIVO;

-- funciÃƒÂ³n para determinar si el producto tiene inversiÃƒÂ³n comercial
-- se lo realiza por cada mes a procesar
  FUNCTION F_VERIFICAINVERSION(P_ITEM IN VARCHAR,P_FECHA IN DATE DEFAULT TRUNC(SYSDATE,'MM'))
                RETURN NUMBER
IS
V_EXISTE NUMBER;
V_PERIODO VARCHAR(10) :='';
V_COLUMNA  VARCHAR(3) :='';
BEGIN


   SELECT count(P.IDINVERSION) INTO V_EXISTE
   FROM T_ICOM_INVERSION_PRODUCTO P
   INNER JOIN T_ICOM_INVERSIONES I ON (I.ID=P.IDINVERSION AND P.CODIGOPRODUCTO=P_ITEM)
   WHERE P_FECHA BETWEEN TRUNC(FECHAINICIO, 'MM') AND LAST_DAY(FECHAFIN)
   AND IDETAPA IN (2,3,7) AND IDPADRE IS NULL AND IDINVERSIONTIPO=1;--- SOLO PROMOCIONES

    RETURN V_EXISTE;

END F_VERIFICAINVERSION;

/*
  funciÃƒÂ³n pera determinar si la capacidad de la mÃƒÂ¡quina estÃƒÂ¡ acorde al lo calculado
  en el plan de producciÃƒÂ³n
*/
FUNCTION F_VERIFICACAPACIDAD(P_MAQUINA IN VARCHAR,P_FECHA DATE DEFAULT SYSDATE)    RETURN NUMBER
IS
    V_EXISTE NUMBER;
BEGIN
    WITH PRODUCCION AS (SELECT  SUM(HORAS_MAQUINA) HORAS_MAQUINA, CODIGO_MAQUINA FROM  DATA.VT_PPLA_PLANPRODUCCION
                     WHERE FECHA=TRUNC(P_FECHA,'MM')  AND CODIGO_MAQUINA=P_MAQUINA  AND HORAS_MAQUINA>0 GROUP BY CODIGO_MAQUINA)
        SELECT
         CASE WHEN HORAS_MAQUINA>(CAPACIDAD) THEN 1 ELSE 0 END INTO V_EXISTE
        FROM PRODUCCION X
        left JOIN DATA.VT_PPLA_MAQUINAMES Y ON Y.CODIGOMAQUINA=X.CODIGO_MAQUINA AND TRUNC(P_FECHA,'MM') BETWEEN FECHADESDE AND FECHAHASTA;

        RETURN V_EXISTE;

END F_VERIFICACAPACIDAD;

-------------------------------------------------------------------------------------------------------

PROCEDURE SP_PROCESACARGASTOCKINICIAL (
          P_COMPANIA IN VARCHAR2,
          P_USUARIO IN VARCHAR2) AS

  V_EXISTE  NUMBER :=0;
  V_CONTOBSOLETOS  NUMBER  :=0;
  V_OBSOLETOS  VARCHAR2(3000) :='';

BEGIN

    -- 1. verifico que los Items no estÃƒÆ’Ã‚Â©n marcadas como obsoletas
     SELECT COUNT(*),LISTAGG(TRIM(C02) , ',') WITHIN GROUP (ORDER BY C02)
     INTO V_CONTOBSOLETOS,V_OBSOLETOS
     FROM VT_APEX_EXCEL
     WHERE P_COMPANIA = '00001'
       AND EXISTS (SELECT 'X'
                   FROM F4101@JDEDTADL
                   WHERE TRIM(IMLITM)=TRIM(C02) AND TRIM(IMSTKT)='O'
                  );

     IF NVL(V_CONTOBSOLETOS,0)>0 THEN

        apex_error.add_error (
        p_message          => 'Producto(s): '||V_OBSOLETOS||'<p> marcados como OBSOLETOS en el archivo a cargar. Revise por favor.',
        p_display_location => apex_error.c_inline_in_notification );

        RETURN;  -- se finaliza el proceso

     END IF;

    -- 2. verifico que los items a procesar existan en JDE
     SELECT COUNT(*),LISTAGG(TRIM(C02) , ',') WITHIN GROUP (ORDER BY C02)
     INTO V_EXISTE,V_OBSOLETOS
     FROM VT_APEX_EXCEL
     WHERE NOT EXISTS (SELECT 'X'
                   FROM VT_GZM_PRODUCTO
                   WHERE COMPANIA = P_COMPANIA
                     AND TRIM(CODIGOPRODUCTO)=TRIM(C02)
                  );

     IF NVL(V_EXISTE,0)>0 THEN

        apex_error.add_error (
        p_message          => 'Producto(s): '||V_OBSOLETOS||' a procesar, NO EXISTEN en JDE. Revise por favor.',
        --p_display_location => apex_error.c_on_error_page );
        p_display_location => apex_error.c_inline_in_notification );

        RETURN;  -- se finaliza el proceso

     END IF;

     V_EXISTE:='';

     -- 3. verifico que no existan items duplicados
     BEGIN
         SELECT COUNT(*) INTO V_EXISTE
         FROM VT_APEX_EXCEL
         GROUP BY TRIM(C02)
         HAVING COUNT(*)>1;
       EXCEPTION WHEN TOO_MANY_ROWS THEN V_EXISTE:=1;
         WHEN NO_DATA_FOUND THEN NULL;
      END;

    IF NVL(V_EXISTE,0)>0 THEN
        apex_error.add_error (
        p_message          => 'CÃƒÂ³digo de Items duplicados en el archivo a cargar. Revise por favor.',
        p_display_location => apex_error.c_inline_in_notification );

        RETURN;  -- se finaliza el proceso

     END IF;

    -- 4. inserto los datos en la tabla

    INSERT INTO T_PPLA_PRODUCTOSTOCKIDEAL (
              CODIGOPRODUCTO,STOCKINICIALIDEAL, FECHADESDE,FECHAHASTA, AUDITORIAUSUARIO,AUDITORIAFECHA,COMPANIA)
    SELECT C02,replace(c03,'.',','),
    TRUNC(SYSDATE),TO_DATE('31/12/2040'),P_USUARIO,TRUNC(SYSDATE, 'MM'),P_COMPANIA
	FROM vt_apex_excel
    WHERE NOT EXISTS (SELECT 'X' FROM T_PPLA_PRODUCTOSTOCKIDEAL
                      WHERE TRIM(CODIGOPRODUCTO)=TRIM(C02)
                      AND TO_CHAR(FECHAHASTA,'YYYYMMDD')='20401231'
                      AND COMPANIA = P_COMPANIA);


END SP_PROCESACARGASTOCKINICIAL;

PROCEDURE SP_PROCESACARGASCOSTOSTANDARD (
          P_COMPANIA IN VARCHAR2,
          P_USUARIO IN VARCHAR2) AS

  V_EXISTE  NUMBER :=0;
  V_CONTOBSOLETOS  NUMBER  :=0;
  V_OBSOLETOS  VARCHAR2(3000) :='';

BEGIN

    /* C01 es solo numero de fila; C02 y C03 son SKU y costo del archivo. */
    SELECT COUNT(*)
      INTO V_EXISTE
      FROM VT_APEX_EXCEL
     WHERE C01 > 1
       AND (TRIM(C02) IS NULL OR C03 IS NULL OR NOT REGEXP_LIKE(REPLACE(TRIM(C03), ',', '.'), '^[0-9]+([.][0-9]+)?$'));

    IF V_EXISTE > 0 THEN
        apex_error.add_error(
            p_message => 'El archivo debe contener SKU en C02 y costo numerico en C03.',
            p_display_location => apex_error.c_inline_in_notification);
        RETURN;
    END IF;

    -- 1. verifico que los Items no estÃƒÆ’Ã‚Â©n marcadas como obsoletas
     SELECT COUNT(*),LISTAGG(TRIM(C02) , ',') WITHIN GROUP (ORDER BY C02)
     INTO V_CONTOBSOLETOS,V_OBSOLETOS
     FROM VT_APEX_EXCEL
     WHERE C01 > 1
       AND EXISTS (SELECT 'X'
                   FROM F4101@JDEDTADL
                   WHERE TRIM(IMLITM)=TRIM(C02) AND TRIM(IMSTKT)='O'
                  );

     IF NVL(V_CONTOBSOLETOS,0)>0 THEN

        apex_error.add_error (
        p_message          => 'Producto(s): '||V_OBSOLETOS||'<p> marcados como OBSOLETOS en el archivo a cargar. Revise por favor.',
        p_display_location => apex_error.c_inline_in_notification );

        RETURN;  -- se finaliza el proceso

     END IF;

    -- 2. verifico que los items a procesar existan en JDE
     SELECT COUNT(*),LISTAGG(TRIM(C02) , ',') WITHIN GROUP (ORDER BY C02)
     INTO V_EXISTE,V_OBSOLETOS
     FROM VT_APEX_EXCEL
     WHERE C01 > 1
       AND NOT EXISTS (SELECT 'X'
                   FROM F4101@JDEDTADL
                   WHERE TRIM(IMLITM)=TRIM(C02)
                  );

     IF NVL(V_EXISTE,0)>0 THEN

        apex_error.add_error (
        p_message          => 'Producto(s): '||V_OBSOLETOS||' a procesar, NO EXISTEN en JDE. Revise por favor.',
        --p_display_location => apex_error.c_on_error_page );
        p_display_location => apex_error.c_inline_in_notification );

        RETURN;  -- se finaliza el proceso

     END IF;

     V_EXISTE:='';

     -- 3. verifico que no existan items duplicados
     BEGIN
         SELECT COUNT(*) INTO V_EXISTE
         FROM VT_APEX_EXCEL
         WHERE C01 > 1
         GROUP BY TRIM(C02)
         HAVING COUNT(*)>1;
       EXCEPTION WHEN TOO_MANY_ROWS THEN V_EXISTE:=1;
         WHEN NO_DATA_FOUND THEN NULL;
      END;

    IF NVL(V_EXISTE,0)>0 THEN
        apex_error.add_error (
        p_message          => 'CÃƒÂ³digo de Items duplicados en el archivo a cargar. Revise por favor.',
        p_display_location => apex_error.c_inline_in_notification );

        RETURN;  -- se finaliza el proceso

     END IF;

    /*
      El archivo es la fuente vigente: expirar conserva historial y evita
      borrar datos que participan en auditorias o cierres anteriores.
    */
    UPDATE T_PPLA_PRODUCTOS_COSTO_STANDARD COSTO
       SET FECHAHASTA = TRUNC(SYSDATE) - 1,
           AUDITORIAUSUARIO = P_USUARIO,
           AUDITORIAFECHA = SYSDATE
     WHERE COSTO.COMPANIA = TRIM(P_COMPANIA)
       AND COSTO.FECHAHASTA >= TRUNC(SYSDATE)
       AND NOT EXISTS (
           SELECT 1
             FROM VT_APEX_EXCEL EXCEL
            WHERE EXCEL.C01 > 1
              AND TRIM(EXCEL.C02) = TRIM(COSTO.CODIGOPRODUCTO)
       );

    MERGE INTO T_PPLA_PRODUCTOS_COSTO_STANDARD COSTO
    USING (
        SELECT TRIM(C02) CODIGOPRODUCTO,
               TO_NUMBER(REPLACE(TRIM(C03), ',', '.'), '999999999999999D999999999999999', 'NLS_NUMERIC_CHARACTERS=''.,''') COSTOSTANDARD
          FROM VT_APEX_EXCEL
         WHERE C01 > 1
    ) EXCEL
       ON (COSTO.COMPANIA = TRIM(P_COMPANIA)
           AND COSTO.FECHAHASTA >= TRUNC(SYSDATE)
           AND TRIM(COSTO.CODIGOPRODUCTO) = EXCEL.CODIGOPRODUCTO)
     WHEN MATCHED THEN UPDATE SET
        COSTO.COSTOSTANDARD = EXCEL.COSTOSTANDARD,
        COSTO.FECHADESDE = TRUNC(SYSDATE),
        COSTO.AUDITORIAUSUARIO = P_USUARIO,
        COSTO.AUDITORIAFECHA = SYSDATE;

    -- Insertar solamente los SKU nuevos del archivo.

    INSERT INTO DATA.T_PPLA_PRODUCTOS_COSTO_STANDARD (
              CODIGOPRODUCTO,COSTOSTANDARD, FECHADESDE,FECHAHASTA, AUDITORIAUSUARIO,AUDITORIAFECHA,COMPANIA)
    SELECT TRIM(C02),
           TO_NUMBER(REPLACE(TRIM(C03), ',', '.'), '999999999999999D999999999999999', 'NLS_NUMERIC_CHARACTERS=''.,'''),
    TRUNC(SYSDATE),TO_DATE('31/12/2040'),P_USUARIO,TRUNC(SYSDATE, 'MM'),P_COMPANIA
	FROM vt_apex_excel
    WHERE C01 > 1
      AND NOT EXISTS (SELECT 'X' FROM T_PPLA_PRODUCTOS_COSTO_STANDARD
                      WHERE TRIM(CODIGOPRODUCTO)=TRIM(C02)
                      AND COMPANIA = TRIM(P_COMPANIA)
                      AND TO_CHAR(FECHAHASTA,'YYYYMMDD')='20401231');


END SP_PROCESACARGASCOSTOSTANDARD;

PROCEDURE SP_ACTUALIZA_STOCKIDEALINICIAL (
          P_COMPANIA IN VARCHAR2,
          P_USUARIO IN VARCHAR2) AS

   CURSOR CAMBIOS IS
     SELECT CASE WHEN CODTIPO IN ('SEM   ','PTE   ') THEN 'PRODUCTO TERMINADO' ELSE 'MATERIA PRIMA' END TIPO,
        SUM(STOCKINICIALIDEAL*(COUNCS/10000)) VALOR,
        SUM(NVL(replace(C03,'.',','),X.STOCKINICIALIDEAL)*(COUNCS/10000)) VALOR2,
        ( (SUM(NVL(replace(C03,'.',','),X.STOCKINICIALIDEAL)*(COUNCS/10000)) - SUM(STOCKINICIALIDEAL*(COUNCS/10000))) /
         SUM(STOCKINICIALIDEAL*(COUNCS/10000)) )*100 VARIACION
     FROM  T_PPLA_PRODUCTOSTOCKIDEAL X,VT_JDE_PRODUCTOS Y,F4105@JDEDTADL, VT_APEX_EXCEL Z
     WHERE X.CODIGOPRODUCTO=Y.CODIGOPRODUCTO
     AND X.CODIGOPRODUCTO=TRIM(COLITM) AND TO_CHAR(FECHAHASTA,'YYYYMMDD')>TO_CHAR(SYSDATE,'YYYYMMDD')
     AND COMCU= CASE WHEN CODTIPO IN ('SEM   ','PTE   ') THEN '       17003' ELSE '       17001' END
     AND COCSIN='I'
     AND TRIM(X.CODIGOPRODUCTO)=TRIM(Z.C02(+))
     GROUP BY CODTIPO;

   V_EXISTE  NUMBER :=0;
   V_CONTOBSOLETOS  NUMBER  :=0;

   P_TO            VARCHAR2(250);
   P_CC            VARCHAR2(250);
   P_FROM          VARCHAR2(250);
   P_SUBJECT       VARCHAR2(250);
   P_TEXT_MSG      VARCHAR2(250);
   L_BODY_HTML     CLOB;
   L_BODY          CLOB;
   CRLF            VARCHAR2(2)  := chr(13)||chr(10);

BEGIN

  -- notifico a planificadores y finanzas
    P_TO:=',malban@zaimella.com';
    P_FROM:='Notificacion@zaimella.com';
    P_SUBJECT:='Stock Ideal Inicial';
    P_TEXT_MSG:='  ';

    dbms_lob.createtemporary(l_body, true);

    dbms_lob.createtemporary(l_body_html, true);

    --dbms_lob.freetemporary(l_body_html,true);

    l_body := 'To view the content of this message, please use an HTML enabled mail client.'||utl_tcp.crlf;

    l_body_html := '<html>
        <head>
             <style type="text/css">
                body{font-family: Arial, Helvetica, sans-serif;
                    font-size:10pt;
                    margin:30px;
                    background-color:#ffffff;}

                span.sig{font-style:italic;
                    font-weight:bold;
                    color:#811919;}
             </style>
        </head>
        <meta charset="UTF-8">
        <body>'||utl_tcp.crlf;

        l_body_html := l_body_html ||'<p>Estimados(as),'||utl_tcp.crlf;

        l_body_html := l_body_html ||'<p>Se realizaron cambios en el stock inicial ideal. Para mÃƒÂ¡s detalles, ver en el portal de planificaciÃƒÂ³n.'||utl_tcp.crlf;

        l_body_html := l_body_html ||'<p> ' ||utl_tcp.crlf;

    -- Armo el detalle de la notificaciÃƒÂ³n
        l_body_html := l_body_html||'<table style="border: solid 1px lightgray;">';
        l_body_html := l_body_html||'<tr><td style="text-align: center; font-weight: bolder; border: solid 1px lightgray;" colspan="7">Stock Ideal Inicial</td></tr>';
        l_body_html := l_body_html||'<tr>';
        l_body_html := l_body_html||'<td style="text-align: center; font-weight: bolder; border: solid 1px lightgray;">  </td>';
        l_body_html := l_body_html||'<td style="text-align: center; font-weight: bolder; border: solid 1px lightgray;">EstÃƒÂ¡ndar Anterior</td>';
        l_body_html := l_body_html||'<td style="text-align: center; font-weight: bolder; border: solid 1px lightgray;">EstÃƒÂ¡ndar Nuevo</td>';
        l_body_html := l_body_html||'<td style="text-align: center; font-weight: bolder; border: solid 1px lightgray;">VariaciÃƒÂ³n</td>';
        l_body_html := l_body_html||'</tr>';
        FOR DETALLE IN (
            SELECT CASE WHEN CODTIPO IN ('SEM   ','PTE   ') THEN 'PRODUCTO TERMINADO' ELSE 'MATERIA PRIMA' END TIPO,
                  ROUND(SUM(STOCKINICIALIDEAL * (COUNCS / 10000)), 2) AS VALOR,
                    ROUND(SUM(NVL(REPLACE(C03, '.', ','), X.STOCKINICIALIDEAL) * (COUNCS / 10000)), 2) AS VALOR2,
                    ROUND(
                        CASE
                            WHEN SUM(STOCKINICIALIDEAL * (COUNCS / 10000)) = 0 THEN NULL
                            ELSE
                                ( (SUM(NVL(REPLACE(C03, '.', ','), X.STOCKINICIALIDEAL) * (COUNCS / 10000)) -
                                    SUM(STOCKINICIALIDEAL * (COUNCS / 10000)) ) /
                                  NULLIF(SUM(STOCKINICIALIDEAL * (COUNCS / 10000)), 0)
                                ) * 100
                        END, 2
                    ) AS VARIACION
            FROM  T_PPLA_PRODUCTOSTOCKIDEAL X,VT_JDE_PRODUCTOS Y,F4105@JDEDTADL, VT_APEX_EXCEL Z
            WHERE X.CODIGOPRODUCTO=Y.CODIGOPRODUCTO
            AND X.CODIGOPRODUCTO=TRIM(COLITM) AND TO_CHAR(FECHAHASTA,'YYYYMMDD')>TO_CHAR(SYSDATE,'YYYYMMDD')
            AND COMCU= CASE WHEN CODTIPO IN ('SEM   ','PTE   ') THEN '       17003' ELSE '       17001' END
            AND COCSIN='I' AND TRIM(X.CODIGOPRODUCTO)=TRIM(Z.C02(+))
            GROUP BY CODTIPO
        )LOOP
            l_body_html := l_body_html||'<tr>';
            l_body_html := l_body_html||'<td style="border: solid 1px lightgray;">'||DETALLE.TIPO||'</td>';
            l_body_html := l_body_html||'<td style="border: solid 1px lightgray;">'||DETALLE.VALOR||'</td>';
            l_body_html := l_body_html||'<td style="border: solid 1px lightgray;">'||DETALLE.VALOR2||'</td>';
            l_body_html := l_body_html||'<td style="border: solid 1px lightgray;">'||DETALLE.VARIACION||'</td>';
            l_body_html := l_body_html||'</tr>';
        END LOOP;
        l_body_html := l_body_html||'</table>';

        l_body_html := l_body_html ||'<p> ' ||utl_tcp.crlf;

        l_body_html := l_body_html ||'</body>'||utl_tcp.crlf;
        l_body_html := l_body_html ||'</html>'||utl_tcp.crlf;

        PK_CORP_CORREO.SP_ENVIO_S('PPLA',  P_TO, P_FROM, P_SUBJECT, l_body_html);

      -- caduco el stock ideal inicial de los items que se actualizan
      UPDATE T_PPLA_PRODUCTOSTOCKIDEAL SET FECHAHASTA=TRUNC(SYSDATE, 'MM') - 1
      WHERE TO_CHAR(FECHAHASTA,'YYYYMMDD')='20401231'
      --AND FECHADESDE<>
      AND EXISTS (SELECT 'X' FROM vt_apex_excel
                    WHERE TRIM(C02)=CODIGOPRODUCTO);

      -- inserto los items que se actualizaron
      INSERT INTO T_PPLA_PRODUCTOSTOCKIDEAL (
                  CODIGOPRODUCTO,STOCKINICIALIDEAL, FECHADESDE,FECHAHASTA, AUDITORIAUSUARIO,AUDITORIAFECHA,COMPANIA)
      SELECT C02,replace(C03,'.',','),TRUNC(SYSDATE, 'MM'),TO_DATE('31/12/2040'),P_USUARIO,SYSDATE,P_COMPANIA
      FROM vt_apex_excel
      WHERE EXISTS (SELECT 'X' FROM T_PPLA_PRODUCTOSTOCKIDEAL
                    WHERE TRIM(CODIGOPRODUCTO)=TRIM(C02)
                    AND FECHAHASTA=SYSDATE-1);

     -- inserto items nuevos
      INSERT INTO T_PPLA_PRODUCTOSTOCKIDEAL (
                  CODIGOPRODUCTO,STOCKINICIALIDEAL, FECHADESDE,FECHAHASTA, AUDITORIAUSUARIO,AUDITORIAFECHA,COMPANIA)
      SELECT C02,replace(C03,'.',','),TRUNC(SYSDATE, 'MM'),TO_DATE('31/12/2040'),P_USUARIO,SYSDATE,P_COMPANIA
      FROM vt_apex_excel
      WHERE NOT EXISTS (SELECT 'X' FROM T_PPLA_PRODUCTOSTOCKIDEAL
                        WHERE TRIM(CODIGOPRODUCTO)=TRIM(C02)
                        AND FECHAHASTA=SYSDATE-1);


END SP_ACTUALIZA_STOCKIDEALINICIAL;

PROCEDURE SP_ACTUALIZA_STOCKSTANDARD (
          P_COMPANIA IN VARCHAR2,
          P_USUARIO IN VARCHAR2) AS

BEGIN
      -- caduco el stock ideal inicial de los items que se actualizan
      UPDATE T_PPLA_PRODUCTOS_COSTO_STANDARD SET FECHAHASTA=TRUNC(SYSDATE, 'MM') - 1
      WHERE TO_CHAR(FECHAHASTA,'YYYYMMDD')='20401231'
      --AND FECHADESDE<>
      AND EXISTS (SELECT 'X' FROM vt_apex_excel
                    WHERE TRIM(C02)=CODIGOPRODUCTO);

      -- inserto los items que se actualizaron
      INSERT INTO T_PPLA_PRODUCTOS_COSTO_STANDARD (
                  CODIGOPRODUCTO,COSTOSTANDARD, FECHADESDE,FECHAHASTA, AUDITORIAUSUARIO,AUDITORIAFECHA,COMPANIA)
      SELECT TRIM(C02),replace(C03,'.',','),TRUNC(SYSDATE, 'MM'),TO_DATE('31/12/2040'),P_USUARIO,SYSDATE,P_COMPANIA
      FROM vt_apex_excel
      WHERE EXISTS (SELECT 'X' FROM T_PPLA_PRODUCTOS_COSTO_STANDARD
                    WHERE TRIM(CODIGOPRODUCTO)=TRIM(C02)
                    AND FECHAHASTA=SYSDATE-1);

     -- inserto items nuevos
      INSERT INTO T_PPLA_PRODUCTOS_COSTO_STANDARD (
                  CODIGOPRODUCTO,COSTOSTANDARD, FECHADESDE,FECHAHASTA, AUDITORIAUSUARIO,AUDITORIAFECHA,COMPANIA)
      SELECT TRIM(C02),replace(C03,'.',','),TRUNC(SYSDATE, 'MM'),TO_DATE('31/12/2040'),P_USUARIO,SYSDATE,P_COMPANIA
      FROM vt_apex_excel
      WHERE NOT EXISTS (SELECT 'X' FROM T_PPLA_PRODUCTOS_COSTO_STANDARD
                        WHERE TRIM(CODIGOPRODUCTO)=TRIM(C02)
                        AND FECHAHASTA=SYSDATE-1);


END SP_ACTUALIZA_STOCKSTANDARD;

PROCEDURE SP_PROCESACARGAMAQUINA (
          P_COMPANIA IN VARCHAR2,
          P_USUARIO IN VARCHAR2,
          P_MENSAJE OUT VARCHAR)
          AS

  V_EXISTE  NUMBER :=0;
  V_CONTOBSOLETOS  NUMBER  :=0;
  V_FECDESDE DATE :=TRUNC(SYSDATE,'MONTH');
  V_FECHASTA DATE :=TRUNC(LAST_DAY(SYSDATE));

  BEGIN

     -- 1. valido que la mÃƒÂ¡quina a procesar exista en la vista VT_JDE_MAQUINAS
     SELECT COUNT(*) INTO V_EXISTE
     FROM VT_APEX_EXCEL
     WHERE TRIM(C02) is not null
       AND ((P_COMPANIA = '00001' AND NOT EXISTS (SELECT 'X' FROM VT_JDE_MAQUINA WHERE CODIGO=TRIM(C02)))
         OR (P_COMPANIA = '00003' AND NOT EXISTS (SELECT 'X' FROM OBIN@HANA_PE WHERE TRIM("BinCode")=TRIM(C02))));
     IF NVL(V_EXISTE,0)>0 THEN

        apex_error.add_error (
        p_message          => 'MÃƒÂ¡quina(s) en el archivo a cargar, no existe(n) en JDE. Revise por favor.',
        --p_display_location => apex_error.c_on_error_page );
        p_display_location => apex_error.c_inline_in_notification );

        RETURN;  -- se finaliza el proceso

     END IF;

     V_EXISTE:='';

     -- 2. verifico que no existan cÃƒÂ³digos de mÃƒÂ¡quina duplicados
     BEGIN
         SELECT COUNT(*) INTO V_EXISTE
         FROM VT_APEX_EXCEL WHERE TRIM(C02) is not null
         GROUP BY TRIM(C02)
         HAVING COUNT(*)>1;
       EXCEPTION WHEN TOO_MANY_ROWS THEN V_EXISTE:=1;
         WHEN NO_DATA_FOUND THEN NULL;
      END;

     IF NVL(V_EXISTE,0)>0 THEN
        apex_error.add_error (
        p_message          => 'CÃƒÂ³digo de MÃƒÂ¡quina duplicados en el archivo a cargar. Revise por favor.',
        p_display_location => apex_error.c_inline_in_notification );

        RETURN;  -- se finaliza el proceso
     END IF;

     -- 3. actualizo la tabla T_PPLA_MAQUINAS
     UPDATE T_PPLA_MAQUINAS SET (CODIGOMAQUINA,TURNOS,HORASTURNO,PERSONAS,GRUPOS,EFICIENCIA)=
        (SELECT C02 CODIGOMAQUINA,replace(C03,'.',',') TURNOS,replace(C04,'.',',') HORASTURNO,replace(C05,'.',',') PERSONAS,
                replace(C06,'.',',') GRUPOS,replace(C07,'.',',') EFICIENCIA
         FROM vt_apex_excel
         WHERE TRIM(CODIGOMAQUINA)=C02
         AND FECHADESDE=V_FECDESDE AND FECHAHASTA=V_FECHASTA
         AND COMPANIA=P_COMPANIA)
     WHERE EXISTS (SELECT 'X' FROM vt_apex_excel
                   WHERE TRIM(CODIGOMAQUINA)=C02 AND FECHADESDE=V_FECDESDE AND FECHAHASTA=V_FECHASTA
                     AND COMPANIA=P_COMPANIA);

     -- 4. inserto en la tabla T_PPLA_MAQUINAS aquellas mÃƒÂ¡quinas que no existen en esta tabla
     INSERT INTO T_PPLA_MAQUINAS(CODIGOMAQUINA,FECHADESDE,FECHAHASTA,TURNOS,HORASTURNO,PERSONAS,GRUPOS,EFICIENCIA,COMPANIA)
     SELECT C02,V_FECDESDE,V_FECHASTA ,replace(C03,'.',','),replace(C04,'.',','),replace(C05,'.',','),replace(C06,'.',','),
            replace(C07,'.',','),P_COMPANIA
     FROM vt_apex_excel
     WHERE TRIM(C02) is not null  AND NOT EXISTS (SELECT 'X' FROM T_PPLA_MAQUINAS
                       WHERE TRIM(CODIGOMAQUINA)=C02
                       AND FECHADESDE=V_FECDESDE AND FECHAHASTA=V_FECHASTA
                       AND COMPANIA=P_COMPANIA);
      P_MENSAJE:='Carga existosa';
      apex_application.g_print_success_message := '<span style="green">'||P_MENSAJE || ' </span>';

END SP_PROCESACARGAMAQUINA;

/*
  Este procedimiento se calendariza para su ejecuciÃƒÂ³n el primer dÃƒÆ’Ã‚Â­a del mes
  copia los datos de la tabla T_PPLA_MAQUINAS del mes anterior al nuevo mes
  PK_PPLA_CONFIGURACION.SP_MAQUINA_INICIO(P_COMPANIA=>'00001');
*/
PROCEDURE SP_MAQUINA_INICIO  (P_COMPANIA IN VARCHAR2)

          AS

  V_EXISTE  NUMBER :=0;
  V_CONTOBSOLETOS  NUMBER  :=0;
  V_FECDESDE DATE :=TRUNC(SYSDATE,'MONTH');
  V_FECHASTA DATE :=TRUNC(LAST_DAY(SYSDATE));

  BEGIN

      INSERT INTO T_PPLA_MAQUINAS(CODIGOMAQUINA,FECHADESDE,FECHAHASTA,TURNOS,HORASTURNO,PERSONAS,GRUPOS,EFICIENCIA,COMPANIA)
      SELECT CODIGOMAQUINA,V_FECDESDE,V_FECHASTA,TURNOS,HORASTURNO,PERSONAS,GRUPOS,EFICIENCIA,COMPANIA
      FROM T_PPLA_MAQUINAS A
      WHERE COMPANIA=P_COMPANIA
      AND FECHADESDE=ADD_MONTHS(TRUNC(SYSDATE,'MONTH'),-1)
      AND NOT EXISTS (
      SELECT 1 FROM T_PPLA_MAQUINAS B WHERE B.CODIGOMAQUINA=A.CODIGOMAQUINA AND B.FECHADESDE=V_FECDESDE AND B.COMPANIA=P_COMPANIA)
      ;


END SP_MAQUINA_INICIO;

PROCEDURE SP_PROCESACARGAPRODUCTO (
          P_COMPANIA IN VARCHAR2,
          P_USUARIO IN VARCHAR2,
          P_MENSAJE OUT VARCHAR)
          AS

  V_EXISTE  NUMBER :=0;
  V_CONTOBSOLETOS  NUMBER  :=0;
  V_FECDESDE DATE :=TRUNC(SYSDATE,'MONTH');
  V_FECHASTA DATE :=TRUNC(LAST_DAY(SYSDATE));
  V_OBSOLETOS  VARCHAR2(5000) :='';

  BEGIN

     -- 1. valido que los productos a procesar exista en la vista VT_JDE_PRODUCTOS
     SELECT COUNT(*) INTO V_EXISTE
     FROM VT_APEX_EXCEL
     WHERE NOT EXISTS (SELECT 'X'
                       FROM VT_JDE_PRODUCTOS
                       WHERE CODIGOPRODUCTO=TRIM(C02));
     IF NVL(V_EXISTE,0)>0 THEN
        apex_error.add_error (
        p_message          => 'Producto(s) en el archivo a cargar, no existe(n) en JDE. Revise por favor.',
        p_display_location => apex_error.c_inline_in_notification );

        RETURN;  -- se finaliza el proceso

     END IF;

     V_EXISTE:='';

     -- 2. verifico que no existan cÃƒÂ³digos duplicados de productos
     BEGIN
         SELECT COUNT(*) INTO V_EXISTE
         FROM VT_APEX_EXCEL
         GROUP BY TRIM(C02)
         HAVING COUNT(*)>1;
       EXCEPTION WHEN TOO_MANY_ROWS THEN V_EXISTE:=1;
         WHEN NO_DATA_FOUND THEN NULL;
      END;

     IF NVL(V_EXISTE,0)>0 THEN
        apex_error.add_error (
        p_message          => 'Productos duplicados en el archivo a cargar. Revise por favor.',
        p_display_location => apex_error.c_inline_in_notification );

        RETURN;  -- se finaliza el proceso

     END IF;

     -- 3. verifico que los Items no estÃƒÆ’Ã‚Â©n marcadas como obsoletas
     SELECT COUNT(*),LISTAGG(TRIM(C02) , ',') WITHIN GROUP (ORDER BY C02)
     INTO V_CONTOBSOLETOS,V_OBSOLETOS
     FROM VT_APEX_EXCEL
     WHERE EXISTS (SELECT 'X'
                   FROM F4101@JDEDTADL
                   WHERE TRIM(IMSTKT)='O' AND TRIM(IMLITM)=TRIM(C02)
                  );

     IF NVL(V_CONTOBSOLETOS,0)>0 AND 1=2 THEN

        apex_error.add_error (
        p_message          => 'Existen productos en el archivo a cargar: '||V_OBSOLETOS||' marcados como OBSOLETOS en JDE. Revise por favor.',
        p_display_location => apex_error.c_inline_in_notification );

        RETURN;  -- se finaliza el proceso

     END IF;

     -- 4. actualizo la tabla T_PPLA_PRODUCTO
     UPDATE T_PPLA_PRODUCTO SET (CODIGOPRODUCTO, CODIGOHISTORICO, TIPOVENTA)=
        (SELECT C02 CODIGOPRODUCTO,C03 CODIGOHISTORICO,C04 TIPOVENTA
         FROM vt_apex_excel
         WHERE TRIM(CODIGOPRODUCTO)=C02)
     WHERE  EXISTS (SELECT 'X' FROM vt_apex_excel WHERE TRIM(CODIGOPRODUCTO)=C02);

     -- 5. inserto en la tabla T_PPLA_PRODUCTO los productos que no existen en esta tabla
     INSERT INTO T_PPLA_PRODUCTO (CODIGOPRODUCTO, CODIGOHISTORICO, TIPOVENTA)
     SELECT C02,C03,C04
     FROM vt_apex_excel
     WHERE NOT EXISTS (SELECT 'X' FROM T_PPLA_PRODUCTO
                       WHERE TRIM(CODIGOPRODUCTO)=C02);

      P_MENSAJE:='Carga existosa';
      apex_application.g_print_success_message := '<span style="green">'||P_MENSAJE || ' </span>';

END SP_PROCESACARGAPRODUCTO;

PROCEDURE SP_PRODUCTOPLANIFICADOR (
          P_COMPANIA IN VARCHAR2,
          P_USUARIO IN VARCHAR2,
          P_MENSAJE OUT VARCHAR)
          AS
  CURSOR DATOS IS
  SELECT CODERP,TRIM(C02) PRODUCTO FROM VT_CORP_USUARIO,VT_APEX_EXCEL
  WHERE NOMBREUSUARIO=TRIM(C03);

  CURSOR SIN_PLANIFICADOR IS
        SELECT TRIM(C02) AS IMLITM
        FROM VT_APEX_EXCEL
        WHERE TRIM(C03) IS NULL AND TRIM(C02) IS NOT NULL;

  V_EXISTE  NUMBER :=0;
  V_CONTOBSOLETOS  NUMBER  :=0;
  V_FECDESDE DATE :=TRUNC(SYSDATE,'MONTH');
  V_FECHASTA DATE :=TRUNC(LAST_DAY(SYSDATE));
  V_OBSOLETOS VARCHAR2(5000) :='';

  BEGIN

  -- 1. valido que los productos a procesar existan en la vista VT_JDE_PRODUCTOS
     SELECT COUNT(*),LISTAGG(TRIM(C02) , ',') WITHIN GROUP (ORDER BY C02)
     INTO V_EXISTE,V_OBSOLETOS
     FROM VT_APEX_EXCEL
     WHERE NOT EXISTS (SELECT 'X'
                       FROM VT_JDE_PRODUCTOS
                       WHERE CODIGOPRODUCTO=TRIM(C02));
     IF NVL(V_EXISTE,0)>0 THEN
        apex_error.add_error (
        p_message          => 'Producto(s): '||V_OBSOLETOS||' en el archivo a cargar, no existe(n) en JDE. Revise por favor.',
        p_display_location => apex_error.c_inline_in_notification );

        RETURN;  -- se finaliza el proceso

     END IF;

     V_EXISTE:='';V_OBSOLETOS:='';

     -- 2. verifico que no existan cÃƒÂ³digos duplicados de productos
     BEGIN
         SELECT COUNT(*),LISTAGG(TRIM(C02) , ',') WITHIN GROUP (ORDER BY C02)
         INTO V_EXISTE,V_OBSOLETOS
         FROM VT_APEX_EXCEL
         GROUP BY TRIM(C02)
         HAVING COUNT(*)>1;
       EXCEPTION WHEN TOO_MANY_ROWS THEN V_EXISTE:=1;
         WHEN NO_DATA_FOUND THEN NULL;
      END;

     IF NVL(V_EXISTE,0)>0 THEN
        apex_error.add_error (
        p_message          => 'Productos: '||V_OBSOLETOS||' duplicados en el archivo a cargar. Revise por favor.',
        p_display_location => apex_error.c_inline_in_notification );

        RETURN;  -- se finaliza el proceso

     END IF;

     -- 3. verifico que no existan obsoletos
      BEGIN
         SELECT COUNT(*),LISTAGG(TRIM(IMLITM) , ',') WITHIN GROUP (ORDER BY IMLITM)
         INTO V_CONTOBSOLETOS,V_OBSOLETOS
         FROM F4101@JDEDTADL, VT_APEX_EXCEL
         WHERE TRIM(IMSTKT)='O' AND TRIM(IMLITM)=TRIM(C02);
       EXCEPTION WHEN TOO_MANY_ROWS THEN V_EXISTE:=1;
         WHEN NO_DATA_FOUND THEN NULL;
      END;

     IF NVL(V_CONTOBSOLETOS,0)>0 THEN
        apex_error.add_error (
        p_message          => 'Productos Obsoletos en el archivo a cargar: '||V_OBSOLETOS||' Revise por favor.',
        p_display_location => apex_error.c_inline_in_notification );

        RETURN;  -- se finaliza el proceso
      END IF;

    -- 4. verifico que el planificador estÃƒÆ’Ã‚Â© activo
     V_CONTOBSOLETOS:=0;
     V_OBSOLETOS:='';
     BEGIN
         SELECT COUNT(*), LISTAGG (DISTINCT TRIM(C03) , ',') WITHIN GROUP (ORDER BY C03)
         INTO V_CONTOBSOLETOS,V_OBSOLETOS
         FROM VT_APEX_EXCEL,VT_CORP_USUARIO
         WHERE TRIM(C03)=NOMBREUSUARIO AND ESTADO=0 AND TRIM(C03) IS NOT NULL;
       EXCEPTION WHEN TOO_MANY_ROWS THEN V_CONTOBSOLETOS:=1;
         WHEN NO_DATA_FOUND THEN NULL;
      END;

     IF NVL(V_CONTOBSOLETOS,0)>0 THEN
        apex_error.add_error (
        p_message          => 'Planificador: '||V_OBSOLETOS||' inactivo(s). Revise por favor.',
        p_display_location => apex_error.c_inline_in_notification );

        RETURN;  -- se finaliza el proceso
      END IF;

      -- 5. verifico que el planificador exista
     V_CONTOBSOLETOS:=0;
     V_OBSOLETOS:='';

     BEGIN
         SELECT COUNT(*), LISTAGG (DISTINCT TRIM(C03) , ',') WITHIN GROUP (ORDER BY C03)
         INTO V_CONTOBSOLETOS,V_OBSOLETOS
         FROM VT_APEX_EXCEL
         WHERE NOT EXISTS (SELECT 'X' FROM VT_CORP_USUARIO WHERE TRIM(C03)=NOMBREUSUARIO)
         AND TRIM(C03) IS NOT NULL;
       EXCEPTION WHEN TOO_MANY_ROWS THEN V_CONTOBSOLETOS:=1;
     END;

     IF NVL(V_CONTOBSOLETOS,0)>0 THEN
        apex_error.add_error (
        p_message          => 'Planificador: '||V_OBSOLETOS||' no existe. Revise por favor.',
        p_display_location => apex_error.c_inline_in_notification );

        RETURN;  -- se finaliza el proceso
      END IF;

      -- actualizo el planificador en JDE
      FOR C1 IN DATOS LOOP
          UPDATE F4101@JDEDTADL
          SET IMANPL=C1.CODERP
          WHERE TRIM(IMLITM)=C1.PRODUCTO;
      END LOOP;

      -- quita el planificador en JDE
     FOR rec IN SIN_PLANIFICADOR LOOP
        -- Actualizar cada registro en la base de datos remota
        UPDATE F4101@JDEDTADL
        SET IMANPL = 0
        WHERE TRIM(IMLITM) = rec.IMLITM;
    END LOOP;

END SP_PRODUCTOPLANIFICADOR;

    PROCEDURE SP_QUITARPLANIFICADOR AS
    BEGIN
    ---QUITAR PLANIFICADOR QUE NO ES DEL AREA PARA PRODUCTOS ANTIGUOS O NUEVOS
        FOR C1 IN ( select CODIGOPRODUCTO from (
         SELECT * FROM VT_JDE_PRODUCTOS where TEXTOBUSQUEDA in ('TERCEROS') AND CODESTADO<>'O'
                AND EXISTS (
                    SELECT 1
                    FROM F42119@JDEDTADL
                    WHERE  sdivd
                    BETWEEN TO_CHAR( TRUNC(ADD_MONTHS(SYSDATE, -12),'MM'), 'YYYYDDD')-1900000  AND TO_CHAR(LAST_DAY(SYSDATE), 'YYYYDDD')-1900000
                    AND SDDCTO IN ('VN', 'VE')
                    AND TRIM(SDLITM)=CODIGOPRODUCTO)
                UNION ALL
                --- TERMINADOS QUE NO ESTAN OBSOLETOS
                SELECT * FROM VT_JDE_PRODUCTOS where TEXTOBUSQUEDA in ('TERMINADO') AND CODESTADO<>'O')
                WHERE PLANIFICADOR IN (10504, 10268)     ) LOOP

                     UPDATE F4101@JDEDTADL
                              SET IMANPL=0
                              WHERE TRIM(IMLITM)=C1.CODIGOPRODUCTO;
        END LOOP;

    END SP_QUITARPLANIFICADOR;

       PROCEDURE SP_CARGAR_PARAMETROS_METODOS_STOCK_IDEAL(
        P_COMPANIA IN VARCHAR2,
        P_USUARIO IN VARCHAR2
    )
    AS
    v_codigos_duplicados VARCHAR2(4000);
    BEGIN

        DELETE FROM T_TMP_A;

        INSERT INTO T_TMP_A(TXT01)
        SELECT jt.codigo
        FROM vt_apex_excel t,
             JSON_TABLE(
                 '["' || REPLACE(t.c03, ',', '","') || '"]',
                 '$[*]'
                 COLUMNS (
                     codigo VARCHAR2(100) PATH '$'
                 )
             ) jt
        WHERE TRIM(t.c03) IS NOT NULL;

        --VALIDAR QUE NO EXISTAN CODIGOS DE PRODUCTOS DUPLICADOS, DEVOLVER ESTOS CODIGOS DUPLICADOS
        SELECT LISTAGG(codigo, ', ') WITHIN GROUP (ORDER BY codigo)
        INTO v_codigos_duplicados
        FROM  (
            SELECT TRIM(TXT01) AS codigo
            FROM T_TMP_A
            WHERE TRIM(TXT01) IS NOT NULL
            GROUP BY TRIM(TXT01)
            HAVING COUNT(*) > 1
        );

        IF v_codigos_duplicados IS NOT NULL THEN
            apex_error.add_error(
                p_message          => 'Existen cÃƒÂ³digos de productos duplicados: ' || v_codigos_duplicados,
                p_display_location => apex_error.c_inline_in_notification
            );
            RETURN;
        END IF;

        --Concatenar todos los CODIGO DE PRODUCTOS que no existen en la tabla VT_GZM_PRODUCTO
        SELECT LISTAGG(codigo, ', ') WITHIN GROUP (ORDER BY codigo)
        INTO v_codigos_duplicados
        FROM  (
            SELECT TRIM(TXT01) AS codigo
            FROM T_TMP_A
            WHERE TRIM(TXT01) IS NOT NULL
            AND NOT EXISTS (
                SELECT 1
                FROM VT_JDE_PRODUCTOS
                WHERE TRIM(CODIGOPRODUCTO) = TRIM(TXT01)
                AND COMPANIA = P_COMPANIA -- Vista solo ECUADOR
                AND (TEXTOBUSQUEDA =  'MATERIA PRIMA'
                    OR TEXTOBUSQUEDA =  'TERMINADO'
                    OR TEXTOBUSQUEDA =  'Termiando'
                    )
            )
        );

        -- IF v_codigos_duplicados IS NOT NULL THEN
        --     apex_error.add_error(
        --         p_message          => 'Los siguientes cÃƒÂ³digos de productos no existen en la compaÃƒÂ±ÃƒÂ­a o no son MATERIA PRIMA o TERMINADO: ' || v_codigos_duplicados,
        --         p_display_location => apex_error.c_inline_in_notification
        --     );
        --     RETURN;
        -- END IF;

        --VALIDAR QUE EXISTAN DATOS EN LAS COLUMANS C06 HASTA C08 TENGAN DATOS, DEVOLVER EL CODIGO DE PRODUCTO
        SELECT LISTAGG(codigo, ', ') WITHIN GROUP (ORDER BY codigo)
        INTO v_codigos_duplicados
        FROM  (
            SELECT TRIM(c03) AS codigo
            FROM vt_apex_excel
            WHERE TRIM(c03) IS NOT NULL
            AND (TRIM(c06) IS NULL OR TRIM(c07) IS NULL OR TRIM(c08) IS NULL)
        );

        IF v_codigos_duplicados IS NOT NULL THEN
            apex_error.add_error(
                p_message          => 'Los siguientes cÃƒÂ³digos de productos tienen datos vacÃƒÂ­os en MINIMO DIAS, MAXIMO DIAS O METODO CALCULADO: ' || v_codigos_duplicados,
                p_display_location => apex_error.c_inline_in_notification
            );
            RETURN;
        END IF;

        --VALIDAR LOS METODOS CALCULADOS (C09) SEAN VÃƒÂLIDOS (NORMAL / REEMPLAZO / AGOTAMIENTO / NO CONSIDERAR)
        SELECT LISTAGG(codigo, ', ') WITHIN GROUP (ORDER BY codigo)
        INTO v_codigos_duplicados
        FROM  (
            SELECT TRIM(c03) AS codigo
            FROM vt_apex_excel
            WHERE TRIM(c03) IS NOT NULL
            AND UPPER(TRIM(C08)) NOT IN ('NORMAL', 'REEMPLAZO', 'AGOTAMIENTO', 'NO CONSIDERAR')
        );
        IF v_codigos_duplicados IS NOT NULL THEN
            apex_error.add_error(
                p_message          => 'Los siguientes cÃƒÂ³digos de productos tienen un MÃƒâ€°TODO CALCULADO invÃƒÂ¡lido (debe ser NORMAL, REEMPLAZO, AGOTAMIENTO o NO CONSIDERAR): ' || v_codigos_duplicados,
                p_display_location => apex_error.c_inline_in_notification
            );
            RETURN;
        END IF;

        --VALIDAR QUE SI EL METODO CALCULADO ES REEMPLAZO (C09), ENTONCES EL CAMPO CODIGOS REEMPLAZO (C07) NO DEBE ESTAR VACÃƒÂO
        -- SELECT LISTAGG(codigo, ', ') WITHIN GROUP (ORDER BY codigo)
        -- INTO v_codigos_duplicados
        -- FROM  (
        --     SELECT TRIM(c03) AS codigo
        --     FROM vt_apex_excel
        --     WHERE TRIM(c03) IS NOT NULL
        --     AND UPPER(TRIM(c08)) = 'REEMPLAZO'
        --     AND TRIM(c09) IS NULL
        -- );
        -- IF v_codigos_duplicados IS NOT NULL THEN
        --     apex_error.add_error(
        --         p_message          => 'Los siguientes cÃƒÂ³digos de productos tienen el MÃƒâ€°TODO CALCULADO como REEMPLAZO, por lo tanto el campo CÃƒâ€œDIGOS REEMPLAZO no debe estar vacÃƒÂ­o: ' || v_codigos_duplicados,
        --         p_display_location =>Apex_error.c_inline_in_notification
        --     );
        --     RETURN;
        -- END IF;

        ------------------------------------------------------------------
        --INACTIVAR REGISTROS ACTIVOS EXISTENTES
        ------------------------------------------------------------------
        UPDATE T_PPLA_STOCKIDEALPARAMETROS tgt
           SET tgt.ESTADO              = 0,
               tgt.FECHACADUCIDAD      = SYSDATE,
               tgt.USUARIOMODIFICACION = P_USUARIO,
               tgt.FECHAMODIFICACION  = SYSDATE
         WHERE tgt.ESTADO = 1
              AND tgt.COMPANIA = P_COMPANIA
              AND EXISTS (
                    SELECT 1
                    FROM T_TMP_A tmp
                    WHERE tmp.TXT01 IS NOT NULL
                      AND INSTR(',' || tgt.CODIGOPRODUCTO || ',',
                                ',' || TRIM(tmp.TXT01) || ',') > 0
              );

        ------------------------------------------------------------------
        --INSERTAR NUEVOS REGISTROS ACTIVOS
        ------------------------------------------------------------------

        INSERT INTO T_PPLA_STOCKIDEALPARAMETROS (
            TIPOPRODUCTO,
            CODIGOPRODUCTO,
            DESCRIPCIONSKU,
            CATEGORIAPLANIFICACION,
            MINIMODIAS,
            MAXIMODIAS,
            METODOCALCULO,
            --CODIGOSREEMPLAZO,
            OBSERVACION,
            FECHACADUCIDAD,
            USUARIOCREACION,
            FECHACREACION,
            ESTADO,
            COMPANIA
        )

        SELECT DISTINCT   -- elimina B repetido dentro de la misma fila
            vp.TIPOPRODUCTO,
            TRIM(vt.c03) AS CODIGOPRODUCTO,
            vp.NOMBREPRODUCTO||
             CASE WHEN vp.TEXTOBUSQUEDA = 'MATERIA PRIMA' THEN '-'||TO_CHAR(vp.CODIGOALTERNO) ELSE '' END NOMBREPRODUCTO,
            CASE
                WHEN vp.TEXTOBUSQUEDA = 'MATERIA PRIMA' THEN TO_CHAR(vp.CATPLANIFICACION)
                WHEN vp.TEXTOBUSQUEDA IN ('TERMINADO', 'Termiando') THEN TO_CHAR(vp.MARCA)
            END AS CATEGORIAPLANIFICACION,
            ROUND(REPLACE(TRIM(vt.c06), '.', ','), 4),
            ROUND(REPLACE(TRIM(vt.c07), '.', ','), 4),
            UPPER(TRIM(vt.c08)),
            TRIM(vt.c09),
            NULL,
            P_USUARIO,
            SYSDATE,
            1,
            P_COMPANIA
        FROM VT_APEX_EXCEL vt
        JOIN VT_JDE_PRODUCTOS vp
            ON vp.CODIGOPRODUCTO = TRIM(REGEXP_SUBSTR(vt.c03, '[^,]+', 1, 1))
            AND vp.COMPANIA = P_COMPANIA;

    END SP_CARGAR_PARAMETROS_METODOS_STOCK_IDEAL;


/* Actualiza exclusivamente las metas de variacion visibles en Stock Ideal. */
PROCEDURE SP_GUARDAR_METAS_STOCK_IDEAL(
    P_COMPANIA IN VARCHAR2,
    P_META_PT  IN NUMBER,
    P_META_MP  IN NUMBER,
    P_USUARIO  IN VARCHAR2) AS
    V_FILAS_PT PLS_INTEGER;
    V_FILAS_MP PLS_INTEGER;
BEGIN
    IF TRIM(P_COMPANIA) IS NULL OR P_META_PT IS NULL OR P_META_MP IS NULL
       OR P_META_PT < 0 OR P_META_MP < 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Las metas de PT y MP deben ser valores numericos no negativos.');
    END IF;

    UPDATE T_CORP_UDC
       SET VALOR = TO_CHAR(P_META_PT, 'FM999999999999990D999999', 'NLS_NUMERIC_CHARACTERS=''.,''')
     WHERE ID_CABECERA = 'PPLA_PARAM'
       AND ID_TABLA = 'PAR9'
       AND ACTIVO = 1
       AND CODIGOCOMPANIA = TRIM(P_COMPANIA);
    V_FILAS_PT := SQL%ROWCOUNT;

    UPDATE T_CORP_UDC
       SET VALOR = TO_CHAR(P_META_MP, 'FM999999999999990D999999', 'NLS_NUMERIC_CHARACTERS=''.,''')
     WHERE ID_CABECERA = 'PPLA_PARAM'
       AND ID_TABLA = 'PAR10'
       AND ACTIVO = 1
       AND CODIGOCOMPANIA = TRIM(P_COMPANIA);
    V_FILAS_MP := SQL%ROWCOUNT;

    IF V_FILAS_PT = 0 OR V_FILAS_MP = 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'No existen las metas PT y MP activas para la compania.');
    END IF;
END SP_GUARDAR_METAS_STOCK_IDEAL;

END PK_PPLA_CONFIGURACION;
/
