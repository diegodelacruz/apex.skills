create or replace package body data.pk_cntr_configuracion as
    -- usuario_actual: rutina funcional del m?dulo CNTR.
    function usuario_actual return varchar2 is
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        return nvl(sys_context('APEX$SESSION', 'APP_USER'), user);
    end usuario_actual;

    -- compania_actual: rutina funcional del m?dulo CNTR.

    function compania_actual(p_compania in varchar2) return varchar2 is
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        return nvl(nullif(trim(p_compania), ''), nvl(nullif(trim(v('G_COMPANIA')), ''), '00001'));
    end compania_actual;

    -- validar_propietario: rutina funcional del m?dulo CNTR.

    procedure validar_propietario(p_id_configuracion in number, p_usuario in varchar2);

    -- validar_editor_configuracion: autoriza contenido operativo al propietario o usuario compartido.
    procedure validar_editor_configuracion(p_id_configuracion in number, p_usuario in varchar2);

    -- validar_estado: rutina funcional del m?dulo CNTR.

    procedure validar_estado(p_estado in varchar2, p_permite_no_verificable in boolean) is
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        if p_estado not in ('ACTIVO', 'INACTIVO') and not (p_permite_no_verificable and p_estado = 'NO_VERIFICABLE') then
            raise_application_error(-20001, 'El estado seleccionado no es valido.');
        end if;
    end validar_estado;

    -- guardar_portal: rutina funcional del m?dulo CNTR.

    procedure guardar_portal(
        p_id_portal in out nocopy number,
        p_compania in varchar2,
        p_nombre_portal in varchar2,
        p_url_base in varchar2,
        p_descripcion in varchar2,
        p_requiere_captcha in number,
        p_requiere_login in number,
        p_estado in varchar2
    ) is
        v_compania varchar2(5);
        v_usuario varchar2(100);
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        v_compania := compania_actual(p_compania);
        v_usuario := usuario_actual;
        validar_estado(p_estado, true);

        if trim(p_nombre_portal) is null then
            raise_application_error(-20002, 'Ingrese el nombre del portal.');
        end if;

        if trim(p_url_base) is null then
            raise_application_error(-20003, 'Ingrese la URL base del portal.');
        end if;

        if nvl(p_requiere_captcha, 0) not in (0, 1) or nvl(p_requiere_login, 0) not in (0, 1) then
            raise_application_error(-20004, 'Los indicadores del portal no son validos.');
        end if;

        if p_id_portal is null then
            insert into data.t_cntr_portales (
                compania, nombre_portal, url_base, descripcion,
                requiere_captcha, requiere_login, estado
            ) values (
                v_compania, trim(p_nombre_portal), trim(p_url_base), p_descripcion,
                nvl(p_requiere_captcha, 0), nvl(p_requiere_login, 0), p_estado
            )
            returning id_portal into p_id_portal;
        else
            update data.t_cntr_portales
               set compania = v_compania,
                   nombre_portal = trim(p_nombre_portal),
                   url_base = trim(p_url_base),
                   descripcion = p_descripcion,
                   requiere_captcha = nvl(p_requiere_captcha, 0),
                   requiere_login = nvl(p_requiere_login, 0),
                   estado = p_estado,
                   fecha_actualizacion = systimestamp,
                   usuario_actualizacion = v_usuario
             where id_portal = p_id_portal;

            if sql%rowcount = 0 then
                raise_application_error(-20005, 'No se encontro el portal que intenta actualizar.');
            end if;
        end if;
    exception
        when dup_val_on_index then
            raise_application_error(-20006, 'Ya existe un portal con ese nombre para la compania seleccionada.');
    end guardar_portal;

    -- guardar_documento: rutina funcional del m?dulo CNTR.

    procedure guardar_documento(
        p_id_documento in out nocopy number,
        p_id_portal in number,
        p_compania in varchar2,
        p_nombre_documento in varchar2,
        p_evidencia_esperada in varchar2,
        p_modo_captura in varchar2,
        p_dato_busqueda in varchar2,
        p_prompt_ia in clob,
        p_actualizacion_minima_dias in number,
        p_estado in varchar2
    ) is
        v_compania varchar2(5);
        v_portal number;
        v_usuario varchar2(100);
        v_actualizacion_minima_dias number := nvl(p_actualizacion_minima_dias, 7);
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        v_compania := compania_actual(p_compania);
        v_usuario := usuario_actual;
        validar_estado(p_estado, false);

        if p_id_portal is null then
            raise_application_error(-20007, 'Seleccione el portal del documento.');
        end if;

        select count(*)
          into v_portal
          from data.t_cntr_portales
         where id_portal = p_id_portal;

        if v_portal = 0 then
            raise_application_error(-20008, 'El portal seleccionado no existe.');
        end if;

        if trim(p_nombre_documento) is null then
            raise_application_error(-20009, 'Ingrese el nombre del documento.');
        end if;

        if p_modo_captura not in ('AUTOMATICO', 'SEMIAUTOMATICO', 'MANUAL') then
            raise_application_error(-20010, 'Seleccione un modo de captura valido.');
        end if;

        -- El campo vacío conserva el límite operativo predeterminado de siete días.
        if v_actualizacion_minima_dias < 0
           or v_actualizacion_minima_dias <> trunc(v_actualizacion_minima_dias) then
            raise_application_error(-20074, 'La actualizacion minima debe ser un numero entero de dias mayor o igual a cero.');
        end if;

        if p_id_documento is null then
            insert into data.t_cntr_documentos (
                id_portal, compania, nombre_documento, evidencia_esperada,
                modo_captura, dato_busqueda, prompt_ia, actualizacion_minima_dias, estado
            ) values (
                p_id_portal, v_compania, trim(p_nombre_documento), p_evidencia_esperada,
                p_modo_captura, p_dato_busqueda, p_prompt_ia, v_actualizacion_minima_dias, p_estado
            )
            returning id_documento into p_id_documento;
        else
            update data.t_cntr_documentos
               set id_portal = p_id_portal,
                   compania = v_compania,
                   nombre_documento = trim(p_nombre_documento),
                   evidencia_esperada = p_evidencia_esperada,
                   modo_captura = p_modo_captura,
                   dato_busqueda = p_dato_busqueda,
                   prompt_ia = p_prompt_ia,
                   actualizacion_minima_dias = v_actualizacion_minima_dias,
                   estado = p_estado,
                   fecha_actualizacion = systimestamp,
                   usuario_actualizacion = v_usuario
             where id_documento = p_id_documento;

            if sql%rowcount = 0 then
                raise_application_error(-20011, 'No se encontro el documento que intenta actualizar.');
            end if;
        end if;
    exception
        when dup_val_on_index then
            raise_application_error(-20012, 'Ya existe un documento con ese nombre para el portal seleccionado.');
    end guardar_documento;

    -- guardar_paso: rutina funcional del m?dulo CNTR.

    procedure guardar_paso(
        p_id_paso in out nocopy number,
        p_id_documento in number,
        p_orden in number,
        p_instruccion in varchar2,
        p_valor_entrada in varchar2,
        p_requiere_intervencion in number,
        p_estado in varchar2
    ) is
        v_documento number;
        v_orden number;
        v_usuario varchar2(100);
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        v_usuario := usuario_actual;
        validar_estado(p_estado, false);

        if p_id_documento is null then
            raise_application_error(-20013, 'Seleccione el documento del paso.');
        end if;

        select count(*)
          into v_documento
          from data.t_cntr_documentos
         where id_documento = p_id_documento;

        if v_documento = 0 then
            raise_application_error(-20014, 'El documento seleccionado no existe.');
        end if;

        if trim(p_instruccion) is null then
            raise_application_error(-20015, 'Ingrese la instruccion del paso.');
        end if;

        if nvl(p_requiere_intervencion, 0) not in (0, 1) then
            raise_application_error(-20016, 'El indicador de intervencion no es valido.');
        end if;

        if p_orden is null then
            select nvl(max(orden), 0) + 1
              into v_orden
              from data.t_cntr_documento_pasos
             where id_documento = p_id_documento;
        else
            v_orden := p_orden;
        end if;

        if p_id_paso is null then
            insert into data.t_cntr_documento_pasos (
                id_documento, orden, instruccion, valor_entrada,
                requiere_intervencion, estado
            ) values (
                p_id_documento, v_orden, trim(p_instruccion), p_valor_entrada,
                nvl(p_requiere_intervencion, 0), p_estado
            )
            returning id_paso into p_id_paso;
        else
            update data.t_cntr_documento_pasos
               set id_documento = p_id_documento,
                   orden = v_orden,
                   instruccion = trim(p_instruccion),
                   valor_entrada = p_valor_entrada,
                   requiere_intervencion = nvl(p_requiere_intervencion, 0),
                   estado = p_estado,
                   fecha_actualizacion = systimestamp,
                   usuario_actualizacion = v_usuario
             where id_paso = p_id_paso;

            if sql%rowcount = 0 then
                raise_application_error(-20018, 'No se encontro el paso que intenta actualizar.');
            end if;
        end if;
    exception
        when dup_val_on_index then
            raise_application_error(-20019, 'Ya existe un paso con ese orden para el documento seleccionado.');
    end guardar_paso;

    -- guardar_paso: rutina funcional del m?dulo CNTR.

    procedure guardar_paso(
        p_id_paso in out nocopy number,
        p_id_documento in number,
        p_orden in number,
        p_tipo_accion in varchar2,
        p_selector_elemento in varchar2,
        p_valor_entrada in varchar2,
        p_tiempo_espera_seg in number,
        p_requiere_intervencion in number,
        p_descripcion in varchar2,
        p_estado in varchar2,
        p_origen_valor in varchar2
    ) is
        v_instruccion varchar2(2000);
        v_usuario varchar2(100);
        v_tipo_accion varchar2(30) := upper(trim(p_tipo_accion));
        v_selector varchar2(2000) := trim(p_selector_elemento);
        v_valor varchar2(2000) := trim(p_valor_entrada);
        v_origen_valor varchar2(30) := upper(trim(p_origen_valor));
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        if v_tipo_accion not in ('NAVEGAR', 'LLENAR', 'CLICK', 'ESPERAR', 'DESCARGAR', 'CAPTURAR') then
            raise_application_error(-20021, 'Seleccione una accion RPA valida.');
        end if;

        if v_tipo_accion in ('NAVEGAR', 'LLENAR', 'CLICK', 'DESCARGAR') and v_selector is null then
            raise_application_error(-20022, 'La URL o selector es obligatorio para la accion seleccionada.');
        end if;

        if v_origen_valor is not null
           and v_origen_valor not in ('IDENTIFICACION', 'NOMBRES', 'CORREO', 'RAZON_SOCIAL', 'NOMBRE_COMERCIAL') then
            raise_application_error(-20023, 'Seleccione un origen de valor RPA valido.');
        end if;

        if v_tipo_accion = 'LLENAR' and v_valor is null and v_origen_valor is null then
            raise_application_error(-20024, 'Ingrese un valor fijo o seleccione su origen para la accion Llenar.');
        end if;

        if p_tiempo_espera_seg is not null and p_tiempo_espera_seg < 0 then
            raise_application_error(-20025, 'La espera en segundos no puede ser negativa.');
        end if;

        v_usuario := usuario_actual;
        v_instruccion := coalesce(
            nullif(trim(p_descripcion), ''),
            nullif(trim(p_tipo_accion), ''),
            'Ejecutar paso configurado en el documento.'
        );

        guardar_paso(
            p_id_paso => p_id_paso,
            p_id_documento => p_id_documento,
            p_orden => p_orden,
            p_instruccion => v_instruccion,
            p_valor_entrada => p_valor_entrada,
            p_requiere_intervencion => p_requiere_intervencion,
            p_estado => p_estado
        );

        update data.t_cntr_documento_pasos
           set tipo_accion = v_tipo_accion,
               selector_elemento = v_selector,
               origen_valor = v_origen_valor,
               tiempo_espera_seg = p_tiempo_espera_seg,
               descripcion = p_descripcion,
               fecha_actualizacion = systimestamp,
               usuario_actualizacion = v_usuario
         where id_paso = p_id_paso;
    end guardar_paso;

    /** Verifica que el documento pueda ser consumido por el motor RPA declarativo. */
    procedure validar_pasos_documento(p_id_documento in number) is
        v_documento number;
        v_total number;
        v_terminal number;
        v_invalidos number;
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        -- Validar que el documento exista antes de evaluar su secuencia activa.
        select count(*) into v_documento
          from data.t_cntr_documentos
         where id_documento = p_id_documento;
        if v_documento = 0 then
            raise_application_error(-20025, 'No se encontro el documento para validar sus pasos RPA.');
        end if;

        -- La secuencia debe usar acciones soportadas y terminar en una evidencia.
        select count(*),
               count(case when tipo_accion in ('DESCARGAR', 'CAPTURAR') then 1 end),
               count(case
                   when tipo_accion not in ('NAVEGAR', 'LLENAR', 'CLICK', 'ESPERAR', 'DESCARGAR', 'CAPTURAR')
                     or tipo_accion is null
                     or (tipo_accion in ('NAVEGAR', 'LLENAR', 'CLICK', 'DESCARGAR') and trim(selector_elemento) is null)
                     or (tipo_accion = 'LLENAR' and trim(valor_entrada) is null and origen_valor is null)
                     or nvl(tiempo_espera_seg, 0) < 0
                   then 1 end)
          into v_total, v_terminal, v_invalidos
          from data.t_cntr_documento_pasos
         where id_documento = p_id_documento
           and estado = 'ACTIVO';

        if v_total = 0 or v_invalidos > 0 or v_terminal = 0 then
            raise_application_error(
                -20026,

    'El documento no tiene una configuracion RPA ejecutable: complete acciones, URL/selectores y un paso Descargar o Capturar activo.'
            );
        end if;
    end validar_pasos_documento;

    -- validar_tipo_identificacion: rutina funcional del m?dulo CNTR.

    procedure validar_tipo_identificacion(p_tipo_identificacion in varchar2) is
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        if upper(trim(p_tipo_identificacion)) not in ('CI', 'RUC', 'PASAPORTE') then
            raise_application_error(-20030, 'Seleccione un tipo de identificacion valido.');
        end if;
    end validar_tipo_identificacion;

    -- validar_rol: rutina funcional del m?dulo CNTR.

    procedure validar_rol(p_rol in varchar2) is
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        if upper(trim(p_rol)) not in (
            'REPRESENTANTE', 'SOCIO', 'ACCIONISTA', 'RELACIONADO',
            'EMPLEADO', 'BENEFICIARIO_FINAL', 'CONTACTO'
        ) then
            raise_application_error(-20031, 'Seleccione un rol valido para la persona vinculada.');
        end if;
    end validar_rol;

    -- texto_csv: rutina funcional del m?dulo CNTR.

    function texto_csv(p_valor in varchar2) return varchar2 is
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        return '"' || replace(nvl(p_valor, ''), '"', '""') || '"';
    end texto_csv;

    -- numero_fila: rutina funcional del m?dulo CNTR.

    function numero_fila(p_valor in varchar2) return number is
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        return to_number(trim(p_valor));
    exception
        when others then
            return null;
    end numero_fila;

    -- crear_carga: rutina funcional del m?dulo CNTR.

    procedure crear_carga(
        p_compania in varchar2,
        p_tipo_carga in varchar2,
        p_id_carga out nocopy number
    ) is
        v_compania varchar2(5);
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        v_compania := compania_actual(p_compania);

        insert into data.t_cntr_cargas (
            compania, tipo_carga, total_filas, filas_validas, filas_error, estado
        ) values (
            v_compania, p_tipo_carga, 0, 0, 0, 'SIN_DATOS'
        )
        returning id_carga into p_id_carga;
    end crear_carga;

    -- registrar_detalle_carga: rutina funcional del m?dulo CNTR.

    procedure registrar_detalle_carga(
        p_id_carga in number,
        p_numero_fila in number,
        p_clave_referencia in varchar2,
        p_accion in varchar2,
        p_estado in varchar2,
        p_mensaje in varchar2,
        p_datos_fila in varchar2
    ) is
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        insert into data.t_cntr_carga_detalles (
            id_carga, numero_fila, clave_referencia, accion, estado, mensaje, datos_fila
        ) values (
            p_id_carga, p_numero_fila, p_clave_referencia, p_accion, p_estado,
            substr(p_mensaje, 1, 2000), substr(p_datos_fila, 1, 4000)
        );
    end registrar_detalle_carga;

    -- cerrar_carga: rutina funcional del m?dulo CNTR.

    procedure cerrar_carga(p_id_carga in number) is
        v_total number;
        v_ok number;
        v_error number;
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        select count(*),
               sum(case when estado = 'OK' then 1 else 0 end),
               sum(case when estado = 'ERROR' then 1 else 0 end)
          into v_total, v_ok, v_error
          from data.t_cntr_carga_detalles
         where id_carga = p_id_carga;

        update data.t_cntr_cargas
           set total_filas = nvl(v_total, 0),
               filas_validas = nvl(v_ok, 0),
               filas_error = nvl(v_error, 0),
               estado = case
                            when nvl(v_total, 0) = 0 then 'SIN_DATOS'
                            when nvl(v_error, 0) > 0 then 'CON_ERRORES'
                            else 'PROCESADA'
                        end
         where id_carga = p_id_carga;
    end cerrar_carga;

    /*
      Guarda una persona matriculada para el proceso documental CNTR.
    */
    procedure guardar_persona(
        p_id_persona in out nocopy number,
        p_compania in varchar2,
        p_tipo_identificacion in varchar2,
        p_identificacion in varchar2,
        p_nombres in varchar2,
        p_correo in varchar2,
        p_telefono in varchar2,
        p_estado in varchar2
    ) is
        v_compania varchar2(5);
        v_tipo varchar2(30);
        v_identificacion varchar2(30);
        v_usuario varchar2(100);
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        v_compania := compania_actual(p_compania);
        v_tipo := upper(trim(p_tipo_identificacion));
        v_identificacion := upper(trim(p_identificacion));
        v_usuario := usuario_actual;
        validar_tipo_identificacion(v_tipo);
        validar_estado(p_estado, false);

        if v_identificacion is null then
            raise_application_error(-20032, 'Ingrese la identificacion de la persona.');
        end if;

        if trim(p_nombres) is null then
            raise_application_error(-20033, 'Ingrese los nombres de la persona.');
        end if;

        -- La carga y el formulario pueden entregar un identificador vacío al
        -- repetir una persona. La identidad de negocio es compañía, tipo e
        -- identificación; resolverla primero evita duplicar el sujeto.
        if p_id_persona is null then
            begin
                select id_persona
                  into p_id_persona
                  from data.t_cntr_personas
                 where compania = v_compania
                   and tipo_identificacion = v_tipo
                   and identificacion = v_identificacion;
            exception
                when no_data_found then
                    null;
            end;
        end if;

        if p_id_persona is null then
            insert into data.t_cntr_personas (
                compania, tipo_identificacion, identificacion, nombres,
                correo, telefono, estado
            ) values (
                v_compania, v_tipo, v_identificacion, trim(p_nombres),
                trim(p_correo), trim(p_telefono), p_estado
            )
            returning id_persona into p_id_persona;
        else
            update data.t_cntr_personas
               set compania = v_compania,
                   tipo_identificacion = v_tipo,
                   identificacion = v_identificacion,
                   nombres = trim(p_nombres),
                   correo = trim(p_correo),
                   telefono = trim(p_telefono),
                   estado = p_estado,
                   fecha_actualizacion = systimestamp,
                   usuario_actualizacion = v_usuario
             where id_persona = p_id_persona;

            if sql%rowcount = 0 then
                raise_application_error(-20034, 'No se encontro la persona que intenta actualizar.');
            end if;
        end if;
    end guardar_persona;

    /*
      Guarda una empresa matriculada para el proceso documental CNTR.
    */
    procedure guardar_empresa(
        p_id_empresa in out nocopy number,
        p_compania in varchar2,
        p_ruc in varchar2,
        p_razon_social in varchar2,
        p_nombre_comercial in varchar2,
        p_tipo_empresa in varchar2,
        p_estado in varchar2
    ) is
        v_compania varchar2(5);
        v_ruc varchar2(30);
        v_usuario varchar2(100);
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        v_compania := compania_actual(p_compania);
        v_ruc := upper(trim(p_ruc));
        v_usuario := usuario_actual;
        validar_estado(p_estado, false);

        if v_ruc is null then
            raise_application_error(-20036, 'Ingrese el RUC de la empresa.');
        end if;

        if trim(p_razon_social) is null then
            raise_application_error(-20037, 'Ingrese la razon social de la empresa.');
        end if;

        if p_id_empresa is null then
            insert into data.t_cntr_empresas (
                compania, ruc, razon_social, nombre_comercial, tipo_empresa, estado
            ) values (
                v_compania, v_ruc, trim(p_razon_social), trim(p_nombre_comercial),
                trim(p_tipo_empresa), p_estado
            )
            returning id_empresa into p_id_empresa;
        else
            update data.t_cntr_empresas
               set compania = v_compania,
                   ruc = v_ruc,
                   razon_social = trim(p_razon_social),
                   nombre_comercial = trim(p_nombre_comercial),
                   tipo_empresa = trim(p_tipo_empresa),
                   estado = p_estado,
                   fecha_actualizacion = systimestamp,
                   usuario_actualizacion = v_usuario
             where id_empresa = p_id_empresa;

            if sql%rowcount = 0 then
                raise_application_error(-20038, 'No se encontro la empresa que intenta actualizar.');
            end if;
        end if;
    exception
        when dup_val_on_index then
            raise_application_error(-20039, 'Ya existe una empresa con ese RUC para la compania seleccionada.');
    end guardar_empresa;

    /*
      Vincula una persona existente a una empresa con un rol.
    */
    procedure vincular_persona_empresa(
        p_id_empresa_persona in out nocopy number,
        p_id_empresa in number,
        p_id_persona in number,
        p_rol in varchar2,
        p_estado in varchar2,
        p_observacion in varchar2
    ) is
        v_empresa number;
        v_persona number;
        v_rol varchar2(50);
        v_usuario varchar2(100);
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        v_rol := upper(trim(p_rol));
        v_usuario := usuario_actual;
        validar_rol(v_rol);
        validar_estado(p_estado, false);

        select count(*) into v_empresa from data.t_cntr_empresas where id_empresa = p_id_empresa;
        select count(*) into v_persona from data.t_cntr_personas where id_persona = p_id_persona;

        if v_empresa = 0 then
            raise_application_error(-20040, 'La empresa seleccionada no existe.');
        end if;

        if v_persona = 0 then
            raise_application_error(-20041, 'La persona seleccionada no existe.');
        end if;

        if p_id_empresa_persona is null then
            select count(*) into v_empresa
              from data.t_cntr_empresa_personas
             where id_empresa = p_id_empresa
               and id_persona = p_id_persona;

            if v_empresa > 0 then
                raise_application_error(-20043, 'La persona ya esta vinculada a la empresa seleccionada.');
            end if;

            insert into data.t_cntr_empresa_personas (
                id_empresa, id_persona, rol, estado, observacion
            ) values (
                p_id_empresa, p_id_persona, v_rol, p_estado, p_observacion
            )
            returning id_empresa_persona into p_id_empresa_persona;
        else
            update data.t_cntr_empresa_personas
               set id_empresa = p_id_empresa,
                   id_persona = p_id_persona,
                   rol = v_rol,
                   estado = p_estado,
                   observacion = p_observacion,
                   fecha_actualizacion = systimestamp,
                   usuario_actualizacion = v_usuario
             where id_empresa_persona = p_id_empresa_persona;

            if sql%rowcount = 0 then
                raise_application_error(-20042, 'No se encontro el vinculo que intenta actualizar.');
            end if;
        end if;
    exception
        when dup_val_on_index then
            raise_application_error(-20043, 'La persona ya esta vinculada a la empresa seleccionada.');
    end vincular_persona_empresa;

    /*
      Inactiva un vinculo persona-empresa.
    */
    procedure desvincular_persona_empresa(p_id_empresa_persona in number) is
        v_usuario varchar2(100);
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        v_usuario := usuario_actual;

        update data.t_cntr_empresa_personas
           set estado = 'INACTIVO',
               fecha_actualizacion = systimestamp,
               usuario_actualizacion = v_usuario
         where id_empresa_persona = p_id_empresa_persona;

        if sql%rowcount = 0 then
            raise_application_error(-20044, 'No se encontro el vinculo que intenta desvincular.');
        end if;
    end desvincular_persona_empresa;

    -- formato_personas: rutina funcional del m?dulo CNTR.

    function formato_personas return clob is
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        return 'TIPO_IDENTIFICACION,IDENTIFICACION,NOMBRES,CORREO,TELEFONO,ESTADO' || chr(10) ||
               'CI,0912345678,JUAN CARLOS PEREZ LOPEZ,correo@dominio.com,0999999999,ACTIVO';
    end formato_personas;

    /*
      Genera y descarga el formato Excel esperado para carga masiva de personas.
    */
    procedure descargar_formato_personas_xlsx is
        v_context apex_exec.t_context;
        v_export apex_data_export.t_export;
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        v_context := apex_exec.open_query_context(
            p_location  => apex_exec.c_location_local_db,
            p_sql_query => q'[
                select 'CI' as tipo_identificacion,
                       '0912345678' as identificacion,
                       'JUAN CARLOS PEREZ LOPEZ' as nombres,
                       'correo@dominio.com' as correo,
                       '0999999999' as telefono,
                       'ACTIVO' as estado
                  from dual
            ]'
        );

        v_export := apex_data_export.export(
            p_context   => v_context,
            p_format    => apex_data_export.c_format_xlsx,
            p_file_name => 'formato_personas_cntr'
        );

        apex_exec.close(v_context);
        v_context := null;
        apex_data_export.download(p_export => v_export);
    exception
        when apex_application.e_stop_apex_engine then
            raise;
        when others then
            if v_context is not null then
                apex_exec.close(v_context);
            end if;
            raise;
    end descargar_formato_personas_xlsx;

    -- formato_vinculos: rutina funcional del m?dulo CNTR.

    function formato_vinculos return clob is
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        return 'TIPO_IDENTIFICACION,IDENTIFICACION_PERSONA,ROL,ESTADO' || chr(10) ||
               'CI,0912345678,REPRESENTANTE,ACTIVO';
    end formato_vinculos;

    /*
      Genera y descarga el formato Excel esperado para carga masiva de vinculos.
    */
    procedure descargar_formato_vinculos_xlsx is
        v_context apex_exec.t_context;
        v_export apex_data_export.t_export;
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        v_context := apex_exec.open_query_context(
            p_location  => apex_exec.c_location_local_db,
            p_sql_query => q'[
                select '0999999999001' as ruc_empresa,
                       'CI' as tipo_identificacion,
                       '0912345678' as identificacion_persona,
                       'REPRESENTANTE' as rol,
                       'ACTIVO' as estado
                  from dual
            ]'
        );

        v_export := apex_data_export.export(
            p_context   => v_context,
            p_format    => apex_data_export.c_format_xlsx,
            p_file_name => 'formato_vinculos_cntr'
        );

        apex_exec.close(v_context);
        v_context := null;
        apex_data_export.download(p_export => v_export);
    exception
        when apex_application.e_stop_apex_engine then
            raise;
        when others then
            if v_context is not null then
                apex_exec.close(v_context);
            end if;
            raise;
    end descargar_formato_vinculos_xlsx;

    /* Genera el formato de carga para asociar sujetos existentes a una configuracion. */
    procedure descargar_formato_config_sujetos_xlsx is
        v_context apex_exec.t_context;
        v_export apex_data_export.t_export;
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        v_context := apex_exec.open_query_context(
            p_location  => apex_exec.c_location_local_db,
            p_sql_query => q'[
                select '0912345678' as identificacion
                  from dual
            ]'
        );

        v_export := apex_data_export.export(
            p_context   => v_context,
            p_format    => apex_data_export.c_format_xlsx,
            p_file_name => 'formato_configuracion_sujetos_cntr'
        );

        apex_exec.close(v_context);
        v_context := null;
        apex_data_export.download(p_export => v_export);
    exception
        when apex_application.e_stop_apex_engine then
            raise;
        when others then
            if v_context is not null then
                apex_exec.close(v_context);
            end if;
            raise;
    end descargar_formato_config_sujetos_xlsx;

    /* Genera el formato de carga para asociar empresas y sus sujetos existentes a una configuracion. */
    procedure descargar_formato_config_empresa_personas_xlsx is
        v_context apex_exec.t_context;
        v_export apex_data_export.t_export;
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        v_context := apex_exec.open_query_context(
            p_location  => apex_exec.c_location_local_db,
            p_sql_query => q'[
                select '0999999999001' as ruc_empresa,
                       '0912345678' as identificacion
                  from dual
            ]'
        );

        v_export := apex_data_export.export(
            p_context   => v_context,
            p_format    => apex_data_export.c_format_xlsx,
            p_file_name => 'formato_configuracion_empresa_sujetos_cntr'
        );

        apex_exec.close(v_context);
        v_context := null;
        apex_data_export.download(p_export => v_export);
    exception
        when apex_application.e_stop_apex_engine then
            raise;
        when others then
            if v_context is not null then
                apex_exec.close(v_context);
            end if;
            raise;
    end descargar_formato_config_empresa_personas_xlsx;

    /*
      Procesa filas de DATA.VT_APEX_EXCEL como personas.
    */
    procedure confirmar_carga_personas(
        p_compania in varchar2,
        p_id_carga out nocopy number
    ) is
        v_compania varchar2(5);
        v_id_persona number;
        v_accion varchar2(30);
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        v_compania := compania_actual(p_compania);
        crear_carga(v_compania, 'PERSONAS', p_id_carga);

        for r in (
            select c01, c02, c03, c04, c05, c06, c07, c08
              from data.vt_apex_excel
             where c01 > 1
               and (trim(c02) is not null or trim(c03) is not null)
        ) loop
            begin
                v_id_persona := null;
                v_accion := 'CREADO';

                begin
                    select id_persona
                      into v_id_persona
                      from data.t_cntr_personas
                     where compania = v_compania
                       and tipo_identificacion = upper(trim(r.c02))
                       and identificacion = upper(trim(r.c03));
                    v_accion := 'ACTUALIZADO';
                exception
                    when no_data_found then
                        null;
                end;

                guardar_persona(
                    p_id_persona => v_id_persona,
                    p_compania => v_compania,
                    p_tipo_identificacion => r.c02,
                    p_identificacion => r.c03,
                    p_nombres => r.c04,
                    p_correo => r.c05,
                    p_telefono => r.c06,
                    p_estado => nvl(upper(trim(r.c07)), 'ACTIVO')
                );

                registrar_detalle_carga(
                    p_id_carga => p_id_carga,
                    p_numero_fila => numero_fila(r.c01),
                    p_clave_referencia => upper(trim(r.c03)),
                    p_accion => v_accion,
                    p_estado => 'OK',
                    p_mensaje => 'Persona procesada correctamente.',
                    p_datos_fila => texto_csv(r.c02) || ',' || texto_csv(r.c03) || ',' || texto_csv(r.c04) || ',' || texto_csv(r.c05)
                );
            exception
                when others then
                    registrar_detalle_carga(
                        p_id_carga => p_id_carga,
                        p_numero_fila => numero_fila(r.c01),
                        p_clave_referencia => upper(trim(r.c03)),
                        p_accion => 'RECHAZADO',
                        p_estado => 'ERROR',
                        p_mensaje => sqlerrm,
                        p_datos_fila => texto_csv(r.c02) || ',' || texto_csv(r.c03) || ',' || texto_csv(r.c04) || ',' || texto_csv(r.c05)
                    );
            end;
        end loop;

        cerrar_carga(p_id_carga);
    end confirmar_carga_personas;

    /*
      Procesa filas de DATA.VT_APEX_EXCEL como vinculos empresa-persona.
    */
    procedure confirmar_carga_vinculos(
        p_compania in varchar2,
        p_id_empresa in number,
        p_id_carga out nocopy number
    ) is
        v_compania varchar2(5);
        v_id_empresa number;
        v_id_persona number;
        v_id_vinculo number;
        v_accion varchar2(30);
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        v_compania := compania_actual(p_compania);
        if p_id_empresa is null then
            raise_application_error(-20045, 'Seleccione la empresa para procesar los vinculos.');
        end if;

        select id_empresa
          into v_id_empresa
          from data.t_cntr_empresas
         where id_empresa = p_id_empresa
           and compania = v_compania
           and estado = 'ACTIVO';

        crear_carga(v_compania, 'VINCULOS', p_id_carga);

        for r in (
            select c01, c02, c03, c04, c05
              from data.vt_apex_excel
             where trim(c02) is not null
                or trim(c03) is not null
        ) loop
            begin
                select id_persona
                  into v_id_persona
                  from data.t_cntr_personas
                 where compania = v_compania
                   and tipo_identificacion = upper(trim(r.c02))
                   and identificacion = upper(trim(r.c03));

                v_id_vinculo := null;
                v_accion := 'CREADO';

                begin
                    select id_empresa_persona
                      into v_id_vinculo
                      from data.t_cntr_empresa_personas
                     where id_empresa = v_id_empresa
                       and id_persona = v_id_persona
                       and rol = upper(trim(r.c04));
                    v_accion := 'ACTUALIZADO';
                exception
                    when no_data_found then
                        null;
                end;

                vincular_persona_empresa(
                    p_id_empresa_persona => v_id_vinculo,
                    p_id_empresa => v_id_empresa,
                    p_id_persona => v_id_persona,
                    p_rol => r.c04,
                    p_estado => nvl(upper(trim(r.c05)), 'ACTIVO'),
                    p_observacion => null
                );

                registrar_detalle_carga(
                    p_id_carga => p_id_carga,
                    p_numero_fila => numero_fila(r.c01),
                    p_clave_referencia => to_char(v_id_empresa) || ' / ' || upper(trim(r.c03)),
                    p_accion => v_accion,
                    p_estado => 'OK',
                    p_mensaje => 'Vinculo procesado correctamente.',
                    p_datos_fila => texto_csv(r.c02) || ',' || texto_csv(r.c03) || ',' || texto_csv(r.c04) || ',' || texto_csv(r.c05)
                );
            exception
                when no_data_found then
                    registrar_detalle_carga(
                        p_id_carga => p_id_carga,
                        p_numero_fila => numero_fila(r.c01),
                        p_clave_referencia => to_char(v_id_empresa) || ' / ' || upper(trim(r.c03)),
                        p_accion => 'RECHAZADO',
                        p_estado => 'ERROR',
                        p_mensaje => 'No se encontro la empresa o la persona indicada.',
                        p_datos_fila => texto_csv(r.c02) || ',' || texto_csv(r.c03) || ',' || texto_csv(r.c04) || ',' || texto_csv(r.c05)
                    );
                when others then
                    registrar_detalle_carga(
                        p_id_carga => p_id_carga,
                        p_numero_fila => numero_fila(r.c01),
                        p_clave_referencia => to_char(v_id_empresa) || ' / ' || upper(trim(r.c03)),
                        p_accion => 'RECHAZADO',
                        p_estado => 'ERROR',
                        p_mensaje => sqlerrm,
                        p_datos_fila => texto_csv(r.c02) || ',' || texto_csv(r.c03) || ',' || texto_csv(r.c04) || ',' || texto_csv(r.c05)
                    );
            end;
        end loop;

        cerrar_carga(p_id_carga);
    end confirmar_carga_vinculos;

    /* Carga de sujetos de configuración: C01 es fila; C02 es identificación. */
    procedure confirmar_carga_config_sujetos(
        p_id_configuracion in number,
        p_compania in varchar2,
        p_id_carga out nocopy number
    ) is
        v_compania varchar2(5);
        v_usuario varchar2(100) := usuario_actual;
        v_id_persona number;
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        v_compania := compania_actual(p_compania);
        validar_editor_configuracion(p_id_configuracion, v_usuario);
        crear_carga(v_compania, 'CONFIG_SUJETOS', p_id_carga);
        for r in (
            select c01, c02 from data.vt_apex_excel
             where c01 > 1 and trim(c02) is not null
        ) loop
            begin
                select id_persona into v_id_persona
                  from data.t_cntr_personas
                 where compania = v_compania
                   and identificacion = upper(trim(r.c02))
                   and estado = 'ACTIVO';
                guardar_config_sujeto(p_id_configuracion, 'PERSONA', v_id_persona, 'ACTIVO');
                registrar_detalle_carga(p_id_carga, numero_fila(r.c01), upper(trim(r.c02)), 'ASOCIADO', 'OK',
                    'Sujeto matriculado asociado a la configuración.', texto_csv(r.c02));
            exception
                when no_data_found then
                    registrar_detalle_carga(p_id_carga, numero_fila(r.c01), upper(trim(r.c02)), 'RECHAZADO', 'ERROR',
                        'La identificación no corresponde a un sujeto matriculado activo.', texto_csv(r.c02));
                when too_many_rows then
                    registrar_detalle_carga(p_id_carga, numero_fila(r.c01), upper(trim(r.c02)), 'RECHAZADO', 'ERROR',
                        'La identificación no es única en la matrícula.', texto_csv(r.c02));
                when others then
                    registrar_detalle_carga(p_id_carga, numero_fila(r.c01), upper(trim(r.c02)), 'RECHAZADO', 'ERROR',
                        sqlerrm, texto_csv(r.c02));
            end;
        end loop;
        cerrar_carga(p_id_carga);
    end confirmar_carga_config_sujetos;

    /* Carga de vínculos de configuración: C01 fila, C02 RUC, C03 identificación. */
    procedure confirmar_carga_config_empresa_personas(
        p_id_configuracion in number,
        p_compania in varchar2,
        p_id_carga out nocopy number
    ) is
        v_compania varchar2(5);
        v_usuario varchar2(100) := usuario_actual;
        v_id_empresa number;
        v_id_persona number;
        v_id_config_empresa number;
        v_existe number;
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        v_compania := compania_actual(p_compania);
        validar_editor_configuracion(p_id_configuracion, v_usuario);
        crear_carga(v_compania, 'CONFIG_EMPRESA_SUJETOS', p_id_carga);
        for r in (
            select c01, c02, c03 from data.vt_apex_excel
             where c01 > 1 and (trim(c02) is not null or trim(c03) is not null)
        ) loop
            begin
                select id_empresa into v_id_empresa from data.t_cntr_empresas
                 where compania=v_compania and ruc=upper(trim(r.c02)) and estado='ACTIVO';
                select id_persona into v_id_persona from data.t_cntr_personas
                 where compania=v_compania and identificacion=upper(trim(r.c03)) and estado='ACTIVO';
                select count(*) into v_existe from data.t_cntr_empresa_personas
                 where id_empresa=v_id_empresa and id_persona=v_id_persona and estado='ACTIVO';
                if v_existe = 0 then
                    raise_application_error(-20069, 'El sujeto no pertenece a la empresa indicada.');
                end if;
                merge into data.t_cntr_config_empresas destino
                using (select p_id_configuracion id_configuracion, v_id_empresa id_empresa from dual) origen
                   on (destino.id_configuracion=origen.id_configuracion and destino.id_empresa=origen.id_empresa)
                when matched then update set destino.estado='ACTIVO', destino.incluir_todos='N',
                    destino.fecha_actualizacion=systimestamp, destino.usuario_actualizacion=v_usuario
                when not matched then insert(id_configuracion,id_empresa,incluir_todos,estado,usuario_creacion)
                    values(origen.id_configuracion,origen.id_empresa,'N','ACTIVO',v_usuario);
                select id_config_empresa into v_id_config_empresa from data.t_cntr_config_empresas
                 where id_configuracion=p_id_configuracion and id_empresa=v_id_empresa;
                merge into data.t_cntr_config_empresa_personas destino
                using (select v_id_config_empresa id_config_empresa,v_id_persona id_persona from dual) origen
                   on (destino.id_config_empresa=origen.id_config_empresa and destino.id_persona=origen.id_persona)
                when matched then update set destino.estado='ACTIVO', destino.fecha_actualizacion=systimestamp,
                    destino.usuario_actualizacion=v_usuario
                when not matched then insert(id_config_empresa,id_persona,estado,usuario_creacion)
                    values(origen.id_config_empresa,origen.id_persona,'ACTIVO',v_usuario);
                registrar_detalle_carga(p_id_carga,numero_fila(r.c01),upper(trim(r.c02))||' / '||upper(trim(r.c03)),
                    'ASOCIADO','OK','Empresa y sujeto asociados a la configuración.',texto_csv(r.c02)||','||texto_csv(r.c03));
            exception
                when no_data_found then
                    registrar_detalle_carga(p_id_carga,numero_fila(r.c01),upper(trim(r.c02))||' / '||upper(trim(r.c03)),
                        'RECHAZADO','ERROR','No se encontró la empresa o el sujeto matriculado.',texto_csv(r.c02)||','||texto_csv(r.c03));
                when others then
                    registrar_detalle_carga(p_id_carga,numero_fila(r.c01),upper(trim(r.c02))||' / '||upper(trim(r.c03)),
                        'RECHAZADO','ERROR',sqlerrm,texto_csv(r.c02)||','||texto_csv(r.c03));
            end;
        end loop;
        cerrar_carga(p_id_carga);
    end confirmar_carga_config_empresa_personas;

    -- eliminar_paso: rutina funcional del m?dulo CNTR.

    procedure eliminar_paso(p_id_paso in number) is
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        delete from data.t_cntr_documento_pasos
         where id_paso = p_id_paso;

        if sql%rowcount = 0 then
            raise_application_error(-20020, 'No se encontro el paso que intenta eliminar.');
        end if;
    end eliminar_paso;

    -- intercambiar_orden: rutina funcional del m?dulo CNTR.

    procedure intercambiar_orden(p_id_paso in number, p_direccion in number) is
        v_id_documento number;
        v_orden_actual number;
        v_id_paso_destino number;
        v_orden_destino number;
        v_usuario varchar2(100);
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        v_usuario := usuario_actual;
        select id_documento, orden
          into v_id_documento, v_orden_actual
          from data.t_cntr_documento_pasos
         where id_paso = p_id_paso;

        if p_direccion < 0 then
            select id_paso, orden
              into v_id_paso_destino, v_orden_destino
              from (
                    select id_paso, orden
                      from data.t_cntr_documento_pasos
                     where id_documento = v_id_documento
                       and orden < v_orden_actual
                     order by orden desc
                   )
             where rownum = 1;
        else
            select id_paso, orden
              into v_id_paso_destino, v_orden_destino
              from (
                    select id_paso, orden
                      from data.t_cntr_documento_pasos
                     where id_documento = v_id_documento
                       and orden > v_orden_actual
                     order by orden
                   )
             where rownum = 1;
        end if;

        update data.t_cntr_documento_pasos
           set orden = -1,
               fecha_actualizacion = systimestamp,
               usuario_actualizacion = v_usuario
         where id_paso = p_id_paso;

        update data.t_cntr_documento_pasos
           set orden = v_orden_actual,
               fecha_actualizacion = systimestamp,
               usuario_actualizacion = v_usuario
         where id_paso = v_id_paso_destino;

        update data.t_cntr_documento_pasos
           set orden = v_orden_destino,
               fecha_actualizacion = systimestamp,
               usuario_actualizacion = v_usuario
         where id_paso = p_id_paso;
    exception
        when no_data_found then
            null;
    end intercambiar_orden;

    -- subir_paso: rutina funcional del m?dulo CNTR.

    procedure subir_paso(p_id_paso in number) is
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        intercambiar_orden(p_id_paso, -1);
    end subir_paso;

    -- bajar_paso: rutina funcional del m?dulo CNTR.

    procedure bajar_paso(p_id_paso in number) is
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        intercambiar_orden(p_id_paso, 1);
    end bajar_paso;

    -- validar_propietario: rutina funcional del m?dulo CNTR.

    procedure validar_propietario(p_id_configuracion in number, p_usuario in varchar2) is
        v_existe number;
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        select count(*) into v_existe from data.t_cntr_configuraciones
         where id_configuracion=p_id_configuracion and usuario_creacion=p_usuario;
        if v_existe=0 then
            raise_application_error(-20060, 'La configuracion no existe o no pertenece al usuario actual.');
        end if;
    end validar_propietario;

    -- validar_editor_configuracion: valida que el usuario pueda editar, sin delegarle administrar accesos.
    procedure validar_editor_configuracion(p_id_configuracion in number, p_usuario in varchar2) is
        v_existe number;
    -- Ejecuta la logica funcional y conserva la auditoria transaccional.
    begin
        select count(*) into v_existe
          from data.t_cntr_configuraciones c
         where c.id_configuracion = p_id_configuracion
           and (upper(c.usuario_creacion) = upper(p_usuario)
                or exists (
                    select 1
                      from data.t_cntr_config_usuarios cu
                     where cu.id_configuracion = c.id_configuracion
                       and upper(cu.usuario_apex) = upper(p_usuario)
                ));
        if v_existe = 0 then
            raise_application_error(-20060, 'La configuracion no existe o no esta compartida con el usuario actual.');
        end if;
    end validar_editor_configuracion;

    -- guardar_configuracion: rutina funcional del m?dulo CNTR.

    procedure guardar_configuracion(p_id_configuracion in out nocopy number, p_compania in varchar2, p_nombre in varchar2, p_estado in
    varchar2) is
        v_usuario varchar2(100):=usuario_actual;
        v_nombre varchar2(200):=trim(p_nombre);
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        if v_nombre is null then raise_application_error(-20061,'Ingrese el nombre de la configuracion.'); end if;
        if trim(p_compania) is null then raise_application_error(-20070,'Seleccione una compania antes de configurar la captura.'); end
    if;
        if upper(trim(p_estado)) not in ('ACTIVO','INACTIVO') then raise_application_error(-20062,'Seleccione un estado valido.'); end if;
        if p_id_configuracion is null then
            insert into data.t_cntr_configuraciones(compania,nombre,estado,usuario_creacion)
            values(trim(p_compania),v_nombre,'INACTIVO',v_usuario) returning id_configuracion into p_id_configuracion;
            if upper(trim(p_estado))='ACTIVO' then activar_configuracion(p_id_configuracion,'ACTIVO'); end if;
        else
            validar_editor_configuracion(p_id_configuracion,v_usuario);
            update data.t_cntr_configuraciones set nombre=v_nombre, fecha_actualizacion=systimestamp, usuario_actualizacion=v_usuario
    where id_configuracion=p_id_configuracion;
            activar_configuracion(p_id_configuracion,upper(trim(p_estado)));
        end if;
    exception when dup_val_on_index then
    raise_application_error(-20063,'Ya existe una configuracion con ese nombre para el usuario actual.');
    end guardar_configuracion;

    -- guardar_config_sujeto: rutina funcional del m?dulo CNTR.

    procedure guardar_config_sujeto(p_id_configuracion in number, p_tipo_sujeto in varchar2, p_id_sujeto in number, p_estado in varchar2)
    is
        v_usuario varchar2(100):=usuario_actual; v_tipo varchar2(20):=upper(trim(p_tipo_sujeto)); v_existe number;
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        validar_editor_configuracion(p_id_configuracion,v_usuario);
        if v_tipo not in ('PERSONA','EMPRESA') then raise_application_error(-20064,'Seleccione un tipo de sujeto valido.'); end if;
        if v_tipo='PERSONA' then select count(*) into v_existe from data.t_cntr_personas where id_persona=p_id_sujeto and estado='ACTIVO';
        else select count(*) into v_existe from data.t_cntr_empresas where id_empresa=p_id_sujeto and estado='ACTIVO'; end if;
        if v_existe=0 then raise_application_error(-20065,'El sujeto seleccionado no existe o esta inactivo.'); end if;
        merge into data.t_cntr_config_sujetos d using (select p_id_configuracion id_configuracion,v_tipo tipo_sujeto,p_id_sujeto id_sujeto
    from dual) s
        on (d.id_configuracion=s.id_configuracion and d.tipo_sujeto=s.tipo_sujeto and d.id_sujeto=s.id_sujeto)
        when matched then update set d.estado=upper(trim(p_estado)),d.fecha_actualizacion=systimestamp,d.usuario_actualizacion=v_usuario
        when not matched then insert(id_configuracion,tipo_sujeto,id_sujeto,estado,usuario_creacion)
    values(s.id_configuracion,s.tipo_sujeto,s.id_sujeto,upper(trim(p_estado)),v_usuario);
    end guardar_config_sujeto;

    -- guardar_config_documento: rutina funcional del m?dulo CNTR.

    procedure guardar_config_documento(p_id_configuracion in number, p_id_documento in number, p_estado in varchar2) is
        v_usuario varchar2(100):=usuario_actual; v_existe number;
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        validar_editor_configuracion(p_id_configuracion,v_usuario);
        select count(*) into v_existe from data.t_cntr_documentos where id_documento=p_id_documento and estado='ACTIVO';
        if v_existe=0 then raise_application_error(-20066,'El documento seleccionado no existe o esta inactivo.'); end if;
        merge into data.t_cntr_config_documentos d using (select p_id_configuracion id_configuracion,p_id_documento id_documento from
    dual) s
        on (d.id_configuracion=s.id_configuracion and d.id_documento=s.id_documento)
        when matched then update set d.estado=upper(trim(p_estado)),d.fecha_actualizacion=systimestamp,d.usuario_actualizacion=v_usuario
        when not matched then insert(id_configuracion,id_documento,estado,usuario_creacion)
    values(s.id_configuracion,s.id_documento,upper(trim(p_estado)),v_usuario);
    end guardar_config_documento;

    -- guardar_config_empresa: rutina funcional del m?dulo CNTR.

    procedure guardar_config_empresa(p_id_configuracion in number, p_id_empresa in number, p_incluir_todos in varchar2, p_personas_csv in
    varchar2) is
        v_usuario varchar2(100):=usuario_actual; v_id number; v_existe number; v_incluir_todos
    varchar2(1):=nvl(upper(trim(p_incluir_todos)),'N');
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        validar_editor_configuracion(p_id_configuracion,v_usuario);
        select count(*) into v_existe from data.t_cntr_empresas where id_empresa=p_id_empresa and estado='ACTIVO';
        if v_existe=0 then raise_application_error(-20068,'La empresa seleccionada no existe o está inactiva.'); end if;
        merge into data.t_cntr_config_empresas d using (select p_id_configuracion id_configuracion,p_id_empresa id_empresa from dual) s
        on (d.id_configuracion=s.id_configuracion and d.id_empresa=s.id_empresa)
        when matched then update set
    d.incluir_todos=v_incluir_todos,d.estado='ACTIVO',d.fecha_actualizacion=systimestamp,d.usuario_actualizacion=v_usuario
        when not matched then insert(id_configuracion,id_empresa,incluir_todos,estado,usuario_creacion)
    values(s.id_configuracion,s.id_empresa,v_incluir_todos,'ACTIVO',v_usuario);
        select id_config_empresa into v_id from data.t_cntr_config_empresas where id_configuracion=p_id_configuracion and
    id_empresa=p_id_empresa;
        if v_incluir_todos='S' then
            update data.t_cntr_config_empresa_personas set
    estado='INACTIVO',fecha_actualizacion=systimestamp,usuario_actualizacion=v_usuario where id_config_empresa=v_id;
        else
            update data.t_cntr_config_empresa_personas
               set estado='INACTIVO',fecha_actualizacion=systimestamp,usuario_actualizacion=v_usuario
             where id_config_empresa=v_id
               and estado='ACTIVO';
            for r in (select to_number(regexp_substr(p_personas_csv,'[^,:]+',1,level)) id_persona from dual connect by
    regexp_substr(p_personas_csv,'[^,:]+',1,level) is not null) loop
                select count(*) into v_existe from data.t_cntr_empresa_personas where id_empresa=p_id_empresa and id_persona=r.id_persona
    and estado='ACTIVO';
                if v_existe=0 then raise_application_error(-20069,'La persona seleccionada no pertenece a la empresa activa.'); end if;
                merge into data.t_cntr_config_empresa_personas d using (select v_id id_config_empresa,r.id_persona id_persona from dual) s
    on (d.id_config_empresa=s.id_config_empresa and d.id_persona=s.id_persona)
                when matched then update set d.estado='ACTIVO',d.fecha_actualizacion=systimestamp,d.usuario_actualizacion=v_usuario
                when not matched then insert(id_config_empresa,id_persona,estado,usuario_creacion)
    values(s.id_config_empresa,s.id_persona,'ACTIVO',v_usuario);
            end loop;
        end if;
    end guardar_config_empresa;

    -- eliminar_config_documento: rutina funcional del m?dulo CNTR.

    procedure eliminar_config_documento(p_id_configuracion in number, p_id_documento in number) is v_usuario
    varchar2(100):=usuario_actual;
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        validar_editor_configuracion(p_id_configuracion, v_usuario);
        update data.t_cntr_config_documentos
           set estado = 'INACTIVO',
               fecha_actualizacion = systimestamp,
               usuario_actualizacion = v_usuario
         where id_configuracion = p_id_configuracion
           and id_documento = p_id_documento;
    end eliminar_config_documento;
    -- eliminar_config_sujeto: rutina funcional del m?dulo CNTR.
    procedure eliminar_config_sujeto(p_id_configuracion in number, p_id_sujeto in number, p_tipo_sujeto in varchar2 default 'PERSONA') is
    v_usuario varchar2(100):=usuario_actual; v_tipo varchar2(20):=upper(trim(p_tipo_sujeto));
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        validar_editor_configuracion(p_id_configuracion,v_usuario);
        if v_tipo not in ('PERSONA','EMPRESA') then raise_application_error(-20073,'Tipo de sujeto invalido.'); end if;
        update data.t_cntr_config_sujetos
           set estado = 'INACTIVO',
               fecha_actualizacion = systimestamp,
               usuario_actualizacion = v_usuario
         where id_configuracion = p_id_configuracion
           and id_sujeto = p_id_sujeto
           and tipo_sujeto = v_tipo;
    end eliminar_config_sujeto;
    -- eliminar_config_empresa: rutina funcional del m?dulo CNTR.
    procedure eliminar_config_empresa(
        p_id_configuracion in number,
        p_id_config_empresa in number
    ) is
        v_usuario varchar2(100) := usuario_actual;
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        validar_editor_configuracion(p_id_configuracion, v_usuario);
        update data.t_cntr_config_empresa_personas
           set estado = 'INACTIVO',
               fecha_actualizacion = systimestamp,
               usuario_actualizacion = v_usuario
         where id_config_empresa = p_id_config_empresa;
        update data.t_cntr_config_empresas
           set estado = 'INACTIVO',
               fecha_actualizacion = systimestamp,
               usuario_actualizacion = v_usuario
         where id_config_empresa = p_id_config_empresa
           and id_configuracion = p_id_configuracion;
    end eliminar_config_empresa;

    -- cambiar_estado_config_documento: rutina funcional del m?dulo CNTR.

    procedure cambiar_estado_config_documento(p_id_configuracion in number, p_id_documento in number, p_estado in varchar2) is v_usuario
    varchar2(100):=usuario_actual;
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        validar_editor_configuracion(p_id_configuracion,v_usuario);
        if upper(trim(p_estado)) not in ('ACTIVO','INACTIVO') then raise_application_error(-20071,'Estado de documento invalido.'); end
    if;
        update data.t_cntr_config_documentos set
    estado=upper(trim(p_estado)),fecha_actualizacion=systimestamp,usuario_actualizacion=v_usuario where
    id_configuracion=p_id_configuracion and id_documento=p_id_documento;
    end cambiar_estado_config_documento;

    -- cambiar_estado_config_sujeto: rutina funcional del m?dulo CNTR.

    procedure cambiar_estado_config_sujeto(p_id_configuracion in number, p_id_sujeto in number, p_estado in varchar2, p_tipo_sujeto in
    varchar2 default 'PERSONA') is v_usuario varchar2(100):=usuario_actual; v_tipo varchar2(20):=upper(trim(p_tipo_sujeto));
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        validar_editor_configuracion(p_id_configuracion,v_usuario);
        if upper(trim(p_estado)) not in ('ACTIVO','INACTIVO') then raise_application_error(-20072,'Estado de sujeto invalido.'); end if;
        if v_tipo not in ('PERSONA','EMPRESA') then raise_application_error(-20073,'Tipo de sujeto invalido.'); end if;
        update data.t_cntr_config_sujetos set
    estado=upper(trim(p_estado)),fecha_actualizacion=systimestamp,usuario_actualizacion=v_usuario where
    id_configuracion=p_id_configuracion and id_sujeto=p_id_sujeto and tipo_sujeto=v_tipo;
    end cambiar_estado_config_sujeto;

    -- cambiar_estado_config_empresa: rutina funcional del m?dulo CNTR.

    procedure cambiar_estado_config_empresa(p_id_configuracion in number, p_id_config_empresa in number, p_estado in varchar2) is
    v_usuario varchar2(100):=usuario_actual;
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        validar_editor_configuracion(p_id_configuracion,v_usuario);
        if upper(trim(p_estado)) not in ('ACTIVO','INACTIVO') then raise_application_error(-20073,'Estado de empresa invalido.'); end if;
        update data.t_cntr_config_empresas set
    estado=upper(trim(p_estado)),fecha_actualizacion=systimestamp,usuario_actualizacion=v_usuario where
    id_config_empresa=p_id_config_empresa and id_configuracion=p_id_configuracion;
        update data.t_cntr_config_empresa_personas set
    estado=upper(trim(p_estado)),fecha_actualizacion=systimestamp,usuario_actualizacion=v_usuario where
    id_config_empresa=p_id_config_empresa;
    end cambiar_estado_config_empresa;

    /** Agrega solo usuarios corporativos activos del mismo departamento del creador. */
    procedure compartir_configuracion(p_id_configuracion in number, p_usuario_apex in varchar2) is
        v_usuario varchar2(100):=usuario_actual;
        v_destino varchar2(100):=upper(trim(p_usuario_apex));
        v_depto_origen data.vt_corp_usuario.departamento%type;
        v_depto_destino data.vt_corp_usuario.departamento%type;
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        validar_propietario(p_id_configuracion,v_usuario);
        if v_destino is null or v_destino=upper(v_usuario) then
    raise_application_error(-20074,'Seleccione otro usuario para compartir la configuracion.'); end if;
        select departamento into v_depto_origen from data.vt_corp_usuario where upper(nombreusuario)=upper(v_usuario) and rownum=1;
        select departamento into v_depto_destino from data.vt_corp_usuario where upper(nombreusuario)=v_destino and nvl(estado,0)=1 and
    rownum=1;
        if v_depto_origen is null or v_depto_destino is null or upper(v_depto_origen)<>upper(v_depto_destino) then
    raise_application_error(-20075,'El usuario compartido debe pertenecer al mismo departamento o area.'); end if;
        insert into data.t_cntr_config_usuarios(id_configuracion,usuario_apex,usuario_creacion)
    values(p_id_configuracion,v_destino,v_usuario);
    exception when no_data_found then
    raise_application_error(-20076,'El usuario seleccionado no esta activo en el catalogo corporativo.'); when dup_val_on_index then
    raise_application_error(-20077,'El usuario ya tiene acceso compartido a esta configuracion.');
    end compartir_configuracion;

    /** Revoca la visualización y ejecución delegadas sin eliminar la configuración. */
    procedure eliminar_usuario_compartido(p_id_configuracion in number, p_usuario_apex in varchar2) is
        v_usuario varchar2(100):=usuario_actual;
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        validar_propietario(p_id_configuracion,v_usuario);
        delete from data.t_cntr_config_usuarios where id_configuracion=p_id_configuracion and
    upper(usuario_apex)=upper(trim(p_usuario_apex));
        if sql%rowcount=0 then raise_application_error(-20078,'El usuario compartido no existe para esta configuracion.'); end if;
    end eliminar_usuario_compartido;

    -- activar_configuracion: rutina funcional del m?dulo CNTR.

    procedure activar_configuracion(p_id_configuracion in number, p_estado in varchar2) is
        v_usuario varchar2(100):=usuario_actual; v_sujetos number; v_documentos number;
    -- Ejecuta la l?gica funcional y conserva la auditor?a transaccional.
    begin
        validar_editor_configuracion(p_id_configuracion,v_usuario);
        if upper(trim(p_estado))='ACTIVO' then
            select (select count(*) from data.t_cntr_config_sujetos where id_configuracion=p_id_configuracion and estado='ACTIVO') +
    (select count(*) from data.t_cntr_config_empresas where id_configuracion=p_id_configuracion and estado='ACTIVO') into v_sujetos from
    dual;
            select count(*) into v_documentos from data.t_cntr_config_documentos where id_configuracion=p_id_configuracion and
    estado='ACTIVO';
            if v_sujetos=0 or v_documentos=0 then
    raise_application_error(-20067,'Para activar la configuracion agregue al menos un sujeto y un documento.'); end if;
        end if;
        update data.t_cntr_configuraciones set
    estado=upper(trim(p_estado)),fecha_actualizacion=systimestamp,usuario_actualizacion=v_usuario where
    id_configuracion=p_id_configuracion;
    end activar_configuracion;
end pk_cntr_configuracion;
/
