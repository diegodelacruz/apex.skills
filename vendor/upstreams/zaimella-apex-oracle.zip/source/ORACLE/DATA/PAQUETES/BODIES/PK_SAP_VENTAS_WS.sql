﻿prompt TEST PACKAGE_BODY DATA.PK_SAP_VENTAS_WS

  CREATE OR REPLACE EDITIONABLE PACKAGE BODY PK_SAP_VENTAS_WS AS

    FUNCTION F_CARD_CODE(P_CODIGOCLIENTE IN VARCHAR2) RETURN VARCHAR2 IS
    BEGIN
        RETURN 'C' || REGEXP_REPLACE(P_CODIGOCLIENTE, '^C');
    END F_CARD_CODE;

    FUNCTION F_JSON_PEDIDO(
        P_IDPEDIDO IN NUMBER
    ) RETURN CLOB IS
        V_CAB DATA.T_VTAS_PEDIDOS_CAB%ROWTYPE;
        V_CARD_CODE VARCHAR2(50);
        V_COUNTRY VARCHAR2(10);
        V_SLP_CODE NUMBER;
        V_TAX_CODE VARCHAR2(20);
        V_OPERACION VARCHAR2(3);
        V_AFECTACION VARCHAR2(2);
        V_DOC_DATE DATE;
        V_DOC_CURRENCY VARCHAR2(3);
        V_DOC_RATE NUMBER;
        V_COMMENTS VARCHAR2(254);
        V_LINEAS NUMBER;
        V_JSON CLOB;
    BEGIN
        SELECT *
          INTO V_CAB
          FROM DATA.T_VTAS_PEDIDOS_CAB
         WHERE IDPEDIDO = P_IDPEDIDO;

        IF V_CAB.COMPANIA <> '00003' THEN
            RAISE_APPLICATION_ERROR(-20110, 'El envio SAP Service Layer solo aplica para Peru.');
        END IF;

        V_CARD_CODE := F_CARD_CODE(NVL(V_CAB.CODIGOCLIENTE, V_CAB.CODIGOGRUPO));

        BEGIN
            SELECT MAX(C."Country"), MAX(C."SlpCode")
              INTO V_COUNTRY, V_SLP_CODE
              FROM OCRD@HANA_PE C
             WHERE C."CardCode" = V_CARD_CODE
               AND C."CardType" = 'C';
        EXCEPTION
            WHEN OTHERS THEN
                V_COUNTRY := 'PE';
                V_SLP_CODE := NULL;
        END;

        IF NVL(V_COUNTRY, 'PE') = 'PE' THEN
            V_TAX_CODE := 'IGV';
            V_OPERACION := 'A';
            V_AFECTACION := '10';
            V_DOC_CURRENCY := 'SOL';
        ELSE
            V_TAX_CODE := 'EXO';
            V_OPERACION := 'EX';
            V_AFECTACION := '40';
            V_DOC_CURRENCY := 'USD';
        END IF;

        -- En TEST puede no estar abierto el periodo actual; se usa la ultima fecha contable con ordenes SAP.
        BEGIN
            SELECT NVL(MAX(C."DocDate"), TRUNC(SYSDATE))
              INTO V_DOC_DATE
              FROM ORDR@HANA_PE C
             WHERE C."DocDate" <= TRUNC(SYSDATE);
        EXCEPTION
            WHEN OTHERS THEN
                V_DOC_DATE := TRUNC(SYSDATE);
        END;

        IF V_DOC_CURRENCY = 'USD' THEN
            BEGIN
                SELECT MAX(C."DocRate") KEEP (DENSE_RANK LAST ORDER BY C."DocDate", C."DocEntry")
                  INTO V_DOC_RATE
                  FROM ORDR@HANA_PE C
                 WHERE C."DocCur" = 'USD'
                   AND C."DocRate" > 0
                   AND C."DocDate" <= V_DOC_DATE;
            EXCEPTION
                WHEN OTHERS THEN
                    V_DOC_RATE := NULL;
            END;

            IF NVL(V_DOC_RATE, 0) <= 0 THEN
                RAISE_APPLICATION_ERROR(-20119, 'No existe tasa USD valida en SAP para convertir pedido de exportacion.');
            END IF;
        ELSE
            V_DOC_RATE := 1;
        END IF;

        V_COMMENTS := SUBSTR(
            'OC ' || NVL(V_CAB.ORDENCOMPRA, 'S/N') ||
            CASE WHEN TRIM(V_CAB.OBSERVACION) IS NOT NULL THEN ' | Obs: ' || TRIM(V_CAB.OBSERVACION) ELSE NULL END ||
            CASE WHEN TRIM(V_CAB.INFORMACIONADICIONAL) IS NOT NULL THEN ' | Info: ' || TRIM(REGEXP_REPLACE(V_CAB.INFORMACIONADICIONAL, '[[:space:]]+', ' ')) ELSE NULL END ||
            ' | APEX ' || P_IDPEDIDO,
            1,
            254
        );

        SELECT COUNT(1)
          INTO V_LINEAS
          FROM DATA.T_VTAS_PEDIDOS
         WHERE IDPEDIDO = P_IDPEDIDO
           AND ESTADO = 1
           AND CODIGOPRODUCTO IS NOT NULL;

        IF V_LINEAS = 0 THEN
            RAISE_APPLICATION_ERROR(-20111, 'El pedido no tiene lineas activas homologadas para enviar a SAP.');
        END IF;

        APEX_JSON.INITIALIZE_CLOB_OUTPUT;
        APEX_JSON.OPEN_OBJECT;
        APEX_JSON.WRITE('CardCode', V_CARD_CODE);
        APEX_JSON.WRITE('DocDate', TO_CHAR(V_DOC_DATE, 'YYYY-MM-DD'));
        APEX_JSON.WRITE('TaxDate', TO_CHAR(V_DOC_DATE, 'YYYY-MM-DD'));
        APEX_JSON.WRITE('DocDueDate', TO_CHAR(GREATEST(NVL(V_CAB.FECHAENTREGA, V_DOC_DATE), V_DOC_DATE), 'YYYY-MM-DD'));
        APEX_JSON.WRITE('NumAtCard', SUBSTR(NVL(V_CAB.ORDENCOMPRA, 'APEX-' || P_IDPEDIDO), 1, 100));
        APEX_JSON.WRITE('DocCurrency', V_DOC_CURRENCY);
        APEX_JSON.WRITE('DocRate', V_DOC_RATE);
        APEX_JSON.WRITE('Comments', V_COMMENTS);
        IF V_SLP_CODE IS NOT NULL THEN
            APEX_JSON.WRITE('SalesPersonCode', V_SLP_CODE);
        END IF;

        APEX_JSON.OPEN_ARRAY('DocumentLines');
        FOR R IN (
            SELECT LINEA,
                   CODIGOPRODUCTO,
                   CANTIDAD,
                   PRECIO,
                   DESCUENTO
              FROM DATA.T_VTAS_PEDIDOS
             WHERE IDPEDIDO = P_IDPEDIDO
               AND ESTADO = 1
               AND CODIGOPRODUCTO IS NOT NULL
             ORDER BY LINEA
        ) LOOP
            IF NVL(R.CANTIDAD, 0) <= 0 THEN
                RAISE_APPLICATION_ERROR(-20112, 'La linea ' || R.LINEA || ' tiene cantidad invalida para SAP.');
            END IF;

            IF NVL(R.PRECIO, 0) < 0 THEN
                RAISE_APPLICATION_ERROR(-20113, 'La linea ' || R.LINEA || ' tiene precio invalido para SAP.');
            END IF;

            APEX_JSON.OPEN_OBJECT;
            APEX_JSON.WRITE('ItemCode', R.CODIGOPRODUCTO);
            APEX_JSON.WRITE('Quantity', R.CANTIDAD);
            -- SAP Peru recibe el precio unitario con precision controlada de cuatro decimales.
            APEX_JSON.WRITE(
                'UnitPrice',
                CASE
                    WHEN V_DOC_CURRENCY = 'USD' THEN ROUND(NVL(R.PRECIO, 0) / V_DOC_RATE, 4)
                    ELSE ROUND(NVL(R.PRECIO, 0), 4)
                END
            );
            APEX_JSON.WRITE('Currency', V_DOC_CURRENCY);
            IF V_DOC_CURRENCY = 'USD' THEN
                APEX_JSON.WRITE('Rate', V_DOC_RATE);
            END IF;
            APEX_JSON.WRITE('DiscountPercent', NVL(R.DESCUENTO, 0));
            APEX_JSON.WRITE('WarehouseCode', '06');
            APEX_JSON.WRITE('TaxCode', V_TAX_CODE);
            APEX_JSON.WRITE('U_BPP_OPER', V_OPERACION);
            APEX_JSON.WRITE('U_STR_FE_SUNATC7', V_AFECTACION);
            APEX_JSON.WRITE('U_tipoOpT12', '01');
            APEX_JSON.CLOSE_OBJECT;
        END LOOP;
        APEX_JSON.CLOSE_ARRAY;
        APEX_JSON.CLOSE_OBJECT;

        V_JSON := APEX_JSON.GET_CLOB_OUTPUT;
        APEX_JSON.FREE_OUTPUT;
        RETURN V_JSON;
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                APEX_JSON.FREE_OUTPUT;
            EXCEPTION
                WHEN OTHERS THEN
                    NULL;
            END;
            RAISE;
    END F_JSON_PEDIDO;

    PROCEDURE SP_POST_ORDERS(
        P_COMPANIA IN VARCHAR2,
        P_JSON IN CLOB,
        P_SESSION_ID IN VARCHAR2,
        P_ROUTE_ID IN VARCHAR2,
        P_RESPONSE OUT CLOB,
        P_HTTP_CODE OUT NUMBER
    ) IS
        V_BASE_URL VARCHAR2(4000);
        V_WALLET_PATH VARCHAR2(4000);
        V_HTTP_REQ UTL_HTTP.REQ;
        V_HTTP_RESP UTL_HTTP.RESP;
        V_BUFFER VARCHAR2(32767);
        V_BODY VARCHAR2(32767);
        V_COOKIE VARCHAR2(4000);
    BEGIN
        SELECT MAX(CASE WHEN DESCRIPCION = 'url' THEN VALOR END),
               MAX(CASE WHEN DESCRIPCION = 'certificado' THEN VALOR END)
          INTO V_BASE_URL, V_WALLET_PATH
          FROM DATA.T_CORP_UDC
         WHERE CODIGOCOMPANIA = P_COMPANIA
           AND ID_CABECERA = 'SAP_CREDEN'
           AND DESCRIPCION IN ('url', 'certificado');

        IF V_BASE_URL IS NULL OR V_WALLET_PATH IS NULL THEN
            RAISE_APPLICATION_ERROR(-20114, 'Configuracion SAP_CREDEN incompleta para Service Layer.');
        END IF;

        V_BODY := DBMS_LOB.SUBSTR(P_JSON, 32767, 1);
        UTL_HTTP.SET_WALLET(V_WALLET_PATH, NULL);
        UTL_HTTP.SET_RESPONSE_ERROR_CHECK(FALSE);

        V_HTTP_REQ := UTL_HTTP.BEGIN_REQUEST(V_BASE_URL || 'Orders', 'POST', 'HTTP/1.1');
        UTL_HTTP.SET_HEADER(V_HTTP_REQ, 'Content-Type', 'application/json');
        UTL_HTTP.SET_HEADER(V_HTTP_REQ, 'Accept', 'application/json');
        UTL_HTTP.SET_HEADER(V_HTTP_REQ, 'Content-Length', LENGTH(V_BODY));

        V_COOKIE := 'B1SESSION=' || P_SESSION_ID;
        IF P_ROUTE_ID IS NOT NULL THEN
            V_COOKIE := V_COOKIE || '; ROUTEID=' || P_ROUTE_ID;
        END IF;
        UTL_HTTP.SET_HEADER(V_HTTP_REQ, 'Cookie', V_COOKIE);
        UTL_HTTP.WRITE_RAW(V_HTTP_REQ, UTL_RAW.CAST_TO_RAW(V_BODY));

        V_HTTP_RESP := UTL_HTTP.GET_RESPONSE(V_HTTP_REQ);
        P_HTTP_CODE := V_HTTP_RESP.STATUS_CODE;
        P_RESPONSE := EMPTY_CLOB();

        BEGIN
            LOOP
                UTL_HTTP.READ_TEXT(V_HTTP_RESP, V_BUFFER, 32767);
                P_RESPONSE := P_RESPONSE || V_BUFFER;
            END LOOP;
        EXCEPTION
            WHEN UTL_HTTP.END_OF_BODY THEN
                NULL;
        END;

        UTL_HTTP.END_RESPONSE(V_HTTP_RESP);
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                UTL_HTTP.END_RESPONSE(V_HTTP_RESP);
            EXCEPTION
                WHEN OTHERS THEN
                    NULL;
            END;
            RAISE;
    END SP_POST_ORDERS;

    PROCEDURE SP_CREAR_PEDIDO(
        P_IDPEDIDO IN NUMBER,
        P_USUARIO IN VARCHAR2,
        P_EXITO OUT NUMBER,
        P_MENSAJE OUT VARCHAR2
    ) IS
        V_CAB DATA.T_VTAS_PEDIDOS_CAB%ROWTYPE;
        V_JSON CLOB;
        V_RESPUESTA CLOB;
        V_LOGIN_RESPUESTA CLOB;
        V_SESSION_ID VARCHAR2(4000);
        V_ROUTE_ID VARCHAR2(4000);
        V_HTTP_CODE NUMBER;
        V_DOCENTRY NUMBER;
        V_DOCNUM NUMBER;
    BEGIN
        P_EXITO := 0;
        P_MENSAJE := NULL;

        SELECT *
          INTO V_CAB
          FROM DATA.T_VTAS_PEDIDOS_CAB
         WHERE IDPEDIDO = P_IDPEDIDO
         FOR UPDATE;

        IF V_CAB.COMPANIA <> '00003' THEN
            P_EXITO := 1;
            P_MENSAJE := 'No aplica envio SAP para compania ' || V_CAB.COMPANIA;
            RETURN;
        END IF;

        IF V_CAB.ESTADO <> 1 THEN
            RAISE_APPLICATION_ERROR(-20115, 'El pedido debe estar aprobado antes de enviarse a SAP.');
        END IF;

        IF V_CAB.SAP_DOCENTRY IS NOT NULL THEN
            P_EXITO := 1;
            P_MENSAJE := 'Pedido ya enviado a SAP DocEntry ' || V_CAB.SAP_DOCENTRY;
            RETURN;
        END IF;

        UPDATE DATA.T_VTAS_PEDIDOS_CAB
           SET SAP_ESTADO = 'EN_PROCESO',
               SAP_FECHA_ENVIO = SYSDATE,
               SAP_USUARIO_ENVIO = P_USUARIO,
               SAP_MENSAJE = NULL
         WHERE IDPEDIDO = P_IDPEDIDO;

        V_JSON := F_JSON_PEDIDO(P_IDPEDIDO);
        DATA.PK_SAP_COMMONS.SP_LOGIN(V_CAB.COMPANIA, V_SESSION_ID, V_ROUTE_ID, V_LOGIN_RESPUESTA);

        IF V_SESSION_ID IS NULL THEN
            UPDATE DATA.T_VTAS_PEDIDOS_CAB
               SET SAP_ESTADO = 'ERROR',
                   SAP_MENSAJE = SUBSTR(V_LOGIN_RESPUESTA, 1, 4000)
             WHERE IDPEDIDO = P_IDPEDIDO;
            RAISE_APPLICATION_ERROR(-20116, 'No se pudo iniciar sesion en SAP Service Layer.');
        END IF;

        SP_POST_ORDERS(V_CAB.COMPANIA, V_JSON, V_SESSION_ID, V_ROUTE_ID, V_RESPUESTA, V_HTTP_CODE);

        IF V_HTTP_CODE NOT BETWEEN 200 AND 299 THEN
            UPDATE DATA.T_VTAS_PEDIDOS_CAB
               SET SAP_ESTADO = 'ERROR',
                   SAP_MENSAJE = SUBSTR('HTTP ' || V_HTTP_CODE || ': ' || V_RESPUESTA, 1, 4000)
             WHERE IDPEDIDO = P_IDPEDIDO;
            RAISE_APPLICATION_ERROR(-20117, 'SAP no creo el pedido. HTTP ' || V_HTTP_CODE || ': ' || SUBSTR(V_RESPUESTA, 1, 1000));
        END IF;

        V_DOCENTRY := JSON_VALUE(V_RESPUESTA, '$.DocEntry' RETURNING NUMBER NULL ON ERROR);
        V_DOCNUM := JSON_VALUE(V_RESPUESTA, '$.DocNum' RETURNING NUMBER NULL ON ERROR);

        IF V_DOCENTRY IS NULL THEN
            UPDATE DATA.T_VTAS_PEDIDOS_CAB
               SET SAP_ESTADO = 'ERROR',
                   SAP_MENSAJE = SUBSTR('Respuesta SAP sin DocEntry: ' || V_RESPUESTA, 1, 4000)
             WHERE IDPEDIDO = P_IDPEDIDO;
            RAISE_APPLICATION_ERROR(-20118, 'SAP respondio sin DocEntry para el pedido.');
        END IF;

        UPDATE DATA.T_VTAS_PEDIDOS_CAB
           SET SAP_DOCENTRY = V_DOCENTRY,
               SAP_DOCNUM = V_DOCNUM,
               SAP_FECHA_ENVIO = SYSDATE,
               SAP_USUARIO_ENVIO = P_USUARIO,
               SAP_ESTADO = 'ENVIADO',
               SAP_MENSAJE = SUBSTR(V_RESPUESTA, 1, 4000),
               DOCUMENTO = NVL(TO_CHAR(V_DOCNUM), TO_CHAR(V_DOCENTRY))
         WHERE IDPEDIDO = P_IDPEDIDO;

        -- SAP es una transaccion externa. Se confirma la referencia antes de ADAIA
        -- para evitar duplicar el pedido SAP si ADAIA rechaza el envio.
        COMMIT;

        DECLARE
            V_ADAIA_EXITO NUMBER;
            V_ADAIA_MENSAJE VARCHAR2(4000);
            V_ADAIA_ERROR VARCHAR2(4000);
        BEGIN
            DATA.PK_ADAIA_WS.SP_ENVIAR_PEDIDO(
                P_IDPEDIDO => P_IDPEDIDO,
                P_USUARIO => P_USUARIO,
                P_EXITO => V_ADAIA_EXITO,
                P_MENSAJE => V_ADAIA_MENSAJE
            );
            COMMIT;
        EXCEPTION
            WHEN OTHERS THEN
                V_ADAIA_ERROR := SQLERRM;
                UPDATE DATA.T_VTAS_PEDIDOS_CAB
                   SET ADAIA_ESTADO = 'ERROR',
                       ADAIA_MENSAJE = SUBSTR(V_ADAIA_ERROR, 1, 4000)
                 WHERE IDPEDIDO = P_IDPEDIDO
                   AND NVL(ADAIA_ESTADO, 'X') <> 'ENVIADO';
                COMMIT;
                RAISE;
        END;

        P_EXITO := 1;
        P_MENSAJE := 'Pedido SAP creado. DocEntry ' || V_DOCENTRY || ', DocNum ' || NVL(TO_CHAR(V_DOCNUM), 'S/N') || '. ADAIA OK.';

        BEGIN
            DATA.PK_SAP_COMMONS.SP_LOGOUT(V_CAB.COMPANIA, V_SESSION_ID, V_ROUTE_ID, V_LOGIN_RESPUESTA);
        EXCEPTION
            WHEN OTHERS THEN
                NULL;
        END;
    EXCEPTION
        WHEN OTHERS THEN
            BEGIN
                IF V_SESSION_ID IS NOT NULL THEN
                    DATA.PK_SAP_COMMONS.SP_LOGOUT(V_CAB.COMPANIA, V_SESSION_ID, V_ROUTE_ID, V_LOGIN_RESPUESTA);
                END IF;
            EXCEPTION
                WHEN OTHERS THEN
                    NULL;
            END;

            IF P_MENSAJE IS NULL THEN
                P_MENSAJE := SQLERRM;
            END IF;
            P_EXITO := 0;
            RAISE;
    END SP_CREAR_PEDIDO;

END PK_SAP_VENTAS_WS;
/
/

