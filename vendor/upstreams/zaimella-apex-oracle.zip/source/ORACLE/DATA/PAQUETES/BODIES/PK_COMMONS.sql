﻿  CREATE OR REPLACE PACKAGE BODY             PK_COMMONS as

	v_clave raw(255) := utl_raw.cast_to_raw('6c4d0e9ca53078a392e372b6465c72c148d1e7fd');
	v_aux_num   number;
	v_aux_txt   varchar2(100);
	v_aux_tx1   varchar2(4000);
	v_aux_tx2	varchar2(4000);
	v_aux_tx3	varchar2(4000);
	v_aux_dte   date;

	/*---- Funciones ----*/
	function f_add_wdays(p_fecha date,p_dias number default 0) return date is
	begin
		v_aux_num := 0;	-- contador
		v_aux_dte := p_fecha;

		while v_aux_num < abs(p_dias) loop
			if p_dias > 0 then
				v_aux_dte := v_aux_dte + 1; -- Sumar un dÃ­a
			else
				v_aux_dte := v_aux_dte - 1; -- Restar un dÃ­a
			end if;

			-- Verificar si es sÃ¡bado o domingo
			if to_char(v_aux_dte, 'D') in (6,7) then
				continue; -- Si es sÃ¡bado o domingo, omitir y seguir con el siguiente dÃ­a
			else
				v_aux_num := v_aux_num + 1; -- Aumentar el contador solo si no es fin de semana
			end if;		
		end loop;

		return v_aux_dte;
	end;

	function f_esbisiesto (p_anno in number) return number
	as
	v_numero 	number;
	v_anno		number;
	begin
		if p_anno < 0 then
			return -1;
		else
			select to_char(last_day(to_date('0102'||p_anno,'ddmmyyyy')),'dd') into v_numero from dual;
			if v_numero = 29 then return 1; else return 0; end if;
		end if;
	end;

	function f_mesespanol (p_mes in varchar2) return varchar2
	as
	v_texto	varchar2(100);
	begin
		v_texto := p_mes;
		v_texto := replace(v_texto,'january','enero');			v_texto := replace(v_texto,'January','Enero');			v_texto := replace(v_texto,'jan','ene');
		v_texto := replace(v_texto,'february','febrero');		v_texto := replace(v_texto,'February','Febrero');
		v_texto := replace(v_texto,'march','marzo');			v_texto := replace(v_texto,'March','Marzo');
		v_texto := replace(v_texto,'april','abril');			v_texto := replace(v_texto,'April','Abril');			v_texto := replace(v_texto,'apr','abr');
		v_texto := replace(v_texto,'may','mayo');				v_texto := replace(v_texto,'May','Mayo');
		v_texto := replace(v_texto,'june','junio');				v_texto := replace(v_texto,'June','Junio');
		v_texto := replace(v_texto,'july','julio');				v_texto := replace(v_texto,'July','Julio');
		v_texto := replace(v_texto,'august','agosto');			v_texto := replace(v_texto,'August','Agosto');			v_texto := replace(v_texto,'aug','ago');
		v_texto := replace(v_texto,'september','septiembre');	v_texto := replace(v_texto,'September','Septiembre');
		v_texto := replace(v_texto,'october','octubre');		v_texto := replace(v_texto,'October','Octubre');
		v_texto := replace(v_texto,'november','noviembre');		v_texto := replace(v_texto,'November','Noviembre');
		v_texto := replace(v_texto,'december','diciembre');		v_texto := replace(v_texto,'December','Diciembre');		v_texto := replace(v_texto,'dec','dic');

		return v_texto;
	end;

	function f_esnumero (p_valor in varchar2) return number as
	v_numero	number;
	begin
		v_numero := to_number(replace(p_valor,'.',','));

		if v_numero is null then
			return 0;
		else
			return 1;
		end if;

		exception when others then return -1;
	end;

	function f_esfecha (p_valor in varchar2) return number as
	v_fecha		date;
	begin
		v_fecha := to_date(p_valor,'dd/mm/yyyy');
		return 1;

		exception when others then return -1;
	end;

	function f_jde2g(p_fecha in number) return date as
	begin
		if p_fecha = 0 or p_fecha is null then
			return null;
		else
			return to_date(p_fecha + 1900000,'yyyyddd');
		end if;
	end;

	function f_g2jde(p_fecha in date) return number as
	begin
		if p_fecha is null then
			return 0;
		else
			return to_number(to_char(p_fecha,'yyyyddd')) - 1900000;
		end if;
	end;

	function f_escorreo(p_correo in varchar2) return number as
	v_valida boolean;
	begin
		v_valida := regexp_like(p_correo,'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$');

		if v_valida then
			return 1;
		else
			return 0;
		end if;
	end;

 /*
	Funcion que obtiene secuencia numerica. Ejemplo de uso:
	SELECT PK_COMMONS.F_SECUENCIA('T_MODULO_TABLA') FROM DUAL;

	@param P_KEY	nombre de tabla.
*/
	function f_secuencia(p_key in varchar) return number is pragma autonomous_transaction;
	v_contador number;
	begin  
		sp_secuencia (p_key,v_contador);
		commit;
      		return v_contador;
	end f_secuencia;

 /*
	Funcion que obtiene el periodo (bimestre,trimestre,semestre) de una fecha.

	@param P_KEY	nombre de tabla.
*/ 

	function f_periodo		(p_tipo in varchar2,p_fecha in date) 	return varchar2
	as
	v_periodo 	varchar2(7);
	v_tipo		varchar2(9);
	begin
		v_tipo := upper(p_tipo);
		if v_tipo in ('B','T','S') and p_fecha is not null then
			select to_char(p_fecha,'yyyy')||'-'||v_tipo||ceil(to_number(to_char(p_fecha,'mm'))/decode(v_tipo,'B',2,'T',3,'S',6)) into v_periodo from dual;
			return v_periodo;
		else
			return null;
		end if;
	end;

	function f_clob2blob (p_clob in clob) return blob
	is
	v_blob blob;
	v_offset 		number default 1;
	v_amount 		number default 4096;
	v_offsetwrite 	number default 1;
	v_amountwrite 	number;
	v_buffer 		varchar2(4096 CHAR);
	begin
		dbms_lob.createtemporary(v_blob, true);
		begin
			loop
				dbms_lob.read(
					lob_loc => p_clob,
					amount  => v_amount,
					offset  => v_offset,
					buffer  => v_buffer
				);

				v_amountwrite := utl_raw.length (r => utl_raw.cast_to_raw(c => v_buffer));

				dbms_lob.write (
					lob_loc => v_blob,
					amount  => v_amountwrite,
					offset  => v_offsetwrite,
					buffer  => utl_raw.cast_to_raw(v_buffer)
				);

				v_offsetwrite := v_offsetwrite + v_amountwrite;

				v_offset := v_offset + v_amount;
				v_amount := 4096;
			end loop;

			exception when no_data_found then null;
		end;
		return v_blob;
	end f_clob2blob;

	function f_dividirtexto(p_cadena varchar2,p_delimitador char) return split2col_tv_t
	AS 
		v_ret split2col_tv_t;
		cursor cadena_cursor
			is 
				SELECT LEVEL AS id
						,REGEXP_SUBSTR(P_CADENA, '[^'||P_DELIMITADOR||']+', 1, LEVEL) AS data 
				FROM dual
				CONNECT BY REGEXP_SUBSTR(P_CADENA, '[^'||P_DELIMITADOR||']+', 1, LEVEL) IS NOT NULL;
	BEGIN 
		v_ret:=split2col_tv_t();
		for cadena_record
		in cadena_cursor
		loop
			v_ret.extend;
			v_ret(v_ret.count):=split2col_rv_t(cadena_record.id,cadena_record.data);
		end loop;
		return v_ret;
	END f_dividirtexto;

	function f_dividirtextov2(p_cadena clob,p_delimitador char) return split2col_tc_t
	AS 
		v_ret split2col_tc_t;
		cursor cadena_cursor
			is 
				SELECT	LEVEL AS id
						,REGEXP_SUBSTR(DBMS_LOB.SUBSTR(P_CADENA, 4000), '[^'||P_DELIMITADOR||']+', 1, LEVEL) AS data 
				FROM dual
				CONNECT BY REGEXP_SUBSTR(DBMS_LOB.SUBSTR(P_CADENA, 4000), '[^'||P_DELIMITADOR||']+', 1, LEVEL) IS NOT NULL;
	BEGIN 
		v_ret:=split2col_tc_t();
		for cadena_record
		in cadena_cursor
		loop
			v_ret.extend;
			v_ret(v_ret.count):=split2col_rc_t(cadena_record.id,cadena_record.data);
		end loop;
		return v_ret;
	END f_dividirtextov2;

	/*
	** PropÃ³sito:	convertir una cadena en filas y columnas 
	** ParÃ¡metros:	
	**  p_cadena	varchar2:	parametro de entrada cadena  con los datos necesarios para ser convetida
	**  p_delimitadorcolumna char:  parametro de entrada delimitador de columna puede ser un caracter especial pipe"|"
	**  p_delimitadorfila char: parametro de entrada delimitador de fila puede ser un caracter especial punto y coma";"
	*/--split2tab_tc_t as table of split2tab_rc_t;
function f_split2table(p_cadena in varchar2,p_delimitadorcolumna char,p_delimitadorfila char) return split2tab_tv_t as
    v_ret split2tab_tv_t;
	v_campo1	varchar2(3999);
	v_campo2	varchar2(3999);
	v_campo3	varchar2(3999);
	v_campo4	varchar2(3999);
	v_campo5	varchar2(3999);
	v_campo6	varchar2(3999);
	v_campo7	varchar2(3999);
	v_campo8	varchar2(3999);
	v_campo9	varchar2(3999);
	v_campo10	varchar2(3999);
	BEGIN
		v_ret  := split2tab_tv_t();
		FOR SPL IN (SELECT LEVEL AS id
						,REGEXP_SUBSTR(p_cadena, '[^'||p_delimitadorfila||']+', 1, LEVEL) AS ITEM 
				FROM dual
				CONNECT BY REGEXP_SUBSTR(p_cadena, '[^'||p_delimitadorfila||']+', 1, LEVEL) IS NOT NULL
                )
		LOOP
 			begin select ITEM into v_campo1  from table(pk_commons.f_dividirtextoV2(SPL.ITEM,p_delimitadorcolumna)) where id=1;  exception when others then v_campo1 :=''; end;
			begin select ITEM into v_campo2  from table(pk_commons.f_dividirtextoV2(SPL.ITEM,p_delimitadorcolumna)) where id=2;  exception when others then v_campo2 :=''; end;
			begin select ITEM into v_campo3  from table(pk_commons.f_dividirtextoV2(SPL.ITEM,p_delimitadorcolumna)) where id=3;  exception when others then v_campo3 :=''; end;
			begin select ITEM into v_campo4  from table(pk_commons.f_dividirtextoV2(SPL.ITEM,p_delimitadorcolumna)) where id=4;  exception when others then v_campo4 :=''; end;
			begin select ITEM into v_campo5  from table(pk_commons.f_dividirtextoV2(SPL.ITEM,p_delimitadorcolumna)) where id=5;  exception when others then v_campo5 :=''; end;
			begin select ITEM into v_campo6  from table(pk_commons.f_dividirtextoV2(SPL.ITEM,p_delimitadorcolumna)) where id=6;  exception when others then v_campo6 :=''; end;
			begin select ITEM into v_campo7  from table(pk_commons.f_dividirtextoV2(SPL.ITEM,p_delimitadorcolumna)) where id=7;  exception when others then v_campo7 :=''; end;
			begin select ITEM into v_campo8  from table(pk_commons.f_dividirtextoV2(SPL.ITEM,p_delimitadorcolumna)) where id=8;  exception when others then v_campo8 :=''; end;
			begin select ITEM into v_campo9  from table(pk_commons.f_dividirtextoV2(SPL.ITEM,p_delimitadorcolumna)) where id=9;  exception when others then v_campo9 :=''; end;
			begin select ITEM into v_campo10 from table(pk_commons.f_dividirtextoV2(SPL.ITEM,p_delimitadorcolumna)) where id=10; exception when others then v_campo10:=''; end;
			v_ret.extend; v_ret(v_ret.count) := split2tab_rv_t(SPL.id,v_campo1,v_campo2,v_campo3,v_campo4,v_campo5,v_campo6,v_campo7,v_campo8,v_campo9,v_campo10 );
		END LOOP;
		return v_ret;
	END;
	function f_split2tablev2(p_cadena in clob,p_delimitadorcolumna char,p_delimitadorfila char) return split2tab_tc_t as
			v_ret split2tab_tc_t;
			v_campo1  clob;
			v_campo2  clob;
			v_campo3  clob;
			v_campo4  clob;
			v_campo5  clob;
			v_campo6  clob;
			v_campo7  clob;
			v_campo8  clob;
			v_campo9  clob;
			v_campo10 clob;
	BEGIN
		v_ret  := split2tab_tc_t();
		FOR SPL IN (select id, ITEM from table(pk_commons.f_dividirtextov2(P_CADENA,P_DELIMITADORFILA))where item is not null)
		LOOP
			begin select ITEM into v_campo1  from table(pk_commons.f_dividirtextov2(SPL.ITEM,P_DELIMITADORCOLUMNA)) where id=1;  exception when others then v_campo1 :=''; end;
			begin select ITEM into v_campo2  from table(pk_commons.f_dividirtextov2(SPL.ITEM,P_DELIMITADORCOLUMNA)) where id=2;  exception when others then v_campo2 :=''; end;
			begin select ITEM into v_campo3  from table(pk_commons.f_dividirtextov2(SPL.ITEM,P_DELIMITADORCOLUMNA)) where id=3;  exception when others then v_campo3 :=''; end;
			begin select ITEM into v_campo4  from table(pk_commons.f_dividirtextov2(SPL.ITEM,P_DELIMITADORCOLUMNA)) where id=4;  exception when others then v_campo4 :=''; end;
			begin select ITEM into v_campo5  from table(pk_commons.f_dividirtextov2(SPL.ITEM,P_DELIMITADORCOLUMNA)) where id=5;  exception when others then v_campo5 :=''; end;
			begin select ITEM into v_campo6  from table(pk_commons.f_dividirtextov2(SPL.ITEM,P_DELIMITADORCOLUMNA)) where id=6;  exception when others then v_campo6 :=''; end;
			begin select ITEM into v_campo7  from table(pk_commons.f_dividirtextov2(SPL.ITEM,P_DELIMITADORCOLUMNA)) where id=7;  exception when others then v_campo7 :=''; end;
			begin select ITEM into v_campo8  from table(pk_commons.f_dividirtextov2(SPL.ITEM,P_DELIMITADORCOLUMNA)) where id=8;  exception when others then v_campo8 :=''; end;
			begin select ITEM into v_campo9  from table(pk_commons.f_dividirtextov2(SPL.ITEM,P_DELIMITADORCOLUMNA)) where id=9;  exception when others then v_campo9 :=''; end;
			begin select ITEM into v_campo10 from table(pk_commons.f_dividirtextov2(SPL.ITEM,P_DELIMITADORCOLUMNA)) where id=10; exception when others then v_campo10:=''; end;
			v_ret.extend; v_ret(v_ret.count) := split2tab_rc_t(SPL.id,v_campo1,v_campo2,v_campo3,v_campo4,v_campo5,v_campo6,v_campo7,v_campo8,v_campo9,v_campo10 );
		END LOOP;
		return v_ret;
	END;

	 FUNCTION f_split_cadena_tabla (
		p_cadena             CLOB,
		p_delimitadorcolumna CHAR := '#',
		p_delimitadorfila    CHAR := 'Â¬'
	) return t_tabla_dato_split pipelined
	AS
		v_fila      VARCHAR2(32767);
		v_pos       PLS_INTEGER := 1;
		v_num       VARCHAR2(50);
		v_desc      CLOB;
		v_codigo    VARCHAR2(100);
		v_index     PLS_INTEGER := 1;
	BEGIN
		LOOP
			-- Extrae cada fila usando el delimitador de fila
			v_fila := REGEXP_SUBSTR(p_cadena, '[^' || p_delimitadorfila || ']+', 1, v_index);
			EXIT WHEN v_fila IS NULL;
	
			-- Extrae columnas separadas por el delimitador de columna
			v_num    := TRIM(REGEXP_SUBSTR(v_fila, '[^' || p_delimitadorcolumna || ']+', 1, 1));
			v_desc   := TRIM(REGEXP_SUBSTR(v_fila, '[^' || p_delimitadorcolumna || ']+', 1, 2));
			v_codigo := TRIM(REGEXP_SUBSTR(v_fila, '[^' || p_delimitadorcolumna || ']+', 1, 3));
	
			-- Emitir fila como registro
			IF (v_desc IS NOT NULL)THEN
			PIPE ROW(t_dato_split(v_num, v_desc, v_codigo));
			END IF;
			v_index := v_index + 1;
		END LOOP;
	
		RETURN;
	END f_split_cadena_tabla;

	function f_esdesarrollador(p_usuario varchar2) return number as
	begin
		select case when count(1) > 0 then 1 else 0 end into v_aux_num
		from data.t_corp_udc where id_cabecera = 'DEVELOPER' and upper(id_tabla) = upper(p_usuario);

		return v_aux_num;
	end;

	function f_nombreusuario (p_usuario in varchar2) return varchar2 is
	begin
		begin
			select trim(nombres)||' '||trim(apellidos) into v_aux_tx1
			from data.vt_corp_usuario where nombreusuario = upper(p_usuario);

			exception when others then v_aux_tx1 := null;
		end;

		return v_aux_tx1;
	end f_nombreusuario;

	function f_correousuario (p_usuario in varchar2) return varchar2 is
	begin
		begin
			select email into v_aux_tx1
			from vt_corp_usuario
			where 1 = 1
				and nombreusuario = upper(p_usuario)
				and pk_commons.f_escorreo(email) = 1;

			exception when others then v_aux_tx1 := null;
		end;

		return v_aux_tx1;
	end f_correousuario;
 /*
	SP que obtiene secuencia numerica. Ejemplo de uso:
	PK_COMMONS.SP_SECUENCIA ('T_MODULO_TABLA', V_CODIGO);

	@param P_KEY		nombre de tabla.
	@param P_CONTADOR	Contador secuencial.
*/
	procedure sp_secuencia (p_key in varchar,p_contador out number) as pragma autonomous_transaction;
	begin  
		select nextvalue + 1 into p_contador from t_secuencia where key = p_key for update;
		update t_secuencia set nextvalue = p_contador where key = p_key;
        commit;

		exception
			when no_data_found then
				insert into t_secuencia (key, nextvalue) values (p_key, 1);
				select 1 into p_contador from t_secuencia where key = p_key;
                commit;
	end sp_secuencia;

	function f_enlacearchivo (p_numeroarchivo in number) return varchar2 is
	v_enlace	varchar2(1000);
	begin
		/*
		return 'f?p='||APEX_APPLICATION.g_flow_id||':0:'||APEX_APPLICATION.g_instance||':APPLICATION_PROCESS=pk_commons.sp_servirarchivo:::P_NUMEROARCHIVO:'||p_numeroarchivo;
		return 'f?p='||APEX_APPLICATION.g_flow_id||
				':0:'||APEX_APPLICATION.g_instance||
				':pk_commons.sp_servirarchivo:'||p_numeroarchivo;
		*/
		return	'f?p='	|| 100							|| -- 'f?p='	|| APEX_APPLICATION.g_flow_id	|| 
				':402:' || APEX_APPLICATION.g_instance	|| 
				'::NO::P402_NUMEROARCHIVO:'				|| p_numeroarchivo;
	end f_enlacearchivo;

	function f_googledocview (p_numeroarchivo in number, p_mimetype in varchar2) return varchar2 is
	v_puerto varchar2(10) := '8090';
	v_enlace varchar2(4000);
	v_mimetype varchar2(1000);
	begin
		v_mimetype := lower(p_mimetype);

		if pk_corp_commons.f_isproduccion then
			v_puerto := '8080';
		end if;

		return f_enlacearchivo(p_numeroarchivo);
/*
		if v_mimetype in (
			'application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document',
			'application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') then
		
			return	'https://docs.google.com/gview?url=' ||
					'http://sistemas.zaimella.com/' || v_puerto ||
					'/apex/'||pk_commons.f_enlacearchivo(p_numeroarchivo) || '&embedded=true';
		else
			return f_enlacearchivo(p_numeroarchivo);
		end if;
*/
	end f_googledocview;

    function f_coloralerta (p_identificador in varchar2) return varchar2 as
    v_color varchar2(25);
    begin
        select valor2 into v_color
        from t_corp_udc
        where 1 = 1
            and id_cabecera = 'APEX'
            and id_tabla = 'COLOR_ALERTA'
            and valor = p_identificador
            and rownum = 1;
        return v_color;

        exception when others then return null;        
    end f_coloralerta;

    function f_espacios (p_texto in varchar2, p_posicion in varchar2, p_cantidad in number) return varchar2 is
    begin
        v_aux_txt := trim(p_texto);
        v_aux_num := p_cantidad;

        if length(v_aux_txt) > 250 then
            return v_aux_txt;
        end if;

        if v_aux_num > 0 and (v_aux_txt is null or v_aux_txt = '') then
            return lpad(' ',v_aux_num,' ');
        end if;

        if p_posicion = 'I' then
            return lpad(v_aux_txt,v_aux_num,' ');
        elsif p_posicion = 'D' then
            return rpad(v_aux_txt,v_aux_num,' ');
        end if;
    end;

/*
	SP para el envio de correo electronicos, si se desea notificar a mas de un correo electronico,
	se debe separar por comas Ejemplo: jaltamirano@zaimella.com, dcueva@zaimella.com.
	V_AMBIENTEPRODUCCION ES UNA BANDERA QUE INDICA SI AMBIENTE DE PRODUCCION 1(sI)/0(nO)

	@param p_to	correo(s) a notificar.
	@param p_from	correo remitente.
	@param p_subject  asunto.
	@param p_body  contenido del correo.
*/	
	procedure sp_enviarcorreo(p_to in varchar2, p_from in varchar2 , p_subject in varchar2, p_body in  clob) as
	l_boundary	varchar2(100);
	l_mail_conn	UTL_SMTP.connection;
	p_smtp_port  number;
	p_smtp_host  varchar2(20); 
	V_AMBIENTEPRODUCCION  number :=1;
	v_cur_pos number:=1;
	V_LEN number:=0;
	V_BODY	clob;
	nls_charset	varchar2(255);
	cursor cur_correos (var_correos varchar2) is
	select substr (','||var_correos||',',
	instr (','||var_correos||',',',', 1, rownum )+1,
	instr (','||var_correos||',',',', 1, rownum +1) - instr(','||var_correos||',', ',', 1, rownum)-1  ) res
	from ( select ','||var_correos||',' palabras from dual)
	connect by rownum < (length(','||var_correos||',') - length(replace(','||var_correos||',',',','')))
	and prior dbms_random.random is not null;

	ErrorU exception;
	PRAGMA EXCEPTION_INIT (ErrorU,-29279);

	var_correos varchar2(500);

	procedure process_recipients
	(p_mail_conn in out utl_smtp.connection,p_list	in	varchar2)as
	l_tab string_api.t_split_array;	

	begin

	if trim(p_list) is not null then
		l_tab := string_api.split_text(p_list);
		for i in 1 .. l_tab.count loop
			utl_smtp.rcpt(p_mail_conn, trim(l_tab(i)));
		end loop;
	end if;
	end process_recipients;

	begin
		p_smtp_port:= 587;
		p_smtp_host:='192.168.5.12';
		l_boundary:='----=*#abc1234321cba#*=';
		-- get characterset
		select value into nls_charset from nls_database_parameters where parameter = 'NLS_CHARACTERSET';
		l_mail_conn := utl_smtp.open_connection(p_smtp_host, p_smtp_port);
		UTL_SMTP.helo(l_mail_conn, p_smtp_host);
		--UTL_SMTP.ehlo(l_mail_conn, 'zaimella.com');
		--UTL_SMTP.command(l_mail_conn, 'AUTH LOGIN');  
		--utl_smtp.command(l_mail_conn,utl_encode.text_encode('mail', nls_charset, 1));
		--utl_smtp.command(l_mail_conn, utl_encode.text_encode('Relay2014', nls_charset, 1));
		UTL_SMTP.mail(l_mail_conn, p_from);

		IF(V_AMBIENTEPRODUCCION=1) then
			FOR ECUR_CORREOS IN CUR_CORREOS(TRIM(p_to)) LOOP  
			UTL_SMTP.rcpt(l_mail_conn, ECUR_CORREOS.RES);
			end LOOP;
		end IF;

		V_BODY:=P_BODY;
		IF(V_AMBIENTEPRODUCCION=1) then
			process_recipients(l_mail_conn, p_to);
			UTL_SMTP.open_data(l_mail_conn);
			UTL_SMTP.write_data(l_mail_conn, 'To: ' || p_to || UTL_TCP.crlf);
		else
			process_recipients(l_mail_conn, 'pruebas.zaimella@gmail.com');
			UTL_SMTP.open_data(l_mail_conn);
			UTL_SMTP.write_data(l_mail_conn, 'To: ' || 'pruebas.zaimella@gmail.com' || UTL_TCP.crlf);
		end IF; 

		utl_smtp.write_data(l_mail_conn, 'From: ' || p_from || utl_tcp.crlf);
		UTL_SMTP.write_data(l_mail_conn, 'Subject: ' || p_subject || UTL_TCP.crlf);
		UTL_SMTP.write_data(l_mail_conn, 'Reply-To: ' || p_from || UTL_TCP.crlf);
		UTL_SMTP.write_data(l_mail_conn, 'MIME-Version: 1.0' || UTL_TCP.crlf);
		UTL_SMTP.write_data(l_mail_conn, 'Content-Type: multipart/alternative; boundary="' || l_boundary || '"' || UTL_TCP.crlf || UTL_TCP.crlf);

	IF V_BODY IS NOT NULL THEN
		UTL_SMTP.write_data(l_mail_conn, '--' || l_boundary || UTL_TCP.crlf);
		UTL_SMTP.write_data(l_mail_conn, 'Content-Type: text/html; charset="iso-8859-1"' || UTL_TCP.crlf || UTL_TCP.crlf);
		V_LEN := DBMS_LOB.getlength(V_BODY);

		while v_cur_pos <= V_LEN  loop
			UTL_SMTP.WRITE_DATA(l_mail_conn, DBMS_LOB.SUBSTR(V_BODY,32000,v_cur_pos));
			--UTL_SMTP.write_data(l_mail_conn, V_BODY);
			v_cur_pos:=v_cur_pos+32000;
		end loop;

		UTL_SMTP.write_data(l_mail_conn, UTL_TCP.crlf || UTL_TCP.crlf);
	end IF;

	UTL_SMTP.write_data(l_mail_conn, '--' || l_boundary || '--' || UTL_TCP.crlf);
	utl_smtp.close_data(l_mail_conn);

	utl_smtp.quit(l_mail_conn);
	end sp_enviarcorreo;

/*
	El procedimiento permite guardar los pasos de una transacciÃ³n. No tiene COMMIT en caso de que la transacciÃ³n utilice tablas globales.
	@param p_aplicacion		Nombre de la aplicaciÃ³n o procedimiento. Permite buscar en la tabla de log.
	@param p_paso			NÃºmero de paso del log.
	@param p_descripcion	DescripciÃ³n de lo que estÃ¡ haciendo en el paso.
	@param p_mensaje		Mensaje que quiere visualizar.
	@param p_observacion	ObservaciÃ³n que quiere visualizar.
	@param p_query			Sentencia SQL si se trata de una sentencia que fue construida.
	@author Diego AndrÃ©s de la Cruz Sandoval
*/
	procedure sp_apex_log
	(	
		p_aplicacion	in varchar,
		p_paso 			in number,
		p_descripcion 	in varchar,
		p_mensaje		in varchar2,
		p_observacion	in varchar2,
		p_query			in clob
	) as pragma autonomous_transaction;
	begin
		insert into t_apex_log (aplicacion,instancia,paso,descripcion,mensaje,observacion,query)
		values (substr(p_aplicacion,1,100),'PROCEDIMIENTO',p_paso,substr(p_descripcion,1,4000),substr(p_mensaje,1,4000),substr(p_observacion,1,4000),p_query);
		commit;
	end;

/*
	El procedimiento permite guardar las excepciones lanzadas en los procesos.
	@param p_aplicacion		Nombre de la aplicaciÃ³n o procedimiento. Permite buscar en la tabla de log.
	@param p_paso			NÃºmero de paso del log.
	@param p_descripcion	DescripciÃ³n de lo que estÃ¡ haciendo en el paso.
	@param p_codexcepcion	CÃ³digo de la ExepciÃ³n
	@param p_mensaje		Mensaje excepciÃ³n
	@param p_observacion	ObservaciÃ³n que quiere visualizar.
	@param p_query			Sentencia SQL si se trata de una sentencia que fue construida.
	@author Diego AndrÃ©s de la Cruz Sandoval
*/
	procedure sp_apex_excepciones
	(
		p_aplicacion 	in varchar2,
		p_paso 			in number,
		p_descripcion 	in varchar2,
		p_codexcepcion 	in number,
		p_mensaje 		in varchar2,
		p_observacion 	in varchar2,
		p_correo 		in varchar2,
		p_query 		in clob
	) as pragma autonomous_transaction;
	begin
		begin
			insert into t_apex_log (aplicacion,instancia,paso,descripcion,codexcepcion,mensaje,observacion,correo,query)
			values (p_aplicacion,'EXCEPCIÃ“N',p_paso,p_descripcion,p_codexcepcion,p_mensaje,p_observacion,p_correo,p_query);
			commit;
		end;

		if p_correo is not null then
			declare
			v_cor_ocul varchar2(100) := 'pruebas.zaimella@gmail.com';
			v_cor_remi varchar2(100) := 'excepciones@zaimella.com';
			v_cor_subj varchar2(250) := 'ExcepciÃ³n lanzada en ';
			v_cor_tiem timestamp := sysdate;
			v_cor_cont clob;
			v_cor_tabl clob;
			begin
				v_cor_cont := '<html>
				<head>
					<style type="text/css">body{font-family: Arial, Helvetica, sans-serif;font-size:10pt;margin:30px;background-color:#ffffff;}
						span.sig{font-style:italic;font-weight:bold;color:#811919;}
					</style>
				</head>
				<meta charset="UTF-8">
				<body>'||utl_tcp.crlf;
				v_cor_cont := v_cor_cont ||'<p>Excepcion lanzada a las <strong>'||to_char(v_cor_tiem,'dd/mm/yyyy hh24:mi:ss')||'</strong>.</p>'||utl_tcp.crlf;

				v_cor_tabl := '<table style="width:auto;padding: 0px 0px !important; text-align: left; font-size: small; border-collapse: collapse;white-space:nowrap;">'||utl_tcp.crlf;
				v_cor_tabl := v_cor_tabl||'<tr>'||utl_tcp.crlf;
				v_cor_tabl := v_cor_tabl||'<th style="padding: 3px 6px 3px 6px !important; border: 1px solid #bbbbbb !important;">Concepto</th>'||utl_tcp.crlf;
				v_cor_tabl := v_cor_tabl||'<th style="padding: 3px 6px 3px 6px !important; border: 1px solid #bbbbbb !important;">Descripcion</th>'||utl_tcp.crlf;
				v_cor_tabl := v_cor_tabl||'</tr>'||utl_tcp.crlf;

				if p_aplicacion is not null then
					v_cor_tabl := v_cor_tabl||'<tr>'||utl_tcp.crlf;
					v_cor_tabl := v_cor_tabl||'<td style="padding: 3px 6px 3px 6px !important; border: 1px solid #bbbbbb !important;">Aplicacion</td>'||utl_tcp.crlf;
					v_cor_tabl := v_cor_tabl||'<td style="padding: 3px 6px 3px 6px !important; border: 1px solid #bbbbbb !important;">'||p_aplicacion||'</td>'||utl_tcp.crlf;
					v_cor_tabl := v_cor_tabl||'</tr>'||utl_tcp.crlf;
				end if;

				if p_paso is not null then
					v_cor_tabl := v_cor_tabl||'<tr>'||utl_tcp.crlf;
					v_cor_tabl := v_cor_tabl||'<td style="padding: 3px 6px 3px 6px !important; border: 1px solid #bbbbbb !important;">Paso</td>'||utl_tcp.crlf;
					v_cor_tabl := v_cor_tabl||'<td style="padding: 3px 6px 3px 6px !important; border: 1px solid #bbbbbb !important;">'||p_paso||'</td>'||utl_tcp.crlf;
					v_cor_tabl := v_cor_tabl||'</tr>'||utl_tcp.crlf;
				end if;

				if p_descripcion is not null then
					v_cor_tabl := v_cor_tabl||'<tr>'||utl_tcp.crlf;
					v_cor_tabl := v_cor_tabl||'<td style="padding: 3px 6px 3px 6px !important; border: 1px solid #bbbbbb !important;">Descripcion</td>'||utl_tcp.crlf;
					v_cor_tabl := v_cor_tabl||'<td style="padding: 3px 6px 3px 6px !important; border: 1px solid #bbbbbb !important;">'||p_descripcion||'</td>'||utl_tcp.crlf;
					v_cor_tabl := v_cor_tabl||'</tr>'||utl_tcp.crlf;
				end if;

				if p_codexcepcion is not null then
					v_cor_tabl := v_cor_tabl||'<tr>'||utl_tcp.crlf;
					v_cor_tabl := v_cor_tabl||'<td style="padding: 3px 6px 3px 6px !important; border: 1px solid #bbbbbb !important;">Codigo Error</td>'||utl_tcp.crlf;
					v_cor_tabl := v_cor_tabl||'<td style="padding: 3px 6px 3px 6px !important; border: 1px solid #bbbbbb !important;">'||p_codexcepcion||'</td>'||utl_tcp.crlf;
					v_cor_tabl := v_cor_tabl||'</tr>'||utl_tcp.crlf;
				end if;

				if p_mensaje is not null then
					v_cor_tabl := v_cor_tabl||'<tr>'||utl_tcp.crlf;
					v_cor_tabl := v_cor_tabl||'<td style="padding: 3px 6px 3px 6px !important; border: 1px solid #bbbbbb !important;">Descripcion Error</td>'||utl_tcp.crlf;
					v_cor_tabl := v_cor_tabl||'<td style="padding: 3px 6px 3px 6px !important; border: 1px solid #bbbbbb !important;">'||p_mensaje||'</td>'||utl_tcp.crlf;
					v_cor_tabl := v_cor_tabl||'</tr>'||utl_tcp.crlf;
				end if;

				if p_observacion is not null then
					v_cor_tabl := v_cor_tabl||'<tr>'||utl_tcp.crlf;
					v_cor_tabl := v_cor_tabl||'<td style="padding: 3px 6px 3px 6px !important; border: 1px solid #bbbbbb !important;">Observacion</td>'||utl_tcp.crlf;
					v_cor_tabl := v_cor_tabl||'<td style="padding: 3px 6px 3px 6px !important; border: 1px solid #bbbbbb !important;">'||p_observacion||'</td>'||utl_tcp.crlf;
					v_cor_tabl := v_cor_tabl||'</tr>'||utl_tcp.crlf;
				end if;

				v_cor_tabl := v_cor_tabl||'</table>'||utl_tcp.crlf;

				v_cor_cont := v_cor_cont||v_cor_tabl;
				v_cor_cont := v_cor_cont||'</body>'||utl_tcp.crlf;
				v_cor_cont := v_cor_cont||'</html>'||utl_tcp.crlf;

				v_cor_subj := v_cor_subj||p_aplicacion;

				pk_commons.sp_apex_correo(p_aplicacion,v_cor_remi,p_correo,null,v_cor_ocul,v_cor_subj,v_cor_cont);
			end;
		end if;
	end;
/*
	El procedimiento devuelve el URL de una imagen que puede ser usada en un correo electrÃ³nico, por ejemplo.
	@param p_imagen			URL de la imagen.
	@author Diego AndrÃ©s de la Cruz Sandoval
*/
	procedure sp_imagen (p_imagen out varchar2) as
	v_contador 	number;
	v_random	number;
	v_imagen	varchar2(500);
	begin
		v_imagen := null;
		select count(*) into v_contador from t_corp_udc where id_cabecera = '649';
		select round(dbms_random.value(1,v_contador),0) into v_random from dual;

		begin
			insert into t_tmp_a (num01,txt01)
			select rownum registro, a.valor from t_corp_udc a where a.id_cabecera = '649';

			select txt01 into v_imagen from t_tmp_a where num01 = v_random;
			p_imagen := v_imagen;
			commit;
		end;
	end sp_imagen;

/*
	El procedimiento recibe un string y donde encuentre un caracter especial lo codifica para que sea legible en los navegadores.
	@param	p_ingreso	String de entrada
	@param	p_salida	String de salida
	@author Diego AndrÃ©s de la Cruz Sandoval
*/

	procedure sp_apex_correohtml
	(
		p_ingreso 			in clob,
		p_salida 			out clob
	) as
	v_clb_aux clob;
	begin
		v_clb_aux := p_ingreso;
		-- NormalizaciÃ³n de caracteres especiales
		begin
			v_clb_aux := replace(v_clb_aux,'Á','&Aacute;');
			v_clb_aux := replace(v_clb_aux,'É','&Eacute;');
			v_clb_aux := replace(v_clb_aux,'Í','&Iacute;');
			v_clb_aux := replace(v_clb_aux,'Ó','&Oacute;');
			v_clb_aux := replace(v_clb_aux,'Ú','&Uacute;');

			v_clb_aux := replace(v_clb_aux,'á','&aacute;');
			v_clb_aux := replace(v_clb_aux,'é','&eacute;');
			v_clb_aux := replace(v_clb_aux,'í','&iacute;');
			v_clb_aux := replace(v_clb_aux,'ó','&oacute;');
			v_clb_aux := replace(v_clb_aux,'ú','&uacute;');

			v_clb_aux := replace(v_clb_aux,'Ñ','&Ntilde;');
			v_clb_aux := replace(v_clb_aux,'ñ','&ntilde;');

			v_clb_aux := replace(v_clb_aux, '“', '&ldquo;');
			v_clb_aux := replace(v_clb_aux, '”', '&rdquo;');
			v_clb_aux := replace(v_clb_aux, '‘', '&lsquo;');
			v_clb_aux := replace(v_clb_aux, '’', '&rsquo;');
			v_clb_aux := replace(v_clb_aux, '–', '&ndash;');
			v_clb_aux := replace(v_clb_aux, '—', '&mdash;');
			v_clb_aux := replace(v_clb_aux, '…', '&hellip;');

			v_clb_aux := replace(v_clb_aux, '©', '&copy;');
			v_clb_aux := replace(v_clb_aux, '®', '&reg;');
			v_clb_aux := replace(v_clb_aux, '€', '&euro;');

			v_clb_aux := replace(v_clb_aux, chr(160), ' ');
		end;
		p_salida := v_clb_aux;
	end sp_apex_correohtml;
/*
	El procedimiento ermite enviar un correo electrÃ³nico a un destinatario, enviar con copia y enviar una copia oculta.
	El proceso ademas guarda un historial de los correos enviados.
	@param	p_aplicacion		Nombre de la aplicaciÃ³n, se usa para buscar en el log.
	@param	p_remitente			Origen del correo electrÃ³nico.
	@param	p_para				Destinatario(s) principal(es).
	@param 	p_concopia 			Destinatario(s) secundario(s).
	@param 	p_concopiaoculta 	Destinatario(s) oculto(s).
	@param 	p_asunto			Asunto del correo.
	@param 	p_contenido			Contenido del correo.
	@author Diego AndrÃ©s de la Cruz Sandoval
*/
	procedure sp_apex_correo
	(
		p_aplicacion 		in varchar2,
		p_remitente			in varchar2,
		p_para				in varchar2,
		p_concopia			in varchar2,
		p_concopiaoculta	in varchar2,
		p_asunto			in varchar2,
		p_contenido			in clob
	) as
	v_limite		varchar2(100);
	v_conexion		utl_smtp.connection;
	v_smtp_puerto	number;
	v_smtp_host		varchar2(20);
	v_texto			varchar2(20) := null;
	v_inicio		number;
	v_longitud		number;
	nls_charset		varchar2(255);

	v_para				varchar2(1000);
	v_concopia			varchar2(1000);
	v_concopiaoculta	varchar2(1000);

	cursor correos (v_correos varchar2) is
		select 	substr(','||v_correos||',',
				instr(','||v_correos||',',',', 1,rownum) + 1,
				instr(','||v_correos||',',',', 1,rownum + 1) - instr(','||v_correos||',', ',', 1,rownum) - 1) res
		from (select ','||v_correos||',' palabras from dual)
		connect by rownum < (length(','||v_correos||',') - length(replace(','||v_correos||',',',','')))
		and prior dbms_random.random is not null;

	v_error 	exception;
	pragma 		exception_init(v_error,-29279);

	v_correos varchar2(1000);

	procedure proc_destino
	(
		p_conexion	in out utl_smtp.connection,
		p_lista		in varchar2
	) as
	v_destino string_api.t_split_array;
	begin
		if trim(p_lista) is not null then
			v_destino := string_api.split_text(p_lista);
			for i in 1..v_destino.count loop
				utl_smtp.rcpt(p_conexion,trim(v_destino(i)));
			end loop;
		end if;
	end;

	begin
		v_inicio		:= 1;
		v_longitud		:= 3999;
		v_limite		:= '----=*#abc1234321cba#*=';
		v_smtp_host		:= '192.168.5.12';
		v_smtp_puerto	:= 587;

		if pk_corp_commons.f_isproduccion then
			v_para				:= p_para;
			v_concopia			:= p_concopia;
			v_concopiaoculta	:= p_concopiaoculta;
        else
			v_para				:= 'test@zaimella.org';
			v_concopia			:= null;
			v_concopiaoculta	:= null;
        end if;

		v_conexion := utl_smtp.open_connection(v_smtp_host,v_smtp_puerto);

		-- get characterset
		select value
		into	nls_charset
		from	nls_database_parameters
		where  parameter = 'NLS_CHARACTERSET';

		utl_smtp.helo(v_conexion,v_smtp_host);
		--utl_smtp.ehlo(v_conexion, 'zaimella.com');
		--utl_smtp.command(v_conexion,'AUTH LOGIN');
		--utl_smtp.command(v_conexion,utl_encode.text_encode('mail',nls_charset,1));
		--utl_smtp.command(v_conexion,utl_encode.text_encode('Relay2014',nls_charset,1));
		utl_smtp.mail(v_conexion,p_remitente);

		for c in correos(trim(v_para)) loop  
			utl_smtp.rcpt(v_conexion,c.res);
		end loop;

		if v_concopia is not null then
			for c in correos(trim(v_concopia)) loop
				if c.res is not null and c.res <> ' ' then
				begin
					utl_smtp.rcpt(v_conexion,c.res);
					v_correos := c.res||','||v_correos;

					exception when v_error then rollback;
				end;
				end if;
			end loop;
		end if;

		proc_destino(v_conexion,v_para);
		proc_destino(v_conexion,v_concopia);
		proc_destino(v_conexion,v_concopiaoculta);

		utl_smtp.open_data(v_conexion);
		utl_smtp.write_data(v_conexion,'To: '||v_para||utl_tcp.crlf);

		if v_concopia is not null then
			utl_smtp.write_data(v_conexion,'Cc: '||v_correos||utl_tcp.crlf);
		end if;

		if trim(v_concopiaoculta) is not null then
			utl_smtp.write_data(v_conexion,'BCC: '||replace(v_concopiaoculta,',',';')||utl_tcp.crlf);
		end if;

		utl_smtp.write_data(v_conexion,'From: '||p_remitente||utl_tcp.crlf);
		utl_smtp.write_data(v_conexion,'Subject: '||p_asunto||utl_tcp.crlf);
		utl_smtp.write_data(v_conexion,'Reply-To: '||p_remitente||utl_tcp.crlf);
		utl_smtp.write_data(v_conexion,'MIME-Version: 1.0'||utl_tcp.crlf);
		utl_smtp.write_data(v_conexion,'Content-Type: multipart/alternative; boundary="'||v_limite||'"'||utl_tcp.crlf||utl_tcp.crlf);
		-- utl_smtp.write_data(v_conexion,'Content-Type: text/html; charset="iso-8859-1; boundary="'||v_limite||'"'||utl_tcp.crlf||utl_tcp.crlf);

		if v_texto is not null then
			utl_smtp.write_data(v_conexion,'--' || v_limite || utl_tcp.crlf);
			utl_smtp.write_data(v_conexion,'Content-Type: text/plain; charset="iso-8859-1"' || utl_tcp.crlf || utl_tcp.crlf);
			utl_smtp.write_data(v_conexion,v_texto);
			utl_smtp.write_data(v_conexion,utl_tcp.crlf||utl_tcp.crlf);
		end if;

		if p_contenido is not null then
			utl_smtp.write_data(v_conexion,'--' || v_limite || utl_tcp.crlf);
			utl_smtp.write_data(v_conexion,'Content-Type: text/html; charset="iso-8859-1"'||utl_tcp.crlf||utl_tcp.crlf);
			-----------------------------------------------------------------------------------------------------------------
			if length(p_contenido) > v_longitud then
				loop
					if (v_inicio + v_longitud) <= (length(p_contenido) + 1) then
						utl_smtp.write_data(v_conexion,substr(p_contenido,v_inicio,v_longitud));
					end if;
					v_inicio := v_inicio + v_longitud;
					exit when v_inicio + v_longitud > length(p_contenido);
				end loop;
				utl_smtp.write_data(v_conexion,substr(p_contenido,v_inicio,length(p_contenido) - v_inicio + 1));
			else
				utl_smtp.write_data(v_conexion,p_contenido);
			end if;
			-----------------------------------------------------------------------------------------------------------------
			utl_smtp.write_data(v_conexion,utl_tcp.crlf||utl_tcp.crlf);
		end if;

		utl_smtp.write_data(v_conexion,'--'||v_limite||'--'||utl_tcp.crlf);
		utl_smtp.close_data(v_conexion);

		utl_smtp.quit(v_conexion);

		insert into t_apex_logcorreo (proceso,aplicacion,remitente,para,concopia,concopiaoculta,asunto,contenido)
		values ('pk_commons.sp_apex_correo',p_aplicacion,p_remitente,v_para,v_concopia,v_concopiaoculta,p_asunto,null);
	end sp_apex_correo;

	-- Suma dÃ­as laborables a una fecha inicial.
	-- fechaInicial	: la fecha a la cual se le suman dÃ­as
	-- diasASumar	: dÃ­as a sumar
	-- diasLaborables : permitido Ãºnicamente 5, 6 o 7. 5=lunes-viernes, 6=lunes-s{abado, 7=lunes-domingo
	-- @author dcueva
	function f_sumadiaslaborables(fechaInicial timestamp, diasASumar number, diasLaborables number) return timestamp AS
	diasParaArrancar	number;
	counter				number := 0;
	fechaArranque		timestamp;
	fechaFinal			timestamp;
	diaSemana			char(1);
	begin
		if fechaInicial is not null and diasASumar is not null and diasLaborables is not null THEN
			diaSemana := to_char(fechaInicial, 'D');
			diasParaArrancar := case 
				when diasLaborables=5 and diaSemana='6' then 2
				when diasLaborables=5 and diaSemana='7' then 1
				when diasLaborables=6 and diaSemana='7' then 1
				else 0
			end;
			if diasParaArrancar  > 0 then
				fechaArranque := fechaInicial + diasParaArrancar *(interval '1' day);
			else
				fechaArranque := fechaInicial;
			end if;

			fechaFinal := fechaArranque;
			while (counter < diasASumar) loop
				fechaFinal := fechaFinal + (interval '1' day);
				diaSemana  := to_char(fechaFinal, 'D');
				if (diasLaborables = 5 and diaSemana = '6') or (diasLaborables = 5 and diaSemana = '7') or (diasLaborables = 6 and diaSemana = '7') then
					null;
				else
					counter := counter + 1;
				end if;
			end loop;
			return fechaFinal;
		else
			return fechaInicial;
		end if;
	end f_sumadiaslaborables;	


	-- Es el equivalete java  System.currentTimeMillis();
	-- @author dcueva
	function f_currenttimemillis
		return number
	AS
		currentTimeMillis  number;
	begin
			select extract(day from(sys_extract_utc(systimestamp) - to_timestamp('1970-01-01', 'YYYY-MM-DD'))) * 86400000 
				+ to_number(to_char(sys_extract_utc(systimestamp), 'SSSSSFF3'))
			into currentTimeMillis
			from dual;
			return currentTimeMillis;
	end f_currenttimemillis;

	function f_obtieneemail(p_nombreusuario in varchar) return varchar
	AS
		V_COUNT  number;
		V_EMAIL  varchar2(1000);
	begin
		V_EMAIL:=null;
		select count(*) INTO V_COUNT from VT_CORP_USUARIO where NOMBREUSUARIO=p_nombreusuario;
		IF V_COUNT>0 THEN
			select email INTO V_EMAIL from VT_CORP_USUARIO where NOMBREUSUARIO=p_nombreusuario;
		end IF;
		return V_EMAIL;
	end;
	function f_encrypt (p_texto in varchar2) return raw is
	v_texto			varchar2(32767) := p_texto;
	v_txt_enc 		raw(32767);
	begin
		v_texto := rpad( v_texto, (trunc(length(v_texto)/8)+1)*8, chr(0) );

		SELECT DBMS_CRYPTO.ENCRYPT
		(
			src => UTL_I18N.STRING_TO_RAW (v_texto, 'AL32UTF8'),
			typ => 4353,
			key => v_clave
		) 
		INTO v_txt_enc FROM DUAL;


		/*dbms_obfuscation_toolkit.desencrypt
			(
				input => utl_raw.cast_to_raw(v_texto),
				key => v_clave,
				encrypted_data => v_txt_enc
			);
		*/
		return v_txt_enc;
	end;

	function f_decrypt (p_txt_enc in raw) return varchar2 is
	v_desencriptado	varchar2(32767);
	v_txt_dnc		varchar2(32767);
	begin
		/*dbms_obfuscation_toolkit.desdecrypt
			(
				input => p_txt_enc,
				key => v_clave,
				decrypted_data => v_desencriptado
			);

		v_txt_dnc := utl_raw.cast_to_varchar2(v_desencriptado);

		return rtrim(v_txt_dnc,chr(0));
		*/ 
		select UTL_RAW.cast_to_varchar2(
		DBMS_CRYPTO.DECRYPT
		(
			src => p_txt_enc,
			typ => 4353,
			key => v_clave
		))	
		INTO v_txt_dnc FROM DUAL;

		-- return trim(v_txt_dnc);
		return rtrim(v_txt_dnc,chr(0));		
	end;

		procedure sp_apex_imagenbase64
	(
		p_idarchivo 	in number,
		p_tipoarchivo	out varchar2,
		p_codigo		out clob
	) as
	v_archivo blob;
	v_paso number;
	begin
		select BLOBCONTENT,MIMETYPE,12000 into v_archivo,p_tipoarchivo,v_paso from FILES.t_apex_archivos where NUMEROARCHIVO = p_idarchivo;

		for i in 0 .. trunc((dbms_lob.getlength(v_archivo) - 1 )/v_paso) loop
			p_codigo := p_codigo||utl_raw.cast_to_varchar2(utl_encode.base64_encode(dbms_lob.substr(v_archivo,v_paso,i*v_paso+1)));
		end loop;
	end;

	--  PL/SQL function to convert a BLOB to a CLOB
	function f_blob_to_clob (blob_in IN BLOB) return CLOB
	AS
		v_clob CLOB;
		v_varchar varchar2(32767);
		v_start PLS_INTEGER := 1;
		v_buffer PLS_INTEGER := 32767;
	begin
		DBMS_LOB.CREATETEMPORARY(v_clob, TRUE);

		FOR i IN 1..CEIL(DBMS_LOB.GETLENGTH(blob_in) / v_buffer)
		LOOP

			v_varchar := UTL_RAW.CAST_TO_VARCHAR2(DBMS_LOB.SUBSTR(blob_in, v_buffer, v_start));

			DBMS_LOB.WRITEAPPEND(v_clob, LENGTH(v_varchar), v_varchar);
			v_start := v_start + v_buffer;
		end LOOP;
		return v_clob;
	end f_blob_to_clob;

	--  PL/SQL function to convert a CLOB to a BLOB
	function f_clob_to_blob (clob_in IN CLOB) return BLOB
	AS
		v_blob		BLOB;
		dest_offset	integer;
		src_offset	integer;
		lang_context  integer;
		warning		varchar2(1000);
	begin
		-- set-up parms to convert to a BLOB:
		dbms_lob.createtemporary(v_blob, FALSE);
		dest_offset := 1;
		src_offset := 1;
		lang_context := 0;

		-- convert to a BLOB here:
		dbms_lob.converttoblob(
			v_blob, 
			clob_in,
			dbms_lob.getlength( clob_in ), 
			dest_offset, 
			src_offset, 
			0, 
			lang_context, 
			warning
		);
		return v_blob;
	end;

	function f_cedula_supervisor (p_cedula in varchar2) return varchar2 is
	v_cedula	varchar2(100);
	v_codsup	number;
	begin
		select id_supervisor into v_codsup from evolution.hr_5 x, evolution.hr_1 y
		where x.codigo = y.codigo and cod_alterno = p_cedula;

		select id_1 into v_cedula from evolution.empleados where codigo = v_codsup;
		return v_cedula;
	end;

    procedure sp_correo_adjunto (  
		p_aplicacion 		in varchar2,
		p_remitente			in varchar2,
		p_para				in varchar2,
		p_concopia			in varchar2,
		p_concopiaoculta	in varchar2,
		p_asunto			in varchar2,
		p_contenido			in clob,
		p_adjuntos 			in blobs_list
    )
    as
    v_boundary		varchar2(100);
    v_smtp_host  	varchar2(20);
    v_smtp_port  	number;
    v_mail_conn   	utl_smtp.connection;
    v_arc_ajunt		blob;
    v_qty			number := 0;
    v_step  		pls_integer  := 12000;
    v_nls_charset   varchar2(255);
	v_text_msg      varchar2(255);
	v_para			varchar2(500);
    
    cursor cur_correos (var_correos varchar2) is
        select substr (','||var_correos||',',
        instr (','||var_correos||',',',', 1, rownum )+1,
        instr (','||var_correos||',',',', 1, rownum +1) - instr(','||var_correos||',', ',', 1, rownum)-1  ) res
        from ( select ','||var_correos||',' palabras from dual)
        connect by rownum < (length(','||var_correos||',') - length(replace(','||var_correos||',',',','')))
        and prior dbms_random.random is not null;
        erroru exception;
        pragma exception_init (erroru,-29279);
        var_correos varchar2(500);
        procedure process_recipients(p_mail_conn in out utl_smtp.connection,p_list in varchar2) as
            l_tab string_api.t_split_array;
        begin
            if trim(p_list) is not null then
                l_tab := string_api.split_text(p_list);
                for i in 1 .. l_tab.count
                loop
                    utl_smtp.rcpt(p_mail_conn, trim(l_tab(i)));
                end loop;
            end if;
        end;
    begin
        		v_para:=p_para;
		
		if (pk_corp_commons.f_isproduccion)then
			v_para:=v_para;
        else
			v_para:='pruebas.zaimella@gmail.com';
			v_para:='jose.masabandac@gmail.com';
        end if;
                dbms_output.put_line('p_aplicacion:'||p_aplicacion);
                dbms_output.put_line('p_remitente:'||p_remitente);
                dbms_output.put_line('p_para:'||v_para);
                dbms_output.put_line('p_concopia:'||p_concopia);
                dbms_output.put_line('p_concopiaoculta:'||p_concopiaoculta);
                dbms_output.put_line('p_asunto:'||p_asunto);
                dbms_output.put_line('p_contenido:'||p_contenido);
                dbms_output.put_line('p_adjuntos:'||p_adjuntos.COUNT);

        v_smtp_port:= 587;
        v_smtp_host:='192.168.5.12';
        v_boundary:='----=*#abc1234321cba#*=';
        -- get characterset
        select value into v_nls_charset from nls_database_parameters where parameter = 'NLS_CHARACTERSET';
        v_mail_conn := utl_smtp.open_connection(v_smtp_host, v_smtp_port);
        UTL_SMTP.helo(v_mail_conn, v_smtp_host);
        UTL_SMTP.mail(v_mail_conn, p_remitente);
        for ecur_correos in cur_correos(trim(v_para))
        loop  
            utl_smtp.rcpt(v_mail_conn, ecur_correos.res);
        end loop;

        if p_concopia is not null then
            for ecur_correos in cur_correos(trim(p_concopia)) 
            loop
                if ecur_correos.res is not null and ecur_correos.res<>' ' then
                    begin
                        utl_smtp.rcpt(v_mail_conn, ecur_correos.res); 
                        var_correos:=ecur_correos.res||','||var_correos;
                        exception when erroru then rollback;
                    end;
                end if;
            end loop;
        end if;

        process_recipients(v_mail_conn, v_para);
        process_recipients(v_mail_conn, p_concopia);
        process_recipients(v_mail_conn, p_concopiaoculta);

        utl_smtp.open_data(v_mail_conn);
        utl_smtp.write_data(v_mail_conn, 'To: ' || v_para || UTL_TCP.crlf);

        if p_concopia is not null then
            utl_smtp.write_data(v_mail_conn, 'Cc: ' || var_correos|| utl_tcp.crlf);
        end if;

        if trim(p_concopiaoculta) is not null then
            utl_smtp.write_data(v_mail_conn, 'BCC: ' || replace(p_concopiaoculta, ',', ';') || utl_tcp.crlf);
        end if;

        utl_smtp.write_data(v_mail_conn, 'From: ' || p_remitente || utl_tcp.crlf);
        utl_smtp.write_data(v_mail_conn, 'Subject: ' || p_asunto || utl_tcp.crlf);
        utl_smtp.write_data(v_mail_conn, 'Reply-To: ' || p_remitente || utl_tcp.crlf);
        utl_smtp.write_data(v_mail_conn, 'MIME-Version: 1.0' || utl_tcp.crlf);

        utl_smtp.write_data(v_mail_conn, 'Content-Type: multipart/mixed; boundary="' || v_boundary || '"' || utl_tcp.crlf || utl_tcp.crlf);

        if v_text_msg is not null then
            utl_smtp.write_data(v_mail_conn, '--' || v_boundary || utl_tcp.crlf);
            utl_smtp.write_data(v_mail_conn, 'Content-Type: text/plain; charset="iso-8859-1"' || utl_tcp.crlf || utl_tcp.crlf);

            utl_smtp.write_data(v_mail_conn, v_text_msg);
            utl_smtp.write_data(v_mail_conn, utl_tcp.crlf || utl_tcp.crlf);
        end if;

        if p_contenido is not null then
            utl_smtp.write_data(v_mail_conn, '--' || v_boundary || utl_tcp.crlf);
            utl_smtp.write_data(v_mail_conn, 'Content-Type: text/html; charset="iso-8859-1"' || utl_tcp.crlf || utl_tcp.crlf);

            utl_smtp.write_data(v_mail_conn, p_contenido);
            utl_smtp.write_data(v_mail_conn, utl_tcp.crlf || utl_tcp.crlf);
        end if;

        FOR i IN 1..p_adjuntos.COUNT LOOP
            dbms_output.put_line('p_adjuntos(i).FILENAME:'||p_adjuntos(i).FILENAME);
            utl_smtp.write_data(v_mail_conn, '--' || v_boundary || utl_tcp.crlf);
            utl_smtp.write_data(v_mail_conn, 'Content-Type: ' || p_adjuntos(i).MIMETYPE || '; name="' || p_adjuntos(i).FILENAME || '"' || utl_tcp.crlf);
            utl_smtp.write_data(v_mail_conn, 'Content-Transfer-Encoding: base64' || utl_tcp.crlf);
            utl_smtp.write_data(v_mail_conn, 'Content-Disposition: attachment; filename="' ||  p_adjuntos(i).FILENAME || '"' || utl_tcp.crlf || utl_tcp.crlf);
            v_arc_ajunt:=p_adjuntos(i).BLOBCONTENT;
            for i in 0 .. trunc((dbms_lob.getlength(v_arc_ajunt) - 1 )/v_step) loop
                utl_smtp.write_data(v_mail_conn, utl_raw.cast_to_varchar2(utl_encode.base64_encode(dbms_lob.substr(v_arc_ajunt, v_step, i * v_step + 1))));
            end loop;

            utl_smtp.write_data(v_mail_conn, utl_tcp.crlf || utl_tcp.crlf);
        end loop;

        utl_smtp.write_data(v_mail_conn, '--' || v_boundary || '--' || utl_tcp.crlf);
        utl_smtp.close_data(v_mail_conn);
        utl_smtp.quit(v_mail_conn);
        insert into t_apex_logcorreo (proceso,aplicacion,remitente,para,concopia,concopiaoculta,asunto,contenido)
		values ('pk_commons.sp_correo_adjunto',p_aplicacion,p_remitente,v_para,p_concopia,p_concopiaoculta,p_asunto,null);
    end sp_correo_adjunto;

	procedure sp_servirarchivo (p_numeroarchivo in number) as
	v_archivo	blob;
	v_mimetype	varchar2(100);
	v_nombrearc	varchar2(255);
	begin
		insert into t_apex_log (aplicacion,paso) values ('sp_servirarchivo',p_numeroarchivo); commit;
		select blobcontent, mimetype, filename
		into v_archivo, v_mimetype, v_nombrearc
		from files.t_apex_archivos
		where numeroarchivo = p_numeroarchivo;
	
		-- ConfiguraciÃ³n para enviar el archivo al navegador
		owa_util.mime_header(v_mimetype, false);
		htp.p('Content-Disposition: inline; filename="'||v_nombrearc||'"');
		owa_util.http_header_close;
	
		-- Enviar el contenido BLOB
		wpg_docload.download_file(v_archivo);		
	end sp_servirarchivo;

    function f_get_json_param(p_tramajson in clob, p_etiqueta varchar2) return clob as
        v_sql       varchar(3999);
        v_clob      clob;
    begin
        v_sql := '
        select TO_CHAR(jt.'||p_etiqueta||') '||p_etiqueta||'  from   json_table('''|| p_tramajson|| ''',''$[*]''
        columns ( '|| p_etiqueta|| ' format json path ''$.'|| p_etiqueta|| ''')) jt';
        execute immediate v_sql
        into v_clob;
        return v_clob ;
    end f_get_json_param;
    
        /*
    ** 
      transforma de forma segura una fecha que viene desde un arhivo excel  
        @param p_fecha varchar2
        @return objeto de tipo date
    */
     /*
    ** 
      transforma de forma segura una fecha que viene desde un arhivo excel  
        @param p_fecha varchar2
        @return objeto de tipo date
    */
    function safe_to_date(p_fecha varchar2) return date is
        type t_formatos is table of varchar2(20);
        v_formatos t_formatos := t_formatos(
            'DD/MM/YYYY',
            'MM/DD/YYYY',
            'YYYY/DD/MM',
            'YYYY/MM/DD',
            'YYYY-MM-DD',
            'YYYY-DD-MM',
            'MM-DD-YYYY',
            'DD-MM-YYYY'
        );
        v_fecha varchar2(39):=trim(p_fecha);
    begin
        if v_fecha is null then
            return null;
        end if;

        for i in 1 .. v_formatos.count loop
            begin
                return  to_date(v_fecha, v_formatos(i));
            exception
                when others then
                    null;
            end;
        end loop;

       return null;
    end safe_to_date;
 /*
      transforma de forma segura una numero que viene desde un arhivo excel  
         @param p_numero varchar2
        @return objeto de tipo number    
    */      
       
--    function safe_to_number(p_numero varchar2) return number is
--        v_retorno number;
--    begin
--        v_retorno := to_number(replace(p_numero,'.',','));
--        return v_retorno;
--    exception when others then 
--        begin
--            v_retorno := to_number(replace(p_numero,',','.'));
--            return v_retorno;
--        exception when others then 
--            return 0;
--        end;    
--    end safe_to_number;
    function safe_to_number(p_numero varchar2) return number is
        v_numero       varchar2(500);
        v_decimal_sep  varchar2(1);
        v_last_dot     pls_integer;
        v_last_comma   pls_integer;
        v_pos_decimal  pls_integer;
        v_entero       varchar2(500);
        v_decimal      varchar2(500);
        v_restriccion  pls_integer := 25; -- La restricciÃ³n de decimales que acordamos
    begin
        v_numero := trim(p_numero);
        if v_numero is null then return null; end if;

        -- Excel puede serializar importes validos con exponente, por ejemplo -4.062E-2.
        -- Se convierten antes de aplicar la normalizacion vigente de miles y decimales.
        if regexp_like(
            v_numero,
            '^[+-]?([[:digit:]]+([.,][[:digit:]]*)?|[.,][[:digit:]]+)[eE][+-]?[[:digit:]]+$'
        ) then
            return to_number(
                replace(v_numero, ',', '.'),
                '99999999999999999999999999999999D99999999999999999999999999999EEEE',
                'NLS_NUMERIC_CHARACTERS = ''.,'''
            );
        end if;
    
        -- 1. IDENTIFICAR EL SÃMBOLO DECIMAL (El que estÃ© mÃ¡s a la derecha)
        v_last_dot   := instr(v_numero, '.', -1);
        v_last_comma := instr(v_numero, ',', -1);
    
        if v_last_dot > v_last_comma then
            v_decimal_sep := '.';
            v_pos_decimal := v_last_dot;
        elsif v_last_comma > v_last_dot then
            v_decimal_sep := ',';
            v_pos_decimal := v_last_comma;
        else
            v_decimal_sep := null; -- Es un entero
        end if;
    
        -- 2. QUITAR SÃMBOLOS DE MILES Y LIMPIAR
        if v_decimal_sep is not null then
            -- Separamos la parte entera de la decimal
            v_entero  := substr(v_numero, 1, v_pos_decimal - 1);
            v_decimal := substr(v_numero, v_pos_decimal + 1);
    
            -- Limpiamos la parte entera de cualquier punto o coma (miles/millares)
            v_entero := replace(replace(v_entero, '.', ''), ',', '');
            
            -- 3. CORTAR DECIMALES HASTA LA RESTRICCIÃ“N (25 caracteres)
            v_decimal := substr(v_decimal, 1, v_restriccion);
            
            -- Reconstruimos en formato estÃ¡ndar (usando punto para Oracle)
            v_numero := v_entero || '.' || v_decimal;
        else
            -- Si es entero, solo quitamos basura de miles
            v_numero := replace(replace(v_numero, '.', ''), ',', '');
        end if;
    
        -- ConversiÃ³n final segura
        return to_number(v_numero, '99999999999999999999999999999999D99999999999999999999999999999', 'NLS_NUMERIC_CHARACTERS = ''.,''');
    
    exception when others then
        return null;
    end safe_to_number;
      /*
      Muestra mensaje de error amigable para el usuario final
      Realizado por: Marco AlbÃ¡n
    */
    PROCEDURE raise_error(p_msg VARCHAR2) IS
    BEGIN
        raise_application_error(-20001, p_msg);
    END raise_error;
end pk_commons;
/
