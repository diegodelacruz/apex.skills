﻿CREATE OR REPLACE PACKAGE BODY "DATA"."PK_TRAD_CARGAMASIVA" AS
    v_rows_affected number;
    v_formatofechaexel varchar2(50):='1899-12-30';
    PROCEDURE sp_cargaArchivoCliente(p_compania varchar2,p_retorno out number,p_mensaje out varchar2);
    PROCEDURE sp_cargaArchivoProducto(p_compania varchar2,p_retorno out number,p_mensaje out varchar2);
    PROCEDURE sp_cargaArchivoSellin(p_compania varchar2,p_anio varchar2,p_retorno out number,p_mensaje out varchar2);
    PROCEDURE sp_cargaArchivoLocal(p_compania varchar2,p_retorno out number,p_mensaje out varchar2);
    PROCEDURE sp_cargaArchivoRuc(p_compania varchar2,p_retorno out number,p_mensaje out varchar2);
    PROCEDURE sp_cargaArchivoLocalRucInfo(p_compania varchar2,p_retorno out number,p_mensaje out varchar2);
    PROCEDURE sp_cargaArchivoZonificacion(p_compania varchar2,p_retorno out number,p_mensaje out varchar2);
    PROCEDURE sp_cargaArchivoClasificacion (p_compania varchar2,  p_retorno out number, p_mensaje out varchar2) ;
    procedure sp_cargaArchivo(p_compania varchar2,p_tipoarchivo varchar2,p_anio varchar2 default null,p_retorno out number,p_mensaje out varchar2)as
    begin
        pk_commons.sp_apex_log('PK_TRAD_CARGAMASIVA.sp_cargaArchivo',0,'carga archivo','p_compania:'||p_compania||',p_tipoarchivo:'||p_tipoarchivo||',p_anio:'||p_anio,null,null);
        case p_tipoarchivo
            when 'T_GZM_CLIENTE'  then sp_cargaArchivoCliente(p_compania,p_retorno,p_mensaje);
            when 'T_GZM_PRODUCTO' then sp_cargaArchivoProducto(p_compania,p_retorno,p_mensaje);
            when 'T_TRAD_SELLIN' then sp_cargaArchivoSellin(p_compania,p_anio,p_retorno,p_mensaje);
            when 'T_TRAD_CLIENTELOCAL' then sp_cargaArchivoLocal(p_compania,p_retorno,p_mensaje);
            when 'T_TRAD_CLIENTERUC' then sp_cargaArchivoRuc(p_compania,p_retorno,p_mensaje);
            when 'T_TRAD_LOCAL_RUC_INFO' then sp_cargaArchivoLocalRucInfo(p_compania,p_retorno,p_mensaje);
            when 'VT_TRAD_GEOGRAFICO_NIVEL' then sp_cargaArchivoZonificacion(p_compania,p_retorno,p_mensaje);
            when 'T_TRAD_CLIENTELOCALCLASIFICA' then sp_cargaArchivoClasificacion(p_compania,p_retorno,p_mensaje);
        end case ;
    end sp_cargaArchivo;
    PROCEDURE sp_cargaArchivoCliente(p_compania varchar2,p_retorno out number,p_mensaje out varchar2)as
    begin
        MERGE INTO t_gzm_cliente cli
        USING VT_APEX_EXCEL arc
        ON (cli.codigocliente = arc.c02 and cli.compania=p_compania )
        WHEN MATCHED THEN
            UPDATE SET
                cli.CODIGOGRUPO=arc.C03,
                cli.NOMBRES=arc.C04,
                cli.GRUPO=arc.C05,
                cli.DIRECCION=arc.C06,
                cli.CODIGOCANAL=arc.C07,
                cli.CANAL=arc.C08,
                cli.CODIGOPAIS=arc.C09,
                cli.CODIGOORIGEN=arc.C10,
                cli.RUC=arc.C11,
                cli.EJECUTIVO=arc.C12,
                cli.CODIGOEJECUTIVO=arc.C13,
                cli.CANALALTERNO=arc.C14,
                cli.estado=1
        WHEN NOT MATCHED THEN
            INSERT (   compania,CODIGOCLIENTE,CODIGOGRUPO,NOMBRES,  GRUPO,DIRECCION,CODIGOCANAL,  CANAL,CODIGOPAIS,CODIGOORIGEN,    RUC,EJECUTIVO,CODIGOEJECUTIVO,CANALALTERNO,estado)
            VALUES ( p_compania,      arc.C02,    arc.C03,arc.C04,arc.C05,  arc.C06,    arc.C07,arc.C08,   arc.C09,     arc.C10,arc.C11,  arc.C12,        arc.C13,     arc.C14,     1);
        v_rows_affected := SQL%ROWCOUNT;DBMS_OUTPUT.PUT_LINE('N?mero de filas afectadas: ' || v_rows_affected);
        commit;
        p_retorno :=0;
    exception when OTHERS then
        p_retorno :=-1;
        p_mensaje :='Error al importar datos de cliente';
    end sp_cargaArchivoCliente;
    PROCEDURE sp_cargaArchivoProducto(p_compania varchar2,p_retorno out number,p_mensaje out varchar2)as
    begin
        MERGE INTO T_GZM_PRODUCTO prd
        USING VT_APEX_EXCEL arc
        ON (prd.CODIGOPRODUCTO = arc.c02 and prd.compania=p_compania )
        WHEN MATCHED THEN
            UPDATE SET
                prd.CODIGOPRODUCTOPADRE=arc.C03,
                prd.CODIGOCORTO=arc.C04,
                prd.CODIGOALTERNO=arc.C05,
                prd.NOMBREPRODUCTO=arc.C06,
                prd.CODIGOBARRA=arc.C07,
                prd.TEXTOBUSQUEDA=arc.C08,
                prd.UNIDADPRINCIPAL=arc.C09,
                prd.CODIGOLINEA=arc.C10,
                prd.LINEANEGOCIO=arc.C11,
                prd.CODIGOMARCA=arc.C12,
                prd.MARCA=arc.C13,
                prd.CODIGOSUBMARCA=arc.C14,
                prd.SUBMARCA=arc.C15,
                prd.TIPOPRODUCTO=arc.C16,
                prd.estado=1
        WHEN NOT MATCHED THEN
            INSERT (   compania,CODIGOPRODUCTO,CODIGOPRODUCTOPADRE,CODIGOCORTO,CODIGOALTERNO,NOMBREPRODUCTO,CODIGOBARRA,TEXTOBUSQUEDA,UNIDADPRINCIPAL,CODIGOLINEA,LINEANEGOCIO,CODIGOMARCA,  MARCA,CODIGOSUBMARCA,SUBMARCA,TIPOPRODUCTO,estado)
            VALUES ( p_compania,       arc.C02,            arc.C03,    arc.C04,      arc.C05,       arc.C06,    arc.C07,      arc.C08,        arc.C09,    arc.C10,     arc.C11,    arc.C12,arc.C13,       arc.C14, arc.C15,     arc.C16,     1);
        v_rows_affected := SQL%ROWCOUNT;DBMS_OUTPUT.PUT_LINE('N?mero de filas afectadas: ' || v_rows_affected);
        commit;
        p_retorno :=0;
    exception when OTHERS then
        p_retorno :=-1;
        p_mensaje :='Error al importar datos de producto';
    end sp_cargaArchivoProducto;
    PROCEDURE sp_cargaArchivoSellin(p_compania varchar2,p_anio varchar2,p_retorno out number,p_mensaje out varchar2)as
--    declare p_compania varchar2(5):='00003';p_anio varchar2(6):='072024';p_retorno number;p_mensaje varchar2(3999);     v_rows_affected number;
        v_contador number:=0;
        v_meses VARCHAR2(500);
    begin
        select listagg(distinct '<li>'||to_char(TO_DATE(to_date(v_formatofechaexel , 'YYYY-MM-DD')+C02),'Month,yyyy')||'</li>',' ')
        into v_meses
        from VT_APEX_EXCEL a
        where to_char(TO_DATE(to_date(v_formatofechaexel , 'YYYY-MM-DD')+C02),'mmyyyy') <> trim(p_anio);
        if (v_meses is not null)then
            v_meses:='<ul>'||v_meses||'</ul>';
            v_meses:=replace(v_meses,' ','');
            p_retorno :=-1;
            p_mensaje :='Archivo contiene informaci?n distinta a la fecha seleccionada :<br/>'||v_meses ;
            return;
        end if;
        delete  t_trad_sellin sel
        where trim(to_char(sel.compania,'00000'))= p_compania and trim(to_char(fecha,'mmyyyy')) = p_anio;
        v_rows_affected := SQL%ROWCOUNT;DBMS_OUTPUT.PUT_LINE('N?mero de filas afectadas: ' || v_rows_affected);
        INSERT INTO t_trad_sellin(COMPANIA,FECHA,CODIGOCLIENTE,CODIGOGRUPO,CODIGOPRODUCTO,VALORUNIDAD,VALORVENTA,VALORVENTA2,VALORVENTA3,VALORCOSTO,CODIGOPRODUCTOPADRE)
            SELECT
                p_compania COMPANIA
                ,TO_DATE(to_date(v_formatofechaexel , 'YYYY-MM-DD')+arc.C02) fecha
                ,arc.C03 CODIGOCLIENTE
                ,arc.C03 CODIGOGRUPO
                ,arc.C04 CODIGOPRODUCTO
                ,to_number(replace(arc.C05,'.',','))VALORUNIDAD
                ,to_number(replace(arc.C06,'.',','))VALORVENTA
                ,to_number(replace(arc.C07,'.',','))VALORVENTA2
                ,to_number(replace(arc.C08,'.',','))VALORVENTA3
                ,to_number(replace(arc.C09,'.',','))VALORCOSTO
                ,arc.C10  CODIGOPRODUCTOPADRE
            FROM VT_APEX_EXCEL arc;
        v_rows_affected := SQL%ROWCOUNT;DBMS_OUTPUT.PUT_LINE('N?mero de filas afectadas: ' || v_rows_affected);
        commit;
        p_retorno :=0;
        p_mensaje :='' ;
        return;
    end sp_cargaArchivoSellin;
    PROCEDURE sp_cargaArchivoLocal(p_compania varchar2,p_retorno out number,p_mensaje out varchar2)as
--    declare p_COMPANIA VARCHAR2(5):='00003';P_RETORNO number;P_MENSAJE varchar2(3999);
        V_ROWS_AFFECTED number;
        v_RESULTADO NUMBER;
        v_CODIGOPDV NUMBER ;
        v_CODIGOLOCAL NUMBER ;
        v_matriz number:=0;
        V_rucs varchar2(3999);
        V_CodigosLocales varchar2(3999);
        v_existe number;
        V_compania varchar2(5):=trim(to_char(p_COMPANIA,'00000'));
        V_FECHA DATE;
        v_codigoclilocal number;
    begin
        /*Si no estan vacias las columnas CODIGOPDV, NUMERO se debe modificar update*/
        begin
            MERGE INTO T_TRAD_CLIENTELOCAL loc
            USING (
                select a.compania,
                c.c02 CODIGOPDV,c.c03 NUMERO,c.c04 GRUPO,C.c05 CODIGOLOCAL,c.c06 CLASIFICACION,c.c07 NOMBRECOMERCIAL,c.c08 NOMBRECONOCIDO,c.c09 IDGEOGRAFICO,c.c10 DIRECCION,
                c.c11 LATITUD,c.c12 LONGITUD,c.c13 CONTACTO,c.c14 TELEFONO,c.c15 EMAIL,c.c16 TIPOVISITA,NULLIF(TRIM(c.c19),'') SEGMENTACION
                FROM t_trad_cliente A
                INNER JOIN t_trad_clienteLocal B ON A.CODIGOPDV=B.CODIGOPDV
                INNER join VT_APEX_EXCEL c on b.CODIGOPDV=c.c02 and b.numero=c.c03 and a.compania=v_compania
            )arc
            ON (loc.codigopdv = arc.codigopdv and loc.numero=arc.NUMERO )
            WHEN MATCHED THEN
                UPDATE SET
                    loc.CODIGOLOCAL=NVL(NULLIF(TRIM(arc.CODIGOLOCAL), ''), loc.CODIGOLOCAL),
                    loc.CLASIFICACION=NVL(NULLIF(TRIM(arc.CLASIFICACION), ''), loc.CLASIFICACION),
                    loc.NOMBRECOMERCIAL=NVL(NULLIF(TRIM(arc.NOMBRECOMERCIAL), ''), loc.NOMBRECOMERCIAL),
                    loc.NOMBRECONOCIDO=NVL(NULLIF(TRIM(arc.NOMBRECONOCIDO), ''), loc.NOMBRECONOCIDO),
                    loc.IDGEOGRAFICO=NVL(NULLIF(TRIM(arc.IDGEOGRAFICO), ''), loc.IDGEOGRAFICO),
                    loc.DIRECCION=NVL(NULLIF(TRIM(arc.DIRECCION), ''), loc.DIRECCION),
                    loc.LATITUD=NVL(NULLIF(TRIM(arc.LATITUD), ''), loc.LATITUD),
                    loc.LONGITUD=NVL(NULLIF(TRIM(arc.LONGITUD), ''), loc.LONGITUD),
                    loc.CONTACTO=NVL(NULLIF(TRIM(arc.CONTACTO), ''), loc.CONTACTO),
                    loc.TELEFONO=NVL(NULLIF(TRIM(arc.TELEFONO), ''), loc.TELEFONO),
                    loc.EMAIL=NVL(NULLIF(TRIM(arc.EMAIL), ''), loc.EMAIL),
                    loc.TIPOVISITA=NVL(arc.TIPOVISITA, loc.TIPOVISITA),
                    loc.SEGMENTACION=NVL(arc.SEGMENTACION, loc.SEGMENTACION),
                    loc.estado=1
            ;
            v_rows_affected := SQL%ROWCOUNT;DBMS_OUTPUT.PUT_LINE('N?mero de filas afectadas en update: ' || v_rows_affected);
        end ;
        /*Si la columna CODIGOPDV no esta vacia y NUMERO  esta vacia debe insertar en la tabla t_trad_clienteLocal*/
        begin
            for datoLocal in(
                select c.id,
                      a.compania,c.c02 CODIGOPDV,c.c03 numero,c.c05 CODIGOLOCAL,c.c06 CLASIFICACION,c.c07 NOMBRECOMERCIAL,c.c08 NOMBRECONOCIDO,c.c09 IDGEOGRAFICO
                    ,c.c10 DIRECCION,c.c11 LATITUD,c.c12 LONGITUD,c.c13 CONTACTO,c.c14 TELEFONO,c.c15 EMAIL
                    ,PK_INTC_CLIENTETRADE.F_LOCALES_CANTIDAD(c.c02)MATRIZ,1 ESTADO,nvl(v('user'),'EMASABANDA') AUDITORIAUSUARIO,0 BODEGA
                    ,1 TIPO,0 ENVIAR,to_number(c.c16) TIPOVISITA,NULLIF(TRIM(c.c19),'') SEGMENTACION,0 ESTADOFLUJO, 1 CREAXRUC
                FROM t_trad_cliente A
                LEFT JOIN t_trad_clienteLocal B ON A.CODIGOPDV=B.CODIGOPDV
                inner join VT_APEX_EXCEL c on A.CODIGOPDV=c.c02 and a.compania=v_compania
                WHERE  NVL(TRIM(c.c03),0)=0
                group by c.id,a.compania,c.c02,c.c03,c.c05,c.c06,c.c07,c.c08,c.c09,c.c10,c.c11,c.c12,c.c13,c.c14,c.c15,nvl(v('user'),'EMASABANDA'),to_number(c.c16),NULLIF(TRIM(c.c19),'')
                order by c.id
            )loop
--                DBMS_OUTPUT.PUT_LINE('datoLocal.CODIGOPDV:'||datoLocal.CODIGOPDV||' datoLocal.CODIGOLOCAL:'||datoLocal.CODIGOLOCAL);
                /************************************************inserta en la tabla t_trad_clientelocal************************************************/
                v_codigoclilocal:= data.PK_TRAD_CLIENTE.F_SEC_CLI_LOCAL (datoLocal.CODIGOPDV);
                insert into data.t_trad_clientelocal(CODIGOPDV,NUMERO,CODIGOLOCAL,CLASIFICACION,FECHAINICIOCLASIFICACION,NOMBRECOMERCIAL,NOMBRECONOCIDO,ZONIFICACION,IDGEOGRAFICO,DIRECCION,LATITUD,LONGITUD,CONTACTO,TELEFONO,EMAIL,CASIFICACIONINICIO,CASIFICACIONFIN,MATRIZ,FLUJO,PROMOCIONAL,PORCENTAJEPROMO,ESTADO,AUDITORIAFECHA,AUDITORIAUSUARIO,FORMATO,IDRUTA,IDRUTACAMBIO,ESTADORUTA,BODEGA,ESTADOFLUJO, CREAXRUC,  ESTADO_ESTABLECIMIENTO, NUMERO_ESTABLECIMIENTO, TIPOVISITA, SEGMENTACION)
                values
                (datoLocal.CODIGOPDV,v_codigoclilocal,datoLocal.CODIGOLOCAL,datoLocal.CLASIFICACION,null,datoLocal.NOMBRECOMERCIAL,datoLocal.NOMBRECONOCIDO,
                null,datoLocal.IDGEOGRAFICO,datoLocal.DIRECCION,datoLocal.LATITUD,datoLocal.LONGITUD,datoLocal.CONTACTO,datoLocal.TELEFONO,
                datoLocal.EMAIL,null,null,datoLocal.MATRIZ ,null,null,null,
                datoLocal.ESTADO,SYSTIMESTAMP,datoLocal.AUDITORIAUSUARIO,null,null,null,null,
                datoLocal.BODEGA,datoLocal.ESTADOFLUJO,datoLocal.CREAXRUC, null,null,datoLocal.TIPOVISITA,datoLocal.SEGMENTACION);
            end loop;-- datoslocal
        end;
        /*Si estan vacias las columnas CODIGOPDV, NUMERO, grupo de debe insertar en las tablas
                t_trad_cliente,
                t_trad_clienteLocal,
                t_trad_clienteRuc-> solo insertar en el caso que no exista el ruc
        */
        V_rucs :='';V_codigolocal:='';v_existe:=0;
        begin
            FOR CLIENTES IN (
                select
                 v_compania COMPANIA, c.id,c.c02 CODIGOPDV,c.c03 numero,c.c04 CODIGOGRUPO,c.c05 CODIGOLOCAL,c.c06 CLASIFICACION,c.c07 NOMBRECOMERCIAL,c.c08 NOMBRECONOCIDO
                ,c.c09 IDGEOGRAFICO,c.c10 DIRECCION,c.c11 LATITUD,c.c12 LONGITUD,c.c13 CONTACTO,c.c14 TELEFONO,c.c15 EMAIL
                ,PK_INTC_CLIENTETRADE.F_LOCALES_CANTIDAD(c.c02)MATRIZ,1 ESTADO,nvl(v('user'),'EMASABANDA') USUARIO,0 BODEGA
                ,to_number(c.c16) TIPOVISITA,c.c17 RUC,TO_DATE(to_date(v_formatofechaexel , 'YYYY-MM-DD')+c.c18) FECHADESDE,'2' CANALATENCION,c.c07 NOMBRECLIENTE,c.c17 CEDULA,' 'OBSERVACION,NULL CODIGOCLIENTE
                ,'TRAD_CLIENTE' OBJETO,3 TIPO ,0 ESTADOFLUJO
                ,CASE pk_commons.f_esnumero (c.c17)
                    WHEN 1 THEN
                        CASE
                            WHEN LENGTH(TRIM(c.c17)) = 10 THEN 1
                            WHEN LENGTH(TRIM(c.c17)) = 13 THEN 2
                            ELSE 4
                        END
                    ELSE 4
                END TIPOIDENTIFICACION,SYSDATE FECHAINICIOCLASIFICACION
                ,(SELECT ESTADO_CONTRIBUYENTE FROM T_INTC_SRI WHERE NUMERO_RUC = c.c17 AND ROWNUM = 1)ESTADO_CONTRIBUYENTE
                ,NULLIF(TRIM(c.c19),'') SEGMENTACION
                FROM   VT_APEX_EXCEL c
                WHERE  NVL(TRIM(c.c02),0)=0 AND NVL(TRIM(c.c03),0)=0 AND NVL(TRIM(c.c04),0)=0
                and trim(c.c07) is not null and  trim(c.c08) is not null and  trim(c.c09) is not null
                and  trim(c.c10) is not null   and  trim(c.c17) is not null
            )
            LOOP
                v_CODIGOPDV:=clientes.CODIGOPDV;
                PK_TRAD_CLIENTE.SP_EXISTECLIENTEIDENTIFICACION(CLIENTES.CEDULA,v_CODIGOPDV);
                IF (v_CODIGOPDV IS NULL)THEN
                /************************************************inserta en la tabla t_trad_cliente************************************************/
                    v_codigopdv := data.PK_COMMONS.F_SECUENCIA ('T_TRAD_CLIENTE');
                    insert into data.t_trad_cliente
                    (CODIGOPDV,CODIGOGRUPO,CANALATENCION,CLASIFICACION,CORREO,RAZONSOCIAL,TELEFONO,
                    CEDULA, OBSERVACION,ESTADO, ESTADOFLUJO,COMPANIA,FLUJO,AUDITORIAFECHA,AUDITORIAUSUARIO,CODIGOCLIENTE,
                    TIPOIDENTIFICACION, CREAXRUC, FECHAINICIOCLASIFICACION )
                    values
                    (v_codigopdv, CLIENTES.CODIGOGRUPO,CLIENTES.CANALATENCION,CLIENTES.CLASIFICACION,CLIENTES.EMAIL,CLIENTES.NOMBRECLIENTE,CLIENTES.TELEFONO,
                    CLIENTES.CEDULA,CLIENTES.OBSERVACION, CLIENTES.estado,CLIENTES.ESTADOFLUJO, CLIENTES.COMPANIA, NULL, SYSTIMESTAMP, CLIENTES.USUARIO, CLIENTES.CODIGOCLIENTE,
                    CLIENTES.TIPOIDENTIFICACION, decode(CLIENTES.TIPO, 3, 1,0), CLIENTES.FECHAINICIOCLASIFICACION );
                END IF;
                DBMS_OUTPUT.PUT_LINE('v_CODIGOPDV:'||v_CODIGOPDV);
                DBMS_OUTPUT.PUT_LINE('v_resultado:'||v_resultado);
                    for datoLocal in(
                        select c.id,
                             v_compania compania,v_codigopdv CODIGOPDV,c.c03 numero,c.c05 CODIGOLOCAL,c.c06 CLASIFICACION,c.c07 NOMBRECOMERCIAL,c.c08 NOMBRECONOCIDO,c.c09 IDGEOGRAFICO
                            ,c.c10 DIRECCION,c.c11 LATITUD,c.c12 LONGITUD,c.c13 CONTACTO,c.c14 TELEFONO,c.c15 EMAIL
                            ,PK_INTC_CLIENTETRADE.F_LOCALES_CANTIDAD(c.c02)MATRIZ,1 ESTADO,nvl(v('user'),'EMASABANDA') AUDITORIAUSUARIO,0 BODEGA
                            ,1 TIPO,0 ENVIAR,to_number(c.c16) TIPOVISITA,c.c17 ruc,NULLIF(TRIM(c.c19),'') SEGMENTACION ,0 ESTADOFLUJO, 1 CREAXRUC
                        from VT_APEX_EXCEL c
                        WHERE  NVL(TRIM(c.c02),0)=0 AND NVL(TRIM(c.c03),0)=0 AND NVL(TRIM(c.c04),0)=0  and CLIENTES.RUC= TRIM(c.c17)
                        order by c.id
                    )loop
                        DBMS_OUTPUT.PUT_LINE('datoLocal.CODIGOPDV:'||datoLocal.CODIGOPDV||' datoLocal.CODIGOLOCAL:'||datoLocal.CODIGOLOCAL||'   funcion:'||PK_TRAD_CLIENTE.F_EXISTECODIGOLOCAL(datoLocal.CODIGOPDV,datoLocal.CODIGOLOCAL));
                        if (datoLocal.CODIGOLOCAL is null or (PK_TRAD_CLIENTE.F_EXISTECODIGOLOCAL(datoLocal.CODIGOPDV,datoLocal.CODIGOLOCAL)=0))then
                        /************************************************inserta en la tabla t_trad_clientelocal************************************************/
                            v_codigoclilocal := data.PK_TRAD_CLIENTE.F_SEC_CLI_LOCAL (datoLocal.CODIGOPDV);
                            insert into data.t_trad_clientelocal(CODIGOPDV,NUMERO,CODIGOLOCAL,CLASIFICACION,FECHAINICIOCLASIFICACION,NOMBRECOMERCIAL,NOMBRECONOCIDO,ZONIFICACION,IDGEOGRAFICO,DIRECCION,LATITUD,LONGITUD,CONTACTO,TELEFONO,EMAIL,CASIFICACIONINICIO,CASIFICACIONFIN,MATRIZ,FLUJO,PROMOCIONAL,PORCENTAJEPROMO,ESTADO,AUDITORIAFECHA,AUDITORIAUSUARIO,FORMATO,IDRUTA,IDRUTACAMBIO,ESTADORUTA,BODEGA,ESTADOFLUJO, CREAXRUC,  ESTADO_ESTABLECIMIENTO, NUMERO_ESTABLECIMIENTO, TIPOVISITA, SEGMENTACION)
                            values (datoLocal.CODIGOPDV,v_codigoclilocal,datoLocal.CODIGOLOCAL,datoLocal.CLASIFICACION,null,datoLocal.NOMBRECOMERCIAL,datoLocal.NOMBRECONOCIDO,
                            null,datoLocal.IDGEOGRAFICO,datoLocal.DIRECCION,datoLocal.LATITUD,datoLocal.LONGITUD,datoLocal.CONTACTO,datoLocal.TELEFONO,
                            datoLocal.EMAIL,null,null,datoLocal.MATRIZ ,null,null,null,
                            datoLocal.ESTADO,SYSTIMESTAMP,datoLocal.AUDITORIAUSUARIO,null,null,null,null,
                            datoLocal.BODEGA,datoLocal.ESTADOFLUJO,datoLocal.CREAXRUC, null,null,datoLocal.TIPOVISITA,datoLocal.SEGMENTACION);
                        else
                            if nvl(INSTR(V_CodigosLocales, datoLocal.ruc||'{'||datoLocal.CODIGOLOCAL||'}'),0) = 0 THEN
                                V_CodigosLocales:=V_CodigosLocales ||datoLocal.ruc||'{'||datoLocal.CODIGOLOCAL||'}'||'|';
                            end if;
                        end if ;
                        v_CODIGOLOCAL:=null;
                    end loop;-- datoslocal
--                    if (trim(V_CodigosLocales) is not null)then
--                        RAISE_APPLICATION_ERROR(-20100,'C?digo(s) de local(es) ya resitrado(s) para el mismo cliente, '||V_CodigosLocales||' favor validar.');
--                    end if;
                    for datoRuc in(
                        select distinct
                              v_compania compania,v_CODIGOPDV CODIGOPDV,c.c07 razon_social,c.c09 UBICACION,nvl(v('user'),'EMASABANDA') AUDITORIAUSUARIO
                              ,1 TIPO,c.c17 ruc,TO_DATE(to_date(v_formatofechaexel , 'YYYY-MM-DD')+C.c18) FECHA_DESDE,clientes.TIPOIDENTIFICACION TIPOIDENTIFICACION,clientes.ESTADO_CONTRIBUYENTE ESTADO_CONTRIBUYENTE
                              ,1 estado
                        from VT_APEX_EXCEL c
                        WHERE  NVL(TRIM(c.c02),0)=0 AND NVL(TRIM(c.c03),0)=0 AND NVL(TRIM(c.c04),0)=0 and TRIM(c.c17)=TRIM(CLIENTES.RUC)
                        and not exists (select * from t_trad_clienteruc where ruc = TRIM(CLIENTES.RUC))
                    )loop
--                        DBMS_OUTPUT.PUT_LINE('datoRuc.FECHA_DESDE :' || datoRuc.FECHA_DESDE ||'datoRuc.CODIGOPDV :' || datoRuc.CODIGOPDV );
                        BEGIN
                            SELECT TO_DATE( LISTAGG(ITEM,'/') WITHIN GROUP (ORDER BY ID DESC)) INTO V_FECHA  FROM PK_COMMONS.f_dividirtexto(datoRuc.FECHA_DESDE,'-');
                        EXCEPTION WHEN OTHERS THEN
                            BEGIN
                                V_FECHA:=TO_DATE(datoRuc.FECHA_DESDE);
                            EXCEPTION WHEN OTHERS THEN
                                V_FECHA:=NULL;
                            END;
                        END;
                        /************************************************inserta en la tabla t_trad_clienteruc************************************************/
                        insert into data.t_trad_clienteruc (codigopdv,ruc,fechadesde,fechahasta,estado,auditoriafecha,auditoriausuario,convenio,estadoflujo,creaxruc,razon_social,estado_contribuyente,ubicacion,es_principal,tipoidentificacion )
                        values (datoRuc.CODIGOPDV,trim(datoRuc.ruc) ,V_FECHA,null,datoRuc.estado,SYSTIMESTAMP,datoRuc.AUDITORIAUSUARIO,0,0,1,datoRuc.RAZON_SOCIAL,datoRuc.ESTADO_CONTRIBUYENTE,datoRuc.UBICACION,1,datoRuc.TIPOIDENTIFICACION);
                    end loop;
            END LOOP;--datos t_trade_cliente
        end;
        /*for por grupo y generar el codigo del pdv unico e insertar por grupo debe insertar en las dos tablas
            t_trad_cliente,
            t_trad_clienteLocal,
            t_trad_clienteRuc-> solo insertar en el caso que no exista el ruc
        */
        begin
                for grupo in (
                    select distinct
                     '00003' COMPANIA, c.c04 CODIGOGRUPO
                    FROM   VT_APEX_EXCEL c
                    WHERE  NVL(TRIM(c.c02),0)=0 AND NVL(TRIM(c.c03),0)=0 AND NVL(TRIM(c.c04),0)!=0
                    and trim(c.c07) is not null and  trim(c.c08) is not null and  trim(c.c09) is not null
                    and  trim(c.c10) is not null   and  trim(c.c17) is not null
                )
                loop
                    null;
                    FOR CLIENTES IN (
                        select
                         v_compania COMPANIA, c.id,c.c02 CODIGOPDV,c.c03 numero,c.c04 CODIGOGRUPO,c.c05 CODIGOLOCAL,c.c06 CLASIFICACION,c.c07 NOMBRECOMERCIAL,c.c08 NOMBRECONOCIDO
                        ,c.c09 IDGEOGRAFICO,c.c10 DIRECCION,c.c11 LATITUD,c.c12 LONGITUD,c.c13 CONTACTO,c.c14 TELEFONO,c.c15 EMAIL
                        ,PK_INTC_CLIENTETRADE.F_LOCALES_CANTIDAD(c.c02)MATRIZ,1 ESTADO,nvl(v('user'),'EMASABANDA') USUARIO,0 BODEGA
                        ,to_number(c.c16) TIPOVISITA,c.c17 RUC,TO_DATE(to_date(v_formatofechaexel , 'YYYY-MM-DD')+c.c18) FECHADESDE,'2' CANALATENCION,c.c07 NOMBRECLIENTE,c.c17 CEDULA,' 'OBSERVACION,NULL CODIGOCLIENTE
                        ,'TRAD_CLIENTE' OBJETO,3 TIPO ,0 ESTADOFLUJO
                        ,CASE pk_commons.f_esnumero (c.c17)
                            WHEN 1 THEN
                                CASE
                                    WHEN LENGTH(TRIM(c.c17)) = 10 THEN 1
                                    WHEN LENGTH(TRIM(c.c17)) = 13 THEN 2
                                    ELSE 4
                                END
                            ELSE 4
                        END TIPOIDENTIFICACION,SYSDATE FECHAINICIOCLASIFICACION
                        ,(SELECT ESTADO_CONTRIBUYENTE FROM T_INTC_SRI WHERE NUMERO_RUC = c.c17 AND ROWNUM = 1)ESTADO_CONTRIBUYENTE
                ,NULLIF(TRIM(c.c19),'') SEGMENTACION
                        FROM   VT_APEX_EXCEL c
                        WHERE  NVL(TRIM(c.c02),0)=0 AND NVL(TRIM(c.c03),0)=0 AND NVL(TRIM(c.c04),0)!=0  and NVL(TRIM(c.c04),0)= grupo.CODIGOGRUPO
                    )
                    LOOP
                        v_CODIGOPDV:=clientes.CODIGOPDV;
                        PK_TRAD_CLIENTE.SP_EXISTECLIENTEIDENTIFICACION(CLIENTES.CEDULA,v_CODIGOPDV);
                        IF (v_CODIGOPDV IS NULL)THEN
                        /************************************************inserta en la tabla t_trad_cliente************************************************/
                            v_CODIGOPDV := data.PK_COMMONS.F_SECUENCIA ('T_TRAD_CLIENTE');
                            insert into data.t_trad_cliente
                            (CODIGOPDV,CODIGOGRUPO,CANALATENCION,CLASIFICACION,CORREO,RAZONSOCIAL,TELEFONO,
                            CEDULA, OBSERVACION,ESTADO, ESTADOFLUJO,COMPANIA,FLUJO,AUDITORIAFECHA,AUDITORIAUSUARIO,CODIGOCLIENTE,
                            TIPOIDENTIFICACION, CREAXRUC, FECHAINICIOCLASIFICACION ) values
                            (v_CODIGOPDV, CLIENTES.CODIGOGRUPO,CLIENTES.CANALATENCION,CLIENTES.CLASIFICACION,CLIENTES.EMAIL,CLIENTES.NOMBRECLIENTE,CLIENTES.TELEFONO,
                            CLIENTES.CEDULA,CLIENTES.OBSERVACION, CLIENTES.estado, CLIENTES.ESTADOFLUJO, CLIENTES.COMPANIA, NULL, SYSTIMESTAMP, CLIENTES.USUARIO, CLIENTES.CODIGOCLIENTE,
                            CLIENTES.TIPOIDENTIFICACION, decode(CLIENTES.TIPO, 3, 1,0), CLIENTES.FECHAINICIOCLASIFICACION );
                        END IF;
                        DBMS_OUTPUT.PUT_LINE('v_CODIGOPDV:'||v_CODIGOPDV);
                        DBMS_OUTPUT.PUT_LINE('v_resultado:'||v_resultado);
                        if (v_resultado!=0)then
                            for datoLocal in(
                                select c.id,
                                     v_compania compania,v_CODIGOPDV CODIGOPDV,c.c03 numero,c.c05 CODIGOLOCAL,c.c06 CLASIFICACION,c.c07 NOMBRECOMERCIAL,c.c08 NOMBRECONOCIDO,c.c09 IDGEOGRAFICO
                                    ,c.c10 DIRECCION,c.c11 LATITUD,c.c12 LONGITUD,c.c13 CONTACTO,c.c14 TELEFONO,c.c15 EMAIL
                                    ,PK_INTC_CLIENTETRADE.F_LOCALES_CANTIDAD(c.c02)MATRIZ,1 ESTADO,nvl(v('user'),'EMASABANDA') AUDITORIAUSUARIO,0 BODEGA
                                    ,1 TIPO,0 ENVIAR,to_number(c.c16) TIPOVISITA,c.c17 ruc,NULLIF(TRIM(c.c19),'') SEGMENTACION
                                    ,0 ESTADOFLUJO, 1 CREAXRUC
                                from VT_APEX_EXCEL c
                                WHERE  NVL(TRIM(c.c02),0)=0 AND NVL(TRIM(c.c03),0)=0 AND NVL(TRIM(c.c04),0)=0  and CLIENTES.RUC= TRIM(c.c17)
                                order by c.id
                            )loop
                                DBMS_OUTPUT.PUT_LINE('datoLocal.CODIGOPDV:'||datoLocal.CODIGOPDV||' datoLocal.CODIGOLOCAL:'||datoLocal.CODIGOLOCAL||'   funcion:'||PK_TRAD_CLIENTE.F_EXISTECODIGOLOCAL(datoLocal.CODIGOPDV,datoLocal.CODIGOLOCAL));
                                if (datoLocal.CODIGOLOCAL is null or (PK_TRAD_CLIENTE.F_EXISTECODIGOLOCAL(datoLocal.CODIGOPDV,datoLocal.CODIGOLOCAL)=0))then
                        /************************************************inserta en la tabla t_trad_clientelocal************************************************/
                                    v_codigoclilocal := data.PK_TRAD_CLIENTE.F_SEC_CLI_LOCAL (datoLocal.CODIGOPDV);
                                    insert into data.t_trad_clientelocal(CODIGOPDV,NUMERO,CODIGOLOCAL,CLASIFICACION,FECHAINICIOCLASIFICACION,NOMBRECOMERCIAL,NOMBRECONOCIDO,
                                    ZONIFICACION,IDGEOGRAFICO,DIRECCION,LATITUD,LONGITUD,CONTACTO,TELEFONO,
                                    EMAIL,CASIFICACIONINICIO,CASIFICACIONFIN,MATRIZ,FLUJO,PROMOCIONAL,PORCENTAJEPROMO,
                                    ESTADO,AUDITORIAFECHA,AUDITORIAUSUARIO,FORMATO,IDRUTA,IDRUTACAMBIO,ESTADORUTA,
                                    BODEGA,ESTADOFLUJO, CREAXRUC,  ESTADO_ESTABLECIMIENTO, NUMERO_ESTABLECIMIENTO, TIPOVISITA, SEGMENTACION)
                                    values (datoLocal.CODIGOPDV,v_codigoclilocal,datoLocal.CODIGOLOCAL,datoLocal.CLASIFICACION,null,datoLocal.NOMBRECOMERCIAL,datoLocal.NOMBRECONOCIDO,
                                    null,datoLocal.IDGEOGRAFICO,datoLocal.DIRECCION,datoLocal.LATITUD,datoLocal.LONGITUD,datoLocal.CONTACTO,datoLocal.TELEFONO,
                                    datoLocal.EMAIL,null,null,datoLocal.MATRIZ ,null,null,null,
                                    datoLocal.ESTADO,SYSTIMESTAMP,datoLocal.AUDITORIAUSUARIO,null,null,null,null,
                                    datoLocal.BODEGA,datoLocal.ESTADOFLUJO,datoLocal.CREAXRUC, null,null,datoLocal.TIPOVISITA,datoLocal.SEGMENTACION);
                                else
                                    if nvl(INSTR(V_CodigosLocales, datoLocal.ruc||'{'||datoLocal.CODIGOLOCAL||'}'),0) = 0 THEN
                                        V_CodigosLocales:=V_CodigosLocales ||datoLocal.ruc||'{'||datoLocal.CODIGOLOCAL||'}'||'|';
                                    end if;
                                end if ;
                                v_CODIGOLOCAL:=null;
                            end loop;-- datoslocal
                            for datoRuc in(
                                select distinct
                                      v_compania compania,v_CODIGOPDV CODIGOPDV,c.c07 razon_social,c.c09 UBICACION,nvl(v('user'),'EMASABANDA') AUDITORIAUSUARIO
                                      ,1 TIPO,c.c17 ruc,TO_DATE(to_date(v_formatofechaexel , 'YYYY-MM-DD')+C.c18) FECHA_DESDE,clientes.TIPOIDENTIFICACION TIPOIDENTIFICACION,clientes.ESTADO_CONTRIBUYENTE ESTADO_CONTRIBUYENTE
                                      ,1 estado
                                from VT_APEX_EXCEL c
                                WHERE  NVL(TRIM(c.c02),0)=0 AND NVL(TRIM(c.c03),0)=0 AND NVL(TRIM(c.c04),0)=0 and TRIM(c.c17)=TRIM(CLIENTES.RUC)
                                and not exists (select * from t_trad_clienteruc where ruc = TRIM(CLIENTES.RUC))
                            )loop
        --                        DBMS_OUTPUT.PUT_LINE('datoRuc.FECHA_DESDE :' || datoRuc.FECHA_DESDE ||'datoRuc.CODIGOPDV :' || datoRuc.CODIGOPDV );
                                BEGIN
                                    SELECT TO_DATE( LISTAGG(ITEM,'/') WITHIN GROUP (ORDER BY ID DESC)) INTO V_FECHA  FROM PK_COMMONS.f_dividirtexto(datoRuc.FECHA_DESDE,'-');
                                EXCEPTION WHEN OTHERS THEN
                                    BEGIN
                                        V_FECHA:=TO_DATE(datoRuc.FECHA_DESDE);
                                    EXCEPTION WHEN OTHERS THEN
                                        V_FECHA:=NULL;
                                    END;
                                END;
                        /************************************************inserta en la tabla t_trad_clienteruc************************************************/
                                insert into data.t_trad_clienteruc (codigopdv,ruc,fechadesde,fechahasta,estado,auditoriafecha,auditoriausuario,convenio,estadoflujo,creaxruc,razon_social,estado_contribuyente,ubicacion,es_principal,tipoidentificacion )
                                values (datoRuc.CODIGOPDV,trim(datoRuc.ruc) ,V_FECHA,null,datoRuc.estado,SYSTIMESTAMP,datoRuc.AUDITORIAUSUARIO,0,0,1,datoRuc.RAZON_SOCIAL,datoRuc.ESTADO_CONTRIBUYENTE,datoRuc.UBICACION,1,datoRuc.TIPOIDENTIFICACION);
                            end loop;
                        end if;
                    END LOOP;--datos t_trade_cliente
                end loop;
        end;
       commit;
        p_retorno :=0;
        DBMS_OUTPUT.PUT_LINE('fin:' || p_retorno );
    exception when OTHERS then
        p_retorno :=-1;
        p_mensaje :=substr(SQLERRM,instr(SQLERRM,':')+1);
        DBMS_OUTPUT.PUT_LINE('p_retorno :' || p_retorno );
        DBMS_OUTPUT.PUT_LINE('p_mensaje :' || p_mensaje );
        rollback;
    end sp_cargaArchivoLocal;
    PROCEDURE sp_cargaArchivoRuc(p_compania varchar2,p_retorno out number,p_mensaje out varchar2)as
--    DECLARE p_compania varchar2(5):='00003';p_retorno number;p_mensaje varchar2(3999):='';V_ROWS_AFFECTED number;
    begin
        MERGE INTO T_TRAD_CLIENTERUC ruc
        USING (
            select C01, trim(C02) codigopdv, trim(C03) ruc,
            TO_DATE(to_date(v_formatofechaexel , 'YYYY-MM-DD')+C04) FECHADESDE,
            TO_DATE(to_date(v_formatofechaexel , 'YYYY-MM-DD')+C05) FECHAHASTA,
            C06 ESTADO, C07 UBICACION, C08 RAZON_SOCIAL, C09 ES_PRINCIPAL, C10 TIPOIDENTIFICACION
            from VT_APEX_EXCEL ach inner join t_trad_cliente cli on c02=codigopdv
            and compania=p_compania)arc
            ON (ruc.CODIGOPDV = arc.codigopdv and trim(ruc.ruc)=arc.ruc)
        WHEN MATCHED THEN
            UPDATE SET
                ruc.FECHADESDE=arc.FECHADESDE,
                ruc.FECHAHASTA=arc.FECHAHASTA,
                ruc.ESTADO=arc.ESTADO,
                ruc.UBICACION=arc.UBICACION,
                ruc.RAZON_SOCIAL=arc.RAZON_SOCIAL,
                ruc.ES_PRINCIPAL=arc.ES_PRINCIPAL,
                ruc.TIPOIDENTIFICACION=arc.TIPOIDENTIFICACION
        WHEN NOT MATCHED THEN
            INSERT (    CODIGOPDV,    RUC,    FECHADESDE,    FECHAHASTA,    ESTADO,    UBICACION,    RAZON_SOCIAL,ESTADOFLUJO,    ES_PRINCIPAL,    TIPOIDENTIFICACION)
            VALUES (arc.CODIGOPDV,arc.RUC,arc.FECHADESDE,arc.FECHAHASTA,arc.ESTADO,arc.UBICACION,arc.RAZON_SOCIAL,          0,arc.ES_PRINCIPAL,arc.TIPOIDENTIFICACION);
        v_rows_affected := SQL%ROWCOUNT;DBMS_OUTPUT.PUT_LINE('N?mero de filas afectadas: ' || v_rows_affected);
        commit;
        p_retorno :=0;
    exception when OTHERS then
        p_retorno :=-1;
        p_mensaje :='Error al importar datos de rucs SQLERRM: '||SQLERRM;
    end sp_cargaArchivoRuc;
    PROCEDURE sp_cargaArchivoLocalRucInfo(p_compania varchar2,p_retorno out number,p_mensaje out varchar2)as
    begin
        MERGE INTO T_TRAD_LOCAL_RUC_INFO cli
        USING VT_APEX_EXCEL arc
        ON ((C02 = CODIGOCLIENTE) AND
            (C03 = CODIGOLOCAL or C03 is null ) AND
            (C05=RUC or C05 is null)
        )
        WHEN MATCHED THEN
            UPDATE SET
                cli.NOMBRE_LOCAL_CLIENTE=	arc.C06,
                cli.CUIDAD_CLIENTE=	arc.C07,
                cli.PROV_DEPTO_CLIENTE=	arc.C08,
                cli.CODIFICACION_CLIENTE=	arc.C09,
                cli.NOMBRE_CLIENTE=	arc.C10,
                cli.CATEGORIA_CLIENTE=	arc.C11,
                cli.SUBCATEGORIA_CLIENTE=	arc.C12,
                cli.SEGMENTO_CLIENTE=	arc.C13,
                cli.CANAL_CLIENTE=	arc.C14,
                cli.SUBCANAL_CLIENTE=	arc.C15,
                cli.ZONA_CLIENTE=	arc.C16
        WHEN NOT MATCHED THEN
            INSERT (CODIGOCLIENTE,CODIGOLOCAL,CODIGOGRUPO,    RUC,NOMBRE_LOCAL_CLIENTE,CUIDAD_CLIENTE,PROV_DEPTO_CLIENTE,CODIFICACION_CLIENTE,NOMBRE_CLIENTE,CATEGORIA_CLIENTE,SUBCATEGORIA_CLIENTE,SEGMENTO_CLIENTE,CANAL_CLIENTE,SUBCANAL_CLIENTE,ZONA_CLIENTE)
            VALUES (      arc.C02,    arc.C03,    arc.C04,arc.C05,             arc.C06,       arc.C07,           arc.C08,             arc.C09,       arc.C10,          arc.C11,             arc.C12,         arc.C13,      arc.C14,         arc.C15,     arc.C16);
        v_rows_affected := SQL%ROWCOUNT;DBMS_OUTPUT.PUT_LINE('N?mero de filas afectadas: ' || v_rows_affected);
        commit;
        p_retorno :=0;
    exception when OTHERS then
        p_retorno :=-1;
        p_mensaje :='Error al importar datos de LocalRucInfo';
    end sp_cargaArchivoLocalRucInfo;
    PROCEDURE sp_cargaArchivoZonificacion(p_compania varchar2,p_retorno out number,p_mensaje out varchar2)as
    begin
        MERGE INTO data.T_CORP_UDC cli
        USING VT_APEX_EXCEL arc
        ON (ID_CABECERA = 'TRAD_GEOGR' AND ID_TABLA=C02 and CODIGOCOMPANIA= p_compania)
        WHEN MATCHED THEN UPDATE SET cli.DESCRIPCION2=arc.C03
        ;
        v_rows_affected := SQL%ROWCOUNT;DBMS_OUTPUT.PUT_LINE('N?mero de filas afectadas: ' || v_rows_affected);
        commit;
        p_retorno :=0;
    exception when OTHERS then
        p_retorno :=-1;
        p_mensaje :='Error al importar datos de Zonificacion';
    end sp_cargaArchivoZonificacion;
    PROCEDURE sp_cargaArchivoClasificacion (p_compania varchar2, p_retorno out number, p_mensaje out varchar2) as
        V_LISTACODIGO VARCHAR2(4000);
    begin
        --apex_debug.message('parametros,   p_compania='||p_compania);
        --Validar que todos los codigospdv existan y pertenecen a la compania
        begin
            SELECT LISTAGG(arc.c02, ', ') WITHIN GROUP (ORDER BY arc.c02) AS codigo
            INTO V_LISTACODIGO
            FROM DATA.VT_APEX_EXCEL arc
                LEFT JOIN DATA.T_TRAD_CLIENTE CLI ON ( arc.c02 = cli.codigopdv and cli.compania = p_compania )
            WHERE cli.codigopdv is null ;
        exception when no_data_found then
            v_listacodigo := '';
        end ; --apex_debug.message('Listado='||V_LISTACODIGO);
        if length(trim(nvl(v_listacodigo,'*'))) > 2 then
            p_retorno :=-1;
            p_mensaje :='Error los codiogos de PDV '||v_listacodigo||', no se encuentran, en los codigos de clientes';
            return;
        end if;
        MERGE INTO T_TRAD_CLIENTELOCALCLASIFICA cl
        USING VT_APEX_EXCEL arc
        ON (cl.codigopdv = arc.c02 and  nvl(cl.numero,-1) = nvl(arc.c03,-1) and cl.idclasificaciontipo = arc.c04 )
        WHEN MATCHED THEN UPDATE SET  cl.idclasificacion = arc.C05, cl.estado =arc.C06, cl.estadoflujo = 1 , fechainicio = sysdate,
                usuariomodifica = apex_util.get_session_state('APP_USER'), fechamodifica = sysdate
        WHEN NOT MATCHED THEN
            INSERT ( CODIGOPDV, NUMERO, IDCLASIFICACIONTIPO, IDCLASIFICACION, ESTADO, ESTADOFLUJO, FECHAINICIO, USUARIOCREA, FECHACREA)
            VALUES ( arc.C02,   arc.C03, arc.C04, arc.C05,  arc.C06,  1, sysdate, apex_util.get_session_state('APP_USER') , sysdate );
        v_rows_affected := SQL%ROWCOUNT;
        --apex_debug.message('filas afectadas ='||v_rows_affected);
        commit;
        p_retorno :=0;
    exception when OTHERS then
        p_retorno :=-1;
        p_mensaje :='Error al importar datos de clasificaci?n local: '+sqlerrm ;
    end sp_cargaArchivoClasificacion;
    /*Procedimiento para hacer carga masiva productos sellout*/
    PROCEDURE sp_cargaProductoSO (p_compania varchar2, p_retorno out number, p_mensaje out varchar2) AS
    V_LISTACODIGO varchar2(4000);
BEGIN
    p_retorno := 0;
    p_mensaje := '';
    pk_commons.sp_apex_log('PK_TRAD_CARGAMASIVA.sp_cargaProductoSO', 0, 'carga archivo', 'p_compania:' || p_compania, null, null);
    --Validar que el codigo de barra y el codigo de producto existan en el catalogo de productos.
    BEGIN
        SELECT CASE
                 WHEN MAX(total_length) > 3996 THEN LISTAGG(codigo, ', ') WITHIN GROUP (ORDER BY codigo) || ' ...'
                 ELSE LISTAGG(codigo, ', ') WITHIN GROUP (ORDER BY codigo)
               END
          INTO V_LISTACODIGO
          FROM (
                SELECT DISTINCT TRIM(arc.c02) || '-' || TRIM(arc.c03) codigo,
                       SUM(LENGTHB(TRIM(arc.c02) || '-' || TRIM(arc.c03)) + 2)
                         OVER (ORDER BY TRIM(arc.c02) || '-' || TRIM(arc.c03)) running_length,
                       SUM(LENGTHB(TRIM(arc.c02) || '-' || TRIM(arc.c03)) + 2) OVER () total_length
                  FROM DATA.VT_APEX_EXCEL ARC
                  LEFT JOIN DATA.VT_GZM_PRODUCTO PRO
                    ON PRO.compania = p_compania
                   AND ARC.C02 = PRO.CODIGOBARRA
                   AND ARC.C03 = PRO.CODIGOPRODUCTO
                 WHERE PRO.CODIGOPRODUCTO IS NULL
               )
         WHERE running_length <= 3996;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            V_LISTACODIGO := '';
    END;
    IF LENGTH(TRIM(NVL(V_LISTACODIGO, '*'))) > 2 THEN
        p_retorno := -1;
        p_mensaje := 'Error los codigos de barra con el codigo de producto ' || V_LISTACODIGO || ', no se encuentran en los productos';
        RETURN;
    END IF;
    --Validar que el codigo de cliente Zaimella exista solo cuando venga informado.
    BEGIN
        SELECT CASE
                 WHEN MAX(total_length) > 3996 THEN LISTAGG(codigo, ', ') WITHIN GROUP (ORDER BY codigo) || ' ...'
                 ELSE LISTAGG(codigo, ', ') WITHIN GROUP (ORDER BY codigo)
               END
          INTO V_LISTACODIGO
          FROM (
                SELECT DISTINCT TRIM(ARC.C05) codigo,
                       SUM(LENGTHB(TRIM(ARC.C05)) + 2)
                         OVER (ORDER BY TRIM(ARC.C05)) running_length,
                       SUM(LENGTHB(TRIM(ARC.C05)) + 2) OVER () total_length
                  FROM DATA.VT_APEX_EXCEL ARC
                  LEFT JOIN (
                      SELECT DISTINCT COMPANIA, CODIGOGRUPO
                        FROM DATA.VT_GZM_CLIENTE
                       WHERE CODIGOGRUPO IS NOT NULL
                  ) CLI
                    ON CLI.COMPANIA = p_compania
                   AND CLI.CODIGOGRUPO = TRIM(ARC.C05)
                 WHERE TRIM(ARC.C05) IS NOT NULL
                   AND CLI.CODIGOGRUPO IS NULL
               )
         WHERE running_length <= 3996;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            V_LISTACODIGO := '';
    END;
    IF LENGTH(TRIM(NVL(V_LISTACODIGO, '*'))) > 2 THEN
        p_retorno := -1;
        p_mensaje := 'Error los codigos de cliente Zaimella ' || V_LISTACODIGO || ', no se encuentran en los clientes';
        RETURN;
    END IF;
    --Validar que el tipo de caso informado sea uno de los casos permitidos.
    BEGIN
        SELECT CASE
                 WHEN MAX(total_length) > 3996 THEN LISTAGG(codigo, ', ') WITHIN GROUP (ORDER BY codigo) || ' ...'
                 ELSE LISTAGG(codigo, ', ') WITHIN GROUP (ORDER BY codigo)
               END
          INTO V_LISTACODIGO
          FROM (
                SELECT DISTINCT TRIM(ARC.C09) codigo,
                       SUM(LENGTHB(TRIM(ARC.C09)) + 2)
                         OVER (ORDER BY TRIM(ARC.C09)) running_length,
                       SUM(LENGTHB(TRIM(ARC.C09)) + 2) OVER () total_length
                  FROM DATA.VT_APEX_EXCEL ARC
                 WHERE TRIM(ARC.C09) IS NOT NULL
                   AND UPPER(TRIM(ARC.C09)) NOT IN ('CAMBIO_IMAGEN', 'PRODUCTO_EXTERIOR', 'PRODUCTO_PROMOCIONAL', 'IMAGEN_ANTERIOR_CLIENTE')
               )
         WHERE running_length <= 3996;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            V_LISTACODIGO := '';
    END;
    IF LENGTH(TRIM(NVL(V_LISTACODIGO, '*'))) > 2 THEN
        p_retorno := -1;
        p_mensaje := 'Error los tipos de caso ' || V_LISTACODIGO || ', no son validos';
        RETURN;
    END IF;
    --Validar que no existan rangos solapados para el mismo producto.
    --Si el cliente esta informado, la validacion aplica por producto y cliente.
    --Si el cliente esta vacio, la validacion aplica como producto general y no puede solaparse con ningun cliente.
    BEGIN
        WITH datos AS (
            SELECT ARC.C01 AS fila,
                   TRIM(ARC.C03) AS codigoproducto,
                   TRIM(ARC.C05) AS codigogrupo,
                   TRUNC(TO_DATE(v_formatofechaexel, 'YYYY-MM-DD') + TO_NUMBER(ARC.C07)) AS fechadesde,
                   NVL(TRUNC(TO_DATE(v_formatofechaexel, 'YYYY-MM-DD') + TO_NUMBER(ARC.C08)), DATE '9999-12-31') AS fechahasta
              FROM DATA.VT_APEX_EXCEL ARC
             WHERE TRIM(ARC.C03) IS NOT NULL
               AND ARC.C07 IS NOT NULL
        ),
        codigo AS (
            SELECT DISTINCT D1.CODIGOPRODUCTO || '-' || NVL(D1.CODIGOGRUPO, 'SIN CLIENTE') AS codigo,
                   SUM(LENGTHB(D1.CODIGOPRODUCTO || '-' || NVL(D1.CODIGOGRUPO, 'SIN CLIENTE')) + 2)
                     OVER (ORDER BY D1.CODIGOPRODUCTO || '-' || NVL(D1.CODIGOGRUPO, 'SIN CLIENTE')) running_length,
                   SUM(LENGTHB(D1.CODIGOPRODUCTO || '-' || NVL(D1.CODIGOGRUPO, 'SIN CLIENTE')) + 2) OVER () total_length
              FROM datos D1
              INNER JOIN datos D2
                ON D1.FILA <> D2.FILA
               AND D1.CODIGOPRODUCTO = D2.CODIGOPRODUCTO
               AND (
                    NVL(D1.CODIGOGRUPO, '*SIN_CLIENTE*') = NVL(D2.CODIGOGRUPO, '*SIN_CLIENTE*')
                    OR D1.CODIGOGRUPO IS NULL
                    OR D2.CODIGOGRUPO IS NULL
               )
               AND D1.FECHADESDE <= D2.FECHAHASTA
               AND D2.FECHADESDE <= D1.FECHAHASTA
        )
        SELECT CASE
                 WHEN MAX(total_length) > 3996 THEN LISTAGG(codigo, ', ') WITHIN GROUP (ORDER BY codigo) || ' ...'
                 ELSE LISTAGG(codigo, ', ') WITHIN GROUP (ORDER BY codigo)
               END
          INTO V_LISTACODIGO
          FROM codigo
         WHERE running_length <= 3996;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            V_LISTACODIGO := '';
    END;
    IF LENGTH(TRIM(NVL(V_LISTACODIGO, '*'))) > 2 THEN
        p_retorno := -1;
        p_mensaje := 'Error los productos ' || V_LISTACODIGO || ', tienen rangos de fecha solapados para el mismo cliente o producto general';
        RETURN;
    END IF;
    DELETE FROM DATA.T_INTC_PRODUCTO_SO
     WHERE COMPANIA = p_compania;
    INSERT INTO DATA.T_INTC_PRODUCTO_SO (
        CODIGOBARRA, CODIGOPRODUCTO, CODIGOGRUPO, FECHADESDE, FECHAHASTA,
        AUDITORIAUSUARIO, AUDITORIAFECHA, COMPANIA, TIPO_CASO
    )
    SELECT TRIM(C02),
           TRIM(C03),
           TRIM(C05),
           TO_DATE(TO_DATE(v_formatofechaexel, 'YYYY-MM-DD') + C07),
           CASE WHEN C08 IS NOT NULL THEN TO_DATE(TO_DATE(v_formatofechaexel, 'YYYY-MM-DD') + C08) END,
           APEX_UTIL.GET_SESSION_STATE('APP_USER'),
           SYSDATE,
           p_compania,
           UPPER(TRIM(C09))
      FROM DATA.VT_APEX_EXCEL;
    COMMIT;
    p_retorno := 0;
    p_mensaje := 'Datos importados con exito';
END sp_cargaProductoSO;
    /* Reemplaza el presupuesto del anio solicitado exclusivamente para la compania recibida. */
    PROCEDURE sp_cargaPortafolio  (p_compania varchar2, p_usuario varchar2, p_retorno out number, p_mensaje out varchar2) AS
        V_LISTACODIGO varchar2(4000) ;
        V_ID NUMBER ;
    BEGIN
        p_retorno := 0 ;
        p_mensaje := '';
        pk_commons.sp_apex_log('PK_TRAD_CARGAMASIVA.sp_cargaPortafolio',0,'carga archivo','p_compania:'||p_compania||', p_usuario: '||p_usuario,null,null);
        --Validar que c?digo de barra existan en la vista VT_JDE_PRODUCTOS
        begin
            WITH codigos_no_existentes AS (
                SELECT DISTINCT TRIM(arc.c02) AS codigo
                FROM DATA.VT_APEX_EXCEL arc
                    LEFT JOIN data.vt_intc_productoso pro ON pro.compania = p_compania AND arc.c02 = pro.codigobarra
                WHERE pro.codigoproducto IS NULL
            ), codigos_con_longitud AS (
                SELECT codigo, SUM(LENGTHB(codigo) + 2) OVER (ORDER BY codigo) AS running_length, SUM(LENGTHB(codigo) + 2) OVER () AS total_length
                FROM codigos_no_existentes
            ) SELECT CASE WHEN MAX(total_length) > 3996 THEN LISTAGG(codigo, ', ') WITHIN GROUP (ORDER BY codigo) || ' ...'
                       ELSE LISTAGG(codigo, ', ') WITHIN GROUP (ORDER BY codigo) END
                INTO V_LISTACODIGO
                FROM codigos_con_longitud
                WHERE running_length <= 3996;
        exception when no_data_found then
            v_listacodigo := '';
        end ; --apex_debug.message('Listado='||V_LISTACODIGO);
        if length(trim(nvl(v_listacodigo,'*'))) > 2 then
            p_retorno :=-1;
            p_mensaje :='Error los codiogos de barra '||v_listacodigo||', no se encuentran, en los productos';
            return;
        end if;
        --Si pasa las validaciones graba los datos del archivo y borrar la tabla e insertar los datos.
        V_ID := data.PK_COMMONS.F_SECUENCIA ('T_INTC_EXCELPORTAFOLIO') ;
        insert into data.T_INTC_EXCELPORTAFOLIO  (IDEXCELPORTAFOLIO, CODIGOBARRA, CLOUSTER, TIPO,
            AUDITORIAFECHA, AUDITORIAUSUARIO, COMPANIA)
        select  v_id, ex.c02, ex.c03, ex.c04, sysdate, p_usuario, p_compania
        from DATA.VT_APEX_EXCEL  ex;
        MERGE INTO data.T_INTC_EXCELPORTAFOLIO t
        USING (
          SELECT p.codigobarra,
                 MAX(p.ub) ub
            FROM data.t_intc_portafolio p
           WHERE p.compania = p_compania
             AND p.ub IS NOT NULL
             AND EXISTS (
                   SELECT 1
                     FROM data.T_INTC_EXCELPORTAFOLIO ex
                    WHERE ex.idexcelportafolio = v_id
                      AND ex.codigobarra = p.codigobarra)
           GROUP BY p.codigobarra
        ) u
        ON (t.idexcelportafolio = v_id and t.codigobarra = u.codigobarra)
        WHEN MATCHED THEN
          UPDATE SET t.ub = u.ub;
        insert into data.t_intc_portafolio_stg ( CODIGOPRODUCTO, TIPO, CODIGOPDV,
        NUMERO,CLASIFICACION, COMPANIA , CODIGOBARRA, PRODUCTO, UB
        )
        WITH ex_base AS (
            SELECT /*+ materialize */ ex.compania, ex.idexcelportafolio, ex.codigobarra,
                   ex.clouster, ex.tipo, ex.ub
              FROM data.t_intc_excelportafolio ex
             WHERE ex.compania = p_compania
               AND ex.idexcelportafolio = v_id
        ),
        pcl_base AS (
            SELECT /*+ materialize */ pcl.compania, pcl.closter, pcl.codigopdv, pcl.numero
              FROM data.vt_intc_pdvcluster pcl
             WHERE pcl.compania = p_compania
               AND EXISTS (
                     SELECT 1
                       FROM ex_base ex
                      WHERE ex.clouster = pcl.closter)
        ),
        pro_base AS (
            SELECT /*+ materialize */ pro.compania, pro.codigobarra,
                   pro.codigoproducto, pro.producto
              FROM data.vt_intc_productoso pro
             WHERE pro.compania = p_compania
               AND EXISTS (
                     SELECT 1
                       FROM ex_base ex
                      WHERE ex.codigobarra = pro.codigobarra)
        )
        SELECT pro.codigoproducto, ex.tipo, pcl.codigopdv, pcl.numero,
               ex.clouster, ex.compania, pro.codigobarra, pro.producto, ex.ub
          FROM ex_base ex
          INNER JOIN pcl_base pcl
            ON pcl.compania = ex.compania
           AND pcl.closter = ex.clouster
          INNER JOIN pro_base pro
            ON pro.compania = ex.compania
           AND pro.codigobarra = ex.codigobarra;
        IF SQL%ROWCOUNT = 0 THEN
            ROLLBACK;
            p_retorno := -1;
            p_mensaje := 'No se genero portafolio con el archivo cargado; se conserva el portafolio anterior';
            pk_commons.sp_apex_log('PK_TRAD_CARGAMASIVA.sp_cargaPortafolio',-1,p_mensaje,'p_compania:'||p_compania||', v_id:'||v_id,null,null);
            RETURN;
        END IF;
        EXECUTE IMMEDIATE 'TRUNCATE TABLE data.t_intc_portafolio';
        INSERT /*+ APPEND */ INTO data.t_intc_portafolio (
            CODIGOPRODUCTO, TIPO, CODIGOPDV, NUMERO, CLASIFICACION,
            COMPANIA, CODIGOBARRA, PRODUCTO, UB
        )
        SELECT CODIGOPRODUCTO, TIPO, CODIGOPDV, NUMERO, CLASIFICACION,
               COMPANIA, CODIGOBARRA, PRODUCTO, UB
          FROM data.t_intc_portafolio_stg;
        commit;
    END sp_cargaPortafolio ;
    /*Procedimiento para hacer carga masiva portafolio*/
    PROCEDURE sp_cargaPresupuesto  (p_compania varchar2, p_usuario varchar2, p_anio number, p_retorno out number, p_mensaje out varchar2) AS
        V_LISTACODIGO varchar2(4000) ;
        V_ID NUMBER ;
    BEGIN
        p_retorno := 0 ;
        p_mensaje := '';
        pk_commons.sp_apex_log('PK_TRAD_CARGAMASIVA.sp_cargaPresupuesto',0,'carga archivo','p_compania:'||p_compania||', p_usuario: '||p_usuario||', p_anio: '||p_anio,null,null);
        --Validar que c?digo de producto existan en la vista VT_JDE_PRODUCTOS
        begin
            WITH codigos_no_existentes AS (
                SELECT DISTINCT TRIM(arc.c04) AS codigo
                FROM DATA.VT_APEX_EXCEL arc
                    LEFT JOIN data.vt_gzm_producto pro ON pro.compania = p_compania AND arc.c04 = pro.codigoproducto
                WHERE pro.codigoproducto IS NULL
            ), codigos_con_longitud AS (
                SELECT codigo, SUM(LENGTHB(codigo) + 2) OVER (ORDER BY codigo) AS running_length, SUM(LENGTHB(codigo) + 2) OVER () AS total_length
                FROM codigos_no_existentes
            ) SELECT CASE WHEN MAX(total_length) > 3996 THEN LISTAGG(codigo, ', ') WITHIN GROUP (ORDER BY codigo) || ' ...'
                       ELSE LISTAGG(codigo, ', ') WITHIN GROUP (ORDER BY codigo) END
                INTO V_LISTACODIGO
                FROM codigos_con_longitud
                WHERE running_length <= 3996;
        exception when no_data_found then
            v_listacodigo := '';
        end ; --apex_debug.message('Listado='||V_LISTACODIGO);
        if length(trim(nvl(v_listacodigo,'*'))) > 2 then
            p_retorno :=-1;
            p_mensaje :='Error los codigos de producto '||v_listacodigo||', no se encuentran, en los productos';
            return;
        end if;
        --Validar que c?digo de cliente existan en la vista vt_trad_cliente
        begin
            WITH codigos_no_existentes AS (
                SELECT DISTINCT TRIM(arc.c05) AS codigo
                FROM DATA.VT_APEX_EXCEL arc
                    LEFT JOIN data.vt_gzm_cliente pro ON pro.compania = p_compania AND trim(arc.c05) = pro.codigocliente
                    --vt_trad_cliente no existe codigocliente
                WHERE pro.codigocliente IS NULL
            ), codigos_con_longitud AS (
                SELECT codigo, SUM(LENGTHB(codigo) + 2) OVER (ORDER BY codigo) AS running_length, SUM(LENGTHB(codigo) + 2) OVER () AS total_length
                FROM codigos_no_existentes
            ) SELECT CASE WHEN MAX(total_length) > 3996 THEN LISTAGG(codigo, ', ') WITHIN GROUP (ORDER BY codigo) || ' ...'
                       ELSE LISTAGG(codigo, ', ') WITHIN GROUP (ORDER BY codigo) END
                INTO V_LISTACODIGO
                FROM codigos_con_longitud
                WHERE running_length <= 3996;
        exception when no_data_found then
            v_listacodigo := '';
        end ; --apex_debug.message('Listado='||V_LISTACODIGO);
        if length(trim(nvl(v_listacodigo,'*'))) > 2 then
            p_retorno :=-1;
            p_mensaje :='Error los codiogos de clientes '||v_listacodigo||', no se encuentran, en los clientes ';
            return;
        end if;
        --Si pasa las validaciones graba los datos del archivo y borrar la tabla e insertar los datos.
        delete from data.t_finz_presupuesto_cliente_producto
        where anio = p_anio
          and compania = p_compania;
        commit;
        V_ID := data.PK_COMMONS.F_SECUENCIA ('T_FINZ_PRESUPUESTO_CLIENTE_PRODUCTO') ;
        insert into data.t_finz_presupuesto_cliente_producto ( ANIO, MES, NIVEL, CODIGOPRODUCTO, CODIGOCLIENTE, VALOR, FECHA, compania )
        SELECT p_anio, ex.c02, ex.C03, ex.c04, ex.c05, data.pk_commons.safe_to_number(p_numero => ex.c06),
            PK_CORP_COMMONS.EXCEL_TO_DATE(EX.C07), p_compania
            --TO_DATE(to_date(v_formatofechaexel , 'YYYY-MM-DD')+EX.C07)
         FROM data.vt_apex_excel ex ;
        commit;
    END sp_cargaPresupuesto ;
    PROCEDURE sp_refrescarPortafolio (p_compania varchar2)
    AS
        MAX_ID NUMBER ;
    BEGIN

        pk_commons.sp_apex_log('PK_TRAD_CARGAMASIVA.sp_refrescarPortafolio',0,'refresca portafolio','p_compania:'||p_compania||', p_usuario: '||'TAREAS AUTOMATICAS',null,null);

        SELECT MAX(IDEXCELPORTAFOLIO) INTO MAX_ID FROM data.T_INTC_EXCELPORTAFOLIO WHERE COMPANIA = p_compania ;

        SELECT COUNT(*)
          INTO v_rows_affected
          FROM (
        WITH ex_base AS (
            SELECT /*+ materialize */ ex.compania, ex.idexcelportafolio, ex.codigobarra,
                   ex.clouster, ex.tipo, ex.ub
              FROM data.t_intc_excelportafolio ex
             WHERE ex.compania = p_compania
               AND ex.idexcelportafolio = max_id
        ),
        pcl_base AS (
            SELECT /*+ materialize */ pcl.compania, pcl.closter, pcl.codigopdv, pcl.numero
              FROM data.vt_intc_pdvcluster pcl
             WHERE pcl.compania = p_compania
               AND EXISTS (
                     SELECT 1
                       FROM ex_base ex
                      WHERE ex.clouster = pcl.closter)
        ),
        pro_base AS (
            SELECT /*+ materialize */ pro.compania, pro.codigobarra,
                   pro.codigoproducto, pro.producto
              FROM data.vt_intc_productoso pro
             WHERE pro.compania = p_compania
               AND EXISTS (
                     SELECT 1
                       FROM ex_base ex
                      WHERE ex.codigobarra = pro.codigobarra)
        )
        SELECT pro.codigoproducto, ex.tipo, pcl.codigopdv, pcl.numero,
               ex.clouster, ex.compania, pro.codigobarra, pro.producto, ex.ub
          FROM ex_base ex
          INNER JOIN pcl_base pcl
            ON pcl.compania = ex.compania
           AND pcl.closter = ex.clouster
          INNER JOIN pro_base pro
            ON pro.compania = ex.compania
           AND pro.codigobarra = ex.codigobarra
          );

        IF v_rows_affected = 0 THEN
            ROLLBACK;
            pk_commons.sp_apex_log('PK_TRAD_CARGAMASIVA.sp_refrescarPortafolio',-1,'Refresco sin registros; se conserva portafolio anterior','p_compania:'||p_compania||', max_id:'||max_id,null,null);
            RETURN;
        END IF;

        EXECUTE IMMEDIATE 'TRUNCATE TABLE data.t_intc_portafolio';

        INSERT /*+ APPEND */ INTO data.t_intc_portafolio ( CODIGOPRODUCTO, TIPO, CODIGOPDV,
        NUMERO,CLASIFICACION, COMPANIA , CODIGOBARRA, PRODUCTO, UB
        )
        WITH ex_base AS (
            SELECT /*+ materialize */ ex.compania, ex.idexcelportafolio, ex.codigobarra,
                   ex.clouster, ex.tipo, ex.ub
              FROM data.t_intc_excelportafolio ex
             WHERE ex.compania = p_compania
               AND ex.idexcelportafolio = max_id
        ),
        pcl_base AS (
            SELECT /*+ materialize */ pcl.compania, pcl.closter, pcl.codigopdv, pcl.numero
              FROM data.vt_intc_pdvcluster pcl
             WHERE pcl.compania = p_compania
               AND EXISTS (
                     SELECT 1
                       FROM ex_base ex
                      WHERE ex.clouster = pcl.closter)
        ),
        pro_base AS (
            SELECT /*+ materialize */ pro.compania, pro.codigobarra,
                   pro.codigoproducto, pro.producto
              FROM data.vt_intc_productoso pro
             WHERE pro.compania = p_compania
               AND EXISTS (
                     SELECT 1
                       FROM ex_base ex
                      WHERE ex.codigobarra = pro.codigobarra)
        )
        SELECT pro.codigoproducto, ex.tipo, pcl.codigopdv, pcl.numero,
               ex.clouster, ex.compania, pro.codigobarra, pro.producto, ex.ub
          FROM ex_base ex
          INNER JOIN pcl_base pcl
            ON pcl.compania = ex.compania
           AND pcl.closter = ex.clouster
          INNER JOIN pro_base pro
            ON pro.compania = ex.compania
           AND pro.codigobarra = ex.codigobarra;

        commit;

    exception when OTHERS then
        pk_commons.sp_apex_log('PK_TRAD_CARGAMASIVA.sp_refrescarPortafolio',-1,'Error al refrescar portafolio: '||sqlerrm,'p_compania:'||p_compania||', p_usuario: '||'TAREAS AUTOMATICAS',null,null);
        RAISE;
    END sp_refrescarPortafolio ;
END PK_TRAD_CARGAMASIVA;
/
