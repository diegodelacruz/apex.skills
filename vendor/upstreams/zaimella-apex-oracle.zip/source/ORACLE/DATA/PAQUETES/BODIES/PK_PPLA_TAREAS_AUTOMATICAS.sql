CREATE OR REPLACE PACKAGE BODY DATA.PK_PPLA_TAREAS_AUTOMATICAS AS

/*FUNCION PARA RETORNAR STOCK DEL CIERRE
F_STOCKCIERRE(P_ANIO=>2025,P_MES=>2,  P_PRODUCTO=>'B08001005');
*/
FUNCTION F_STOCKCIERRE(P_ANIO NUMBER, P_MES NUMBER, P_PRODUCTO VARCHAR, P_BODEGA VARCHAR DEFAULT NULL,  P_COMPANIA VARCHAR) RETURN NUMBER AS
V_TOTAL NUMBER;
BEGIN

 SELECT   NVL(SUM(valor) / 10000, 0) INTO V_TOTAL
        FROM (
            SELECT
                inlitm, incmqt, innq01, innq02, innq03, innq04, innq05,
                innq06, innq07, innq08, innq09, innq10, innq11, innq12
            FROM f41112@jdedtadl
            WHERE inmcu = NVL(P_BODEGA, inmcu)
              AND inctry || infy = TO_CHAR(P_ANIO)
            ) UNPIVOT (
                 valor FOR mes IN (
                           incmqt AS 0, innq01 AS 1, innq02 AS 2, innq03 AS 3, innq04 AS 4,
                           innq05 AS 5, innq06 AS 6, innq07 AS 7, innq08 AS 8, innq09 AS 9,
                           innq10 AS 10, innq11 AS 11, innq12 AS 12
                                   )
                        )
        WHERE mes <= P_MES AND inlitm= RPAD(P_PRODUCTO, 25, ' ');

    RETURN V_TOTAL;
END F_STOCKCIERRE;


/*FUNCION PARA RETORNAR STOCK DEL CIERRE
F_STOCKIDEAL(P_PRODUCTO=>'B08001005', P_COMPANIA=>P_COMPANIA);
*/
FUNCTION F_STOCKIDEAL(P_PRODUCTO VARCHAR, P_COMPANIA VARCHAR) RETURN NUMBER AS
V_TOTAL NUMBER;
BEGIN

 SELECT  nvl(sum(STOCKINICIALIDEAL),0) INTO V_TOTAL
        FROM  t_ppla_productostockideal S
             WHERE  S.CODIGOPRODUCTO = P_PRODUCTO
             AND SYSDATE BETWEEN S.FECHADESDE AND S.FECHAHASTA  AND COMPANIA = P_COMPANIA ;

    RETURN V_TOTAL;

END F_STOCKIDEAL;

    /* PROCEDIMIENTO AUTOMATICO PARA EL PORTAL DE PLANIFICACIONES
    DATA.PK_PPLA_TAREAS_AUTOMATICAS.SP_EJECUTAR_TAREAS();
    */
  PROCEDURE  SP_EJECUTAR_TAREAS AS
  v_fecha DATE := trunc(SYSDATE);
  BEGIN

   DBMS_OUTPUT.PUT_LINE('SP_EJECUTAR_TAREAS: ' || v_fecha);
    IF TRUNC(v_fecha, 'MM') = TRUNC(v_fecha) THEN
        DBMS_OUTPUT.PUT_LINE('Hoy es el primer día del mes, ejecuta:
        1) copia de configuracion de manaquina
        2) calculo del plan de produccion' );

        PK_PPLA_CONFIGURACION.SP_MAQUINA_INICIO(P_COMPANIA=>'00001');

        PK_PPLA_TAREAS_AUTOMATICAS.SP_CALCULOPLANPRODUCCION(P_COMPANIA=>'00001');
    ELSE
        DBMS_OUTPUT.PUT_LINE('Hoy NO es el primer día del mes: ' || TO_CHAR(v_fecha, 'DD-MON-YYYY'));
    END IF;

    --validamos por nombre en inglés para evitar errores de región
    --(debe estar configurado el correo de destino PPLA_PARAM par12)
    IF TO_CHAR(v_fecha, 'FMDAY', 'NLS_DATE_LANGUAGE=ENGLISH') = 'MONDAY' THEN
        PK_PPLA_TAREAS_AUTOMATICAS.SP_NOTIFICAR_NUEVOS_PRODUCTOS(P_COMPANIA=>'00001');
    END IF;

    PK_PPLA_TAREAS_AUTOMATICAS.SP_ACTUALIZAR_PARAMETROS_PLANIFICACION_AGOTAMIENTO(P_COMPANIA=>'00001');

    PK_PPLA_TAREAS_AUTOMATICAS.SP_CALCULARSTOCKIDEAL(
        P_PERIODO => NULL,
        P_COMPANIA => '00001',
        P_USUARIO => 'TAREA');

  END SP_EJECUTAR_TAREAS;

/*
  Procedimiento que se calendariza para su ejecuciónn el día 1 de cada mes a las 3 am
  Este genera el plan de producción en base a:
  plan de demanda
  stock ideal inicial
  stock al cierre
  BOM materias primas
  P_TIPO -> INDICA 0 SI ES DEL MES ACTUAL O DESDE EL MES SIGUIENTE
  Realizado por Marco Albán el 13/02/2025
  PK_PPLA_TAREAS_AUTOMATICAS.SP_CALCULOPLANPRODUCCION(P_COMPANIA=>'00001', P_NIVEL=>1);
*/
  PROCEDURE SP_CALCULOPLANPRODUCCION(
             P_COMPANIA     IN VARCHAR2, P_TIPO NUMBER DEFAULT 0, P_NIVEL NUMBER DEFAULT 0)
             AS
  BEGIN
   DECLARE
        V_DIAS          NUMBER;
        V_MESESMAX      NUMBER := 12;
        V_DIASMES       NUMBER;
        V_MES_STOCKCIERRE NUMBER;
        V_ANIO_STOCKCIERRE NUMBER;
        V_MES_INICIA    DATE;
        V_MES_FIN       DATE;
        V_MES_ACTUAL       DATE;
        V_SUMA_DEMANDA    NUMBER;
        V_SUMA_PRODUCCION NUMBER;
        P_TO  VARCHAR2(250);
        P_CC            VARCHAR2(250);
        P_FROM          VARCHAR2(250);
        P_SUBJECT       VARCHAR2(250);
        P_TEXT_MSG      VARCHAR2(250);
        L_BODY_HTML     CLOB;
        L_BODY          CLOB;
        CRLF            VARCHAR2(2)  := chr(13)||chr(10);

        v_objeto	varchar2(50);

   BEGIN

   -- Obtengo el parámetro PAR6 que indica el máximo día del mes para modificar el plan de producción del mes en curso
   BEGIN
      SELECT VALOR INTO V_DIAS
      FROM T_CORP_UDC
      WHERE ID_CABECERA='PPLA_PARAM' AND ID_TABLA='PAR6';
    EXCEPTION WHEN NO_DATA_FOUND THEN V_DIAS:=1;
   END;
   -- OBTENER EL D¿A DEL MES
    SELECT EXTRACT(DAY FROM SYSDATE) INTO V_DIASMES FROM DUAL;

    -- DETERMINAR EL MES DE INICIO
    V_MES_INICIA := CASE WHEN (V_DIASMES > V_DIAS OR P_TIPO=1) THEN TRUNC(ADD_MONTHS(SYSDATE, 1), 'MM')
                        ELSE TRUNC(SYSDATE, 'MM')
                    END;

    -- DETERMINAR EL MES DE FIN
    V_MES_FIN := ADD_MONTHS(V_MES_INICIA, V_MESESMAX);

    -- OBTENER EL MES Y AÑO DE STOCK CIERRE (MES ANTERIOR)
    SELECT
        TO_NUMBER(TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'MM')),
        TO_NUMBER(TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'YYYY'))
    INTO V_MES_STOCKCIERRE, V_ANIO_STOCKCIERRE
    FROM DUAL;

    -- ELIMINAR REGISTROS EXISTENTES EN EL RANGO DE FECHAS
    UPDATE   T_PPLA_PLANPRODUCCION SET DEMANDA_ANTERIOR=0, DEMANDA=0, TOTAL=0
    WHERE FECHA >= V_MES_INICIA AND NIVEL>=P_NIVEL;

    DBMS_OUTPUT.PUT_LINE('V_MES_INICIA: '||V_MES_INICIA||
    ' V_MES_FIN: '||V_MES_FIN||' V_MES_STOCKCIERRE: '||V_MES_STOCKCIERRE||' V_ANIO_STOCKCIERRE: '||V_ANIO_STOCKCIERRE);

    -- INSERTAR NUEVOS REGISTROS
    -- NIVEL 0 TERMINADO DEL PLAN DE DEMANDA
    IF(P_NIVEL=0) THEN

        delete T_PPLA_PLANPRODUCCION  WHERE FECHA >= V_MES_INICIA AND NIVEL>=P_NIVEL;

        INSERT INTO T_PPLA_PLANPRODUCCION (
            CODIGOPRODUCTO, FECHA, DEMANDA, STOCKINICIAL, DOSIFICACION,
            FECHASTOCKCIERRE, STOCKINVENTARIO,CODIGOMAQUINA, NIVEL, COMPANIA,PLANIFICADOR,ESTADO)
        WITH STOCK_CIERRE AS (
            SELECT INLITM AS CODIGOPRODUCTO,
                NVL(SUM(valor) / 10000, 0) AS STOCKINVENTARIO
            FROM (
                SELECT
                    inlitm, incmqt, innq01, innq02, innq03, innq04, innq05,
                    innq06, innq07, innq08, innq09, innq10, innq11, innq12
                FROM f41112@jdedtadl
                WHERE inmcu = '       17003'
                  AND inctry || infy = TO_CHAR(V_ANIO_STOCKCIERRE)
                ) UNPIVOT (
                     valor FOR mes IN (
                               incmqt AS 0, innq01 AS 1, innq02 AS 2, innq03 AS 3, innq04 AS 4,
                               innq05 AS 5, innq06 AS 6, innq07 AS 7, innq08 AS 8, innq09 AS 9,
                               innq10 AS 10, innq11 AS 11, innq12 AS 12
                                       )
                            )
            WHERE mes <= V_MES_STOCKCIERRE
            GROUP BY inlitm ),
            PLANDEMANDA AS (
                    SELECT P.CODIGOPRODUCTO,TRUNC(P.FECHA) FECHA ,P.COMPANIA, SUM(P.CANTIDAD)CANTIDAD
                                FROM T_PPLA_PLANDEMANDA P WHERE
                                P.FECHA BETWEEN V_MES_INICIA AND V_MES_FIN
                                GROUP BY P.CODIGOPRODUCTO,P.FECHA,P.COMPANIA)
            SELECT P.CODIGOPRODUCTO,
                TRUNC(P.FECHA),
                P.CANTIDAD AS DEMANDA,
                NVL(S.STOCKINICIALIDEAL, 0) AS STOCKINICIAL,
                0 AS DOSIFICACION,
                LAST_DAY(ADD_MONTHS(SYSDATE, -1)) AS FECHASTOCKCIERRE,
                nvl(Sc.STOCKINVENTARIO,0),  0 AS MAQUINA, 0 AS NIVEL, P.COMPANIA,PLA.NOMBREUSUARIO,0
            FROM PLANDEMANDA P
            LEFT JOIN t_ppla_productostockideal S
                 ON P.CODIGOPRODUCTO = S.CODIGOPRODUCTO
                 AND P.COMPANIA = S.COMPANIA
                 AND SYSDATE BETWEEN S.FECHADESDE AND S.FECHAHASTA
            LEFT JOIN STOCK_CIERRE Sc
                 ON Sc.CODIGOPRODUCTO = RPAD(P.CODIGOPRODUCTO, 25, ' ')
            LEFT JOIN vt_ppla_producto_planificador PLA
                 ON PLA.CODIGOPRODUCTO=RPAD(P.CODIGOPRODUCTO, 25, ' ')
            WHERE P.FECHA BETWEEN V_MES_INICIA AND V_MES_FIN;

    END IF;
    --COMMIT;

    FOR I IN 0 .. MONTHS_BETWEEN(V_MES_FIN, V_MES_INICIA) LOOP

        V_MES_ACTUAL := TRUNC(ADD_MONTHS(V_MES_INICIA, i));
         DBMS_OUTPUT.PUT_LINE('Procesando mes: ' || V_MES_ACTUAL);

        IF(P_NIVEL=0) THEN
              --- CALCULO PLAN DE PRODUCCION
                      --- TRAIGO  DEMANDA ANTERIOR PARA LA FORMULA
             UPDATE T_PPLA_PLANPRODUCCION A SET (DEMANDA_ANTERIOR, PRODUCCION_ANTERIOR) =
             (SELECT NVL(SUM(DEMANDA),0), NVL(SUM(TOTAL),0) FROM T_PPLA_PLANPRODUCCION B
             WHERE A.CODIGOPRODUCTO=B.CODIGOPRODUCTO AND B.FECHA BETWEEN V_MES_INICIA AND ADD_MONTHS(V_MES_ACTUAL,-1) )
             WHERE A.FECHA=V_MES_ACTUAL  AND NIVEL=0;

              UPDATE T_PPLA_PLANPRODUCCION A
                  SET TOTAL =  GREATEST((DEMANDA+ DEMANDA_ANTERIOR + STOCKINICIAL- STOCKINVENTARIO -PRODUCCION_ANTERIOR),0) ,
                      TOTALORIGINAL =
                      (DEMANDA+ DEMANDA_ANTERIOR + STOCKINICIAL- STOCKINVENTARIO -PRODUCCION_ANTERIOR)
              WHERE A.FECHA=V_MES_ACTUAL AND NIVEL=0;
         END IF;

         IF(P_NIVEL<=1) THEN
             ---BOOM LISTA DE MATERIALES,
             -- NIVEL 1: TERMINADO SEGUN LISTA DE MATERIALES
             MERGE INTO T_PPLA_PLANPRODUCCION A
              USING ( SELECT TRIM(IMLITM) CODIGOLM, SUM(TOTAL*(IXQNTY/100000000)) DOSIFICACION
                      FROM T_PPLA_PLANPRODUCCION C
                      INNER JOIN F3002@JDEDTADL -- LISTA DE MATERIALES
                      ON ((IXKITL) =( CASE WHEN IXMMCU='       17005' THEN RPAD('P'||SUBSTR(C.CODIGOPRODUCTO,2),25,' ') ELSE RPAD(C.CODIGOPRODUCTO, 25, ' ') END)
                      AND IXTBM = 'M  ' AND TO_CHAR(SYSDATE, 'YYYYDDD') - 1900000 BETWEEN IXEFFF AND IXEFFT )
                      INNER JOIN  F4101@JDEDTADL -- MAESTRO PRODUCTO PARA TRAER SOLO TERMINADO
                      ON IXLITM=IMLITM --AND IMPRP7='PTE'
                      AND IMGLPT IN ('IN30', 'IN60', 'IN65')
                      WHERE C.FECHA=V_MES_ACTUAL AND NIVEL=0
                      GROUP BY IMLITM,C.FECHA
                    ) B
              ON (A.CODIGOPRODUCTO = B.CODIGOLM  AND A.FECHA=V_MES_ACTUAL)
              WHEN MATCHED THEN
                 UPDATE SET
                    A.DEMANDA = A.DEMANDA + B.DOSIFICACION
              WHEN NOT MATCHED THEN
                 INSERT (CODIGOPRODUCTO, COMPANIA, DEMANDA, FECHA, NIVEL,CODIGOMAQUINA,ESTADO, STOCKINVENTARIO, STOCKINICIAL, FECHASTOCKCIERRE)
                 VALUES (TRIM(B.CODIGOLM),P_COMPANIA, B.DOSIFICACION, V_MES_ACTUAL, 1,0,0
                 ,F_STOCKCIERRE(P_ANIO=>V_ANIO_STOCKCIERRE,P_MES=>V_MES_STOCKCIERRE,  P_PRODUCTO=>TRIM(B.CODIGOLM), P_COMPANIA=>P_COMPANIA)
                 ,F_STOCKIDEAL(P_PRODUCTO=>TRIM(B.CODIGOLM), P_COMPANIA=>P_COMPANIA)
                 ,LAST_DAY(ADD_MONTHS(SYSDATE, -1)));


               --- TRAIGO  DEMANDA ANTERIOR PARA LA FORMULA
             UPDATE T_PPLA_PLANPRODUCCION A SET (DEMANDA_ANTERIOR, PRODUCCION_ANTERIOR) =
             (SELECT NVL(SUM(DEMANDA),0), NVL(SUM(TOTAL),0) FROM T_PPLA_PLANPRODUCCION B
             WHERE A.CODIGOPRODUCTO=B.CODIGOPRODUCTO AND B.FECHA BETWEEN V_MES_INICIA AND ADD_MONTHS(V_MES_ACTUAL,-1) )
             WHERE A.FECHA=V_MES_ACTUAL  AND NIVEL=1;

             --- CALCULO PLAN DE PRODUCCION
              UPDATE T_PPLA_PLANPRODUCCION A
                  SET TOTAL =  GREATEST((DEMANDA+ DEMANDA_ANTERIOR + STOCKINICIAL- STOCKINVENTARIO -PRODUCCION_ANTERIOR),0) ,
                      TOTALORIGINAL =
                      GREATEST((DEMANDA+ DEMANDA_ANTERIOR + STOCKINICIAL- STOCKINVENTARIO -PRODUCCION_ANTERIOR),0)
              WHERE A.FECHA=V_MES_ACTUAL AND NIVEL=1;

        END IF;

        IF(P_NIVEL<=2) THEN
        --NIVEL 2: SEMIELABORADO DE LA LISTA 0 Y 1
            MERGE INTO T_PPLA_PLANPRODUCCION A
              USING ( SELECT TRIM(IMLITM)  CODIGOLM, SUM(TOTAL * (IXQNTY/100000000)) DOSIFICACION
                      FROM T_PPLA_PLANPRODUCCION C
                      INNER JOIN F3002@JDEDTADL -- LISTA DE MATERIALES
                       ON ((IXKITL) =( CASE WHEN IXMMCU='       17005' THEN RPAD('P'||SUBSTR(C.CODIGOPRODUCTO,2),25,' ') ELSE RPAD(C.CODIGOPRODUCTO, 25, ' ') END)
                      AND IXTBM = 'M  ' AND TO_CHAR(SYSDATE, 'YYYYDDD') - 1900000 BETWEEN IXEFFF AND IXEFFT )
                      INNER JOIN  F4101@JDEDTADL -- MAESTRO PRODUCTO PARA TRAER SOLO TERMINADO
                      ON IXLITM=IMLITM --AND IMPRP7='PTE'
                      AND IMGLPT IN ('IN40', 'IN80', 'IN85')
                      WHERE C.FECHA=V_MES_ACTUAL AND NIVEL IN (0,1)
                      GROUP BY IMLITM,C.FECHA
                    ) B
              ON (A.CODIGOPRODUCTO = B.CODIGOLM  AND A.FECHA=V_MES_ACTUAL)
              WHEN MATCHED THEN
                 UPDATE SET
                    A.DEMANDA = A.DEMANDA + B.DOSIFICACION
              WHEN NOT MATCHED THEN
                 INSERT (CODIGOPRODUCTO, COMPANIA, DEMANDA, FECHA, NIVEL,CODIGOMAQUINA,ESTADO, STOCKINVENTARIO, STOCKINICIAL, FECHASTOCKCIERRE)
                 VALUES (TRIM(B.CODIGOLM),P_COMPANIA, B.DOSIFICACION, V_MES_ACTUAL, 2,0,0
                 ,F_STOCKCIERRE(P_ANIO=>V_ANIO_STOCKCIERRE,P_MES=>V_MES_STOCKCIERRE,  P_PRODUCTO=>TRIM(B.CODIGOLM), P_COMPANIA=>P_COMPANIA)
                 ,F_STOCKIDEAL(P_PRODUCTO=>TRIM(B.CODIGOLM), P_COMPANIA=>P_COMPANIA)
                 ,LAST_DAY(ADD_MONTHS(SYSDATE, -1)));


                 --- TRAIGO  DEMANDA ANTERIOR PARA LA FORMULA
             UPDATE T_PPLA_PLANPRODUCCION A SET (DEMANDA_ANTERIOR, PRODUCCION_ANTERIOR) =
             (SELECT NVL(SUM(DEMANDA),0), NVL(SUM(TOTAL),0) FROM T_PPLA_PLANPRODUCCION B
             WHERE A.CODIGOPRODUCTO=B.CODIGOPRODUCTO AND B.FECHA BETWEEN V_MES_INICIA AND ADD_MONTHS(V_MES_ACTUAL,-1) )
             WHERE A.FECHA=V_MES_ACTUAL  AND NIVEL=2;

             --- CALCULO PLAN DE PRODUCCION
              UPDATE T_PPLA_PLANPRODUCCION A
                  SET TOTAL =  GREATEST((DEMANDA+ DEMANDA_ANTERIOR + STOCKINICIAL- STOCKINVENTARIO -PRODUCCION_ANTERIOR),0) ,
                      TOTALORIGINAL =
                      GREATEST((DEMANDA+ DEMANDA_ANTERIOR + STOCKINICIAL- STOCKINVENTARIO -PRODUCCION_ANTERIOR),0)
              WHERE A.FECHA=V_MES_ACTUAL AND NIVEL=2;

        END IF;

       IF(P_NIVEL<=3) THEN
            --NIVEL 3: SEMILABORADO DE LA LISTA 2
            MERGE INTO T_PPLA_PLANPRODUCCION A
              USING ( SELECT TRIM(IMLITM)  CODIGOLM, SUM(TOTAL* (IXQNTY/100000000)) DOSIFICACION
                      FROM T_PPLA_PLANPRODUCCION C
                      INNER JOIN F3002@JDEDTADL -- LISTA DE MATERIALES
                       ON ((IXKITL) =( CASE WHEN IXMMCU='       17005' THEN RPAD('P'||SUBSTR(C.CODIGOPRODUCTO,2),25,' ') ELSE RPAD(C.CODIGOPRODUCTO, 25, ' ') END)
                      AND IXTBM = 'M  ' AND TO_CHAR(SYSDATE, 'YYYYDDD') - 1900000 BETWEEN IXEFFF AND IXEFFT )
                      INNER JOIN  F4101@JDEDTADL -- MAESTRO PRODUCTO PARA TRAER SOLO TERMINADO
                      ON IXLITM=IMLITM --AND IMPRP7='PTE'
                      AND IXMMCU in ('       17016','       17009')---REVISAR CON LIS
                      AND IMGLPT IN ('IN40', 'IN80', 'IN85')
                      WHERE C.FECHA=V_MES_ACTUAL AND NIVEL IN (0,1,2)
                      GROUP BY IMLITM,C.FECHA
                    ) B
              ON (A.CODIGOPRODUCTO = B.CODIGOLM  AND A.FECHA=V_MES_ACTUAL)
              WHEN MATCHED THEN
                 UPDATE SET
                    A.DEMANDA = CASE WHEN P_NIVEL>=A.NIVEL THEN  NVL(A.DEMANDA,0) + B.DOSIFICACION ELSE A.DEMANDA END
                    , A.NIVEL= CASE WHEN P_NIVEL>=A.NIVEL THEN  3 ELSE  A.NIVEL END
              WHEN NOT MATCHED THEN
                 INSERT (CODIGOPRODUCTO, COMPANIA, DEMANDA, FECHA, NIVEL,CODIGOMAQUINA,ESTADO, STOCKINVENTARIO, STOCKINICIAL, FECHASTOCKCIERRE)
                 VALUES (TRIM(B.CODIGOLM),P_COMPANIA, B.DOSIFICACION, V_MES_ACTUAL, 3,0,0
                 ,F_STOCKCIERRE(P_ANIO=>V_ANIO_STOCKCIERRE,P_MES=>V_MES_STOCKCIERRE,  P_PRODUCTO=>TRIM(B.CODIGOLM), P_COMPANIA=>P_COMPANIA)
                 ,F_STOCKIDEAL(P_PRODUCTO=>TRIM(B.CODIGOLM), P_COMPANIA=>P_COMPANIA)
                 ,LAST_DAY(ADD_MONTHS(SYSDATE, -1)));


                --- TRAIGO  DEMANDA ANTERIOR PARA LA FORMULA
             UPDATE T_PPLA_PLANPRODUCCION A SET (DEMANDA_ANTERIOR, PRODUCCION_ANTERIOR) =
             (SELECT NVL(SUM(DEMANDA),0), NVL(SUM(TOTAL),0) FROM T_PPLA_PLANPRODUCCION B
             WHERE A.CODIGOPRODUCTO=B.CODIGOPRODUCTO AND B.FECHA BETWEEN V_MES_INICIA AND ADD_MONTHS(V_MES_ACTUAL,-1) )
             WHERE A.FECHA=V_MES_ACTUAL  AND NIVEL>=P_NIVEL;

             --- CALCULO PLAN DE PRODUCCION
              UPDATE T_PPLA_PLANPRODUCCION A
                  SET TOTAL =  GREATEST((DEMANDA+ DEMANDA_ANTERIOR + STOCKINICIAL- STOCKINVENTARIO -PRODUCCION_ANTERIOR),0) ,
                      TOTALORIGINAL =
                      GREATEST((DEMANDA+ DEMANDA_ANTERIOR + STOCKINICIAL- STOCKINVENTARIO -PRODUCCION_ANTERIOR),0)
              WHERE A.FECHA=V_MES_ACTUAL AND NIVEL >=P_NIVEL;

        END IF;

       IF(P_NIVEL<=4) THEN
            -- NIVEL 4: SEMILABORADO DE LA LISTA 3
            MERGE INTO T_PPLA_PLANPRODUCCION A
              USING ( SELECT TRIM(IMLITM)  CODIGOLM, SUM(TOTAL* (IXQNTY/100000000)) DOSIFICACION
                      FROM T_PPLA_PLANPRODUCCION C
                      INNER JOIN F3002@JDEDTADL -- LISTA DE MATERIALES
                       ON ((IXKITL) =( CASE WHEN IXMMCU='       17005' THEN RPAD('P'||SUBSTR(C.CODIGOPRODUCTO,2),25,' ') ELSE RPAD(C.CODIGOPRODUCTO, 25, ' ') END)
                      AND IXTBM = 'M  ' AND TO_CHAR(SYSDATE, 'YYYYDDD') - 1900000 BETWEEN IXEFFF AND IXEFFT )
                      INNER JOIN  F4101@JDEDTADL -- MAESTRO PRODUCTO PARA TRAER SOLO TERMINADO
                      ON IXLITM=IMLITM --AND IMPRP7='PTE'
                      AND IXMMCU in ('       17016','       17009')
                      AND IMGLPT IN ('IN40', 'IN80', 'IN85')
                      WHERE C.FECHA=V_MES_ACTUAL AND NIVEL=3
                      GROUP BY IMLITM,C.FECHA
                    ) B
              ON (A.CODIGOPRODUCTO = B.CODIGOLM  AND A.FECHA=V_MES_ACTUAL)
              WHEN MATCHED THEN
                 UPDATE SET
                    A.DEMANDA = A.DEMANDA + B.DOSIFICACION, NIVEL=4
              WHEN NOT MATCHED THEN
                 INSERT (CODIGOPRODUCTO, COMPANIA, DEMANDA, FECHA, NIVEL,CODIGOMAQUINA,ESTADO, STOCKINVENTARIO, STOCKINICIAL, FECHASTOCKCIERRE)
                 VALUES (TRIM(B.CODIGOLM),P_COMPANIA, B.DOSIFICACION, V_MES_ACTUAL, 4,0,0
                 ,F_STOCKCIERRE(P_ANIO=>V_ANIO_STOCKCIERRE,P_MES=>V_MES_STOCKCIERRE,  P_PRODUCTO=>TRIM(B.CODIGOLM), P_COMPANIA=>P_COMPANIA)
                 ,F_STOCKIDEAL(P_PRODUCTO=>TRIM(B.CODIGOLM), P_COMPANIA=>P_COMPANIA)
                 ,LAST_DAY(ADD_MONTHS(SYSDATE, -1)));

               --- TRAIGO  DEMANDA ANTERIOR PARA LA FORMULA
             UPDATE T_PPLA_PLANPRODUCCION A SET (DEMANDA_ANTERIOR, PRODUCCION_ANTERIOR) =
             (SELECT NVL(SUM(DEMANDA),0), NVL(SUM(TOTAL),0) FROM T_PPLA_PLANPRODUCCION B
             WHERE A.CODIGOPRODUCTO=B.CODIGOPRODUCTO AND B.FECHA BETWEEN V_MES_INICIA AND ADD_MONTHS(V_MES_ACTUAL,-1) )
             WHERE A.FECHA=V_MES_ACTUAL  AND NIVEL  >=P_NIVEL;

             --- CALCULO PLAN DE PRODUCCION
              UPDATE T_PPLA_PLANPRODUCCION A
                  SET TOTAL =  GREATEST((DEMANDA+ DEMANDA_ANTERIOR + STOCKINICIAL- STOCKINVENTARIO -PRODUCCION_ANTERIOR),0) ,
                      TOTALORIGINAL =
                      GREATEST((DEMANDA+ DEMANDA_ANTERIOR + STOCKINICIAL- STOCKINVENTARIO -PRODUCCION_ANTERIOR),0)
              WHERE A.FECHA=V_MES_ACTUAL AND NIVEL  >=P_NIVEL;
        END IF;
    END LOOP;

         -- CALCULO EL PLAN DE PRODUCCION EN UNIDADES
    UPDATE T_PPLA_PLANPRODUCCION
       SET (TOTALUNIDADES,TOTALUNIDADESORIGINAL)=(SELECT nvl(max(UNID5),1)*TOTAL, nvl(max(UNID5),1)*TOTAL
                          FROM DP.t_converciones X
                          WHERE TRIM(ILTM)=CODIGOPRODUCTO)
    WHERE FECHA >= V_MES_INICIA;


      -- Actualiza máquina estándar, tomo del dato de la vista: VT_JDE_MAQUINAFABRICA
      UPDATE T_PPLA_PLANPRODUCCION
        SET CODIGOMAQUINA=(SELECT MAQUINA
                           FROM VT_JDE_MAQUINAFABRICA
                           WHERE TIPORUTA='M' AND PRODUCTO=CODIGOPRODUCTO )
      WHERE FECHA >= V_MES_INICIA AND NIVEL>=P_NIVEL AND CODIGOMAQUINA=0
      AND EXISTS (SELECT 'X'
                  FROM VT_JDE_MAQUINAFABRICA
                  WHERE TIPORUTA='M' AND PRODUCTO=CODIGOPRODUCTO);

    -- Actualizo el PLANIFICADOR
    UPDATE T_PPLA_PLANPRODUCCION P
        SET PLANIFICADOR=(SELECT PLA.NOMBREUSUARIO
                          FROM vt_ppla_producto_planificador PLA
                          WHERE PLA.CODIGOPRODUCTO=P.CODIGOPRODUCTO)
    WHERE  FECHA >= V_MES_INICIA AND NIVEL>=P_NIVEL  AND PLANIFICADOR is null and EXISTS (SELECT 'X'
                  FROM vt_ppla_producto_planificador PLA
                  WHERE PLA.CODIGOPRODUCTO=P.CODIGOPRODUCTO);

      IF(P_NIVEL=0) THEN
        -- Notifico a los planificadores, tomando el dato de la tabla VT_PPLA_PRODUCTO_PLANIFICADOR
        WITH LISTACORREOS AS (
                SELECT DISTINCT EMAIL CORREO
                FROM VT_CORP_USUARIO X
                JOIN T_PPLA_PLANPRODUCCION Y ON (X.NOMBREUSUARIO = Y.PLANIFICADOR)
                WHERE FECHA >= V_MES_INICIA
                )
            SELECT LISTAGG(CORREO, ',') WITHIN GROUP (ORDER BY CORREO) INTO P_TO
            FROM LISTACORREOS ;
        DBMS_OUTPUT.PUT_LINE('CORREOS: ' || P_TO);
        v_log_app	:= 'PK_PPLA_TAREAS_AUTOMATICAS.SP_CALCULOPLANPRODUCCION';
         v_aux_tx2 := pk_commons.f_mesespanol(trim(to_char(to_date(substr(v_objeto,7,6),'yyyymm'),'Month')))||' '||substr(v_objeto,7,4);
                v_mensaje := '<html><head>
                                    <style type="text/css">body{font-family: Arial,Helvetica,sans-serif;
                                    font-size:10pt; margin:30px; background-color:#ffffff;}
                                    span.sig{font-style:italic;font-weight:bold;color:#811919;}}
                                    </style>
                                    </head><meta charset="UTF-8"><body>'||utl_tcp.crlf;

                v_mensaje := v_mensaje || '<p>Estimado Planificador,</p>'||utl_tcp.crlf;
                v_mensaje := v_mensaje || '<p>Se generó el Plan de Producción para su revisión y aprobación en el portal de APEX. '||utl_tcp.crlf;
                v_mensaje := v_mensaje || '<p><p><strong>Atentamente.</strong></p></p>'||utl_tcp.crlf;
                v_mensaje := v_mensaje || '<p><strong>PORTAL DE PLANIFICACION</strong>'||utl_tcp.crlf;

                v_mensaje := v_mensaje || '<p></p>'||utl_tcp.crlf;

                v_mensaje := v_mensaje || '</body>'||utl_tcp.crlf;
                v_mensaje := v_mensaje || '</html>'||utl_tcp.crlf;

                data.pk_commons.sp_apex_correohtml(v_mensaje,v_mensaje);
                v_cor_sub := 'PPLA - Plan de Producción ';
                data.pk_commons.sp_apex_correo(
                    p_aplicacion		=> v_log_app
                    , p_remitente		=> v_cor_rem
                    , p_para			=> P_to
                    , p_concopia		=> null--v_cor_rem
                    , p_concopiaoculta	=> null
                    , p_asunto			=> v_cor_sub
                    , p_contenido		=> v_mensaje
                );

        end if;

  END;

  END SP_CALCULOPLANPRODUCCION;

  /*
    Procediemnto que genera el plan de producción semanal, toma los datos del plan de producción mensual aprobado

    PK_PPLA_TAREAS_AUTOMATICAS.SP_CALCULOPLANPRODUCCIONSEMANAL(:G_COMPANIA, 'CLOPEZ');
  */

  PROCEDURE SP_CALCULOPLANPRODUCCIONSEMANAL(
             P_COMPANIA     IN VARCHAR2,
             P_PLANIFICADOR IN VARCHAR2)
     AS
        V_ANIO        NUMBER;-- := 2024;  -- Año específico
        V_DIA_INICIO  DATE;
        V_DIA_FIN    DATE;
        V_SEMANA_INICIAL NUMBER;
        V_SEMANA_FINAL NUMBER;
        V_FECHA       DATE  :=TRUNC(SYSDATE,'MM');

    BEGIN
        -- OBTENGO EL AÑO EN CURSO
        SELECT EXTRACT(YEAR FROM sysdate) into V_ANIO FROM dual;

        -- obtengo número de semana inicial y final
        SELECT
        TO_CHAR(trunc(sysdate,'mm'), 'IW'),TO_CHAR(last_day(sysdate), 'IW')
        INTO  V_SEMANA_INICIAL, V_SEMANA_FINAL
        FROM DUAL;

       -- creo por semana el plan de producción semanal
       FOR I IN V_SEMANA_INICIAL .. V_SEMANA_FINAL LOOP

            -- Calcular el primer día del año
            V_DIA_INICIO := TRUNC(TO_DATE(V_ANIO, 'YYYY'), 'YYYY') + (I - 1) * 7;

            -- Ajustar al lunes de esa semana (en caso de que el año comience en otro día)
            V_DIA_INICIO := NEXT_DAY(V_DIA_INICIO - 7, 'LUNES');

            -- Obtener el domingo de esa semana
            V_DIA_FIN := V_DIA_INICIO + 6;

            -- copio el plan de producción mensual a cada semana
            IF TO_CHAR(SYSDATE,'MM')= TO_CHAR(V_DIA_INICIO,'MM') THEN
                -- Mostrar los resultados
                --DBMS_OUTPUT.PUT_LINE('Semana ' || I || ' del año ' || V_ANIO || ':');
                --DBMS_OUTPUT.PUT_LINE('Inicio: ' || TO_CHAR(V_DIA_INICIO, 'DD-MON-YYYY'));
                --DBMS_OUTPUT.PUT_LINE('Fin: ' || TO_CHAR(V_DIA_FIN, 'DD-MON-YYYY'));

                INSERT INTO T_PPLA_PLANPRODUCCIONSEMANAL (ANIO,MES,SEMANA,FECHADESDE,FECHAHASTA,CODIGOPRODUCTO,CODIGOMAQUINA,
                       DEMANDA,TOTALUNIDADES,TOTAL,FECHA,ESTADO,PLANIFICADOR,COMPANIA)
                SELECT EXTRACT(YEAR FROM FECHA),EXTRACT(MONTH FROM FECHA),I,V_DIA_INICIO,V_DIA_FIN,CODIGOPRODUCTO,CODIGOMAQUINA,
                       DEMANDA,TOTALUNIDADES,TOTAL,SYSDATE,0,PLANIFICADOR,P_COMPANIA
                FROM T_PPLA_PLANPRODUCCION
                WHERE FECHA=TRUNC(SYSDATE,'MM') AND ESTADO=2 AND PLANIFICADOR=P_PLANIFICADOR;
            END IF;
        END LOOP;

  END SP_CALCULOPLANPRODUCCIONSEMANAL;

  /*
    Detecta productos con movimientos de las bodegas incluidas que aun no tienen
    parametro de Stock Ideal. La configuracion se copia solo desde un producto
    activo del mismo subtipo y se deja trazabilidad para el calculo posterior.
  */
  PROCEDURE SP_DETECTAR_NUEVOS_SKU_STOCKIDEAL(
    P_PERIODO NUMBER DEFAULT NULL,
    P_COMPANIA VARCHAR,
    P_USUARIO VARCHAR
  ) AS
      V_FECHA_CALCULO DATE := ADD_MONTHS(TO_DATE(NVL(P_PERIODO, TO_NUMBER(TO_CHAR(TRUNC(SYSDATE, 'MM'), 'YYYYMM'))) || '01', 'YYYYMMDD'), -1);
      V_PERIODO_MOVIMIENTO NUMBER;
      V_PERIODO_MOVIMIENTO_ANTERIOR NUMBER;
  BEGIN
      V_PERIODO_MOVIMIENTO := TO_NUMBER(TO_CHAR(V_FECHA_CALCULO, 'YYYYMM'));
      V_PERIODO_MOVIMIENTO_ANTERIOR := TO_NUMBER(TO_CHAR(ADD_MONTHS(V_FECHA_CALCULO, -1), 'YYYYMM'));

      FOR CANDIDATO IN (
          WITH MOVIMIENTOS AS (
              SELECT DISTINCT TRIM(MOV.CODIGOPRODUCTO) CODIGO_SKU
                FROM T_MANF_BISTOCKBODEGA MOV
               WHERE TRIM(MOV.CODIGOCOMPANIA) = TRIM(P_COMPANIA)
                 AND MOV.ANNO * 100 + MOV.MES IN (V_PERIODO_MOVIMIENTO, V_PERIODO_MOVIMIENTO_ANTERIOR)
                 AND TRIM(MOV.CODIGOBODEGA) IN ('17003', '17005', '17009', '17016', '17022')
                 AND UPPER(TRIM(MOV.TIPOSTOCK)) IN ('INGRESO', 'EGRESO', 'AJUSTES')
                 AND (NVL(MOV.STOCKUND, 0) <> 0 OR NVL(MOV.STOCKUSD, 0) <> 0)
          )
          SELECT TRIM(PROD.CODIGOPRODUCTO) CODIGO_SKU,
                 PROD.NOMBREPRODUCTO,
                 CASE WHEN UPPER(PROD.TEXTOBUSQUEDA) = 'MATERIA PRIMA' THEN 'MATERIA PRIMA' ELSE 'PRODUCTO TERMINADO' END TIPO_PRODUCTO,
                 CASE WHEN UPPER(PROD.TEXTOBUSQUEDA) = 'MATERIA PRIMA' THEN NVL(TRIM(PROD.CATPLANIFICACION), 'SIN CATEGORIA') ELSE NVL(TRIM(PROD.LINEANEGOCIO), 'SIN LINEA') END SUBTIPO
            FROM MOVIMIENTOS MOV
            JOIN VT_GZM_PRODUCTO MAESTRO
              ON TRIM(MAESTRO.CODIGOPRODUCTO) = MOV.CODIGO_SKU
            JOIN VT_JDE_PRODUCTOS PROD
              ON TRIM(PROD.COMPANIA) = TRIM(MAESTRO.COMPANIA)
             AND TRIM(PROD.CODIGOPRODUCTO) = TRIM(MAESTRO.CODIGOPRODUCTO)
           WHERE TRIM(MAESTRO.COMPANIA) = TRIM(P_COMPANIA)
             AND MAESTRO.ESTADO = 1
             AND TRIM(MAESTRO.CODIGOPRODUCTO) = TRIM(MAESTRO.CODIGOPRODUCTOPADRE)
             AND UPPER(MAESTRO.TEXTOBUSQUEDA) IN ('MATERIA PRIMA','TERMINADO')
             AND NOT EXISTS (
                 SELECT 1 FROM T_PPLA_STOCKIDEALPARAMETROS PARAM
                  WHERE PARAM.COMPANIA = TRIM(P_COMPANIA)
                    AND PARAM.ESTADO = 1
                    AND TRIM(PARAM.CODIGOPRODUCTO) = TRIM(PROD.CODIGOPRODUCTO)
             )
      ) LOOP
          DECLARE
              V_REFERENCIA T_PPLA_STOCKIDEALPARAMETROS%ROWTYPE;
              V_PUNTAJE NUMBER;
          BEGIN
              FOR REFERENCIA IN (
                    SELECT *
                      FROM (
                          SELECT PARAM.*
                            FROM T_PPLA_STOCKIDEALPARAMETROS PARAM
                            LEFT JOIN VT_JDE_PRODUCTOS PROD_REFERENCIA
                              ON TRIM(PROD_REFERENCIA.COMPANIA) = TRIM(P_COMPANIA)
                             AND TRIM(PROD_REFERENCIA.CODIGOPRODUCTO) = TRIM(PARAM.CODIGOPRODUCTO)
                           WHERE PARAM.COMPANIA = TRIM(P_COMPANIA)
                             AND PARAM.ESTADO = 1
                             AND PARAM.METODOCALCULO <> 'NO CONSIDERAR'
                             AND PARAM.TIPOPRODUCTO = CANDIDATO.TIPO_PRODUCTO
                             AND (CASE WHEN CANDIDATO.TIPO_PRODUCTO = 'MATERIA PRIMA'
                                       THEN CAST(NVL(TRIM(PARAM.CATEGORIAPLANIFICACION), 'SIN CATEGORIA') AS VARCHAR2(100))
                                       ELSE CAST(NVL(TRIM(PROD_REFERENCIA.LINEANEGOCIO), 'SIN LINEA') AS VARCHAR2(100)) END) = CAST(CANDIDATO.SUBTIPO AS VARCHAR2(100))
                           ORDER BY UTL_MATCH.JARO_WINKLER_SIMILARITY(UPPER(REGEXP_REPLACE(CANDIDATO.NOMBREPRODUCTO, '[^[:alnum:] ]', '')), UPPER(REGEXP_REPLACE(PARAM.DESCRIPCIONSKU, '[^[:alnum:] ]', ''))) DESC, PARAM.CODIGOPRODUCTO
                      )
                     WHERE ROWNUM = 1
                ) LOOP
                  V_REFERENCIA := REFERENCIA;
                  V_PUNTAJE := UTL_MATCH.JARO_WINKLER_SIMILARITY(UPPER(REGEXP_REPLACE(CANDIDATO.NOMBREPRODUCTO, '[^[:alnum:] ]', '')), UPPER(REGEXP_REPLACE(REFERENCIA.DESCRIPCIONSKU, '[^[:alnum:] ]', '')));
                  EXIT;
              END LOOP;

              IF V_REFERENCIA.IDPARAMETRO IS NULL THEN
                  CONTINUE;
              END IF;

              IF V_PUNTAJE < 90 THEN
                  CONTINUE;
              END IF;

              INSERT INTO T_PPLA_STOCKIDEALPARAMETROS (
                  TIPOPRODUCTO, CODIGOPRODUCTO, DESCRIPCIONSKU, CATEGORIAPLANIFICACION,
                  MINIMODIAS, MAXIMODIAS, METODOCALCULO, CODIGOSREEMPLAZO, SKUPRINCIPAL,
                  OBSERVACION, FECHACADUCIDAD, USUARIOCREACION, FECHACREACION, ESTADO, COMPANIA
              ) VALUES (
                  V_REFERENCIA.TIPOPRODUCTO, CANDIDATO.CODIGO_SKU, CANDIDATO.NOMBREPRODUCTO, V_REFERENCIA.CATEGORIAPLANIFICACION,
                  V_REFERENCIA.MINIMODIAS, V_REFERENCIA.MAXIMODIAS, V_REFERENCIA.METODOCALCULO, NULL, CANDIDATO.CODIGO_SKU,
                  V_REFERENCIA.OBSERVACION, V_REFERENCIA.FECHACADUCIDAD, P_USUARIO, SYSDATE, 1, TRIM(P_COMPANIA)
              );

              INSERT INTO T_PPLA_STOCKIDEAL_AUTO_SKU (
                  COMPANIA, CODIGO_SKU, CODIGO_SKU_REFERENCIA, ESTADO_ORIGEN, PUNTAJE_SIMILITUD, USUARIO_CREACION
              ) VALUES (
                  TRIM(P_COMPANIA), CANDIDATO.CODIGO_SKU, V_REFERENCIA.CODIGOPRODUCTO, 'AUTO', V_PUNTAJE, P_USUARIO
              );
          EXCEPTION
              WHEN NO_DATA_FOUND THEN NULL;
              WHEN DUP_VAL_ON_INDEX THEN NULL;
          END;
      END LOOP;
  END SP_DETECTAR_NUEVOS_SKU_STOCKIDEAL;

  PROCEDURE SP_CALCULARSTOCKIDEAL(
    P_PERIODO NUMBER,
    P_COMPANIA VARCHAR,
    P_USUARIO VARCHAR,
    P_ES_RECALCULO NUMBER DEFAULT 0
  )
  AS
      V_PERIODO NUMBER := P_PERIODO;
      V_PERIODO_ANTERIOR NUMBER;
      V_FECHA_CALCULO DATE;
      V_DIAS_PERIODO NUMBER;

      V_ANIO_ASOF_ANTERIOR NUMBER;
      V_MES_ASOF_ANTERIOR  NUMBER;

      V_DIA_INICIO_JDE NUMBER;
      V_DIA_FIN_JDE NUMBER;

      V_CODIGO_BODEGA_17001 VARCHAR2(12) := LPAD('17001', 12, ' ');
      V_CODIGO_BODEGA_17002 VARCHAR2(12) := LPAD('17002', 12, ' ');
      V_CODIGO_BODEGA_17003 VARCHAR2(12) := LPAD('17003', 12, ' ');
      V_CODIGO_BODEGA_17005 VARCHAR2(12) := LPAD('17005', 12, ' ');
      V_CODIGO_BODEGA_17009 VARCHAR2(12) := LPAD('17009', 12, ' ');
      V_CODIGO_BODEGA_17016 VARCHAR2(12) := LPAD('17016', 12, ' ');
      V_CODIGO_BODEGA_17022 VARCHAR2(12) := LPAD('17022', 12, ' ');
      V_CODIGO_BODEGA_17027 VARCHAR2(12) := LPAD('17027', 12, ' ');

    TYPE t_productos IS TABLE OF T_PPLA_STOCKIDEALPARAMETROS%ROWTYPE INDEX BY PLS_INTEGER;
    v_productos_tab t_productos;

    TYPE t_mov IS TABLE OF NUMBER INDEX BY PLS_INTEGER;
    TYPE t_bodega_mov IS TABLE OF t_mov INDEX BY VARCHAR2(30);

    v_mov_usd_bod   t_bodega_mov;
    v_mov_cant_bod  t_bodega_mov;

    TYPE t_flag_bodega IS TABLE OF BOOLEAN INDEX BY VARCHAR2(30);
    v_empezar_sumar_bod t_flag_bodega;

    TYPE t_num_bod IS TABLE OF NUMBER INDEX BY VARCHAR2(30);
    TYPE t_num_producto IS TABLE OF NUMBER INDEX BY VARCHAR2(30);

    V_STOCK_ACUMULADO_USD_BOD      t_num_bod;
    V_STOCK_ACUMULADO_CANT_BOD     t_num_bod;
    V_STOCK_USD_BOD                t_num_bod;
    V_STOCK_CANTIDAD_BOD           t_num_bod;

    V_STOCK_INICIAL_CANTIDAD_BOD   t_num_bod;
    V_STOCK_INICIAL_USD_BOD        t_num_bod;

    -- Los consumos se consultan una sola vez a JDE y se reutilizan por SKU.
    -- Esto conserva las reglas de bodegas/documentos del calculo historico y
    -- evita una consulta remota por cada parametro activo.
    V_CONSUMO_MP_USD                t_num_producto;
    V_CONSUMO_PT_USD                t_num_producto;

    V_DIA_ACTUAL NUMBER;
    V_CALC_PROG_MES_ACTUAL NUMBER DEFAULT 0;

  BEGIN

    IF V_PERIODO IS NULL THEN
        V_PERIODO := TO_NUMBER(TO_CHAR(TRUNC(SYSDATE,'MM'), 'YYYYMM'));
    END IF;

    V_DIA_ACTUAL := EXTRACT(DAY FROM SYSDATE);

    IF V_DIA_ACTUAL <> 1 AND TO_NUMBER(TO_CHAR(TRUNC(SYSDATE,'MM'), 'YYYYMM')) = V_PERIODO THEN
        V_CALC_PROG_MES_ACTUAL := 1;
    END IF;

    -- Si tengo que calcular el progreso del mes actual, aumento 1 mes el periodo que guarda los datos
    IF P_ES_RECALCULO = 0 AND V_CALC_PROG_MES_ACTUAL = 1 THEN
        V_PERIODO := TO_NUMBER(TO_CHAR(ADD_MONTHS(TRUNC(TO_DATE(V_PERIODO, 'YYYYMM'),'MM'), 1), 'YYYYMM'));
    END IF;

    -- Incorporar primero los nuevos SKU; la formula posterior conserva su comportamiento vigente.
    SP_DETECTAR_NUEVOS_SKU_STOCKIDEAL(V_PERIODO, P_COMPANIA, P_USUARIO);

    V_FECHA_CALCULO := ADD_MONTHS(TO_DATE(V_PERIODO||'01','YYYYMMDD'), -1); -- Mes anterior para movimientos de kardex

    V_PERIODO_ANTERIOR := TO_NUMBER(TO_CHAR(V_FECHA_CALCULO, 'YYYYMM')); --Unicamente para guardar de donde se tomaron los datos

    V_ANIO_ASOF_ANTERIOR := EXTRACT(YEAR FROM ADD_MONTHS(V_FECHA_CALCULO, -1)); -- Para el cierre del mes anterior al de los movimientos de kardex
    V_MES_ASOF_ANTERIOR := EXTRACT(MONTH FROM ADD_MONTHS(V_FECHA_CALCULO, -1));

    -- Precalcular fechas JDE
    V_DIA_INICIO_JDE := TO_NUMBER(TO_CHAR(V_FECHA_CALCULO, 'YYYYDDD')) - 1900000;
    V_DIA_FIN_JDE := TO_NUMBER(TO_CHAR(LAST_DAY(V_FECHA_CALCULO), 'YYYYDDD')) - 1900000;

    V_DIAS_PERIODO := EXTRACT(DAY FROM LAST_DAY(V_FECHA_CALCULO));

    -- si no 1 de cada mes, toma el dia actual como límite, solo para el actual (y debe cumplir que sea el mes en curso)
    -- Si no es el primer dia del mes y estoy calculando el mes en curso,
    -- entonces aumento un mes mas al periodo a calcular para tomar el mes anterior al actual como referencia para movimientos de kardex,
    -- pero con fecha de corte el dia actual, esto para que el planificador tenga datos mas actualizados si corre el proceso durante el mes en curso
    IF P_ES_RECALCULO = 0 AND V_CALC_PROG_MES_ACTUAL = 1 THEN
        V_DIAS_PERIODO := V_DIA_ACTUAL;
        V_DIA_FIN_JDE := TO_NUMBER(TO_CHAR(V_FECHA_CALCULO, 'YYYYDDD')) - 1900000 + V_DIA_ACTUAL - 1;
    END IF;

    -- Eliminar datos anteriores
    DELETE FROM T_PPLA_STOCKIDEAL WHERE COMPANIA = P_COMPANIA AND PERIODO = V_PERIODO;

    --RAISE_APPLICATION_ERROR(-20001, 'The '||V_MES_ASOF_ANTERIOR);

    SELECT *
    BULK COLLECT INTO v_productos_tab
    FROM T_PPLA_STOCKIDEALPARAMETROS
    WHERE ESTADO = 1
      AND (COMPANIA = P_COMPANIA)
      AND METODOCALCULO <> 'NO CONSIDERAR'
      --AND TIPOPRODUCTO = 'PRODUCTO TERMINADO'
      --AND CODIGOPRODUCTO = '634005251'
      --AND IDPARAMETRO = 2280
    ORDER BY COMPANIA;

    DECLARE
        TYPE T_CODIGOS_CONSUMO IS TABLE OF VARCHAR2(30) INDEX BY PLS_INTEGER;
        TYPE T_CODIGOS_VISTOS IS TABLE OF BOOLEAN INDEX BY VARCHAR2(30);
        V_CODIGOS       T_CODIGOS_CONSUMO;
        V_VISTOS        T_CODIGOS_VISTOS;
        V_TOTAL_CODIGOS PLS_INTEGER := 0;
        V_DESDE         PLS_INTEGER := 1;
        V_HASTA         PLS_INTEGER;
        V_LISTA_SQL     VARCHAR2(32767);
        V_SQL_CONSUMO   VARCHAR2(32767);
        V_CURSOR        SYS_REFCURSOR;
        V_CODIGO        VARCHAR2(30);
        V_CONSUMO_MP    NUMBER;
        V_CONSUMO_PT    NUMBER;
    BEGIN
        -- Se expanden y deduplican los codigos normales y de reemplazo.
        FOR IDX_PARAMETRO IN 1..V_PRODUCTOS_TAB.COUNT LOOP
            FOR REC_CODIGO IN (
                SELECT TRIM(REGEXP_SUBSTR(
                           V_PRODUCTOS_TAB(IDX_PARAMETRO).CODIGOPRODUCTO,
                           '[^,]+', 1, LEVEL)) CODIGO
                  FROM DUAL
                CONNECT BY REGEXP_SUBSTR(
                           V_PRODUCTOS_TAB(IDX_PARAMETRO).CODIGOPRODUCTO,
                           '[^,]+', 1, LEVEL) IS NOT NULL
            ) LOOP
                IF REC_CODIGO.CODIGO IS NOT NULL
                   AND NOT V_VISTOS.EXISTS(REC_CODIGO.CODIGO) THEN
                    V_TOTAL_CODIGOS := V_TOTAL_CODIGOS + 1;
                    V_CODIGOS(V_TOTAL_CODIGOS) := REC_CODIGO.CODIGO;
                    V_VISTOS(REC_CODIGO.CODIGO) := TRUE;
                END IF;
            END LOOP;
        END LOOP;

        -- Lotes acotados permiten que JDE use la lista de articulos y evitan
        -- tanto una consulta por SKU como un escaneo agrupado de todo el mes.
        WHILE V_DESDE <= V_TOTAL_CODIGOS LOOP
            V_HASTA := LEAST(V_DESDE + 99, V_TOTAL_CODIGOS);
            V_LISTA_SQL := NULL;

            FOR IDX_CODIGO IN V_DESDE..V_HASTA LOOP
                IF V_LISTA_SQL IS NOT NULL THEN
                    V_LISTA_SQL := V_LISTA_SQL || ',';
                END IF;
                V_LISTA_SQL := V_LISTA_SQL ||
                    DBMS_ASSERT.ENQUOTE_LITERAL(RPAD(V_CODIGOS(IDX_CODIGO), 25, ' '));
            END LOOP;

            V_SQL_CONSUMO :=
                'SELECT TRIM(ILLITM), ' ||
                'SUM(CASE WHEN ILMCU IN (' ||
                'LPAD(''17005'',12,'' ''),LPAD(''17009'',12,'' ''),' ||
                'LPAD(''17016'',12,'' ''),LPAD(''17022'',12,'' '')) ' ||
                'AND ILDCT IN (''IM'',''IG'',''I9'') THEN ILPAID/100 ELSE 0 END), ' ||
                'SUM(CASE WHEN ILMCU IN (' ||
                'LPAD(''17003'',12,'' ''),LPAD(''17022'',12,'' '')) ' ||
                'AND ILDCT IN (''FN'',''FE'',''IM'',''I9'') THEN ILPAID/100 ELSE 0 END) ' ||
                'FROM F4111@JDEDTADL ' ||
                'WHERE ILTRDJ BETWEEN :P_DIA_INICIO_1 AND :P_DIA_FIN_1 ' ||
                'AND ILCRDJ BETWEEN :P_DIA_INICIO_2 AND :P_DIA_FIN_2 ' ||
                'AND ((ILMCU IN (' ||
                'LPAD(''17005'',12,'' ''),LPAD(''17009'',12,'' ''),' ||
                'LPAD(''17016'',12,'' ''),LPAD(''17022'',12,'' '')) ' ||
                'AND ILDCT IN (''IM'',''IG'',''I9'')) OR ' ||
                '(ILMCU IN (LPAD(''17003'',12,'' ''),LPAD(''17022'',12,'' '')) ' ||
                'AND ILDCT IN (''FN'',''FE'',''IM'',''I9''))) ' ||
                'AND ILLITM IN (' || V_LISTA_SQL || ') ' ||
                'GROUP BY TRIM(ILLITM)';

            BEGIN
                OPEN V_CURSOR FOR V_SQL_CONSUMO
                    USING V_DIA_INICIO_JDE, V_DIA_FIN_JDE,
                          V_DIA_INICIO_JDE, V_DIA_FIN_JDE;
                LOOP
                    FETCH V_CURSOR INTO V_CODIGO, V_CONSUMO_MP, V_CONSUMO_PT;
                    EXIT WHEN V_CURSOR%NOTFOUND;
                    V_CONSUMO_MP_USD(V_CODIGO) := NVL(V_CONSUMO_MP, 0);
                    V_CONSUMO_PT_USD(V_CODIGO) := NVL(V_CONSUMO_PT, 0);
                END LOOP;
                CLOSE V_CURSOR;
            EXCEPTION
                WHEN OTHERS THEN
                    IF V_CURSOR%ISOPEN THEN
                        CLOSE V_CURSOR;
                    END IF;
                    RAISE;
            END;

            V_DESDE := V_HASTA + 1;
        END LOOP;
    END;

    -- Procesar productos
    FOR i IN 1..v_productos_tab.COUNT LOOP
        DECLARE
            V_CODIGO_PRODUCTO VARCHAR2(4000);
            V_STOCK_ACUMULADO_USD NUMBER := 0;
            V_STOCK_ACUMULADO_CANTIDAD NUMBER := 0;
            V_STOCK_USD NUMBER := 0;
            V_STOCK_CANTIDAD NUMBER := 0;
            V_SUMA_CONSUMO_USD NUMBER := 0;
            V_PROMEDIO_INVENTARIADO_USD NUMBER;
            V_PROMEDIO_INVENTARIADO_CANTIDAD NUMBER;
            V_CONSUMO_PROMEDIO_USD NUMBER;
            V_STOCK_MINIMO_USD NUMBER := 0;
            V_STOCK_MAXIMO_USD NUMBER := 0;

            TYPE t_set_producto IS TABLE OF BOOLEAN INDEX BY VARCHAR2(30);
            v_productos_movidos t_set_producto;
            v_cant_productos_movidos NUMBER := 0;

            V_IDX_BODEGA VARCHAR2(30);
            V_INICIAL_USD NUMBER := 0;

            V_productos_movidos_concat varchar(150) := '';

        BEGIN
            IF v_productos_tab(i).METODOCALCULO = 'REEMPLAZO' THEN
                -- Formatear cada código de la lista separada por comas
                SELECT LISTAGG(RPAD(TRIM(codigo), 25, ' '), ',') WITHIN GROUP (ORDER BY NULL)
                INTO V_CODIGO_PRODUCTO
                FROM (
                    SELECT REGEXP_SUBSTR(v_productos_tab(i).CODIGOPRODUCTO, '[^,]+', 1, LEVEL) AS codigo
                    FROM dual
                    CONNECT BY LEVEL <= REGEXP_COUNT(v_productos_tab(i).CODIGOPRODUCTO, '[^,]+')
                );
            ELSE
                V_CODIGO_PRODUCTO := RPAD(v_productos_tab(i).CODIGOPRODUCTO, 25, ' ');
            END IF;

            --Cálculo de stocks iniciales
            BEGIN
                V_STOCK_INICIAL_CANTIDAD_BOD.DELETE;
                V_STOCK_INICIAL_USD_BOD.DELETE;

                FOR r IN (
                    SELECT
                        inmcu AS bodega,
                        inlitm AS producto,
                        SUM(NVL(cantidad, 0) / 10000) AS stock_inicial_cantidad,
                        SUM(NVL(valor, 0) / 100)     AS stock_inicial_usd
                    FROM (
                        SELECT
                            TRIM(inmcu) inmcu,
                            cantidad,
                            valor,
                            TRIM(inlitm) inlitm
                        FROM (
                            WITH PRODUCTOS_E AS (
                                SELECT REGEXP_SUBSTR(V_CODIGO_PRODUCTO, '[^,]+', 1, LEVEL) AS CODIGO
                                FROM dual
                                CONNECT BY REGEXP_SUBSTR(V_CODIGO_PRODUCTO, '[^,]+', 1, LEVEL) IS NOT NULL
                            )
                            SELECT
                                inmcu,
                                incmqt, innq01, innq02, innq03, innq04, innq05,
                                innq06, innq07, innq08, innq09, innq10, innq11, innq12,
                                incuma, inan01, inan02, inan03, inan04, inan05,
                                inan06, inan07, inan08, inan09, inan10, inan11, inan12,
                                inlitm
                            FROM f41112@JDEDTADL CK
                            INNER JOIN PRODUCTOS_E PE ON PE.CODIGO = CK.inlitm
                            WHERE (inmcu) IN (
                                V_CODIGO_BODEGA_17001,
                                V_CODIGO_BODEGA_17002,
                                V_CODIGO_BODEGA_17003,
                                V_CODIGO_BODEGA_17005,
                                V_CODIGO_BODEGA_17009,
                                V_CODIGO_BODEGA_17016,
                                V_CODIGO_BODEGA_17022,
                                V_CODIGO_BODEGA_17027
                                )
                              AND inctry || infy = TO_CHAR(V_ANIO_ASOF_ANTERIOR)
                        )
                        UNPIVOT (
                            (cantidad, valor) FOR mes IN (
                                (incmqt, incuma) AS 0,
                                (innq01, inan01) AS 1,
                                (innq02, inan02) AS 2,
                                (innq03, inan03) AS 3,
                                (innq04, inan04) AS 4,
                                (innq05, inan05) AS 5,
                                (innq06, inan06) AS 6,
                                (innq07, inan07) AS 7,
                                (innq08, inan08) AS 8,
                                (innq09, inan09) AS 9,
                                (innq10, inan10) AS 10,
                                (innq11, inan11) AS 11,
                                (innq12, inan12) AS 12
                            )
                        )
                        WHERE mes <= V_MES_ASOF_ANTERIOR --AND cantidad <> 0 --and valor <> 0
                    )
                    GROUP BY inmcu, inlitm
                    HAVING SUM(NVL(cantidad, 0) / 10000) > 0

                ) LOOP
                    V_STOCK_INICIAL_CANTIDAD_BOD(r.bodega|| '|' || r.producto) := r.stock_inicial_cantidad;
                    V_STOCK_INICIAL_USD_BOD(r.bodega|| '|' || r.producto)  := r.stock_inicial_usd;
                END LOOP;
            EXCEPTION
                WHEN OTHERS THEN
                    RAISE_APPLICATION_ERROR(-20002, 'Error cargando Stoks de Cierre Anterior');
            END;

            V_IDX_BODEGA := V_STOCK_INICIAL_USD_BOD.FIRST;
            WHILE V_IDX_BODEGA IS NOT NULL LOOP
                V_INICIAL_USD := NVL(V_INICIAL_USD, 0) + NVL(V_STOCK_INICIAL_USD_BOD(V_IDX_BODEGA), 0);
                V_IDX_BODEGA := V_STOCK_INICIAL_USD_BOD.NEXT(V_IDX_BODEGA);
            END LOOP;

            -- Limpiar collections
            v_mov_usd_bod.DELETE;
            v_mov_cant_bod.DELETE;

            v_empezar_sumar_bod.DELETE;
            V_STOCK_ACUMULADO_USD_BOD.DELETE;
            V_STOCK_ACUMULADO_CANT_BOD.DELETE;
            V_STOCK_USD_BOD.DELETE;
            V_STOCK_CANTIDAD_BOD.DELETE;

            DECLARE

                v_key  VARCHAR2(100);

            BEGIN

            -- Obtener movimientos diarios y asignarlos a su día correspondiente
            IF v_productos_tab(i).TIPOPRODUCTO = 'MATERIA PRIMA' THEN
                FOR mov IN (
                    WITH PRODUCTOS_E AS (
                        SELECT REGEXP_SUBSTR(V_CODIGO_PRODUCTO, '[^,]+', 1, LEVEL) AS CODIGO
                        FROM dual
                        CONNECT BY REGEXP_SUBSTR(V_CODIGO_PRODUCTO, '[^,]+', 1, LEVEL) IS NOT NULL
                    ),
                    TRANSFORMACION AS (
                         SELECT
                            im.imlitm      AS CODIGOPRODUCTO,
                            im.imuom1      AS UNIDADPRINCIPAL,
                            um.umum        AS UNIDADDESTINO,
                            um.umconv / 10000000 AS FACTOR_C
                        FROM f4101@jdedtadl im
                        JOIN f41002@jdedtadl um
                            ON um.umitm = im.imitm
                            AND um.umrum = im.imuom1
                        JOIN PRODUCTOS_E P
                            ON P.CODIGO = im.imlitm
                    ),
                    DatosBase AS (
                    SELECT
                        EXTRACT(DAY FROM TO_DATE(TO_CHAR(KDE.ILCRDJ + 1900000), 'YYYYDDD')) AS dia,
                        SUM(KDE.ILPAID/100) AS usd,
                        SUM((KDE.ILTRQT/10000) *(NVL(TRA.FACTOR_C,1))) AS cantidad,
                        TRIM(KDE.ILMCU) BODEGA,
                        TRIM(KDE.ILLITM) PRODUCTO,
                        SUM(SUM(KDE.ILPAID/100)) OVER (PARTITION BY TRIM(KDE.ILMCU), TRIM(KDE.ILLITM)) AS total_usd_bodega_prod
                    FROM F4111@jdedtadl KDE
                    JOIN PRODUCTOS_E P ON P.CODIGO = KDE.ILLITM
                    LEFT JOIN TRANSFORMACION TRA ON TRA.CODIGOPRODUCTO = KDE.ILLITM AND TRA.UNIDADDESTINO = KDE.ILTRUM
                    WHERE
                    (KDE.ILMCU) IN (
                        V_CODIGO_BODEGA_17001,
                        V_CODIGO_BODEGA_17002,
                        V_CODIGO_BODEGA_17003,
                        V_CODIGO_BODEGA_17005,
                        V_CODIGO_BODEGA_17009,
                        V_CODIGO_BODEGA_17016,
                        V_CODIGO_BODEGA_17022,
                        V_CODIGO_BODEGA_17027
                    )
                    AND KDE.ILTRDJ BETWEEN V_DIA_INICIO_JDE AND V_DIA_FIN_JDE
                    AND KDE.ILCRDJ BETWEEN V_DIA_INICIO_JDE AND V_DIA_FIN_JDE
                    --AND ILPAID <> 0 AND KDE.ILTRQT <> 0
                    GROUP BY KDE.ILMCU,KDE.ILLITM,KDE.ILCRDJ
                    ORDER BY ILCRDJ
                    )
                    SELECT 
                        dia,
                        usd,
                        cantidad,
                        BODEGA,
                        PRODUCTO
                    FROM DatosBase
                    WHERE NOT (total_usd_bodega_prod = 0 AND BODEGA IN ('17005', '17009', '17016', '17022'))
                    ORDER BY dia
                ) LOOP
                    v_key := mov.bodega||'|'||mov.producto;

                    --ACTUALIZO LA CANTIDAD DE PRODUCTOS, ESTO SE UTLIZA CUANDO ES REEMPLAZO
                    --YA QUE NO SIEMPRE TODOS LOS PRODUCTOS DE REEMPLAZO TIENEN MOVIMIENTOS
                    --Y ENTONCES NO SE PUEDE UTLIZAR UN CONTEO DE LOS PRODUCTOS DE REEMPLAZO DESDE LA TABLA T_PPLA_STOCKIDEALPARAMETROS
                    IF NOT v_productos_movidos.EXISTS(mov.producto) THEN
                        v_productos_movidos(mov.producto) := TRUE;
                        v_cant_productos_movidos := v_cant_productos_movidos + 1;
                        IF V_productos_movidos_concat IS NULL THEN
                            V_productos_movidos_concat := mov.producto;
                        ELSE
                            V_productos_movidos_concat := V_productos_movidos_concat||','||mov.producto;
                        END IF;
                    END IF;

                    IF NOT v_mov_usd_bod.EXISTS(v_key) THEN
                        FOR d IN 1..V_DIAS_PERIODO LOOP
                            v_mov_usd_bod(v_key)(d)  := 0;
                            v_mov_cant_bod(v_key)(d) := 0;
                        END LOOP;

                        v_empezar_sumar_bod(v_key) := FALSE;

                        IF V_STOCK_INICIAL_USD_BOD.EXISTS(v_key) THEN
                            V_STOCK_ACUMULADO_USD_BOD(v_key)  := NVL(V_STOCK_INICIAL_USD_BOD(v_key), 0);
                            V_STOCK_ACUMULADO_CANT_BOD(v_key) := NVL(V_STOCK_INICIAL_CANTIDAD_BOD(v_key), 0);
                        ELSE
                            V_STOCK_ACUMULADO_USD_BOD(v_key) := 0;
                            V_STOCK_ACUMULADO_CANT_BOD(v_key) := 0;
                        END IF;

                        V_STOCK_USD_BOD(v_key)            := 0;
                        V_STOCK_CANTIDAD_BOD(v_key)       := 0;
                    END IF;
                    BEGIN
                        v_mov_usd_bod(v_key)(mov.dia) :=
                            NVL(v_mov_usd_bod(v_key)(mov.dia), 0) + NVL(mov.usd, 0);
                    EXCEPTION
                        WHEN OTHERS THEN
                            RAISE_APPLICATION_ERROR(-20002, 'Error cargando v_mov_usd_bod(v_key)(mov.dia): '||v_key||
                            ' '||mov.dia||' '||' '||v_productos_tab(i).CODIGOPRODUCTO);
                    END;

                    v_mov_cant_bod(v_key)(mov.dia) :=
                        NVL(v_mov_cant_bod(v_key)(mov.dia), 0) + NVL(mov.cantidad, 0);

                END LOOP;

            ELSE

                FOR mov IN (
                    WITH PRODUCTOS_E AS (
                        SELECT REGEXP_SUBSTR(V_CODIGO_PRODUCTO, '[^,]+', 1, LEVEL) AS CODIGO
                        FROM dual
                        CONNECT BY REGEXP_SUBSTR(V_CODIGO_PRODUCTO, '[^,]+', 1, LEVEL) IS NOT NULL
                    ),
                    TRANSFORMACION AS (
                         SELECT
                            im.imlitm      AS CODIGOPRODUCTO,
                            im.imuom1      AS UNIDADPRINCIPAL,
                            um.umum        AS UNIDADDESTINO,
                            um.umconv / 10000000 AS FACTOR_C
                        FROM f4101@jdedtadl im
                        JOIN f41002@jdedtadl um
                            ON um.umitm = im.imitm
                            AND um.umrum = im.imuom1
                        JOIN PRODUCTOS_E P
                            ON P.CODIGO = im.imlitm
                    )
                    SELECT
                        EXTRACT(DAY FROM TO_DATE(TO_CHAR(KDE.ILCRDJ + 1900000), 'YYYYDDD')) AS dia,
                        SUM(KDE.ILPAID/100) AS usd,
                        SUM((KDE.ILTRQT/10000) *(NVL(TRA.FACTOR_C,1))) AS cantidad,
                        TRIM(KDE.ILMCU) BODEGA,
                        TRIM(KDE.ILLITM) PRODUCTO
                    FROM F4111@jdedtadl KDE
                    JOIN PRODUCTOS_E P ON P.CODIGO = KDE.ILLITM
                    LEFT JOIN TRANSFORMACION TRA ON TRA.CODIGOPRODUCTO = KDE.ILLITM AND TRA.UNIDADDESTINO = KDE.ILTRUM
                    WHERE
                    (KDE.ILMCU) IN (
                        -- V_CODIGO_BODEGA_17001,
                        V_CODIGO_BODEGA_17002,
                        V_CODIGO_BODEGA_17003,
                        V_CODIGO_BODEGA_17005,
                        V_CODIGO_BODEGA_17009,
                        -V_CODIGO_BODEGA_17016--,
                        -- V_CODIGO_BODEGA_17022,
                        -- V_CODIGO_BODEGA_17027
                    )
                    AND KDE.ILTRDJ BETWEEN V_DIA_INICIO_JDE AND V_DIA_FIN_JDE
                    AND KDE.ILCRDJ BETWEEN V_DIA_INICIO_JDE AND V_DIA_FIN_JDE
                    --AND ILPAID <> 0 AND KDE.ILTRQT <> 0
                    GROUP BY KDE.ILMCU,KDE.ILLITM,KDE.ILCRDJ
                    ORDER BY ILCRDJ
                ) LOOP
                    v_key := mov.bodega||'|'||mov.producto;

                    --ACTUALIZO LA CANTIDAD DE PRODUCTOS, ESTO SE UTLIZA CUANDO ES REEMPLAZO
                    --YA QUE NO SIEMPRE TODOS LOS PRODUCTOS DE REEMPLAZO TIENEN MOVIMIENTOS
                    --Y ENTONCES NO SE PUEDE UTLIZAR UN CONTEO DE LOS PRODUCTOS DE REEMPLAZO DESDE LA TABLA T_PPLA_STOCKIDEALPARAMETROS
                    IF NOT v_productos_movidos.EXISTS(mov.producto) THEN
                        v_productos_movidos(mov.producto) := TRUE;
                        v_cant_productos_movidos := v_cant_productos_movidos + 1;
                        IF V_productos_movidos_concat IS NULL THEN
                            V_productos_movidos_concat := mov.producto;
                        ELSE
                            V_productos_movidos_concat := V_productos_movidos_concat||','||mov.producto;
                        END IF;
                    END IF;

                    IF NOT v_mov_usd_bod.EXISTS(v_key) THEN
                        FOR d IN 1..V_DIAS_PERIODO LOOP
                            v_mov_usd_bod(v_key)(d)  := 0;
                            v_mov_cant_bod(v_key)(d) := 0;
                        END LOOP;

                        v_empezar_sumar_bod(v_key) := FALSE;

                        IF V_STOCK_INICIAL_USD_BOD.EXISTS(v_key) THEN
                            V_STOCK_ACUMULADO_USD_BOD(v_key)  := NVL(V_STOCK_INICIAL_USD_BOD(v_key), 0);
                            V_STOCK_ACUMULADO_CANT_BOD(v_key) := NVL(V_STOCK_INICIAL_CANTIDAD_BOD(v_key), 0);
                        ELSE
                            V_STOCK_ACUMULADO_USD_BOD(v_key) := 0;
                            V_STOCK_ACUMULADO_CANT_BOD(v_key) := 0;
                        END IF;

                        V_STOCK_USD_BOD(v_key)            := 0;
                        V_STOCK_CANTIDAD_BOD(v_key)       := 0;
                    END IF;
                    BEGIN
                        v_mov_usd_bod(v_key)(mov.dia) :=
                            NVL(v_mov_usd_bod(v_key)(mov.dia), 0) + NVL(mov.usd, 0);
                    EXCEPTION
                        WHEN OTHERS THEN
                            RAISE_APPLICATION_ERROR(-20002, 'Error cargando v_mov_usd_bod(v_key)(mov.dia): '||v_key||
                            ' '||mov.dia||' '||' '||v_productos_tab(i).CODIGOPRODUCTO);
                    END;

                    v_mov_cant_bod(v_key)(mov.dia) :=
                        NVL(v_mov_cant_bod(v_key)(mov.dia), 0) + NVL(mov.cantidad, 0);

                END LOOP;

            END IF;

            -- EXCEPTION
            --     WHEN OTHERS THEN
            --         RAISE;
            END;


            -- SUMAR LOS STOCK DE CADA BODEGA
            DECLARE
                bod VARCHAR2(100);
            BEGIN
                bod := v_mov_usd_bod.FIRST;  -- inicializa con la primera bodega

                WHILE bod IS NOT NULL LOOP

                    FOR d IN 1..V_DIAS_PERIODO LOOP

                        IF NOT v_empezar_sumar_bod(bod) AND NVL(v_mov_usd_bod(bod)(d), 0) <> 0 THEN
                            v_empezar_sumar_bod(bod) := TRUE;
                        END IF;

                        IF v_empezar_sumar_bod(bod) THEN
                            V_STOCK_ACUMULADO_USD_BOD(bod) :=
                                V_STOCK_ACUMULADO_USD_BOD(bod) + NVL(v_mov_usd_bod(bod)(d), 0);

                            V_STOCK_ACUMULADO_CANT_BOD(bod) :=
                                V_STOCK_ACUMULADO_CANT_BOD(bod) + NVL(v_mov_cant_bod(bod)(d), 0);

                            V_STOCK_USD_BOD(bod) :=
                                V_STOCK_USD_BOD(bod) + V_STOCK_ACUMULADO_USD_BOD(bod);

                            V_STOCK_CANTIDAD_BOD(bod) :=
                                V_STOCK_CANTIDAD_BOD(bod) + V_STOCK_ACUMULADO_CANT_BOD(bod);
                        END IF;

                    END LOOP;

                    bod := v_mov_usd_bod.NEXT(bod);  -- pasa a la siguiente bodega existente
                END LOOP;
            END;


            DECLARE
                bod VARCHAR2(100);
            BEGIN
                bod := V_STOCK_USD_BOD.FIRST;
                WHILE bod IS NOT NULL LOOP
                    V_STOCK_ACUMULADO_USD       := V_STOCK_ACUMULADO_USD       + V_STOCK_USD_BOD(bod);
                    V_STOCK_ACUMULADO_CANTIDAD  := V_STOCK_ACUMULADO_CANTIDAD  + V_STOCK_CANTIDAD_BOD(bod);
                    bod := V_STOCK_USD_BOD.NEXT(bod);  -- pasa a la siguiente bodega
                END LOOP;
            END;

            -- Consumos del período precargados desde JDE.
            FOR REC_CONSUMO_PRODUCTO IN (
                SELECT TRIM(REGEXP_SUBSTR(V_CODIGO_PRODUCTO, '[^,]+', 1, LEVEL)) CODIGO
                  FROM DUAL
                CONNECT BY REGEXP_SUBSTR(V_CODIGO_PRODUCTO, '[^,]+', 1, LEVEL) IS NOT NULL
            ) LOOP
                IF v_productos_tab(i).TIPOPRODUCTO = 'MATERIA PRIMA' THEN
                    IF V_CONSUMO_MP_USD.EXISTS(REC_CONSUMO_PRODUCTO.CODIGO) THEN
                        V_SUMA_CONSUMO_USD := V_SUMA_CONSUMO_USD
                            + V_CONSUMO_MP_USD(REC_CONSUMO_PRODUCTO.CODIGO);
                    END IF;
                ELSIF V_CONSUMO_PT_USD.EXISTS(REC_CONSUMO_PRODUCTO.CODIGO) THEN
                    V_SUMA_CONSUMO_USD := V_SUMA_CONSUMO_USD
                        + V_CONSUMO_PT_USD(REC_CONSUMO_PRODUCTO.CODIGO);
                END IF;
            END LOOP;

            BEGIN
                IF v_productos_tab(i).METODOCALCULO = 'REEMPLAZO' THEN
                    -- Cálculos finales - El promedio es la suma acumulada / días
                    IF v_cant_productos_movidos = 0 THEN
                        CONTINUE;
                    END IF;
                    V_PROMEDIO_INVENTARIADO_USD := (V_STOCK_ACUMULADO_USD / V_DIAS_PERIODO)/v_cant_productos_movidos;
                    V_PROMEDIO_INVENTARIADO_CANTIDAD := (V_STOCK_ACUMULADO_CANTIDAD / V_DIAS_PERIODO)/v_cant_productos_movidos;
                    V_INICIAL_USD := V_INICIAL_USD/v_cant_productos_movidos;
                ELSE
                    -- Cálculos finales - El promedio es la suma acumulada / días
                    V_PROMEDIO_INVENTARIADO_USD := V_STOCK_ACUMULADO_USD / V_DIAS_PERIODO;
                    V_PROMEDIO_INVENTARIADO_CANTIDAD := V_STOCK_ACUMULADO_CANTIDAD / V_DIAS_PERIODO;
                END IF;
            EXCEPTION
                WHEN OTHERS THEN
                    RAISE_APPLICATION_ERROR(-20002, 'Error cargando'||V_CODIGO_PRODUCTO);
            END;

            IF v_productos_tab(i).METODOCALCULO = 'REEMPLAZO' THEN
                V_CONSUMO_PROMEDIO_USD := (ABS(NVL(V_SUMA_CONSUMO_USD,0)) / V_DIAS_PERIODO)/ v_cant_productos_movidos;
            ELSE
                V_CONSUMO_PROMEDIO_USD := ABS(NVL(V_SUMA_CONSUMO_USD,0)) / V_DIAS_PERIODO;
            END IF;

            IF v_productos_tab(i).METODOCALCULO <> 'AGOTAMIENTO' THEN
                V_STOCK_MINIMO_USD := V_CONSUMO_PROMEDIO_USD * v_productos_tab(i).MINIMODIAS;
            END IF;

            V_STOCK_MAXIMO_USD := V_CONSUMO_PROMEDIO_USD * v_productos_tab(i).MAXIMODIAS;

            DECLARE
                V_COSTOSTANDARD NUMBER;
            BEGIN

            FOR REC IN (
                SELECT REGEXP_SUBSTR(NVL(V_productos_movidos_concat,V_CODIGO_PRODUCTO), '[^,]+', 1, LEVEL) AS CODIGO,LEVEL NIVEL
                FROM dual
                CONNECT BY REGEXP_SUBSTR(NVL(V_productos_movidos_concat,V_CODIGO_PRODUCTO), '[^,]+', 1, LEVEL) IS NOT NULL
                ORDER BY LEVEL DESC
            ) LOOP

                BEGIN

                -- IF v_cant_productos_movidos <> 1 AND REC.NIVEL = 1 THEN
                --     CONTINUE;
                -- END IF;

                SELECT
                    COSTOSTANDARD
                INTO
                    V_COSTOSTANDARD
                FROM T_PPLA_PRODUCTOS_COSTO_STANDARD
                WHERE COMPANIA = P_COMPANIA
                    AND FECHAHASTA > SYSDATE
                    AND TRIM(CODIGOPRODUCTO) = TRIM(REC.CODIGO)
                ;
                EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                        V_COSTOSTANDARD := 0;
                    WHEN OTHERS THEN
                        RAISE_APPLICATION_ERROR(-20002, 'Error obteniendo costo standard de producto ' || REC.CODIGO);
                END;

                INSERT INTO T_PPLA_STOCKIDEAL (
                    PERIODO,TIPOPRODUCTO,CODIGOSKU,DESCRIPCIONSKU,CATEGORIAPLANIFICACION,
                    PROMEDIOINVENTARIOUSD,PROMEDIOINVENTARIOCANTIDAD,CONSUMOPROMEDIOUSD,
                    MINIMODIAS,MAXIMODIAS,STOCKMINIMOUSD,STOCKMAXIMOUSD,
                    SOBREMAXIMOUSD,BAJOMINIMOUSD,VARIACIONUSD,OBSERVACION,
                    FECHAPROCESO,USUARIOPROCESO,COMPANIA,METODOCALCULO,
                    TOTALCANTIDAD,TOTALUSD, FECHA,COSTOSTANDARD,INICIALUSD,ORIGEN_REGISTRO
                ) VALUES (
                    V_PERIODO,
                    v_productos_tab(i).TIPOPRODUCTO,
                    TRIM(REC.CODIGO),
                    v_productos_tab(i).DESCRIPCIONSKU,
                    v_productos_tab(i).CATEGORIAPLANIFICACION,
                    V_PROMEDIO_INVENTARIADO_USD,
                    V_PROMEDIO_INVENTARIADO_CANTIDAD,
                    V_CONSUMO_PROMEDIO_USD,
                    v_productos_tab(i).MINIMODIAS,
                    v_productos_tab(i).MAXIMODIAS,
                    V_STOCK_MINIMO_USD,
                    V_STOCK_MAXIMO_USD,
                    GREATEST(V_PROMEDIO_INVENTARIADO_USD - V_STOCK_MAXIMO_USD, 0),
                    GREATEST(V_STOCK_MINIMO_USD - V_PROMEDIO_INVENTARIADO_USD, 0),
                    GREATEST(V_PROMEDIO_INVENTARIADO_USD - V_STOCK_MAXIMO_USD, 0) +
                    GREATEST(V_STOCK_MINIMO_USD - V_PROMEDIO_INVENTARIADO_USD, 0),
                    CASE WHEN v_productos_tab(i).METODOCALCULO = 'REEMPLAZO' THEN
                        V_CODIGO_PRODUCTO || ' - ' || v_productos_tab(i).OBSERVACION
                        ELSE v_productos_tab(i).OBSERVACION
                    END,
                    SYSDATE,P_USUARIO,P_COMPANIA, v_productos_tab(i).METODOCALCULO,
                    CASE WHEN v_productos_tab(i).METODOCALCULO = 'REEMPLAZO' THEN
                        V_STOCK_ACUMULADO_CANTIDAD/v_cant_productos_movidos
                    ELSE
                        V_STOCK_ACUMULADO_CANTIDAD
                    END,
                    CASE WHEN v_productos_tab(i).METODOCALCULO = 'REEMPLAZO' THEN
                        V_STOCK_ACUMULADO_USD/v_cant_productos_movidos
                    ELSE
                        V_STOCK_ACUMULADO_USD
                    END,
                    V_PERIODO_ANTERIOR,
                    V_COSTOSTANDARD,
                    V_INICIAL_USD,
                    NVL((SELECT AUTO.ESTADO_ORIGEN
                           FROM T_PPLA_STOCKIDEAL_AUTO_SKU AUTO
                          WHERE AUTO.COMPANIA = P_COMPANIA
                            AND TRIM(AUTO.CODIGO_SKU) = TRIM(REC.CODIGO)), 'CALCULO')
               );
               --IF v_cant_productos_movidos <= 2 THEN
                --EXIT;
               --END IF;

            END LOOP;
            END;
        END;
    END LOOP;

  END SP_CALCULARSTOCKIDEAL;

    PROCEDURE SP_ACTUALIZAR_PARAMETROS_PLANIFICACION_AGOTAMIENTO(
        P_COMPANIA IN VARCHAR2
    )
    AS
    BEGIN
        MERGE INTO T_PPLA_STOCKIDEALPARAMETROS PARAM
        USING (
            SELECT distinct TRIM(CALITM) AS CODIGOPRODUCTO
            FROM
            F574310@jdedtadl
        ) SRC
            ON (TRIM(PARAM.CODIGOPRODUCTO) = SRC.CODIGOPRODUCTO AND 
            PARAM.COMPANIA = P_COMPANIA AND PARAM.ESTADO = 1)
        WHEN MATCHED THEN
            UPDATE SET PARAM.METODOCALCULO = -- 'AGOTAMIENTO';
                CASE 
                    WHEN PARAM.CATEGORIAPLANIFICACION = 'SEMIELABORADO' THEN 'NO CONSIDERAR'
                    ELSE 'AGOTAMIENTO'
                END;
            
    END SP_ACTUALIZAR_PARAMETROS_PLANIFICACION_AGOTAMIENTO;

    PROCEDURE SP_NOTIFICAR_NUEVOS_PRODUCTOS(
        P_COMPANIA IN VARCHAR2
    )
    AS
        CURSOR C_NUEVOS_PRODUCTOS IS
            SELECT a.CODIGOPRODUCTO, a.NOMBREPRODUCTO, a.CODIGOBARRA,a.MARCA, a.TIPOPRODUCTO
            FROM VT_GZM_PRODUCTO a
            WHERE a.COMPANIA = P_COMPANIA
                AND a.ESTADO = 1
                AND UPPER(a.TEXTOBUSQUEDA) IN ( 'MATERIA PRIMA', 'TERMINADO')
                AND a.CODIGOPRODUCTO=a.CODIGOPRODUCTOPADRE
                AND NOT EXISTS (
                    SELECT  1
                    FROM DATA.T_PPLA_STOCKIDEALPARAMETROS b
                    WHERE TRIM(a.CODIGOPRODUCTO)=TRIM(b.CODIGOPRODUCTO)
                )
                AND NOT EXISTS (SELECT 1
                    FROM F574310@jdedtadl
                    WHERE TRIM(CALITM) = TRIM(a.CODIGOPRODUCTO));

        V_MENSAJE CLOB := '';
        V_ASUNTO VARCHAR2(200) := 'Notificación de nuevos productos para planificación de inventarios';
        V_CORREO_NOTIFICACION VARCHAR2(200);
        V_NOMBRES VARCHAR2(200);
    BEGIN
        SELECT VALOR
        INTO V_CORREO_NOTIFICACION
        FROM T_CORP_UDC
        WHERE ID_CABECERA = 'PPLA_PARAM'
        AND ID_TABLA = 'PAR12';

        SELECT nombres||' '||apellidos INTO V_NOMBRES
        FROM DATA.VT_CORP_USUARIO WHERE EMAIL = V_CORREO_NOTIFICACION ;

        --Armar el correo con una tabla html con todos los productos y enviar en un solo correo
        V_MENSAJE := '<p>&nbsp;</p>' ||
                     '<p>Estimado Usuario</p>' ||
                     '<p>&nbsp;</p>' ||
                     '<p>'||v_nombres||'</p>' ||
                     '<p>&nbsp;</p>' ||
                     '<p>Tiene pendiente la carga de código/s nuevo/s dentro de la configuración de parámetros de planificación de inventario: </p> <p>&nbsp;</p>' ;

        --cabecera de la tabla
        V_MENSAJE := V_MENSAJE || '<table border="1" cellpadding="5" cellspacing="0">' ||
                    '<tr>' ||
                    '<th>Código Producto</th>' ||
                    '<th>Nombre Producto</th>' ||
                    '<th>Código de Barra</th>' ||
                    '<th>Marca</th>' ||
                    '<th>Tipo Producto</th>' ||
                    '</tr>';
        FOR REC IN C_NUEVOS_PRODUCTOS LOOP
            V_MENSAJE := V_MENSAJE || '<tr>' ||
                        '<td>'||REC.CODIGOPRODUCTO||'</td>' ||
                        '<td>'||REC.NOMBREPRODUCTO||'</td>' ||
                        '<td>'||REC.CODIGOBARRA||'</td>' ||
                        '<td>'||REC.MARCA||'</td>' ||
                        '<td>'||REC.TIPOPRODUCTO||'</td>' ||
                        '</tr>';
        END LOOP;
        V_MENSAJE := V_MENSAJE || '</table>';
        --Se inserta la despedida
        V_MENSAJE := V_MENSAJE || '<p>&nbsp;</p>' ||
                    '<p>Por favor, ingrese a la aplicación de planificación de inventarios para cargar el o los códigos nuevos dentro de la configuración de parámetros de planificación de inventario. </p>' ||
                    '<p>&nbsp;</p>' ||
                    '<p>Saludos cordiales.</p>';

        PK_CORP_CORREO.SP_ENVIO(
            P_MODULO => 'PPLA',
            P_TO => V_CORREO_NOTIFICACION,
            P_FROM => 'notificacion@zaimella.com',
            P_SUBJECT => v_asunto,
            P_BODY => V_MENSAJE
        );
    END SP_NOTIFICAR_NUEVOS_PRODUCTOS;

END PK_PPLA_TAREAS_AUTOMATICAS;
/
