CREATE OR REPLACE PACKAGE BODY DATA.PK_PPLA_STOCKIDEAL AS

    C_GRUPO_SIN_CATEGORIA CONSTANT VARCHAR2(100) := 'Sin categoria de planificacion';
    C_GRUPO_SIN_LINEA     CONSTANT VARCHAR2(100) := 'Sin linea de negocio';

    /*
      Verifica si un SKU fue excluido por el usuario en una lista separada por comas.
    */
    FUNCTION F_SKU_EXCLUIDO (
        P_CODIGO_PRODUCTO IN VARCHAR2,
        P_SKU_EXCLUIDOS   IN CLOB
    ) RETURN BOOLEAN IS
        V_LISTA VARCHAR2(32767);
        V_CODIGO VARCHAR2(100);
        V_POSICION PLS_INTEGER := 1;
    BEGIN
        IF P_SKU_EXCLUIDOS IS NULL THEN
            RETURN FALSE;
        END IF;

        V_LISTA := REPLACE(DBMS_LOB.SUBSTR(P_SKU_EXCLUIDOS, 32767, 1), ' ', '');
        LOOP
            V_CODIGO := TRIM(REGEXP_SUBSTR(P_CODIGO_PRODUCTO, '[^,]+', 1, V_POSICION));
            EXIT WHEN V_CODIGO IS NULL;
            IF INSTR(',' || V_LISTA || ',', ',' || REPLACE(V_CODIGO, ' ', '') || ',') > 0 THEN
                RETURN TRUE;
            END IF;
            V_POSICION := V_POSICION + 1;
        END LOOP;
        RETURN FALSE;
    END F_SKU_EXCLUIDO;

    /*
      Obtiene los grupos del periodo cerrado asociados a los codigos de un parametro.

      Retorna:
        Cantidad de grupos distintos, el grupo unico y si contiene el grupo evaluado.
    */
    PROCEDURE SP_OBTENER_GRUPO_PARAMETRO (
        P_COMPANIA        IN  VARCHAR2,
        P_PERIODO         IN  NUMBER,
        P_TIPO_PRODUCTO   IN  VARCHAR2,
        P_CODIGOS         IN  VARCHAR2,
        P_GRUPO_EVALUADO  IN  VARCHAR2,
        P_CANTIDAD_GRUPOS OUT NUMBER,
        P_GRUPO_UNICO     OUT VARCHAR2,
        P_CONTIENE_GRUPO  OUT NUMBER
    ) IS
    BEGIN
        SELECT COUNT(*), MIN(GRUPO), NVL(MAX(CASE WHEN GRUPO = TRIM(P_GRUPO_EVALUADO) THEN 1 ELSE 0 END),0)
          INTO P_CANTIDAD_GRUPOS, P_GRUPO_UNICO, P_CONTIENE_GRUPO
          FROM (
                SELECT DISTINCT
                       CASE
                           WHEN P_TIPO_PRODUCTO = 'MATERIA PRIMA'
                           THEN NVL(TRIM(STOCK.CATEGORIAPLANIFICACION), C_GRUPO_SIN_CATEGORIA)
                           ELSE NVL((
                               SELECT CAST(MAX(TRIM(PRODUCTO.LINEANEGOCIO)) AS VARCHAR2(100))
                                 FROM VT_JDE_PRODUCTOS PRODUCTO
                                WHERE TRIM(PRODUCTO.COMPANIA) = TRIM(P_COMPANIA)
                                  AND CAST(TRIM(PRODUCTO.CODIGOPRODUCTO) AS VARCHAR2(30)) = TRIM(STOCK.CODIGOSKU)
                           ), C_GRUPO_SIN_LINEA)
                       END GRUPO
                  FROM (
                        SELECT TRIM(REGEXP_SUBSTR(P_CODIGOS, '[^,]+', 1, LEVEL)) AS CODIGO_PRODUCTO
                          FROM DUAL
                        CONNECT BY REGEXP_SUBSTR(P_CODIGOS, '[^,]+', 1, LEVEL) IS NOT NULL
                       ) CODIGO
                  JOIN T_PPLA_STOCKIDEAL STOCK
                    ON STOCK.COMPANIA = TRIM(P_COMPANIA)
                   AND STOCK.FECHA = P_PERIODO
                   AND STOCK.TIPOPRODUCTO = P_TIPO_PRODUCTO
                   AND TRIM(STOCK.CODIGOSKU) = CODIGO.CODIGO_PRODUCTO
               );
    END SP_OBTENER_GRUPO_PARAMETRO;

    /*
      Registra el resultado individual de un parametro evaluado por el ajuste.
    */
    PROCEDURE SP_REGISTRAR_DETALLE (
        P_ID_AJUSTE             IN NUMBER,
        P_COMPANIA              IN VARCHAR2,
        P_PARAMETRO             IN T_PPLA_STOCKIDEALPARAMETROS%ROWTYPE,
        P_MINIMO_NUEVO          IN NUMBER,
        P_MAXIMO_NUEVO          IN NUMBER,
        P_OBSERVACION_NUEVA     IN VARCHAR2,
        P_RESULTADO             IN VARCHAR2,
        P_DETALLE_RESULTADO     IN VARCHAR2
    ) IS
    BEGIN
        INSERT INTO T_PPLA_STOCKIDEAL_AJUSTE_DET (
            ID_AJUSTE, COMPANIA, ID_PARAMETRO, CODIGO_PRODUCTO, DESCRIPCION_SKU,
            METODO_CALCULO, MINIMO_ANTERIOR, MINIMO_NUEVO, MAXIMO_ANTERIOR,
            MAXIMO_NUEVO, OBSERVACION_ANTERIOR, OBSERVACION_NUEVA,
            RESULTADO, DETALLE_RESULTADO
        ) VALUES (
            P_ID_AJUSTE, P_COMPANIA, P_PARAMETRO.IDPARAMETRO,
            P_PARAMETRO.CODIGOPRODUCTO, P_PARAMETRO.DESCRIPCIONSKU,
            P_PARAMETRO.METODOCALCULO, P_PARAMETRO.MINIMODIAS, P_MINIMO_NUEVO,
            P_PARAMETRO.MAXIMODIAS, P_MAXIMO_NUEVO, P_PARAMETRO.OBSERVACION,
            P_OBSERVACION_NUEVA, P_RESULTADO, P_DETALLE_RESULTADO
        );
    END SP_REGISTRAR_DETALLE;

    /*
      Aplica y audita los cambios permitidos a todos los parametros activos del grupo.
    */
    PROCEDURE SP_GUARDAR_AJUSTE (
        P_COMPANIA             IN  VARCHAR2,
        P_PERIODO              IN  NUMBER,
        P_TIPO_PRODUCTO        IN  VARCHAR2,
        P_TIPO_GRUPO           IN  VARCHAR2,
        P_GRUPO                IN  VARCHAR2,
        P_CODIGO_SKU           IN  VARCHAR2 DEFAULT NULL,
        P_APLICA_MINIMO        IN  NUMBER,
        P_MINIMO_DIAS          IN  NUMBER,
        P_APLICA_MAXIMO        IN  NUMBER,
        P_MAXIMO_DIAS          IN  NUMBER,
        P_APLICA_OBSERVACION   IN  NUMBER,
        P_OBSERVACION          IN  VARCHAR2,
        P_METODO_CALCULO       IN  VARCHAR2 DEFAULT NULL,
        P_SKU_EXCLUIDOS        IN  CLOB,
        P_MOTIVO               IN  VARCHAR2,
        P_USUARIO              IN  VARCHAR2,
        P_ID_AJUSTE            OUT NUMBER,
        P_ACTUALIZADOS         OUT NUMBER,
        P_OMITIDOS             OUT NUMBER,
        P_RECHAZADOS           OUT NUMBER
    ) IS
        V_MINIMO_NUEVO       NUMBER;
        V_MAXIMO_NUEVO       NUMBER;
        V_OBSERVACION_NUEVA  VARCHAR2(4000);
        V_METODO_NUEVO        VARCHAR2(30);
        V_APLICA_MINIMO       NUMBER;
        V_APLICA_MAXIMO       NUMBER;
        V_APLICA_OBSERVACION  NUMBER;
        V_CANTIDAD_GRUPOS    NUMBER;
        V_GRUPO_UNICO        VARCHAR2(100);
        V_CONTIENE_GRUPO     NUMBER;
        V_PERIODO_RESUMEN    NUMBER;
        V_PERTENECE_GRUPO    BOOLEAN;
    BEGIN
        -- Validar el contexto funcional antes de modificar parametros.
        IF PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES(
               'PLAN', P_USUARIO, '1000', 'AJUSTAR_STOCK_IDEAL', P_COMPANIA
           ) <> 1 THEN
            RAISE_APPLICATION_ERROR(-20001, 'El usuario no tiene permiso para ajustar Stock Ideal.');
        END IF;

        IF TRIM(P_COMPANIA) IS NULL OR P_PERIODO IS NULL OR LENGTH(TO_CHAR(P_PERIODO)) <> 6 THEN
            RAISE_APPLICATION_ERROR(-20001, 'Compania y periodo cerrado son obligatorios.');
        END IF;

        IF P_TIPO_PRODUCTO NOT IN ('MATERIA PRIMA', 'PRODUCTO TERMINADO') THEN
            RAISE_APPLICATION_ERROR(-20001, 'Tipo de producto no permitido.');
        END IF;

        IF (P_TIPO_PRODUCTO = 'MATERIA PRIMA' AND P_TIPO_GRUPO <> 'CATEGORIA_PLANIFICACION')
           OR (P_TIPO_PRODUCTO = 'PRODUCTO TERMINADO' AND P_TIPO_GRUPO <> 'LINEA_NEGOCIO') THEN
            RAISE_APPLICATION_ERROR(-20001, 'El tipo de agrupacion no corresponde al tipo de producto.');
        END IF;

        IF TRIM(P_GRUPO) IS NULL OR TRIM(P_MOTIVO) IS NULL THEN
            RAISE_APPLICATION_ERROR(-20001, 'El grupo y el motivo del ajuste son obligatorios.');
        END IF;

        -- Un campo con valor se actualiza; un campo vacio conserva su valor actual.
        -- Los indicadores se mantienen solo para compatibilidad con llamadas anteriores.
        V_APLICA_MINIMO := CASE WHEN P_MINIMO_DIAS IS NOT NULL THEN 1 ELSE 0 END;
        V_APLICA_MAXIMO := CASE WHEN P_MAXIMO_DIAS IS NOT NULL THEN 1 ELSE 0 END;
        V_APLICA_OBSERVACION := CASE WHEN P_OBSERVACION IS NOT NULL THEN 1 ELSE 0 END;
        IF P_METODO_CALCULO IS NOT NULL AND TRIM(P_METODO_CALCULO) NOT IN ('NORMAL', 'AGOTAMIENTO', 'REEMPLAZO', 'NO CONSIDERAR') THEN
            RAISE_APPLICATION_ERROR(-20001, 'Metodo de calculo no permitido.');
        END IF;

        IF V_APLICA_MINIMO + V_APLICA_MAXIMO + V_APLICA_OBSERVACION = 0 AND P_METODO_CALCULO IS NULL THEN
            RAISE_APPLICATION_ERROR(-20001, 'Ingrese al menos un valor para actualizar.');
        END IF;

        SELECT MAX(FECHA)
          INTO V_PERIODO_RESUMEN
          FROM T_PPLA_STOCKIDEAL
         WHERE COMPANIA = TRIM(P_COMPANIA)
           AND FECHA <= TO_NUMBER(TO_CHAR(ADD_MONTHS(SYSDATE,-1),'YYYYMM'));

        IF V_PERIODO_RESUMEN IS NULL OR P_PERIODO <> V_PERIODO_RESUMEN THEN
            RAISE_APPLICATION_ERROR(-20001, 'El periodo no corresponde al cierre mostrado en el Resumen.');
        END IF;

        -- Crear la cabecera que relaciona el ajuste con su futuro recalculo.
        INSERT INTO T_PPLA_STOCKIDEAL_AJUSTE_CAB (
            COMPANIA, PERIODO, TIPO_PRODUCTO, TIPO_GRUPO, GRUPO, MOTIVO,
            APLICA_MINIMO, MINIMO_DIAS, APLICA_MAXIMO, MAXIMO_DIAS,
            APLICA_OBSERVACION, OBSERVACION, SKU_EXCLUIDOS, ESTADO,
            USUARIO_CREACION
        ) VALUES (
            TRIM(P_COMPANIA), P_PERIODO, P_TIPO_PRODUCTO, P_TIPO_GRUPO,
            TRIM(P_GRUPO), TRIM(P_MOTIVO), V_APLICA_MINIMO,
            P_MINIMO_DIAS, V_APLICA_MAXIMO, P_MAXIMO_DIAS,
            V_APLICA_OBSERVACION, P_OBSERVACION, P_SKU_EXCLUIDOS,
            'PENDIENTE_RECALCULO', P_USUARIO
        ) RETURNING ID_AJUSTE INTO P_ID_AJUSTE;

        P_ACTUALIZADOS := 0;
        P_OMITIDOS := 0;
        P_RECHAZADOS := 0;

        -- Evaluar cada parametro activo del tipo seleccionado sin confiar en listas enviadas por APEX.
        FOR PARAMETRO IN (
            SELECT *
             FROM T_PPLA_STOCKIDEALPARAMETROS
             WHERE COMPANIA = TRIM(P_COMPANIA)
               AND TIPOPRODUCTO = P_TIPO_PRODUCTO
               AND (P_CODIGO_SKU IS NULL OR TRIM(CODIGOPRODUCTO) = TRIM(P_CODIGO_SKU))
               AND ESTADO = 1
             FOR UPDATE
        ) LOOP
            V_PERTENECE_GRUPO := FALSE;

            SP_OBTENER_GRUPO_PARAMETRO(
                P_COMPANIA        => P_COMPANIA,
                P_PERIODO         => P_PERIODO,
                P_TIPO_PRODUCTO   => P_TIPO_PRODUCTO,
                P_CODIGOS         => PARAMETRO.CODIGOPRODUCTO,
                P_GRUPO_EVALUADO  => P_GRUPO,
                P_CANTIDAD_GRUPOS => V_CANTIDAD_GRUPOS,
                P_GRUPO_UNICO     => V_GRUPO_UNICO,
                P_CONTIENE_GRUPO  => V_CONTIENE_GRUPO
            );

            V_PERTENECE_GRUPO := V_CONTIENE_GRUPO = 1;
            IF NOT V_PERTENECE_GRUPO THEN
                CONTINUE;
            END IF;

            V_MINIMO_NUEVO := CASE WHEN V_APLICA_MINIMO = 1 THEN P_MINIMO_DIAS ELSE PARAMETRO.MINIMODIAS END;
            V_MAXIMO_NUEVO := CASE WHEN V_APLICA_MAXIMO = 1 THEN P_MAXIMO_DIAS ELSE PARAMETRO.MAXIMODIAS END;
            V_OBSERVACION_NUEVA := CASE WHEN V_APLICA_OBSERVACION = 1 THEN P_OBSERVACION ELSE PARAMETRO.OBSERVACION END;
            V_METODO_NUEVO := NVL(TRIM(P_METODO_CALCULO), PARAMETRO.METODOCALCULO);

            IF PARAMETRO.METODOCALCULO = 'NO CONSIDERAR' AND P_METODO_CALCULO IS NULL THEN
                SP_REGISTRAR_DETALLE(P_ID_AJUSTE, P_COMPANIA, PARAMETRO,
                    V_MINIMO_NUEVO, V_MAXIMO_NUEVO, V_OBSERVACION_NUEVA,
                    'OMITIDO', 'Metodo NO CONSIDERAR.');
                P_OMITIDOS := P_OMITIDOS + 1;
            ELSIF F_SKU_EXCLUIDO(PARAMETRO.CODIGOPRODUCTO, P_SKU_EXCLUIDOS) THEN
                SP_REGISTRAR_DETALLE(P_ID_AJUSTE, P_COMPANIA, PARAMETRO,
                    V_MINIMO_NUEVO, V_MAXIMO_NUEVO, V_OBSERVACION_NUEVA,
                    'OMITIDO', 'SKU excluido por el usuario.');
                P_OMITIDOS := P_OMITIDOS + 1;
            ELSIF V_MINIMO_NUEVO IS NOT NULL AND V_MAXIMO_NUEVO IS NOT NULL
                  AND V_MINIMO_NUEVO > V_MAXIMO_NUEVO THEN
                SP_REGISTRAR_DETALLE(P_ID_AJUSTE, P_COMPANIA, PARAMETRO,
                    V_MINIMO_NUEVO, V_MAXIMO_NUEVO, V_OBSERVACION_NUEVA,
                    'RECHAZADO', 'Los dias minimos resultantes superan los dias maximos.');
                P_RECHAZADOS := P_RECHAZADOS + 1;
            ELSE
                SP_REGISTRAR_DETALLE(P_ID_AJUSTE, P_COMPANIA, PARAMETRO,
                    V_MINIMO_NUEVO, V_MAXIMO_NUEVO, V_OBSERVACION_NUEVA,
                    'ACTUALIZADO', 'Parametro actualizado correctamente.');

                UPDATE T_PPLA_STOCKIDEALPARAMETROS
                   SET MINIMODIAS = V_MINIMO_NUEVO,
                       MAXIMODIAS = V_MAXIMO_NUEVO,
                       METODOCALCULO = V_METODO_NUEVO,
                       OBSERVACION = V_OBSERVACION_NUEVA,
                       USUARIOMODIFICACION = P_USUARIO,
                       FECHAMODIFICACION = SYSDATE
                 WHERE IDPARAMETRO = PARAMETRO.IDPARAMETRO;

                -- Un ajuste individual o grupal confirma que el usuario reviso un alta automatica.
                UPDATE T_PPLA_STOCKIDEAL_AUTO_SKU
                   SET ESTADO_ORIGEN = 'MANUAL',
                       USUARIO_MODIFICACION = P_USUARIO,
                       FECHA_MODIFICACION = SYSTIMESTAMP
                 WHERE COMPANIA = TRIM(P_COMPANIA)
                   AND TRIM(CODIGO_SKU) = TRIM(PARAMETRO.CODIGOPRODUCTO)
                   AND ESTADO_ORIGEN = 'AUTO';

                UPDATE T_PPLA_STOCKIDEAL
                   SET ORIGEN_REGISTRO = 'MANUAL'
                 WHERE COMPANIA = TRIM(P_COMPANIA)
                   AND FECHA = P_PERIODO
                   AND TRIM(CODIGOSKU) = TRIM(PARAMETRO.CODIGOPRODUCTO)
                   AND ORIGEN_REGISTRO = 'AUTO';

                P_ACTUALIZADOS := P_ACTUALIZADOS + 1;
            END IF;
        END LOOP;

        IF P_ACTUALIZADOS = 0 THEN
            RAISE_APPLICATION_ERROR(-20001, 'No existen parametros actualizables en el grupo seleccionado.');
        END IF;

        UPDATE T_PPLA_STOCKIDEAL_AJUSTE_CAB
           SET CANTIDAD_ACTUALIZADOS = P_ACTUALIZADOS,
               CANTIDAD_OMITIDOS = P_OMITIDOS,
               CANTIDAD_RECHAZADOS = P_RECHAZADOS,
               USUARIO_ACTUALIZACION = P_USUARIO,
               FECHA_ACTUALIZACION = SYSTIMESTAMP
         WHERE ID_AJUSTE = P_ID_AJUSTE;
    END SP_GUARDAR_AJUSTE;

    /*
      Regenera la fotografia del periodo cerrado y conserva el ajuste si el calculo falla.
    */
    PROCEDURE SP_RECALCULAR_AJUSTE (
        P_ID_AJUSTE       IN  NUMBER,
        P_COMPANIA        IN  VARCHAR2,
        P_USUARIO         IN  VARCHAR2,
        P_EXITO           OUT NUMBER,
        P_MENSAJE         OUT VARCHAR2
    ) IS
        V_PERIODO_CERRADO NUMBER;
        V_PERIODO_PROCESO NUMBER;
        V_ESTADO          VARCHAR2(30);
        V_FILAS           NUMBER;
        V_AJUSTES_CERRADOS NUMBER;
        V_ERROR           VARCHAR2(4000);
    BEGIN
        IF PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES(
               'PLAN', P_USUARIO, '1000', 'AJUSTAR_STOCK_IDEAL', P_COMPANIA
           ) <> 1 THEN
            RAISE_APPLICATION_ERROR(-20001, 'El usuario no tiene permiso para recalcular Stock Ideal.');
        END IF;

        SELECT PERIODO, ESTADO
          INTO V_PERIODO_CERRADO, V_ESTADO
          FROM T_PPLA_STOCKIDEAL_AJUSTE_CAB
         WHERE ID_AJUSTE = P_ID_AJUSTE
           AND COMPANIA = TRIM(P_COMPANIA)
         FOR UPDATE;

        IF V_ESTADO NOT IN ('PENDIENTE_RECALCULO', 'ERROR_RECALCULO') THEN
            RAISE_APPLICATION_ERROR(-20001, 'El ajuste ya fue recalculado.');
        END IF;

        V_PERIODO_PROCESO := TO_NUMBER(TO_CHAR(ADD_MONTHS(TO_DATE(V_PERIODO_CERRADO || '01', 'YYYYMMDD'), 1), 'YYYYMM'));

        -- La reversa al savepoint preserva el ajuste guardado antes de iniciar esta rutina.
        SAVEPOINT ANTES_RECALCULO_STOCK_IDEAL;

        BEGIN
            -- El periodo cerrado ya conserva consumo e inventario historicos.
            -- Recalcular dias/metodo no debe volver a consultar F4111 por DB link.
            MERGE INTO T_PPLA_STOCKIDEAL STOCK
            USING (
                SELECT STOCK.ROWID RID,
                       PARAM.MINIMODIAS,
                       PARAM.MAXIMODIAS,
                       PARAM.METODOCALCULO,
                       CASE WHEN PARAM.METODOCALCULO = 'AGOTAMIENTO'
                            THEN STOCK.STOCKMINIMOUSD
                            ELSE NVL(STOCK.CONSUMOPROMEDIOUSD,0) * PARAM.MINIMODIAS END MINIMO_USD,
                       NVL(STOCK.CONSUMOPROMEDIOUSD,0) * PARAM.MAXIMODIAS MAXIMO_USD,
                       NVL(STOCK.PROMEDIOINVENTARIOUSD,0) INVENTARIO_USD
                  FROM T_PPLA_STOCKIDEAL STOCK
                  JOIN T_PPLA_STOCKIDEALPARAMETROS PARAM
                    ON PARAM.COMPANIA = STOCK.COMPANIA
                   AND PARAM.ESTADO = 1
                   AND TRIM(PARAM.CODIGOPRODUCTO) = TRIM(STOCK.CODIGOSKU)
                  JOIN T_PPLA_STOCKIDEAL_AJUSTE_DET DET
                    ON DET.ID_PARAMETRO = PARAM.IDPARAMETRO
                   AND DET.ID_AJUSTE = P_ID_AJUSTE
                   AND DET.RESULTADO = 'ACTUALIZADO'
                 WHERE STOCK.COMPANIA = TRIM(P_COMPANIA)
                   AND STOCK.FECHA = V_PERIODO_CERRADO
            ) CALC
               ON (STOCK.ROWID = CALC.RID)
            WHEN MATCHED THEN UPDATE SET
                STOCK.MINIMODIAS = CALC.MINIMODIAS,
                STOCK.MAXIMODIAS = CALC.MAXIMODIAS,
                STOCK.METODOCALCULO = CALC.METODOCALCULO,
                STOCK.STOCKMINIMOUSD = CALC.MINIMO_USD,
                STOCK.STOCKMAXIMOUSD = CALC.MAXIMO_USD,
                STOCK.BAJOMINIMOUSD = GREATEST(CALC.MINIMO_USD - CALC.INVENTARIO_USD, 0),
                STOCK.SOBREMAXIMOUSD = GREATEST(CALC.INVENTARIO_USD - CALC.MAXIMO_USD, 0),
                STOCK.VARIACIONUSD = GREATEST(CALC.MINIMO_USD - CALC.INVENTARIO_USD, 0)
                                  + GREATEST(CALC.INVENTARIO_USD - CALC.MAXIMO_USD, 0),
                STOCK.FECHAPROCESO = SYSDATE,
                STOCK.USUARIOPROCESO = P_USUARIO;

            V_FILAS := SQL%ROWCOUNT;

            IF V_FILAS = 0 THEN
                RAISE_APPLICATION_ERROR(-20001, 'El proceso no genero productos para el periodo cerrado.');
            END IF;

            UPDATE T_PPLA_STOCKIDEAL_AJUSTE_CAB
               SET ESTADO = 'RECALCULADO',
                   FECHA_RECALCULO = SYSTIMESTAMP,
                   MENSAJE_RECALCULO = 'Recalculo completado. Filas generadas: ' || V_FILAS,
                   USUARIO_ACTUALIZACION = P_USUARIO,
                   FECHA_ACTUALIZACION = SYSTIMESTAMP
             WHERE ID_AJUSTE = P_ID_AJUSTE
               AND COMPANIA = TRIM(P_COMPANIA)
               AND ESTADO IN ('PENDIENTE_RECALCULO', 'ERROR_RECALCULO');

            V_AJUSTES_CERRADOS := SQL%ROWCOUNT;

            P_EXITO := 1;
            P_MENSAJE := 'Recalculo completado para el periodo ' || V_PERIODO_CERRADO ||
                         '. Ajustes cerrados: ' || V_AJUSTES_CERRADOS || '.';
        EXCEPTION
            WHEN OTHERS THEN
                V_ERROR := SUBSTR(SQLERRM, 1, 4000);
                ROLLBACK TO ANTES_RECALCULO_STOCK_IDEAL;

                UPDATE T_PPLA_STOCKIDEAL_AJUSTE_CAB
                   SET ESTADO = 'ERROR_RECALCULO',
                       FECHA_RECALCULO = SYSTIMESTAMP,
                       MENSAJE_RECALCULO = V_ERROR,
                       USUARIO_ACTUALIZACION = P_USUARIO,
                       FECHA_ACTUALIZACION = SYSTIMESTAMP
                 WHERE COMPANIA = TRIM(P_COMPANIA)
                   AND PERIODO = V_PERIODO_CERRADO
                   AND ESTADO IN ('PENDIENTE_RECALCULO', 'ERROR_RECALCULO');

                P_EXITO := 0;
                P_MENSAJE := 'Cambios guardados; el recalculo no se completo: ' || SUBSTR(V_ERROR, 1, 3000);
        END;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20001, 'El ajuste no existe para la compania de la sesion.');
    END SP_RECALCULAR_AJUSTE;

    PROCEDURE SP_SOLICITAR_RECALCULO (
        P_ID_AJUSTE IN  NUMBER,
        P_COMPANIA  IN  VARCHAR2,
        P_USUARIO   IN  VARCHAR2,
        P_ID_JOB    OUT NUMBER,
        P_MENSAJE   OUT VARCHAR2
    ) IS
        V_PERIODO NUMBER;
        V_ESTADO  VARCHAR2(30);
        V_ACTIVOS NUMBER;
    BEGIN
        IF PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES(
               'PLAN', P_USUARIO, '1000', 'AJUSTAR_STOCK_IDEAL', P_COMPANIA
           ) <> 1 THEN
            RAISE_APPLICATION_ERROR(-20001, 'El usuario no tiene permiso para solicitar el recalculo.');
        END IF;

        SELECT PERIODO, ESTADO
          INTO V_PERIODO, V_ESTADO
          FROM T_PPLA_STOCKIDEAL_AJUSTE_CAB
         WHERE ID_AJUSTE = P_ID_AJUSTE
           AND COMPANIA = TRIM(P_COMPANIA)
         FOR UPDATE;

        IF V_ESTADO NOT IN ('PENDIENTE_RECALCULO', 'ERROR_RECALCULO') THEN
            RAISE_APPLICATION_ERROR(-20001, 'El ajuste no esta disponible para solicitar recalculo.');
        END IF;

        -- Liberar solicitudes que quedaron marcadas en proceso pero cuyo job ya no existe.
        -- Una hora evita interferir con un recalculo vigente y permite reintentar fallos huerfanos.
        UPDATE T_PPLA_STOCKIDEAL_AJUSTE_CAB
           SET ESTADO = 'ERROR_RECALCULO',
               MENSAJE_RECALCULO = 'Recalculo marcado como pendiente de reintento: no finalizo en una hora.',
               FECHA_RECALCULO = SYSTIMESTAMP,
               FECHA_ACTUALIZACION = SYSTIMESTAMP
         WHERE COMPANIA = TRIM(P_COMPANIA)
           AND PERIODO = V_PERIODO
           AND ESTADO = 'PENDIENTE_RECALCULO'
           AND MENSAJE_RECALCULO = 'Recalculo en proceso.'
           AND FECHA_RECALCULO < SYSTIMESTAMP - INTERVAL '1' HOUR;

        SELECT COUNT(*)
          INTO V_ACTIVOS
          FROM T_PPLA_STOCKIDEAL_AJUSTE_CAB
         WHERE COMPANIA = TRIM(P_COMPANIA)
           AND PERIODO = V_PERIODO
           AND ESTADO = 'PENDIENTE_RECALCULO'
           AND (MENSAJE_RECALCULO LIKE 'Solicitud encolada.%'
                OR MENSAJE_RECALCULO = 'Recalculo en proceso.');

        IF V_ACTIVOS > 0 THEN
            RAISE_APPLICATION_ERROR(-20001, 'Ya existe un recalculo solicitado o en proceso para el periodo.');
        END IF;

        DBMS_JOB.SUBMIT(
            JOB       => P_ID_JOB,
            WHAT      => 'BEGIN DATA.PK_PPLA_STOCKIDEAL.SP_EJECUTAR_RECALCULO_JOB(' ||
                         TO_CHAR(P_ID_AJUSTE) || '); END;',
            NEXT_DATE => SYSDATE
        );

        UPDATE T_PPLA_STOCKIDEAL_AJUSTE_CAB
           SET ESTADO = 'PENDIENTE_RECALCULO',
               MENSAJE_RECALCULO = 'Solicitud encolada. Job Oracle: ' || P_ID_JOB,
               USUARIO_ACTUALIZACION = P_USUARIO,
               FECHA_ACTUALIZACION = SYSTIMESTAMP
         WHERE COMPANIA = TRIM(P_COMPANIA)
           AND PERIODO = V_PERIODO
           AND ESTADO IN ('PENDIENTE_RECALCULO', 'ERROR_RECALCULO');

        P_MENSAJE := 'Recalculo solicitado para el periodo ' || V_PERIODO ||
                     '. Job Oracle: ' || P_ID_JOB || '.';
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20001, 'El ajuste no existe para la compania de la sesion.');
    END SP_SOLICITAR_RECALCULO;

    PROCEDURE SP_EJECUTAR_RECALCULO_JOB (
        P_ID_AJUSTE IN NUMBER
    ) IS
        V_COMPANIA VARCHAR2(5);
        V_USUARIO  VARCHAR2(100);
        V_PERIODO  NUMBER;
        V_EXITO    NUMBER;
        V_MENSAJE  VARCHAR2(4000);
        V_ERROR    VARCHAR2(4000);
    BEGIN
        SELECT COMPANIA, NVL(USUARIO_ACTUALIZACION, USUARIO_CREACION), PERIODO
          INTO V_COMPANIA, V_USUARIO, V_PERIODO
          FROM T_PPLA_STOCKIDEAL_AJUSTE_CAB
         WHERE ID_AJUSTE = P_ID_AJUSTE;

        UPDATE T_PPLA_STOCKIDEAL_AJUSTE_CAB
           SET MENSAJE_RECALCULO = 'Recalculo en proceso.',
               FECHA_RECALCULO = SYSTIMESTAMP,
               USUARIO_ACTUALIZACION = V_USUARIO,
               FECHA_ACTUALIZACION = SYSTIMESTAMP
         WHERE COMPANIA = V_COMPANIA
           AND PERIODO = V_PERIODO
           AND ESTADO = 'PENDIENTE_RECALCULO'
           AND MENSAJE_RECALCULO LIKE 'Solicitud encolada.%';
        COMMIT;

        SP_RECALCULAR_AJUSTE(
            P_ID_AJUSTE => P_ID_AJUSTE,
            P_COMPANIA  => V_COMPANIA,
            P_USUARIO   => V_USUARIO,
            P_EXITO     => V_EXITO,
            P_MENSAJE   => V_MENSAJE
        );
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            V_ERROR := SUBSTR(SQLERRM, 1, 4000);
            ROLLBACK;
            UPDATE T_PPLA_STOCKIDEAL_AJUSTE_CAB
               SET ESTADO = 'ERROR_RECALCULO',
                   FECHA_RECALCULO = SYSTIMESTAMP,
                   MENSAJE_RECALCULO = V_ERROR,
                   FECHA_ACTUALIZACION = SYSTIMESTAMP
             WHERE COMPANIA = V_COMPANIA
               AND PERIODO = V_PERIODO
               AND ESTADO = 'PENDIENTE_RECALCULO';
            COMMIT;
    END SP_EJECUTAR_RECALCULO_JOB;

END PK_PPLA_STOCKIDEAL;
/
