create or replace package body data.pk_cntr_ia_analisis as
    procedure crear_solicitud(
        p_id_configuracion in number, p_tipo_sujeto in varchar2, p_id_sujeto in number,
        p_usuario in varchar2, p_compania in varchar2, p_id_solicitud out nocopy number,
        p_total_cabeceras out nocopy number) is
    begin
        select data.seq_cntr_ia_solicitud.nextval into p_id_solicitud from dual;
        p_total_cabeceras := 0;
        for sujeto in (
            select distinct matriz.tipo_sujeto, matriz.id_sujeto
              from data.vt_cntr_matriz_documental matriz
              join data.t_cntr_documentos documento on documento.id_documento = matriz.id_documento
             where matriz.id_configuracion = p_id_configuracion
               and matriz.compania = p_compania
               and upper(matriz.usuario_propietario) = upper(p_usuario)
               and matriz.id_evidencia is not null
               and trim(documento.prompt_ia) is not null
               and (p_tipo_sujeto is null or matriz.tipo_sujeto = upper(p_tipo_sujeto))
               and (p_id_sujeto is null or matriz.id_sujeto = p_id_sujeto)
        ) loop
            insert into data.t_cntr_ia_analisis(
                id_solicitud_analisis,id_configuracion,tipo_sujeto,id_sujeto,compania,usuario_solicitante)
            values(p_id_solicitud,p_id_configuracion,sujeto.tipo_sujeto,sujeto.id_sujeto,p_compania,p_usuario);
            p_total_cabeceras := p_total_cabeceras + 1;
        end loop;
        if p_total_cabeceras = 0 then p_id_solicitud := null; end if;
    end crear_solicitud;

    procedure notificar_solicitud(p_id_solicitud in number) is
        l_base_url varchar2(4000); l_request utl_http.req; l_response utl_http.resp;
        l_body varchar2(32767); l_error varchar2(2000); l_http_status number;
    begin
        commit;
        select trim(valor) into l_base_url from data.t_corp_udc
         where id_cabecera='CNTRIAAPI' and descripcion='URL_EJECUTAR' and activo=1 and rownum=1;
        utl_http.set_detailed_excp_support(true); utl_http.set_transfer_timeout(900);
        l_request := utl_http.begin_request(rtrim(l_base_url,'/') || '/solicitudes-analisis/' || to_char(p_id_solicitud) || '/ejecutar','POST','HTTP/1.1');
        utl_http.set_header(l_request,'Content-Type','application/json');
        utl_http.set_header(l_request,'Content-Length','0');
        l_response := utl_http.get_response(l_request); l_http_status := l_response.status_code;
        begin utl_http.read_text(l_response,l_body); exception when utl_http.end_of_body then null; end;
        utl_http.end_response(l_response);
        if l_http_status <> 200 or json_value(l_body,'$.estado') <> 'COMPLETADA' then
            raise_application_error(-20084,'API IA no finalizo correctamente. HTTP ' || l_http_status || ': ' || substr(l_body,1,1000));
        end if;
    exception when others then
        l_error := sqlerrm;
        begin utl_http.end_response(l_response); exception when others then null; end;
        update data.t_cntr_ia_analisis
           set advertencias=to_clob('Error terminal API IA: ' || substr(l_error,1,1500))
         where id_solicitud_analisis=p_id_solicitud
           and estado in ('PENDIENTE','ERROR_REINTENTABLE');
        raise;
    end notificar_solicitud;

    procedure obtener_cabeceras(p_id_solicitud in number,p_resultado out sys_refcursor) is
    begin
        open p_resultado for select * from data.t_cntr_ia_analisis where id_solicitud_analisis=p_id_solicitud and estado in ('PENDIENTE','ERROR_REINTENTABLE') order by id_analisis;
    end obtener_cabeceras;
    procedure iniciar_analisis(p_id_analisis in number) is
    begin update data.t_cntr_ia_analisis set estado='EN_EXTRACCION',fecha_inicio=systimestamp where id_analisis=p_id_analisis and estado in ('PENDIENTE','ERROR_REINTENTABLE'); end iniciar_analisis;
    procedure reintentar_analisis(p_id_analisis in number,p_mensaje in varchar2 default null) is
    begin update data.t_cntr_ia_analisis set estado='ERROR_REINTENTABLE',advertencias=case when p_mensaje is not null then to_clob(p_mensaje) else advertencias end,fecha_fin=systimestamp where id_analisis=p_id_analisis and estado in ('PENDIENTE','EN_EXTRACCION','EN_ANALISIS','ERROR_REINTENTABLE'); end reintentar_analisis;
    procedure registrar_documento(p_id_analisis in number,p_id_documento in number,p_id_evidencia in number,p_numero_archivo in number,p_nombre_archivo in varchar2,p_prompt_ia in clob,p_estado_extraccion in varchar2,p_texto_extraido in clob,p_paginas_procesadas in number,p_advertencias in clob,p_error_tecnico in varchar2) is
    begin
        update data.t_cntr_ia_analisis_documento set nombre_archivo=p_nombre_archivo,prompt_ia=p_prompt_ia,estado_extraccion=p_estado_extraccion,texto_extraido=p_texto_extraido,paginas_procesadas=p_paginas_procesadas,advertencias=p_advertencias,error_tecnico=p_error_tecnico,fecha_procesamiento=systimestamp where id_analisis=p_id_analisis and id_documento=p_id_documento and id_evidencia=p_id_evidencia and nvl(numero_archivo,-1)=nvl(p_numero_archivo,-1);
        if sql%rowcount=0 then insert into data.t_cntr_ia_analisis_documento(id_analisis,id_documento,id_evidencia,numero_archivo,nombre_archivo,prompt_ia,estado_extraccion,texto_extraido,paginas_procesadas,advertencias,error_tecnico,fecha_procesamiento) values(p_id_analisis,p_id_documento,p_id_evidencia,p_numero_archivo,p_nombre_archivo,p_prompt_ia,p_estado_extraccion,p_texto_extraido,p_paginas_procesadas,p_advertencias,p_error_tecnico,systimestamp); end if;
    end registrar_documento;
    procedure finalizar_analisis(p_id_analisis in number,p_estado in varchar2,p_proveedor in varchar2,p_modelo in varchar2,p_resultado in clob,p_resumen in clob,p_confianza in number,p_advertencias in clob,p_error_tecnico in varchar2) is
    begin update data.t_cntr_ia_analisis set estado=p_estado,proveedor=p_proveedor,modelo=p_modelo,resultado=p_resultado,resumen=p_resumen,confianza=p_confianza,advertencias=p_advertencias,error_tecnico=p_error_tecnico,fecha_fin=systimestamp where id_analisis=p_id_analisis; end finalizar_analisis;
end pk_cntr_ia_analisis;
/
