﻿prompt Esquema DATA para codigo PL/SQL
alter session set current_schema=DATA;

prompt PROD PACKAGE_BODY DATA.PK_ICOM_HERRAMIENTAS

  CREATE OR REPLACE EDITIONABLE PACKAGE BODY PK_ICOM_HERRAMIENTAS AS
 /*
 Procedimiento que actualiza el valor de aplicacion y crecimiento meta de todos los pdv
 que pertenecen a un canal

 P_ID 		- Inversion
 P_CANAL 	- Codigo de Canal
 P_DIS_APLI - Valor de aplicacion
 P_DIS_CRE 	- Valor de crecimiento meta

 Por: Ccarrasco
 Fecha: Agosto 2022
 */
  
 PROCEDURE SP_PRODUCTODISTRIBUCION(P_ID NUMBER,
 P_GRUPO1 VARCHAR DEFAULT NULL, P_GRUPO2 VARCHAR DEFAULT NULL,
 P_DIS_APLI NUMBER, P_DIS_CRE NUMBER)
 AS
    V_MES NUMBER;
BEGIN
 
    /*OBTENER LA COMPANIA DE LA INVERSION*/
    select  PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '2', COMPANIA )  into  V_MES from data.t_icom_inversiones where id = p_id and rownum=1;

    --GUARDA VALORES GENERALES EN LA INVERSION
    UPDATE T_ICOM_INVERSIONES
    SET REGALOCRECIMIENTO=P_DIS_CRE ,REGALOAPLICACION=P_DIS_APLI  
    WHERE ID = P_ID;	   

    -- GUARDA VALORES POR CLIENTE PARA QUE SE PUEDAN MODIFICAR POR CLIENTE 
	UPDATE data.T_ICOM_CLIENTE_PDV SET 
    DISTRIBUCIONAPLICACION=P_DIS_APLI , DISTRIBUCIONCRECIMIENTO=P_DIS_CRE
	WHERE IDINVERSION = P_ID;	   

    UPDATE t_icom_producto_dis_parametro  P
    SET (DISPONIBLE, SELLOUT)=
    --OnPacks
    (SELECT SUM((z.total* (1+(z.DISTRIBUCIONCRECIMIENTO/100)) )*  z.DISTRIBUCIONAPLICACION/100 ) CANTIDADONPACKS, SUM(z.total)
     FROM(   
            -- consulta ventas en unidad
            SELECT W.CODIGOPRODUCTO,W.CODIGOREGALO,NVL((SUM(V.VALORUNIDAD)/(V_MES)),0) TOTAL,
            max(w.DISTRIBUCIONAPLICACION) DISTRIBUCIONAPLICACION, max(w.DISTRIBUCIONCRECIMIENTO) DISTRIBUCIONCRECIMIENTO
            FROM (
                    --consulta cliente - producto - regalo
                    SELECT A.CODIGOPRODUCTO, CODIGOBARRA, A.PRODUCTO,A.CODIGOREGALO,A.REGALO,B.CODIGOPDV,A.MINIMO,A.DISPONIBLE,
                    B.DISTRIBUCIONAPLICACION, B.DISTRIBUCIONCRECIMIENTO
                    FROM DATA.VT_ICOM_PRODUCTO_DIS_PARAMETRO a, DATA.T_ICOM_CLIENTE_PDV b
                    WHERE A.IDINVERSION = P_ID AND B.IDINVERSION = P_ID) W
            LEFT JOIN  ( select   r.CODIGOPDV CODIGOPDV, S.CODIGOBARRA,S.VALORUNIDAD
						from t_trad_sellout S 
							left JOIN t_trad_clienteruc R ON (R.ruc=S.ruc AND S.FECHA BETWEEN  R.FECHADESDE AND NVL(r.fechahasta, SYSDATE))
							--LEFT JOIN T_TRAD_CLIENTE C ON (C.CODIGOCLIENTE=S.CODIGOCLIENTE)
						WHERE fecha between trunc(ADD_MONTHS(sysdate, -(V_MES)),'MM')  and sysdate )   V 
					ON (V.Codigopdv =w.codigopdv and V.CODIGOBARRA =W.CODIGOBARRA)  
            GROUP BY W.CODIGOPRODUCTO, W.CODIGOREGALO) Z
            WHERE z.CODIGOPRODUCTO=P.CODIGOPRODUCTO AND  z.CODIGOREGALO=P.CODIGOREGALO)
    WHERE idinversion = P_ID ;

 END SP_PRODUCTODISTRIBUCION;


 /*
 Procedimiento que realiza la ingesta de data a la tabla T_ICOM_PRODUCTO_DESCUENTO

 P_ID 		- Inversion

 Por: Ccarrasco
 Fecha: Agosto 2022
 */ 
  PROCEDURE SP_SIMULADORDESCUENTO (P_ID NUMBER) 
  AS
  v_contador number;
  begin

  select count(distinct 1)   into v_contador
  from data.T_ICOM_PRODUCTO_DESCUENTO   where idinversion=P_ID;

  --Solo inserta si no existen registros de la inversion en la tabla T_ICOM_PRODUCTO_DESCUENTO
    IF (v_contador=0) then  
        insert into data.T_ICOM_PRODUCTO_DESCUENTO 
        (IDINVERSION,CODIGOPRODUCTO,CODIGOBARRA,CODIGOCLIENTE,PRECIO,DESCUENTO, CODIGOGRUPO, CODIGOCANAL, CLIENTEGRUPO)
        SELECT  P_ID,a.codigoproducto,A.CODIGOBARRA,b.CODIGOCLIENTE,preciopromo,DESCUENTOMANUAL,B.CODIGOGRUPO,G.CODIGOCANAL, G.NOMBRES
        from data.T_ICOM_INVERSION_PRODUCTO a
        inner join data.T_ICOM_INVERSION_CLIENTE b  on (b.idinversion = a.idinversion )
        INNER JOIN t_icom_inversion_cliente_g G ON (B.IDINVERSION=G.IDINVERSION AND B.CODIGOGRUPO=G.CODIGOGRUPO)
        where a.idinversion = P_ID and tipo=1;
  end if;

  end SP_SIMULADORDESCUENTO;

    PROCEDURE SP_SIMULADORDESCUENTO_ACTUALIZAR (P_ID NUMBER, P_PRODUCTO VARCHAR DEFAULT NULL, P_TIPO NUMBER DEFAULT 1 )
    AS
    BEGIN 
        IF  P_PRODUCTO IS NULL THEN
        ---ELIMINA LOS QUE NO EXISTEN 
        DELETE T_ICOM_PRODUCTO_DESCUENTO D WHERE idinversion = P_ID AND 
        NOT EXISTS (SELECT  1 from data.T_ICOM_INVERSION_PRODUCTO a
            inner join data.T_ICOM_INVERSION_CLIENTE b  on (b.idinversion = a.idinversion )
            WHERE a.idinversion = P_ID and tipo=1 AND A.CODIGOPRODUCTO=D.CODIGOPRODUCTO AND B.CODIGOCLIENTE=D.CODIGOCLIENTE           
            );
        
         ---AGREGA LOS NUEVOS 
            insert into data.T_ICOM_PRODUCTO_DESCUENTO 
            (IDINVERSION,CODIGOPRODUCTO,CODIGOBARRA,CODIGOCLIENTE,PRECIO,DESCUENTO, CODIGOGRUPO, CODIGOCANAL, CLIENTEGRUPO)
            SELECT  P_ID,a.codigoproducto,A.CODIGOBARRA,b.CODIGOCLIENTE,preciopromo,DESCUENTOMANUAL,B.CODIGOGRUPO,G.CODIGOCANAL, G.NOMBRES
            from data.T_ICOM_INVERSION_PRODUCTO a
            inner join data.T_ICOM_INVERSION_CLIENTE b  on (b.idinversion = a.idinversion )
            INNER JOIN t_icom_inversion_cliente_g G ON (B.IDINVERSION=G.IDINVERSION AND B.CODIGOGRUPO=G.CODIGOGRUPO)
            where a.idinversion = P_ID and tipo= P_TIPO
            AND  NOT EXISTS  (SELECT 1 FROM T_ICOM_PRODUCTO_DESCUENTO D WHERE IDINVERSION=P_ID 
            AND A.CODIGOPRODUCTO=D.CODIGOPRODUCTO AND B.CODIGOCLIENTE=D.CODIGOCLIENTE);
            
       ELSIF P_PRODUCTO IS NOT NULL THEN     
            ---ELIMINA EL ANTERIOR
            DELETE T_ICOM_PRODUCTO_DESCUENTO D 
            WHERE idinversion = P_ID AND D.CODIGOPRODUCTO = P_PRODUCTO ;
        
            ---AGREGA DE NUEVO EL PRODUCTO
            insert into data.T_ICOM_PRODUCTO_DESCUENTO 
            (IDINVERSION,CODIGOPRODUCTO,CODIGOBARRA,CODIGOCLIENTE,PRECIO,DESCUENTO, CODIGOGRUPO, CODIGOCANAL, CLIENTEGRUPO)
            SELECT  P_ID,a.codigoproducto,A.CODIGOBARRA,b.CODIGOCLIENTE,preciopromo,DESCUENTOMANUAL,B.CODIGOGRUPO,G.CODIGOCANAL, G.NOMBRES
            from data.T_ICOM_INVERSION_PRODUCTO a
            inner join data.T_ICOM_INVERSION_CLIENTE b  on (b.idinversion = a.idinversion )
            INNER JOIN t_icom_inversion_cliente_g G ON (B.IDINVERSION=G.IDINVERSION AND B.CODIGOGRUPO=G.CODIGOGRUPO)
            where a.idinversion = P_ID and A.tipo = P_TIPO
            AND A.CODIGOPRODUCTO = P_PRODUCTO ;
            
       END IF;
         
    END SP_SIMULADORDESCUENTO_ACTUALIZAR    ;
    
    
  /*Calcula los valores de la herrmienta para guardar en la tabla T_ICOM_PRODUCTO_DESCUENTO */  
  PROCEDURE SP_SIMULADORDESCUENTO_CALCULAR (P_ID NUMBER, P_MESES NUMBER, P_PRODUCTO VARCHAR DEFAULT NULL, P_TIPO NUMBER DEFAULT 1, P_TIPO_CALCULO NUMBER DEFAULT 1) AS
  BEGIN

    SP_SIMULADORDESCUENTO_ACTUALIZAR(P_ID => P_ID, P_PRODUCTO => P_PRODUCTO , P_TIPO => P_TIPO );
    /*
        en caso de que sea el proceso automatico de productos todos se actualiza el  precio y/o descuento 
        con el mayor valor del precio que se encuentre del cliente por linea de negocio
        en caso que sea de un proceso normal lo hace con el procedimiento normal
    */
    if(P_TIPO_CALCULO =2)THEN
        UPDATE T_ICOM_PRODUCTO_DESCUENTO a 
        set (precio , descuento)= (
            select max(precio), max(descuento) 
            from T_ICOM_PRODUCTO_DESCUENTO b
            where a.codigoCliente=b.codigoCliente 
            and b.descuento is not null 
            and a.lineaNegocio=b.lineaNegocio
        ) 
        where descuento is null and idinversion=p_id;
    end if;

    insert into  t_tmp_a (NUM01, TXT01, TXT02, TXT03, TXT04, 
        TXT05, TXT06, TXT07, NUM02, NUM03, NUM04,
        NUM05, NUM06, NUM07, NUM08, NUM09, 
        NUM10, NUM11, NUM12, NUM13, NUM14,  
        NUM15, TXT08, TXT09, NUM16, NUM17)
        WITH DESCUENTO AS (
            SELECT * FROM T_ICOM_PRODUCTO_DESCUENTO P 
            WHERE IDINVERSION=P_ID 
            AND (P.CODIGOPRODUCTO = P_PRODUCTO or P_PRODUCTO  is null )
        )
        ,VENTAS AS (
            SELECT P_ID IDINVERSION,  D.CODIGOPRODUCTO, D.CODIGOCLIENTE, SUM(VALORVENTA)/P_MESES VENTA 
            FROM  DESCUENTO D
            INNER JOIN vt_trad_sellIN V ON (v.CODIGOCLIENTE=D.codigocliente AND v.CODIGOPRODUCTO=D.CODIGOPRODUCTO )
            WHERE V.FECHA  between trunc(ADD_MONTHS(sysdate, -P_MESES),'MM') and sysdate
            GROUP BY  D.CODIGOPRODUCTO, D.CODIGOCLIENTE
        )
        SELECT D.*, V.VENTA, DESCUENTOCALCULADO* V.VENTA DESCUENTOPROYECCION
        FROM VT_ICOM_PRODUCTO_DESCUENTO D 
        LEFT JOIN VENTAS V ON (v.CODIGOCLIENTE=D.codigocliente AND v.CODIGOPRODUCTO=D.CODIGOPRODUCTO AND V.IDINVERSION=D.IDINVERSION) 
        WHERE D.IDINVERSION=P_ID;
        
     UPDATE  T_ICOM_PRODUCTO_DESCUENTO P SET (
     LINEANEGOCIO, 	 PRODUCTO, 	 CANAL, 	 CLIENTE,
	 PRECIOLISTA, 	 ICE, 	 PRECIOMAYORISTA, 	
     MGR, PRECIOSUGERIDOSINIVA, PRECIOSUGERIDOCONIVA, PRECIOPROMO, 	/*DESCUENTO,*/
     MGPDV,  DESCUENTOCALCULADO,	 PRECIOPROMOPDV, 	 PRECIOPROMOIVA_S, 	 PRECIOPROMOCLIENTE, 
     DESCUENTOCLIENTE,  MARCA, 	 SUBMARCA, 	 VENTA, 	 DESCUENTOPROYECCION ) =
     (select --NUM01 IDINVERSION, TXT01 CODIGOBARRA, TXT02 CODIGOPRODUCTO, 
        TXT03 LINEANEGOCIO,  TXT04 PRODUCTO,--TXT05 CODIGOCLIENTE, 
        TXT06 CANAL, TXT07 CLIENTE, NUM02 PRECIOLISTA, NUM03 ICE, NUM04 PRECIOMAYORISTA,
        NUM05 MGR, NUM06 PRECIOSUGERIDOSINIVA, NUM07 PRECIOSUGERIDOCONIVA, NUM08 PRECIOPROMO,/* NUM09 DESCUENTO,*/ 
        NUM10 MGPDV, NUM11 DESCUENTOCALCULADO, NUM12 PRECIOPROMOPDV, NUM13 PRECIOPROMOIVA_S, NUM14 PRECIOPROMOCLIENTE,
        NUM15 DESCUENTOCLIENTE, TXT08 MARCA, TXT09 SUBMARCA, NUM16 VENTA, NUM17 DESCUENTOPROYECCION 
        from t_tmp_a where TXT02=CODIGOPRODUCTO and  TXT05=CODIGOCLIENTE)
    WHERE IDINVERSION=P_ID
    AND (CODIGOPRODUCTO = P_PRODUCTO  or P_PRODUCTO  is null)
    and (P_TIPO_CALCULO=1 or (P_TIPO_CALCULO=2 and DESCUENTOCALCULADO is null ) )
    ;

        
  END SP_SIMULADORDESCUENTO_CALCULAR;  

 /*
 Procedimiento que actualiza el precio y descuento de todos los clientes 
 en la inversiÃ³n y producto modificado a la tabla T_ICOM_PRODUCTO_DESCUENTO

 P_ID 		 - Inversion
 P_PRODUCTO  - Codigo del Producto
 P_PRECIO	 - Precio modificado
 P_DESCUENTO - Descuento modificado
 */ 
  PROCEDURE SP_ACTUALIZA_PRECIO_DESCUENTO (P_ID NUMBER, P_PRODUCTO VARCHAR2, 
    P_PRECIO NUMBER DEFAULT NULL, P_DESCUENTO NUMBER DEFAULT NULL , P_TIPO NUMBER DEFAULT 1) AS
  BEGIN
  
    SP_SIMULADORDESCUENTO_ACTUALIZAR(P_ID => P_ID, P_PRODUCTO => P_PRODUCTO, P_TIPO => P_TIPO);
    
	update data.T_ICOM_PRODUCTO_DESCUENTO set precio = P_PRECIO, descuento=P_DESCUENTO
	where idinversion  = P_ID 	and codigoproducto = P_PRODUCTO;
    
    UPDATE T_ICOM_INVERSION_PRODUCTO SET PRECIOPROMO=P_PRECIO, DESCUENTOMANUAL =P_DESCUENTO
    WHERE idinversion = P_ID and codigoproducto = P_PRODUCTO and tipo = p_tipo;

  end SP_ACTUALIZA_PRECIO_DESCUENTO;

   /*
 Procedimiento que actualiza el precio y descuento de todos los clientes 
 en la inversiÃ³n y producto modificado a la tabla T_ICOM_PRODUCTO_DESCUENTO

 P_ID 		 - Inversion
 P_PRODUCTO  - Codigo del Producto
 P_PRECIO	 - Precio modificado
 P_DESCUENTO - Descuento modificado

 Por: Ccarrasco
 Fecha: Agosto 2022
 */ 
  PROCEDURE SP_ACT_REGISTRO_PRECIO_DESC (P_ID NUMBER, P_PRODUCTO VARCHAR, P_PRECIO NUMBER, P_DESCUENTO NUMBER, P_CLIENTE VARCHAR) AS
  BEGIN
  
    --EDITA DE FORMA MASIVA
    IF( P_CLIENTE is null) THEN 
           SP_SIMULADORDESCUENTO_ACTUALIZAR(P_ID);
           UPDATE T_ICOM_INVERSION_PRODUCTO SET PRECIOPROMO=P_PRECIO, DESCUENTOMANUAL =P_DESCUENTO
           WHERE idinversion = P_ID and  (codigoproducto = P_PRODUCTO or P_PRODUCTO is null);
    END IF;
    
    --EDITA DE FORMA INDIVIDUAL
	update data.T_ICOM_PRODUCTO_DESCUENTO set precio = P_PRECIO, descuento=P_DESCUENTO
	where idinversion  = P_ID
	and (codigoproducto = P_PRODUCTO or P_PRODUCTO is null)
	AND (CODIGOCLIENTE  = P_CLIENTE or P_CLIENTE is null);
    
  end SP_ACT_REGISTRO_PRECIO_DESC;
  
  /*
     Procedimiento que graba la distrubucion de los producto regalo 
     P_ID 		- Inversion
    
     Por: JAsanza
     Fecha: Marzo 2023      */
     PROCEDURE SP_DISTRIBUCIONPROD (P_IDINVERSION NUMBER, P_MES_PROMEDIO NUMBER, P_PORCENTAJEMINIMO NUMBER ) AS
        V_PORCENTAJEMINIMO NUMBER;
     BEGIN
        --Borramos la distribuciÃ³n existente
        delete from data.t_icom_productodistribucion
        where idinversion = p_idinversion ;
        commit;
        
        /*OBTENER LA COMPANIA DE LA INVERSION*/
        --Busca el %minimo en tablas generales 
        select  PK_ICOM_COMMONS.f_traervalorudc('ICOM_PARAM', '13', COMPANIA )/100 into  V_PORCENTAJEMINIMO from data.t_icom_inversiones where id = p_idinversion and rownum=1;

        --guardamos la distribucion
        insert into data.t_icom_productodistribucion
        (idinversion, codigoproducto, producto, codigoregalo, regalo, codigopdv, nombrepdv,
         total, cantidadonpacks, sellout, minimo, disponible) 
         ( SELECT p_idinversion, W.CODIGOPRODUCTO, W.PRODUCTO,W.CODIGOREGALO, W.REGALO, W.CODIGOPDV, NULL, 
                NVL((SUM(V.VALORUNIDAD)/(P_MES_PROMEDIO)),0) TOTAL, 
                ((NVL((SUM(V.VALORUNIDAD)/(P_MES_PROMEDIO)),0)*(1+(max(w.DISTRIBUCIONCRECIMIENTO)/100)) )*max(w.DISTRIBUCIONAPLICACION)/100 ), 
                MAX(W.SELLOUT) SELLOUT, MAX(W.MINIMO) MINIMO, MAX(W.DISPONIBLE) DISPONIBLE
            FROM (
                    --consulta cliente - producto - regalo
                    SELECT A.CODIGOPRODUCTO, CODIGOBARRA, A.PRODUCTO, A.CODIGOREGALO, A.REGALO, B.CODIGOPDV, --,B.RAZONSOCIAL NOMBREPDV,
                    A.MINIMO, A.DISPONIBLE, B.DISTRIBUCIONAPLICACION, B.DISTRIBUCIONCRECIMIENTO, A.SELLOUT
                    FROM DATA.VT_ICOM_PRODUCTO_DIS_PARAMETRO a
					inner join DATA.T_ICOM_CLIENTE_PDV b on (A.IDINVERSION =b.IDINVERSION )
                    WHERE A.IDINVERSION = p_idinversion
                  ) W
            LEFT JOIN ( select   r.CODIGOPDV CODIGOPDV, S.CODIGOBARRA,S.VALORUNIDAD
						from t_trad_sellout S 
							left JOIN t_trad_clienteruc R ON (R.ruc=S.ruc AND S.FECHA BETWEEN  R.FECHADESDE AND NVL(r.fechahasta, SYSDATE))
						--	LEFT JOIN T_TRAD_CLIENTE C ON (C.CODIGOCLIENTE=S.CODIGOCLIENTE)
						WHERE fecha between trunc(ADD_MONTHS(sysdate, -(P_MES_PROMEDIO)),'MM')  and sysdate )   V 
					ON (V.Codigopdv =w.codigopdv and V.CODIGOBARRA =W.CODIGOBARRA)  
            GROUP BY p_idinversion, W.CODIGOPRODUCTO, W.PRODUCTO,W.CODIGOREGALO,W.REGALO,W.CODIGOPDV )
         ;
        commit;
        
        --grabar los datos adicionales 
        update data.t_icom_productodistribucion k
            set ( k.DISPONIBLEONPACKS, k.MINIMOBULTO, k.BULTOAJUSTADO, k.PAQUETESFINAL) = 
                ( select  CASE WHEN k.SELLOUT=0 THEN 0 ELSE ((k.CANTIDADONPACKS/tot.cantidad)* k.DISPONIBLE)  END,
                      CASE WHEN SELLOUT=0 THEN 0 WHEN ((k.CANTIDADONPACKS/tot.cantidad)* k.DISPONIBLE) >= k.minimo*P_PORCENTAJEMINIMO THEN 
                               ROUND(ceil(((((k.CANTIDADONPACKS/tot.cantidad)* k.DISPONIBLE))/k.minimo)*10)/10)
                           ELSE 0 END,
                      CASE WHEN (CASE WHEN SELLOUT=0 THEN 0 
                                      WHEN ((k.CANTIDADONPACKS/tot.cantidad)* k.DISPONIBLE) >= k.minimo*P_PORCENTAJEMINIMO THEN 
                                          ROUND(ceil(((((k.CANTIDADONPACKS/tot.cantidad)* k.DISPONIBLE)  )/k.minimo) *10)/10)
                                      ELSE 0 END) >=1 THEN  
                               CASE WHEN ((k.CANTIDADONPACKS/tot.cantidad)* k.DISPONIBLE) >= k.minimo*P_PORCENTAJEMINIMO THEN 
                                        ROUND(ceil(((((k.CANTIDADONPACKS/tot.cantidad)* k.DISPONIBLE)  )/k.minimo) *10)/10)
                                    ELSE 0 END
                           ELSE CASE WHEN (CASE WHEN k.SELLOUT=0 THEN 0 
                                                ELSE ((k.CANTIDADONPACKS/tot.cantidad)* k.DISPONIBLE)  END)>= MINIMO*V_PORCENTAJEMINIMO THEN 1 
                                     ELSE  0 END END,     
                      CASE WHEN (CASE WHEN SELLOUT=0 THEN 0                   
                                      WHEN ((k.CANTIDADONPACKS/tot.cantidad)* k.DISPONIBLE) >= k.minimo*P_PORCENTAJEMINIMO THEN 
                                          ROUND(ceil(((((k.CANTIDADONPACKS/tot.cantidad)* k.DISPONIBLE)  )/k.minimo) *10)/10)
                                      ELSE 0 END) >=1 THEN  
                               CASE WHEN ((k.CANTIDADONPACKS/tot.cantidad)* k.DISPONIBLE) >= k.minimo*P_PORCENTAJEMINIMO THEN 
                                        ROUND(ceil(((((k.CANTIDADONPACKS/tot.cantidad)* k.DISPONIBLE)  )/k.minimo) *10)/10)
                                    ELSE 0 END
                           ELSE CASE WHEN (CASE WHEN k.SELLOUT=0 THEN 0 
                                                ELSE ((k.CANTIDADONPACKS/tot.cantidad)* k.DISPONIBLE)  END)>= MINIMO*V_PORCENTAJEMINIMO THEN 1 
                                     ELSE  0 END END * MINIMO                
                  from ( SELECT o.CODIGOPRODUCTO, o.CODIGOREGALO, decode(nvl(SUM(o.CANTIDADONPACKS),0),0,1,SUM(o.CANTIDADONPACKS))  cantidad 
                    FROM data.t_icom_productodistribucion o
                    where o.idinversion = p_idinversion 
                    group by o.CODIGOPRODUCTO, o.CODIGOREGALO ) tot
                  where k.codigoproducto = tot.CODIGOPRODUCTO 
                    and k.codigoregalo = tot.CODIGOREGALO
                    --and k.codigopdv = tot.codigopdv   
                )
        where k.idinversion = p_idinversion ;
        
        commit;   
        /*
        --actualiza el total
        UPDATE t_icom_producto_dis_parametro  P
        SET (DISPONIBLE, SELLOUT)=
        --OnPacks
        (SELECT sum(nvl(DISPONIBLEONPACKS,0)), SUM(nvl(total,0))
         FROM data.t_icom_productodistribucion Z
         WHERE z.idinversion= p.idinversion and z.CODIGOPRODUCTO=P.CODIGOPRODUCTO AND z.CODIGOREGALO=P.CODIGOREGALO)
        WHERE idinversion = p_idinversion;
          */  
     END SP_DISTRIBUCIONPROD;

    /*Procedimiento que valida que exista los mismo cliente y productos en descuento*/
    PROCEDURE SP_descuentoValidacion (P_ID NUMBER) AS
        v_cuenta number;
    BEGIN
    
    -- VLIDA TODAS LAS HIJAS EN EL CASO QUE SEA PADRE
        FOR INVERSION IN (SELECT * FROM T_ICOM_INVERSIONES WHERE ID=P_ID OR IDGRUPO=P_ID) LOOP
        
            --IF(INVERSION.COMPANIA='00003') THEN 
           --     RETURN;
           -- END IF;
            
            v_cuenta := PK_ICOM_COMMONS.F_PRODUCTO_TODOS(P_ID);
            CONTINUE WHEN nvl(v_cuenta,0) = 1; 
            select count(1) into v_cuenta from data.t_icom_producto_descuento where idinversion = INVERSION.id ;
            CONTINUE WHEN nvl(v_cuenta,0) = 0; 
            
            /*if nvl(v_cuenta,0) = 0 then
                return ;
            end if;*/
            
            begin
                --busco si un producto no tienen descuento
                select count(1)
                into v_cuenta 
                from ( (select codigocliente, codigoproducto 
                           from data.t_icom_producto_descuento 
                           where idinversion = INVERSION.id
                           minus
                           select codigocliente, codigoproducto 
                           from data.VT_ICOM_INVERSION_CLI_PRO
                           where idinversion = INVERSION.id) 
                       union
                       (select codigocliente, codigoproducto 
                           from data.VT_ICOM_INVERSION_CLI_PRO
                           where idinversion = INVERSION.id
                           minus
                           select codigocliente, codigoproducto 
                           from data.t_icom_producto_descuento 
                           where idinversion = INVERSION.id) ) ;
            exception when no_data_found then
                v_cuenta := 0 ;
            end ;    
            if (nvl(v_cuenta,0)>0) then 
                raise_application_error(-20000,'Error los productos con descuento no son iguales en la inversion: '||INVERSION.id);
            end if;   
            v_cuenta := 0 ;
            
            ---verifica que esten echos los calculos 
            begin 
                select  sum(preciolista) into v_cuenta from  t_icom_producto_descuento 
                   where  IDinversion=INVERSION.id;
            end;
             if (nvl(v_cuenta,0)=0) then 
                raise_application_error(-20000,'No existen valores calculados en la herramienta de descuento para la inversion: '||INVERSION.id);
            end if;   
            v_cuenta := 0 ;
            
            --Agrupar por codigogrupo y sum(nvl(preciolista,0))=0 => error caso contrario esta bien
            begin
                select count(1) into v_cuenta
                from ( select codigogrupo, sum(nvl(preciolista,0)) preciolista 
                       from data.vt_icom_productodescuento_f
                       where idinversion = INVERSION.id 
                       group by codigogrupo ) dato
                where nvl(dato.preciolista,0) = 0 ;
            exception when no_data_found then
                v_cuenta := 0 ;    
            end;
            if (nvl(v_cuenta,0)>0) then 
                raise_application_error(-20000,'Existen clientes con productos sin precio en la inversion: '||INVERSION.id);
            end if;   
        
        END LOOP;
        
    END SP_descuentoValidacion;
    
    /*Procedimiento que valida que exista los productos del regalo en la inversion */
    PROCEDURE SP_productoValidacion (P_ID NUMBER) AS
        v_cuenta number;
    BEGIN
       begin
            --busco si un producto regalo no esta en la inversion
            select count(1)
            into v_cuenta 
            from data.t_icom_producto_dis_parametro 
            where idinversion = p_id
            and ( codigoproducto not in ( select codigoproducto from data.t_icom_inversion_producto where idinversion = p_id and tipo = 1 ) 
            or codigoregalo not in ( select codigoproducto from data.t_icom_inversion_producto where idinversion = p_id and tipo = 2 ) ) ;
        exception when no_data_found then
            v_cuenta := 0 ;
        end ;    
        if (nvl(v_cuenta,0)>0) then 
            raise_application_error(-20000,'Existen productos regalo que no se encuentran en la inversion');
        end if;   
        
    END SP_productoValidacion;
    
    /*Funcion que retorna 1 si la inversion ha usuado la herramienta de descuento 0 caso contrario*/
    FUNCTION F_TIENEDESCUENTO ( P_ID NUMBER ) RETURN NUMBER AS
        v_cuenta number;
    BEGIN
         select count(1)   into v_cuenta 
            from data.t_icom_producto_descuento 
            where idinversion = P_ID ;
        
        if nvl(v_cuenta,0) > 0 then    
            return 1;
        end if;
        
        return 0;
    END F_TIENEDESCUENTO ;
    
    PROCEDURE SP_INFORMACION_CREAR  (
            P_CODMODULO VARCHAR2,
            P_CODEMPRESA VARCHAR2,
            P_OBJETOCLASE  VARCHAR2,
            P_OBJETOID VARCHAR2,
            P_OBJETOTIPO VARCHAR2,
            P_OBJETOCONTENIDO CLOB,
            P_FECHACREACION DATE DEFAULT SYSDATE,
            P_ID IN OUT NUMBER  
    ) AS
    V_ID NUMBER;
    v_cuenta NUMBER;
    BEGIN

        V_ID:=P_ID;
        if (V_ID is null)then
            V_ID:=pk_commons.f_secuencia('T_COMENTARIO');
        end if;
        
        MERGE INTO t_comentario cli
        USING (
            SELECT 
                 
                P_CODMODULO CODMODULO ,
                TRIM(TO_CHAR(P_CODEMPRESA,'00000')) CODEMPRESA,
                P_OBJETOCLASE  OBJETOCLASE,
                TO_CHAR(P_OBJETOID) OBJETOID,
                P_OBJETOTIPO OBJETOTIPO,
                P_OBJETOCONTENIDO OBJETOCONTENIDO,
                nvl(v('user'),'ORCL') NOMBREUSUARIO,
                P_FECHACREACION FECHACREACION ,
                DECODE (P_OBJETOTIPO ,'COMUNICADO',V_ID,NULL) id
            FROM DUAL
        ) arc
        ON (    1=1
            AND CLI.IDOBJETO=arc.OBJETOID 
            and CLI.CLASEOBJETO=arc.OBJETOCLASE 
            and CLI.TIPOCOMENTARIO=arc.OBJETOTIPO 
            and CLI.CODMODULO=arc.CODMODULO 
            and CLI.CODEMPRESA=arc.CODEMPRESA
            and (cli.id=arc.id or arc.id is null )
        )
        WHEN MATCHED THEN
            UPDATE SET
                cli.FECHACREACION=arc.FECHACREACION,               
                cli.ZCONTENIDO=arc.OBJETOCONTENIDO,
                cli.NOMBREUSUARIO=arc.NOMBREUSUARIO 
        WHEN NOT MATCHED THEN
            
            INSERT (   id,     IDOBJETO,     CLASEOBJETO, TIPOCOMENTARIO,ETAPA,         ZCONTENIDO,     CODMODULO,     CODEMPRESA,    NOMBREUSUARIO,     FECHACREACION, OPERACION, IDOBJETONUM)
            VALUES ( V_ID, arc.OBJETOID, arc.OBJETOCLASE, arc.OBJETOTIPO, null,arc.OBJETOCONTENIDO, arc.CODMODULO, arc.CODEMPRESA,arc.NOMBREUSUARIO, arc.FECHACREACION,      null,     null) ;
        p_ID:=V_ID;
        
            COMMIT;
    END SP_INFORMACION_CREAR;
    PROCEDURE SP_COMUNICADO_ACEPTAR (P_IDCOMUNICADO NUMBER,P_CODMODULO VARCHAR2,P_CODEMPRESA VARCHAR2,P_FECHACREACION DATE)AS
    V_ID NUMBER;
    BEGIN
        V_ID:=pk_commons.f_secuencia('T_CORP_NOTIFICACION');        
        INSERT INTO T_CORP_NOTIFICACION (ID  ,  IDCOMENTARIO,NOMBREUSUARIODESTINATARIO,ASUNTO,  CODMODULO,  CODEMPRESA,  FECHACREACION, FECHALEIDO, ESTADO, LEIDO, NOMBREUSUARIOREMITENTE) 
        VALUES                          (V_ID,P_IDCOMUNICADO,nvl(v('user'),'ORCL')    , 'N/A',P_CODMODULO,P_CODEMPRESA,P_FECHACREACION, SYSDATE   ,      1,     1, nvl(v('user'),'ORCL'));
        COMMIT;
    END SP_COMUNICADO_ACEPTAR;
    FUNCTION  F_COMUNICADO_USUARIO (P_CODMODULO VARCHAR2,P_CODEMPRESA VARCHAR2,P_USUARIO VARCHAR2) RETURN NUMBER AS
    V_RETORNO NUMBER;
    BEGIN
       V_RETORNO :=0;
       SELECT COUNT( DISTINCT 1) 
       INTO V_RETORNO 
       FROM VT_ICOM_COMUNICADOS A
       WHERE NOT EXISTS  (SELECT * FROM VT_ICOM_COMUNICADO_USUARIO B WHERE 1=1 AND ESTADO='Vigente' AND NOMBREUSUARIODESTINATARIO =P_USUARIO AND A.ID=B.IDCOMENTARIO AND A.COMPANIA= B.COMPANIA AND  A.CODMODULO=B.CODMODULO)
       AND ESTADO='Vigente'
        AND COMPANIA= P_CODEMPRESA AND  CODMODULO=P_CODMODULO
       ORDER BY A.INFO_FECHACREACION DESC,A.ID DESC;
       RETURN V_RETORNO  ;
    END F_COMUNICADO_USUARIO ;
    
    FUNCTION F_INVERSIONVALIDATIPOINVERSION(P_IDINVERSION NUMBER, TIPO VARCHAR2, 
    P_CODGRUPO VARCHAR2 DEFAULT NULL, P_ENCUESTA NUMBER DEFAULT 1 )RETURN NUMBER AS
     V_RETURN NUMBER:=0;
     v_codigorigen data.vt_gzm_cliente.codigoorigen%type;
      v_canal varchar2(500);
    BEGIN
        IF (TIPO ='DESCUENTO') THEN
        
            if p_codgrupo is not null then 
                select CODIGOORIGEN, CANAL into v_codigorigen , v_canal
                from data.vt_gzm_cliente where codigogrupo = p_codgrupo and codigogrupo=codigocliente ;
            else 
                
                    select max(CANAL) into v_canal from T_ICOM_INVERSION_cliente_g i
                    inner join data.vt_gzm_cliente c  on i.CODIGOGRUPO=c.codigocliente
                    where i.idinversion=P_IDINVERSION and c.CANAL is not null;
            end if;
            
            if(v_canal='TRADICIONAL') then 
                return 0;
            end if;
            
            if nvl(v_codigorigen ,'NAC') != 'EXT' then
            
                select  COUNT(DISTINCT 1) INTO V_RETURN 
                from t_icom_inversiones I 
                INNER JOIN vt_icom_tipo T ON I.idtipo=T.idtipo
                where   I.ID=P_IDINVERSION AND  T.idtipo in (6,22,23,10);--DESCUENTOS
                
                 if(V_RETURN=1 AND P_ENCUESTA=1) then 
                     SELECT COUNT(DISTINCT 1) INTO V_RETURN FROM VT_ICOM_PROCESO A
                    INNER JOIN T_ICOM_INVERSION_PROCESO P ON A.IDPROCESO=P.IDPROCESO
                    WHERE IDINVERSION=P_IDINVERSION AND A.ESTADO=1 AND a.IDPROCESO IN (12,2,3);
                    
                    V_RETURN:= case when V_RETURN>1 then 1 else V_RETURN end;
                    
                end if;
                
            else
               V_RETURN := 0 ;
            end if;   
        END IF;
        IF (TIPO ='EXHIBICION') THEN
            --RETURN 1 ;
                select  COUNT(DISTINCT 1) INTO V_RETURN 
                from t_icom_inversiones I 
                INNER JOIN vt_icom_tipo T ON I.idtipo=T.idtipo
                where   I.ID=P_IDINVERSION AND T.idtipo in (14);--EXHIBICIONES
                
                if(V_RETURN=1) then 
                     SELECT COUNT(DISTINCT 1) INTO V_RETURN FROM VT_ICOM_PROCESO A
                    INNER JOIN T_ICOM_INVERSION_PROCESO P ON A.IDPROCESO=P.IDPROCESO
                    WHERE IDINVERSION=P_IDINVERSION AND A.ESTADO=1 AND a.IDPROCESO IN (12,3);
                    
                    V_RETURN:= case when V_RETURN>1 then 1 else V_RETURN end;
                end if;
                
        END IF;
        IF (TIPO ='TOMALOCAL') THEN
                select  COUNT(DISTINCT 1) INTO V_RETURN 
                from vt_icom_inversiones I 
                INNER JOIN vt_icom_tipo T ON I.idtipo=T.idtipo
                where   I.ID=P_IDINVERSION AND  T.idtipo in (16);--TOMALOCAL
        END IF;
--        IF (TIPO ='ONPACK') THEN
--                select  COUNT(DISTINCT 1) INTO V_RETURN 
--                from vt_icom_inversiones I 
--                INNER JOIN vt_icom_tipo T ON I.idtipo=T.idtipo
--                where   I.ID=P_IDINVERSION AND  T.descripcion in ('ONPACK');--TOMALOCAL
--        END IF;
        
        RETURN V_RETURN ;
    EXCEPTION WHEN OTHERS THEN
        V_RETURN :=0;
        RETURN V_RETURN ;
    END F_INVERSIONVALIDATIPOINVERSION;
    
    FUNCTION F_CORREOEJECUTIVO(P_EJECUTIVO VARCHAR2 DEFAULT NULL,P_CODIGOGRUPO VARCHAR2 DEFAULT NULL,P_NOMBREUSUARIO VARCHAR2 DEFAULT NULL,P_TIPO VARCHAR2 DEFAULT 'MAIL') RETURN VARCHAR2 AS
        V_RETORNO VARCHAR2(500);
    BEGIN
        SELECT
            CASE
                WHEN P_TIPO='USUARIO' THEN b.NOMBREUSUARIO
                WHEN P_TIPO='NOMBRE' THEN trim( b.NOMBRES||' '||b.APELLIDOS)
                WHEN P_TIPO='MAIL' THEN b.EMAIL
            END RETORNO 
            INTO V_RETORNO

        FROM data.VT_GZM_CLIENTE a
        INNER join data.VT_CORP_USUARIO b on (a.EJECUTIVO = b.NUMEROIDENTIFICACION)
        where 1=1
        AND (A.CodigoCLIENTE= A.Codigogrupo)
        AND (a.EJECUTIVO= P_EJECUTIVO OR P_EJECUTIVO IS NULL)
        AND (B.NOMBREUSUARIO= P_NOMBREUSUARIO OR P_NOMBREUSUARIO IS NULL)
        AND (A.Codigogrupo= P_Codigogrupo OR P_Codigogrupo IS NULL)
        AND b.EMAIL IS NOT NULL
        GROUP BY CASE WHEN P_TIPO='USUARIO' THEN b.NOMBREUSUARIO WHEN P_TIPO='NOMBRE' THEN trim( b.NOMBRES||' '||b.APELLIDOS) WHEN P_TIPO='MAIL' THEN b.EMAIL END

        ORDER BY 1;
        V_RETORNO:=CASE WHEN V_RETORNO IS NULL THEN '' ELSE ','END ||V_RETORNO;
        DBMS_OUTPUT.PUT_LINE('V_RETORNO:'||V_RETORNO);
        return V_RETORNO;
    EXCEPTION WHEN OTHERS THEN
        V_RETORNO:=' ';
        DBMS_OUTPUT.PUT_LINE('V_RETORNO:'||V_RETORNO);
        DBMS_OUTPUT.PUT_LINE('error:'||sqlerrm);

        return V_RETORNO;
    END F_CORREOEJECUTIVO;
    FUNCTION GET_ITEM_LABEL(P_APP_ID NUMBER, P_APP_PAGE_ID NUMBER, P_ITEM_NAME VARCHAR2) RETURN VARCHAR2 AS
        v_label VARCHAR2(255);
    BEGIN
        SELECT LABEL
        INTO v_label
        FROM apex_application_page_items
        WHERE application_id = P_APP_ID
        AND page_id = P_APP_PAGE_ID
        AND item_name = P_ITEM_NAME; -- Cambia por el nombre del elemento.
        return v_label;
    exception when others then return '' ;
    END GET_ITEM_LABEL;

   
END PK_ICOM_HERRAMIENTAS;
/
/

