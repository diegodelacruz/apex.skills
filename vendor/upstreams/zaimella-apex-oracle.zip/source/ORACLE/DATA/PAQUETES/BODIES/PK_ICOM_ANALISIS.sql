﻿prompt Esquema DATA para codigo PL/SQL
alter session set current_schema=DATA;

prompt PROD PACKAGE_BODY DATA.PK_ICOM_ANALISIS

  CREATE OR REPLACE EDITIONABLE PACKAGE BODY PK_ICOM_ANALISIS AS

/*Borrar analisi de rentabilidad */

    PROCEDURE SP_REINICIARANALISIS(P_ID NUMBER) AS
        v_idgrupo number;
    BEGIN
        DELETE T_ICOM_INVERSION_ANALISIS WHERE IDINVERSION=P_ID;
        DELETE t_icom_inversion_gasto WHERE IDINVERSION=P_ID AND CALCULADO=1;
        SP_borrarObjetivoKpi(P_ID);
        --delete data.T_ICOM_INVERSION_KPI 	where idinversion = P_ID;

        delete from t_icom_inversion_ventas where idinversion=p_id;

        UPDATE t_icom_inversiones SET
        sellin=0, sellinund=0, sellout=0, selloutund=0, SITUACIONACTUALMES= 0
        WHERE ID=P_ID;

        select idgrupo into v_idgrupo from data.t_icom_inversiones where id = p_id;

        if nvl(v_idgrupo,0) > 0 then
            --en caso de que exista debe reiniciar el analisis de la inversion grupal
            SP_REINICIARANALISIS(v_idgrupo);
        end if;

    END SP_REINICIARANALISIS;


    /*Guarda informacion del analisis t_icom_inversion_analisis
    y actuliza los filtros en la tabla t_icom_inversiones*/
    PROCEDURE SP_GUARDAR_ANALISIS(P_ID NUMBER, P_GRUPAL NUMBER, P_ANIO NUMBER,P_PERIODO VARCHAR, P_GRAFICO VARCHAR, P_TIPOEJECUCION NUMBER DEFAULT 0) AS

    V_FECHA_ANALISIS DATE;
    V_PERIODO VARCHAR(250);
    V_ANIO NUMBER;

    BEGIN
        IF (P_GRAFICO= '1') then
            PK_ICOM_ANALISIS.SP_RELACION_SELL_IN_OUT(P_ID => P_ID, P_GRUPAL => P_GRUPAL,
            P_TIEMPO => P_ANIO, P_PERIODO=> P_PERIODO);

        ELSIF (P_GRAFICO = '2') then

            PK_ICOM_ANALISIS.SP_RELACION_LINEANEGOCIO(P_ID => P_ID, P_GRUPAL => P_GRUPAL,
            P_TIEMPO => P_ANIO, P_PERIODO=> P_PERIODO);

        ELSIF (P_GRAFICO= '3' ) THEN

            DELETE T_ICOM_INVERSION_ANALISIS WHERE IDINVERSION=P_ID AND ANALISISTIPO='PDV_ANALISIS' ;
            V_PERIODO:=P_PERIODO;
            V_ANIO :=P_ANIO;
            V_FECHA_ANALISIS:=SYSDATE;

            IF (P_TIPOEJECUCION=1) THEN
                  SELECT ANALISISPERIODO,  ANALISISANIO,FECHAANALISIS
                  INTO V_PERIODO, V_ANIO, V_FECHA_ANALISIS FROM
                  DATA.T_ICOM_INVERSIONES  WHERE ID=P_ID;
            END IF;

            INSERT INTO T_ICOM_INVERSION_ANALISIS
                (IDINVERSION, ANALISISTIPO, TIPO, TIPO1, PERIODO, VALOR , ORDEN)

                --VENTAS POR PERIODO PROMEDIO
                SELECT P_ID, 'PDV_ANALISIS',  P.CODIGOPDV||'-'|| P.CODIGODISTRIBUIDOR,'VENTA_PERIODO'
                   ,P.ANIO|| ' '||P.PERIODO PIVOT, NVL(SUM(S.VALORVENTA)/V_PERIODO,0) VALOR ,    (P.ANIO/100)+(MIN(P.MES)/10000) ORDEN
                   --PUNTOS DE VENTAS CON PERIODO Y AÃ¯Â¿Â½OS
                    FROM (SELECT R.ANIO, R.PERIODO, R.MES, PDV.CODIGOPDV, PDV.CODIGODISTRIBUIDOR, PDV.RUC, PDV.RAZONSOCIAL NOMBREPDV, PDV.DISTRIBUIDOR, PDV.ESCALA, '' CODIGOGRUPO, NULL CODIGOLOCAL
                                -- PERIODOS Y AÃ¯Â¿Â½OS
                                FROM (SELECT A.ANIO, D.PERIODODESCRIPCION PERIODO, D.ORDEN MES
                                      --AÃ¯Â¿Â½OS DE ANALISIS
                                      FROM ( SELECT Level NUMERO, TO_NUMBER(TO_CHAR(V_FECHA_ANALISIS,'YYYY'))-LEVEL+1 ANIO
                                               FROM Dual CONNECT BY Level <= V_ANIO) A,
                                               -- PERIODO DE ANALISIS
                                           VT_ICOM_PERIODOS D
                                      WHERE D.CODIGO=V_PERIODO /* ORDER BY A.ANIO , ORDEN*/ ) R, VT_ICOM_CLIENTE_PDV PDV
                                WHERE PDV.idinversion=P_ID ) P
                      LEFT JOIN  MVT_TRAD_SELLOUT  S ON (P.ANIO= TO_NUMBER(TO_CHAR(FECHA,'YYYY')) AND P.MES=TO_NUMBER(TO_CHAR(FECHA,'MM'))
                                                        AND P.CODIGOPDV=S.CODIGOPDV /*AND P.CODIGODISTRIBUIDOR=S.codigoGRUPO*/)
                    GROUP BY  P.ANIO, P.PERIODO,P.CODIGOPDV, P.CODIGODISTRIBUIDOR, P.NOMBREPDV, P.DISTRIBUIDOR, P.RUC, P.ESCALA
                UNION
                --VENTAS POR PERIODO TOTAL  VENTA_PERIODO_T
                /*P.ANIO|| ' '||P.PERIODO||' TOTAL' PIVOT    20 ORDEN   VENTA_PERIODO_T TIPO1*/
                --(IDINVERSION, ANALISISTIPO, TIPO, TIPO1, PERIODO, VALOR , ORDEN)
                SELECT P_ID, 'PDV_ANALISIS',  P.CODIGOPDV||'-'|| P.CODIGODISTRIBUIDOR, 'VENTA_PERIODO_T'
                   ,P.ANIO|| ' '||P.PERIODO||' TOTAL' PIVOT, NVL(SUM(S.VALORVENTA),0) VALOR ,  20 +(P.ANIO/100)+(MIN(P.MES)/10000) ORDEN
                   --PUNTOS DE VENTAS CON PERIODO Y AÃ¯Â¿Â½OS
                    FROM (SELECT ANIO, PERIODO, MES, CODIGOPDV, CODIGODISTRIBUIDOR, RUC, RAZONSOCIAL NOMBREPDV, DISTRIBUIDOR, ESCALA
                                -- PERIODOS Y AÃ¯Â¿Â½OS
                                FROM (SELECT ANIO, PERIODODESCRIPCION PERIODO, ORDEN MES
                                    --AÃ¯Â¿Â½OS DE ANALISIS
                                        FROM ( SELECT Level NUMERO, TO_NUMBER(TO_CHAR(V_FECHA_ANALISIS,'YYYY'))-LEVEL+1 ANIO
                                               FROM Dual CONNECT BY Level <= V_ANIO) A
                                                -- PERIODO DE ANALISIS
                                                ,VT_ICOM_PERIODOS P WHERE CODIGO=V_PERIODO /* ORDER BY A.ANIO , ORDEN*/ ) P
                                    , VT_ICOM_CLIENTE_PDV PDV WHERE idinversion=P_ID) P
                      LEFT JOIN  MVT_TRAD_SELLOUT  S ON (P.ANIO= TO_NUMBER(TO_CHAR(FECHA,'YYYY')) AND P.MES=TO_NUMBER(TO_CHAR(FECHA,'MM'))
                                                        AND P.CODIGOPDV=S.CODIGOPDV /*AND P.CODIGODISTRIBUIDOR=S.codigoGRUPO*/)
                    GROUP BY  P.ANIO, P.PERIODO,P.CODIGOPDV, P.CODIGODISTRIBUIDOR, P.NOMBREPDV, P.DISTRIBUIDOR, P.RUC, P.ESCALA
                UNION
                --- MEDIANA
                /*CON LOS DATOS T_ICOM_INVERSION_ANALISIS WHERE IDINERSION AND ANALISISTIPO='PDV_ANALISIS' AND TIPO1='VENTA_PERIODO' AND VALOR>=100
                ' MEDIANA' PIVOT  25 ORDEN  FUNCION MEDIANA VALOR  'MEDIANA' TIPO1
                */
                --VENTAS ANUALES
                SELECT   P_ID, 'PDV_ANALISIS',  P.CODIGOPDV||'-'|| P.CODIGODISTRIBUIDOR,'VENTA_ANUALES',
                       'TOTAL '||P.ANIO PIVOT,     NVL(SUM(S.VALORVENTA),0) VALOR ,  30+(P.ANIO/1000)+(MIN(P.NUMERO)/10000) ORDEN
                       --PUNTOS DE VENTAS Y AÃ¯Â¿Â½OS
                        FROM (SELECT ANIO, NUMERO,  CODIGOPDV, CODIGODISTRIBUIDOR, RUC, RAZONSOCIAL NOMBREPDV, DISTRIBUIDOR, ESCALA
                                    --  AÃ¯Â¿Â½OS
                                    FROM (SELECT Level NUMERO, TO_NUMBER(TO_CHAR(V_FECHA_ANALISIS,'YYYY'))-LEVEL+1 ANIO FROM Dual CONNECT BY Level <= V_ANIO) A
                                        , VT_ICOM_CLIENTE_PDV PDV WHERE idinversion=P_ID) P
                          LEFT JOIN  MVT_TRAD_SELLOUT  S ON (P.ANIO= TO_NUMBER(TO_CHAR(FECHA,'YYYY'))
                          AND P.CODIGOPDV=S.CODIGOPDV /*AND P.CODIGODISTRIBUIDOR=S.codigoGRUPO*/)
                        GROUP BY  P.ANIO, P.CODIGOPDV, P.CODIGODISTRIBUIDOR, P.NOMBREPDV, P.DISTRIBUIDOR, P.RUC, P.ESCALA
                --VENTAS METAS
               UNION
               SELECT  P_ID, 'PDV_ANALISIS',  P.CODIGOPDV||'-'|| P.CODIGODISTRIBUIDOR, 'VENTA_META',
                       CASE WHEN ORDEN=1 THEN 'META MENSUAL'
                            WHEN ORDEN=2 THEN 'META PERIODO'
                            WHEN ORDEN=3 THEN 'META ANUAL' END PIVOT,
                       CASE WHEN ORDEN=1 THEN METAMENSUAL
                            WHEN ORDEN=2 THEN METAMENSUAL * V_PERIODO
                            WHEN ORDEN=3 THEN METAMENSUAL *12 END VALOR, 40+ORDEN ORDEN
               FROM (SELECT Level ORDEN  FROM Dual CONNECT BY Level <= 3 ) T, VT_ICOM_CLIENTE_PDV P
               WHERE idinversion=P_ID
               ---CRECIMIENTO VS META
               UNION
               SELECT P_ID, 'PDV_ANALISIS',  P.CODIGOPDV||'-'|| P.CODIGODISTRIBUIDOR, 'CRECIMIENTO_META','CRE VS META '||P.ANIO PIVOT,
                      CASE WHEN SUM(S.VALORVENTA)> 0 THEN  MAX(META_ANAUL)/ SUM(S.VALORVENTA)-1 ELSE 0 END *100 VALOR ,  50+ (P.ANIO/1000) ORDEN
               --PUNTOS DE VENTAS Y AÃ¯Â¿Â½OS
               FROM (SELECT ANIO, NUMERO,  CODIGOPDV, CODIGODISTRIBUIDOR, RUC, RAZONSOCIAL NOMBREPDV, DISTRIBUIDOR, ESCALA, METAMENSUAL *12 META_ANAUL
                     --  AÃ¯Â¿Â½OS
                     FROM (SELECT Level NUMERO, TO_NUMBER(TO_CHAR(V_FECHA_ANALISIS,'YYYY'))-LEVEL+1 ANIO FROM Dual CONNECT BY Level <= V_ANIO) A
                                        , VT_ICOM_CLIENTE_PDV PDV WHERE idinversion=P_ID) P
                           LEFT JOIN  MVT_TRAD_SELLOUT  S ON (P.ANIO= TO_NUMBER(TO_CHAR(FECHA,'YYYY'))
                                                                     AND P.CODIGOPDV=S.CODIGOPDV /*AND P.CODIGODISTRIBUIDOR=S.codigoGRUPO*/)
               GROUP BY  P.ANIO, P.CODIGOPDV, P.CODIGODISTRIBUIDOR, P.NOMBREPDV, P.DISTRIBUIDOR, P.RUC, P.ESCALA
               ;

                    INSERT INTO T_ICOM_INVERSION_ANALISIS
                    (IDINVERSION, ANALISISTIPO, TIPO, TIPO1, PERIODO, VALOR , ORDEN)
                    SELECT P_ID, 'PDV_ANALISIS',  TIPO, 'MEDIANA', 'MEDIANA' PIVOT, ROUND(MEDIAN(VALOR),2) VALOR , 25  ORDEN
                   --PUNTOS DE VENTAS CON PERIODO Y AÃ¯Â¿Â½OS
                    FROM T_ICOM_INVERSION_ANALISIS
                    WHERE IDINVERSION = P_ID AND ANALISISTIPO = 'PDV_ANALISIS' AND TIPO1 = 'VENTA_PERIODO'
                    AND VALOR >= 100
                    GROUP BY IDINVERSION, ANALISISTIPO, TIPO, TIPO1;
        END IF;


        IF (P_TIPOEJECUCION=0) THEN
            UPDATE T_ICOM_INVERSIONES SET
            ANALISISPERIODO=P_PERIODO ,            ANALISISANIO=P_ANIO,
            ANALISISVISTA=P_GRAFICO,             FECHAANALISIS=nvl(FECHAANALISIS, sysdate)
                WHERE ID=P_ID;
        END IF;

    END SP_GUARDAR_ANALISIS;


 /*
	Procedimiento que realizar el proceso de la relacion entre SELL IN y SELL OUT y la insercion de
	data a la tabla T_ICOM_INVERSION_ANALISIS
	Por: CCarrasco
	Fecha: Junio 2022
	*/
	PROCEDURE SP_RELACION_SELL_IN_OUT(P_ID NUMBER, P_GRUPAL NUMBER, P_TIEMPO NUMBER, P_PERIODO VARCHAR) AS
    --Declaraciones
	cursor cPeriodos is
	SELECT id_tabla, valor 	FROM data.T_CORP_UDC WHERE ID_CABECERA = 'ICOM_A1G1' AND ACTIVO = 1;
    v_pdv number;
    v_pdvlocal number ;
    v_fechaanalisis date;
	v_atipo data.t_icom_inversion_analisis.analisistipo%type;
    v_id_tipo_inversion number;
    v_compania varchar2(50);
	BEGIN
	v_atipo:='R_SELLIN_SELLOUT';

    select nvl(FECHAANALISIS, sysdate), compania into v_fechaanalisis, v_compania  from t_icom_inversiones where id=P_ID;
    --v_fechaanalisis := SYSDATE;
	--GRAFICO RELACION SELL IN - SELL OUT
	DELETE T_ICOM_INVERSION_ANALISIS WHERE IDINVERSION = P_ID AND analisisTIPO = v_atipo;
	DELETE T_ICOM_INVERSION_ANALISIS WHERE IDINVERSION = P_ID AND analisisTIPO = 'VENTAS_PERIODO';
    DELETE FROM T_ICOM_INVERSION_VENTAS WHERE IDINVERSION=P_ID;

    --VERIFICA SI TIENE PDV
    V_PDV := PK_ICOM_COMMONS.F_TIENEPDV(P_ID);
    v_pdvlocal := PK_ICOM_COMMONS.F_TIENEPDVLOCAL(P_ID);

    SELECT IDINVERSIONTIPO INTO v_id_tipo_inversion FROM DATA.T_ICOM_INVERSIONES WHERE ID = P_ID;

    --- GRAFICO Sell In / Sell Out - SituaciÃ¯Â¿Â½n Actual
	for periodo in cPeriodos loop
        --VALORES SELL IN
        insert into data.t_icom_inversion_analisis
        (IDINVERSION, ANALISISTIPO, TIPO, PERIODO, FECHA, VALOR, VALORUND, VALORCOSTO, SELECCION, TIPO1, ORDEN)
            SELECT  P_ID, v_atipo ,
            'SELL_IN' TIPO, periodo.id_tabla PERIODO, NULL,
            nvl(
                SUM(
                    CASE V_ID_TIPO_INVERSION
                        WHEN 4 THEN v.VALORVENTA3
                        ELSE v.VALORVENTA
                    END
                ) / periodo.VALOR
            ,0) venta,
            nvl(SUM(v.VALORUNIDAD)/periodo.VALOR,0) vund,
            nvl(SUM(v.VALORCOSTO)/periodo.VALOR,0) vcosto, 0 SELECCCION,periodo.VALOR,0
            from data.Vt_trad_sellIN v
            INNER JOIN T_ICOM_INVERSION_CLIENTE C ON (c.idinversion=P_ID  AND v.CODIGOCLIENTE=c.codigocliente)
            INNER JOIN ( select CODIGOPRODUCTOPADRE, IDINVERSION from  DATA.T_ICOM_INVERSION_PRODUCTO p where P.idinversion=P_ID  AND TIPO=1
                        group by IDINVERSION,  CODIGOPRODUCTOPADRE) p ON ( v.CODIGOPRODUCTOPADRE=p.CODIGOPRODUCTOPADRE )
            where FECHA  between trunc(ADD_MONTHS(v_fechaanalisis, - (periodo.VALOR)),'MM') and LAST_DAY(ADD_MONTHS(v_fechaanalisis, -1))
            and v.compania = v_compania
;

        --VALORES SELL OUT PDV
        insert into data.t_icom_inversion_analisis
        (IDINVERSION, ANALISISTIPO, TIPO, PERIODO, FECHA, VALOR, VALORUND, VALORCOSTO, SELECCION, TIPO1, ORDEN)
           (select  P_ID, v_atipo ,'SELL_OUT' TIPO, periodo.id_tabla PERIODO, NULL,
            nvl(sum(d.VALORVENTA)/periodo.VALOR,0) venta ,
            nvl(SUM(d.VALORUNIDAD)/periodo.VALOR,0) vund,
            0 vcosto, 0 SELECCCION, periodo.VALOR,0
            from ( select nvl(sum(v.VALORVENTA),0) valorventa, nvl(SUM(v.VALORUNIDAD),0) valorunidad
                   from data.MVT_TRAD_SELLOUT v
                        INNER JOIN T_ICOM_INVERSION_CLIENTE C ON (c.idinversion=P_ID  AND v.CODIGOCLIENTE=c.codigocliente)
                       -- INNER JOIN T_ICOM_INVERSION_producto  P ON (v.CODIGOPRODUCTO=p.CODIGOPRODUCTO and P.idinversion=P_ID AND TIPO=1 )
                        LEFT JOIN T_ICOM_CLIENTE_PDV PDV ON (PDV.IDINVERSION=P_ID AND v.CODIGOPDV=PDV.codigopdv)
                        LEFT JOIN  T_ICOM_CLIENTE_PDV_LOCAL CL ON (CL.idinversion=P_ID  AND v.CODIGOPDV=CL.codigopdv AND V.NUMERO=CL.NUMERO )
                   where V.FECHA  between trunc(ADD_MONTHS(v_fechaanalisis, - (periodo.VALOR)),'MM')  and LAST_DAY(ADD_MONTHS(v_fechaanalisis, -1))
                   AND EXISTS (select 1  from t_icom_inversion_PRODUCTO P where idinversion=P_ID AND TIPO=1  AND P.CODIGOBARRA=V.CODIGOBARRA)
                   AND (V_PDV=0 OR PDV.codigopdv IS NOT NULL) --- CLIENTE PDV
                   and (v_pdvlocal = 0  OR  CL.NUMERO IS NOT NULL) -- LOCALES DE CLIENTE PDV ) d
                   and v.compania = v_compania
                ) d
            );

        insert into data.t_icom_inversion_analisis
        (IDINVERSION, ANALISISTIPO, TIPO, PERIODO, FECHA, VALOR, VALORUND, VALORCOSTO, SELECCION, TIPO1, ORDEN)
            with venta_cliente_producto as (
                select  nvl(SUM(v.VALORUNIDAD)/periodo.VALOR,0) valorunidad, v.CODIGOCLIENTE, v.CODIGOPRODUCTO, max(V.FECHA ) FECHA
                   from data.MVT_TRAD_SELLOUT v
                        INNER JOIN T_ICOM_INVERSION_CLIENTE C ON (c.idinversion=P_ID  AND v.CODIGOCLIENTE=c.codigocliente)
                        LEFT JOIN T_ICOM_CLIENTE_PDV PDV ON (PDV.IDINVERSION=P_ID AND v.CODIGOPDV=PDV.codigopdv)
                        LEFT JOIN  T_ICOM_CLIENTE_PDV_LOCAL CL ON (CL.idinversion=P_ID   AND v.CODIGOPDV=CL.codigopdv AND V.NUMERO=CL.NUMERO )
                   where V.FECHA  between trunc(ADD_MONTHS(v_fechaanalisis, - (periodo.VALOR)),'MM')  and LAST_DAY(ADD_MONTHS(v_fechaanalisis, -1))
                    AND EXISTS (select 1  from t_icom_inversion_PRODUCTO P where idinversion=P_ID AND TIPO=1  AND P.CODIGOBARRA=V.CODIGOBARRA)
                   AND (V_PDV=0 OR PDV.codigopdv IS NOT NULL) --- CLIENTE PDV
                   and (v_pdvlocal = 0  OR  CL.NUMERO IS NOT NULL) -- LOCALES DE CLIENTE PDV ) d
                   and v.compania = v_compania
                   group by v.CODIGOCLIENTE, v.CODIGOPRODUCTO, periodo.VALOR
            )
            select  P_ID, v_atipo ,'SELL_OUT_PRECIO_LISTA' TIPO, periodo.id_tabla PERIODO, NULL,
            PK_ICOM_ANALISIS.F_PRECIO_LISTA(CODIGOPRODUCTO,CODIGOCLIENTE,v_fechaanalisis,v_compania)*VALORUNIDAD venta,
            VALORUNIDAD vund,
            0 vcosto, 0 SELECCCION, periodo.VALOR,0 ORDEN
            from venta_cliente_producto d
            ;

	end loop;

    --GRAFICO Sell In  - Ventas
    insert into data.t_icom_inversion_analisis
        (IDINVERSION, ANALISISTIPO, TIPO, PERIODO, FECHA,
        VALOR, VALORUND, VALORCOSTO, SELECCION, TIPO1, ORDEN)
        select  P_ID,'VENTAS_PERIODO' atipo ,'SELL_IN' TIPO,UDC.ANIO||' - '||PERIODODESCRIPCION PERIODO,NULL,
        SUM(nvl(v.VALORVENTA,0)) venta , SUM(nvl(v.VALORUNIDAD,0)) vund,SUM(nvl(v.VALORCOSTO,0)) vcosto,
        0 SELECCCION,null,UDC.ANIO||MIN(UDC.MES)
        from (SELECT A.MES, A.ANIO,PERIODODESCRIPCION
             FROM  (SELECT TO_CHAR(ADD_MONTHS(v_fechaanalisis,-LEVEL),'MM') MES,
                            TO_CHAR(ADD_MONTHS(v_fechaanalisis,-LEVEL ),'YYYY') ANIO
                            FROM Dual CONNECT BY Level <= P_TIEMPO*12) A, VT_ICOM_PERIODOS UDC
                            WHERE TO_NUMBER(A.MES)=udc.ORDEN AND UDC.codigo=P_PERIODO) udc
        LEFT JOIN (SELECT

                    SUM(
                        CASE v_id_tipo_inversion
                            WHEN 4 THEN VALORVENTA3
                            ELSE VALORVENTA
                        END
                    ) VALORVENTA, SUM(VALORUNIDAD) VALORUNIDAD, SUM(VALORCOSTO) VALORCOSTO,
                          to_char(v.fecha,'MM')MES, to_char(v.fecha,'YYYY') ANIO from
                          Vt_trad_sellIN V
                     INNER JOIN T_ICOM_INVERSION_CLIENTE C ON (c.idinversion=P_ID  AND v.CODIGOCLIENTE=c.codigocliente)
                     INNER JOIN ( select CODIGOPRODUCTOPADRE, IDINVERSION from  DATA.T_ICOM_INVERSION_producto p
                                where P.idinversion=P_ID  AND TIPO=1 group by IDINVERSION,  CODIGOPRODUCTOPADRE) P ON (v.CODIGOPRODUCTOPADRE=p.CODIGOPRODUCTOPADRE )
                     WHERE V.FECHA between trunc(ADD_MONTHS(v_fechaanalisis, -(P_TIEMPO*12)),'MM') and LAST_DAY(ADD_MONTHS(v_fechaanalisis, -1)) and v.compania = v_compania
                     GROUP BY to_char(v.fecha,'MM'),to_char(v.fecha,'YYYY')
                    ) v on udc.MES=V.MES  AND UDC.ANIO=V.ANIO
                    group by UDC.ANIO, PERIODODESCRIPCION;

    --GRAFICO Sell Out - Ventas
    insert into data.t_icom_inversion_analisis
        (IDINVERSION, ANALISISTIPO, TIPO, PERIODO, FECHA, VALOR, VALORUND, VALORCOSTO, SELECCION, TIPO1, ORDEN)
            select  P_ID,'VENTAS_PERIODO' atipo ,'SELL_OUT' TIPO,UDC.ANIO||' - '||PERIODODESCRIPCION PERIODO,NULL,
            sum(nvl(v.VALORVENTA,0)) venta ,SUM(nvl(v.VALORUNIDAD,0)) vund,
            0 vcosto, 0 SELECCCION, null,UDC.ANIO||MIN(UDC.MES)
            from (SELECT A.MES, A.ANIO,PERIODODESCRIPCION
                    FROM  (SELECT TO_CHAR(ADD_MONTHS(v_fechaanalisis,-LEVEL ),'MM') MES, TO_CHAR(ADD_MONTHS(v_fechaanalisis,-LEVEL ),'YYYY') ANIO
                            FROM Dual CONNECT BY Level <= P_TIEMPO*12) A, VT_ICOM_PERIODOS UDC
                            WHERE TO_NUMBER(A.MES)=udc.ORDEN AND UDC.codigo=P_PERIODO) udc
            LEFT JOIN (SELECT SUM(V.VALORUNIDAD)VALORUNIDAD,sum(V.VALORVENTA) VALORVENTA,
                              to_char(v.fecha,'MM')MES, to_char(v.fecha,'YYYY') ANIO
                       FROM data.MVT_TRAD_SELLOUT V
                           INNER JOIN T_ICOM_INVERSION_CLIENTE C ON (c.idinversion=P_ID  AND v.CODIGOCLIENTE=c.codigocliente)
                           LEFT JOIN T_ICOM_CLIENTE_PDV PDV ON (PDV.IDINVERSION=P_ID AND v.CODIGOPDV=PDV.codigopdv)
                           LEFT JOIN  T_ICOM_CLIENTE_PDV_LOCAL CL ON (CL.idinversion=P_ID  AND v.CODIGOPDV=CL.codigopdv AND V.NUMERO=CL.NUMERO )
                           --INNER JOIN T_ICOM_INVERSION_producto  P ON (v.CODIGOPRODUCTO=p.CODIGOPRODUCTO and P.idinversion=P_ID AND TIPO=1 )
                       WHERE V.FECHA between trunc(ADD_MONTHS(v_fechaanalisis, -(P_TIEMPO*12)),'MM') and LAST_DAY(ADD_MONTHS(v_fechaanalisis, -1))
                        AND EXISTS (select 1  from t_icom_inversion_PRODUCTO P where idinversion=P_ID AND TIPO=1  AND P.CODIGOBARRA=V.CODIGOBARRA)
                       AND (V_PDV=0 OR PDV.codigopdv IS NOT NULL)
                        and (v_pdvlocal = 0  OR  CL.NUMERO IS NOT NULL) -- LOCALES DE CLIENTE PDV ) d
                          and v.compania = v_compania
                       GROUP BY to_char(v.fecha,'MM'),to_char(v.fecha,'YYYY')) v on udc.MES=V.MES  AND UDC.ANIO=V.ANIO
            group by UDC.ANIO, PERIODODESCRIPCION;

	END SP_RELACION_SELL_IN_OUT;

	/*
	LINEA DE NEGOCIO
	Procedimiento relacionado al grafico de Ventas por anio de analisis por periodo
	Por: CCarrasco
	Fecha: Junio 2022
	*/
	PROCEDURE SP_RELACION_LINEANEGOCIO(P_ID NUMBER, P_GRUPAL NUMBER, P_TIEMPO NUMBER, P_PERIODO VARCHAR) AS
	--Variables
	v_anio number;
	v_anio1 number;
    v_id_tipo_inversion number;
    v_compania varchar(5);
	begin

        DELETE data.T_ICOM_INVERSION_ANALISIS WHERE IDINVERSION = P_ID
        AND analisisTIPO in ( 'LINEA_NEGOCIO_G', 'LINEA_NEGOCIO_PERIODO', 'LINEA_NEGOCIO', 'CRECIMIENTO', 'CRECIMIENTO_META' );

        SELECT IDINVERSIONTIPO, COMPANIA INTO v_id_tipo_inversion, v_compania FROM DATA.T_ICOM_INVERSIONES WHERE ID = P_ID;

	--GRAFICO N1 - ANALISIS LINEA DE NEGOCIO X PERIODO
		insert into data.t_icom_inversion_analisis
        (IDINVERSION, ANALISISTIPO, TIPO, PERIODO, FECHA, VALOR, VALORUND, VALORCOSTO, SELECCION, TIPO1, ORDEN)
			select  P_ID,'LINEA_NEGOCIO_G' ANALISISTIPO ,UDC.ANIO TIPO,udc.PERIODODESCRIPCION PERIODO,NULL,
			nvl(sum(v.VALORVENTA),0) venta ,
			nvl(SUM(v.VALORUNIDAD),0) vund,
			nvl(SUM(v.VALORCOSTO),0) vcosto, 0 SELECCCION,UDC.ANIO,MIN(udc.MES)
			from (SELECT UDC.ORDEN MES, A.ANIO,PERIODODESCRIPCION
                        FROM  (SELECT TO_CHAR(SYSDATE,'YYYY') -LEVEL+1  ANIO FROM Dual CONNECT BY Level <= P_TIEMPO) A,
                                VT_ICOM_PERIODOS UDC  WHERE UDC.codigo=P_PERIODO) udc
			LEFT JOIN (SELECT
                            SUM(
                                CASE v_id_tipo_inversion
                                    WHEN 4 THEN VALORVENTA3
                                    ELSE VALORVENTA
                                END
                            ) VALORVENTA, SUM(VALORUNIDAD) VALORUNIDAD, SUM(VALORCOSTO) VALORCOSTO,
                              to_char(v.fecha,'MM')MES, to_char(v.fecha,'YYYY') ANIO from   data.Vt_trad_sellIN V
                         INNER JOIN T_ICOM_INVERSION_CLIENTE C ON (c.idinversion=P_ID  AND v.CODIGOCLIENTE=c.codigocliente)
                         --INNER JOIN ( select CODIGOPRODUCTOPADRE, IDINVERSION from  DATA.T_ICOM_INVERSION_producto p
                         --           where P.idinversion=P_ID  AND TIPO=1 group by IDINVERSION,  CODIGOPRODUCTOPADRE) P
                          --          ON (V.CODIGOPRODUCTOPADRE=p.CODIGOPRODUCTOPADRE )
                         WHERE V.FECHA between trunc(ADD_MONTHS(sysdate, -(P_TIEMPO*12)),'MM') and LAST_DAY(ADD_MONTHS(sysdate, -1)) and v.compania = v_compania
                         GROUP BY to_char(v.fecha,'MM'),to_char(v.fecha,'YYYY')
                        ) v on udc.MES=TO_NUMBER(V.MES)  AND UDC.ANIO=V.ANIO
			group by udc.ANIO, udc.PERIODODESCRIPCION;

	-- GRAFICO N3 - ANALISIS POR LINEA DE NEGOCIO

    	insert into data.t_icom_inversion_analisis
       (IDINVERSION, ANALISISTIPO, TIPO, PERIODO,  VALOR,   SELECCION,  ORDEN)
        select 	P_ID,'LINEA_NEGOCIO_PERIODO' ANALISISTIPO ,lineanegocio TIPO, udc.PERIODODESCRIPCION||'-'||to_char(FECHA,'yyyy') PERIODO,
                SUM(
                    case v_id_tipo_inversion
                        when 4 then (v.VALORVENTA3)
                        else (v.VALORVENTA)
                    end
                ) VALOR,0 seleccion ,MIN(udc.ORDEN)  ORDEN
				from VT_ICOM_PERIODOS udc
				LEFT JOIN data.Vt_trad_sellIN v on (TO_NUMBER(to_char(v.fecha,'MM')) = udc.orden AND v.COMPANIA = v_compania)
				where  udc.codigo=P_PERIODO
				and TO_CHAR(FECHA, 'YYYY') between  TO_CHAR(SYSDATE, 'YYYY')-P_TIEMPO AND TO_CHAR(SYSDATE, 'YYYY')
				and exists(	select 1 from data.t_icom_inversiones I
				   inner join  data.T_ICOM_INVERSION_CLIENTE c on (i.id=c.idinversion)
					WHERE I.ID=P_ID  and v.CODIGOCLIENTE=c.codigocliente )
				--and (exists ( select 1 from data.t_icom_inversiones I
				 --  inner join  data.T_ICOM_INVERSION_producto p on (i.id=p.idinversion AND TIPO=1)
				--	WHERE I.ID=P_ID   and v.CODIGOPRODUCTOPADRE=p.CODIGOPRODUCTOPADRE))
				group by lineanegocio, udc.PERIODODESCRIPCION, to_char(FECHA,'yyyy');

	v_anio := to_char(SYSDATE,'yyyy');
	for j in 1..P_TIEMPO loop
		v_anio1:= v_anio-j;
		insert into data.t_icom_inversion_analisis
          (IDINVERSION, ANALISISTIPO, TIPO, PERIODO,  VALOR,   VALORUND,  ORDEN)
		select 	P_ID,'LINEA_NEGOCIO' ANALISISTIPO , TIPO,PERIODO||' '||v_anio1||'-'||(v_anio1+1) PERIODO,
			SUM(venta1)- SUM(venta2) VALOR,
            CASE WHEN sum(venta2)=0 THEN 0 ELSE (sum(venta1)/sum(venta2))-1 END *100 VALORUND	,MIN(ORDEN) ORDEN
			from(
				select 	'LINEA_NEGOCIO' ANALISISTIPO ,lineanegocio tipo,udc.PERIODODESCRIPCION PERIODO,
                sum(
                    case v_id_tipo_inversion
                        when 4 then (v.VALORVENTA3)
                        else (v.VALORVENTA)
                    end
                ) venta1,0 venta2,0 seleccion ,MIN(udc.ORDEN)  ORDEN
				from VT_ICOM_PERIODOS udc
				LEFT JOIN data.Vt_trad_sellIN v on (TO_NUMBER(to_char(v.fecha,'MM')) = udc.orden AND v.COMPANIA = v_compania)
				where  udc.codigo=P_PERIODO
				and to_char(FECHA,'yyyy') =to_char(v_anio1+1)
				and exists(	select 1 from data.t_icom_inversiones I
				   inner join  data.T_ICOM_INVERSION_CLIENTE c on (i.id=c.idinversion)
					WHERE I.ID=P_ID  and v.CODIGOCLIENTE=c.codigocliente )
				--and ( exists( select 1 from data.t_icom_inversiones I
				--   inner join  data.T_ICOM_INVERSION_producto p on (i.id=p.idinversion AND TIPO=1 )
				--	WHERE I.ID=P_ID   and v.CODIGOPRODUCTOPADRE=p.CODIGOPRODUCTOPADRE))
				group by lineanegocio, udc.PERIODODESCRIPCION, to_char(FECHA,'yyyy')

				union

				select 	'LINEA_NEGOCIO' ANALISISTIPO ,lineanegocio tipo,udc.PERIODODESCRIPCION PERIODO,
				0 venta1,
                sum(
                    case v_id_tipo_inversion
                        when 4 then (v.VALORVENTA3)
                        else (v.VALORVENTA)
                    end
                ) venta2,0 seleccion ,MIN(udc.ORDEN)  ORDEN
				from VT_ICOM_PERIODOS udc
				LEFT JOIN data.Vt_trad_sellIN v on (TO_NUMBER(to_char(v.fecha,'MM')) = udc.orden AND v.COMPANIA = v_compania)
				where udc.codigo=P_PERIODO
				and to_char(FECHA,'yyyy') =to_char(v_anio1)
				and	exists( select 1 from data.t_icom_inversiones I
				   inner join  data.T_ICOM_INVERSION_CLIENTE c on (i.id=c.idinversion)
					WHERE I.ID=P_ID  and v.CODIGOCLIENTE=c.codigocliente )
				--and (exists (  select 1 from data.t_icom_inversiones I
                --                     inner join  data.T_ICOM_INVERSION_producto p on (i.id=p.idinversion AND TIPO=1)
                --                WHERE I.ID=P_ID  and v.CODIGOPRODUCTOPADRE=p.CODIGOPRODUCTOPADRE))
				group by lineanegocio, udc.PERIODODESCRIPCION, to_char(FECHA,'yyyy')
				) GROUP BY TIPO, PERIODO;
	end loop;


	-- GRAFICO N2 - ANALISIS COMPARATIVO POR ANIO

	for j in 1..P_TIEMPO loop
	v_anio1:= v_anio-j;
		-- GRAFICO N2 - ANALISIS COMPARATIVO POR ANIO
		insert into data.t_icom_inversion_analisis
        (IDINVERSION, ANALISISTIPO, TIPO, PERIODO, FECHA, VALOR, VALORUND, VALORCOSTO, SELECCION, TIPO1, ORDEN)
			select 	P_ID,'CRECIMIENTO' ANALISISTIPO ,v_anio1||'-'||(v_anio1+1)||'$' tipo,
			PERIODO,null,nvl(sum(valor1),0)-nvl(sum(valor2),0), 0,0,0 seleccion,null,MIN(ORDEN)
			from(SELECT  a.valor valor1, 0 valor2,a.periodo, ORDEN
                    FROM data.t_icom_inversion_analisis a
                    WHERE A.IDINVERSION=P_ID  AND a.tipo=to_char(v_anio1+1)
                    and a.ANALISISTIPO='LINEA_NEGOCIO_G'
                    union
                    SELECT  0 valor1,b.valor valor2,b.periodo, ORDEN
                    FROM data.t_icom_inversion_analisis b
                    WHERE B.IDINVERSION=P_ID AND b.tipo=to_char(v_anio1)
                    and b.ANALISISTIPO='LINEA_NEGOCIO_G' )
            group by periodo;

		insert into data.t_icom_inversion_analisis
        (IDINVERSION, ANALISISTIPO, TIPO, PERIODO, FECHA, VALOR, VALORUND, VALORCOSTO, SELECCION, TIPO1, ORDEN)
			select 	P_ID,'CRECIMIENTO' ANALISISTIPO ,v_anio1||'-'||(v_anio1+1)||'%' tipo,
			PERIODO,null,CASE WHEN sum(valor2)=0 THEN 0 ELSE (sum(valor1)/sum(valor2))-1 END *100,0,0,0 seleccion,null,MIN(ORDEN)
			from( SELECT  a.valor valor1, 0 valor2,a.periodo, ORDEN
                    FROM data.t_icom_inversion_analisis a
                    WHERE A.IDINVERSION=P_ID AND a.tipo=to_char(v_anio1+1)
                    and a.ANALISISTIPO='LINEA_NEGOCIO_G'
                    union
                    SELECT  0 valor1,b.valor valor2,b.periodo, ORDEN
                    FROM data.t_icom_inversion_analisis b
                    WHERE B.IDINVERSION=P_ID AND b.tipo=to_char(v_anio1)
                    and b.ANALISISTIPO='LINEA_NEGOCIO_G' )
            group by periodo;

	end loop;

	END SP_RELACION_LINEANEGOCIO;

	/*
	ANÃ¯Â¿Â½LISIS PUNTO DE VENTA
	Procedimiento que realiza el anÃ¯Â¿Â½lisis de punto de venta
	Por: CCarrasco
	Fecha: Julio 2022
	*/
	PROCEDURE SP_RELACION_PDV(P_ID NUMBER, P_GRUPAL NUMBER, P_TIEMPO NUMBER, P_PERIODO VARCHAR) AS
	--Variables
	v_anio number;
	v_anio1 number;
	v_tiempo number;
	v_meses number;
    v_compania varchar(5);
	BEGIN
	v_anio := to_char((trunc(ADD_MONTHS(to_date(sysdate,'dd/mm/yyyy'), (-1)*(P_TIEMPO)*12),'MM')),'yyyy');
	select compania into v_compania  from data.t_icom_inversiones where id=P_ID;

	IF(P_ID IS NOT NULL) THEN
	--ActualizaciÃ¯Â¿Â½n codigo de grupo
		MERGE INTO data.t_icom_cliente_pdv pdv USING (
			select CODGRP,sum(venta),PDV,FECHA
			from(
			SELECT a.codigocliente CODGRP,sum(a.valorventa) venta, a.codigopdv PDV, TO_CHAR(a.FECHA,'YYYY') fecha
			FROM DATA.MVT_TRAD_SELLOUT a
			inner join data.t_icom_cliente_pdv b on (b.idinversion=P_ID and a.codigopdv = b.codigopdv)
			WHERE TO_CHAR(FECHA,'YYYY') = v_anio and a.compania = v_compania
			group by a.codigopdv, a.codigocliente,a.fecha
			)
			GROUP BY CODGRP,PDV,FECHA
		) cli
		ON (pdv.idinversion=P_ID AND pdv.codigopdv = cli.PDV)
		WHEN MATCHED THEN
		UPDATE SET
			pdv.codigogrupo = cli.CODGRP
		WHEN NOT MATCHED THEN
		INSERT (idinversion,codigopdv,codigogrupo)
		VALUES (P_ID, cli.PDV,cli.CODGRP);
	end if;

	end SP_RELACION_PDV;

    PROCEDURE SP_INGRESO_PDV(P_ID NUMBER) AS
    v_compania varchar(500);
    v_clientes varchar(2500);
    v_contador number;
    V_FECHAINICIO   DATA.T_ICOM_INVERSIONES.FECHAINICIO%TYPE;
    V_FECHAFIN      DATA.T_ICOM_INVERSIONES.FECHAFIN%TYPE;
    BEGIN
        DELETE  t_icom_cliente_pdv WHERE IDINVERSION=P_ID;
        DELETE T_ICOM_CLIENTE_PDV_RUCS  WHERE IDINVERSION=P_ID;
        delete t_icom_inversion_cliente_g  WHERE IDINVERSION=P_ID;

        SELECT FECHAINICIO, FECHAFIN, compania
			INTO  V_FECHAINICIO, V_FECHAFIN, v_compania
			FROM DATA.T_ICOM_INVERSIONES WHERE ID=P_ID;

            SELECT count(1), max(trim(C03))  into v_contador, v_clientes  FROM VT_APEX_EXCEL
        WHERE TRIM(C02) IS NOT NULL AND TRIM(C04) IS NOT NULL
        and LENGTH(trim(C03))>13;

      --  if (v_contador>0) then
       --      raise_application_error(-20100, 'Existen Rucs con mas de 13 digitos :'||v_clientes);
      --  end if;

        --Concatenar todos los CODIGOPDV de los clientes que no existen en la compaÃƒÂ±ia
        SELECT LISTAGG(trim(C02),', ') WITHIN GROUP (ORDER BY trim(C02)), count(1)  into v_clientes, v_contador  FROM VT_APEX_EXCEL
        LEFT JOIN DATA.T_TRAD_CLIENTE clientes ON trim(C02)=trim(clientes.CODIGOPDV)
        WHERE TRIM(C02) IS NOT NULL AND TRIM(C04) IS NOT NULL
        AND clientes.CODIGOPDV IS NULL --AND (clientes.COMPANIA <> v_compania OR clientes.COMPANIA IS NULL)
        ;
        
        if (v_contador>0) then
             raise_application_error(-20101, 'Existen clientes que no existen en la compaÃƒÂ±ÃƒÂ­a:'||v_clientes);
        end if;

        --validar que existe gasto, meta y escala
        SELECT LISTAGG(trim(C02),', ') WITHIN GROUP (ORDER BY trim(C02)), count(1)  into v_clientes, v_contador  FROM VT_APEX_EXCEL
        WHERE TRIM(C02) IS NOT NULL AND TRIM(C04) IS NOT NULL
        AND (  TRIM(NVL(C05,'E'))='E' OR NVL(C06,'')='E' OR C06 = '0' OR NVL(C07,'E')='E' OR C07 = '0'
        )
        ;

        if (v_contador>0) then
             raise_application_error(-20102, 'Existen clientes con datos incompletos (Escala, Meta Mensual o Gasto):'||v_clientes);
        end if;

        INSERT INTO t_icom_cliente_pdv (IDINVERSION, codigopdv, RUC,FECHAINICIO,FECHAFIN,codigogrupo, ESCALA,
        METAMENSUAL,GASTO, CRITERIO, OBSERVACION, SECUENCIAL )
        SELECT P_ID,  C02 CODIGOPDV,trim(C03) RUC,V_FECHAINICIO, V_FECHAFIN, C04 CODIGODISTRIBUIDOR,C05 ESCALA,
        NVL(ROUND(REPLACE(C06, '.', ','),2),0)  METAMENSUAL,
        NVL(ROUND(REPLACE(C07, '.', ','),2),0)  GASTO, C08 CRITERIO, C09 OBSERVAION, ROWNUM
        FROM VT_APEX_EXCEL
        INNER JOIN DATA.T_TRAD_CLIENTE clientes ON trim(C02)=trim(clientes.CODIGOPDV)
        WHERE TRIM(C02) IS NOT NULL AND TRIM(C04) IS NOT NULL AND clientes.COMPANIA= v_compania;

        for p in (select distinct codigogrupo from t_icom_cliente_pdv where idinversion=P_ID) loop
            PK_ICOM_CRUD.SP_CLIENTEAGREGAR(P_ID =>P_ID,P_CLIENTE =>p.codigogrupo,
            P_ALCANCE=>'G', P_COMPANIA =>v_compania, P_ANALISIS=>0);
        end loop;

        INSERT INTO T_ICOM_CLIENTE_PDV_RUCS
            (codigopdv, ruc, auditoriafecha, auditoriausuario, idinversion )
            select C.CODIGOPDV, r.RUC, sysdate, null, P_ID
            from T_TRAD_CLIENTERUC R
            INNER JOIN t_icom_cliente_pdv C ON (C.CODIGOPDV=R.CODIGOPDV)
            where C.IDINVERSION=P_ID AND TRUNC(sysdate) between fechadesde and nvl(fechahasta, sysdate)
            and r.estado = 1 ;

        SP_GASTOS_ANALISIS(P_ID);
-- consecutivo
    END SP_INGRESO_PDV;


	/*
	Procedimiento que actualiza el campo seleccion de la tabla T_ICOM_INVERSION_ANALISIS
	Por: CCarrasco
	Fecha: Junio 2022
	*/
    PROCEDURE SP_SELEC_ANALIS_SELL_IN_OUT(P_ID NUMBER, P_IDTABLA VARCHAR, P_ANALISISTIPO VARCHAR, P_TIPOEJECUCION NUMBER DEFAULT 0) AS
	V_MESES VARCHAR(5);
    v_pdv number;
    v_pdvlocal number;
    v_fechaanalisis date;
    v_id_tipo_inversion number;
    v_compania varchar2(5);
    begin

    V_PDV := PK_ICOM_COMMONS.F_TIENEPDV(P_ID);
    v_pdvlocal := PK_ICOM_COMMONS.F_TIENEPDVLOCAL(P_ID);

        SELECT IDINVERSIONTIPO, COMPANIA INTO v_id_tipo_inversion, v_compania FROM DATA.T_ICOM_INVERSIONES WHERE ID = P_ID;

        if P_ANALISISTIPO='CRECIMIENTO_META' then
            DELETE data.T_ICOM_INVERSION_ANALISIS
                    where idinversion=P_ID and analisisTIPO =P_ANALISISTIPO   and tipo=P_IDTABLA;
            RETURN ;
        end if;

		update data.T_ICOM_INVERSION_ANALISIS set seleccion= 0 where idinversion=P_ID;

		update data.T_ICOM_INVERSION_ANALISIS set seleccion= 1
		where idinversion=P_ID 	and analisisTIPO =P_ANALISISTIPO
		and ((P_ANALISISTIPO NOT IN ('LINEA_NEGOCIO_G', 'LINEA_NEGOCIO') AND PERIODO=P_IDTABLA )
        OR (P_ANALISISTIPO IN ('LINEA_NEGOCIO_G', 'LINEA_NEGOCIO') AND TIPO=P_IDTABLA));

        IF (P_ANALISISTIPO= 'LINEA_NEGOCIO_G' )THEN
            V_MESES:= 12;
        ELSE
            SELECT NVL(MAX(TIPO1),0) INTO V_MESES FROM  T_ICOM_INVERSION_ANALISIS
            WHERE IDINVERSION=P_ID 	AND ANALISISTIPO =P_ANALISISTIPO AND  SELECCION= 1;
        END IF;

        if (P_TIPOEJECUCION =0)then
            --borra los objetivos KPI
            PK_ICOM_ANALISIS.SP_BORRAROBJETIVOKPI( P_ID => P_ID );
        end if;
        if(P_ANALISISTIPO IN('R_SELLIN_SELLOUT','LINEA_NEGOCIO_G')) THEN

            -- ACTULIZO  SELL / sellout COMO VENTA SITUACION INICIAL
            UPDATE DATA.T_ICOM_INVERSIONES
            SET (SELLIN, SELLINUND, SELLINCOSTO, SITUACIONACTUALMES, sellout, selloutund,SELLOUT_PRECIO_LISTA )
            =   (
                    SELECT
                        ROUND(SUM(case when TIPO='SELL_IN' then VALOR else 0 end),2),
                        ROUND(SUM(case when TIPO='SELL_IN' then VALORUND else 0 end )),
                        ROUND(SUM(case when TIPO='SELL_IN' then VALORCOSTO else 0 end ),2),
                        V_MESES,
                        ROUND(SUM(case when TIPO='SELL_OUT' then VALOR else 0 end),2),
                        ROUND(SUM(case when TIPO='SELL_OUT' then VALORUND else 0 end )),
                        ROUND(SUM(case when TIPO='SELL_OUT_PRECIO_LISTA' then NVL(VALOR,0) else 0 end),2)
                    FROM    data.T_ICOM_INVERSION_ANALISIS
                    WHERE   idinversion=P_ID
                    and     analisisTIPO =P_ANALISISTIPO
                    and     (
                                (P_ANALISISTIPO NOT IN ('LINEA_NEGOCIO_G', 'LINEA_NEGOCIO') AND PERIODO=P_IDTABLA )
                            OR
                                (P_ANALISISTIPO IN ('LINEA_NEGOCIO_G', 'LINEA_NEGOCIO') AND TIPO=P_IDTABLA)
                            )
                    AND     seleccion= 1
                )
            WHERE ID = P_ID;

            BEGIN
                IF (P_ANALISISTIPO= 'LINEA_NEGOCIO_G' )THEN
                    V_MESES:= 12;
                END IF;
                select FECHAANALISIS into v_fechaanalisis  from t_icom_inversiones where id=P_ID;
                v_fechaanalisis:=nvl(v_fechaanalisis,sysdate);
                DELETE FROM T_ICOM_INVERSION_VENTAS WHERE IDINVERSION= P_ID ;
                INSERT INTO T_ICOM_INVERSION_VENTAS(IDINVERSION, TIPO, CODIGOCLIENTE, CODIGOGRUPO, CODIGOBARRA, CODIGOPRODUCTO, COMPANIA,PRECIOLISTA, VENTAINICIAL, CANTIDADINICIAL, COSTOINICIAL)
                    with
                    clientes as (SELECT * FROM  data.t_icom_inversion_cliente g  WHERE (G.idinversion =P_ID )),
                    productos as (SELECT * FROM  data.t_icom_inversion_producto p WHERE (p.idinversion =P_ID and tipo=1/*{1 normal;2:regalo/promocional}*/) )
                    SELECT
                        P_ID idinversion,
                        1 tipo,--'{1:SELLIN,2:SELLOUT}';
                        v.CODIGOCLIENTE,v.CODIGOGRUPO,(select codigobarra from productos a where a.codigoproducto=v.codigoproducto and rownum=1) codigobarra,v.codigoproducto,v.COMPANIA,
                        --round(PK_JDE_VENTAS.F_PRECIOXPRODUCTO(V.CODIGOCLIENTE, V.codigoproducto, NULL, v.COMPANIA) , 2) preciolista,
                        round(PK_ICOM_ANALISIS.F_PRECIO_LISTA(V.codigoproducto,V.CODIGOCLIENTE , v_fechaanalisis, v.COMPANIA) , 2) preciolista,
                        decode(v_meses,
                                0,0,
                                nvl(
                                    sum(
                                        case v_id_tipo_inversion
                                            when 4 then v.valorventa3
                                            else v.valorventa
                                        end
                                    ) / v_meses
                                ,0)
                        ) ventainicial,
                        decode(v_meses,0,0,nvl( sum(v.valorunidad) / v_meses, 0) )  cantidadinicial,
                        decode(v_meses,0,0,nvl( sum (v.valorcosto) / v_meses, 0) )  costoinicial
                    FROM Vt_trad_sellIN V
                    WHERE 1=1
                    AND V.fecha BETWEEN trunc(add_months(v_fechaanalisis, (-v_meses)), 'MM') AND last_day(add_months(v_fechaanalisis,case when v_meses<=0 then 0 else -1 end))
                    AND v.codigocliente  in (SELECT g.codigocliente  FROM  clientes g     )
                    AND v.CODIGOGRUPO  in (SELECT g.CODIGOGRUPO  FROM  clientes g     )
                    AND v.codigoproductopadre in (SELECT p.codigoproductopadre FROM  productos  p   )
                    AND V.COMPANIA = v_compania
                    GROUP BY v.CODIGOCLIENTE,v.CODIGOGRUPO ,V.CODIGOPRODUCTO,v.COMPANIA;

                INSERT INTO T_ICOM_INVERSION_VENTAS(IDINVERSION, TIPO, CODIGOCLIENTE, CODIGOGRUPO, CODIGOBARRA, CODIGOPRODUCTO, COMPANIA,PRECIOLISTA, VENTAINICIAL, CANTIDADINICIAL, COSTOINICIAL)
                    with
                    clientes as (SELECT * FROM  data.t_icom_inversion_cliente g  WHERE (G.idinversion =P_ID )),
                    productos as (SELECT * FROM  data.t_icom_inversion_producto p WHERE (p.idinversion =P_ID and tipo=1/*{1 normal;2:regalo/promocional}*/) )
                    SELECT
                        P_ID idinversion,
                        2 tipo,--'{1:SELLIN,2:SELLOUT}';
                        v.CODIGOCLIENTE,v.CODIGOGRUPO,v.codigobarra,NULL codigoproducto,v.COMPANIA,
                        --round(PK_JDE_VENTAS.F_PRECIOXPRODUCTO(V.CODIGOCLIENTE, null, v.codigobarra, v.COMPANIA) , 2) preciolista,
                        round(PK_ICOM_ANALISIS.F_PRECIO_LISTA(V.codigoproducto,V.CODIGOCLIENTE , v_fechaanalisis, v.COMPANIA) , 2) preciolista,
                    decode(v_meses,0,0,nvl( sum(v.VALORVENTA)  / v_meses, 0)) ventainicial,
                    decode(v_meses,0,0,nvl( sum(v.VALORUNIDAD) / v_meses, 0)) cantidadinicial,
                        0 costoinicial--nvl( sum (v.valorcosto) / v_meses, 0)  costoinicial
                    FROM MVT_TRAD_SELLOUT V
                    LEFT JOIN T_ICOM_CLIENTE_PDV PDV ON (PDV.IDINVERSION=P_ID AND v.CODIGOPDV=PDV.codigopdv)
                    LEFT JOIN  T_ICOM_CLIENTE_PDV_LOCAL CL ON (CL.idinversion=P_ID  AND v.CODIGOPDV=CL.codigopdv AND V.NUMERO=CL.NUMERO )
                    WHERE 1=1
                    AND V.fecha BETWEEN trunc(add_months(v_fechaanalisis, (-v_meses)), 'MM') AND last_day(add_months(v_fechaanalisis,-1 ))
                    AND v.codigocliente  in (SELECT g.codigocliente  FROM  clientes g     )
                    --AND v.CODIGOGRUPO  in (SELECT g.CODIGOGRUPO  FROM  clientes g     )
                    AND v.CODIGOBARRA in (SELECT p.CODIGOBARRA FROM  productos  p   )
                    AND (V_PDV=0 OR PDV.codigopdv IS NOT NULL)
                        and (v_pdvlocal = 0  OR  CL.NUMERO IS NOT NULL) -- LOCALES DE CLIENTE PDV
                    AND V.COMPANIA = v_compania
                    GROUP BY v.CODIGOCLIENTE,v.CODIGOGRUPO ,v.codigobarra,v.COMPANIA, V.codigoproducto;
                DBMS_OUTPUT.PUT_LINE(rpad('-',180,'-'));
                commit;
            END;
        END IF;
	END SP_SELEC_ANALIS_SELL_IN_OUT;


	/*
	Procedimiento que procesa informaciÃ¯Â¿Â½n hacia la tabla T_ICOM_INVERSION_ANALISIS para el reporte de CRECIMIENTO META
	Por: CCarrasco
	Fecha: Julio 2022
	*/
	PROCEDURE SP_PRO_CRECIMIENTO(P_ID NUMBER, P_PERIODO varchar) AS
	v_contador number;

	CURSOR DATOS IS
	SELECT  PERIODODESCRIPCION, min(ORDEN) ORDEN
	FROM VT_ICOM_PERIODOS WHERE PERIODO = P_PERIODO
    group by PERIODODESCRIPCION;

	begin

	delete data.T_ICOM_INVERSION_ANALISIS WHERE IDINVERSION = P_ID AND ANALISISTIPO = 'CRECIMIENTO_META' and TIPO IS NULL;

	if P_ID is not null then
		for i in Datos loop
			insert into data.T_ICOM_INVERSION_ANALISIS
            ( IDINVERSION,ANALISISTIPO,TIPO,PERIODO,VALOR,VALORUND,VALORCOSTO,SELECCION,TIPO1, orden)
            values (P_ID,'CRECIMIENTO_META',null,i.PERIODODESCRIPCION,0,0,0,0,P_PERIODO, i.ORDEN);
		end loop;

	end if;

    END SP_PRO_CRECIMIENTO;

	/*
	Procedimiento para actualizar el aÃ¯Â¿Â½o del perÃ¯Â¿Â½odo de los registros para el grÃ¯Â¿Â½fico de CRECIMIENTO META
	Por: CCarrasco
	Fecha: Julio 2022
	*/
	PROCEDURE SP_PRO_CRECIMIENTO_ACTUALIZAR(P_ID NUMBER, P_ANIO NUMBER, P_PERIODO varchar) AS

	v_tipo 		data.T_ICOM_INVERSION_ANALISIS.tipo%type;
	v_total 	number;
	v_contador  number;
	begin
	--Consulta para verificar si el aÃ¯Â¿Â½o(TIPO) ya existe
	select nvl(count(*),0)
	into v_contador
	from data.T_ICOM_INVERSION_ANALISIS
	WHERE IDINVERSION = P_ID
	AND ANALISISTIPO = 'CRECIMIENTO_META'
	and TIPO=to_char(P_ANIO);

		if v_contador = 0 then --NO existe el aÃ¯Â¿Â½o (TIPO)
			-- Si no existe el aÃ¯Â¿Â½o y existe un tipo nulo entonces actualiza anio de los periodos
			SP_PRO_CRECIMIENTO(P_ID, P_PERIODO);

			UPDATE data.T_ICOM_INVERSION_ANALISIS SET TIPO = P_ANIO
			WHERE IDINVERSION = P_ID
			AND ANALISISTIPO = 'CRECIMIENTO_META'
			and TIPO IS NULL;

		else
			-- Ya existe el aÃ¯Â¿Â½o solo borra informaciÃ¯Â¿Â½n de la tabla para tipo is null
			delete data.T_ICOM_INVERSION_ANALISIS
			WHERE IDINVERSION = P_ID
			AND ANALISISTIPO = 'CRECIMIENTO_META'
			and tipo is null;
		end if;

    END SP_PRO_CRECIMIENTO_ACTUALIZAR;


	/*
	Procedimiento que Ingrsa los gastos calculados (Material POP, Descuento) hacia la tabla T_ICOM_INVERSION_GASTO
	Por: CCarrasco
	Fecha: Julio 2022
	*/
	PROCEDURE SP_GASTOS_CALCULADOS(P_ID NUMBER, P_GCALCULO varchar, P_GAPLICACION NUMBER, P_GUNITARIO NUMBER) AS
	v_peq_variable 		number;
	v_peq_fijo			number;
	v_meta_variable 	number;
    V_APLICACION	    number;
    V_UNITARIO			number;
	begin

        --ACTUALIZA TABLA INVERSIONES
        UPDATE T_ICOM_INVERSIONES
        SET GASTOAPLICACION=P_GAPLICACION, GASTOCALCULO=P_GCALCULO, GASTOUNITARIO=P_GUNITARIO
        WHERE ID = P_ID;

        DELETE T_ICOM_INVERSION_GASTO WHERE IDINVERSION = P_ID AND GASTOTIPO= 'GASTO' AND CALCULADO=1;

--    	--GASTO FIJO
--        select nvl((sum(nvl(costo,0) * nvl(cantidad,0))),0) total
--        into v_peq_fijo from data.t_icom_cliente_material
--        where idinversion = P_ID and nvl(TIPO,0)=0
--        ;

--        IF(v_peq_fijo>0) THEN
--            insert into T_ICOM_INVERSION_GASTO( IDINVERSION,GASTOTIPO,TIPO,PERIODO,VALOR,FUENTE,OBSERVACION,
--            VALORMETA,VALORPEQ,VALORREAL, CALCULADO)
--            values (P_ID,'GASTO','FIJO',NULL,NULL,NULL,NULL,v_peq_fijo,v_peq_fijo,0,1);
--        END IF;

--        V_APLICACION :=NVL(P_GAPLICACION,0)/100;
--        V_UNITARIO :=NVL(P_GUNITARIO,0);
--        V_UNITARIO := CASE WHEN P_GCALCULO = 0 THEN  V_UNITARIO/100 ELSE V_UNITARIO END;
--
--        --GASTO VARIABLE
--		IF P_GCALCULO = 0 then --%
--			v_peq_variable:=PK_ICOM_FORMULAS.F_VentaUsdPEQ(P_ID) * V_APLICACION * V_UNITARIO;
--   			v_meta_variable:=PK_ICOM_FORMULAS.F_VentaUsdMeta(P_ID)  * V_APLICACION * V_UNITARIO;
--		ELSE --$
--			v_peq_variable:=(PK_ICOM_FORMULAS.F_VentaUndPEQ(P_ID) * V_APLICACION * V_UNITARIO);
--   		    v_meta_variable:=(PK_ICOM_FORMULAS.F_VentaUndMeta(P_ID)  * V_APLICACION * V_UNITARIO) ;
--		END IF;
--
--        IF(v_meta_variable>0) THEN
--            insert into T_ICOM_INVERSION_GASTO( IDINVERSION,GASTOTIPO,TIPO,PERIODO,VALOR,FUENTE,OBSERVACION,
--                    VALORMETA,VALORPEQ,VALORREAL, CALCULADO)
--                    values (P_ID,'GASTO','VARIABLE',NULL,NULL,NULL,NULL,v_meta_variable,v_peq_variable,0,1);
--        END IF;

        --borra los objetivos KPI
        --PK_ICOM_ANALISIS.SP_BORRAROBJETIVOKPI( P_ID => P_ID );

    END SP_GASTOS_CALCULADOS;

	/*
	Procedimiento que procesa informaciÃ¯Â¿Â½n de detalle de gastos
	hacia la tabla T_ICOM_INVERSION_GASTO
	Por: CCarrasco
	Fecha: Julio 2022
	*/
	PROCEDURE SP_GASTOS_AGREGAR(P_ID NUMBER, P_DESCRIPCION VARCHAR, P_VALOR NUMBER, P_TIPO NUMBER DEFAULT 0,P_IDGASTO OUT NUMBER,P_PERIODO VARCHAR DEFAULT NULL,P_OBSERVACION VARCHAR DEFAULT NULL) AS
	v_peq_variable 		number;
	v_peq_fijo			number;
	v_meta_variable 	number;
	v_automaticas		number;
    v_id                number;
    V_TABLASECUENCIA  varchar2(250):='DATA.T_ICOM_INVERSION_GASTO';
	begin
        DBMS_OUTPUT.PUT_LINE('PARAMETROS => P_ID:'||P_ID||',P_DESCRIPCION:'''||P_DESCRIPCION||''', P_VALOR:'||P_VALOR||', P_TIPO:'||P_TIPO||'');
        V_ID:=PK_COMMONS.F_SECUENCIA (V_TABLASECUENCIA);
        if P_ID is not null and nvl(p_tipo,0) = 0  then
            insert into T_ICOM_INVERSION_GASTO( IDINVERSION,GASTOTIPO,TIPO,PERIODO,VALOR,FUENTE,OBSERVACION,VALORMETA,VALORPEQ,VALORREAL,IDGASTO)
            values (P_ID,'GASTO','FIJO',P_PERIODO,NULL,P_DESCRIPCION,P_DESCRIPCION,P_VALOR,P_VALOR,0,v_id);
            --borra los objetivos KPI
            PK_ICOM_ANALISIS.SP_BORRAROBJETIVOKPI( P_ID => P_ID );
        elsif P_ID is not null and nvl(p_tipo,0) = 1  then
            --valor real
            insert into T_ICOM_INVERSION_GASTO(IDINVERSION,GASTOTIPO,TIPO,PERIODO,VALOR,FUENTE,OBSERVACION,VALORMETA,VALORPEQ,VALORREAL,IDGASTO)
            values (P_ID, 'GASTO','CIERRE', P_PERIODO, NULL, P_DESCRIPCION, P_DESCRIPCION,0,0,P_VALOR,v_id);
        elsif P_ID is not null and nvl(p_tipo,0) IN (2,3)  then
            --valor real
            insert into T_ICOM_INVERSION_GASTO(IDINVERSION,GASTOTIPO,TIPO,PERIODO,VALOR,FUENTE,OBSERVACION,VALORMETA,VALORPEQ,VALORREAL,IDGASTO)
            values (P_ID, 'GASTO','CIERRE', P_PERIODO, NULL, P_DESCRIPCION, P_DESCRIPCION,0,0,P_VALOR,v_id);
        end if;
        P_IDGASTO:=V_ID;
	END SP_GASTOS_AGREGAR;


	 /*Procedimiento para guardar valor inicial, meta y objetivo de una inversion.
      @param P_ID  id de la inversion
      @param P_IDOBJETIVO id objetivo que se asocia al KPI
	  @param P_AREA id area de negocio
    Autor: CCarrasco (NETBY)
	Fecha: Julio 2022
	*/
    PROCEDURE SP_CREAOBJETIVOKPI (P_ID NUMBER, P_AREA NUMBER,P_IDOBJETIVO NUMBER,P_COMPANIA VARCHAR) AS
   BEGIN

        SP_borrarObjetivoKpi(P_ID);
        --delete data.T_ICOM_INVERSION_KPI 	where idinversion = P_ID;
		-- Registro inicial en cero para Valor Inicial y Meta para que el usuario ingrese valores por pantalla
		insert into data.T_ICOM_INVERSION_KPI (IDINVERSION, IDKPI, VALORINICIAL, META, PONDERACION, IDOBJETIVO)
		select P_ID,idkpi,0,0,valor,P_IDOBJETIVO
		from data.VT_ICOM_CONF_AREA_OBJ_KPI
		where compania =P_COMPANIA 	and idarea=P_AREA 	and idobjetivo=P_IDOBJETIVO AND ESTADO=1;

        UPDATE T_ICOM_INVERSIONES SET IDOBJETIVO=P_IDOBJETIVO WHERE ID=P_ID;
        --Se llama el proceso para asignar el valor inicial y meta
        DATA.PK_ICOM_CIERRE.SP_KPIVALORES( P_IDINVERSION => P_ID );

   END SP_CREAOBJETIVOKPI;

   /*Procedimiento que crea los clientes y productos para la inversiÃ¯Â¿Â½n padre y luego crear el analisis*/
    PROCEDURE SP_ANALISISPADRE (P_ID NUMBER, P_TIEMPO NUMBER, P_PERIODO VARCHAR, P_COMPANIA VARCHAR2 ) AS
   /*v_clientes clob;
   v_producto clob;
   v_vclientes varchar2(5000);
   --v_cliente varchar2(5000);

   v_vproducto varchar2(5000);*/
   v_productotodos number ;
   v_cuenta number;
   c_limite INTEGER := 300;

   cursor v_cur_clientes is select c.codigocliente
             from data.t_icom_inversiones i
                  inner join data.t_icom_inversion_cliente c on ( i.id = c.idinversion )
            where i.idgrupo = p_id
            group by c.codigocliente;
   cursor v_cur_productos is select p.codigoproducto
                    from data.t_icom_inversiones i
                        inner join data.t_icom_inversion_producto p on ( i.id = p.idinversion )
                    where i.idgrupo = p_id  AND P.TIPO=1
                    group by p.codigoproducto ;

   /*TYPE clientes_ids_t IS TABLE OF t_icom_inversion_cliente.codigocliente%TYPE INDEX BY PLS_INTEGER;
   vl_clientes_ids   productos_ids_t;
   TYPE productos_ids_t IS TABLE OF t_icom_inversion_producto.codigoproducto%TYPE INDEX BY PLS_INTEGER;
   vl_productos_ids   productos_ids_t;*/

   vl_clientes_ids   apex_application_global.vc_arr2;
   vl_clientes varchar2(4000);
   vl_productos_ids   apex_application_global.vc_arr2;
   vl_productos varchar2(4000);

   BEGIN
        --Se borra todo lo existente
        delete from data.t_icom_inversion_cliente where idinversion = p_id ;
        delete from data.t_icom_inversion_cliente_g where idinversion = p_id ;
        delete from data.T_ICOM_CLIENTE_PDV where idinversion = p_id ;
        delete from data.t_icom_inversion_producto where idinversion = p_id ;
       -- commit;

        --valido que las hijas tengan al menos un cliente y un producto
        select count(1) into v_cuenta
        from data.t_icom_inversiones i
            inner join data.t_icom_inversion_cliente c on ( i.id = c.idinversion )
        where i.idgrupo = p_id ;

        --Como puede ser muchos clientes se trabaja la secuencia por partes
        if nvl(v_cuenta,0) = 0 then
            raise_application_error(-20100, 'Error, las hijas no tienen clientes para agregar');
        end if;
        --Se busca si alguna hija tiene producto todos para actualizar
        select max(PRODUCTOTODO) into v_productotodos from data.t_icom_inversiones where idgrupo = p_id ;
        --valido que las hijas tengan al menos un producto
        select count(1) into v_cuenta
        from data.t_icom_inversiones i
             inner join data.t_icom_inversion_producto p on ( i.id = p.idinversion )
        where i.idgrupo = p_id ;

        if nvl(v_productotodos,0) = 0 and  nvl(v_cuenta,0) = 0 then
            raise_application_error(-20100, 'Error, las hijas no tienen productos para agregar');
        end if;

        --agregamos los clientas
        open v_cur_clientes ;
        LOOP
          FETCH v_cur_clientes BULK COLLECT INTO vl_clientes_ids LIMIT c_limite;
          EXIT WHEN vl_clientes_ids.count = 0;
          vl_clientes :=  apex_util.table_to_string (
                       p_table => vl_clientes_ids,
                       p_string => ':');
          --se agrega los clientes
          PK_ICOM_CRUD.SP_CLIENTEAGREGAR(P_ID =>P_ID,
                                    P_CLIENTE =>vl_clientes,
                                    P_ALCANCE =>'CL',
                                    P_COMPANIA => P_COMPANIA);
        END LOOP;

        if v_productotodos > 0 then --en caso de que sea todos los producto
           --tiene todos los producto
           update data.t_icom_inversiones set productotodo = 1 where id = p_id ;
            open v_cur_productos ;
            LOOP
              FETCH v_cur_productos BULK COLLECT INTO vl_productos_ids LIMIT c_limite;
              EXIT WHEN vl_productos_ids.count = 0;
              vl_productos :=  apex_util.table_to_string (
                           p_table => vl_productos_ids,
                           p_string => ':');
              --se agrega los productos
              PK_ICOM_CRUD.SP_PRODUCTOAGREGAR(P_ID => P_ID,
                                        P_PRODUCTO => vl_productos,
                                        P_ALCANCE =>'P' ,
                                        P_TIPO => 1 ,
                                        P_COMPANIA => P_COMPANIA );
            END LOOP;
        else
           --agregamos los productos
           open v_cur_productos ;
            LOOP
              FETCH v_cur_productos BULK COLLECT INTO vl_productos_ids LIMIT c_limite;
              EXIT WHEN vl_productos_ids.count = 0;
              vl_productos :=  apex_util.table_to_string (
                           p_table => vl_productos_ids,
                           p_string => ':');
              --se agrega los productos
              PK_ICOM_CRUD.SP_PRODUCTOAGREGAR(P_ID => P_ID,
                                        P_PRODUCTO => vl_productos,
                                        P_ALCANCE =>'P' ,
                                        P_TIPO => 1 ,
                                        P_COMPANIA => P_COMPANIA );
            END LOOP;
        end if;


        --- INGRESA PDV
        select count(1) into v_cuenta  from (
        SELECT SUM(PK_ICOM_COMMONS.F_TIENEPDV(ID)) PDV, COUNT(1) TOTAL FROM t_icom_inversiones WHERE   idgrupo=p_id)
        where pdv=total;

        if(v_cuenta>0) THEN
            insert into T_ICOM_CLIENTE_PDV (IDINVERSION, CODIGOPDV, FECHAINICIO,FECHAFIN,	ESTADO)
            select p_id, CODIGOPDV, min(FECHAINICIO) FECHAINICIO ,max(FECHAFIN) FECHAFIN,	1 estado
            from T_ICOM_CLIENTE_PDV where EXISTS (select 1 from t_icom_inversiones where idgrupo=p_id  and id=idinversion)
            group by CODIGOPDV;
        END IF;
        --llamamos al analisis de la padre siempre es grafico 1
        PK_ICOM_ANALISIS.SP_RELACION_SELL_IN_OUT(P_ID => P_ID, P_GRUPAL => 1,
            P_TIEMPO => P_TIEMPO, P_PERIODO=> P_PERIODO);

   END SP_ANALISISPADRE;

   /*Procedimiento que borra los objetivos kpi de una inversion, solo se pueden borrar en idetapa in (1,4,5) and estado in (0,1)*/
    PROCEDURE SP_borrarObjetivoKpi (P_ID NUMBER) AS
   V_ETAPA NUMBER;
   V_ESTADO NUMBER;
   BEGIN
    BEGIN
        DBMS_OUTPUT.PUT_LINE('SELECT IDETAPA, ESTADO INTO V_ETAPA,V_ESTADO FROM T_ICOM_INVERSIONES WHERE ID='||P_ID||';');
        SELECT IDETAPA, ESTADO INTO V_ETAPA,V_ESTADO FROM T_ICOM_INVERSIONES WHERE ID=P_ID;
        DBMS_OUTPUT.PUT_LINE('SELECT IDETAPA, ESTADO INTO V_ETAPA,V_ESTADO FROM T_ICOM_INVERSIONES WHERE ID='||P_ID||';');
        /* IF(V_ETAPA  IN (2,3,7) OR  V_ESTADO =2 ) THEN
          RAISE_APPLICATION_ERROR(-20000, 'No se puede borrar los KPI en las etapas
          : NEGOCIACION, IMPLEMENTACION, VALIDACION o en ruta de aprobaciÃ¯Â¿Â½n de la inversion: '||P_ID);
       END IF;*/
    EXCEPTION WHEN OTHERS THEN
        NULL;
    END;


       delete data.T_ICOM_INVERSION_KPI where idinversion = P_ID;

   END SP_borrarObjetivoKpi;

    PROCEDURE SP_DISTRIBUCION_GASTOS(P_IDINVERSION NUMBER,P_TIPO NUMBER,P_COMPANIA varchar2,
    P_DOCUMENTOTIPO VARCHAR2 DEFAULT NULL,P_DOCUMENTO VARCHAR2 DEFAULT NULL,P_DESCRIPCION VARCHAR2 DEFAULT NULL,
    P_GAPLICACION NUMBER DEFAULT NULL,P_GUNITARIO NUMBER DEFAULT NULL,P_GCALCULO NUMBER DEFAULT NULL,P_GELIMINA NUMBER DEFAULT 1,
    P_GTODOSCLIENTES NUMBER DEFAULT 1,P_IDGASTO NUMBER DEFAULT NULL) AS
        V_ID NUMBER:=P_IDINVERSION;
        V_TIPO NUMBER:=P_TIPO;
        V_COMPANIA VARCHAR2(5):=trim(P_COMPANIA);
        V_APLICACION	    NUMBER:=0;
        V_UNITARIO			NUMBER:=0;
        V_TABLAID           VARCHAR2(200);
        V_TABLADESCRIPCION  VARCHAR2(3999);
        v_cont number;
        V_TABLASECUENCIA VARCHAR2(499);
        V_APPLOG VARCHAR2(499);
        V_SEELIMINA number;
        V_MESSAGE varchar2(3999);
        V_IDGASTO NUMBER;
        V_contador NUMBER;
    BEGIN
        V_IDGASTO :=P_IDGASTO ;
        V_TABLASECUENCIA :='DATA.T_ICOM_INVERSION_GASTODISTRIBUCION';
        V_APPLOG:='APEX.T_ICOM_INVERSION_GASTODISTRIBUCION';
        v_message:='1035::';
        v_message:=v_message||'{P_IDINVERSION:'||P_IDINVERSION||',P_TIPO:'||P_TIPO||',P_COMPANIA:'||P_COMPANIA||',P_DOCUMENTOTIPO:'||P_DOCUMENTOTIPO;
        v_message:=v_message||',P_DOCUMENTO:'||P_DOCUMENTO||',P_DESCRIPCION:'||P_DESCRIPCION||',P_GAPLICACION:'||P_GAPLICACION||',P_GUNITARIO:'||P_GUNITARIO;
        v_message:=v_message||',P_GCALCULO:'||P_GCALCULO||',P_GELIMINA:'||P_GELIMINA||',P_GTODOSCLIENTES:'||P_GTODOSCLIENTES||',V_IDGASTO :'||V_IDGASTO ||'}';

        --conocer el tipo de gasto meta,punto de equilibrio/real
        V_TIPO:=
            CASE
                WHEN P_TIPO IN (1,3,5,6,7,8) THEN 1 --PROPUESTA/REBATE
                WHEN P_TIPO IN (2) THEN 2 --PUNTO DE EQUILIBRIO
                WHEN P_TIPO IN (4) THEN 3 --CIERRE
            END;

        V_TABLAID:=
            CASE P_TIPO
                WHEN 1 THEN 'T_ICOM_CLIENTE_MATERIAL'
                WHEN 2 THEN 'T_GASTO_VARIABLE'
                WHEN 3 THEN 'T_GASTO_VARIABLE'
                WHEN 4 THEN 'T_CIERRE'
                WHEN 5 THEN 'T_MANUAL'
                WHEN 6 THEN 'T_MATERIALPOP_SERVICIO'
                WHEN 7 THEN 'T_REBATE'
                WHEN 7 THEN 'T_PRODUCTO'
            END;
        V_SEELIMINA :=
            CASE P_TIPO
                WHEN 1 THEN 0
                WHEN 2 THEN 0
                WHEN 3 THEN 0
                WHEN 4 THEN 1
                WHEN 5 THEN 1
                WHEN 6 THEN 1
                WHEN 7 THEN 0
                WHEN 8 THEN 1
            END;

        V_TABLADESCRIPCION:=
            CASE P_TIPO
                WHEN 1 THEN 'PROPUESTA MATERIAL POP'
                WHEN 2 THEN 'GASTO VARIABLE'
                WHEN 3 THEN 'GASTO VARIABLE'
                WHEN 4 THEN 'GASTO EN CIERRE'
                WHEN 5 THEN 'MANUAL FIJO'
                WHEN 6 THEN 'MATERIAL POP SERVICIO'
                WHEN 7 THEN 'INVERSION REBATE'
                WHEN 7 THEN 'GASTO EN PRODUCTO'
            END;
        IF (P_GELIMINA=1)THEN
            DELETE T_ICOM_INVERSION_GASTO g where exists (SELECT 1 FROM T_ICOM_INVERSION_GASTODISTRIBUCION d WHERE (G.IDINVERSION=V_ID ) AND (G.IDINVERSION=D.IDINVERSION) AND G.IDGASTO=D.IDGASTO AND TABLAID=V_TABLAID AND COMPANIA=V_COMPANIA AND (IDGASTO=V_IDGASTO  OR V_IDGASTO  IS NULL)  );COMMIT;
            DELETE FROM T_ICOM_INVERSION_GASTODISTRIBUCION  WHERE (IDINVERSION=V_ID ) AND TABLAID=V_TABLAID AND COMPANIA=V_COMPANIA AND (IDGASTO=V_IDGASTO  OR V_IDGASTO  IS NULL);COMMIT;
        END IF;

        if (P_TIPO=1) then/*GASTOS FIJOS - material pop*/

            V_IDGASTO:=PK_COMMONS.F_SECUENCIA ('DATA.T_ICOM_INVERSION_GASTO');

            insert into T_ICOM_INVERSION_GASTO( IDINVERSION,GASTOTIPO,TIPO,PERIODO,
            VALOR,FUENTE,OBSERVACION,VALORMETA,VALORPEQ,VALORREAL, CALCULADO,IDGASTO)
                SELECT IDINVERSION,  'GASTO','FIJO',NULL,NULL,NULL,NULL,
                SUM(TOTAL),SUM(TOTAL),0,1,V_IDGASTO
                FROM DATA.T_ICOM_CLIENTE_MATERIAL m
                WHERE IDINVERSION = V_ID AND NVL(TIPO,0)=0 and codigogrupo is not null
                group by IDINVERSION;

                select count(1) into V_contador from t_icom_inversion_ventas where idinversion=V_ID;
                
                if V_contador=0 then 
                       insert into T_ICOM_INVERSION_GASTODISTRIBUCION( ID,IDINVERSION,  TIPO,CODIGOGRUPO,
                        DESCRIPCION,  COMPANIA,VALORINICIAL,VALORDISTRIBUCION ,
                        PESODISTRIBUCION,VALOR,  TABLAID,  TABLADESCRIPCION,
                        DOCUMENTOTIPO,DOCUMENTO, 
                        FECHA,   ESELIMINAR,IDGASTO)
                        SELECT
                        PK_COMMONS.F_SECUENCIA (V_TABLASECUENCIA) ID ,IDINVERSION, V_TIPO TIPO, CODIGOGRUPO,
                        P_DESCRIPCION DESCRIPCION, V_COMPANIA, 0 VALORINICIAL, SUM(TOTAL)VALORDISTRIBUCION,
                        1 PESODISTRIBUCION, SUM(TOTAL)VALOR, V_TABLAID TABLAID, V_TABLADESCRIPCION TABLADESCRIPCION, 
                        P_DOCUMENTOTIPO  DOCUMENTOTIPO, P_DOCUMENTO DOCUMENTO, SYSDATE FECHA, V_SEELIMINA ESELIMINAR, V_IDGASTO IDGASTO
                        
                        FROM DATA.T_ICOM_CLIENTE_MATERIAL m
                        WHERE IDINVERSION = V_ID AND NVL(TIPO,0)=0   and codigogrupo is not null
                        GROUP BY IDINVERSION, CODIGOGRUPO;
                else 
                    FOR GASTOS IN (
                        SELECT
                            PK_COMMONS.F_SECUENCIA (V_TABLASECUENCIA)ID,IDINVERSION,  CODIGOGRUPO,SUM(TOTAL)TOTAL,V_TIPO TIPO,null CODIGOCLIENTE
                            ,(SELECT CODIGOGRUPO ||' '||NOMBRES FROM vt_icom_inversion_cliente c where c.CODIGOGRUPO=m.CODIGOGRUPO  and rownum=1)nombregrupo
                            FROM DATA.T_ICOM_CLIENTE_MATERIAL m
                            WHERE IDINVERSION = V_ID AND NVL(TIPO,0)=0   and codigogrupo is not null
                            GROUP BY IDINVERSION, CODIGOGRUPO
                    )
                    LOOP
                        PK_ICOM_ANALISIS.SP_GASTOS_MATERIA_SERVICIO(
                            P_ID =>GASTOS.ID,
                            P_IDINVERSION =>GASTOS.IDINVERSION,
                            P_TIPO =>GASTOS.TIPO,
                            P_GRUPO =>GASTOS.CODIGOGRUPO,
                            P_CLIENTE =>GASTOS.CODIGOCLIENTE,
                            P_GASTO =>GASTOS.TOTAL,
                            P_COMPANIA =>V_COMPANIA,
                            P_TABLAID =>V_TABLAID,
                            P_TABLADESCRIPCION =>V_TABLADESCRIPCION,
                            P_DOCUMENTOTIPO =>P_DOCUMENTOTIPO,
                            P_DOCUMENTO =>P_DOCUMENTO,
                            P_DESCRIPCION=>P_DESCRIPCION ,
                            P_SEELIMINA=>V_SEELIMINA ,
                            P_IDGASTO=>V_IDGASTO
        
                        );
                    END LOOP;      
                end if; 
        end if;


        IF (P_TIPO=2 )THEN/*gastos variables*/

            V_APLICACION :=NVL(P_GAPLICACION,0)/100;
            V_UNITARIO :=NVL(P_GUNITARIO,0);
            V_UNITARIO := CASE WHEN P_GCALCULO = 0 THEN  V_UNITARIO/100 ELSE V_UNITARIO END;

            FOR GASTOS IN(
                SELECT
                    PK_COMMONS.F_SECUENCIA (V_TABLASECUENCIA)ID,
                    IDINVERSION,TIPO,CODIGOGRUPO,CODIGOCLIENTE,
                    CASE TO_NUMBER(P_GCALCULO)
                        WHEN 0  THEN (PK_ICOM_FORMULAS.F_VentaUsdPEQ(IDINVERSION) * TO_NUMBER(V_APLICACION) * TO_NUMBER(V_UNITARIO))
                        ELSE (PK_ICOM_FORMULAS.F_VentaUndPEQ(IDINVERSION) * TO_NUMBER(V_APLICACION) * TO_NUMBER(V_UNITARIO))
                    END TOTAL_PEQ,
                    CASE to_number(P_GCALCULO)
                    WHEN 0  THEN (PK_ICOM_FORMULAS.F_VentaUsdMeta(IDINVERSION)  * to_number(V_APLICACION) * to_number(V_UNITARIO))
                            ELSE (PK_ICOM_FORMULAS.F_VentaUndMeta(IDINVERSION)  * to_number(V_APLICACION) * to_number(V_UNITARIO))
                END TOTAL_MET
                FROM (
                        SELECT IDINVERSION,V_TIPO TIPO,DECODE(P_GTODOSCLIENTES,1,NULL,CODIGOGRUPO) CODIGOGRUPO,DECODE(P_GTODOSCLIENTES,1,NULL,CODIGOCLIENTE)  CODIGOCLIENTE
                    FROM T_ICOM_INVERSION_VENTAS WHERE TIPO=1 AND IDINVERSION=V_ID AND COMPANIA=TRIM(TO_CHAR(V_COMPANIA   ,'00000'))
                    GROUP BY IDINVERSION,DECODE(P_GTODOSCLIENTES,1,NULL,CODIGOGRUPO),DECODE(P_GTODOSCLIENTES,1,NULL,CODIGOCLIENTE)
                )
            )
            LOOP

                V_IDGASTO:=PK_COMMONS.F_SECUENCIA ('DATA.T_ICOM_INVERSION_GASTO');

                IF(GASTOS.TOTAL_MET>0) THEN
                    insert into T_ICOM_INVERSION_GASTO( IDINVERSION,GASTOTIPO,TIPO,PERIODO,VALOR,FUENTE,OBSERVACION,
                    VALORMETA,VALORPEQ,VALORREAL, CALCULADO,IDGASTO)
                    values (GASTOS.IDINVERSION,'GASTO','VARIABLE',NULL,NULL,NULL,NULL,GASTOS.TOTAL_MET,GASTOS.TOTAL_PEQ,0,1,V_IDGASTO);
                END IF;

                PK_ICOM_ANALISIS.SP_GASTOS_MATERIA_SERVICIO(
                    P_ID =>GASTOS.ID,
                    P_IDINVERSION =>GASTOS.IDINVERSION,
                    P_TIPO =>2,
                    P_GRUPO =>GASTOS.CODIGOGRUPO,
                    P_CLIENTE =>GASTOS.CODIGOCLIENTE,
                    P_GASTO =>GASTOS.TOTAL_PEQ,
                    P_COMPANIA =>V_COMPANIA,
                    P_TABLAID =>V_TABLAID,
                    P_TABLADESCRIPCION =>V_TABLADESCRIPCION,
                    P_DOCUMENTOTIPO =>P_DOCUMENTOTIPO,
                    P_DOCUMENTO =>P_DOCUMENTO,
                    P_DESCRIPCION=>P_DESCRIPCION,
                    P_SEELIMINA=>V_SEELIMINA,
                    P_IDGASTO=>V_IDGASTO
                );

                PK_ICOM_ANALISIS.SP_GASTOS_MATERIA_SERVICIO(
                    P_ID =>GASTOS.ID,
                    P_IDINVERSION =>GASTOS.IDINVERSION,
                    P_TIPO =>1,
                    P_GRUPO =>GASTOS.CODIGOGRUPO,
                    P_CLIENTE =>GASTOS.CODIGOCLIENTE,
                    P_GASTO =>GASTOS.TOTAL_MET,
                    P_COMPANIA =>V_COMPANIA,
                    P_TABLAID =>V_TABLAID,
                    P_TABLADESCRIPCION =>V_TABLADESCRIPCION,
                    P_DOCUMENTOTIPO =>P_DOCUMENTOTIPO,
                    P_DOCUMENTO =>P_DOCUMENTO,
                    P_DESCRIPCION=>P_DESCRIPCION,
                    P_SEELIMINA=>V_SEELIMINA,
                    P_IDGASTO=>V_IDGASTO
                );
            END LOOP;
        END IF;


        IF ( P_TIPO in (4,5,6,8) ) THEN/*GASTOS FIJOSSERVICIOS*/
            V_APLICACION :=NVL(P_GAPLICACION,0);

            FOR GASTOS IN(
                SELECT PK_COMMONS.F_SECUENCIA (V_TABLASECUENCIA)ID,V_ID IDINVERSION,v_tipo TIPO,null  CODIGOGRUPO,null CODIGOCLIENTE,
                V_APLICACION TOTAL
                FROM dual

            )
            LOOP
                PK_ICOM_ANALISIS.SP_GASTOS_MATERIA_SERVICIO(
                    P_ID =>GASTOS.ID,
                    P_IDINVERSION =>GASTOS.IDINVERSION,
                    P_TIPO =>GASTOS.TIPO,
                    P_GRUPO =>GASTOS.CODIGOGRUPO,
                    P_CLIENTE =>GASTOS.CODIGOCLIENTE,
                    P_GASTO =>GASTOS.TOTAL,
                    P_COMPANIA =>V_COMPANIA,
                    P_TABLAID =>V_TABLAID,
                    P_TABLADESCRIPCION =>V_TABLADESCRIPCION,
                    P_DOCUMENTOTIPO =>P_DOCUMENTOTIPO,
                    P_DOCUMENTO =>P_DOCUMENTO,
                    P_DESCRIPCION=>P_DESCRIPCION,
                    P_SEELIMINA=>V_SEELIMINA,
                    P_IDGASTO=>V_IDGASTO
                );
            END LOOP;
        END IF;



        IF ( P_TIPO in (7) ) THEN/*GASTOS REBATE */
            V_APLICACION :=NVL(P_GAPLICACION,0);
            FOR GASTOS IN(

                WITH
                TDATAGAS AS (
                    select
                        DECODE(NVL(P_GCALCULO,0),0,'GASTOS REBATE / ',NULL) DESC1,
                        DECODE(NVL(P_GCALCULO,0),0,NULL,r.nombre) DESC2,
                        DECODE(NVL(P_GCALCULO,0),0,NULL,case when a.calculo = 1 then valorporcentaje||'% / ' else ' / ' end) DESC3,
                        a.PERIODO DESC4,
                        CASE WHEN NVL(P_GCALCULO,0)=0 THEN NULL ELSE DECODE(a.observacion,NULL,NULL,' / '||a.observacion) END DESC5,
                        NVL(valor,0) valor,
                        p.orden
                    from data.t_icom_inversion_gasto a
                    left join (select PERIODODESCRIPCION , min(ORDEN) orden from VT_ICOM_PERIODOS group by PERIODODESCRIPCION) p on (a.PERIODO=p.PERIODODESCRIPCION)
                    left join data.t_icom_conf_rebate r on ( to_char(r.id) = a.tipo  and r.idinversiontipo = 4 )
                    WHERE idinversion=V_ID
                    and P_TIPO in(7)
                    and gastotipo = 'GASTOREBATE'
                )
                ,TGASTOS AS (
                    select
                        ROW_NUMBER() OVER (PARTITION BY DESC2,DESC3 ORDER BY DESC2,orden ) rn,
                        DESC1,DESC2,DESC3,DESC4,DESC5,SUM(NVL(valor,0)) valor,orden
                    from TDATAGAS
                    GROUP BY DESC1,DESC2,DESC3,DESC4,DESC5,orden
                    HAVING NVL(SUM(NVL(valor,0)),0) !=0
                )
                --SELECT * FROM TGASTOS;
                ,TDATA AS(
                    SELECT RN,DESC1|| DESC2|| DESC3 || DESC4 || DESC5 PERIODO, SUM(VALOR)VALOR,
                    orden orden
                    FROM TGASTOS
                    GROUP BY RN,DESC1 ,DESC2,DESC3 ,DESC4 , DESC5,orden
                    ORDER BY DESC2,RN
                )
                SELECT --RN,
                    PK_COMMONS.F_SECUENCIA (V_TABLASECUENCIA)ID,
                    V_ID IDINVERSION,
                    V_TIPO TIPO,
                    null CODIGOGRUPO,
                    null CODIGOCLIENTE,
                    PERIODO PERIODO,
                    sum(VALOR) total
                FROM TDATA
                GROUP BY PERIODO
            )
            LOOP
                PK_ICOM_ANALISIS.SP_GASTOS_MATERIA_SERVICIO(
                    P_ID =>GASTOS.ID,
                    P_IDINVERSION =>GASTOS.IDINVERSION,
                    P_TIPO =>GASTOS.TIPO,
                    P_GRUPO =>GASTOS.CODIGOGRUPO,
                    P_CLIENTE =>GASTOS.CODIGOCLIENTE,
                    P_GASTO =>GASTOS.TOTAL,
                    P_COMPANIA =>V_COMPANIA,
                    P_TABLAID =>V_TABLAID,
                    P_TABLADESCRIPCION =>V_TABLADESCRIPCION,
                    P_DOCUMENTOTIPO =>P_DOCUMENTOTIPO,
                    P_DOCUMENTO =>P_DOCUMENTO,
                    P_DESCRIPCION=>P_DESCRIPCION ||' / '||GASTOS.PERIODO,
                    P_SEELIMINA=>V_SEELIMINA,
                    P_IDGASTO=>V_IDGASTO
                );
            END LOOP;
        END if;
    END SP_DISTRIBUCION_GASTOS;

    PROCEDURE SP_GASTOS_MATERIA_SERVICIO(
                 P_ID NUMBER,P_IDINVERSION NUMBER,P_TIPO NUMBER,P_GRUPO VARCHAR2,P_CLIENTE VARCHAR2 DEFAULT NULL
                ,P_GASTO NUMBER,P_COMPANIA varchar2,P_TABLAID VARCHAR2,P_TABLADESCRIPCION VARCHAR2
                ,P_DOCUMENTOTIPO VARCHAR2,P_DOCUMENTO VARCHAR2,P_DESCRIPCION VARCHAR2 DEFAULT NULL,P_SEELIMINA NUMBER DEFAULT 0
                ,P_IDGASTO NUMBER DEFAULT NULL) AS
    v_cont NUMBER;
     V_MESSAGE varchar2(3999);
    BEGIN
        V_MESSAGE:='1285>>';
        V_MESSAGE:=V_MESSAGE||'P_ID :'||P_ID||',P_IDINVERSION :'||P_IDINVERSION||',P_TIPO :'||P_TIPO||',P_GRUPO :'||P_GRUPO||',P_CLIENTE :'||P_CLIENTE;
        V_MESSAGE:=V_MESSAGE||' ,P_GASTO :'||P_GASTO||',P_COMPANIA :'''||P_COMPANIA||''',P_TABLAID :'''||P_TABLAID||''',P_TABLADESCRIPCION :'''||P_TABLADESCRIPCION||'''';
        V_MESSAGE:=V_MESSAGE||' ,P_DOCUMENTOTIPO :'''||P_DOCUMENTOTIPO||''',P_DOCUMENTO :'''||P_DOCUMENTO||''',P_DESCRIPCION :'''||P_DESCRIPCION||''''||''',P_ESELIMNIAR :'''||P_SEELIMINA||'''';
        V_MESSAGE:=V_MESSAGE||' ,P_IDGASTO:'||P_IDGASTO;

        DBMS_OUTPUT.PUT_LINE('parametros >>P_ID :'||P_ID||',P_IDINVERSION :'||P_IDINVERSION||',P_TIPO :'||P_TIPO||',P_GRUPO :'||P_GRUPO||',P_CLIENTE :'||P_CLIENTE||' ,P_GASTO :'||P_GASTO||',P_COMPANIA :'''||P_COMPANIA||''',P_TABLAID :'''||P_TABLAID||''',P_TABLADESCRIPCION :'''||P_TABLADESCRIPCION||''',P_DOCUMENTOTIPO :'''||P_DOCUMENTOTIPO||''',P_DOCUMENTO :'''||P_DOCUMENTO||''',P_DESCRIPCION :'''||P_DESCRIPCION||''''||''',P_SEELIMINA:'''||P_SEELIMINA||'''');
        insert into T_ICOM_INVERSION_GASTODISTRIBUCION( ID,IDINVERSION,  TIPO,CODIGOGRUPO,CODIGOCLIENTE,
        CODIGOPRODUCTO,CODIGOBARRA,DESCRIPCION,  COMPANIA,VALORINICIAL,
        VALORDISTRIBUCION ,PESODISTRIBUCION,VALOR,  
        TABLAID,  TABLADESCRIPCION,DOCUMENTOTIPO,DOCUMENTO,  FECHA,  OBSERVACION, ESELIMINAR,IDGASTO)
            SELECT
                P_ID ID,
                IDINVERSION,
                P_TIPO TIPO,
                CODIGOGRUPO CODIGOGRUPO,
                nvl(P_CLIENTE,CODIGOCLIENTE ) CODIGOCLIENTE,
                CODIGOPRODUCTO CODIGOPRODUCTO,
                NULL CODIGOBARRA,
                P_DESCRIPCION DESCRIPCION,
                P_COMPANIA COMPANIA,
                VENTAINICIAL VALORINICIAL,
                P_GASTO VALORDISTRIBUCION ,
                NVL(ROUND(VENTAINICIAL /NULLIF(SUM(VENTAINICIAL) OVER (), 0),  15),0) *100 PESODISTRIBUCION,
                P_GASTO *  NVL(ROUND(VENTAINICIAL /NULLIF(SUM(VENTAINICIAL) OVER (), 0),  15),0) VALOR,
                P_TABLAID TABLAID,
                P_TABLADESCRIPCION TABLADESCRIPCION,
                case P_TIPO
                    when 3 then P_DOCUMENTOTIPO
                    else null
                end DOCUMENTOTIPO,
                case P_TIPO
                    when 3 then P_DOCUMENTO
                    else null
                end  DOCUMENTO,
                SYSDATE FECHA,
                NULL OBSERVACION,
                P_SEELIMINA,
                P_IDGASTO
            FROM
                t_icom_inversion_ventas where idinversion=P_IDINVERSION
                and CODIGOGRUPO=nvl(P_GRUPO,CODIGOGRUPO )
                and CODIGOCLIENTE=nvl(P_CLIENTE,CODIGOCLIENTE )
                and tipo=1
            ORDER BY CODIGOGRUPO,  CODIGOPRODUCTO, CODIGOBARRA;
        v_cont:=SQL%ROWCOUNT;    DBMS_OUTPUT.PUT_LINE('*****************************************************************Registros afectados:'||v_cont||'*****************************************************************');
            commit;
    END SP_GASTOS_MATERIA_SERVICIO;

    -- ==================================================================================
    -- Procedimiento: SP_EXCEL_A_COLECCION_PDV_AUMENTAR
    -- Objetivo    : Procesa la vista VT_APEX_EXCEL y actualiza los registros existentes
    --               en la colecciÃƒÂ³n APEX 'CANDIDATOS_PDV' segÃƒÂºn el Excel cargado.
    -- Notas       :
    --   - No se limpia la colecciÃƒÂ³n, se actualizan los registros ya cargados.
    --   - Se omite la cabecera (fila 1 del Excel).
    --   - Se valida que el PDV (C01) exista en T_TRAD_CLIENTE.
    --   - Se valida que las columnas C04 (meta_mensual) y C05 (gasto) sean numÃƒÂ©ricas.
    --   - Se detiene la ejecuciÃƒÂ³n al primer error encontrado (modo estricto).
    -- ==================================================================================
    PROCEDURE SP_EXCEL_A_COLECCION_PDV_AUMENTAR AS
        v_seq_id       NUMBER;
        v_exists       NUMBER;
        v_meta_mensual NUMBER;
        v_gasto        NUMBER;

        -- Variables para mantener valores actuales de la colecciÃƒÂ³n
        v_c001 apex_collections.c001%TYPE;
        v_c002 apex_collections.c002%TYPE;
        v_c003 apex_collections.c003%TYPE;
        v_c004 apex_collections.c004%TYPE;
        v_c005 apex_collections.c005%TYPE;
        v_c006 apex_collections.c006%TYPE;

    BEGIN
        FOR rec IN (SELECT * FROM VT_APEX_EXCEL where trim(c02) is not null) LOOP
            -- Ignorar cabecera
            IF rec.c01 <> '1' THEN
                -- Validar PDV en T_TRAD_CLIENTE
                SELECT COUNT(*)
                  INTO v_exists
                FROM T_TRAD_CLIENTE c
                WHERE c.codigopdv = TO_NUMBER(rec.c02);

                IF v_exists = 0 THEN
                    RAISE_APPLICATION_ERROR(-20001,'El PDV ' || rec.c02 || ' no existe.');
                END IF;

                --Validar nÃƒÂºmeros
                BEGIN
                    v_meta_mensual := TO_NUMBER(replace(rec.c04, '.', ','));
                EXCEPTION
                    WHEN VALUE_ERROR THEN
                        RAISE_APPLICATION_ERROR(-20002, 'Valor invalido en columna META_MENSUAL para PDV ' || rec.c02);
                END;

                BEGIN
                    v_gasto := TO_NUMBER(replace(rec.c05, '.', ','));
                EXCEPTION
                    WHEN VALUE_ERROR THEN
                        RAISE_APPLICATION_ERROR(-20003, 'Valor invalido en columna GASTO para PDV ' || rec.c02);
                END;

                -- Buscar registro actual en la colecciÃƒÂ³n
                SELECT seq_id, c001, c002
                  INTO v_seq_id, v_c001, v_c002
                  FROM apex_collections
                 WHERE collection_name = 'CANDIDATOS_PDV'
                   AND c001 = rec.c02;

                -- Actualizar todos los atributos (con nuevos valores del Excel o valores previos)
                APEX_COLLECTION.UPDATE_MEMBER(
                    p_collection_name => 'CANDIDATOS_PDV',
                    p_seq             => v_seq_id,
                    p_c001            => v_c001,             -- PDV (ya cargado)
                    p_c002            => v_c002,
                    p_c003            => rec.c03,
                    p_c004            => replace(rec.c04, '.', ','),
                    p_c005            =>replace(rec.c05, '.', ','),
                    p_c006            => rec.c06,
                    p_c007            => rec.c07
                );

            END IF;
        END LOOP;
    EXCEPTION
        WHEN OTHERS THEN
            apex_error.add_error (
                p_message          => 'Error en SP_EXCEL_A_COLECCION_PDV_AUMENTAR: ' || SQLERRM,
                p_display_location => apex_error.c_inline_in_notification
            );
            RAISE;
    END SP_EXCEL_A_COLECCION_PDV_AUMENTAR;

    /*
        Agrega nuevos puntos de venta (PDV) a una inversiÃƒÂ³n comercial.
        - Inserta los PDV desde la colecciÃƒÂ³n APEX 'CANDIDATOS_PDV'
        - Actualiza la tabla de RUCS asociados
        - EnvÃƒÂ­a el contrato automÃƒÂ¡ticamente por cada PDV agregado
    */
    PROCEDURE SP_AUMENTAR_PDV(
        P_ID          NUMBER,
        P_FECHAINICIO DATA.T_ICOM_INVERSIONES.FECHAINICIO%TYPE,
        P_CODIGOGRUPO NUMBER,
        P_USUARIO     VARCHAR2
    ) AS
    v_compania varchar(500);
    v_clientes varchar(2500);
    v_fechafin DATA.T_ICOM_INVERSIONES.FECHAFIN%TYPE;
    v_maximo_secuencial NUMBER;
    v_count NUMBER;
    BEGIN

        --------------------------------------------------------------------
        -- Recuperar datos generales de la inversiÃƒÂ³n (fecha fin, compaÃƒÂ±ÃƒÂ­a)
        --------------------------------------------------------------------
        SELECT FECHAFIN, COMPANIA
          INTO v_fechafin, v_compania
          FROM DATA.T_ICOM_INVERSIONES
        WHERE ID = P_ID;

        --------------------------------------------------------------------
        -- Obtener el mÃƒÂ¡ximo secuencial actual en T_ICOM_CLIENTE_PDV
        --------------------------------------------------------------------
        SELECT NVL(MAX(SECUENCIAL), 0)
          INTO v_maximo_secuencial
          FROM T_ICOM_CLIENTE_PDV
        WHERE IDINVERSION = P_ID;

        --------------------------------------------------------------------
        -- Insertar nuevos PDV desde la colecciÃƒÂ³n APEX
        --------------------------------------------------------------------
        INSERT INTO T_ICOM_CLIENTE_PDV (
            IDINVERSION, CODIGOPDV, RUC,FECHAINICIO,FECHAFIN,CODIGOGRUPO, ESCALA,
            METAMENSUAL,GASTO, CRITERIO, OBSERVACION, SECUENCIAL,CONTRATOAPROBAR
        )
        SELECT P_ID, C001 CODIGOPDV, C002 RUC, P_FECHAINICIO, v_fechafin, P_CODIGOGRUPO, C003 ESCALA,
        NVL(ROUND(REPLACE(C004, '.', ','),2),0)  METAMENSUAL,
        NVL(ROUND(REPLACE(C005, '.', ','),2),0)  GASTO, C006 CRITERIO, C007 OBSERVACION, v_maximo_secuencial + ROWNUM,3
        FROM apex_collections
        WHERE collection_name = 'CANDIDATOS_PDV';

        --------------------------------------------------------------------
        -- Actualizar tabla de RUCS eliminando registros anteriores
        --------------------------------------------------------------------
        DELETE FROM T_ICOM_CLIENTE_PDV_RUCS WHERE idinversion = P_ID AND codigopdv IN (SELECT C001 FROM apex_collections
        WHERE collection_name = 'CANDIDATOS_PDV'  );

        --------------------------------------------------------------------
        -- Insertar RUCS vÃƒÂ¡lidos para los nuevos PDV (solo si existen)
        --------------------------------------------------------------------
        SELECT COUNT(1)
        INTO v_count
        FROM T_TRAD_CLIENTERUC R
        INNER JOIN apex_collections C
           ON C.C001 = R.CODIGOPDV
        WHERE TRUNC(SYSDATE) BETWEEN R.FECHADESDE AND NVL(R.FECHAHASTA, SYSDATE)
          AND C.collection_name = 'CANDIDATOS_PDV'
          AND R.estado = 1;

        IF v_count > 0 THEN

            INSERT INTO T_ICOM_CLIENTE_PDV_RUCS
                (codigopdv, ruc, auditoriafecha, auditoriausuario, idinversion )
            select C.C001, r.RUC, sysdate, null, P_ID
            from T_TRAD_CLIENTERUC R
            INNER JOIN apex_collections C ON (C.C001=R.CODIGOPDV)
            where TRUNC(sysdate) between fechadesde and nvl(fechahasta, sysdate)
            and collection_name = 'CANDIDATOS_PDV'
            and r.estado = 1;
        END IF;

        --------------------------------------------------------------------
        -- Enviar contrato a cada PDV insertado
        --------------------------------------------------------------------
        FOR rec IN (SELECT C001 AS CODIGOPDV
            FROM apex_collections
            WHERE collection_name = 'CANDIDATOS_PDV')
        LOOP
            PK_ICOM_CONTRATO.SP_CONTRATO_ENVIAR (
                P_IDINVERSION  => P_ID,
                P_CODIGOCLIENTE => NULL,
                P_CODIGOPDV     => rec.CODIGOPDV,
                P_TIPOCONTRATO  => 2,
                P_USUARIO       => P_USUARIO
            );
        END LOOP;

        SP_GUARDAR_ANALISIS(P_ID => P_ID, P_GRUPAL => NULL, P_ANIO=> NULL, P_PERIODO => NULL, P_GRAFICO =>'3', P_TIPOEJECUCION =>1);

    END SP_AUMENTAR_PDV;

    PROCEDURE SP_GASTOS_ANALISIS(
        P_IDINVERSION NUMBER
    ) AS
    V_IDGASTO NUMBER;
    V_IDDETALLEGASTO NUMBER;
    V_COMPANIA VARCHAR2(5);
    V_IDINVERSIONTIPO NUMBER;
    V_FECHAINICIO DATA.T_ICOM_INVERSIONES.FECHAINICIO%TYPE;
    BEGIN

        DELETE FROM T_ICOM_INVERSION_GASTO WHERE IDINVERSION = P_IDINVERSION AND TIPO = 'FIJO' AND CALCULADO = 1 AND FUENTE = 'ANALISIS PDV';
        DELETE FROM T_ICOM_INVERSION_GASTODISTRIBUCION WHERE IDINVERSION = P_IDINVERSION AND TABLAID = 'T_ICOM_CLIENTE_PDV';

        SELECT IDINVERSIONTIPO, COMPANIA, FECHAINICIO
        INTO V_IDINVERSIONTIPO, V_COMPANIA, V_FECHAINICIO
        FROM DATA.T_ICOM_INVERSIONES
        WHERE ID = P_IDINVERSION;


        V_IDGASTO := pk_commons.f_secuencia('DATA.T_ICOM_INVERSION_GASTO');

        INSERT INTO T_ICOM_INVERSION_GASTO (
            IDINVERSION, GASTOTIPO, TIPO, PERIODO, VALOR, FUENTE,
            OBSERVACION, VALORMETA, VALORPEQ, VALORREAL, CALCULADO,idgasto
        )
        SELECT
            IDINVERSION,
            'GASTO',
            'FIJO',
            NULL,
            SUM(GASTO) VALOR,
            'ANALISIS PDV',
            NULL OBSERVACION,
            SUM(GASTO) VALORMETA,
            SUM(GASTO) VALORPEQ,
            0 VALORREAL,
            1 CALCULADO,
            V_IDGASTO
        FROM T_ICOM_CLIENTE_PDV
        WHERE IDINVERSION = P_IDINVERSION
        GROUP BY IDINVERSION;


        V_IDDETALLEGASTO := pk_commons.f_secuencia('DATA.T_ICOM_INVERSION_GASTODISTRIBUCION');

        FOR DETALLES IN (
            SELECT pdv.IDINVERSION, pdv.CODIGOGRUPO, s.CODIGOCLIENTE, s.CODIGOPRODUCTO,g.VALOR,
            ROUND((SUM(
                                CASE V_IDINVERSIONTIPO
                                    WHEN 4 THEN s.VALORVENTA3
                                    ELSE S.VALORVENTA
                                END
                                ) * 100) /
                                SUM(SUM(
                                CASE V_IDINVERSIONTIPO
                                    WHEN 4 THEN s.VALORVENTA3
                                    ELSE S.VALORVENTA
                                END
                                )) OVER (PARTITION BY pdv.CODIGOGRUPO),2) AS PESODISTRIBUCION,
            ROUND((SUM(
                                CASE V_IDINVERSIONTIPO
                                    WHEN 4 THEN s.VALORVENTA3
                                    ELSE s.VALORVENTA
                                END
                                )) /
                                SUM(SUM(
                                CASE V_IDINVERSIONTIPO
                                    WHEN 4 THEN s.VALORVENTA3
                                    ELSE s.VALORVENTA
                                END
                                )) OVER (PARTITION BY pdv.CODIGOGRUPO),2) * g.VALOR AS VALORVENTA
            FROM T_ICOM_CLIENTE_PDV pdv
            JOIN DATA.Vt_trad_sellIN s
            ON pdv.CODIGOGRUPO = s.CODIGOGRUPO
            JOIN DATA.T_ICOM_INVERSION_GASTO g
            ON pdv.IDINVERSION = g.IDINVERSION
            JOIN DATA.t_icom_inversion_cliente_g c
            ON pdv.CODIGOGRUPO = c.CODIGOGRUPO AND pdv.IDINVERSION = c.IDINVERSION
            WHERE pdv.IDINVERSION = P_IDINVERSION
            AND s.COMPANIA = V_COMPANIA
            AND s.FECHA >= ADD_MONTHS(TRUNC(V_FECHAINICIO, 'MM'), -12)
            group by pdv.IDINVERSION, pdv.CODIGOGRUPO, s.CODIGOCLIENTE, s.CODIGOPRODUCTO, g.VALOR
            )
        LOOP
            INSERT INTO T_ICOM_INVERSION_GASTODISTRIBUCION (
                ID, IDINVERSION, TIPO, CODIGOGRUPO, CODIGOCLIENTE,
                CODIGOPRODUCTO, CODIGOBARRA, DESCRIPCION, COMPANIA,
                VALORINICIAL, VALORDISTRIBUCION, PESODISTRIBUCION,
                VALOR, TABLAID, TABLADESCRIPCION, DOCUMENTOTIPO,
                DOCUMENTO, FECHA, OBSERVACION, ESELIMINAR, IDGASTO
            ) VALUES (
                V_IDDETALLEGASTO,
                DETALLES.IDINVERSION,
                1,
                DETALLES.CODIGOGRUPO,
                DETALLES.CODIGOCLIENTE,
                DETALLES.CODIGOPRODUCTO,
                NULL,
                'ANALISIS PDV',
                V_COMPANIA,
                DETALLES.VALOR,
                DETALLES.VALOR,
                DETALLES.PESODISTRIBUCION,
                DETALLES.VALORVENTA,
                'T_ICOM_CLIENTE_PDV',
                'Gastos desde Analisis PDV',
                NULL,
                NULL,
                SYSDATE,
                NULL,
                0,
                V_IDGASTO
            );
        END LOOP;
    END SP_GASTOS_ANALISIS;

    -- ===============================================
    -- FunciÃƒÂ³n: F_PRECIO_LISTA
    -- PropÃƒÂ³sito:
    --   Retorna el precio vigente o ÃƒÂºltimo vÃƒÂ¡lido de un producto
    --   segÃƒÂºn cliente, compaÃƒÂ±ÃƒÂ­a y fecha.
    -- ParÃƒÂ¡metros:
    --   P_CODIGOPRODUCTO : CÃƒÂ³digo interno de producto JDE (BPLITM)
    --   P_CODIGOCLIENTE  : NÃƒÂºmero de cliente (BPAN8)
    --   P_FECHA          : Fecha de evaluaciÃƒÂ³n
    --   P_COMPANIA       : CompaÃƒÂ±ÃƒÂ­a (ej. '00001')
    -- Retorna:
    --   Precio numÃƒÂ©rico con 4 decimales
    -- ===============================================
    FUNCTION F_PRECIO_LISTA (
        P_CODIGOPRODUCTO   VARCHAR2,
        P_CODIGOCLIENTE    VARCHAR2,
        P_FECHA            DATE,
        P_COMPANIA         VARCHAR2
    ) RETURN NUMBER AS
        V_PRECIO NUMBER := 0;
    BEGIN
        IF P_COMPANIA = '00001' THEN
            -- 1. Buscar precio vÃƒÂ¡lido en la fecha proporcionada
            BEGIN
                SELECT ROUND(BPUPRC / 10000, 4)
                INTO V_PRECIO
                FROM (
                    SELECT BPUPRC
                    FROM F4106@jdedtadl
                    WHERE
                        TRIM(BPLITM) = TRIM(P_CODIGOPRODUCTO)
                        AND TRIM(BPAN8) = TRIM(P_CODIGOCLIENTE)
                        AND P_FECHA BETWEEN TO_DATE(BPEFTJ + 1900000, 'YYYYDDD')
                                         AND TO_DATE(BPEXDJ + 1900000, 'YYYYDDD')
                        AND BPUPRC IS NOT NULL
                        AND BPCGID = 0 AND TRIM(BPMCU) = '17003'
                    ORDER BY BPEFTJ DESC
                )
                FETCH FIRST 1 ROWS ONLY;
                RETURN V_PRECIO;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    NULL; -- Continuar a bÃƒÂºsqueda hacia atrÃƒÂ¡s
            END;

            -- 2. Buscar precio mÃƒÂ¡s cercano hacia atrÃƒÂ¡s (antes de la fecha)
            BEGIN
                SELECT ROUND(BPUPRC / 10000, 4)
                INTO V_PRECIO
                FROM (
                    SELECT BPUPRC
                    FROM F4106@jdedtadl
                    WHERE
                        TRIM(BPLITM) = TRIM(P_CODIGOPRODUCTO)
                        AND TRIM(BPAN8) = TRIM(P_CODIGOCLIENTE)
                        AND TO_DATE(BPEXDJ + 1900000, 'YYYYDDD') < SYSDATE
                        AND BPUPRC IS NOT NULL
                        AND BPCGID = 0 AND TRIM(BPMCU) = '17003'
                    ORDER BY BPEXDJ DESC
                )
                FETCH FIRST 1 ROWS ONLY;
                RETURN V_PRECIO;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    NULL; -- Continuar a bÃƒÂºsqueda hacia adelante
            END;

            -- 3. Buscar precio mÃƒÂ¡s cercano hacia adelante (despuÃƒÂ©s de la fecha)
            BEGIN
                SELECT ROUND(BPUPRC / 10000, 4)
                INTO V_PRECIO
                FROM (
                    SELECT BPUPRC
                    FROM F4106@jdedtadl
                    WHERE
                        TRIM(BPLITM) = TRIM(P_CODIGOPRODUCTO)
                        AND TRIM(BPAN8) = TRIM(P_CODIGOCLIENTE)
                        AND TO_DATE(BPEXDJ + 1900000, 'YYYYDDD') < P_FECHA
                        AND BPUPRC IS NOT NULL
                        AND BPCGID = 0 AND TRIM(BPMCU) = '17003'
                    ORDER BY BPEXDJ ASC
                )
                FETCH FIRST 1 ROWS ONLY;
                RETURN V_PRECIO;
            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    RETURN 0; -- No se encontrÃƒÂ³ ningÃƒÂºn precio
            END;

        ELSE
            RETURN 0; -- Otras compaÃƒÂ±ÃƒÂ­as
        END IF;

    EXCEPTION
        WHEN OTHERS THEN
            RETURN 0;
    END F_PRECIO_LISTA;


END PK_ICOM_ANALISIS;
/
/

