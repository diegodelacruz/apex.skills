﻿prompt Esquema DATA para codigo PL/SQL
alter session set current_schema=DATA;

prompt PROD PACKAGE_BODY DATA.PK_ICOM_FORMULAS

  CREATE OR REPLACE EDITIONABLE PACKAGE BODY PK_ICOM_FORMULAS AS
    /* 
	Procedimiento que actualizar campo SELLINCRECIMIENTO de la InversiÃƒÂ³n
	Por: Ccarrasco
	Fecha: Julio 2022
	*/
	PROCEDURE ACTUALIZA_SELLINCRECIMIENTO(P_ID NUMBER, P_SELLINC NUMBER) AS
	BEGIN
        --INVERSIONES
		UPDATE data.t_icom_inversiones SET SELLINCRECIMIENTO = P_SELLINC
		where id = P_ID;
        --CLIENTES
        UPDATE data.t_icom_INVERSION_CLIENTE_G SET SELLINCRECIMIENTO = P_SELLINC
		where IDINVERSION = P_ID;
	END ACTUALIZA_SELLINCRECIMIENTO;

	/*
	Procedimiento que actualiza el crecimiento meta en dolares y porcentaje de un cliente por categoria
	Por: Ccarrasco
	Fecha: Julio 2022
	*/
	PROCEDURE ACTUALIZA_CRECIMIENTO_META(P_ID NUMBER, P_SELLOUTCRECIMIENTO NUMBER,P_SELLOUTCRECIMIENTOUND NUMBER,P_CATEGORIA VARCHAR) AS
    V_PCT_CRE_SELLOUT NUMBER;
    V_PCT_CRE_SELLOUTUND NUMBER;
    V_TOT_SELLOUT  NUMBER;
    V_TOT_METASELLOUT NUMBER; 
    V_TOT_SELLOUTUND NUMBER; 
    V_TOT_METASELLOUTUND NUMBER;
	BEGIN
		update DATA.T_ICOM_INVERSION_CLIENTE_G set SELLOUTCRECIMIENTO=P_SELLOUTCRECIMIENTO,
												   SELLOUTCRECIMIENTOUND=P_SELLOUTCRECIMIENTOUND
		WHERE IDINVERSION = P_ID
		AND (CATEGORIA = P_CATEGORIA OR  P_CATEGORIA IS NULL);

            --- ACTUALIZO PORCENTAJE DE CRECIMIENTOS 
         SELECT SUM(NVL(SELLOUT,0)), SUM( NVL(SELLOUT,0) *(1+NVL(SELLOUTCRECIMIENTO/100,0)) ), 
                       SUM(NVL(SELLOUTUND,0)), SUM( NVL(SELLOUTUND,0) *(1+NVL(SELLOUTCRECIMIENTOUND/100,0)) ) 
                INTO V_TOT_SELLOUT, V_TOT_METASELLOUT,      V_TOT_SELLOUTUND, V_TOT_METASELLOUTUND
                FROM VT_ICOM_INVERSION_CLIENTE  WHERE IDINVERSION = P_ID ;
                
                V_PCT_CRE_SELLOUT := CASE WHEN NVL(V_TOT_SELLOUT,0) =0 THEN 0 ELSE 
                (V_TOT_METASELLOUT / CASE WHEN V_TOT_SELLOUT = 0 THEN 0 ELSE V_TOT_SELLOUT END )  -1 END;
                V_PCT_CRE_SELLOUTUND := CASE WHEN NVL(V_TOT_SELLOUTUND,0) =0 THEN 0 ELSE  (V_TOT_METASELLOUTUND / CASE WHEN NVL(V_TOT_SELLOUTUND,0) = 0 THEN 0 ELSE V_TOT_SELLOUTUND END ) -1  END;
        
        UPDATE T_ICOM_INVERSIONES SET SELLOUT_CRECIMIENTO=V_PCT_CRE_SELLOUT ,SELLOUT_CRECIMIENTOUND=V_PCT_CRE_SELLOUTUND   WHERE ID=P_ID;

	END ACTUALIZA_CRECIMIENTO_META;

    /*Formula la para situacion Actual en unidades */
	FUNCTION  F_VENTAUNDSITUACION (P_ID NUMBER) 	RETURN NUMBER
	AS
	V_VENTA 	NUMBER;		
	BEGIN
        SELECT SUM(SELLINUND * DURACION) INTO V_VENTA
        FROM DATA.T_ICOM_INVERSIONES WHERE ID = P_ID ;

        RETURN V_VENTA;

	EXCEPTION WHEN NO_DATA_FOUND THEN
        RETURN 0;
	END F_VENTAUNDSITUACION;

 /*Formula la para situacion Actual en dolares */
	FUNCTION  F_VENTAUSDSITUACION (P_ID NUMBER, P_MESES NUMBER DEFAULT 0) RETURN NUMBER
	AS
	V_VENTA 	NUMBER;		
	BEGIN
        SELECT SUM(SELLIN * DECODE(p_meses, 0, DURACION, p_meses)) INTO V_VENTA
        FROM DATA.T_ICOM_INVERSIONES WHERE (ID = P_ID );

        RETURN V_VENTA;

	EXCEPTION WHEN NO_DATA_FOUND THEN
        RETURN 0;
	END F_VENTAUSDSITUACION;

/*Formula la para obtener el costo seleccionado */
	FUNCTION  F_COSTO (P_ID NUMBER)
	RETURN NUMBER
	AS
	V_COSTO 		NUMBER;	
	V_SELLINCOSTO 	NUMBER;	
	V_DURACION 		NUMBER;

	BEGIN
		BEGIN
			SELECT SELLINCOSTO,DURACION
			INTO V_SELLINCOSTO,V_DURACION
			FROM DATA.T_ICOM_INVERSIONES
			WHERE (ID = P_ID );
			EXCEPTION WHEN NO_DATA_FOUND THEN
			V_SELLINCOSTO:=0;
			V_DURACION:=0;
		END;

		V_COSTO:=NVL(V_SELLINCOSTO,0)*NVL(V_DURACION,0);
        RETURN V_COSTO;
	END F_COSTO;

    /*Formula la para obtener el  margen bruto estandar */
	FUNCTION  F_MargenBrutoEstandar (P_ID NUMBER)
	RETURN NUMBER
	AS
	V_MARGEN 		NUMBER;
    V_VALOR1		NUMBER;
    V_VALOR2 		NUMBER;
	V_UNDSITUACION 	NUMBER;
	V_COSTO 		NUMBER;
	BEGIN
        select MargenBrutoEstandar into V_MARGEN 
        from data.t_icom_inversiones
        where id = P_id ;

        if nvl(V_MARGEN,0) != 0 then
            return V_MARGEN ;
        end if;    
        /*IF(data.PK_ICOM_COMMONS.F_ESPADRE(P_ID)=1) THEN 

            SELECT SUM(PK_ICOM_FORMULAS.F_MargenBrutoSituacion(ID)) INTO V_VALOR1  
            FROM T_ICOM_INVERSIONES WHERE  IDGRUPO=P_ID; 

              SELECT SUM(PK_ICOM_FORMULAS.F_VENTAUSDSITUACION(ID)) INTO V_VALOR2 
            FROM T_ICOM_INVERSIONES WHERE  IDGRUPO=P_ID; 


            RETURN ((V_VALOR1/V_VALOR2)); 
        END IF;*/


		V_UNDSITUACION:=F_VENTAUSDSITUACION (P_ID);
		V_COSTO:=F_COSTO (P_ID); 

		V_MARGEN:=(V_UNDSITUACION-V_COSTO) /V_UNDSITUACION;

        RETURN V_MARGEN;
     EXCEPTION  WHEN OTHERS THEN
        RETURN 0;     
	END F_MargenBrutoEstandar;


    /*Formula la para obtener el  margen bruto de le situacion actual */
	FUNCTION  F_MargenBrutoSituacion (P_ID NUMBER)
	RETURN NUMBER AS
	BEGIN
        RETURN F_VENTAUSDSITUACION(P_ID)*F_MargenBrutoEstandar(P_ID);
	END F_MargenBrutoSituacion;


    /*Formula la para obtener el  gasto fijo en punto de equilibrio */
	FUNCTION  F_GastoFijoPEQ (P_ID NUMBER)
	RETURN NUMBER
	AS
	V_sumcosto	NUMBER;
	BEGIN
			SELECT sum(VALORPEQ)
			INTO V_sumcosto
			FROM DATA.T_ICOM_INVERSION_GASTO
			WHERE IDINVERSION = P_ID AND TIPO='FIJO';
		RETURN V_sumcosto;
	END F_GastoFijoPEQ;

     /*Formula la para obtener el  gasto fijo en meta */
	FUNCTION  F_GastoFijoMeta (P_ID NUMBER)
	RETURN NUMBER
	AS
	V_sumcosto	NUMBER;
	BEGIN
			SELECT nvl(sum(VALORMETA), 0) INTO V_sumcosto
			FROM DATA.T_ICOM_INVERSION_GASTO
			WHERE IDINVERSION = P_ID AND TIPO='FIJO';
	RETURN V_sumcosto;
	END F_GastoFijoMeta;

     /*Formula la para obtener la venta actual en dolares o unidad, dependiendo del gastocalculo */
	FUNCTION  F_ventaActual (P_ID NUMBER) 	RETURN NUMBER 	AS
	V_CALCULO	NUMBER;
	BEGIN
        SELECT CASE WHEN GASTOCALCULO=0 THEN F_VENTAUSDSITUACION(P_ID) ELSE   F_VENTAUNDSITUACION (P_ID) END
         INTO V_CALCULO
        FROM DATA.T_ICOM_INVERSIONES 	WHERE ID = P_ID;

        RETURN V_CALCULO;

    EXCEPTION WHEN NO_DATA_FOUND THEN
			RETURN 0;	
	END F_ventaActual;

     /*Formula la para obtener el gasto  en dolares o porcentaje, dependiendo del gastocalculo */
	FUNCTION  F_GastoUnitario (P_ID NUMBER) RETURN NUMBER 	AS
	V_CALCULO NUMBER;
	BEGIN
        SELECT nvl(CASE WHEN GASTOCALCULO=0 THEN GASTOUNITARIO/100 ELSE  GASTOUNITARIO END,0)
        INTO V_CALCULO FROM DATA.T_ICOM_INVERSIONES WHERE ID = P_ID;

        RETURN V_CALCULO;

    EXCEPTION WHEN others THEn
        RETURN 0;

	END F_GastoUnitario;

    /*Formaula para creimiento de punto de equilibrio*/
	FUNCTION  F_CrecimientoPeq (P_ID NUMBER)
	RETURN NUMBER
	AS
	V_CALCULO		NUMBER;
	v_fijometa		NUMBER;
	v_margen		NUMBER;
	v_venta			NUMBER;
	v_gunitario		NUMBER;
	v_margenbruto	NUMBER;
	v_ventausd		NUMBER;
	V_GASTOAPLICACION number;

	BEGIN
        --dbms_output.put_line( 'F_CrecimientoPeq: '||P_ID);
        IF(PK_ICOM_COMMONS.F_ESPADRE(P_ID)=1) THEN 
            v_ventausd := PK_ICOM_FORMULAS.F_VentaUsdPEQ(P_ID) ;
            v_venta := PK_ICOM_FORMULAS.F_VENTAUSDSITUACION(P_ID) ;
            RETURN ((v_ventausd/v_venta)-1); 
        END IF;

		BEGIN
			SELECT nvl(GASTOAPLICACION/100,0) 	INTO V_GASTOAPLICACION
			FROM DATA.T_ICOM_INVERSIONES 	WHERE ID = P_ID;

		 EXCEPTION WHEN others THEN
			 V_GASTOAPLICACION:=0;
		END;
		v_fijometa:=	F_GastoFijoMeta (P_ID);  
		v_margen:=		F_MargenBrutoSituacion(P_ID);
		v_venta:=		F_ventaActual(P_ID);
		v_gunitario:=	F_GastoUnitario(P_ID);
		v_margenbruto:=	F_MargenBrutoEstandar(P_ID);
		v_ventausd:=	F_VENTAUSDSITUACION(P_ID);
--        dbms_output.put_line( 'V_GASTOAPLICACION: '||V_GASTOAPLICACION||' v_fijometa: '||v_fijometa||' v_margen: '||v_margen||
--        ' v_venta: '||v_venta||' v_gunitario: '||v_gunitario||' v_margenbruto: '||v_margenbruto||' v_ventausd: '||v_ventausd);

--         dbms_output.put_line( v_fijometa||' + '||v_margen||
--        ' + (( '||v_venta||' * '||v_gunitario||' * '||V_GASTOAPLICACION||')-( '||v_margenbruto||' * '||v_ventausd||')))/(('
--        ||v_ventausd||' * '||v_margenbruto ||' ) - ( '||v_venta ||' * '||v_gunitario||' * '||V_GASTOAPLICACION);

		V_CALCULO:=(v_fijometa + v_margen + ((v_venta * v_gunitario * V_GASTOAPLICACION)-(v_margenbruto * v_ventausd)))/
		((v_ventausd * v_margenbruto) - (v_venta * v_gunitario * V_GASTOAPLICACION ));

--         dbms_output.put_line( 'V_CALCULO: '||V_CALCULO);
		RETURN V_CALCULO;
   EXCEPTION  WHEN OTHERS THEN
        RETURN 0;          

	END F_CrecimientoPeq;

     FUNCTION F_CrecimientoMeta(P_ID NUMBER) RETURN NUMBER as
        V_CALCULO		NUMBER;
        V_VALOR1		NUMBER;
        V_VALOR2		NUMBER;
     begin 
        /*IF(PK_ICOM_COMMONS.F_ESPADRE(P_ID)=1) THEN 

            SELECT SUM(PK_ICOM_FORMULAS.F_VentaUsdMeta(ID)) INTO V_VALOR1  
            FROM T_ICOM_INVERSIONES WHERE  IDGRUPO=P_ID; 

              SELECT SUM(PK_ICOM_FORMULAS.F_VENTAUSDSITUACION(ID)) INTO V_VALOR2 
            FROM T_ICOM_INVERSIONES WHERE  IDGRUPO=P_ID; 


            RETURN ((V_VALOR1/V_VALOR2)-1)*100; 
        END IF;*/

        SELECT NVL(SELLINCRECIMIENTO,0) INTO  V_CALCULO FROM DATA.T_ICOM_INVERSIONES WHERE ID =P_ID;

        RETURN V_CALCULO;
    EXCEPTION WHEN others THEN
        RETURN 0;

     end F_CrecimientoMeta;

	FUNCTION  F_VentaUndPEQ (P_ID NUMBER)
	RETURN NUMBER
	AS
	v_ventaund		NUMBER;
	V_CALCULO		NUMBER;
	v_crecimiento	number;
	BEGIN
		v_ventaund:=	F_VENTAUNDSITUACION(P_ID);
		v_crecimiento:=	F_CrecimientoPeq (P_ID);
		V_CALCULO:=round(v_ventaund*(1+v_crecimiento));

		RETURN V_CALCULO;
	END F_VentaUndPEQ;


	FUNCTION  F_VentaUsdPEQ (P_ID NUMBER, P_MESES NUMBER DEFAULT 0 )
	RETURN NUMBER
	AS
	v_ventausd		NUMBER;
	V_CALCULO		NUMBER;
	v_crecimiento	number;
    v_margen		NUMBER;
	v_margenbruto	NUMBER;
	BEGIN
        IF(PK_ICOM_COMMONS.F_ESPADRE(P_ID)=1) THEN 
            v_margen:=		F_MargenBrutoSituacion(P_ID);
            v_margenbruto:=	F_MargenBrutoEstandar(P_ID);
            
            IF(v_margenbruto=0)  THEN 
                RETURN 0;
            END IF;
            
            V_CALCULO:= PK_ICOM_FORMULAS.F_GastoInversionPEQ(P_ID);
            
            RETURN ( v_margen + V_CALCULO )/v_margenbruto ; 
        END IF;
        
		v_ventausd:=	F_VENTAUSDSITUACION(P_ID, P_MESES);
		v_crecimiento:=	F_CrecimientoPeq (P_ID);
		V_CALCULO:=v_ventausd*(1+v_crecimiento);

		RETURN V_CALCULO;

	END F_VentaUsdPEQ;

	FUNCTION  F_VentaUndMeta (P_ID NUMBER)
	RETURN NUMBER
	AS
	v_ventaund		NUMBER;
	V_CALCULO		NUMBER;
	v_crecimiento	number;
	V_SELLINCRECIMIENTO number;
	BEGIN
		BEGIN
			SELECT SELLINCRECIMIENTO, VentaUndMeta 
			INTO V_SELLINCRECIMIENTO, v_ventaund
			FROM DATA.T_ICOM_INVERSIONES
			WHERE ID = P_ID;
		EXCEPTION WHEN NO_DATA_FOUND THEN
			 V_SELLINCRECIMIENTO:=0;
		END;

        if nvl(v_ventaund,0) != 0 then
            return round(v_ventaund,0) ;
        end if;

		v_ventaund:=	F_VENTAUNDSITUACION(P_ID);

		V_CALCULO:=nvl(v_ventaund,0)*(1+(nvl(V_SELLINCRECIMIENTO,0)/100));

		RETURN round(V_CALCULO,0);
    EXCEPTION WHEN others THEN
        RETURN 0;    
	END F_VentaUndMeta;

	FUNCTION  F_VentaUsdMeta (P_ID NUMBER)
	RETURN NUMBER
	AS
	v_ventausd		NUMBER;
	V_CALCULO		NUMBER;
	v_crecimiento	number;
	V_SELLINCRECIMIENTO number;
	BEGIN
/*Si el valor creado es >0 devolver el valor caso contrario la formula */
		BEGIN
			SELECT SELLINCRECIMIENTO, VentaUsdMeta 
			INTO V_SELLINCRECIMIENTO, v_ventausd
			FROM DATA.T_ICOM_INVERSIONES
			WHERE ID = P_ID;
		EXCEPTION WHEN NO_DATA_FOUND THEN
			 V_SELLINCRECIMIENTO:=0;
		END;

        if nvl(v_ventausd,0) != 0 then
            return v_ventausd ;
        end if;

		v_ventausd:=	F_VENTAUSDSITUACION(P_ID);

		V_CALCULO:=nvl(v_ventausd,0)*(1+(nvl(V_SELLINCRECIMIENTO,0)/100));

		RETURN V_CALCULO;
    EXCEPTION WHEN others THEN
        RETURN 0;    
	END F_VentaUsdMeta;

	FUNCTION  F_VentaPEQ (P_ID NUMBER)	RETURN NUMBER	AS
	V_CALCULO	number;
    BEGIN
        SELECT CASE WHEN GASTOCALCULO=0 THEN F_VentaUsdPEQ(P_ID) ELSE   F_VentaUndPEQ (P_ID) END
         INTO V_CALCULO
        FROM DATA.T_ICOM_INVERSIONES 	WHERE ID = P_ID;

        RETURN V_CALCULO;

    EXCEPTION WHEN NO_DATA_FOUND THEN
        RETURN 0;	        
	END F_VentaPEQ;

	FUNCTION  F_MetaPEQ (P_ID NUMBER) 	RETURN NUMBER 	AS
	V_CALCULO		NUMBER;
	BEGIN
        SELECT CASE WHEN GASTOCALCULO=0 THEN F_VentaUsdMeta(P_ID) ELSE   F_VentaUndMeta (P_ID) END
         INTO V_CALCULO
        FROM DATA.T_ICOM_INVERSIONES 	WHERE ID = P_ID;

        RETURN V_CALCULO;

    EXCEPTION WHEN NO_DATA_FOUND THEN
			RETURN 0;	

	END F_MetaPEQ;

    /*Formula para el Crecimiento USD de PEQ*/
	FUNCTION  F_CreciminetoUsdPEQ (P_ID NUMBER)	RETURN NUMBER
	AS
	BEGIN

		RETURN F_VentaUsdPEQ(P_ID)-F_VENTAUSDSITUACION(P_ID) ;
	END F_CreciminetoUsdPEQ;

    /*Formula para el Crecimiento USD de Meta*/
	FUNCTION  F_CreciminetoUsdMeta(P_ID NUMBER)	RETURN NUMBER
	AS
	BEGIN
		RETURN F_VentaUsdMeta(P_ID)- F_VENTAUSDSITUACION(P_ID);
	END F_CreciminetoUsdMeta;

	FUNCTION  F_GastoPEQ(P_ID NUMBER)
	RETURN NUMBER
	AS
	V_CALCULO		NUMBER;
	v_ventapeq		number;
	v_gunitario		number;
	V_GASTOAPLICACION number;
	BEGIN
		BEGIN
			SELECT GASTOAPLICACION/100 	INTO V_GASTOAPLICACION 
			FROM DATA.T_ICOM_INVERSIONES 	WHERE ID = P_ID;

		EXCEPTION WHEN NO_DATA_FOUND THEN
			V_GASTOAPLICACION:=0;	
		END;

		v_ventapeq:= F_VentaPEQ(P_ID);
		v_gunitario:=F_GastoUnitario(P_ID);	

		V_CALCULO:= nvl(v_ventapeq,0)*(V_GASTOAPLICACION)*nvl(v_gunitario,0);

		RETURN V_CALCULO;
	END F_GastoPEQ;

	FUNCTION  F_GastoMeta(P_ID NUMBER)
	RETURN NUMBER
	AS
	V_CALCULO		NUMBER;
	v_metapeq		number;
	v_gunitario		number;
	V_GASTOAPLICACION number;
	BEGIN
		BEGIN
			SELECT GASTOAPLICACION/100 		INTO V_GASTOAPLICACION
			FROM DATA.T_ICOM_INVERSIONES 	WHERE ID = P_ID;

		EXCEPTION WHEN NO_DATA_FOUND THEN
			V_GASTOAPLICACION:=0;	
		END;

		v_metapeq:= F_MetaPEQ(P_ID);
		v_gunitario:=F_GastoUnitario(P_ID);	

		V_CALCULO:= nvl(v_metapeq,0)*(V_GASTOAPLICACION)*nvl(v_gunitario,0);

		RETURN V_CALCULO;
        
	END F_GastoMeta; 

	FUNCTION  F_MargenBrutoPEQ(P_ID NUMBER)
	RETURN NUMBER
	AS
	V_CALCULO		NUMBER;
	v_bruto		number;
	v_venta		number;

	BEGIN

		v_bruto:=F_MargenBrutoEstandar(P_ID);
		v_venta:=F_VentaUsdPEQ(P_ID);

		V_CALCULO:= v_bruto*v_venta;

		RETURN V_CALCULO;
	END F_MargenBrutoPEQ; 

	FUNCTION  F_MargenBrutoMeta(P_ID NUMBER)
	RETURN NUMBER
	AS
	V_CALCULO		NUMBER;
	v_bruto		number;
	v_venta		number;

	BEGIN

		v_bruto:=F_MargenBrutoEstandar(P_ID);
		v_venta:=F_VentaUsdMeta(P_ID);

		V_CALCULO:= v_bruto*v_venta;

		RETURN V_CALCULO;
	END F_MargenBrutoMeta; 

	FUNCTION  F_GastoInversionPEQ(P_ID NUMBER)
	RETURN NUMBER
	AS
	V_CALCULO		NUMBER;
	v_gastopeq		number;
	v_gastofijopeq	number;

	BEGIN
        IF(PK_ICOM_COMMONS.F_ESPADRE(P_ID)=1) THEN 
            
            SELECT SUM(PK_ICOM_FORMULAS.F_GastoInversionMeta(ID)) INTO V_CALCULO  
            FROM T_ICOM_INVERSIONES WHERE  IDGRUPO=P_ID and IDPADRE is null; 
            
            RETURN V_CALCULO ; 
        END IF;
        
		v_gastopeq:=F_GastoPEQ(P_ID);
		v_gastofijopeq:=F_GastoFijoPEQ(P_ID);

		V_CALCULO:= nvl(v_gastopeq,0)+nvl(v_gastofijopeq,0);

		RETURN V_CALCULO;
	END F_GastoInversionPEQ; 

	FUNCTION  F_GastoInversionMeta(P_ID NUMBER)
	RETURN NUMBER
	AS
	V_CALCULO		NUMBER;
	v_gastom		number;
	v_gastofijom	number;

	BEGIN
        
        IF(PK_ICOM_COMMONS.F_ESPADRE(P_ID)=1) THEN 
            
            SELECT SUM(PK_ICOM_FORMULAS.F_GastoInversionMeta(ID)) INTO V_CALCULO  
            FROM T_ICOM_INVERSIONES WHERE  IDGRUPO=P_ID and IDPADRE is null; 
            
            RETURN V_CALCULO ; 
        END IF;
        
		v_gastom:=F_GastoMeta(P_ID);
		v_gastofijom:=F_GastoFijoMeta(P_ID);

		V_CALCULO:= nvl(v_gastom,0)+nvl(v_gastofijom,0);

		RETURN V_CALCULO;
	END F_GastoInversionMeta; 


	FUNCTION  F_MargenDespuesGastoPEQ(P_ID NUMBER)
	RETURN NUMBER
	AS
	V_CALCULO		NUMBER;
	v_mbrutopeq		number;
	v_gastopeq		number;

	BEGIN

		v_mbrutopeq:=F_MargenBrutoPEQ(P_ID);
		v_gastopeq:=F_GastoInversionPEQ(P_ID);

		V_CALCULO:= nvl(v_mbrutopeq,0)-nvl(v_gastopeq,0);

		RETURN V_CALCULO;
	END F_MargenDespuesGastoPEQ; 

	FUNCTION  F_MargenDespuesGastoMeta (P_ID NUMBER)
	RETURN NUMBER
	AS
	V_CALCULO		NUMBER;
	v_mbrutometa	number;
	v_gastometa		number;

	BEGIN

		v_mbrutometa:=F_MargenBrutoMeta(P_ID);
		v_gastometa:=F_GastoInversionMeta(P_ID);

		V_CALCULO:= nvl(v_mbrutometa,0)-nvl(v_gastometa,0);

		RETURN V_CALCULO;
	END F_MargenDespuesGastoMeta; 

	FUNCTION  F_MargenIncrementalPEQ (P_ID NUMBER)
	RETURN NUMBER
	AS
	V_CALCULO		NUMBER;
	v_mdespues		number;
	v_mbruto		number;
    V_VALOR1		number;
    V_VALOR2		number;

	BEGIN

        /*IF(PK_ICOM_COMMONS.F_ESPADRE(P_ID)=1) THEN 
            SELECT SUM(PK_ICOM_FORMULAS.F_MargenDespuesGastoPEQ(ID)) INTO  V_VALOR1
            FROM T_ICOM_INVERSIONES WHERE  IDGRUPO=P_ID; 

            SELECT SUM(PK_ICOM_FORMULAS.F_MargenBrutoSituacion(ID)) INTO V_VALOR2
            FROM T_ICOM_INVERSIONES WHERE IDGRUPO=P_ID; 

            RETURN (V_VALOR1-V_VALOR2); 
        END IF;*/

		v_mdespues:=F_MargenDespuesGastoPEQ(P_ID);
		v_mbruto:=F_MargenBrutoSituacion(P_ID);

		V_CALCULO:= nvl(v_mdespues,0)-nvl(v_mbruto,0);

		RETURN round(V_CALCULO,6);
	END F_MargenIncrementalPEQ; 


	FUNCTION  F_MargenIncrementalMeta(P_ID NUMBER)
	RETURN NUMBER
	AS
	V_CALCULO		NUMBER;
	v_mdespues		number;
	v_mbruto		number;
    V_VALOR1		number;
    V_VALOR2		number;
	BEGIN

      /* IF(PK_ICOM_COMMONS.F_ESPADRE(P_ID)=1) THEN 
            SELECT SUM(PK_ICOM_FORMULAS.F_MargenDespuesGastoMeta(ID)) INTO  V_VALOR1
            FROM T_ICOM_INVERSIONES WHERE  IDGRUPO=P_ID; 

            SELECT SUM(PK_ICOM_FORMULAS.F_MargenBrutoSituacion(ID)) INTO V_VALOR2
            FROM T_ICOM_INVERSIONES WHERE IDGRUPO=P_ID; 

            RETURN (V_VALOR1-V_VALOR2); 
        END IF;*/

		v_mdespues:=F_MargenDespuesGastoMeta(P_ID);
		v_mbruto:=F_MargenBrutoSituacion(P_ID);

		V_CALCULO:= nvl(v_mdespues,0)-nvl(v_mbruto,0);

		RETURN V_CALCULO;
	END F_MargenIncrementalMeta; 

	FUNCTION  F_MargePBrutoPEQ(P_ID NUMBER)
	RETURN NUMBER
	AS
	V_CALCULO		NUMBER;
	v_mdespues		number;
	v_venta			number;
    V_VALOR1		number;
    V_VALOR2		number;
	BEGIN

         /*IF(PK_ICOM_COMMONS.F_ESPADRE(P_ID)=1) THEN 
            SELECT SUM(PK_ICOM_FORMULAS.F_MargenDespuesGastoPEQ(ID)) INTO  V_VALOR1
            FROM T_ICOM_INVERSIONES WHERE  IDGRUPO=P_ID; 

            SELECT SUM(PK_ICOM_FORMULAS.F_VentaUsdPEQ(ID)) INTO V_VALOR2
            FROM T_ICOM_INVERSIONES WHERE IDGRUPO=P_ID; 

            RETURN (V_VALOR1/V_VALOR2)*100; 
        END IF;*/

		v_mdespues:=F_MargenDespuesGastoPEQ(P_ID);
		v_venta:=F_VentaUsdPEQ(P_ID);

		V_CALCULO:= (v_mdespues/v_venta)*100;

		RETURN V_CALCULO;
    EXCEPTION WHEN others THEN
        RETURN 0;    
	END F_MargePBrutoPEQ; 


	FUNCTION  F_MargePBrutoMeta(P_ID NUMBER)
	RETURN NUMBER
	AS
	V_CALCULO		NUMBER;
	v_mdespues		number;
	v_venta			number;
    V_VALOR1		number;
    V_VALOR2		number;
	BEGIN
        /*IF(PK_ICOM_COMMONS.F_ESPADRE(P_ID)=1) THEN 
            SELECT SUM(PK_ICOM_FORMULAS.F_MargenDespuesGastoMeta(ID)) INTO  V_VALOR1
            FROM T_ICOM_INVERSIONES WHERE  IDGRUPO=P_ID; 

            SELECT SUM(PK_ICOM_FORMULAS.F_VentaUsdmETA(ID)) INTO V_VALOR2
            FROM T_ICOM_INVERSIONES WHERE IDGRUPO=P_ID; 

            RETURN (V_VALOR1/V_VALOR2)*100; 
        END IF;*/

		v_mdespues:=F_MargenDespuesGastoMeta(P_ID);
		v_venta:=F_VentaUsdMeta(P_ID);

		V_CALCULO:= CASE WHEN v_venta = 0 THEN 0 ELSE (v_mdespues/v_venta)*100 END;

		RETURN V_CALCULO;
    EXCEPTION WHEN others THEN
        RETURN 0;    
	END F_MargePBrutoMeta; 	

	 /*
	Funcion que el valor del Margen % - Situacion Actual 
	Por: JAsanza
	Fecha: Diciembre 2022
	*/
    FUNCTION F_VAL_MARGENSITUACION ( P_SELLIN NUMBER, P_DURACION NUMBER, P_SELLINCOSTO NUMBER) return number as 
	BEGIN

			return ((nvl(p_sellin,0)*nvl(p_duracion,0))-(nvl(p_sellincosto,0)*nvl(p_duracion,0)))
			             /case when (nvl(p_sellin,0)*nvl(p_duracion,0)) = 0 then 1 else (nvl(p_sellin,0)*nvl(p_duracion,0)) end  ;

	END;

	 /*
	Funcion que el valor del Margen % - Meta 
	Por: JAsanza
	Fecha: Diciembre 2022
	*/
    FUNCTION F_VAL_MARGENMETA ( P_SELLIN NUMBER, P_DURACION NUMBER, 
		P_SELLINCOSTO NUMBER) return number as 
	BEGIN

			return ((nvl(p_sellin,0)*nvl(p_duracion,0))-(nvl(p_sellincosto,0)*nvl(p_duracion,0)))
			             /case when (nvl(p_sellin,0)*nvl(p_duracion,0)) = 0 then 1 else (nvl(p_sellin,0)*nvl(p_duracion,0)) end  ;

	END;

	/*
	Funcion que el valor del Margen % - Real 
	Por: JAsanza
	Fecha: Diciembre 2022
	*/
    FUNCTION F_VAL_MARGENREAL ( P_SELLINREAL NUMBER, P_SELLINREALCOSTO NUMBER) return number as 
	BEGIN

			return ( (nvl(p_sellinreal,0)-nvl(p_sellinrealcosto,0))/ 
                case nvl(p_sellinreal,0) when 0 then 1 else p_sellinreal end ) ;

	END;

	/*
	Funcion que el valor del Total Margen - Situacion Actual 
	Por: JAsanza
	Fecha: Diciembre 2022
	*/
    FUNCTION F_VAL_TOTALMARGENSITUACION ( P_SELLIN NUMBER, P_DURACION NUMBER, P_SELLINCOSTO NUMBER) return number as 
	BEGIN

			return ((nvl(p_sellin,0)*nvl(p_duracion,0)) 
			    * data.PK_ICOM_FORMULAS.F_VAL_MARGENSITUACION ( P_SELLIN => p_sellin, 
																P_DURACION => p_duracion, 
																P_SELLINCOSTO => p_sellincosto) ) ;

	END;

	/*
	Funcion que el valor del Total Margen  - Meta
	Por: JAsanza
	Fecha: Diciembre 2022
	*/
    FUNCTION F_VAL_TOTALMARGENMETA ( P_ID NUMBER, P_SELLINCRECIMIENTO NUMBER, P_SELLIN NUMBER, P_DURACION NUMBER, 
		P_SELLINCOSTO NUMBER) return number as 
		v_meta number ;
        v_valormeta number ;
	BEGIN
        IF(data.PK_ICOM_COMMONS.F_ESPADRE(P_ID)=1) THEN 
            begin
                select sum(nvl(valormeta,0)) into v_meta 
                from data.t_icom_inversion_gasto 
                where idinversion in ( select id from data.t_icom_inversiones where (idgrupo = p_id and idpadre is null)) ;
            exception 
                when others then v_meta := 0;
            end;
            
        ELSE
            begin
                select sum(nvl(valormeta,0)) into v_meta from data.t_icom_inversion_gasto where idinversion = p_id ;
            exception 
                when others then v_meta := 0;
            end;
        END IF;
        
		
        v_valormeta := ((nvl(p_sellin,0)*nvl(p_duracion,0)) * (1+(nvl(p_sellincrecimiento,0)/100)));
		return (( nvl(v_valormeta,0) * data.PK_ICOM_FORMULAS.F_VAL_MARGENMETA ( P_SELLIN => p_sellin, 
																P_DURACION => p_duracion, 
																P_SELLINCOSTO => p_sellincosto)) - nvl(v_meta,0) ) ;

	END;

	/*
	Funcion que el valor del Total Margen  - Real
	Por: JAsanza
	Fecha: Diciembre 2022
	*/
    FUNCTION F_VAL_TOTALMARGENREAL ( P_ID NUMBER, P_SELLINREAL NUMBER, P_SELLINREALCOSTO NUMBER) return number as 
		v_real number ;
	BEGIN
        IF(data.PK_ICOM_COMMONS.F_ESPADRE(P_ID)=1) THEN 
            begin
                select sum(nvl(valorreal,0)) into v_real 
                from data.t_icom_inversion_gasto 
                where idinversion in ( select id from data.t_icom_inversiones where (idgrupo = p_id and idpadre is null) ) ;
            exception 
                when others then v_real := 0;
            end;
            
        ELSE
            begin
                select sum(nvl(valorreal,0)) into v_real from data.t_icom_inversion_gasto where idinversion = p_id ;
            exception 
                when others then v_real := 0;
            end;
        END IF;
        
		return (( nvl(P_SELLINREAL,0) * data.PK_ICOM_FORMULAS.F_VAL_MARGENREAL ( P_SELLINREAL => p_sellinreal, 
																P_SELLINREALCOSTO => p_sellinrealcosto )) - nvl(v_real,0) ) ;

	END;

    /*
	Funcion que devuelve el valor real de las ventas Sell In
	Por: JAsanza
	Fecha: Diciembre 2022
	*/
    FUNCTION F_TOTALREAL ( P_ID NUMBER) return number as 
		v_real number ;
	BEGIN
        BEGIN
			SELECT sellinreal 		INTO v_real
			FROM DATA.T_ICOM_INVERSIONES 	WHERE ID = P_ID;

		EXCEPTION WHEN NO_DATA_FOUND THEN
			v_real:=0;	
		END;
        return v_real ;
    END;

    /*
	Funcion que devuelve el valor situacion de las ventas Sell Out
	Por: JAsanza
	Fecha: Diciembre 2022
	*/
    FUNCTION  F_VENTAUSDSITUACIONSELLOUT (P_ID NUMBER) RETURN NUMBER
	AS
	V_VENTA 	NUMBER;		
	BEGIN
        SELECT SUM(SELLOUT * DURACION) INTO V_VENTA
        FROM DATA.T_ICOM_INVERSIONES WHERE (ID = P_ID );

        RETURN V_VENTA;

	EXCEPTION WHEN NO_DATA_FOUND THEN
        RETURN 0;
	END F_VENTAUSDSITUACIONSELLOUT;

     /*
	Funcion que devuelve el valor meta de las ventas Sell Out
	Por: JAsanza
	Fecha: Diciembre 2022
	*/
    FUNCTION  F_VentaUsdMetaSellOut (P_ID NUMBER, P_DURACION NUMBER DEFAULT 1) RETURN NUMBER AS
	    v_ventausd	NUMBER;
	BEGIN
		BEGIN
			select sum(nvl(((sellout*p_duracion)*(1+nvl((selloutcrecimiento/100),0))),0))
            into v_ventausd
            from data.vt_icom_inversion_cliente
            where idinversion = p_id
            --and estado = 1 
            ; 
		EXCEPTION WHEN NO_DATA_FOUND THEN
			 v_ventausd:=0;
		END;

		RETURN v_ventausd;
    EXCEPTION WHEN others THEN
        RETURN 0;    
	END F_VentaUsdMetaSellOut;

    /*
	Funcion que devuelve el valor real de las ventas Sell Out
	Por: JAsanza
	Fecha: Diciembre 2022
	*/
    FUNCTION F_TOTALREALSELLOUT ( P_ID NUMBER) return number as 
		v_real number ;
	BEGIN
        BEGIN
			SELECT selloutreal 		INTO v_real
			FROM DATA.T_ICOM_INVERSIONES 	WHERE ID = P_ID;
		EXCEPTION WHEN NO_DATA_FOUND THEN
			v_real:=0;	
		END;
        return v_real ;
    END;

    /* Funcion que retorn el valor real de venta para la inversion 
    Por: JAsanza
	Fecha: Diciembre 2022
    */
    FUNCTION F_VentaReal (P_ID NUMBER, P_PERIODO VARCHAR2, P_FECHAINICIO DATE, P_MESES NUMBER) return number as
    v_ventareal number;
    begin


        select  SUM(nvl(v.VALORVENTA,0))  into v_ventareal
			from ( select to_char(orden,'00') mes, to_char(p_fechainicio,'yyyy') anio, periododescripcion 
                   from data.vt_icom_periodos 
                   where (codigo = p_meses or p_meses=0) and periododescripcion = p_periodo ) udc
			LEFT JOIN (SELECT SUM(VALORVENTA) valorventa,  to_char(v.fecha,'MM')MES, to_char(v.fecha,'YYYY') ANIO 
                        from   data.vt_trad_sellIN V 
                            INNER JOIN T_ICOM_INVERSION_CLIENTE C ON (c.idinversion=P_ID  AND v.CODIGOCLIENTE=c.codigocliente)
                            INNER JOIN T_ICOM_INVERSION_producto P ON (P.idinversion=P_ID  AND v.CODIGOPRODUCTO=p.CODIGOPRODUCTO AND TIPO=1 )
                        WHERE V.FECHA between trunc(ADD_MONTHS(P_FECHAINICIO, -12),'MM') and LAST_DAY(ADD_MONTHS(P_FECHAINICIO, 12))
                        GROUP BY to_char(v.fecha,'MM'),to_char(v.fecha,'YYYY')
                        ) v on udc.MES=V.MES  AND UDC.ANIO=V.ANIO
                        --group by UDC.ANIO, PERIODODESCRIPCION
                        ;
         return v_ventareal ;               
    exception 
        when others then    
            return null ;
    end ;

    /* Funcion que retorn gasto variable por cliente para la inversion     */
    FUNCTION F_GastoVariableCliente (P_ID NUMBER, P_CODIGOGRUPO VARCHAR2, P_DURACION NUMBER, P_SELLOUT NUMBER, P_CRECIMIENTO NUMBER ) return number as
        v_totalMeta number;
        v_totalMetaGasto number;
        v_gasto number;
    BEGIN
        --busco el total meta sell out USD
        BEGIN
			select sum(nvl(((sellout*p_duracion)*(1+nvl((selloutcrecimiento/100),0))),0))
            into v_totalMeta
            from data.vt_icom_inversion_cliente
            where idinversion = p_id
             ; 
		EXCEPTION WHEN NO_DATA_FOUND THEN
			 v_totalMeta:=0;
		END;
        if nvl(v_totalMeta,0) = 0 then 
            v_totalMeta := 1 ;
        end if;
        BEGIN
            SELECT sum(nvl(VALORMETA,0)) INTO v_totalMetaGasto
                FROM DATA.T_ICOM_INVERSION_GASTO
                WHERE IDINVERSION = P_ID and GASTOTIPO = 'GASTO' AND TIPO='VARIABLE';
        EXCEPTION WHEN NO_DATA_FOUND THEN
			 v_totalMetaGasto:=0;
		END;  
        if nvl(v_totalMetaGasto,0) = 0 then 
            v_totalMetaGasto := 0 ;
        end if;
        v_gasto := ((nvl(((p_sellout*p_duracion)*(1+nvl((p_crecimiento/100),0))),0))/v_totalMeta)*v_totalMetaGasto;
        return v_gasto ;
    END F_GastoVariableCliente;
    
    /*Formula la para situacion Actual en dolares por aprobacion de cliente */
    /* P_ID El id de la inversion comercia
       P_TIPO 1 para clientes aprobados, 0 para clientes rechazados
       P_MESES el numero de meses de duraciÃƒÂ³n de la inversiÃƒÂ³n*/
	FUNCTION  F_ventaUsdSituacionCliente (P_ID NUMBER,  P_TIPO NUMBER, P_MESES NUMBER DEFAULT 0) RETURN NUMBER
	AS
    v_duracion number;
	V_VENTA 	NUMBER;		
	BEGIN
        if p_meses = 0 then
            select duracion into v_duracion 
            from t_icom_inversiones
            where id = p_id ;
        end if;

        SELECT SUM(SELLIN * DECODE(p_meses, 0, v_duracion, p_meses)) INTO V_VENTA
        FROM data.vt_icom_inversion_cliente
        WHERE IDINVERSION = P_ID 
        AND ( (P_TIPO = 1 AND NEGOCIACION IN (1,3)) OR (P_TIPO = 0 AND NEGOCIACION NOT IN (1,3)) ) ; --tipo 1: aprobados 0:  rechazados

        RETURN V_VENTA;

	EXCEPTION WHEN NO_DATA_FOUND THEN
        RETURN 0;
	END F_ventaUsdSituacionCliente;
    
    /*Formula la para venta meta en dolares por tipo de cliente */
    /* P_ID El id de la inversion comercia
       P_TIPO 1 para clientes aprobados, 0 para clientes rechazados*/
    FUNCTION  F_VentaUsdMetaCliente (P_ID NUMBER,  P_TIPO NUMBER) RETURN NUMBER
	AS
	v_ventausd		NUMBER;
	V_CALCULO		NUMBER;
	v_crecimiento	number;
	V_SELLINCRECIMIENTO number;
	BEGIN
        /*Busca el porcentaje de crecimiento meta */
		BEGIN
			SELECT SELLINCRECIMIENTO 
			INTO V_SELLINCRECIMIENTO
			FROM DATA.T_ICOM_INVERSIONES
			WHERE ID = P_ID;
		EXCEPTION WHEN NO_DATA_FOUND THEN
			 V_SELLINCRECIMIENTO:=0;
		END;
        
        v_ventausd:=	F_ventaUsdSituacionCliente(P_ID => p_id,  P_TIPO => p_tipo);
		V_CALCULO:=nvl(v_ventausd,0)*(1+(nvl(V_SELLINCRECIMIENTO,0)/100));

		RETURN V_CALCULO;
    EXCEPTION WHEN others THEN
        RETURN 0;    
	END F_VentaUsdMetaCliente;
    
    /*
	Funcion que devuelve el valor real de las ventas Sell In por tipo de cliente
	Por: JAsanza
	P_ID El id de la inversion comercia
       P_TIPO 1 para clientes aprobados, 0 para clientes rechazados
	*/
    FUNCTION F_TotalRealCliente (P_ID NUMBER,  P_TIPO NUMBER)  return number as 
		v_real number ;
	BEGIN
        BEGIN
			SELECT sum(nvl(sellinreal,0)) 		INTO v_real
			FROM DATA.T_ICOM_INVERSION_CLIENTE_G 	
            WHERE idinversion = P_ID
            AND ( (P_TIPO = 1 AND NEGOCIACION IN (1,3)) OR (P_TIPO = 0 AND NEGOCIACION NOT IN (1,3)) ) ; --tipo 1: aprobados 0:  rechazados

		EXCEPTION WHEN NO_DATA_FOUND THEN
			v_real:=0;	
		END;
        return v_real ;
    END F_TotalRealCliente;
    
    /*
	Funcion que devuelve el valor situacion de las ventas Sell Out por tipo de cliente
	Por: JAsanza
	P_ID El id de la inversion comercia
       P_TIPO 1 para clientes aprobados, 0 para clientes rechazados
	*/
    FUNCTION  F_ventaUsdSit_SelloutCliente (P_ID NUMBER ,  P_TIPO NUMBER) RETURN NUMBER
	AS
	V_VENTA 	NUMBER;	
    v_duracion number;
	BEGIN
        select duracion into v_duracion 
            from t_icom_inversiones
            where id = p_id ;
            
        SELECT SUM(SELLOUT * v_DURACION) INTO V_VENTA
        FROM data.vt_icom_inversion_cliente
        WHERE IDINVERSION = P_ID 
        AND ( (P_TIPO = 1 AND NEGOCIACION IN (1,3)) OR (P_TIPO = 0 AND NEGOCIACION NOT IN (1,3)) ) ; --tipo 1: aprobados 0:  rechazados

        RETURN V_VENTA;

	EXCEPTION WHEN NO_DATA_FOUND THEN
        RETURN 0;
	END F_ventaUsdSit_SelloutCliente;
    
    /*
	Funcion que devuelve el valor meta de las ventas Sell Out por cliente
	Por: JAsanza
	P_ID El id de la inversion comercia
       P_TIPO 1 para clientes aprobados, 0 para clientes rechazados
	*/
    FUNCTION  F_VentaUsdMetaSellOutCliente (P_ID NUMBER,  P_TIPO NUMBER ) RETURN NUMBER AS
	    v_ventausd	NUMBER;
        v_duracion number;
	BEGIN
        
        select duracion into v_duracion 
            from t_icom_inversiones
            where id = p_id ;
		
        BEGIN
			select sum(nvl(((sellout*v_duracion)*(1+nvl((selloutcrecimiento/100),0))),0))
            into v_ventausd
            from data.vt_icom_inversion_cliente
            where idinversion = p_id
            AND ( (P_TIPO = 1 AND NEGOCIACION IN (1,3)) OR (P_TIPO = 0 AND NEGOCIACION NOT IN (1,3)) ) ; --tipo 1: aprobados 0:  rechazados
            
		EXCEPTION WHEN NO_DATA_FOUND THEN
			 v_ventausd:=0;
		END;

		RETURN v_ventausd;
    EXCEPTION WHEN others THEN
        RETURN 0;    
	END F_VentaUsdMetaSellOutCliente;
    
    /*
	Funcion que devuelve el valor real de las ventas Sell Out por cliente
	Por: JAsanza
	P_ID El id de la inversion comercia
       P_TIPO 1 para clientes aprobados, 0 para clientes rechazados
	*/
    FUNCTION F_totalRealSellOutCliente (P_ID NUMBER,  P_TIPO NUMBER) return number as 
		v_real number ;
	BEGIN
        BEGIN
			SELECT SUM(SELLOUTREAL) INTO  v_real 
              FROM T_ICOM_INVERSION_CLIENTE_G
             WHERE IDINVERSION= p_id
               AND ( (P_TIPO = 1 AND NEGOCIACION IN (1,3)) 
                    OR (P_TIPO = 0 AND NEGOCIACION NOT IN (1,3)) 
                    OR P_TIPO = 2 ) ; --tipo 1:aprobados 0:rechazados 2:todos
		EXCEPTION WHEN NO_DATA_FOUND THEN
			v_real:=0;	
		END;
        return v_real ;
    END;
    
    /*
	Funcion que devuelve el valor del Total Margen - Situacion Actual por cliente
	Por: JAsanza
    P_ID El id de la inversion comercia
       P_TIPO 1 para clientes aprobados, 0 para clientes rechazados
	*/
    FUNCTION F_val_totalMargenSit_Cliente ( P_ID NUMBER, P_TIPO NUMBER, P_DURACION NUMBER) return number as 
        v_sellin number;
        v_sellincosto number;
	BEGIN
        
        SELECT SUM(nvl(SELLIN,0)), sum(nvl(sellincosto,0)) INTO v_sellin, v_sellincosto
        FROM data.vt_icom_inversion_cliente
        WHERE IDINVERSION = P_ID 
        AND ( (P_TIPO = 1 AND NEGOCIACION IN (1,3)) OR (P_TIPO = 0 AND NEGOCIACION NOT IN (1,3)) ) ; --tipo 1: aprobados 0:  rechazados

		return ( (v_sellin*nvl(p_duracion,0) ) * data.PK_ICOM_FORMULAS.F_VAL_MARGENSITUACION ( P_SELLIN => v_sellin, 
																P_DURACION => p_duracion, 
																P_SELLINCOSTO => v_sellincosto) ) ;
        
	END F_val_totalMargenSit_Cliente;
    
    /*
	Funcion que devuelve el gasto fijo por Cliente
	Por: JAsanza
    P_ID El id de la inversion comercia
    P_TIPO 1 para clientes aprobados, 0 para clientes rechazados
    P_TIPOGASTO 0: para el gasto meta 1: para el gastoreal
	*/
    FUNCTION F_gastoFijoCliente ( P_ID NUMBER, P_TIPO NUMBER, P_TIPOGASTO NUMBER) return number as 
        v_meta number;
    BEGIN
        IF(data.PK_ICOM_COMMONS.F_ESPADRE(P_ID)=1) THEN 
            begin
                SELECT sum(NVL(M.TOTAL,0)) INTO V_META
                FROM DATA.T_ICOM_INVERSION_CLIENTE_G G
                  INNER JOIN DATA.t_icom_cliente_material M 
                    ON ( G.IDINVERSION = M.IDINVERSION AND G.CODIGOGRUPO = M.CODIGOGRUPO 
                         AND M.TIPO = CASE WHEN P_TIPOGASTO = 0 THEN --META
                                             0 ELSE M.TIPO END
                         AND M.NEGOCIACION = CASE WHEN P_TIPOGASTO = 1 THEN --REAL
                                             1 ELSE M.NEGOCIACION END )
                WHERE G.IDINVERSION in ( select id from data.t_icom_inversiones where (idgrupo = p_id and idpadre is null) )
                AND ( (P_TIPO = 1 AND G.NEGOCIACION IN (1,3)) OR (P_TIPO = 0 AND G.NEGOCIACION NOT IN (1,3)) ) ;
            exception 
                when others then v_meta := 0;
            end;
        ELSE
            begin
                SELECT sum(NVL(M.TOTAL,0)) INTO V_META
                FROM DATA.T_ICOM_INVERSION_CLIENTE_G G
                  INNER JOIN DATA.t_icom_cliente_material M 
                    ON ( G.IDINVERSION = M.IDINVERSION AND G.CODIGOGRUPO = M.CODIGOGRUPO 
                         AND M.TIPO = CASE WHEN P_TIPOGASTO = 0 THEN --META
                                             0 ELSE M.TIPO END
                         AND M.NEGOCIACION = CASE WHEN P_TIPOGASTO = 1 THEN --REAL
                                             1 ELSE M.NEGOCIACION END )
                WHERE G.IDINVERSION = P_ID 
                AND ( (P_TIPO = 1 AND G.NEGOCIACION IN (1,3)) OR (P_TIPO = 0 AND G.NEGOCIACION NOT IN (1,3)) ) ;
            exception 
                when others then v_meta := 0;
            end;
        END IF;
        return v_meta;
    END F_gastoFijoCliente;
    
    /*
	Funcion que devuelve el valor del Total Margen  - Meta por Cliente
	Por: JAsanza
    P_ID El id de la inversion comercia
    P_TIPO 1 para clientes aprobados, 0 para clientes rechazados
    P_DURACION el nÃƒÂºmero de meses que tiene de validas la inversion comercial
	*/
    FUNCTION F_val_totalMargenMetaCliente ( P_ID NUMBER, P_TIPO NUMBER, P_DURACION NUMBER) return number as 
		v_meta number ;
        v_valormeta number ;
        v_sellin number;
        v_sellincosto number;
        v_sellincrecimiento number;
	BEGIN
    
        v_meta := F_gastoFijoCliente ( P_ID => P_ID, P_TIPO => P_TIPO, P_TIPOGASTO => 0) ; --GASTO META
        
        --Se busca el total sellin por clientes aprobados o rechazados
        SELECT SUM(nvl(SELLIN,0)), sum(nvl(sellincosto,0)), max(sellincrecimiento) 
        INTO v_sellin, v_sellincosto, v_sellincrecimiento
        FROM data.vt_icom_inversion_cliente
        WHERE IDINVERSION = P_ID 
        AND ( (P_TIPO = 1 AND NEGOCIACION IN (1,3)) OR (P_TIPO = 0 AND NEGOCIACION NOT IN (1,3)) ) ; --tipo 1: aprobados 0:  rechazados

        v_valormeta := ((nvl(v_sellin,0)*nvl(p_duracion,0)) * (1+(nvl(v_sellincrecimiento,0)/100)));
		return (( nvl(v_valormeta,0) * data.PK_ICOM_FORMULAS.F_VAL_MARGENMETA ( P_SELLIN => v_sellin, 
																P_DURACION => p_duracion, 
																P_SELLINCOSTO => v_sellincosto)) - nvl(v_meta,0) ) ;

	END F_val_totalMargenMetaCliente;
    
    /*
	Funcion que devuelve el valor del Total Margen  - Real por Cliente
	Por: JAsanza
    P_ID El id de la inversion comercial
    P_TIPO 1 para clientes aprobados, 0 para clientes rechazados
    P_DURACION el nÃƒÂºmero de meses que tiene de validas la inversion comercial
	*/
    FUNCTION F_val_totalMargenRealCliente ( P_ID NUMBER, P_TIPO NUMBER, P_DURACION NUMBER) return number as 
		v_meta number ;
        v_valormeta number ;
        v_sellin number;
        v_sellincosto number;
        v_sellincrecimiento number;
	BEGIN
    
        v_meta := F_gastoFijoCliente ( P_ID => P_ID, P_TIPO => P_TIPO, P_TIPOGASTO => 1) ; --GASTO REAL
        
        SELECT SUM(nvl(SELLINREAL,0)), sum(nvl(SELLINCOSTOREAL,0)) INTO v_sellin, v_sellincosto
        FROM DATA.T_ICOM_INVERSION_CLIENTE_G 
        WHERE IDINVERSION = P_ID 
        AND ( (P_TIPO = 1 AND NEGOCIACION IN (1,3)) OR (P_TIPO = 0 AND NEGOCIACION NOT IN (1,3)) ) ; --tipo 1: aprobados 0:  rechazados

        return (( nvl(v_sellin,0) * data.PK_ICOM_FORMULAS.F_VAL_MARGENREAL ( P_SELLINREAL => v_sellin, 
																P_SELLINREALCOSTO => v_sellincosto )) ) ;

	END F_val_totalMargenRealCliente;
    
    /*Formula para situacion Actual en unidades por aprobacion de cliente */
    /* P_ID El id de la inversion comercia
       P_TIPO 1 para clientes aprobados, 0 para clientes rechazados
       P_MESES el numero de meses de duraciÃƒÂ³n de la inversiÃƒÂ³n*/
	FUNCTION  F_ventaUndSituacionCliente (P_ID NUMBER,  P_TIPO NUMBER, P_MESES NUMBER DEFAULT 0) RETURN NUMBER AS
    v_duracion number;
	V_VENTA 	NUMBER;		
	BEGIN
        if p_meses = 0 then
            select duracion into v_duracion 
            from t_icom_inversiones
            where id = p_id ;
        end if;

        SELECT SUM(SELLINUND * DECODE(p_meses, 0, v_duracion, p_meses)) INTO V_VENTA
        FROM data.vt_icom_inversion_cliente
        WHERE IDINVERSION = P_ID 
        AND ( (P_TIPO = 1 AND NEGOCIACION IN (1,3)) OR (P_TIPO = 0 AND NEGOCIACION NOT IN (1,3)) ) ; --tipo 1: aprobados 0:  rechazados

        RETURN V_VENTA;

	EXCEPTION WHEN NO_DATA_FOUND THEN
        RETURN 0;
	END F_ventaUndSituacionCliente;
    
    /*
	Funcion que devuelve el valor del Venta Unidades - Meta por Cliente
	Por: JAsanza
    P_ID El id de la inversion comercia
    P_TIPO 1 para clientes aprobados, 0 para clientes rechazados
	*/
    FUNCTION  F_VentaUndMetaCliente (P_ID NUMBER, P_TIPO NUMBER) RETURN NUMBER 	AS
	v_ventaund		NUMBER;
	V_CALCULO		NUMBER;
	v_crecimiento	number;
	V_SELLINCRECIMIENTO number;
	BEGIN
		/*Busca el porcentaje de crecimiento meta */
		BEGIN
			SELECT SELLINCRECIMIENTO 
			INTO V_SELLINCRECIMIENTO
			FROM DATA.T_ICOM_INVERSIONES
			WHERE ID = P_ID;
		EXCEPTION WHEN NO_DATA_FOUND THEN
			 V_SELLINCRECIMIENTO:=0;
		END;
        
        v_ventaund:= F_ventaUndSituacionCliente(P_ID => p_id,  P_TIPO => p_tipo);
		V_CALCULO:=nvl(v_ventaund,0)*(1+(nvl(V_SELLINCRECIMIENTO,0)/100));

		RETURN round(V_CALCULO,0);
    EXCEPTION WHEN others THEN
        RETURN 0;    
	END F_VentaUndMetaCliente;
            
    /*Funcion que retorna el gasto meta por cliente 
    Por: JAsanza
    P_ID El id de la inversion comercia
    P_TIPO 1 para clientes aprobados, 0 para clientes rechazados
    */
    FUNCTION  F_GastoInversionMetaCliente (P_ID NUMBER, P_TIPO NUMBER) RETURN NUMBER AS
	V_CALCULO		NUMBER;
	v_gastovariablem	number;
	v_gastofijom	number;
    v_meta       NUMBER;
    v_gastoaplicacion number;
    v_gastocalculo number;
    v_gastounitario number;
    v_gastocompartido number;
    v_gunitario number ;
    v_num_cliente   number;
    
	BEGIN
        
        IF(PK_ICOM_COMMONS.F_ESPADRE(P_ID)=1) THEN 
            SELECT SUM(PK_ICOM_FORMULAS.F_GastoInversionMetaCliente(P_ID =>ID, P_TIPO => P_TIPO)) INTO V_CALCULO  
            FROM T_ICOM_INVERSIONES WHERE  IDGRUPO=P_ID  and IDPADRE is null; 
            
            RETURN V_CALCULO ; 
        END IF;
        
        SELECT gastoaplicacion/100, gastocalculo, gastounitario
        INTO v_gastoaplicacion, v_gastocalculo, v_gastounitario
        FROM DATA.T_ICOM_INVERSIONES 	
        WHERE ID = P_ID;
        
        if v_gastocalculo = 0 then --%
            v_gastounitario := v_gastounitario/100 ;
            v_meta := F_VentaUsdMetaCliente (P_ID => P_ID,  P_TIPO => P_TIPO) ;
        else --$
            v_meta := F_VentaUndMetaCliente (P_ID => P_ID,  P_TIPO => P_TIPO);
        end if;
       		
		v_gastovariablem := nvl(v_meta,0)*(v_gastoaplicacion)*nvl(v_gunitario,0);
        
        v_gastofijom := F_gastoFijoCliente ( P_ID => P_ID, P_TIPO => P_TIPO, P_TIPOGASTO => 0) ; --GASTO META
        
		V_CALCULO:= nvl(v_gastovariablem,0)+nvl(v_gastofijom,0);

		RETURN V_CALCULO;
	END F_GastoInversionMetaCliente; 
    
    /*Funcion que retorna el total del gasto meta de una inversion
      ** p_id el identificador de la inversion */
    FUNCTION F_TotalGastoMetaInv (P_ID NUMBER) RETURN NUMBER as
        v_valor number;
    BEGIN
        select sum(valormeta) into v_valor
        from data.t_icom_inversion_gasto G
        where gastotipo = 'GASTO'
        AND EXISTS (SELECT 1 FROM T_ICOM_INVERSIONES I WHERE I.ID =G.idinversion AND (I.ID=P_ID OR (I.IDGRUPO=P_ID  and IDPADRE is null))) ;
        
        return nvl(v_valor,0) ;
    exception 
        when others then
            return 0 ;
    END F_TotalGastoMetaInv ;

    function f_presentaPuntoEquilibrio (p_id number) return number as 
    v_retorno number;
    begin
        SELECT case COUNT(DISTINCT 1) when 1 then 0 else 1 end activo
        into v_retorno 
        FROM (
            SELECT SUM(PK_ICOM_FORMULAS.F_VENTAUNDPEQ(ID))          PEQ FROM T_ICOM_INVERSIONES WHERE (ID=P_ID ) UNION ALL
            SELECT SUM(PK_ICOM_FORMULAS.F_VENTAUSDPEQ(ID))          PEQ FROM T_ICOM_INVERSIONES WHERE (ID=P_ID ) UNION ALL
            SELECT SUM(PK_ICOM_FORMULAS.F_CRECIMINETOUSDPEQ(ID))    PEQ FROM T_ICOM_INVERSIONES WHERE (ID=P_ID ) UNION ALL
            SELECT SUM(PK_ICOM_FORMULAS.F_MARGENBRUTOPEQ(ID))       PEQ FROM T_ICOM_INVERSIONES WHERE (ID=P_ID ) UNION ALL
            SELECT SUM(PK_ICOM_FORMULAS.F_GASTOINVERSIONPEQ(ID))    PEQ FROM T_ICOM_INVERSIONES WHERE (ID=P_ID ) UNION ALL
            SELECT SUM(PK_ICOM_FORMULAS.F_MARGENDESPUESGASTOPEQ(ID))PEQ FROM T_ICOM_INVERSIONES WHERE (ID=P_ID ) UNION ALL
            SELECT PK_ICOM_FORMULAS.F_CRECIMIENTOPEQ(P_ID)*100      PEQ FROM DUAL UNION ALL
            SELECT PK_ICOM_FORMULAS.F_MARGENBRUTOESTANDAR(P_ID)*100 PEQ FROM DUAL UNION ALL
            SELECT PK_ICOM_FORMULAS.F_MARGENINCREMENTALPEQ(P_ID)    PEQ FROM DUAL UNION ALL
            SELECT PK_ICOM_FORMULAS.F_MARGEPBRUTOPEQ(P_ID)          PEQ FROM DUAL
        ) 
        WHERE PEQ<0;  
        --dbms_output.put_line(v_retorno);
        RETURN v_retorno;
    end f_presentaPuntoEquilibrio;
END PK_ICOM_FORMULAS;
/
/

