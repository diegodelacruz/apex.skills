CREATE OR REPLACE EDITIONABLE PACKAGE BODY "DATA"."PK_VTAS_OC_PDF" AS

    C_TABLA_PEDIDO CONSTANT VARCHAR2(50) := 'T_VTAS_PEDIDOS_CAB';
    C_TIPO_PEDIDO  CONSTANT VARCHAR2(50) := 'OC_PDF';
    C_TABLA_MAPEO  CONSTANT VARCHAR2(50) := 'T_VTAS_PEDIDO_CONF_OC';
    C_TIPO_MAPEO   CONSTANT VARCHAR2(50) := 'OC_MAPEO_EXCEL';

    FUNCTION F_URL_SERVICIO RETURN VARCHAR2 IS
        V_URL T_CORP_UDC.VALOR%TYPE;
    BEGIN
        SELECT VALOR
          INTO V_URL
          FROM T_CORP_UDC
         WHERE ID_CABECERA = 'WEBSERVICE'
           AND ID_TABLA = '18'
           AND ACTIVO = '1';

        RETURN V_URL;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20100, 'No existe configuracion WEBSERVICE/18 para convertir PDF a Excel');
    END F_URL_SERVICIO;

    FUNCTION F_ULTIMO_ARCHIVO_PDF(P_IDPEDIDO IN NUMBER) RETURN NUMBER IS
        V_NUMEROARCHIVO FILES.T_APEX_ARCHIVOS.NUMEROARCHIVO%TYPE;
    BEGIN
        SELECT NUMEROARCHIVO
          INTO V_NUMEROARCHIVO
          FROM (
                SELECT NUMEROARCHIVO
                  FROM FILES.T_APEX_ARCHIVOS
                 WHERE TABLA = C_TABLA_PEDIDO
                   AND ID_TABLA = TO_CHAR(P_IDPEDIDO)
                   AND TIPO = C_TIPO_PEDIDO
                   AND LOWER(FILENAME) LIKE '%.pdf'
                 ORDER BY FECHA DESC, NUMEROARCHIVO DESC
               )
         WHERE ROWNUM = 1;

        RETURN V_NUMEROARCHIVO;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20100, 'Debe adjuntar un archivo PDF para el pedido ' || P_IDPEDIDO);
    END F_ULTIMO_ARCHIVO_PDF;

    /* Valida extension, MIME y firma antes de enviar el adjunto al conversor. */
    PROCEDURE SP_VALIDAR_ARCHIVO_PDF(P_NUMEROARCHIVO IN NUMBER) IS
        V_FILENAME FILES.T_APEX_ARCHIVOS.FILENAME%TYPE;
        V_MIMETYPE FILES.T_APEX_ARCHIVOS.MIMETYPE%TYPE;
        V_FIRMA    RAW(5);
    BEGIN
        SELECT FILENAME,
               MIMETYPE,
               DBMS_LOB.SUBSTR(BLOBCONTENT, 5, 1)
          INTO V_FILENAME,
               V_MIMETYPE,
               V_FIRMA
          FROM FILES.T_APEX_ARCHIVOS
         WHERE NUMEROARCHIVO = P_NUMEROARCHIVO;

        IF LOWER(V_FILENAME) NOT LIKE '%.pdf' THEN
            RAISE_APPLICATION_ERROR(-20100, 'El archivo seleccionado debe tener extension .pdf');
        END IF;

        IF V_MIMETYPE IS NOT NULL AND LOWER(V_MIMETYPE) NOT LIKE '%pdf%' THEN
            RAISE_APPLICATION_ERROR(-20100, 'El archivo seleccionado no tiene tipo PDF');
        END IF;

        IF UTL_RAW.CAST_TO_VARCHAR2(V_FIRMA) <> '%PDF-' THEN
            RAISE_APPLICATION_ERROR(-20100, 'El contenido del archivo no corresponde a un PDF valido');
        END IF;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20100, 'No existe el adjunto PDF seleccionado');
    END SP_VALIDAR_ARCHIVO_PDF;

    PROCEDURE SP_CARGAR_COLECCION_EXCEL(P_NUMEROARCHIVO IN NUMBER) IS
    BEGIN
        APEX_COLLECTION.CREATE_OR_TRUNCATE_COLLECTION('TABLA_EXCEL');

        FOR R IN (
            SELECT P.LINE_NUMBER,
                   P.COL001, P.COL002, P.COL003, P.COL004, P.COL005,
                   P.COL006, P.COL007, P.COL008, P.COL009, P.COL010,
                   P.COL011, P.COL012, P.COL013, P.COL014, P.COL015,
                   P.COL016, P.COL017, P.COL018, P.COL019, P.COL020,
                   P.COL021, P.COL022, P.COL023, P.COL024, P.COL025,
                   P.COL026, P.COL027, P.COL028, P.COL029, P.COL030,
                   P.COL031, P.COL032, P.COL033, P.COL034, P.COL035,
                   P.COL036, P.COL037, P.COL038, P.COL039, P.COL040,
                   P.COL041, P.COL042, P.COL043, P.COL044, P.COL045,
                   P.COL046, P.COL047, P.COL048, P.COL049
              FROM FILES.T_APEX_ARCHIVOS A,
                   TABLE(APEX_DATA_PARSER.PARSE(
                       P_CONTENT   => A.BLOBCONTENT,
                       P_FILE_NAME => A.FILENAME,
                       P_SKIP_ROWS => 0
                   )) P
             WHERE A.NUMEROARCHIVO = P_NUMEROARCHIVO
        ) LOOP
            APEX_COLLECTION.ADD_MEMBER(
                P_COLLECTION_NAME => 'TABLA_EXCEL',
                P_C001 => TO_CHAR(R.LINE_NUMBER),
                P_C002 => R.COL001, P_C003 => R.COL002, P_C004 => R.COL003, P_C005 => R.COL004,
                P_C006 => R.COL005, P_C007 => R.COL006, P_C008 => R.COL007, P_C009 => R.COL008,
                P_C010 => R.COL009, P_C011 => R.COL010, P_C012 => R.COL011, P_C013 => R.COL012,
                P_C014 => R.COL013, P_C015 => R.COL014, P_C016 => R.COL015, P_C017 => R.COL016,
                P_C018 => R.COL017, P_C019 => R.COL018, P_C020 => R.COL019, P_C021 => R.COL020,
                P_C022 => R.COL021, P_C023 => R.COL022, P_C024 => R.COL023, P_C025 => R.COL024,
                P_C026 => R.COL025, P_C027 => R.COL026, P_C028 => R.COL027, P_C029 => R.COL028,
                P_C030 => R.COL029, P_C031 => R.COL030, P_C032 => R.COL031, P_C033 => R.COL032,
                P_C034 => R.COL033, P_C035 => R.COL034, P_C036 => R.COL035, P_C037 => R.COL036,
                P_C038 => R.COL037, P_C039 => R.COL038, P_C040 => R.COL039, P_C041 => R.COL040,
                P_C042 => R.COL041, P_C043 => R.COL042, P_C044 => R.COL043, P_C045 => R.COL044,
                P_C046 => R.COL045, P_C047 => R.COL046, P_C048 => R.COL047, P_C049 => R.COL048,
                P_C050 => R.COL049
            );
        END LOOP;
    END SP_CARGAR_COLECCION_EXCEL;

    PROCEDURE SP_VALIDAR_EXCEL_DISPONIBLE(P_NUMEROARCHIVO IN NUMBER) IS
        V_CONVERTIDO NUMBER := 0;
    BEGIN
        FOR I IN 1 .. 15 LOOP
            SELECT COUNT(*)
              INTO V_CONVERTIDO
              FROM FILES.T_APEX_ARCHIVOS
             WHERE NUMEROARCHIVO = P_NUMEROARCHIVO
               AND (
                    LOWER(FILENAME) LIKE '%.xlsx'
                    OR LOWER(MIMETYPE) LIKE '%spreadsheet%'
                    OR LOWER(MIMETYPE) LIKE '%excel%'
               );

            EXIT WHEN V_CONVERTIDO > 0;
            DBMS_SESSION.SLEEP(1);
        END LOOP;

        IF V_CONVERTIDO = 0 THEN
            RAISE_APPLICATION_ERROR(-20100, 'El archivo convertido no quedo disponible para lectura: ' || P_NUMEROARCHIVO);
        END IF;
    END SP_VALIDAR_EXCEL_DISPONIBLE;

    PROCEDURE SP_SOLICITAR_CONVERSION(
        P_NUMEROARCHIVO IN NUMBER,
        P_USUARIO       IN VARCHAR2
    ) IS
        V_URL       VARCHAR2(2000);
        V_PAYLOAD   CLOB;
        V_RESPUESTA CLOB;
        V_EXITO     VARCHAR2(20);
        V_MENSAJE   VARCHAR2(4000);
    BEGIN
        V_URL := F_URL_SERVICIO;

        SELECT JSON_OBJECT(
                   'numeroArchivo' VALUE P_NUMEROARCHIVO,
                   'usuario' VALUE NVL(P_USUARIO, USER)
                   RETURNING CLOB
               )
          INTO V_PAYLOAD
          FROM DUAL;

        APEX_WEB_SERVICE.G_REQUEST_HEADERS.DELETE;
        APEX_WEB_SERVICE.G_REQUEST_HEADERS(1).NAME := 'Content-Type';
        APEX_WEB_SERVICE.G_REQUEST_HEADERS(1).VALUE := 'application/json';

        V_RESPUESTA := APEX_WEB_SERVICE.MAKE_REST_REQUEST(
            P_URL         => V_URL,
            P_HTTP_METHOD => 'POST',
            P_BODY        => V_PAYLOAD
        );

        V_EXITO := JSON_VALUE(V_RESPUESTA, '$.exito' RETURNING VARCHAR2 DEFAULT 'false' ON ERROR);
        V_MENSAJE := JSON_VALUE(V_RESPUESTA, '$.mensaje' RETURNING VARCHAR2 NULL ON ERROR);

        IF NVL(LOWER(V_EXITO), 'false') NOT IN ('true', '1') THEN
            RAISE_APPLICATION_ERROR(
                -20100,
                'No se pudo convertir el PDF a Excel. '
                || NVL(V_MENSAJE, DBMS_LOB.SUBSTR(V_RESPUESTA, 3500, 1))
            );
        END IF;
    END SP_SOLICITAR_CONVERSION;

    PROCEDURE SP_CONVERTIR_Y_LEER_PDF(
        P_IDPEDIDO      IN NUMBER,
        P_USUARIO       IN VARCHAR2,
        P_NUMEROARCHIVO OUT NUMBER
    ) IS
        V_FILAS   NUMBER := 0;
        V_DETALLE NUMBER := 0;
    BEGIN
        IF P_IDPEDIDO IS NULL THEN
            RAISE_APPLICATION_ERROR(-20100, 'Debe guardar la orden de compra antes de adjuntar el PDF');
        END IF;

        P_NUMEROARCHIVO := F_ULTIMO_ARCHIVO_PDF(P_IDPEDIDO);

        SP_VALIDAR_ARCHIVO_PDF(P_NUMEROARCHIVO);
        SP_SOLICITAR_CONVERSION(P_NUMEROARCHIVO => P_NUMEROARCHIVO, P_USUARIO => P_USUARIO);

        SP_VALIDAR_EXCEL_DISPONIBLE(P_NUMEROARCHIVO);

        FOR I IN 1 .. 3 LOOP
            SP_CARGAR_COLECCION_EXCEL(P_NUMEROARCHIVO);

            SELECT COUNT(*)
              INTO V_FILAS
              FROM APEX_COLLECTIONS
             WHERE COLLECTION_NAME = 'TABLA_EXCEL';

            EXIT WHEN V_FILAS > 0;
            DBMS_SESSION.SLEEP(1);
        END LOOP;

        IF V_FILAS = 0 THEN
            RAISE_APPLICATION_ERROR(-20100, 'No se pudo leer filas del Excel convertido para el archivo ' || P_NUMEROARCHIVO);
        END IF;

        PK_VTAS_PEDIDOS.SP_LECTURAOC(P_IDPEDIDO => P_IDPEDIDO);

        SELECT COUNT(*)
          INTO V_DETALLE
          FROM DATA.T_VTAS_PEDIDOS
         WHERE IDPEDIDO = P_IDPEDIDO;

        IF V_DETALLE = 0 THEN
            RAISE_APPLICATION_ERROR(
                -20100,
                'El PDF fue convertido, pero no se cargo detalle para el pedido ' || P_IDPEDIDO
            );
        END IF;
    END SP_CONVERTIR_Y_LEER_PDF;

    PROCEDURE SP_CONVERTIR_Y_LEER_PDF(
        P_IDPEDIDO IN NUMBER,
        P_USUARIO  IN VARCHAR2
    ) IS
        V_NUMEROARCHIVO NUMBER;
    BEGIN
        SP_CONVERTIR_Y_LEER_PDF(
            P_IDPEDIDO      => P_IDPEDIDO,
            P_USUARIO       => P_USUARIO,
            P_NUMEROARCHIVO => V_NUMEROARCHIVO
        );
    END SP_CONVERTIR_Y_LEER_PDF;

    PROCEDURE SP_ELIMINAR_EXCEL_MAPEO(
        P_IDCONFIG      IN NUMBER,
        P_NUMEROARCHIVO IN NUMBER DEFAULT NULL
    ) IS
    BEGIN
        IF P_IDCONFIG IS NULL THEN
            RAISE_APPLICATION_ERROR(-20100, 'Debe guardar la configuracion antes de eliminar el Excel');
        END IF;

        FOR R IN (
            SELECT NUMEROARCHIVO
              FROM FILES.T_APEX_ARCHIVOS
             WHERE TABLA = C_TABLA_MAPEO
               AND ID_TABLA = TO_CHAR(P_IDCONFIG)
               AND TIPO = C_TIPO_MAPEO
               AND (P_NUMEROARCHIVO IS NULL OR NUMEROARCHIVO = P_NUMEROARCHIVO)
        ) LOOP
            DATA.PK_APEX_ARCHIVOS.SP_ELIMINAARCHIVO(R.NUMEROARCHIVO);
        END LOOP;
    END SP_ELIMINAR_EXCEL_MAPEO;

    PROCEDURE SP_CONVERTIR_PDF_MAPEO(
        P_IDCONFIG      IN NUMBER,
        P_ARCHIVO       IN VARCHAR2,
        P_USUARIO       IN VARCHAR2,
        P_NUMEROARCHIVO OUT NUMBER
    ) IS
        V_EXISTE NUMBER;
    BEGIN
        IF P_IDCONFIG IS NULL THEN
            RAISE_APPLICATION_ERROR(-20100, 'Debe guardar la configuracion de mapeo antes de convertir el PDF');
        END IF;

        IF P_ARCHIVO IS NULL THEN
            RAISE_APPLICATION_ERROR(-20100, 'Debe seleccionar un PDF para convertir a Excel');
        END IF;

        SELECT COUNT(*)
          INTO V_EXISTE
          FROM DATA.T_VTAS_PEDIDO_CONF_OC
         WHERE ID = P_IDCONFIG;

        IF V_EXISTE = 0 THEN
            RAISE_APPLICATION_ERROR(-20100, 'No existe la configuracion de mapeo ' || P_IDCONFIG);
        END IF;

        SP_ELIMINAR_EXCEL_MAPEO(P_IDCONFIG => P_IDCONFIG);

        DATA.PK_APEX_ARCHIVOS.SP_CREARARCHIVO(
            P_ARCHIVO       => P_ARCHIVO,
            P_TABLA         => C_TABLA_MAPEO,
            P_IDTABLA       => TO_CHAR(P_IDCONFIG),
            P_TIPO          => C_TIPO_MAPEO,
            P_OBSERVACION   => 'PDF convertido a Excel para validar mapeo de OC',
            P_USUARIO       => NVL(P_USUARIO, USER),
            P_NUMEROARCHIVO => P_NUMEROARCHIVO
        );

        COMMIT;

        BEGIN
            SP_SOLICITAR_CONVERSION(P_NUMEROARCHIVO => P_NUMEROARCHIVO, P_USUARIO => P_USUARIO);
            SP_VALIDAR_EXCEL_DISPONIBLE(P_NUMEROARCHIVO);
            COMMIT;
        EXCEPTION
            WHEN OTHERS THEN
                BEGIN
                    DATA.PK_APEX_ARCHIVOS.SP_ELIMINAARCHIVO(P_NUMEROARCHIVO);
                    COMMIT;
                EXCEPTION
                    WHEN OTHERS THEN
                        NULL;
                END;
                RAISE;
        END;
    END SP_CONVERTIR_PDF_MAPEO;

    PROCEDURE SP_CONVERTIR_PDF_MAPEO(
        P_IDCONFIG IN NUMBER,
        P_ARCHIVO  IN VARCHAR2,
        P_USUARIO  IN VARCHAR2
    ) IS
        V_NUMEROARCHIVO NUMBER;
    BEGIN
        SP_CONVERTIR_PDF_MAPEO(
            P_IDCONFIG      => P_IDCONFIG,
            P_ARCHIVO       => P_ARCHIVO,
            P_USUARIO       => P_USUARIO,
            P_NUMEROARCHIVO => V_NUMEROARCHIVO
        );
    END SP_CONVERTIR_PDF_MAPEO;

END PK_VTAS_OC_PDF;
/
