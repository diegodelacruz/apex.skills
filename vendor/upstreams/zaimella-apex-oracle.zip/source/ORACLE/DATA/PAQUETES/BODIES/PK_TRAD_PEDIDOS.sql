alter session set current_schema=DATA;

CREATE OR REPLACE EDITIONABLE PACKAGE BODY PK_TRAD_PEDIDOS AS
    
    /*Procedimiento para guardar la venta sellout promedio del portafolio*/
    PROCEDURE SP_VENTASPROMEDIO AS
        v_meses NUMBER;
    BEGIN
        SELECT TO_NUMBER(valor) INTO v_meses FROM data.t_corp_udc WHERE id_cabecera = 'TRAD_PARAM' AND id_tabla = '9';
        /* Refresca completamente los productos sugeridos con venta real por PDV. */
        EXECUTE IMMEDIATE 'TRUNCATE TABLE data.t_trad_productos_sugeridos';

        /* Materializa primero productos configurados para todos los PDVs activos. */
        INSERT INTO data.t_trad_productos_sugeridos
          (codigoproducto, tipo, codigopdv, compania, producto, codigobarra, selloutmes, ub)
        SELECT p.codigoproducto,
               NULL,
               c.codigopdv,
               p.compania,
               p.nombreproducto,
               p.codigobarra,
               0,
               case when validate_conversion(u.valor2 as number) = 1 then to_number(u.valor2) end
          FROM data.t_corp_udc u
          JOIN data.vt_gzm_producto p
            ON p.compania = u.codigocompania
           AND p.codigoproducto = u.id_tabla
          JOIN data.t_trad_cliente c
            ON c.compania = u.codigocompania
           AND c.codigogrupo IS NULL
         WHERE u.id_cabecera = 'TRA_PESU'
           AND NVL(u.activo, '1') = '1';

        /* Actualiza solo el universo materializado con ventas del periodo configurado. */
        MERGE INTO data.t_trad_productos_sugeridos d
        USING (
          SELECT /*+ LEADING(d s) USE_NL(s) INDEX(s IX_MVT_TRAD_SELLOUT_PDV_BARRA) */
                 d.rowid AS rid,
                 ROUND(GREATEST(0, NVL(SUM(s.valorunidad), 0)) / v_meses, 2) AS selloutmes
            FROM data.t_trad_productos_sugeridos d
            JOIN data.mvt_trad_sellout s
              ON s.compania = d.compania
             AND s.codigobarra = d.codigobarra
             AND s.codigopdv = d.codigopdv
             AND s.fecha >= TRUNC(ADD_MONTHS(SYSDATE, -v_meses), 'MM')
             AND s.fecha < TRUNC(SYSDATE, 'MM')
           GROUP BY d.rowid
        ) v ON (d.rowid = v.rid)
        WHEN MATCHED THEN UPDATE SET d.selloutmes = v.selloutmes;
        COMMIT;
    END SP_VENTASPROMEDIO;
    
    /*Procedimiento para sumar a la secuencia varios numeros */
    function f_secuencia (p_key in varchar,p_numero in number) return number is pragma autonomous_transaction;
        v_contador number;
    begin  
		select nextvalue + p_numero into v_contador from t_secuencia where key = p_key for update;
		update t_secuencia set nextvalue = v_contador where key = p_key;
        commit;
        return v_contador;
		exception
			when no_data_found then
				insert into t_secuencia (key, nextvalue) values (p_key, p_numero);
				select nextvalue into v_contador from t_secuencia where key = p_key;
                commit;
                return v_contador;
                
	end f_secuencia;
    
    /*
      Registra pedidos sugeridos sin duplicar cabeceras confirmadas para la
      misma compañía, PDV y fecha de visita. Un reenvío conserva el primer
      pedido confirmado y no altera sus líneas.
    */
    PROCEDURE SP_REGISTRARPEDIDOSUGERIDO (P_DATOS CLOB DEFAULT null, p_id number ) AS
        l_datos         CLOB;
        v_id_pedido     NUMBER;
        v_usuario       VARCHAR2(20);
        v_compania      VARCHAR2(5);
        v_insertado     BOOLEAN;
    BEGIN
       
        -- Obtener el JSON
        IF LENGTH(NVL(P_DATOS, '*')) < 10 AND p_id > 0 THEN
            SELECT archivo INTO l_datos
            FROM data.t_mvzm_sincronizacionjson
            WHERE id = p_id;
        ELSE
            l_datos := P_DATOS;
        END IF;
    
        IF LENGTH(l_datos) > 10 THEN
            -- Leer usuario y compañía desde JSON
            SELECT jt.usuario, jt.compania
            INTO v_usuario, v_compania
            FROM JSON_TABLE(l_datos, '$'
                COLUMNS (
                    usuario   VARCHAR2(20) PATH '$.usuario',
                    compania  VARCHAR2(5) PATH '$.compania'
                )
            ) jt;
            FOR pedido IN (
                SELECT p.codigopdv,
                       TO_DATE(p.fecha_visita, 'DD/MM/YYYY') AS fechavisita,
                       p.observaciones,
                       CASE WHEN p.confirmado = 'true' THEN 1 ELSE 0 END AS confirmado,
                       p.detalle_json
                  FROM JSON_TABLE(l_datos, '$.pedidos[*]'
                    COLUMNS (
                        codigopdv     VARCHAR2(100) PATH '$.codigopdv',
                        fecha_visita  VARCHAR2(20) PATH '$.fecha_visita',
                        observaciones VARCHAR2(2500) PATH '$.observaciones',
                        confirmado    VARCHAR2(5) PATH '$.confirmado',
                        detalle_json  CLOB FORMAT JSON PATH '$.pedido_sugerido'
                    )
                ) p
            ) LOOP
                v_insertado := FALSE;
                BEGIN
                    SELECT id_pedido
                      INTO v_id_pedido
                      FROM data.t_trad_pedidosugerido
                     WHERE compania = v_compania
                       AND codigopdv = pedido.codigopdv
                       AND fechavisita = pedido.fechavisita
                       AND confirmado = 1
                     FOR UPDATE;
                EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                        BEGIN
                            v_id_pedido := f_secuencia('T_TRAD_PEDIDOSUGERIDO', 1);
                            INSERT INTO data.t_trad_pedidosugerido
                                (id_pedido, codigopdv, fechavisita, usuario, compania,
                                 observaciones, confirmado, fechacreacion)
                            VALUES
                                (v_id_pedido, pedido.codigopdv, pedido.fechavisita, v_usuario,
                                 v_compania, pedido.observaciones, pedido.confirmado, SYSDATE);
                            v_insertado := TRUE;
                        EXCEPTION
                            WHEN DUP_VAL_ON_INDEX THEN
                                -- Otro proceso confirmó el mismo PDV/día durante este reenvío.
                                v_insertado := FALSE;
                        END;
                END;

                IF v_insertado THEN
                    INSERT INTO data.t_trad_pedidosugeridodet
                        (id_detalle, id_pedido, codigoproducto, producto, codigobarra,
                         inventario, cantidadsugerida, cantidadpedido, justificacion)
                    SELECT data.pk_commons.f_secuencia('T_TRAD_PEDIDOSUGERIDODET'),
                           v_id_pedido, d.sku, d.descripcion, d.codigobarra,
                           d.inventario, d.cantidad_sugerida, d.cantidad_a_pedir, d.justificacion
                      FROM JSON_TABLE(pedido.detalle_json, '$[*]'
                        COLUMNS (
                            sku               VARCHAR2(50) PATH '$.sku',
                            descripcion       VARCHAR2(250) PATH '$.descripcion',
                            codigobarra       VARCHAR2(250) PATH '$.codigobarra',
                            cantidad_sugerida NUMBER PATH '$.cantidad_sugerida',
                            inventario        NUMBER PATH '$.inventario',
                            cantidad_a_pedir  NUMBER PATH '$.cantidad_a_pedir',
                            justificacion     VARCHAR2(500) PATH '$.justificacion'
                        )
                    ) d;
                END IF;
            END LOOP;
            -- Éxito
            data.PK_TRAD_MOVILMELLA.SP_actualizarJson ( p_id => p_id, p_estado => 1, p_mensaje => 'OK' ) ;		
        ELSE
            data.PK_TRAD_MOVILMELLA.SP_actualizarJson ( p_id => p_id, p_estado => 1, p_mensaje => 'ERROR: El JSON está vacío o es inválido.' ) ;		
        END IF;
    
    EXCEPTION WHEN OTHERS THEN
        data.PK_TRAD_MOVILMELLA.SP_actualizarJson ( p_id => p_id, p_estado => 1, p_mensaje => 'ERROR: ' || SQLERRM ) ;		 
    END SP_REGISTRARPEDIDOSUGERIDO;
    
    /*Procedimiento para grabar el sellout diario de los pedidos sugeridos por día parametrizados*/
    PROCEDURE SP_VENTASPEDIDO AS 
        v_dias number;
    BEGIN
        select valor into v_dias from data.t_corp_udc where id_cabecera like 'TRAD_PARAM' and id_tabla = 10 ;
        
        MERGE INTO data.t_trad_pedidosugeridodet f
        USING ( select s.id_pedido, s.codigopdv, d.codigoproducto, d.codigobarra, v.total_venta, v.fecha  
                from data.t_trad_pedidosugerido s
                    inner join data.t_trad_pedidosugeridodet d on ( s.id_pedido = d.id_pedido )
                    inner join ( SELECT v.compania, v.codigopdv, v.numero, v.codigobarra, 
                                    SUM(v.valorventa) AS total_venta, max(v.fecha) fecha
                                FROM data.mvt_trad_sellout v
                                WHERE v.fecha >= trunc(sysdate,'MM')
                                GROUP BY v.compania, v.codigopdv, v.numero, v.codigobarra ) v
                        on ( s.compania = v.compania and s.codigopdv = v.codigopdv||'-'||v.numero and d.codigobarra = v.codigobarra )
                where s.fechavisita >= trunc(sysdate)-v_dias   ) v
        ON (f.id_pedido = v.id_pedido and f.codigobarra = v.codigobarra and f.codigoproducto = v.codigoproducto )
        WHEN MATCHED THEN
          UPDATE SET sellout = v.total_venta, fechasellout = v.fecha ;
        commit;
    END SP_VENTASPEDIDO;

    /* Mantiene TRA_PESU usando codigo de barras para validar y codigo de producto para persistir. */
    procedure sp_guardarproductosugerido(
      p_id in out number, p_compania varchar2, p_codigobarra varchar2,
      p_codigoproducto varchar2, p_activo varchar2
    ) as
      l_id number := p_id;
      l_compania varchar2(5) := p_compania;
      l_codigobarra varchar2(50) := p_codigobarra;
      l_codigoproducto varchar2(50) := p_codigoproducto;
      l_activo varchar2(1) := nvl(p_activo, '1');
      l_ub number;
      l_producto number;
      l_duplicado number;
    begin
      select count(*) into l_producto from data.vt_gzm_producto p
       where p.compania=l_compania and p.codigobarra=l_codigobarra and p.codigoproducto=l_codigoproducto;
      if l_producto=0 then raise_application_error(-20001,'El producto no corresponde al código de barras de la compañía.'); end if;
      l_ub := data.pk_vtas_pedidos.f_cantidadpresentacion(l_codigoproducto);
      if l_id is null then
        select count(*) into l_duplicado from data.t_corp_udc u
         where u.id_cabecera='TRA_PESU' and u.codigocompania=l_compania and u.id_tabla=l_codigoproducto;
        if l_duplicado>0 then raise_application_error(-20002,'El producto ya está registrado como sugerido.'); end if;
        l_id:=data.pk_commons.f_secuencia('T_CORP_UDC');
        insert into data.t_corp_udc(id,id_cabecera,id_tabla,descripcion,activo,codigocompania,valor2)
        values(l_id,'TRA_PESU',l_codigoproducto,'Producto sugerido APP 132',l_activo,l_compania,to_char(l_ub));
      else
        update data.t_corp_udc set id_tabla=l_codigoproducto,activo=l_activo,valor2=to_char(l_ub)
         where id=l_id and id_cabecera='TRA_PESU' and codigocompania=l_compania;
        if sql%rowcount=0 then raise_application_error(-20003,'No existe el producto sugerido que se intenta modificar.'); end if;
      end if;
      p_id := l_id;
    end sp_guardarproductosugerido;

    /* Elimina exclusivamente un registro TRA_PESU de la compañía activa. */
    procedure sp_eliminarproductosugerido(p_id number, p_compania varchar2) as
    begin
      delete from data.t_corp_udc where id=p_id and id_cabecera='TRA_PESU' and codigocompania=p_compania;
      if sql%rowcount=0 then raise_application_error(-20004,'No existe el producto sugerido que se intenta eliminar.'); end if;
    end sp_eliminarproductosugerido;
END PK_TRAD_PEDIDOS;
/
