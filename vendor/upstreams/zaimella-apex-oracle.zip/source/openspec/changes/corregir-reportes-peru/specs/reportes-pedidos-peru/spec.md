## ADDED Requirements

### Requirement: Resumen de cliente y línea de negocio para Perú

El reporte de la página 303 para la compañía `00003` MUST mostrar Cantidad Bu Ca sin decimales y Subtotal con dos decimales, visible en el reporte predeterminado.

#### Scenario: Consulta del resumen Perú

- **WHEN** un usuario autorizado consulta Cliente y Línea de Negocio
- **THEN** Cantidad Bu Ca se presenta como entero y Subtotal se incluye con dos decimales.

### Requirement: Tracking coherente con SAP

El Tracking de la página 309 para la compañía `00003` MUST marcar Facturado cuando la consulta resuelva una factura SAP activa asociada al pedido y MUST expresar Cantidad Bu Ca Pedido usando el factor de presentación aplicable.

#### Scenario: Pedido con factura SAP

- **WHEN** existe una factura SAP activa relacionada directa o indirectamente con el pedido
- **THEN** Facturado se presenta como Sí.

#### Scenario: Comparación de cantidades

- **WHEN** se visualiza un pedido con presentación mayor a uno
- **THEN** Cantidad Bu Ca Pedido refleja la cantidad SAP convertida a bulto/caja.

### Requirement: Trazabilidad de líneas inactivas

Las líneas inactivas mostradas en Con novedades MUST poder contrastarse con la orden SAP sin asumir que fueron facturadas.

#### Scenario: Línea inactiva excluida

- **WHEN** una línea local tiene estado inactivo
- **THEN** el análisis de trazabilidad verifica si la línea existe en SAP antes de afirmar que fue enviada o facturada.
