## Why

Los reportes de pedidos de Peru presentan cantidades y estados de facturacion inconsistentes, lo que dificulta el control operativo. La revision del pedido 12728 tambien requiere dejar evidencia verificable de que una linea inactiva no llegue a SAP ni a facturacion.

## What Changes

- Mostrar la cantidad de bultos/cajas sin decimales y el subtotal visible por defecto con dos decimales en el reporte Cliente y Linea de Negocio.
- Corregir el indicador Facturado y la conversion de Cantidad Bu Ca Pedido del Tracking.
- Verificar y proteger la trazabilidad de lineas inactivas mostradas en Con novedades.

## Capabilities

### New Capabilities

- `reportes-pedidos-peru`: Presentacion y trazabilidad consistente de pedidos SAP en los reportes de Ventas.

### Modified Capabilities

- Ninguna.

## Impact

- APEX 114, paginas 303 y 309.
- Vista `DATA.VT_VTAS_PEDIDOS_TRACKING_PE` y validacion de `DATA.VT_VTAS_PEDIDOS_INACTIVOS_PE`.
- SAP Peru por `@HANA_PE`; Ecuador queda fuera de alcance.
