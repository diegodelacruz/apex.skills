# corregir-reportes-peru

Corregir formatos, facturacion, conversion de cantidades y trazabilidad de lineas canceladas en reportes de ventas Peru.
