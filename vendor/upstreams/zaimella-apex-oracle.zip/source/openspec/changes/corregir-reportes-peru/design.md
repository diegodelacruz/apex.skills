## Context

Las páginas 303 y 309 consumen fuentes separadas para Peru. El Tracking usa `VT_VTAS_PEDIDOS_TRACKING_PE`: su indicador de facturación está fijo en cero y su cantidad SAP omite el factor de presentación. En 303, el reporte Perú ya calcula el subtotal correcto pero no lo muestra por defecto.

## Goals / Non-Goals

**Goals:**

- Mostrar cantidades de bulto/caja como enteros y subtotal con dos decimales en el resumen Perú.
- Derivar Facturado desde la factura SAP encontrada por el Tracking.
- Convertir Cantidad Bu Ca Pedido con el factor de presentación de la línea local correspondiente.
- Mantener evidencia de que las líneas inactivas no se enviaron al pedido SAP.

**Non-Goals:**

- No cambiar datos transaccionales históricos, documentos SAP ni la lógica de Ecuador.
- No crear una nueva asignación de clientes o ejecutivos.

## Decisions

- Ajustar el formato y columnas por defecto en la definición APEX de la región Perú de 303; evita afectar la región equivalente de Ecuador.
- Calcular el indicador Facturado en el SQL de Tracking con la factura real ya resuelta por su CTE, en vez de usar el campo fijo de la vista.
- Aplicar en la vista Perú el factor de presentación por pedido/producto para la cantidad SAP. Los importes se preservan porque ya coinciden con `LineTotal` de SAP.
- No cambiar el flujo de envío por el caso 12728: la evidencia muestra que la línea inactiva no llegó a SAP y el pedido no fue facturado.

## Risks / Trade-offs

- [Producto repetido en un pedido] → el factor se agrupa por pedido y producto; se validarán muestras con líneas repetidas antes de QA.
- [Factura emitida vía entrega] → se conserva la resolución actual de facturas directas y por entrega, usando su resultado para el indicador.
- [Diferencias TEST/PROD] → se exportará y reconciliará cada destino antes del pase.

## Migration Plan

1. Importar páginas y vista en TEST desde el mismo commit candidato.
2. Validar cantidades, subtotal e indicador con muestras SAP.
3. Ejecutar QA independiente sobre 303 y 309.
4. Con autorización expresa, respaldar e importar el mismo candidato en producción.

## Open Questions

- Ninguna: la evidencia del pedido 12728 descarta una facturación de su línea inactiva.
