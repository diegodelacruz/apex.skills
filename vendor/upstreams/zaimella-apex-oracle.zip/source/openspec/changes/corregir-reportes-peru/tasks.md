## 1. Implementación

- [ ] 1.1 Ajustar formatos y columnas predeterminadas de 303 para Perú.
- [ ] 1.2 Corregir el indicador Facturado en 309.
- [ ] 1.3 Corregir la conversión de Cantidad Bu Ca Pedido en la vista Perú.
- [ ] 1.4 Registrar la validación del pedido 12728 sin alterar datos históricos.

## 2. Validación

- [ ] 2.1 Validar fuentes y objetos en TEST.
- [ ] 2.2 Importar páginas en TEST desde el candidato.
- [ ] 2.3 Ejecutar QA independiente y documentar evidencias.
