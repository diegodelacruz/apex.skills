# Preparacion De Ambiente - aws-etl-experto

Usar este prompt antes de ejecutar tareas AWS ETL con el skill `aws-etl-experto`.

## Repositorio Descargado

Este prompt se ejecuta desde un contexto donde el usuario ya descargo o clono el repositorio de skills y tiene disponibles:

```text
skill/
prompts/
```

La fuente local del skill es:

```text
skill/aws-etl-experto/
```

## Instalar O Actualizar El Skill

- Preparar el ambiente incluye instalar o actualizar el skill `aws-etl-experto`.
- Si el skill no esta instalado, instalarlo desde `skill/aws-etl-experto/` del repositorio descargado en la instalacion activa de Codex.
- Si el skill ya existe, validar que la instalacion activa corresponde a la fuente vigente de `skill/aws-etl-experto/` del repositorio descargado; si no coincide, actualizarla antes de continuar.
- No reemplazar este skill con instrucciones improvisadas ni con prompts copiados al proyecto.

## Requisitos Previos

- Confirmar AWS CLI instalado y accesible.
- Confirmar perfil operativo SSO:

```text
AWSAdministratorAccess-402709932444
```

- Confirmar region operativa:

```text
us-east-1
```

- Confirmar que no se guardaran credenciales, tokens, perfiles personales, salidas sensibles ni datos de negocio innecesarios en el repositorio.
- Confirmar que Python o un parser JSON local esta disponible para inspeccionar salidas AWS CLI cuando aplique.
- Si el trabajo depende de documentacion externa vigente, confirmar Context7.
- Si el cambio es mediano, grande, multi-job, productivo planificado o ambiguo, confirmar OpenSpec y usar `openspec/` en el proyecto objetivo.

## Gate SSO Obligatorio

Antes de cualquier validacion real de Glue, Athena, S3, Glue Catalog, STS, bitacora o ejecucion de jobs:

```powershell
aws sts get-caller-identity --profile AWSAdministratorAccess-402709932444
```

Si el SSO esta vencido o no autenticado, intentar una sola vez:

```powershell
aws sso login --profile AWSAdministratorAccess-402709932444
aws sts get-caller-identity --profile AWSAdministratorAccess-402709932444
```

Si no se confirma identidad despues del login, detener la tarea y pedir al usuario completar SSO. No continuar como analisis preliminar cuando la solicitud requiere evidencia AWS en vivo.

## Estructura Operativa Del Proyecto

Esta seccion describe las entradas esperadas. El orquestador AWS prepara la estructura, contratos y bitacora; este skill no crea ni reordena carpetas.

Preparar o confirmar:

```text
docs/bitacora.md
TMP/
JOB/
glue_jobs/manifests/
glue_jobs/scripts/
docs/operacion/
```

Reglas:

- `docs/bitacora.md` es la bitacora operativa unica.
- `TMP/` es temporal y no puede ser destino final de tablas, particiones ni evidencias de cierre.
- `JOB/` debe contener scripts Glue descargados desde su `ScriptLocation` real antes de editar.
- No dejar `create_*`, `update_*`, `tmp_*` ni manifiestos sueltos en la raiz si existe ruta funcional.

## Validaciones Iniciales Recomendadas

Segun el caso, preparar:

```powershell
aws glue get-job --job-name <job> --profile AWSAdministratorAccess-402709932444 --output json
aws s3 ls s3://<bucket>/<ruta>/ --profile AWSAdministratorAccess-402709932444
aws athena start-query-execution --profile AWSAdministratorAccess-402709932444
```

En PowerShell, no pasar JSON inline complejo a AWS CLI; generar archivo JSON UTF-8 sin BOM y usar `--cli-input-json file://...`.

## Resultado Esperado

Antes de usar `aws-etl-experto`, el contexto debe tener:

- SSO valido o bloqueo al usuario;
- estructura operativa preparada;
- bitacora operativa lista;
- perfil, region y alcance AWS confirmados;
- politica de no publicar secretos ni salidas sensibles clara.
