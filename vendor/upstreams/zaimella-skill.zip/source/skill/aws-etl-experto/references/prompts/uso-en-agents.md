# Prompt De Uso - aws-etl-experto

Usar este prompt en proyectos o contextos con jobs Glue, tablas DWH/Athena, Glue Catalog, rutas S3, procesos ETL AWS, backfills, promociones TEST->PROD o workflows de publicacion/extraccion.

## Seccion 1 - Contenido Para AGENTS.md

Copiar o fusionar este bloque en el `AGENTS.md` del proyecto/contexto:

```markdown
# Uso Obligatorio De aws-etl-experto

Usar el skill `aws-etl-experto` para crear, modificar, corregir, refactorizar, validar o publicar jobs Glue; crear o diagnosticar tablas Athena/Glue Catalog; cambiar rutas S3, particiones o metadata; ejecutar backfills; reparar particiones; diagnosticar jobs fallidos; migrar logica legacy; y validar cierres Glue/Athena/S3.

## Fuente De Verdad

- `aws-etl-experto` es la fuente normativa para AWS ETL.
- No copiar reglas tecnicas extensas en este `AGENTS.md`; leerlas desde `skill/aws-etl-experto/SKILL.md` y sus `references/`.
- Todo cierre, excepcion o bloqueo debe respetar los gates del skill.

## Bitacora Operativa

Usar `docs/bitacora.md` como bitacora operativa unica para inicio, avance, bloqueos, validaciones, evidencias y cierre.

## Regla SSO

Si una tarea requiere evidencia AWS real y el SSO AWS no esta validado, el trabajo queda bloqueado hasta autenticar. No declarar cierres operativos sin SSO valido.
```

## Seccion 2 - Preparacion De Arquitectura Y Ambiente

### 1. Instalar O Actualizar El Skill

Confirmar repositorio descargado con:

```text
skill/aws-etl-experto/
```

Instalar o actualizar `aws-etl-experto` desde `skill/aws-etl-experto/` en la instalacion activa de Codex.

### 2. Verificar Contexto Operativo

El orquestador AWS prepara la arquitectura, contratos, bitacora y rutas. El skill valida los insumos y devuelve resultados; no crea ni administra la estructura operativa.

Crear o validar:

```text
docs/bitacora.md
docs/operacion/
TMP/
JOB/
glue_jobs/manifests/
glue_jobs/scripts/
```

`TMP/` es temporal. `JOB/` contiene scripts Glue descargados desde `ScriptLocation` real. No dejar manifiestos ni temporales sueltos en la raiz.

### 3. Validar AWS Y SSO

Ejecutar:

```text
skill/aws-etl-experto/references/prompts/preparacion-ambiente.md
```

No continuar con Glue, Athena, S3, Catalog, bitacora o ejecucion de jobs sin SSO confirmado.

### 4. Inicializar Tarea AWS

Registrar en `docs/bitacora.md`:

- tarea;
- ambiente;
- job/tabla/ruta;
- perfil AWS;
- fuente oficial;
- legacy revisado si aplica;
- evidencia esperada.

### 5. Entrega De Preparacion

Informar:

- skill instalado/actualizado;
- SSO validado o bloqueo;
- estructura preparada;
- bitacora inicial registrada;
- job, tabla o ruta objetivo identificada.
