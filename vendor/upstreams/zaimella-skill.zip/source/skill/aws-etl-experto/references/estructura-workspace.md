# Responsabilidades de ubicaciones AWS

> El orquestador AWS crea y gobierna la estructura de trabajo. Esta referencia no autoriza al skill a crear, reorganizar o asumir carpetas; describe unicamente que tipo de fuente, evidencia o salida debe recibir o devolver en las ubicaciones entregadas.

Esta estructura organiza el trabajo técnico en el proyecto destino. No se crea toda de forma automática: crear solo las carpetas necesarias para la tarea autorizada y conservar las convenciones locales existentes.

```text
<PROJECT_ROOT>/
├─ AGENTS.md                         # Reglas locales y coordinación
├─ docs/
│  ├─ bitacora.md                    # Estado operativo único por defecto
│  ├─ operacion/                     # Evidencias, reportes y manifests de cierre
│  └─ arquitectura/                  # Documentación local si no vive en otro repo
├─ JOB/                              # Copia de scripts Glue descargados desde ScriptLocation
├─ glue_jobs/
│  ├─ manifests/                     # JSON create/update, snapshots get-job y DDL controlados
│  ├─ scripts/                       # Automatizaciones reutilizables del proyecto
│  └─ sql/                           # DDL y consultas Athena versionables
├─ openspec/
│  └─ changes/<id-cambio>/           # Especificaciones para cambios que lo requieran
└─ TMP/                              # Archivos efímeros no versionables
```

## Responsabilidad por carpeta

| Ruta | Contenido permitido | Regla principal |
| --- | --- | --- |
| `JOB/` | Script activo descargado y su evidencia de origen. | Nombrar o registrar el job y `ScriptLocation`; no usar copias ambiguas como fuente. |
| `glue_jobs/manifests/` | Snapshots `get-job`, entradas `update-job`, DDL y manifests de creación. | JSON UTF-8 sin BOM; conservar el snapshot previo antes de modificar configuración. |
| `glue_jobs/scripts/` | Automatizaciones estables y reutilizables del proyecto. | No guardar scripts de un único ensayo ni secretos. |
| `glue_jobs/sql/` | SQL de Athena, Glue o validaciones repetibles. | Incluir propósito, parámetros esperados y motor de ejecución. |
| `docs/bitacora.md` | Tareas, estado, avance y resultado. | Actualizar al inicio, cambios de estado y cierre. |
| `docs/operacion/` | Evidencia de soporte, reportes de validación y planes de remediación. | No sustituye la bitácora y no almacenar datos sensibles. |
| `docs/arquitectura/` | Arquitectura local, si el proyecto no usa un repositorio dedicado. | Crear y actualizar gradualmente solo los documentos afectados por trabajo autorizado; documentar únicamente hechos verificables. |
| `openspec/changes/` | Especificaciones de cambios de riesgo o alcance relevante. | No reemplaza la evidencia ni los gates operativos. |
| `TMP/` | Descargas, JSON intermedios, resultados locales y artefactos efímeros. | Nunca es ruta final de datos, catálogo, bitácora ni evidencia de cierre. |

## Ciclo de trabajo

1. Registrar la tarea en `docs/bitacora.md` o la ruta local equivalente.
2. Guardar evidencia temporal en `TMP/`; promover solo evidencia útil y no sensible a `docs/operacion/`.
3. Descargar el script vigente desde S3 a `JOB/` y guardar configuraciones o manifests en `glue_jobs/manifests/`.
4. Mantener SQL y automatizaciones reutilizables fuera de la raíz, en sus carpetas estables.
5. Aplicar el gate de cierre, actualizar la bitácora y limpiar solo temporales propios de la tarea cuando sea seguro.

## Documentación progresiva

Si el proyecto no tiene un repositorio de arquitectura dedicado, el skill crea en `docs/arquitectura/` únicamente el documento necesario para el alcance autorizado y lo actualiza cuando cambie la información que describe. Ejemplos: un catálogo al crear o modificar una tabla, una ficha de jobs al cambiar un job, o una decisión al aprobar una alternativa arquitectónica.

No se crean documentos vacíos ni se completa documentación con supuestos. Un trabajo sin impacto arquitectónico no exige actualizar esta carpeta.

## Control de versionado

- Versionar scripts, SQL, manifests estables y documentación solicitada cuando el repositorio del proyecto lo permita.
- No versionar secretos, perfiles AWS, tokens, exports completos, resultados con datos de negocio, cachés ni contenido de `TMP/`.
- Si existe un repositorio separado de arquitectura, no mezclar sus cambios con el repositorio de implementación ETL.
