# Estandar AWS ETL

Este estandar es reutilizable. Los valores concretos de cuentas, perfiles, regiones, buckets, rutas, bases, conexiones, nombres de tablas, convenciones de job, ventanas, repositorios y fuentes pertenecen al proyecto destino.

## Contexto obligatorio

Antes de operar, leer las instrucciones y configuracion locales para identificar:

- perfil y region AWS;
- buckets y prefijos S3 por ambiente;
- bases, tablas y conexiones Glue;
- utilitarios, parametros y convencion de nombres;
- fuente y formato de la bitacora;
- ruta de documentacion de arquitectura y ventana operativa.

No inferir ni reutilizar estos valores desde otro proyecto. Si falta un valor que impide una accion real, pedirlo o registrar el bloqueo.

Para crear, ordenar o auditar carpetas de trabajo, aplicar `estructura-workspace.md`.

## Modelado, catalogo y legacy

- Separar extraccion (datos crudos o minimamente estandarizados) de publicacion (modelos finales consumibles).
- Usar nombres en `snake_case`, minusculas y sin tildes. El proyecto define sus prefijos de tablas, vistas y datamarts.
- Toda tabla, vista, datamart o tabla externa creada o modificada debe tener un comentario funcional en cada columna y particion. No usar comentarios vacios ni genéricos.
- Si una vista requiere actualizar metadata de Glue, preservar `ViewOriginalText`, `ViewExpandedText`, `TableType`, parametros, particiones y `StorageDescriptor`.
- Legacy solo puede leerse como referencia de reglas funcionales. No modificarlo ni usarlo como nueva fuente oficial o destino; reimplementar la logica bajo el estandar vigente.
- Declarar la fuente oficial de carga, cualquier legacy consultado y la evidencia de validacion.

## Tipos, llaves y particiones

- Preservar el tipo y formato funcional. Un codigo `string` con ceros a la izquierda no se convierte a numero.
- `fecha` y `fecha_*` deben ser `date` salvo necesidad funcional documentada de conservar hora; solo entonces usar `timestamp`.
- Un `id_*`, `codigo_*` o `tipo_*` funcionalmente entero debe publicarse como `int` o `bigint`, no como `double`, `float` o `decimal`.
- Antes de concatenar un numero entero con texto, normalizarlo y luego convertirlo a texto: `CAST(CAST(ROUND(campo, 0) AS BIGINT) AS STRING)`.
- Validar que las llaves funcionalmente enteras no tengan decimales visibles como `.0` o `.000`.
- Definir las particiones por volumen y patrones de consulta, no solo por disponibilidad de columnas. Si hay codigo funcional y particion equivalente, validar que coincidan.

## Jobs Glue

El proyecto define el patron de nombres. Todo job nuevo debe declarar ambiente, dominio, etapa, tabla y alcance de manera consistente.

Estructura minima, en este orden:

1. `CONFIGURACION`
2. `INIT`
3. `LECTURA`
4. `TRANSFORMACION`
5. `VALIDACION`
6. `PARTICIONES`
7. `ESCRITURA`
8. `CIERRE OK`
9. `CIERRE ERROR`

Separar los bloques con `# ==========================================================`.

- Usar los utilitarios de parametros, rutas y bitacora definidos por el proyecto.
- Para escritura particionada, configurar `spark.sql.sources.partitionOverwriteMode = dynamic` cuando corresponda.
- Leer solo las columnas necesarias, preferir pushdown real cuando aplique y evitar `count()` pesado en extraccion.
- En publicacion, no escribir una salida vacia salvo que el requerimiento la espere explícitamente.
- Usar Parquet con compresion y modo de escritura definidos por el proyecto; no hardcodear rutas si existe un utilitario para resolverlas.
- Todo job creado o modificado debe ejecutarse tras publicar el script, salvo que el usuario solo haya autorizado un analisis o revision local.

## Configuracion y conexiones

Antes de ejecutar, relanzar, diagnosticar o actualizar un job, obtener `aws glue get-job --job-name <job> --output json` y verificar:

- `Command.ScriptLocation` vigente;
- argumentos funcionales, `--extra-py-files` y `--TempDir` cuando apliquen;
- `Timeout`, `GlueVersion`, tipo y cantidad de workers, `Role` y reintentos;
- `Connections.Connections` frente a las fuentes reales usadas por el script.

Para JDBC, el proyecto debe declarar el parametro de conexion, el lector controlado y la conexion Glue requerida. Si hay varias fuentes, validar todas las conexiones. No atribuir fallas de red, listener, VPN o JDBC al origen sin comparar antes la configuracion con un job funcional que lea la misma fuente.

## Operacion segura con AWS CLI

- Para argumentos con guiones, analizar el JSON completo localmente en vez de depender de JMESPath fragil.
- Guardar `get-job` en `TMP/` si es temporal o en `glue_jobs/manifests/` si es evidencia operativa.
- En PowerShell, no pasar JSON inline a AWS CLI. Crear un archivo JSON validado y usar `--cli-input-json file://<ruta>`.
- Escribir JSON en UTF-8 sin BOM. En Windows PowerShell 5.1 usar `[System.IO.File]::WriteAllText($path, $json, (New-Object System.Text.UTF8Encoding($false)))`; validar que no inicie con `EF BB BF`.
- Antes de `update-job`, conservar la configuracion completa. Generar `JobUpdate` desde ella y modificar solo los campos autorizados.
- Tras un `update-job`, comparar contra la copia previa y confirmar que se conservaron argumentos, conexiones, `Command`, `Role`, version Glue, workers y reintentos.
- Si un cambio de configuracion causa errores de importacion, revisar primero la perdida de `--extra-py-files` o librerias antes de tocar el script.

## Backfill

El timeout normal y el temporal los define el proyecto. Para un backfill:

1. Registrar rango y motivo.
2. Si se requiere ampliar el timeout, actualizarlo desde la configuracion vigente sin perder campos operativos.
3. Ejecutar y validar catalogo, S3, Athena, datos y particiones.
4. Restaurar la configuracion temporal al valor normal.
5. Confirmar con `get-job` la restauracion y la preservacion de argumentos y conexiones.

No cerrar un backfill mientras la configuracion temporal siga activa o falte evidencia de restauracion.

## Gate de cierre

Un estado `SUCCEEDED` no es cierre suficiente. Para una creacion, cambio, publicacion, promocion o reproceso autorizado, validar:

- ejecucion posterior al cambio dentro de la ventana o excepcion aprobada;
- `StorageDescriptor.Location` y particiones hacia rutas S3 vigentes, nunca temporales;
- presencia de objetos en la ruta esperada;
- cobertura de particiones derivada primero desde S3 y comparada contra Glue Catalog;
- registro de particiones faltantes por API o mantenimiento controlado; no usar `MSCK REPAIR TABLE` como rutina manual recurrente en produccion;
- lectura simple y conteo en Athena;
- datos presentes salvo resultado cero esperado;
- lectura de todas las particiones esperadas, no solo las ya registradas;
- comentarios funcionales completos en Glue Catalog;
- evidencia y estado en la bitacora operativa.

Si falla una validacion, el estado es `EN_PROGRESO` o `BLOQUEADO`. Corregir y repetir el ciclo solo cuando el usuario haya autorizado cambios; en un diagnostico, entregar la evidencia y el plan de remediacion.

## TEST a PROD

1. Verificar la tabla destino; no recrearla si existe sin autorizacion.
2. Si se toma una definicion desde TEST, copiar columnas, particiones, formato, serde e inputs y ajustar la ruta de PROD.
3. Guardar el manifest tecnico antes de crear o actualizar.
4. Asegurar que exista un job productivo que publique la tabla cuando ese sea el alcance de la promocion.
5. Ejecutar el job y aplicar el gate completo de cierre. Una tabla catalogada sin datos o un job `SUCCEEDED` sin datos no completan la promocion.

## Bitacora y diagnostico

Usar la bitacora operativa definida por el proyecto; por defecto, `docs/bitacora.md`. Registrar fecha, tarea, estado y resultado, al inicio, en cambios de estado y al cierre. Estados: `PENDIENTE`, `EN_PROGRESO`, `BLOQUEADO`, `COMPLETADO`.

Cuando un job falla, consultar primero el origen de bitacora configurado (CloudWatch, S3 o Athena), localizar la ejecucion exacta y usar la evidencia más reciente antes de proponer cambios. Si la bitacora usa Partition Projection, no ejecutar `MSCK REPAIR TABLE` sobre ella.

## Documentacion de arquitectura

El proyecto o el usuario debe identificar el repositorio oficial. Antes de editar, inspeccionar sus instrucciones, actualizar la copia local de forma no destructiva y revisar el estado Git. Documentar solo hechos respaldados por evidencia reproducible de Glue, jobs, S3, Athena, bitacora o scripts vigentes. No publicar secretos ni datos de negocio innecesarios.

Por defecto, documentar no implica commit ni push. Solo publicar cuando el usuario lo solicite, dentro del repositorio de arquitectura y reportando branch, commit, archivos y validaciones.
