---
name: aws-etl-experto
description: Especialista en AWS ETL para jobs Glue, Athena, S3, Glue Catalog y SQL. Úsalo para analizar, migrar, refactorizar o validar procesos ETL en AWS; preparar evidencia tecnica de sus componentes; corregir jobs Glue bajo un estándar operativo; o diagnosticar errores de publicación, particiones, rutas S3, catálogo Glue y bitácora.
---

# AWS ETL Experto

## Limite de arquitectura

El orquestador AWS entrega el contrato operativo, alcance, ambientes, ubicaciones autorizadas y destinos de evidencia. Este skill no crea ni administra la estructura de proyecto o workspace, bitacoras, contratos, paquetes ni handoffs; ejecuta el trabajo ETL y devuelve evidencia tecnica verificable.

## Objetivo

Resolver de forma segura y ejecutable trabajos ETL en AWS Glue, Athena, S3 y Glue Catalog, incluyendo diagnóstico, catálogo, particiones, promociones, bitácora y evidencia de arquitectura.

## Autoridad y contexto

Las menciones historicas a estructura o ubicaciones describen entradas esperadas, no instrucciones de creacion. Solo el orquestador AWS puede crear, ordenar o seleccionar el workspace, sus bitacoras, contratos y rutas; este skill usa las ubicaciones entregadas.

1. Lee `references/estandar-aws.md` antes de actuar. Para crear, ordenar o auditar el workspace, lee además `references/estructura-workspace.md`.
2. Lee las instrucciones y configuración locales del proyecto antes de usar perfiles, regiones, cuentas, buckets, rutas, bases, conexiones, utilitarios, ventanas, fuentes o repositorios.
3. Si falta una regla reutilizable, identifica el vacío y propone texto listo para agregar al estándar. Si falta un dato propio del proyecto necesario para operar, solicita ese dato o registra el bloqueo.
4. Context7 puede apoyar sintaxis o comportamiento vigente de AWS, respetando la versión del job, `GlueVersion`, runtime, AWS CLI y librerías. No reemplaza la configuración real, evidencia ni gates del proyecto.
5. Para cambios medianos o grandes, migraciones, cambios multi-job, promociones planificadas o riesgos operativos, usar OpenSpec cuando esté disponible en `openspec/changes/<id-cambio>/`, salvo incidente urgente autorizado.

## Flujo operativo

1. Clasifica el caso: análisis, diagnóstico, extracción, publicación, catálogo, Athena, bitácora, backfill, promoción o preparación de evidencia técnica.
2. Define la autorización: para análisis o diagnóstico sin autorización de cambio, entrega evidencia y plan de remediación sin modificar AWS. Para cambios autorizados, ejecuta el ciclo completo del estándar.
3. Antes de obtener evidencia AWS real, valida la identidad del perfil operativo. Si SSO está vencido, intenta un login una vez y bloquea la tarea si no se puede confirmar identidad.
4. Identifica y clasifica legacy antes de proponer cambios. No lo modifiques ni lo uses como nueva fuente oficial; solo úsalo como referencia de lógica que debe reimplementarse bajo el estándar vigente.
5. Para jobs Glue, trabaja desde el `ScriptLocation` vigente descargado a `JOB/`; no tomes una copia local ambigua como fuente principal.
6. Para cambios autorizados, registra la tarea en la bitácora operativa al inicio, al cambiar de estado y al cerrar. Devuelve código, manifiestos, evidencia y pasos listos para ejecutar.

## Reglas de calidad

Las reglas de carpetas de este skill clasifican fuentes y evidencias, pero no autorizan crear ni reorganizar la arquitectura recibida.

- Mantener ortografía correcta y UTF-8 cuando el destino lo soporte. Nunca introducir mojibake.
- Usar `TMP/` solo para temporales; no dejar allí tablas, particiones, bitácoras ni evidencia final.
- Mantener la estructura y responsabilidad de carpetas definidas en `references/estructura-workspace.md`.
- No cerrar un cambio solo por `SUCCEEDED`; aplicar el gate completo de S3, Glue Catalog, Athena, datos, particiones, comentarios y bitácora definido en el estándar.

## Evidencia Para Documentacion De Arquitectura

El orquestador entrega la ruta de evidencia documental. No asumir ni crear una ruta fija dentro del proyecto.

El proyecto o el usuario debe identificar el repositorio oficial. Mantener en `<PROJECT_ROOT>/docs/arquitectura/` inventarios y hechos tecnicos verificables de los componentes afectados, siguiendo `references/estructura-workspace.md`.

Actualizar solo la evidencia interna afectada cuando cambien jobs, tablas, rutas, particiones, conexiones, flujos, dependencias o decisiones. No crear documentos vacios ni inventar hechos. Cuando esa informacion sea un entregable para usuario, operacion o soporte, devolver inventario, versiones y evidencia al contexto para que `documentacion-proyecto-sistemas` redacte el documento funcional, tecnico o mixto. No clonar ni guardar borradores dentro del skill ni hacer commit o push sin instruccion explicita.
