---
name: metodologia-proyectos
description: "Guia el ciclo completo de proyectos tecnologicos de Sistemas Zaimella: descubrimiento, levantamiento de procesos, RI, casos de uso, prototipos, AD, planificacion, seguimiento, cierre y lecciones aprendidas. Usar al iniciar, diagnosticar, estructurar, documentar, asesorar, controlar o cerrar un proyecto; al transformar necesidad, oportunidad o insumos Word, Excel, PDF, HTML/RI de portal, imagenes, videos, audios, entrevistas o demostraciones en una solucion trazable."
---

# Metodologia de Proyectos Zaimella

## Proposito y limites

Conducir un proyecto tecnologico desde una necesidad u oportunidad hasta su cierre, con evidencia, decisiones y trazabilidad. Aplicar solo a proyectos de Sistemas; no inventar procesos, reglas, responsables, datos ni decisiones de negocio.

`levantamiento-procesos` es el especialista para analizar evidencia y reconstruir procesos. Este skill define el metodo del ciclo de vida y transforma sus resultados en documentos, decisiones y seguimiento. Cuando exista `Gestion-Proyectos`, ese comando gobierna contratos, entregables, paquetes, handoffs e integracion; este skill no sustituye su coordinacion. No duplicar scripts ni reglas especificas de otros dominios.

Cuando `levantamiento-procesos` se active desde esta metodología, usar sus técnicas, plantillas y scripts, pero aplicar la arquitectura de [`references/arquitectura_archivos.md`](references/arquitectura_archivos.md). No ejecutar su creador de `PROCESOS/` ni mantener dos expedientes paralelos: mapear fuentes y entregables a `proyecto/00_insumos/` y `proyecto/01_levantamiento/`.

Leer [`references/ciclo_vida_proyecto.md`](references/ciclo_vida_proyecto.md) al iniciar, retomar, cambiar de etapa o cerrar un proyecto.

## Principios obligatorios

- Trabajar desde evidencia: clasificar cada hallazgo como `Observado`, `Confirmado`, `Inferido` o `Pendiente`.
- Levantar primero el proceso actual; el `RI` es la salida formal de ese levantamiento. Contiene el AS-IS, problemas, riesgos, oportunidades, objetivo y alcance de negocio.
- Diseñar después el proceso futuro: el `TO-BE` forma parte del análisis funcional de `AD`, junto con casos de uso y prototipos cuando aporten claridad.
- Mantener trazabilidad de necesidad u oportunidad a proceso, RI, TO-BE, caso de uso, prototipo, AD, plan, entrega y cierre.
- No cerrar una etapa con una definición, decisión, aprobación o dependencia crítica abierta.
- Registrar cada sesión y cambio relevante en la bitácora general y en la bitácora de la etapa afectada.

## Limite de arquitectura

El orquestador de proyectos define y prepara las carpetas, contratos, bitacoras y rutas de cada artefacto. Este skill solo recibe esas ubicaciones, aplica el metodo y devuelve contenido, trazabilidad y controles de calidad; no crea, mueve, renombra ni administra la arquitectura del proyecto.

Usar [`references/arquitectura_archivos.md`](references/arquitectura_archivos.md) como modelo de artefactos y trazabilidad. El orquestador entrega las rutas de insumos, salidas y bitacoras; este skill no crea ni administra carpetas. El diseño funcional usa el AS-IS y el RI para producir TO-BE, casos de uso, prototipos y propuesta antes del AD técnico.

## Inicio y recuperación

1. Confirmar que el caso pertenece a Sistemas, el nombre del proyecto y el objetivo inicial; proponer un nombre temporal si solo hay una idea.
2. Leer [`references/inicio_proyecto.md`](references/inicio_proyecto.md) y validar los insumos, contrato y rutas preparados por el orquestador. Solicitar la fecha de inicio solo cuando se planifiquen fechas.
3. Si el proyecto existe, leer la bitácora transversal, la bitácora de la etapa y los artefactos trazables en las rutas entregadas antes de continuar.
4. Inventariar los insumos con [`references/lectura_insumos.md`](references/lectura_insumos.md) en la ubicación que entregue el orquestador. Conservar los originales sin alterarlos, registrar ubicación, fuente, fecha, alcance y nivel de evidencia, y aplicar la excepción conservadora para proyectos heredados.
5. Cuando haya proceso, operación actual o evidencia sin estructurar, activar `levantamiento-procesos`; leer sus salidas antes de redactar el RI.

## Flujo por etapas

1. **Descubrimiento y levantamiento.** Reunir insumos, actores, sistemas, AS-IS, problemas, riesgos y oportunidades. Leer [`references/etapas/levantamiento/reglas.md`](references/etapas/levantamiento/reglas.md).
2. **RI.** Convertir el levantamiento validado en el requerimiento de negocio. Leer las referencias de `RI`. Si el RI lo entrega el cliente, preservarlo como entrada formal y contrastarlo contra la evidencia, sin reescribirlo silenciosamente.
3. **AD funcional y técnico.** Diseñar el TO-BE, casos de uso, prototipos y definición técnica. Leer [`references/etapas/ad/diseno_funcional.md`](references/etapas/ad/diseno_funcional.md) y las referencias de `AD` aplicables.
4. **Planificación y seguimiento.** Convertir el AD estable en entregables, sprints, paquetes de trabajo, hitos, riesgos, decisiones y control de cambios. Con `Gestion-Proyectos`, conservar la jerarquia `Proyecto -> Entregable -> Sprint -> Paquete -> Tarea interna de dominio` y delegar por orquestador de dominio, nunca por skill tecnico directo. Leer [`references/planificacion.md`](references/planificacion.md) y [`references/seguimiento.md`](references/seguimiento.md).
5. **Cierre.** Validar aceptación, entregas, pendientes transferidos, resultados, archivo de evidencia y lecciones aprendidas. Leer las referencias de cierre.

## Uso de insumos y herramientas

Usar la ruta de lectura indicada en [`references/lectura_insumos.md`](references/lectura_insumos.md) y, cuando existan fuentes relacionadas, aplicar [`references/protocolo_correlacion_insumos.md`](references/protocolo_correlacion_insumos.md). No analizar aisladamente una reunión, audio, Word o Excel que describan el mismo proceso.

- Para Word, usar `documents`; al generar o editar un `.docx`, renderizarlo e inspeccionarlo antes de entregarlo.
- Para Excel, CSV o TSV, usar `spreadsheets`; revisar hojas, valores, fórmulas y visualización antes de usar resultados.
- Para PDF, usar `pdf`; extraer texto y revisar visualmente las páginas relevantes.
- Para HTML guardado o RI exportado de un portal, usar `scripts/extraer_html.py` sin ejecutar JavaScript ni cargar recursos externos y registrar cualquier control o elemento visual no verificable.
- Para imágenes, inspeccionar la evidencia visual y registrar lo observado, sin inferir texto o campos ilegibles.
- Para video y audio, usar `levantamiento-procesos`, sus scripts versionados y su protocolo de transcripción, capturas y sincronización voz-pantalla, remapeando todas las salidas a la arquitectura de este skill.
- Para el uso instalado de `ffmpeg`, `ffprobe` y `faster-whisper`, leer [`references/herramientas_audiovisuales.md`](references/herramientas_audiovisuales.md) y usar el script versionado `scripts/transcribir_audio.py`.

Antes de presentar el levantamiento como completo o convertirlo en RI, ejecutar el gate de [`references/calidad_levantamiento.md`](references/calidad_levantamiento.md). Guardar su resultado en `proyecto/01_levantamiento/auditoria_levantamiento.md`; no ocultar fuentes pendientes, contradicciones, pasos sin evidencia ni subprocesos redundantes.

## Reglas de entrega

- `RI` usa lenguaje de negocio y nunca contiene diseño técnico cerrado.
- `TO-BE`, casos de uso y prototipos describen el comportamiento futuro validable; no sustituyen el AD técnico.
- `AD` convierte lo aprobado en un plan técnico ejecutable y conserva la correspondencia con el alcance y los casos de uso.
- Los prototipos son una herramienta de validación: indicar versión, flujos/casos de uso cubiertos, decisiones validadas y pendientes. No afirmar que un diseño visual constituye aprobación técnica.
- Proponer planificación en consola y guardarla como `.md`; generar Excel solo tras el OK explícito del usuario.
- Ante cambios de alcance, evaluar el impacto en RI, TO-BE, casos de uso, prototipo, AD y planificación antes de ejecutar el cambio.
- Planificar manuales funcionales y documentos tecnicos como entregables del proyecto. `documentacion-proyecto-sistemas` los produce desde una linea base y evidencia aprobadas; la metodologia define proposito, audiencia y aceptacion, pero no pide a QA que sea autor.

## Referencias por necesidad

- Estructura y continuidad: [`references/arquitectura_archivos.md`](references/arquitectura_archivos.md), [`references/ciclo_vida_proyecto.md`](references/ciclo_vida_proyecto.md), [`references/inicio_proyecto.md`](references/inicio_proyecto.md), [`references/metodologia_general.md`](references/metodologia_general.md)
- Evidencia: [`references/lectura_insumos.md`](references/lectura_insumos.md), [`references/protocolo_correlacion_insumos.md`](references/protocolo_correlacion_insumos.md), [`references/herramientas_audiovisuales.md`](references/herramientas_audiovisuales.md), [`references/calidad_levantamiento.md`](references/calidad_levantamiento.md)
- Levantamiento y RI: [`references/etapas/levantamiento/reglas.md`](references/etapas/levantamiento/reglas.md), [`references/etapas/levantamiento/documento_principal.md`](references/etapas/levantamiento/documento_principal.md), [`references/flujo_desde_ri_existente.md`](references/flujo_desde_ri_existente.md), referencias de `RI`
- AD funcional: [`references/etapas/ad/diseno_funcional.md`](references/etapas/ad/diseno_funcional.md); AD técnico: referencias de `AD`
- Control: [`references/planificacion.md`](references/planificacion.md), [`references/seguimiento.md`](references/seguimiento.md)
- Cierre: [`references/etapas/ci/reglas.md`](references/etapas/ci/reglas.md), [`references/etapas/ci/lecciones_aprendidas.md`](references/etapas/ci/lecciones_aprendidas.md)

## Integraciones opcionales

Usar Context7 solo para documentación técnica externa vigente y OpenSpec solo para especificaciones técnicas ejecutables; ninguno reemplaza evidencia, aprobaciones, RI, AD ni documentos finales. Usar ChatGPT o Figma cuando el usuario lo elija o estén disponibles; Codex conserva el análisis, trazabilidad y auditoría de la salida.
