# Arquitectura colaborativa para AD

## Objetivo

Definir una forma de trabajo combinada entre `Codex`, `ChatGPT` y `Figma` para producir `RI`, casos de uso, prototipos y `AD` con mejor calidad, mayor velocidad y control de cierre metodologico.

## Principio base

No asignar a una sola herramienta todo el proceso documental. Separar el trabajo por fortalezas:

- `Codex`: analisis estructural, trazabilidad, extraccion de insumos, control tecnico y auditoria metodologica.
- `ChatGPT`: redaccion, ordenamiento narrativo y mejora de claridad documental.
- `Figma`: consolidacion visual de pantallas, wireframes y prototipos rapidos.

## Distribucion de responsabilidades

### Codex

- Generar o consolidar el `RI` cuando corresponda.
- Analizar insumos de negocio, adjuntos, imagenes y evidencia visual.
- Descomponer el alcance aprobado en puntos trazables.
- Identificar actores, reglas de negocio, procesos, pantallas y componentes tecnicos.
- Preparar los insumos estructurados para casos de uso y `AD`.
- Detectar contradicciones, vacios y bloqueos de cierre.
- Auditar el resultado final antes de aprobar el `AD`.

### ChatGPT

- Redactar casos de uso textuales a partir de insumos estructurados.
- Redactar `Resumen ejecutivo`, `Analisis` y el primer borrador de `Definicion`.
- Mejorar claridad, tono ejecutivo y legibilidad sin inventar definiciones no confirmadas.
- Reescribir contenido manteniendo la trazabilidad tecnica definida por `Codex`.

### Figma

- Convertir ideas de pantalla en wireframes o prototipos rapidos.
- Consolidar pantallas clave y flujos visuales relevantes para el alcance.
- Servir como soporte visual del `AD`, no como sustituto de la definicion tecnica.

## Flujo operativo recomendado

1. `Codex` genera o consolida el `RI`.
2. `Codex` prepara insumos estructurados para la etapa `AD`.
3. `ChatGPT` redacta casos de uso textuales.
4. `ChatGPT` redacta el borrador del `AD` a partir de los insumos validados.
5. `ChatGPT` y `Figma` aterrizan pantallas o prototipos rapidos para los puntos criticos del alcance.
6. `Codex` revisa el `AD`, valida trazabilidad, precision tecnica y cumplimiento metodologico.
7. Si encuentra ambiguedades, texto inventado, huecos tecnicos o mala correspondencia con el alcance, devuelve observaciones y exige correccion antes del cierre.

## Reglas para casos de uso

- Los casos de uso no son obligatoriamente graficos.
- Para esta metodologia se priorizan casos de uso textuales cuando eso mejore velocidad y facilidad de correccion.
- `Codex` debe proponer la lista base de casos de uso a partir del alcance, actores y procesos.
- `ChatGPT` debe redactarlos con formato consistente y lenguaje claro.
- Si existe un flujo especialmente complejo, puede complementarse con apoyo visual en `Figma`, pero el caso de uso textual sigue siendo el artefacto base.

## Reglas para prototipos

- El prototipo debe ser rapido y orientado a alineacion funcional, no a diseno definitivo.
- `Figma` se usa para consolidar las pantallas clave y el flujo principal.
- Si primero se genera una idea visual por prompt en otra herramienta conversacional, esa salida debe tratarse como exploracion y luego consolidarse en `Figma`.
- No cerrar un frente visual del `AD` solo con imagen aislada si el alcance requiere comportamiento, validaciones, componentes o estados de pantalla.

## Regla de control para ChatGPT

`ChatGPT` no debe arrancar desde cero sobre el requerimiento bruto cuando el objetivo sea redactar el `AD`.

Antes de pedirle redaccion, `Codex` debe preparar como minimo:

- alcance descompuesto por puntos
- actores identificados
- reglas de negocio visibles
- pantallas y objetos confirmados
- dependencias
- bloqueos
- matriz de trazabilidad entre necesidad y solucion

## Paquete minimo de trabajo recomendado

Antes de enviar a redaccion externa o conversacional, construir en `proyecto/04_ad/documentos/` o en archivos de apoyo equivalentes:

- `01_ri_base.md`
- `02_insumos_ad.md`
- `03_matriz_trazabilidad.md`
- `04_bloqueos_y_supuestos.md`
- `05_casos_de_uso.md`
- `06_borrador_ad.md`
- `07_revision_ad_codex.md`

Los nombres pueden adaptarse al proyecto, pero la separacion logica debe mantenerse.

## Criterio de cierre

La etapa `AD` solo puede considerarse lista cuando:

- el `RI` o insumo rector ya fue analizado
- los casos de uso estan alineados con el alcance
- los prototipos cubren al menos las pantallas o flujos criticos que requieren apoyo visual
- `ChatGPT` ya redacto el borrador final
- `Codex` audito el documento y no mantiene bloqueos criticos abiertos
