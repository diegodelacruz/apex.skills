# Inicio del proyecto

> Este procedimiento define la informacion y los artefactos iniciales que debe existir. `Gestion-Proyectos` crea la estructura y los archivos desde sus plantillas; `metodologia-proyectos` no crea, mueve ni reorganiza la arquitectura.

## Procedimiento

1. Confirmar que es un proyecto tecnológico de Sistemas e identificar nombre, necesidad u oportunidad.
2. Validar que el orquestador creó la carpeta raíz, el contrato y las ubicaciones de los artefactos metodológicos.
3. Validar que el orquestador entregó las bitácoras transversal y de etapa aplicables.
4. Solicitar al usuario que coloque los originales en `proyecto/00_insumos/` según su tipo y cualquier RI recibido en `proyecto/00_insumos/ri/`. En un proyecto heredado, inventariar también el RI externo que ya se encuentre en `proyecto/02_ri/`, sin moverlo automáticamente. No crear análisis profundo hasta contar con fuentes o información suficiente en la conversación.
5. Entregar al orquestador el inventario de insumos y los datos para registrar: objetivo inicial, etapa activa, fuentes recibidas, responsables conocidos, bloqueos y siguiente acción.
6. Pedir o confirmar fecha de inicio solo antes de crear fechas en `05_planificacion/`.

## Archivos iniciales obligatorios

```text
proyecto/bitacora.md
proyecto/01_levantamiento/bitacora.md
proyecto/01_levantamiento/inventario_insumos.md
proyecto/02_ri/bitacora.md
proyecto/03_diseno_funcional/bitacora.md
proyecto/04_ad/bitacora.md
```

Los archivos finales se generan cuando su etapa cuenta con evidencia y validación suficientes: `02_ri/ri.docx`, artefactos de `03_diseno_funcional/`, `04_ad/ad.docx`, planificación y cierre.
