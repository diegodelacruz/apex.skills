# Gate de calidad del levantamiento

## Propósito

Comprobar que el proceso levantado puede entenderse, reconstruirse y validarse sin depender de la conversación del agente. Ejecutar este gate después de consolidar las fuentes y antes de presentar el levantamiento como completo, cerrar el RI o diseñar el TO-BE.

Guardar el resultado en `proyecto/01_levantamiento/auditoria_levantamiento.md`. El gate no elimina preguntas legítimas: las vuelve visibles, les asigna impacto y evita que una inferencia se convierta silenciosamente en requisito.

Ejecutar primero la comprobación mecánica y conservarla como evidencia del gate:

```powershell
python "<skill-metodologia-proyectos>/scripts/auditar_levantamiento.py" `
  --project-root "<PROJECT_ROOT>/proyecto" `
  --output "<PROJECT_ROOT>/proyecto/01_levantamiento/evidencia/auditoria_mecanica.md"
```

Un error mecánico bloquea el cierre. Las advertencias se revisan semánticamente; el script no decide si dos procesos tienen sentido de negocio ni resuelve contradicciones.

## 1. Cobertura de fuentes

- Cada original tiene `SRC-ID`, ubicación, tipo, metadatos, estado y salida de trabajo en `inventario_insumos.md`.
- Cada video/audio tiene transcripción fuente y secuencia detallada, o una justificación explícita si no contiene información utilizable.
- Cada Word/PDF/Excel relevante tiene extracción estructural y revisión visual cuando el formato, capturas, fórmulas o gráficos aportan significado.
- El estado `Pendiente` identifica exactamente qué falta; `Revisado` no se usa si solo se leyó una muestra insuficiente.

## 2. Trazabilidad

- Cada hecho material usa `EV-*` y una referencia verificable: timestamp, página/párrafo, hoja/rango, fórmula, mensaje o captura.
- Todo paso del flujo resumido apunta al subproceso propietario y a evidencia.
- Cada paso detallado tiene evidencia o queda marcado `Inferido/Pendiente`; no se citan transcripciones automáticas como única prueba de nombres, cifras o reglas críticas cuando existe pantalla/archivo para contrastar.
- Toda contradicción conserva ambas fuentes; ninguna se resuelve por preferencia silenciosa.

## 3. Coherencia punta a punta

- Existe un inicio y fin del macroproceso, un disparador y una salida consumible.
- La salida de cada subproceso es entrada válida del siguiente, o el handoff/persistencia queda explicado.
- Actores, sistemas, archivos, hojas, campos, unidades, periodos y fórmulas mantienen el mismo significado entre flujo, AS-IS y datos.
- Una cifra de ejemplo no se convierte en umbral; un color de presentación no se mezcla con un semáforo de validación; una idea futura no se describe como AS-IS.
- Problemas, riesgos y oportunidades están sustentados y no duplican la misma causa con nombres distintos.

## 4. Separación y no redundancia

Para cada par de subprocesos, comparar esta firma:

`objetivo + disparador + actor principal + sistema/archivo dominante + entrada + transformación + salida`

- Separar cuando cambia materialmente el objetivo o la salida, existe un handoff, se cambia de análisis de datos a decisión, o el resultado puede ejecutarse/validarse de forma independiente.
- Unificar cuando dos expedientes tienen el mismo objetivo, transforman la misma entrada en la misma salida y solo difieren por ejemplo, archivo o periodo.
- Una acción tiene un único subproceso propietario. Otros expedientes la referencian como entrada o control, sin copiar sus pasos.
- Repeticiones masivas se documentan una vez con regla, frecuencia y variaciones; no se omiten las decisiones internas ni se enumeran miles de filas iguales.

## 5. Detalle operativo suficiente

Cada expediente debe permitir responder:

1. ¿Qué dispara el trabajo y quién lo ejecuta?
2. ¿Qué abre, consulta, filtra, descarga, carga, copia, calcula, valida o decide el usuario?
3. ¿Qué dato entra y qué cambia o se genera?
4. ¿Qué regla, fórmula, unidad, umbral o excepción aplica?
5. ¿Qué pasa si falta el dato, no coincide o genera duda?
6. ¿Dónde queda la salida y quién la consume/valida?

No fusionar acciones si cambia actor, sistema, archivo/hoja, dato, regla, estado o resultado. No inventar clics no visibles: registrar el vacío como pregunta.

## 6. Sentido de negocio

- El objetivo de cada subproceso explica para qué existe, no solo qué archivo manipula.
- La salida aporta al objetivo del macroproceso y tiene consumidor o propósito identificado.
- Las decisiones distinguen dato, cálculo, interpretación y autorización.
- Los controles atacan riesgos reales; una automatización futura no se presenta como control actual.
- El alcance diferencia operación actual, piloto solicitado y fases futuras.

## 7. Formato de auditoría

```markdown
# Auditoría del levantamiento

- Fecha:
- Fuentes totales/revisadas/pendientes:
- Subprocesos evaluados:
- Resultado: APROBADO | APROBADO_CON_PENDIENTES | BLOQUEADO

| ID | Dimensión | Severidad | Hallazgo | Evidencia/artefacto | Acción | Estado |
| --- | --- | --- | --- | --- | --- | --- |

## Pruebas cruzadas
| Prueba | Resultado | Evidencia |
| --- | --- | --- |

## Pendientes aceptados
| ID | Decisión requerida | Impacto | Responsable esperado | Gate afectado |
| --- | --- | --- | --- | --- |
```

## Resultado y bloqueo

- `APROBADO`: cobertura completa y sin hallazgos abiertos que afecten el entendimiento o los resultados.
- `APROBADO_CON_PENDIENTES`: el AS-IS es coherente, pero quedan datos identificados que no cambian su estructura; pueden presentarse como preguntas, no cerrarse como confirmados.
- `BLOQUEADO`: falta una fuente prometida, hay pasos críticos sin evidencia, la cadena de entradas/salidas no cierra, una contradicción altera cálculos/alcance o existen subprocesos duplicados que cambian la interpretación.

Corregir hallazgos antes de marcar `APROBADO`. Para `APROBADO_CON_PENDIENTES`, registrar responsable esperado e impacto; no avanzar al diseño afectado hasta resolver la decisión material.
