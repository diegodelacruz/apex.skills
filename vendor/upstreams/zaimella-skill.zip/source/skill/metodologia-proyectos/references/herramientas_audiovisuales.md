# Herramientas audiovisuales

## Componentes requeridos

- `ffmpeg` y `ffprobe` mediante el paquete `Gyan.FFmpeg`: inspección de duración, códec y pistas; extracción de audio y capturas.
- Python con `faster-whisper`: transcripción local con modelos Whisper. Los modelos se descargan al primer uso y se almacenan en la caché local del usuario.

Después de instalar FFmpeg, una terminal nueva puede resolverlo por `PATH`. Si no ocurre, usar el resolver versionado; este busca primero `PATH` y después una instalación `Gyan.FFmpeg` administrada por WinGet, sin guardar rutas personales en el proyecto.

## Verificar herramientas

```powershell
$ffmpegBin = & "<skill-metodologia-proyectos>/scripts/resolver_ffmpeg.ps1"
$env:PATH = "$ffmpegBin;$env:PATH"
ffmpeg -version
ffprobe -version
python -c "from faster_whisper import WhisperModel; print('FASTER_WHISPER_OK')"
```

El ajuste de `PATH` anterior aplica solo a la sesión actual. Bloquear el procesamiento audiovisual si el resolver o cualquiera de las tres verificaciones falla.

## Inspeccionar una fuente sin alterarla

```powershell
ffprobe -v error -show_entries format=duration:stream=codec_type,codec_name -of default=noprint_wrappers=1 "<AUDIO_O_VIDEO>"
```

Registrar códec, duración y pistas en `inventario_insumos.md`. Esta inspección no sustituye la revisión funcional del contenido.

## Extraer audio y capturas

Usar el script versionado de `levantamiento-procesos` para capturas. Para video de reunión, comenzar con una captura cada 10 segundos y bajar a 3-5 segundos en segmentos donde se muestren archivos, hojas, reglas, pantallas, cálculos o decisiones.

```powershell
& "<skill-levantamiento-procesos>/scripts/extraer_capturas_video.ps1" `
  -VideoPath "<VIDEO>" `
  -OutputDir "<PROJECT_ROOT>/proyecto/01_levantamiento/evidencia/capturas/<SRC-ID>" `
  -EverySeconds 10
```

Guardar audio extraído, si fuera necesario, en `evidencia/audio/<SRC-ID>.wav`; conservar el video original en `00_insumos/`.

## Transcribir

Usar [`scripts/transcribir_audio.py`](../scripts/transcribir_audio.py). Para una prueba técnica usar `tiny`; para el análisis de una reunión o audio en español usar como mínimo `base` con CPU `int8`. Si la calidad no permite identificar reglas, nombres de archivo, cifras o decisiones, repetir con `small` y comparar contra el audio/video: una transcripción automática siempre requiere validación.

```powershell
python "<skill-metodologia-proyectos>/scripts/transcribir_audio.py" "<AUDIO_O_VIDEO>" `
  --output "<PROJECT_ROOT>/proyecto/01_levantamiento/evidencia/transcripciones/<SRC-ID>_transcripcion.md" `
  --source-id "<SRC-ID>" `
  --language es `
  --model base `
  --cpu-threads 4
```

El límite de hilos evita que una reunión extensa bloquee Word, Excel y la revisión visual ejecutados en paralelo. Aumentarlo solo después de comprobar memoria, temperatura y capacidad de respuesta de la máquina; no ejecutar varias transcripciones formales simultáneas en CPU.

Para grabaciones largas en Windows, iniciar el proceso con el lanzador versionado. Este conserva rutas con espacios, redirige `stdout`/`stderr` y crea un registro con PID en `_logs/`:

```powershell
& "<skill-metodologia-proyectos>/scripts/iniciar_transcripcion.ps1" `
  -InputPath "<AUDIO_O_VIDEO>" `
  -OutputPath "<PROJECT_ROOT>/proyecto/01_levantamiento/evidencia/transcripciones/<SRC-ID>_transcripcion.md" `
  -SourceId "<SRC-ID>" `
  -Model base `
  -Language es `
  -CpuThreads 4
```

No asumir que el proceso terminó por haber recuperado el control de la consola. Verificar el PID indicado, revisar que `stderr` esté vacío y confirmar que la salida Markdown exista y contenga metadatos y segmentos. Usar `-Wait` solo cuando la duración permita mantener la consola ocupada.

El transcriptor y el lanzador se niegan a sobrescribir una transcripción existente. `--force`/`-Force` solo se usan después de preservar o descartar explícitamente la versión anterior; la escritura del Markdown es atómica para no entregar como completa una salida interrumpida.

No editar la transcripción fuente para convertirla en análisis. Las correcciones o interpretaciones se registran en la secuencia detallada con evidencia y estado `Observado`, `Confirmado`, `Inferido` o `Pendiente`.

## Secuencia recomendada

1. Ejecutar `ffprobe` y registrar metadatos.
2. Generar la transcripción fuente y las capturas.
3. Revisar cronológicamente texto, voz y pantalla; crear la secuencia detallada sin omitir acciones observables.
4. Relacionar cada referencia con Word, Excel o PDF en `matriz_correlacion.md`.
5. Recién entonces consolidar los subprocesos AS-IS y el flujo actual resumido.
