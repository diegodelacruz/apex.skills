# Modelo De Artefactos Metodologicos

El nombre historico se conserva por compatibilidad. No define rutas, carpetas, contratos ni bitacoras: `Gestion-Proyectos` administra esa arquitectura y entrega al skill las ubicaciones autorizadas.

## Artefactos Por Etapa

| Etapa | Entradas | Salidas metodologicas |
|---|---|---|
| Descubrimiento y levantamiento | Insumos originales, entrevistas, demostraciones y evidencia | Inventario, matriz de correlacion, AS-IS, problemas, riesgos, oportunidades y preguntas pendientes |
| RI | Levantamiento validado o RI externo | Requerimiento de negocio trazable, alcance y criterios de exito |
| Diseno funcional | AS-IS y RI | TO-BE, casos de uso, prototipos, propuesta y trazabilidad |
| AD tecnico | Decisiones funcionales aprobadas y handoffs de dominio | AD ejecutable, dependencias, riesgos y decisiones tecnicas |
| Planificacion y seguimiento | AD y cambios aprobados | Entregables, sprints, paquetes, handoffs, integracion, riesgos y decisiones |
| Cierre | Evidencia de ejecucion, aceptacion y documentos | Indice de entregables, pendientes transferidos y lecciones aprendidas |

## Reglas

1. Conservar originales sin alterarlos y registrar su procedencia, fecha, alcance y nivel de evidencia.
2. Mantener trazabilidad entre necesidad, proceso, RI, diseno, AD, plan, entrega y cierre.
3. No duplicar un expediente: referenciar el artefacto fuente y conservar una sola salida vigente por decision o etapa.
4. En un proyecto heredado, inventariar las ubicaciones existentes; no mover, copiar, renombrar ni borrar archivos. El orquestador registra las equivalencias.
5. Entregar al orquestador los artefactos, evidencias y datos de bitacora para que los ubique y relacione en la arquitectura contractual.
