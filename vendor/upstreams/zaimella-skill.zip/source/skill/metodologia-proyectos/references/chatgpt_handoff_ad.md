# Handoff estructurado hacia ChatGPT para AD y casos de uso

## Objetivo

Definir como debe preparar `Codex` los insumos que se enviaran a `ChatGPT` para redactar `AD` y casos de uso con mejor calidad, menor ambiguedad y mayor trazabilidad.

## Hallazgo base

Los ejemplos revisados muestran un patron consistente:

- `ChatGPT` responde mejor cuando recibe un `prompt maestro` del proyecto.
- El resultado mejora cuando existe un conjunto de `insumos concretos` y no solo un requerimiento general.
- Los mejores resultados aparecen cuando `ChatGPT` redacta sobre una estructura ya definida y no cuando interpreta el problema desde cero.

## Responsabilidad de Codex antes de usar ChatGPT

Antes de pedir redaccion a `ChatGPT`, `Codex` debe producir y validar:

- estructura del proyecto por etapas
- `proyecto/bitacora.md` general y la bitácora de la etapa concreta: `01_levantamiento`, `02_ri`, `03_diseno_funcional` o `04_ad`.
- centralizacion de insumos en `proyecto/04_ad/documentos/`
- nombre del proyecto
- objetivo del proyecto
- alcance incluido y fuera de alcance
- contexto actual o `AS-IS`
- lista de actores
- lista de procesos
- reglas de negocio
- dependencias y restricciones
- analisis tecnico base
- inventario de pantallas, paginas, tablas, vistas, paquetes, jobs, APIs u objetos equivalentes
- bloqueos o vacios criticos

## Paquete minimo para AD

Todo insumo que `Codex` prepare para que `ChatGPT` redacte el `AD` debe quedar dentro de `proyecto/04_ad/documentos/`.

Como minimo, el paquete debe incluir:

- `01_instrucciones_proyecto_chatgpt.md`
- `02_ri_base.md`
- `03_analisis_tecnico_detallado.md`
- `04_matriz_trazabilidad.md`
- `05_bloqueos_y_supuestos.md`
- `06_prompt_chatgpt_ad.md`

Si el proyecto usa una aplicacion APEX existente como referencia, `03_analisis_tecnico_detallado.md` debe incluir obligatoriamente la `situacion actual` de esa aplicacion:

- nombre y alcance funcional actual de la aplicacion
- paginas relevantes
- regiones relevantes
- objetos de base usados por la aplicacion
- paquetes, vistas, tablas e integraciones identificadas
- observaciones sobre como funciona hoy

Usa como base:

- [`plantilla_instrucciones_proyecto_chatgpt.md`](prompts/templates/plantilla_instrucciones_proyecto_chatgpt.md)
- [`plantilla_analisis_tecnico_detallado.md`](prompts/templates/plantilla_analisis_tecnico_detallado.md)
- [`plantilla_matriz_trazabilidad.md`](prompts/templates/plantilla_matriz_trazabilidad.md)
- [`plantilla_bloqueos_y_supuestos.md`](prompts/templates/plantilla_bloqueos_y_supuestos.md)
- [`plantilla_prompt_chatgpt_ad.md`](prompts/templates/plantilla_prompt_chatgpt_ad.md)

Las reglas metodologicas de redaccion de `AD` no viven en estas plantillas. La fuente de verdad para ese criterio es:

- [`references/etapas/ad/reglas.md`](etapas/ad/reglas.md)
- [`references/ejemplos/ad/patron_redaccion_ad.md`](ejemplos/ad/patron_redaccion_ad.md)

## Regla para proyectos.md

Dentro de `proyecto/04_ad/documentos/` debe existir un archivo `proyectos.md`.

Ese archivo debe mantener la ruta de documentacion de los `3` ultimos proyectos usados como referencia para el analisis o la redaccion del `AD`.

Reglas:

- guardar rutas reales y completas
- ordenar desde el proyecto mas reciente al menos reciente
- no mezclar explicaciones largas dentro de `proyectos.md`; debe ser lista de referencia corta
- si todavia no existen tres referencias confirmadas, registrar las disponibles y completar despues

## Paquete minimo para casos de uso

Para redactar casos de uso, `Codex` debe dejar al menos estos archivos de apoyo:

- `01_instrucciones_proyecto_chatgpt.md`
- `02_objetivo_y_alcance.md`
- `03_actores_procesos_reglas.md`
- `04_matriz_casos_de_uso.md`
- `05_excepciones_y_variantes.md`
- `06_prompt_chatgpt_casos_uso.md`

Usa como base:

- [`plantilla_instrucciones_proyecto_chatgpt.md`](prompts/templates/plantilla_instrucciones_proyecto_chatgpt.md)
- [`plantilla_matriz_casos_de_uso.md`](prompts/templates/plantilla_matriz_casos_de_uso.md)
- [`plantilla_prompt_chatgpt_casos_uso.md`](prompts/templates/plantilla_prompt_chatgpt_casos_uso.md)

## Contenido esperado de cada insumo

### 01_instrucciones_proyecto_chatgpt.md

Debe funcionar como `prompt maestro` y contener:

- nombre del proyecto
- rol esperado de `ChatGPT`
- objetivo del proyecto
- contexto obligatorio
- alcance
- requerimientos principales
- lineamientos de redaccion
- entregables esperados

### 02_ri_base.md

Debe condensar el `RI` aprobado o el insumo rector del negocio en formato claro:

- antecedente
- problemas actuales
- objetivo del proyecto
- oportunidades
- alcance del proyecto

### 03_analisis_tecnico_detallado.md

Debe ser construido por `Codex` y contener el aterrizaje tecnico minimo:

- tecnologia principal y tecnologias relacionadas
- aplicacion principal
- modulos involucrados
- paginas o pantallas identificadas
- tablas, vistas, paquetes, procedimientos, jobs, servicios o componentes equivalentes
- integraciones
- flujos relevantes
- fuentes de datos
- validaciones
- dependencias
- riesgos tecnicos

### 04_matriz_trazabilidad.md

Debe relacionar:

- punto del alcance aprobado
- necesidad funcional
- solucion tecnica prevista
- componentes involucrados
- estado de definicion

### 05_bloqueos_y_supuestos.md

Debe separar con claridad:

- definiciones confirmadas
- supuestos tecnicos provisionales
- bloqueos criticos
- decisiones pendientes del usuario o de terceros

### 06_prompt_chatgpt_ad.md

Debe ser el prompt final que consumira `ChatGPT` para redactar el `AD`, usando como base todos los archivos anteriores.

## Regla para analisis tecnico detallado

El objetivo no es que `ChatGPT` descubra la solucion tecnica. Ese trabajo debe llegar ya preparado por `Codex`.

Por eso, `Codex` debe identificar y escribir con precision:

- que paginas o pantallas se tocan
- que objetos tecnicos se crean o modifican
- que datos entran y salen
- que reglas cambian
- que dependencias externas existen
- que puntos aun no pueden cerrarse

## Regla para casos de uso

Los casos de uso se redactan mejor cuando `Codex` entrega primero:

- actor principal
- actores secundarios
- evento disparador
- precondiciones
- flujo principal
- variantes o excepciones
- postcondiciones
- reglas de negocio
- pantallas o componentes involucrados

`ChatGPT` debe usarse para convertir eso en texto claro, no para inventar actores o escenarios no identificados.

## Criterio de calidad del handoff

El handoff a `ChatGPT` es correcto solo si cumple estas condiciones:

1. El proyecto ya tiene estructura por etapas y bitacoras base.
2. El proyecto ya tiene objetivo y alcance claros.
3. Existe un `RI` o equivalente resumido por `Codex`.
4. Existe analisis tecnico concreto y no solo narrativa funcional.
5. Los bloqueos estan separados del contenido cerrado.
6. El prompt final de `ChatGPT` indica expresamente que no debe inventar definiciones no confirmadas.
