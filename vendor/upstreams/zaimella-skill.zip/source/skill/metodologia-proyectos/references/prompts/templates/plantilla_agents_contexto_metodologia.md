<!-- ZAIMELLA: METODOLOGIA-PROYECTOS:START -->
# Metodología de proyectos de Sistemas

Usar `metodologia-proyectos` para iniciar, levantar, diseñar, planificar, seguir o cerrar proyectos tecnológicos de Sistemas. La fuente de verdad de estructura, etapas, gates, herramientas y entregables permanece dentro del skill; este bloque no la reemplaza.

- Seguir: necesidad u oportunidad -> levantamiento AS-IS -> RI -> diseño funcional (TO-BE, casos de uso, prototipos y propuesta) -> AD técnico -> planificación y seguimiento -> cierre.
- Usar `levantamiento-procesos` para reconstruir AS-IS, problemas, riesgos y oportunidades desde evidencia. El RI recibido también se inventaría y contrasta como insumo; no demuestra aprobación por sí solo.
- Aplicar `references/arquitectura_archivos.md`, `references/lectura_insumos.md` y `references/protocolo_correlacion_insumos.md`. En proyectos nuevos, guardar originales en `proyecto/00_insumos/`; en heredados, preservar e inventariar originales existentes sin moverlos automáticamente.
- Conservar transcripción fuente y secuencia detallada por reunión, además del flujo resumido y expedientes AS-IS por subproceso. No analizar aisladamente archivos que expliquen el mismo proceso.
- Antes de cerrar el levantamiento o pasar al RI, ejecutar `references/calidad_levantamiento.md` y guardar `proyecto/01_levantamiento/auditoria_levantamiento.md`.
- El TO-BE, los casos de uso, prototipos y propuesta se validan en `proyecto/03_diseno_funcional/` antes de cerrar el AD técnico en `proyecto/04_ad/`.
- Mantener bitácoras, evidencia, aprobaciones, decisiones, cambios, riesgos, pendientes y siguiente paso. No cerrar una etapa con decisiones críticas abiertas.
- Usar `documents`, `spreadsheets` y `pdf` para sus formatos; aplicar los helpers locales solo como apoyo de lectura/render y sus protecciones contra sobrescritura.

<!-- ZAIMELLA: METODOLOGIA-PROYECTOS:END -->
