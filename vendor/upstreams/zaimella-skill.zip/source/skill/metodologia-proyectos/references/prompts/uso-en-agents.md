# Prompt de uso - metodologia-proyectos

## Contenido para AGENTS.md

El orquestador de proyectos prepara y gobierna la arquitectura, contratos, bitacoras y rutas. `metodologia-proyectos` recibe esas entradas y aplica el metodo; no crea ni administra la estructura del proyecto.

```markdown
# Uso de metodologia-proyectos

Usar `metodologia-proyectos` para iniciar, levantar, documentar, asesorar, seguir o cerrar proyectos tecnológicos de Sistemas Zaimella. El flujo es: necesidad u oportunidad -> levantamiento -> RI -> AD funcional (TO-BE, casos de uso y prototipos) -> AD técnico -> planificación y seguimiento -> cierre.

- Usar `levantamiento-procesos` para analizar documentos, entrevistas, videos, audios, capturas, sistemas y procesos actuales. El RI formaliza AS-IS, problemas, riesgos y oportunidades resultantes.
- Leer insumos con `references/lectura_insumos.md`; cuando las fuentes se relacionen, aplicar `references/protocolo_correlacion_insumos.md`, IDs `SRC-*`/`EV-*` y matriz de correlación. Para video/audio, conservar transcripción fuente y secuencia detallada sin omitir acciones; generar luego flujo actual resumido y AS-IS detallado por subproceso. Usar `documents`, `spreadsheets` y `pdf` según el tipo de archivo, el extractor local para HTML/RI de portal y `levantamiento-procesos` para video y audio.
- Antes de cerrar el levantamiento o pasar al RI, aplicar `references/calidad_levantamiento.md` y guardar `proyecto/01_levantamiento/auditoria_levantamiento.md`; corregir o declarar fuentes pendientes, incoherencias, contradicciones, pasos sin evidencia y subprocesos redundantes.
- Mantener trazabilidad, evidencia, bitácoras, decisiones, control de cambios y pendientes. No cerrar etapas con definiciones críticas abiertas.
- Cuando el contexto use `Gestion-Proyectos`, mantener entregables, sprints, paquetes y handoffs; delegar por orquestador de dominio registrado, nunca por sus skills internos. Un hallazgo corregible permanece en el ciclo del dominio.
- Planificar manuales funcionales y documentacion tecnica bajo un solo skill `documentacion-proyecto-sistemas`, con perfiles, audiencia, linea base y evidencia comunes.
- Mantener la metodología en `proyecto/`; no duplicar sus reglas extensas en este AGENTS.md.
```

## Verificación

Confirmar que existen `proyecto/bitacora.md`, las carpetas de levantamiento, RI, AD, planificación, seguimiento y cierre, sus bitácoras aplicables y un inventario de insumos. Si se gestionara ejecucion, confirmar tambien matriz de entregables, sprints, paquetes, handoffs y plan documental.
