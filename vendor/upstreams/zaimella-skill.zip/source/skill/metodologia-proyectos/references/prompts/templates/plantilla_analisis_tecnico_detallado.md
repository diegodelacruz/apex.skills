# Analisis tecnico detallado

## Objetivo

Dejar el aterrizaje tecnico minimo que `ChatGPT` necesita para redactar el `AD` sin inventar definiciones.

## Contexto tecnico general

- tecnologia principal:
- tecnologias relacionadas:
- aplicacion principal:
- modulo principal:
- aplicaciones o sistemas relacionados:

## Referencia actual

- solucion actual o sistema origen:
- componente o modulo de referencia:
- flujo actual resumido:

## Componentes funcionales involucrados

- proceso o frente 1:
- proceso o frente 2:
- proceso o frente 3:

## Paginas o pantallas identificadas

- `Pagina <ID> - <Nombre>`:
  - objetivo:
  - cambio previsto:
  - componentes relevantes:

## Objetos tecnicos identificados

- tablas:
- vistas:
- paquetes:
- procedimientos o funciones:
- jobs:
- APIs o servicios:
- archivos o interfaces:

## Reglas de negocio y validaciones

- regla 1:
- regla 2:
- regla 3:

## Integraciones y datos

- origen de datos:
- destino de datos:
- mecanismo de integracion:
- eventos o disparadores:

## Reportes o salidas esperadas

- reporte o salida 1:
- reporte o salida 2:

## Riesgos, dependencias y bloqueos

- dependencia 1:
- bloqueo 1:
- decision pendiente 1:

