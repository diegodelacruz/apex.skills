# Bloqueos y supuestos

## Definiciones confirmadas

- 

## Supuestos tecnicos provisionales

- 

## Bloqueos criticos

- 

## Decisiones pendientes del usuario o de terceros

- 

