# Matriz de casos de uso

| Codigo | Nombre del caso de uso | Actor principal | Disparador | Resultado esperado | Pantallas o componentes | Variantes o excepciones |
|---|---|---|---|---|---|---|
| UC-01 |  |  |  |  |  |  |
| UC-02 |  |  |  |  |  |  |
| UC-03 |  |  |  |  |  |  |
| UC-04 |  |  |  |  |  |  |

