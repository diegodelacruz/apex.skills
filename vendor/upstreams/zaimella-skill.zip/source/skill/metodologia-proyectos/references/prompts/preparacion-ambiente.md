# Preparación de ambiente - metodologia-proyectos

Usar antes de iniciar o retomar un proyecto tecnológico de Sistemas Zaimella.

## Requisitos

El orquestador prepara la arquitectura y entrega las rutas; este prompt valida insumos y herramientas. No crear carpetas, contratos ni bitacoras de proyecto desde este skill.

- Tener disponible `skill/metodologia-proyectos/` y confirmar que el caso pertenece a Sistemas.
- Identificar nombre, necesidad u oportunidad y, cuando se planifique, fecha de inicio.
- Confirmar el acceso a los insumos originales y su sensibilidad.
- Tener disponibles `documents`, `spreadsheets` y `pdf` para Word, Excel y PDF, y `levantamiento-procesos` para reconstruir procesos desde evidencia.
- En Windows, Microsoft Word y Excel son opcionales para los helpers COM de lectura y render; comprobarlos creando los objetos `Word.Application` y `Excel.Application`. Si no existen, usar los skills especializados y registrar la limitación.
- Para revisión PDF, verificar las herramientas exigidas por `pdf` (incluido Poppler cuando ese skill lo requiera). Para HTML/RI guardado de portal, usar el extractor local versionado sin JavaScript ni recursos externos.
- Para video/audio, verificar `ffmpeg`, `ffprobe` y `faster-whisper` con `references/herramientas_audiovisuales.md` antes de procesar una fuente formal.

Comprobación rápida en Windows, sin abrir documentos del proyecto:

```powershell
$wordApp = New-Object -ComObject Word.Application
$wordApp.Quit()
$excelApp = New-Object -ComObject Excel.Application
$excelApp.Quit()
$popplerBin = & "<skill-metodologia-proyectos>/scripts/resolver_poppler.ps1"
$env:PATH = "$popplerBin;$env:PATH"
$previousErrorAction = $ErrorActionPreference
$ErrorActionPreference = 'SilentlyContinue'
& (Join-Path $popplerBin 'pdftoppm.exe') -v
$pdftoppmCode = $LASTEXITCODE
& (Join-Path $popplerBin 'pdfinfo.exe') -v
$pdfinfoCode = $LASTEXITCODE
$ErrorActionPreference = $previousErrorAction
if ($pdftoppmCode -ne 0 -or $pdfinfoCode -ne 0) { throw 'POPPLER_NO_DISPONIBLE' }
python -c "from faster_whisper import WhisperModel; print('FASTER_WHISPER_OK')"
```

Los ajustes de `PATH` aplican solo a la sesión actual. Ejecutar además el resolver y las verificaciones de FFmpeg descritas en `references/herramientas_audiovisuales.md`. Una comprobación fallida bloquea solo el tipo de insumo afectado: registrar la limitación y usar el método alternativo del skill especializado; no declarar una fuente revisada si faltó la inspección necesaria.

## Estructura

Preparar o confirmar:

```text
proyecto/
|- bitacora.md
|- 00_insumos/
|- 01_levantamiento/
|- 02_ri/
|- 03_diseno_funcional/
|- 04_ad/
|- 05_planificacion/
|  `- sprints/
|- 06_seguimiento/
|  |- paquetes/
|  |- handoffs/
|  |- integracion/
|  |- documentacion/
|  `- _control/
`- 07_cierre/
   `- entregables/
```

Inventariar primero los insumos siguiendo `references/lectura_insumos.md`. Si video, audio, Word, Excel, PDF, imágenes o conversaciones explican un mismo proceso, aplicar `references/protocolo_correlacion_insumos.md`, usar IDs de fuente y crear la matriz de correlación antes de identificar procesos o redactar RI. Cada fuente audiovisual debe generar transcripción fuente y secuencia detallada; el levantamiento consolida un flujo actual resumido y AS-IS detallados por subproceso. Si existe operación, proceso o evidencia sin estructurar, activar `levantamiento-procesos`. Antes de cerrar el levantamiento, ejecutar `references/calidad_levantamiento.md` y guardar `auditoria_levantamiento.md`.

## Resultado esperado

La etapa activa, la estructura, las bitácoras, los insumos y el siguiente paso deben quedar registrados sin suponer información faltante.
