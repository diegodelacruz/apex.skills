# Matriz de trazabilidad

| Punto del alcance aprobado | Necesidad funcional | Solucion tecnica prevista | Componentes involucrados | Estado | Observaciones |
|---|---|---|---|---|---|
| 1 |  |  |  |  |  |
| 2 |  |  |  |  |  |
| 3 |  |  |  |  |  |
| 4 |  |  |  |  |  |

