# Prompt para ChatGPT - Casos de uso

Usa las `Instrucciones del Proyecto` y los insumos adjuntos para redactar los casos de uso del proyecto.

## Reglas obligatorias

- No inventes actores, procesos ni excepciones no sustentadas.
- Redacta casos de uso textuales, claros y reutilizables.
- Si una variante depende de una restriccion tecnica o legal, dejala explicita.
- Si un caso usa RPA, deja visibles las restricciones de captcha, login, validacion manual u otras barreras.

## Insumos que debes usar

- `01_instrucciones_proyecto_chatgpt.md`
- `02_objetivo_y_alcance.md`
- `03_actores_procesos_reglas.md`
- `04_matriz_casos_de_uso.md`
- `05_excepciones_y_variantes.md`

## Formato sugerido por caso de uso

- codigo
- nombre
- objetivo
- actor principal
- actores secundarios
- disparador
- precondiciones
- flujo principal
- flujos alternos
- reglas de negocio
- postcondiciones
- observaciones

