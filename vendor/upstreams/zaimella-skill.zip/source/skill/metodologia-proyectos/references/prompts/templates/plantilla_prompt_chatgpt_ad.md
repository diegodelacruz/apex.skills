# Prompt para ChatGPT - AD

Usa las `Instrucciones del Proyecto` y los insumos adjuntos para redactar el `AD` del proyecto.

Este prompt no reemplaza la metodologia del skill ni define arquitectura por su cuenta. Solo convierte a redaccion final los insumos ya preparados por `Codex`.

## Reglas obligatorias

- No redactes desde cero sin respetar los insumos entregados.
- No inventes paginas, objetos, integraciones, decisiones de arquitectura ni alcances no confirmados.
- Si un punto tiene bloqueo, mantenlo visible y no lo cierres artificialmente.
- Conserva la secuencia del alcance aprobado.
- `Resumen ejecutivo` debe quedar en lenguaje ejecutivo.
- `Analisis` debe resumir la situacion actual y el alcance tecnico.
- `Definicion` debe quedar como plan tecnico ejecutable y no como narrativa vaga.

## Insumos que debes usar

- `01_instrucciones_proyecto_chatgpt.md`
- `02_ri_base.md`
- `03_analisis_tecnico_detallado.md`
- `04_matriz_trazabilidad.md`
- `05_bloqueos_y_supuestos.md`

## Resultado esperado

Redacta el documento con esta estructura:

1. `Resumen ejecutivo`
2. `Analisis`
3. `Definicion`

En `Definicion`:

- respeta el orden del alcance aprobado
- usa titulos claros por punto o subpunto
- abre cada bloque describiendo la solucion
- luego desarrolla la secuencia tecnica
- nombra objetos concretos cuando ya esten confirmados
