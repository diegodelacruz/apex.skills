# Metodología general

## Fuente de verdad

El modelo de artefactos y su secuencia viven en `references/arquitectura_archivos.md`. La arquitectura concreta, responsables de carpetas y rutas las define el orquestador; el skill no crea una estructura paralela ni mueve archivos existentes.

## Secuencia metodológica

1. `00_insumos`: evidencia original aportada por usuario o cliente.
2. `01_levantamiento`: identificación de procesos, AS-IS, problemas, riesgos y oportunidades.
3. `02_ri`: requerimiento de negocio derivado del levantamiento o RI externo contrastado contra él.
4. `03_diseno_funcional`: TO-BE, casos de uso, prototipos y propuesta funcional.
5. `04_ad`: definición técnica ejecutable basada en decisiones funcionales validadas.
6. `05_planificacion` y `06_seguimiento`: ejecución, control y cambios del proyecto.
7. `07_cierre`: aceptación, pendientes y lecciones aprendidas.

## Reglas transversales

- Mantener evidencia, aprobación, responsables, decisiones, bloqueos y siguiente paso en las bitácoras aplicables.
- No convertir una oportunidad o hipótesis en requisito cerrado sin validación.
- Si el RI llega de un tercero, preservarlo como insumo formal; registrar las contradicciones contra la evidencia y solicitar definición antes de cerrar el diseño funcional o AD.
- Si cambia el alcance, evaluar el impacto de forma secuencial: RI, TO-BE, casos de uso, prototipo, AD y planificación.
- Validar visualmente los DOCX, PDF y hojas de cálculo que se generen o se usen como evidencia crítica, con el skill especializado correspondiente.
