# ejemplo2

- Nombre: REDISEÑO DE LA ARQUITECTURA DE DATOS - BI COMERCIAL
- Fuente original: `<EXAMPLE_SOURCE>/documento_fuente.docx`
- Imágenes identificadas en la fuente: 2
- Archivo de texto extraído: [texto_extraido.md](./texto_extraido.md)
- Imágenes no publicadas en el skill; consultar la fuente autorizada cuando el análisis visual sea necesario.

## Coincidencias de secciones y palabras clave

- Definición de tabla en Athena/Glue Catalog (para consulta).
- Se publicará el histórico completo de Sellout en AWS en la tabla comercial.sellout. La tabla será la fuente de histórico y análisis; la tabla transaccional se quedará como fuente operativa acotada a dos años.
