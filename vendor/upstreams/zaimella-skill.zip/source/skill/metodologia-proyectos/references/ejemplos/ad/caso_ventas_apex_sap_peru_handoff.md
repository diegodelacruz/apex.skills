# Caso de referencia - Ventas APEX con SAP Peru

## Objetivo

Usar el proyecto `IMPLEMENTACION MODULO DE VENTAS APEX CON SAP PERU` como ejemplo real para mostrar como debe quedar el handoff desde `Codex` hacia `ChatGPT` despues de tener un `RI` ya construido.

## Estado observado del proyecto de referencia

Ruta del proyecto:

- `<PROJECT_ROOT>`

Estado actual observado:

- existe `RI.docx` en raiz
- existe `AGENTS.md`
- no existe `bitacora.md`
- no existe estructura completa por etapas
- el `RI` no contiene imagenes embebidas relevantes en el archivo revisado

## Lectura util del RI

El `RI` ya contiene:

- contexto actual de Peru operando en `SAP`
- referencia comparativa del modulo de Ventas de Ecuador en `APEX`
- problemas actuales
- objetivo de negocio
- oportunidades
- alcance numerado

El alcance aprobado identificado en el `RI` se resume en estos frentes:

1. incorporar la compania Peru al modulo de Ventas en `APEX`, integrado con `SAP`
2. integrar automaticamente pedidos y devoluciones aprobados con `SAP`
3. implementar reportes operativos y comerciales para Peru
4. disenar e implementar documentos transaccionales consultables y descargables en `APEX`

## Como debe operar Codex sobre este caso

`Codex` no debe pedir a `ChatGPT` que descubra la solucion tecnica. Primero debe producir:

### 01_instrucciones_proyecto_chatgpt.md

Debe dejar claro que el proyecto trata de:

- extender a Peru el modulo de Ventas existente en `APEX`
- integrar la operacion con `SAP`
- reutilizar el patron funcional ya existente en Ecuador cuando aplique
- definir reportes y documentos transaccionales para seguimiento comercial

### 02_ri_base.md

Debe resumir el `RI` actual sin cambiar su sentido, especialmente:

- proceso actual en Peru usando `SAP`
- referencia funcional del modelo de Ecuador en `APEX`
- alcance aprobado por bloques

### 03_analisis_tecnico_detallado.md

En este proyecto, el analisis tecnico que `Codex` debe construir debe responder como minimo:

- cual es la `Aplicacion principal` en `APEX`
- que paginas actuales de Ecuador sirven de referencia
- que paginas nuevas o adaptadas requerira Peru
- que validaciones comerciales deben replicarse o ajustarse
- que objetos `SAP` intervienen en pedidos, devoluciones, precios, descuentos, conversiones y productos inactivos
- como se integran pedidos y devoluciones aprobados hacia `SAP`
- que notificaciones a Bodega existen o deben existir
- que reportes actuales de Ecuador se reutilizan y con que fuente de datos
- como se consultaran y descargaran factura y nota de credito

Si estos identificadores no existen todavia, `Codex` debe dejar el bloqueo y pedirlos antes de cerrar `AD`.

### 04_matriz_trazabilidad.md

Debe mapear cada punto del alcance aprobado contra:

- necesidad funcional
- solucion tecnica prevista
- paginas o componentes afectados
- objetos `SAP` o integraciones asociadas
- estado del punto

### 05_bloqueos_y_supuestos.md

En este caso, tipicamente deben revisarse y dejarse explicitos posibles bloqueos como:

- nombre o identificador de la aplicacion `APEX`
- paginas exactas del modulo de Ecuador que se reutilizaran
- objetos o servicios `SAP` que recibiran pedidos y devoluciones
- mecanismo de notificacion a Bodega
- origen exacto de datos para reportes
- forma tecnica de generacion y descarga de factura y nota de credito

### 06_prompt_chatgpt_ad.md

Debe pedir a `ChatGPT` que redacte el `AD` usando el paquete ya preparado por `Codex`, manteniendo:

- el orden del alcance aprobado
- tono ejecutivo en `Resumen ejecutivo`
- tono tecnico en `Analisis`
- `Definicion` como plan ejecutable
- bloqueos visibles cuando falten paginas, objetos o integraciones criticas

## Valor de este caso para el skill

Este proyecto sirve como patron para proyectos donde:

- ya existe un `RI` aprobado
- hay una aplicacion `APEX` de referencia en otro pais, compania o modulo
- la nueva solucion debe reutilizar comportamiento existente
- `Codex` debe producir primero el aterrizaje tecnico para que luego `ChatGPT` redacte mejor

## Regla derivada para el skill

Si el proyecto combina `APEX` con un `ERP` corporativo como `SAP`, el handoff a `ChatGPT` no puede quedarse en frases generales como `integrar con ERP`, `replicar modulo` o `hacer reportes similares`.

Antes de enviar a redaccion, `Codex` debe aterrizar:

- paginas de referencia
- componentes a crear o adaptar
- objetos o interfaces de integracion
- validaciones de negocio
- reportes involucrados
- documentos transaccionales

