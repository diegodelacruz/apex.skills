# ejemplo1

- Nombre: BASES DE DATOS MARKET SHARE
- Fuente original: `<EXAMPLE_SOURCE>/BASES DE DATOS MARKET SHARE.docx`
- Imágenes identificadas en la fuente: 15
- Archivo de texto extraído: [texto_extraido.md](./texto_extraido.md)
- Imágenes no publicadas en el skill; consultar la fuente autorizada cuando el análisis visual sea necesario.

## Coincidencias de secciones y palabras clave

- No se detectaron encabezados literales de `Resumen ejecutivo` o `Definicion`; el ejemplo se conserva por su contenido técnico y su estilo de detalle.
