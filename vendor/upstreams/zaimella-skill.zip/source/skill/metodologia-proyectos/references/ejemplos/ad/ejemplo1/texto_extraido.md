# BASES DE DATOS MARKET SHARE

Fuente original: `<EXAMPLE_SOURCE>/BASES DE DATOS MARKET SHARE.docx`

## Texto extraido

BASES DE DATOS MARKET SHARE

Se realizarán las mejoras en la aplicación APEX 145 para las encuestas y asignación de rutas. Los procedimientos deben crearse dentro de los paquetes: PK_INTC_MARKETSHARE.

Tablas Maestras / Dimensiones

T_INTC_MARKETSHARE_PROVEEDOR

Tabla para registrar los proveedores de información de market share.Columnas:

idproveedor → Identificador único del proveedor (clave primaria).

codigogrupo → Código del grupo o cliente en el ERP (si aplica).

nombreproveedor → Nombre completo del proveedor de datos (ej. Favorita, Rosado, IQVIA).

tipoarchivo → Tipo de archivo fuente (CSV o EXCEL).

Separador → En el caso que sea CSV .

Categoria ->

Tipo -> MarkeShare / Importaciones

Iniciofila -> Indica en qué número de fila inicia la información.

mesInicio -> Mes  inicio de archivo en el caso que no tenga fecha

compañía → Código de compañía (ej. ZM EC).

fechaultimacarga → Fecha en que se realizó la última carga de archivo.

fechacreacion → Fecha de creación del registro.

usuariocreacion → Usuario que creó el registro.

fechamodificacion → Fecha de la última modificación del registro.

usuariomodificacion → Usuario que modificó el registro.

IdentificarCompetencia -> Bandera que indica que no pudo identificar la competencia en los archivos procesados.

IdentificarProductos -> Bandera que indica que no pudo identificar los productos en los archivos procesados.

estado → Estado del proveedor (1=activo, 0=inactivo)

ErrorCarga -> Descripción del error de la carga

T_INTC_COMPETENCIA_EMPRESA

Tabla para registrar las empresas competidoras.Columnas:

idcompetencia → Identificador único de la empresa competidora (clave primaria).

nombre → Nombre de la empresa competidora.

ruc → Número de RUC o identificador legal de la empresa.

país → País donde opera la empresa.

Identificadores -> Palabras claves para identificar la competencia en los archivos Excel.

Compañía → Código de compañía de Zaimella.

fechacreacion → Fecha de creación del registro.

usuariocreacion → Usuario que creó el registro.

fechamodificacion → Fecha de última modificación.

usuariomodificacion → Usuario que modificó el registro.

estado → Estado de la empresa (1=activa, 0=inactiva, 2 sin homologar) .

T_INTC_COMPETENCIA_PRODUCTO

Tabla para registrar los productos de las empresas competidoras.Columnas:

idproducto → Identificador único del producto (clave primaria).

idcompetencia → Identificador de la empresa competidora a la que pertenece (FK).

nombreproducto → Nombre completo del producto.

CodigoProductoCliente --->

codigobarra → Código de barras EAN13 del producto (si aplica).

Identificadores -> Palabras claves para identificar la competencia en los archivos Excel.

CodigoBarraproductozaimella → Identificador del producto Zaimella con el que se compara (FK a maestro de productos internos de ZM, p. ej. d_producto).

Linea ->

Marca→ Categoría a la que pertenece el producto.

SubMarca

Categoria

Talla

Conteo

Segmento

compañía → Código de compañía de Zaimella.

fechacreacion → Fecha de creación del registro.

usuariocreacion → Usuario que creó el registro.

fechamodificacion → Fecha de última modificación.

usuariomodificacion → Usuario que modificó el registro.

estado → Estado del producto (1=activo, 0=inactivo).

T_INTC_MARKETSHARE

Propósito: Almacenar los registros estandarizados de Market Share, provenientes de todas las fuentes (autoservicios, farmacias, importaciones). Esta tabla será la fuente transaccional que luego se replica al DWH en AWS.

Columnas:

idproveedor → Identificador del proveedor de la información (FK a T_INTC_MARKETSHARE_PROVEEDOR).

idcompetencia -> Id de la competencia identificada

Competencia -> Texto que viene en los archivos Excel

fecha → Fecha del registro de venta/importación.

local → Local, tienda o ciudad donde se registró la venta.

Ubicación

Formato → Formato o canal (ej. Hipermercado, Vecino, Farmacia, etc.).

Producto ->

codigobarra → Código de barras (EAN13) si está disponible en la fuente.

codigoproductoproveedor → Código de producto definido por el proveedor o portal (SKU propio de la fuente).

cantidad → Cantidad de unidades vendidas o importadas.

Precio → Precio unitario en dólares (si lo reporta la fuente; puede ser nulo en Favorita).

total → Valor total de la venta en dólares (si aplica; si no se calcula después).

compania → Código de compañía Zaimella (ej. ZM EC).

Crear la tabla T_CORP_MAPEO_EXCEL , que contenga las siguientes columnas:

Tabla  -> atadura

IdTabla -> atadura

TablaDestino

CampoDestino -> columna de la tabla T_INTC_MARKETSHARE

Columna -> Columna del Excel

Formula -> Formula para aplicar a la columna

T_INTC_IMPORTACIONES

Propósito:Almacenar la información de importaciones de productos terminados (PT) y materias primas (MP) provenientes de Cobus. Será la base para medir oferta, analizar tendencias de importación de pañales y otras categorías, y compararla contra ventas locales (demanda).

RAZÓN SOCIAL

RUC DEL IMPORTADOR

PROVEEDOR NOMBRE

POSICIÓN ARANCELARÍA

DESCRIPCIÓN DE LA POSICION

FECHA

DESCRIPCIÓN COMERCIAL 1

DESCRIPCIÓN COMERCIAL 2

DESCRIPCIÓN COMERCIAL 3

DESCRIPCIÓN COMERCIAL 4

DESCRIPCIÓN COMERCIAL 5

DESCRIPCIÓN COMERCIAL 6

DESCRIPCIÓN COMERCIAL 7

MARCA

MODELO

CARACTERISTICAS

VALOR FOB U$S

VALOR FLETE U$S

VALOR SEGURO U$S

VALOR CIF U$S

VALOR CANTIDAD

UNIDAD DE MEDIDA

CANTIDAD DE UNIDAD COMERCIAL

TIPO DE UNIDAD COMERCIAL

PAÍS DE ORIGEN

VALOR KGS NETOS

VALOR KGS BRUTO

ADVAL

IMPUESTO 1

IMPUESTO 2

CAMPOExtra1

CAMPOExtra2

CAMPOExtra3

T_INTC_IMPORTACIONES_PRODUCTOS

DescripcionImportacion

codigoBarra

Configuración

En el menú de la aplicación de Inteligencia Comercial se agregará el menú de Market Share.

Competencia

Crear una pantalla para administrar los datos de la competencia.

Agregar un nuevo registro

Editar registros

Ver productos de la competencia

Producto

Crear una pantalla para administrar los datos de los productos de la competencia. Debe tener un filtro por empresa competidora.

Subir masivamente los productos de las empresas competidoras.

Seleccionar productos

Seleccionar todos los productos

Eliminar productos seleccionados

Proveedor

Crear la página para la administración de proveedores. Tipo -> MarkeShare

Abrir diálogo para crear un proveedor, este puede atarse a un Cliente de Zm disponible. Esta información se debe guardar en la tabla T_INTC_MARKETSHARE_PROVEEDOR

Editar información del proveedor

Configurar archivo Excel, se debe abrir un diálogo para guardar la configuración del Excel que se debe guardar en la tabla T_INTC_MARKETSHARE_EXCEL

Subir Excel para procesar con la siguiente lógica:

El archivo debe guardarse en la tabla de FILES.T_APEX_ARCHIVO;

Validar que sea archivo Excel.

Puede subir más de un archivo.

Crear un proceso para leer los archivos Excel y guardarlos en la tabla T_INTC_MARKETSHARE.

Borrar los datos de la tabla T_INTC_MARKETSHARE con el rango de fecha de los archivos Excel.

El proceso debe tomar la configuración de la tabla T_INTC_MARKETSHARE_EXCEL para identificar los valores.

En el caso de que no tenga fecha, se debe colocar la fecha de inicio del mes actual.

Debe guardar la fecha de carga y el error en el caso de que exista.

Lógica para leer Excel:

DECLARE

l_blob   BLOB;

BEGIN

-- Obtener el archivo desde la tabla

SELECT blobcontent

INTO l_blob

FROM files.t_apex_archivos

WHERE numeroarchivo = 1030471;

-- Utilizar FOR para iterar las filas sin declarar t_parser ni t_data

FOR fila IN (

SELECT *

FROM apex_data_parser.parse(

p_content   => l_blob,

p_file_name => 'archivo.xlsx'

)

) LOOP

-- Mostrar en debug o insertar

-- DBMS_OUTPUT.put_line('Columna 2: ' || l_row(2).value);

DBMS_OUTPUT.put_line('Fila:' || fila.col001||' - '|| fila.col002||' - '|| fila.col003);

--- FOR PARA VER LOS CAMPOS MAPEAOS

--- V_CAMPOS  T_CORP_MAPEO_EXCEL_DET.CAMPO

---V_COLUMNAS  col00||T_CORP_MAPEO_EXCEL_DET.COLUMNAS

INSERT   ||T_CORP_MAPEO_EXCEL.TABLA|| '  '|| V_CAMPOS

SELECT V_COLUMNAS FROM

END LOOP;

END;

begin PK_CORP_MAPEO_EXCEL.SP_PROCESAR_MAPEO_EXCEL(P_TABLA_PROCESO => 'T_INTC_MARKETSHARE_PROVEEDOR',P_ID_TABLA_PROCESO => 61,

P_TABLA_DESTINO => 'T_INTC_MARKETSHARE', P_TIPO => 'EXCEL'); end;

Borrar archivo Excel

Identificar el idcompetencia  con el texto que viene en el Excel y llenar el campo IdentificarCompetencia.

Se puede identificar con los textos guardados en la columna "Identificadores "

Por el código de barras del producto.

En el caso de que exista competencia sin identificar, mostrar el icono  , que realiza lo siguiente:

Mostrar una pantalla de las competencias que no están identificadas. El usuario podrá seleccionar una empresa para agregar el registro en Identificadores T_INTC_COMPETENCIA_EMPRESA y

Actualizar el idcompetencia de la tabla T_INTC_MARKETSHARE .

Una vez que se identifiquen todas las competencias, debe cambiar la bandera.

Ejecutar el proceso para mostrar los productos sin identificar.

El usuario puedo decidir que la empresa no la quiere homologar

Identificar el codigobarra/codigoproductoproveedor   que exista en la tabla T_INTC_COMPETENCIA_PRODUCTO  y llenar el campo IdentificarProducto.

En el caso de que existan productos sin identificar, mostrar el icono. , que realice lo siguiente:

Mostrar en una pantalla los productos que no se pudieron identificar. Estos registros deben tener empresa competidora.

Estos productos se deben guardar en la tabla T_INTC_COMPETENCIA_PRODUCTO llenando los valores.

Importaciones

Crear una pagina donde muestre los proveedores de Tipo ->  Importaciones

los botones deben funcionar igual que la pantalla de proveedores sin realizar el proceso de idcompetencia y producto

Crea un boton para subir homologocacion de forma masiva donde el usuario sube un excel donde pone descripcion y codigo de barra.

PS <LOCAL_SHELL> $excel = New-Object -ComObject Excel.Application

PS <LOCAL_SHELL> $excel.Visible = $false

PS <LOCAL_SHELL> $excel.DisplayAlerts = $false

PS <LOCAL_SHELL> $workbook = $excel.Workbooks.Open("<LOCAL_SOURCE>/market share favorita jul 2025 (1) - copia.csv")

PS <LOCAL_SHELL> $workbook.SaveAs("<LOCAL_SOURCE>/market share favorita jul 2025 (1) - copia2.csv", 6)

PS <LOCAL_SHELL> $workbook.Close()

PS <LOCAL_SHELL> $excel.Quit()

PS <LOCAL_SHELL>

Reportes

Crear los siguientes reportes:

T_INTC_MARKETSHARE

T_INTC_IMPORTACIONES

RPA (headless -> chrome web driver ->SimulateClick y SimulateType para entradas de usuario  )

Se  usara uipath community edition para descargar los archivos excel de cada proveedor:

Corporación Favorita

Corporación El Rosado

Mega SantaMaria

IQVIA

IMPORTACIONES PT Y MP

En el caso que el portal se necesite doble autenticación, se ejecutaran desde el equipo del usuario para que genere la autenticación

ETL

Crear el JOBS "Comercial_MarketShare" para leer las tablas del Creadas en el proyecto, la tablas que se van a procesar son:

T_INTC_MARKETSHARE

T_INTC_IMPORTACIONES

T_INTC_COMPETENCIA_EMPRESA

T_INTC_COMPETENCIA_PRODUCTO

