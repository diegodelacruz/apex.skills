# Patron de redaccion de AD

Usa este archivo para transformar ejemplos historicos en reglas practicas de redaccion. No reemplaza las reglas metodologicas del skill; las refuerza con criterios de estilo.

## Objetivo

Lograr que el `AD` final quede con:

- `Resumen ejecutivo` breve, ejecutivo y funcional.
- `Definicion` tecnica, concreta y ejecutable.
- Trazabilidad clara con el alcance aprobado.
- Redaccion natural, sin checklist mecanico ni narrativa vaga.

## Patron para Resumen ejecutivo

- Cada punto debe expresar una capacidad funcional o una mejora visible del proyecto.
- La redaccion debe sonar a resultado de solucion, no a marketing ni a minuta tecnica.
- Cada punto debe ser breve y entendible para gerencia, cliente y usuario no tecnico.
- No conviertas el resumen en lista de beneficios abstractos como `mayor eficiencia`, `mejor control`, `optimizacion del proceso` si no dices que se construye o mejora.
- No conviertas el resumen en lista de tareas tecnicas como `crear tabla`, `ajustar paquete`, `modificar pagina`.
- Cuando un frente es segregado, en el resumen solo deja claro que existe la dependencia y el resultado funcional esperado; no desarrolles detalle tecnico ahi.

## Patron para Definicion

- Cada bloque principal debe seguir la secuencia del alcance aprobado.
- Cada subpunto debe iniciar con un titulo y una frase corta que diga como quedara la solucion.
- La frase inicial debe sonar a definicion de solucion, no a objetivo metodologico ni a promesa vaga.
- Despues de la frase inicial, usa pasos tecnicos en orden real de construccion.
- Agrupa acciones por fase tecnica: referencia actual, base de datos, logica de negocio, APEX o interfaz, validacion final.
- Usa menos pasos, pero mas completos.
- Cada paso debe nombrar objetos concretos y el cambio exacto.
- Si existe cobertura previa, declarala de forma expresa dentro del bloque que corresponde.
- Si existe una dependencia externa con ajuste tecnico conocido, nombrala y define su alcance real; no la reduzcas a exclusion generica.

## Aperturas prohibidas y reemplazos

- Incorrecto: `Se separaran el mantenimiento de observacion y la publicacion del cliente origen en dos frentes tecnicos distintos del mismo bloque.`
- Correcto: `Se incorporaran ajustes en la gestion de RUCs para registrar observaciones en la atencion del caso y mostrar el cliente ZM que origina cada RUC pendiente.`
- Incorrecto: `Se ampliara la trazabilidad operativa del frente RUC.`
- Correcto: `Se habilitara el registro de observaciones en la atencion del RUC y la visualizacion del cliente origen en la bandeja de pendientes.`
- Incorrecto: `Se consolidara el frente geografico sobre la estructura vigente del maestro.`
- Correcto: `Pagina 502 incorporara una nueva seccion para mantener niveles geograficos sobre T_CORP_UDC y permitir actualizacion individual o masiva.`
- Incorrecto: `Se reconocera como cobertura previa el patron de control de errores ya implementado.`
- Correcto: `El control base de errores ya existe en el modulo y este alcance lo extiende hacia Inventarios, locales por identificar y reproceso historico.`

Usa estos reemplazos como patron: la apertura debe describir la solucion real, no el acomodo del texto ni la metodologia aplicada.

## Lo que si debes copiar de los ejemplos

- De `ejemplo2`: aterrizaje de objetos reales, dependencias concretas y tono tecnico fuerte.
- De `ejemplo3`: tono ejecutivo y capacidad de resumir frentes funcionales sin bajar al detalle tecnico.
- De `ejemplo4`: granularidad funcional cuando hace falta documentar pantallas, parametros o reglas operativas.
- De `ejemplo1`: inventario concreto de objetos cuando el analisis requiera bajar a tablas, columnas o estructuras de datos.

## Lo que no debes copiar de los ejemplos

- Listas largas de microacciones que conviertan la `Definicion` en checklist.
- Bloques donde el documento hable de si mismo, por ejemplo `en el presente AD`.
- Beneficios abstractos sin aterrizaje funcional.
- Exclusiones genericas que escondan detalle tecnico ya conocido.
- Especificaciones crudas de tablas o campos usadas como si fueran redaccion final del `AD`.

## Anti-patrones que debes corregir antes de cerrar

- `Resumen ejecutivo` escrito como lista de slogans.
- `Definicion` escrita como secuencia mecanica de `Revisar`, `Crear`, `Modificar`, `Validar` en pasos muy cortos.
- Bloques sin frase inicial corta.
- Dependencias externas reducidas a `queda fuera de alcance` cuando ya existe logica, job, API o proceso identificado.
- Redaccion que omite paginas, objetos o componentes concretos aun cuando ya fueron confirmados.
- Redaccion que mezcla varias tecnologias en un mismo bloque sin separar frentes.
- Aperturas que describen el bloque en lugar de la solucion, por ejemplo `se separaran ... en dos frentes`, `se consolidara el frente`, `se ampliara la trazabilidad` o `se reconocera como cobertura previa`.

## Regla de cierre

Antes de cerrar un `AD`, revisa cada bloque y responde internamente:

1. El `Resumen ejecutivo` dice que mejora o construye cada frente sin caer en tecnicismo ni abstraccion vacia.
2. La `Definicion` se lee como plan de construccion y no como lista de tickets.
3. Los ejemplos se usaron como patron de estilo y no como fuente para copiar texto.
4. El documento mantiene trazabilidad por orden y contenido con el alcance aprobado.
5. Ninguna apertura relevante suena a metodologia explicando bloques; todas describen cambios reales en la solucion.
