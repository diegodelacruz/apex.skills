# AUTOMATIZACIÓN DE EXTRACCIÓN Y GENERACIÓN DE BASES BI PARA TABLERO DE ECOMMERCE

Fuente original: `<EXAMPLE_SOURCE>/documento_fuente.docx`

## Texto extraido

Se realizarán los siguientes puntos:

1. APIs disponibles en las plataformas del Grupo Zaimella

Se realizará un levantamiento completo de las APIs disponibles en las plataformas digitales del Grupo Zaimella, identificando todas las fuentes de información relacionadas con Ecommerce. Este análisis permitirá conocer qué datos pueden ser extraídos de forma automática y cómo aprovecharlos de manera integral.

2. Clasificación y estandarización del tipo de información

La información obtenida de las plataformas será organizada y clasificada por dominios de negocio, estandarizando los indicadores clave para asegurar consistencia, comparabilidad y una visión unificada del desempeño del canal Ecommerce.

3. Diseño de la Base de Datos Ecommerce

Se diseñará una base de datos Ecommerce que consolide la información transaccional y maestra de forma estructurada y escalable, sentando una base sólida para el análisis, control y crecimiento del negocio digital.

4. Configuración de Acceso a APIs

Se definirán los mecanismos necesarios para la configuración y administración segura de accesos a las plataformas, garantizando la correcta autenticación, el control de permisos y la continuidad operativa de las integraciones.

5. Diseño del módulo en Oracle APEX para consumir APIs

Se desarrollará un módulo en Oracle APEX que permita administrar las integraciones, automatizar la ejecución de las APIs, monitorear las cargas de información y visualizar los datos operativos del Ecommerce de forma controlada.

6. Desarrollo de los Jobs y ETL en AWS

Se implementará un proceso automatizado en la nube para trasladar y preparar la información de Ecommerce para su análisis, asegurando actualización periódica, confiabilidad de los datos y disponibilidad para herramientas de visualización como Power BI.

A continuación, se detalla cada uno de los puntos descritos, especificando las actividades, configuraciones y entregables que se realizarán dentro del proyecto.

1. APIs disponibles en las plataformas del Grupo Zaimella

En esta sección se detallan todas las APIs que ofrecen las plataformas, considerando únicamente aquellas utilizadas para extraer información. Se incluyen APIs que entregan datos claves para ventas, publicidad, inventario, productos, marketing y clientes, incluso si no aportan directamente los KPIs definidos en el proyecto. Toda esta información servirá como base para construir el catálogo oficial de APIs, definir el módulo de consumo en APEX y diseñar la base de datos Ecommerce en AWS.

Al revisar cada plataforma, es importante distinguir el tipo de fuente de información, ya que esto afecta la forma en que los datos se procesan y cómo se construyen los KPIs:

API estándar

Son APIs que entregan datos detallados tal como ocurren en la plataforma: pedidos, productos, inventario, clientes, campañas, entre otros. Estos datos permiten calcular internamente la mayoría de KPIs y son ideales para procesos automáticos y actualizaciones frecuentes.

Reporte configurado o reporte vía API

Son APIs que devuelven reportes ya procesados por la plataforma, como métricas de tráfico, conversiones atribuidas, CTR, CPC, ROAS o vistas de producto. Estos reportes contienen cálculos que no pueden reconstruirse a partir de datos crudos, por lo que son esenciales para ciertos KPIs establecidos en el proyecto.

2. Clasificación y estandarización del tipo de información

Definición de los Dominios de Información Ecommerce

La información proveniente de Amazon, Shopify, Meta Ads, Google Ads, Klaviyo, Criteo y las plataformas de Customer Service con API pública (Gorgias, PayPal, ShipMonk, Yotpo, Judge.me, Stamped.io, Recharge) se organiza en los siguientes dominios funcionales, que representan las áreas clave del análisis:

Ventas: Información transaccional sobre pedidos, ventas brutas, ventas netas, unidades y descuentos.

Clientes: Identificación y comportamiento de clientes nuevos, recurrentes y new-to-brand.

Tráfico: Información de sesiones, vistas de página, visitas de tienda o blog.

Conversiones: Indicadores de eficiencia como la tasa de conversión, sesiones convertidas y métricas derivadas.

Publicidad: Datos de rendimiento publicitario como impresiones, clics, CTR, CPC, CPA, ROAS y alcance.

Marketing: Métricas de email marketing relacionadas con aperturas, clics y revenue atribuido.

Inventario / Oferta destacada: Stock, unidades reembolsadas y participación en la Buy Box.

Engagement Externo: Interacciones fuera del sitio, como visitas a tienda física o exposición a campañas.

Customer Service (Soporte): Tickets, estados, SLA, tiempos de primera respuesta y resolución, productividad y CSAT (cuando aplique).

Postventa (Disputas y logística): Disputas/contracargos, reembolsos, devoluciones, tracking e incidencias logísticas.

Reputación (Reseñas): Reseñas, calificaciones (rating), volumen y tendencias por producto/periodo.

Agrupación de KPIs por Dominio

Toda la información recopilada se clasifica en 11 dominios principales dentro del modelo Ecommerce:

3. Diseño de la Base de Datos Ecommerce

T_ECOMMERCE_API_CONFIG: Tabla maestra de configuración de cada API/Reporte a consumir, incluyendo credenciales, parámetros clave y tablas destino.

Reglas de operación por tipo_transaccion:

MAESTRO (UPSERT):

El proceso consulta columna_identificador

Si no existe → INSERT

Si existe → UPDATE

TRANSACCIONAL (REPROCESO POR VENTANA):

Se calcula ventana: desde (hoy - meses_busqueda) hasta hoy

Se elimina en destino: DELETE FROM tabla_destino WHERE columna_fecha_control BETWEEN desde AND hoy

Se vuelve a insertar lo obtenido desde la API en ese rango

T_ECOMMERCE_API_MAPEO:  Define la relación campo JSON/API → columna base de datos, permitiendo insertar dinámicamente sin hardcode.

T_ECOMMERCE_LOTE_CARGA: Control y auditoría de cada ejecución de extracción/carga (batch), para trazabilidad, reproceso y seguimiento de errores.

T_ECOMMERCE_VENTAS_PEDIDO: Cabecera de pedidos (1 registro por pedido). Base para KPIs de órdenes y ventas a nivel pedido.

T_ECOMMERCE_VENTAS_DETALLE: Detalle del pedido (líneas de pedido). Base para KPIs de unidades, ventas por producto, devoluciones por item.

T_ECOMMERCE_PUBLICIDAD_METRICAS: Métricas de publicidad por fecha y campaña (y opcionalmente por conjunto/anuncio). Base para KPIs de Ads.

T_ECOMMERCE_TRAFICO_CONVERSION: Tráfico y conversión por fecha (y opcional por producto). Base para Sessions, Page Views, CVR, etc.

T_ECOMMERCE_MARKETING_EMAIL: Métricas de email marketing por fecha y campaña (Klaviyo). Base para aperturas, clics, revenue atribuido.

T_ECOMMERCE_CLIENTES: Registro/snapshot de métricas de clientes por plataforma y fecha. Base para Total Customers, Repeat Customers y New-to-Brand.

T_ECOMMERCE_PRODUCTOS: Catálogo estandarizado por plataforma para SKU/ASIN, nombre, categoría y precio lista.

T_ECOMMERCE_INVENTARIO:  Inventario por SKU y ubicación en una fecha determinada. Base para stock disponible y niveles críticos.

T_ECOMMERCE_CS_TICKET: Tickets/casos de soporte (estado, prioridad, canal, fechas clave, relación con cliente/orden).

T_ECOMMERCE_CS_TICKET_INTERACCION: Eventos e interacciones del ticket (mensajes, cambios de estado, asignaciones) para trazabilidad y cálculo de tiempos reales.

T_ECOMMERCE_CS_SATISFACCION: Resultados de CSAT asociados a tickets (puntaje, comentario, fecha).

T_ECOMMERCE_POSTVENTA_DISPUTA: Disputas/contracargos (estado, montos, motivo, resultado, fechas).

T_ECOMMERCE_LOGISTICA_ENVIO: Envíos y tracking (transportista, código seguimiento, estado, fechas, incidencias).

T_ECOMMERCE_POSTVENTA_DEVOLUCION: Devoluciones (motivo, estado, cantidades/valores, fechas).

T_ECOMMERCE_REPUTACION_REVIEW: Reseñas/ratings (calificación, comentario, estado, fecha, SKU).

4. Configuración de Acceso a APIs

En este punto se define qué APIs deben configurarse por plataforma, qué credenciales son obligatorias y qué tablas transaccionales se alimentan, de manera que la extracción de información pueda realizarse de forma automatizada desde Oracle APEX.

Cada API o reporte se registra en la tabla T_ECOMMERCE_API_CONFIG, y la relación entre los campos del API y las columnas de la base de datos se define en T_ECOMMERCE_API_MAPEO.Si una misma API alimenta más de una tabla, se deberá registrar una configuración independiente por cada tabla destino.

Amazon (Seller Central – SP-API)

Tipo de autenticación: OAuth 2.0 + firma AWS (SigV4)

Credenciales obligatorias a configurar:

Client ID

Client Secret

Refresh Token

Access Key

Secret Key

Role ARN (si aplica)

APIs / Reportes que se deben configurar:

Amazon SP-API – Orders API

Tabla destino:

T_ECOMMERCE_VENTAS_PEDIDO

T_ECOMMERCE_VENTAS_DETALLE

Tipo de transacción: TRANSACCIONAL

Columna de control de fecha: fecha_pedido

Ventana de reproceso: meses hacia atrás configurables (1, 2 o 3)

Amazon SP-API – Reportes de negocio y tráfico

Tabla destino:

T_ECOMMERCE_TRAFICO_CONVERSION

T_ECOMMERCE_CLIENTES

Tipo de transacción: TRANSACCIONAL

Columna de control de fecha: fecha del reporte

Ventana de reproceso: meses hacia atrás configurables

3. Amazon - Inventory API (SP-API)

Tabla destino:

T_ECOMMERCE_INVENTARIO

Tipo de transaccion: TRANSACCIONAL

Columna de control de fecha: fecha

Ventana de reproceso: meses hacia atrás configurables

Para Amazon, los KPIs de tráfico, Buy Box y New-To-Brand se obtienen mediante reportes configurados dentro de la plataforma.

Shopify

Tipo de autenticación: Access Token (App privada o personalizada)

Credenciales obligatorias a configurar:

Access Token

URL base de la tienda

APIs que se deben configurar:

Shopify – Orders API

Tabla destino:

T_ECOMMERCE_VENTAS_PEDIDO

T_ECOMMERCE_VENTAS_DETALLE

Tipo de transacción: TRANSACCIONAL

Columna de control de fecha: fecha_pedido

Ventana de reproceso: meses hacia atrás configurables

Shopify – Products API

Tabla destino: T_ECOMMERCE_PRODUCTOS

Tipo de transacción: MAESTRO

Columna identificador: sku

Shopify – Inventory API

Tabla destino: T_ECOMMERCE_INVENTARIO

Tipo de transacción: TRANSACCIONAL

Columna de control de fecha: fecha

Shopify – Customers API

Tabla destino: T_ECOMMERCE_CLIENTES

Tipo de transacción: MAESTRO

Columna identificador: id_cliente_plataforma

Meta Ads (Facebook Marketing API)

Tipo de autenticación: OAuth 2.0 (Bearer Token)

Credenciales obligatorias a configurar:

Access Token

ID de cuenta publicitaria

APIs que se deben configurar:

Meta Ads – Insights API

Tabla destino:

T_ECOMMERCE_PUBLICIDAD_METRICAS

Tipo de transacción: TRANSACCIONAL

Columna de control de fecha: fecha

Ventana de reproceso: meses hacia atrás configurables

2. Meta Ads - Campaign API

Tabla destino:

T_ECOMMERCE_PUBLICIDAD_CAMPANIA

Tipo de transaccion: MAESTRO

Columna identificador: id_compania_plataforma

Google Ads

Tipo de autenticación: OAuth 2.0 + Developer Token

Credenciales obligatorias a configurar:

Client ID

Client Secret

Refresh Token

Developer Token

Customer ID

APIs que se deben configurar:

Google Ads – Reportes vía GAQL

Tabla destino: T_ECOMMERCE_PUBLICIDAD_METRICAS

Tipo de transacción: TRANSACCIONAL

Columna de control de fecha: fecha

Ventana de reproceso: meses hacia atrás configurables

Klaviyo

Tipo de autenticación: API Key privada (Bearer)

Credenciales obligatorias a configurar:

API Key

URL base

APIs que se deben configurar:

Klaviyo – Métricas de campañas de email

Tabla destino: T_ECOMMERCE_MARKETING_EMAIL

Tipo de transacción: TRANSACCIONAL

Columna de control de fecha: fecha

Ventana de reproceso: meses hacia atrás configurables

Klaviyo – Profiles (Clientes)

Tabla destino: T_ECOMMERCE_CLIENTES

Tipo de transacción: MAESTRO

Columna identificador: id_cliente_plataforma

Criteo

Tipo de autenticación: OAuth 2.0 (Client Credentials)

Credenciales obligatorias a configurar:

Client ID

Client Secret

APIs / Reportes que se deben configurar:

Criteo – Reportes de performance publicitario

Tabla destino: T_ECOMMERCE_PUBLICIDAD_METRICAS

Tipo de transacción: TRANSACCIONAL

Columna de control de fecha: fecha

Ventana de reproceso: meses hacia atrás configurables

Gorgias

Tipo de autenticacion: API Key (Basic/Bearer segun configuracion de cuenta)

Credenciales obligatorias a configurar.

API Key

URL base / subdominio

APIs que se deben configurar:

1. Gorgias - Tickets API

Tabla destino:

T_ECOMMERCE_CS_TICKET

Tipo de transacción: TRANSACCIONAL

Columna de control de fecha: fecha_creacion

Ventana de reproceso: meses hacia atrás configurables

2. Gorgias - Events/Messages API (interacciones)

Tabla destino:

T_ECOMMERCE_CS_TICKET_INTERACCION

Tipo de transacción: TRANSACCIONAL

Columna de control de fecha: fecha_interaccion

Ventana de reproceso: meses hacia atrás configurables

3. Gorgias - Satisfaction/CSAT (si aplica)

Tabla destino:

T_ECOMMERCE_CS_SATISFACCION

Tipo de transacción: TRANSACCIONAL

Columna de control de fecha: fecha_respuesta

Ventana de reproceso: meses hacia atrás configurables

PayPal

Tipo de autenticacion: OAuth 2.0 (Client Credentials)

Credenciales obligatorias a configurar.

Client ID

Client Secret

Ambiente (Sandbox/Producción)

APIs que se deben configurar:

1. PayPal - Disputes API

Tabla destino:

T_ECOMMERCE_POSTVENTA_DISPUTA

Tipo de transacción: TRANSACCIONAL

Columna de control de fecha: fecha_apertura

Ventana de reproceso: meses hacia atrás configurables

ShipMonk

Tipo de autenticación: API Key

Credenciales obligatorias a configurar.

API Key

URL base

APIs que se deben configurar:

1. ShipMonk - Shipments/Tracking API

Tabla destino:

T_ECOMMERCE_LOGISTICA_ENVIO

Tipo de transacción: TRANSACCIONAL

Columna de control de fecha: fecha_creacion_envio

Ventana de reproceso: meses hacia atrás configurables

2. ShipMonk - Returns API (devoluciones)

Tabla destino:

T_ECOMMERCE_POSTVENTA_DEVOLUCION

Tipo de transaccion: TRANSACCIONAL

Columna de control de fecha: fecha_solicitud

Ventana de reproceso: meses hacia atras configurables

3. ShipMonk - Inventory API (si se requiere)

Tabla destino:

T_ECOMMERCE_INVENTARIO

Tipo de transaccion: TRANSACCIONAL

Columna de control de fecha: fecha

Ventana de reproceso: meses hacia atras configurables

Recharge

Tipo de autenticación: API Token

Credenciales obligatorias a configurar.

Access Token

URL base

APIs que se deben configurar:

1. Recharge - Customers API

Tabla destino:

T_ECOMMERCE_CLIENTES

Tipo de transacción: MAESTRO

Columna identificador: id_cliente_plataforma

2. Recharge - Subscriptions API

Tabla destino:

T_ECOMMERCE_CLIENTES

Tipo de transacción: MAESTRO

Columna identificador: id_cliente_plataforma

Yotpo

Tipo de autenticacion: API Keys (según endpoints habilitados)

Credenciales obligatorias a configurar.

App Key

Secret Key / Token

APIs que se deben configurar:

1. Yotpo - Reviews API

Tabla destino:

T_ECOMMERCE_REPUTACION_REVIEW

Tipo de transacción: TRANSACCIONAL

Columna de control de fecha: fecha_publicacion

Ventana de reproceso: meses hacia atrás configurables

Judge.me

Tipo de autenticación: Private API Token

Credenciales obligatorias a configurar.

API Token

URL base / tienda

APIs que se deben configurar:

1. Judge.me - Reviews API

Tabla destino:

T_ECOMMERCE_REPUTACION_REVIEW

Tipo de transacción: TRANSACCIONAL

Columna de control de fecha: fecha_publicacion

Ventana de reproceso: meses hacia atrás configurables

Stamped.io

Tipo de autenticación: API Keys (Public/Private)

Credenciales obligatorias a configurar.

Public Key

Private Key

Store ID / Store Hash (si aplica)

APIs que se deben configurar:

1. Stamped.io - Reviews API

Tabla destino:

T_ECOMMERCE_REPUTACION_REVIEW

Tipo de transacción: TRANSACCIONAL

Columna de control de fecha: fecha_publicacion

Ventana de reproceso: meses hacia atrás configurables

Toda API o reporte debe registrarse obligatoriamente en la tabla T_ECOMMERCE_API_CONFIG, y la relación entre los campos del origen y las columnas de la base de datos debe definirse en T_ECOMMERCE_API_MAPEO, sin excepciones. Cuando una misma API alimenta más de una tabla, deberá registrarse una configuración independiente por cada tabla destino. Cada integración deberá clasificarse como MAESTRO o TRANSACCIONAL: en el caso de MAESTRO, el proceso validará la existencia del registro mediante una columna identificadora para insertar o actualizar según corresponda; en el caso TRANSACCIONAL, el proceso eliminará e insertará nuevamente la información dentro de una ventana temporal definida por una columna de control de fecha y un número de meses hacia atrás configurable. No se permitirá lógica hardcodeada ni desarrollos específicos por API, garantizando que toda la extracción y carga de información sea completamente parametrizable, escalable y reutilizable desde Oracle APEX.

5. Diseño del módulo en APEX para consumir APIs

Este módulo en APEX permitirá parametrizar, ejecutar y auditar la extracción de datos desde APIs de Ecommerce hacia las tablas transaccionales T_ECOMMERCE_*, sin necesidad de desarrollo adicional por cada nuevo endpoint, utilizando las tablas de configuración T_ECOMMERCE_API_CONFIG y T_ECOMMERCE_API_MAPEO, y registrando cada ejecución en T_ECOMMERCE_LOTE_CARGA.

Configuración de APIs

Se implementarán listas de valores obligatorias para estandarizar la parametrización:

Plataforma: Amazon, Shopify, Meta Ads, Google Ads, Klaviyo, Criteo

Tabla destino: lista basada en tablas T_ECOMMERCE_* habilitadas para carga

Frecuencia de ejecución: DIARIA, SEMANAL, QUINCENAL, MENSUAL

Tipo de transacción: MAESTRO, TRANSACCIONAL

Estado: ACTIVO, INACTIVO

Pantalla  – Administración de Configuración de APIs

Administrar de forma centralizada las configuraciones de APIs y reportes, su mapeo de campos y el control de ejecuciones.

Tabla:T_ECOMMERCE_API_CONFIG

La pantalla presentará un listado (Interactive Report o Interactive Grid) con todas las configuraciones registradas y permitirá:

Crear nuevas configuraciones de API

Adjuntar el json

Editar la cabecera de configuración (credenciales, frecuencia, tabla destino, tipo de transacción)

Activar o inactivar configuraciones

Ejecutar la API bajo demanda, mediante un botón que invoque inmediatamente el proceso de extracción usando la configuración registrada, sin depender del job automático

Acceder al detalle de mapeo de campos mediante un diálogo modal, que permite mantener los registros de T_ECOMMERCE_API_MAPEO

Consultar el historial de ejecuciones mediante un diálogo modal que muestra los registros de T_ECOMMERCE_LOTE_CARGA

La pantalla validará obligatoriamente que:

Para transacciones MAESTRO exista una columna identificadora.

Para transacciones TRANSACCIONAL exista columna de fecha de control y meses de búsqueda.

Exista un correo configurado para notificación de errores.

Pantalla – Reportes de información cargadaEsta pantalla permitirá visualizar la información almacenada en todas las tablas T_ECOMMERCE_* mediante pestañas o subpáginas independientes, incluyendo ventas, detalle de pedidos, publicidad, tráfico, marketing, clientes, productos e inventario.

Para tablas transaccionales se incluirá un filtro obligatorio por rango de fechas, mientras que para tablas maestras se habilitarán filtros por plataforma,.

Proceso automático diario de extracción

Se implementará un job que se ejecuta diariamente y evalúa las configuraciones activas en T_ECOMMERCE_API_CONFIG para determinar qué integraciones deben ejecutarse según su frecuencia (diaria, semanal, quincenal o mensual). Para cada API habilitada, el proceso seguirá la siguiente secuencia:

Selección de configuraciones a ejecutar: Se consultan las configuraciones con estado='ACTIVO' y se valida si la frecuencia corresponde al día actual (diaria: todos los días; semanal: día configurado; quincenal: día 15; mensual: día 1). Solo las configuraciones que cumplen la condición pasan a ejecución.

Creación e inicio del lote de auditoría: Antes de llamar al API se crea un registro en T_ECOMMERCE_LOTE_CARGA con estado PENDIENTE, registrando plataforma, nombre_api, tipo_fuente, fecha de inicio y el identificador de configuración. Este lote se actualizará durante toda la ejecución.

Preparación de credenciales y request: El proceso arma la llamada usando la configuración (URL, endpoint, método, headers, credenciales). Si la plataforma requiere token, valida vigencia, renueva si aplica y registra la actualización del token en la configuración.

Ejecución del API y obtención del JSON: Se realiza la llamada y se obtiene la respuesta JSON. Si la respuesta es inválida, vacía o con error HTTP, se registra el fallo en auditoría indicando el paso exacto.

Construcción dinámica del cargue por mapeo: Se consulta T_ECOMMERCE_API_MAPEO para construir dinámicamente el insert/update, resolviendo campos origen → columnas destino, conversiones de tipo y valores por defecto (plataforma, fecha_carga, id_lote, etc.).

Ejecución de carga según tipo de transacción

MAESTRO: se ejecuta UPSERT por columna_identificador, contabilizando cuántos registros fueron insertados y cuántos fueron actualizados.

TRANSACCIONAL: se calcula la ventana desde hoy menos meses_busqueda hasta hoy, se eliminan los registros de esa ventana (contabilizando los eliminados) y luego se insertan nuevamente los registros retornados por la API (contabilizando los insertados).

Cierre del lote con métricas de auditoría: Al finalizar, se actualiza T_ECOMMERCE_LOTE_CARGA con:

Estado final (EXITOSO o ERROR)

Fecha fin de extracción

Cantidad de registros insertados, actualizados y eliminados

Mensaje de error (si aplica)

Gestión de errores con detalle de paso: Cuando ocurra un error, el proceso debe registrar un mensaje claro que incluya:

Paso donde falló (ej: "Paso 4: ejecución del API")

Detalle del error técnico (HTTP code, timeout, conversión, SQL, token, etc.)

Identificador de API y lote asociado Además, se enviará notificación al correo configurado en T_ECOMMERCE_API_CONFIG.

6. Desarrollo de los Jobs y ETL en AWS

Creación de base de datos Ecommerce en S3 y catálogo

En AWS se debe crear una nueva base de datos de Analytics para Ecommerce, con su estructura en S3 y su exposición en Glue/Athena con el nombre ecommerce. Dentro de esta base se deben publicar las siguientes tablas de consumo:

Tablas Ecommerce

VENTAS

PUBLICIDAD_METRICAS

TRAFICO_CONVERSION

MARKETING_EMAIL

INVENTARIO

CLIENTES

PRODUCTOS

Tablas Customer Service

CS_TICKET

CS_TICKET_INTERACCION

CS_SATISFACCION

POSTVENTA_DISPUTA

LOGISTICA_ENVIO

POSTVENTA_DEVOLUCION

REPUTACION_REVIEW

La data se almacenará en S3 bajo una estructura estándar por tabla, separando ambientes:

TEST: ruta en el bucket de test (ya existente)

PROD: ruta en el bucket productivo bajo carpeta Ecommerce/

Desarrollo de Jobs Glue por tabla (TEST_JOB → JOB)

Se debe construir un Job por tabla, siguiendo el patrón de nomenclatura:

TEST_JOB_ECOMMERCE_<TABLA> (ambiente test)

JOB_ECOMMERCE_<TABLA> (ambiente producción)

Cada Job debe leer desde Oracle (APEX) las tablas T_ECOMMERCE_* y escribir en S3 para ser consumido por Glue/Athena. La diferencia entre TEST y PROD se debe controlar por parámetros (conexión Oracle / destino S3 / base de datos Glue), de forma que el mismo diseño se replique en ambos ambientes.

Se realizará con las siguientes reglas:

a) Tablas transaccionales (VENTAS, PUBLICIDAD_METRICAS, TRAFICO_CONVERSION, MARKETING_EMAIL, INVENTARIO, CLIENTES si aplica como snapshot)

El Job debe leer primero los registros de los últimos 2 meses desde Oracle.

Solo si la lectura finaliza sin error (validación de extracción exitosa), se procede a:

eliminar en destino (S3/Athena) la ventana de esos mismos 2 meses, e

insertar / escribir nuevamente la data leída.

Esto evita el problema actual de "borrar primero y luego fallar al leer", dejando la tabla destino vacía.

Particionado obligatorio:

Las tablas transaccionales deben almacenarse particionadas por año y mes, por ejemplo:

anio=2026/mes=01/

El Job debe escribir respetando esa estructura para performance en Athena y Power BI.

b) Tablas maestras (PRODUCTOS y cualquier maestro adicional)

No se re procesan por ventana de meses.

Deben manejar lógica tipo UPSERT: insertar nuevos registros y actualizar los existentes.

La llave de comparación debe incluir plataforma + identificador (por ejemplo idproducto o sku, idcliente según corresponda).

El script del Job debe estar ordenado y documentado, separando claramente:

parámetros de entrada

conexión y extracción

validaciones

transformación / normalización

escritura en S3

manejo de errores y logs

Creación y ejecución de Crawlers (Glue Catalog)

Se deben crear y ejecutar Crawlers para construir el catálogo de datos de la base ecommerce en Glue, garantizando que:

las tablas queden creadas con su esquema

se detecten correctamente las particiones (anio/mes)

se mantenga consistencia de nombres y tipos de datos para Athena/Power BI

Creación de Workflow de ejecución

Se debe crear un Workflow en AWS Glue para orquestar la ejecución completa, que ejecute todos los Jobs JOB_ECOMMERCE_*

