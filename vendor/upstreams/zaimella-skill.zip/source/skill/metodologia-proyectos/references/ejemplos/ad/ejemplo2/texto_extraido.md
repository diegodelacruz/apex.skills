# REDISEÑO DE LA ARQUITECTURA DE DATOS - BI COMERCIAL

Fuente original: `<EXAMPLE_SOURCE>/documento_fuente.docx`

## Texto extraido

1) Estándares ETL en AWS Glue

Se define una forma única y obligatoria de ejecutar las cargas de datos para asegurar continuidad y evitar que, ante un error, queden tablas sin información. Se realizará la modificación de todos los procesos de carga existentes dentro del alcance para que trabajen bajo este estándar. La actualización incluirá cargar solo lo necesario por periodos recientes, controlar cuándo se reemplaza información, validar resultados antes de publicar y registrar evidencias de cada ejecución (qué se cargó, cuánto se cargó, si falló y por qué). Con esto, los procesos quedarán uniformes, controlados y con trazabilidad.

2) Estándares de modelado de datos

Se define un estándar de estructura para las tablas que se usan en BI, de manera que todos los datos tengan nombres consistentes, tipos de datos uniformes y campos mínimos de control. Se define qué tablas forman parte del alcance, cuáles se mantienen y cuáles se ajustan para alinearse al estándar. Se define y se realizará la unificación de la información de ventas en una sola estructura final, con campos homologados, para que los reportes consuman una única fuente consistente.

3) Sellout: rediseño

Se define una nueva forma de generar Sellout para que sea más estable y menos dependiente de procesos frágiles o lentos. Se realizará el traslado de la lógica principal hacia un proceso de carga y consolidación más controlado, asegurando que el histórico se conserve de forma ordenada y que la parte operativa se mantenga liviana. Se realizará una mejora en la forma de procesar los archivos de entrada para reducir tiempos y errores, y se define una salida final consistente para que BI y las aplicaciones consuman el resultado de manera confiable.

4) Estrategia multi-compañía APEX

Se define cómo se manejará la operación cuando existan varias compañías o fuentes de información, evitando que un problema en una de ellas afecte a las demás. Se define qué información debe consultarse directamente y cuál debe mantenerse guardada como respaldo para asegurar disponibilidad. Se realizará el ajuste y fortalecimiento de ese respaldo, con reglas claras de actualización y control, para mantener la operación estable y evitar fallos en cadena.

A continuación, se detalla cada uno de los puntos descritos, especificando las actividades, configuraciones y entregables que se realizarán dentro del proyecto.

Estándares ETL en AWS Glue

Antes de borrar cualquier dato publicado, la extracción desde el origen debe ejecutarse correctamente y pasar validaciones mínimas. Cuando el origen esté caído, haya timeout o cambie la estructura, el job termina con ERROR, registra bitácora y notifica (en PRODUCCIÓN), sin borrar información.

los nombre de los JOB para el ambiente de test debe tener el  prefijo TEST_JOB* , siempre se debe realizar los cambios en los job de test para luego pasar el codigo a produccion.

Parámetros estándar del job

Todos los jobs del alcance reciben los mismos parámetros (prefijo p_):

p_ambiente (TEST | PROD): Selecciona ambiente. En PROD la notificación por error es obligatoria.

p_meses_recalculo (Entero (valor estándar: 2)): Cantidad de meses a recalcular: mes actual y mes anterior hasta hoy.

p_correo_notificacion (Correo o lista/grupo): Destino de notificación en caso de error. En TEST puede ir vacío; en PROD debe venir informado.

Construcción de rutas S3 por ambiente (TEST/PROD)

Regla: el bucket depende del ambiente; la ubicación lógica de la tabla se mantiene estable.

Ejemplo obligatorio:

if p_ambiente == 'TEST':bucket_name = 's3zaimellabi-test' else:bucket_name = 's3zaimellabi' tabla_ubicacion = 'DATA CATALOGOS GLUE/COMERCIAL/MARKETSHARE/' ruta_s3_destino = f"s3://{bucket_name}/{tabla_ubicacion}"

Particionado estándar (Compañía / Año / Mes)

Para tablas de HECHOS (ventas, sellin, sellout, etc.) se escribe particionado por: compania, anio y mes. Esto permite borrar y recargar únicamente el mes actual y el mes anterior sin afectar histórico.

Regla de borrado: solo se eliminan particiones del rango calculado (mes actual y anterior) por compañía.

Ventana de recarga (mes actual y anterior hasta hoy)

Con p_meses_recalculo=2, el job recalcula desde el primer día del mes anterior hasta hoy. El mes actual se recalcula 'hasta hoy' (no hasta fin de mes).

Ejemplo de cálculo del rango (Python):

from datetime import date from dateutil.relativedelta import relativedelta hoy = date.today() rango_inicio = (hoy.replace(day=1) - relativedelta(months=int(p_meses_recalculo)-1)).replace(day=1) rango_fin = hoy

Bitácora de ejecuciones (tabla a crear y uso obligatorio)

Se crea una tabla de bitácora para registrar cada ejecución (EXITOSO o ERROR). No se requiere p_run_id; el identificador de la ejecución se construye dentro del job usando el nombre del job y fecha/hora de inicio.

La bitácora se almacena en S3 y se consulta desde Athena/Glue Catalog. Ubicación lógica estándar:

s3://<bucket>/DATA CATALOGOS GLUE/CONTROL/ETL_BITACORA/ (particionada por anio/mes/dia)

Campos definidos a guardar

id_ejecucion (job_name + timestamp)

job_name

ambiente

fecha_inicio

fecha_fin

estado (EN_PROCESO / EXITOSO / ERROR)

meses_recalculo

rango_inicio

rango_fin (hoy)

particiones_afectadas (lista compania-anio-mes)

registros_consultados

registros_insertados

tipo_error (CONEXION / TIMEOUT / ESTRUCTURA / VALIDACION / OTRO)

mensaje_error

Ejemplo de construcción de id_ejecucion:

from datetime import datetime job_name = args['JOB_NAME']  # o variable equivalente en el job id_ejecucion = f"{job_name}-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"

Cómo escribir un registro en bitácora (función reutilizable)

Para evitar repetir código, se implementa un módulo común (etl_utils.py) compartido por todos los jobs. Los jobs solo invocan la función 'registrar_bitacora(...)'.

Ejemplo de función genérica (etl_utils.py):

import json, boto3 def registrar_bitacora(bucket_name, prefijo_bitacora, anio, mes, dia, registro):s3 = boto3.client('s3')key = f"{prefijo_bitacora}/anio={anio}/mes={mes:02d}/dia={dia:02d}/{registro['id_ejecucion']}.json"s3.put_object(Bucket=bucket_name, Key=key, Body=(json.dumps(registro, ensure_ascii=False) + "\n"))

Ejemplo de uso desde un job (una sola línea):

from etl_utils import registrar_bitacora registrar_bitacora(bucket_name, 'DATA CATALOGOS GLUE/CONTROL/ETL_BITACORA', hoy.year, hoy.month, hoy.day, registro)

Definición de tabla en Athena/Glue Catalog (para consulta)

CREATE EXTERNAL TABLE IF NOT EXISTS control.etl_bitacora_jobs (   id_ejecucion string,   job_name string,   ambiente string,   fecha_inicio timestamp,   fecha_fin timestamp,   estado string,   meses_recalculo int,   rango_inicio date,   rango_fin date,   particiones_afectadas string,   registros_consultados bigint,   registros_insertados bigint,   tipo_error string,   mensaje_error string, ) LOCATION 's3://<bucket>/DATA CATALOGOS GLUE/CONTROL/ETL_BITACORA/';

Notificación por correo cuando ocurra ERROR

En PRODUCCIÓN la notificación es obligatoria. En TEST no se envía notificación. La notificación se realiza enviando un correo al destino indicado en p_correo_notificacion.

Mecanismo recomendado: Amazon SES (si está habilitado en la cuenta). Alternativa: mecanismo corporativo existente. No se expone p_sns_topic_arn como parámetro del job.

Ejemplo de envío simple con Amazon SES (si está disponible):

import boto3 def enviar_correo_ses(origen, destino, asunto, mensaje):ses = boto3.client('ses')ses.send_email(Source=origen,Destination={'ToAddresses': [destino]},Message={'Subject': {'Data': asunto},'Body': {'Text': {'Data': mensaje}}})

Contenido mínimo del correo: nombre del job, ambiente, rango procesado, tipo_error, mensaje_error y confirmación de si se borró o no el rango.

Flujo obligatorio – Tablas de HECHOS

Orden obligatorio : consultar → validar → borrar → insertar → registrar bitácora / notificar.

Paso 1. Inicialización: Leer parámetros, resolver bucket y ruta destino según p_ambiente. Calcular rango_inicio y rango_fin=hoy. Crear id_ejecucion y registrar bitácora EN_PROCESO.

Paso 2. Consulta al origen (Oracle): Ejecutar la consulta filtrada por rango_inicio a hoy. Si falla por conexión/timeout, terminar en ERROR sin borrar nada.

Paso 3. Validación de estructura: Verificar que están presentes las columnas obligatorias (contrato mínimo). Si falta alguna, terminar en ERROR sin borrar nada.

Paso 4. Validación mínima de datos: Validar: no vacío (si aplica), fechas dentro del rango, campos críticos completos y sin duplicados por llave.

Paso 5. Borrado controlado: Borrar únicamente las particiones compania/anio/mes del mes actual y anterior. Este paso solo ocurre si Pasos 2–4 fueron exitosos.

Paso 6. Inserción: Insertar la data del rango con particionado compania/anio/mes.

Paso 7. Cierre: Registrar bitácora EXITOSO con conteos. Si ocurre error, registrar ERROR y notificar (solo en PROD).

Ejemplos de validación mínima (Spark):

# 1) No vacío if df.limit(1).count() == 0:raise Exception('Resultado vacío para el rango solicitado') # 2) Nulos en columnas críticas from pyspark.sql.functions import col for c in columnas_criticas:if df.filter(col(c).isNull()).limit(1).count() > 0:raise Exception(f'Columna crítica con nulos: {c}') # 3) Duplicados por llave dups = df.groupBy(*llaves).count().filter('count > 1').limit(1).count() if dups > 0:raise Exception(f'Duplicados detectados por llave: {llaves}')

Flujo obligatorio – Tablas MAESTRAS (Dimensiones)

Las maestras no se recalculan por meses. La actualización se realiza con un UPSERT lógico: insertar nuevos y reemplazar/actualizar registros existentes según llave de negocio.

Paso 1. Consulta al origen: Extraer la dimensión (completa o incremental según el caso).

Paso 2. Validación de estructura: Validar columnas obligatorias y que la llave de negocio no sea nula.

Paso 3. Leer dimensión publicada: Leer la versión actual desde S3 (destino).

Paso 4. UPSERT lógico: Eliminar del dataset actual los registros a actualizar e incorporar la extracción nueva.

Paso 5. Validaciones finales: Validar sin duplicados por llave y campos críticos completos.

Paso 6. Publicación: Escribir/actualizar dimensión. Para simplicidad, se permite overwrite completo en dimensiones.

Paso 7. Bitácora y notificación: Registrar EXITOSO/ERROR. Notificar solo en PROD.

Ejemplo UPSERT en Spark (llave codigo_producto):

# df_nuevo: extracción del origen # df_actual: dimensión publicada llave = ['codigo_producto'] actual_sin_actualizados = df_actual.join(     df_nuevo.select(*llave).dropDuplicates(),on=llave,how='left_anti' ) df_resultado = actual_sin_actualizados.unionByName(df_nuevo) # validar duplicados por llave antes de publicar dups = df_resultado.groupBy(*llave).count().filter('count > 1').limit(1).count() if dups > 0:raise Exception('Duplicados en dimensión por llave') df_resultado.write.mode('overwrite').parquet(ruta_s3_destino)

Tecnología por origen

SAP/HANA: implementación del job en Python.

Oracle: implementación del job en Spark (Glue).

Bitácora y notificación se aplican igual en ambos (módulo común etl_utils).

Jobs que se modifican aplicando este estándar (por dominio)

COMERCIAL

JOB_COMERCIAL_CLIENTE_ASIGNACION

JOB_COMERCIAL_CONVENIOS

JOB_COMERCIAL_FORMASPDV

JOB_COMERCIAL_IMPORTACIONES

JOB_COMERCIAL_INVERSIONES

JOB_COMERCIAL_INVERSION_PRECIO_VALORADO

JOB_COMERCIAL_MARKETSHARE

JOB_COMERCIAL_MARKET_SHARE

JOB_COMERCIAL_PORTAFOLIO

JOB_COMERCIAL_PRECIO_PVP

JOB_COMERCIAL_PRESUPUESTO

JOB_COMERCIAL_SELLIN

JOB_COMERCIAL_SELLIN_HISTORIAL

JOB_COMERCIAL_SELLIN_SAP

JOB_COMERCIAL_SELLOUT

JOB_COMERCIAL_SELLOUT_HISTORIAL

JOB_COMERCIAL_VENTAS

JOB_COMERCIAL_VENTAS_SAP

JOB_COMERCIAL_VISITAS

DIMENSIONES (MAESTRAS)

JOB_DIMENSION_BIMETAS

JOB_DIMENSION_CLIENTE

JOB_DIMENSION_CLIENTE_CLASIFICACIONES_AUD

JOB_DIMENSION_CLIENTE_CLASIFICAIONES

JOB_DIMENSION_CLIENTE_SAP

JOB_DIMENSION_COMPANIA

JOB_DIMENSION_CONVERSIONES

JOB_DIMENSION_ESPECIFICACIONES

JOB_DIMENSION_ESTANDARMAQUINA

JOB_DIMENSION_LISTAPRECIOS

JOB_DIMENSION_LISTAPRECIOS_SAP

JOB_DIMENSION_ORGANIZACION_TERRITORIAL

JOB_DIMENSION_PERSONAL

JOB_DIMENSION_PRODUCTO

JOB_DIMENSION_PRODUCTO_SAP

JOB_DIMENSION_PROVEEDOR

JOB_DIMENSION_UNIDADESNEGOCIO

Estándares de modelado de datos

La carpeta inmediatamente debajo de 'DATA CATALOGOS GLUE/' representa el nombre de la base de datos en Glue. Se crea una base por dominio/área funcional de la compañía (por ejemplo: comercial, ecommerce, logistica, finanzas, manufactura, planificacion, etc.). Dentro de cada base se publican únicamente las tablas que pertenecen a ese dominio. Las tablas maestras se publican en una base exclusiva llamada dimensiones.

Regla de carpetas: s3://<bucket>/DATA CATALOGOS GLUE/<base_de_datos>/<tabla>/ ...

Regla de contenido: una tabla no debe "saltar" de dominio; si el dato es maestro/transversal va a dimensiones.

Regla TEST: la base es única (TEST)

Regla TEST: la carpeta base en S3 es: s3://s3zaimellabi-test/DATA CATALOGOS GLUE/TEST/<tabla_unica>/ ...

Regla PROD: el bucket es s3zaimellabi y las bases están separadas por dominio (comercial, ecommerce, logistica, planificacion, etc.) y una base exclusiva dimensiones para maestras.

Regla PROD: la carpeta base en S3 es: s3://s3zaimellabi/DATA CATALOGOS GLUE/<base_dominio>/<tabla>/ ...

En pruebas se utiliza un solo bucket (s3zaimellabi-test) y una sola base de datos en Glue llamada TEST. Al existir una única base, los nombres de las tablas deben ser únicos e incorporar el dominio para evitar colisiones.

A continuación se lista el inventario actual agrupado por base. Este inventario sirve como referencia para mantener la organización por dominio y ubicar nuevas tablas en el dominio correcto.

Base: comercial

cliente_asignacion,

convenios,

convenios_rucs,

importaciones,

inversiones,

inversiones_clientes,

inversiones_evaluaciones,

inversiones_gastos,

inversiones_preciovalorado,

inversiones_productos,

market_share,

marketshare

marketshare_empresas,

marketshare_productos,

personal,

portafolio,

presupuesto_comercial,

sellin,

sellin_historial,

sellout,

sellout_historial,

ventas,

visitas,

visitas_planificacion

Base: compras

gastosimportacion,

ordenescompra

Base: dimensiones

d_bimetas,

d_cliente,

d_cliente_clasificaciones,

d_clientetrade_clasificacion_auditoria,

d_compania,

d_conversiones,

d_especificaciones,

d_estandarmaquina,

d_listaprecios,

d_organizacion_territorial,

d_personal,

d_producto

d_proveedor,

d_unidadesnegocio

Base: finanzas

cuentasporpagar,

distribucion

Base: logistica

ajustesinventarios,

costosproducto

fletes,

gastoslogisticos,

inventarios,

productividad,

tomainventarios,

toneladasrecibidas

Base: manufactura

calidad_defectos,

calidad_pruebas,

calidad_unidades_defectuosas,

consumoajustesmp,

gastomantenimiento,

parosmaquina,

presupuestogasto,

produccion,

reciclacab,

recicladet,

reclamos,

stockbodega

Base: metodologia

encuestas,

metodologia

Base: planificacion

plandemanda,

planproduccion

Base: temporal

formaspdv,

inventario,

inventariospdv,

inversiones,

inversiongasto,

listaprecios,

pedidoscabecera,

pedidosdetalle,

rp3_inventario,

rp3_venta,

sellin_tmp

En la base de datos temporal se analizara cada tabla con el Cliente y se asignara a la base de datos del dominio que corresponda o en el caso que no se use sera eliminada.

Columna obligatoria: compania

La columna compania es obligatoria en todas las tablas del modelo (hechos, dimensiones y catálogos). Sirve para diferenciar datos entre compañías y evitar colisiones de identificadores.

Tipo: string.

Dominio: valores controlados y consistentes (ej.: ECUADOR, PERU, GUATEMALA).

Si una fuente no entrega compania, el job asigna un valor fijo según su origen (por ejemplo, un job de JDE Ecuador asigna compania='ECUADOR').

Regla de unicidad: cualquier llave natural se interpreta como (compania + llave).

Organización física y particionamiento

Las tablas de hechos se publican particionadas por compania, anio y mes para reducir el volumen leído en consultas y permitir mantenimiento por ventana. Las dimensiones se publican con compania y se particionan por compania cuando tengan variaciones por compañía.

Hechos: particiones obligatorias compania/anio/mes.

Derivación: anio y mes se derivan de la fecha de negocio principal (por ejemplo, fecha_venta).

Ruta estándar: s3://<bucket>/DATA CATALOGOS GLUE/<base>/<tabla>/compania=<X>/anio=<YYYY>/mes=<MM>/

Unificación de ventas: tabla oficial comercial.sellin

La información de ventas actualmente proveniente de SELLIN y VENTAS se consolida en una sola tabla oficial: comercial.sellin, manteniendo coherencia de nombres con sellout. La tabla oficial distingue el origen del registro para trazabilidad y conserva una lista homologada de columnas.

Reglas de construcción

La tabla comercial.sellin se construye como unión de ambas fuentes con columnas homologadas; las columnas no disponibles en una fuente se publican como nulas.

Se incorpora origen_venta con valores controlados: 'sellin' o 'ventas'.

Se define fecha_venta como fecha de negocio principal (sellin.fecha → fecha_venta; ventas.fechafactura → fecha_venta).

Se derivan compania/anio/mes desde fecha_venta para particionar.

Se define id_venta (hash del grano) para identificar de forma única el registro y evitar duplicados.

Los montos se publican con nombres explícitos (por ejemplo, total_ventas, venta_bruta, venta_neta) para evitar mezclar conceptos de distintas fuentes.

Diccionario de datos

Se elaborará y mantendrá un diccionario de datos único para todas las tablas del DWH en Glue, registrando por cada tabla: nombre de campo, tipo de dato y descripción. Adicionalmente, se elaborará un diccionario de Jobs Glue, registrando por cada job: nombre del job, tablas que afecta y horario(s) de ejecución.Ejemplo:

Diccionario de tablas: comercial.sellin → codigocliente (string): Código único del cliente, total (decimal): Valor total de la transacción, etc.

Diccionario de jobs: JOB_COMERCIAL_SELLIN → Tablas afectadas: comercial.sellin; Horarios: 06:00 y 12:00.

DataMart

Se crearán DataMarts (dm_*) únicamente cuando se requiera entregar un dataset listo para consumo en Power BI que reduzca complejidad y estandarice cálculos. Los DataMarts no reemplazan el modelo base (estrella), lo complementan.

Reglas mínimas (obligatorias):

Granularidad obligatoria (mensual/diaria): el dm_* debe ser agregado y declarar su grano. No se permiten DataMarts a nivel detalle transaccional (factura/línea).Ejemplo:dm_comercial_sellin_sellout_mensual (compania+año+mes+producto+cliente)

Reuso mínimo: solo se crea si será usado por al menos 2 reportes/datasets (o 2 procesos/áreas).Ejemplo: lo consumen dashboard Comercial y dashboard Planificación.

Complejidad real (cruce de 2 o más hechos): se justifica cuando requiere unir 2 o más tablas de hechos, alineando granos y reglas para estandarizar el cálculo en ETL.Ejemplo:dm_comercial_margen_mensual = sellout + costosproducto.

Sellout: rediseño

Desacoplar el procesamiento de Sellout del esquema/BD operativa DATA, trasladando la lógica y la tabla transaccional a la base de datos ETL, asegurando estabilidad para APEX, y publicando el histórico completo en AWS (Glue/Athena) en la tabla comercial.sellout. La operación en base transaccional conservará únicamente dos años de información, con depuración anual controlada.

Migración de tabla transaccional de Sellout t_trad_sellout a la base de datos ETL.

Migración de procesos/paquetes relacionados con Sellout a la base de datos ETL.

Ajuste de aplicaciones APEX para ejecutar el proceso de Sellout desde ETL (no desde DATA).

Carga histórica completa a AWS en comercial.sellout y establecimiento de recargas incrementales posteriores.

Retención operativa: mantener únicamente año actual y año anterior en la tabla transaccional, con depuración anual.

Mejora del proceso Sellout tomando como referencia el enfoque de MarketShare y el uso de funciones estándar de APEX para lectura/validación de archivos.

Ajustes en APEX para ejecutar Sellout desde ETL

Identificar en APEX las pantallas/procesos que disparan Sellout (procesos, jobs internos, botones, páginas de carga, etc.).

Cambiar el llamado: reemplazar la ejecución de procedimientos en DATA por la ejecución del procedimiento homologado en ETL.

La aplicación APEX disparará la ejecución del proceso de Sellout de forma asíncrona mediante un job en la base de datos ETL. Con este enfoque, la base de datos DATA no ejecuta el procesamiento ni ocupa recursos durante la carga; todo el proceso se realiza en ETL y APEX únicamente consulta el estado y el resultado.

En la base de datos DATA se crearán referencias hacia los objetos de ETL que utiliza APEX para mostrar información de Sellout. De esta forma, APEX puede seguir consultando objetos en DATA (según su configuración actual), pero los datos provienen físicamente de ETL.

t_trad_sellout: tabla transaccional (reside en ETL).

mvt_trad_sellout: vista(s) utilizada(s) por APEX para mostrar información (reside en DATA).

Publicación del histórico completo en AWS (comercial.sellout)

Se publicará el histórico completo de Sellout en AWS en la tabla comercial.sellout. La tabla será la fuente de histórico y análisis; la tabla transaccional se quedará como fuente operativa acotada a dos años.

Retención operativa: solo dos años en la tabla transaccional

La tabla t_trad_sellout en la base ETL mantendrá únicamente el año actual y el año anterior. La depuración se realizará de forma anual, eliminando el año más antiguo y conservando siempre dos años disponibles para APEX.

Mejora del proceso Sellout con enfoque MarketShare y funciones estándar de APEX

El proceso de Sellout se mejorará tomando como referencia el enfoque usado en MarketShare: lectura eficiente de Excel, validación de estructura, control de errores y reutilización de funciones estándar en APEX para reducir mantenimiento.

Lectura de Excel en APEX/PLSQL usando utilidades estándar (por ejemplo, APEX_DATA_PARSER) para evitar lógica manual por archivo.

Validación de encabezados: verificar columnas obligatorias y orden/alias aceptados antes de cargar datos.

Control de archivos: registrar cada archivo (nombre, compañía, periodo, estado, conteos) para evitar reprocesos y facilitar soporte.

Manejo de errores por fila: almacenar errores en una tabla de log (fila, columna, motivo) y permitir al usuario ver/descargar el detalle.

Estrategia multi-compañía APEX

Garantizar disponibilidad y buen desempeño en APEX para las compañías SAP (Guatemala y Perú) mediante un caché casi en tiempo real en Oracle. La consulta en APEX se realiza sobre tablas cacheadas en Oracle, evitando dependencias directas hacia SAP en tiempo de consulta. Ante caídas o lentitud de SAP, APEX mantiene continuidad operativa utilizando la última versión válida del caché.

APEX consulta datos SAP Guatemala y Perú desde Oracle (caché), sin ejecutar consultas directas a SAP durante la navegación del usuario.

La base de datos DATA no ejecuta procesos pesados: las recargas se ejecutan en ETL de forma asíncrona mediante jobs programados.

La actualización del caché es casi en tiempo real (frecuencia configurable), manteniendo un sello visible de 'última actualización' por compañía.

Si una recarga falla, no se truncan tablas ni se deja información vacía; se conserva el último caché exitoso.

Se implementa un patrón de caché cerca del origen: SAP → Oracle ETL (caché) → Oracle DATA (referencias) → APEX. La capa ETL absorbe la variabilidad de SAP (caídas, cambios, lentitud) y APEX consume únicamente estructuras estables en Oracle.

SAP HANA (Guatemala y Perú): origen de datos.

Oracle ETL: almacena tablas cacheadas, ejecuta recargas y validaciones, y mantiene el control de estado. esto se lo realizara mediante un proceso almacenado.

APEX: consulta únicamente en DATA los objetos

Alcance del caché (qué se cachea y cómo se clasifica)

Se clasifica cada entidad SAP a cachear según criticidad y tamaño para definir frecuencia de actualización. La recomendación base divide en: maestras críticas, transaccionales recientes y transaccionales históricas.

Estructura de tablas cacheadas en Oracle ETL (estándar)

Las tablas cacheadas viven en ETL y se diseñan con consistencia de nombres, columna compania obligatoria y auditoría mínima. Se recomienda mantener un esquema dedicado para caché SAP (por ejemplo, ETL_SAP_CACHE).

Convención obligatoria de nombres: todas las tablas físicas de caché SAP en Oracle ETL deben iniciar con el prefijo T_GZM_. Ejemplos: T_GZM_CLIENTE, T_GZM_PRODUCTO, T_GZM_LISTA_PRECIOS, T_GZM_SELLIN_SAP.

Columna obligatoria: compania (valores: GUATEMALA, PERU).

