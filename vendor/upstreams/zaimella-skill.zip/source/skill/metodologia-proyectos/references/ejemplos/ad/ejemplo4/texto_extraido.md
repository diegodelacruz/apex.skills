# NUEVA HERRAMIENTA DE PLANIFICACIÓN MODULO PLANIFICACIÓN DE LA PRODUCCIÓN

Fuente original: `<EXAMPLE_SOURCE>/documento_fuente.docx`

## Texto extraido

DEFINICIÓN

Los objetos de base de datos se identifican por el código "PPLA". La lógica de la aplicación debe ir en el paquete PK_PPLA_PRODUCCION. La aplicación APEX donde se realiza el desarrollo es la 140 (PLANIFICACIÓN). La aplicación debe ser multicompañía: En las vistas, consultas, tablas debe guardar la compañía. En los procedimientos debe recibir como parámetro la compañía.

Las tareas o procesos automáticos deben ir en el paquete PK_PPLA_TAREAS_AUTOMATICAS.

sp_ejecutar

--- se ejecuta solo el primer dia del mes

if(to_char(sysdate, 'D')=1  ) then

SP_MAQUINA_INICIO('00001');

sp_generaPlanProduccion('00001');

end if;

---Se ejecuta todos los dias

sp_

Configuraciones del sistema

Para las pantallas de configuración se usará la numeración desde la 100-199.

Los parámetros generales deben guardarse en la tabla general "PPLA_PARAM". La lógica debe ir en el paquete PK_PPLA_CONFIGURACION.

Roles de usuario

Se crearán tres tipos de roles para los accesos a las páginas:

Administrador: Acceso total de la aplicación.

Planificador:

Usuario:

Asignación de planificador

Crear la vista VT_PPLA_PRODUCTO_PLANIFICADOR donde une información de la tabla F4101 filtrando los productos activos y terminados, vt_corp_usuario con la siguiente información:

CodigoProducto -> tabla: F4101, columna: IMLITM

Producto -> columna: IMDSC1

Marca -> ver vista vt_jde_productos

Linea-> ver vista vt_jde_productos

DivisionManufactura -> ver vista vt_jde_productos

CentroTrabajo -> ver vista vt_jde_productos

CodigoERP   ->   columna:  imanpl

NombreUsuario -> vista: vt_corp_usuario, columna: NOMBREUSUARIO, unión: CODIGOSISTEMA - imanpl

Nombres -> columna: NOMBRES, APELLIDOS

DEPARTAMENTO -> Columna: DEPARTAMENTO

Compañía

En el caso de que imanpl sea igual a 0, en el nombre del planificador debe ir el texto "SIN PLANIFICADOR".

Se realizará una actualización masiva en JDE de los productos de venta regular (activos, terminados) del código del planificador, como lo indique el área de planificación mediante un Excel. En el caso de que un producto de venta regular no esté en el Excel, se actualizará con 0.

Para la asignación del planificador en un producto nuevo, se lo realizará desde la aplicación de Creación de producto.

Crear la página 100 que tendrá el siguiente diseño:

Resumen planificador: Agrupar por nombre de planificador, división de manufactura y centro de trabajo, contando la cantidad de productos asignados.

Detalle planificador: Mostrar información de la vista VT_PPLA_PRODUCTO_PLANIFICADOR.

La modificación de esta información debe ser a través del área de finanzas, que es la  administradora de los parámetros de JDE.

Stock inicial ideal

Agregar los parámetros:

Valor porcentaje de error para la variación del stock inicial ideal.

Correo notificación finanzas

Crear la tabla t_ppla_productoStockIdeal que contenga las siguientes columnas.

CodigoProducto

StockInicialIdeal

FechaDesde

FechaHasta

AuditoriaUsuario

AuditoriaFecha

Compania

Crear la página 101 que contenga el siguiente diseño:

Descargar formato Excel para subir de forma masiva.

Subir información de stock inicial ideal de forma masiva. Mostrar información de la tabla  t_ppla_productoStockIdeal comparada con la información subida en el Excel. Pintar los valores que superen el porcentaje parametrizado.

Botón para actualizar (¿Está seguro de enviar?) el valor del stock inicial ideal en la tabla t_ppla_productoStockIdeal. Debe caducar los valores anteriores poniendo fecha fin = sysdate-1 e insertar los nuevos valores con fecha inicio = sysdate. Se debe notificar a todos los planificadores y a los correos que están configurados en los parámetros.

Estimados,

Se realizaron cambios en el stock inicial ideal. Para ver más detalle, ver en el portal de planificación.

Máquinas

Crear la tabla T_PPLA_MAQUINAS; la tabla va a guardar información de los parámetros de la máquina por mes y por semana. Debe contener las siguientes columnas:

CodigoMaquina PK

FechaDesde PK

FechaHasta PK

Turnos

HoraTurno

Grupos

Personas

Eficiencia

Compañía

Crear las vistas:

VT_PPLA_MAQUINAMES. Muestra información de las máquinas solo de los meses. con la siguiente información:

División

Codigo máquina

Nombre de máquina

Año

Mes

FechaDesde

FechaHasta

Turnos

HorasTurno

Capacidad = HorasTurno * Turnos* EFICIENCIA

Eficiencia

Personas

TotalPersonas = personas* grupo

Compañía

Agregar los parámetros:

Días máximos para modificar parámetros de máquina mensual. Máximo o por defecto 5 (quinto día del mes).

Crear la página 102 que contenga el siguiente diseño:

Pestaña mensual

Mostrar el año actual y el mes actual.

Mostrar la información de la vista VT_PPLA_MAQUINAMES.

Crear procedimiento SP_MAQUINA_INICIO que ingrese las máquinas de la compañía que no existen en el mes en la tabla T_PPLA_MAQUINAS;  la fecha de inicio y fin del mes , los valores Turnos, HoraTurno deben ser iguales al del mes anterior.

Debe mostrar la información del mes anterior. Solo puede retroceder un mes del mes actual.

Debe mostrar información del mes siguiente. Solo puede ir hacia un mes adelante del mes actual.

Descargar formato para actualizar de forma masiva. Debe aparecer solo si el día máximo para modificar parámetros de máquina mensual es menor a hoy.

Subir de forma masiva los valores de turno y horas de turno para modificar en las máquinas que se sube en el Excel. Debe mostrar mensaje de éxito o de error.

Plan de demanda

Ingreso de información en FORECAST PRO

Crear dos vistas que reemplacen los archivos compartidos que lee el FORECAST PRO:

Histórico de ventas: crear la tabla t_ppla_producto donde se van a guardar los códigos de productos y el código histórico para las ventas, tipo de venta NAC/EXT, esta tabla debe tener una pantalla de mantenimiento.

Matriz de precios

Dólares, es el promedio de las ventas /precio en los últimos 6 meses anteriores al mes actual

unidades: es la presentación

Subir y enviar plan de demanda

Agregar los parámetros:

Días máximos para modificar el plan de demanda. Máximo o por defecto 5 (quinto día del mes).

El plan de demanda debe usar las páginas de la 200 a la 299. Crear la página 200 que va a tener el siguiente diseño:

Lista de selección de mercado NACIONAL/EXTERIOR .

T_PPLA_DEMANDA -> MES/AÑO, CODIGOPRODUCTO, MERCADO

Subir archivo Excel; el formato debe contener código de producto y demanda del mes. Ejemplo del formato :

En la pantalla deben mostrarse los datos del excel (VT_APEX_EXCEL). En el caso de que ya exista información del mes actual en la tabla de  T_PPLA_DEMANDA y ya haya pasado el día máximo para modificar el plan de demanda, se debe notificar al usuario que no se puede modificar la información y no se debe mostrar el mes en la pantalla. Al mostrar la información, el sistema debe validar mediante funciones lo siguiente:

Producto en agotamiento: Si el producto existe en la tabla T_VTAS_PRODUCTOAGOTAMIENTO. Al pasar el ratón mostrar un tooltip donde muestre información de agotamiento.

Producto inactivo: Si el producto está inactivo en la vista VT_GZM_PRODUCTO.

Inversión comercial: Si el producto y el mes de la demanda existen en la consulta:

SELECT * FROM T_ICOM_INVERSION_PRODUCTO P

INNER JOIN T_ICOM_INVERSIONES I ON (I.ID=P.IDINVERSION)

WHERE MES_DEMANDA BETWEEN FECHAINICIO AND FECHAFIN AND

IDETAPA IN (2,3,7) AND IDPADRE IS NULL. Al pasar el ratón, mostrar un tooltip donde muestre información de la inversión.

Botón para guardar la información t_ppla_plandemanda, guardar o modificar la información que se muestra en la pantalla. Antes de guardar, debe alertar lo siguiente:

¿Está seguro de ingresar/modificar el plan de demanda?

En el caso de que existan valores en la demanda del mes actual. Se generará el plan de producción del mes actual (ver plan de producción).

--select DEMANDAFORECAST from T_PLAN_PLANPROD; -> CANTIDAD t_ppla_plandemanda

MERGE INTO DATA.t_ppla_plandemanda a

USING (SELECT SUM(DEMANDAFORECAST) CANTIDAD ,SUM(DEMANDAFORECAST) CANTIDADINICIAL,

TRIM(A.CODIGOPRODUCTO) CODIGOPRODUCTO

,COMPANIA,'APROBADO' ESTADO, TO_DATE('01/'||MES||'/'||ANNO, 'DD/MM/YYYY') FECHA, MAX(FECHACARGA) FECHACREACION,

CASE WHEN TIPOVENTA='EXT' THEN 'EXTERIOR' ELSE 'NACIONAL' END MERCADO ,'PPLA' USUARIO, AVG(NVL(VENTA,0)) VENTAS

FROM T_PLAN_PLANPROD A

INNER JOIN T_PPLA_PRODUCTO B ON (TRIM(A.CODIGOPRODUCTO)=TRIM(B.CODIGOPRODUCTO))

GROUP BY A.CODIGOPRODUCTO,COMPANIA,MES,ANNO,TIPOVENTA

) b

ON ( a.compania=b.compania and a.CODIGOPRODUCTO=b.CODIGOPRODUCTO and trunc(a.FECHA)=trunc(b.FECHA) and a.MERCADO=b.MERCADO)

WHEN MATCHED THEN

UPDATE SET A.CANTIDAD=b.CANTIDAD

WHEN NOT MATCHED THEN

INSERT (CANTIDAD, CANTIDADINICIAL, CODIGOPRODUCTO, COMPANIA, ESTADO, FECHA, FECHACREACION,  MERCADO, USUARIO, VENTAS )

VALUES (B.CANTIDAD, B.CANTIDADINICIAL, B.CODIGOPRODUCTO, B.COMPANIA, B.ESTADO, B.FECHA, B.FECHACREACION,  B.MERCADO, B.USUARIO, B.VENTAS) ;

Plan de producción

Agregar los parámetros:

N meses hacia adelante para el plan de producción.  por defecto 12

Cálculo del plan de producción mensual

Los estados del plan de producción mensual se deben guardar en la tabla T_PPLA_PLANPRODUCCION; los estados serán los siguientes:

0 -> Creado/Borrador

1 -> En ruta

2->  Aprobado

Crear un proceso automático para la generación del plan de producción que se ejecute el primer día del mes a las 3 am.  El proceso debe realizar lo siguiente:

Crear una lista de productos del plan de demanda desde el mes actual hasta N meses (parámetro) de los productos activos y con clasificación terminados.

Buscar datos para el plan de producción:

Buscar el stock inicial ideal de cada producto.

Buscar la máquina estándar configurada para cada producto. Para Ecuador, buscar en la vista select * from VT_JDE_MAQUINAFABRICA where TIPORUTA='M';

Buscar el stock al cierre de cada producto. ver funcion PK_JDE_INVENTARIO.f_stock_cierre_producto

Calcular el plan de producción de cada producto de cada mes con la fórmula: demanda del mes + suma (demanda menor al mes) + stock inicial ideal - stock al cierre - suma (plan de producción del mes actual). Ejemplo:

Producto: 146400072PANOLINI PLUS F4X72

Demanda

Stock inicial ideal: 1000

Stock al cierre de noviembre: 500

Plan de producción diciembre = 2000 + 0 + 1500 - 200 - 0 -> 3300

Realizar el boom de materiales a 3 niveles:

Para buscar la lista de materiales, usar la vista para Ecuador VT_JDE_LISTAMATERIALES WHERE SYSDATE BETWEEN FECHADESDE AND FECHAHASTA.

Identificar a los productos que son de lista de materiales con dosificación = 1.

La demanda para la lista de materiales es la sumatoria de todas las demandas:

Boom de productos terminados -→ Buscar la lista de materiales de los productos del plan de producción; la lista de materiales sólo puede ser de productos terminados y de tipo estándar "tipoLista=M", calcular el plan de producción.

Boom de productos semielaborados Nivel 1 -> Buscar lista de materiales (SEMI-Elaborado) de productos terminados.

Boom de productos semielaborados Nivel 2 -> Buscar lista de materiales (SEMI-Elaborado) de los productos semielaborados Nivel 1.

Boom de productos semielaborados Nivel 3 -> Buscar lista de materiales (SEMI-Elaborado) de los productos semielaborados Nivel 2.

De los productos del boom de materiales se deben buscar datos para el plan de producción y calcular el plan de producción.

Al finalizar el cálculo, debe notificar a los planificadores de la vista VT_PPLA_PRODUCTO_PLANIFICADOR mediante un correo electrónico con el siguiente formato:

Estimado planificador,

Se generó el plan de producción del mes de DICIEMBRE para su revisión y aprobación dentro del portal APEX.

Atentamente.

PORTAL DE PLANIFICACIÓN

Revisión, modificación del plan de producción mensual.

Crear la página 201 que va a tener el siguiente diseño:

Crear la vista VT_PPLA_VELOCIDADPRODUCTO con la siguiente query

SELECT CODIGOMAQUINA, CODIGOPRODUCTO, UNIDADESHORA*(eficiencia/100) UNIDADESHORA,TURNOS*HORASTURNO CAPACIDAD

FROM T_ESTN_VELOCIDADPRODUCTO e

INNER JOIN T_PPLA_MAQUINAS m ON (TRIM(e.MAQUINA)=TRIM(m.CODIGOMAQUINA))

AND TRUNC(SYSDATE) BETWEEN FECHADESDE AND FECHAHASTA)

WHERE TRUNC(SYSDATE) BETWEEN VIGENCIADESDE AND VIGENCIAHASTA

;

Debe mostrar la información del plan de producción "T_PPLA_PLANPRODUCCION" del mes actual mostrando los siguientes datos:

Mostrar los productos que están asignados al planificador.

Cantidades de producción en diferentes presentaciones: Paquetes, cajas/bulto, pallet. Para Ecuador, usar la vista de conversiones vt_jde_conversiones.

Horas Maquina -> Cantidad / UNIDADESHORA, donde la unidad hora se consulta de la vista VT_PPLA_VELOCIDADPRODUCTO.

Turnos = Horas Maquina / HoraTurno

Turnos-> Horas Maquina / HoraTurno, donde hora turno se saca de la vista Turnos =A_MAQUINAMES. Debe mostrar valores enteros.

Mostrar/Ocultar valores del mes siguiente; por defecto debe venir oculto.

Mostrar los iconos informativos:

Producto en agotamiento: debe tener el mismo funcionamiento que el del plan de demanda.

Inversión comercial: debe tener el mismo funcionamiento que el del plan de demanda.

Fórmula Plan producción: Mostrar los valores con los que se calculó el plan de producción:

Sobrepasa la capacidad de la máquina en horas mensuales. El icono debe mostrar cuando la suma de Horas Máquina sea mayor a la capacidad de la vista VT_PPLA_MAQUINAMES. Crear una función para que valide por máquina.

El usuario podrá modificar los valores de las tablas:

Máquina -> Podrá cambiar la máquina listando las máquinas disponibles para el producto que están en la vista VT_JDE_MAQUINAFABRICA para Ecuador. Al cambiar la máquina, debe recalcular la capacidad de la máquina.

Turnos -> Podrá cambiar la cantidad de turnos y debe recalcular la cantidad a producir -> Cantidad=Turno×HoraTurno×UnidadHora. Debe guardar valor inicial y el modificado. y recalcular el plan de producción de los meses siguientes y la capacidad de la máquina. Debe agregar una observación que justifique el cambio.

Jeff: la observación se guarda en la tabla T_PPLA_PLANPRODUCCION?

Mostrar un resumen de las máquinas donde se van a fabricar los productos asignados al planificador, y pintar de rojo en el caso de que las horas del plan de producción cambien.

Botón de enviar a ruta el mes actual; debe agrupar el plan con id secuencial para identificar la ruta de aprobación. Al enviar a ruta, debe ir a la nueva página 202 para mostrar el resumen del plan mensual. Con el siguiente diseño:

Turno mes ant -> Turno planificado el mes anterior

Turno Mes -> Turnos planificados el mes actual

Horas turno ->  Horas del  turno en la máquina

Horas requeridas → Horas planificadas el mes actual

Efectividad Ant. -> Eficiencia de la maquina del mes anterior

Efectividad-> Eficiencia de la maquina del mes actual

Unidades por minuto ante. ->

Unidades por minuto. ->

Unidades efectivas x hora -> Unidades por minuto X 60 X Efectividad

Al finalizar, se debe enviar a ruta de aprobación al supervisor. La aprobación podrá ser mediante correo electrónico con link que redirige a una página pública o desde la mesa de trabajo.

La página de aprobación debe mostrar el resumen y detalle de la planificación mensual.

Al aprobar, debe cambiar el estado a 1; en el caso de que rechace, se debe cambiar el estado a 0.

Planificación semanal

Agregar los parámetros:

Días de inventario rojo de 0 a 5 días,

Días de inventario amarillo entre 5 y 10

Días de inventario verde entre 11 a 999

N meses para peso de venta.

Crear la tabla t_ppla_planproduccionSemanal que tenga las siguientes columnas:

Año

Mes

Semana

Fecha desde

Fecha hasta

CodigoProducto

CodigoMaquina

Demanda

PlanProduccion

Total

Fecha

Estado

Usuario

Compania

Una vez aprobado el plan de producción mensual, se deberá ejecutar un proceso de forma automática y asincronomo para replicar los datos del mensual a toda la semana t_ppla_planproduccion-> t_ppla_planproduccionSemanal del mes aprobado y del siguiente (se ingresa en el caso de que no exista información del mes). Ejemplo: Si es el mes de enero de 2025, se deberán crear 5 semanas, en el caso de que no existan.

Crear la página 203 para la planificación semanal que contenga el siguiente diseño:

Debe mostrar la información de los productos asignados al planificador de la siguiente semana al día de hoy.

Demanda: valor de la demanda del mes.

Mensual: Valores del plan de producción mensual.

Unidades -> plan de producción t_ppla_planproduccion

Unidades fabricadas -> Crear una función que retorne cantidades fabricadas desde un rango de fecha. Revisar el paquetepk_manf_bimanufactura.sp_produccion el valor se guarda en la columna PRIMERAUNIDADESNETA.

Unidades pendientes -> Unidades - Unidades fabricadas.

Turnos -> (Unidades pendientes / UNIDADESHORA(VT_PPLA_VELOCIDADPRODUCTO ) ) /  HoraTurno(VT_PPLA_MAQUINAMES)

Cumplimiento: (Unidades pendientes / Unidades) * 100

Stock : El stock disponible debe de ser de todas las bodegas. Para Ecuador, tomar la función PK_JDE_INVENTARIO.f_disponibleproducto, modificar la función para obtener el disponible de todas las bodegas.

Día de inventario: Stock/Demanda * 30 ; llenar de color dependiendo de los parámetros.

Peso de venta de los N últimos meses de los productos asignados al planificador.

Ordenar por peso de venta y días de inventario, normalizando los valores.

Valor Normalizado=Valor Maximo−Valor MınimoValor Actual−Valor Mıˊnimo​

Ponderacion Total=0.5×(Peso de Venta Normalizado)+0.5×(1 - Dıas de Inventario Normalizado)

Iconos de estados del producto

El planificador podrá realizar las siguientes acciones:

Seleccionar productos a fabricar en la semana.

Con la selección de productos, el sistema deberá calcular para referencia los siguientes datos:

Total de unidades a fabricar con disponibilidad de stock de las cantidades pendientes. El sistema le recomienda la cantidad máxima a fabricar en la semana. Cantidad=Turno×HoraTurno×UnidadHora . En el caso de que la cantidad supere unidades pendientes, la cantidad debe ser igual a cantidades pendientes.

Turnos en la semana de las cantidades pendientes

Por defecto, definir 2 turnos por día.

Días de producción del producto.

El planificar podría modificar los valores referidos por el sistema, como:

Turnos por semana

Definir si se trabaja uno o dos turnos por día.

Días de producción

El sistema deberá indicar si existe stock disponible de la materia prima y del semielaborado para la producción del producto. Debe tener un botón para ver el detalle de stock de la lista de materiales (semielaborado y materia prima).

Consulta:

Jeff, el stock es en la bodega productiva o en la bodega de MP (17001)?

el cálculo se hace con la cantidad por producir o con la cantidad calculada según el plan de producción?

Para ver la información de tránsito, ver la página 130:176, tomar las etapas 2,3 y la fecha ETD; la cantidad, ver el detalle de la OI.

El sistema debería indicar la capacidad de la máquina semanal vs. la producción seleccionada.

Al finalizar las selecciones de los productos y las modificaciones de los valores para la producción de la semana, se debe enviar a ruta de aprobación , indicando un resumen de la semana por máquina y producto que se va a fabricar por día y turno. La página de aprobación debe mostrar el resumen y detalle de la planificación mensual.

Jeff,

Al aprobar, debe cambiar el estado a 1; en el caso de que rechace, se debe cambiar el estado a 0.

Mesa de trabajo y monitoreo

Crear una mesa de trabajo donde debe mostrar la información pendiente de aprobar de la planificación mensual y semanal. Esta información también puede aprobarse mediante correo electrónico a través de un link que abra la página de aprobación.

Los monitoreos deben contar con filtros como:

Planificador

Líneas, marca, submarca

Máquina

Las pantallas de monitoreo deben ser las siguientes:

Avance de la producción: Debe monitorear las órdenes de producción abiertas. Indicando los siguientes datos:

Número de orden

Producto-> linea, marca, submar, divmafuactura

Cantidad solicitada

Cantidad reportada (fabricada)

Indicador de stock de materia prima y producto semielaborado. Indicar si existe alguna novedad para fabricar las cantidades pendientes.

Indicador si existe materia prima por llegar y por liberar en I+D.

Seguimiento de producción: Debe monitorear la planificación del mes actual. Indicando los siguientes datos:

Producto

Cantidad demandada en unidades y paquete.

Cándida planificada en producción en unidades y paquete

Cantidad producida en paquetes y unidades

Cantidad pendiente

Cantidad vendida en paquetes, unidad , dólares.

Stock disponible en paquetes, unidad , dólares.

Días de inventario

Cumplimiento Venta/demandadólares

Incumplimiento en paquetes, unidad , dólares

Fecha de última fabricación y próxima fabricación

Orden de producción activa y sus cantidades

Cantidad en cuarentena y en pruebas de I+D

Reportes

Plan de demanda: Se podrá consultar el historial del plan de demanda. Y para los meses actuales y futuros deberá mostrar los iconos.

Plan de producción mensual: Se podrá consultar el historial del plan de producción.

Plan de producción semanal:  Se podrá consultar el historial del plan de producción semanal escogiendo el año y el mes. Debe mostrar información detallada y resumida.

Planificación semanal de personal: Reporte de la planificación semanal indicando el centro de costo (máquina), cantidad de turnos y personas por día. Este reporte se usará para enviar a Recursos Humanos.

