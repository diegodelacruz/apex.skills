# Extractos clave de ejemplo1

Fuente original: `<EXAMPLE_SOURCE>/BASES DE DATOS MARKET SHARE.docx`

## Fragmentos detectados

- No se detectaron encabezados literales con los patrones configurados.

## Primeros parrafos

- BASES DE DATOS MARKET SHARE
- Se realizarán las mejoras en la aplicación APEX 145 para las encuestas y asignación de rutas. Los procedimientos deben crearse dentro de los paquetes: PK_INTC_MARKETSHARE.
- Tablas Maestras / Dimensiones
- T_INTC_MARKETSHARE_PROVEEDOR
- Tabla para registrar los proveedores de información de market share.Columnas:
- idproveedor → Identificador único del proveedor (clave primaria).
- codigogrupo → Código del grupo o cliente en el ERP (si aplica).
- nombreproveedor → Nombre completo del proveedor de datos (ej. Favorita, Rosado, IQVIA).
- tipoarchivo → Tipo de archivo fuente (CSV o EXCEL).
- Separador → En el caso que sea CSV .
- Categoria ->
- Tipo -> MarkeShare / Importaciones
- Iniciofila -> Indica en qué número de fila inicia la información.
- mesInicio -> Mes  inicio de archivo en el caso que no tenga fecha
- compañía → Código de compañía (ej. ZM EC).
- fechaultimacarga → Fecha en que se realizó la última carga de archivo.
- fechacreacion → Fecha de creación del registro.
- usuariocreacion → Usuario que creó el registro.
- fechamodificacion → Fecha de la última modificación del registro.
- usuariomodificacion → Usuario que modificó el registro.
- IdentificarCompetencia -> Bandera que indica que no pudo identificar la competencia en los archivos procesados.
- IdentificarProductos -> Bandera que indica que no pudo identificar los productos en los archivos procesados.
- estado → Estado del proveedor (1=activo, 0=inactivo)
- ErrorCarga -> Descripción del error de la carga
- T_INTC_COMPETENCIA_EMPRESA
- Tabla para registrar las empresas competidoras.Columnas:
- idcompetencia → Identificador único de la empresa competidora (clave primaria).
- nombre → Nombre de la empresa competidora.
- ruc → Número de RUC o identificador legal de la empresa.
- país → País donde opera la empresa.
- Identificadores -> Palabras claves para identificar la competencia en los archivos Excel.
- Compañía → Código de compañía de Zaimella.
- fechacreacion → Fecha de creación del registro.
- usuariocreacion → Usuario que creó el registro.
- fechamodificacion → Fecha de última modificación.
- usuariomodificacion → Usuario que modificó el registro.
- estado → Estado de la empresa (1=activa, 0=inactiva, 2 sin homologar) .
- T_INTC_COMPETENCIA_PRODUCTO
- Tabla para registrar los productos de las empresas competidoras.Columnas:
- idproducto → Identificador único del producto (clave primaria).
- idcompetencia → Identificador de la empresa competidora a la que pertenece (FK).
- nombreproducto → Nombre completo del producto.
- CodigoProductoCliente --->
- codigobarra → Código de barras EAN13 del producto (si aplica).
- Identificadores -> Palabras claves para identificar la competencia en los archivos Excel.
- CodigoBarraproductozaimella → Identificador del producto Zaimella con el que se compara (FK a maestro de productos internos de ZM, p. ej. d_producto).
- Linea ->
- Marca→ Categoría a la que pertenece el producto.
- SubMarca
- Categoria
- Talla
- Conteo
- Segmento
- compañía → Código de compañía de Zaimella.
- fechacreacion → Fecha de creación del registro.
- usuariocreacion → Usuario que creó el registro.
- fechamodificacion → Fecha de última modificación.
- usuariomodificacion → Usuario que modificó el registro.
- estado → Estado del producto (1=activo, 0=inactivo).
- T_INTC_MARKETSHARE
- Propósito: Almacenar los registros estandarizados de Market Share, provenientes de todas las fuentes (autoservicios, farmacias, importaciones). Esta tabla será la fuente transaccional que luego se replica al DWH en AWS.
- Columnas:
- idproveedor → Identificador del proveedor de la información (FK a T_INTC_MARKETSHARE_PROVEEDOR).
- idcompetencia -> Id de la competencia identificada
- Competencia -> Texto que viene en los archivos Excel
- fecha → Fecha del registro de venta/importación.
- local → Local, tienda o ciudad donde se registró la venta.
- Ubicación
- Formato → Formato o canal (ej. Hipermercado, Vecino, Farmacia, etc.).
- Producto ->
- codigobarra → Código de barras (EAN13) si está disponible en la fuente.
- codigoproductoproveedor → Código de producto definido por el proveedor o portal (SKU propio de la fuente).
- cantidad → Cantidad de unidades vendidas o importadas.
- Precio → Precio unitario en dólares (si lo reporta la fuente; puede ser nulo en Favorita).
- total → Valor total de la venta en dólares (si aplica; si no se calcula después).
- compania → Código de compañía Zaimella (ej. ZM EC).
- Crear la tabla T_CORP_MAPEO_EXCEL , que contenga las siguientes columnas:
- Tabla  -> atadura
- IdTabla -> atadura
- TablaDestino
