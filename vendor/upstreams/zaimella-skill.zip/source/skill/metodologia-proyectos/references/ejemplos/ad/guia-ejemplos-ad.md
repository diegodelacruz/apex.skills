# Guia de ejemplos de AD

Esta carpeta conserva ejemplos reales usados como referencia de redaccion para `AD`, junto con texto extraido, imagenes y metadatos.

## Estructura

- `ejemplo1`: `BASES DE DATOS MARKET SHARE`
- `ejemplo2`: `REDISEÑO DE LA ARQUITECTURA DE DATOS - BI COMERCIAL`
- `ejemplo3`: `AUTOMATIZACIÓN DE EXTRACCIÓN Y GENERACIÓN DE BASES BI PARA TABLERO DE ECOMMERCE`
- `ejemplo4`: `NUEVA HERRAMIENTA DE PLANIFICACIÓN MODULO PLANIFICACIÓN DE LA PRODUCCIÓN`

Cada ejemplo contiene:

- `metadata.md`: origen, imagenes extraidas y coincidencias de palabras clave.
- `extractos_clave.md`: primeros parrafos y fragmentos detectados.
- `texto_extraido.md`: texto completo extraido del `.docx`.
- `imagenes/`: recursos graficos extraidos del documento.

## Alineacion con la redaccion objetivo

### ejemplo1

- Alineacion general: baja.
- Sirve para: inventario de objetos, tablas, columnas y nivel de detalle tecnico base.
- No sirve como modelo principal para: `Resumen ejecutivo` ni `Definicion` metodologica de `AD`, porque su redaccion es mas cercana a especificacion cruda de objetos que a entregable metodologico cerrado.

### ejemplo2

- Alineacion general: media-alta.
- Sirve para: aterrizar definiciones tecnicas con objetos concretos, dependencias reales y logica de procesamiento bien especificada.
- Sirve parcialmente para: tono tecnico fuerte y aterrizaje por frentes.
- Limite: no debe copiarse literal como patron completo de `Resumen ejecutivo`, porque el mayor valor del ejemplo esta en la densidad tecnica y no en la estructura ejecutiva del `AD`.

### ejemplo3

- Alineacion general: media.
- Sirve para: tono ejecutivo, estructuracion por dominios, explicacion funcional de alto nivel y organizacion de informacion para audiencias no tecnicas.
- No sirve como modelo principal para: `Definicion` de `AD` centrada en APEX, Oracle, paginas y objetos concretos.

### ejemplo4

- Alineacion general: media-baja.
- Sirve para: nombrar paginas, tablas, vistas, paquetes, parametros y reglas con mucho detalle funcional.
- No sirve como modelo principal para: redaccion final de `Definicion`, porque cae facilmente en listas largas y especificacion tipo minuta.

## Uso recomendado dentro del skill

- Para `Resumen ejecutivo`, prioriza `ejemplo3` y toma de `ejemplo2` solo el nivel de aterrizaje funcional cuando haga falta.
- Para `Definicion`, prioriza `ejemplo2` por la forma de aterrizar componentes reales y usa `ejemplo4` solo como apoyo para granularidad funcional de pantallas o parametrizaciones.
- Usa `ejemplo1` solo como apoyo de concrecion tecnica de objetos, nunca como patron principal de estilo.
- Si varios ejemplos se contradicen, prioriza siempre las reglas metodologicas activas del skill por encima del estilo historico de los documentos.
