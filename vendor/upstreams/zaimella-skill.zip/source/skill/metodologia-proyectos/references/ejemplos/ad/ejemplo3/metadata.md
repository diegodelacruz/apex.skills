# ejemplo3

- Nombre: AUTOMATIZACIÓN DE EXTRACCIÓN Y GENERACIÓN DE BASES BI PARA TABLERO DE ECOMMERCE
- Fuente original: `<EXAMPLE_SOURCE>/documento_fuente.docx`
- Imágenes identificadas en la fuente: 24
- Archivo de texto extraído: [texto_extraido.md](./texto_extraido.md)
- Imágenes no publicadas en el skill; consultar la fuente autorizada cuando el análisis visual sea necesario.

## Coincidencias de secciones y palabras clave

- Se realizará un levantamiento completo de las APIs disponibles en las plataformas digitales del Grupo Zaimella, identificando las fuentes relacionadas con Ecommerce.
- Se diseñará una base de datos Ecommerce que consolide la información transaccional y maestra de forma estructurada y escalable.
- Se implementará un proceso automatizado en la nube para preparar la información de Ecommerce para su análisis y visualización.
- Definición de los dominios de información Ecommerce.
