# ejemplo4

- Nombre: NUEVA HERRAMIENTA DE PLANIFICACIÓN MODULO PLANIFICACIÓN DE LA PRODUCCIÓN
- Fuente original: `<EXAMPLE_SOURCE>/documento_fuente.docx`
- Imágenes identificadas en la fuente: 48
- Archivo de texto extraído: [texto_extraido.md](./texto_extraido.md)
- Imágenes no publicadas en el skill; consultar la fuente autorizada cuando el análisis visual sea necesario.

## Coincidencias de secciones y palabras clave

- DEFINICIÓN.
- Resumen por planificador, división de manufactura y centro de trabajo, con cantidad de productos asignados.
- Resumen de máquinas y alerta visual cuando cambian las horas del plan de producción.
- Envío del plan mensual/semanal a ruta de aprobación con resumen y detalle por máquina, producto, día y turno.
