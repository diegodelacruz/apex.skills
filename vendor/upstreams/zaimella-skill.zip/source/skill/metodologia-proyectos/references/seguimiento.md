# Seguimiento del proyecto

## Propósito

Mantener control continuo sin duplicar RI, AD ni el cronograma. Guardar el registro en `proyecto/06_seguimiento/seguimiento.md` y actualizar la bitácora general cuando cambie el estado del proyecto.

## Registro mínimo

- Estado general y etapa activa.
- Hitos, entregables y fechas comprometidas.
- Avance evidenciado, sin inventar porcentajes.
- Riesgos, bloqueos, dependencias y responsable de siguiente acción.
- Decisiones tomadas o requeridas.
- Cambios de alcance y su impacto en RI, TO-BE, casos de uso, prototipos, AD y plan.
- Próximo paso y fecha de revisión cuando exista.

## Entregables, Sprints Y Paquetes

- Mantener una fila por entregable verificable y relacionarla con todos sus sprints y paquetes; una tarea principal terminada no completa resultados omitidos.
- Cada paquete identifica `PROJECT_ID`, entregable, sprint, `PACKAGE_ID`, `capability_id`, orquestador propietario, criterios, evidencia e impacto documental.
- El orquestador de dominio crea y controla sus tareas internas. El proyecto solo recibe el handoff contractual; no decide sus locks, worktrees, QA ni correcciones.
- Un resultado `EN_CORRECCION_DOMINIO` sigue en ejecucion. Escalar solo una decision material no inferible o un impedimento externo real.
- Permitir paquetes paralelos si dependencias, ambientes, datos sensibles y resultados no se cruzan.
- Antes de integrar o cerrar, comprobar cobertura de todos los paquetes y subtareas representadas en sus handoffs.

## Documentacion Entregable

Planificar cada documento con perfil `funcional`, `tecnico` o `mixto`, audiencia, proposito, cobertura, linea base, evidencia y salida. Usar `documentacion-proyecto-sistemas` para redactar y auditar. QA de dominio aporta evidencia visual o tecnica; no es autor del documento.

## Control de cambios

Todo cambio debe registrar solicitud, motivo, impacto, decisión, artefactos afectados y aprobación. Si cambia negocio, actualizar o reabrir RI; si cambia comportamiento, actualizar TO-BE/casos/prototipo; si cambia construcción, actualizar AD; si cambia secuencia o duración, actualizar planificación tras aprobación.

## Cierre operativo

Antes de cerrar, registrar entregas y aceptación, resultado frente al objetivo, incidencias o pendientes transferidos con responsable, ubicación de documentación final y evidencia que sustenta las lecciones aprendidas.
