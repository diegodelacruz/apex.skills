# Planificacion del proyecto

## Objetivo

Definir como debe trabajar el agente la carpeta `proyecto/05_planificacion/` cuando el usuario necesite cronograma, seguimiento de avance o artefactos de control del tiempo.

## Regla base

`proyecto/05_planificacion/` no es una etapa formal de la metodologia, pero si es una carpeta operativa obligatoria cuando el proyecto necesita fechas, duraciones o control de avance.

## Fuente principal de la planificacion

Si el proyecto ya tiene `AD` aprobado o en estado suficientemente estable para planificar, la planificacion debe tomar ese `AD` como fuente principal.

La planificacion no puede contradecir el `AD` ni inventar frentes de trabajo que no tengan sustento en el alcance o en la definicion tecnica aprobada.

## Estructura Contractual De Cobertura

Cuando el contexto use `Gestion-Proyectos`, el cronograma es una vista temporal y no sustituye estos contratos:

1. `entregables.md`: un resultado verificable por fila, con aceptacion, evidencia y documentacion.
2. `sprints/<SPRINT_ID>.md`: objetivo de iteracion y todos los entregables/paquetes vinculados.
3. `paquetes/<PACKAGE_ID>.md`: resultado delegado a un unico orquestador de dominio propietario.
4. Handoff del dominio: cobertura de sus tareas/subtareas internas, versiones y evidencia.

Una solicitud del usuario con varios items se descompone por resultados verificables antes de estimar fechas. Los items que comparten un objetivo y propietario pueden pertenecer al mismo paquete, pero conservan cobertura en las subtareas internas del dominio. Los items con objetivos o propietarios distintos usan paquetes separados. No declarar completo un sprint, entregable o proyecto porque finalizo la actividad mas larga o principal.

Solo se permiten fuera del `AD` actividades transversales evidentes y coherentes con la ejecucion, por ejemplo:

- `Pruebas de usuario`
- `Pruebas y correccion de errores`
- `Documentacion`
- `Reportes`
- `Estabilizacion`
- actividades equivalentes claramente necesarias para ejecutar el proyecto

## Regla obligatoria de trazabilidad con AD

Cuando exista `AD`, cada frente principal de la planificacion debe tener correspondencia reconocible con uno o mas bloques del `AD`.

Esa trazabilidad debe verse en:

- nombres de frentes
- secuencia de ejecucion
- coherencia tecnica de las tareas

No es obligatorio escribir referencias mecanicas como `sale del punto 1 del AD`, pero si debe poder entenderse claramente que el cronograma organiza la construccion real de lo definido en `AD`.

Si el usuario pide una planificacion en cascada por modulo, entregable o bloque funcional, las pruebas y correcciones deben quedar integradas dentro de cada modulo correspondiente. No deben abrirse como una etapa global separada al final, salvo instruccion explicita del usuario.

## Regla de cambio del AD

Si el `AD` cambia en alcance, secuencia, frentes tecnicos o entregables relevantes, la planificacion queda desactualizada.

En ese caso, el agente debe:

1. revisar nuevamente el `AD`
2. ajustar la propuesta de planificacion en consola
3. volver a pedir aprobacion del usuario antes de regenerar el Excel

## Gate obligatorio

Antes de crear o actualizar cualquier cronograma, el agente debe pedir o confirmar la `fecha de inicio del proyecto`.

Si la fecha de inicio no existe o no esta confirmada:

1. no inventarla
2. no proyectar fechas de tareas
3. dejar bloqueo formal
4. pedir al usuario la fecha de inicio antes de cerrar la planificacion

## Patron historico observado

Los avances hist?ricos disponibles en el contexto siguen normalmente este patr?n:

- nombre del proyecto como bloque principal
- frentes o entregables principales
- tareas cortas y operativas debajo de cada frente
- fechas de inicio y fin por tarea
- duracion por tarea en dias
- hitos recurrentes como `Pruebas de usuario`, `Pruebas y correccion de errores`, `Reportes`, `Documentacion`, `Estabilizacion` o equivalentes

## Regla obligatoria de redaccion de tareas

La redaccion de las tareas en `proyecto/05_planificacion/` debe seguir el patron historico observado en los avances reales del repositorio.

Cada tarea debe cumplir estas condiciones al mismo tiempo:

- ser entendible a primera lectura
- sonar coherente con el tipo de proyecto
- quedar resumida en una sola linea
- mantener secuencia logica con la tarea anterior y la siguiente
- no quedar ni demasiado detallada ni demasiado vaga

## Que si hacer en la redaccion

- Nombrar la tarea con una frase breve, operativa y natural.
- Usar nombres que describan una unidad real de trabajo y no una accion atomica sin contexto.
- Mantener vocabulario coherente con el proyecto, su dominio y su tecnologia.
- Agrupar por frentes, entregables o modulos cuando el proyecto tenga varios bloques funcionales.
- Usar hitos de cierre o control cuando apliquen, por ejemplo `Pruebas de usuario`, `Pruebas y correccion de errores`, `Reportes`, `Documentacion`, `Estabilizacion` o equivalentes del caso.
- Si el usuario ya da por implícito que cada modulo incluye base de datos, paquetes, vistas, servicios o logica tecnica, no enumeres esas capas en el nombre de la tarea; deja la redaccion centrada en el modulo o entregable.
- Si el cierre del proyecto naturalmente agrupa documentacion, estabilizacion, despliegue y verificacion inicial, solo consolidar su nombre en el cronograma cuando la matriz conserve por separado la cobertura, evidencia y aceptacion de cada entregable aplicable.
- Si ese cierre queda mejor con nombres mas simples, prefiere redacciones directas como `Documentacion tecnica del proyecto`, `Paso a produccion y estabilizacion` o `Cierre y salida a produccion` antes que frases largas o redundantes.
- Si el usuario entiende `Estabilizacion` como parte de la salida productiva, ubicala junto al `Paso a produccion` y a la revision posterior, no junto a `Documentacion tecnica`.
- Si el cronograma esta organizado por modulos o entregables, ubicar las pruebas y correcciones dentro del mismo modulo y no como un bloque global separado al final.

## Que no hacer en la redaccion

- No redactar tareas como parrafos explicativos.
- No usar nombres excesivamente tecnicos si el resto del plan no esta en ese nivel.
- No fragmentar una misma unidad de trabajo en demasiadas microtareas irrelevantes.
- No agrupar en una sola tarea un bloque demasiado amplio que impida entender que se va a ejecutar realmente.
- No usar rotulos genericos vacios como `Desarrollo`, `Cambios varios` o `Revision` sin contexto.
- No crear frentes genericos sin entregable real como `Preparacion funcional y tecnica`, `Preparacion general`, `Alineacion tecnica`, `Cierre de alcance` o equivalentes, salvo que el usuario los pida explicitamente.
- No sacar las pruebas y correcciones de su entregable cuando el usuario espera una secuencia en cascada por modulo.
- No recargar el nombre de la tarea con listas como `tablas, paquetes, vistas, servicios` si ese contenido ya se entiende incluido por defecto dentro del modulo.
- No fragmentar el nombre de un mismo cierre operativo sin necesidad, pero nunca fusionar contratos de entregables o paquetes distintos por simplificar el cronograma.
- No usar en el cierre combinaciones redundantes como `final`, `inicial`, `operativo` o equivalentes si el mismo sentido ya esta implicito en la tarea.
- No asociar `Estabilizacion` a `Documentacion tecnica` cuando el sentido operativo real es estabilizar despues del pase a produccion.

## Regla de granularidad

La tarea debe representar una unidad de trabajo razonable, similar a los patrones historicos observados, por ejemplo:

- un frente principal como `Plan de demanda`, `Jobs y ETL en AWS` o `Mejoras en APEX`
- una actividad concreta dentro de ese frente como `Configuracion inicial`, `Pruebas de usuario`, `Mesa de trabajo`, `Monitoreo`, `Reportes` o `Estabilizacion`

No bajar a nivel demasiado fino como:

- click por pantalla
- campo por campo
- validacion menor aislada
- cambios triviales de interfaz sin contexto funcional

Tampoco subir a nivel demasiado amplio como:

- `Desarrollo completo del proyecto`
- `Implementacion total`
- `Correcciones generales`

Tampoco usar actividades cuya salida principal no sea reconocible, por ejemplo:

- reuniones o alineaciones internas sin entregable concreto
- preparaciones abstractas que no construyen ni habilitan un frente identificable
- bloques previos que solo describen `arranque` o `revision` sin un resultado operativo claro

## Regla de secuencia

Las tareas deben quedar ordenadas por secuencia real de trabajo.

Cuando aplique, seguir una progresion natural como:

1. configuracion o preparacion
2. desarrollo por frentes o entregables
3. pruebas del entregable
4. correcciones del entregable
5. reportes o documentacion
6. estabilizacion o cierre operativo

Si el proyecto tiene entregables parciales, la secuencia puede repetirse por bloque, por ejemplo:

- `Entregable #1`
- tareas del entregable
- `Pruebas de usuario Entregable #1`
- `Correcciones Entregable #1`

## Regla de coherencia con el proyecto

- Si el proyecto es APEX, BI, ETL, movil o integraciones, los nombres deben sonar propios de ese frente.
- Si el proyecto usa modulos o paginas conocidas, usarlas solo cuando ayuden a entender la unidad de trabajo y no conviertan la tarea en detalle excesivo.
- Si una tarea depende del lenguaje funcional del cliente, conservar ese lenguaje cuando sea claro y consistente.
- Si ya existe `AD`, la coherencia del cronograma debe medirse primero contra el `AD` y no solo contra una idea general del proyecto.
- Si el `AD` separa frentes distintos como APEX, RPA, IA, ORDS o despliegue, la planificacion no debe volver a mezclarlos en una sola tarea salvo que se trate de una prueba, documentacion o hito transversal claramente identificable.
- Si aparece una actividad previa al desarrollo, valida si realmente deja un entregable concreto. Si no lo deja, no la abras como frente independiente.
- Si el usuario pide cascada por modulo, cada modulo debe contemplar su propia construccion, pruebas y correccion de errores antes de pasar al siguiente bloque principal.
- Si el usuario espera redaccion ejecutiva o natural del cronograma, expresa el modulo o entregable principal y evita abrir cada tarea nombrando capas tecnicas implicitas.
- En el cierre del proyecto, prioriza una redaccion simple y operativa. Si dos bloques finales dicen practicamente lo mismo o forman parte del mismo cierre, unificalos.

## Gate de calidad antes de cerrar la planificacion

Antes de cerrar una propuesta de cronograma, el agente debe revisar internamente cada tarea y confirmar:

1. `Entendible`
   - se entiende que trabajo representa sin explicacion adicional
2. `Coherente`
   - suena alineada con el proyecto y con las tareas vecinas
   - si existe `AD`, tambien suena alineada con la definicion tecnica aprobada
3. `Nivel correcto`
   - no quedo ni demasiado detallada ni demasiado resumida
4. `Secuencia real`
   - esta ubicada donde realmente deberia ejecutarse
5. `Patron historico`
   - se parece al estilo de los avances reales del repositorio
6. `Trazabilidad con AD`
   - si existe `AD`, el bloque del cronograma se puede relacionar con un frente real del analisis
7. `Entregable real`
   - la tarea produce un entregable, desarrollo, prueba, despliegue, documentacion o hito operativo reconocible
8. `Sin mezcla artificial`
   - no junta en una sola tarea frentes tecnicos que el `AD` trata por separado
9. `Pruebas integradas`
   - si el plan esta por modulos o entregables, las pruebas y correcciones quedaron dentro del mismo bloque y no como cola global separada
10. `Cobertura contractual`
   - cada item del alcance esta relacionado con un entregable y paquete, y los documentos funcionales/tecnicos tienen perfil, audiencia, linea base y evidencia previstos

Si una tarea falla en uno de estos puntos, reescribirla antes de cerrar el plan.

## Regla de alcance para Codex

Por defecto, el agente debe preparar solo estos campos base de planificacion:

1. `Actividad`
2. `Fecha de inicio`
3. `Fecha de fin`
4. `Duracion estimada en dias`

No debe completar por defecto:

- horas como `8:00` o `17:00`
- porcentaje de avance
- porcentaje completado
- recursos asignados
- predecesores

Esos campos solo deben agregarse si el usuario los pide explicitamente.

## Flujo obligatorio de entrega

Cuando el usuario pida construir o actualizar la planificacion:

1. el agente debe proponer primero el cronograma en consola
2. esa propuesta debe salir ordenada por niveles, frentes y tareas
3. esa misma propuesta debe guardarse tambien como borrador `.md` dentro de `proyecto/05_planificacion/`
4. el usuario debe revisar y aprobar esa propuesta
5. solo despues del `OK` del usuario se debe generar el archivo Excel dentro de `proyecto/05_planificacion/`

## Regla de aprobacion previa al Excel

- No generar el Excel si el usuario aun no aprueba las tareas.
- No asumir aprobacion tacita por el simple hecho de haber mostrado el cronograma.
- No omitir el borrador `.md`; debe existir aunque la planificacion siga en revision.
- Si el usuario corrige secuencia, nombres o granularidad, ajustar primero la propuesta en consola y esperar nueva aprobacion.
- Si el `AD` cambio desde la ultima aprobacion de planificacion, no reutilizar el Excel anterior sin rehacer primero la propuesta.

## Regla de presentacion en consola

Antes de generar el Excel, el cronograma debe mostrarse en consola con estructura legible por niveles, por ejemplo:

- proyecto
- frente o entregable principal
- tareas del frente en secuencia

La salida en consola debe permitir validar:

- orden
- coherencia
- nivel de detalle
- fechas
- duracion

sin obligar al usuario a abrir aun el archivo final.

## Regla de salida en archivo

El borrador inicial de la planificacion debe generarse como archivo `.md` dentro de `proyecto/05_planificacion/`.

Ese archivo `.md` debe reflejar exactamente la propuesta mostrada en consola:

- mismos niveles
- mismas tareas
- mismas fechas
- mismas duraciones

Si el usuario necesita cortes de entrega para probar o usar parcialmente la solucion, el mismo archivo puede incluir una seccion adicional de `Entregables`.

Cada entregable debe:

- redactarse como resultado usable por el usuario
- poder agrupar uno o mas puntos del cronograma
- indicar claramente que bloques del plan cubre
- servir como hito de entrega o MVP y no como tarea tecnica interna

Una vez aprobada la planificacion, el agente debe generar un Excel dentro de `proyecto/05_planificacion/`.

La salida preferida es un archivo `.xlsx` con la planificacion aprobada.

El Excel debe reflejar exactamente la version aprobada en consola:

- mismos niveles
- mismas tareas
- mismas fechas
- mismas duraciones

No introducir cambios silenciosos entre la version aprobada y la version exportada.

## Regla de tiempo

- La duracion debe expresarse en dias.
- La fecha de fin debe derivarse de la fecha de inicio y de la duracion estimada.
- Si el usuario entrega restricciones reales como feriados, vacaciones, ventanas de pruebas o dependencias externas, integrarlas en la propuesta.
- Si no existen esas restricciones, no asumir calendarios especiales ni horas operativas.

## Regla de redaccion

- Nombrar las actividades con frases cortas, concretas y orientadas a ejecucion.
- Agrupar actividades por frente, entregable o modulo cuando eso mejore la lectura.
- Evitar parrafos largos de explicacion si el usuario realmente necesita cronograma.
- Mantener nombres consistentes con el lenguaje del proyecto, por ejemplo `Entregable #1`, `Pruebas de usuario`, `Estabilizacion`, `Reportes`, `Paso a produccion`, `Correcciones` o equivalentes del caso.

## Preferencias de lenguaje operativo

- Si el usuario entiende mejor el lenguaje operativo del proyecto con `Pruebas` y `Correccion de errores`, usa esos terminos en lugar de `Validacion` y `Ajustes`.
- No dejes subpuntos de cierre separados si en la practica ya estan cubiertos por `Paso a produccion y estabilizacion`.
- Si existe una seccion de `Entregables`, redacta cada entregable como algo que el usuario puede probar, revisar o empezar a usar, por ejemplo `MVP de portales y documentos`, `MVP de captura documental` o equivalentes del caso.
- Si la seccion de `Entregables` incluye algo que el usuario no puede probar o usar directamente, reescribelo o quitalo de esa seccion.

## Ubicacion sugerida

Dentro de `proyecto/05_planificacion/`, el agente puede crear o actualizar archivos como:

- `cronograma.xlsx`
- `cronograma.md`
- `avance.md`
- matrices o minutas relacionadas

Siempre que ayuden al control del tiempo y no dupliquen `RI` o `AD`.

## Resultado esperado

La carpeta `proyecto/05_planificacion/` debe permitir entender desde cuando corre el proyecto, que actividades existen, cuanto duran y en que fecha deben terminar. El agente debe presentar primero la propuesta en consola ordenada por niveles, guardar ese mismo borrador en `.md` y generar el Excel solo despues de la aprobacion del usuario, dejando al usuario el control de horas y porcentaje de avance.
