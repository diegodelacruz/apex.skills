# Protocolo de herramientas y correlación de insumos

## Objetivo

Convertir fuentes heterogéneas en evidencia trazable para identificar procesos actuales. No analizar cada archivo de forma aislada: relacionar lo que se dice o muestra en reuniones con el Word, Excel, imágenes y conversaciones que explican el mismo paso del proceso.

## Espacio de trabajo y preservación

- En proyectos nuevos, conservar originales exclusivamente en `proyecto/00_insumos/`. En proyectos heredados, inventariar también originales ya ubicados fuera de esa carpeta y preservarlos sin modificar, renombrar ni mover automáticamente.
- Guardar transcripciones, capturas, extractos y catálogos generados en `proyecto/01_levantamiento/evidencia/`.
- Guardar resúmenes tabulares de Word, Excel y PDF en `proyecto/01_levantamiento/extracciones/`.
- Usar identificadores estables: `SRC-001`, `SRC-002`, etc. Cada hallazgo usa `EV-<id>` y debe señalar la fuente y una referencia exacta: página, hoja/rango, minuto o mensaje.

## Salidas obligatorias de una reunión o demostración

Para cada video o audio procesado, conservar tres niveles distintos:

1. **Transcripción fuente.** `evidencia/transcripciones/<SRC-ID>_transcripcion.md`. Contiene segmentos con timestamps y distingue texto transcrito de notas de calidad; no se reescribe como interpretación.
2. **Secuencia detallada.** `evidencia/secuencias/<SRC-ID>_secuencia_detallada.md`. Registra, sin saltar acciones observables, cada paso mostrado o explicado: inicio/fin, actor, qué dice, qué ve, sistema/archivo/hoja/pantalla, acción, dato de entrada o salida, regla/validación, resultado, evidencia y pendiente.
3. **Flujo consolidado resumido.** `flujo_actual_resumido.md`. Integra todas las fuentes y describe el proceso completo de punta a punta en pasos cortos: `Paso 1`, `Paso 2`, etc. Cada paso enlaza los `EV-*` y el subproceso detallado que lo sustenta.

El flujo resumido no reemplaza la secuencia detallada: sirve para entender la operación completa. La secuencia detallada conserva todo lo necesario para reconstruir el AS-IS sin perder pasos.

## Expedientes detallados por subproceso

Cuando la reunión cambie de objetivo, actor, sistema principal, archivo, etapa operativa o salida, separar un subproceso en `procesos/<codigo_proceso>/`.

Cada expediente debe contener:

- `ficha_proceso.md`: objetivo, alcance, disparador, inicio, fin, actores, entradas, salidas, fuentes y estado de validación.
- `as_is.md`: tabla detallada de cada paso, incluso navegación, filtros, aperturas/cierres de archivos, cargas, descargas, digitación, copiado/pegado, cálculos, consultas, validaciones, decisiones, errores, esperas y cambios de sistema.
- `sistemas_y_datos.md`: sistemas, archivos, hojas, rangos, campos, fórmulas, reportes y movimientos de datos observados.
- `evidencia.md`: relación `EV-*` con source ID, timestamp, hoja/rango, página o captura.
- `preguntas_pendientes.md`: vacíos, contradicciones, inferencias y decisiones que requieren confirmación.

No resumir dos acciones distintas como una sola si cambia el responsable, entrada, salida, regla, sistema, archivo, pantalla o resultado. Si el paso se repite, documentar la primera ejecución completa y registrar la regla de repetición, frecuencia y variaciones observadas.

## Herramientas por tipo de fuente

| Fuente | Herramienta y método | Salida de trabajo |
| --- | --- | --- |
| Video de reunión | `levantamiento-procesos`: verificar `ffmpeg`/`ffprobe`, extraer audio y capturas, transcribir con Whisper/OpenAI o usar transcripción entregada; revisar voz y pantalla sincronizadas. No ejecutar su creador de estructura. | `proyecto/01_levantamiento/evidencia/transcripciones/`, `capturas/` y `secuencias/`. |
| Audio, nota de voz o MP4 de WhatsApp | Mismo protocolo audiovisual, pero sin asumir que hay pantalla. Transcribir, segmentar por tema y registrar decisiones, aclaraciones y cambios. | `evidencia/transcripciones/` y `evidencia/conversaciones/`. |
| Word (`.docx`) | `documents`: leer texto, tablas, comentarios e imágenes relevantes. Si se modifica o genera un DOCX, renderizar e inspeccionar; para extracción no alterar el original. | `extracciones/<SRC-ID>_word.md`. |
| Excel, CSV o TSV | `spreadsheets`: inspeccionar hojas, encabezados, rangos, fórmulas, filtros, tablas y gráficos; renderizar antes de concluir sobre formato o significado visual. | `extracciones/<SRC-ID>_excel.md`. |
| PDF | `pdf`: extraer texto y renderizar páginas con flujos, tablas, capturas, firmas o reglas. | `extracciones/<SRC-ID>_pdf.md`. |
| HTML guardado / RI de portal | `scripts/extraer_html.py`: analizar localmente sin JavaScript ni recursos externos; contrastar controles, imágenes o formato relevantes contra la fuente. | `extracciones/<SRC-ID>_html.md`. |
| Imagen o captura | Inspección visual; registrar pantalla, campo, acción, estado, validación y legibilidad. | `evidencia/imagenes/<SRC-ID>_hallazgos.md`. |
| Chat, correo o minuta | Lectura estructurada; separar hechos, decisiones, responsables, fechas, preguntas y supuestos. | `evidencia/conversaciones/<SRC-ID>_registro.md`. |

No instalar herramientas ni cargar archivos a servicios externos sin autorización. Si falta `ffmpeg`/`ffprobe` o un motor de transcripción, registrar el bloqueo y pedir autorización para instalar o usar el servicio habilitado.

## Secuencia de trabajo

1. **Catalogar.** Asignar `SRC-ID` a cada fuente en `inventario_insumos.md`; registrar tipo, fecha, tamaño, origen y relación conocida.
2. **Preparar audiovisual.** Procesar primero el video principal y luego los audios. Crear transcripción con timestamps; extraer capturas cada 10 segundos al inicio y aumentar la precisión en segmentos donde se abra un archivo, se explique una regla o se navegue en una pantalla.
3. **Registrar momentos de referencia.** Crear la secuencia detallada voz-pantalla por reunión: `minuto`, `qué se explica`, `qué se ve`, `archivo/hoja/pantalla mencionada`, `proceso posible`, `pendiente`. No omitir acciones visibles.
4. **Leer archivos nombrados o mostrados.** Revisar Word y Excel en el orden en que aparecen en la secuencia. Registrar estructura y referencias verificables, no conclusiones prematuras.
5. **Correlacionar.** Usar `matriz_correlacion.md` para vincular el minuto o declaración con hoja/rango, página/sección o imagen. Si hay contradicción, conservar ambas fuentes y abrir una pregunta.
6. **Identificar procesos.** Agrupar evidencias por objetivo, disparador, actor, entradas, pasos, reglas, sistemas/archivos, salidas y excepciones. Crear expedientes AS-IS detallados por proceso/subproceso y luego el flujo consolidado resumido.
7. **Auditar antes de RI.** Ejecutar `references/calidad_levantamiento.md`, guardar `auditoria_levantamiento.md` y corregir duplicidades, saltos, referencias rotas o contradicciones silenciosas.
8. **Validar antes de RI.** Presentar el AS-IS, problemas, riesgos, oportunidades, contradicciones y preguntas con sus referencias. El RI se redacta únicamente con elementos observados o confirmados; lo inferido o pendiente conserva su estado.

## Matriz de correlación obligatoria

Crear `proyecto/01_levantamiento/matriz_correlacion.md` con esta estructura:

| ID | Fuente audiovisual/conversación | Referencia temporal o mensaje | Archivo relacionado | Referencia interna | Hecho observado o declarado | Proceso posible | Estado | Pregunta o decisión |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `EV-001` | `SRC-001` | `00:00:00-00:00:00` | `SRC-005` | Hoja/rango o sección |  |  | Observado/Confirmado/Inferido/Pendiente |  |

## Plantilla de secuencia detallada

| Paso detallado | Inicio-fin | Actor | Qué dice | Qué se ve / usa | Acción exacta | Entrada o dato | Regla o validación | Salida o resultado | Evidencia | Subproceso | Estado / pendiente |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `D-001` | `00:00:00-00:00:00` |  |  |  |  |  |  |  | `EV-001` |  |  |

## Reglas para identificar procesos

- No crear un proceso porque un archivo exista: debe haber objetivo, disparador y una secuencia de acciones identificable.
- Un mismo archivo puede alimentar varios procesos; registrar la relación en la matriz.
- Una reunión puede explicar varios procesos; segmentar por tema y no tratarla como un único flujo.
- Diferenciar paso manual, regla de negocio, cálculo, decisión humana, control, salida y reporte.
- Si una explicación verbal contradice una fórmula, dato o documento, registrar `POR_VALIDAR`; no elegir una fuente de forma silenciosa.
- Los audios posteriores pueden aclarar o cambiar una decisión, pero no eliminan evidencia anterior: registrar el cambio, fecha y autoridad que lo confirmó.
