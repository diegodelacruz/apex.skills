# Ciclo de vida del proyecto

## Flujo rector

```text
Necesidad u oportunidad
  -> Descubrimiento y levantamiento
  -> RI: AS-IS, problemas, riesgos, oportunidades, objetivo y alcance
  -> AD funcional: TO-BE, casos de uso y prototipos
  -> AD técnico
  -> Planificación, ejecución y seguimiento
  -> Aceptación, cierre y lecciones aprendidas
```

El orden puede ser iterativo, pero no se debe adelantar una definición cerrada cuando falta evidencia o una aprobación de la etapa anterior.

## Trazabilidad mínima

Mantener una matriz o registro que relacione: necesidad u oportunidad, proceso/actor afectado, evidencia, punto de RI, flujo TO-BE, caso de uso, prototipo, bloque de AD, tarea o entregable, estado y decisión.

## Estados de evidencia

- `Observado`: aparece directamente en una fuente revisada.
- `Confirmado`: fue validado por el responsable autorizado.
- `Inferido`: es una conclusión razonable aún no validada.
- `Pendiente`: falta información o decisión.

No usar información `Inferida` o `Pendiente` como requisito, aprobación o definición técnica cerrada.

## Gates

- Pasar a RI: el levantamiento fue auditado; existen hallazgos suficientes para describir la situación actual y una necesidad de negocio validable, y todo hallazgo crítico tiene tratamiento.
- Pasar a diseño funcional: el RI o requerimiento externo fue evaluado y está aprobado o aceptado explícitamente como entrada formal; su nombre, carpeta o ruta de aprobación no bastan.
- Cerrar AD funcional: el TO-BE, los casos de uso críticos y los prototipos aplicables tienen decisión registrada.
- Planificar: AD técnico estable y fecha de inicio confirmada.
- Cerrar: aceptación o estado de la entrega, pendientes transferidos y lecciones sustentadas en evidencia.
