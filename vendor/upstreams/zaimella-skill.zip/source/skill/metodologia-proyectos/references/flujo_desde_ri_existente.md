# Flujo desde un proyecto con RI existente

## Objetivo

Operar con un proyecto heredado que ya contiene un RI formal, incluso si está en la raíz, en `proyecto/02_ri/`, en un HTML guardado del portal o junto con archivos sueltos. El RI recibido sigue siendo un insumo del levantamiento: no sustituye la reconstrucción del AS-IS ni demuestra por sí solo aprobación vigente.

## Regla de preservación

- Inventariar el RI con `SRC-ID`, ruta real, formato, fecha disponible, hash o metadatos, sensibilidad y estado de revisión.
- No mover, renombrar, convertir ni sobrescribir el original automáticamente.
- No marcarlo `Aprobado` por su nombre, carpeta, etapa del portal o ruta de aprobación. Registrar como hecho solo el estado que la evidencia permita verificar.
- Si el proyecto ya conserva el original en `proyecto/02_ri/`, mantenerlo allí como excepción heredada y registrar la equivalencia con la ruta canónica `proyecto/00_insumos/ri/`.

## Secuencia obligatoria

1. Validar con el orquestador que las rutas del modelo de artefactos están preparadas, sin borrar ni mover archivos existentes.
2. Leer `proyecto/bitacora.md` y las bitácoras disponibles; registrar etapa actual, ubicación del RI y siguiente paso.
3. Inventariar el RI y los demás insumos en `proyecto/01_levantamiento/inventario_insumos.md`.
4. Extraer texto, tablas, imágenes, controles y estado visible con el método correspondiente al formato. Para HTML guardado, usar `scripts/extraer_html.py` y declarar lo que no pueda verificarse sin interfaz activa.
5. Reconstruir y auditar AS-IS, problemas, riesgos y oportunidades usando también reuniones, documentos, hojas de cálculo y evidencia operativa. No convertir el texto del RI en pasos observados sin corroboración.
6. Crear `proyecto/02_ri/evaluacion_ri_recibido.md` con coincidencias, diferencias, contradicciones, vacíos, estado visible, preguntas y efecto en alcance.
7. Ejecutar `references/calidad_levantamiento.md`. No avanzar al diseño afectado si una contradicción material cambia cálculo, alcance, actor, control o aceptación.
8. Tras la validación de negocio, mantener el RI recibido, crear una versión ajustada o continuar hacia `proyecto/03_diseno_funcional/`, según la decisión explícita registrada.

## Evaluación mínima del RI

Comprobar si el RI contiene y sustenta:

- antecedente y AS-IS resumido;
- problemas actuales, riesgos y oportunidades;
- objetivo y resultado de negocio;
- alcance, exclusiones y fases;
- actores y responsables conocidos;
- criterios o condiciones de aceptación;
- estado, aprobadores o evidencia de aprobación;
- contradicciones frente a archivos y operación observada.

Cada diferencia conserva referencias `SRC-*`/`EV-*` y estado `Observado`, `Confirmado`, `Inferido` o `Pendiente`.

## Gate de transición

La transición queda lista para diseño funcional únicamente cuando:

- el RI y todos los insumos relevantes están inventariados;
- el AS-IS y sus subprocesos fueron levantados y auditados;
- `evaluacion_ri_recibido.md` distingue alcance confirmado, contradicciones y decisiones abiertas;
- el estado de aprobación del RI está demostrado o declarado pendiente;
- las decisiones materiales que afectan el TO-BE cuentan con responsable y tratamiento.

El paquete para AD se prepara después del TO-BE, casos de uso, prototipos y propuesta funcional aplicables; un RI existente no autoriza saltar directamente al diseño técnico.
