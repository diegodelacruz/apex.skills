# Lectura y control de insumos

## Inventario obligatorio

El usuario deposita fuentes originales en `proyecto/00_insumos/`, clasificadas por tipo. Un RI recibido también es insumo y debe ubicarse en `proyecto/00_insumos/ri/`. En proyectos existentes, revisar además `proyecto/02_ri/` por RI formales que ya estén allí: inventariarlos y preservarlos sin moverlos automáticamente. Antes de analizar, registrar toda fuente en `proyecto/01_levantamiento/inventario_insumos.md`: nombre, tipo, origen, fecha, proceso o tema, contenido relevante, sensibilidad, estado de revisión y nivel de evidencia. Mantener el archivo original sin editar.

## Rutas por tipo de archivo

| Insumo | Método obligatorio | Salida mínima |
| --- | --- | --- |
| Word (`.docx`) | Usar `documents`; extraer contenido y revisar tablas, imágenes y comentarios relevantes. En Windows con Microsoft Word puede usarse `scripts/extraer_word.ps1` para una copia Markdown y PDF de solo lectura. Si se edita o genera, aplicar además el render y QA exigidos por `documents`. | Secciones, tablas, imágenes y decisiones relevantes. |
| Excel, CSV, TSV | Usar `spreadsheets`; identificar hojas, encabezados, rangos, fórmulas, filtros y datos relevantes. En Windows con Microsoft Excel puede usarse `scripts/inspeccionar_excel.ps1` para inventario, muestra trazable y PDF de solo lectura; no sustituye los gates de autoría de `spreadsheets`. Renderizar antes de concluir sobre estructura o formato. | Tabla/resumen de datos, reglas y anomalías observadas. |
| PDF | Usar `pdf`; extraer texto y renderizar las páginas que contengan tablas, flujos, firmas, capturas o información funcional. En Windows, si Poppler está instalado por WinGet pero no aparece en `PATH`, resolver su carpeta con `scripts/resolver_poppler.ps1` para la sesión actual. | Hallazgos textuales y visuales vinculados a página. |
| HTML guardado / RI de portal | Usar `scripts/extraer_html.py` localmente, sin ejecutar JavaScript ni cargar enlaces o recursos externos. Revisar por separado imágenes, controles seleccionados y diseño si cambian el significado. | Texto trazable con hash y limitaciones visuales. |
| Imagen o captura | Inspeccionar visualmente; registrar pantalla, datos, acciones, validaciones y fuente. | Hallazgo observado y limitaciones de legibilidad. |
| Video o audio | Activar `levantamiento-procesos`; seguir su protocolo de transcripción, capturas, timestamps y cruce voz-pantalla. | Secuencia observable, sistemas, navegación, datos y dudas. |
| Chat, correo, notas o transcripción | Identificar hechos, solicitudes, decisiones, responsables, fechas, supuestos y preguntas abiertas. | Registro trazable de declaraciones y decisiones. |

## Reglas de evidencia

- Diferenciar siempre lo visto, lo dicho y lo inferido.
- Para una captura, PDF o video, registrar archivo y página, minuto o referencia visible.
- No exponer credenciales, datos personales, información comercial o archivos sensibles innecesarios; anonimizar las copias de trabajo cuando corresponda.
- Si una fuente contradice otra, conservar ambas y abrir una decisión o pregunta; no elegir una versión sin validación.
- No usar únicamente la transcripción de un video cuando la pantalla aporte navegación, campos o decisiones relevantes.

## Comandos de lectura nativa en Windows

Word, sin modificar el original:

```powershell
& "<skill-metodologia-proyectos>/scripts/extraer_word.ps1" `
  -InputPath "<DOCX>" `
  -OutputPath "<PROJECT_ROOT>/proyecto/01_levantamiento/extracciones/<SRC-ID>_word.md" `
  -PdfPath "<PROJECT_ROOT>/proyecto/01_levantamiento/evidencia/documentos/<SRC-ID>.pdf"
```

Si la extracción Markdown ya existe y solo falta la copia visual, usar `scripts/renderizar_word_pdf.ps1` para evitar repetir el recorrido textual.

Excel, sin guardar cambios en el libro:

```powershell
& "<skill-metodologia-proyectos>/scripts/inspeccionar_excel.ps1" `
  -InputPath "<XLSX>" `
  -OutputPath "<PROJECT_ROOT>/proyecto/01_levantamiento/extracciones/<SRC-ID>_excel.md" `
  -PdfPath "<PROJECT_ROOT>/proyecto/01_levantamiento/evidencia/hojas_calculo/<SRC-ID>_<HOJA>.pdf" `
  -PdfSheet "<HOJA_RELEVANTE>"
```

Para libros extensos, renderizar por separado todas las hojas relevantes en vez de exportar el libro completo. La muestra Markdown está limitada por `-MaxRows` y `-MaxColumns`; si una regla depende de filas o columnas fuera de esa muestra, realizar una inspección dirigida y registrar el rango exacto.

HTML local, sin abrir enlaces ni cargar recursos externos:

```powershell
python "<skill-metodologia-proyectos>/scripts/extraer_html.py" "<ARCHIVO_HTML>" `
  --output "<PROJECT_ROOT>/proyecto/01_levantamiento/extracciones/<SRC-ID>_html.md" `
  --source-id "<SRC-ID>"
```

Si la inspección Markdown ya existe, renderizar una hoja adicional sin repetirla mediante `scripts/renderizar_excel_pdf.ps1` con `-InputPath`, `-SheetName` y `-PdfPath`.

Si Word o Excel COM no están disponibles, no instalar Office automáticamente: usar el skill especializado y registrar la herramienta efectiva, su limitación y cualquier validación visual pendiente.

Los helpers nativos se niegan a reemplazar extracciones o PDF existentes. Usar `-Force` únicamente después de preservar o descartar explícitamente la versión previa y registrar la regeneración en la bitácora.
