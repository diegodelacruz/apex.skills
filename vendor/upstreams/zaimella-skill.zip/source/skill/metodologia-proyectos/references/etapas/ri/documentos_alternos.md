# RI - Documentos alternos

## Usar cuando hagan falta anexos o mayor detalle

- Lista de interesados.
- Matriz de problemas.
- Levantamiento de procesos actuales.
- Lista inicial de requerimientos.
- Acta de reunion de descubrimiento.
- Archivo de trabajo `RI.docx`.

## Criterio de uso

Crear estos documentos cuando el requerimiento sea amplio, involucre varias áreas o necesite trazabilidad desde el inicio. Si se está construyendo el RI final, usar `RI.docx` como entregable principal editable.
