# RI - Documento principal

## Nombre sugerido

Documento de Requerimientos Iniciales

## Archivos finales

`proyecto/02_ri/ri.docx`

## Carpeta de insumos

`proyecto/02_ri/documentos/`

## Secciones minimas

- Antecedente
- Problemas actuales
- Riesgos
- Objetivo del proyecto
- Oportunidades
- Alcance del proyecto

## Reglas de formato

- Usar viñetas para riesgos, indicando condición, impacto y responsable o decisión pendiente cuando se conozcan.

- Mantener títulos claramente diferenciados.
- Usar viñetas en `Problemas actuales` y `Oportunidades`.
- Usar `Arial` en la versión final del documento.
- Mantener tono formal y orden visual.

## Limite de la etapa

- El `RI` documenta el requerimiento en lenguaje de negocio.
- El `RI` no debe contener solución técnica detallada ni plan de construcción.
- Si se mencionan aplicaciones, módulos o sistemas, debe ser solo como contexto o referencia de alcance.
- La salida aprobada de `RI` debe servir como entrada directa de `AD`.

## Uso por el agente

- Trabajar sección por sección.
- Permitir que el usuario avance las secciones en orden flexible.
- Proponer texto antes de actualizar el documento final.
- Convertir notas operativas en redacción formal.
- Revisar que cada sección cumpla su propósito antes de presentarla.
- Reubicar contenido cuando el usuario entregue texto que corresponda a otra sección.
- Derivar `Problemas actuales` desde el `Antecedente` ya aprobado siempre que exista base suficiente.
- Hacer preguntas breves solo cuando falte claridad para sostener un problema real y su impacto.
- Verificar antes de cerrar `RI` que el `Objetivo del proyecto` y el `Alcance del proyecto` puedan ser usados por `AD` como fuente formal para la definición técnica.
