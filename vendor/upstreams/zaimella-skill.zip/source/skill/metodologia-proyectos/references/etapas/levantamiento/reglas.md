# Descubrimiento y levantamiento

## Propósito

Convertir una necesidad, oportunidad o conjunto de evidencias en una comprensión verificable de la operación actual. Esta etapa alimenta el RI; no define aún la solución técnica ni el TO-BE cerrado.

## Coordinación con levantamiento-procesos

Cuando existan entrevistas, documentos, videos, audios, capturas, sistemas o una operación por reconstruir, usar `levantamiento-procesos` como fuente especializada. Solicitar y reutilizar, según aplique: ficha de proceso, inventario de sistemas, catálogo de pantallas y datos, AS-IS, problemas, riesgos, oportunidades y preguntas abiertas.

El orquestador de proyectos entrega la arquitectura para este flujo coordinado. No ejecutar `crear_estructura_procesos.ps1` ni crear la estructura `PROCESOS/`. Usar los métodos, plantillas y scripts especializados de `levantamiento-procesos`, y devolver sus resultados para que el orquestador los guarde y vincule en la ubicación asignada.

## Salidas mínimas

- Inventario de insumos y evidencia.
- Necesidad u oportunidad inicial, actores y procesos afectados.
- AS-IS con inicio, fin, responsables, entradas, salidas, sistemas, reglas y excepciones conocidas.
- Problemas y riesgos con evidencia e impacto.
- Oportunidades de mejora priorizadas de forma preliminar.
- Preguntas, supuestos y decisiones pendientes.
- Auditoría de cobertura, coherencia, separación, no redundancia y trazabilidad conforme a `references/calidad_levantamiento.md`.

## Gate de RI

Solo iniciar o cerrar el RI cuando el AS-IS y los problemas tengan evidencia suficiente y `auditoria_levantamiento.md` no conserve hallazgos críticos sin tratamiento. Si el cliente entrega un RI, conservarlo como requerimiento formal y contrastar inconsistencias contra el levantamiento; registrar diferencias y solicitar validación, sin reemplazar su alcance por inferencias.
