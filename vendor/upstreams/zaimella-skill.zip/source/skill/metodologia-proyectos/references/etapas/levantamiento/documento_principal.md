# Artefacto principal de levantamiento

Guardar una síntesis trazable en `proyecto/01_levantamiento/levantamiento.md`. Puede enlazar archivos producidos por `levantamiento-procesos` sin duplicar su contenido.

## Estructura mínima

1. Necesidad u oportunidad.
2. Alcance del levantamiento y fuentes revisadas.
3. Procesos, actores y sistemas involucrados.
4. AS-IS validable.
5. Problemas y riesgos.
6. Oportunidades preliminares.
7. Preguntas, supuestos, decisiones y siguientes pasos.

No incluir el TO-BE como solución cerrada en este documento. Una hipótesis de mejora puede quedar identificada como `Inferida` o `Pendiente` hasta que pase al AD funcional.
