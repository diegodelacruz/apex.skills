# Lecciones aprendidas - Reglas

## Proposito

Consolidar las lecciones aprendidas del proyecto en un archivo raiz reutilizable y fiel a la evidencia disponible.

## Criterios de entrada

- Existe evidencia suficiente del trabajo realizado.

## Reglas de trabajo

- Registrar lecciones aprendidas usando [`lecciones_aprendidas.md`](lecciones_aprendidas.md).
- Guardar el resultado final en `proyecto/07_cierre/lecciones_aprendidas.md`.
- Antes de concluir lecciones aprendidas, identificar y releer todas las `bitacora.md` que existan en el proyecto, empezando por la general y siguiendo por las de etapas y subcarpetas relevantes.
- Analizar las bitacoras en detalle para detectar patrones de errores, correcciones, bloqueos, aciertos y desviaciones de planificacion o alcance; no cerrar lecciones desde eventos aislados sin contexto.
- Aplicar la `Checklist previa obligatoria` de `lecciones_aprendidas.md` antes de redactar cada leccion.
- Si las bitacoras y evidencias no explican suficientemente aciertos, incumplimientos de planificacion, cambios fuera del alcance, complicaciones o reprocesos, pedir informacion al usuario antes de cerrar las lecciones.
- No asumir causas ni completar lecciones con inferencias no sustentadas.

## Criterios de aprobacion

- El cierre deja trazabilidad suficiente del proyecto.
- Las lecciones aprendidas son claras, accionables, estan estructuradas con `Titulo de la leccion`, `Descripcion` y `Etapa del proyecto`, y se sustentan en bitacoras, evidencias o aclaraciones del usuario.
- El cierre contiene entre `3` y `5` lecciones aprendidas, salvo que falte informacion suficiente y el agente haya dejado el bloqueo formal en lugar de asumir.

## Salida minima

- Archivo `proyecto/07_cierre/lecciones_aprendidas.md` actualizado.
