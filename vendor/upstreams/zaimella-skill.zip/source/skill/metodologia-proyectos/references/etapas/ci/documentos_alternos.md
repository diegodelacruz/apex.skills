# CI - Documentos alternos

## Usar cuando el cierre requiera mayor nivel de evidencia

- Acta de cierre.
- Inventario documental final.
- Encuesta o registro de satisfaccion del cliente.
- Registro de lecciones aprendidas extendido.
- Lista de acciones de mejora.

## Criterio de uso

Agregar estos documentos cuando el proyecto deba dejar evidencia formal para auditoria, mejora continua o seguimiento posterior.
