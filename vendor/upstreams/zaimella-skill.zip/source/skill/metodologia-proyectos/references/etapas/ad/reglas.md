# AD - Reglas de etapa

## Proposito

Analizar el RI aprobado y definir con precision la solucion tecnica que se va a construir, de forma que pueda ser ejecutada por un tecnico o desarrollador.

## Criterios de entrada

- La etapa RI fue aprobada.
- Existe contexto suficiente para definir solucion y alcance detallado.
- Se conoce la tecnologia principal de la solucion o las tecnologias involucradas.

## Reglas de trabajo

- Analizar el RI aprobado antes de proponer definiciones tecnicas.
- Antes de cerrar la definición técnica, usar el diseño funcional aplicable: TO-BE, casos de uso y prototipos. Leer `references/etapas/ad/diseno_funcional.md` cuando el alcance cambie flujo, interacción, reglas, permisos, estados o pantallas.
- Revisar el levantamiento auditado, el RI evaluado/aprobado, el diseño funcional validado y los insumos técnicos disponibles en `proyecto/04_ad/documentos/` antes de redactar el AD técnico.
- Si el requerimiento fue entregado directamente para `AD`, inventariarlo como fuente formal, aplicar `references/flujo_desde_ri_existente.md` y completar el levantamiento mínimo y el diseño funcional aplicable; la ausencia de un `ri.docx` generado dentro del repositorio no autoriza saltar esos gates.
- Priorizar los archivos que identifiquen el RI o requerimiento base como fuente formal de alcance, pero contrastarlos contra AS-IS, decisiones funcionales y evidencia. No tratarlos como aprobación ni como única fuente rectora por su nombre o ubicación.
- Si el `RI` fue entregado en `.pdf`, analizar el archivo completo como insumo principal, incluyendo texto, tablas, capturas, diagramas e imagenes con informacion funcional o de negocio.
- Si para trabajar mejor hace falta una version en `.md`, generarla como copia de trabajo fiel al `.pdf`, sin omitir hallazgos visuales ni reinterpretar el contenido original.
- Tomar como entradas obligatorias del `RI` aprobado: `Antecedente`, `Problemas actuales`, `Riesgos`, `Objetivo del proyecto` y `Alcance del proyecto`.
- Si el `RI` fue generado por el cliente, el usuario final o un tercero externo al usuario solicitante, tratarlo como insumo formal de negocio y no reemplazar su definicion por una reinterpretacion propia del agente.
- Si el `RI` externo no usa exactamente la estructura metodologica esperada, mapear su contenido a `Antecedente`, `Problemas actuales`, `Riesgos`, `Objetivo del proyecto` y `Alcance del proyecto` sin inventar secciones no sustentadas.
- Si las imagenes del `RI` contienen flujos, pantallas, formularios, tablas, observaciones o ejemplos operativos, incorporarlas al analisis con el mismo peso que el texto del documento.
- Si el `RI` fue redactado por el cliente, no asumir que el nombre funcional o coloquial del proceso coincide con el nombre tecnico de la pantalla, pagina, modulo u objeto que se debe intervenir.
- Cuando el `RI` incluya capturas, imagenes o referencias visuales donde el cliente identifique explicitamente la pantalla objetivo, usar esa evidencia visual como referencia principal para ubicar la pantalla o pagina correcta; no redirigir el cambio a otra pantalla solo porque su nombre tecnico o su titulo coincide mejor con el texto del proceso descrito.
- Si el texto del `RI` usa un nombre de proceso y la imagen apunta a una pantalla distinta, registrar la diferencia como hallazgo y pedir aclaracion antes de cerrar el `AD` si la ubicacion tecnica no queda confirmada.
- Tratar el `RI` aprobado como antecedente formal obligatorio de la etapa y no como una fila dentro de `Fuentes revisadas`.
- Crear y mantener `desarrollo.md` como archivo de contexto tecnico de la etapa.
- En `desarrollo.md`, registrar al menos aplicacion origen, modulo, aplicacion destino si existe, tecnologia y observaciones tecnicas relevantes.
- Si el proyecto es APEX, tomar de `desarrollo.md` la referencia de aplicacion y modulo que se deben analizar.
- Si el proyecto es APEX, analizar los archivos disponibles en `plantilla-proyecto-apex/apex/`.
- Si falta la identificacion clara de aplicacion o modulo en `desarrollo.md`, pedirla al usuario antes de cerrar el AD.
- Iniciar el AD con un `Resumen ejecutivo` antes del detalle tecnico.
- Generar siempre el `AD` principal y su variante `AD-portal` como parte de la salida de la etapa.
- En el `Resumen ejecutivo`, listar los puntos principales que se van a realizar, cada uno con titulo y descripcion corta.
- El `Resumen ejecutivo` debe redactarse en lenguaje ejecutivo no tecnico, entendible para gerencia, cliente y usuarios no tecnicos.
- En el `Resumen ejecutivo`, no usar numeros de aplicacion, IDs internos, nombres de esquema, nombres de objetos tecnicos ni referencias crudas como `145`, `App 132`, `PKG_CONTRATOS` o equivalentes.
- Traducir toda referencia tecnica del `Resumen ejecutivo` a nombres funcionales o de negocio, por ejemplo `aplicacion de contratos`, `portal de encuestas`, `servicio de correo`, `flujo de aprobaciones` o `plataforma AWS`.
- Si un nombre tecnico no tiene equivalente funcional claro, describir su proposito de forma natural para usuario antes que exponer el identificador.
- Despues del `Resumen ejecutivo`, estructurar el AD solo con `Analisis` y `Definicion`.
- El `Objetivo` no debe quedar como titulo principal independiente; debe ser el primer parrafo de `Analisis`.
- Fuera de `Resumen ejecutivo`, `Analisis` y `Definicion`, el resto del contenido debe quedar como subtitulos dentro de esas secciones.
- No crear titulos intermedios redundantes o fabricados como `Objetivo y alcance aprobado desde RI`, `Alcance tecnologico vigente del AD` u otros equivalentes; si una idea puede expresarse en el primer parrafo de `Analisis` o en un subtitulo tecnico concreto, no debe convertirse en un titulo adicional.
- Redactar en espanol natural, claro y tecnico, sin introducciones innecesarias, texto de relleno ni frases de defensa o queja como `Para elaborar este AD`, `no se recibieron` o similares.
- Antes de dar por terminada cualquier tarea de generacion o actualizacion del AD, valida en `ad.docx` la ortografia, la redaccion, la numeracion, los encabezados y la correcta visualizacion de tildes, `ñ` y demas caracteres especiales.
- Si falta un insumo critico para cerrar la etapa, pedirlo al usuario antes de dar el AD por terminado.
- Si el `RI` externo presenta vacios, contradicciones o definiciones de negocio ambiguas, no completarlas por cuenta propia; registrar supuestos tecnicos separados y pedir aclaracion antes de cerrar el AD.
- Traducir la necesidad aprobada en `RI` a una definicion funcional y tecnica ejecutable, dejando claros alcance incluido, excluido, reglas de negocio, dependencias, supuestos, restricciones, entregables y criterios de aceptacion.
- Si la solucion usa varias tecnologias, separar el analisis por tecnologia y mantener trazabilidad con el RI.
- Mantener en la `Definicion` la misma secuencia de los puntos aprobados en el alcance, de forma que se pueda identificar que punto del requerimiento se resuelve en cada bloque tecnico del `AD`.
- Cuando un punto del alcance requiera varias actividades tecnicas para implementarse, desglosarlo en subpuntos dentro del mismo bloque del `AD`, sin perder la relacion con el punto origen.
- Cuando un punto del alcance incluya varios subtemas o frentes tecnicos que no dependan entre si, separarlos en subpuntos tecnicos dentro del mismo bloque principal del `AD`.
- No fusionar en una sola lista continua un punto del alcance que combine necesidades distintas, por ejemplo cambios en APEX, base de datos, Java, APIs, lectura de adjuntos o automatizaciones de carga.
- Si los subtemas pertenecen a tecnologias distintas, separarlos explicitamente dentro del mismo punto principal y dejar claro cual frente se construye y cual queda como dependencia o frente segregado.
- Dentro de cada subpunto tecnico, agrupar las acciones por fase de construccion y evitar listas excesivamente fragmentadas cuando varias acciones pertenecen a la misma unidad tecnica.
- Preferir menos pasos, pero mas completos y con mejor redaccion, siempre que se mantenga la precision tecnica y la secuencia real de implementacion.
- La `Definicion` debe leerse como plan tecnico natural y profesional, no como checklist microoperativo ni minuta atomizada de tareas.
- La frase inicial de cada subpunto debe decir directamente que cambio funcional o tecnico quedara implementado; no debe explicar como se organizo el texto, el bloque o la metodologia.
- Nunca abras un subpunto enumerando tablas, vistas, paquetes, jobs, APIs o paginas como si el inventario fuera la idea principal; primero declara la solucion implementada y despues desarrolla los objetos tecnicos que la construyen.
- Si una apertura comienza con varios objetos tecnicos seguidos, reescribela hasta que la primera frase exprese el cambio que quedara habilitado en el sistema.
- No redactes aperturas ni frases dominantes del bloque por contraste negativo, descarte o reemplazo informal, por ejemplo `no en correo`, `no en comentarios sueltos`, `deje de operar por correo y Excel`, `sin crear`, `sin duplicar`, `conservara la operacion actual` o equivalentes. El bloque debe abrir en positivo, describiendo primero la capacidad implementada.
- Evitar aperturas abstractas o metodologicas como `se ampliara la trazabilidad operativa`, `se consolidara el frente`, `se separaran ... en dos frentes tecnicos`, `se reconocera como cobertura previa` o equivalentes cuando ya se conoce el cambio real.
- Si un punto del alcance contiene dos o mas cambios distintos, separarlos con subtitulos internos o subpuntos tecnicos, pero mantener una apertura principal natural que describa la solucion y no la estructura del bloque.
- Si el usuario confirma que un subtema ya fue resuelto en otro proyecto, requerimiento o entrega previa, documentarlo de forma explicita como antecedente implementado, cobertura ya existente o exclusión del alcance actual por resolución previa; no omitirlo del `AD`.
- Si el usuario entrega un componente tecnico concreto de otro frente, por ejemplo un repositorio, API, clase, servicio, job o proceso existente, nombrarlo de forma directa en la `Definicion`; no reemplazarlo por etiquetas genericas como `Java/Integraciones` o `AWS`.
- Si un frente segregado si tiene un ajuste tecnico identificado, documentarlo como definicion tecnica de ese frente segregado y no como exclusión total.
- No reagrupar ni reordenar libremente los puntos del alcance aprobado si eso rompe la trazabilidad entre lo solicitado y la forma en que se resolvera.
- No abras subpuntos autonomos de `Definicion` solo para declarar que una pagina, proceso, tabla, vista, job o componente no se tocara, no tendra logica o no tendra desarrollo. Las exclusiones solo deben aparecer si el usuario las indico expresamente o si el alcance aprobado obliga a acotarlas.
- Si una exclusion si debe documentarse, integrala dentro del bloque principal que resuelve el alcance y no como subpunto independiente creado solo para descartar trabajo.
- Si una exclusion o reemplazo operativo debe mencionarse, no la conviertas en la idea central del parrafo. El primer foco del bloque siempre debe ser la solucion implementada; la exclusion solo puede quedar como aclaracion secundaria y breve cuando el usuario o el alcance la exijan.
- Mantener esa trazabilidad de forma natural y profesional, por secuencia y contenido tecnico, sin escribir frases literales como `se resolvera el punto 1 del RI` ni mencionar `RI` dentro de la redaccion final del `AD`.
- Si existe un skill tecnico especializado para la tecnologia, usarlo como apoyo para construir la definicion tecnica.
- Si un dominio requiere contexto o archivos operativos, delegar al orquestador de dominio para que prepare su arquitectura y contrato; el skill metodologico solo incorpora los resultados y trazabilidad correspondientes.
- Si falta el nombre exacto de un job, API, clase, servicio, proceso o cualquier objeto tecnico critico para cerrar la definicion, pedirlo al usuario antes de dar por terminado el `AD`.
- Si falta un insumo critico para cerrar un subpunto, por ejemplo endpoint, campo SAP, homologacion, vista estable, aprobacion de arquitectura, nombre final de objeto o criterio de publicacion, no redactes ese subpunto como solucion cerrada. Debes pedir al usuario la definicion o instruccion faltante antes de cerrar el `AD`.
- En el primer parrafo de `Analisis`, resumir que se va a hacer, desde donde hacia donde, que componentes tecnicos entran en el alcance y cual es el resultado esperado, sin reescribir completo el `RI`.
- El `Resumen ejecutivo` debe permitir entender rapidamente el alcance del proyecto sin leer aun el detalle completo del documento.
- En `Analisis`, documentar la situacion actual del alcance: aplicaciones, paginas, pantallas, objetos de base de datos, integraciones, dependencias y hallazgos encontrados como duplicidades, redundancias, inconsistencias o riesgos.
- En `Analisis`, ampliar tecnicamente el alcance aprobado en `RI`, no volver a levantar el requerimiento de negocio desde cero.
- Seguir la estructura del ejemplo metodologico de `AD` y no sustituir sus subtitulos por variantes libres salvo que exista una necesidad tecnica real y claramente justificada.
- En `Definicion`, ordenar el trabajo como actividades ejecutables para que el tecnico pueda implementarlo en secuencia o por sprint.
- Usar como orden principal de la `Definicion` la secuencia del alcance aprobado; dentro de cada punto, ordenar las actividades tecnicas en la secuencia real de construccion.
- Cuando un punto del alcance tenga varios subfrentes, usar primero la separacion por subpuntos tecnicos y luego ordenar dentro de cada subpunto la secuencia real de construccion.
- No convertir cada accion menor en un paso separado si varias acciones forman una misma fase tecnica; integrarlas en un paso mas solido y legible.
- Usar numeracion en la `Definicion` solo cuando aporte claridad real al orden de construccion.
- Si un bloque queda mejor con menos pasos, con pasos mas fuertes o con redaccion tecnica corrida bien estructurada, no fuerces numeracion extensa.
- No abrir subpuntos con frases que hablen del bloque, del literal o del tratamiento metodologico; la apertura debe describir la solucion y sonar a definicion tecnica real.
- Validar siempre que la numeracion y la jerarquia queden coherentes, continuas y sin subtitulos huerfanos: no dejar niveles sin justificar, no repetir alcances semanticos entre puntos consecutivos y no crear un punto padre para un unico subpunto; si un contenido no tiene desarrollo propio, integrarlo al nivel que realmente corresponde.
- La `Definicion` no puede quedarse en verbos generales como `ajustar`, `modificar`, `integrar` o `migrar` sin indicar exactamente que componentes se tocan y como quedan.
- No cierres un parrafo tecnico con formulas vagas como `la pagina se ajustara`, `la salida final debe conservar`, `el proceso se adaptara`, `se consumiran vistas Oracle` o equivalentes si no indicas que objetos concretos cambian, que objetos nuevos intervienen, que fuentes alimentan esos objetos y que resultado funcional deja implementado ese bloque.
- Si un subpunto depende de un insumo critico no resuelto, no mezcles una definicion que suena implementada con un bloqueo que invalida el cierre. Limita el texto a lo confirmado, declara el bloqueo formal y solicita la definicion faltante al usuario o al responsable correspondiente.
- Para cada tecnologia involucrada, detallar explicitamente que objetos existentes se revisan, cuales se modifican, cuales se crean y cuales se dejan sin cambio por estar fuera de alcance.
- Si existen objetos tecnicos identificables, nombrarlos de forma directa dentro de la `Definicion`: paquetes, procedimientos, funciones, jobs, tablas, vistas, APIs, colas, buckets, pipelines, paginas, servicios, interfaces, reportes, archivos, procesos batch o equivalentes segun la tecnologia.
- Cuando aun no se conozca el nombre final de un objeto nuevo, describirlo por su funcion, responsabilidad, origen, destino y relacion con el resto de la solucion; no dejarlo como referencia abstracta.
- No uses comodines tecnicos como `PPLA_*`, `VT_*`, `PK_*`, `vista o tabla`, `fuente equivalente` u `objeto que sustituya` dentro de una definicion que se presenta como cerrada. Si el nombre exacto todavia no existe o no esta confirmado, registralo como bloqueo de cierre en lugar de simular precision.
- Para cada objeto o componente relevante, indicar al menos proposito, accion esperada, entradas, salidas, reglas de negocio, dependencias, validaciones y criterio de resultado.
- Si el bloque describe una pagina, modulo, job, vista o proceso existente, la definicion debe indicar al menos estos cuatro elementos cuando apliquen: objeto que se modifica, fuentes de datos de origen, logica o regla principal que cambia y salida funcional esperada.
- Si una pagina depende de una vista, tabla, paquete o proceso y esos objetos no quedan identificados con suficiente precision tecnica, el bloque no se considera cerrado; debe ampliarse o quedar como bloqueo de cierre.
- Si una actividad implica cambios en base de datos, especificar que tablas, vistas, procedimientos, funciones, paquetes, jobs, indices, triggers o estructuras se crean, alteran, migran o consumen.
- Si una actividad implica cambios en aplicacion o integracion, especificar que pantallas, endpoints, APIs, procesos, colas, archivos, conectores o servicios se crean, modifican o reemplazan.
- Si el alcance afecta una aplicacion existente, la `Definicion` debe nombrar las paginas, pantallas, modulos, menus, reportes o componentes intervenidos; no basta con mencionar solo la aplicacion.
- Si la solucion corresponde principalmente a una sola aplicacion, declarar esa aplicacion una sola vez como contexto general y luego documentar el detalle por pagina, pantalla, modulo o componente.
- En APEX, cuando se documenten paginas intervenidas, usar el formato `Pagina <ID> - <Nombre de la pagina>` y describir debajo, en un parrafo tecnico, lo que se implementara en esa pagina.
- No crear un subpunto de pagina solo para decir que una pagina existente no tendra cambios; una pagina debe abrirse como subpunto cuando el alcance aprobado exige una intervencion concreta sobre esa pagina o cuando el usuario pidio dejar explicita una exclusion.
- Evitar redacciones comprimidas con identificadores tecnicos mezclados, por ejemplo `145 / 416 ...`, porque dificultan entender que valor corresponde a la aplicacion y cual a la pagina.
- En la redaccion de cambios por pagina, evitar etiquetas innecesarias como `Cambio requerido:` cuando el parrafo puede expresar directamente la definicion de lo que se va a construir o ajustar.
- Si el alcance afecta base de datos, la `Definicion` debe nombrar los objetos involucrados o, si todavia no tienen nombre definitivo, describir claramente el objeto por su funcion y relacion tecnica.
- Si el agente no puede identificar aun paginas u objetos concretos, debe pedir el insumo faltante o dejar la aclaracion como bloqueo de cierre; no debe reemplazar ese detalle con redaccion general.
- No dejar en la version final textos como `Por definir`, `Pendiente`, `Por revisar` o equivalentes dentro de tablas, listas o descripciones.
- No cerrar el AD con puntos abiertos del tipo `se debe analizar`, `se debe definir` o `pendiente de revisar`; si un dato critico falta, se debe pedir antes de considerar completo el documento.
- No cierres el AD con alternativas tecnicas abiertas disfrazadas de definicion, por ejemplo `preferiblemente`, `si se aprueba`, `si se requiere`, `si SAP no aprueba`, `o mapear`, `vista o tabla`, `fuente equivalente` u `objeto que sustituya`. Si la decision no esta tomada, conviertela en bloqueo formal de cierre.
- Si un bloqueo critico sigue abierto, no redactes el bloque como solucion cerrada ni presentes la etapa como aprobable; concentra el bloqueo de forma explicita y coherente con el resto del documento.
- Si un bloqueo critico sigue abierto, no cierres el subpunto con frases de implementacion aprobada como `quedara disponible`, `se publicara`, `operara`, `quedara operativo` o equivalentes. Un bloque bloqueado no se redacta como solucion ejecutable completa.
- Cuando el bloqueo dependa de una definicion que el usuario aun no entrego, informalo y pide esa definicion en lugar de completar el texto con supuestos o cierres aparentes.
- En BI o AWS, si el naming, el dominio, la estrategia de jobs o la separacion de cargas aun no estan aprobados, no los redactes como implementacion definitiva. Deben quedar como decision pendiente previa al cierre del AD.
- Si el `AD` cambia el alcance aprobado o redefine el objetivo del proyecto, se debe actualizar primero el `RI`.

## Nivel de detalle esperado

- El AD debe dejar claro que se construira y como funcionara.
- El AD debe abrir con un resumen ejecutivo breve y entendible de los puntos a realizar.
- Debe permitir que el desarrollador o tecnico ejecute el trabajo con minima reinterpretacion.
- Debe existir coherencia directa entre lo aprobado en `RI` y lo definido en `AD`.
- La `Definicion` debe indicar como queda la solucion objetivo y en que orden se construye.
- La `Definicion` debe explicar primero como queda la solucion objetivo y luego como se construye, con redaccion tecnica corrida y no excesivamente cortada.
- La `Definicion` debe permitir identificar con claridad que punto del alcance aprobado resuelve cada bloque o subbloque tecnico del `AD`, sin necesidad de mencionar `RI` dentro del documento.
- Cuando un subpunto ya fue cubierto en otro requerimiento o un frente segregado tenga implementacion concreta, esa situacion debe quedar declarada expresamente y no inferirse por ausencia de detalle.
- La `Definicion` debe dejar inventario claro de componentes a crear, modificar, migrar, integrar o retirar del flujo objetivo.
- La `Definicion` no debe sonar a inventario tecnico comentado ni a nota de analisis; debe leerse primero como solucion implementada y despues como secuencia de construccion.
- La `Definicion` debe centrarse en lo que se implementa; no debe abrir bloques autonomos de no-implementacion o no-desarrollo que el usuario no haya pedido.
- La `Definicion` tampoco debe explicarse principalmente por contraste con practicas previas informales; si el texto puede resumirse como `ya no sera por correo`, `ya no sera en Excel` o similar, la redaccion sigue siendo deficiente y debe reescribirse.
- Cada punto y subpunto del `AD` debe tener profundidad tecnica suficiente por si mismo; no basta con que algunos bloques esten detallados si otros quedan en nivel general o ambiguo.
- Si se define una pagina nueva, se deben documentar su nombre, objetivo, componentes, validaciones, origen de datos, procesos, permisos y comportamiento esperado.
- Si se definen tablas, vistas, integraciones, procesos batch, cargas a S3, jobs de Glue u otros componentes, se deben describir sus entradas, salidas, reglas y dependencias.
- Si existe migracion de datos, se debe documentar como se migra: tabla o fuente actual, objeto destino, mecanismo de carga, homologaciones, validaciones y criterio de exito.
- En cualquier tecnologia, el nivel de detalle debe permitir identificar que se toca exactamente en codigo, configuracion, datos e integraciones sin depender de interpretacion libre del desarrollador.

## Criterios de aprobacion

- Lo que se va a hacer y como se va a resolver esta claramente definido.
- El alcance detallado evita ambiguedades criticas.
- El documento tiene detalle suficiente para desarrollo o construccion tecnica.
- La `Definicion` identifica de forma concreta paginas, objetos de base de datos y componentes tecnicos relevantes del alcance, cuando aplique.
- La relacion entre cada punto del alcance aprobado y su resolucion dentro del `AD` es clara y no requiere reinterpretacion libre del lector.
- La redaccion tecnica es natural, legible y suficientemente corrida; no parece checklist microoperativo, documento que habla de si mismo ni metodologia explicandose a si misma.
- Las aperturas de los subpuntos describen soluciones y no arrancan como inventario de objetos ni como lista de nombres tecnicos.
- No quedan alternativas abiertas, comodines tecnicos evitables ni decisiones criticas pendientes disfrazadas de definicion cerrada.
- No existen subpuntos autonomos creados solo para declarar exclusiones o no-implementaciones que el usuario no solicito.
- No quedan frases dominantes redactadas por oposicion a practicas previas, medios informales o descartes negativos; los bloques abren con solucion positiva y ejecutable.
- No quedan bloques tecnicamente pobres o generales; cada punto relevante identifica objetos, fuentes, logica y resultado con suficiente precision para ejecutar el cambio o, si no puede hacerlo, deja el bloqueo formal correspondiente.
- Ningun bloque bloqueado queda redactado como implementacion cerrada; si falta una definicion critica del usuario o de otra area, el documento la solicita y no simula cierre tecnico.
- Las areas involucradas entienden el resultado esperado.

## Salida minima

- Documento principal de AD aprobado en `proyecto/04_ad/ad.docx`.
- Variante `AD-portal` aprobada en `proyecto/04_ad/ad-portal.docx`.
