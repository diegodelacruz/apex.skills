# Lecciones aprendidas del proyecto

## Objetivo

Estandarizar la generacion de `proyecto/07_cierre/lecciones_aprendidas.md` en un formato breve, accionable y comparable entre cierres.

## Estructura obligatoria

Cada leccion aprendida debe registrarse con exactamente estos tres campos:

1. `Titulo de la leccion`
2. `Descripcion`
3. `Etapa del proyecto`

## Insumos obligatorios antes de concluir

Antes de redactar o cerrar `proyecto/07_cierre/lecciones_aprendidas.md`, el agente debe reconstruir primero que ocurrio en el proyecto.

## Barrido obligatorio de bitacoras

Antes de escribir una leccion, identifica primero todas las bitacoras disponibles dentro del proyecto.

Como minimo, busca y revisa:

1. `proyecto/bitacora.md`
2. `proyecto/02_ri/bitacora.md`
3. `proyecto/04_ad/bitacora.md`
4. cualquier otra `bitacora.md` encontrada en subcarpetas del proyecto

No limites el analisis solo a las bitacoras esperadas por metodologia si el proyecto contiene otras bitacoras operativas relevantes.

## Insumos documentales complementarios

Luego de revisar las bitacoras, lee documentos o evidencias relevantes del proyecto, especialmente dentro de `proyecto/02_ri/documentos/` y `proyecto/04_ad/documentos/`, que expliquen:
   - incumplimientos de planificacion
   - cambios fuera del alcance
   - bloqueos
   - reprocesos
   - incidencias de pruebas
   - retroalimentacion del cliente
   - decisiones relevantes del coordinador o del equipo

Si la informacion documental no alcanza para explicar por que ocurrieron los principales aciertos, retrasos, reprocesos o desviaciones, el agente debe pedir informacion al usuario antes de concluir.

## Analisis obligatorio antes de redactar

Con las bitacoras y evidencias reunidas, el agente debe hacer primero un analisis detallado y no saltar directo a redactar.

Ese analisis debe buscar patrones en:

- errores repetidos
- correcciones recurrentes
- bloqueos que afectaron tiempo o alcance
- acciones bien realizadas que ayudaron al resultado
- causas de incumplimiento de planificacion
- causas de mejoras o cambios fuera del alcance
- dependencias externas que condicionaron el proyecto
- decisiones de coordinacion, validacion o soporte que influyeron en el resultado

La leccion aprendida debe salir de ese patron, no de una observacion aislada tomada fuera de contexto.

## Regla de suficiencia

- No asumir causas, motivaciones ni decisiones que no esten soportadas por bitacoras, documentos o aclaraciones del usuario.
- No convertir sospechas en lecciones cerradas.
- No crear ni inventar una leccion solo para completar la cantidad minima si el patron no esta claro.
- Si falta contexto para saber por que no se cumplio la planificacion, por que se hicieron mejoras fuera del alcance, por que hubo complicaciones o por que una practica funciono bien, detener la redaccion final y pedir esa informacion al usuario.
- La calidad de las lecciones depende de entender primero el hecho y su causa; no redactes solo desde el sintoma.

## Cantidad esperada

- Genera minimo `3` y maximo `5` lecciones aprendidas por cierre.
- No fuerces llegar a `5` si el proyecto solo deja `3` o `4` aprendizajes claros y bien sustentados.
- Si no hay informacion suficiente para llegar a `3` lecciones confiables, pide informacion adicional al usuario y no completes con supuestos.
- Si despues del analisis solo existen `1` o `2` aprendizajes realmente sustentados, no inventes los demas; declara que falta informacion y pide contexto adicional.

## Clasificaciones obligatorias

Cada leccion debe enfocarse siempre en una de estas clasificaciones reales del cierre:

- `Que hicimos bien?`
- `Que debimos haber hecho mejor?`
- `Que deberiamos dejar de hacer?`
- `Que no hicimos que debimos haber hecho?`
- `Cuales fueron las principales complicaciones del proyecto?`

No inventes nuevas clasificaciones si el usuario no las pide.

## Agrupacion recomendada

Organiza las lecciones en dos bloques cuando el cierre lo permita:

- `Que hicimos bien?`
- bloque correctivo compuesto por `Que debimos haber hecho mejor?`, `Que deberiamos dejar de hacer?`, `Que no hicimos que debimos haber hecho?` y `Cuales fueron las principales complicaciones del proyecto?`

Si el proyecto no amerita ambos bloques, usa solo el que aplique, pero no mezcles hallazgos positivos y brechas dentro de la misma lista.

## Regla de redaccion por campo

### Titulo de la leccion

- Redacta una frase corta y concreta.
- Debe ser siempre accionable.
- Debe empezar con verbo en infinitivo o con una formulacion concreta equivalente que exprese una accion, decision o practica aplicable.
- Debe nombrar la practica, decision o ausencia de accion que genero el aprendizaje.
- Debe decir exactamente lo que la evidencia permite concluir, sin ampliar el alcance real del hallazgo.
- Evita titulos vagos como `Comunicacion`, `Pruebas`, `Capacitacion` o `Soporte` sin contexto.
- Evita titulos grandilocuentes o inflados como `Transformar`, `Revolucionar`, `Potenciar estrategicamente`, `Optimizar integralmente` o equivalentes si esa magnitud no esta demostrada en bitacoras o evidencias.
- Prefiere construcciones accionables como:
  - `Asegurar la adopcion alineando necesidades del cliente a la herramienta`
  - `Definir la ventana de pruebas piloto desde la planificacion`
  - `Incorporar un coordinador del cliente como primer nivel de soporte`

### Descripcion

- Explica que ocurrio, por que fue relevante y cual fue el efecto observado.
- En lecciones positivas, deja claro que practica funciono y que beneficio produjo.
- En brechas, deja claro que falto, que riesgo o impacto genero y que debe hacerse distinto en futuros proyectos.
- Redacta en un solo parrafo, claro y ejecutivo.
- Debe quedar pegada a la realidad observada: ni mas ni menos de lo que muestran las bitacoras, evidencias o aclaraciones del usuario.
- Usa normalmente `2` o `3` oraciones completas:
  - hecho observado
  - impacto o consecuencia real
  - conclusion o recomendacion, cuando aplique
- No conviertas la descripcion en lista de actividades ni en relato extenso.
- No dejes la recomendacion implicita cuando la leccion sea correctiva; debe quedar visible en el mismo parrafo.
- No agregues beneficios, causas, riesgos o intenciones que no esten claramente sustentados.
- Si existe dato concreto comprobable, por ejemplo tiempo planificado vs tiempo real, actor involucrado, dependencia, proveedor, fase o decision, usalo para aterrizar la leccion.
- Si ese dato no existe, no lo inventes ni simules precision.

### Etapa del proyecto

- Indica la etapa dominante en la que nace o debio haberse resuelto la leccion.
- Usa una etapa metodologica o una etiqueta operativa corta y consistente con el cierre.
- Prioriza una sola etapa por leccion salvo que el caso requiera aclaracion adicional.
- Ejemplos validos: `Planificacion`, `Implementacion`, `Cierre`, `Capacitacion`, `Soporte`, `Recurso`.

## Criterios de calidad

Una leccion aprendida correcta debe cumplir esto:

- Se entiende sin releer todo el proyecto.
- Distingue claramente entre hecho observado y conclusion.
- Permite reutilizar la conclusion en proyectos futuros.
- No culpa personas; analiza decisiones, organizacion, definiciones o ejecucion.
- No usa generalidades vacias como `mejorar comunicacion` o `hacer mas pruebas` sin precisar que cambio concreto se recomienda.
- No exagera el impacto real del hallazgo.
- No minimiza un problema relevante dejando fuera su consecuencia principal.
- No cambia el sentido del caso historico por sonar mas elegante o mas ejecutivo.

## Plantilla sugerida

| Titulo de la leccion | Descripcion | Etapa del proyecto |
| --- | --- | --- |
| `<titulo concreto>` | `<parrafo breve con hecho, impacto y aprendizaje>` | `<etapa>` |

## Patron inferido del ejemplo

El ejemplo compartido sigue este patron:

- El `titulo` resume la accion o definicion clave.
- La `descripcion` explica el hecho observado y su efecto real en el proyecto.
- La `etapa` clasifica rapidamente donde pertenece el aprendizaje.
- Las lecciones negativas no solo describen el problema; cierran con la practica que debe adoptarse en futuros proyectos.

## Patron observado en proyectos cerrados

La revision de proyectos cerrados del coordinador `79` en `PROYECTOS_PROD` confirma este patron operativo:

- La relacion se construye asi:
  - `PROYECTO.ID`
  - `PROYECTO_LECCIONES.PROYECTO_ID`
  - `LECCIONAPRENDIDA.ID`
  - `LECCION.LECCIONAPRENDIDA_ID`
- `LECCION.TEXTOLECCION` funciona como `Titulo de la leccion`.
- `LECCION.DESCRIPCION` funciona como `Descripcion`.
- `LECCIONAPRENDIDA.PREGUNTA_ID` define el bloque de cierre.
- `LECCION.CATEGORIA_ID` define la clasificacion corta que en el formato nuevo se usara como `Etapa del proyecto`.

## Bloques reales usados en produccion

Las preguntas existentes en produccion son:

- `1` - `Que hicimos bien?`
- `2` - `Que debimos haber hecho mejor?`
- `3` - `Que deberiamos dejar de hacer?`
- `4` - `Que no hicimos que debimos haber hecho?`
- `5` - `Cuales fueron las principales complicaciones del proyecto?`

Para el formato nuevo, conserva siempre una de las cinco clasificaciones reales como origen del hallazgo.

Si luego el documento final agrupa visualmente en positivo/correctivo, esa agrupacion no reemplaza la clasificacion original; solo la ordena.

## Clasificaciones reales observadas

Las categorias mas usadas en los cierres revisados fueron:

- `Planificacion`
- `Recurso`
- `Implementacion`
- `Definiciones`

Estas categorias coinciden bien con el campo `Etapa del proyecto` del formato nuevo. Cuando el origen venga de base de datos, conserva esa clasificacion salvo que el usuario pida otra taxonomia.

## Patron de redaccion del titulo

En los proyectos cerrados revisados, los titulos siguen estas reglas:

- Empiezan con verbo en infinitivo o con una construccion accionable.
- Nunca deben quedar como sustantivo suelto, problema aislado o etiqueta abstracta.
- Describen una practica concreta, no una idea abstracta.
- Suelen tener entre `5` y `14` palabras.
- En positivos, destacan una decision o practica que funciono.
- En correctivos, nombran lo que debio definirse, anticiparse, incluirse o revisarse.

Ejemplos observados:

- `Asegurar la adopcion alineando necesidades del cliente a la herramienta`
- `Definir la ventana de pruebas piloto desde la planificacion`
- `Considerar vacaciones del cliente en la planificacion de pruebas y estabilizacion`
- `Estandarizar cargas incrementales y uso de particiones en los procesos de datos`

## Patron de redaccion de la descripcion

En los proyectos cerrados revisados, la descripcion sigue normalmente esta logica:

### Lecciones positivas

1. Expone la practica o condicion que si funciono.
2. Explica el beneficio observado en ejecucion, adopcion, tiempo, soporte o calidad.
3. Cuando aplica, cierra indicando que la practica conviene mantenerla o reutilizarla.

Plantilla mental:

`Se aplico X. Esto permitio Y. Conviene mantener o reutilizar esta practica en futuros proyectos.`

### Lecciones correctivas

1. Expone que no se definio, planifico, valido o considero a tiempo.
2. Explica el impacto real: retrasos, reprocesos, dependencia, carga operativa o mala interpretacion.
3. Cierra con la accion concreta que debe repetirse distinto en futuros proyectos.

Plantilla mental:

`No se hizo X a tiempo. Esto genero Y. Para futuros proyectos, debe hacerse Z desde el inicio o en la etapa correcta.`

## Reglas estrictas de fidelidad

Para no escribir ni mas ni menos de la realidad:

- No uses palabras como `exitoso`, `eficiente`, `adecuado`, `correcto`, `agil`, `rapido`, `estrategico` o `optimizado` si la evidencia no demuestra ese resultado.
- No conviertas una hipotesis en causa raiz confirmada.
- No cierres una leccion correctiva con una recomendacion distinta al problema real observado.
- No omitas el impacto principal cuando ese impacto fue la razon del aprendizaje.
- No escribas una leccion positiva solo porque algo se termino; debe existir una practica concreta que haya aportado al resultado.
- No escribas una leccion correctiva solo porque hubo molestia; debe existir un hecho, impacto y accion concluible para futuro.
- Si el caso historico solo muestra una complicacion y no su solucion futura, pide al usuario la conclusion esperada o redacta la leccion como pendiente de definicion, pero no inventes la recomendacion.

## Antipatrones a evitar

- Titulo abstracto: `Comunicacion con el cliente`
- Titulo exagerado: `Transformar la gestion del soporte del cliente`
- Descripcion inflada: `Esto mejoro radicalmente toda la operacion` sin evidencia real.
- Descripcion incompleta: `Hubo retrasos en pruebas` sin explicar por que y que debe hacerse distinto.
- Descripcion maquillada: suavizar una desviacion importante solo para que el cierre suene mejor.

## Regla de conversion al formato nuevo

Cuando la fuente venga de tablas productivas o de notas historicas:

- Usa `TEXTOLECCION` como base del titulo, pero corrige redaccion si viene muy corto, ambiguo o con ruido.
- Usa `DESCRIPCION` como base del parrafo final, compactandolo si tiene repeticiones o frases residuales.
- Usa `CATEGORIA.NOMBRE` como `Etapa del proyecto`.
- Usa `PREGUNTA.NOMBRE` para decidir si la leccion va al bloque positivo o correctivo.
- Si una leccion viene desde `Principales complicaciones`, reescribela como aprendizaje accionable y no como simple queja o incidente.
- Si una leccion viene con titulo historico no accionable, reescribela antes de cerrar el documento para llevarla a verbo en infinitivo o formulacion concreta equivalente.

## Metodo de conclusion

Para concluir las lecciones del proyecto:

1. Identifica y lee todas las bitacoras que encuentre el proyecto.
2. Levanta hechos relevantes desde bitacoras y evidencias.
3. Identifica causas o decisiones detras de esos hechos.
4. Detecta patrones repetidos de errores, correcciones, bloqueos, acciones acertadas y desviaciones de alcance o tiempo.
5. Separa:
   - practicas que funcionaron bien
   - practicas que faltaron
   - practicas que deben mejorarse o dejar de hacerse
   - complicaciones que dejan una conclusion reusable
6. Convierte cada hallazgo en aprendizaje accionable.
7. Filtra duplicados o lecciones que digan lo mismo con palabras distintas.
8. Reescribe cada leccion para que refleje exactamente el nivel de certeza de la evidencia disponible.
9. Cierra solo entre `3` y `5` lecciones fuertes, claras y no redundantes.

## Checklist previa obligatoria

Antes de redactar cada leccion, valida internamente esta checklist:

1. `Patron detectado`
   - Existe un patron real y no solo un evento aislado.
2. `Evidencia en bitacora o documento`
   - Puedo señalar en que bitacora, evidencia o aclaracion del usuario se sostiene.
3. `Impacto real`
   - Esta claro que consecuencia tuvo: retraso, reproceso, mejora, soporte, claridad, calidad, adopcion o similar.
4. `Accion futura o conclusion reusable`
   - La leccion deja claro que mantener, corregir, anticipar, evitar o repetir en futuros proyectos.
5. `Clasificacion de cierre`
   - La leccion cae claramente en una de las cinco clasificaciones obligatorias.
6. `Etapa del proyecto`
   - La etapa o categoria corta esta suficientemente sustentada.

Si cualquiera de estos puntos falla, no cierres la leccion todavia:

- relee bitacoras
- busca evidencia adicional
- o pide informacion al usuario

## Checklist de descarte

Descarta una posible leccion si ocurre cualquiera de estos casos:

- solo describe un incidente sin patron ni conclusion reusable
- no tiene evidencia suficiente en bitacoras, documentos o aclaracion del usuario
- repite otra leccion ya redactada con palabras distintas
- su impacto real no esta claro
- obliga a inventar causa, beneficio o recomendacion

## Uso por el agente

- Si el usuario pide redactar `lecciones aprendidas`, lee primero todas las bitacoras que encuentre en `proyecto/` y luego las evidencias documentales antes de escribir.
- Identifica primero si cada hallazgo es positivo o correctivo y en cual de las cinco clasificaciones obligatorias cae.
- Si el usuario entrega notas sueltas, transformalas al formato de tres campos sin perder el sentido del hallazgo.
- Si el usuario no entrega notas suficientes y las bitacoras tampoco explican causas y decisiones, pide informacion puntual al usuario.
- Si las bitacoras muestran eventos aislados pero no un patron claro, no cierres la leccion como conclusion definitiva sin validar con el usuario.
- Si falta la etapa, inferirla solo cuando sea evidente; si no, dejarlo como pendiente para validacion del usuario.
- Si encuentras mas de `5` posibles hallazgos, prioriza los mas reutilizables y con mayor impacto para futuros proyectos.
- Antes de cerrar `proyecto/07_cierre/lecciones_aprendidas.md`, revisa que las lecciones no repitan el mismo aprendizaje con palabras distintas.
