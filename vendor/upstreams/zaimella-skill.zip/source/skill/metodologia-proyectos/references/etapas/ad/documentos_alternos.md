# AD - Documentos alternos

## Usar cuando se necesite mayor control del analisis

- Catalogo de requerimientos.
- Matriz de alcance.
- Matriz de dependencias.
- Lista de validaciones pendientes.
- Analisis de impacto.
- Matriz requerimiento-solucion.
- Catalogo de objetos tecnicos.
- Diagramas de flujo o arquitectura.
- Flujo TO-BE.
- Matriz de casos de uso y criterios de aceptación.
- Prototipos y registro de validación funcional.
- Especificacion de interfaces o integraciones.

## Criterio de uso

Agregar estos documentos cuando el proyecto tenga varios modulos, integraciones, varias tecnologias, riesgos de interpretacion o multiples interesados validadores.

`AD-portal` ya no se considera documento alterno. Forma parte obligatoria de la salida de `AD` y se regula en el documento principal y en las reglas de la etapa.
