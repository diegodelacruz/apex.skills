# AD funcional: TO-BE, casos de uso y prototipos

## Propósito

Convertir el alcance aprobado en una operación futura validable antes de congelar la definición técnica. El resultado sirve de puente entre RI y AD técnico.

## TO-BE

Describir el flujo futuro por pasos: actor, acción, sistema o canal objetivo, entrada, salida, regla, control, excepción y trazabilidad. Cada diferencia relevante con el AS-IS debe relacionarse con un problema, riesgo u oportunidad del RI.

## Casos de uso

Crear casos de uso cuando haya interacción humana, decisiones, estados, permisos, validaciones, excepciones o integraciones que deban acordarse. Cada caso debe tener: identificador, objetivo, actores, precondiciones, disparador, flujo principal, alternos/excepciones, reglas, datos, resultado y criterio de aceptación.

No crear casos de uso artificiales para tareas puramente técnicas. Mantener una matriz que relacione caso de uso, punto de RI, TO-BE, prototipo, bloque técnico de AD y pruebas.

## Prototipos

Usar prototipos para pantallas, recorridos, decisiones de experiencia o validaciones difíciles de explicar en texto. Registrar: versión, objetivo, casos de uso cubiertos, pantallas/flujo, decisiones validadas, observaciones, pendientes y aprobación. Un prototipo no reemplaza requisitos, reglas de negocio ni diseño técnico.

## Propuesta funcional

Generar `proyecto/03_diseno_funcional/propuesta/propuesta_funcional.md` cuando se deba presentar la solución antes de elaborar el AD. Debe consolidar, sin inventar definición técnica:

1. necesidad y objetivo aprobados;
2. procesos incluidos y principales problemas/riesgos atendidos;
3. resumen del TO-BE;
4. casos de uso y prototipos cubiertos;
5. beneficios, alcance, exclusiones y dependencias;
6. decisiones requeridas para pasar al AD técnico.

La propuesta usa lenguaje ejecutivo y funcional. Si se requiere una propuesta comercial, mantener separados los términos comerciales de los requisitos y decisiones funcionales.

## Gate hacia AD técnico

No cerrar el diseño funcional si un flujo crítico, una regla de negocio, una excepción, un permiso o una decisión de prototipo continúa pendiente. El AD técnico debe incorporar las decisiones confirmadas; las pendientes quedan como bloqueos formales.
