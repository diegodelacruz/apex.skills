# AD - Documento principal

## Archivos finales

`proyecto/04_ad/ad.docx`
`proyecto/04_ad/ad-portal.docx`

El `AD` debe generarse siempre junto con su variante `AD-portal`. Ambos deben mantener el mismo contenido base; solo cambia el orden de las secciones principales.

## Carpeta de insumos

`proyecto/04_ad/documentos/`

## Contexto tecnico

- Crear y mantener `desarrollo.md` para registrar el contexto tecnico del AD.
- En `desarrollo.md`, registrar al menos:
  - tecnologia
  - aplicacion origen
  - modulo
  - aplicacion destino si existe
  - observaciones tecnicas relevantes
- Si el proyecto es APEX, usar `desarrollo.md` para identificar que aplicacion y que modulo se deben analizar.
- Si el proyecto es APEX, usar `plantilla-proyecto-apex/apex/` como ubicacion esperada de los archivos de aplicacion a revisar.

## Estructura general obligatoria

El AD debe iniciar con un `Resumen ejecutivo` y luego organizarse con dos secciones principales adicionales:

- `Resumen ejecutivo`
- `Analisis`
- `Definicion`

## Contenido esperado por seccion

### Resumen ejecutivo

- Ubicar esta seccion al inicio del documento, antes del desarrollo detallado.
- Resumir los principales puntos que se van a realizar en la solucion.
- Presentar cada punto con un titulo y una descripcion corta.
- Mantener un nivel ejecutivo no tecnico: claro, concreto y facil de entender para gerencia, cliente y usuarios no tecnicos.
- Evitar en esta seccion tablas, nombres de objetos tecnicos, siglas internas, detalle de arquitectura, scripts o definiciones de implementacion.
- No usar numeros de aplicacion, IDs internos, nombres de esquema, nombres de paquetes, nombres de tablas ni codigos tecnicos aislados como si fueran comprensibles para el lector.
- Si el alcance nace de APEX, Oracle, Java, AWS u otra tecnologia, traducir esos referentes a nombres funcionales o de negocio cuando exista forma entendible de decirlo, por ejemplo `aplicacion de contratos`, `portal de encuestas`, `servicio de correo` o `plataforma de integraciones`.
- Si un identificador tecnico es necesario para trazabilidad, dejarlo fuera del `Resumen ejecutivo` y ubicarlo en `Analisis` o `Definicion`.
- Considerar incorrecta una redaccion ejecutiva como `alcance APEX en 145 y frente de encuestas de 132`; debe convertirse en una formulacion entendible como `alcance en la aplicacion de contratos y en el portal de encuestas`.
- No reemplazar el detalle posterior; esta seccion solo anticipa los componentes o frentes principales del trabajo.

### Analisis

- Abrir `Analisis` con un primer parrafo de objetivo tecnico.
- En ese primer parrafo, resumir el requerimiento aprobado en RI con enfoque tecnico.
- Indicar que se va a migrar, construir, reemplazar o ajustar.
- Precisar origen y destino cuando aplique, por ejemplo aplicacion origen y aplicacion destino, esquema actual y esquema objetivo, proceso actual y proceso objetivo.
- Incluir el alcance tecnico principal: paginas, tablas, vistas, paquetes, integraciones, reportes, adjuntos u otros componentes que entran en el proyecto.
- Redactar de forma directa, como parrafo de arranque del analisis, no como introduccion extensa.
- No usar un titulo `Objetivo` ni variantes redundantes como `Objetivo y alcance aprobado desde RI` para ese contenido; debe quedar integrado como texto continuo del primer parrafo de `Analisis`.
- No volver a redactar completos el `Antecedente`, los `Problemas actuales` ni las `Oportunidades` del `RI`.
- Si el `RI` proviene del cliente, del usuario final o de un tercero, conservar su definicion de negocio como base y limitarse a resumir solo lo necesario para introducir el analisis tecnico.
- Si el `RI` proviene del cliente, no asumir que el nombre funcional del proceso coincide con el nombre tecnico de la pantalla o pagina que se debe intervenir.
- Documentar la situacion actual del alcance.
- Si existe un subtitulo `Fuentes revisadas`, listar solo insumos tecnicos o documentales de trabajo de la etapa; no incluir `RI aprobado` como fuente listada porque ya es entrada formal obligatoria de `AD`.
- Si existe un texto introductorio para `Fuentes revisadas`, mantenerlo breve y natural, por ejemplo `Se revisaron las siguientes fuentes:`.
- Cuando ya exista `Aplicacion origen`, no repetir la misma idea con etiquetas redundantes como `Fuente analizada`; en esos casos, usar descripciones mas precisas para insumos tecnicos revisados o eliminar la fila si no aporta informacion nueva.
- Listar aplicaciones, paginas, pantallas revisadas y su funcion actual.
- Listar tablas, vistas, paquetes, procedimientos, jobs, integraciones y demas objetos tecnicos involucrados.
- Incluir capturas o disenos actuales si existen; si no existen, documentar el estado actual de las pantallas desde metadata o insumos tecnicos disponibles, sin usar un tono de queja o justificativo.
- Si el `RI` incluye capturas o imagenes donde el cliente marca o muestra la pantalla objetivo, usar esa evidencia visual para identificar la pagina o pantalla correcta, aunque el texto describa el proceso con un nombre de negocio distinto al nombre tecnico de la pantalla.
- Registrar hallazgos encontrados: duplicidades, redundancias, dependencias legacy, inconsistencias de datos, riesgos y restricciones.
- Mantener trazabilidad entre lo aprobado en RI y lo encontrado tecnicamente.
- Usar el `RI` como punto de partida y ampliar el detalle tecnico, sin reabrir la definicion de negocio salvo que aparezca un cambio de alcance.
- Si el `RI` externo tiene vacios o contradicciones, no completar negocio por inferencia libre; documentar el impacto tecnico y elevar las aclaraciones necesarias antes del cierre.
- Si el texto del `RI` y la imagen apuntan a pantallas distintas, no elegir una por inferencia libre; documentar la contradiccion y pedir aclaracion antes del cierre.

### Definicion

- Redactar esta seccion como plan tecnico de ejecucion, no como descripcion general.
- Mantener la misma secuencia de los puntos del alcance aprobado como orden principal de la `Definicion`.
- Hacer visible la trazabilidad entre cada punto del alcance y el bloque tecnico del `AD` que lo resuelve, pero con redaccion natural y tecnica, sin mencionar `RI` dentro del texto final.
- Si un punto del alcance requiere varias actividades tecnicas, desarrollarlas como subpuntos dentro del mismo bloque, sin perder la correspondencia con el punto origen.
- Si un punto del alcance contiene varios frentes o subsoluciones independientes, separarlos en subpuntos tecnicos dentro del mismo bloque principal en lugar de redactarlos como una sola tarea continua.
- Dentro de cada subpunto tecnico, agrupar las acciones por fase de construccion y evitar listas excesivamente fragmentadas cuando varias acciones forman una sola unidad tecnica.
- Preferir una redaccion mas corrida y natural, enfocada en como quedara la solucion y como se implementara, antes que una lista demasiado larga de pasos pequenos.
- Si el usuario confirma que un subpunto ya fue resuelto en otro requerimiento o proyecto, declararlo explicitamente como antecedente implementado, cobertura previa o exclusión del alcance actual por resolución ya existente.
- Si el usuario entrega un componente tecnico concreto de otro frente, como repo, API, clase, servicio o job, nombrarlo de forma directa en la `Definicion` en lugar de reemplazarlo por rótulos genericos.
- Enumerar las actividades principales con formato `1.`, `2.`, `3.` y usar subtareas solo cuando aplique.
- Validar que la numeracion quede coherente, continua y sin subtitulos huerfanos.
- Ordenar las actividades en la secuencia real en que deberian ejecutarse o planificarse por sprint, pero sin romper el orden principal heredado del alcance aprobado.
- Definir como debe quedar la solucion objetivo: modelo de datos, paquetes, vistas, integraciones, paginas, diseno de pantallas y comportamiento esperado.
- No usar al documento como sujeto de la redaccion. Evitar frases como `en el presente AD`, `este AD`, `el alcance del AD` o equivalentes dentro de la `Definicion`.
- No aceptar una `Definicion` generica del tipo `se ajustara el proceso` o `se modificara la integracion` sin identificar exactamente que objetos, componentes o artefactos se tocan.
- Considerar incorrecta una `Definicion` como `Aplicacion a intervenir: X. Se ampliara el mapeo y almacenamiento...` si no aterriza que paginas, modulos, tablas, vistas, paquetes, procedimientos, reportes, endpoints o servicios se cambian.
- Separar la `Definicion` por tecnologia cuando participen varias tecnologias, manteniendo trazabilidad del alcance en cada una.
- En cada bloque tecnico, indicar explicitamente que se crea, que se modifica, que se reutiliza y que queda fuera de alcance.
- Nombrar de forma directa los objetos tecnicos cuando ya se conozcan: tablas, vistas, paquetes, procedimientos, funciones, jobs, APIs, endpoints, colas, buckets, pipelines, paginas, componentes, reportes, archivos, servicios o equivalentes.
- Si todavia no existe nombre final para un objeto nuevo, describirlo por funcion, responsabilidad, origen, destino y reglas esperadas.
- Para cada componente relevante, documentar al menos proposito, accion a realizar, entradas, salidas, dependencias, validaciones y resultado esperado.
- Si el alcance afecta una aplicacion existente, detallar como minimo paginas o pantallas intervenidas, procesos afectados, reportes impactados y objetos de datos relacionados.
- Si el alcance afecta base de datos, detallar como minimo tablas, vistas, paquetes, procedimientos, funciones, jobs, indices, triggers o estructuras relacionadas.
- Si hay migracion de datos, indicar explicitamente `fuente actual -> destino nuevo`, mecanismo de carga, scripts o paquetes de migracion y validacion de exito.
- Incluir un bloque de validacion de datos o validacion funcional cuando la solucion lo requiera.
- Incluir un bloque de unificaciones o mejoras cuando se consoliden paginas, tablas, procesos o logica.
- Si la tecnologia es APEX, incluir tambien criterios de construccion APEX dentro de `Definicion`.
- Si la tecnologia es APEX y la mayor parte del alcance pertenece a una sola aplicacion, declarar primero la `Aplicacion principal` una sola vez y despues documentar los cambios por pagina.
- En APEX, no redactar cambios con identificadores tecnicos comprimidos o ambiguos como `145 / 416 Rucs atados`; siempre separar contexto de aplicacion y detalle por pagina.
- En APEX, usar como formato base `Pagina <ID> - <Nombre de la pagina>` y desarrollar debajo un parrafo que explique lo que se implementara en esa pagina.
- Cuando exista una aplicacion principal ya declarada, no repetirla en cada punto de pagina salvo que un cambio pertenezca a otra aplicacion.
- Si existen cambios en una aplicacion distinta a la principal, crear un bloque separado para esa aplicacion y luego continuar nuevamente con el detalle por pagina.
- En la redaccion por pagina, evitar rotulos como `Cambio requerido:` si el parrafo ya define de forma clara lo que se hara.
- En la redaccion por pagina, usar verbos de definicion tecnica como `se incorporara`, `se modificara`, `se ajustara`, `se implementara`, `se reemplazara` o equivalentes.
- No dejar placeholders como `Por definir`, `Pendiente` o `Por revisar` en la version final del documento.
- No dejar preguntas abiertas ni frases del tipo `se debe analizar` o `se debe definir` en la version final del documento.
- Si una actividad tecnica adicional resuelve mas de un punto del alcance, integrarla de forma natural dentro del bloque que corresponda o en una subtarea relacionada, en lugar de dejarla aislada sin referencia funcional.
- No redactar frases artificiales como `este punto resuelve el punto 3 del RI`; la correspondencia debe entenderse por la misma secuencia del alcance y por el contenido tecnico desarrollado en cada bloque.
- Cuando aplique, usar una estructura de descomposicion como `A.1`, `A.2`, `A.3` o equivalente natural para separar subfrentes dentro de un mismo punto principal del alcance.
- Si falta el nombre exacto de un job, API, clase, servicio, proceso u objeto tecnico indispensable para definir el cambio, no cerrar el bloque: pedir el dato faltante.
- Si un subpunto supera la longitud razonable de lectura por exceso de microacciones, reagruparlo en menos pasos mas solidos sin perder detalle tecnico relevante.

## Estructura recomendada para AD de desarrollo de software

Usar esta estructura como referencia obligatoria de redaccion. No reemplazarla por titulos libres o creativos si el mismo contenido ya cabe en el primer parrafo de `Analisis` o en los subtitulos tecnicos definidos.

- `Resumen ejecutivo`
  - `1. Titulo del punto`
  - `Descripcion corta del punto`
- `Analisis`
  - `Parrafo inicial de objetivo tecnico`
  - `Fuentes revisadas`
  - `Alcance tecnico de migracion`
  - `Aplicaciones y alcance actual`
  - `Hallazgos encontrados`
- `Definicion`
  - `1. Modelo objetivo`
  - `1.1 Base de datos objetivo`
  - `1.2 Paquetes, vistas e integraciones objetivo`
  - `2. Inventario tecnico por tecnologia`
  - `2.1 Componentes a crear`
  - `2.2 Componentes a modificar`
  - `2.3 Componentes a reutilizar o mantener`
  - `3. Paginas o componentes a construir o ajustar`
  - `3.1 Inventario objetivo`
  - `3.2 Diseno propuesto`
  - `4. Migracion de datos`
  - `5. Validacion de datos o validacion funcional`
  - `6. Unificaciones y mejoras`
  - `7. Criterios de construccion por tecnologia`

## Regla de redaccion para cambios en APEX

Cuando el alcance del `AD` se concentre principalmente en una sola aplicacion APEX, la redaccion debe seguir esta estructura:

- declarar una `Aplicacion principal` al inicio del bloque correspondiente
- listar luego solo las paginas intervenidas con formato `Pagina <ID> - <Nombre de la pagina>`
- redactar debajo de cada pagina un parrafo tecnico que describa lo que se implementara y el comportamiento esperado
- mencionar una segunda aplicacion solo cuando realmente existan cambios fuera de la aplicacion principal

Ejemplo de estructura esperada:

- `Aplicacion principal`
- `La mayoria de los cambios definidos en este analisis se implementaran en la aplicacion 145 - Inteligencia Comercial.`
- `Pagina 416 - Rucs Atados`
- `En esta pagina se incorporara el campo Observaciones en los procesos de atadura y desatadura. El sistema debera permitir registrar el motivo del cambio, el usuario que ejecuta la accion y la fecha en que se realiza el movimiento.`

El agente debe preferir esta forma de redaccion frente a expresiones ambiguas o poco legibles como `145 / 416 Rucs atados debera incorporar...`, porque el `AD` debe poder entenderse sin obligar al lector a interpretar que numero corresponde a la aplicacion y cual a la pagina.

## Minimo obligatorio de detalle en Definicion

Ademas del detalle tecnico, cada bloque principal de `Definicion` debe permitir responder estas dos preguntas sin ambiguedad:

- que necesidad aprobada se esta resolviendo
- como se implementara tecnicamente ese punto

Si esa necesidad aprobada contiene varios subfrentes independientes, el bloque principal tambien debe dejar clara la separacion entre esos subfrentes y la resolucion tecnica especifica de cada uno.
Si una parte del alcance ya fue resuelta previamente o pertenece a un frente segregado con ajuste tecnico identificado, el bloque principal tambien debe declarar de forma explicita esa condicion.
La lectura del bloque debe sentirse como definicion tecnica del cambio y no como minuta de tareas administrativas del documento.

Si la solucion toca una aplicacion, la `Definicion` debe identificar como minimo:

- pagina, pantalla, modulo o componente intervenido
- accion sobre ese componente: crear, modificar, reemplazar, eliminar, reutilizar
- objetos de datos o servicios que usa
- validaciones o reglas relevantes

Si la solucion toca base de datos, la `Definicion` debe identificar como minimo:

- tabla, vista, paquete, procedimiento, funcion, job, trigger, indice u objeto equivalente
- accion sobre ese objeto: crear, modificar, ampliar, migrar, consumir, desactivar
- cambio esperado en estructura, logica o uso
- dependencia con otros objetos o procesos

## Uso por el agente

- Eliminar ambiguedades detectadas en RI.
- Crear o actualizar `desarrollo.md` antes de profundizar el analisis tecnico.
- Abrir el AD con un resumen ejecutivo de los puntos principales a realizar antes del detalle completo.
- Redactar el objetivo tecnico como primer parrafo de `Analisis`, no como titulo principal separado.
- No introducir titulos redundantes como `Objetivo y alcance aprobado desde RI` o `Alcance tecnologico vigente del AD`.
- Expresar definiciones verificables.
- Dejar claro que se construira y como se resolvera tecnicamente.
- Exigir que la `Definicion` identifique exactamente que objetos se crean, modifican, integran, migran o consumen en cada tecnologia.
- Documentar el analisis al nivel que necesita el desarrollador o tecnico responsable.
- Si existe skill tecnico especializado para la tecnologia, usarlo para enriquecer la definicion.
- Pedir informacion faltante antes de cerrar el AD si existe una definicion critica no resuelta.
- Si la definicion tecnica obliga a cambiar el alcance aprobado, devolver el ajuste a `RI` antes de cerrar `AD`.
