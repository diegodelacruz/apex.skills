# Lecciones aprendidas - Documento principal

## Nombre sugerido

Lecciones aprendidas del proyecto

## Archivos finales

`proyecto/07_cierre/lecciones_aprendidas.md`

## Carpeta de insumos

`proyecto/`

## Secciones minimas

- Lecciones aprendidas

## Uso por el agente

- Consolidar solo los aprendizajes reutilizables del proyecto.
- Dejar visibles recomendaciones para futuros proyectos.
- Para `Lecciones aprendidas`, usar el formato definido en [`lecciones_aprendidas.md`](lecciones_aprendidas.md): `Titulo de la leccion`, `Descripcion` y `Etapa del proyecto`.
