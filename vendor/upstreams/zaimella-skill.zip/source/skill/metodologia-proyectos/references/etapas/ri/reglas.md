# RI - Reglas de etapa

## Propósito

Levantar el requerimiento inicial y convertir información operativa en una redacción formal, clara y validable.

## Criterios de entrada

- Existe una necesidad, problema o iniciativa por atender y evidencia suficiente del levantamiento, o un RI externo que se debe tratar como entrada formal.
- Hay al menos un solicitante o área responsable.
- Se puede trabajar sobre el documento RI o sobre una de sus secciones.

## Reglas generales

- Redactar todo en español formal.
- Cuidar correctamente tildes, eñes y caracteres especiales.
- No asumir contenido no confirmado por el usuario.
- Trabajar una sección a la vez.
- Permitir trabajar las secciones en el orden que el usuario necesite.
- Proponer la redacción antes de incorporarla al documento final.
- Trabajar sobre el archivo final `proyecto/02_ri/ri.docx` de la etapa.
- No mezclar conceptos entre secciones.
- Si el usuario entrega contenido que corresponde a otra sección, indicarlo y reubicarlo antes de proponer la redacción.
- Mantener una presentación formal, ordenada y fácil de leer.
- Cuando exista `Antecedente` suficiente, proponer `Problemas actuales` a partir de ese contenido.
- Si los antecedentes no son suficientes para sostener problemas claros, hacer preguntas puntuales antes de redactarlos.
- Mantener el `RI` en lenguaje de negocio y no convertirlo en definición técnica.
- Incorporar los riesgos relevantes identificados en el levantamiento dentro de la sección que corresponda o como bloque explícito si el formato del cliente lo permite; no ocultarlos ni convertirlos en solución técnica.
- No incluir en `RI` actividades de desarrollo, páginas por construir, tablas, vistas, paquetes, scripts, arquitectura, migraciones técnicas ni diseño técnico detallado.
- Dejar el `RI` con suficiente claridad para que `AD` pueda tomar `Antecedente`, `Problemas actuales`, `Objetivo del proyecto` y `Alcance del proyecto` como base formal de entrada.

## Secciones obligatorias del RI

Para el formato RI Zaimella, `Riesgos` es una sección obligatoria. Si el RI externo no puede modificarse, conservar sus riesgos en un documento alterno trazable y referenciarlo desde el RI.

- `Antecedente`
- `Problemas actuales`
- `Riesgos`
- `Objetivo del proyecto`
- `Oportunidades`
- `Alcance del proyecto`

## Reglas específicas por sección

### Antecedente

- Describir únicamente cómo funciona hoy la operación o proceso actual.
- Usar tono descriptivo y neutral.
- No incluir problemas, oportunidades ni soluciones.

### Problemas actuales

- Redactar 3 o 4 problemas como máximo.
- Presentar cada problema con título corto y explicación clara.
- No culpar personas, áreas, sistemas o herramientas.
- No proponer soluciones en esta sección.
- Tomar como base principal el `Antecedente` ya validado.
- Convertir brechas, controles limitados, dispersión, trabajo manual o restricciones observadas en problemas redactados para negocio.
- Si el antecedente no evidencia claramente el problema o su impacto, pedir aclaración al usuario.

### Objetivo del proyecto

- Responder qué capacidad o resultado tendrá la compañía al finalizar el proyecto.
- Enfocarse en valor de negocio.
- No describir tareas, desarrollos ni entregables.

### Oportunidades

- Expresar valor, mejora o ventaja esperada.
- Redactar 3 o 4 puntos claros y concretos.
- No escribirlas como el contrario del problema ni como funcionalidades técnicas.

### Alcance del proyecto

- Iniciar obligatoriamente con `Se requiere:`.
- Desarrollar requerimientos numerados.
- Incluir título y descripción por requerimiento.
- Describir solo lo incluido en el proyecto.
- No incluir beneficios esperados.
- Definir el alcance en términos de lo que negocio aprueba, no en términos de implementación técnica detallada.
- Si es necesario mencionar sistemas, aplicaciones o módulos, usarlos solo como referencia de alcance y contexto, no como diseño técnico final.

## Criterios de aprobación

- Las secciones obligatorias, incluido `Riesgos`, están completas o claramente en validación.
- Cada sección respeta su propósito.
- El contenido es entendible para negocio.
- El usuario aprueba explícitamente cada sección antes de incorporarla.
- En `Problemas actuales`, cada problema debe tener trazabilidad con el `Antecedente` o con una aclaración confirmada por el usuario.
- El `RI` deja base suficiente para iniciar `AD` sin redefinir el requerimiento de negocio.

## Salida mínima

- Documento principal de RI aprobado en `proyecto/02_ri/ri.docx`.
