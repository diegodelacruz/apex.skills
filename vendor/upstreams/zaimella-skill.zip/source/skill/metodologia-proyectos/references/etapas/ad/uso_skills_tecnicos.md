# AD - Coordinacion Con Dominios Tecnicos

## Objetivo

Obtener una definicion tecnica suficiente durante AD sin convertir la metodologia ni el orquestador de proyectos en coordinadores internos de desarrollo.

## Regla General

La etapa AD debe aterrizar la solucion con el nivel necesario para construirla. Cuando se necesite analisis especializado, `Gestion-Proyectos` identifica una capacidad en `commands/orchestrators.json` y delega un paquete al orquestador de dominio propietario, nunca por skill tecnico directo. La metodologia no invoca directamente `desarrollador-apex`, `qa-apex`, `desarrollador-movilmella`, `aws-etl-experto` ni otros skills internos de dominio.

Elegir el orquestador compuesto mas especifico que cubra el resultado completo:

- `Movilmella` para Flutter Movilmella y su backend MVZM relacionado.
- `Desarrollo-AWS` para ETL AWS aunque consulte Oracle/APEX como fuente de solo lectura.
- `Desarrollo-APEX` para soluciones APEX, Oracle u ORDS independientes.

Dividir paquetes solo ante resultados independientes, propietarios distintos o una exclusion declarada. Si no existe orquestador registrado, usar `DOMINIO_SIN_ORQUESTADOR`; no improvisar con un skill tecnico ni crear un orquestador preventivamente. Los nuevos orquestadores se diseñan cuando exista un proyecto o necesidad concreta que permita probarlos.

## Forma De Uso

1. Identificar componentes, tecnologias, dependencias y resultados esperados.
2. Separar decisiones funcionales confirmadas de preguntas tecnicas por resolver.
3. Crear un paquete de analisis con `capability_id`, alcance, exclusiones, entradas, criterios, evidencia e impacto documental.
4. Delegarlo mediante `Gestion-Proyectos` al orquestador propietario.
5. Recibir un handoff trazable con componentes, decisiones, riesgos, evidencia y linea base.
6. Consolidar los resultados compatibles en `proyecto/04_ad/ad.docx` y `ad-portal.docx` cuando aplique. No copiar reglas operativas, worktrees, locks ni QA internos del dominio al AD.

## Cobertura Tecnica Minima

Segun el alcance, identificar paginas o pantallas; servicios, APIs, jobs o procesos; objetos de datos; entradas, salidas, reglas, permisos y dependencias; y estrategias de migracion, integracion, seguridad, observabilidad y aceptacion aplicables.

Para APEX, detallar pagina, objetivo, componentes visibles, datos, validaciones, acciones, objetos y permisos. Para migraciones, relacionar origen/destino, datos/adjuntos y controles de integridad. Para otras tecnologias, declarar la accion exacta sobre cada componente y su resultado verificable.

## Resultado Esperado

El AD debe ser entendible por negocio y el equipo tecnico, mantener trazabilidad con RI y casos de uso, y contener definiciones suficientes sin sustituir el contrato operativo del orquestador de dominio.
