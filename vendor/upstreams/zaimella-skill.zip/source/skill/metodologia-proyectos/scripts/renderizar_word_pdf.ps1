[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$InputPath,
    [Parameter(Mandatory = $true)][string]$PdfPath,
    [switch]$Force
)

$ErrorActionPreference = 'Stop'
$source = (Resolve-Path -LiteralPath $InputPath).Path
$pdf = [IO.Path]::GetFullPath($PdfPath)
[IO.Directory]::CreateDirectory((Split-Path -Parent $pdf)) | Out-Null
if ((Test-Path -LiteralPath $pdf -PathType Leaf) -and -not $Force) {
    throw "El PDF ya existe y no se sobrescribirá: $pdf"
}

$word = $null
$document = $null
try {
    $word = New-Object -ComObject Word.Application
    $word.Visible = $false
    $word.DisplayAlerts = 0
    $document = $word.Documents.Open($source, $false, $true)
    $document.ExportAsFixedFormat($pdf, 17)
    Write-Output "WORD_RENDER_OK pdf=$pdf"
} finally {
    if ($document) {
        $document.Close(0)
        [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($document)
    }
    if ($word) {
        $word.Quit()
        [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($word)
    }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
