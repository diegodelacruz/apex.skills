﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$InputPath,
    [Parameter(Mandatory = $true)][string]$OutputPath,
    [ValidateRange(1, 200)][int]$MaxRows = 40,
    [ValidateRange(1, 100)][int]$MaxColumns = 25,
    [ValidateRange(0, 200)][int]$MaxSampleFormulas = 30,
    [string]$PdfPath,
    [string]$PdfSheet,
    [switch]$Force
)

$ErrorActionPreference = 'Stop'

function Escape-MarkdownCell {
    param($Value)

    if ($null -eq $Value) { return '' }
    return (([string]$Value -replace '\r?\n', ' / ') -replace '\|', '\|').Trim()
}

$source = (Resolve-Path -LiteralPath $InputPath).Path
$output = [IO.Path]::GetFullPath($OutputPath)
[IO.Directory]::CreateDirectory((Split-Path -Parent $output)) | Out-Null
if ((Test-Path -LiteralPath $output -PathType Leaf) -and -not $Force) {
    throw "La inspección ya existe y no se sobrescribirá: $output"
}
if ($PdfPath) {
    $requestedPdf = [IO.Path]::GetFullPath($PdfPath)
    if ((Test-Path -LiteralPath $requestedPdf -PathType Leaf) -and -not $Force) {
        throw "El PDF ya existe y no se sobrescribirá: $requestedPdf"
    }
}

$excel = $null
$workbook = $null
$tempCopy = $null
try {
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $excel.AskToUpdateLinks = $false
    try {
        $workbook = $excel.Workbooks.Open($source, 0, $true)
    } catch {
        $tempCopy = Join-Path ([IO.Path]::GetTempPath()) ("zaimella-metodologia-" + [guid]::NewGuid().ToString('N') + [IO.Path]::GetExtension($source))
        Copy-Item -LiteralPath $source -Destination $tempCopy
        $workbook = $excel.Workbooks.Open($tempCopy, 0, $true)
    }

    $lines = [Collections.Generic.List[string]]::new()
    $lines.Add("# Inspección Excel: $([IO.Path]::GetFileName($source))")
    $lines.Add('')
    $lines.Add('## Metadatos')
    $lines.Add('')
    $lines.Add('- Fuente: `' + [IO.Path]::GetFileName($source) + '`')
    $lines.Add("- Hojas: $($workbook.Worksheets.Count)")
    $lines.Add("- Nombres definidos: $($workbook.Names.Count)")
    $linkSources = $workbook.LinkSources(1)
    $linkCount = if ($null -eq $linkSources) { 0 } else { @($linkSources).Count }
    $lines.Add("- Vínculos externos: $linkCount")
    $lines.Add('- Estado: inspección automática de solo lectura; validar estructura y formato contra el PDF o Excel original.')
    $lines.Add('')

    foreach ($sheet in $workbook.Worksheets) {
        $used = $sheet.UsedRange
        $rowCount = [int]$used.Rows.Count
        $columnCount = [int]$used.Columns.Count
        $sampleRows = [Math]::Min($rowCount, $MaxRows)
        $sampleColumns = [Math]::Min($columnCount, $MaxColumns)
        $sample = $sheet.Range($sheet.Cells.Item($used.Row, $used.Column), $sheet.Cells.Item($used.Row + $sampleRows - 1, $used.Column + $sampleColumns - 1))

        $formulaCount = 0
        try {
            $formulaCells = $used.SpecialCells(-4123)
            $formulaCount = [int]$formulaCells.Count
            [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($formulaCells)
        } catch { $formulaCount = 0 }

        $lines.Add("## Hoja: $($sheet.Name)")
        $lines.Add('')
        $lines.Add("- Visibilidad: $($sheet.Visible)")
        $lines.Add("- Rango usado: $($used.Address($false, $false))")
        $lines.Add("- Filas usadas: $rowCount")
        $lines.Add("- Columnas usadas: $columnCount")
        $lines.Add("- Celdas con fórmula: $formulaCount")
        $lines.Add("- Tablas Excel: $($sheet.ListObjects.Count)")
        $lines.Add("- Gráficos: $($sheet.ChartObjects().Count)")
        $lines.Add("- Muestra extraída: $sampleRows filas x $sampleColumns columnas")
        $lines.Add('')

        $header = 1..$sampleColumns | ForEach-Object { "C$_" }
        $lines.Add('| ' + ($header -join ' | ') + ' |')
        $lines.Add('| ' + (($header | ForEach-Object { '---' }) -join ' | ') + ' |')
        $values = $sample.Value2
        $formulas = $sample.Formula
        for ($rowIndex = 1; $rowIndex -le $sampleRows; $rowIndex++) {
            $rowValues = [Collections.Generic.List[string]]::new()
            for ($columnIndex = 1; $columnIndex -le $sampleColumns; $columnIndex++) {
                if ($sampleRows -eq 1 -and $sampleColumns -eq 1) {
                    $value = $values
                } else {
                    $value = $values[$rowIndex, $columnIndex]
                }
                $rowValues.Add((Escape-MarkdownCell $value))
            }
            $lines.Add('| ' + ($rowValues -join ' | ') + ' |')
        }
        $lines.Add('')

        if ($MaxSampleFormulas -gt 0) {
            $sampleFormulaCount = 0
            $lines.Add('### Fórmulas visibles en la muestra')
            $lines.Add('')
            for ($rowIndex = 1; $rowIndex -le $sampleRows -and $sampleFormulaCount -lt $MaxSampleFormulas; $rowIndex++) {
                for ($columnIndex = 1; $columnIndex -le $sampleColumns -and $sampleFormulaCount -lt $MaxSampleFormulas; $columnIndex++) {
                    if ($sampleRows -eq 1 -and $sampleColumns -eq 1) {
                        $formula = $formulas
                    } else {
                        $formula = $formulas[$rowIndex, $columnIndex]
                    }
                    if (([string]$formula).StartsWith('=')) {
                        $cell = $sample.Cells.Item($rowIndex, $columnIndex)
                        $lines.Add("- $($cell.Address($false, $false)): $formula")
                        $sampleFormulaCount++
                        [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($cell)
                    }
                }
            }
            if ($sampleFormulaCount -eq 0) { $lines.Add('- No se encontraron fórmulas dentro de la muestra extraída.') }
            $lines.Add('')
        }

        [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($sample)
        [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($used)
        [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($sheet)
    }

    [IO.File]::WriteAllLines($output, $lines, [Text.UTF8Encoding]::new($false))

    if ($PdfPath) {
        $pdf = [IO.Path]::GetFullPath($PdfPath)
        [IO.Directory]::CreateDirectory((Split-Path -Parent $pdf)) | Out-Null
        if ($PdfSheet) {
            $pdfWorksheet = $workbook.Worksheets.Item($PdfSheet)
            $pdfWorksheet.ExportAsFixedFormat(0, $pdf)
            [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($pdfWorksheet)
        } else {
            $workbook.ExportAsFixedFormat(0, $pdf)
        }
    }

    Write-Output "EXCEL_INSPECTION_OK output=$output pdf=$PdfPath"
} finally {
    if ($workbook) {
        $workbook.Close($false)
        [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($workbook)
    }
    if ($excel) {
        $excel.Quit()
        [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel)
    }
    if ($tempCopy -and (Test-Path -LiteralPath $tempCopy -PathType Leaf)) {
        Remove-Item -LiteralPath $tempCopy -Force
    }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
