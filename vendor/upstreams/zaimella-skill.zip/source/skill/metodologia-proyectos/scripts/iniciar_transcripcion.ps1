param(
    [Parameter(Mandatory = $true)]
    [string]$InputPath,

    [Parameter(Mandatory = $true)]
    [string]$OutputPath,

    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$')]
    [string]$SourceId,

    [string]$Title,
    [ValidateSet('tiny', 'base', 'small', 'medium', 'large-v3')]
    [string]$Model = 'base',
    [string]$Language = 'es',
    [ValidateRange(1, 64)]
    [int]$CpuThreads = 4,
    [ValidateRange(1, 16)]
    [int]$Workers = 1,
    [string]$PythonCommand = 'python',
    [switch]$Force,
    [switch]$Wait
)

$ErrorActionPreference = 'Stop'

$source = (Resolve-Path -LiteralPath $InputPath).Path
$scriptPath = Join-Path $PSScriptRoot 'transcribir_audio.py'
if (-not (Test-Path -LiteralPath $scriptPath -PathType Leaf)) {
    throw "No se encontró el transcriptor: $scriptPath"
}

$output = [IO.Path]::GetFullPath($OutputPath)
$outputDir = Split-Path -Parent $output
[IO.Directory]::CreateDirectory($outputDir) | Out-Null
if ((Test-Path -LiteralPath $output -PathType Leaf) -and -not $Force) {
    throw "La salida ya existe y no se sobrescribirá: $output. Use -Force solo después de preservar o descartar explícitamente la versión anterior."
}

$logDir = Join-Path $outputDir '_logs'
[IO.Directory]::CreateDirectory($logDir) | Out-Null
$stdout = Join-Path $logDir "${SourceId}.stdout.log"
$stderr = Join-Path $logDir "${SourceId}.stderr.log"
$statePath = Join-Path $logDir "${SourceId}.proceso.md"

if ([string]::IsNullOrWhiteSpace($Title)) {
    $Title = "Transcripción $SourceId"
}

function Quote-ProcessArgument {
    param([string]$Value)
    return '"' + ($Value -replace '(\\*)"', '$1$1\"' -replace '(\\+)$', '$1$1') + '"'
}

$arguments = @(
    (Quote-ProcessArgument $scriptPath),
    (Quote-ProcessArgument $source),
    '--output', (Quote-ProcessArgument $output),
    '--source-id', (Quote-ProcessArgument $SourceId),
    '--title', (Quote-ProcessArgument $Title),
    '--language', (Quote-ProcessArgument $Language),
    '--model', (Quote-ProcessArgument $Model),
    '--cpu-threads', [string]$CpuThreads,
    '--workers', [string]$Workers
) -join ' '
if ($Force) {
    $arguments += ' --force'
}

$process = Start-Process -FilePath $PythonCommand `
    -ArgumentList $arguments `
    -RedirectStandardOutput $stdout `
    -RedirectStandardError $stderr `
    -WindowStyle Hidden `
    -PassThru

$started = Get-Date
$state = @(
    "# Proceso de transcripción $SourceId",
    '',
    "- PID: $($process.Id)",
    "- Inicio: $($started.ToString('yyyy-MM-dd HH:mm:ss zzz'))",
    "- Fuente: ``$source``",
    "- Salida: ``$output``",
    "- Modelo: ``$Model``",
    "- Hilos de CPU: ``$CpuThreads``",
    "- Trabajadores: ``$Workers``",
    "- Stdout: ``$stdout``",
    "- Stderr: ``$stderr``"
)
[IO.File]::WriteAllLines($statePath, $state, [Text.UTF8Encoding]::new($false))

if ($Wait) {
    $process.WaitForExit()
    $process.Refresh()
    $exitCode = $process.ExitCode
    if (($null -ne $exitCode) -and ($exitCode -ne 0)) {
        throw "La transcripción terminó con código $exitCode. Revise $stderr"
    }
    if (-not (Test-Path -LiteralPath $output -PathType Leaf)) {
        throw "El proceso terminó sin generar $output"
    }
}

[pscustomobject]@{
    Pid        = $process.Id
    SourceId   = $SourceId
    OutputPath = $output
    StatePath  = $statePath
    StdoutLog  = $stdout
    StderrLog  = $stderr
    Waiting    = [bool]$Wait
}
