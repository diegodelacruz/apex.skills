#!/usr/bin/env python
"""Audita mecánicamente la estructura y trazabilidad de un levantamiento."""

from __future__ import annotations

import argparse
import os
import re
import tempfile
from dataclasses import dataclass
from pathlib import Path


REQUIRED_PROCESS_FILES = {
    "ficha_proceso.md",
    "as_is.md",
    "sistemas_y_datos.md",
    "evidencia.md",
    "preguntas_pendientes.md",
}


@dataclass
class Finding:
    severity: str
    check: str
    detail: str


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8-sig")


def add(findings: list[Finding], severity: str, check: str, detail: str) -> None:
    findings.append(Finding(severity, check, detail))


def atomic_write(path: Path, content: str) -> None:
    with tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", newline="\n", delete=False, dir=path.parent,
        prefix=f"{path.name}.", suffix=".tmp",
    ) as temporary:
        temporary.write(content)
        temporary_path = Path(temporary.name)
    os.replace(temporary_path, path)


def audit(project: Path) -> list[Finding]:
    findings: list[Finding] = []
    lifting = project / "01_levantamiento"
    required = {
        "inventario_insumos.md", "matriz_correlacion.md", "flujo_actual_resumido.md",
        "levantamiento.md", "analisis/problemas_y_riesgos.md", "analisis/oportunidades.md",
    }
    for relative in sorted(required):
        target = lifting / relative
        add(
            findings,
            "OK" if target.is_file() else "ERROR",
            "archivo_obligatorio",
            f"{relative}: {'presente' if target.is_file() else 'ausente'}",
        )

    inventory_path = lifting / "inventario_insumos.md"
    matrix_path = lifting / "matriz_correlacion.md"
    flow_path = lifting / "flujo_actual_resumido.md"
    if not (inventory_path.is_file() and matrix_path.is_file() and flow_path.is_file()):
        return findings

    inventory = read(inventory_path)
    matrix = read(matrix_path)
    flow = read(flow_path)

    source_rows: dict[str, str] = {}
    for line in inventory.splitlines():
        match = re.match(r"^\|\s*(SRC-\d+)\s*\|", line)
        if match:
            if match.group(1) in source_rows:
                add(findings, "ERROR", "src_unico", f"ID duplicado: {match.group(1)}")
            source_rows[match.group(1)] = line
    add(
        findings, "OK" if source_rows else "ERROR", "inventario_src",
        f"Fuentes inventariadas: {len(source_rows)}",
    )

    for source_id, row in sorted(source_rows.items()):
        cells = [cell.strip().lower() for cell in row.strip().strip("|").split("|")]
        source_type = cells[2] if len(cells) > 2 else ""
        if "audio" in source_type or "video" in source_type:
            transcript = lifting / "evidencia" / "transcripciones" / f"{source_id}_transcripcion.md"
            sequence = lifting / "evidencia" / "secuencias" / f"{source_id}_secuencia_detallada.md"
            for artifact, label in ((transcript, "transcripción"), (sequence, "secuencia")):
                add(
                    findings, "OK" if artifact.is_file() else "ERROR", "cobertura_audiovisual",
                    f"{source_id} {label}: {'presente' if artifact.is_file() else 'ausente'}",
                )

    evidence_ids: list[str] = []
    for line in matrix.splitlines():
        match = re.match(r"^\|\s*(EV-\d+)\s*\|", line)
        if match:
            evidence_ids.append(match.group(1))
    duplicate_evidence = sorted({item for item in evidence_ids if evidence_ids.count(item) > 1})
    add(
        findings, "ERROR" if duplicate_evidence else "OK", "ev_unico",
        "Duplicados: " + ", ".join(duplicate_evidence) if duplicate_evidence else f"Evidencias únicas: {len(evidence_ids)}",
    )
    evidence_set = set(evidence_ids)

    flow_rows = [line for line in flow.splitlines() if re.match(r"^\|\s*Paso\s+\d+\s*\|", line)]
    add(
        findings, "OK" if flow_rows else "ERROR", "flujo_resumido",
        f"Pasos resumidos: {len(flow_rows)}",
    )
    for line in flow_rows:
        step = re.match(r"^\|\s*(Paso\s+\d+)", line).group(1)  # type: ignore[union-attr]
        process_match = re.search(r"`procesos/([^/]+)/`", line)
        if not process_match:
            add(findings, "ERROR", "flujo_a_proceso", f"{step}: no enlaza subproceso")
        else:
            process_dir = lifting / "procesos" / process_match.group(1)
            add(
                findings, "OK" if process_dir.is_dir() else "ERROR", "flujo_a_proceso",
                f"{step}: {process_match.group(1)} {'existe' if process_dir.is_dir() else 'no existe'}",
            )
        refs = set(re.findall(r"EV-\d+", line))
        if not refs:
            add(findings, "ERROR", "flujo_a_evidencia", f"{step}: sin EV")
        missing = sorted(refs - evidence_set)
        if missing:
            add(findings, "ERROR", "flujo_a_evidencia", f"{step}: EV no registradas: {', '.join(missing)}")

    process_root = lifting / "procesos"
    process_dirs = sorted(path for path in process_root.iterdir() if path.is_dir()) if process_root.is_dir() else []
    add(
        findings, "OK" if process_dirs else "ERROR", "expedientes",
        f"Subprocesos encontrados: {len(process_dirs)}",
    )
    for process_dir in process_dirs:
        present = {path.name for path in process_dir.iterdir() if path.is_file()}
        missing = sorted(REQUIRED_PROCESS_FILES - present)
        add(
            findings, "ERROR" if missing else "OK", "expediente_completo",
            f"{process_dir.name}: " + ("faltan " + ", ".join(missing) if missing else "5/5 archivos"),
        )
        as_is = process_dir / "as_is.md"
        if not as_is.is_file():
            continue
        action_rows = [
            line for line in read(as_is).splitlines()
            if re.match(r"^\|\s*P\d{2}-\d+\s*\|", line)
        ]
        if not action_rows:
            add(findings, "ERROR", "detalle_as_is", f"{process_dir.name}: no tiene pasos identificables")
            continue
        without_trace = [
            line for line in action_rows
            if not re.search(
                r"EV-\d+|SRC-\d+|Pendiente|Inferido|Confirmado|Observado|POR_VALIDAR",
                line,
                re.IGNORECASE,
            )
        ]
        add(
            findings, "ERROR" if without_trace else "OK", "detalle_as_is",
            f"{process_dir.name}: {len(action_rows)} pasos; {len(without_trace)} sin evidencia/estado",
        )

    used_evidence: set[str] = set()
    for path in lifting.rglob("*.md"):
        if path in {matrix_path, inventory_path} or path.name == "auditoria_mecanica.md":
            continue
        used_evidence.update(re.findall(r"EV-\d+", read(path)))
    ri_assessment = project / "02_ri" / "evaluacion_ri_recibido.md"
    if ri_assessment.is_file():
        used_evidence.update(re.findall(r"EV-\d+", read(ri_assessment)))
    orphaned = sorted(evidence_set - used_evidence)
    add(
        findings, "WARN" if orphaned else "OK", "ev_consumida",
        f"EV registradas sin uso en flujo/expedientes: {', '.join(orphaned)}" if orphaned else "Todas las EV están consumidas",
    )
    return findings


def render(findings: list[Finding], project: Path) -> str:
    errors = sum(item.severity == "ERROR" for item in findings)
    warnings = sum(item.severity == "WARN" for item in findings)
    result = "BLOQUEADO" if errors else ("APROBADO_CON_ADVERTENCIAS" if warnings else "APROBADO")
    lines = [
        "# Auditoría mecánica del levantamiento", "",
        f"- Proyecto: `{project}`", f"- Resultado: `{result}`",
        f"- Errores: `{errors}`", f"- Advertencias: `{warnings}`", "",
        "Esta comprobación valida estructura y referencias; no sustituye la auditoría semántica de `references/calidad_levantamiento.md`.",
        "", "| Severidad | Prueba | Detalle |", "| --- | --- | --- |",
    ]
    for item in findings:
        detail = item.detail.replace("|", "\\|").replace("\n", " ")
        lines.append(f"| {item.severity} | {item.check} | {detail} |")
    lines.append("")
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", required=True, type=Path, help="Carpeta `proyecto/`.")
    parser.add_argument("--output", required=True, type=Path, help="Markdown de auditoría mecánica.")
    parser.add_argument("--force", action="store_true", help="Permite reemplazar la salida existente.")
    args = parser.parse_args()

    project = args.project_root.resolve()
    if not (project / "01_levantamiento").is_dir():
        parser.error(f"No existe 01_levantamiento en {project}")
    if args.output.exists() and not args.force:
        parser.error(f"La salida ya existe y no se sobrescribirá: {args.output}")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    findings = audit(project)
    atomic_write(args.output, render(findings, project))
    errors = sum(item.severity == "ERROR" for item in findings)
    warnings = sum(item.severity == "WARN" for item in findings)
    print(f"LIFTING_AUDIT errors={errors} warnings={warnings} output={args.output}")
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
