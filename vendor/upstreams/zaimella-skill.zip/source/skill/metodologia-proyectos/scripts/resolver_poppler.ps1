[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

function Test-PopplerBin {
    param([Parameter(Mandatory = $true)][string]$BinPath)

    return (
        (Test-Path -LiteralPath (Join-Path $BinPath 'pdftoppm.exe') -PathType Leaf) -and
        (Test-Path -LiteralPath (Join-Path $BinPath 'pdfinfo.exe') -PathType Leaf)
    )
}

$pdftoppmCommand = Get-Command pdftoppm.exe -ErrorAction SilentlyContinue
$pdfinfoCommand = Get-Command pdfinfo.exe -ErrorAction SilentlyContinue
if ($pdftoppmCommand -and $pdfinfoCommand) {
    $popplerBin = Split-Path -Parent $pdftoppmCommand.Source
    if (Test-PopplerBin -BinPath $popplerBin) {
        Write-Output $popplerBin
        exit 0
    }
}

$wingetRoot = Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Packages'
if (Test-Path -LiteralPath $wingetRoot -PathType Container) {
    $candidate = Get-ChildItem -LiteralPath $wingetRoot -Directory -Filter 'oschwartz10612.Poppler*' -ErrorAction SilentlyContinue |
        ForEach-Object {
            Get-ChildItem -LiteralPath $_.FullName -Recurse -File -Filter 'pdftoppm.exe' -ErrorAction SilentlyContinue
        } |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1

    if ($candidate) {
        $popplerBin = Split-Path -Parent $candidate.FullName
        if (Test-PopplerBin -BinPath $popplerBin) {
            Write-Output $popplerBin
            exit 0
        }
    }
}

throw 'No se encontraron pdftoppm.exe y pdfinfo.exe en PATH ni en una instalación oschwartz10612.Poppler administrada por WinGet.'
