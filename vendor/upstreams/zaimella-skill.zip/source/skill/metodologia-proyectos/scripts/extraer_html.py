#!/usr/bin/env python
"""Extrae texto trazable de un HTML local sin cargar recursos externos."""

from __future__ import annotations

import argparse
import hashlib
import os
import re
import tempfile
from html.parser import HTMLParser
from pathlib import Path


BLOCK_TAGS = {
    "address", "article", "aside", "blockquote", "br", "caption", "dd", "div",
    "dt", "footer", "h1", "h2", "h3", "h4", "h5", "h6", "header", "label",
    "li", "main", "nav", "p", "section", "td", "th", "title", "tr",
}
SKIP_TAGS = {"script", "style", "noscript", "svg", "template"}


class LocalHtmlTextExtractor(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.skip_depth = 0
        self.parts: list[str] = []
        self.lines: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag = tag.lower()
        if tag in SKIP_TAGS:
            self.skip_depth += 1
            return
        if self.skip_depth == 0 and tag in BLOCK_TAGS:
            self.flush()

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag in SKIP_TAGS:
            if self.skip_depth > 0:
                self.skip_depth -= 1
            return
        if self.skip_depth == 0 and tag in BLOCK_TAGS:
            self.flush()

    def handle_data(self, data: str) -> None:
        if self.skip_depth == 0 and data:
            self.parts.append(data)

    def flush(self) -> None:
        if not self.parts:
            return
        value = re.sub(r"\s+", " ", " ".join(self.parts)).strip()
        self.parts.clear()
        if value and (not self.lines or self.lines[-1] != value):
            self.lines.append(value)

    def close(self) -> None:
        super().close()
        self.flush()


def atomic_write(path: Path, content: str) -> None:
    with tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", newline="\n", delete=False, dir=path.parent,
        prefix=f"{path.name}.", suffix=".tmp",
    ) as temporary:
        temporary.write(content)
        temporary_path = Path(temporary.name)
    os.replace(temporary_path, path)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="HTML local de entrada.")
    parser.add_argument("--output", required=True, type=Path, help="Markdown de salida.")
    parser.add_argument("--source-id", required=True, help="ID trazable, por ejemplo SRC-001.")
    parser.add_argument("--force", action="store_true", help="Permite reemplazar una salida preservada.")
    args = parser.parse_args()

    if not args.input.is_file():
        parser.error(f"No existe el HTML: {args.input}")
    if args.output.exists() and not args.force:
        parser.error(f"La salida ya existe y no se sobrescribirá: {args.output}")

    raw = args.input.read_bytes()
    text = raw.decode("utf-8-sig", errors="replace")
    extractor = LocalHtmlTextExtractor()
    extractor.feed(text)
    extractor.close()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    content = [
        f"# Extracción HTML {args.source_id}", "", "## Metadatos", "",
        f"- Fuente: `{args.input.name}`", f"- Bytes: `{len(raw)}`",
        f"- SHA-256: `{hashlib.sha256(raw).hexdigest()}`",
        f"- Bloques de texto: `{len(extractor.lines)}`",
        "- Método: parser local; no se ejecutó JavaScript ni se cargaron recursos externos.",
        "- Estado: extracción estructural; validar imágenes, selección de controles y diseño contra la fuente guardada.",
        "", "## Texto", "",
    ]
    content.extend(f"- H-{index:04}: {line}" for index, line in enumerate(extractor.lines, 1))
    content.append("")
    atomic_write(args.output, "\n".join(content))
    print(f"HTML_EXTRACTION_OK blocks={len(extractor.lines)} output={args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
