﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$InputPath,
    [Parameter(Mandatory = $true)][string]$OutputPath,
    [string]$PdfPath,
    [switch]$Force
)

$ErrorActionPreference = 'Stop'

function Escape-MarkdownCell {
    param([AllowEmptyString()][string]$Text)

    if ($null -eq $Text) { return '' }
    return (($Text -replace '\r?\n', ' / ') -replace '\|', '\|').Trim()
}

$source = (Resolve-Path -LiteralPath $InputPath).Path
$output = [IO.Path]::GetFullPath($OutputPath)
$outputDir = Split-Path -Parent $output
[IO.Directory]::CreateDirectory($outputDir) | Out-Null
if ((Test-Path -LiteralPath $output -PathType Leaf) -and -not $Force) {
    throw "La extracción ya existe y no se sobrescribirá: $output"
}
if ($PdfPath) {
    $requestedPdf = [IO.Path]::GetFullPath($PdfPath)
    if ((Test-Path -LiteralPath $requestedPdf -PathType Leaf) -and -not $Force) {
        throw "El PDF ya existe y no se sobrescribirá: $requestedPdf"
    }
}

$word = $null
$document = $null
try {
    $word = New-Object -ComObject Word.Application
    $word.Visible = $false
    $word.DisplayAlerts = 0
    $document = $word.Documents.Open($source, $false, $true)

    $lines = [Collections.Generic.List[string]]::new()
    $lines.Add("# Extracción Word: $([IO.Path]::GetFileName($source))")
    $lines.Add('')
    $lines.Add('## Metadatos')
    $lines.Add('')
    $lines.Add('- Fuente: `' + [IO.Path]::GetFileName($source) + '`')
    $lines.Add("- Páginas estimadas por Word: $($document.ComputeStatistics(2))")
    $lines.Add("- Párrafos: $($document.Paragraphs.Count)")
    $lines.Add("- Tablas: $($document.Tables.Count)")
    $lines.Add("- Imágenes en línea: $($document.InlineShapes.Count)")
    $lines.Add("- Formas flotantes: $($document.Shapes.Count)")
    $lines.Add("- Comentarios: $($document.Comments.Count)")
    $lines.Add('- Estado: extracción automática de solo lectura; validar contenido visual contra el PDF renderizado.')
    $lines.Add('')
    $lines.Add('## Párrafos')
    $lines.Add('')

    $paragraphIndex = 0
    foreach ($paragraph in $document.Paragraphs) {
        $paragraphIndex++
        $text = ($paragraph.Range.Text -replace '[\r\a]+$', '').Trim()
        if (-not $text) { continue }
        $style = ''
        try { $style = [string]$paragraph.Range.Style.NameLocal } catch { $style = '' }
        $lines.Add("- P-$('{0:D4}' -f $paragraphIndex) [$style]: $text")
        [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($paragraph)
    }

    $lines.Add('')
    $lines.Add('## Tablas')
    $lines.Add('')
    for ($tableIndex = 1; $tableIndex -le $document.Tables.Count; $tableIndex++) {
        $table = $document.Tables.Item($tableIndex)
        $lines.Add("### Tabla $tableIndex")
        $lines.Add('')
        $columnCount = $table.Columns.Count
        $headers = 1..$columnCount | ForEach-Object { "Columna $_" }
        $lines.Add('| ' + ($headers -join ' | ') + ' |')
        $lines.Add('| ' + (($headers | ForEach-Object { '---' }) -join ' | ') + ' |')
        for ($rowIndex = 1; $rowIndex -le $table.Rows.Count; $rowIndex++) {
            $values = [Collections.Generic.List[string]]::new()
            for ($columnIndex = 1; $columnIndex -le $columnCount; $columnIndex++) {
                try {
                    $cell = $table.Cell($rowIndex, $columnIndex)
                    $values.Add((Escape-MarkdownCell (($cell.Range.Text -replace '[\r\a]+$', ''))))
                    [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($cell)
                } catch {
                    $values.Add('[celda combinada]')
                }
            }
            $lines.Add('| ' + ($values -join ' | ') + ' |')
        }
        $lines.Add('')
        [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($table)
    }

    if ($document.Comments.Count -gt 0) {
        $lines.Add('## Comentarios')
        $lines.Add('')
        for ($commentIndex = 1; $commentIndex -le $document.Comments.Count; $commentIndex++) {
            $comment = $document.Comments.Item($commentIndex)
            $commentText = ($comment.Range.Text -replace '[\r\a]+$', '').Trim()
            $lines.Add("- C-$('{0:D3}' -f $commentIndex): $commentText")
            [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($comment)
        }
        $lines.Add('')
    }

    [IO.File]::WriteAllLines($output, $lines, [Text.UTF8Encoding]::new($false))

    if ($PdfPath) {
        $pdf = [IO.Path]::GetFullPath($PdfPath)
        [IO.Directory]::CreateDirectory((Split-Path -Parent $pdf)) | Out-Null
        $document.ExportAsFixedFormat($pdf, 17)
    }

    Write-Output "WORD_EXTRACTION_OK output=$output pdf=$PdfPath"
} finally {
    if ($document) {
        $document.Close(0)
        [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($document)
    }
    if ($word) {
        $word.Quit()
        [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($word)
    }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
