[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$InputPath,
    [Parameter(Mandatory = $true)][string]$SheetName,
    [Parameter(Mandatory = $true)][string]$PdfPath,
    [switch]$Force
)

$ErrorActionPreference = 'Stop'
$source = (Resolve-Path -LiteralPath $InputPath).Path
$pdf = [IO.Path]::GetFullPath($PdfPath)
[IO.Directory]::CreateDirectory((Split-Path -Parent $pdf)) | Out-Null
if ((Test-Path -LiteralPath $pdf -PathType Leaf) -and -not $Force) {
    throw "El PDF ya existe y no se sobrescribirá: $pdf"
}

$excel = $null
$workbook = $null
$worksheet = $null
$tempCopy = $null
try {
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $excel.AskToUpdateLinks = $false
    try {
        $workbook = $excel.Workbooks.Open($source, 0, $true)
    } catch {
        $tempCopy = Join-Path ([IO.Path]::GetTempPath()) ("zaimella-metodologia-" + [guid]::NewGuid().ToString('N') + [IO.Path]::GetExtension($source))
        Copy-Item -LiteralPath $source -Destination $tempCopy
        $workbook = $excel.Workbooks.Open($tempCopy, 0, $true)
    }
    $worksheet = $workbook.Worksheets.Item($SheetName)
    $worksheet.ExportAsFixedFormat(0, $pdf)
    Write-Output "EXCEL_RENDER_OK sheet=$SheetName pdf=$pdf"
} finally {
    if ($worksheet) { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($worksheet) }
    if ($workbook) {
        $workbook.Close($false)
        [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($workbook)
    }
    if ($excel) {
        $excel.Quit()
        [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($excel)
    }
    if ($tempCopy -and (Test-Path -LiteralPath $tempCopy -PathType Leaf)) {
        Remove-Item -LiteralPath $tempCopy -Force
    }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
