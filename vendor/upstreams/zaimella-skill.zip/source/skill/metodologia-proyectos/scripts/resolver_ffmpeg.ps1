﻿[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

function Test-FfmpegBin {
    param([Parameter(Mandatory = $true)][string]$BinPath)

    return (
        (Test-Path -LiteralPath (Join-Path $BinPath 'ffmpeg.exe') -PathType Leaf) -and
        (Test-Path -LiteralPath (Join-Path $BinPath 'ffprobe.exe') -PathType Leaf)
    )
}

$ffmpegCommand = Get-Command ffmpeg.exe -ErrorAction SilentlyContinue
$ffprobeCommand = Get-Command ffprobe.exe -ErrorAction SilentlyContinue

if ($ffmpegCommand -and $ffprobeCommand) {
    $ffmpegBin = Split-Path -Parent $ffmpegCommand.Source
    if (Test-FfmpegBin -BinPath $ffmpegBin) {
        Write-Output $ffmpegBin
        exit 0
    }
}

$wingetRoot = Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Packages'
if (Test-Path -LiteralPath $wingetRoot -PathType Container) {
    $candidate = Get-ChildItem -LiteralPath $wingetRoot -Directory -Filter 'Gyan.FFmpeg*' -ErrorAction SilentlyContinue |
        ForEach-Object {
            Get-ChildItem -LiteralPath $_.FullName -Recurse -File -Filter 'ffmpeg.exe' -ErrorAction SilentlyContinue
        } |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1

    if ($candidate) {
        $ffmpegBin = Split-Path -Parent $candidate.FullName
        if (Test-FfmpegBin -BinPath $ffmpegBin) {
            Write-Output $ffmpegBin
            exit 0
        }
    }
}

throw 'No se encontraron ffmpeg.exe y ffprobe.exe en PATH ni en una instalación Gyan.FFmpeg administrada por WinGet.'
