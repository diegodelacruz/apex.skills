#!/usr/bin/env python
"""Genera una transcripción Markdown trazable con faster-whisper."""

from __future__ import annotations

import argparse
import os
import tempfile
from pathlib import Path


def timestamp(seconds: float) -> str:
    total = max(0, round(seconds))
    hours, remainder = divmod(total, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{hours:02}:{minutes:02}:{seconds:02}"


def markdown_cell(value: str) -> str:
    return value.replace("|", "\\|").replace("\r", " ").replace("\n", " ")


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Transcribe audio/video y guarda segmentos con timestamps en Markdown."
    )
    parser.add_argument("input", type=Path, help="Archivo audiovisual de entrada.")
    parser.add_argument("--output", required=True, type=Path, help="Archivo Markdown de salida.")
    parser.add_argument("--source-id", required=True, help="Identificador trazable, por ejemplo SRC-001.")
    parser.add_argument(
        "--title",
        help="Título del Markdown; por defecto se usa 'Transcripción <source-id>'.",
    )
    parser.add_argument("--language", default="es", help="Idioma ISO 639-1; por defecto es.")
    parser.add_argument(
        "--model",
        default="base",
        choices=("tiny", "base", "small", "medium", "large-v3"),
        help="Modelo local. tiny solo para prueba; base es el mínimo recomendado para análisis.",
    )
    parser.add_argument("--compute-type", default="int8", help="Tipo de cómputo; int8 es recomendado para CPU.")
    parser.add_argument(
        "--cpu-threads",
        type=int,
        default=min(4, os.cpu_count() or 1),
        help="Hilos de CPU. El valor por defecto limita el consumo para no bloquear otras herramientas.",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=1,
        help="Trabajadores de transcripción; 1 evita competir por CPU en el análisis documental paralelo.",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Permite reemplazar una salida existente; preservar primero la versión anterior.",
    )
    args = parser.parse_args()

    if not args.input.is_file():
        parser.error(f"No existe el archivo de entrada: {args.input}")
    if args.output.exists() and not args.force:
        parser.error(
            f"La salida ya existe y no se sobrescribirá: {args.output}. "
            "Use --force solo después de preservar o descartar explícitamente la versión anterior."
        )

    from faster_whisper import WhisperModel

    args.output.parent.mkdir(parents=True, exist_ok=True)
    if args.cpu_threads < 1 or args.workers < 1:
        parser.error("--cpu-threads y --workers deben ser mayores que cero.")

    model = WhisperModel(
        args.model,
        device="cpu",
        compute_type=args.compute_type,
        cpu_threads=args.cpu_threads,
        num_workers=args.workers,
    )
    segments, info = model.transcribe(
        str(args.input), language=args.language, vad_filter=True, beam_size=5
    )

    rows = []
    for index, segment in enumerate(segments, start=1):
        text = markdown_cell(segment.text.strip())
        if text:
            rows.append(
                f"| T-{index:04} | {timestamp(segment.start)} | {timestamp(segment.end)} | {text} |"
            )

    segment_rows = rows or ["| - | - | - | No se detectaron segmentos de voz. |"]
    content = [
        f"# {args.title or f'Transcripción {args.source_id}'}",
        "",
        "## Metadatos",
        "",
        f"- Fuente: `{args.input.name}`",
        f"- ID de fuente: `{args.source_id}`",
        f"- Idioma solicitado: `{args.language}`",
        f"- Idioma detectado: `{info.language}`",
        f"- Probabilidad de idioma: `{info.language_probability:.2f}`",
        f"- Modelo: `{args.model}`",
        f"- Hilos de CPU: `{args.cpu_threads}`",
        f"- Trabajadores: `{args.workers}`",
        "- Estado: transcripción automática; validar contra el audio/video antes de usar como hecho confirmado.",
        "",
        "## Segmentos",
        "",
        "| ID | Inicio | Fin | Texto transcrito |",
        "| --- | --- | --- | --- |",
        *segment_rows,
        "",
    ]
    with tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        newline="\n",
        delete=False,
        dir=args.output.parent,
        prefix=f"{args.output.name}.",
        suffix=".tmp",
    ) as temporary:
        temporary.write("\n".join(content))
        temporary_path = Path(temporary.name)
    os.replace(temporary_path, args.output)
    print(f"TRANSCRIPTION_OK segments={len(rows)} output={args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
