---
name: qa-apex
description: Ejecutar QA funcional, auditoria de pantallas, revision de botones, validacion de flujos, capturas reales y reportes QA para aplicaciones Oracle APEX de Zaimella. Usar cuando se deba validar en TEST una version candidata con navegacion y ubicaciones de evidencia entregadas por el contexto, mediante Browser o Playwright reutilizable, sin controlar estados ni coordinacion de tareas.
---

# QA APEX

## Limite de arquitectura

El contexto invocador entrega alcance, version, contrato de navegacion, credenciales autorizadas y rutas de evidencia. Este skill no crea ni administra estructura de proyecto, contratos, bitacoras, estados, worktrees, locks, paquetes ni handoffs; ejecuta QA y devuelve el informe y evidencia en las ubicaciones recibidas.

Skill operativo para QA funcional y evidencia visual de aplicaciones Oracle APEX de Zaimella.

## Gobierno de reglas

- `./references/` contiene las reglas publicadas que viajan con el skill.
- Aplica `./references/estandares-qa-apex.md` como fuente de verdad para navegacion, Playwright, capturas, hallazgos, severidades y salidas.
- No uses scaffolds web ajenos a APEX salvo que el usuario indique explicitamente que el proyecto APEX ya tiene uno aprobado.
- No instales dependencias dentro del proyecto APEX ni investigues `node_modules` locales como parte normal del QA.
- Los estandares publicados son obligatorios; cualquier excepcion requiere autorizacion explicita del usuario y registro de la decision.
- El flujo definido por el usuario, requerimiento, contrato u OpenSpec es vinculante. QA comprueba su mecanismo primario completo y no acepta como equivalente una contingencia, job, sondeo o prueba aislada de un componente. Si el flujo no es comprobable o contiene una contradiccion, emitir la brecha; no reinterpretarlo ni decidir una alternativa.
- Este skill es independiente: recibe alcance, version, navegacion y evidencia; ejecuta QA y emite resultado. No invoca otros skills, no coordina agentes, no asigna correcciones y nunca marca una tarea `Bloqueada` ni decide estados, locks, handoffs o ciclos; esas responsabilidades pertenecen al contexto invocador.
- Para documentacion tecnica externa vigente, usar Context7 cuando este disponible. Respetar la version indicada por el usuario, la aplicacion, el runner registrado o el proyecto; si no existe version definida, usar la version mas reciente disponible en Context7. Context7 no reemplaza rutas funcionales, estandares QA, evidencia real ni el informe obligatorio.
- Para QA de cambios especificados con OpenSpec, usar OpenSpec cuando este disponible. Leer `openspec/changes/<id-cambio>/proposal.md`, specs y `tasks.md` del proyecto objetivo para convertir criterios de aceptacion en escenarios; OpenSpec no reemplaza rutas funcionales, capturas reales ni el informe de `qa/tareas/<ID_TAREA>/reports/`.

## Flujo obligatorio APEX

Toda ruta o nombre de contrato mencionado en este flujo es una entrada entregada por el orquestador. QA no crea, migra, completa ni deduce la arquitectura, contratos o bitacoras; si falta una entrada, devuelve la brecha concreta.

1. Confirmar alcance, ambiente, tipo de QA y version candidata. Para QA visual, leer de `desarrollo.md` la URL de login, el usuario QA y si el login requiere contrasena; recibir APP_ID, PAGE_ID y compania desde el alcance o la navegacion cuando apliquen. No usar valores de identidad o acceso quemados en el skill. Si un campo obligatorio permanece pendiente, emitir preparacion incompleta con el campo exacto.
2. Leer `./references/estandares-qa-apex.md`.
3. Usar exclusivamente la identidad, alcance y autorizacion de ejecucion entregados por el contexto. No descubrir tareas pendientes ni tomar frases historicas como autorizacion.
4. Recibir del contexto invocador alcance, version candidata, evidencia tecnica pre-TEST, ambiente objetivo y, cuando corresponda, ubicacion de entradas y salidas. Para tareas compuestas, recibir la matriz contractual y un escenario por cada ID de subtarea; no aceptar un resultado global que omita una subtarea. No construir rutas operativas a partir de IDs ni asumir una arquitectura de coordinacion. Si falta inventario, auditoria, reconciliacion, cobertura de subtareas o version identificable, emitir `No aprobado` con la brecha concreta. El skill reporta; no decide handoffs, estados ni coordinacion entre agentes.
5. Verificar que la version candidata y TEST coinciden con la evidencia recibida. No adquirir, mantener, liberar ni interpretar locks; el contexto invocador debe entregar la fase autorizada. Si la version no es verificable, emitir `No aprobado por version no verificable`.
6. Usar el QA reutilizable y, cuando el modo sea visual, la navegacion que entregue el contexto. No construir ubicaciones operativas ni sincronizar contratos por cuenta propia.
7. Para `QA técnico acotado`, comprobar su elegibilidad y ejecutar directamente en TEST el contrato reproducible del objeto o rutina con la herramienta Oracle autorizada; registrar antes/despues, limpieza y SHA. Omitir los pasos visuales 8 a 15 y continuar con recuperacion, evidencia, informe y resultado.
8. Para los modos visuales, antes de abrir navegador verificar que la navegacion fue aceptada por el contexto con `NAVIGATION_CONTRACT_OK` y que incluye su mapa funcional generado desde el export candidato; usarlo solo para identificar componentes/acciones del alcance, nunca para inventar rutas. El contrato clasifica `principal`, `secundaria_parametrizada` o `dialogo_modal`: para los dos ultimos, QA sigue obligatoriamente la pagina padre y el parametro/contexto entregados, sin exigir menu ni URL directa. Si falta esa evidencia o el contrato conserva pendientes/marcadores, emitir `No aprobado por navegacion incompleta` sin diagnosticar ni completar login, menu, lanzador o URLs. Con un contrato aceptado, ejecutar la ruta primaria. Si falla, ejecutar una sola alternativa documentada para la misma sesion; no inventar rutas desde metadata, URL directa ni `pInstance`. Si ambas fallan, emitir `No aprobado` con evidencia. El contexto invocador devuelve el hallazgo a Desarrollo para correccion, nuevo candidato y reintento QA.
9. Para los modos visuales, validar el servicio APEX con `scripts/check_apex_web.py --project-root <PROJECT_ROOT>` del skill cuando este disponible; el script debe obtener la URL desde `<PROJECT_ROOT>/desarrollo.md`. `--url` se reserva para un diagnostico standalone autorizado y no reemplaza el contrato del proyecto. Si el script no esta disponible en la instalacion activa del skill, registrar preparacion incompleta y no reimplementar herramientas HTTP salvo autorizacion explicita.
10. Para los modos visuales, si la sesion actual de Codex expone Browser, usarlo como navegador aprobado para el QA autenticado: abrir login, seguir la ruta operativa, comprobar el estado visible y guardar evidencia. No declarar que no hay navegador sin intentar ese Browser.
11. Para los modos visuales, si Browser no esta disponible, usar el runner reutilizable de Playwright registrado en `%USERPROFILE%\.zaimella\qa-tools\playwright\QA_TOOLS.md` o en `docs/logs/qa-tools.md`. No usar runner efimero, `npx`, `npm exec`, `node_modules` del proyecto ni ajustes manuales de `NODE_PATH`.
12. Para los modos visuales, si no hay Browser y el runner registrado no responde, reparar una sola vez con `ensure-playwright-env.ps1 -ProjectRoot .` disponible en la instalacion activa de `qa-apex`, volver a ejecutar el mismo comando y registrar ambos intentos. Solo si persiste, reportar `Preparacion de herramientas QA fallida` con el error exacto.
13. Para los modos visuales, iniciar sesion en APEX TEST con el flujo documentado y navegar por la ruta operativa entregada, o por levantamiento autorizado explicitamente. Si la ruta o funcionamiento es insuficiente, emitir `No aprobado por navegacion incompleta`. Si falta una definicion de negocio, acceso o confirmacion tecnica que solo el usuario puede aportar, emitir `Impedimento externo` con la pregunta y evidencia exactas; no cambiar el estado de la tarea.
14. Para los modos visuales, ejecutar los escenarios del alcance: carga, navegacion, botones, formularios, reportes, filtros, LOVs, validaciones, modales, permisos visibles, mensajes y errores de consola.
15. En `QA funcional`, si el alcance incluye crear, guardar, editar, cargar, adjuntar, aprobar, rechazar o procesar, ejecutar la accion principal en TEST con datos temporales y comprobar `antes / accion / despues`.
    - Para cada dialogo, primero usa su proposito y accion esperada documentados: uno informativo valida contenido, contexto y cierre/retorno; uno de consulta o navegacion valida la accion y destino; uno transaccional o de proceso valida su efecto real (guardar, actualizar, ejecutar procedimiento, accion dinamica, refresh, mensaje o estado) con la comprobacion posterior aplicable. No se asume que todo dialogo debe guardar.
    - Para guardar Ajax o una accion dinamica, comprobar que el control visible y habilitado ejecuta una unica accion, termina su indicador de proceso, muestra resultado y conserva o cambia la vista exactamente como define el contrato. Una mutacion optimista del DOM no es persistencia.
    - Reabrir o recargar la pantalla por la ruta autorizada antes de aprobar una transaccion; la comprobacion posterior no puede depender solo de valores que permanecieron en el DOM de la misma interaccion.
16. Si una validacion o runner termina por timeout, corte local o demora, ejecutar dentro del mismo turno el `Gate terminal y recuperacion de timeout` de la referencia: capturar comando/error/duracion y logs/traces disponibles; cerrar solo procesos propios colgados; aplicar higiene de sesiones Oracle cuando corresponda; clasificar herramienta, autenticacion/navegacion, APEX/servicio/base o defecto funcional; reparar y reintentar por la misma ruta y luego por la alternativa autorizada. Un timeout aislado no es resultado terminal ni `Impedimento externo`.
17. Guardar evidencia en la ubicacion de salida recibida del contexto.
    - En modo `Capturas para manual`, exigir antes de capturar un inventario de cobertura entregado por el contexto: una fila por pantalla, dialogo, accion derivada, tab, acordeon o paso del flujo que el documento deba explicar. Cada fila identifica contrato de navegacion, accion de entrada, captura primaria, resultado/retorno y seccion documental. No completar ni inferir ese inventario desde screenshots historicos.
    - Para tablas, reportes y grillas, capturar solo el viewport normal de escritorio (máximo la pantalla visible de un laptop); queda prohibida la captura `fullPage` o una imagen vertical que concatene todo el scroll. Mostrar encabezado, filtros/barra de acciones y primeras filas; usar capturas adicionales de viewport para acciones o información que no entren en la primera.
    - Recorrer el inventario completo por la ruta funcional. Si una fila carece de contrato suficiente, captura real vigente, dialogo derivado o accion/retorno comprobados, emitir `No aprobado por cobertura de evidencia documental incompleta`. Entregar capturas, manifiesto de cobertura e informe; no redactar ni generar el manual.
18. Generar o actualizar el informe QA en la ubicacion recibida. Para modos visuales, incluir la version candidata y matriz por pagina/flujo en funcionalidad, diseno web APEX y programacion; cada `Cumple` transaccional enlaza antes, clic, resultado y comprobacion independiente. Para `QA técnico acotado`, incluir objeto/rutina o vista, caso directo, antes/despues, limpieza, evidencia y SHA, sin exigir matriz visual.
19. Entregar hallazgos, evidencia y resultado al contexto invocador solo despues de agotar las acciones seguras y ejecutables del skill. Frases como `hasta diagnosticar`, `queda pendiente diagnosticar`, `continuare despues` o equivalentes solo pueden ser avances intermedios mientras el skill sigue trabajando; no son una salida final valida.
20. Emitir el resultado QA para la version identificada: `Aprobado para cierre`, `No aprobado`, `Impedimento tecnico` o `Impedimento externo`. El skill no cambia estados de tarea ni ordena correcciones; el contexto invocador interpreta el resultado y decide el ciclo. Un impedimento solo es salida del skill despues de ejecutar su recuperacion aplicable y no equivale al cierre de la tarea.

## Modos

- `QA funcional`: valida comportamiento real desde login y ruta documentada.
- `QA técnico acotado`: valida directamente en TEST una función, procedimiento, vista, `PACKAGE` o `PACKAGE BODY` sin impacto visible declarado. Exige contrato técnico ejecutable con objeto/rutina, datos o binds, precondición, ejecución, resultado verificable, limpieza y evidencia del mismo SHA. No abre Browser, no exige navegación, capturas ni prueba visual extensa. `VALID` o `ALL_ERRORS=0` no sustituyen la prueba del comportamiento modificado.
- `Auditoria visual`: revisa layout, overflow, responsive, textos, mensajes y consistencia visual.
- `Capturas para manual`: genera evidencia visual real y un manifiesto de cobertura siguiendo rutas funcionales. No redacta el documento.
- `Levantamiento de navegacion`: solo se ejecuta si el usuario lo pide explicitamente; no forma parte del QA normal.

## Salidas esperadas

- Informe QA en la ubicacion recibida, con version candidata, alcance, ambiente, tipo de QA, paginas/flujo u objeto/rutina segun el modo, escenarios, hallazgos, severidad, evidencia y resultado.
- Resultado QA explicito: `Aprobado para cierre`, `No aprobado`, `Impedimento tecnico` o `Impedimento externo`.
- Evidencia visual en la ubicacion recibida solo para los modos visuales.
- Para documentacion, inventario de cobertura con estado por destino y resultado `No aprobado` si queda cualquier fila sin evidencia real. `documentacion-proyecto-sistemas` consume ese handoff y es responsable de redactar el entregable.
- Impedimentos externos concretos cuando falte acceso, servicio APEX, credencial autorizada o una definicion que el skill no pueda resolver; las brechas corregibles de ruta o runner se reportan como `No aprobado` o preparacion fallida, sin marcar la tarea.
