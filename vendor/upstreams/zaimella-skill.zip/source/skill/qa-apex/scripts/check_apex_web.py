from __future__ import annotations

import argparse
import re
import sys
import time
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import Request, urlopen


URL_FIELD = "URL login APEX TEST para QA"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Valida rapidamente si el servicio web APEX responde antes de ejecutar QA."
    )
    parser.add_argument(
        "--url",
        default="",
        help="Override explicito de la URL APEX. El uso normal la lee desde desarrollo.md.",
    )
    parser.add_argument(
        "--project-root",
        default=".",
        help="Raiz del proyecto que contiene desarrollo.md.",
    )
    parser.add_argument(
        "--desarrollo",
        default="",
        help="Ruta explicita a desarrollo.md; prevalece sobre --project-root.",
    )
    parser.add_argument("--timeout", type=float, default=5.0, help="Timeout en segundos.")
    parser.add_argument(
        "--expect-text",
        default="",
        help="Texto opcional que debe existir en la respuesta HTML.",
    )
    parser.add_argument(
        "--config-only",
        action="store_true",
        help="Valida y muestra el origen de la URL sin realizar una solicitud HTTP.",
    )
    return parser.parse_args()


def read_contract_value(path: Path, field: str) -> str:
    try:
        content = path.read_text(encoding="utf-8-sig")
    except FileNotFoundError as exc:
        raise ValueError(f"No existe el contrato: {path}") from exc
    except OSError as exc:
        raise ValueError(f"No se pudo leer el contrato {path}: {exc}") from exc

    pattern = re.compile(rf"^\s*-\s*{re.escape(field)}\s*:\s*(.*?)\s*$", re.MULTILINE)
    match = pattern.search(content)
    if not match:
        raise ValueError(f"Falta el campo '{field}' en {path}")

    value = match.group(1).strip().strip("`")
    if not value or value.startswith("<") or value.upper().startswith("PENDIENTE"):
        raise ValueError(f"El campo '{field}' no esta completo en {path}")
    return value


def resolve_url(args: argparse.Namespace) -> tuple[str, str]:
    if args.url:
        url = args.url.strip()
        source = "--url"
    else:
        contract = (
            Path(args.desarrollo).expanduser()
            if args.desarrollo
            else Path(args.project_root).expanduser() / "desarrollo.md"
        )
        contract = contract.resolve()
        url = read_contract_value(contract, URL_FIELD)
        source = str(contract)

    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError(f"URL APEX invalida obtenida de {source}: {url}")
    return url, source


def main() -> int:
    args = parse_args()
    try:
        url, source = resolve_url(args)
    except ValueError as exc:
        print(f"APEX WEB CONFIG ERROR: {exc}", file=sys.stderr)
        return 6

    print(f"Configuracion URL: {source}")
    if args.config_only:
        print(f"APEX WEB CONFIG OK: {url}")
        return 0

    request = Request(url, headers={"User-Agent": "zaimella-qa-apex-healthcheck/1.0"})
    start = time.monotonic()

    try:
        with urlopen(request, timeout=args.timeout) as response:
            status = response.getcode()
            final_url = response.geturl()
            content_type = response.headers.get("content-type", "")
            body = response.read(300000)
    except HTTPError as exc:
        print(f"APEX WEB ERROR HTTP: {exc.code} {exc.reason} url={url}", file=sys.stderr)
        return 3
    except TimeoutError as exc:
        print(f"APEX WEB TIMEOUT: {url} -> {exc}", file=sys.stderr)
        return 4
    except URLError as exc:
        print(f"APEX WEB NO DISPONIBLE: {url} -> {exc.reason}", file=sys.stderr)
        return 2
    except OSError as exc:
        print(f"APEX WEB NO DISPONIBLE: {url} -> {exc}", file=sys.stderr)
        return 2

    elapsed = time.monotonic() - start
    print(f"APEX WEB OK: status={status} seconds={elapsed:.2f}")
    print(f"URL final: {final_url}")
    print(f"Content-Type: {content_type}")

    if status < 200 or status >= 400:
        print(f"APEX WEB STATUS NO VALIDO: {status}", file=sys.stderr)
        return 3

    if args.expect_text:
        text = body.decode("utf-8", errors="ignore")
        if args.expect_text not in text:
            print(f"APEX WEB TEXTO NO ENCONTRADO: {args.expect_text}", file=sys.stderr)
            return 5
        print(f"Texto esperado encontrado: {args.expect_text}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
