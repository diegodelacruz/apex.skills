param(
  [string]$ProjectRoot = ".",
  [string]$ToolsRoot = "$env:USERPROFILE\.zaimella\qa-tools\playwright"
)

$ErrorActionPreference = "Stop"

function Test-Command([string]$Name) {
  $null -ne (Get-Command $Name -ErrorAction SilentlyContinue)
}

function Refresh-Path {
  $env:Path = @(
    [Environment]::GetEnvironmentVariable("Path", "Machine"),
    [Environment]::GetEnvironmentVariable("Path", "User")
  ) -join ";"
}

if (-not (Test-Command "node") -or -not (Test-Command "npm")) {
  if (-not (Test-Command "winget")) {
    throw "Node.js/npm no estan disponibles y winget no permite repararlos automaticamente."
  }
  winget install --id OpenJS.NodeJS.LTS --silent --accept-package-agreements --accept-source-agreements
  Refresh-Path
  if (-not (Test-Command "node") -or -not (Test-Command "npm")) {
    throw "Node.js/npm no responden despues de la instalacion. Abre una nueva terminal y repite la preparacion QA."
  }
}

$ToolsRoot = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($ToolsRoot)
$ProjectRoot = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($ProjectRoot)
$cli = Join-Path $ToolsRoot "node_modules\.bin\playwright.cmd"
$runner = Join-Path $ToolsRoot "run-playwright.ps1"
$config = Join-Path $ToolsRoot "playwright.config.cjs"
$toolsMd = Join-Path $ToolsRoot "QA_TOOLS.md"

New-Item -ItemType Directory -Force -Path $ToolsRoot | Out-Null
if (-not (Test-Path (Join-Path $ToolsRoot "package.json"))) {
  Set-Content -LiteralPath (Join-Path $ToolsRoot "package.json") -Encoding UTF8 -Value '{"name":"zaimella-qa-tools","private":true}'
}
if (-not (Test-Path $cli)) {
  Push-Location $ToolsRoot
  try {
    npm install @playwright/test
    & $cli install chromium
  } finally { Pop-Location }
}

Set-Content -LiteralPath $config -Encoding UTF8 -Value @'
const { defineConfig, devices } = require('@playwright/test');
module.exports = defineConfig({
  // El runner puede recibir un spec externo al directorio de herramientas.
  // En ese caso QA_APEX_TEST_DIR se define solo para la invocacion actual.
  ...(process.env.QA_APEX_TEST_DIR ? { testDir: process.env.QA_APEX_TEST_DIR } : {}),
  timeout: 120000,
  use: { browserName: 'chromium', screenshot: 'only-on-failure', trace: 'retain-on-failure' },
  projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'] } }]
});
'@

Set-Content -LiteralPath $runner -Encoding UTF8 -Value @'
param([Parameter(ValueFromRemainingArguments = $true)][string[]]$PlaywrightArgs)
$ErrorActionPreference = "Stop"
$cli = Join-Path $PSScriptRoot "node_modules\.bin\playwright.cmd"
$config = Join-Path $PSScriptRoot "playwright.config.cjs"
if (-not (Test-Path $cli)) { throw "Playwright CLI no existe: $cli" }
# Los specs del proyecto no tienen node_modules. El runner corporativo expone
# unicamente sus propias dependencias al proceso hijo, sin modificar el proyecto.
$env:NODE_PATH = Join-Path $PSScriptRoot "node_modules"
if ($PlaywrightArgs.Count -gt 0 -and $PlaywrightArgs[0] -eq "test") {
  $testArgs = @($PlaywrightArgs | Select-Object -Skip 1)
  # Playwright aplica los filtros de archivo dentro de testDir. Al recibir un
  # spec existente por ruta, usar su carpeta como testDir sin mover ni instalar
  # nada dentro del proyecto APEX.
  for ($index = 0; $index -lt $testArgs.Count; $index++) {
    $argument = $testArgs[$index]
    if ($argument.StartsWith("-")) { continue }
    if (Test-Path -LiteralPath $argument -PathType Leaf) {
      $resolvedSpec = (Resolve-Path -LiteralPath $argument).Path
      $env:QA_APEX_TEST_DIR = Split-Path -Parent $resolvedSpec
      # El CLI interpreta argumentos posicionales como expresiones regulares.
      # Usar solo el nombre evita que barras invertidas de una ruta Windows se
      # interpreten como escapes y dejen el spec fuera del filtro.
      $testArgs[$index] = Split-Path -Leaf $resolvedSpec
      break
    }
  }
  & $cli test --config $config @testArgs
} else { & $cli @PlaywrightArgs }
exit $LASTEXITCODE
'@

$version = (& $cli --version) -join " "
$content = @"
# Herramientas QA APEX

- Tools root: $ToolsRoot
- Playwright runner: $runner
- Playwright: $version
- Navegador: Chromium

Usar el runner sin instalar dependencias en el proyecto APEX:

````powershell
powershell -ExecutionPolicy Bypass -File "$runner" --version
````

Para un spec formal ubicado fuera de las herramientas, pasar su ruta completa;
el runner ajusta el descubrimiento solo para esa ejecucion:

````powershell
powershell -ExecutionPolicy Bypass -File "$runner" test "<RUTA_ABSOLUTA_SPEC>" --project=chromium
````
"@
Set-Content -LiteralPath $toolsMd -Encoding UTF8 -Value $content
if (Test-Path $ProjectRoot) {
  $logDir = Join-Path $ProjectRoot "docs\logs"
  New-Item -ItemType Directory -Force -Path $logDir | Out-Null
  Set-Content -LiteralPath (Join-Path $logDir "qa-tools.md") -Encoding UTF8 -Value $content
}
Write-Output "PLAYWRIGHT_RUNNER=$runner"
Write-Output "TOOLS_MD=$toolsMd"
