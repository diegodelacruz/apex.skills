# Auditoria De Estandares APEX

Referencia de QA para evaluar cumplimiento de estandares APEX, diseno web corporativo y programacion asociada. No reemplaza los estandares de desarrollo; resume los criterios que QA debe verificar.

## Ejes De Auditoria

- `Funcionalidad`: la pantalla o flujo permite al usuario completar la accion real con datos, permisos, mensajes y navegacion correctos.
- `Diseno web APEX`: la pantalla cumple estructura visual, componentes y usabilidad corporativa.
- `Programacion`: la implementacion respeta arquitectura APEX/PLSQL verificable desde export APEX, metadata, scripts o evidencia del proyecto.

## Diseno Web APEX

Validar como minimo:

- Titulo visible claro, corto y en espanol.
- Region breadcrumb corporativa `Zaimella Barra de Navegacion` cuando aplique.
- Opcion `t-BreadcrumbRegion--useBreadcrumbTitle` cuando el titulo dependa del breadcrumb corporativo.
- Una sola region `Barra de acciones` con template `Zaimella Barra de Acciones` en paginas principales de mantenimiento o flujo no dialogo.
- Boton de retorno a la izquierda y acciones principales a la derecha dentro de la barra de acciones.
- Botones de accion personalizados de paginas normales con template `Icon`, sin texto visible, con icono semantico y etiqueta accesible; solo los botones finales de dialogo pueden usar template `Text` y etiqueta visible.
- Botones principales no dispersos en regiones inferiores o barras separadas, salvo excepcion documentada.
- Dialogos sin `Barra de acciones`; botones finales agrupados en region final `Botones` con template `Zaimella Grupo Botones`.
- Paginas normales con items de formulario contienen una unica region padre de formulario en `Content Body`; items, subregiones, tablas, reportes y grillas funcionales son descendientes de ella.
- Formularios organizados en dos columnas, maximo dos componentes visibles por fila.
- `Textarea` o `Rich Text Editor` a ancho completo cuando capture informacion amplia.
- Labels visibles claros, en espanol y sin textos genericos como `NEW`.
- Regiones con nombres funcionales claros y agrupacion visual coherente.
- Titulos o etiquetas visibles que permitan distinguir regiones similares y sus estados vacios; nombres internos de metadata no bastan si el usuario no puede identificar la seccion.
- Filtros principales visibles antes del resultado cuando controlen carga de datos.
- Consultas o listados como `Interactive Report`; no `Classic Report`.
- Regiones de tabla, listado, `Interactive Report` o `Interactive Grid` con template `Zaimella Tabla`, titulo funcional en el nombre de region y `Header Text` vacio.
- Acciones personalizadas por fila o toolbar representadas solo por iconos con `title`, `aria-label` o etiqueta accesible equivalente; no enlaces o botones con texto visible.
- `Interactive Grid` solo cuando la region edite informacion.
- Reportes con columnas visibles de nombres completos, sin abreviaturas ambiguas como `Est`, `Ob` o `Nom Repr`.
- Mensajes visibles de exito o error en acciones relevantes.
- Acciones principales visibles, operables y ubicadas en la region prevista; existencia en DOM o metadata sin presencia util en pantalla no cumple.
- Pantallas sin overflow horizontal, sin elementos fuera de viewport y usables en desktop, tablet y mobile cuando aplique.

## Programacion APEX Y PL/SQL

Validar con export APEX, metadata, scripts o evidencia disponible:

- Logica de negocio centralizada en paquetes de base de datos.
- Procesos APEX sin `INSERT`, `UPDATE` o `DELETE` directo de negocio.
- `Interactive Grid - Automatic Row Processing (DML)` no usado para logica de negocio.
- Acciones dinamicas no usadas para reemplazar procesos transaccionales complejos.
- Procesos, botones, regiones y acciones dinamicas con nombres descriptivos.
- Nombres funcionales visibles en espanol.
- Esquema de parsing `DATA` salvo excepcion autorizada.
- Consultas de listas, reportes o regiones filtran por `:G_COMPANIA` cuando la fuente expone `COMPANIA`.
- No existe fallback literal que invente una compania cuando falta `:G_COMPANIA`; cargas y operaciones por identificador validan aislamiento de compania o control equivalente.
- Acciones dependientes de cabecera, identificador, estado, permiso o dato previo tienen condicion, deshabilitacion o rechazo controlado y se prueban antes y despues de satisfacer la precondicion.
- Cada eliminacion iniciada por el usuario, incluida la eliminacion fisica o logica y acciones equivalentes, muestra antes de ejecutar el mensaje exacto `¿Está seguro de eliminar el registro?`; la confirmacion esta asociada a la accion destructiva concreta.
- Cancelar la confirmacion no ejecuta submit, Ajax, PL/SQL, DML, cambio de estado ni navegacion y conserva el registro sin cambios. Aceptarla ejecuta el flujo una sola vez y permite comprobar su resultado o error.
- LOVs y componentes compartidos reutilizados antes de crear nuevos.
- `Select List` limitado a catalogos pequenos, cerrados y de bajo crecimiento; si usa SQL, existe evidencia de origen, cantidad, crecimiento y ausencia de necesidad de busqueda.
- Maestros o catalogos transaccionales que pueden crecer usan `Popup LOV` o `Modal LOV`, nunca `Select List` aunque hoy tengan pocos registros.
- `Popup LOV` permite buscar por los identificadores funcionales necesarios; `Modal LOV` se usa cuando hacen falta volumen alto, filtros o varias columnas para decidir.
- Cargas masivas usan el patron corporativo `100/300` cuando aplique.
- Adjuntos usan patron corporativo o reglas de adjuntos autorizadas; no soluciones ad hoc.
- Paquetes, funciones o procedimientos modificados tienen prueba del caso principal y resultado esperado o error controlado.
- Objetos nuevos o modificados cumplen nomenclatura funcional, comentarios obligatorios y auditoria cuando aplique si la evidencia esta disponible.

## Resultado

Reportar cada eje como:

- `Cumple`: se verifico con evidencia suficiente.
- `No cumple`: existe hallazgo concreto.
- `No evaluado por bloqueo`: falta acceso, export, metadata, scripts o evidencia necesaria.

Los hallazgos altos o criticos de diseno web APEX o programacion bloquean recomendacion de publicacion igual que los hallazgos funcionales.

La salida debe registrar una fila por cada pagina, dialogo o flujo del alcance recibido. QA contrasta la version candidata, la evidencia tecnica entregada, la reconciliacion y TEST; una aprobacion anterior no sobrevive a una version posterior.
