# Preparacion De Ambiente - qa-apex

Usar este prompt antes de ejecutar QA funcional, auditoria visual o capturas documentales con el skill `qa-apex`.

## Repositorio Descargado

Este prompt se ejecuta desde un contexto donde el usuario ya descargo o clono el repositorio de skills y tiene disponibles:

```text
skill/
prompts/
```

La fuente local del skill es:

```text
skill/qa-apex/
```

## Instalar O Actualizar El Skill

- Preparar el ambiente incluye instalar o actualizar el skill `qa-apex`.
- Si el skill no esta instalado, instalarlo desde `skill/qa-apex/` del repositorio descargado en la instalacion activa de Codex.
- Si el skill ya existe, validar que la instalacion activa corresponde a la fuente vigente de `skill/qa-apex/` del repositorio descargado; si no coincide, actualizarla antes de continuar.
- No reemplazar este skill con instrucciones improvisadas ni con prompts copiados al proyecto.

## Requisitos Previos

- Confirmar que el proyecto tiene acceso a APEX TEST o al ambiente indicado por el usuario.
- Confirmar que `<PROJECT_ROOT>/desarrollo.md` contiene URL de login APEX TEST, usuario QA y declaracion de si el login requiere contrasena. Confirmar compania, APP_ID, PAGE_ID y alcance cuando apliquen.
- Confirmar que no se guardaran credenciales, cookies, capturas temporales ni trazas sensibles en el repositorio.
- Confirmar que Python esta disponible para scripts del skill.
- Confirmar que la sesion de Codex expone Browser o que el runner reutilizable de Playwright esta instalado o registrado. Browser es un navegador aprobado para QA autenticado cuando esta disponible.

## Rutas Minimas Del Proyecto

Verificar que el proyecto contenga o haya confirmado:

```text
qa/tareas/<ID_TAREA>/navigation/
qa/tareas/<ID_TAREA>/reports/
qa/tareas/<ID_TAREA>/screenshots/
qa/tareas/<ID_TAREA>/traces/
docs/logs/
```

Si el proyecto usa `zaimella-apex-oracle`, verificar que la navegacion estable este disponible desde:

```text
APEX/<APP_ID>-<CODIGO_O_NOMBRE_APP>/QA/navigation/
```

hacia la copia operativa provista por el contexto:

```text
qa/tareas/<ID_TAREA>/navigation/
```

Este prompt de ambiente instala y valida el skill, runner y servicio APEX; no crea la arquitectura completa del proyecto/contexto. Si faltan entradas operativas, navegacion o estructura del proyecto, reportar `Impedimento tecnico de contexto incompleto`; el skill no cambia el estado de la tarea.

## Validaciones Iniciales

Validar el servicio APEX con el script del skill cuando este disponible:

```powershell
python <RUTA_SKILL_QA_APEX>\scripts\check_apex_web.py --project-root <PROJECT_ROOT>
```

El script obtiene la URL desde `desarrollo.md`. No mantener una segunda URL por defecto en el prompt, el skill, el runner ni el script; `--url` solo se usa para un diagnostico standalone autorizado.

Confirmar Browser disponible en la sesion actual. Solo si no esta disponible, confirmar runner reutilizable:

```text
%USERPROFILE%\.zaimella\qa-tools\playwright\QA_TOOLS.md
docs/logs/qa-tools.md
```

No usar `npx playwright`, `npm exec`, `node_modules` del proyecto ni runners efimeros como reemplazo normal del runner registrado.

Para ejecutar una prueba Playwright formal del proyecto, entregar al runner corporativo un spec existente por ruta absoluta o relativa al directorio actual. El runner debe descubrirlo desde su propia carpeta sin moverlo ni crear dependencias dentro del proyecto:

```powershell
powershell -ExecutionPolicy Bypass -File "<PLAYWRIGHT_RUNNER>" test "<RUTA_SPEC>" --project=chromium
```

Si el alcance incluye capturas documentales, verificar adicionalmente `qa/tareas/<ID_TAREA>/manual-coverage.json`: una fila por pantalla, diálogo, acción derivada, tab, acordeón o paso, enlazada a su contrato de navegación, entrada, resultado/retorno, captura primaria y sección objetivo. Sin ese inventario no se prepara una cobertura completa.

Si Browser no esta disponible y el runner no responde, reparar una sola vez con el script de la instalacion activa de `qa-apex`:

```powershell
powershell -ExecutionPolicy Bypass -File <RUTA_SKILL_QA_APEX>\scripts\ensure-playwright-env.ps1 -ProjectRoot .
```

## Gate De Navegacion

Antes de abrir navegador, debe existir ruta funcional suficiente en `qa/tareas/<ID_TAREA>/navigation/` y `docs/tareas/<ID_TAREA>/tarea.md` debe identificar el commit candidato desplegado en TEST:

- login y entrada real;
- controles visibles de usuario, compania e ingreso, con marcadores que confirman el usuario QA declarado en `desarrollo.md` y la compania aplicada;
- pagina o flujo;
- botones, links o acciones por fila;
- datos minimos;
- resultado esperado;
- mensajes esperados;
- restricciones o permisos relevantes.

Si falta ruta funcional y el usuario no pidio levantamiento, emitir preparacion incompleta al contexto invocador; no dejar la tarea esperando al usuario salvo definicion de negocio no inferible.

Para capturas documentales, si falta una fila del inventario, la captura real o un diálogo derivado, emitir `No aprobado por cobertura de evidencia documental incompleta`; QA no genera DOCX.

Configurar las capturas de manual con viewport de escritorio/laptop y `fullPage=false`. Para tablas largas, usar una captura inicial con controles, encabezados y primeras filas, más capturas de viewport puntuales; no usar una imagen de scroll completo.

Si el portal abre como `nobody` o sin compania, ejecutar primero la recuperacion publicada en `skill/qa-apex/references/estandares-qa-apex.md`: comprobar controles documentados, capturar estado, crear sesion limpia, repetir el login corporativo de TEST con el usuario QA de `desarrollo.md` y la compania contractual, y probar la ruta oficial. No pedir nuevamente al usuario configuracion ya completa; solo escalar si el login cambio realmente o requiere una credencial/acceso no disponible.

## Resultado Esperado

Antes de usar `qa-apex`, el ambiente debe tener:

- servicio APEX validado o bloqueo claro;
- Browser disponible o runner Playwright reutilizable listo; si faltan ambos, bloqueo claro despues de intentar la reparacion autorizada;
- navegacion operativa documentada;
- carpeta de reporte/evidencia disponible;
- alcance y datos minimos confirmados.
