# Prompt De Uso - qa-apex

Usar este prompt en proyectos o contextos que ejecuten QA funcional, auditoria visual o capturas documentales para Oracle APEX.

## Seccion 1 - Contenido Para AGENTS.md

Copiar o fusionar este bloque en el `AGENTS.md` del proyecto/contexto:

```markdown
# Uso Obligatorio De qa-apex

Usar el skill `qa-apex` para QA funcional, auditoria visual, validacion de pantallas, botones, formularios, reportes, modales, flujos APEX, capturas y evidencias. No redacta manuales.

## Fuente De Verdad

- `qa-apex` es la fuente de verdad para QA funcional, Playwright, evidencia, severidades, impedimentos, capturas e informe QA.
- No copiar reglas tecnicas extensas en este `AGENTS.md`; leerlas desde `skill/qa-apex/SKILL.md` y sus `references/`.
- Si falta navegacion, evidencia pre-TEST, datos minimos o trazabilidad de la version candidata, emitir `No aprobado`. Si falta confirmacion tecnica, acceso o definicion de negocio que solo el usuario puede aportar, emitir `Impedimento externo`. El skill nunca marca la tarea `Bloqueada`; reporta y el contexto invocador dirige el siguiente paso.

## Reglas De Uso

- Recibir alcance, version candidata, evidencia pre-TEST y navegacion antes de abrir navegador. Si el contexto define rutas operativas, leerlas sin asumir quien las creo.
- Antes de abrir navegador, exigir `NAVIGATION_CONTRACT_OK` y evidencia existente de ruta primaria/alternativa por cada destino visible. El contrato debe clasificar `principal`, `secundaria_parametrizada` o `dialogo_modal`; QA sigue la pagina padre y parametro/contexto de los dos ultimos sin exigir menu ni URL directa. Si falta o contiene pendientes, emitir `No aprobado por navegacion incompleta`; si la evidencia muestra que el usuario no ve un paso aplicable, emitir `No aprobado por acceso/ruta no entregable`. En ambos casos devolver el control sin explorar login, metadata, lanzador, menu ni URL directa.
- Validar el flujo acordado por su mecanismo primario completo. Una contingencia, job, sondeo o prueba directa a un componente no prueba ni reemplaza el flujo definido. Si existe una brecha o contradiccion, reportarla como `No aprobado` o `Impedimento externo` segun corresponda; QA no decide una alternativa.
- Para una mejora aislada de `PACKAGE`, `PACKAGE BODY`, función, procedimiento o vista sin impacto visible declarado, el contexto puede solicitar `QA técnico acotado`. Debe entregar objeto/rutina, SHA, datos o binds TEST, precondición, ejecución, resultado antes/después, limpieza y riesgos. QA prueba directamente ese caso en TEST y no exige Browser, login, navegación, capturas ni corrida visual extensa. `VALID` y `ALL_ERRORS=0` no sustituyen la prueba directa. Si hay impacto visible, permisos, navegación, persistencia iniciada por usuario, configuración o falta caso reproducible, se exige QA funcional.
- Recibir del contexto la version y fase autorizadas. QA no crea, exige, interpreta, conserva ni libera locks.
- No deducir flujos desde metadata salvo levantamiento autorizado explicitamente.
- No deducir condiciones de servidor, WHERE/filtros, variables/items ni acciones de refresh; deben venir documentadas en los insumos recibidos.
- Leer de `desarrollo.md` la URL de login APEX TEST, el usuario QA y si requiere contrasena; obtener la compania de la tarea o navegacion. Usar esos valores y los controles/marcadores documentados, sin identidades quemadas en estas instrucciones. Si la sesion queda como `nobody` o sin compania, ejecutar recuperacion con sesion limpia y dos intentos por la ruta oficial antes de reportar; no pedir nuevamente configuracion ya completa ni tratarla como impedimento externo.
- Ejecutar acciones principales en APEX TEST con datos temporales de prueba cuando el alcance incluya crear, guardar, editar, cargar, adjuntar, aprobar, rechazar o procesar.
- Para cada accion transaccional, evidenciar `antes -> clic visible -> despues independiente`; reabrir o recargar por la ruta autorizada antes de aprobar. Un selector, mensaje aislado o valor que permanece en el DOM no demuestra persistencia.
- Para cada dialogo, recibir su proposito y flujo: `informativo`, `consulta/navegacion`, `transaccional` o `proceso`, con accion real y efecto esperado. Solo un dialogo transaccional exige guardar/persistencia; uno informativo valida contexto, contenido y cierre sin cambios; uno de proceso debe probar la ejecucion y su resultado. No aprobar por apariencia ni inferir el flujo desde los botones.
- Para capturas documentales, exigir `qa/tareas/<ID_TAREA>/manual-coverage.json` o matriz equivalente: una fila por pantalla, dialogo, accion derivada, tab, acordeon o paso, enlazada al contrato, accion de entrada, resultado/retorno, captura primaria y seccion objetivo. Si una fila falta o no tiene evidencia real, emitir `No aprobado por cobertura de evidencia documental incompleta`. Entregar manifiesto y capturas al contexto; `documentacion-proyecto-sistemas` redacta el documento.
- Las capturas de tablas, reportes y grillas para manual deben ser solo el viewport normal de laptop/escritorio, con filtros/barra de acciones, encabezados y primeras filas visibles. Prohibido usar `fullPage`, stitching o una imagen larga de scroll; usar capturas adicionales de viewport para acciones o detalles fuera de la primera vista.
- No reemplazar la ruta primaria con URL directa ni automatizar acciones mediante JavaScript/DOM oculto. La navegacion dirigida sirve para acelerar la ruta ya entregada, no para omitirla; los dialogos se abren siempre desde su padre.
- Tras corregir un hallazgo, repetir el caso fallido completo y regresion padre/destino sobre un SHA nuevo; no reutilizar evidencia ni aprobar comportamientos que el test no ejecuta y afirma.
- Si el alcance incluye migracion de datos, comprobar en TEST conteos/claves esperadas y ejecutar el proceso funcional consumidor para confirmar que la carga es util y no produjo regresion dentro del alcance.
- Generar o actualizar siempre `qa/tareas/<ID_TAREA>/reports/informe_qa.md`, indicando el SHA validado.
- Incluir en el informe una fila por cada pagina, dialogo o flujo del inventario para funcionalidad, diseno web APEX y programacion; un resultado global o selectores exitosos no sustituyen la cobertura por destino.
- Para una tarea/sprint con subtareas, recibir y reportar una fila por cada ID de subtarea. No emitir `Aprobado para cierre` por un resultado global si una subtarea no tiene escenario, evidencia o veredicto propio.
- Emitir `No aprobado por version no verificable` si TEST no puede vincularse al commit candidato o si el SHA cambia durante QA; no cambiar el estado de la tarea.
- No aprobar si hay hallazgos criticos/altos pendientes, accion principal no probada, ambiente no disponible, ruta incompleta o sesiones Oracle propias pendientes por validaciones del QA.
- Ante timeout del runner o una validacion, diagnosticar y reintentar dentro del mismo turno: guardar comando/error/duracion y logs/traces, cerrar solo procesos propios colgados, revisar sesiones Oracle cuando aplique, clasificar la causa, reparar y repetir por la misma ruta y luego por la alternativa autorizada. Un timeout aislado no es salida final ni impedimento externo.
- No finalizar con acciones propias pendientes ni responder en futuro con `hasta diagnosticar`, `queda pendiente` o `continuare despues`. Esas frases solo pueden usarse como avance intermedio mientras QA sigue ejecutandose.
```

## Seccion 2 - Preparacion O Verificacion De Uso

### 1. Validar Prerrequisito Del Skill

Confirmar repositorio descargado con:

```text
skill/qa-apex/
```

Confirmar que el skill `qa-apex` ya esta instalado y actualizado en la instalacion activa. Si no esta instalado, si no coincide con `skill/qa-apex/` o si hay duda sobre la version activa, detener esta preparacion de uso y ejecutar primero:

```text
skill/qa-apex/references/prompts/preparacion-ambiente.md
```

### 2. Verificar Estructura QA Del Proyecto

Este prompt de uso no crea la arquitectura del proyecto. Verificar que el contexto ya contiene la arquitectura QA requerida.

Verificar que existan, segun el alcance:

```text
qa/tareas/<ID_TAREA>/navigation/
qa/tareas/<ID_TAREA>/reports/
qa/tareas/<ID_TAREA>/screenshots/
qa/tareas/<ID_TAREA>/traces/
docs/logs/
```

Si falta la estructura operativa, no crearla desde este prompt. Emitir preparacion incompleta al contexto invocador; no convertir una brecha resoluble en espera del usuario.

### 3. Verificar Navegacion

Si el proyecto usa `zaimella-apex-oracle`, verificar que existe navegacion estable disponible desde:

```text
APEX/<APP_ID>-<CODIGO_O_NOMBRE_APP>/QA/navigation/
```

hacia la copia operativa de la tarea:

```text
qa/tareas/<ID_TAREA>/navigation/
```

La copia en `qa/tareas/<ID_TAREA>/navigation/` es la operativa para la corrida actual cuando el contexto use esa arquitectura. Si falta, emitir `No aprobado`; el contexto invocador decide la correccion y el handoff.

### 4. Validar Runner Y Servicio

Ejecutar la preparacion tecnica:

```text
skill/qa-apex/references/prompts/preparacion-ambiente.md
```

No iniciar QA normal si falta servicio APEX o ruta funcional suficiente. Para el navegador, usar Browser cuando la sesion lo exponga; solo si Browser no existe, exigir el runner Playwright reutilizable y su reparacion unica antes de reportar un impedimento tecnico.

### 5. Entrega De Preparacion

Informar:

- skill disponible y actualizado;
- estructura QA lista o impedimento de contexto;
- navegacion disponible o `No aprobado` por entrada incompleta;
- runner/servicio validado;
- ruta esperada de `qa/tareas/<ID_TAREA>/reports/informe_qa.md` y commit candidato que se validara.
