# Estandares de Oracle APEX Zaimella

## Objetivo
Definir estandares APEX que QA debe observar al validar aplicaciones Oracle APEX de Zaimella.

## Principios generales
- Oracle APEX debe usarse como capa de presentacion, navegacion, captura y orquestacion.
- La logica de negocio debe centralizarse en paquetes de base de datos.
- Las aplicaciones deben priorizar consistencia funcional, mantenibilidad y reutilizacion.
- El esquema objetivo esperado para objetos de datos es `DATA`, salvo instruccion explicita del proyecto.

## Arquitectura base
- La aplicacion `100` es la aplicacion master.
- Los componentes reutilizables corporativos deben tomarse de la aplicacion `100`.
- La autenticacion centralizada se realiza con el esquema definido en la aplicacion `100`.
- Para aplicaciones nuevas, la suscripcion de tema y menu debe basarse en la aplicacion `100`.

## Alcance de la aplicacion 100
- Contexto: La aplicacion `100` es una aplicacion generica que centraliza desarrollos, componentes y patrones corporativos usados por muchas aplicaciones APEX.
- Estandar: Queda prohibido desarrollar en la aplicacion `100` funcionalidades especificas para una tarea, modulo, compania, usuario, proyecto o aplicacion puntual.
- Estandar: Los desarrollos nuevos en la aplicacion `100` solo se permiten cuando sean estandares reutilizables y exista una necesidad real de uso transversal por varias aplicaciones.
- Estandar: Si una funcionalidad resuelve un caso especifico, debe implementarse en la aplicacion funcional correspondiente y consumir desde `100` solo los componentes genericos aprobados.
- Razon: Usar la aplicacion `100` para casos puntuales contamina la arquitectura comun, aumenta el riesgo de regresiones en otras aplicaciones y dificulta mantener componentes verdaderamente reutilizables.
- Ejemplo: Un cargador, plugin, tema, autenticacion, menu o componente compartido puede vivir en `100` si sera usado por varias aplicaciones. Una validacion, pantalla, proceso o flujo creado solo para una tarea de un modulo especifico no debe desarrollarse en `100`.

## Regla arquitectonica principal
- Toda la logica de negocio debe implementarse en paquetes de base de datos.
- Queda prohibido colocar sentencias `INSERT`, `UPDATE` o `DELETE` de negocio directamente en procesos APEX.
- Oracle APEX debe invocar procedimientos o funciones definidos en paquetes de base de datos para ejecutar la logica transaccional.

## Aplicaciones nuevas
- El nombre de la aplicacion debe ser claro y descriptivo.
- El idioma base debe configurarse en espanol.
- El esquema de parsing debe ser `DATA`.
- Para aplicaciones nuevas, se debe heredar tema, autenticacion y menu desde la aplicacion `100` cuando aplique.

## Nomenclatura
- El nombre de la aplicacion debe ser claro y con palabras completas.
- El nombre de la pagina debe ser claro, corto y con palabras completas.
- Las paginas de dialogo deben iniciar con `Dlg`.
- Las constantes de aplicacion deben iniciar con `APP_`.
- Los application items deben iniciar con `G_`.
- Las listas de valores deben iniciar con `LOV_`.
- Los nombres de botones, regiones, procesos y acciones dinamicas deben ser descriptivos.
- Los nombres funcionales visibles para el usuario deben estar en espanol.

## Paginas
- La numeracion de paginas debe seguir una estructura ordenada por bloques funcionales.
- La numeracion debe iniciar desde `100` para paginas funcionales.
- Se debe agrupar por submodulo usando bloques de `100` cuando la aplicacion lo permita.
- Las paginas modales o auxiliares deben ubicarse cerca de la pagina funcional a la que pertenecen.
- Toda pagina debe mantener consistencia con el diseno corporativo.
- Toda pagina debe tener titulo claro, corto, contenido organizado y acciones visibles segun el caso.
- Toda pagina debe tener de forma obligatoria un titulo claro y corto visible para el usuario final.
- El titulo visible de la pagina debe implementarse con la region breadcrumb corporativa `Zaimella Barra de Navegacion`.
- Esa region debe usar la opcion `t-BreadcrumbRegion--useBreadcrumbTitle` para tomar el titulo actual de la pagina.
- Toda pagina principal de mantenimiento o flujo que no sea dialogo debe tener una unica region `Barra de acciones` con template `Zaimella Barra de Acciones` ubicada en `Breadcrumb Bar`.
- El boton de retorno, como `Atras`, debe ubicarse a la izquierda dentro de esa barra.
- Los demas botones de accion de la pagina deben ubicarse a la derecha dentro de esa misma barra.
- Los botones de accion personalizados de paginas normales deben usar template `Icon`, mostrarse sin texto visible y conservar icono y etiqueta accesible descriptivos. Los controles nativos de APEX quedan fuera de esta regla.
- Solo los botones finales de paginas de dialogo pueden usar template `Text` y etiqueta visible, salvo excepcion autorizada.
- Si el flujo tiene varios retornos posibles, deben resolverse por condicion, manteniendo un solo boton de retorno visible a la izquierda.
- No se deben dispersar los botones principales de la pagina en regiones inferiores o barras separadas, salvo excepcion funcional justificada y documentada.
- Las pantallas modales y no modales deben usarse solo cuando aporten claridad al flujo.

## Regiones y diseno
- Usar regiones para organizar formularios, tablas, filtros y secciones funcionales.
- Los nombres de regiones deben ser claros y descriptivos.
- Usar regiones de contenido estatico para agrupar componentes relacionados cuando mejore orden y mantenibilidad.
- Una pagina normal con items de formulario debe tener una unica region padre de formulario en `Content Body`; todos sus items, subregiones, tablas, reportes y grillas funcionales deben ser descendientes de ella. Breadcrumb y barra de acciones permanecen fuera.
- Las acciones principales de la pagina deben concentrarse en una barra de acciones coherente.
- Los filtros principales deben ubicarse de forma visible antes del resultado cuando controlen carga de datos.

## Reportes y grillas
- No usar `Classic Report`.
- Toda pagina de consulta o listado debe usar `Interactive Report`.
- El `Interactive Report` debe quedar con opciones de busqueda y descarga de informacion.
- Toda region de tabla, listado, `Interactive Report` o `Interactive Grid` debe usar template `Zaimella Tabla`, un titulo funcional definido por el nombre de region y `Header Text` vacio.
- Las acciones personalizadas de tabla, toolbar o fila deben mostrarse solo como iconos con nombre accesible; no como enlaces o botones con texto visible.
- Los nombres de columnas visibles deben ser claros, cortos dentro de lo posible y con palabras completas.
- No se permiten abreviaturas ambiguas o recortes funcionales en columnas visibles como `Est`, `Ob`, `Nom Repr`, `F. Suscrip` o similares.
- En columnas visibles se debe usar siempre un nombre funcional completo como `Estado`, `Observacion`, `Nombre Representante` o `Fecha Suscripcion`.
- Usar `Interactive Grid` solo cuando la experiencia requiera edicion de informacion sobre la tabla.
- Si la region no edita informacion, no debe implementarse como `Interactive Grid`.
- No usar `Interactive Grid - Automatic Row Processing (DML)` para logica de negocio.
- Si un `Interactive Grid` necesita guardar datos de negocio, la persistencia debe delegarse a paquetes de base de datos.
- Si un reporte consulta informacion extensa, debe incorporar filtros principales antes de cargar datos.
- Toda consulta de listas, reportes o regiones APEX debe filtrar por compania con `:G_COMPANIA` cuando la fuente exponga `COMPANIA`.
- La edicion o gestion de registros desde reportes debe dirigir al flujo adecuado de formulario o dialogo cuando eso mejore control y trazabilidad.
- Si la operacion requiere validaciones, aprobaciones o reglas transaccionales, no debe resolverse solo con configuracion declarativa de APEX.

## Dialogos
- Los dialogos se deben usar para capturar o mostrar informacion adicional sin romper el flujo principal.
- El tipo de dialogo debe elegirse entre modal y no modal segun la necesidad funcional.
- Los dialogos no deben usar la region `Barra de acciones` ni el template `Zaimella Barra de Acciones`.
- Todo dialogo que tenga acciones finales debe agrupar sus botones en una region ubicada al final del contenido, normalmente llamada `Botones`, usando el template `Zaimella Grupo Botones`.
- Los botones principales del dialogo, como `Guardar`, `Salir`, `Cancelar`, `Regresar` o `Siguiente`, deben quedar dentro de esa region final y no dispersos en regiones intermedias del formulario.
- Los botones finales del dialogo deben usar template `Text`, etiqueta visible, sin `Icon CSS Classes`, posicion `BELOW_BOX` y alineacion derecha.
- Los botones auxiliares propios de una region interna, como acciones de carga o control de una grilla, pueden vivir dentro de su region solo cuando responden a esa seccion puntual y no reemplazan a los botones finales del dialogo.
- Los botones auxiliares internos de dialogo deben usar template `Icon`, mostrarse sin texto visible y conservar icono y etiqueta accesible descriptivos.
- Los botones de dialogo deben estar agrupados de forma consistente y visible.

## Items y componentes
- Elegir el tipo de item segun volumen y forma de uso de la informacion.
- En pantallas tipo formulario, normales o dialogo, los componentes visibles de captura o consulta deben distribuirse en dos columnas, con maximo dos componentes por fila.
- Esta regla aplica a componentes como `Select List`, `Popup LOV`, `Modal LOV`, `Text Field`, `Number Field`, `Date Picker`, `Display Only`, `Radio Group` y equivalentes que muestran o capturan informacion.
- No se deben dejar tres o mas componentes visibles de formulario en una misma fila, salvo excepcion funcional claramente justificada y documentada.
- Cuando el componente sea `Textarea` o `Rich Text Editor` para capturar informacion amplia, debe ocupar una fila propia a ancho completo en una sola columna visual.
- `Select List` solo para listas pequenas, cerradas y de bajo crecimiento. Un `Select List` SQL requiere evidencia de origen, cantidad, crecimiento y motivo por el que no necesita busqueda.
- No usar `Select List` para maestros o catalogos transaccionales que puedan crecer, como personas, clientes, proveedores, empleados, productos, articulos, documentos, contratos o entidades similares.
- `Popup LOV` para catalogos de tabla que puedan crecer y necesiten busqueda simple por nombre, codigo, identificacion o descripcion.
- `Modal LOV` para busquedas complejas, volumen alto, filtros adicionales o varias columnas relevantes.
- Reutilizar LOVs y componentes compartidos antes de crear nuevos.
- Las LOV que consuman mas de una tabla deben apoyarse en vistas o consultas controladas.
- Evitar listas estaticas cuando el valor deba mantenerse desde base de datos.
- Todo label visible al usuario debe ser claro, estar en espanol y describir el dato esperado.
- No se permiten labels en blanco ni labels con textos genericos como `NEW`.

## Archivos y adjuntos
- El manejo de archivos debe usar componentes y procesos reutilizables definidos por la arquitectura vigente.
- El almacenamiento temporal y procesamiento de archivos debe seguir el patron corporativo aprobado.
- No crear soluciones ad hoc para adjuntos si ya existe un mecanismo compartido.
- La implementacion interna de adjuntos pertenece a los estandares tecnicos del proyecto. Este skill valida solo comportamiento visible, descarga, carga, permisos y evidencia funcional segun `estandares-qa-apex.md`.

## Cargas masivas
- El patron corporativo para cargas masivas desde Excel o CSV es la aplicacion `100`, pagina `300`.
- La pagina `100/300` debe usarse como cargador generico de archivos y no como pagina final de negocio.
- La responsabilidad de `100/300` es recibir el archivo, transformarlo a una coleccion temporal, exponer una previsualizacion y entregar el control a la pagina invocadora.
- La logica funcional de validacion de datos y la persistencia final no deben ejecutarse en `100/300`; deben ejecutarse en la pagina invocadora o en paquetes de base de datos.
- En cualquier página, proceso o componente de la aplicación `100`, queda prohibida la lógica o referencia de negocio de una aplicación invocadora. Si existe aislamiento de sesión/colección, la evidencia QA debe confirmar handoff genérico por identificador de carga y ejecución de la lógica en la aplicación invocadora; una excepción local no es válida.
- El flujo de carga masiva debe consumir la vista `DATA.VT_APEX_EXCEL` como fuente de lectura de la informacion cargada.
- `DATA.VT_APEX_EXCEL` lee la coleccion APEX `TABLA_EXCEL` de la sesion actual. Su columna `ID` es el `SEQ_ID` interno del miembro de la coleccion y no debe usarse como dato de negocio.
- En la implementacion vigente de `100/300`, `VT_APEX_EXCEL.C01` esta reservado para el numero de fila del archivo origen. No representa la primera columna del Excel ni del CSV.
- Las columnas de datos del archivo empiezan en `VT_APEX_EXCEL.C02`: `C02` corresponde a la columna A del Excel o al primer campo del CSV, `C03` a la columna B o segundo campo, y asi sucesivamente hasta `C50`.
- Por ese desplazamiento, la pagina invocadora debe mapear sus columnas de negocio desde `C02` en adelante. Queda prohibido interpretar `C01` como dato funcional salvo que el requerimiento pida explicitamente usar el numero de fila para trazabilidad, errores o auditoria.
- Si la carga usa cabecera, `100/300` toma la primera fila para etiquetas de previsualizacion y la elimina de la coleccion; la pagina invocadora recibe solo filas de datos, pero `C01` conserva el numero de fila original del archivo.
- Antes de aprobar una carga que consuma `DATA.VT_APEX_EXCEL`, exigir evidencia de muestra real en TEST y matriz `columna de negocio -> C0n` contrastada con la plantilla. `C01` es fila origen; el primer dato de negocio es `C02`.
- Cuando el archivo tenga cabecera, la primera fila debe tratarse como encabezado y no como dato de negocio.
- El cargador corporativo de `100/300` trabaja unicamente con la hoja `1` en archivos Excel.
- El cargador corporativo de `100/300` expone `C01..C50` en `VT_APEX_EXCEL`, pero por el uso de `C01` como numero de fila la capacidad de datos de negocio disponible para la pagina invocadora es `C02..C50` hasta `49` columnas. Si un requerimiento necesita 50 columnas de negocio, debe ajustarse el cargador compartido o definirse una excepcion aprobada; no se debe forzar el uso de `C01` como primera columna.
- El boton `Siguiente` debe usarse solo para retornar a la pagina invocadora y continuar la validacion o procesamiento.
- El boton `Siguiente` solo debe estar disponible cuando el flujo haya enviado pagina destino y parametros de retorno validos.
- La pagina invocadora es responsable de validar estructura, columnas esperadas, tipos de dato, reglas funcionales y mensajes al usuario antes de grabar.
- No se deben crear cargadores masivos nuevos por modulo si el requerimiento puede resolverse con el patron corporativo de `100/300`.
- Si un requerimiento de carga masiva necesita una variacion, primero debe justificarse por que el patron `100/300` no cubre la necesidad.

## JavaScript
- La logica JavaScript simple puede vivir en la pagina cuando sea breve y clara.
- La logica JavaScript compleja debe moverse a archivos `.js` reutilizables de la aplicacion.
- No dejar bloques grandes de JavaScript incrustados si afectan mantenibilidad.
- No duplicar funciones JavaScript en varias paginas si pueden centralizarse.

## Processing
- Los procesos deben tener nombres descriptivos.
- No deben contener codigo comentado innecesario.
- Si la logica es extensa, dividir en varios procesos claros o moverla a paquetes.
- Toda transaccion de negocio debe ejecutarse a traves de procedimientos o funciones de paquetes.
- Los procesos no deben contener `INSERT`, `UPDATE` o `DELETE` directos de negocio.
- Si un proceso solo coordina llamada a paquete, su responsabilidad debe quedar clara en el nombre y en el codigo.
- Toda accion iniciada desde APEX que ejecute un proceso, validacion, cambio de estado, guardado, aprobacion, rechazo, carga, eliminacion o cualquier operacion relevante para el usuario debe mostrar un mensaje claro de exito o de error.
- No basta con ejecutar la accion correctamente en backend; el resultado debe quedar visible para el usuario en la interfaz.
- Los mensajes deben ser cortos, claros y entendibles para el usuario final.

## Dynamic Actions
- Las acciones dinamicas deben tener nombres descriptivos.
- No deben contener codigo comentado innecesario.
- Si una accion dinamica requiere logica extensa, se debe dividir o mover la logica a JavaScript reutilizable o a paquetes segun corresponda.
- Toda transaccion de negocio disparada desde una accion dinamica debe ejecutarse a traves de paquetes.
- No usar acciones dinamicas para reemplazar procesos transaccionales complejos.
- Usar acciones dinamicas para comportamiento de interfaz, validaciones ligeras y orquestacion de eventos.
- Si una accion dinamica ejecuta una operacion relevante para el usuario, debe dejar tambien un mensaje claro de exito o de error y no terminar en silencio.

## Reutilizacion
- Reutilizar LOVs, catalogos, plugins y componentes comunes antes de crear nuevos.
- Reutilizar paquetes existentes si ya cubren la necesidad funcional.
- Los plugins corporativos o aprobados deben tomarse desde la aplicacion `100` cuando aplique.
- Antes de crear una nueva pagina, validar si el flujo ya existe en la aplicacion o en otra aplicacion corporativa reutilizable.

## Trazabilidad y depuracion
- Toda operacion critica iniciada desde APEX debe poder rastrearse en base de datos.
- Los errores funcionales y tecnicos deben registrarse con mecanismos estandar definidos por el equipo.
- Los mensajes de exito y error deben mostrarse de forma consistente en toda la aplicacion.
- El agente debe evitar soluciones APEX que dificulten identificar en que pagina, proceso o accion se produjo un error.
- Cada vez que se realice un cambio en el ambiente de test, el agente debe ejecutar el despliegue correspondiente para que el usuario pueda realizar pruebas funcionales sobre el cambio aplicado.

## Publicacion en Test
- La publicacion de cambios APEX en el ambiente TEST declarado en `desarrollo.md` debe ejecutarse sobre el archivo export `.sql` vigente de la aplicacion.
- Antes de publicar, validar conectividad con `python scripts/validate_oracle_connectivity.py --environment test`; solo ejecutar `. .\scripts\set-oracle-env.ps1 -CreateDefaultIfMissing` si el validador reporta variables faltantes.
- El metodo preferido de publicacion en este contexto es `python scripts/import_apex_sql_via_python.py <ruta_export.sql>`.
- No probar `SQLcl`, `sqlplus.exe` ni clientes Oracle alternativos como parte normal de publicacion. Si el importador Python falla por preparacion de herramientas, reportar el error exacto y pedir autorizacion explicita antes de cambiar de herramienta.
- Si el import finaliza sin errores SQL bloqueantes, el cambio debe considerarse publicado.
- Despues de publicar, el agente debe validar en metadata APEX que las paginas o componentes modificados reflejen el cambio esperado antes de informar al usuario que ya puede probar.

## Seguridad
- La autenticacion debe seguir el esquema centralizado de la aplicacion `100`.
- Los accesos y flujos de aprobacion se regiran por las reglas corporativas vigentes.
- La implementacion interna de accesos y aprobaciones pertenece a los estandares tecnicos del proyecto. Este skill valida permisos visibles, flujo autorizado, botones disponibles y resultado funcional segun `estandares-qa-apex.md`.
