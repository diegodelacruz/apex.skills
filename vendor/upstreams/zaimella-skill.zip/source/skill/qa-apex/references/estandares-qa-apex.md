﻿# Estandares QA APEX

Esta referencia define la arquitectura y forma de trabajo para QA funcional, QA tecnico acotado y capturas de manuales en aplicaciones Oracle APEX y sus objetos Oracle asociados.

## Resolucion de rutas por tarea

El orquestador APEX crea y gobierna la arquitectura QA, contratos y rutas. Las rutas historicas de esta referencia son ejemplos de entradas o salidas que el contexto puede entregar; QA no las crea, administra ni deduce.

En contextos por tarea, define obligatoriamente:

```text
QA_RUN_ROOT = qa/tareas/<ID_TAREA>
```

Toda ruta abreviada `qa/navigation`, `qa/reports`, `qa/screenshots`, `qa/traces`, `qa/pages`, `qa/scenarios` o `qa/tests` mencionada en esta referencia se resuelve dentro de `QA_RUN_ROOT`.

Antes de QA, recibe y revisa el alcance, la evidencia tecnica pre-TEST y la version candidata que entregue el contexto invocador. TEST debe corresponder a esa version. Si falta identificador, no puede verificarse TEST o cambia durante la corrida, cierra como `No aprobado por version no identificable`. QA reporta el resultado; no decide el handoff ni modifica estados de otros agentes.

Cuando TEST sea compartido, QA ejecuta solo la version y fase que el contexto invocador entregue como autorizadas. QA no crea, exige, interpreta, conserva ni libera locks. Si la version o la autorizacion de fase no son verificables, emite `No aprobado por version/fase no verificable`; no cambia el estado de la tarea.

## Principio

Contexto:
- Este skill es especifico para Oracle APEX. No debe heredar flujos, comandos ni estructura de QA de otros tipos de proyectos web.

Estandar:
- Para APEX se usa una arquitectura propia basada en Playwright, paginas APEX, export `.sql`, ambiente Oracle y rutas `f?p=APP_ID:PAGE_ID`.
- No se debe exigir scaffolds, rutas tecnicas ni comandos de proyectos web ajenos a APEX salvo que el proyecto APEX ya los tenga aprobados explicitamente.
- En proyectos Zaimella orquestados, el QA APEX debe ejecutarse en TEST: no existe ambiente Oracle DEV. Un entorno local solo aplica a un contexto standalone expresamente identificado y no sustituye la validacion del commit candidato en TEST.
- `desarrollo.md` es la unica fuente de la URL de login APEX TEST, el usuario QA y la declaracion de si el login requiere contrasena. La plantilla del orquestador aporta la URL predeterminada; el skill, sus referencias, scripts y prompts no deben duplicar ese valor ni quemar una identidad.
- Antes de intentar login, navegacion, capturas o QA visual, ejecutar una validacion rapida del servicio web APEX con `scripts/check_apex_web.py --project-root <PROJECT_ROOT>` del skill activo. No buscar ese script dentro del proyecto APEX ni reimplementar validaciones HTTP en cada sesion; si el script no existe en el skill instalado, registrar `Preparacion de herramientas QA fallida` y continuar solo con validaciones no visuales.
- Si el usuario o el alcance indican `APP_ID` y `PAGE_ID`, usar esos datos para identificar la pantalla objetivo. Nunca saltarse el login real; después de una sesión autenticada, una página normal, activa y registrada en el modelo de menú/accesos puede abrirse por URL rápida documentada sin recorrer visualmente el menú.
- Una ruta relativa `f?p=APP_ID:PAGE_ID`, completada con la base APEX de la URL contractual, puede usarse como ruta rapida autorizada para paginas normales con acceso registrado y sesion activa; no debe usarse para abrir dialogos, modales o paginas auxiliares que requieren inicializacion desde una pagina padre.
- Si el servicio APEX web no responde, devuelve timeout, error de red o codigo HTTP de caida, detener solo la ejecucion visual dependiente y emitir `Impedimento externo` con evidencia. QA no cambia el estado de la tarea.

Razon:
- APEX no tiene rutas React ni componentes TypeScript; su inventario funcional sale de paginas, regiones, items, botones, procesos, acciones dinamicas, permisos y objetos Oracle.

Ejemplo:
- Login test: abrir `<URL_LOGIN_APEX_TEST_DE_DESARROLLO_MD>`, ingresar `<USUARIO_QA_APEX_TEST_DE_DESARROLLO_MD>` y aplicar el modo de contrasena declarado en el contrato.
- App `144`, pagina `10`: ruta base `f?p=144:10`, usuario de prueba contractual y datos controlados en el ambiente TEST declarado.

## QA técnico acotado de objetos Oracle

Usar este modo solo cuando el inventario del candidato se limite a una mejora aislada en `PACKAGE`, `PACKAGE BODY`, función, procedimiento o vista y desarrollo demuestre que no cambió página APEX, navegación, permisos, configuración, datos, job, interfaz ni comportamiento observable por el usuario.

El contexto debe entregar un contrato técnico con: objeto y rutina o consulta exacta, SHA candidato, datos/binds de TEST, precondición, comando de ejecución, resultado esperado, comprobación posterior, limpieza y riesgos. QA ejecuta o verifica independientemente ese caso directo en TEST con la herramienta Oracle autorizada disponible; no usa Browser, Playwright, login, rutas APEX ni capturas.

No es elegible si la lógica modifica o puede modificar salida visible, validación, persistencia, permisos, navegación, proceso iniciado por usuario, integración con efecto funcional o si falta un caso directo reproducible. En esos casos aplica `QA funcional` por la ruta visible completa.

El informe identifica `Tipo QA: Técnico acotado`, objeto probado, caso ejecutado, resultado antes/después, evidencia y SHA. `PACKAGE`/`PACKAGE BODY` debe estar `VALID` y con `ALL_ERRORS=0`, pero esos estados son evidencia complementaria; no reemplazan el caso técnico.

## Arquitectura de carpetas

Contexto:
- Los proyectos multitarea APEX ya usan estructura compartida `apex`, `docs`, `docs/sql`, `docs/deploy` final y `docs/manuales`, junto con workspaces aislados `docs/tareas/<ID_TAREA>` y `qa/tareas/<ID_TAREA>`.
- Las aplicaciones APEX con repo fuente `zaimella-apex-oracle` pueden tener contratos reutilizables de QA versionados por aplicacion.

Estandar:
- Cuando el proyecto requiera QA automatizado o asistido, agregar la carpeta `qa`.
- La estructura base de QA APEX es:

```text
QA_RUN_ROOT/
|- config/
|  |- qa-apex.config.json
|  `- credentials.example.json
|- navigation/
|  |- login.md
|  |- app-APP_ID.md
|  `- page-APP_ID-PAGE_ID.md
|- pages/
|  `- pages.json
|- scenarios/
|  `- escenarios.md
|- tests/
|  `- apex-functional.spec.ts
|- reports/
|  `- informe_qa.md
|- screenshots/
|- traces/
`- README.md
```

Estandar:
- En corridas visuales, `QA_RUN_ROOT/config/qa-apex.config.json` define URL base, app id, ambiente, viewports, usuario de prueba referenciado por variable de entorno y opciones de ejecucion.
- `QA_RUN_ROOT/navigation/` es la fuente operativa principal para ejecutar QA, capturas y manuales. Cuando existe `APEX/<APP_ID>-<CODIGO_O_NOMBRE_APP>/QA/navigation/` versionado, debe sincronizarse hacia `QA_RUN_ROOT/navigation/` antes de ejecutar.
- `QA_RUN_ROOT/navigation/login.md` documenta URL de login, usuario QA, seleccion de compania y marcador visible de sesion iniciada.
- `QA_RUN_ROOT/navigation/app-APP_ID.md` documenta como entrar a la aplicacion desde el menu o lanzador corporativo.
- `QA_RUN_ROOT/navigation/page-APP_ID-PAGE_ID.md` documenta la ruta funcional a una pantalla especifica: menu, boton, link de reporte, accion por fila, branch, dialogo o flujo que la abre.
- El mismo archivo debe documentar el funcionamiento que QA debe probar: botones o acciones aplicables al escenario, procesos o comportamientos relevantes, datos minimos, resultado esperado, mensaje esperado y flujos alternos que no aplican.
- `QA_RUN_ROOT/pages/pages.json` registra paginas objetivo, nombre funcional, page id, tipo de pantalla, permisos esperados y acciones principales.
- `QA_RUN_ROOT/scenarios/escenarios.md` documenta escenarios funcionales, datos de prueba, precondiciones, pasos y resultado esperado.
- `QA_RUN_ROOT/tests/` contiene pruebas Playwright cuando aplique.
- `QA_RUN_ROOT/reports/informe_qa.md` contiene el resultado ejecutivo y tecnico del QA.
- `QA_RUN_ROOT/screenshots/` guarda evidencia visual de QA.
- `QA_RUN_ROOT/traces/` guarda trazas o videos cuando existan fallos.
- Las capturas documentales deben tener evidencia primaria en `QA_RUN_ROOT/screenshots` con reporte o log QA. Cualquier copia usada en el artefacto final la administra el contexto documental, no QA.

Razon:
- Separar configuracion, inventario de paginas, escenarios, pruebas y evidencias evita mezclar QA funcional con documentacion de usuario.
- La navegacion APEX depende de sesion, menu, permisos, compania, items de pagina, branches, dialogos y acciones dinamicas. Guardar la ruta funcional evita que cada QA improvise con URLs, `pInstance` o esperas genericas.

## QA reutilizable versionado

Contexto:
- Hay flujos APEX que se repiten por pagina o por proceso funcional: crear, modificar, eliminar, aprobar, cargar, consultar, filtrar o adjuntar.
- Una prueba robusta necesita reutilizar interacciones por pagina sin perder la vision completa del proceso.

Estandar:
- Si el proyecto usa `zaimella-apex-oracle` y existe navegacion versionada aplicable, QA debe verificar que el contexto la entregue para la corrida. Si falta, emitir `No aprobado`; QA no debe crearla como sustituto del contrato recibido.
- La estructura recomendada en el repo fuente es:

```text
QA/
|- pages/
|- flows/
|- tests/
|- navigation/
`- data/
```

- `pages/` contiene funciones o page objects por pagina APEX: selectores, botones, items, mensajes, acciones locales y validaciones propias de la pagina.
- `flows/` contiene procesos funcionales que pueden usar una o varias paginas: alta, modificacion, eliminacion, aprobacion, carga, adjuntos, consulta o filtros.
- `tests/` contiene escenarios ejecutables que llaman flows y casos de uso; un test no debe duplicar selectores si ya existe page object.
- `navigation/` dentro de `APEX/<APP_ID>-<CODIGO_O_NOMBRE_APP>/QA/` contiene contrato funcional estable por pagina o flujo: ruta, dialogos, botones, precondiciones, resultado esperado y restricciones.
- `data/` contiene plantillas y casos de uso parametrizables. Debe incluir casos positivos y negativos para validar restricciones: campos obligatorios, formatos invalidos, duplicados, estados no permitidos, permisos, limites, LOVs dependientes, combinaciones validas e invalidas y datos de limpieza cuando aplique.
- Las evidencias de ejecucion concreta no se guardan en `zaimella-apex-oracle`: screenshots, traces, logs, informes QA y datos temporales concretos van en el `proyecto/contexto`.
- Si QA detecta que un flujo estable cambio, debe reportar el hallazgo. QA no actualiza el contrato versionado ni la navegacion operativa salvo que el usuario autorice explicitamente una tarea separada de levantamiento.

Razon:
- APEX se implementa por paginas, pero el usuario valida procesos. Separar `pages/` y `flows/` evita duplicar selectores y permite probar procesos que atraviesan varias paginas.

Ejemplo:

```json
{
  "environment": "<AMBIENTE_QA_TEST>",
  "baseUrl": "<URL_BASE_APEX_TEST_DERIVADA_DEL_CONTRATO>",
  "loginUrl": "<URL_LOGIN_APEX_TEST_DE_DESARROLLO_MD>",
  "appId": 100,
  "login": {
    "type": "<TIPO_LOGIN_CONTRACTUAL>",
    "username": "<USUARIO_QA_APEX_TEST_DE_DESARROLLO_MD>",
    "passwordRequired": "<SEGUN_DESARROLLO_MD>",
    "companyRequired": true,
    "companyCode": "00001"
  },
  "navigation": {
    "preferred": "menu",
    "fallback": ["application-action", "direct-url"]
  }
}
```

## Fuente oficial de navegacion

Contexto:
- En APEX, una URL `f?p=APP_ID:PAGE_ID` no siempre reproduce el flujo real. Puede faltar sesion, compania, estado de pagina padre, valores de items, branch o inicializacion de dialogo.
- El QA debe reutilizar conocimiento de navegacion ya documentado en el proyecto o por pruebas anteriores.
- El archivo de navegacion inicial debe existir cuando una pantalla ya fue analizada o modificada. QA valida esa ruta y reporta diferencias reales; no la corrige ni reconstruye como primer paso normal.
- En proyectos multitarea pueden existir varias sesiones de Codex trabajando en paralelo. La bitacora puede contener pendientes de otra sesion que no forman parte del alcance actual.

Estandar:
- Antes de iniciar QA visual o capturas, el agente debe leer `docs/bitacora.md` cuando exista e identificar `Sesion`, `ID tarea`, alcance y estado del QA actual.
- Antes de abrir Browser, validar que el contexto entrego por cada destino `NAVIGATION_CONTRACT_OK` del validador de navegacion y evidencia existente de la ruta primaria/alternativa probada por Desarrollo. Si falta, si el contrato dice que esta pendiente o conserva marcadores, emitir `No aprobado por navegacion incompleta`, listar los campos y devolver el control; no ejecutar diagnosticos adicionales de login, lanzador, metadata, menu ni URL directa. `No aprobado por acceso/ruta no entregable` solo procede cuando el contexto demuestra que Desarrollo ya agotó la reconciliacion TEST → PRODUCCION → TEST de jerarquia y acceso del rol; QA no prueba la accion funcional.
- Si faltan los identificadores o entradas que exige el contexto, QA emite `No aprobado por entrada incompleta`; no crea identificadores, no abre tareas ni cambia estados por su cuenta.
- El agente no debe ejecutar, cerrar ni corregir pendientes de otra sesion salvo instruccion explicita del usuario o entrada de `Transferencia de tarea`.
- Frases historicas como "voy a sincronizar", "pendiente QA", "ejecutar QA real" o equivalentes no autorizan acciones en la sesion actual si pertenecen a otra sesion.
- Antes de iniciar QA visual o capturas, verificar que el contrato versionado aplicable ya fue sincronizado hacia `QA_RUN_ROOT/navigation/` y leer esa copia operativa.
- La fuente principal es la navegacion operativa que entregue el contexto. Si falta o no es suficiente, emitir `No aprobado por contrato de navegacion no entregado`.
- Si no existe contrato versionado ni archivo operativo de navegacion para una pantalla objetivo que viene de un cambio o correccion, QA debe registrar `No aprobado por ruta funcional de navegacion no entregada`. Solo puede levantar la ruta inicial si el usuario lo pide explicitamente como tarea de levantamiento de navegacion.
- Si la navegacion disponible no explica el funcionamiento necesario, QA debe registrar `No aprobado por funcionamiento no documentado`.
- Si una tabla, región, botón o componente depende de `Server Condition`, autorización, `WHERE`, filtro, item, parámetro o refresh, el contrato debe indicar el valor QA, cómo se obtiene o llena, la acción visible que actualiza el componente y su resultado esperado. QA no debe deducir estas condiciones desde metadata; si faltan, emitir `No aprobado por condición de componente no documentada`.
- QA no debe gastar el primer intento deduciendo desde metadata, export APEX o exploracion visual que boton/proceso corresponde al escenario. La metadata puede usarse para validar una ruta entregada o diagnosticar una diferencia, no para sustituir el contrato funcional requerido.
- Si hay acciones similares o ambiguas, QA debe usar solo la accion documentada. Si la ruta no las distingue, emitir `No aprobado por flujo ambiguo`; si la distincion requiere una definicion de negocio del usuario, emitir `Impedimento externo` con la pregunta exacta.
- Si existe contrato versionado, `QA_RUN_ROOT/navigation/app-APP_ID.md`, `QA_RUN_ROOT/pages/pages.json`, `QA_RUN_ROOT/scenarios/escenarios.md`, export APEX o metadata, QA puede usarlos para validar o diagnosticar, no para sustituir el insumo inicial.
- Si durante QA se confirma una diferencia, registrar hallazgo o impedimento con evidencia. QA no corrige la navegacion ni el contrato recibido, salvo levantamiento autorizado.
- QA no debe improvisar navegacion en cada intento si existe un archivo de navegacion aplicable. Con contrato aceptado, debe seguir la ruta primaria, usar una sola alternativa previamente validada para la misma sesion si falla la primaria y registrar el resultado. Despues de esos dos intentos no hace diagnosticos exploratorios: emite `No aprobado` y devuelve el control.
- Si la ruta documentada falla por cambio funcional, menu no visible, permiso, compania incorrecta o rebote al login, registrar hallazgo; no actualizar el flujo desde QA normal.
- Si el objetivo es un boton, link, region o dialogo que no aparece al cargar la pagina, antes de declarar bloqueo el agente debe revisar la ruta documentada, metadata/export disponible y la pantalla real para identificar tabs, acordeones, regiones colapsables o secciones internas que deban activarse. Un boton dentro de un acordeon cerrado no es `no visible`; es navegacion interna incompleta hasta probar la expansion.
- Cuando la ruta requiera tabs, acordeones o regiones colapsables, `QA_RUN_ROOT/navigation/page-APP_ID-PAGE_ID.md` debe nombrar el componente visible y la accion exacta para activarlo antes del boton final.
- Para dialogos y modales, el archivo de navegacion debe indicar la trazabilidad completa de invocacion desde la primera pagina navegable hasta el dialogo: pagina inicial, pagina padre inmediata, paginas intermedias, botones, links, acciones por fila, branches, procesos o acciones dinamicas que abren cada paso. No basta indicar solo la pagina padre inmediata.
- Si un dialogo de la pagina `308` se abre desde la `306`, y la `306` se abre desde la `305`, el archivo debe indicar que QA entra primero a la `305`, luego presiona el boton/link/accion que abre la `306`, y finalmente presiona el boton/link/accion que abre el dialogo `308`.
- No se aprueba QA de dialogos con URL directa ni con una cadena parcial de navegacion. Si falta un eslabon, emitir `No aprobado por trazabilidad incompleta del dialogo`.
- No se debe construir ni reutilizar manualmente `pInstance` como solucion normal para navegar. El `pInstance` debe salir de la sesion creada por login real con el usuario QA contractual; navegar con un `pInstance` armado o copiado solo puede usarse para diagnostico tecnico, no para aprobar QA funcional.

Formato minimo de navegacion operativa `QA_RUN_ROOT/navigation/page-APP_ID-PAGE_ID.md`:

```markdown
# Navegacion APP_ID/PAGE_ID - Nombre funcional

- Ambiente: <AMBIENTE_QA_TEST>
- Login: `<URL_LOGIN_APEX_TEST_DE_DESARROLLO_MD>`
- Usuario QA: `<USUARIO_QA_APEX_TEST_DE_DESARROLLO_MD>`
- Compania: `00001` o la compania del alcance
- Tipo de pantalla: menu | pagina fuera de menu | dialogo | modal | reporte | formulario
- Ruta oficial:
  1. Iniciar sesion con el usuario QA contractual.
  2. Seleccionar compania.
  3. Entrar a la app por menu/lanzador.
  4. Abrir menu, boton, link o accion exacta.
- Trazabilidad completa para dialogos:
  - Entrada navegable: APP_ID/PAGE_ID y nombre de pantalla
  - Paso 1: pagina origen, boton/link/accion/proceso, resultado esperado
  - Paso 2: pagina intermedia, boton/link/accion/proceso, resultado esperado
  - Paso final: pagina padre inmediata, boton/link/accion/proceso que abre el dialogo
- Pantalla padre: APP_ID/PAGE_ID cuando aplique
- Accion que abre: etiqueta visible del boton, link, fila, tab, branch o proceso
- Componentes internos que deben activarse: tab, acordeon, region colapsable o seccion interna, con etiqueta visible y orden de apertura
- Componentes impactados:
  - Tipo: boton | link | region | reporte | tabla | Interactive Report | Interactive Grid | item | tab | acordeon | modal | otro
  - Nombre funcional:
  - ID APEX o Static ID:
  - Region padre:
  - Selector recomendado: texto visible, `id`, `title`, `aria-label`, `href`, clase o combinacion estable
  - Condicion/autorizacion esperada:
  - Accion esperada:
- Funcionamiento del escenario:
  - Accion exacta que debe ejecutar QA:
  - Proceso APEX/PLSQL o comportamiento relevante:
  - Datos minimos o precondiciones:
  - Resultado esperado:
  - Mensaje esperado:
  - Flujos alternos que no aplican:
- Marcador de carga correcta: titulo, region, item o boton visible esperado
- Espera recomendada: esperar marcador visible y fin de spinners APEX; no depender de `networkidle`
- Datos minimos de prueba:
- Ultima validacion: YYYY-MM-DD, usuario, resultado
```

Razon:
- El archivo de navegacion convierte el conocimiento operativo en una fuente reutilizable para implementacion, QA, capturas y manuales. Si no existe, el QA normal no debe reemplazarlo con descubrimiento improvisado.
- Separar responsabilidades evita retrabajo: QA valida la ruta entregada y reporta diferencias; no corrige el contrato durante una corrida normal.

## Login QA APEX

Contexto:
- El mecanismo de login puede cambiar entre contextos. `desarrollo.md` declara la URL, el usuario QA y si el ambiente TEST requiere contrasena; las credenciales o secretos se obtienen desde la configuracion externa autorizada y nunca se registran en el contrato ni en evidencias.

Estandar:
- Antes de abrir la pantalla de login con navegador, el agente debe validar que el servicio APEX web responde con `scripts/check_apex_web.py --project-root <PROJECT_ROOT>` del skill activo. El script lee la URL de `desarrollo.md`; `--url` solo se permite para un diagnostico standalone autorizado y no modifica ni sustituye el contrato. No buscar scripts en el proyecto ni crear validadores equivalentes salvo autorizacion explicita.
- No declarar un impedimento externo solo porque el proyecto evaluado no contiene `scripts/check_apex_web.py`.
- Si la validacion confirma que el servicio APEX web no esta disponible, no debe intentar login ni capturas; debe reportar `Impedimento externo: servicio APEX web no disponible`. Esto no cambia el estado de la tarea.
- El agente debe abrir la URL exacta declarada en `desarrollo.md` y reproducida en el contrato de navegacion.
- Debe iniciar sesion con el usuario QA declarado en `desarrollo.md`.
- El login de QA en TEST no debe improvisarse: llenar el item visible de usuario con el valor contractual, aplicar el modo de contrasena declarado, ejecutar el boton visible de ingreso y esperar un marcador real de sesion iniciada, como menu, nombre de usuario, selector de compania, pagina inicial o lanzador de aplicaciones.
- Si el alcance corresponde a una compania especifica, debe seleccionar esa compania en el login antes de continuar a la aplicacion.
- La compania seleccionada debe coincidir con el requerimiento, `desarrollo.md`, el RI o el alcance operativo aprobado. Si no se puede identificar la compania requerida, el agente debe detener el QA y pedir precision antes de probar pantallas dependientes de compania.
- Despues del login, debe confirmar que la sesion quedo con la compania correcta cuando la pantalla o el contexto visible lo permitan.
- No debe registrar ni solicitar contrasena cuando `desarrollo.md` indica que no se requiere. Cuando se requiere, debe obtenerla desde la configuracion externa autorizada sin mostrarla ni persistirla.
- El contrato de navegacion debe identificar el control visible de usuario, el control/accion para compania, el boton de ingreso y los marcadores visibles que demuestran la identidad contractual y la compania seleccionada. QA usa esos controles documentados; no llena el primer `input` o `select` generico ni infiere el login por orden de DOM.
- Si tras enviar el login la aplicacion queda como `nobody`, anonima o sin `G_COMPANIA`, no debe pedir de inmediato otro mecanismo al usuario ni concluir que no sabe autenticar. Debe ejecutar, registrar y agotar esta recuperacion corta: (1) comprobar que uso los controles y valores exactos del contrato; (2) capturar URL, titulo/mensaje visible y marcadores de usuario/compania sin exponer secretos; (3) cerrar la sesion o crear contexto limpio y repetir el login corporativo con el usuario QA y la compania contractuales; (4) ejecutar la ruta primaria y, solo si corresponde, la alternativa ya validada; (5) confirmar nuevamente identidad, compania y marcador de pagina antes de abrir el flujo. No usar `pInstance`, cookies copiadas, JavaScript ni una URL construida para fingir la sesion.
- Solo si los dos intentos por el flujo corporativo documentado siguen dejando una sesion anonima, o si la pantalla de login cambio y exige una credencial que el contrato no contempla, emitir `No aprobado por inicializacion de sesion TEST` con la evidencia de los dos intentos. Solo solicitar al usuario un dato si el login corporativo cambio realmente y falta una credencial, acceso o definicion que no existe en `desarrollo.md`, en la navegacion ni en la configuracion externa autorizada; nunca volver a pedir valores que ya esten completos.
- Despues del login debe confirmar que la sesion quedo iniciada antes de probar pantallas.
- Si una pagina rebota al login, no debe resolverlo armando URL con `pInstance` ni copiando una sesion previa. Debe volver al flujo oficial y a la navegacion documentada en `QA_RUN_ROOT/navigation/`.
- Si tras la recuperacion la pagina vuelve al login, registrar `No aprobado por sesion/permisos/ruta funcional` con evidencia. Un problema de inicializacion de sesion, selector incorrecto, compania no aplicada o ruta incompleta es una brecha tecnica/funcional a diagnosticar, no un `Impedimento externo` ni un motivo para detener el ciclo.

Razon:
- El QA debe reproducir la forma real de acceso al ambiente test sin guardar secretos en el repositorio.
- En aplicaciones multicompania, seleccionar una compania distinta puede ocultar datos, permisos, LOVs, rutas de aprobacion, filtros por `:G_COMPANIA` o errores funcionales reales.

Ejemplo:
- Abrir la URL contractual, completar el item con el usuario QA de `desarrollo.md`, seleccionar la compania definida por el alcance, aplicar el modo de contrasena contractual, ejecutar el boton de ingreso y esperar la pagina inicial o menu de aplicaciones.

## Navegacion y permisos

Contexto:
- El menu y la visibilidad de paginas dependen de permisos, roles y reglas de acceso definidas por el proyecto o por sus estandares tecnicos aplicables.

Estandar:
- El agente debe navegar primero por el menu visible para el usuario autenticado.
- Debe aplicar el orden de revision de accesos: menu de aplicacion, acceso a pagina, acceso a accion o componente, y validacion de negocio en paquete cuando la operacion modifica datos o ejecuta un proceso sensible.
- Si una pantalla aparece en el menu, debe accederse desde el menu para validar visibilidad, etiqueta, ruta y carga.
- Si una pantalla no aparece en el menu, el agente debe clasificarla como pagina operativa fuera de menu o pagina auxiliar de dialogo/soporte antes de probarla.
- Para paginas fuera de menu, el acceso debe intentarse por la accion real de la aplicacion que la abre, por ejemplo boton, link de reporte, branch, modal o flujo de aprobacion.
- Para dialogos, modales y paginas auxiliares, el acceso debe hacerse desde la pagina padre y el boton, link, accion por fila, branch o proceso que inicializa el dialogo; queda prohibido abrirlos directamente con `f?p=APP_ID:PAGE_ID` como forma de aprobar QA.
- Si solo se conoce el `PAGE_ID` de un dialogo, emitir `No aprobado por ruta funcional incompleta`. QA no debe buscar la pagina padre o accion de apertura salvo levantamiento autorizado explicitamente.
- Si no se puede identificar la pagina padre o accion que abre el dialogo desde la ruta entregada, emitir `No aprobado por falta de ruta funcional de navegacion`, no por falta de URL directa.
- Si se confirma que la pantalla es normal, activa, no diálogo, no modal y no auxiliar, y `scripts/validate_apex_direct_access.py` confirma `DIRECT_URL_ALLOWED` para el usuario y compañía QA, el agente puede entrar tras login por URL `f?p=APP_ID:PAGE_ID` como ruta rápida documentada. No necesita recorrer el menú visualmente para esa corrida.
- Para capturas de manual, no se permite documentar una pantalla obtenida por URL directa si existe menu, boton, link, branch, modal o flujo real para llegar a ella.
- Para dialogos APEX, queda prohibido abrir la pagina dialog directamente por URL para capturarla; debe abrirse desde el boton o link real que inicializa el dialogo. Si al abrir directo aparece `Dialog page cannot be rendered successfully`, esa captura es evidencia invalida y el caso queda `No aprobado`, no es material de manual.
- No se permite usar JavaScript directo para forzar navegacion, ejecutar links ocultos, saltarse permisos o simular una ruta que el usuario no puede realizar visualmente.
- Si el acceso directo por URL permite entrar a una pagina que deberia estar restringida, debe registrarse como hallazgo de seguridad funcional.
- Si la pagina no aparece en menu y tampoco es accesible por accion ni por URL autorizada, emitir `No aprobado por navegacion inaccesible` o `Impedimento externo` si requiere acceso/definicion exclusiva del usuario.
- La espera tecnica de Playwright debe basarse en marcadores funcionales visibles: titulo de pagina, region esperada, boton esperado, resultado de reporte, fin de spinners APEX o mensaje visible. No usar `networkidle` ni `domcontentloaded` como unico criterio para aprobar o bloquear una pagina APEX.
- Si APEX mantiene requests pendientes pero la pantalla ya muestra el marcador funcional y no hay spinner bloqueante, capturar y continuar. Si no aparece el marcador dentro del tiempo acordado, registrar hallazgo de carga y `No aprobado`; ante una dependencia externa que requiera intervencion del usuario, emitir `Impedimento externo`.

Razon:
- El login real y la comprobación del registro activo de menú/acceso validan el permiso. La URL rápida no sustituye esa comprobación y no aplica a diálogos, modales o páginas auxiliares.

Ejemplo:
- Para una pagina principal de mantenimiento, entrar desde el menu.
- Para una pagina de detalle abierta desde un reporte, entrar desde el link o boton del reporte.
- Para una pagina tecnica fuera de menu solicitada explicitamente, entrar con `f?p=144:25` y validar si el acceso directo esta autorizado.

## Modos de trabajo

Contexto:
- El usuario puede pedir probar funcionalidades o generar prints para manuales.

Estandar:
- `QA funcional`: valida comportamiento de pantallas y flujos.
- `QA técnico acotado`: valida directamente un objeto o rutina Oracle elegible mediante el contrato reproducible, sin navegador ni matriz visual.
- `Capturas para manual`: genera imagenes limpias y representativas para documentacion.
- `Auditoria visual`: revisa layout, overflow, responsive, textos, mensajes y consistencia visual sin ejecutar transacciones de negocio.
- `Exploracion asistida`: navega manualmente con Playwright para levantar inventario, riesgos y casos candidatos antes de automatizar.

Razon:
- Cada modo produce salidas distintas y tiene riesgos distintos sobre datos y procesos.

Ejemplo:
- `QA funcional` crea un registro de prueba y valida mensaje de exito.
- `Capturas para manual` abre el mismo flujo con datos preparados y toma imagenes sin alterar informacion real.

## QA funcional obligatorio en cambios de pantalla

Contexto:
- Un cambio en una pantalla APEX puede compilar, responder por API o reflejarse en metadata/base, pero aun fallar para el usuario por navegacion, sesion, permisos, items, validaciones, acciones dinamicas, botones, mensajes, modales o persistencia visible.
- La validacion tecnica por SQL, API, metadata APEX o paquetes de base es complementaria y no equivale a QA funcional de pantalla.

Estandar:
- Cuando el cambio o correccion toque una pagina, region, formulario, reporte, item, boton, accion dinamica, proceso de pagina, branch, permiso, adjunto, modal o flujo visible, el agente debe ejecutar QA funcional desde la interfaz APEX real antes de cerrar.
- Antes de construir selectores propios, QA debe revisar `QA_RUN_ROOT/navigation/page-APP_ID-PAGE_ID.md` y usar sus IDs APEX, Static IDs, regiones padre y selectores recomendados.
- Si el inventario falta para una pantalla entregada al QA, emitir `No aprobado por inventario de componentes no entregado`, salvo que el usuario haya pedido explicitamente levantar la navegacion o descubrir componentes.
- El QA funcional debe iniciar sesion en APEX, navegar hasta la pantalla por el menu o por la accion real que usa el usuario, y ejecutar el flujo desarrollado o modificado de punta a punta.
- Para reportes, grillas o tablas dentro del alcance, el QA debe ejecutar la busqueda, `Go`, filtros, fechas, tabs o accion necesaria, esperar hasta que desaparezca la carga pendiente y confirmar datos visibles o un resultado funcional claro. La espera maxima es de 5 minutos.
- Si una pagina o modal se abre por redirect, boton, link, branch o accion similar y contiene reportes, grillas o regiones con consultas pesadas, QA debe validar que la pantalla abra primero con titulo, filtros, barra de acciones o marcador funcional visible antes de ejecutar la consulta pesada. Si el render inicial queda bloqueado mas de `15` segundos por cargar datos pesados, registrar hallazgo de experiencia y rendimiento.
- Para consultas pesadas, QA debe validar que la region cargue de forma diferida, por `Lazy Loading`, refresh posterior al `Page Load` o accion explicita como `Buscar`, `Go` o `Aplicar`. La region puede iniciar vacia o con mensaje funcional, pero no debe impedir que el usuario vea y controle la pantalla.
- Si el reporte pesado requiere filtros minimos y permite ejecutar una consulta amplia sin ellos, QA debe registrar hallazgo funcional o de rendimiento segun impacto.
- Durante refresh o carga diferida de una region pesada, QA debe confirmar indicador visual de procesamiento y salida de error controlada. Si un error deja spinner, bloqueo o region pendiente indefinidamente, registrar hallazgo.
- Para botones o links dentro de tabs, acordeones, regiones colapsables o secciones internas, el QA debe activar primero cada componente contenedor por su control visible y esperar el marcador funcional de esa seccion antes de buscar o hacer clic en el boton final. Si el componente existe y el boton aparece al expandirlo, no registrar bloqueo por visibilidad.
- Si un boton esperado no aparece, antes de emitir `No aprobado` se debe comprobar al menos: ruta recibida, tabs/acordeones, metadata/export APEX, region contenedora, condicion/autorizacion y compania/usuario.
- Para toolbars de Interactive Report, Interactive Grid, regiones APEX o botones renderizados solo con icono, no usar el texto visible como unico selector ni como unica prueba de existencia. El agente debe inspeccionar controles visibles y atributos como `title`, `aria-label`, `id`, `name`, `href`, `data-*`, clase CSS, icono, region contenedora y accion JavaScript antes de concluir que el boton no esta disponible.
- Si la metadata confirma que el boton existe, no tiene condicion ni esquema de seguridad, y pertenece a la region visible, QA debe ajustar el localizador al control real del toolbar. Si despues de activar contenedores y revisar atributos no existe ningun control visible/habilitado correspondiente, emitir `No aprobado`.
- Si despues de 5 minutos el reporte no muestra datos ni resultado claro, QA no puede dar OK. Debe emitir `Impedimento externo por ambiente no disponible` si comprobo que el ambiente esta caido, o `No aprobado por carga de reporte` si el flujo falla o es lento.
- La pantalla modificada debe probarse con todas las funcionalidades visibles que pertenezcan al alcance del cambio o que formen parte directa del flujo impactado: carga, filtros, busqueda, limpiar, botones, acciones por fila, formularios, LOVs, validaciones, guardado, cancelacion, retorno, modales, mensajes, permisos visibles y errores de consola.
- El QA funcional debe interactuar con los componentes como lo haria el usuario. Queda prohibido aprobar un flujo usando APIs directas de Playwright, DOM o JavaScript sobre componentes invisibles, transparentes, ocultos, deshabilitados o no accesibles visualmente para el usuario.
- Para componentes de carga de archivo, como `File Browse` o `input[type=file]`, no basta usar `setInputFiles()` sobre el input tecnico. Antes de cargar, el agente debe validar que el control visible, label, boton o zona de carga que usa el usuario exista, sea visible, este habilitado y pueda accionarse desde la interfaz. Si solo el input tecnico acepta el archivo pero el control visual no se ve o no se puede usar, el QA debe fallar con hallazgo de visibilidad/usabilidad.
- Si el flujo modifica datos o ejecuta un proceso de negocio, el QA debe validar tambien el resultado de datos: registro insertado, actualizado, eliminado, estado cambiado, adjunto persistido, aprobacion registrada, proceso ejecutado o ausencia de cambio cuando la accion sea cancelar/cerrar.
- Si el alcance incluye una migracion de datos desde archivo, el QA debe comprobar los conteos y claves esperadas de la carga en TEST, ejecutar el proceso funcional que consume esos datos y verificar que no se alteraron los resultados, permisos ni el flujo previo dentro del alcance. La migracion queda `No aprobada` si falta la evidencia antes/despues, si los datos esperados no son utilizables por el proceso o si aparece una regresion.
- Si la carga consume `DATA.VT_APEX_EXCEL`, el QA debe verificar que la evidencia de desarrollo mapea la primera columna de negocio desde `C02`; `C01` solo puede representar la fila de origen. Si el paquete usa `C01`, o no existe matriz de mapeo contrastada con la plantilla, registrar hallazgo y no aprobar la carga.
- Si el cambio afecta una pantalla especifica, por ejemplo la pagina `612`, el informe debe indicar explicitamente que la pagina fue abierta en APEX, por que ruta se ingreso, que acciones se ejecutaron y que resultado visible produjo cada accion.
- Las validaciones por base, API, metadata APEX, SQL publicado o paquetes PL/SQL deben registrarse como `QA tecnico` o `validacion complementaria`; no pueden presentarse como `QA funcional` ni como evidencia suficiente de que la pantalla funciona.
- El agente no debe decir que el cambio esta validado funcionalmente si no navego la pantalla real y no ejecuto el flujo modificado. Debe emitir `No aprobado por QA funcional incompleto` o `Impedimento externo`, con causa concreta.
- El agente tampoco debe decir que un reporte esta validado si no lleno los filtros obligatorios, no ejecuto la consulta, capturo durante spinner/carga o no espero hasta resultado visible dentro del limite de 5 minutos.
- Si una accion es destructiva o requiere datos que no existen, no debe ejecutarse sobre informacion real. Debe probarse con datos controlados o registrarse como `No aprobado por prueba segura no ejecutada`; si solo el usuario puede autorizar o suministrar lo necesario, emitir `Impedimento externo`.
- Si QA encuentra errores dentro del alcance, debe registrarlos. Luego prueba nuevamente solo cuando el contexto entregue una nueva version candidata desplegada en TEST con evidencia verificable; QA no implementa correcciones ni interpreta locks.

Razon:
- El objetivo del QA funcional es comprobar que el usuario puede completar el flujo real sin errores. Las pruebas tecnicas reducen riesgo de backend, pero no validan experiencia, permisos, navegacion ni comportamiento de la pantalla.

Ejemplo:
- Para una correccion en pagina `612`, no basta validar que el SQL publicado devuelve datos. El agente debe abrir APEX, entrar a la pagina `612`, ejecutar los botones o acciones modificadas, probar validaciones del formulario o filtros afectados, confirmar el mensaje visible y verificar el resultado posterior en pantalla o base cuando aplique.
- Si una pagina tiene un item de carga de archivos, QA no puede aprobarlo solo porque `setInputFiles()` cargo el archivo en un `input[type=file]` oculto o transparente. Debe confirmar que el usuario ve y puede usar el control de carga; si no se ve, registra el hallazgo y emite `No aprobado`. El contexto invocador decide la correccion posterior.

## Auditoria de cumplimiento de estandares

Contexto:
- En APEX, compilar en base de datos o importar un export sin errores no demuestra que la pantalla cumpla el estandar corporativo ni que el codigo siga la arquitectura aprobada.
- El QA APEX debe funcionar como gate independiente de cumplimiento, no solo como prueba de que la pagina abre.

Estandar:
- Todo QA funcional o visual de un cambio APEX debe clasificar el resultado en tres ejes: `Funcionalidad`, `Diseno web APEX` y `Programacion`. En `QA técnico acotado`, evaluar `Funcionalidad tecnica` y `Programacion`; `Diseno web APEX` se registra como `No aplica` y no se exige matriz por pagina.
- `Funcionalidad` valida que el usuario puede completar el flujo real con mensajes, permisos, datos y navegacion correctos.
- `Diseno web APEX` valida contra `references/auditoria-estandares-apex.md`: titulo visible con `Zaimella Barra de Navegacion`, una sola `Barra de acciones` cuando aplique, botones personalizados con iconos fuera de dialogos, region padre de formulario cuando corresponda, tablas con template y titulo corporativos, acciones de fila con iconos accesibles, seleccionadores adecuados al volumen, formularios en dos columnas, labels claros en espanol, reportes interactivos, responsive, sin overflow y sin acciones dispersas.
- `Programacion` valida contra `references/auditoria-estandares-apex.md` y la evidencia disponible del proyecto: logica de negocio en paquetes, ausencia de `INSERT`, `UPDATE` o `DELETE` de negocio directo en procesos APEX, nombres descriptivos, uso de `DATA`, filtro por `:G_COMPANIA` cuando aplique, comentarios obligatorios, mensajes de exito/error y pruebas del procedimiento o funcion modificada.
- QA debe contrastar el alcance y la evidencia pre-TEST recibidos contra la pantalla real. Debe existir resultado por cada pagina, dialogo o flujo; aprobar la pagina principal no aprueba automaticamente sus destinos.
- La auditoria visual debe comprobar controles y etiquetas realmente visibles, posiciones, titulos de regiones, estados vacios, precondiciones y comportamiento responsive. Que un selector exista en DOM o que un dialogo abra/cierre no demuestra cumplimiento visual ni funcional.
- La auditoria debe contrastar metadata y pantalla para confirmar que las regiones de tabla usan `Zaimella Tabla`, que el titulo proviene del nombre de region y no de `Header Text`, y que la jerarquia de `Content Body` mantiene todas las regiones funcionales dentro de la region padre del formulario cuando aplique.
- Para cada boton personalizado, QA debe distinguir pagina normal de dialogo: en paginas normales y acciones de tabla debe verse solo un icono con nombre accesible; en dialogos, los botones finales deben conservar texto visible. Una accion textual dentro de una tabla o barra normal es `No cumple`, aunque funcione.
- Para cada componente de lista alimentado por datos, QA debe comprobar busqueda, filtrado, seleccion y claridad de resultados. Un maestro o catalogo transaccional que pueda crecer presentado como `Select List` es `No cumple`; un `Select List` SQL solo cumple con evidencia de catalogo pequeno, cerrado y de bajo crecimiento.
- QA debe comprobar que la version candidata, evidencia de import/reconciliacion, TEST e informe identifican la misma fuente funcional. Una aprobacion anterior queda invalidada en cuanto cambia cualquiera de esos elementos.
- La auditoria de programacion puede apoyarse en export APEX, metadata Oracle, scripts SQL/PLSQL y consultas controladas. Debe marcarse como `auditoria tecnica no visual` cuando no haya evidencia visual; esa etiqueta no convierte por si sola el alcance en `QA técnico acotado`.
- Si una pantalla funciona pero incumple diseno web APEX, el informe debe marcar `No cumple estandar de diseno` y recomendar correccion antes de publicacion.
- Si una pantalla funciona pero la logica esta implementada fuera de paquetes o rompe estandares PL/SQL/SQL, el informe debe marcar `No cumple estandar de programacion`.
- Los hallazgos de estandar criticos o altos impiden recomendar publicacion igual que los hallazgos funcionales.
- Si no se puede evaluar un eje por falta de acceso, export, metadata o evidencia, debe quedar como `No evaluado por impedimento`, no como aprobado.

Razon:
- Separar funcionalidad, diseno y programacion evita que una compilacion exitosa o una prueba visual superficial oculte incumplimientos que luego aparecen en revision manual.

Ejemplo:
- Una pagina guarda correctamente, pero no tiene breadcrumb corporativo ni barra de acciones: funcionalidad `Cumple`, diseno web APEX `No cumple`, programacion `No evaluado` o `Cumple` segun evidencia.
- Un boton `Guardar` funciona, pero ejecuta `INSERT` directo en proceso APEX: funcionalidad `Cumple`, diseno segun revision visual, programacion `No cumple`.

## Ejecucion Playwright y dependencias

Contexto:
- Los proyectos APEX no necesariamente son proyectos Node y pueden no tener `package.json`, `node_modules`, `playwright` ni `@playwright/test` locales.
- La ausencia de `node_modules` local no es por si sola un bloqueo valido de QA visual.
- La herramienta Browser de Codex, cuando existe en la sesion, es un navegador aprobado para navegar, autenticarse, inspeccionar estado visible y capturar evidencia. Su ausencia no es por si sola un bloqueo valido de QA visual.
- Las herramientas de QA visual deben vivir fuera del proyecto APEX y reutilizarse entre tareas para no reinstalar ni redescubrir dependencias en cada ejecucion.

Estandar:
- Antes de ejecutar QA visual, el agente debe comprobar si la sesion actual expone Browser. Si existe, debe usarlo primero como navegador aprobado; no puede declarar ausencia de navegador/runner ni emitir impedimento tecnico sin ese intento.
- Si Browser no esta disponible en la sesion actual, debe usar la instalacion reutilizable registrada en `%USERPROFILE%\.zaimella\qa-tools\playwright\QA_TOOLS.md` o en `docs/logs/qa-tools.md`, mediante el `Playwright runner` registrado o el que entregue `ensure-playwright-env.ps1`.
- No debe usar runners efimeros, `npx`, `npm exec`, caches de `npx`, ni resolver `NODE_PATH` manualmente como camino normal de QA.
- No ejecutar `ensure-playwright-env.ps1` como preflight rutinario. Solo ejecutarlo una vez cuando no exista `QA_TOOLS.md`, no exista el runner registrado o el runner falle con `--version`.
- Si falta `node` o `npm`, no diagnosticarlo manualmente ni iniciar busquedas de instalacion. Dejar que `ensure-playwright-env.ps1` lo repare una sola vez; si no puede, reportar `Preparacion de herramientas QA fallida`.
- El runner reutilizable ya define `playwright.config.js`, proyecto `chromium` y contexto de modulos. Cuando ejecute un spec externo, el propio runner debe exponer sus dependencias al proceso hijo y ajustar su `testDir` de forma temporal. El agente no debe anunciar ni intentar ajustes como quitar `--project=chromium`, cambiar el navegador por defecto, cambiar imports de `@playwright/test` a `playwright`, mover specs al directorio del paquete, crear runners efimeros o editar `NODE_PATH` desde el proyecto.
- Para pruebas formales, ejecutar el runner con un spec existente, absoluto o relativo al directorio actual: `powershell -ExecutionPolicy Bypass -File "<PLAYWRIGHT_RUNNER>" test "<spec>" --project=chromium`. Cuando el spec este fuera de las herramientas corporativas, el runner debe detectar su ruta y usar su carpeta como `testDir` solo para esa ejecucion; no debe mover el spec al directorio de herramientas ni instalar dependencias en el proyecto APEX.
- Para exploracion, capturas puntuales o validacion visual asistida sin pruebas formales, usar el runner reutilizable o un script temporal fuera del codigo fuente, guardando evidencia en `QA_RUN_ROOT/screenshots`, `QA_RUN_ROOT/traces` o `docs/tareas/<ID_TAREA>/logs`.
- Si no existen pruebas Playwright formales, el agente debe crear o ejecutar un script temporal fuera del codigo fuente del proyecto para abrir login, navegar por menu/accion real, capturar pantalla y registrar errores de consola cuando aplique.
- Si falla la ejecucion por proyecto `chromium`, resolucion de `@playwright/test`, navegador o contexto de modulos, no diagnosticarlo como problema del spec ni improvisar alternativas. Debe ejecutar `ensure-playwright-env.ps1` una sola vez para reparar la instalacion reutilizable, volver a correr el mismo comando con `<PLAYWRIGHT_RUNNER>` y, si aun falla, reportar `Preparacion de herramientas QA fallida` con el error exacto.
- No debe ejecutar `npm install`, `npm install playwright` ni `npm install @playwright/test` dentro del proyecto APEX salvo autorizacion explicita del usuario o salvo que el propio proyecto ya tenga un scaffold Node aprobado para QA.
- Tampoco debe anunciar que instalara Playwright localmente como paso normal de QA. Si considera indispensable instalar dependencias locales, debe detenerse, explicar por que la instalacion reutilizable no sirve y pedir autorizacion explicita antes de modificar el proyecto.
- Si la instalacion reutilizable requiere descargar navegadores, debe limitarse a Chromium y registrar el intento. Si la descarga falla por red, proxy, permisos o timeout, debe reportarse como fallo de preparacion de herramientas.
- Si un proceso `npm`, `npx`, `node` o Playwright queda colgado, debe detener solo los procesos que inicio para esa validacion, registrar el comando y continuar con las validaciones no visuales que correspondan.
- Si una validacion o prueba APEX dependiente de Oracle queda colgada por mas de 10 minutos, debe usar la referencia de conectividad disponible en el proyecto o solicitar diagnostico tecnico/DBA. Si no hay acceso a esa referencia o a Oracle, emitir `Impedimento tecnico` con evidencia y no repetir la prueba indefinidamente.
- Si una consulta de comprobacion, reporte APEX, proceso de guardado/carga o conteo usado por QA termina por timeout local, cierre del cliente, interrupcion o demora operativa, QA debe activar higiene de sesiones antes de emitir resultado: revisar o solicitar revision de sesiones Oracle propias activas, cerrar o escalar sesiones colgadas y registrar evidencia de `0 sesiones pendientes` o del impedimento tecnico.
- QA no debe declarar `Aprobado para cierre` si existe una sesion Oracle activa generada por la validacion, o si no se pudo revisar sesiones despues de un timeout/corte local. El resultado correcto es `Impedimento tecnico: sesion Oracle pendiente` o `No aprobado por higiene de sesiones incompleta`; el contexto decide el estado de la tarea.
- El informe QA debe distinguir entre `QA visual no ejecutable por herramienta`, `QA visual no ejecutable por acceso APEX` y `validacion por metadata/base ejecutada`.
- La categoria `QA visual no ejecutable por herramienta` no es un estado de tarea. Si falla la instalacion reutilizable de Node/Playwright/Chromium, reportar `Preparacion de herramientas QA fallida`, incluir comando intentado, salida resumida, ruta esperada de `QA_TOOLS.md` y siguiente accion tecnica; no recomendar pase a produccion hasta completar QA visual, pero no culpar a APEX ni a la pagina.
- No usar la ausencia de Playwright local como motivo para investigar dependencias. Si Browser existe, usarlo; si no existe, usar el runner reutilizable registrado en `QA_TOOLS.md` y repararlo una sola vez solo si no responde.
- Un `Impedimento externo` de QA visual APEX solo procede por acceso real no disponible: APEX/login caido, HTTP con error de servicio o red, credenciales/mecanismo de login no confirmados o permisos que solo el usuario puede aportar. Pagina no visible, ruta no identificada o pantalla que no carga normalmente son `No aprobado` y deben volver al ciclo. La preparacion de herramienta se reporta como impedimento tecnico solo despues de que Browser no este disponible y el runner registrado haya fallado, incluida su reparacion autorizada.

Razon:
- APEX no debe heredar dependencias ni scripts de otros tipos de proyectos web. La instalacion reutilizable permite probar pantallas reales sin contaminar el repositorio ni convertir la falta de dependencias locales en un falso bloqueo.
- La disponibilidad de Browser o de Playwright instalado localmente depende de la sesion de Codex, no de la aplicacion APEX. El gate visual debe fallar solo por imposibilidad real de navegar o capturar evidencia tras asegurar la instalacion reutilizable.
- Separar preparacion de herramientas de impedimentos funcionales evita falsos cierres: si APEX responde y el login es posible, el agente debe preparar sus utilitarios y ejecutar el QA visual.

Ejemplo:
- Si el runner registrado no responde o falla por resolucion de modulos/proyecto, ejecutar una sola vez `ensure-playwright-env.ps1 -ProjectRoot .` y volver a usar el `Playwright runner` registrado en `docs/logs/qa-tools.md`; no usar runners efimeros, `npx`, caches efimeras, imports alternativos ni ajustes manuales de `NODE_PATH`.
- Si la descarga de Chromium falla por timeout, registrar `Preparacion de herramientas QA fallida: descarga de navegador no disponible` y completar el reporte con la validacion de export APEX y base que si se haya ejecutado.
- No anunciar instalaciones de Playwright para ejecutar QA visual. La respuesta operativa es usar la instalacion reutilizable registrada en `QA_TOOLS.md`.
- No mencionar runners efimeros, falta de proyecto `chromium`, cambio de navegador por defecto, ajuste de imports ni `NODE_PATH` como plan normal. La respuesta correcta es usar el runner reutilizable registrado en `QA_TOOLS.md` con `--project=chromium` y reparar esa instalacion una sola vez si falla.
- No anunciar ajustes de spec, caches de `npx`, runners efimeros ni resolucion manual de modulos como parte del flujo normal. Debe usar el Playwright runner reutilizable registrado en `QA_TOOLS.md`; si el runner no responde, reparar la instalacion una sola vez con `ensure-playwright-env.ps1`.

## Gate terminal y recuperacion de timeout

Un timeout del runner, navegador, pagina, consulta o proceso no autoriza terminar el turno ni pedir una nueva orden. Antes de emitir resultado:

1. Registrar comando, limite agotado, duracion observada, salida, URL/ruta, escenario y logs/traces disponibles.
2. Identificar y cerrar solo los procesos iniciados por esa validacion que sigan colgados. Si hubo Oracle, revisar sesiones propias y dejar evidencia de `0 sesiones pendientes` o escalamiento tecnico.
3. Clasificar la causa con evidencia:
   - `Herramienta`: Browser/runner/Chromium/configuracion reutilizable.
   - `Autenticacion o navegacion`: login, sesion, lanzador, ruta primaria o alternativa documentada.
   - `Ambiente`: servicio APEX, red u Oracle realmente inaccesibles.
   - `Aplicacion`: carga, consulta, JavaScript, Ajax, PL/SQL o comportamiento funcional defectuoso.
4. Ejecutar en el mismo turno la recuperacion aplicable: reparar una vez la instalacion reutilizable cuando corresponda, repetir el mismo escenario despues de corregir la causa y probar la alternativa ya autorizada. No aumentar timeouts a ciegas; solo ajustarlos con evidencia de una operacion valida que necesita mas tiempo y manteniendo un limite finito.
5. Emitir `No aprobado` si la aplicacion, ruta o escenario falla; `Impedimento tecnico` si las herramientas siguen inutilizables despues de su reparacion autorizada; `Impedimento externo` solo si el ambiente/acceso depende realmente del usuario. Entregar la evidencia al contexto para que este continue el ciclo.

No son salidas terminales validas: `la QA no termino`, `hasta diagnosticar`, `queda pendiente diagnosticar`, `continuare despues` ni equivalentes. Pueden aparecer unicamente como avance intermedio mientras continúan el diagnostico, la recuperacion y el reintento.

## Prohibicion de inferir pantallas no vistas

Contexto:
- El QA funcional y las capturas documentales dependen de evidencia visual real de la aplicacion.

Estandar:
- El agente no debe inventar pantallas, botones, textos, imagenes, layouts, dialogos ni flujos cuando no haya podido acceder a la URL o visualizar la pantalla real.
- Si no tiene acceso a la URL, si falla el login, si la pantalla no carga o si Playwright no puede capturar evidencia, debe detener la generacion de capturas.
- En ese caso debe registrar `No aprobado` o `Impedimento externo`, segun corresponda, con la causa concreta: URL inaccesible, login fallido, pagina no autorizada, timeout, error de red o pantalla no encontrada.
- Puede analizar el export APEX `.sql` o metadata Oracle para levantar inventario tecnico, pero debe marcar la salida como `analisis desde metadata, sin validacion visual` y no debe presentarla como manual con capturas reales.
- No debe crear imagenes simuladas, wireframes, screenshots aproximados ni descripciones visuales inferidas, salvo que el usuario pida explicitamente un wireframe o una propuesta visual, y aun asi debe rotularse como `referencial`, no como captura de la aplicacion.
- Si una pagina no pudo abrirse, el manifiesto de evidencia debe dejarla como `No documentada visualmente por falta de acceso` y explicar que informacion falta.

Razon:
- La evidencia QA que alimenta documentacion debe reflejar la aplicacion real. Inventar pantallas produce documentacion falsa y puede ocultar errores de acceso, menu, permisos o publicacion.

Ejemplo:
- Si la URL APEX objetivo no responde desde el entorno del agente, el resultado correcto es `Impedimento externo` con evidencia; no fabricar capturas ni botones y no cambiar el estado de la tarea.

## Flujo QA funcional

Estandar:
1. Leer `desarrollo.md` y confirmar ambiente, `ZAIMELLA_ORACLE_SID`, URL APEX, usuario QA y modo de contrasena; confirmar app id y compania objetivo desde el alcance o la navegacion cuando apliquen.
2. Usar exclusivamente la identidad, alcance, commit candidato y ubicacion de corrida entregados por el contexto invocador. No descubrir tareas, estados, pendientes ni transferencias por cuenta propia.
3. Validar que no se usaran datos reales sensibles ni acciones destructivas.
4. Validar disponibilidad web APEX con `python <RUTA_SKILL_QA_APEX>/scripts/check_apex_web.py --project-root <PROJECT_ROOT>`; la URL proviene de `desarrollo.md`.
5. Abrir la URL de login TEST, iniciar sesion con el usuario QA y el modo de contrasena declarados en `desarrollo.md`, y seleccionar la compania objetivo cuando el alcance aplique a una compania especifica.
6. Leer el export APEX vigente, las paginas objetivo y `QA_RUN_ROOT/navigation/`, sincronizado desde el contrato versionado cuando exista.
7. Si falta navegacion documentada suficiente o no explica el funcionamiento, registrar `No aprobado por ruta funcional o funcionamiento no entregado`, salvo levantamiento autorizado explicitamente.
8. Registrar o actualizar `QA_RUN_ROOT/pages/pages.json`.
9. Registrar escenarios en `QA_RUN_ROOT/scenarios/escenarios.md`.
10. Navegar siguiendo la ruta operativa entregada. Si falta ruta, accion o resultado, detener la corrida y emitir `No aprobado`.
11. Para pantallas fuera de menu, navegar por la accion real documentada; usar URL directa solo si el alcance aprobado lo pide explicitamente y la pantalla no es dialogo, modal ni auxiliar.
12. Ejecutar exploracion o pruebas Playwright en test.
13. Validar carga de pantalla, navegacion, botones, formularios, validaciones, modales, reportes, filtros, mensajes, permisos visibles y errores de consola.
14. Si hubo timeout, corte local, reporte/consulta pesada o proceso Oracle lento, aplicar higiene de sesiones con la referencia de conectividad disponible antes de continuar el cierre.
15. Guardar evidencia en `QA_RUN_ROOT/screenshots`, `QA_RUN_ROOT/traces` o `docs/tareas/<ID_TAREA>/logs`.
16. Generar `qa/tareas/<ID_TAREA>/reports/informe_qa.md` con el SHA exacto validado.
17. Registrar hallazgos en `docs/bitacora.md` cuando el proyecto sea multitarea, siempre bajo la `Sesion` e `ID tarea` correspondientes.

Impedimento:
- Si TEST no puede vincularse a la version candidata registrada o si cambia durante la corrida, usar `No aprobado por version no identificable`; no aprobar por comportamiento observado sobre una version incierta.
- Si no se puede abrir la URL, iniciar sesion o cargar las paginas objetivo, no se ejecuta esa parte del QA funcional. Se entrega `Impedimento externo` si el servicio/acceso depende del usuario, o `No aprobado` si falla la aplicacion/ruta, siempre con evidencia; no se inventan resultados ni estados de tarea.
- Si `check_apex_web.py` falla, indicar ambiente, URL, codigo o error, y pedir al usuario restablecer el servicio APEX web antes de continuar.
- Si no existe navegacion documentada o no explica el funcionamiento, el resultado correcto es `No aprobado por ruta funcional o funcionamiento no entregado`, no un intento indefinido con metadata, URL directa, `pInstance`, `networkidle` o esperas genericas.
- Si una validacion Oracle del QA quedo en timeout y no se pudo confirmar que no hay sesiones propias activas, el resultado correcto es `Impedimento tecnico: higiene de sesiones Oracle incompleta`; QA no marca la tarea.

## Limites de tiempo para QA visual

Contexto:
- Una prueba sencilla de pantalla no debe tardar 20 minutos por descubrimiento de navegacion, login o esperas genericas.
- Si falta la ruta funcional, el problema pertenece a la preparacion del insumo, no a una exploracion larga de QA.

Estandar:
- Antes de abrir navegador, verificar en maximo 2 minutos que existen el contrato versionado o `QA_RUN_ROOT/navigation/`, funcionamiento, ambiente, login, usuario, compania y datos minimos.
- Si falta navegacion documentada para una pantalla entregada al QA, o si falta el funcionamiento esperado del escenario, detener el QA visual. No iniciar exploracion de menu, metadata, export APEX o URL directa para reemplazar el archivo faltante o incompleto.
- Para una prueba visual sencilla con ruta documentada, el presupuesto normal es 5 a 8 minutos: preparar herramienta reutilizable si hace falta, login, navegar por ruta oficial, validar marcador funcional, capturar evidencia y registrar resultado.
- Se permiten maximo 2 intentos de navegacion por pantalla: un intento siguiendo la ruta documentada y un reintento solo si hay evidencia de error transitorio, sesion expirada o carga incompleta.
- Si despues de 2 intentos la pantalla no carga por la ruta documentada, emitir `No aprobado` con evidencia. No cambiar a `pInstance`, URL directa, `networkidle`, busqueda de menus, metadata o analisis largo sin autorizacion explicita.
- El descubrimiento inicial de ruta no forma parte del QA normal. Solo puede hacerse si el usuario lo pide explicitamente como levantamiento de navegacion, y debe registrarse como actividad separada del QA funcional.

Razon:
- El objetivo del QA visual es validar la pantalla y el flujo entregado, no redescubrir la aplicacion. Timeboxes cortos hacen visible si el contrato de navegacion llego incompleto.

## QA de formularios y botones

Contexto:
- En APEX, un formulario puede ejecutar procesos PL/SQL, validaciones, acciones dinamicas, cambios de estado, adjuntos, aprobaciones o navegacion condicionada.
- Un boton visible no queda validado solo porque aparece en pantalla o porque responde al clic.

Estandar:
- Todo formulario dentro del alcance debe probarse como flujo funcional completo: carga inicial, datos requeridos, validaciones, accion principal, mensaje, persistencia y navegacion posterior.
- En ambiente TEST, el agente debe asumir que puede crear, modificar y eliminar datos temporales controlados para QA cuando eso sea necesario para validar el objetivo del flujo. No debe pedir autorizacion caso por caso para insertar, actualizar o limpiar registros de prueba en TEST, salvo que el usuario haya marcado el dato, tabla, compania o proceso como sensible o restringido.
- Antes de ejecutar acciones que modifiquen datos, el agente debe confirmar que usa datos de prueba controlados y que no actuara sobre informacion real sensible.
- Para acciones que insertan, actualizan, eliminan, aprueban, rechazan, adjuntan, importan o procesan datos, el QA debe registrar evidencia de datos `antes / accion / despues`. La evidencia puede ser visual en la pantalla, consulta posterior en la aplicacion, reporte origen o consulta SQL controlada cuando aplique.
- Una prueba que solo confirma que abre una pantalla, dialogo o modal no valida el flujo funcional si el objetivo era guardar, actualizar, eliminar, cargar, aprobar, procesar o leer datos.
- Si el alcance incluye alta, edicion, guardado, aplicacion de cambios, carga de archivo, adjunto, aprobacion, rechazo, procesamiento o cualquier accion transaccional, el QA debe ejecutar esa accion con datos de prueba en TEST y comprobar el resultado posterior. Validar solo apertura del boton, modal, URL, parametros recibidos, metadata, compilacion o carga inicial no permite emitir `OK funcional`.
- Si faltan datos minimos para llenar el formulario, el agente debe construir datos temporales razonables y trazables segun el contexto de TEST, LOVs visibles, defaults, catalogos disponibles y reglas documentadas. Solo emite `Impedimento externo` si el dato no puede inferirse sin riesgo funcional real, no existe configuracion obligatoria, falta un permiso que solo el usuario puede otorgar, el proceso es sensible o el usuario restringio expresamente la creacion de datos.
- Si no existen condiciones seguras para ejecutar la accion principal, el resultado debe ser `No aprobado por prueba funcional incompleta` o, cuando solo el usuario pueda suministrar autorizacion, acceso o definicion, `Impedimento externo`, con la lista exacta de requisitos. No se debe trasladar al usuario el primer hallazgo funcional corregible por falta de ejecucion del flujo principal.
- Las acciones no destructivas necesarias para completar el flujo, como `Nuevo`, llenar formulario y `Guardar`, deben probarse en TEST con registros temporales cuando el alcance sea un alta o mantenimiento. Si el flujo genera datos, el QA debe usar nombres o marcas de prueba trazables y registrar limpieza requerida cuando aplique.
- Cada formulario debe probar al menos:
  - carga sin errores visibles ni errores funcionales de consola
  - campos obligatorios vacios
  - formatos invalidos cuando existan fechas, numeros, correos, identificadores o montos
  - valores validos de prueba
  - listas de valores, dependencias entre campos y valores por defecto
  - tipo de componente de lista acorde con origen, volumen y crecimiento; busqueda por identificadores funcionales en `Popup LOV` o filtros/columnas suficientes en `Modal LOV`
  - guardado o aplicacion de cambios
  - persistencia en consulta posterior, reporte origen o validacion de base cuando aplique
  - cancelacion, cierre o retorno sin guardar cambios indebidos
- Cada boton visible o accion equivalente dentro del alcance debe inventariarse y clasificarse antes de probarse.
- Ademas de su comportamiento, cada boton personalizado debe auditarse por presentacion: icono sin texto visible y etiqueta accesible en paginas normales, toolbars y filas de tabla; texto visible solo en botones finales de dialogo. Los controles nativos generados por APEX se validan segun su componente y no se confunden con botones personalizados.
- La clasificacion minima de botones es:
  - `Navegacion`: volver, cancelar, cerrar, abrir detalle, abrir modal o ir a otra pagina
  - `Consulta`: buscar, filtrar, limpiar, refrescar, descargar o ver detalle
  - `Transaccion`: crear, guardar, aplicar cambios, duplicar, importar o cargar informacion
  - `Proceso`: ejecutar, procesar, generar, recalcular, sincronizar o publicar
  - `Aprobacion`: enviar, aprobar, rechazar, devolver, anular o cambiar estado
  - `Adjunto`: cargar, ver, descargar, reemplazar o eliminar archivo
  - `Destructiva`: eliminar, borrar, anular definitivamente o ejecutar una accion irreversible
- Para botones de navegacion, el QA debe validar destino, retorno, cierre correcto y ausencia de cambios no solicitados.
- Para botones de consulta, el QA debe validar filtros vacios, filtros con datos, filtros combinados, limpieza y consistencia de resultados.
- Para botones transaccionales, el QA debe validar precondiciones, ejecucion, mensaje, persistencia y resultado visible posterior.
- Para botones de proceso, el QA debe validar precondiciones, bloqueo ante datos incompletos, mensaje final, efecto esperado y evidencia disponible del proceso.
- Para botones, submits o acciones dinamicas que ejecutan procesos PL/SQL, Ajax, guardados, aprobaciones, rechazos, cargas, eliminaciones, calculos o sincronizaciones, el QA debe confirmar que al iniciar aparece un bloqueo visual o spinner corporativo, normalmente el `waitPopup` disparado por `mostrarBarra();`.
- Mientras el proceso esta en curso, la pantalla o el flujo afectado no debe permitir que el usuario vuelva a disparar la misma accion por doble clic o por presionar controles relacionados. Si visualmente no pasa nada y el usuario puede repetir la accion, registrar hallazgo funcional.
- Si la accion dinamica depende del resultado de un proceso PL/SQL/Ajax antes de continuar, QA debe revisar metadata o comportamiento para confirmar que espera el resultado; un proceso asincronico sin espera solo es aceptable si el flujo fue disenado para continuar sin esperar respuesta inmediata.
- Al finalizar, debe desaparecer el bloqueo por `ocultarBarra();`, submit o navegacion, y debe verse un mensaje claro de exito o error. Si no hay mensaje final, si el bloqueo queda indefinido o si el error termina en silencio, registrar hallazgo.
- Si la accion falla por error JavaScript, Ajax o PL/SQL, el bloqueo debe cerrarse antes de mostrar o dejar visible el error. Si el `waitPopup` queda encima del mensaje, impide leer el error o no permite continuar usando la pantalla, registrar hallazgo funcional alto cuando afecte una accion principal.
- Para botones de aprobacion, el QA debe validar permisos, estado inicial, cambio de estado, ruta o responsable siguiente, mensaje y bloqueo para usuarios no autorizados cuando el alcance lo permita.
- Para botones de adjunto, el QA debe validar tipo de archivo, tamano permitido, carga, visualizacion, descarga, reemplazo o eliminacion solo con archivos de prueba.
- Para carga de adjuntos o archivos, el QA debe validar primero la visibilidad y usabilidad del componente de carga desde la pantalla. La carga directa al input tecnico con `setInputFiles()` solo puede usarse despues de confirmar que el control visible de usuario existe y es operable; no puede reemplazar esa confirmacion.
- Para botones o links que visualizan, abren o descargan archivos, como `Ver Factura`, `Ver PDF`, `Descargar`, `Abrir adjunto` o acciones equivalentes, no basta inspeccionar `href`, `target`, `download`, MIME type, URL formada ni metadata APEX. El QA debe ejecutar clic real sobre el control visible y validar el comportamiento del navegador.
- Cuando una accion de archivo use `target="_blank"`, nueva ventana, descarga o visor PDF, el QA debe esperar explicitamente el evento correspondiente de Playwright: `popup`, `download` o navegacion. Si no ocurre ningun evento despues del clic real, debe registrarse hallazgo funcional aunque el enlace tecnico parezca correcto.
- Si se abre una nueva pestana o ventana, el QA debe confirmar que la pestana intenta cargar el archivo esperado, que la URL corresponde al documento solicitado y que no queda en blanco, error de navegador, error APEX, bloqueo de permisos, descarga fallida ni visor PDF vacio. Cuando el navegador bloquee `file://` desde una pagina `http://` o `https://`, debe registrarse como fallo funcional de acceso al archivo.
- Si el navegador bloquea la apertura, la descarga o la navegacion por politica de seguridad, popup bloqueado, contenido local `file://`, mixed content, CORS, permiso o error de consola, el QA debe capturar la evidencia disponible y marcar el caso como `No cumple funcionalidad`; no debe aprobarlo por tener URL o HTML bien formado.
- Para botones destructivos, no ejecutar sobre datos reales. En TEST crear o identificar primero un registro temporal y ejecutar sobre ese registro; si no es posible, registrar `No aprobado por falta de dato destructivo de prueba`. Si requiere un dato no temporal, solicitar la definicion de negocio o confirmacion tecnica necesaria; nunca aprobar con esa validacion pendiente.
- Toda eliminacion iniciada por el usuario debe mostrar, antes de comenzar el proceso destructivo, el mensaje exacto `¿Está seguro de eliminar el registro?`. Aplica a eliminacion fisica o logica y a acciones equivalentes como borrar, retirar o desvincular un registro.
- QA debe probar cada accion destructiva con el registro temporal en dos recorridos: primero cancelar y verificar que no hubo submit, llamada Ajax/PLSQL, DML, cambio de estado, navegacion ni alteracion del registro; despues volver a iniciarla, aceptar y comprobar que se ejecuta una sola vez y presenta el resultado o error esperado.
- Una confirmacion generica presente en la pagina no basta: debe estar asociada al boton, accion de fila, link, submit o accion dinamica que realiza esa eliminacion. Si el proceso empieza antes de confirmar, el texto difiere o cancelar produce cualquier efecto, registrar `No cumple`.
- Toda accion de negocio debe validarse con enfoque `antes / accion / despues`: estado o datos previos, ejecucion realizada y resultado posterior comprobable.
- Si un boton abre un modal, dialogo, region emergente, reporte o pagina secundaria, esa pantalla destino tambien debe probarse con su accion real de negocio o registrarse como alcance pendiente.
- En dialogos o modales, cerrar con `X`, tecla Escape o clic fuera solo valida cancelacion/cierre cuando esa sea la accion esperada. No sustituye un boton `Guardar`, `Aplicar`, `Procesar`, `Aceptar`, `Cerrar dialogo` configurado para retornar datos, ni cualquier accion que dispare procesamiento APEX.
- Si el cierre del modal debe refrescar una region, retornar valores, ejecutar proceso o actualizar datos, el QA debe validar el efecto posterior en la pantalla padre y, cuando aplique, en base de datos.
- Si un boton falla, no responde, no muestra mensaje, muestra mensaje ambiguo o ejecuta una accion distinta a la esperada, debe registrarse como hallazgo con severidad segun impacto.

Razon:
- Validar solo que la pantalla carga no prueba el comportamiento real del formulario ni protege contra errores en procesos, permisos, validaciones, rutas de aprobacion o persistencia de datos.
- Validar solo que un dialogo abre o cierra con `X` no prueba que el flujo de negocio procese datos ni que la pantalla padre reciba el resultado correcto.
- La clasificacion de botones evita ejecutar acciones sensibles sin control y obliga a comprobar el efecto real de cada accion funcional.

Ejemplo:
- En un formulario de mantenimiento, probar `Guardar` con campos obligatorios vacios, luego con datos validos de prueba, confirmar mensaje de exito y verificar el registro desde el reporte origen.
- En un dialogo de lectura o carga de datos, abrir el modal, ejecutar la accion funcional que corresponda, confirmar mensaje o cierre esperado, validar que la pantalla padre se refresco y consultar que los datos fueron insertados, actualizados o no modificados segun el caso.
- En un boton `Aprobar`, confirmar que el registro esta en estado aprobable, ejecutar con usuario autorizado y validar cambio de estado. Si la ruta no existe, emitir `No aprobado`; si falta una definicion de negocio sobre la ruta, emitir `Impedimento externo` con la pregunta exacta.
- En un boton `Eliminar`, crear primero un registro temporal de QA en TEST; abrir la confirmacion `¿Está seguro de eliminar el registro?`, cancelar y comprobar que el registro permanece; repetir, aceptar y verificar la eliminacion y su mensaje final. Si no se puede crear o identificar ese registro, no ejecutar la eliminacion sobre datos existentes.
- En un link `Ver Factura`, hacer clic real, esperar `popup` o navegacion, confirmar que el PDF carga o intenta cargar en la pestana nueva, revisar consola/permisos si falla y registrar hallazgo alto si el navegador bloquea un enlace `file://` aunque el `href` este bien formado.

## Gate de aceptacion para guardados, Ajax y dialogos

Contexto:
- Un selector visible, un mensaje aislado o una tabla modificada en memoria puede coexistir con un submit roto, un proceso Ajax fallido, un dialogo sin boton utilizable o una persistencia que se pierde al recargar.
- La navegacion dirigida debe reducir el descubrimiento, no eliminar las acciones reales ni las comprobaciones posteriores.

Estandar:
- Cada escenario transaccional debe tener una evidencia trazable de `antes -> accion visible -> despues independiente`, asociada al mismo SHA, usuario, compania, dato temporal y ejecucion. Un screenshot, log SQL o assertion aislado no cubre los tres momentos.
- La prueba debe comenzar por la ruta primaria entregada. Solo puede usar la alternativa documentada despues de que falle la primaria o cuando el contrato la declare expresamente como ruta de ese escenario. Una URL directa autenticada nunca sustituye menu/lanzador para aprobar su navegacion y nunca abre un dialogo, modal o auxiliar.
- Los scripts Playwright pueden leer atributos o esperar eventos, pero no pueden aprobar una accion usando `evaluate`, JavaScript, APIs DOM, clic sobre elementos ocultos ni navegacion construida fuera del contrato. El boton, link o accion debe estar visible, habilitado y ser pulsado como usuario.
- Para `Guardar`, `Aplicar`, `Actualizar`, `Procesar` o Ajax equivalente, verificar como minimo: valor previo identificado; campos de prueba diligenciados; clic en el control visible; una sola ejecucion observable; fin de spinner/bloqueo; mensaje de exito o error legible; valor posterior en la region/refresco esperado; y comprobacion tras recarga o reapertura por la ruta autorizada. Si el DOM conserva el valor pero la reapertura no lo confirma, es hallazgo `Alta`.
- Para `Guardar y recalcular`, colas o procesos asincronos, separar y evidenciar el guardado, la solicitud unica y el resultado del proceso. Que se encole un job no prueba que el guardado haya persistido; que el job termine no prueba que el boton haya sido accionable ni que el usuario recibiera resultado claro.
- Antes de probar un dialogo/modal, QA debe recibir y leer su contrato funcional: proposito (`informativo`, `consulta/navegacion`, `transaccional` o `proceso`), datos/estado de entrada, accion real disponible, proceso APEX/accion dinamica/procedimiento invocado cuando aplique, resultado visible, efecto esperado en el padre y comprobacion posterior. Si el contrato no permite saber que debe hacer el dialogo, emitir `No aprobado por funcionamiento de dialogo no entregado`; QA no lo infiere por sus botones o apariencia.
- Un dialogo informativo aprueba al comprobar que se abre desde su accion real con el contexto correcto, presenta informacion completa/actualizada y comprensible, y se cierra o retorna como define el contrato sin producir cambios. No requiere boton `Guardar` ni persistencia.
- Un dialogo de consulta o navegacion aprueba al comprobar la accion visible que le corresponde (filtrar, seleccionar, abrir destino, devolver una seleccion o descargar), el resultado/destino y el efecto definido en el padre. No se le exige DML si el contrato no lo contempla.
- Un dialogo transaccional verifica, en el viewport real y en cada viewport comprometido: titulo/identidad, todos los botones finales esperados con texto visible, habilitados y dentro de la zona visible sin scroll accidental; modificacion de un dato temporal; clic real de la accion final; mensaje o cierre esperado; refresco/retorno del padre; y persistencia al reabrir el mismo registro o consultarlo de nuevo. La visibilidad, el tamano, `X`, Escape o `Salir` no validan la transaccion.
- Un dialogo de proceso verifica su accion real y el efecto documentado: invocacion unica de la accion dinamica/proceso/procedimiento, bloqueo y finalizacion apropiados, mensaje o estado, refresh/retorno del padre cuando corresponda y resultado posterior en pantalla o consulta controlada. Que el dialogo se cierre no demuestra que el proceso se ejecuto.
- Para `Salir`, `Cancelar` o cierre sin guardar de un dialogo transaccional, cambiar primero un valor temporal, ejecutar esa salida y confirmar en la reapertura que no hubo persistencia. Si el dialogo promete devolver datos al padre, validar tambien que el padre no se actualizo al cancelar.
- Antes de aprobar una transaccion, recargar o reabrir con una sesion limpia o estado de pagina reconstruido mediante la ruta autorizada. La comprobacion debe leer un resultado nuevo de APEX o una consulta controlada, no nodos conservados de la ejecucion anterior.
- Un test solo puede declarar el resultado que realmente ejecuta y afirma. Si solo verifica apertura, visibilidad o geometria, debe informarlo como cobertura parcial; queda prohibido describir en el informe que guardo, cerro, refresco o persistio sin esas assertions y evidencia.
- Ante una correccion de un hallazgo funcional, ejecutar nuevamente el escenario fallido completo y una regresion acotada de su padre/destino, sobre el nuevo SHA. No reutilizar capturas, logs ni resultado de un candidato anterior.

Razon:
- Este gate impide que una prueba rapida de selectores o apariencia se convierta en una aprobacion funcional de botones que el usuario no puede completar.

Ejemplo:
- Para editar un SKU desde un dialogo transaccional: abrirlo desde la fila real, anotar el valor inicial, cambiarlo por un valor QA, pulsar `Guardar`, comprobar que el modal se cierra y la fila padre cambia, recargar/reabrir el SKU y confirmar el nuevo valor. Luego restaurar el valor temporal si corresponde y verificar nuevamente.
- Para un dialogo informativo de detalle: abrirlo desde la fila real, contrastar los datos con la fila/contexto padre, validar la accion de cierre y comprobar que no altero los datos. No inventar una prueba de guardado.

## Flujo de capturas para manuales

Estandar:
1. Confirmar paginas y flujo que se documentara.
2. Preparar datos de prueba o datos no sensibles.
3. Iniciar sesion y llegar a cada pantalla por menu o por la accion real de la aplicacion.
4. Para reportes, ejecutar los filtros, busqueda o boton requerido hasta mostrar datos o un resultado funcional claro. No capturar reportes vacios, con spinner, region incompleta o sin haber ejecutado la consulta necesaria.
   - Despues de ejecutar el reporte, esperar hasta que desaparezcan spinners, indicadores de carga y regiones pendientes. La espera maxima es de 5 minutos; si no muestra datos o resultado claro en ese tiempo, registrar `No aprobado por carga incompleta` y no usar la captura para el manual.
5. Si el reporte o pantalla requiere filtros para mostrar informacion, llenar o seleccionar filtros validos antes de capturar; en reportes con fechas, usar un rango que devuelva datos reales de prueba o datos no sensibles.
   - Si el reporte muestra filtros visibles de fecha o compania, esos valores deben quedar diligenciados antes de capturar.
   - `Reporte Sell Out` debe capturarse despues de llenar fechas/compania o criterios equivalentes y ejecutar la busqueda con filas visibles.
6. Para formularios, abrir desde el boton real y completar o preparar campos con datos de prueba suficientes para mostrar como se llena la informacion. No capturar formularios totalmente vacios salvo que el objetivo sea documentar especificamente el estado inicial.
7. Para modales o dialogos, abrir desde el boton, link o accion real de la pantalla padre. No capturar dialogos abiertos por URL directa ni pantallas con error de inicializacion de dialogo.
8. Para tabs, acordeones, regiones colapsables o secciones internas, activar el componente correspondiente dentro del flujo real antes de capturar.
   - En `Control de Sell Out e Inventario`, abrir el acordeon o region `Sellout/Inventario`; no basta capturar el tab `Control` con acordeones cerrados.
9. Limpiar informacion sensible visible antes de capturar.
10. Tomar capturas representativas: listado con datos, formulario preparado, modal funcional, validacion, resultado final y consulta posterior cuando aplique.
11. Guardar la evidencia primaria en `QA_RUN_ROOT/screenshots`; el contexto documental decide y copia las imagenes finales a su ubicacion de entrega.
12. Registrar por cada captura la ruta usada, el flujo ejecutado, el tipo de pantalla, el estado validado, filtros usados cuando aplique, `sourceScreenshot` y `qaReport` en el manifiesto de evidencia.
13. Entregar el manifiesto, capturas y reporte al contexto invocador. QA no actualiza el manual fuente ni genera Word.
14. Si aparece un error funcional, registrarlo como hallazgo; no usar esa imagen como evidencia documental aprobada.

Impedimento de evidencia:
- Si no se puede acceder a la URL o capturar la pantalla real, no se generan capturas para manual. Se registra el impedimento de evidencia y se informa que el manual queda pendiente; esto no cambia el estado de la tarea.
- Si la unica forma de llegar a la pantalla es URL directa o JavaScript y el usuario real no puede navegarla, marcar `Pendiente de captura por falta de ruta funcional` o registrar hallazgo de acceso.

## Handoff de evidencia para documentacion

Contexto:
- QA aporta evidencia del uso real de las pantallas. `documentacion-proyecto-sistemas` redacta y audita el entregable para su audiencia.

Estandar:
- Antes de abrir Browser o Playwright, el contexto debe entregar `qa/tareas/<ID_TAREA>/manual-coverage.json` o una matriz equivalente versionada. Debe contener una fila por cada pantalla, dialogo, accion derivada, tab, acordeon o paso que el manual cubrira, con: identificador, tipo, contrato de navegacion, accion de entrada, resultado/retorno esperado, captura primaria y seccion objetivo del manual.
- Entregar el inventario como `qa/tareas/<ID_TAREA>/manual-coverage.json` o formato contractual equivalente. El skill documental valida que sus secciones correspondan a evidencia aprobada.
- El inventario se deriva del alcance aprobado, contratos de navegacion y auditoria pre-TEST; no se arma desde la lista de screenshots historicos. Desarrollo entrega los destinos y su comportamiento; QA verifica la cobertura y evidencia real.
- No se permite declarar `Cobertura de evidencia completa` ni usar `capture.validated=true` si una fila del inventario no tiene contrato vigente, captura primaria real y accion de entrada ejecutada. Emitir `No aprobado por cobertura de evidencia documental incompleta` y listar las filas faltantes.
- Cuando el contexto solicite capturas para documentacion, QA debe recorrer cada pagina incluida en el inventario.
- Antes de entregar una pantalla como evidenciada, QA debe haberla abierto y tomado o reutilizado una captura real vigente de la misma linea base.
- Una captura real vigente debe cumplir: ruta funcional usada, pantalla sin errores APEX visibles, sin spinner, sin region incompleta, con datos visibles cuando es reporte y con campos preparados cuando es formulario o carga.
- Por cada pagina, el handoff de evidencia debe registrar:
  - titulo visible de la pantalla
  - descripcion breve, entendible y no tecnica de que hace la pagina
  - captura principal de la pantalla
  - botones disponibles y accion que realiza cada boton
  - filtros, campos o secciones importantes cuando ayuden a usar la pantalla
- La lista de botones evidenciados es obligatoria por cada pagina del inventario. Debe incluir todos los botones visibles o acciones equivalentes del alcance, por ejemplo botones de pagina, acciones por fila, botones de region, botones de dialogo y acciones principales de reportes o grillas.
- Para cada pantalla, cambio o tema evidenciado, consolidar las acciones relacionadas en una sola lista funcional.
- Cada boton debe registrar una frase corta que explique que hace para el usuario y el escenario QA que lo comprobo.
- Si un boton abre un dialogo, modal, region emergente, reporte, detalle u otra pagina, el handoff debe incluir tambien:
  - captura de la pantalla o dialogo destino
  - descripcion funcional del destino
  - accion esperada del usuario en esa pantalla
  - forma de volver, cerrar o continuar el flujo
- La descripcion debe enfocarse en el objetivo funcional: consultar, crear, editar, aprobar, rechazar, adjuntar, buscar, filtrar, generar o revisar informacion.
- El handoff de capturas no debe exponer nombres internos o datos sensibles que la audiencia no necesite.
- Las capturas deben usar datos de prueba o datos no sensibles. La evidencia primaria debe guardarse en `QA_RUN_ROOT/screenshots`.
- Cuando la pantalla tenga una tabla, reporte interactivo o grilla, la captura debe tomarse tal como se ve al llegar a la pantalla en el viewport normal. No debe hacerse una captura vertical completa de toda la informacion si eso produce una imagen excesivamente alta.
- Una captura de manual corresponde como máximo a un viewport de laptop/escritorio; no usar `fullPage`, stitching ni imágenes que unan el scroll de una tabla. Registrar `capture.fullPage=false` cuando el formato fuente lo soporte. Para un reporte, la captura muestra barra de acciones o filtros, encabezados y las primeras filas visibles; tomar otra captura de viewport para una pestaña, acción por fila, detalle o información adicional.
- Si el reporte requiere presionar `Buscar`, `Go`, `Aplicar`, seleccionar filtros o completar fechas para mostrar informacion, el agente debe ejecutar esa accion antes de capturar.
- Si el reporte queda sin datos despues de ejecutar correctamente, el handoff debe declarar el criterio y el resultado sin datos; no debe presentarse como reporte con filas.
- Si la pantalla es un formulario, el agente debe abrirlo desde el flujo real y llenarlo con datos de prueba o valores representativos antes de capturar, salvo que el estado inicial vacio sea la funcionalidad documentada.
- Si la pantalla es un dialogo, modal, detalle por registro o ventana que recibe informacion de un ID, debe abrirse desde el boton, link o accion por fila original. No se permite construir la URL con parametros para generar la captura del manual.
- Si la mejora esta dentro de un tab, acordeon, region colapsable o seccion oculta, el agente debe activar ese componente dentro del flujo real antes de capturar.
- Para tablas largas, capturar el encabezado, filtros o barra de acciones y las primeras filas visibles. Si se requiere mostrar informacion adicional, tomar capturas separadas y acotadas, no una sola imagen gigante.
- QA no decide la ruta ni el formato del documento fuente; entrega rutas de evidencia al contexto invocador.
- Si una pagina no puede abrirse, no debe redactarse como si estuviera validada. Debe quedar marcada como pendiente por falta de acceso o falta de captura real.

Razon:
- Un handoff util debe permitir que el skill documental explique que hace cada pantalla y que ocurre al usar sus botones, incluyendo dialogos o pantallas secundarias.

Ejemplo:
- Pagina `Consulta de APIs`: incluir titulo, descripcion funcional, captura del listado, descripcion del boton `Nuevo`, captura del formulario que abre, descripcion del boton `Guardar` y resultado esperado.
- Pagina `Administracion API`: listar botones como `Ejecutar`, `Copiar`, `Editar`, `Ver mapeo` y `Ver lotes`, indicando en una frase corta la accion de cada uno. La captura del reporte debe mostrar la tabla como aparece en pantalla, con las filas visibles, sin extender la imagen hasta el final de todos los registros.

## Evidencia para manual de cambios y mejoras

Contexto:
- Este modo evidencia que se modifico, mejoro o habilito en la aplicacion o proceso.
- No se ejecuta como parte normal del QA. El contexto debe solicitarlo y entregar el inventario de cobertura.
- QA no define ni genera el formato final.

Estandar:
- Aplicar solo las reglas de captura real, navegacion y cobertura de este skill. Las reglas de redaccion, formato y auditoria del documento viven en `documentacion-proyecto-sistemas`.
- Las capturas deben verse como pantalla normal de computador; no usar capturas verticales largas de scroll completo.
- Cada imagen del manifiesto debe incluir evidencia `capture`, ruta fuente e informe QA.
- La evidencia `capture` debe demostrar el flujo funcional completo de la tarea: pasos ejecutados, accion usada para llegar, accion ejecutada para reportes, campos preparados para formularios, accion origen para dialogos/detalles y componente activado para tabs o acordeones.
- Si una pantalla no puede abrirse o no hay print real, no se debe inventar captura. Marcarla como `Pendiente de captura` y devolver la fila al contexto.

## Severidades

Estandar:
- `Critica`: login roto, pantalla principal no carga, flujo principal roto, datos sensibles expuestos o accion destructiva accesible sin control.
- `Alta`: boton principal no funciona, formulario importante no guarda, proceso PL/SQL falla, permiso visible incorrecto, link o boton de archivo principal no abre, no descarga o es bloqueado por el navegador, error de consola funcional, logica de negocio con DML directo en APEX, ausencia de mensaje visible en accion de negocio o incumplimiento grave de barra de acciones/breadcrumb que afecta operacion.
- `Media`: validacion incompleta, filtro parcial, mensaje confuso, modal con bloqueo parcial, dato calculado inconsistente, label no estandar, formulario con distribucion visual incorrecta o reporte que no cumple tipo/controles esperados.
- `Baja`: detalle visual menor, texto mejorable, alineacion, overflow menor o mejora de usabilidad.

## Salidas obligatorias

Estandar:
- Todo `QA funcional` o `QA técnico acotado` debe entregar `qa/tareas/<ID_TAREA>/reports/informe_qa.md` con ID tarea, commit candidato validado, alcance, ambiente, tipo de QA, escenarios ejecutados, hallazgos, evidencia y recomendacion de publicacion. El QA técnico registra objeto/rutina o vista, caso directo y comprobación antes/después en vez de páginas probadas.
- `Aprobado para cierre` aplica exclusivamente al SHA escrito en el informe. Cualquier cambio posterior exige recompilar/importar TEST y repetir el QA afectado sobre un nuevo commit candidato.
- Solo QA puede emitir `OK funcional`, `Aprobado para cierre` o recomendacion equivalente para una tarea APEX visible/funcional o una tarea elegible de QA técnico acotado. Otros flujos pueden indicar `listo para QA`, pero no pueden marcar el trabajo como aprobado.
- El informe QA debe cerrar con uno de estos resultados: `Aprobado para cierre`, `No aprobado`, `Impedimento tecnico` o `Impedimento externo`. Ninguno cambia por si mismo el estado de la tarea.
- `Aprobado para cierre` solo se permite cuando no existan impedimentos ni hallazgos `Critica` o `Alta` pendientes dentro del alcance probado. Si hay hallazgos `Media` o `Baja` aceptados, deben quedar listados como riesgo o mejora pendiente.
- Para `QA funcional`, `Aprobado para cierre` queda prohibido si una accion principal del alcance no fue ejecutada funcionalmente de punta a punta. Para `QA técnico acotado`, queda prohibido si no se ejecutó y verificó el caso directo documentado; compilar o consultar metadata no basta. Si el cambio tiene impacto visible o falta un caso directo reproducible, no es técnico acotado y debe ejecutarse QA funcional.
- Cuando el QA sea parcial, el informe debe decir `QA parcial` y separar `Validado` de `No probado`. La seccion `No probado` debe listar accion, motivo, dato o definicion pendiente y riesgo funcional; nunca puede convivir con una recomendacion de `Aprobado para cierre`.
- El informe debe incluir una seccion `Cumplimiento de estandares`. Para QA funcional o visual, registra funcionalidad, diseno web APEX y programacion; para QA técnico acotado, registra funcionalidad tecnica y programacion, con diseno web APEX como `No aplica`.
- En QA funcional o visual, `Cumplimiento de estandares` debe contener una fila por cada pagina, dialogo o flujo del inventario, con evidencia y hallazgos; un resumen global sin cobertura por destino no satisface el informe. En QA técnico acotado, debe contener una fila por cada objeto/rutina o vista y caso directo del contrato.
- Toda captura para documentacion debe tener evidencia primaria en `QA_RUN_ROOT/screenshots`, nombre descriptivo y fila correspondiente en el manifiesto de cobertura.
- QA debe entregar por pagina titulo visible, ruta, captura principal, acciones cubiertas y capturas de dialogos o pantallas derivadas cuando existan.
- QA no genera ni declara completo el manual; entrega evidencia a `documentacion-proyecto-sistemas` mediante el contexto invocador.
- Todo reporte que no tenga acceso visual real debe declararlo explicitamente como impedimento o analisis no visual. No debe usar lenguaje que sugiera que la pantalla fue probada o capturada.
- Si hubo timeout, consulta pesada o proceso Oracle lento durante QA, el informe debe incluir evidencia de higiene de sesiones: ambiente, comando o mecanismo de revision, sesiones encontradas, accion de cierre/escalamiento y resultado posterior. Sin esa evidencia no puede recomendar `Aprobado para cierre`.

Ejemplo:
- `qa/tareas/<ID_TAREA>/screenshots/ecmm_apis_01_listado.png`
- `qa/tareas/<ID_TAREA>/screenshots/ecmm_apis_02_formulario.png`
- `qa/tareas/<ID_TAREA>/reports/informe_qa.md`
