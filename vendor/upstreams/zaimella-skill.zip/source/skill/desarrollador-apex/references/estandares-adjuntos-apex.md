# Estandares de Adjuntos en Oracle APEX

## Objetivo
Definir la politica corporativa para manejo de archivos adjuntos en aplicaciones Oracle APEX de Zaimella.

## Regla obligatoria

- `Contexto:` El manejo de adjuntos en Oracle APEX debe seguir un unico patron corporativo.
- `Estandar:` Todos los adjuntos deben almacenarse obligatoriamente en `FILES.T_APEX_ARCHIVOS`.
- `Razon:` Esta es la tabla corporativa comun de adjuntos ya usada transversalmente por aplicaciones, paquetes y vistas.
- `Ejemplo:` si una pagina necesita guardar un PDF, XML, imagen o documento de soporte, el archivo debe terminar en `FILES.T_APEX_ARCHIVOS`.

- `Contexto:` A menudo se intenta resolver adjuntos agregando estructuras propias en tablas de negocio.
- `Estandar:` No se deben crear tablas nuevas de adjuntos ni columnas `BLOB`, `CLOB` o similares para almacenar archivos en tablas funcionales, salvo autorizacion explicita del desarrollador y documentada como excepcion.
- `Razon:` Rompe el patron comun, duplica logica y dificulta reutilizacion, mantenimiento y soporte.
- `Ejemplo:` no se debe crear `T_LEGA_ADJUNTOS`, ni agregar `ARCHIVO_BLOB` en una tabla del modulo, si el caso puede resolverse con `FILES.T_APEX_ARCHIVOS`.

- `Contexto:` El repositorio corporativo validado en la base actual no es `FILES.T_APEX_ARCHIVO` en singular.
- `Estandar:` El objeto correcto del estandar es `FILES.T_APEX_ARCHIVOS` en plural.
- `Razon:` Es la tabla real existente y usada transversalmente por paquetes, vistas y aplicaciones APEX.
- `Ejemplo:` al implementar un flujo de adjuntos, la referencia correcta para insercion, consulta o descarga es `FILES.T_APEX_ARCHIVOS`.

- `Contexto:` La tabla corporativa de adjuntos funciona como un repositorio generico relacionado por nombre de tabla e identificador del registro.
- `Estandar:` La relacion del archivo con el negocio debe resolverse con `TABLA`, `ID_TABLA` y opcionalmente `TIPO`.
- `Razon:` Este diseno permite reutilizar la misma tabla para multiples modulos y distintos tipos de documento sin agregar estructura fisica por cada caso.
- `Ejemplo:` un archivo legal puede registrarse con `TABLA = 'T_LEGA_DOCUMENTOS'`, `ID_TABLA = <ID del documento>` y `TIPO = 'POLIZA'` o el tipo funcional que corresponda.

- `Contexto:` La carga estandar desde APEX ya esta resuelta con paquete corporativo.
- `Estandar:` Para crear adjuntos desde `File Browse` APEX se debe usar `DATA.PK_APEX_ARCHIVOS.SP_CREARARCHIVO`.
- `Razon:` Ese procedimiento toma el archivo desde `APEX_APPLICATION_TEMP_FILES`, genera `NUMEROARCHIVO` y registra el contenido y metadatos en `FILES.T_APEX_ARCHIVOS`.
- `Ejemplo:` despues de seleccionar un archivo en un item `File Browse`, el proceso APEX debe invocar `PK_APEX_ARCHIVOS.SP_CREARARCHIVO`.

- `Contexto:` Existen casos donde el archivo no viene desde `APEX_APPLICATION_TEMP_FILES`, sino que ya se tiene el `BLOB` en memoria.
- `Estandar:` Para esos casos se debe usar `DATA.PK_APEX_ARCHIVOS.SP_CREARARCHIVOMANUAL`.
- `Razon:` Permite reutilizar la tabla comun sin depender del flujo estandar de `File Browse`.
- `Ejemplo:` una rutina que genera un PDF o XML desde PL/SQL y necesita guardarlo como adjunto debe usar `SP_CREARARCHIVOMANUAL`.

- `Contexto:` La eliminacion de adjuntos tambien debe seguir un punto comun.
- `Estandar:` Para eliminar adjuntos se debe usar `DATA.PK_APEX_ARCHIVOS.SP_ELIMINAARCHIVO` cuando el requerimiento sea la baja fisica del archivo.
- `Razon:` Centraliza la operacion minima de eliminacion por `NUMEROARCHIVO`.
- `Ejemplo:` si el usuario elimina un archivo desde una pagina APEX, la accion debe ejecutar `PK_APEX_ARCHIVOS.SP_ELIMINAARCHIVO(:P_IDARCHIVO)`.

- `Contexto:` La descarga en APEX ya tiene un patron declarativo usado en aplicaciones existentes.
- `Estandar:` La descarga debe resolverse con el formato `DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment:...:FILES` o equivalente segun el componente APEX.
- `Razon:` Aprovecha el soporte nativo de APEX para descargar el `BLOB` desde el esquema `FILES`.
- `Ejemplo:` una columna de reporte puede descargar el archivo usando `NUMEROARCHIVO` como clave y `BLOBCONTENT` como contenido.

- `Contexto:` El paquete corporativo de adjuntos no hace `COMMIT`.
- `Estandar:` El control transaccional debe quedar en la logica llamadora de negocio o en el proceso APEX que orquesta la operacion completa.
- `Razon:` Permite que el guardado del adjunto y el guardado del registro funcional queden en una misma transaccion.
- `Ejemplo:` si primero se crea un registro de negocio y luego se adjunta un archivo, el `COMMIT` debe ocurrir al final del flujo completo, no dentro de `PK_APEX_ARCHIVOS`.

- `Contexto:` La tabla comun es usada por muchos modulos y algunos objetos hacen `INSERT`, `UPDATE`, `DELETE` y `SELECT` directos sobre ella.
- `Estandar:` Para desarrollos nuevos se debe privilegiar el uso del paquete corporativo y el patron comun de consulta por `TABLA`, `ID_TABLA` y `TIPO`. Si se requiere una logica mas especializada, debe justificarse antes de escribir DML directo.
- `Razon:` Reduce variaciones innecesarias y mantiene consistente el manejo funcional de adjuntos entre aplicaciones.
- `Ejemplo:` un desarrollo nuevo no debe crear su propio mecanismo de secuencia o su propia tabla de documentos si el caso se resuelve con `PK_APEX_ARCHIVOS`.

- `Contexto:` Hay formularios donde el usuario solo necesita adjuntar, consultar o eliminar archivos sin ver una region de adjuntos embebida dentro de la pagina funcional.
- `Estandar:` En esos casos se debe usar como patron preferido la aplicacion `100`, pagina `401`, invocada desde un boton de la pagina funcional.
- `Razon:` La pagina `100/401` ya resuelve el flujo corporativo de adjuntos como modal reutilizable, lista archivos existentes y carga el archivo en `FILES.T_APEX_ARCHIVOS` sin volver a implementar la interfaz en cada modulo.
- `Ejemplo:` la aplicacion `137`, pagina `264`, usa el boton `ADJUNTAR` con la URL `f?p=100:401:&SESSION.::&DEBUG.:RP,:P401_TABLA,P401_ID,P401_ESTADO,P401_TIPO:T_ICOM_CLIENTE_VALIDACION,&P264_IDAGRUPACION.,1,`.

- `Contexto:` La pagina `100/401` carga archivos contra un registro de negocio existente y filtra la consulta por `TABLA`, `ID_TABLA` y, cuando aplica, `TIPO`.
- `Estandar:` La pagina invocadora debe enviar como minimo `P401_TABLA` y `P401_ID`. `P401_TIPO` solo debe enviarse cuando la clasificacion funcional del adjunto realmente aplique al caso.
- `Razon:` El modal necesita un identificador real del registro para relacionar correctamente el archivo; ademas, el `File Browse` del modal dispara el guardado al cambiar el item de archivo.
- `Ejemplo:` si el registro funcional aun no existe, el boton `Adjuntar` no debe mostrarse o debe quedar deshabilitado hasta que el usuario guarde primero el registro y se obtenga el `ID_TABLA`.

- `Contexto:` Cuando se usa `100/401`, es comun intentar repetir en la pagina invocadora el `File Browse`, el listado de archivos o procesos propios de insercion y borrado.
- `Estandar:` Si se adopta el patron `100/401`, la pagina invocadora no debe reimplementar la carga, consulta o eliminacion de adjuntos en su propio formulario. Solo debe invocar el modal corporativo y, si necesita reaccionar al cierre, hacerlo con un evento `Dialog Closed` para refrescar regiones o recalcular indicadores.
- `Razon:` Mantiene un unico punto reutilizable para gestionar adjuntos y evita duplicar logica visual y transaccional.
- `Ejemplo:` una pagina puede refrescar un reporte o un contador de archivos al cerrar el modal, pero no debe volver a ejecutar `PK_APEX_ARCHIVOS.SP_CREARARCHIVO` desde la pagina invocadora si ya decidio usar `100/401`.

- `Contexto:` Hay pantallas donde el usuario no necesita gestionar adjuntos, sino solo ver los archivos relacionados con el registro actual.
- `Estandar:` Si el requerimiento es solo mostrar adjuntos en modo lectura, se permite crear una region de tabla o reporte embebida en la pagina funcional, consultando `FILES.T_APEX_ARCHIVOS` por `TABLA`, `ID_TABLA` y, si aplica, `TIPO`.
- `Estandar:` Esa region de solo lectura puede incluir enlace de descarga usando el patron corporativo por `NUMEROARCHIVO`, `BLOBCONTENT`, `MIMETYPE` y `FILENAME`, pero no debe incluir `File Browse`, carga, reemplazo, eliminacion ni procesos propios de gestion.
- `Estandar:` No se debe replicar completa la seccion funcional de `100/401` dentro de la pagina invocadora. Si el usuario necesita adjuntar, reemplazar o eliminar, debe usarse el modal `100/401` como patron preferido, salvo justificacion funcional para usar `File Browse` propio.
- `Razon:` Mostrar una tabla de lectura facilita consultar evidencia o soportes dentro de la pantalla sin obligar a abrir el modal, pero mantiene centralizada la gestion de adjuntos y evita duplicar procesos.
- `Ejemplo:` una pagina de detalle puede mostrar una region `Adjuntos` con columnas `FILENAME`, `MIMETYPE`, fecha, usuario y accion `Descargar`, filtrando `TABLA = 'T_MOD_REGISTRO'` e `ID_TABLA = :P100_ID`. Si ademas se necesita cargar o eliminar archivos, la pagina debe abrir `100/401` desde un boton `Adjuntar`.

## Pasos obligatorios para usar el modal corporativo `100/401`

1. Confirmar la tabla funcional que se va a relacionar en `P401_TABLA`.
2. Confirmar que el registro funcional ya exista y que se disponga del identificador real para `P401_ID`.
3. Definir si el flujo necesita enviar `P401_TIPO` para clasificar o filtrar los adjuntos del caso.
4. Agregar en la pagina funcional un boton que abra `f?p=100:401...` enviando como minimo `P401_TABLA` y `P401_ID`.
5. No agregar un `File Browse` adicional en la pagina invocadora si el flujo ya se resolvera desde `100/401`.
6. Si la pagina funcional necesita actualizar un listado, contador o validacion dependiente de adjuntos, refrescarla al cerrar el modal con `Dialog Closed`.

## Pasos obligatorios para insertar adjuntos con `File Browse` propio

1. Confirmar la tabla funcional que se va a relacionar en `TABLA`.
2. Confirmar el identificador del registro funcional que se va a relacionar en `ID_TABLA`.
3. Definir si el adjunto requiere clasificacion en `TIPO`.
4. Guardar primero el registro funcional si aun no existe, para tener el `ID_TABLA` real.
5. Cargar el archivo en un item APEX tipo `File Browse`, de forma que APEX lo deje en `APEX_APPLICATION_TEMP_FILES`.
6. Invocar `DATA.PK_APEX_ARCHIVOS.SP_CREARARCHIVO` enviando:
   `P_ARCHIVO`, `P_TABLA`, `P_IDTABLA`, `P_TIPO`, `P_OBSERVACION`, `P_USUARIO`, `P_NUMEROARCHIVO`.
7. Mantener el `COMMIT` en la transaccion principal del proceso, no dentro del paquete de adjuntos.
8. Mostrar mensaje claro de exito o error al usuario.
9. Consultar los adjuntos con `TABLA`, `ID_TABLA` y, si aplica, `TIPO`.
10. Para descarga, usar el patron `DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME...:FILES`.
11. Para eliminacion, usar `DATA.PK_APEX_ARCHIVOS.SP_ELIMINAARCHIVO`.

Este patron con `File Browse` propio solo debe usarse cuando el flujo no pueda resolverse con el modal corporativo `100/401` o cuando exista una justificacion funcional clara para mantener la carga en la misma pagina.

## Ejemplo de insercion

```plsql
declare
    v_numeroarchivo number;
begin
    data.pk_apex_archivos.sp_creararchivo(
        p_archivo       => :P100_ARCHIVO,
        p_tabla         => 'T_MOD_REGISTRO',
        p_idtabla       => :P100_ID,
        p_tipo          => 'SOPORTE',
        p_observacion   => :P100_OBSERVACION,
        p_usuario       => :APP_USER,
        p_numeroarchivo => v_numeroarchivo
    );
end;
```
