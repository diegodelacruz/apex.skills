# Diccionario Interno ERP

## Objetivo
Centralizar la referencia del diccionario de datos interno usado por el skill para desarrollos ERP hechos por Zaimella.

## Regla de uso
- Ante una consulta sobre objetos ERP, primero identifica la compania.
- Luego consulta el diccionario de datos de esa compania.
- Si el diccionario de la compania no resuelve el objeto, valida en la fuente oficial del ERP o en la metadata confirmada del origen.
- El diccionario interno sirve para objetos personalizados o extendidos por Zaimella y no reemplaza la validacion oficial del ERP estandar.

## Diccionarios por compania

- `./erp-diccionario/00001-ecuador.md`
- `./erp-diccionario/00003-peru.md`
- `./erp-diccionario/00015-guatemala.md`
