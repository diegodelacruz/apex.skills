# Manual de Flujo de Aprobacion Oracle APEX

## Objetivo
Documentar el patron corporativo de flujo de aprobacion usado por Zaimella para que el agente pueda analizarlo, implementarlo, extenderlo o validarlo de forma consistente.

## Regla principal
Cuando el usuario indique que un objeto o proceso debe aprobarse, el agente debe entender que el alcance incluye el circuito completo de aprobacion y no solo uno o varios botones.

Como minimo debe evaluar:
- envio a ruta
- visualizacion de ruta
- comentarios del objeto
- comentario para aprobar o rechazar
- aprobacion
- rechazo
- configuracion de rutas y aprobadores

## Separacion de responsabilidades

### Logica del objeto
La logica funcional del objeto vive en el paquete del modulo.

Ejemplo en ICOM:
- `DATA.PK_ICOM_CRUD`

Responsabilidades:
- guardar datos del objeto
- actualizar estados del objeto
- registrar auditoria del modulo
- invocar el flujo corporativo cuando corresponde

### Logica corporativa del flujo
La logica corporativa del flujo vive en:
- `DATA.PK_CORP_FLUJOAPROBACION`

Responsabilidades:
- enviar a ruta
- aprobar
- rechazar
- resolver aprobador actual
- soportar mesa de trabajo y visualizacion del flujo
- integrar con servicios REST corporativos del flujo

### Configuracion de rutas
La configuracion funcional de rutas y aprobadores se administra en:
- aplicacion `111`, pagina `500`
- aplicacion `111`, pagina `501`

Responsabilidades:
- crear cabeceras de ruta
- definir criterios de clasificacion
- definir aprobadores y orden del flujo

### Dialogos corporativos reutilizables
La app `100` provee componentes de apoyo al flujo:
- `100/104`: ver ruta en curso
- `100/105`: comentarios del objeto
- `100/107`: comentario para aprobar o rechazar

## Objetos principales

### Paquete corporativo
- `DATA.PK_CORP_FLUJOAPROBACION`

Subprogramas relevantes:
- `SP_FLUJOENVIAR`
- `SP_FLUJOAPROBAR`
- `SP_FLUJORECHAZAR`
- `SP_GESTIONFLUJO`
- `F_APROBADORFLUJO`
- `F_GESTIONCOLOR`
- `F_MESAORDEN`
- `F_MESAICONORUTA`
- `F_GET_APROBADOR`

### Tablas de configuracion
- `DATA.T_ADMI_RUTA`
- `DATA.T_ADMI_RUTADETALLE`

### Tablas de seguimiento del flujo
- `DATA.T_FLUJO_APROBACION_CAB`
- `DATA.T_FLUJO_APROBACION_DET`

### Vistas de apoyo
- `DATA.VT_APEX_USUARIOREEMPLAZO`
- `DATA.VT_CORP_USUARIO`

### Parametrizacion de servicios
El paquete corporativo busca endpoints en:
- `DATA.T_CORP_UDC`

Cabecera usada:
- `ID_CABECERA = 'WEBSERVICE'`

Ids usados:
- `10`: enviar a ruta
- `11`: aprobar
- `12`: rechazar

## Configuracion de rutas en app 111

### Pagina 500
Pagina de listado de rutas.

Uso:
- consulta rutas existentes
- abre la pagina `501` para crear o editar

### Pagina 501
Pagina de mantenimiento de ruta y aprobadores.

Cabecera de ruta:
- tabla `DATA.T_ADMI_RUTA`

Campos relevantes:
- `CODIGOMODULO`
- `CODIGOCOMPANIA`
- `NOMBRE`
- `ORGRANIGRAMA`
- `CAMINOFIJO`
- `TIPO1..TIPO10`
- `CATEGORIA1..CATEGORIA10`

Detalle de aprobadores:
- tabla `DATA.T_ADMI_RUTADETALLE`

Campos relevantes:
- `ID_RUTA`
- `ORDEN`
- `CODIGOUSUARIO`
- `CODIGOCARGO`
- `USUARIOSUPERVISA`
- `SQLACTOR`

Interpretacion:
- la cabecera define para que tipo de objeto aplica la ruta
- `TIPO1..TIPO10` y `CATEGORIA1..CATEGORIA10` son criterios de clasificacion
- el detalle define aprobadores y orden del flujo

## Flujo tecnico corporativo

### Enviar a ruta
Se ejecuta mediante:
- `DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJOENVIAR`

Parametros clave:
- `P_ID`
- `P_OBJETO`
- `P_OBJETODESCRIPCION`
- `P_ETAPA`
- `P_USUARIO`
- `P_MODULO`
- `P_COMPANIA`
- `P_TIPO1..P_TIPO10`
- `P_CODIGOPAGINA`

Comportamiento:
- construye una trama JSON
- envia la solicitud por REST al endpoint configurado en `WEBSERVICE/10`
- pasa clasificaciones en `parametrosRuta`
- devuelve exito o error

### Aprobar
Se ejecuta mediante:
- `DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJOAPROBAR`

Comportamiento:
- arma JSON con objeto, usuario del flujo, comentario y usuarios dirigidos
- incluye usuarios reemplazo desde `VT_APEX_USUARIOREEMPLAZO`
- envia la solicitud al endpoint `WEBSERVICE/11`
- devuelve `P_EXITO`
- devuelve `P_TERMINOFLUJO`

### Rechazar
Se ejecuta mediante:
- `DATA.PK_CORP_FLUJOAPROBACION.SP_FLUJORECHAZAR`

Comportamiento:
- arma JSON con objeto, usuario del flujo, comentario y usuarios dirigidos
- envia la solicitud al endpoint `WEBSERVICE/12`
- devuelve `P_EXITO`

### Estado actual del flujo
Seguimiento general:
- `DATA.T_FLUJO_APROBACION_CAB`

Seguimiento por paso:
- `DATA.T_FLUJO_APROBACION_DET`

Campos utiles en cabecera:
- `ESTADO`
- `USUARIOACTUAL`
- `ENTIDAD_ID`
- `ENTIDAD_CLASE`
- `CODMODULO`
- `CIA`
- `ETAPA`

Campos utiles en detalle:
- `USERID`
- `ESTADO`
- `ZCOMENTARIO`
- `USERIDREEMPLAZO`
- `NOTIFICACION`

## Patron APEX reutilizable

### Ruta en curso
Pagina corporativa:
- `100/104`

Uso:
- visualizar el estado de la ruta
- mostrar aprobadores, gestion y fechas

Parametros esperados:
- `G_OBJETO`
- `G_OBJETO_ID`
- `G_TODO`

Patron de invocacion:
- el modulo abre `100/104`
- la pagina consulta servicio corporativo
- el resultado se transforma en coleccion `JSON`
- un `Interactive Report` muestra la ruta

### Comentarios del objeto
Pagina corporativa:
- `100/105`

Uso:
- listar comentarios del objeto
- registrar nuevo comentario del objeto
- dirigir comentario a usuarios

Parametros esperados:
- `G_MODULO`
- `G_COMPANIA`
- `G_USUARIO`
- `G_OBJETO`
- `G_OBJETO_ID`
- opcionalmente `G_ETAPA`
- opcionalmente `G_OBJETO_DESCRIPCION`

Comportamiento:
- carga comentarios via web service
- muestra resultados en la coleccion `COMENTARIO`
- al guardar construye JSON con:
  - objeto
  - objeto id
  - modulo
  - compania
  - usuario
  - etapa
  - descripcion del objeto
  - contenido
  - lista de usuarios

### Comentario para aprobar o rechazar
Pagina corporativa:
- `100/107`

Uso:
- capturar comentario y usuarios dirigidos antes de aprobar o rechazar

Comportamiento:
- no aprueba ni rechaza directamente
- devuelve datos a la pagina funcional mediante globals:
  - `G_COMENTARIO`
  - `G_USUARIOS_LISTA`

## Patron funcional en app 137

### Pagina 200
Objeto:
- `Inversion comercial`

Botones relevantes:
- `ENVIAR_RUTA`
- `RUTA`
- `COMENTARIO`

#### ENVIAR_RUTA
Secuencia:
1. confirma la accion en una Dynamic Action
2. hace submit con request `ENVIAR_RUTA`
3. la pagina ejecuta su guardado del objeto
4. llama `PK_ICOM_CRUD.SP_ENVIAR_RUTA`
5. ese wrapper llama `PK_CORP_FLUJOAPROBACION.SP_FLUJOENVIAR`

Conclusiones:
- primero debe guardarse el objeto
- luego se envia al flujo
- el modulo arma los clasificadores que el flujo necesita

#### RUTA
Abre:
- `100/104`

Objetivo:
- ver ruta en curso del objeto

#### COMENTARIO
Abre:
- `100/105`

Objetivo:
- registrar o consultar comentarios del objeto

### Pagina 201
Objeto:
- `Aprobacion Inversion`

Botones relevantes:
- `APRUEBA`
- `RECHAZA`
- `RUTA`
- `COMENTARIO`

#### APRUEBA
Secuencia:
1. abre `100/107`
2. el usuario escribe comentario y usuarios dirigidos
3. al cerrar el dialogo, una Dynamic Action copia:
   - `G_COMENTARIO` -> item local
   - `G_USUARIOS_LISTA` -> item local
4. hace submit con request `APRUEBA`
5. el proceso llama `PK_ICOM_CRUD.SP_APROBAR`
6. el wrapper llama `PK_CORP_FLUJOAPROBACION.SP_FLUJOAPROBAR`

#### RECHAZA
Secuencia equivalente:
1. abre `100/107`
2. recoge comentario y usuarios dirigidos
3. submit con request `RECHAZA`
4. llama `PK_ICOM_CRUD.SP_APROBAR` con estado de rechazo
5. el wrapper llama `PK_CORP_FLUJOAPROBACION.SP_FLUJORECHAZAR`

#### RUTA
Abre:
- `100/104`

#### COMENTARIO
Abre:
- `100/105`

## Regla de interpretacion para el agente
Si el usuario pide que un objeto debe aprobarse, el agente debe revisar o implementar como minimo:
- boton o accion de `Enviar a ruta`
- wrapper del modulo para invocar `PK_CORP_FLUJOAPROBACION.SP_FLUJOENVIAR`
- boton o accion `RUTA` hacia `100/104`
- boton o accion `COMENTARIO` hacia `100/105`
- boton o accion de `APRUEBA`
- boton o accion de `RECHAZA`
- uso de `100/107` para comentario de aprobar o rechazar
- configuracion de ruta en `111/500-501`
- validacion de que exista ruta parametrizada para modulo, compania y clasificaciones

## Checklist de implementacion

### Si el objeto nuevo debe aprobarse
- definir `OBJETO` funcional y codigo de modulo
- definir que etapa o clasificacion enviara en `P_TIPO1..P_TIPO10`
- implementar wrapper del modulo para `SP_FLUJOENVIAR`
- implementar wrapper del modulo para aprobar y rechazar
- agregar boton `ENVIAR_RUTA`
- agregar boton `RUTA`
- agregar boton `COMENTARIO`
- agregar pantalla o seccion de aprobacion con `APRUEBA` y `RECHAZA`
- integrar `100/107` para comentarios de aprobacion
- parametrizar ruta y aprobadores en `111/500-501`
- probar envio, aprobacion, rechazo y comentarios

### Si el flujo ya existe y solo se modifica
- validar si el objeto ya usa el patron corporativo
- validar si la ruta existente cubre los nuevos criterios
- validar si la pagina usa `100/104`, `100/105` y `100/107`
- validar si el wrapper del modulo ya llama a `PK_CORP_FLUJOAPROBACION`
- no duplicar componentes si ya existen

## Reglas de implementacion
- no implementar aprobacion solo con logica declarativa APEX
- no crear botones de aprobar o rechazar sin integrarlos al flujo corporativo
- no omitir la configuracion de ruta cuando el objeto requiera aprobacion
- no mezclar el comentario general del objeto con el comentario puntual de aprobar o rechazar
- no reemplazar el patron corporativo salvo justificacion explicita del usuario

## Diferencia entre comentarios

### Comentario del objeto
Se gestiona en:
- `100/105`

Uso:
- conversacion o trazabilidad general del objeto
- no ejecuta aprobacion ni rechazo

### Comentario de aprobar o rechazar
Se gestiona en:
- `100/107`

Uso:
- comentario puntual previo a aprobar o rechazar
- devuelve datos a la pagina funcional para ejecutar la accion real

## Criterio final para el agente
Si el usuario dice:
- "este objeto debe aprobarse"

El agente debe entender:
- que debe integrarse al flujo corporativo completo
- que la logica del objeto y la logica del flujo son separadas
- que ambas deben quedar conectadas
- que tambien debe existir configuracion de ruta
