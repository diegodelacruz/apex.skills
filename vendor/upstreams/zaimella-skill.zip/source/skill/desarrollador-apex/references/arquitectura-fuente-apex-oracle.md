# Arquitectura Fuente APEX/Oracle

> Limite: esta referencia describe convenciones tecnicas de la fuente versionada. El orquestador APEX prepara el contexto, contratos, checkout y worktree; el skill no crea ni administra la arquitectura del proyecto, tareas, bitacoras, ramas, worktrees o handoffs. Si una convencion exige una nueva ubicacion fuente, devolver la necesidad y el inventario al orquestador para que la prepare dentro del alcance autorizado.

Esta referencia aplica cuando el proyecto o `desarrollo.md` indiquen que existe el repositorio empresarial de codigo fuente `zaimella-apex-oracle`.

Repositorio GitHub oficial e inmutable:

```text
https://github.com/zaimella/zaimella-apex-oracle
```

No pidas al usuario redefinir este remoto. Solo confirma la ruta local donde esta clonado en la maquina del usuario.

## Separacion de responsabilidades

Usa dos espacios separados:

```text
proyecto/contexto/
|- desarrollo.md
|- docs/
|- docs/bitacora.md
|- docs/tareas/<ID_TAREA>/
|- qa/tareas/<ID_TAREA>/
|- docs/logs/
`- tmp/

zaimella-apex-oracle/
|- APEX/
`- ORACLE/

<WORKTREES_ROOT>/
`- <REPO_SLUG>/<PROJECT_SLUG>/<ID_TAREA>/
```

- `proyecto/contexto/` gobierna el trabajo local en la maquina del usuario: requerimiento, instrucciones, alcance, bitacora, analisis, QA, evidencias, temporales, deploy activo y pases cerrados. No debe asumirse como repositorio GitHub ni publicarse por rutina.
- `zaimella-apex-oracle/` gobierna el codigo fuente versionado en GitHub: aplicaciones APEX, objetos Oracle y contratos reutilizables de QA por aplicacion cuando existan.
- El checkout principal definido como `Repo fuente local` en `desarrollo.md` es de integracion, revision y publicacion. El skill trabaja exclusivamente en el checkout o worktree entregado por el contexto; no genera slugs, IDs, ramas ni rutas operativas.
- `docs/tareas/<ID_TAREA>/` y `qa/tareas/<ID_TAREA>/` separan deploy, logs, navegacion, reporte y evidencias de sesiones paralelas. `docs/deploy/` se reserva para el pase final integrado o consolidado.
- El ambiente TEST es compartido y el contexto invocador coordina reservas por recurso. Puede autorizar en paralelo integración, compilación/importación y QA de alcances que no compartan objeto Oracle completo, `APP_ID/PAGE_ID`, archivo/import APEX, script de deploy, flujo QA, datos temporales ni una integración no separable. El skill recibe la fase y checkout correspondientes; no crea, interpreta, adquiere, transfiere ni libera mecanismos de coordinación.
- Si el checkout recibido contiene cambios ajenos o archivos sin seguimiento, preservalos: no los sanees, muevas ni borres. Solicita al contexto un worktree limpio y aislado solo cuando no haya entregado uno, reporta el efecto tecnico y continua todo trabajo independiente.
- `qa/tareas/<ID_TAREA>/reports/`, `qa/tareas/<ID_TAREA>/screenshots/`, `qa/tareas/<ID_TAREA>/traces/`, `docs/tareas/<ID_TAREA>/logs/`, `docs/manuales/` y el pase final `docs/deploy/` pertenecen al `proyecto/contexto`, no al repo fuente `zaimella-apex-oracle`.
- Las rutas, page objects, flows, tests y datos de prueba reutilizables pueden vivir versionados en `zaimella-apex-oracle/APEX/<APP_ID>-<CODIGO_O_NOMBRE_APP>/QA/`; las evidencias de una corrida concreta permanecen en el `proyecto/contexto`.
- No guardes en `zaimella-apex-oracle/` bitacoras de sesion, analisis puntuales, temporales, capturas, evidencias QA, deploys de trabajo, credenciales, logs ni documentos especificos de una tarea.
- No guardes en `proyecto/contexto/` copias permanentes que pretendan reemplazar la fuente versionada cuando el objeto ya vive en `zaimella-apex-oracle/`.
- No subas a GitHub archivos del `proyecto/contexto` salvo instruccion explicita del usuario y revision previa de contenido sensible o temporal.
- El unico remoto oficial para `zaimella-apex-oracle` es `https://github.com/zaimella/zaimella-apex-oracle`.

## `desarrollo.md` del proyecto/contexto

Cuando se use esta arquitectura, `desarrollo.md` es la fuente principal de instrucciones del desarrollo, pero no pertenece al skill. Debe vivir en la raiz del `proyecto/contexto` antes de tocar codigo fuente versionado.

### Contrato vinculante

- Trata `desarrollo.md` como contrato obligatorio de alcance, no como nota informativa.
- No edites codigo APEX ni Oracle dependiente si `desarrollo.md` falta, esta incompleto o contiene placeholders obligatorios sin resolver; reporta `Impedimento tecnico de entrada` con los campos exactos y continua todo analisis seguro. El contexto decide el estado.
- No edites aplicaciones APEX cuyo `APP_ID` no este en `desarrollo.md`.
- No edites objetos Oracle que no coincidan con los codigos/prefijos funcionales o patrones autorizados definidos en `desarrollo.md`, salvo autorizacion explicita y actualizacion previa del archivo.
- Si el usuario pide trabajar sobre otra aplicacion, prefijo, ruta u objeto fuera del contrato, actualizar `desarrollo.md` y registrar la decision en `docs/bitacora.md` cuando exista antes de editar.
- Si metadata Oracle/APEX, repo fuente o pedido verbal contradicen `desarrollo.md`, detente, informa la contradiccion y pide actualizar `desarrollo.md` antes de modificar codigo.
- En la respuesta final de un desarrollo, indica que se respeto el alcance de `desarrollo.md` o lista las actualizaciones de alcance realizadas.

### Campos base obligatorios

`desarrollo.md` debe tener siempre estos seis campos:

1. `Responsable/desarrollador`
   - Obligatorio.
   - No tiene valor por defecto.
   - El skill debe exigirlo al usuario.
   - Usalo como responsable en comentarios tecnicos de paquetes, rutinas y documentacion tecnica cuando los estandares de base lo requieran.
2. `Ruta local del proyecto/contexto`
   - Obligatorio.
   - Valor por defecto: directorio actual de la sesion.
   - Si el usuario indica otra ruta, usa la ruta indicada.
3. `Ruta local del checkout GitHub zaimella-apex-oracle`
   - Obligatorio.
   - Valor por defecto: `C:/ZAIMELLA`.
   - El remoto oficial sigue siendo siempre `https://github.com/zaimella/zaimella-apex-oracle`.
   - Si la ruta no existe, reportar `Impedimento tecnico de fuente no preparada` antes de editar fuente versionada; el contexto decide el estado.
4. `Raiz local de worktrees por tarea`
   - Obligatorio.
   - Valor por defecto: `C:/ZAIMELLA-WORKTREES`.
   - El contexto invocador entrega el worktree completo correspondiente; el skill no construye su ruta a partir de identificadores.
5. `Aplicaciones APEX`
   - Obligatorio.
   - No tiene valor por defecto.
   - El usuario debe informar solo el `APP_ID` de la aplicacion o aplicaciones que se trabajaran en el proyecto.
   - Las paginas especificas, componentes o flujos puntuales se documentan dentro del proyecto segun la tarea, por ejemplo en requerimientos, `docs/bitacora.md`, rutas QA o documentos de analisis; no son obligatorios en este bloque base.
6. `Codigos/prefijos funcionales`
   - Obligatorio.
   - No tiene valor por defecto.
   - El usuario debe informar codigos como `INTC`, `ICOM`, `COMP`, `CORP` u otros.
   - Estos codigos definen los patrones autorizados de busqueda y edicion, como `*_INTC_*` o `*_ICOM_*`.

Si cualquiera de los campos obligatorios sin valor por defecto falta o queda vacio, no edites codigo fuente versionado dependiente. Reporta `Impedimento tecnico de entrada` con los campos exactos y continua lo independiente.

Si falta una aplicacion, prefijo u objeto necesario para delimitar el alcance, no edites codigo fuente hasta resolverlo por evidencia local, metadata Oracle/APEX o confirmacion del usuario y dejarlo registrado en `desarrollo.md` o en la bitacora del proyecto.

### Estructura esperada

El skill no debe inventar ni regenerar el formato de `desarrollo.md`; consume el contrato existente del proyecto.

Para validar el contrato, exige como minimo estas secciones:

- `Campos Base`
- `Datos Derivados O Confirmados`
- `Aplicaciones APEX Confirmadas`
- `Objetos De Alcance`
- `Fuera De Alcance`
- `Reglas De Trabajo`
- `Sesion Inicial`

### Reglas de uso para el agente

- Usa `Responsable/desarrollador` como valor de referencia para comentarios tecnicos de encabezado cuando los estandares de base exijan responsable.
- Usa siempre `https://github.com/zaimella/zaimella-apex-oracle` como remoto oficial del repo fuente; si el checkout local apunta a otro remoto, reportalo antes de editar.
- Usa solo los `APP_ID` definidos en `desarrollo.md` para ubicar APEX; no busques ni edites otras aplicaciones por aproximacion.
- Usa `Codigos/prefijos funcionales` para construir y aplicar `Patrones autorizados` durante busquedas amplias.
- Usa `Objetos de alcance` como lista permitida de edicion. Las busquedas de diagnostico pueden leer mas objetos, pero no modificarlos.
- Si el objeto real no coincide con el archivo fuente esperado, registra diferencia entre fuente y base antes de modificar.
- Si un objeto necesario no aparece en `Objetos de alcance`, pide autorizacion o actualiza el alcance en `desarrollo.md`/`docs/bitacora.md` antes de editarlo.
- Si `desarrollo.md` no existe, esta vacio o incompleto, no toques codigo fuente versionado dependiente; reporta `Impedimento tecnico de entrada` con los datos faltantes y continua lo independiente.

## Alcance de edicion

- El proyecto/contexto define el alcance funcional y operativo.
- `zaimella-apex-oracle` define la fuente tecnica versionada en GitHub que se puede modificar.
- Modifica solo los archivos de la aplicacion APEX declarada y los objetos Oracle cubiertos por `desarrollo.md`, `Objetos de alcance` o por una actualizacion de alcance registrada en `docs/bitacora.md`.
- Puedes buscar referencias para diagnosticar dependencias, pero no edites objetos fuera del alcance declarado.
- Si aparece un objeto adicional necesario, informa:
  - objeto
  - motivo tecnico o funcional
  - si es compartido o especifico
  - impacto probable
  - decision requerida
- No incorpores un objeto adicional al cambio sin autorizacion explicita o sin que el alcance quede actualizado en `desarrollo.md` o `docs/bitacora.md`.

## Bootstrap de fuente faltante

Antes de concluir que no existe fuente versionada, asegura primero que el checkout local exista. Si falta, reporta `Impedimento tecnico de fuente no preparada`; este skill no crea ni clona checkouts ni cambia el estado de la tarea.

Si la ruta local definida en `desarrollo.md` para `zaimella-apex-oracle` no existe:

1. No edites codigo fuente versionado.
2. Reporta `Impedimento tecnico de fuente no preparada`; no marques la tarea.
3. Continua solo cuando exista el checkout local y su remoto `origin` sea el oficial.

Si la ruta existe pero no es un repositorio Git:

- No la inicialices desde este skill.
- No sobrescribas ni borres archivos.
- Reporta `Conflicto tecnico por ruta ocupada no versionada`; no muevas archivos ajenos ni cambies el estado de la tarea. El contexto debe proporcionar una ruta limpia o una decision explicita.

Si la ruta existe y es repositorio Git pero apunta a otro remoto, reporta la contradiccion antes de editar y pide confirmacion o correccion del checkout.

Si el checkout `zaimella-apex-oracle` no contiene la aplicacion APEX, pagina u objeto Oracle incluido en `desarrollo.md`, el skill debe confirmar si ya existe en APEX/Oracle real antes de editar. Si existe, debe inicializar esa fuente desde APEX/Oracle real. Si se trata de un objeto Oracle nuevo aprobado por el alcance, debe crear el archivo fuente nuevo en el repo siguiendo los estandares y preparar su despliegue normal. No crees archivos vacios, stubs, esqueletos manuales ni copies exports antiguos, temporales o no verificados como fuente de verdad para objetos existentes.

Clonar el repositorio no completa el bootstrap si la aplicacion u objeto del alcance no existe dentro del checkout. Con el checkout disponible, este skill debe localizar la fuente del alcance y, si falta, verificar existencia en APEX/Oracle real. Para fuente existente, ejecuta inmediatamente la exportacion o extraccion con los scripts oficiales del skill. Para objeto Oracle nuevo, crea la fuente versionada desde cero solo si esta dentro del alcance autorizado.

Reglas:

- Aplica este bootstrap solo para `APP_ID`, paginas y objetos Oracle cubiertos por `desarrollo.md`, `Objetos de alcance` o una actualizacion de alcance registrada.
- Valida conectividad Oracle antes de extraer.
- Usa TEST como ambiente normal de origen. Si el objeto solo existe en PRODUCCION o la metadata de TEST no coincide, detente e informa la diferencia; una extraccion desde PRODUCCION requiere autorizacion explicita y debe ser de solo lectura.
- Si la aplicacion o pagina APEX tampoco existe en APEX real, reportala como `No encontrada` y no inventes la fuente salvo que el requerimiento sea crearla.
- Si el objeto Oracle no existe en Oracle real, separa el caso:
  - Si el usuario pidio modificar, corregir, revisar o desplegar un objeto existente, reportalo como `No encontrado` y no inventes la fuente.
  - Si el usuario pidio crear un objeto nuevo o el alcance aprobado lo requiere, crea el archivo fuente nuevo en `zaimella-apex-oracle`, siguiendo `./references/estandares-base-datos.md`, registra que no habia objeto previo en TEST y prepara el script de creacion en `docs/tareas/<ID_TAREA>/deploy` cuando aplique.
- Usa la estructura existente del repo. Si no existe convencion para esa aplicacion u objeto, crea la carpeta bajo la estructura recomendada de esta referencia y registra la decision en `desarrollo.md` o `docs/bitacora.md`.
- Despues de importar, trata los archivos creados en `zaimella-apex-oracle` como fuente versionada para el resto del desarrollo.

## Convencion obligatoria de archivos APEX versionados

El repo `zaimella-apex-oracle` debe guardar fuente APEX reutilizable y estable. Los nombres de archivo no deben depender de casos, tickets, tareas, fechas, usuarios, companias, documentos o instancias puntuales usadas para diagnosticar un requerimiento.

Reglas:

- Paginas APEX versionadas: usar siempre `APEX/<APP_ID>-<CODIGO_O_NOMBRE_APP>/PAGINAS/page_<PAGE_ID_4_DIGITS>.sql`.
- El `PAGE_ID` debe ir con al menos cuatro digitos, rellenando con ceros a la izquierda. Ejemplos validos: `page_0100.sql`, `page_0400.sql`, `page_1000.sql`.
- No crear ni conservar como fuente nombres como `p400_case_50234.sql`, `page_400_ticket_123.sql`, `page_0400_20260707.sql`, `page_0400_prueba.sql` o equivalentes.
- Exports completos de aplicacion que se guarden como fuente estable deben ir en `APEX/<APP_ID>-<CODIGO_O_NOMBRE_APP>/EXPORTS/f<APP_ID>.sql`.
- Backups, evidencias, pruebas, comparaciones y exports ligados a una tarea, caso o fecha deben vivir en el `proyecto/contexto`, por ejemplo en `tmp/`, `docs/tareas/<ID_TAREA>/logs/`, `docs/tareas/<ID_TAREA>/deploy/` o `docs/pases-produccion/`, no como fuente permanente del repo.
- Si ya existe una pagina con otro formato de nombre en el repo fuente, no crees un segundo archivo para la misma pagina. Normaliza al formato obligatorio si el cambio es claramente la misma pagina y no hay conflicto; si hay colision, cambios ajenos o duda sobre cual archivo manda, detente, registra la diferencia y pide decision antes de editar.
- Al exportar una pagina desde APEX real hacia `zaimella-apex-oracle`, define explicitamente el `--output` con la ruta estandar completa `APEX/<APP_ID>-<CODIGO_O_NOMBRE_APP>/PAGINAS/page_<PAGE_ID_4_DIGITS>.sql`.
- Al registrar `Archivo fuente esperado` en `desarrollo.md`, usa este formato para paginas APEX.

## Convencion obligatoria de rutas y archivos Oracle versionados

El repo `zaimella-apex-oracle` debe guardar objetos Oracle con un solo estilo de ruta y nombre para evitar duplicados por mayusculas/minusculas, rutas distintas por sesion o archivos dependientes de la maquina local.

Reglas generales:

- Usa carpetas canonicas en mayusculas: `ORACLE/DATA/TABLAS`, `ORACLE/DATA/VISTAS`, `ORACLE/DATA/PAQUETES/SPECS`, `ORACLE/DATA/PAQUETES/BODIES`, `ORACLE/DATA/TRIGGERS`, `ORACLE/DATA/TYPES`, `ORACLE/DATA/SEQUENCES`, `ORACLE/DATA/CONSTRAINTS`, `ORACLE/DATA/INDEXES`, `ORACLE/DATA/MIGRACIONES` y `ORACLE/DATA/ORDS/<MODULO>`.
- Usa archivos con el nombre del objeto Oracle en mayusculas y extension `.sql`: `<OBJECT_NAME>.sql`.
- No incluyas owner en el nombre del archivo. La ruta ya define el owner/esquema. Usa `PK_MODULO_OBJETO.sql`, no `DATA.PK_MODULO_OBJETO.sql`.
- No uses carpetas o archivos en minusculas o case mixto como `oracle/data/paquetes/bodies/pk_modulo_objeto.sql`, `ORACLE/DATA/PAQUETES/Bodies/PK_MODULO_OBJETO.sql` o `ORACLE/DATA/PAQUETES/BODIES/pk_modulo_objeto.sql`.
- No uses sufijos de caso, ticket, tarea, fecha, intento o ambiente en archivos fuente Oracle. Esos artefactos pertenecen al `proyecto/contexto`, no al repo fuente.
- Si una herramienta genera archivos en otra carpeta, con minusculas o con un nombre no canonico, normalizalos al destino canonico antes de considerarlos fuente versionada.
- Si ya existe el mismo objeto con variantes de mayusculas/minusculas o rutas duplicadas, no edites a ciegas. Compara contenido, decide la fuente vigente y deja un solo archivo canonico. Si hay conflicto real, registra la diferencia y pide decision antes de modificar.
- En Windows, si Git no detecta un cambio solo de mayusculas/minusculas, usa un renombrado intermedio controlado con `git mv` para que el repositorio registre la normalizacion.
- Al registrar `Archivo fuente esperado` en `desarrollo.md`, usa siempre la ruta canonica.

Convencion por tipo:

```text
PACKAGE SPEC  -> ORACLE/DATA/PAQUETES/SPECS/<PACKAGE_NAME>.sql
PACKAGE BODY  -> ORACLE/DATA/PAQUETES/BODIES/<PACKAGE_NAME>.sql
VIEW          -> ORACLE/DATA/VISTAS/<VIEW_NAME>.sql
TABLE         -> ORACLE/DATA/TABLAS/<TABLE_NAME>.sql
TRIGGER       -> ORACLE/DATA/TRIGGERS/<TRIGGER_NAME>.sql
TYPE          -> ORACLE/DATA/TYPES/<TYPE_NAME>.sql
SEQUENCE      -> ORACLE/DATA/SEQUENCES/<SEQUENCE_NAME>.sql
CONSTRAINT    -> ORACLE/DATA/CONSTRAINTS/<CONSTRAINT_NAME>.sql
INDEX         -> ORACLE/DATA/INDEXES/<INDEX_NAME>.sql
ORDS MODULE   -> ORACLE/DATA/ORDS/<MODULO>/<ARTEFACTO>.sql
```

Para APEX:

- Exporta desde TEST el `APP_ID` o pagina aprobada con el mecanismo oficial del skill:

```powershell
python scripts/apex_export_sql_via_python.py --application-id <APP_ID> --environment test --output APEX/<APP_ID>-<CODIGO_O_NOMBRE_APP>/EXPORTS/f<APP_ID>.sql
python scripts/apex_export_sql_via_python.py --application-id <APP_ID> --page-id <PAGE_ID> --environment test --output APEX/<APP_ID>-<CODIGO_O_NOMBRE_APP>/PAGINAS/page_<PAGE_ID_4_DIGITS>.sql
```

- Guarda el resultado dentro de la carpeta APEX del repo siguiendo la convencion obligatoria de esta referencia. Si el repo aun no tiene carpeta para esa app, usa `APEX/<APP_ID>-<CODIGO_O_NOMBRE_APP>/EXPORTS/` para el export completo y `APEX/<APP_ID>-<CODIGO_O_NOMBRE_APP>/PAGINAS/` para paginas.
- Registra workspace, APP_ID, pagina si aplica, ambiente origen, archivo generado y fecha de extraccion.

Para Oracle:

- Antes de decidir crear fuente nueva, valida si el objeto existe en TEST con metadata Oracle usando la herramienta oficial de consultas del skill. Si existe, no lo recrees desde cero: extrae su definicion real.
- Extrae la definicion desde TEST usando la herramienta oficial disponible para objetos de base, por ejemplo:

```powershell
python scripts/production_deploy_tool.py export-test-objects --project-root <proyecto_contexto> --task-id <ID_TAREA> --objects TIPO:OWNER.OBJETO
```

- Si la herramienta genera el objeto en `docs/tareas/<ID_TAREA>/deploy` u otra carpeta operativa de la tarea, copialo o normalizalo manualmente al archivo fuente canonico de `zaimella-apex-oracle` solo despues de verificar que representa el objeto real de TEST.
- Ubica cada objeto segun la convencion obligatoria de rutas y archivos Oracle versionados de esta referencia; no uses carpetas equivalentes con minusculas o case mixto.
- No importes objetos que no coincidan con los patrones autorizados por `Codigos/prefijos funcionales`, salvo autorizacion explicita y actualizacion previa del alcance.
- Si el objeto Oracle es nuevo y no existe en TEST, crea el archivo fuente en la carpeta correspondiente del repo, con nombre funcional autorizado, DDL/PLSQL completo, comentarios y estructura segun `estandares-base-datos.md`. Luego genera o actualiza el script de despliegue en `docs/tareas/<ID_TAREA>/deploy` para TEST; promuevelo a `docs/deploy` solo al ensamblar el pase final aprobado.

Trazabilidad minima:

- Entrega al contexto la evidencia del bootstrap: ambiente origen, APP_ID u objeto, comando usado, archivo creado, diferencias detectadas y pendientes. No actualices sesiones ni estados.
- Actualiza `desarrollo.md` si durante la importacion se confirma la carpeta fuente, nombre de aplicacion, objetos de alcance o convencion de archivos.
- Antes de editar, revisa `git status` del repo fuente y confirma que los archivos importados corresponden solo al alcance declarado.

## Baseline inicial APEX vs Oracle vs GitHub

Al iniciar un proyecto APEX/Oracle con `zaimella-apex-oracle`, el skill debe ejecutar una unica comparacion inicial para construir el baseline de fuente. Este baseline se ejecuta solo al arranque del proyecto o cuando el usuario lo pida explicitamente; no debe repetirse en cada tarea normal.

Objetivo:

- Tomar la aplicacion APEX en Oracle TEST como fuente mandatoria inicial para identificar los objetos Oracle existentes que usa la aplicacion.
- Asegurar que `zaimella-apex-oracle` contenga la fuente actualizada de esos objetos antes de iniciar desarrollo.
- Dejar registrado el punto de partida para que, despues del baseline, el repositorio versionado sea la fuente mandatoria y Oracle TEST se actualice desde el repo.

Alcance del baseline:

- Usar `APP_ID`, paginas, codigos/prefijos funcionales y objetos declarados en `desarrollo.md`.
- Analizar la aplicacion APEX, su export o metadata real para detectar objetos Oracle usados por reportes, regiones, LOVs, procesos, validaciones, condiciones, branches, acciones dinamicas, jobs invocados, paquetes, funciones, procedimientos, vistas, tablas, secuencias, triggers y tipos cuando sean referenciables.
- No comparar toda la base de datos. Comparar solo objetos usados por la aplicacion APEX o incluidos en el alcance autorizado.

Reglas de decision del baseline:

- Durante el baseline inicial, Oracle TEST manda para objetos existentes usados por la aplicacion APEX.
- Si un objeto existe en Oracle TEST y falta en GitHub, extraelo desde TEST con la herramienta oficial y normalizalo al repo.
- Si un objeto existe en Oracle TEST y en GitHub pero difiere, registra la diferencia y, salvo instruccion contraria del usuario, actualiza GitHub con la definicion de TEST.
- Si un objeto existe en GitHub pero no existe en Oracle TEST, registralo como inconsistencia o como pendiente de despliegue; no lo elimines ni lo despliegues sin decision registrada.
- Si un objeto no existe ni en Oracle TEST ni en GitHub, solo se crea si el requerimiento o alcance aprobado indica que es un objeto nuevo.
- Si un objeto requerido esta `INVALID` en TEST, registra el error y no cierres el baseline como saludable hasta corregirlo o recibir autorizacion para continuar con riesgo.

Evidencia minima:

- Genera o actualiza `docs/fuente/baseline_apex_oracle_vs_github.md` cuando exista estructura `docs/`.
- Registra inventario de objetos detectados, estado en Oracle TEST, estado en GitHub, diferencias, objetos extraidos, objetos nuevos pendientes, objetos invalidos y decisiones tomadas.
- Registra tambien el baseline en `docs/bitacora.md` con `Sesion`, `ID tarea`, APP_ID, ambiente TEST, ruta del repo fuente y resultado.

Despues del baseline:

- `zaimella-apex-oracle` queda como fuente versionada mandatoria.
- Los cambios nuevos se hacen en el repo y se compilan o despliegan hacia Oracle TEST.
- No vuelvas a sincronizar todo desde Oracle TEST salvo que el usuario lo pida, cambie el `APP_ID` o alcance, se detecte desalineacion fuerte, haya cambios manuales fuera del repo o se reinicie formalmente el proyecto con otro baseline.

## Diferencias entre GitHub y Oracle/APEX real

GitHub es la fuente versionada, pero Oracle/APEX real puede contener cambios vigentes no versionados. Antes de editar, si el cambio depende de una aplicacion, pagina u objeto ya existente, el skill debe contrastar el repo fuente contra Oracle/APEX real cuando haya indicios de diferencia o cuando la fuente del alcance fue creada fuera del repositorio.

Casos que obligan a reconciliar antes de editar:

- GitHub no contiene la aplicacion, pagina u objeto, pero Oracle/APEX real si existe.
- GitHub contiene la fuente, pero la metadata, fecha, pagina, objeto o comportamiento relevante no coincide con TEST.
- Oracle TEST contiene cambios manuales no versionados.
- GitHub contiene objetos que no existen o no compilan en TEST.
- El cambio pide crear un objeto Oracle nuevo y el objeto no existe ni en GitHub ni en TEST.
- TEST y PRODUCCION difieren en un reporte productivo o correccion que depende de esa diferencia.
- Hay cambios locales que podrian ser la fuente vigente del mismo `APP_ID/PAGE_ID`, objeto Oracle, archivo o alcance de la tarea actual.

Regla de decision:

- Para desarrollo nuevo o correccion normal, TEST es el origen operativo normal para sincronizar la fuente del alcance.
- Para incidente productivo, PRODUCCION se usa para diagnosticar la verdad del error; la correccion se replica y versiona desde TEST antes del pase, salvo autorizacion explicita de emergencia.
- Si GitHub tiene cambios locales o remotos no publicados que podrian ser la fuente vigente, no los sobrescribas con export de TEST sin revisar el diff y registrar la decision.
- Si existe conflicto real entre GitHub y Oracle/APEX real, no edites el codigo hasta registrar la diferencia y resolver cual fuente manda para esa tarea.
- Cambios ajenos fuera del alcance, incluso sin seguimiento, no son una diferencia de fuente para la tarea actual: preservalos y usa el worktree aislado para integrar cuando corresponda.

Formato minimo de diferencia:

```markdown
## Diferencia fuente vs Oracle/APEX real

- Sesion:
- ID tarea:
- APP_ID / PAGE_ID / objeto:
- GitHub:
- Oracle TEST:
- Oracle PRODUCCION si aplica:
- Riesgo:
- Fuente vigente decidida:
- Accion autorizada:
```

Sincronizacion permitida:

- Si TEST es la fuente vigente para una aplicacion o pagina APEX, exporta con `scripts/apex_export_sql_via_python.py` y guarda el archivo en `zaimella-apex-oracle` segun la convencion obligatoria de archivos APEX versionados de esta referencia.
- Si TEST es la fuente vigente para objetos Oracle, extrae con `scripts/production_deploy_tool.py export-test-objects` y normaliza al archivo fuente canonico definido en esta referencia.
- Si el objeto Oracle es nuevo y TEST confirma que no existe, crea la fuente nueva en `zaimella-apex-oracle` y el script de despliegue correspondiente; no intentes extraerlo ni lo marques como desalineacion bloqueante.
- Si PRODUCCION es la unica fuente existente o la unica que reproduce el estado requerido, la extraccion desde PRODUCCION debe ser de solo lectura, con autorizacion explicita y registro en bitacora.

Despues de sincronizar:

1. Revisa `git status` del repo fuente.
2. Confirma que los archivos creados o actualizados corresponden solo al alcance de `desarrollo.md`.
3. Registra en `docs/bitacora.md` la fuente vigente elegida, comando usado, archivo actualizado y diferencias detectadas.
4. Solo entonces continua con la edicion.

## QA y rutas funcionales

- Distingue dos tipos de QA:
  - Contrato reutilizable versionado: rutas estables, page objects, flows, tests, casos de uso y plantillas de datos que describen como debe funcionar una pagina o proceso normalmente.
  - Ejecucion puntual: rutas usadas en la tarea actual, datos concretos, screenshots, traces, logs, hallazgos e `informe_qa.md`.
- El contrato reutilizable debe vivir en `zaimella-apex-oracle/APEX/<APP_ID>-<CODIGO_O_NOMBRE_APP>/QA/` cuando la aplicacion ya use repo fuente y el flujo sea repetible.
- La ejecucion puntual debe vivir en `qa/tareas/<ID_TAREA>/navigation`, `reports`, `screenshots`, `traces` y `docs/tareas/<ID_TAREA>/logs`.
- Antes de entregar a QA, sincroniza la navegacion versionada desde `zaimella-apex-oracle/APEX/<APP_ID>-<CODIGO_O_NOMBRE_APP>/QA/navigation/` hacia `<PROJECT_ROOT>/qa/tareas/<ID_TAREA>/navigation/`, donde `<PROJECT_ROOT>` es la carpeta real del proyecto/contexto.
- El desarrollo APEX debe crear o actualizar el contrato reutilizable cuando cambia una pantalla, boton, dialogo, menu, link de reporte, accion por fila, branch, formulario, validacion o flujo visible que ya tenga QA versionado o que convenga repetir.
- Si aun no existe contrato reutilizable, el desarrollo APEX debe al menos crear o actualizar la ruta funcional operativa en `<PROJECT_ROOT>` para no bloquear el QA actual.
- La ruta o contrato funcional debe incluir el funcionamiento real de la pagina o flujo: que boton/link/accion debe ejecutar QA, que proceso APEX/PLSQL o comportamiento dispara cuando sea relevante, que dialogo o pantalla abre, que datos minimos requiere, que resultado y mensaje se esperan, que restricciones se validan y que acciones similares no aplican al escenario.
- Si desarrollo ya analizo metadata, export APEX o procesos para implementar el cambio, ese conocimiento debe quedar resumido en el contrato reutilizable o en la ruta operativa de QA; no debe transferirse a QA como investigacion repetida.
- El flujo QA independiente consume `<PROJECT_ROOT>/qa/tareas/<ID_TAREA>/navigation/`; no redescubre la ruta salvo levantamiento autorizado.
- Si una validacion independiente confirma una diferencia estable, registra hallazgo y corrige la copia de la tarea y el contrato versionado dentro del alcance.

## QA reutilizable versionado

Para aplicaciones con `zaimella-apex-oracle`, usa esta estructura cuando el QA sea repetible:

```text
APEX/<APP_ID>-<CODIGO_O_NOMBRE_APP>/QA/
|- pages/
|  `- page_<PAGE_ID_4_DIGITS>.py
|- flows/
|  `- <proceso_funcional>.py
|- tests/
|  `- test_<proceso_funcional>.py
|- navigation/
|  |- page_<PAGE_ID_4_DIGITS>.md
|  `- flow_<proceso_funcional>.md
`- data/
   |- <proceso_funcional>.template.json
   `- <proceso_funcional>.cases.json
```

Responsabilidades:

- `pages/`: funciones reutilizables por pagina APEX, selectores estables, acciones de pagina, carga, botones, formularios, mensajes y validaciones locales.
- `flows/`: procesos funcionales que orquestan una o varias paginas; por ejemplo alta, modificacion, eliminacion, aprobacion, carga o consulta con filtros.
- `tests/`: escenarios ejecutables que llaman flows con datos y casos de uso; no deben duplicar selectores si ya existen en `pages/`.
- `navigation/`: contrato humano estable por pagina o flujo; explica ruta, botones, dialogos, precondiciones, resultado esperado y restricciones funcionales.
- `data/`: plantillas y casos de uso parametrizables. Debe incluir casos positivos y negativos: datos validos, campos obligatorios vacios, formatos invalidos, restricciones de negocio, duplicados, permisos, estados no permitidos, limites, combinaciones de LOV y datos para limpieza cuando aplique.

Reglas:

- Organiza la automatizacion por proceso funcional en `flows/` y `tests/`, pero encapsula interacciones por pagina en `pages/`.
- Si un proceso usa varias paginas, el test principal debe vivir por proceso; las paginas solo exponen operaciones reutilizables.
- Si cambia un item, boton, selector, validacion o parametro de una pagina, actualiza el page object y los casos de uso afectados junto con la fuente APEX.
- Si cambia una regla de negocio o restriccion, actualiza `data/*.cases.json` y los escenarios que validan esa restriccion.
- No guardes resultados de ejecucion, screenshots, traces, logs, informes QA, datos reales ni datos temporales concretos en `zaimella-apex-oracle`.

## Estructura recomendada del repositorio fuente

Usa la estructura existente del repositorio si ya esta definida. Para proyectos nuevos o migraciones aprobadas, esta es la forma recomendada:

```text
zaimella-apex-oracle/
|- APEX/
|  `- <APP_ID>-<CODIGO_O_NOMBRE_APP>/
|     |- PAGINAS/
|     |- SHARED_COMPONENTS/
|     |- APPLICATION/
|     |- EXPORTS/
|     `- QA/
|        |- pages/
|        |- flows/
|        |- tests/
|        |- navigation/
|        `- data/
`- ORACLE/
   `- DATA/
      |- TABLAS/
      |- VISTAS/
      |- PAQUETES/
      |  |- SPECS/
      |  `- BODIES/
      |- TRIGGERS/
      |- TYPES/
      |- SEQUENCES/
      |- CONSTRAINTS/
      |- INDEXES/
      |- ORDS/
      |  `- <MODULO>/
      `- MIGRACIONES/
```

Esta estructura es canonica para fuente nueva y para normalizaciones dentro del alcance de una tarea. No mezcles mayusculas/minusculas ni crees carpetas equivalentes. Si una tarea toca un objeto que ya existe con ruta o nombre no canonico, normalizalo al formato obligatorio cuando no haya conflicto; si hay duplicados o dudas sobre la fuente vigente, registra la diferencia y pide decision antes de editar.

## Flujo operativo con repo fuente

1. Lee `desarrollo.md` y confirma proyecto/contexto, repo fuente, aplicaciones, prefijos y objetos de alcance.
2. Usa la identidad, alcance, worktree, rama y commit base entregados por el contexto invocador; no descubras tareas, reservas ni estados por cuenta propia.
3. Asegura que la ruta local del repositorio fuente exista. Si falta, reporta `Impedimento tecnico de fuente no preparada` y continua las actividades que no dependan de ella.
4. Verifica estado Git y remoto del checkout recibido. Si el mismo `PACKAGE`, `PACKAGE BODY`, pagina o archivo esta siendo modificado por otro alcance, reporta `Conflicto tecnico de fuente` al contexto y continua lo independiente; el skill no bloquea ni cambia el estado de la tarea.
5. Localiza en `zaimella-apex-oracle` solo los archivos fuente de la aplicacion y objetos incluidos.
6. Si la aplicacion, pagina u objeto no existe en el repo clonado, aplica el bootstrap de esta referencia: extrae desde APEX/Oracle real cuando ya exista, o crea fuente nueva versionada cuando sea un objeto Oracle nuevo aprobado por el alcance.
7. Si el proyecto esta iniciando y aun no tiene baseline registrado, ejecuta la seccion `Baseline inicial APEX vs Oracle vs GitHub`.
8. Contrasta la fuente con Oracle/APEX real cuando el cambio dependa de base o metadata vigente, o cuando haya indicios de que GitHub no esta alineado con TEST/PRODUCCION.
9. Si GitHub y Oracle/APEX real difieren en el alcance, aplica la seccion `Diferencias entre GitHub y Oracle/APEX real` antes de editar.
10. Edita el codigo fuente versionado dentro de `<WORKTREES_ROOT>/<REPO_SLUG>/<PROJECT_SLUG>/<ID_TAREA>` para los objetos del alcance.
11. Usa `<PROJECT_ROOT>/docs/tareas/<ID_TAREA>/deploy` durante desarrollo. Antes de compilar TEST, integra solo el diff inventariado en la ruta `Repo fuente local` de `desarrollo.md`, conserva cambios previos y crea el commit candidato.
12. Guarda QA, logs, capturas y analisis en `<PROJECT_ROOT>`.
13. Al cerrar, informa archivos fuente modificados, scripts de pase generados, validaciones y objetos que quedaron fuera de alcance.

## Relacion con `docs/sql`

- Si no existe repo fuente empresarial, `docs/sql` puede contener scripts fuente o scripts de trabajo segun el proyecto local.
- Si existe `zaimella-apex-oracle`, `docs/sql` no reemplaza la fuente versionada. Usalo para scripts operativos, extracciones puntuales, comparaciones, soporte del pase o SQL auxiliar del proyecto.
- El pase a produccion sigue armando `docs/deploy` segun `estandares-base-datos.md`, tomando como origen objetos validados en TEST y/o archivos fuente versionados que correspondan al alcance.

## Git

- No hagas commit, push, merge, rebase ni crees PR salvo instruccion explicita del usuario o comandos de cierre/publicacion vigentes.
- El proyecto puede tener varias sesiones o tareas APEX/Oracle abiertas en paralelo si cada una usa worktree, rama y workspace operativo propios. No desarrolles directamente en el checkout principal de integracion.
- La identidad de aislamiento es `PROJECT_SLUG/ID_TAREA`: las ramas `codex/<PROJECT_SLUG>/<ID_TAREA>` son locales y temporales, y sus worktrees quedan bajo `<PROJECT_SLUG>`. Nunca seleccionar una rama o candidato por solo `ID_TAREA`, porque puede repetirse entre proyectos. La publicacion oficial se hace por defecto integrando solo el inventario aprobado en `main` y ejecutando push directo a `origin/main`; no subas la rama de tarea ni abras PR salvo que el usuario lo solicite o GitHub lo exija.
- Antes de editar, compara el alcance recibido contra `desarrollo.md`, `git status`, `git diff --name-only` y staged files del checkout entregado.
- Si existe conflicto real sobre el mismo `APP_ID/PAGE_ID`, objeto Oracle completo, archivo fuente, flujo QA versionado, integracion, dato compartido sensible o dependencia no separable, reporta `Conflicto tecnico de alcance` con evidencia: `APP_ID`, `PAGE_ID`, ruta completa y hunk/objeto compartido. Un número de página igual en otra aplicación o módulo no es conflicto. Un cambio a cualquier rutina de un `PACKAGE BODY` afecta el body completo.
- Si el alcance recibido toca paginas, objetos o archivos distintos y no comparte dependencias riesgosas, continua el trabajo tecnico sin gestionar sesiones ajenas.
- Si existe conflicto real, entrega al contexto la evidencia, elementos afectados y alternativas tecnicas; el contexto decide serializacion, transferencia o autorizacion adicional.
- El skill entrega resultado tecnico, inventario y evidencias de la version trabajada. No declara aprobacion funcional, no coordina validacion independiente, no cambia estados de tarea y no decide cierre o publicacion; el contexto invocador aplica esos gates.
- Antes de hacer commit/push por cierre, revisa `git status`, valida que los cambios pertenezcan a la tarea actual, ejecuta las validaciones aplicables y no incluyas artefactos temporales, credenciales, logs, capturas, evidencias QA ni deploys de trabajo dentro de `zaimella-apex-oracle`.
- Antes de hacer commit/push autorizado, arma un inventario tecnico con paginas APEX, objetos Oracle, archivos fuente esperados, objetos compilados/importados en TEST, version QA recibida y cambios excluidos con motivo. Entrega el inventario al contexto; no actualices contratos ni estados.
- Antes de compilar TEST, integra solo el commit/diff inventariado de la tarea sobre la fuente vigente, compara el archivo completo para detectar perdida de cambios previos y crea el commit candidato. TEST y QA deben registrar ese SHA.
- Integra, compila/importa o altera TEST solo cuando el contexto entregue esa fase como autorizada. El skill no interpreta, adquiere, conserva, transfiere ni libera locks. Si la fase no esta autorizada, reporta `Fase TEST no autorizada` y continua migracion o bootstrap en modo lectura, analisis, extraccion sin mutacion de TEST y cambios aislados; el contexto serializa y reanuda la fase.
- Cuando el contexto autorice la fase TEST y entregue un worktree limpio de integracion, comprueba su estado sin modificar otros checkouts. Integra, crea el candidato y opera TEST desde ese espacio; nunca incluyas cambios ajenos en el candidato ni los elimines al cerrar.
- Despues de recibir evidencia de QA aprobado, el commit publicado y preparado para el pase debe coincidir. Si no coincide, reporta `No conforme por SHA inconsistente` y no ejecutes el pase; el contexto decide la siguiente fase.
- Inmediatamente antes de publicar, ejecutar `scripts/prepare_apex_integration.py` desde el skill activo con `--project-slug <PROJECT_SLUG>`, repo, tarea, commit base, candidato, todas las rutas inventariadas y worktree de integración bajo ese slug. El reporte verifica `APP_ID/PAGE_ID`, rutas y hunks frente a `origin/main`. Con `AUTO_RECONCILE_READY`, repetir con `--apply` para reconstruir un worktree limpio desde el remoto y reaplicar solo el candidato; con `INVENTORY_MISMATCH`, separar cambios ajenos; con `USER_DECISION_REQUIRED`, elevar solo hunks funcionalmente incompatibles y no inferibles. Si cambia el commit candidato o el contenido probado, vuelve a compilar/importar TEST y repite el QA afectado; no publiques un SHA distinto al aprobado.
- Antes de PRODUCCION, verifica que el objeto actual corresponda al predecesor esperado. Despues del pase, compara el objeto final contra la fuente del commit publicado; `VALID` sin correspondencia de contenido no permite cerrar.
- Los respaldos productivos son solo reversa y nunca fuente hacia adelante.
- Compara el inventario tecnico contra `git status`, `git diff --name-only` y los archivos staged. Si falta un archivo u objeto del alcance, existe un cambio sin stage o hay un archivo staged ajeno, reporta `No conforme por inventario Git` y no declares la entrega tecnica completa hasta corregirlo o recibir una decision explicita; no cambies el estado de la tarea.
- No hagas entregas parciales silenciosas. Si el alcance combina paginas APEX con objetos Oracle, el commit debe incluir ambos grupos cuando corresponda. Si una parte queda pendiente o excluida, reporta motivo, riesgo y autorizacion recibida al contexto.
- No uses `git add .` ni agregues carpetas completas como `APEX/`, `ORACLE/`, `PAGINAS/` o `PAQUETES/` cuando existan cambios ajenos, prefijos no relacionados, sesiones paralelas o archivos no inventariados. Agrega rutas concretas del inventario de cierre.
- El commit debe ser descriptivo y limitado al alcance cerrado. Si hay cambios ajenos o pendientes de otra sesion, no los incluyas; informa la separacion y sube solo lo autorizado.
- Despues del commit integrado y autorizado, ejecuta `git push origin main` al remoto oficial y reporta commit, rama, remoto y resultado. No dejes el cierre solamente en una rama remota o PR pendiente.
- El control Git aplica al repositorio `zaimella-apex-oracle`; no asumas que el `proyecto/contexto` tiene remoto, rama o historial Git.
- No mezcles cambios de varias tareas en el mismo commit ni en el mismo inventario de cierre, salvo autorizacion explicita y registrada.
- Antes de responder, distingue cambios propios, cambios previos ajenos y pendientes no tocados.
