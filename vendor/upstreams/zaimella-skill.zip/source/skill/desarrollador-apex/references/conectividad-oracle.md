# Conectividad Oracle

Usa este flujo antes de cualquier analisis o cambio dependiente de Oracle.

## Archivo fuente y bootstrap

- Las credenciales y configuraciones locales no deben guardarse dentro de la carpeta del skill.
- La fuente preferida son variables de entorno `ZAIMELLA_ORACLE_*` y `ZAIMELLA_HANA_*` ya configuradas en la maquina.
- No inventes ni busques variables `ZAIMELLA_ORACLE_TEST_*`: el ambiente test usa el prefijo base `ZAIMELLA_ORACLE_*`; produccion usa `ZAIMELLA_ORACLE_PROD_*`.
- Si se necesita archivo local, usa una ruta externa al skill: `%USERPROFILE%\.zaimella\configurar_oracle_env.cmd` y `%USERPROFILE%\.zaimella\configurar_oracle_env.local.cmd`, o define `ZAIMELLA_ENV_DIR`, `ZAIMELLA_ORACLE_CONFIG_PATH` y `ZAIMELLA_ORACLE_LOCAL_CONFIG_PATH`.
- `. .\scripts\set-oracle-env.ps1 -CreateDefaultIfMissing` carga esas variables en la sesion PowerShell actual y, si no existe archivo local, crea una plantilla externa con placeholders.
- Si el script crea una plantilla, completa credenciales fuera del skill antes de continuar.
- `abrir_codex.cmd` debe iniciar Codex con ese bootstrap ya ejecutado cuando aplique.

## Secuencia obligatoria

1. Ejecutar primero una sola validacion rapida y deterministica:
   - test: `python scripts/validate_oracle_connectivity.py --environment test`
   - produccion: `python scripts/validate_oracle_connectivity.py --environment prod`
2. El script debe cargar automaticamente variables de entorno y archivos locales externos ubicados en `%USERPROFILE%\.zaimella` o en las rutas indicadas por `ZAIMELLA_ENV_DIR`, `ZAIMELLA_ORACLE_CONFIG_PATH` y `ZAIMELLA_ORACLE_LOCAL_CONFIG_PATH`.
3. Si la validacion retorna variables faltantes, ejecutar `. .\scripts\set-oracle-env.ps1 -CreateDefaultIfMissing` una sola vez para cargar o crear plantilla externa.
4. Si la plantilla queda con placeholders, detener el trabajo dependiente de base y reportar exactamente que variable falta; no pedir host, puerto, SID ni usuario cuando ya esten definidos en el estandar.
5. Si la validacion falla por DNS, puerto cerrado, timeout o `CONEXION ERROR` compatible con servicio Oracle caido, detener el trabajo dependiente de Oracle y pedir al usuario restablecer el servicio con DBA antes de continuar.
6. Si Python `oracledb` no esta disponible, no instalar ni reparar dependencias como parte rutinaria de la tarea. Reportar `Preparacion de herramientas Oracle fallida` con el error exacto y pedir autorizacion explicita antes de instalar o cambiar de herramienta.
7. No repetir DNS, puerto y conexion con herramientas distintas si `validate_oracle_connectivity.py` ya entrego un diagnostico claro.

## Scripts oficiales y ruta de ejecucion

- Los scripts `scripts/validate_oracle_connectivity.py`, `scripts/validate_hana_connectivity.py`, `scripts/set-oracle-env.ps1`, `scripts/oracle_sql_tool.py`, `scripts/hana_sql_tool.py`, `scripts/import_apex_sql_via_python.py`, `scripts/apex_export_sql_via_python.py`, `scripts/production_deploy_tool.py` y `scripts/execute_oracle_deploy.py` pertenecen al skill activo.
- Si el proyecto actual no contiene `scripts/<script>`, no concluyas que el validador estandar no existe. Resuelve y ejecuta el script desde la carpeta instalada del skill activo.
- No uses helpers Oracle recientes del proyecto, snippets Python ad hoc, `sqlplus`, SQLcl, pruebas manuales de DNS/puerto ni comandos equivalentes para reemplazar un script oficial disponible.
- Solo cambia de herramienta si el script oficial reporta `Preparacion de herramientas Oracle fallida`, el usuario autoriza el cambio y registras el motivo exacto.
- Los runners oficiales dependientes de Oracle (`oracle_sql_tool.py`, `import_apex_sql_via_python.py`, `apex_export_sql_via_python.py`, `production_deploy_tool.py` y `execute_oracle_deploy.py`) deben cargar automaticamente los archivos externos `configurar_oracle_env.cmd` y `configurar_oracle_env.local.cmd` igual que los validadores. Si falta `ZAIMELLA_ORACLE_PROD_PASSWORD` antes de conectar, primero corrige la carga del entorno del runner oficial; no crees wrappers locales ad hoc ni ejecutes comandos que impriman credenciales.

## Reglas operativas

- el esquema vigente de desarrollo es `DATA`
- `DATA` es un esquema objetivo, no una identidad de inicio de sesión. No exijas ni infieras una credencial `DATA` para PRODUCCIÓN: la conexión usa los parámetros externos `ZAIMELLA_ORACLE_PROD_*` y el `CURRENT_SCHEMA=DATA` que corresponda al script.
- si existen objetos equivalentes en otros esquemas, interpretalos primero como legado o referencia historica
- el orden normal de conectividad es: `scripts/validate_oracle_connectivity.py` -> `scripts/set-oracle-env.ps1` solo si el validador reporta variables faltantes -> repetir el mismo validador una vez
- si la conexion falla por timeout, revisa primero puerto, DNS y acceso de red
- si DNS, puerto o conexion Oracle fallan de forma clara, reporta `Impedimento externo por servicio o red`; no continues solo con el trabajo dependiente de base y no cambies el estado de la tarea
- si el servicio Oracle de test o produccion esta caido, informa al usuario que debe coordinar con DBA el restablecimiento del servicio y reanudar la tarea despues
- no informes falta de conectividad solo porque `sqlplus` no este en `PATH`
- si Python `oracledb` esta disponible, esa via ya es suficiente para abrir sesion nueva y validar Oracle
- no probar `sqlplus`, `sql`, `sqlcl`, DNS, puertos o clientes alternativos despues de un diagnostico claro del validador, salvo que el usuario pida explicitamente ese diagnostico tecnico
- si falta algun cliente, driver o libreria para Oracle o HANA, no lo instales como parte normal de una tarea APEX; registra `Preparacion de herramientas Oracle fallida` y pide autorizacion explicita para instalar o reparar
- si una validacion falla, no cambies de estrategia ni repitas herramientas si el codigo de salida ya indica la causa; solo reintenta una vez despues de cargar configuracion externa con `set-oracle-env.ps1`
- si el hostname falla, registra el error del validador; no hagas pruebas manuales de IP, puerto o DNS salvo que el usuario pida diagnostico de red
- para conexion directa a produccion usa exclusivamente `ZAIMELLA_ORACLE_PROD_USER`, `ZAIMELLA_ORACLE_PROD_HOST`, `ZAIMELLA_ORACLE_PROD_PORT`, `ZAIMELLA_ORACLE_PROD_SID` y `ZAIMELLA_ORACLE_PROD_PASSWORD` desde la configuracion externa; no infieras valores por nombres de usuario, hosts o SID.
- cuando el requerimiento sea de produccion, el agente debe validar con `python scripts/validate_oracle_connectivity.py --environment prod`; no debe pedir al usuario host, puerto, SID ni usuario productivo si esas variables ya existen
- la contrasena productiva debe guardarse como variable de entorno o en archivo local externo al skill, usando `set "ZAIMELLA_ORACLE_PROD_PASSWORD=..."`; no la guardes en el skill, `SKILL.md`, `references/`, `scripts/`, YAML ni archivos de prueba publicables
- Si faltan parámetros productivos, reporta exactamente las variables `ZAIMELLA_ORACLE_PROD_*` ausentes. No redescubras, consultes ni quemes usuarios, contraseñas, hosts, SID o URLs corporativas en el skill; la configuración se completa solo fuera del repositorio, en la fuente externa autorizada.
- las credenciales HANA directas de Peru y Guatemala deben guardarse como variables de entorno o en archivo local externo al skill; no deben publicarse en YAML, `SKILL.md`, `references/` ni `scripts/`
- `scripts/set-oracle-env.ps1` debe cargar primero el archivo base externo y luego sobrescribir o completar valores con el archivo local externo cuando exista, incluyendo variables `ZAIMELLA_ORACLE_*` y `ZAIMELLA_HANA_*`
- si `ZAIMELLA_ORACLE_PROD_PASSWORD` no existe tras cargar variables y archivos externos, reporta las variables faltantes sin declarar la tarea `BLOQUEADA`; pide configurarla una vez fuera del skill y no cambies a `@zaip` para suplir esa falta. Si otra sesión ya conectó, revisa primero que este runner haya cargado esos mismos archivos y rutas externas antes de concluir que falta una credencial.
- si el usuario pide revisar, diagnosticar, auditar o validar algo de produccion, conectate directamente a produccion con la credencial autorizada; no uses `@zaip` como sustituto de la conexion de produccion
- usa `@zaip` solo cuando estes trabajando conectado en test y necesites consultar, traer o validar informacion de produccion desde ese contexto
- si el trabajo requiere pasar datos de test a produccion desde una sesion de test, puedes usar el DB link `@zaip`, que apunta desde test hacia produccion
- si el trabajo requiere pasar objetos de base de datos a produccion, conectate directamente a produccion con la credencial autorizada y ejecuta el script formal en esa conexion; no despliegues DDL ni paquetes por `@zaip`
- si el trabajo requiere diagnosticar un error de produccion, conectate primero a produccion para identificar el error real logueado; despues replica, corrige y valida en test antes del pase
- si una consulta a `@jdedtadl` responde correctamente, tratala como dependencia remota valida del ERP JDE
- si el requerimiento necesita informacion del ERP de una compania, identifica primero la compania y resuelve el DB link correcto desde `DATA`

## Consultas y planes de ejecucion cotidianos

Contexto:
- Consultar metadata, revisar datos no sensibles y obtener planes de ejecucion son tareas normales del desarrollo APEX. No deben disparar varios intentos con herramientas distintas.

Estandar:
- Para lectura SQL usa `python scripts/oracle_sql_tool.py query --environment test --sql "<SELECT...>"`.
- Para produccion usa `--environment prod` solo cuando el flujo autorice diagnostico productivo o validacion post productiva.
- Para archivos SQL de lectura usa `--file ruta.sql` en lugar de copiar bloques largos en la consola.
- El helper solo permite `SELECT` y `WITH`, aplica limite de filas, marca sus sesiones con `MODULE='CODX_ORACLE_SQL_TOOL'`, usa timeout de llamada Oracle y hace `rollback` al cerrar la sesion.
- Para cambiar el limite de filas usa `--max-rows N`; `--limit N` queda aceptado solo como alias compatible.
- Para consultas que puedan tardar o tocar vistas/tablas pesadas, define un `--call-timeout` razonable. No aumentes el timeout para forzar conteos completos en produccion; primero usa filtros, muestras, `EXPLAIN PLAN`, metadata, agregados acotados o una alternativa de validacion menos costosa.
- Para planes usa `python scripts/oracle_sql_tool.py explain --environment test --sql "<SELECT...>"`.
- El `EXPLAIN PLAN` debe usar `statement_id` literal generado por el helper, consultar `DBMS_XPLAN.DISPLAY` y hacer `rollback`; no debe ejecutar el query objetivo ni DML de negocio.
- Si `EXPLAIN PLAN` falla, no cambies a ejecutar el query completo como prueba de rendimiento. Ajusta la sentencia para que sea explicable o reporta el error exacto.
- Si necesitas ejecutar DML, PL/SQL, DDL, import APEX o pase productivo, no uses este helper; aplica los scripts y gates de despliegue correspondientes.

Resultado esperado:
- Un solo intento normal con el helper oficial.
- Si `validate_oracle_connectivity.py` conecto correctamente pero `oracle_sql_tool.py` falla luego por DNS, puerto o timeout, no concluyas de inmediato que Oracle esta caido ni cambies de herramienta. Repite una sola vez el validador oficial del mismo ambiente; si el validador falla, reporta `Impedimento externo por red o servicio` con su error exacto; si vuelve a conectar, reintenta una sola vez el mismo comando del helper y, si vuelve a fallar, reporta `Consulta Oracle fallida con helper oficial` con comando, ambiente, salida y codigo de retorno.
- Si falla por preparacion de herramienta, reporta `Preparacion de herramientas Oracle fallida` con comando y error.
- Si falla por SQL invalido, reporta el error de Oracle y corrige la consulta, no cambies de cliente ni improvises otro helper.

## Consultas HANA directas de lectura

Contexto:
- Peru y Guatemala deben consultarse primero por el puente Oracle `@HANA_PE` o `@HANA_ABX` desde `DATA`.
- La conexion HANA directa es respaldo autorizado cuando el puente no tiene la tabla, columna o dato requerido, cuando el DB link falla, o cuando se necesita evidencia tecnica para crear o ajustar la vista del puente.

Estandar:
- Antes de una consulta HANA directa, valida la conexion con `python scripts/validate_hana_connectivity.py <COMPANIA> --environment <test|prod>` cuando aplique ambiente.
- Para SELECT/WITH HANA directos usa `python scripts/hana_sql_tool.py query <COMPANIA> --environment <test|prod> --sql "<SELECT...>"`.
- Para archivos SQL de lectura usa `--file ruta.sql`.
- Para cambiar el limite de filas usa `--max-rows N`; `--limit N` queda aceptado como alias compatible.
- Si no aplica un ambiente configurado, usa `--schema <ESQUEMA>` con el esquema HANA autorizado.
- El helper solo permite `SELECT` y `WITH`, aplica limite de filas, carga variables externas seguras y no imprime credenciales.
- No reutilices `validate_hana_connectivity.py` como modulo importado ni escribas snippets Python con `hdbcli` para consultas puntuales si `hana_sql_tool.py` esta disponible.
- Si falta `hdbcli`, reporta `Preparacion de herramientas HANA fallida` con el error exacto y pide autorizacion antes de instalar o cambiar de herramienta.

Ejemplos:

```powershell
python scripts/hana_sql_tool.py query 00003 --environment test --sql "SELECT \"Code\", \"Name\" FROM \"OCRY\""
python scripts/hana_sql_tool.py query 00015 --environment prod --sql "SELECT \"Code\", \"Name\" FROM \"OCRY\"" --max-rows 20
```

Resultado esperado:
- Un solo intento normal con el helper oficial despues de validar conectividad HANA.
- Si el SQL falla por tabla, columna o sintaxis, corrige la consulta o reporta el error HANA exacto; no cambies a snippet Python ni a otro cliente.
- Si la consulta directa confirma una brecha del puente, registra tabla, columnas relevantes, esquema validado y resultado resumido sin credenciales.

## Sesiones colgadas y procesos lentos

Contexto:
- Las validaciones, pruebas funcionales o validaciones tecnicas pueden dejar una sesion Oracle colgada cuando el SQL, paquete o proceso APEX no esta bien optimizado.
- Un timeout local de PowerShell, Python, Codex o Playwright no garantiza que Oracle haya cancelado el SQL que ya estaba corriendo en el servidor.

Estandar:
- Toda consulta manual o validacion de lectura debe ejecutarse con `scripts/oracle_sql_tool.py` para que quede identificada con `MODULE/ACTION`. No uses snippets Python ad hoc para conteos, validaciones productivas ni consultas sobre vistas pesadas.
- Antes de ejecutar conteos completos, `COUNT(*)` sobre vistas pesadas, validaciones contra objetos grandes, queries sin filtros selectivos o consultas en PRODUCCION, evalua el costo con filtros, muestra, metadata o `EXPLAIN PLAN`. Si no hay necesidad funcional de conteo completo, no lo ejecutes.
- En PRODUCCION, las validaciones post normales deben ser smoke checks minimos y acotados: objetos `VALID`, apertura/carga inicial, existencia de configuracion, muestras pequenas o filtros por registros del alcance. No ejecutar QA funcional completo ni conteos masivos salvo autorizacion explicita y motivo registrado.
- Si una consulta, validacion, proceso APEX o prueba dependiente de Oracle termina por timeout local, interrupcion, cancelacion, cierre del cliente o supera el tiempo operativo esperado, inmediatamente revisa sesiones activas propias antes de continuar con otras consultas.
- Para revisar sesiones propias usa el helper oficial:

```powershell
python scripts/oracle_sql_tool.py sessions --environment test --active-only
python scripts/oracle_sql_tool.py sessions --environment prod --active-only
python scripts/oracle_sql_tool.py sessions --environment prod --active-only --only-codex
```

- Si `sessions` falla por falta de privilegios sobre `GV$SESSION`, reporta `Impedimento tecnico de privilegios` y solicita apoyo DBA o usa la vista/herramienta corporativa autorizada; no asumas que no hay sesiones pendientes ni cambies el estado de la tarea.
- Si aparece una sesion propia activa asociada a la validacion, identifica `SID`, `SERIAL#`, `MODULE`, `ACTION`, `SQL_ID`, evento y tiempo activo. No lances otra validacion pesada hasta resolverla.
- Si una validacion o prueba dependiente de Oracle supera 10 minutos sin terminar, considera que el proceso no esta bien hecho para el flujo esperado.
- Antes de volver a ejecutar, identifica la sesion real asociada al proceso colgado y revisa el SQL, plan, filtros, joins, indices, commits, volumen de datos y llamadas remotas para aplicar tuning o mejorar el proceso.
- Si la sesion debe detenerse, usa `rdsadmin.rdsadmin_util.kill` con el `SID` y `SERIAL#` reales de esa sesion. Ejemplo operativo:

```sql
begin
  rdsadmin.rdsadmin_util.kill(1335,30072,'IMMEDIATE');
end;
/
```

- No uses los valores `1335,30072` como fijos; son solo el ejemplo de forma. Deben reemplazarse por el `SID` y `SERIAL#` identificados.
- Registra en `docs/tareas/<ID_TAREA>/logs`, `docs/bitacora.md`, informe de QA o `informe_pase.md` segun el caso: comando ejecutado, ambiente, timeout o corte, sesion encontrada, accion tomada, evidencia posterior de `0 sesiones pendientes` o motivo de escalamiento. Reserva `docs/logs` para registros compartidos del contexto, como herramientas o migracion.
- No declares la entrega tecnica completa si queda activa una sesion propia generada por las validaciones. El resultado tecnico correcto es `Impedimento tecnico: sesion Oracle pendiente` o `No aprobado por higiene de sesiones incompleta` hasta cerrar o escalar la sesion; el contexto invocador decide el estado de la tarea.

Razon:
- Un proceso que bloquea una validacion por mas de 10 minutos introduce riesgo operativo y no debe normalizarse como espera aceptable.
- Las sesiones colgadas consumen recursos aunque el agente local ya haya abandonado la prueba; el cierre funcional debe incluir higiene operativa de base de datos.

Ejemplo:
- Si un guardado APEX queda procesando mas de 10 minutos durante QA, identifica la sesion Oracle del proceso, ejecuta el kill con sus valores reales, documenta el corte y ajusta el paquete o consulta antes de repetir la prueba.
- Si `COUNT(*)` sobre `DATA.VT_INTC_PORTAFOLIO` en PRODUCCION supera el timeout local, no sigas con otra consulta. Ejecuta `oracle_sql_tool.py sessions --environment prod --active-only --only-codex`, identifica la sesion del conteo, coordina kill si sigue activa y registra evidencia de que no quedaron sesiones pendientes.

## Mapa ERP por compania

- Ecuador:
  - ERP: JDE
  - DB link: `@jdedtadl`
  - compania: `00001`
- Peru:
  - ERP: SAP
  - DB link: `@HANA_PE`
  - compania: `00003`
- Guatemala:
  - ERP: SAP
  - DB link: `@HANA_ABX`
  - compania: `00015`

## Regla de decision

- si el requerimiento menciona una compania especifica, usa ese dato para elegir el ERP remoto
- si el requerimiento solo menciona el codigo de compania, resuelvelo con el mapa anterior
- si el requerimiento pide informacion ERP y no se puede identificar la compania, el agente debe pedir esa precision antes de asumir un DB link
- cuando la consulta se origine en `DATA`, sigue este orden:
  - diccionario de datos de la compania
  - acceso ERP disponible desde `DATA`
  - fuente original del ERP cuando falte el objeto o falle el DB link
- Ecuador usa acceso directo JDE por `@jdedtadl`
- Peru y Guatemala usan puente por `@HANA_PE` o `@HANA_ABX` y conexion HANA directa como respaldo autorizado
- Para HANA directa de Peru, usa variables locales `ZAIMELLA_HANA_PE_HOST`, `ZAIMELLA_HANA_PE_PORT`, `ZAIMELLA_HANA_PE_USER` y `ZAIMELLA_HANA_PE_PASSWORD`.
- Para HANA directa de Guatemala, usa variables locales `ZAIMELLA_HANA_ABX_HOST`, `ZAIMELLA_HANA_ABX_PORT`, `ZAIMELLA_HANA_ABX_USER` y `ZAIMELLA_HANA_ABX_PASSWORD`.
- Si esas variables existen en el entorno o en el archivo local externo, el agente debe usarlas sin pedir credenciales al usuario.
- Para validar HANA Peru directo, usa `python scripts/validate_hana_connectivity.py 00003 --environment test` o `python scripts/validate_hana_connectivity.py 00003 --environment prod`; esta validacion debe abrir conexion directa y consultar `OCRD` en el esquema configurado.
- Para validar HANA Guatemala directo, usa `python scripts/validate_hana_connectivity.py 00015 --environment prod`; Guatemala solo tiene HANA produccion y usa el esquema productivo configurado en `./erp-config/00015-guatemala.yaml`. No asumas ambiente test para Guatemala.
- la validacion directa en HANA para Peru y Guatemala debe servir para definir o ajustar vistas nuevas del puente cuando el objeto requerido no exista por DB link

## Validacion en puente SAP

Para Peru y Guatemala, la validacion inicial debe intentarse en el puente. Ejemplo:

```sql
SELECT
    C."DocEntry",
    C."CardCode",
    C."U_AGRUPACION",
    C."CardName",
    C."City",
    C."U_CANAL",
    C."Country",
    C."validFor",
    C."LicTradNum",
    C."SlpCode",
    O."SlpName"
FROM
    OCRD@HANA_ABX C
LEFT JOIN
    OSLP@HANA_ABX O ON C."SlpCode" = O."SlpCode"
WHERE C."CardType" = 'C'
```

Si la tabla o la columna requerida no existe en el puente, la siguiente validacion debe hacerse contra la conexion HANA de la compania.
Esa validacion debe servir como evidencia tecnica para crear o ajustar la vista correspondiente en el puente.
Si el DB link falla, la misma validacion directa debe usarse como respaldo para confirmar estructura y datos en la fuente original.

## Archivos de configuracion por compania

- `./erp-config/00001-ecuador.yaml`
- `./erp-config/00003-peru.yaml`
- `./erp-config/00015-guatemala.yaml`

## Ejemplos de conexion por empresa

- Ecuador:
  - desde `DATA`, consulta directo JDE por `@jdedtadl`
  - ejemplo:

```sql
SELECT *
FROM F0101@jdedtadl
FETCH FIRST 5 ROWS ONLY
```

- Peru:
  - primero consulta el puente por `@HANA_PE`
  - si no resuelve, consulta HANA directa usando host, puerto, esquema y credenciales del archivo de configuracion autorizado del equipo
  - HANA test usa el esquema `SBO_ZM_PE_TEST3`
  - HANA produccion usa el esquema `SBO_ZM_PE_PROD`

```sql
SELECT TOP 5 C."CardCode", C."CardName"
FROM OCRD@HANA_PE C
WHERE C."CardType" = 'C'
```

- Guatemala:
  - primero consulta el puente por `@HANA_ABX`
  - si no resuelve, consulta HANA directa usando host, puerto, esquema y credenciales del archivo de configuracion autorizado del equipo
  - HANA Guatemala solo tiene produccion; no usar ni inventar esquema test

```sql
SELECT TOP 5 C."CardCode", C."CardName"
FROM OCRD@HANA_ABX C
WHERE C."CardType" = 'C'
```

## Diccionario interno ERP

- `./erp-diccionario-interno.md`
- `./erp-diccionario/00001-ecuador.md`
- `./erp-diccionario/00003-peru.md`
- `./erp-diccionario/00015-guatemala.md`
- estos archivos registran tablas, vistas, campos y objetos internos creados sobre ERP por Zaimella
- el orden de consulta es: diccionario por compania -> fuente oficial o metadata del ERP origen

## Archivos base esperados

- `desarrollo.md` cuando el proyecto APEX lo use como documento operativo.
- Archivo local externo de conectividad solo cuando las variables de entorno no esten disponibles.

## Resultado esperado

Antes de continuar debes poder informar:
- SID actual
- ambiente interpretado
- usuario conectado
- base conectada
- motor detectado o banner de Oracle

Si no hay acceso real, deten el trabajo dependiente de base y reportalo.
Si el diagnostico apunta a servicio Oracle caido, indica explicitamente: ambiente afectado, host, puerto, SID, codigo o mensaje de error y que se requiere restablecimiento por DBA antes de continuar.
