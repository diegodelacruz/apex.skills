# Estandares de Accesos y Permisos en Oracle APEX

## Objetivo
Definir las reglas base para interpretar y aplicar accesos, permisos y visibilidad en aplicaciones Oracle APEX de Zaimella.

- `Contexto:` En Zaimella, los permisos y accesos APEX no solo controlan entrada a una aplicacion o pagina; tambien se usan para decidir que elementos se muestran al usuario cuando inicia sesion.
- `Estandar:` Un permiso o acceso puede utilizarse para habilitar o restringir la visualizacion de una aplicacion en el menu APEX al momento del login.
- `Razon:` El menu debe reflejar unicamente las opciones que el usuario tiene autorizadas, evitando mostrar accesos sin uso o sin permiso real.
- `Ejemplo:` si un usuario tiene acceso al modulo Legal, la opcion correspondiente debe dibujarse en el menu; si no lo tiene, no debe mostrarse.

- `Contexto:` En una misma aplicacion APEX, distintos componentes pueden requerir permisos diferentes aunque el usuario ya haya entrado a la pagina.
- `Estandar:` Los permisos o accesos tambien se usan para controlar visibilidad o disponibilidad de paginas, botones, regiones, acciones y secciones especificas.
- `Razon:` No todo usuario con acceso a una pagina debe necesariamente poder ver todas las acciones o secciones funcionales.
- `Ejemplo:` un boton de aprobar, una accion de guardar, una region de costos o una seccion administrativa pueden mostrarse solo a usuarios autorizados.

- `Contexto:` La seguridad funcional puede bajar a nivel mas fino que la pagina completa.
- `Estandar:` Cuando se requiera control granular, se debe evaluar el permiso sobre el componente especifico en lugar de resolver todo con ocultamiento general de pagina.
- `Razon:` Esto permite reutilizar una misma pagina para distintos perfiles sin duplicar flujos innecesariamente.
- `Ejemplo:` en una pagina de contratos, un usuario puede consultar informacion general pero no ver el boton de eliminar ni la region de parametros sensibles.

- `Contexto:` No toda pagina de una aplicacion debe mostrarse en el menu principal; muchas paginas existen solo como soporte de un flujo.
- `Estandar:` Toda pagina nueva debe clasificarse explicitamente como pagina de menu, pagina operativa fuera de menu o pagina auxiliar de dialogo/soporte antes de definir accesos.
- `Razon:` Esta clasificacion evita parametrizaciones innecesarias en menu y permite aplicar seguridad acorde al rol real de la pagina.
- `Ejemplo:` una pagina de mantenimiento principal puede ir al menu, una pagina de aprobacion puede vivir fuera de menu y un dialogo `Dlg` no debe registrarse como opcion navegable principal.

- `Contexto:` En aplicaciones con seguridad funcional por base de datos, una pagina fuera de menu puede seguir requiriendo permiso de uso.
- `Estandar:` Aunque una pagina no vaya al menu, el agente debe validar si necesita registro de acceso funcional para navegacion interna, botones, branches o llamadas directas por URL.
- `Razon:` Evita que una pagina quede tecnicamente creada en APEX pero inaccesible o expuesta sin control por rutas internas.
- `Ejemplo:` una pagina de detalle abierta desde un reporte puede no dibujarse en menu, pero puede requerir permiso para que solo ciertos perfiles puedan entrar o ejecutar acciones.

- `Contexto:` Los permisos de visibilidad deben responder a una regla de negocio identificable y no a ocultamientos improvisados.
- `Estandar:` Toda regla de acceso aplicada a menu, pagina o componente debe tener una base funcional clara y trazable.
- `Razon:` Facilita mantenimiento, auditoria y depuracion cuando un usuario reporta que no ve una opcion o no puede ejecutar una accion.
- `Ejemplo:` si una accion no aparece, el analisis debe revisar primero el permiso o acceso asociado antes de asumir error de interfaz.

- `Contexto:` La seguridad general debe evaluarse de afuera hacia adentro para no mezclar visibilidad con autorizacion de negocio.
- `Estandar:` El orden de decision para accesos generales es: menu de aplicacion, acceso a pagina, acceso a accion o componente, y finalmente validacion de negocio en paquete cuando la operacion modifica datos o ejecuta un proceso sensible.
- `Razon:` Este orden separa navegacion, experiencia de usuario y control transaccional, y evita confiar solo en ocultamiento visual.
- `Ejemplo:` un usuario puede ver la pagina y el reporte, pero el boton `Eliminar` solo debe mostrarse al perfil autorizado y la eliminacion ademas debe validarse en el paquete del modulo.

- `Contexto:` Cuando se crea una pagina nueva en una aplicacion que usa el modelo corporativo de accesos, primero debe definirse si la pagina formara parte del menu visible para el usuario.
- `Estandar:` El agente debe preguntar explicitamente al desarrollador si la pagina nueva va a ir al menu de la aplicacion.
- `Razon:` Esa respuesta determina si la pagina solo existira como componente APEX o si tambien debe parametrizarse en el modelo de acceso y navegacion.
- `Ejemplo:` una pagina auxiliar de dialogo puede no ir al menu, mientras que una pagina operativa principal si debe registrarse como opcion navegable.

- `Contexto:` En aplicaciones con control de acceso por base de datos, crear la pagina en APEX no es suficiente para que aparezca en el menu o pueda usarse.
- `Estandar:` Si el desarrollador confirma que la pagina nueva va al menu, el agente debe registrar tambien la pagina en la base de datos relacionada con la aplicacion y su modelo de accesos.
- `Razon:` El menu, la navegacion y los permisos dependen de la parametrizacion en tablas del modulo o aplicacion, no solo de la definicion APEX.
- `Ejemplo:` en aplicaciones que siguen el modelo de la app 111, la pagina debe quedar asociada al modulo y a su estructura de paginas para que pueda resolverse en el menu y en la seguridad funcional.

- `Contexto:` Cuando la pagina no va al menu, aun asi pueden existir acciones sensibles dentro de esa pagina.
- `Estandar:` Si la pagina no va al menu, el agente debe evaluar y documentar si el control se resolvera por permiso de pagina, por permisos de componente o por validacion de negocio en paquete; no debe dejar la decision implicita.
- `Razon:` La ausencia de menu no elimina la necesidad de controlar acceso ni reemplaza la validacion funcional del proceso.
- `Ejemplo:` una pagina de aprobacion abierta desde una bandeja puede no ir al menu, pero requiere controles explicitos para `APRUEBA`, `RECHAZA`, descarga de archivos o visualizacion de secciones sensibles.

- `Contexto:` Despues de crear una pagina nueva de menu, el desarrollador necesita probarla con un usuario que realmente la vea y pueda usarla.
- `Estandar:` Si la pagina nueva va al menu, el agente debe dar acceso a esa pagina al rol administrador de la aplicacion y asignar al usuario solicitante el rol administrador dentro de la aplicacion para pruebas.
- `Razon:` Esto garantiza una prueba funcional completa del alta de pagina, incluyendo visibilidad en menu y capacidad de ejecutar acciones sobre la pagina.
- `Ejemplo:` al crear una pagina nueva de mantenimiento, primero se registra en el modelo de accesos, luego se otorga al rol administrador y finalmente se asocia ese rol al usuario que la va a validar.

- `Contexto:` La seguridad por componente no debe replicar logica de negocio que ya existe o debe existir en base de datos.
- `Estandar:` Ocultar o deshabilitar botones, regiones o acciones en APEX mejora la experiencia y reduce errores de uso, pero nunca reemplaza las validaciones y autorizaciones que correspondan en paquetes de base de datos.
- `Razon:` Un usuario puede llegar a una operacion por URL, manipulacion del front o ejecucion indirecta; por eso el backend debe seguir protegiendo la transaccion.
- `Ejemplo:` aunque el boton `Guardar` solo se muestre a un rol especifico, el procedimiento de guardado debe validar tambien el contexto funcional antes de aplicar cambios.

- `Contexto:` Cuando el usuario indique que un objeto o proceso "debe aprobarse", el alcance real no es solo mostrar un boton de aprobar.
- `Estandar:` El agente debe interpretar ese pedido como la necesidad de implementar o revisar el circuito completo de aprobacion corporativa.
- `Razon:` Un flujo de aprobacion funcional en Zaimella requiere mas que una accion aislada; necesita integracion con ruta, comentarios, aprobacion, rechazo y configuracion de aprobadores.
- `Ejemplo:` si una inversion, contrato, solicitud o cualquier objeto "debe aprobarse", el agente debe revisar o contemplar como minimo envio a ruta, visualizacion de ruta, comentarios del objeto, aprobacion, rechazo y configuracion de rutas.

- `Contexto:` En Zaimella, la logica de negocio del flujo de aprobacion esta separada de la logica funcional del objeto, pero ambas deben operar juntas.
- `Estandar:` El agente no debe implementar aprobaciones como logica aislada del objeto; debe integrarlas con el patron corporativo de flujo.
- `Razon:` La aprobacion se apoya en componentes compartidos y configuracion comun, mientras que el objeto mantiene su logica propia de negocio.
- `Ejemplo:` el objeto puede guardar o actualizar sus datos con su propio paquete del modulo, pero el envio, aprobacion y rechazo deben usar el circuito corporativo de flujo.

- `Contexto:` El flujo corporativo de aprobacion reutiliza componentes ya existentes.
- `Estandar:` Salvo justificacion explicita, el agente debe usar el patron corporativo reutilizable ya definido para ruta, comentarios y aprobacion.
- `Razon:` Mantener un solo circuito corporativo evita implementaciones parciales o distintas entre modulos para una misma necesidad de aprobacion.
- `Ejemplo:` envio a ruta desde la pagina funcional del objeto, visualizacion de ruta en `100/104`, comentarios del objeto en `100/105`, comentario de aprobar o rechazar en `100/107`, y configuracion de rutas en `111/500` y `111/501`.

- `Contexto:` La configuracion de rutas forma parte obligatoria del alcance cuando se habilita aprobacion para un objeto.
- `Estandar:` Si un objeto nuevo o un proceso nuevo debe aprobarse, el agente debe contemplar tambien la configuracion necesaria en el modelo de rutas y aprobadores.
- `Razon:` Sin ruta configurada, el boton de enviar o aprobar no resuelve el flujo real de negocio.
- `Ejemplo:` no basta con crear `ENVIAR_RUTA`, `APRUEBA` o `RECHAZA`; tambien debe existir la ruta parametrizada para el modulo, compania y criterios aplicables.

## Referencia tecnica

### Diagnostico rapido de ruta y acceso

Antes de una prueba visual cuyo destino no sea visible, ejecutar una sola vez el diagnostico de lectura para ambos ambientes:

```powershell
python scripts/diagnose_apex_navigation_access.py --module-code <MODULO> --page-code <CODIGO_PAGINA> --qa-user <USUARIO_QA> --company <COMPANIA> --output summary
```

El helper consulta TEST y PRODUCCION sin escribir y devuelve una unica decision: `TEST_READY` (navegar y probar), `RECONCILE_TEST_FROM_PROD` (generar/revisar/versionar el `MERGE` y aplicarlo solo en TEST para el rol existente, incluyendo la asignacion del usuario QA si falta) o `USER_DECISION_REQUIRED` (solo entonces solicitar autorizacion para crear o ampliar jerarquia/seguridad). Usar `--route <PAGE_ID>` cuando todavia no se conoce el codigo de pagina. No abrir Browser para descubrir la jerarquia ni usar PRODUCCION para realizar cambios.

Para crear o actualizar una página de menú y sus accesos en el modelo corporativo, usar `scripts/apex_menu_access_tool.py`. El helper prepara un `MERGE` idempotente para `DATA.T_ADMI_MODULOPAGINA`, acceso de rol y usuario de prueba; se versiona primero en el deploy de la tarea y solo se aplica a TEST con autorización del alcance. Antes de invocarlo, confirmar código de módulo/página, ruta, jerarquía, rol, compañía y permisos de acción; no analizar ni construir DML directo de estas tablas en cada tarea.

No crear roles nuevos para habilitar una página, menú o acción. Consultar primero los roles activos existentes, comparar su descripción y accesos con el perfil funcional solicitado y asignar el rol existente más adecuado; registrar el rol elegido y el motivo en el contrato de tarea. Si ningún rol existente corresponde, bloquear y solicitar decisión de seguridad, sin crear un rol por conveniencia. Para cada combinación de `ID_ROL` e `ID_MODULOPAGINA` debe existir exactamente un registro base con `CODIGOACCION` nulo: representa el acceso a la página y contiene los seis permisos generales. Cada permiso específico de botón, región o acción usa un registro adicional para la misma página y rol, con `CODIGOACCION` no nulo; puede haber varios, pero no puede existir un segundo acceso base. La página evalúa cada permiso específico con `DATA.PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES`. `CODIGO_TG` es metadato técnico opcional y la función vigente no lo evalúa, por lo que no debe usarse como único control. En todo acceso nuevo, `AGREGAR`, `GUARDAR`, `ELIMINAR`, `COMENTAR`, `IMPRIMIR` y `CANCELAR` son obligatorios y deben ser explícitamente `0` o `1`; nunca nulos. Los registros históricos incompletos no son una plantilla válida: usar como referencia una página equivalente con acceso completo del mismo módulo o perfil.

Para analisis, implementacion o validacion del patron corporativo de aprobacion, usar:
- [`references/manual-flujo-aprobacion.md`](./manual-flujo-aprobacion.md)
