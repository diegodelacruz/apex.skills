# ORDS Y OAuth

## Objetivo

Publicar y mantener APIs ORDS de Zaimella sin habilitar para REST a la cuenta tecnica productiva, sin borrar modulos durante mantenimiento ordinario y sin recrear clientes OAuth por release, desarrollador o sesion.

La version corporativa comprobada en TEST y PRODUCCION es ORDS `23.1.3.r1371032`. En esta version se usa el paquete `OAUTH`; `ORDS_SECURITY` se evaluara solo despues de una migracion confirmada de ORDS.

## Contrato Por API

Antes de editar, registrar en `tarea.md`:

- esquema propietario, modulo, base path, templates, handlers y privilegio;
- sistema consumidor y cliente OAuth contractual de TEST y PRODUCCION;
- URLs de token y API por ambiente, obtenidas de configuracion externa;
- package publicador `AUTHID DEFINER`, artefacto `DEPLOY.sql`, commit y SHA-256;
- custodio del secreto y ubicacion logica en el gestor corporativo, nunca el secreto;
- estrategia de reversa y pruebas HTTP anonima/autenticada.

Una identidad OAuth representa un sistema consumidor en un ambiente. No representa una version ni una persona. Usa clientes distintos cuando los consumidores necesiten revocacion o permisos independientes; conserva el mismo cliente durante releases y mantenimiento.

## Fuente Y Ejecucion

- Versionar cada modulo bajo `ORACLE/<OWNER>/ORDS/<MODULO>/` y los paquetes bajo la arquitectura Oracle canonica.
- Definir modulo, templates, handlers y privilegio mediante operaciones idempotentes. `ORDS.DELETE_MODULE` esta prohibido en mantenimiento ordinario porque puede abrir una ventana 404 y eliminar metadata no declarada; solo se permite en reemplazo total o prueba de recuperacion expresamente autorizados, con inventario y reversa.
- No incluir URLs de ambiente, tokens, `client_id` ni secretos en SQL, Git, contratos, bitacoras o logs.
- OAuth debe usar HTTPS. Un endpoint corporativo legado HTTP solo se admite dentro de red controlada, con excepcion/riesgo documentado y `--allow-insecure-http`; nunca exponerlo a Internet ni tratar HTTP como estado objetivo.
- Ejecutar `python scripts/validate_ords_deploy.py <RUTAS_SQL>` y exigir `ORDS_STATIC_AUDIT_PASS` antes de TEST.
- Ejecutar DDL/PLSQL solo con `execute_oracle_deploy.py`, checkout limpio, commit candidato y SHA-256. El mismo commit debe superar TEST y publicarse en `origin/main` antes de PRODUCCION.

## Owner DATA Desde Cuenta Tecnica

`DATA` es el owner, no una credencial productiva. El mecanismo principal es:

1. Versionar bajo `DATA` un package publicador con `AUTHID DEFINER`.
2. Compilarlo con la cuenta tecnica autorizada usando `CURRENT_SCHEMA=DATA` y privilegios corporativos de DDL.
3. Invocar el package sincronicamente y validar su resultado en la misma ejecucion.

No habilitar para REST a `JBALCAZAR` ni otra cuenta tecnica para resolver un deploy. Un job bajo `DATA` es contingencia, no camino normal: usarlo solo si la ejecucion sincrona resulta tecnicamente imposible y el contrato documenta owner, evidencia, polling, timeout, limpieza y error final.

## Provision Y Custodia OAuth

El cliente se crea una sola vez por ambiente con `OAUTH.IMPORT_CLIENT`, credenciales conocidas por el custodio y binds Oracle. Antes de importar, consultar `USER_ORDS_CLIENTS` por el nombre contractual:

- ausente: crear y asociar el privilegio;
- presente con el mismo `client_id`: reutilizar;
- presente con otro `client_id`: detenerse; nunca sobrescribir, recrear ni rotar automaticamente.

Para ORDS 23.1, `client_id` y `client_secret` tienen maximo 32 caracteres. El helper genera 32 caracteres hexadecimales (128 bits) y exige `support_email`, requerido por la instalacion corporativa.

La fuente de custodia preferida es un gestor corporativo de secretos con control de acceso, auditoria y respaldo. En Windows, `ords_oauth_tool.py` mantiene una copia/cache local cifrada con DPAPI, ligada al usuario; no es un respaldo portable ni sustituye el vault. Ruta por defecto:

```text
%USERPROFILE%/.zaimella/ords-oauth/<test|prod>/<CLIENT_NAME>.dpapi
```

Para recuperar el mismo cliente en otra estacion, usar primero el vault y crear la cache local con `--client-id-env <NOMBRE>` y `--client-secret-env <NOMBRE>`.

ORDS 23.1 conserva el secreto actual en `USER_ORDS_CLIENTS` del esquema owner. Esto permite una recuperacion de emergencia desde Oracle, pero la cuenta tecnica no consulta esa vista directamente: cada API declara en su package `AUTHID DEFINER` un procedimiento `RECUPERAR_OAUTH` limitado al cliente contractual de esa API. El helper recibe ambos valores exclusivamente por binds, los cifra de inmediato en DPAPI y solo imprime fingerprints.

```powershell
python scripts/ords_oauth_tool.py recover-from-oracle --environment test --client-name <CLIENTE> --token-url <TOKEN_URL_TEST> --base-url <API_BASE_TEST> --support-email <CORREO_OPERATIVO> --package DATA.<PACKAGE_PUBLICADOR> --confirm-recovery
```

La recuperacion falla si ya existe una cache local, para impedir sobrescrituras o rotaciones accidentales. En PRODUCCION requiere tambien `--confirm-production`. Solo las cuentas tecnicas/custodios autorizados pueden ejecutar el package; `MODULE` y `CLIENT_IDENTIFIER` de la sesion identifican la accion sin registrar el secreto.

Ejemplo de provision o reutilizacion:

```powershell
python scripts/ords_oauth_tool.py provision --environment test --client-name <CLIENTE> --token-url <TOKEN_URL_TEST> --base-url <API_BASE_TEST> --support-email <CORREO_OPERATIVO> --package DATA.<PACKAGE_PUBLICADOR>
```

En PRODUCCION agregar `--confirm-production`. No pasar secretos como argumentos de linea de comandos.

Si el ambiente legado aun usa HTTP, agregar `--allow-insecure-http` a cada comando y registrar el riesgo y el plan de migracion TLS en el contrato.

## Gate TEST

Para el candidato final y despues de cualquier correccion:

1. Auditor ORDS y validadores Oracle aplicables en `PASS`.
2. Package spec/body `VALID` y `ALL_ERRORS=0`.
3. Primera provision `CREATED` o cliente previo conforme; segunda provision `REUSED` y fingerprints iguales.
4. Validacion de metadata del modulo, handler, privilegio, cliente y asociacion.
5. Solicitud anonima `401` o `403`; token `client_credentials` emitido; solicitud autenticada `200` y respuesta/version esperada.
6. Prueba de mantenimiento con una nueva version usando el mismo cliente. Un borrado/recuperacion solo si la tarea lo autoriza.

Comandos de validacion:

```powershell
python scripts/ords_oauth_tool.py validate-db <ARGUMENTOS_COMUNES> --package DATA.<PACKAGE_PUBLICADOR>
python scripts/ords_oauth_tool.py smoke <ARGUMENTOS_COMUNES> --expected-version <VERSION>
```

QA ORDS es tecnica cuando no existe interfaz visible: valida contratos Oracle/HTTP y no requiere Browser ni capturas APEX. Si la API alimenta un flujo visible, se agrega la QA funcional de ese consumidor.

## Pase Y Validacion PRODUCCION

- Exigir autorizacion productiva, QA TEST aprobada para el mismo commit, `origin/main` exacto y backup o constatacion de ausencia.
- Ejecutar el mismo `DEPLOY.sql` y SHA-256; no regenerar SQL en PRODUCCION.
- Provisionar solo si el cliente contractual esta ausente. En mantenimiento normal el resultado debe ser `REUSED`.
- Repetir metadata, objeto `VALID`, errores `0`, anonimo denegado, token emitido, HTTP autenticado `200`, version esperada y sesiones propias `0`.
- Registrar fingerprints, nunca credenciales ni tokens.

## Rotacion Y Recuperacion

La rotacion es un cambio coordinado independiente, no parte de un release ordinario. Requiere inventario de consumidores, ventana o estrategia de doble cliente, actualizacion de cada consumidor, prueba, revocacion del anterior y reversa. Nunca borrar primero el unico cliente vigente.

Si se pierde la cache DPAPI, recuperar primero las mismas credenciales del vault. Si el vault tambien se perdio pero el cliente ORDS sigue activo, ejecutar la recuperacion desde Oracle por el package contractual y registrar el evento sin secretos. Si Oracle ya no contiene el secreto recuperable, tratarlo como incidente y ejecutar rotacion coordinada. No intentar crear otro OAuth silenciosamente.

## Evidencia Del Laboratorio

El patron fue comprobado el 2026-08-12 con `ZAIMELLA_ORDS_LAB`:

- TEST 1.0.0 y mantenimiento 1.1.0 reutilizaron el mismo OAuth;
- un borrado controlado del modulo en TEST conservo el cliente y la fuente versionada recupero el servicio;
- PRODUCCION publico el commit `556de0155444ba91856e589d0529b5759b974089` y respondio anonimo `401`, autenticado `200`, version `1.1.0`;
- la reprovision productiva devolvio `REUSED`.
- el transporte corporativo observado fue HTTP legado; el helper ahora lo bloquea por defecto y exige excepcion explicita hasta migrar a HTTPS.
- el 2026-08-12, TEST y PRODUCCION recuperaron una cache perdida desde `DATA.PK_LAB_ORDS.RECUPERAR_OAUTH`, verificaron fingerprints identicos y ejecutaron token/HTTP 200 sin exponer credenciales. El pase productivo uso el commit `3c0f2211c6790b0912dafe65e2bdb0f77943ec65`.

Los nombres y SHA anteriores son evidencia historica, no valores por defecto para otras APIs.
