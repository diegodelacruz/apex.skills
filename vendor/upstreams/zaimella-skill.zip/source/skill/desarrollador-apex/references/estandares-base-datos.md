# Estandares de Base de Datos Zaimella

## Objetivo
Definir los estandares vigentes para diseno, construccion y mantenimiento de objetos Oracle en Zaimella. Este archivo reemplaza al uso operativo del documento antiguo y debe conservar solo reglas aceptadas.

## Principios generales
- Priorizar claridad, consistencia y mantenibilidad.
- Usar nombres descriptivos para objetos y columnas.
- Todos los nombres de tablas, columnas, vistas, paquetes, restricciones y demas objetos deben estar en espanol.
- Reutilizar estandares corporativos antes de crear variantes nuevas.
- Evitar reglas heredadas que dependan de limitaciones tecnicas antiguas.
- Para la creacion o modificacion estructural de tablas, mantener el modelo actualizado en SQL Developer Data Modeler o en la herramienta de modelado oficial definida por el equipo.
- En este contexto Zaimella, los objetos de base de datos del desarrollo Oracle APEX deben crearse y modificarse en el esquema `DATA`, salvo excepcion autorizada.

## Nomenclatura de objetos
- Tablas: `T_<MODULO>_<NOMBRE>`
- Vistas: `VT_<MODULO>_<NOMBRE>`
- Paquetes: `PK_<MODULO>_<NOMBRE>`
- Secuencias: `SQ_<MODULO>_<NOMBRE>`
- Triggers: `TG_<MODULO>_<NOMBRE>`
- Jobs: `<MODULO>_<NOMBRE>`
- `MODULO` debe representar el codigo funcional del sistema, modulo o aplicacion y no el `APP_ID` numerico de Oracle APEX.
- Queda prohibido usar el `APP_ID` de APEX como prefijo de tablas, vistas, paquetes, secuencias, triggers, jobs o cualquier otro objeto de base de datos nuevo.
- Si una aplicacion APEX tiene codigo funcional `ECMM`, los objetos deben nombrarse con `ECMM` aunque el `APP_ID` tecnico sea `210`.
- Queda prohibido crear objetos permanentes con sufijos numericos, fechas, marcas de intento o referencias opacas que no expliquen el concepto funcional, como `STG2`, `_2`, `_20260501`, `_NUEVA`, `_TEMP`, `_PRUEBA` o nombres similares.
- Si un objeto existente no puede modificarse porque esta ocupado, bloqueado o en uso, no se debe crear una tabla alternativa permanente con numero o fecha para esquivar el bloqueo. Primero se debe identificar la sesion, proceso o dependencia que bloquea; coordinar ventana, detener la sesion colgada si aplica segun `conectividad-oracle.md`, o ajustar el plan de despliegue.
- Solo se permiten objetos auxiliares temporales cuando sean indispensables, esten documentados en el script, tengan nombre funcional comprensible, no sean consumidos por APEX como modelo final y se eliminen o migren dentro del mismo pase.

## Nomenclatura de restricciones e indices
- Primary key: `<TABLA>_PK`
- Foreign key: `<TABLA>_FK1`
- Unique key: `<TABLA>_UK1`
- Check: `<TABLA>_CK1`
- Indice: `<TABLA>_IX1`

## Tablas
- Toda tabla debe tener primary key.
- El nombre de la tabla debe incluir el codigo del modulo.
- El nombre de la tabla debe representar una entidad, proceso o staging funcional estable; no debe ser una copia numerada, fechada o ambigua de otra tabla.
- Toda tabla debe definir nulabilidad, tipos de datos y comentarios cuando aplique.
- Toda tabla debe tener un comentario obligatorio que describa en lenguaje funcional y claro el concepto de negocio que representa, evitando tecnicismos innecesarios.
- El comentario de la tabla debe permitir que una persona no tecnica entienda que informacion guarda, para que se usa y, si aplica, con que proceso del negocio se relaciona.
- En desarrollos multicompania, toda tabla principal y toda tabla de hechos del esquema `DATA` debe incluir obligatoriamente la columna `COMPANIA`.
- Toda tabla maestra o parametrica debe incluir obligatoriamente la columna `COMPANIA`.
- Si se crea o modifica una tabla funcional usada por APEX en este contexto, se debe evaluar e incorporar `COMPANIA` como columna obligatoria cuando la informacion pertenezca a una compania.
- El orden sugerido de columnas es:
  - primary key
  - foreign keys
  - `COMPANIA` cuando aplique al contexto funcional
  - columnas obligatorias de negocio
  - columnas opcionales
  - columnas de auditoria

## Columnas
- Usar nombres descriptivos y consistentes.
- Toda columna debe tener un comentario obligatorio que describa su significado funcional con palabras simples, especialmente cuando represente reglas, estados, codigos o relaciones.
- El comentario de una columna debe explicar que dato guarda y como lo interpreta el negocio; no debe limitarse a repetir el nombre tecnico de la columna.
- Si una columna comienza con `ID` y se relaciona con otra tabla, el comentario debe indicar explicitamente la tabla relacionada y que registro identifica dentro de esa tabla.
- Para columnas `ID_*` relacionadas, el comentario debe seguir una redaccion similar a: `Identificador del <registro funcional> relacionado. Se relaciona con DATA.<TABLA_REFERENCIADA>.`
- Si se usan abreviaciones, deben ser conocidas por el equipo o documentadas en comentarios.
- Si una columna referencia otra tabla, debe modelarse como foreign key cuando la integridad aplique.
- Si la tabla referenciada tiene una PK generica `ID`, la foreign key debe ser descriptiva. Ejemplo: `ID_PROYECTO`, `ID_CONTENIDO`.
- Evitar textos libres para estados o tipos cuando exista un catalogo o dominio controlado.
- Para columnas booleanas usar `NUMBER(1)` con constraint `CHECK`.

Ejemplo:

```sql
ACTIVO NUMBER(1) DEFAULT 1 NOT NULL
    CONSTRAINT T_MOD_TABLA_CK1 CHECK (ACTIVO IN (0,1))
```

## Tipos de datos
- Texto corto: `VARCHAR2`
- Numero entero: `NUMBER`
- Numero decimal: `NUMBER(p,s)` segun necesidad real
- Fecha: `DATE`
- Fecha y hora: `TIMESTAMP`
- Texto largo: `CLOB` cuando aplique
- Evitar `CHAR` salvo integracion o requerimiento tecnico especifico

## Primary keys
- Si la entidad tiene una clave natural estable y unica, puede usarse como primary key.
- Si la entidad requiere clave sustituta, usar primary key numerica.
- En Oracle 21c, las primary keys secuenciales nuevas deben crearse con identidad automatica.
- No usar triggers para generar claves primarias secuenciales.

Ejemplo:

```sql
ID NUMBER GENERATED BY DEFAULT ON NULL AS IDENTITY
```

## Foreign keys y unique keys
- Declarar foreign keys reales cuando exista relacion de negocio y la integridad deba preservarse.
- Las claves unicas deben declararse con constraint explicita.
- Las claves naturales que no sean primary key deben protegerse con unique key.

## Indices
- Crear indices por evidencia de filtros, joins o volumen de datos.
- Usar indices compuestos cuando respondan a patrones reales de consulta.
- No forzar indices como practica general.
- El uso de hints debe ser excepcional y justificado con plan de ejecucion.

## Vistas
- Crear vistas para simplificar lecturas compartidas, integraciones o accesos por DBLINK.
- No crear vistas para consultas triviales sin reutilizacion.
- Los accesos por DBLINK deben centralizarse a traves de vistas u objetos controlados.
- Cuando se exponga informacion de sistemas externos, preferir vistas o capas de acceso reutilizables.
- Toda vista debe tener un comentario obligatorio en lenguaje funcional que explique que informacion presenta, para que se consume y, si aplica, de que tablas o fuentes principales proviene.
- Los comentarios de las columnas de una vista deben describir el dato publicado para el usuario o proceso consumidor, no solo la transformacion tecnica usada para obtenerlo.

## Guia de redaccion para comentarios
- Escribir comentarios para que los entienda una persona funcional o de soporte no tecnico.
- Evitar definiciones vagas como `Id de la tabla`, `Estado registro`, `Descripcion vista` o frases que solo repitan el nombre del objeto.
- Cuando exista una relacion, nombrar la tabla relacionada de forma explicita.
- Si la columna representa un estado, tipo, motivo o regla, indicar que significa el valor en el proceso de negocio.
- Para columnas de estado, estatus, situacion, tipo, clasificacion o clase, el comentario debe usar el marcador `Valores permitidos:` y documentar cada valor con el formato `VALOR = significado funcional`. No crear ni usar un valor que no este documentado y aprobado.
- Antes de agregar o cambiar valores de esos dominios, generar una propuesta con objeto/columna, valores vigentes, valor propuesto, significado, consumidores, impacto y pruebas; esperar aprobacion explicita del usuario antes de modificar DDL, comentarios o logica.
- Antes de TEST, toda tabla o vista creada o modificada debe ejecutar `scripts/validate_oracle_data_object_standards.py` y finalizar `ORACLE_DATA_AUDIT_PASS`. El comentario de objeto y los catalogos de dominio son evidencia obligatoria, no una declaracion manual.
- Si la vista o tabla se usa para un proceso puntual, mencionarlo en el comentario.

Ejemplos:

```sql
COMMENT ON TABLE DATA.T_PROY_SOLICITUD IS
    'Guarda las solicitudes de proyecto registradas por el area usuaria para iniciar su revision y seguimiento.';

COMMENT ON COLUMN DATA.T_PROY_SOLICITUD.ID_CLIENTE IS
    'Identificador del cliente asociado a la solicitud. Se relaciona con DATA.T_PROY_CLIENTE.';

COMMENT ON COLUMN DATA.T_PROY_SOLICITUD.ESTADO IS
    'Estado actual de la solicitud. Indica si la solicitud esta pendiente, aprobada, rechazada o anulada.';

COMMENT ON TABLE DATA.VT_PROY_SOLICITUDES IS
    'Muestra las solicitudes de proyecto con su cliente, estado y datos principales para consulta y seguimiento desde APEX.';
```

## Paquetes, funciones y procedimientos
- Toda logica PL/SQL reutilizable debe implementarse en paquetes.
- Toda logica de negocio debe implementarse en paquetes de base de datos.
- Los paquetes deben agrupar responsabilidades relacionadas.
- Parametros: `P_<NOMBRE>`
- Variables: `V_<NOMBRE>`
- Constantes: `C_<NOMBRE>`
- Cursores: `CUR_<NOMBRE>`
- Documentar el objetivo del paquete y de sus rutinas publicas.
- Todo paquete debe tener comentario de encabezado que describa su objetivo general.
- Toda funcion y todo procedimiento debe tener su propio comentario antes de la declaracion o implementacion. No basta un unico comentario en la cabecera del paquete.
- El comentario de cada funcion o procedimiento debe describir su objetivo funcional, parametros relevantes, resultado esperado, efectos sobre datos y consideraciones importantes si aplica.
- Los comentarios tecnicos de encabezado deben incluir el nombre de usuario del desarrollador responsable, tomando como fuente `desarrollo.md`.
- El `package body` debe incluir comentarios por rutina y no puede quedar sin documentacion interna cuando contiene procedimientos o funciones modificados o nuevos.
- En procedimientos o funciones con logica compleja, multiples validaciones, DML, cursores, integraciones, manejo de estados o bifurcaciones relevantes, comentar los pasos principales dentro del body para facilitar mantenimiento.
- Los comentarios internos deben nombrar la intencion del bloque o paso funcional, por ejemplo validacion de precondiciones, busqueda de datos base, calculo de reglas, persistencia, auditoria, integracion, manejo de errores o salida.
- En el `package body` no se deben dejar comentarios grandes, redundantes o que repitan literalmente el codigo; solo comentarios breves que ayuden a entender la intencion o el flujo.
- Para rutinas publicas, documentar el contrato en el `package spec`. Para rutinas privadas, documentarlo antes de la implementacion en el `package body`. Si una rutina publica tiene una implementacion compleja, el body debe agregar comentarios de pasos internos aunque el contrato ya este documentado en el spec.
- Formato recomendado para comentario de paquete:

```sql
/*
  Paquete: PK_MODULO_PROCESO
  Objetivo: Describe la responsabilidad funcional principal del paquete.
  Responsable: USUARIO_DESARROLLADOR
  Alcance:
    - Indicar procesos o pantallas principales que consumen el paquete.
  Consideraciones:
    - Indicar reglas generales, ambiente, compania, dependencias o restricciones relevantes.
*/
```

- Formato recomendado para comentario de procedimiento:

```sql
/*
  Ejecuta la accion funcional principal de la rutina.

  Parametros:
    P_ID_REGISTRO: Identificador del registro funcional que sera procesado.
    P_USUARIO: Usuario que ejecuta la accion desde APEX o proceso autorizado.

  Efectos:
    - Inserta, actualiza o elimina informacion en DATA.T_MODULO_TABLA.
    - Registra trazabilidad o cambia estados funcionales cuando aplique.

  Errores:
    - Lanza error controlado si no existe el registro o no cumple precondiciones.
*/
```

- Formato recomendado para comentario de funcion:

```sql
/*
  Calcula o consulta el resultado funcional requerido por el flujo.

  Parametros:
    P_ID_REGISTRO: Identificador del registro usado para el calculo o consulta.

  Retorna:
    Describir el valor retornado, su significado funcional y valores especiales si aplica.

  Consideraciones:
    - Indicar si depende de estado, compania, configuracion, fecha o datos externos.
*/
```

- Ejemplo de comentario interno util:

```sql
-- Validar precondiciones antes de modificar datos del flujo.
-- Obtener configuracion vigente por compania y estado.
-- Registrar trazabilidad antes de actualizar el estado principal.
-- Aplicar persistencia final del proceso.
-- Convertir errores tecnicos en mensaje funcional controlado.
```

- Ejemplo de comentario interno no permitido como unica documentacion:

```sql
-- Hacer select.
-- Actualizar tabla.
-- Commit.
```

- No incluir `COMMIT` o `ROLLBACK` dentro de paquetes consumidos por APEX salvo autorizacion explicita y justificacion tecnica registrada; la transaccion debe quedar bajo control del flujo que invoca la rutina cuando aplique.
- Evitar paquetes excesivamente grandes; dividir por responsabilidad.
- Antes de agregar logica nueva, evaluar si corresponde a un paquete existente o a un paquete nuevo.
- La logica puede agregarse a un paquete existente solo si el objetivo del paquete realmente cubre esa responsabilidad y el paquete mantiene un tamano y complejidad razonables.
- Si el paquete existente esta saturado, mezcla demasiadas responsabilidades o su nombre ya no representa correctamente la nueva logica, se debe crear un paquete nuevo.
- Queda prohibido crear paquetes, procedimientos, funciones, vistas, jobs o scripts nombrados o condicionados por una instancia puntual de datos, actor, entidad, identificador, documento, archivo, compania, usuario, registro, formato o variante de entrada para resolver un defecto que pertenece a una arquitectura o proceso compartido.
- Cuando un incidente se reproduce con una instancia especifica, ese dato debe usarse como caso de prueba. La correccion debe atacar el patron comun del dato, formato, estado o regla afectada, no la instancia puntual.
- Si existe un convertidor, parser, cargador, normalizador, integracion o proceso compartido que produce el dato incorrecto, la correccion debe hacerse ahi o en una configuracion reutilizable asociada. No compensar el error mas adelante con una regla especial en PL/SQL por instancia puntual.
- Las excepciones por instancia puntual solo se permiten con autorizacion explicita del usuario, registro en bitacora, justificacion funcional, alcance limitado, criterio de retiro/revision y validacion de no regresion del flujo compartido.
- Antes de programar una excepcion, el agente debe presentar la alternativa reutilizable, el riesgo de deuda tecnica de la excepcion y pedir confirmacion explicita.
- Toda funcion o procedimiento nuevo, o modificado, debe probarse antes de darlo por finalizado.
- Como minimo se debe validar compilacion, ejecucion del caso principal y resultado esperado o error controlado cuando aplique.
- Antes de TEST, todo `PACKAGE` o `PACKAGE BODY` modificado debe ejecutar `scripts/validate_plsql_package_standards.py` y obtener `PLSQL_STATIC_AUDIT_PASS`. No basta declarar manualmente que los comentarios o el formato cumplen.
- Los paquetes de un mismo modulo deben analizarse con `scripts/analyze_plsql_reuse.py` cuando se cree o modifique una rutina. Aplicar `references/reutilizacion-plsql.md` para clasificar candidatos y decidir si una responsabilidad reusable exige Commons.
- Un paquete `PK_<MODULO>_COMMONS` solo puede contener logica transversal, estable y sin dependencia ciclica. Su creacion o modificacion requiere alcance autorizado, contrato documentado, migracion de los consumidores y pruebas de regresion; el detector de duplicidad no la crea automaticamente.

## Triggers
- Evitar triggers salvo necesidad tecnica justificada.
- Si se usan, documentar razon, alcance y riesgo.
- No usar triggers para asignar secuencias a primary keys nuevas.

## Consultas SQL
- Usar sintaxis ANSI JOIN.
- Usar alias claros y entendibles; evitar alias demasiado cortos si reducen legibilidad.
- No usar `SELECT *` ni `alias.*` en SQL de aplicacion, paquetes, vistas, reportes, validaciones o despliegues. Declarar explicitamente y en orden estable solo las columnas que consume el caso; asi se evita exponer datos innecesarios y que cambios de estructura alteren contratos o rendimiento.
- `COUNT(*)` es una agregacion valida para contar filas y no constituye una proyeccion comodin. Aun asi, no usar conteos completos sobre tablas o vistas pesadas como comprobacion rutinaria: acotar por el alcance funcional o usar metadata cuando corresponda.
- Usar `UNION ALL` cuando no se necesite eliminar duplicados.
- Limitar `IN` a listas pequenas o controladas.
- Preferir `CASE` sobre `DECODE`.
- Usar `EXISTS` cuando mejore claridad o eficiencia.
- No usar `ROWID` como practica general de desarrollo.
- Evitar `CHAR`; si se interactua con columnas `CHAR` heredadas, manejar sus espacios de relleno de forma explicita.
- Para ejecutar consultas de lectura o `EXPLAIN PLAN` durante analisis, usar `scripts/oracle_sql_tool.py` del skill activo. No improvisar clientes, snippets Python ni helpers del proyecto para operaciones rutinarias de lectura cuando el helper oficial este disponible.
- No ejecutar un query completo solo porque fallo el `EXPLAIN PLAN`; corregir el SQL explicable o reportar el error exacto.
- No usar `COUNT(*)` completo ni consultas sin filtros sobre vistas o tablas pesadas como validacion rutinaria, especialmente en PRODUCCION. Preferir filtros del alcance, muestras pequenas, metadata, `EXPLAIN PLAN`, `ALL_OBJECTS`, `ALL_TAB_MODIFICATIONS` o comprobaciones funcionales acotadas.
- Si una consulta o validacion Oracle termina por timeout local, interrupcion o corte del cliente, aplicar inmediatamente el gate de sesiones de `conectividad-oracle.md`: revisar sesiones propias activas, cerrar o escalar cualquier sesion colgada, y documentar evidencia antes de continuar o cerrar.

## Catalogos y UDC
- Reutilizar catalogos existentes antes de crear nuevos.
- Toda nueva codificacion debe tener ownership y descripcion funcional.
- No duplicar catalogos corporativos ya existentes en otros sistemas si ya son fuente oficial.
- Las aplicaciones deben consumir catalogos comunes de forma consistente.
- Estandar: Las URLs, endpoints, rutas base, hosts, puertos y parametros que cambian por ambiente deben guardarse como configuracion en `DATA.T_CORP_UDC` o tabla general corporativa aprobada. No deben quedar hardcodeados en APEX, paquetes, funciones, procedimientos, vistas, jobs ni JavaScript.
- Estandar: Para URLs por ambiente, se debe registrar al menos la clave funcional, descripcion, ambiente (`TEST` o `PROD`/`PRODUCCION`), compania cuando aplique, estado y valor de la URL. Si `DATA.T_CORP_UDC` ya tiene convencion vigente para estos atributos, usar esa convencion; si no, documentar el mapeo elegido en la vista.
- Estandar: Antes de crear o actualizar configuracion de URLs, pedir al usuario los valores de TEST y PRODUCCION cuando no esten confirmados. No asumir que cambiando puerto, host o dominio se obtiene la URL productiva correcta.
- Estandar: Las aplicaciones y paquetes no deben consumir `DATA.T_CORP_UDC` directamente para URLs. Deben usar una vista funcional `DATA.VT_<MODULO>_<SECCION>` y/o un paquete de configuracion que centralice la lectura, filtros de ambiente, compania y estado.
- Estandar: Los scripts de pase deben tratar los valores por ambiente de forma explicita: TEST se valida en TEST; PRODUCCION se inserta o actualiza en produccion con el valor productivo confirmado por el usuario.
- Estandar: Si la necesidad funcional es guardar pocos registros parametrizables para listas, combos o catalogos simples con aproximadamente `2` a `4` caracteristicas, se debe usar obligatoriamente `DATA.T_CORP_UDC` y no una tabla fisica nueva.
- Estandar: Esta regla aplica especialmente cuando el catalogo solo requiere campos equivalentes a codigo, descripcion, estado, compania, orden, tipo u otros atributos simples de bajo volumen.
- Estandar: Para este tipo de catalogos simples queda prohibido crear tablas fisicas dedicadas solo para almacenar codigo, descripcion y pocos registros, salvo autorizacion explicita del usuario y registro de la excepcion.
- Estandar: Antes de proponer una tabla nueva para datos parametricos, el agente debe justificar por que `DATA.T_CORP_UDC` no cubre la necesidad. Si no existe una justificacion clara, debe resolverse con tabla general y vista.
- Contexto: Cuando una aplicacion APEX requiera una tabla general parametrica propia, la fuente de registro debe ser `DATA.T_CORP_UDC`.
- Estandar: Las aplicaciones no deben consumir `DATA.T_CORP_UDC` directamente; deben consumir una vista especifica por aplicacion y seccion.
- Estandar: `ID_CABECERA` identifica la familia del catalogo. Debe formarse con las primeras letras o codigo corto de la aplicacion, seguido de `_` y el nombre corto de la seccion. Ejemplo: `ICOM_VIST` para visitas del portal Inversiones Comerciales.
- Estandar: `ID_TABLA` identifica el codigo del registro dentro de la cabecera.
- Estandar: `COMPANIA` identifica la compania donde se visualiza el registro; si esta vacio o nulo, el registro aplica a todas las companias.
- Estandar: Los demas campos de `DATA.T_CORP_UDC` se usan como atributos flexibles del registro, segun la necesidad funcional de la vista. La asignacion de cada atributo, incluyendo como se obtiene `COMPANIA`, debe quedar documentada en el comentario de la vista.
- Estandar: La vista debe nombrarse como `VT_<CODIGO_APLICACION>_<SECCION>` y debe exponer nombres funcionales, no nombres genericos de `DATA.T_CORP_UDC`.
- Estandar: Toda vista creada sobre `DATA.T_CORP_UDC` debe tener `COMMENT ON TABLE` indicando `ID_CABECERA`, la regla de compania, el mapeo de atributos y el uso esperado por la aplicacion.
- Razon: La vista desacopla la aplicacion de la tabla general, evita repetir filtros y permite dar nombres funcionales a atributos genericos.
- Razon: Crear tablas fisicas para catalogos minimos como codigo y descripcion fragmenta el modelo, duplica mantenimiento y rompe el criterio corporativo de reutilizar tabla general.
- Ejemplo: Para visitas del portal Inversiones Comerciales, usar `ID_CABECERA = 'ICOM_VIST'` y crear la vista `DATA.VT_ICOM_VISITAS` con columnas funcionales como `ID_VISITA`, `DESCRIPCION`, `TIPO_VISITA`, `AREA`, `ESTADO` y `COMPANIA`.
- Ejemplo: Un catalogo como marcas, tipos, clases, estados o motivos con pocos registros y pocas caracteristicas no debe crearse como tabla fisica propia; debe resolverse en `DATA.T_CORP_UDC` con su vista funcional correspondiente.
- Ejemplo:

```sql
CREATE OR REPLACE VIEW DATA.VT_ICOM_VISITAS AS
SELECT
    ID_TABLA AS ID_VISITA,
    DESCRIPCION2 AS DESCRIPCION,
    VALOR AS TIPO_VISITA,
    DESCRIPCION AS AREA,
    ACTIVO AS ESTADO,
    NULLIF(TRIM(CODIGOCOMPANIA), '') AS COMPANIA
FROM DATA.T_CORP_UDC
WHERE ID_CABECERA = 'ICOM_VIST';

COMMENT ON TABLE DATA.VT_ICOM_VISITAS IS
    'Catalogo de visitas del portal Inversiones Comerciales. Fuente DATA.T_CORP_UDC con ID_CABECERA=ICOM_VIST. ID_TABLA=ID_VISITA, DESCRIPCION2=DESCRIPCION, VALOR=TIPO_VISITA, DESCRIPCION=AREA, ACTIVO=ESTADO, CODIGOCOMPANIA origen se expone como COMPANIA. Si COMPANIA es nula aplica a todas las companias. Consumir desde APEX filtrando COMPANIA = :G_COMPANIA o COMPANIA IS NULL.';
```

## Auditoria, log y errores
- Toda tabla transaccional nueva debe considerar auditoria:
  - `FECHA_CREACION`
  - `USUARIO_CREACION`
  - `FECHA_ACTUALIZACION`
  - `USUARIO_ACTUALIZACION`
- La logica critica debe registrar errores de forma estandar.
- No inventar parametros, columnas, tablas, paquetes, variables ni logs con nombres propios del agente como `p_codex_log`, `codex_log`, `t_codex_log` o equivalentes. Si el proyecto ya tiene un parametro o mecanismo de log existente, usar exactamente esa firma; si no existe, no agregar trazas del agente al contrato funcional sin autorizacion explicita.
- Los logs tecnicos del agente deben quedar fuera del codigo de negocio, en `docs/tareas/<ID_TAREA>/logs`, `qa/tareas/<ID_TAREA>/reports` o la bitacora del proyecto segun corresponda.
- No registrar credenciales ni datos sensibles en logs.
- Ante errores de produccion, el diagnostico inicial debe hacerse en produccion para identificar el error real logueado; la correccion debe replicarse y validarse en test antes de preparar o ejecutar el pase a produccion.

## Correo e integraciones
- Centralizar envios de correo e integraciones en paquetes reutilizables.
- El estandar corporativo para enviar correos desde PL/SQL es `PK_CORP_CORREO.SP_ENVIO`.
- Toda rutina que envie correo debe informar explicitamente como minimo `P_MODULO`, `P_TO`, `P_FROM`, `P_SUBJECT` y `P_BODY`.
- En migraciones de procesos legacy, el cambio tecnico debe concentrarse en el motor de envio; el `FROM`, `SUBJECT` y `BODY` funcionales se conservan igual que en el proceso origen, salvo instruccion explicita del usuario.
- No hardcodear contrasenas, usuarios, destinatarios de prueba, URLs internas, endpoints, hosts, puertos ni rutas base en codigo de negocio.
- Parametrizar diferencias entre ambientes en `DATA.T_CORP_UDC` o tabla general corporativa aprobada, con valores TEST y PRODUCCION confirmados.

## Seguridad
- Aplicar privilegios minimos.
- Evitar SQL dinamico si no es necesario.
- Si se usa SQL dinamico, usar bind variables obligatoriamente.
- No dejar secretos o endpoints sensibles en objetos de base de datos.

## Rendimiento SQL y planes de ejecucion

Esta politica pertenece a desarrollo. QA recibe solo el escenario y criterio no funcional que desarrollo deje en el contrato; no interpreta planes ni decide indices.

### Cuando aplica

Antes de TEST, ejecutar `python scripts/oracle_sql_tool.py explain --environment test --file <SQL_ARCHIVO>` para cada SQL nuevo o modificado que alimente un reporte, grilla, LOV con busqueda, filtro, proceso masivo, vista, paquete o proceso con volumen relevante. Tambien aplica ante timeout, lentitud reportada o un criterio de tiempo solicitado.

No aplica a consultas por clave primaria/única, metadata o catálogos pequeños y cerrados, salvo que exista evidencia de lentitud. `No aplica` debe registrarse con la razón; no se ejecuta `EXPLAIN PLAN` de forma mecánica sobre toda consulta.

### Evidencia y decisión técnica

Por cada SQL al que aplique, la auditoría pre-TEST registra: archivo/objeto y ubicación, escenario y binds representativos de TEST, volumen o cardinalidad conocida, comando y plan, operaciones predominantes, tablas/índices utilizados, riesgo detectado y decisión: `sin cambio`, `reescritura SQL`, `índice propuesto` o `índice implementado`.

Un `FULL TABLE SCAN` no es por sí solo un defecto: se evalúa frente a cardinalidad, selectividad, volumen, frecuencia y costo total. No se declara optimización ni se recomienda un índice sin esa evidencia.

### Índices

Crear, modificar o eliminar un índice requiere alcance autorizado, fuente SQL versionada, validación en TEST y análisis de: índices/constraints existentes, selectividad, columnas de filtros/joins/orden, costo de DML, duplicidad, tamaño y efecto de concurrencia. Si la decisión altera el modelo, la carga transaccional o requiere criterio DBA, preparar la propuesta con impacto y no ejecutarla sin autorización explícita.

El índice no sustituye corregir predicados no indexables, conversiones implícitas, filtros tardíos, joins incorrectos o volumen innecesario. Tras una corrección o índice autorizado, repetir el plan y registrar la comparación técnica. QA valida en TEST únicamente el tiempo objetivo o la ausencia de regresión indicada por desarrollo; no repite `EXPLAIN PLAN` ni crea índices.

## Despliegue y versionado
- Todo cambio de base debe existir en script versionado.
- Separar DDL, DML semilla y grants cuando aplique.
- No hacer cambios manuales en produccion sin respaldo en scripts formales.
- Durante tareas paralelas, preparar el paquete en `docs/tareas/<ID_TAREA>/deploy`. Usar `docs/deploy` solo para el pase final integrado o consolidado.
- En proyectos multitarea, el agente debe mantener control de cambios en `docs/pases-produccion/control_cambios.md` para identificar que tareas, objetos y datos de configuracion ya fueron pasados a produccion y que queda pendiente.
- Antes de preparar un pase, el agente debe comparar el alcance TEST vs produccion con la evidencia disponible: bitacora, checklist, scripts, objetos compilados, paquetes archivados y consultas de metadata cuando aplique.
- Si se acumularon varios dias, varias sesiones o varias tareas en TEST sin paso a produccion, el despliegue debe tratarse como `Pase Consolidado`: incluir solo tareas cerradas y aprobadas por QA, excluir tareas incompletas o sin QA aprobado, validar dependencias del bloque, confirmar GitHub como fuente y ejecutar QA/regresion minima del conjunto antes de declarar `Listo para pase`.
- Para objetos versionados, el origen del pase es el commit aprobado por QA y publicado en GitHub. TEST valida ese commit, pero no reemplaza la fuente Git. Si TEST contiene un cambio valido distinto, reconciliarlo primero al repo y crear un nuevo commit candidato.
- El SQL ejecutado en TEST y PRODUCCION debe tener SHA-256 registrado y provenir de un checkout limpio del commit candidato. Antes de PRODUCCION, ese commit debe resolver exactamente a `origin/main`; un archivo local con el mismo SHA Git declarado pero contenido distinto es `No conforme` y obliga a reconstruir el artefacto desde el commit publicado, repetir TEST/QA si cambia el contenido y nunca a reaplicar desde la copia discrepante.
- Si el pase incluye aplicacion APEX, el agente puede publicarla en produccion cuando el usuario lo pida o el alcance aprobado lo incluya. Debe intentar respaldar APEX productivo, obtener export desde TEST o export vigente verificado, importar en produccion con mecanismo autorizado y validar metadata/paginas. Si el respaldo productivo por API falla con `ORA-20987` o privilegios, pero el import esta habilitado y el export TEST esta verificado, debe proceder y registrar la evidencia alternativa; no debe responder que no puede pasar aplicaciones APEX si existe acceso y mecanismo autorizado.
- Antes de entregar un pase, usar `python scripts/production_deploy_tool.py validate --project-root . --task-id <ID_TAREA>`. Antes de PRODUCCION repetir con `--for-production` para exigir el linaje Git completo.
- Preparar el pase no autoriza ejecutarlo. La ejecucion en produccion requiere instruccion explicita del usuario para aplicar el deploy o importar APEX en produccion.
- Antes de declarar `Listo para pase`, confirmar commit candidato previo a TEST, TEST correspondiente a ese SHA, QA del mismo commit, publicación en GitHub, `control_cambios.md`, manifiesto, backup y autorizacion productiva pendiente o confirmada.
- Antes de ejecutar cambios en produccion, respaldar los objetos productivos del alcance. Para objetos de base usar `python scripts/production_deploy_tool.py backup-prod-objects --project-root . --task-id <ID_TAREA> --objects TIPO:OWNER.OBJETO ...` durante una tarea; para APEX usar export productivo cuando este disponible o evidencia alternativa autorizada cuando el export productivo por API falle.
- El pase debe tener un archivo principal `deploy.sql` que orqueste la ejecucion y deje claro el orden de los scripts.
- Los scripts del pase deben separarse como minimo en:
  - `00_backup_produccion.sql`: respaldo DDL de objetos productivos antes del pase. No se ejecuta desde `deploy.sql`; se conserva como evidencia y reversa tecnica.
  - `01_estructura.sql`: tablas, alter tables, constraints, indices, secuencias, vistas, triggers, jobs, synonyms, grants tecnicos y cambios estructurales de objetos que no sean paquetes.
  - `02_datos_configuracion.sql`: inserts, merges o updates de datos semilla, UDC, LOV, catalogos, parametros, accesos, menus, configuraciones y datos necesarios para listar o habilitar funcionalidad.
  - `03_paquetes.sql`: package specs, package bodies, funciones y procedimientos PL/SQL.
  - `04_validacion_post.sql`: consultas de validacion, conteos, compilacion, objetos invalidos y comprobaciones minimas posteriores al pase.
- Si un bloque no aplica, el archivo puede omitirse, pero `deploy.sql` debe conservar el orden y documentar que no aplica.
- No mezclar DDL estructural, DML de configuracion y paquetes en un unico script largo salvo autorizacion explicita del usuario.
- Los scripts de datos de configuracion deben ser idempotentes cuando sea razonable, usando `MERGE`, validaciones previas o condiciones que eviten duplicados.
- `02_datos_configuracion.sql` no debe incluir data transaccional, registros de prueba, resultados de procesos, cargas temporales, archivos procesados ni copias masivas de datos desde test hacia produccion.
- La data permitida para produccion es solo configuracion necesaria para que funcione el proceso: UDC, LOV, catalogos simples, parametros, menus, accesos, rutas de aprobacion, permisos o tablas generales autorizadas.
- Para UDC o tablas generales, priorizar `DATA.T_CORP_UDC` con `MERGE` idempotente por `ID_CABECERA`, `ID_TABLA` y compania/clave funcional segun aplique.
- Para URLs o endpoints por ambiente, `02_datos_configuracion.sql` debe usar el valor productivo confirmado por el usuario. No copiar el valor de TEST a PRODUCCION ni transformar la URL por inferencia de puerto, host o dominio.
- Si el usuario pide pasar data transaccional o data de test a produccion, debe existir instruccion explicita del usuario, alcance registrado en bitacora, script separado y validacion previa de no sensibilidad y no duplicidad.
- Los scripts estructurales deben ser ejecutables en produccion sin depender de objetos temporales locales no documentados.
- Cuando se necesite extraer objetos desde TEST, usar `scripts/production_deploy_tool.py export-test-objects --task-id <ID_TAREA>` solo para verificacion o reconciliacion; no usar la extraccion como fuente hacia PRODUCCION sin incorporarla antes al repo y generar un commit candidato.
- El paquete de despliegue debe incluir un encabezado con modulo, fecha, ambiente origen, ambiente destino, responsable, alcance, orden de ejecucion y rollback o criterio de reversa cuando aplique.
- El paquete de despliegue debe incluir `docs/deploy/manifest_pase.md` cuando el pase tenga mas de una tarea, mas de un objeto o cualquier dato de configuracion.
- Despues de ejecutar o entregar un pase cerrado, el agente debe archivar una copia completa en `docs/pases-produccion/<YYYYMMDD_HHMM>_<descripcion>/` con los scripts, informe de ejecucion o validacion y evidencias relevantes.
- Todo pase ejecutado, fallido, parcial o preparado no ejecutado debe tener `informe_pase.md` en la carpeta archivada de `docs/pases-produccion/`, con resumen, scripts/imports, usuario productivo, objetos, backups, validacion post, errores y pendientes.
- Luego del archivo historico, `docs/deploy` debe quedar vacio o solo con un marcador no operativo como `.gitkeep`, listo para el siguiente pase.
- Para paso a produccion solicitado al agente, el alcance operativo puede incluir objetos de base y aplicacion APEX cuando el usuario lo indique o el alcance aprobado lo incluya. Si incluye APEX, separar el export/import APEX de los scripts de base, registrar APP_ID, paginas incluidas, workspace, ambiente origen, ambiente destino y evidencia.
- La conexion directa de paso a produccion debe usar exclusivamente los parámetros externos `ZAIMELLA_ORACLE_PROD_*`, apuntando al servidor/servicio configurado para PRODUCCIÓN. Nunca debe guardarse ni redescubrirse un usuario, contraseña, host, SID o URL en el repositorio, skill, bitácora, logs, prompts o reportes.
- Cuando el pase incluya datos desde test hacia produccion, el script puede usar el DB link `@zaip` para leer o escribir contra produccion desde la sesion de test, segun la direccion requerida por el DML.
- El uso de `@zaip` en pases queda limitado a validaciones o DML de configuracion autorizado. No debe usarse para copiar data de pruebas ni para desplegar objetos de base.
- Cuando el pase incluya objetos de base de datos, como tablas, vistas, paquetes, secuencias, triggers o jobs, el despliegue debe ejecutarse conectado directamente a produccion. `@zaip` queda permitido para DML o validaciones de datos, no para desplegar DDL ni codigo PL/SQL de objetos.
- Para recrear paquetes, package bodies, funciones o procedimientos del esquema `DATA` en produccion con la credencial externa autorizada, el script `03_paquetes.sql` debe fijar primero `ALTER SESSION SET CURRENT_SCHEMA=DATA` y luego ejecutar las fuentes sin prefijo de owner en el nombre del objeto. No usar `CREATE OR REPLACE PACKAGE DATA.<PAQUETE>` ni `CREATE OR REPLACE PACKAGE "DATA"."<PAQUETE>"` como camino operativo para estos objetos.
- No basta incluir `ALTER SESSION SET CURRENT_SCHEMA=DATA` en el archivo. Antes de cada DDL de codigo, el ejecutor debe confirmar el `CURRENT_SCHEMA` efectivo, registrar usuario de sesion/esquema/base y comprobar despues el owner `DATA`, tipo y estado `VALID` del objeto creado. Si el owner final no es `DATA`, el pase es fallido aunque el SQL no reporte error.
- Si se extraen paquetes desde TEST con `scripts/production_deploy_tool.py export-test-objects`, el helper debe normalizar el DDL de codigo PL/SQL de `DATA` para este patron y `validate` debe bloquear `03_paquetes.sql` cuando detecte recreacion directa como `DATA.objeto`.
- Despues de importar o ejecutar cada bloque en produccion, validar obligatoriamente que todos los objetos de base del alcance queden `VALID` con `python scripts/production_deploy_tool.py validate-prod-compile --objects TIPO:OWNER.OBJETO ...` o consulta equivalente de `ALL_OBJECTS`. No continuar al siguiente bloque si hay objetos `INVALID` sin diagnosticar y corregir.
- En pases a produccion con objetos de base, `04_validacion_post.sql` o la validacion equivalente debe consultar explicitamente `ALL_OBJECTS` para todos los objetos incluidos en el pase y sus dependencias directas conocidas cuando apliquen. La evidencia debe mostrar `OWNER`, `OBJECT_NAME`, `OBJECT_TYPE` y `STATUS`.
- Para paquetes, la validacion debe incluir por separado `PACKAGE` y `PACKAGE BODY`. No basta validar solo que exista el paquete o que el spec este `VALID`; si el `PACKAGE BODY` queda `INVALID`, el pase no esta correcto.
- Si cualquier objeto queda `INVALID`, el agente debe consultar `ALL_ERRORS` o usar la herramienta equivalente para obtener el error real, recompilar o corregir con la fuente vigente autorizada, volver a validar `ALL_OBJECTS` y dejar evidencia del estado final. Si no puede dejar todos los objetos del alcance en `VALID`, debe reportar el pase tecnico como fallido y describir el impedimento; no marca la tarea ni informa cierre exitoso.
- El cierre del pase debe incluir evidencia de objetos `VALID` posterior a la ejecucion productiva. La ausencia de esta evidencia se considera pase incompleto, aunque los scripts hayan terminado sin error visible.
- Si el cambio ya fue probado funcionalmente en TEST, la validacion productiva posterior al pase es minima: objetos `VALID`, vistas consultables sin error, paquetes compilados, jobs/configuracion presentes, metadata APEX importada cuando aplique y carga inicial de pantalla principal o pagina afectada. No repetir QA funcional completo en produccion.
- En produccion no crear, modificar, aprobar, cargar, eliminar ni procesar datos reales como parte normal del pase. Cualquier prueba transaccional productiva requiere autorizacion explicita, datos controlados/no sensibles y registro en la bitacora o informe del pase.
- Cuando se trate de una correccion reportada en produccion, diagnosticar primero el error real en produccion, pero desarrollar, corregir y probar en TEST antes de pasar nuevamente a produccion. La ejecucion productiva posterior se limita al despliegue y validacion minima.
- Contexto: La credencial operativa externa de PRODUCCIÓN puede no tener privilegios directos para crear, recrear, habilitar o modificar jobs propiedad de `DATA` con `DBMS_SCHEDULER`.
- Estandar: Para jobs de `DATA` en produccion, no usar `DBMS_SCHEDULER.SET_ATTRIBUTE` como camino operativo. Primero se debe usar el camino corporativo por `DATA.PK_CORP_COMMONS.SP_CREA_JOB` cuando el alcance este autorizado.
- Estandar: Antes de generar el script, inspeccionar la firma vigente de `DATA.PK_CORP_COMMONS.SP_CREA_JOB` en el ambiente objetivo con `python scripts/production_deploy_tool.py describe-commons-job-procedure --environment prod` o con `ALL_ARGUMENTS`; no asumir parametros de memoria si la firma no esta confirmada.
- Estandar: Para job existente, el alcance del cambio debe ser minimo. Antes de modificar, consultar y registrar `owner`, `job_name`, `enabled`, `state`, `job_type`, `job_action`, `start_date`, `repeat_interval`, `next_run_date`, `job_class`, `comments` y zona horaria con `python scripts/production_deploy_tool.py describe-job --environment prod --job OWNER.NOMBRE_JOB` o consulta equivalente. Despues de modificar, repetir la consulta y confirmar que solo cambio lo pedido.
- Estandar: Si el usuario pide "agregar una llamada", "agregar una linea" o "anadir un proceso" al `job_action` de un job existente, solo se debe alterar `job_action` agregando esa llamada en el lugar correcto. No modificar horario, `start_date`, `repeat_interval`, `enabled`, clase, zona horaria, comentarios ni otros atributos.
- Estandar: Para job nuevo, antes de crearlo se debe pedir horario/frecuencia de ejecucion, zona horaria y si debe quedar habilitado. No crear jobs nuevos con `repeat_interval = NULL` o `start_date` generado accidentalmente salvo que el usuario indique explicitamente que sera manual o de una sola ejecucion.
- Estandar: Para crear jobs de `DATA` en produccion, recrearlos, habilitarlos, deshabilitarlos o ejecutar acciones puntuales sobre jobs de `DATA`, se debe preparar un bloque usando `DATA.PK_CORP_COMMONS.SP_CREA_JOB`, preservando los atributos existentes cuando se trate de una modificacion.
- Estandar: Para modificar definicion, accion o estado de un job existente, recrear el job objetivo por Commons o crear un job puntual de mantenimiento por Commons segun la firma vigente y la autorizacion del pase. No proponer `DBMS_SCHEDULER.SET_ATTRIBUTE`.
- Estandar: Todo job de base de datos, incluidos jobs operativos, jobs de migracion y jobs puntuales creados con `DATA.PK_CORP_COMMONS.SP_CREA_JOB`, debe tener un nombre funcional, estable y descriptivo. No debe incluir fecha ni hora de ejecucion en el nombre. Usa el prefijo del modulo o proceso aprobado.
- Razon: `DATA.PK_CORP_COMMONS.SP_CREA_JOB` ejecuta la creacion del job bajo el owner corporativo correcto y evita requerir privilegios directos de scheduler al usuario operativo.
- Validacion obligatoria: despues de usar Commons, consultar `ALL_SCHEDULER_JOBS`, `ALL_SCHEDULER_JOB_RUN_DETAILS` y `ALL_OBJECTS` cuando aplique para confirmar estado, ultima ejecucion del job puntual, errores y que el job objetivo quedo con el atributo esperado sin alterar atributos fuera del alcance.
- Ejemplo: Para crear un job de ejecucion de APIs, usar un nombre funcional como `DATA.ECMM_EJECUTA_APIS` con `DATA.PK_CORP_COMMONS.SP_CREA_JOB`. Para habilitar un job existente de `DATA`, crear un job puntual con nombre funcional, usando una accion como `begin dbms_scheduler.enable(name => 'DATA.ECMM_EJECUTA_APIS'); end;`, validar que el job puntual termine `SUCCEEDED` y confirmar que el job objetivo quede `ENABLED=TRUE`.
- El lote de `objetos` debe venir en secuencia valida de dependencias para que tablas, vistas, paquetes y jobs se creen sin errores por orden de ejecucion.
- Ejemplo de `docs/deploy` para un pase activo:

```text
docs/deploy/
|- deploy.sql
|- 00_backup_produccion.sql
|- 01_estructura.sql
|- 02_datos_configuracion.sql
|- 03_paquetes.sql
`- 04_validacion_post.sql
```

- Ejemplo de archivo historico despues del pase:

```text
docs/pases-produccion/20260527_1530_ecmm_aprobaciones/
|- deploy.sql
|- 00_backup_produccion.sql
|- 01_estructura.sql
|- 02_datos_configuracion.sql
|- 03_paquetes.sql
|- 04_validacion_post.sql
|- informe_ejecucion.md
`- evidencias/
```

## Documentacion De Rutinas E Identificadores

- Cada procedimiento y funcion de un `PACKAGE BODY`, procedimiento independiente o funcion independiente debe tener un comentario funcional propio inmediatamente antes de su declaracion. El comentario de la cabecera del paquete no sustituye esta obligacion.
- Cuando una rutina contiene ramas de negocio, validaciones, cursores, agrupaciones, SQL dinamico, transacciones o manejo de excepciones no triviales, comentar los pasos relevantes, decisiones y efectos. No usar comentarios decorativos que repitan literalmente el codigo.
- La auditoria tecnica pre-TEST debe inventariar cada objeto y rutina modificada y dejar evidencia de comentario propio, comentarios internos aplicables, compilacion correcta y `ALL_ERRORS=0`. Una evidencia vacia, global o solo a nivel de paquete no cumple.
- La generacion de una clave primaria debe usar un unico mecanismo definido en el DDL vigente de la tabla. Si la columna es `GENERATED ... AS IDENTITY`, omitirla del `INSERT` y obtener el valor con `RETURNING`; queda prohibido combinarla con una secuencia manual o trigger redundante sin excepcion autorizada y documentada.
- Si la tabla no usa `IDENTITY`, la secuencia corporativa puede usarse como mecanismo oficial. Preferir `INSERT ... VALUES (SECUENCIA.NEXTVAL, ...) RETURNING ID INTO ...` cuando el llamador requiera el identificador; no consultar `DUAL` por separado salvo una razon tecnica documentada.
- Antes de cambiar la estrategia de identificadores, inspeccionar y registrar el DDL vigente, dependencias, triggers y consumidores. No asumir que una secuencia existente demuestra que la columna no es `IDENTITY`.

## Integracion con Oracle APEX
- Exponer a APEX vistas o paquetes estables en lugar de logica SQL dispersa.
- Toda tabla consumida por APEX debe tener nombres claros, claves definidas y auditoria cuando aplique.
- Toda consulta de lectura para listas, reportes o vistas orientadas a APEX debe contemplar filtro por compania cuando la tabla o vista exponga `COMPANIA`.
- El filtro corporativo obligatorio en APEX para compania es `:G_COMPANIA`.
- Para archivos adjuntos no se deben crear tablas nuevas ni columnas BLOB/CLOB en tablas de negocio si el requerimiento corresponde al patron corporativo de adjuntos APEX.
- El estandar corporativo de adjuntos es `FILES.T_APEX_ARCHIVOS`.
