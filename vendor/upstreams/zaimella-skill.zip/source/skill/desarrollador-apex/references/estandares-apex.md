# Estandares de Oracle APEX Zaimella

## Objetivo
Definir los estandares vigentes para el desarrollo, mantenimiento y mejora de aplicaciones Oracle APEX en Zaimella.

## Principios generales
- Oracle APEX debe usarse como capa de presentacion, navegacion, captura y orquestacion.
- La logica de negocio debe centralizarse en paquetes de base de datos.
- Las aplicaciones deben priorizar consistencia funcional, mantenibilidad y reutilizacion.
- El esquema de trabajo para los desarrollos es `DATA`.

## Arquitectura base
- La aplicacion `100` es la aplicacion master.
- Los componentes reutilizables corporativos deben tomarse de la aplicacion `100`.
- La autenticacion centralizada se realiza con el esquema definido en la aplicacion `100`.
- Para aplicaciones nuevas, la suscripcion de tema y menu debe basarse en la aplicacion `100`.

## Alcance de la aplicacion 100
- Contexto: La aplicacion `100` es una aplicacion generica que centraliza desarrollos, componentes y patrones corporativos usados por muchas aplicaciones APEX.
- Estandar: Queda prohibido desarrollar en la aplicacion `100` funcionalidades especificas para una tarea, modulo, compania, usuario, proyecto o aplicacion puntual.
- Estandar: Los desarrollos nuevos en la aplicacion `100` solo se permiten cuando sean estandares reutilizables y exista una necesidad real de uso transversal por varias aplicaciones.
- Estandar: Si una funcionalidad resuelve un caso especifico, debe implementarse en la aplicacion funcional correspondiente y consumir desde `100` solo los componentes genericos aprobados.
- Razon: Usar la aplicacion `100` para casos puntuales contamina la arquitectura comun, aumenta el riesgo de regresiones en otras aplicaciones y dificulta mantener componentes verdaderamente reutilizables.
- Ejemplo: Un cargador, plugin, tema, autenticacion, menu o componente compartido puede vivir en `100` si sera usado por varias aplicaciones. Una validacion, pantalla, proceso o flujo creado solo para una tarea de un modulo especifico no debe desarrollarse en `100`.

## Regla arquitectonica principal
- Toda la logica de negocio debe implementarse en paquetes de base de datos.
- Queda prohibido colocar sentencias `INSERT`, `UPDATE` o `DELETE` de negocio directamente en procesos APEX.
- Oracle APEX debe invocar procedimientos o funciones definidos en paquetes de base de datos para ejecutar la logica transaccional.
- Cuando exista un flujo, componente, servicio, convertidor, cargador, parser, validador, integracion o arquitectura compartida vigente, los defectos deben corregirse en esa fuente comun o en una regla parametrizable reutilizable.
- Queda prohibido resolver un defecto de arquitectura o proceso compartido con un desarrollo especifico para una instancia puntual de datos, actor, entidad, identificador, documento, archivo, compania, usuario, registro, formato o variante de entrada, salvo que el usuario lo pida o apruebe explicitamente como excepcion.
- Si una sola instancia falla dentro de un conjunto mayor, el agente debe diagnosticar primero que patron, regla, formato, estado o precondicion rompe el proceso compartido y proponer una correccion reutilizable para todas las instancias con el mismo patron.
- No se deben crear procesos, botones, validaciones, paquetes, funciones, procedimientos, vistas, tablas, jobs o scripts nombrados o condicionados por una instancia puntual para resolver un incidente que pertenece a una arquitectura compartida.
- Una excepcion puntual solo puede implementarse si el usuario la autoriza explicitamente, queda registrada en bitacora, tiene justificacion funcional, fecha/responsable, alcance, criterio de retiro o revision y QA que demuestre que no rompe el flujo compartido.
- Si el usuario entrega un ejemplo puntual, el agente debe tratarlo como caso reproductor del defecto, no como permiso para hardcodear una regla especifica. Debe pedir confirmacion antes de implementar una solucion puntual.

## Aplicaciones nuevas
- El nombre de la aplicacion debe ser claro y descriptivo.
- El idioma base debe configurarse en espanol.
- El esquema de parsing debe ser `DATA`.
- Para aplicaciones nuevas, se debe heredar tema, autenticacion y menu desde la aplicacion `100` cuando aplique.

## Nomenclatura
- El nombre de la aplicacion debe ser claro y con palabras completas.
- El nombre de la pagina debe ser claro, corto y con palabras completas.
- Las paginas de dialogo deben iniciar con `Dlg`.
- Las constantes de aplicacion deben iniciar con `APP_`.
- Los application items deben iniciar con `G_`.
- Las listas de valores deben iniciar con `LOV_`.
- Los nombres de botones, regiones, procesos y acciones dinamicas deben ser descriptivos.
- Los nombres funcionales visibles para el usuario deben estar en espanol.

## Paginas
- La numeracion de paginas debe seguir una estructura ordenada por bloques funcionales.
- La numeracion debe iniciar desde `100` para paginas funcionales.
- Se debe agrupar por submodulo usando bloques de `100` cuando la aplicacion lo permita.
- Las paginas modales o auxiliares deben ubicarse cerca de la pagina funcional a la que pertenecen.
- Toda pagina debe mantener consistencia con el diseno corporativo.
- Toda pagina debe tener titulo claro, corto, contenido organizado y acciones visibles segun el caso.
- Toda pagina debe tener de forma obligatoria un titulo claro y corto visible para el usuario final.
- El titulo visible de la pagina debe implementarse con la region breadcrumb corporativa `Zaimella Barra de Navegacion`.
- Esa region debe usar la opcion `t-BreadcrumbRegion--useBreadcrumbTitle` para tomar el titulo actual de la pagina.
- Toda pagina principal de mantenimiento o flujo que no sea dialogo debe tener una unica region `Barra de acciones` con template `Zaimella Barra de Acciones` ubicada en `Breadcrumb Bar`.
- El boton de retorno, como `Atras`, debe ubicarse a la izquierda dentro de esa barra.
- Los demas botones de accion de la pagina deben ubicarse a la derecha dentro de esa misma barra.
- Todos los botones de accion personalizados de una pagina normal, incluidos retorno, guardar, crear, agregar, editar, eliminar, descargar o acciones equivalentes, deben usar template de boton `Icon`, mostrarse sin texto visible y definir `Icon CSS Classes` y `p_button_image_alt` descriptivos. La etiqueta accesible debe explicar la accion aunque visualmente solo se muestre el icono.
- Los controles nativos generados por APEX, como busqueda, paginacion o menus propios de un `Interactive Report` o `Interactive Grid`, no se consideran botones personalizados para esta regla.
- Los unicos botones de accion personalizados que pueden usar template `Text` y etiqueta visible son los botones finales de una pagina de dialogo, conforme a la seccion `Dialogos`. Toda excepcion adicional requiere autorizacion explicita y evidencia de accesibilidad.
- Si el flujo tiene varios retornos posibles, deben resolverse por condicion, manteniendo un solo boton de retorno visible a la izquierda.
- No se deben dispersar los botones principales de la pagina en regiones inferiores o barras separadas, salvo excepcion funcional justificada y documentada.
- Las pantallas modales y no modales deben usarse solo cuando aporten claridad al flujo.

## Regiones y diseno
- Usar regiones para organizar formularios, tablas, filtros y secciones funcionales.
- Los nombres de regiones deben ser claros y descriptivos.
- Usar regiones de contenido estatico para agrupar componentes relacionados cuando mejore orden y mantenibilidad.
- Toda pagina normal cuyo contenido permita crear, consultar o mantener un registro mediante items de formulario debe tener en `Content Body` una unica region padre de formulario que abarque todos sus items, subregiones, tablas, reportes y grillas funcionales. Breadcrumb y `Barra de acciones` permanecen fuera de esa region en sus posiciones corporativas.
- Las regiones funcionales de `Content Body` no pueden quedar como hermanas sueltas de la region de formulario. Deben ser hijas directas o descendientes de la misma region padre, con jerarquia verificable mediante `Parent Region` o metadata equivalente.
- La regla de region padre no obliga a envolver paginas exclusivamente de consulta que no tengan formulario ni a los dialogos; esos casos deben usar la estructura corporativa correspondiente a su tipo y justificar cualquier agrupacion diferente en la comparacion con el patron de referencia.
- Las acciones principales de la pagina deben concentrarse en una barra de acciones coherente.
- Los filtros principales deben ubicarse de forma visible antes del resultado cuando controlen carga de datos.

## Reportes y grillas
- No usar `Classic Report`.
- Las fuentes SQL de regiones, LOV, procesos y acciones dinamicas no pueden usar `SELECT *` ni `alias.*`; deben listar solo las columnas realmente consumidas, con alias estables cuando aplique. `COUNT(*)` permanece permitido para contar filas.
- Toda pagina de consulta o listado debe usar `Interactive Report`.
- El `Interactive Report` debe quedar con opciones de busqueda y descarga de informacion.
- Toda region que represente una tabla, listado, `Interactive Report` o `Interactive Grid` debe usar el template de region `Zaimella Tabla`.
- El nombre visible de la region de tabla debe definirse en el titulo propio de la region, con un nombre funcional que describa su contenido. No usar `Header Text`, `p_plug_header` ni HTML manual para repetir, reemplazar o simular ese titulo; el Header Text debe permanecer vacio.
- Las acciones personalizadas por fila o dentro del toolbar de una tabla, reporte o grilla deben mostrarse solo como iconos. Queda prohibido renderizar enlaces o botones con texto visible como `Editar`, `Eliminar`, `Ver` o equivalentes dentro de la tabla.
- Cada accion de tabla debe tener icono semantico y nombre accesible mediante `title`, `aria-label`, texto alternativo o atributo APEX equivalente. Un icono sin descripcion accesible no cumple.
- Los nombres de columnas visibles deben ser claros, cortos dentro de lo posible y con palabras completas.
- No se permiten abreviaturas ambiguas o recortes funcionales en columnas visibles como `Est`, `Ob`, `Nom Repr`, `F. Suscrip` o similares.
- En columnas visibles se debe usar siempre un nombre funcional completo como `Estado`, `Observacion`, `Nombre Representante` o `Fecha Suscripcion`.
- Usar `Interactive Grid` solo cuando la experiencia requiera edicion de informacion sobre la tabla.
- Si la region no edita informacion, no debe implementarse como `Interactive Grid`.
- No usar `Interactive Grid - Automatic Row Processing (DML)` para logica de negocio.
- Si un `Interactive Grid` necesita guardar datos de negocio, la persistencia debe delegarse a paquetes de base de datos.
- Si un reporte consulta informacion extensa, debe incorporar filtros principales antes de cargar datos.
- Si una pagina se abre por redirect, boton, link, branch, dialogo o modal y contiene reportes, grillas o regiones con consultas pesadas que pueden demorar mas de `15` segundos, la pagina no debe bloquear su render inicial ejecutando esas consultas. Primero debe abrir la pantalla con titulo, filtros, barra de acciones y estructura visible; luego cargar las regiones pesadas de forma diferida.
- Para regiones pesadas, usar carga diferida cuando el componente lo permita, o una accion dinamica posterior al `Page Load` que refresque la region despues de que la pagina ya este visible. Si la consulta depende de filtros, la region debe iniciar vacia o con mensaje funcional y cargar solo al presionar `Buscar`, `Go`, `Aplicar` o accion equivalente.
- Las consultas pesadas no deben ejecutarse sin filtros minimos cuando el volumen pueda afectar la experiencia. Definir filtros obligatorios como fecha, compania, estado, cliente, documento u otro criterio funcional antes de permitir la carga.
- Durante la carga diferida o refresh de una region pesada debe existir indicador visual de procesamiento y salida de error controlada. Si se usa bloqueo global con `mostrarBarra();`, aplicar tambien la regla de `ocultarBarra();` en exito y error.
- La carga diferida mejora la experiencia, pero no reemplaza el tuning. Si una consulta supera `15` segundos, revisar SQL, plan, indices, joins, funciones en `WHERE`, DB links, vistas encadenadas y volumen; cuando aplique, evaluar cache, tabla staging, vista materializada o proceso previo.
- Toda consulta de listas, reportes o regiones APEX debe filtrar por compania con `:G_COMPANIA` cuando la fuente exponga `COMPANIA`.
- La edicion o gestion de registros desde reportes debe dirigir al flujo adecuado de formulario o dialogo cuando eso mejore control y trazabilidad.
- Si la operacion requiere validaciones, aprobaciones o reglas transaccionales, no debe resolverse solo con configuracion declarativa de APEX.

## Dialogos
- Los dialogos se deben usar para capturar o mostrar informacion adicional sin romper el flujo principal.
- El tipo de dialogo debe elegirse entre modal y no modal segun la necesidad funcional.
- Todo dialogo debe implementarse como pagina APEX independiente de tipo dialogo, preferentemente cercana a la pagina funcional que lo invoca y nombrada con prefijo `Dlg`.
- Queda prohibido simular o construir dialogos dentro de la misma pagina funcional mediante regiones ocultas, regiones inline, JavaScript, CSS, templates personalizados o mecanismos equivalentes, salvo autorizacion explicita del usuario y justificacion tecnica registrada.
- La pagina invocadora debe abrir el dialogo mediante redirect, link, boton o mecanismo APEX equivalente, y debe manejar el retorno con eventos como `Dialog Closed` cuando necesite refrescar regiones o recalcular informacion.
- Los dialogos no deben usar la region `Barra de acciones` ni el template `Zaimella Barra de Acciones`.
- Todo dialogo que tenga acciones finales debe agrupar sus botones en una region ubicada al final del contenido, normalmente llamada `Botones`, usando el template `Zaimella Grupo Botones`.
- Los botones principales del dialogo, como `Guardar`, `Salir`, `Cancelar`, `Regresar` o `Siguiente`, deben quedar dentro de esa region final y no dispersos en regiones intermedias del formulario.
- Los botones finales del dialogo, como `Guardar`, `Salir`, `Cancelar`, `Regresar`, `Aceptar` o `Siguiente`, deben usar template de boton `Text`, con etiqueta visible para el usuario, sin `Icon CSS Classes`, `p_button_position=>'BELOW_BOX'` y `p_button_alignment=>'RIGHT'`. No deben usar template `Icon`, no deben mostrarse solo como iconos y no deben separarse ubicando un boton final a la izquierda y otro a la derecha.
- Los botones auxiliares propios de una region interna, como acciones de carga o control de una grilla, pueden vivir dentro de su region solo cuando responden a esa seccion puntual y no reemplazan a los botones finales del dialogo.
- Los botones auxiliares internos deben usar template `Icon` cuando representen una accion puntual de su region, por ejemplo descargar, subir, vaciar, seleccionar o abrir detalle dentro de una grilla o subregion. Deben mostrarse sin texto visible y conservar `p_button_image_alt` claro y `p_icon_css_classes` descriptivo. Si la accion no es auxiliar, debe trasladarse a la region final de botones y aplicar el patron `Text` del dialogo.
- Los botones de dialogo deben estar agrupados de forma consistente y visible.

Patron esperado para botones finales de dialogo:

```sql
-- Boton final secundario, por ejemplo Cancelar, Salir o Regresar.
,p_button_template_id=>wwv_flow_imp.id(<TEMPLATE_TEXT>)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'

-- Boton final principal, por ejemplo Guardar o Aceptar.
,p_button_template_id=>wwv_flow_imp.id(<TEMPLATE_TEXT>)
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
```

## Items y componentes
- Elegir el tipo de item segun volumen y forma de uso de la informacion.
- En pantallas tipo formulario, normales o dialogo, los componentes visibles de captura o consulta deben distribuirse en dos columnas, con maximo dos componentes por fila.
- Esta regla aplica a componentes como `Select List`, `Popup LOV`, `Modal LOV`, `Text Field`, `Number Field`, `Date Picker`, `Display Only`, `Radio Group` y equivalentes que muestran o capturan informacion.
- No se deben dejar tres o mas componentes visibles de formulario en una misma fila, salvo excepcion funcional claramente justificada y documentada.
- Cuando el componente sea `Textarea` o `Rich Text Editor` para capturar informacion amplia, debe ocupar una fila propia a ancho completo en una sola columna visual.
- `Select List` para listas pequenas, cerradas y de bajo crecimiento, preferentemente estaticas o catalogos controlados con pocos valores. Ejemplos: estado, rol fijo, tipo fijo o opciones que no creceran por operacion normal del negocio.
- No usar `Select List` para catalogos transaccionales o maestros que viven en tablas y pueden crecer por uso normal, aunque hoy tengan pocos registros en TEST. Ejemplos: personas, clientes, proveedores, empleados, productos, articulos, documentos, contratos o entidades similares.
- `Popup LOV` para catalogos de tabla que pueden crecer y requieren busqueda simple por nombre, codigo, identificacion o descripcion.
- `Modal LOV` para busquedas mas complejas, con varias columnas relevantes, filtros adicionales, necesidad de comparar datos antes de seleccionar o volumen alto.
- Antes de elegir el componente de lista, evaluar origen de datos, crecimiento esperado, cantidad aproximada de registros, campos por los que el usuario buscara y si necesita ver mas de una columna para seleccionar correctamente.
- Para cada `Select List` alimentado por SQL, dejar evidencia de que el catalogo es pequeno, cerrado y de bajo crecimiento. La evidencia debe identificar origen, cantidad aproximada o medida, crecimiento esperado y motivo por el que no requiere busqueda; sin esa evidencia el componente no supera la auditoria pre-TEST.
- Todo `Popup LOV` debe permitir buscar por los identificadores funcionales necesarios para reconocer el registro, por ejemplo nombre, codigo, identificacion o descripcion. Usar `Modal LOV` cuando una sola descripcion no permita distinguir opciones o el usuario necesite filtros y varias columnas para decidir.
- Si el item es obligatorio y usa `Select List`, debe tener una opcion nula visible como `Seleccione <dato>` cuando exista riesgo de seleccion accidental del primer valor.
- Reutilizar LOVs y componentes compartidos antes de crear nuevos.
- Las LOV que consuman mas de una tabla deben apoyarse en vistas o consultas controladas.
- Evitar listas estaticas cuando el valor deba mantenerse desde base de datos.
- Todo label visible al usuario debe ser claro, estar en espanol y describir el dato esperado.
- No se permiten labels en blanco ni labels con textos genericos como `NEW`.

## Archivos y adjuntos
- El manejo de archivos debe usar componentes y procesos reutilizables definidos por la arquitectura vigente.
- El almacenamiento temporal y procesamiento de archivos debe seguir el patron corporativo aprobado.
- No crear soluciones ad hoc para adjuntos si ya existe un mecanismo compartido.
- Las reglas detalladas para adjuntos se documentan en [`references/estandares-adjuntos-apex.md`](./estandares-adjuntos-apex.md).

## Cargas masivas
- El patron corporativo para cargas masivas desde Excel o CSV es la aplicacion `100`, pagina `300`.
- Distinguir capacidad tecnica de lectura y formato funcional de plantilla: que el cargador pueda leer Excel o CSV no significa que ambos formatos deban ofrecerse al usuario final como plantilla principal.
- La plantilla que debe llenar el usuario final debe entregarse preferentemente en formato `.xlsx`.
- El formato `.csv` queda como alternativa tecnica o de integracion, no como plantilla principal para usuario final, salvo justificacion explicita registrada.
- Si se entrega o acepta `.csv`, documentar separador esperado, codificacion, ejemplo y riesgo de configuracion regional de Excel/Windows.
- La plantilla `.xlsx` debe incluir encabezados en la primera fila, nombres claros de columnas y, cuando aplique, una fila de ejemplo o instrucciones de llenado fuera del area que se procesara.
- La pagina `100/300` debe usarse como cargador generico de archivos y no como pagina final de negocio.
- La responsabilidad de `100/300` es recibir el archivo, transformarlo a una coleccion temporal, exponer una previsualizacion y entregar el control a la pagina invocadora.
- La logica funcional de validacion de datos y la persistencia final no deben ejecutarse en `100/300`; deben ejecutarse en la pagina invocadora o en paquetes de base de datos.
- Gate no negociable: queda prohibido agregar en cualquier página, proceso compartido, componente, JavaScript, SQL o configuración de la aplicación `100` condiciones, llamadas PL/SQL, ramas, items o referencias que dependan de un `APP_ID/PAGE_ID`, módulo, tabla, paquete o caso de negocio de una aplicación invocadora. Esta prohibición incluye ejecutar un paquete de negocio antes de cerrar un diálogo para conservar una colección de sesión. Un `AGENTS.md`, contrato de tarea o instrucción local no puede exceptuarla; si la contradice, prevalece este estándar y se debe corregir el cambio.
- Si una aplicación invocadora no puede leer la colección creada por `100/300` al retornar, implementar un handoff genérico en la infraestructura de `100`: conserva archivo/datos temporales con un identificador opaco de carga y devuelve ese identificador; la página invocadora y su paquete de negocio consumen el identificador y ejecutan allí la validación/persistencia. El handoff no puede conocer ni ramificar por la aplicación invocadora.
- El flujo de carga masiva debe consumir la vista `DATA.VT_APEX_EXCEL` como fuente de lectura de la informacion cargada.
- `DATA.VT_APEX_EXCEL` lee la coleccion APEX `TABLA_EXCEL` de la sesion actual. Su columna `ID` es el `SEQ_ID` interno del miembro de la coleccion y no debe usarse como dato de negocio.
- En la implementacion vigente de `100/300`, `VT_APEX_EXCEL.C01` esta reservado para el numero de fila del archivo origen. No representa la primera columna del Excel ni del CSV.
- Las columnas de datos del archivo empiezan en `VT_APEX_EXCEL.C02`: `C02` corresponde a la columna A del Excel o al primer campo del CSV, `C03` a la columna B o segundo campo, y asi sucesivamente hasta `C50`.
- Por ese desplazamiento, la pagina invocadora debe mapear sus columnas de negocio desde `C02` en adelante. Queda prohibido interpretar `C01` como dato funcional salvo que el requerimiento pida explicitamente usar el numero de fila para trazabilidad, errores o auditoria.
- Si la carga usa cabecera, `100/300` toma la primera fila para etiquetas de previsualizacion y la elimina de la coleccion; la pagina invocadora recibe solo filas de datos, pero `C01` conserva el numero de fila original del archivo.
- Preflight obligatorio para toda carga desde `DATA.VT_APEX_EXCEL`: antes de escribir o modificar el mapeo del paquete/página invocadora, inspeccionar en TEST una muestra de la colección y contrastarla contra la plantilla Excel/CSV. Documentar en la tarea la matriz `columna de negocio -> VT_APEX_EXCEL.C0n`, incluyendo que `C01` es fila origen y que el primer dato es `C02`. No compilar/importar ni ejecutar una carga con posiciones inferidas por nombre, memoria o desplazamiento supuesto.
- Gate de implementación: un paquete que consuma `VT_APEX_EXCEL` debe usar `C02` o superior para todo dato de negocio; `C01` solo puede usarse para trazabilidad/error de fila. Si el primer valor de una muestra es un consecutivo de fila, detenerse, corregir el mapeo y repetir la validación antes/después; nunca atribuir la carga cero o una actualización fallida a la colección sin verificar primero este desplazamiento.
- Si el problema aparece en la conversion o lectura de entradas, archivos o datos externos, la correccion debe hacerse en el convertidor, parser, normalizador o componente compartido que interpreta el formato. No crear reglas posteriores por instancia puntual para compensar un defecto de conversion.
- Cuando el archivo tenga cabecera, la primera fila debe tratarse como encabezado y no como dato de negocio.
- El cargador corporativo de `100/300` trabaja unicamente con la hoja `1` en archivos Excel.
- El cargador corporativo de `100/300` expone `C01..C50` en `VT_APEX_EXCEL`, pero por el uso de `C01` como numero de fila la capacidad de datos de negocio disponible para la pagina invocadora es `C02..C50` hasta `49` columnas. Si un requerimiento necesita 50 columnas de negocio, debe ajustarse el cargador compartido o definirse una excepcion aprobada; no se debe forzar el uso de `C01` como primera columna.
- El boton `Siguiente` debe usarse solo para retornar a la pagina invocadora y continuar la validacion o procesamiento.
- El boton `Siguiente` solo debe estar disponible cuando el flujo haya enviado pagina destino y parametros de retorno validos.
- La pagina invocadora es responsable de validar estructura, columnas esperadas, tipos de dato, reglas funcionales y mensajes al usuario antes de grabar.
- No se deben crear cargadores masivos nuevos por modulo si el requerimiento puede resolverse con el patron corporativo de `100/300`.
- Si un requerimiento de carga masiva necesita una variacion, primero debe justificarse por que el patron `100/300` no cubre la necesidad.

## JavaScript
- La logica JavaScript simple puede vivir en la pagina cuando sea breve y clara.
- La logica JavaScript compleja debe moverse a archivos `.js` reutilizables de la aplicacion.
- No dejar bloques grandes de JavaScript incrustados si afectan mantenibilidad.
- No duplicar funciones JavaScript en varias paginas si pueden centralizarse.

## Processing
- Los procesos deben tener nombres descriptivos.
- No deben contener codigo comentado innecesario.
- Si la logica es extensa, dividir en varios procesos claros o moverla a paquetes.
- Toda transaccion de negocio debe ejecutarse a traves de procedimientos o funciones de paquetes.
- Los procesos no deben contener `INSERT`, `UPDATE` o `DELETE` directos de negocio.
- Si un proceso solo coordina llamada a paquete, su responsabilidad debe quedar clara en el nombre y en el codigo.
- Toda eliminacion iniciada por el usuario desde una pagina APEX debe solicitar confirmacion antes de ejecutar cualquier submit, Ajax, PL/SQL, DML, cambio de estado o navegacion que materialice la accion. Esto aplica a eliminacion fisica o logica y a acciones equivalentes como borrar, retirar o desvincular un registro.
- El mensaje visible de confirmacion debe ser exactamente `¿Está seguro de eliminar el registro?`.
- La confirmacion debe pertenecer a cada boton, accion de fila, link, submit o accion dinamica destructiva; no cumple una confirmacion generica sin asociacion verificable con la accion que elimina.
- Usar preferentemente la confirmacion declarativa nativa de APEX (`NATIVE_CONFIRM` o `p_confirm_message`). `apex.message.confirm` se admite cuando el flujo requiera JavaScript, siempre que la eliminacion se invoque unicamente despues de que el callback confirme la aceptacion. No usar una confirmacion posterior al inicio del proceso destructivo.
- Al cancelar la confirmacion no debe ejecutarse el proceso, enviarse la pagina, invocarse Ajax/PLSQL, modificarse sesion ni alterarse el registro. Al aceptar, el flujo puede continuar y debe conservar sus controles de autorizacion, precondiciones, resultado y error; la confirmacion no sustituye esos controles.
- Toda accion iniciada desde APEX que ejecute un proceso, validacion, cambio de estado, guardado, aprobacion, rechazo, carga, eliminacion o cualquier operacion relevante para el usuario debe mostrar un mensaje claro de exito o de error.
- No basta con ejecutar la accion correctamente en backend; el resultado debe quedar visible para el usuario en la interfaz.
- Los mensajes deben ser cortos, claros y entendibles para el usuario final.
- Toda accion que pueda demorar y sea iniciada por boton, submit, accion dinamica, proceso PL/SQL, Ajax, guardado, aprobacion, rechazo, carga, eliminacion, calculo o sincronizacion debe bloquear visualmente la pantalla o el flujo afectado para que el usuario sepa que el sistema esta procesando y no vuelva a presionar controles.
- El patron corporativo vigente para bloqueo visual en aplicaciones con tema `Zaimella` es llamar `mostrarBarra();` antes del proceso y `ocultarBarra();` al finalizar, usando la funcion compartida de `js/zaimella.js` que muestra `apex.widget.waitPopup()`.
- Si el flujo termina con submit o navegacion inmediata, esa navegacion puede cerrar el bloqueo; si el flujo continua en la misma pantalla, debe ejecutarse `ocultarBarra();` despues de procesos y refrescos.
- Si el proceso puede fallar y se controla el error en items, respuestas Ajax o acciones de error, el flujo debe mostrar mensaje de error y retirar el bloqueo antes de dejar visible el error. No se debe dejar la pantalla bloqueada indefinidamente ni con el mensaje de error oculto por debajo del `waitPopup`.
- Cuando se use `mostrarBarra();`, el desarrollo debe contemplar salida de error: `ocultarBarra();` en `finally`, en manejadores `catch`, en acciones dinamicas de error o en la respuesta Ajax/PLSQL controlada, segun el patron usado. Un error JavaScript o PL/SQL no debe dejar al usuario sin posibilidad de continuar.

## Dynamic Actions
- Las acciones dinamicas deben tener nombres descriptivos.
- No deben contener codigo comentado innecesario.
- Si una accion dinamica requiere logica extensa, se debe dividir o mover la logica a JavaScript reutilizable o a paquetes segun corresponda.
- Toda transaccion de negocio disparada desde una accion dinamica debe ejecutarse a traves de paquetes.
- No usar acciones dinamicas para reemplazar procesos transaccionales complejos.
- Usar acciones dinamicas para comportamiento de interfaz, validaciones ligeras y orquestacion de eventos.
- Si una accion dinamica ejecuta una operacion relevante para el usuario, debe dejar tambien un mensaje claro de exito o de error y no terminar en silencio.
- Para acciones dinamicas con proceso PL/SQL o Ajax que deben terminar antes de refrescar regiones, calcular datos, mostrar mensajes o continuar con otra accion, configurar `Wait For Result = Yes`.
- El orden recomendado es: `mostrarBarra();`, proceso PL/SQL/Ajax con espera de resultado cuando aplique, refrescos o actualizaciones visuales, mensaje de exito/error, y `ocultarBarra();` si la pagina no navega ni hace submit.
- Si una accion dinamica tiene `mostrarBarra();`, debe definir tambien la ruta de error que cierre el bloqueo antes de mostrar o dejar visible el error. Para errores JavaScript usar `try/catch/finally` cuando aplique; para procesos PL/SQL/Ajax usar acciones de error, respuestas controladas o manejadores Ajax que ejecuten `ocultarBarra();`.
- Si una accion dinamica usa `mostrarBarra();` y luego ejecuta un proceso sin `Wait For Result = Yes`, debe estar justificado porque el proceso es asincronico real y el usuario no depende del resultado inmediato; de lo contrario el bloqueo puede ocultarse antes de que termine el proceso.

## Reutilizacion
- Reutilizar LOVs, catalogos, plugins y componentes comunes antes de crear nuevos.
- Reutilizar paquetes existentes si ya cubren la necesidad funcional.
- Los plugins corporativos o aprobados deben tomarse desde la aplicacion `100` cuando aplique.
- Antes de crear una nueva pagina, validar si el flujo ya existe en la aplicacion o en otra aplicacion corporativa reutilizable.

## Parametros por ambiente y URLs
- Queda prohibido hardcodear URLs absolutas, hosts, puertos, dominios, rutas base APEX o endpoints internos/externos en procesos APEX, branches, botones, links, acciones dinamicas, JavaScript, SQL, PL/SQL o paquetes de negocio.
- Ninguna URL APEX concreta puede quedar fija en código funcional porque cambia entre TEST y PRODUCCIÓN; usar el parámetro externo de ambiente correspondiente.
- Las URLs, endpoints, rutas base y parametros que cambian por ambiente deben parametrizarse en `DATA.T_CORP_UDC` o en una tabla general corporativa aprobada, consumida por una vista funcional y/o paquete de configuracion.
- APEX no debe leer `DATA.T_CORP_UDC` directamente desde paginas o procesos. Debe consumir una vista `DATA.VT_<MODULO>_<SECCION>` o una funcion de paquete que devuelva la URL vigente para el ambiente, compania y clave funcional.
- Antes de implementar una URL parametrizada, el agente debe pedir al usuario la URL de TEST y la URL de PRODUCCION, salvo que ambas ya existan y esten confirmadas en la configuracion vigente.
- En TEST se debe insertar o actualizar el valor de TEST. Para el pase a PRODUCCION, el script `02_datos_configuracion.sql` debe insertar o actualizar el valor productivo correspondiente, no copiar ciegamente el valor de TEST.
- Si el usuario aun no conoce la URL productiva, el desarrollo puede quedar con configuracion TEST y el pase debe marcar `Pendiente URL PRODUCCION`; no se debe inventar ni asumir la URL productiva.
- Si se detecta una URL hardcodeada existente durante una correccion, debe registrarse hallazgo tecnico y, si esta dentro del alcance, reemplazarse por parametro UDC antes de recomendar pase.
- Las URLs de navegacion interna APEX deben construirse con mecanismos APEX relativos o con la base parametrizada, evitando hosts absolutos. Para links entre paginas de la misma aplicacion, preferir `f?p=&APP_ID.:PAGE:&SESSION.` o helpers APEX antes que URL absoluta.
- Las URLs usadas solo como configuracion local de QA, documentacion de login o ejemplos operativos no son codigo funcional, pero no deben copiarse a paquetes, procesos o branches como constantes de negocio.

## Trazabilidad y depuracion
- Toda operacion critica iniciada desde APEX debe poder rastrearse en base de datos.
- Los errores funcionales y tecnicos deben registrarse con mecanismos estandar definidos por el equipo.
- Los mensajes de exito y error deben mostrarse de forma consistente en toda la aplicacion.
- El agente debe evitar soluciones APEX que dificulten identificar en que pagina, proceso o accion se produjo un error.
- Cada vez que se realice un cambio en el ambiente de test, el agente debe ejecutar el despliegue correspondiente para que el usuario pueda realizar pruebas funcionales sobre el cambio aplicado.

## Gate De Auditoria Pre-TEST

Antes de declarar la entrega tecnica completa, auditar cada pagina, dialogo o flujo visible/funcional creado o modificado. La auditoria no se sustituye con compilacion, import exitoso, apertura de pagina ni una prueba aislada de botones.

- Producir evidencia tecnica auditable con el resultado por cada destino. El skill no decide la ruta, plantilla, ID de tarea ni mecanismo de coordinacion; usa el destino que entregue el contexto que lo invoca o devuelve la evidencia en su salida tecnica.
- Completar una fila por cada destino del inventario; no auditar solo la pagina principal cuando el flujo incluye dialogos, auxiliares, reportes o paginas intermedias.
- Comparar paginas nuevas o reestructuradas contra una pagina corporativa vigente del mismo tipo. Registrar templates, posiciones, regiones, botones, componentes y diferencias justificadas. `Se parece a` o citar un PAGE_ID sin matriz comparativa no es evidencia.
- Revisar como minimo: titulo y breadcrumb; barra, posicion, template, icono y accesibilidad de cada accion; region padre y jerarquia de `Content Body`; nombre, template, Header Text y acciones de cada tabla; tipo de reporte/grilla; decision documentada de cada `Select List`, `Popup LOV` o `Modal LOV`; compania y autorizacion; condiciones y claves previas; dialogos y retorno; refresh; paquetes; mensajes; responsive y resultado funcional.
- Ejecutar `python scripts/validate_apex_page_standards.py <ARCHIVO_O_CARPETA>` sobre los exports del alcance. Un resultado `FAIL` impide integrar en TEST. El validador es complementario: un `PASS` no reemplaza la auditoria manual ni demuestra cumplimiento funcional.
- Toda asociacion o accion dependiente de una cabecera, identificador, estado, permiso o dato previo debe permanecer oculta, deshabilitada o rechazada con mensaje claro hasta cumplir su precondicion. Documentar la condicion y probar el estado anterior y posterior.
- Queda prohibido inventar una compania por fallback literal cuando falta `:G_COMPANIA`. Las cargas, consultas y operaciones deben validar el contexto de compania y evitar acceso por identificador sin aislamiento equivalente.
- Si el alcance crea o modifica tres o mas paginas, o combina APEX con objetos Oracle, confirmar que la especificacion OpenSpec vigente cubre el inventario real antes de integrar. Una especificacion historica con paginas u objetos distintos no satisface el gate.

### Reconciliacion Fuente, TEST Y Candidato

- Importar en TEST exclusivamente desde un commit candidato identificado.
- Exportar desde TEST las paginas modificadas con el exportador oficial y comparar su metadata funcional contra la fuente candidata.
- No exigir igualdad binaria ciega: APEX puede normalizar formato o generar metadata. Clasificar cada diferencia como normalizacion sin efecto o diferencia funcional.
- Toda diferencia funcional valida se reconcilia al repositorio y produce un nuevo commit candidato. Reimportar ese candidato final en TEST y repetir las validaciones afectadas.
- Antes de entregar el resultado tecnico, la fuente Git, la evidencia de importacion y TEST deben identificar el mismo candidato. Si no puede demostrarse, reportar `No conforme por version no verificable` con la evidencia disponible; el contexto invocador decide estado y siguiente fase.

## Publicacion en Test
- La publicacion de cambios APEX en TEST debe ejecutarse sobre el archivo export `.sql` vigente de la aplicacion.
- Antes de publicar, validar conectividad con `python scripts/validate_oracle_connectivity.py --environment test`; solo ejecutar `. .\scripts\set-oracle-env.ps1 -CreateDefaultIfMissing` si el validador reporta variables faltantes.
- El metodo preferido para generar export es `python scripts/apex_export_sql_via_python.py --application-id <APP_ID> [--page-id <PAGE_ID>] --environment test --output <ruta_export.sql>`.
- El metodo preferido de publicacion en este contexto es `python scripts/import_apex_sql_via_python.py <ruta_export.sql>`.
- No probar `SQLcl`, `sqlplus.exe` ni clientes Oracle alternativos como parte normal de publicacion. Si el importador Python falla por preparacion de herramientas, reportar el error exacto y pedir autorizacion explicita antes de cambiar de herramienta.
- Si el import finaliza sin errores SQL bloqueantes, el cambio debe considerarse publicado.
- Despues de publicar, el agente debe validar en metadata APEX que las paginas o componentes modificados reflejen el cambio esperado antes de informar al usuario que ya puede probar.

## Publicacion en Produccion
- El agente puede publicar aplicaciones o paginas APEX en produccion cuando el usuario lo pida o el alcance aprobado lo incluya.
- Antes de publicar en produccion, intentar backup/export productivo de la aplicacion o paginas afectadas y guardarlo en el paquete de pase.
- Si el backup/export productivo por API falla con `ORA-20987` o privilegios insuficientes, no bloquear automaticamente. Si el export desde TEST esta verificado, el import productivo esta habilitado y el alcance esta autorizado, continuar con el import y registrar como evidencia: error del backup API, ruta/hash/fecha del export TEST, APP_ID, workspace, paginas incluidas, usuario productivo y log del import.
- El origen debe ser TEST: generar export desde TEST con el mecanismo disponible o usar un export vigente verificado contra TEST, registrando APP_ID, workspace, paginas incluidas, fecha y metodo.
- La publicacion en produccion debe ejecutarse con la credencial autorizada parametrizada en `ZAIMELLA_ORACLE_PROD_*`, sin guardar ni redescubrir usuarios, contrasenas, hosts, SID o URLs en scripts, bitacoras, logs ni repositorio.
- Metodo Python de export: `python scripts/apex_export_sql_via_python.py --application-id <APP_ID> [--page-id <PAGE_ID>] --environment test --output <ruta_export.sql>`.
- Metodo Python de backup/export productivo: `python scripts/apex_export_sql_via_python.py --application-id <APP_ID> [--page-id <PAGE_ID>] --environment prod --output <ruta_backup.sql>`.
- Metodo Python de import: `python scripts/import_apex_sql_via_python.py <ruta_export.sql> --environment prod`.
- Para pases de TEST a produccion, el exportador Python excluye por defecto reportes guardados de Interactive Report publicos, privados y notificaciones. No activar `--with-ir-public-reports`, `--with-ir-private-reports` ni `--with-ir-notifications` salvo que el usuario pida migrar esos reportes; incluirlos puede provocar `ORA-00001` sobre `APEX_240100.WWV_FLOW_WORKSHEET_RPTS_UK` durante `import_end`.
- Si un import completo de aplicacion falla en `import_end` con `ORA-00001` y constraint `WWV_FLOW_WORKSHEET_RPTS_UK`, confirmar que existe backup/export productivo, ejecutar el import con `--pre-remove-application --cleanup-orphan-ir-reports` y repetir desde el export TEST. Esa opcion hace `remove_flow` confirmado y elimina solo reportes IR residuales de la misma app antes del import. No asumir que el problema es conexion Oracle ni que la app no se puede publicar.
- El importador Python lee `p_default_workspace_id` y `p_default_owner` del export y fija contexto APEX antes de cada bloque. Esto evita el error `Package variable g_security_group_id must be set` durante `wwv_flow_imp_page.remove_page`.
- El exportador Python detecta el esquema APEX activo, lee `WORKSPACE_ID` desde `APEX_APPLICATIONS` y fija workspace con `<APEX_SCHEMA>.WWV_FLOW_SECURITY.SET_G_SECURITY_GROUP_ID(<WORKSPACE_ID>)` antes de llamar `APEX_EXPORT.GET_APPLICATION`.
- Para export o import APEX por API, usar el workspace literal confirmado por metadata con `<APEX_SCHEMA>.WWV_FLOW_SECURITY.SET_G_SECURITY_GROUP_ID(<WORKSPACE_ID>)`. No usar `APEX_UTIL.SET_SECURITY_GROUP_ID` ni `APEX_UTIL.FIND_SECURITY_GROUP_ID` como sustituto si ya se comprobo que devuelven `ORA-20987` en esa sesion.
- Metodo alterno con cliente Oracle local solo bajo autorizacion explicita del usuario y despues de registrar por que el importador Python no aplica. No descubrir ni probar clientes alternativos por rutina.
- Despues de importar, validar metadata APEX y abrir las paginas afectadas en produccion para pruebas pequenas con datos controlados/no sensibles.
- No responder que el skill no puede completar el pase tecnico APEX cuando existen acceso, export autorizado y alcance aprobado; si falla una herramienta, cambiar al metodo alterno documentado y reportar `Impedimento tecnico` solo si ambos caminos no son viables. El contexto decide el estado de la tarea.
- No hacer rondas repetidas de validacion antes de importar si ya se confirmo: export TEST correcto, conexion productiva, `CURRENT_SCHEMA=DATA` o esquema esperado, y metodo de import habilitado.

## Seguridad
- La autenticacion debe seguir el esquema centralizado de la aplicacion `100`.
- Los accesos y flujos de aprobacion se regiran por las reglas corporativas vigentes.
- Las reglas detalladas de accesos y aprobaciones se documentan en [`references/estandares-accesos-apex.md`](./estandares-accesos-apex.md).
