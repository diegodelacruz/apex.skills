# Diccionario ERP 00001 Ecuador

## Objetivo
Registrar tablas, vistas, campos y objetos internos usados sobre el ERP JDE para la compania `00001`.

## Regla de consulta
- Busca primero aqui cuando el requerimiento involucre ERP de Ecuador.
- Si el objeto no aparece aqui, valida luego en la fuente oficial de JDE o en la metadata remota accesible por `@jdedtadl`.

## Forma de registrar

```md
### <NOMBRE_TECNICO>
- `ERP:` JDE
- `Compania:` 00001
- `Tipo de objeto:` tabla | vista | campo | paquete | proceso | otro
- `Nombre tecnico:` <nombre exacto>
- `Es estandar ERP:` si | no | pendiente_validar
- `Origen de validacion:` fuente oficial | JDE directa | desarrollo interno documentado | otro
- `Descripcion funcional:` <que hace o que representa>
- `Observaciones tecnicas:` <joins, dblink, restricciones, notas de uso>
```

## Registros iniciales

Pendiente de poblar.
