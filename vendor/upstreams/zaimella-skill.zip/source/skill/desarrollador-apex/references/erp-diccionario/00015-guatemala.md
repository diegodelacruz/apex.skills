# Diccionario ERP 00015 Guatemala

## Objetivo
Registrar tablas, vistas, campos y objetos internos usados sobre el ERP SAP para la compania `00015`.

## Regla de consulta
- Busca primero aqui cuando el requerimiento involucre ERP de Guatemala.
- Si el objeto no aparece aqui, valida en el puente por `@HANA_ABX`.
- Si no queda resuelto en el puente, valida en la fuente oficial o en la conexion HANA configurada para la compania.

## Forma de registrar

```md
### <NOMBRE_TECNICO>
- `ERP:` SAP
- `Compania:` 00015
- `Tipo de objeto:` tabla | vista | campo | paquete | proceso | otro
- `Nombre tecnico:` <nombre exacto>
- `Es estandar ERP:` si | no | pendiente_validar
- `Origen de validacion:` fuente oficial | puente DATA | HANA directa | desarrollo interno documentado | otro
- `Descripcion funcional:` <que hace o que representa>
- `Observaciones tecnicas:` <joins, dblink, restricciones, notas de uso>
```

## Registros iniciales

Pendiente de poblar.
