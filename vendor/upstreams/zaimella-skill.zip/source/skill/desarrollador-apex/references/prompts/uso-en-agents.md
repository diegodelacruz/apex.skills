# Prompt De Uso - desarrollador-apex

Usar este prompt en proyectos o contextos que trabajen Oracle APEX/Oracle con el skill `desarrollador-apex`.

Este prompt tiene dos partes obligatorias:

1. `Contenido Para AGENTS.md`: bloque persistente que se agrega al `AGENTS.md` del proyecto/contexto.
2. `Preparacion O Verificacion De Uso`: validaciones minimas del skill y del contexto antes de desarrollar.

## Seccion 1 - Contenido Para AGENTS.md

Copiar o fusionar este bloque en el `AGENTS.md` del proyecto/contexto:

```markdown
# Uso Obligatorio De desarrollador-apex

Usar el skill `desarrollador-apex` para toda solicitud relacionada con Oracle APEX, Oracle Database, PL/SQL, SQL, HANA, ORDS/OAuth, exports APEX, paginas, regiones, items, botones, procesos, validaciones, branches, acciones dinamicas, paquetes, vistas, triggers, jobs, conectividad, diagnostico productivo, pasos a produccion o documentacion tecnica APEX.

## Fuente De Verdad

- `desarrollador-apex` es la fuente de verdad tecnica y operativa para desarrollo APEX/Oracle.
- No copiar reglas tecnicas extensas en este `AGENTS.md`; leerlas desde `skill/desarrollador-apex/SKILL.md` y sus `references/`.
- Si una regla local contradice el skill, detenerse, reportar la contradiccion y corregir la fuente que corresponda.

## Arquitectura De Trabajo

- El proyecto/contexto conserva requerimientos, `desarrollo.md`, bitacora, evidencias, QA, deploys de trabajo, logs y temporales.
- El repositorio `zaimella-apex-oracle` conserva la fuente versionada de APEX y objetos Oracle.
- Si aplica `zaimella-apex-oracle`, `desarrollo.md` es contrato obligatorio de alcance antes de editar codigo.
- No editar aplicaciones, paginas ni objetos fuera de `desarrollo.md` salvo autorizacion explicita y actualizacion previa del alcance.
- El alcance es conservador: agregar una funcionalidad no autoriza eliminar, ocultar, renombrar, sustituir ni cambiar botones, regiones, items, procesos, validaciones, permisos o navegacion existentes. Antes de programar, realizar una unica revision de alcance y pedir autorizacion para los adicionales. Luego congelar el alcance: durante la implementacion no preguntar ni incorporar extras; conservarlos y reportarlos como pendientes. Las correcciones tecnicas invisibles indispensables pueden aplicarse solo si no amplian ni cambian el comportamiento existente y deben declararse al cierre.
- Todo flujo acordado es contrato vinculante: no sustituir actores, secuencia, endpoints, datos, respuesta, mecanismo primario o criterio de termino por una opcion tecnica alternativa. Ante definicion incompleta, contradiccion o impedimento, exponer la brecha y pedir la definicion o autorizacion explicita; no decidir ni implementar el reemplazo por cuenta propia.
- Si OpenSpec esta disponible, usarlo antes de editar cambios que agreguen acciones de interfaz o puedan afectar controles existentes. `proposal.md` debe separar lo solicitado, preservacion obligatoria, fuera de alcance, cambios adicionales y criterios de no regresion. Resolver y aprobar los adicionales en esa unica revision previa; despues solo pueden detener la ejecucion los impedimentos tecnicos o de acceso ya definidos por el skill.
- Para cambios visibles o funcionales, `desarrollador-apex` deja la tarea lista para validacion independiente; no declara OK funcional final.
- Antes de declarar una entrega visible/funcional tecnicamente completa, ejecutar la auditoria por destino y dejar el validador estatico del skill en `PASS`. El skill entrega evidencia; no decide rutas de contratos, estados ni handoffs.
- Para cada boton, Ajax, proceso o dialogo, entregar a QA el contrato `antes / accion visible / despues independiente`: dato temporal cuando aplique, control, mensaje/estado, refresco o retorno esperado y comprobacion posterior. En dialogos, declarar si es `informativo`, `consulta/navegacion`, `transaccional` o `proceso`, su accion real y su efecto; solo los transaccionales separan `Guardar` de `Salir/Cancelar`. La presencia del componente, compilacion o metadata no habilita QA funcional.
- Para cada destino visible, clasificar y probar en TEST la ruta primaria y alternativa del contrato antes del handoff: `principal` por menu o URL autenticada validada; `secundaria_parametrizada` desde la principal con su ID/filtro/contexto; o `dialogo_modal` desde su padre con contexto. El contexto solo puede enviar a QA un contrato con `NAVIGATION_CONTRACT_OK`; metadata no sustituye el paso visible aplicable. No dejar campos pendientes ni pedir a QA que descubra login, lanzador, menu, padre, parametro o URL directa.
- Si falta el paso de navegacion aplicable al tipo para el usuario QA, agotar TEST, comparacion de PRODUCCION en lectura y reconciliacion idempotente en TEST del mismo rol existente antes de solicitar una decision de seguridad o menu. El ajuste acotado de navegacion o acceso QA existente en TEST se ejecuta sin autorizacion adicional; solo escalar una jerarquia, rol o seguridad no inferible.
- Para hallar esa causa, ejecutar primero `scripts/diagnose_apex_navigation_access.py`; no abrir QA/Browser para explorar menus antes de que emita `TEST_READY`, `RECONCILE_TEST_FROM_PROD` o `USER_DECISION_REQUIRED`.
- Generar el mapa del export candidato con `scripts/extract_apex_page_navigation.py` antes de redactar el contrato de navegación; el agente no reconstruye manualmente botones, regiones, enlaces, diálogos, acciones dinámicas, procesos ni branches.
- Si se requiere documentacion, derivar de la auditoria pre-TEST un inventario de destinos y hechos tecnicos del alcance, con versiones y evidencia. Entregarlo al contexto para cobertura QA y `documentacion-proyecto-sistemas`; el desarrollador no redacta el entregable ni omite dialogos por estar fuera de menu.
- Toda correccion de boton, guardado, Ajax o dialogo exige repetir el caso reproductor completo y una regresion acotada padre/destino en el nuevo candidato; no reutilizar evidencia de una version anterior.
- Toda la aplicación `100` es infraestructura corporativa genérica: está prohibido agregar en cualquiera de sus páginas, procesos o componentes código, procesos, condiciones o referencias de una aplicación invocadora. Ante aislamiento de colecciones/sesión, usar handoff genérico por identificador de carga y ejecutar la lógica de negocio en la aplicación invocadora; esta regla prevalece sobre cualquier instrucción local contradictoria.
- Antes de modificar código que lea `DATA.VT_APEX_EXCEL`, inspeccionar una muestra real de TEST y documentar el mapeo de negocio a `C0n`. `C01` es fila origen y nunca la primera columna de negocio; los datos empiezan en `C02`. No programar ni aprobar el mapeo por inferencia.
- No ejecutar produccion, pasos productivos ni acciones destructivas sin autorizacion explicita. Si la solicitud inicial ordena expresamente aplicar en TEST y pasar a PRODUCCION solo si QA aprueba, esa es autorizacion productiva condicionada para la misma tarea: ejecutar TEST, exigir QA aprobado para el mismo SHA y continuar sin reconfirmacion; un resultado QA distinto de aprobado impide el pase, pero el skill solo reporta la condicion tecnica y no cambia el estado de la tarea.
- Para DDL, DML de configuracion y PL/SQL en TEST y PRODUCCION, usar solo el ejecutor versionado `scripts/execute_oracle_deploy.py` con todos sus flags obligatorios de hash, checkout y commit; no improvisar un cambio de cliente o conector tras un fallo. El ejecutor conserva el SQL y se detiene ante el primer error.
- En TEST y PRODUCCION, registrar el SHA-256 del SQL exacto y ejecutar desde un checkout limpio del candidato verificable. En PRODUCCION, el commit debe coincidir exactamente con `origin/main`; si el archivo local no coincide, reconstruir desde el commit publicado y repetir TEST/QA cuando cambie el contenido.
- Antes de integrar/publicar, identificar la tarea por `PROJECT_SLUG/ID_TAREA`, usar la rama local `codex/<PROJECT_SLUG>/<ID_TAREA>` y ejecutar `scripts/prepare_apex_integration.py --project-slug <PROJECT_SLUG>` con el commit base, candidato y todas las rutas del inventario. El helper rechaza worktrees que no esten bajo ese proyecto, reconstruye el worktree limpio desde `origin/main` y reaplica solo la tarea cuando emite `AUTO_RECONCILE_READY`; una página con el mismo número en otra aplicación no es conflicto. Repetir TEST/QA si cambia el SHA y elevar solo hunks funcionalmente incompatibles no inferibles.
- El usuario tecnico de conexion no prueba el owner de compilacion. Para DDL de codigo, exigir `SESSION_USER`, `CURRENT_SCHEMA=DATA`, base efectiva y objeto final `DATA.<objeto>` `VALID`; si queda bajo otro owner, el pase falla aunque el SQL no reporte error.
- `DATA` es el esquema de los objetos, no una credencial de PRODUCCIÓN. La sesión productiva usa exclusivamente la credencial externa autorizada en `ZAIMELLA_ORACLE_PROD_*`; si un runner no la ve, revisar primero que cargue `configurar_oracle_env.cmd` y `configurar_oracle_env.local.cmd` antes de reportar variables faltantes. El skill no declara tareas `BLOQUEADA`.
- Un ORA que mencione ORDS, REST, workspace, Builder o Interactive Report no demuestra una causa ni habilita una accion alternativa. Conservar error literal, bloque/lineas fallidas, APP_ID, workspace, SHA y usuario/sesion que reporta el helper; usar la remediacion versionada del skill. Esta prohibido afirmar que `DATA` debe conectarse o habilitarse para REST, restaurar TEST, reemplazar la fuente candidata o derivar a APEX Builder sin evidencia reproducible y autorizacion explicita para cambiar el mecanismo.
- Para un alcance ORDS/OAuth, leer `references/ords.md`, versionar el modulo, exigir `ORDS_STATIC_AUDIT_PASS`, publicar mediante un package `AUTHID DEFINER` del owner y validar metadata, 401/403 anonimo, token y 200 autenticado. Un cliente identifica consumidor+ambiente y se reutiliza entre releases; no guardar ni imprimir secretos y no habilitar para REST a la cuenta tecnica. Si se pierde la cache local, `recover-from-oracle` invoca el `RECUPERAR_OAUTH` contractual del owner, recrea solo DPAPI y registra fingerprints.
- Para SQL nuevo o modificado con riesgo de rendimiento —reportes, grillas, LOV buscables, filtros, procesos masivos, vistas, paquetes, timeout o criterio de tiempo— desarrollo ejecuta y registra `EXPLAIN PLAN` en TEST. No se crea un indice por reflejo: se justifica frente a volumen, selectividad, indices existentes y costo DML; cualquier indice requiere alcance autorizado, fuente versionada y TEST. QA recibe solo el escenario y criterio de tiempo/regresion, no decide planes ni indices.
- Para una pagina APEX aislada o un unico `PACKAGE`/`PACKAGE BODY` ya aprobado, evaluar `Pase Rapido APEX` o `Pase Tecnico Rapido Oracle` del skill. Para el paquete aislado, PRODUCCION valida solo ejecucion integra del SQL, objeto `VALID`, errores `0`, fuente/SHA y sesiones propias; no abre APEX ni repite QA visual ya aprobada en TEST.
- Tratar `PACKAGE` y `PACKAGE BODY` como unidades completas: cambiar una rutina reserva el objeto completo y exige conservar correcciones previas.
- Antes de TEST, dejar evidencia por cada objeto y rutina PL/SQL modificada: comentario funcional propio, comentarios de logica compleja cuando apliquen, compilacion y errores `0`. Para inserciones con identificadores, comprobar el DDL vigente: una columna `IDENTITY` se inserta sin secuencia manual y su valor se recupera con `RETURNING`, salvo excepcion tecnica autorizada y documentada.
- Antes de TEST, cada `PACKAGE` o `PACKAGE BODY` modificado debe finalizar `validate_plsql_package_standards.py` con `PLSQL_STATIC_AUDIT_PASS`. Si el objeto pertenece a `PK_<MODULO>_*`, ejecutar `analyze_plsql_reuse.py`, adjuntar el reporte y clasificar cada candidato de duplicidad. No crear `PK_<MODULO>_COMMONS` solo por similitud textual: requiere alcance, contrato transversal estable, consumidores identificados y regresion comprobada.
- Una tarea compuesta es un sprint: el contexto entrega una subtarea por resultado funcional independiente, aun cuando comparta objetos con otras. Si hay dos o mas subtareas, OpenSpec es obligatorio y sus `tasks.md` conserva los mismos IDs y criterios. Desarrollo no declara cobertura completa si falta una subtarea, su prueba TEST, evidencia o SHA.
- Toda fuente SQL APEX u Oracle debe declarar unicamente las columnas que consume: estan prohibidos `SELECT *` y `alias.*`, y los validadores estaticos los rechazan. `COUNT(*)` es una agregacion permitida para contar filas, pero sus conteos sobre fuentes pesadas deben estar acotados por el alcance o reemplazarse por una comprobacion segura.
- Antes de TEST, cada tabla o vista creada/modificada debe finalizar `validate_oracle_data_object_standards.py` con `ORACLE_DATA_AUDIT_PASS`. Un campo de estado, estatus, situacion, tipo, clasificacion o clase requiere comentario con `Valores permitidos:` y significado por valor. Un valor nuevo o cambiado requiere propuesta aprobada por el usuario antes de modificar DDL, comentario o logica.
- El contexto invocador coordina las reservas de TEST por recurso y entrega al skill la fase autorizada y el checkout correspondiente. Puede ejecutar fases en paralelo si no comparten objeto Oracle completo, `APP_ID/PAGE_ID`, archivo/import APEX, script de deploy, flujo QA, datos temporales ni una integración no separable. El skill no crea, interpreta, adquiere, transfiere ni libera locks.
- Los cambios ajenos o sin seguimiento de otro checkout no se sanean ni bloquean todo el trabajo. Usar exclusivamente el worktree limpio y aislado recibido; si falta, reportar el efecto tecnico y continuar lo independiente.
- Reportar unicamente el alcance y resultado tecnico recibidos. No descubrir ni gestionar estados, pendientes o sesiones ajenas.

## Salida Esperada

Al cerrar una intervencion, reportar:

- archivos y objetos afectados;
- ambiente usado;
- validaciones tecnicas ejecutadas;
- ruta funcional preparada para validacion independiente o impedimento tecnico documentado;
- estado de `desarrollo.md` y repo fuente cuando aplique;
- pendientes y riesgos;
- si la entrega tecnica esta completa, no aprobada o tiene un impedimento tecnico/externo; el contexto decide el estado y la fase siguiente.
```

## Seccion 2 - Preparacion O Verificacion De Uso

Ejecutar esta seccion despues de copiar/fusionar el bloque anterior en `AGENTS.md`.

### 1. Validar Prerrequisito Del Skill

Confirmar que el usuario descargo o clono el repositorio de skills y que existen:

```text
skill/desarrollador-apex/
```

Confirmar que el skill `desarrollador-apex` ya esta instalado y actualizado en la instalacion activa de Codex. Si no esta instalado, si no coincide con `skill/desarrollador-apex/` o si hay duda sobre la version activa, detener esta preparacion de uso y ejecutar primero:

```text
skill/desarrollador-apex/references/prompts/preparacion-ambiente.md
```

### 2. Verificar Contexto Del Proyecto

Este prompt de uso no crea la arquitectura del proyecto. Verificar que el contexto ya contiene la arquitectura y contratos requeridos.

Antes de usar el skill para editar codigo, verificar:

- Si aplica `zaimella-apex-oracle`, existe `desarrollo.md` en la raiz del proyecto/contexto.
- `desarrollo.md` tiene responsable/desarrollador, proyecto/contexto local, repo fuente local, APP_ID y codigos/prefijos funcionales.
- La ruta local del repo fuente existe o hay un impedimento tecnico documentado.
- La estructura compartida existe cuando aplique: `docs/`, `docs/bitacora.md`, `docs/deploy/`, `docs/logs/` y `tmp/`.
- Para una tarea activa existen `docs/tareas/<ID_TAREA>/tarea.md`, su reserva documentada en `docs/tareas/_control/test.lock` cuando altere TEST, `qa/tareas/<ID_TAREA>/` y worktree/rama propios.

Si falta cualquiera de esos elementos, no crear la arquitectura desde este prompt. Reportar el impedimento de contexto con los campos exactos y continuar las comprobaciones seguras; el contexto invocador decide el estado.

### 3. Validar Herramientas Propias Del Skill

Validar Oracle TEST o PROD segun el alcance antes de cualquier analisis dependiente de base, usando las herramientas y credenciales ya preparadas por el prompt de ambiente.

Confirmar que `scripts/validate_apex_page_standards.py` existe en el skill activo y responde a `--help`; no sustituirlo con busquedas manuales cuando corresponda ejecutar el gate estatico.

Si el alcance incluye objetos Oracle, confirmar tambien que `scripts/validate_plsql_package_standards.py`, `scripts/analyze_plsql_reuse.py` y `scripts/validate_oracle_data_object_standards.py` existen y responden a `--help`. Si incluye ORDS/OAuth, confirmar `scripts/validate_ords_deploy.py`, `scripts/ords_oauth_tool.py` y la custodia externa definida en `references/ords.md`.

No iniciar implementaciones dependientes de base si no hay conectividad real al ambiente requerido.

Si faltan instalaciones, configuraciones, credenciales, variables o el skill activo, detener este prompt de uso y ejecutar primero:

```text
skill/desarrollador-apex/references/prompts/preparacion-ambiente.md
```

### 4. Entrega De Verificacion

Al terminar esta verificacion, informar:

- skill instalado/actualizado o impedimento tecnico;
- contexto preparado o impedimento de entrada;
- `desarrollo.md` completo o pendiente;
- repo `zaimella-apex-oracle` disponible o impedimento tecnico;
- conectividad validada o impedimento externo/técnico documentado;
- siguiente accion permitida.
