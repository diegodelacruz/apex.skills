# Preparacion De Ambiente - desarrollador-apex

Usar este prompt antes de iniciar trabajo Oracle APEX/Oracle con el skill `desarrollador-apex`.

## Repositorio Descargado

Este prompt se ejecuta desde un contexto donde el usuario ya descargo o clono el repositorio de skills y tiene disponibles:

```text
skill/
prompts/
```

La fuente local del skill es:

```text
skill/desarrollador-apex/
```

## Instalar O Actualizar El Skill

- Preparar el ambiente incluye instalar o actualizar el skill `desarrollador-apex`.
- Si el skill no esta instalado, instalarlo desde `skill/desarrollador-apex/` del repositorio descargado en la instalacion activa de Codex.
- Si el skill ya existe, validar que la instalacion activa corresponde a la fuente vigente de `skill/desarrollador-apex/` del repositorio descargado; si no coincide, actualizarla antes de continuar.
- No reemplazar este skill con instrucciones improvisadas ni con prompts copiados al proyecto.

## Requisitos Previos

- Confirmar que Python esta disponible para ejecutar scripts del skill.
- Confirmar que `python scripts/execute_oracle_deploy.py --help` responde; este es el unico ejecutor del skill para DDL, DML de configuracion y PL/SQL en TEST y PRODUCCION.
- Confirmar que `python scripts/validate_plsql_package_standards.py --help`, `python scripts/analyze_plsql_reuse.py --help` y `python scripts/validate_oracle_data_object_standards.py --help` responden cuando el alcance incluya objetos Oracle.
- Si el alcance incluye ORDS/OAuth, confirmar que `python scripts/validate_ords_deploy.py --help` y `python scripts/ords_oauth_tool.py --help` responden, y que existe un gestor corporativo de secretos o una cache DPAPI externa bajo `%USERPROFILE%/.zaimella/ords-oauth/`.
- Confirmar acceso al proyecto o contexto objetivo y revisar sus instrucciones locales antes de editar.
- Confirmar que las credenciales Oracle/HANA viven fuera del repositorio, por ejemplo en `%USERPROFILE%\.zaimella` o variables de entorno autorizadas.
- No guardar contrasenas, wallets, tokens, exports completos, capturas temporales ni configuraciones personales en el repositorio del proyecto.
- Si el trabajo depende de documentacion externa vigente, confirmar que Context7 esta disponible.
- Si el cambio requiere OpenSpec por alcance mediano, grande, productivo planificado o ambiguo, confirmar que OpenSpec esta disponible y que `openspec/` vivira en el proyecto objetivo.

## Scripts Del Skill

Validar que el skill instalado incluya los scripts reutilizables necesarios:

```text
scripts/validate_oracle_connectivity.py
scripts/set-oracle-env.ps1
scripts/oracle_sql_tool.py
scripts/validate_hana_connectivity.py
scripts/hana_sql_tool.py
scripts/import_apex_sql_via_python.py
scripts/apex_export_sql_via_python.py
scripts/production_deploy_tool.py
scripts/apex_menu_access_tool.py
scripts/diagnose_apex_navigation_access.py
scripts/extract_apex_page_navigation.py
scripts/validate_apex_page_standards.py
scripts/validate_plsql_package_standards.py
scripts/analyze_plsql_reuse.py
scripts/validate_oracle_data_object_standards.py
scripts/validate_ords_deploy.py
scripts/ords_oauth_tool.py
```

Si el proyecto no tiene carpeta `scripts/`, resolver los scripts desde la carpeta instalada del skill activo. No copiar scripts al proyecto salvo que el flujo lo requiera y quede documentado.

## Validaciones Iniciales

Ejecutar o pedir al agente que ejecute, segun el ambiente requerido:

```powershell
python scripts/validate_oracle_connectivity.py --environment test
python scripts/validate_oracle_connectivity.py --environment prod
```

Si el validador indica variables faltantes, ejecutar una sola vez:

```powershell
. .\scripts\set-oracle-env.ps1 -CreateDefaultIfMissing
```

Luego repetir la validacion del mismo ambiente.

## Proyecto Con Fuente Versionada

Si el proyecto usa `zaimella-apex-oracle`, verificar antes de editar que el contexto tenga:

- `desarrollo.md` con rutas, APP_ID, codigos funcionales y alcance.
- ruta local del repo fuente definida en `desarrollo.md`.
- checkout o worktree aislado completo entregado por el contexto invocador; el skill no genera slugs, IDs, ramas ni rutas operativas. No desarrollar directamente en el checkout principal de integracion.
- contrato `docs/tareas/<ID_TAREA>/tarea.md` y workspace operativo/QA propios para cada tarea activa.
- fuente APEX/Oracle vigente sincronizada desde GitHub o desde Oracle/APEX real cuando sea baseline inicial autorizado.

Este prompt de ambiente instala y valida el skill, sus scripts y sus credenciales externas; no crea la arquitectura completa del proyecto/contexto. Si falta `desarrollo.md`, la ruta local del repo fuente o la estructura operativa del proyecto, reportar `Impedimento tecnico de contexto incompleto`; el skill no cambia el estado de la tarea.

Si falta fuente, aplicacion, pagina u objeto del alcance dentro de un repo ya preparado, bloquear hasta inicializar o confirmar la fuente vigente segun el skill.

## Resultado Esperado

Antes de usar `desarrollador-apex`, el contexto debe tener:

- conectividad validada o bloqueo claro;
- credenciales fuera del repositorio;
- scripts del skill ubicables;
- proyecto y fuente versionada identificados cuando aplique;
- bitacora o mecanismo de seguimiento del proyecto listo para registrar la tarea.
