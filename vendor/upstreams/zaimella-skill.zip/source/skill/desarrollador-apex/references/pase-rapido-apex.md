# Pase Rapido APEX

Usar este camino solo para un pase productivo APEX aislado y de bajo radio de impacto. No elimina los gates de version, QA, autorizacion ni respaldo; reduce pasos manuales y evita repetir pruebas ya aprobadas en TEST.

## Elegibilidad

Es `Pase Rapido APEX` un cambio que cumpla todo lo siguiente:

- una pagina APEX o un inventario explicito pequeno de metadata de la misma aplicacion;
- el mismo SHA fue compilado/importado en TEST y aprobado por QA;
- ese SHA ya esta publicado en `origin/main`;
- no incluye paquetes, package bodies, tablas, datos transaccionales, jobs, permisos, migraciones ni dependencias no verificadas;
- existe export TEST vigente, con APP_ID, pagina y workspace verificables;
- la autorizacion para ejecutar en PRODUCCION es explicita.

Si crea o cambia una vista, funcion, paquete, configuracion, datos o mas de una pagina, usar el pase normal salvo que el usuario autorice una excepcion razonada. Un incidente productivo no convierte por si solo un cambio en pase rapido.

## Secuencia obligatoria

1. Declarar en `docs/tareas/<ID_TAREA>/deploy/manifest_pase.md` que el tipo es `Pase Rapido APEX`, el inventario exacto, SHA de TEST/QA/publicado y la autorizacion.
2. Ejecutar preflight antes de cualquier cambio: verificar SHA en `origin/main`, hash del export, APP_ID, pagina, `p_default_workspace_id`, disponibilidad del respaldo y que la pagina productiva existe.
3. Obtener respaldo APEX de la pagina o registrar evidencia alternativa permitida cuando la API no esta disponible.
4. Importar una sola vez mediante `scripts/import_apex_sql_via_python.py <export.sql> --environment prod --timing-log <log>`; el importador debe detectar el esquema APEX activo y fijar primero `<APEX_SCHEMA>.WWV_FLOW_SECURITY.SET_G_SECURITY_GROUP_ID` desde el workspace declarado por el export. No improvisar bloques SQL ni reintentos manuales.
5. Ejecutar validacion post minima: metadata de los componentes modificados, referencias invalidas `0`, objetos dependientes `VALID` y una consulta segura del caso afectado.
6. Hacer smoke APEX solo si existe sesion autenticada o mecanismo autorizado. No intentar login automatizado sin credencial; registrar `smoke visual manual pendiente` sin convertirlo en fallo tecnico.
7. Archivar respaldo, export, log de tiempos, validacion e `informe_pase.md`. El informe debe registrar inicio, fin y duracion de preflight, respaldo, import y validacion.

## Presupuesto operativo

- Meta: 3 a 7 minutos desde el preflight hasta la validacion post para una pagina aislada.
- Si una etapa tarda mas de 2 minutos o el pase supera 7, informar inmediatamente la etapa, espera/reintento, evidencia y siguiente decision. No continuar con intentos manuales repetidos.

## Prohibiciones

- No usar este flujo para ocultar un pase consolidado ni para pasar todo TEST.
- No reutilizar respaldos, exports historicos o archivos de otra sesion como fuente hacia adelante.
- No reemplazar QA TEST por un smoke productivo.
- No ejecutar reversa salvo autorizacion expresa; el respaldo solo sirve para reversa.

## Pase Tecnico Rapido Oracle

Usar este camino para un pase productivo aislado de un unico `PACKAGE` o `PACKAGE BODY`. Para un cambio con impacto visible, el QA funcional ya fue ejecutado y aprobado en TEST para el mismo SHA; para una mejora interna sin impacto visible, debe existir QA técnico acotado aprobado con prueba directa del objeto para el mismo SHA. En PRODUCCION no se repite navegación, Browser, Playwright, carga de archivos ni ninguna transacción funcional.

### Elegibilidad

Debe cumplirse todo lo siguiente:

- el inventario incluye un solo `PACKAGE` o `PACKAGE BODY`, sin paginas APEX, tablas, vistas, funciones, jobs, permisos, datos ni configuracion;
- el mismo SHA fue compilado en TEST, aprobado por el tipo de QA aplicable y publicado en `origin/main`;
- el artefacto SQL versionado y su SHA-256 estan identificados en el manifiesto;
- la autorizacion para PRODUCCION es explicita o condicionada a ese QA ya aprobado;
- el paquete no requiere una ejecucion funcional productiva para migrar datos, poblar estructuras o completar el despliegue.

Si cualquiera falla, aplicar el pase normal correspondiente.

### Secuencia y validacion post

1. Registrar en el manifiesto el tipo `Pase Tecnico Rapido Oracle`, el objeto, SHA TEST/QA/publicado, hash del SQL y autorizacion.
2. Validar una vez la conectividad productiva, el SHA publicado y la disponibilidad del respaldo; generar respaldo del objeto.
3. Ejecutar el SQL completo sin filtrar ni reescribir lineas internas del `PACKAGE` o `PACKAGE BODY`.
4. Validar exclusivamente: ejecucion SQL sin errores, `PACKAGE` y `PACKAGE BODY` en estado `VALID`, `ALL_ERRORS=0` para el objeto y huella/fuente productiva correspondiente al SHA publicado.
5. Confirmar que no quedan sesiones propias de la ejecucion y archivar respaldo, log, validacion e `informe_pase.md`.

No abrir la aplicacion, no ejecutar smoke web, no ejecutar QA visual y no repetir la accion funcional en PRODUCCION. Esas pruebas pertenecen a TEST y se acreditan con el informe QA del mismo SHA.

### Presupuesto operativo

- Meta: 2 a 5 minutos desde preflight hasta la validacion post.
- Si excede 5 minutos, registrar la fase y causa concreta. Un reintento por un ejecutor que altere el SQL es un defecto del ejecutor que debe corregirse; no es una validacion adicional del pase.
