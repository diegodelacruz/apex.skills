# Flujo Operativo

> Las rutas de contratos, bitacoras, QA, despliegues y evidencias las crea y gobierna el orquestador APEX. Esta referencia define acciones tecnicas sobre los insumos entregados; no autoriza al skill a crear ni reorganizar arquitectura de proyecto.

Usa este flujo para analizar o modificar aplicaciones Oracle APEX en Zaimella.

## 1. Preparacion

- valida conectividad Oracle
- lee `desarrollo.md`
- si `desarrollo.md` define un repositorio fuente `zaimella-apex-oracle`, aplica `references/arquitectura-fuente-apex-oracle.md` para separar codigo versionado del proyecto/contexto
- identifica ambiente actual
- confirma el export `.sql` de la aplicacion o la fuente APEX versionada aprobada cuando exista repo `zaimella-apex-oracle`
- si existe repo `zaimella-apex-oracle` pero no contiene la aplicacion APEX u objetos Oracle del alcance, ejecuta primero el bootstrap desde APEX/Oracle real definido en `references/arquitectura-fuente-apex-oracle.md`
- si el trabajo es multitarea, lee primero el documento principal de tareas y `docs/bitacora.md`
- si existe `docs/bitacora.md`, identifica o crea la `Sesion` y el `ID tarea` del alcance actual antes de ejecutar cambios, consultas de datos, sincronizaciones, QA o pase
- si encuentras pendientes de otra sesion, no los ejecutes ni los cierres salvo instruccion explicita del usuario

## 2. Delimitacion del alcance

- si el usuario indica `id de pagina`, usalo como referencia principal
- si indica nombre de pagina, busca coincidencias
- si hay varias coincidencias, pide precision
- si no hay coincidencias, informa el resultado y solicita una referencia mas precisa
- si el usuario entrega una instancia puntual como ejemplo, tratala como caso reproductor; no asumas que la solucion debe quedar hardcodeada o condicionada a esa instancia
- antes de editar, separa el inventario en: `Solicitado explicitamente`, `Elementos existentes que se conservaran` y `Cambio adicional que requeriria autorizacion`. Para paginas APEX incluye botones, regiones, items, procesos, validaciones, permisos y navegacion afectados.
- agregar una accion o manejo nuevo no implica reemplazar acciones existentes. Conserva controles y comportamiento actuales aunque parezcan redundantes, salvo que el usuario haya pedido expresamente eliminarlos, sustituirlos u ocultarlos.
- si el analisis revela que seria conveniente o necesario modificar, eliminar, ocultar, renombrar, sustituir o cambiar el comportamiento de un elemento no solicitado, no lo ejecutes por interpretacion. Explica el conflicto o motivo tecnico, el impacto visible/funcional, los elementos concretos y las alternativas; pide autorizacion explicita antes de continuar con ese cambio adicional.
- no requiere confirmacion adicional una correccion puramente tecnica e invisible indispensable para que el cambio solicitado compile o funcione, siempre que no amplie el comportamiento ni altere un elemento existente. Debe incluirse en el resumen final.
- cuando OpenSpec este disponible y el cambio agregue una accion de interfaz o pueda afectar controles existentes, crea o actualiza `openspec/changes/<id-cambio>/proposal.md` antes de editar. La propuesta debe tener las secciones `Solicitado explicitamente`, `Preservacion obligatoria`, `Fuera de alcance`, `Cambios adicionales detectados` y `Criterios de aceptacion/no regresion`.
- resuelve los cambios adicionales en una sola revision previa al desarrollo. Si `Cambios adicionales detectados` no esta vacia, presenta la propuesta y pide autorizacion explicita del usuario para cada elemento adicional antes de programar. La aprobacion resultante congela el alcance: permite implementar solo lo declarado en `Solicitado explicitamente`, `Preservacion obligatoria` y los adicionales aceptados; no autoriza otros extras.
- durante la implementacion no detengas el trabajo para pedir nuevas decisiones de alcance ni incorpores interpretaciones nuevas. Si descubres un elemento adicional, conservalo sin cambios y registralo como `Pendiente fuera de alcance` para informar al cierre o en la siguiente revision. Solo aplican los impedimentos tecnicos y de acceso ya definidos por el skill, como conectividad Oracle/APEX, fuente obligatoria o autorizaciones de ambiente.

## 3. Analisis APEX

Para las paginas objetivo identifica:
- nombre de pagina
- regiones
- items
- botones
- procesos
- validaciones
- branches
- acciones dinamicas
- SQL y PL/SQL relevante
- navegacion hacia otras paginas

## 4. Analisis de base

Valida y clasifica:
- tablas
- vistas
- paquetes
- funciones y procedimientos
- secuencias
- jobs
- DB links y referencias remotas
- comentarios de tablas y columnas cuando ayuden a interpretar el requerimiento

Distingue entre:
- objeto local existente
- objeto local inexistente
- referencia remota valida por DB link

Para consultas de metadata, datos no sensibles o planes de ejecucion, usa el helper oficial `scripts/oracle_sql_tool.py` segun `references/conectividad-oracle.md`. No uses helpers locales del proyecto ni snippets ad hoc para reemplazar consultas o `EXPLAIN PLAN` cotidianos.

## 5. Decision tecnica

Antes de programar:
- informa que objetos vas a usar
- informa que objetos vas a modificar
- informa que objetos vas a crear
- informa el inventario de elementos existentes que se conservaran y cualquier cambio adicional que quedo pendiente de autorizacion; no presentes como decidido un reemplazo no autorizado
- cuando aplique OpenSpec, contrasta la decision tecnica contra `proposal.md` y `tasks.md`; antes de programar deja el alcance congelado. Durante la ejecucion no agregues tareas de eliminacion, sustitucion u ocultamiento que no hayan quedado autorizadas en esa revision previa.
- decide si la logica nueva va en paquete existente o en paquete nuevo
- identifica si el defecto pertenece a un flujo, componente, servicio, convertidor, cargador, parser, normalizador, paquete, integracion o arquitectura compartida existente; si es asi, la correccion debe hacerse en esa fuente o en una regla parametrizable reutilizable
- queda prohibido proponer como primera opcion un SP, paquete, vista, script o validacion nombrado o condicionado por una instancia puntual
- si consideras indispensable una excepcion puntual, detente y pide aprobacion explicita del usuario, explicando por que no basta la solucion reutilizable, riesgo de deuda tecnica, alcance, criterio de retiro y pruebas de no regresion
- si el cambio usa URL, endpoint, host, puerto o ruta base, confirma que no quedara hardcodeado y define la configuracion en `DATA.T_CORP_UDC` o tabla general aprobada
- si faltan valores por ambiente, pide al usuario la URL de TEST y la URL de PRODUCCION antes de cerrar el diseno o preparar pase

## 6. Ejecucion

- para cambios APEX, trabaja sobre el export `.sql` vigente o sobre la fuente APEX versionada aprobada cuando exista repo `zaimella-apex-oracle`
- si guardas paginas APEX en `zaimella-apex-oracle`, usa la convencion estable completa `APEX/<APP_ID>-<CODIGO_O_NOMBRE_APP>/PAGINAS/page_<PAGE_ID_4_DIGITS>.sql`; no uses rutas parciales ni nombres de caso, ticket, tarea, fecha o instancia puntual como fuente versionada
- si existe repo fuente `zaimella-apex-oracle`, limita la edicion a la aplicacion, paginas y objetos declarados en el alcance de `desarrollo.md` y la tarea actual
- si guardas objetos Oracle en `zaimella-apex-oracle`, usa rutas y archivos canonicos en mayusculas, por ejemplo `ORACLE/DATA/PAQUETES/BODIES/PK_MODULO_OBJETO.sql`; no uses carpetas `bodies`, `Bodies`, archivos en minuscula ni nombres con owner
- si la fuente versionada del alcance fue inicializada desde base/APEX real en esta tarea, valida ruta, contenido y diferencias antes de editarla
- para logica de negocio, prioriza paquetes de base de datos
- evita DML de negocio directo en procesos APEX
- aplica los estandares del skill antes de modificar
- antes de sincronizar datos, cargar archivos, ejecutar DML o continuar un pendiente de bitacora, confirma que la actividad pertenece a la `Sesion` e `ID tarea` actuales
- no uses como autorizacion operativa una frase historica de otra sesion, por ejemplo "voy a sincronizar", "pendiente QA" o "ejecutar QA real"; si no pertenece a tu sesion, registralo como pendiente ajeno y pide confirmacion
- si una URL absoluta hardcodeada forma parte directa del cambio solicitado, reemplazala por lectura de configuracion; no dejes constantes de ambiente en APEX, PL/SQL, JavaScript ni SQL de negocio. Si se detecta fuera del cambio solicitado, registrala como hallazgo y pide autorizacion antes de ampliar el alcance para corregirla.
- no implementes reglas especificas por instancia puntual salvo autorizacion explicita registrada; usa esos datos como pruebas de la correccion reutilizable

## 7. Validacion

- valida compilacion si hubo cambios PL/SQL
- valida el caso principal
- valida el resultado esperado o el error controlado
- valida al menos un caso positivo generico adicional cuando la correccion haya nacido de un caso puntual, para demostrar que el flujo comun no quedo condicionado al ejemplo
- documenta diferencias entre export y base cuando existan
- para cada boton, Ajax, proceso o dialogo transaccional del alcance, entrega a QA un criterio verificable de `antes / accion visible / despues independiente`: dato temporal identificable, control que debe pulsarse, mensaje o estado esperado, region/pantalla que debe refrescarse y comprobacion tras reapertura o recarga. No declarar listo para TEST por la sola presencia del boton, proceso, metadata o compilacion.
- para dialogos, entrega su proposito (`informativo`, `consulta/navegacion`, `transaccional` o `proceso`), contexto de entrada, accion real, componente que la ejecuta (proceso APEX, accion dinamica o procedimiento cuando aplique), resultado esperado y efecto en el padre. Solo para dialogos transaccionales especifica `Guardar` y `Salir/Cancelar`; para informativos no inventes persistencia y para procesos exige su efecto verificable. Si el dialogo cabe solo por un tamano o viewport determinado, registrarlo como criterio visual.
- despues de corregir un defecto de boton, guardado, Ajax o dialogo, vuelve a ejecutar el caso reproductor completo y una regresion acotada del flujo padre/destino antes de entregar un nuevo candidato. No uses una captura o validacion de un candidato anterior como evidencia de la correccion.

## 8. QA funcional y capturas

Contexto:
- La revision independiente de pantallas puede probar funcionalidad o generar evidencia visual para documentacion.
- La arquitectura, carpetas, modos de trabajo, severidades y salidas obligatorias de validacion funcional se definen en el contexto y en su flujo independiente instalado.

Estandar:
- Antes de entregar a QA validacion funcional o capturas documentales, deja listo el contrato funcional requerido por el contexto.
- Cuando el alcance incluya un manual, entrega al contexto un inventario de destinos derivado de la auditoria pre-TEST: cada pagina, dialogo, accion derivada, tab, acordeon o paso visible; su contrato de navegacion, accion de entrada, proposito, resultado/retorno y datos minimos. No sustituye el inventario de cobertura que prepara el contexto para QA, pero impide que el manual omita destinos secundarios conocidos.
- Cuando el usuario pida `QA`, `probar pantallas`, `validar funcionalidades`, `revisar botones`, `validar flujo` o equivalente, se debe ejecutar QA funcional.
- Para una mejora aislada de `PACKAGE`, `PACKAGE BODY`, función, procedimiento o vista sin impacto visible declarado, preparar `QA técnico acotado`: contrato ejecutable del objeto/rutina, datos o binds TEST, precondición, ejecución, resultado antes/después, limpieza y riesgos. No exigir QA visual ni capturas; `VALID` y `ALL_ERRORS=0` complementan, pero no reemplazan la prueba directa. Si existe impacto visible, persistencia iniciada por usuario, permisos, navegación, configuración o no hay caso técnico reproducible, exigir QA funcional.
- Cuando el usuario pida `prints`, `capturas`, `screenshots`, `pantallazos` o material para manuales, se debe generar evidencia visual para documentacion.
- Las capturas para manual no reemplazan el QA funcional. Si durante las capturas aparece un error, se registra como hallazgo y se recomienda ejecutar QA funcional.
- En el flujo corporativo orquestado, el QA funcional se ejecuta en TEST: no existe ambiente Oracle DEV. Un entorno local solo aplica a un contexto standalone expresamente identificado y no sustituye la validacion del commit candidato en TEST.
- El QA funcional debe validar carga de pantalla, navegacion, botones, formularios, validaciones, modales, reportes, filtros, mensajes, errores de consola, permisos visibles y escenarios principales del flujo.
- Las capturas para manual deben tomarse con datos de prueba o datos no sensibles, mostrar estados representativos y evitar exponer credenciales, informacion personal sensible o datos reales no autorizados.
- En proyectos multitarea, entrega hallazgos y evidencia en las ubicaciones recibidas del contexto; no construyas rutas ni actualices bitacoras de coordinacion.
- La evidencia tecnica debe identificar la version y el alcance trabajados para que el contexto pueda coordinar una validacion independiente sin ambiguedad.
- Las capturas primarias se guardan en la ruta QA entregada por el contexto. Desarrollo solo entrega inventario y hechos; QA produce la evidencia y `documentacion-proyecto-sistemas` redacta el entregable.

Razon:
- QA funcional decide si una funcionalidad esta lista o tiene defectos. Las capturas documentales no prueban por si solas que el flujo funcione y no convierten a QA en autor del manual.

Ejemplo:
- `QA funcional`: iniciar sesion en test, abrir la pagina, crear/editar/consultar un registro, probar botones principales, validar mensajes y registrar hallazgos.
- `Capturas para manual`: abrir la pantalla con datos de prueba, tomar imagen del listado, formulario, modal y resultado final para usarlas en el manual de usuario.

## 9. Errores y cambios reportados en produccion

Contexto:
- Produccion se usa para diagnosticar la verdad del error o cambio reportado, no para improvisar correcciones sin trazabilidad.
- Test se usa para replicar, corregir y validar antes de preparar el pase controlado.
- El agente puede preparar y ejecutar la publicacion APEX en TEST o produccion cuando el usuario lo pida o el alcance aprobado lo incluya; debe usar export vigente, respaldo previo y mecanismo autorizado.
- Si el error corresponde a algo que ya fue pasado a produccion, la correccion debe hacerse primero en test, validarse y luego pasarse nuevamente a produccion. No se corrige directo en produccion salvo autorizacion explicita y registrada.

Estandar:
1. Registrar el reporte en `docs/bitacora.md` antes de ejecutarlo cuando el proyecto sea multitarea.
   - Usa prefijo `[Correccion]` si es un error dentro del alcance aprobado.
   - Usa prefijo `[Nueva fuera de alcance]` si es un cambio funcional nuevo o una solicitud productiva no contemplada.
2. Validar conectividad directa a produccion con `references/conectividad-oracle.md` y confirmar ambiente, usuario y base conectada.
3. Diagnosticar primero en produccion conectandote directamente con la credencial autorizada. No uses `@zaip` como sustituto del diagnostico productivo.
4. Identificar y registrar evidencia minima no sensible:
   - fecha y hora del incidente o reporte
   - usuario, compania, pagina, modulo o proceso afectado cuando aplique
   - objeto de base, paquete, vista, tabla, job, permiso, menu, UDC, LOV o configuracion involucrada
   - mensaje tecnico completo o error visible
   - datos clave no sensibles para reproducir el caso
5. Clasificar el reporte antes de corregir:
   - `Datos`: informacion inconsistente, faltante, duplicada o mal migrada
   - `Configuracion`: UDC, LOV, parametros, menus, accesos, rutas de aprobacion o compania
   - `Permisos`: usuario, rol, menu visible, pagina o accion no autorizada
   - `APEX`: pagina, item, boton, region, proceso, validacion, branch o accion dinamica
   - `Base`: tabla, vista, paquete, funcion, procedimiento, trigger, job o constraint
   - `Cambio funcional`: comportamiento nuevo solicitado desde produccion
6. No corregir directamente en produccion salvo autorizacion explicita del usuario y registro de la excepcion en bitacora e informe.
7. Replicar el caso en test con datos equivalentes o escenario controlado. Si se requieren datos productivos para reproducir, usa datos no sensibles o una extraccion controlada.
8. Aplicar la correccion en la fuente correspondiente:
   - APEX: fuente APEX versionada aprobada cuando exista `zaimella-apex-oracle`; si no existe, export `.sql` vigente
   - Base: objetos versionados en `zaimella-apex-oracle` cuando exista; si no existe, scripts fuente en `docs/sql`
   - Configuracion o datos: script idempotente de datos/configuracion
   - Permisos/menu/UDC/LOV/rutas: script de configuracion validable
9. Validar en test compilacion, caso principal, error original corregido y efectos relacionados.
10. Ejecutar QA funcional independiente cuando el cambio afecte pantallas, formularios, botones, permisos, adjuntos, aprobaciones o flujo funcional. Para una mejora Oracle aislada elegible, ejecutar QA técnico acotado independiente según esta sección.
11. Preparar el paso a produccion segun la seccion `Paso a produccion` de este flujo y `references/estandares-base-datos.md`.
12. Ejecutar o entregar el pase siguiendo la regla de despliegue:
   - datos de configuracion por script controlado y, cuando aplique, usando `@zaip` desde test
   - objetos de base, DDL y paquetes conectandote directamente a produccion
13. Ejecutar `04_validacion_post.sql` o validacion equivalente y guardar evidencia en `docs/tareas/<ID_TAREA>/logs` antes de archivarla con el pase. La validacion post productiva debe confirmar en `ALL_OBJECTS` que todos los objetos del pase quedaron `VALID`; para paquetes debe validar tanto `PACKAGE` como `PACKAGE BODY`.
14. Archivar el pase cerrado en `docs/pases-produccion/<YYYYMMDD_HHMM>_<descripcion>/` y dejar `docs/deploy` vacio o solo con `.gitkeep`.
15. Cerrar la entrada de `docs/bitacora.md` con resultado, evidencia, ruta del respaldo y pendientes si existen.

Razon:
- Separar diagnostico productivo, correccion en test y despliegue controlado evita arreglos invisibles, omisiones en scripts y diferencias entre ambientes.
- Clasificar el reporte antes de corregir ayuda a decidir si corresponde a error, configuracion, permiso, APEX, base o cambio fuera de alcance.

Ejemplo:
- Si produccion reporta `ORA-00001` al guardar una pagina APEX, primero se confirma el error real en produccion, se identifica el paquete o constraint involucrado, se replica en test, se corrige el paquete o validacion, se ejecuta QA del formulario y se prepara el pase con `03_paquetes.sql` y `04_validacion_post.sql`.
- Si falta una opcion en una LOV para una compania, se clasifica como configuracion, se valida el UDC o tabla general en produccion, se replica en test, se prepara `02_datos_configuracion.sql` idempotente y se valida que la LOV liste la opcion correcta con la compania adecuada.

## 10. Paso a produccion

Contexto:
- En proyectos multitarea, `docs/tareas/<ID_TAREA>/deploy` es el area de trabajo aislada. `docs/deploy` se usa solo para el pase final integrado o consolidado.
- El agente puede preparar y ejecutar la publicacion APEX en produccion cuando el usuario lo pida o el alcance aprobado lo incluya; debe separar respaldo/export/import APEX de los scripts de base y registrar evidencia.
- El pase de objetos versionados debe partir del commit aprobado por QA y publicado en GitHub. TEST valida ese commit, pero no reemplaza la fuente Git. Los objetos reales de TEST solo pueden reconciliarse como fuente si primero se incorporan al repo y generan un nuevo commit candidato. No son fuente de pase los temporales, exports viejos, respaldos ni copias de otra sesion.
- El flujo normal de pase es directo: asegurar respaldo disponible, exportar o extraer desde TEST verificado para el alcance aprobado, importar o ejecutar en produccion y validar estado tecnico minimo. Si el cambio ya fue probado funcionalmente en TEST, produccion no repite QA funcional completo.
- Para una pagina APEX aislada que cumpla todos los criterios de `pase-rapido-apex.md`, aplicar ese flujo antes del pase normal. El objetivo es automatizar preflight, backup, import y validacion sin omitir gates ni repetir QA.
- La validacion productiva normal es un smoke check minimo: objetos `VALID`, vistas consultables sin error, paquetes compilados, jobs/configuracion presentes, metadata APEX importada cuando aplique y pantalla principal abre sin error si el pase incluye APEX. No ejecutar flujos transaccionales completos en produccion salvo autorizacion explicita.
- Si el pase incluye aplicacion APEX, generar export desde TEST con el mecanismo disponible o usar el export vigente verificado contra TEST. No responder que el skill no puede publicar APEX en produccion cuando ya se han hecho cambios de paginas en TEST y el pase autorizado incluye esas paginas.
- Si `APEX_EXPORT` o `WWV_FLOW_EXPORT_API` falla en produccion con `ORA-20987` u otro error de privilegios/export, no convertirlo en bloqueo si ya existen: export desde TEST verificado, conexion productiva valida, import APEX habilitado con esquema correcto y alcance autorizado. En ese caso ejecutar el import APEX y registrar explicitamente que el respaldo productivo completo por API no estuvo disponible.
- El agente debe distinguir entre cambios ya pasados a produccion y cambios pendientes, usando bitacora, paquetes archivados, manifiestos y comparacion test vs produccion cuando aplique.
- Los datos de test no se pasan a produccion. Solo se pasan datos de configuracion necesarios para que funcione el proceso, especialmente UDC o tablas generales como `DATA.T_CORP_UDC`, LOV, parametros, menus, permisos o configuraciones autorizadas. La data transaccional o de prueba solo puede pasarse si el usuario lo indica explicitamente.
- El script `scripts/production_deploy_tool.py` es la herramienta estandar para preparar, respaldar objetos productivos, extraer objetos desde TEST y validar `docs/deploy`; usarlo antes de entregar o ejecutar un pase.
- La ejecucion de SQL Oracle versionado en TEST y PRODUCCION usa exclusivamente `scripts/execute_oracle_deploy.py`. En ambos ambientes exige SHA-256 del SQL exacto, checkout limpio y commit candidato verificable; en PRODUCCION exige ademas que ese commit coincida exactamente con `origin/main`. Una etiqueta de SHA en un worktree no demuestra identidad si el archivo local difiere.
- Comando TEST completo: `python scripts/execute_oracle_deploy.py <SQL_VERSIONADO> --environment test --expected-sha256 <SHA256_SQL> --source-repo <CHECKOUT_LIMPIO_EN_SHA_CANDIDATO> --expected-source-commit <SHA_CANDIDATO> --timing-log <LOG>`.
- Para codigo Oracle, el ejecutor fija y comprueba `CURRENT_SCHEMA=DATA`, registra `SESSION_USER`, `CURRENT_SCHEMA` y base efectiva antes de ejecutar DDL, y verifica que cada `PACKAGE`, `PACKAGE BODY`, funcion o procedimiento quede `VALID` bajo `DATA`. Una conexion tecnica autorizada no permite compilar una copia bajo su propio esquema ni en otro owner.
- Para imports APEX, `scripts/import_apex_sql_via_python.py` es el unico mecanismo normal. Debe fijar el workspace desde `p_default_workspace_id` antes de importar y puede registrar hitos con `--timing-log`; un error de workspace es un fallo de preflight, no motivo para reintentos manuales.
- La credencial productiva autorizada se obtiene exclusivamente desde `ZAIMELLA_ORACLE_PROD_*` o su configuración externa segura. El agente no debe redescubrir, registrar ni copiar usuarios, contraseñas, hosts, SID o URLs en archivos, bitácoras, prompts, logs o respuestas.
- Un import APEX no es un despliegue ORDS. Ante `ORA-20012`, `Schema not REST enabled`, u otro error que mencione ORDS/REST, conservar el error literal, el bloque y las lineas que fallaron, el APP_ID, workspace y usuario/sesion efectivos que reporta el helper. No inferir que `DATA` debe ser la credencial, que el esquema objetivo debe habilitarse para REST, ni cambiar `CURRENT_SCHEMA`, credenciales, privilegios u ORDS. Solo tratarlo como requisito ORDS si el export o el inventario del pase contiene de forma verificable un artefacto ORDS y el contrato del pase lo autoriza; en cualquier otro caso diagnosticar el bloque APEX fallido mediante el mecanismo versionado.
- Un fallo de import no autoriza restaurar TEST, sustituir la fuente candidata ni declarar que el cambio solo puede hacerse en APEX Builder. La fuente versionada, el SHA probado y TEST se preservan hasta que exista un rollback separado, trazable y autorizado. Antes de proponer Builder u otra via manual, agotar el importador oficial y su remediacion documentada, conservar el diagnostico reproducible y obtener autorizacion explicita para cambiar de mecanismo; no presentar como hecho una limitacion de API, workspace o credenciales que no este demostrada por la evidencia.
- Preparar un pase y ejecutar un pase son acciones distintas. El agente puede armar y validar `docs/deploy` cuando el alcance lo pida, pero no debe ejecutar cambios en produccion sin una autorizacion explicita de ejecucion productiva.
- Una instruccion de tarea que ordene expresamente `migrar/aplicar en TEST y, si QA aprueba, pasar a PRODUCCION` constituye autorizacion productiva condicionada para esa misma tarea. No pedir una segunda autorizacion: ejecutar primero el script versionado en TEST, completar el QA del mismo candidato y pasar solo si el informe queda aprobado y los demas gates del pase estan conformes. Si TEST o QA falla, queda prohibido pasar.
- Si varias tareas, varios dias o varias sesiones se acumularon en TEST sin paso a produccion, el pase debe manejarse como `Pase Consolidado`. No se debe pasar "todo TEST" sin inventario, control de cambios, QA del bloque y validacion contra GitHub.

Estandar:
1. Antes de preparar un pase, revisar `docs/bitacora.md`, `docs/gestion/checklist_tareas.md` si existe, `docs/pases-produccion/control_cambios.md` si existe, el alcance aprobado y los cambios reales en `docs/sql`, export APEX o base de datos. Crear el artefacto ejecutable desde un checkout limpio del commit candidato, registrar su SHA-256 y no reutilizar archivos de un worktree con cambios locales.
2. Identificar tareas realizadas en test y clasificarlas:
   - `Ya en produccion`: existe evidencia en `docs/pases-produccion`, control de cambios o comparacion contra produccion.
   - `Pendiente de pase`: existe en test y no hay evidencia de produccion.
   - `No elegible`: cambio incompleto, sin QA requerido, sin compilacion o con dependencia rota.
3. Si el pase agrupa varias tareas, sesiones o dias de trabajo, declarar el alcance como `Pase Consolidado` y ejecutar estos pasos antes de preparar scripts:
   - listar tareas candidatas desde `docs/bitacora.md`, `docs/gestion/checklist_tareas.md` si existe y `docs/pases-produccion/control_cambios.md`
   - incluir solo tareas cerradas, con GitHub actualizado, TEST compilado/validado y QA aprobado
   - excluir tareas abiertas, experimentales, sin QA, con dependencias rotas o con diferencias no resueltas entre TEST y GitHub
   - validar dependencias entre tareas para no pasar una tarea que requiere otra excluida
   - confirmar que GitHub/repo fuente es la fuente del bloque y que TEST coincide con esa fuente para el alcance incluido
   - ejecutar o exigir QA/regresion minima del conjunto consolidado antes de declarar `Listo para pase`
   - registrar tareas incluidas y excluidas con motivo en `docs/deploy/manifest_pase.md` y `docs/pases-produccion/control_cambios.md`
4. Preparar el workspace con `python scripts/production_deploy_tool.py scaffold --project-root . --task-id <ID_TAREA>`. Usar `docs/deploy` sin `--task-id` solo al ensamblar el pase final integrado o consolidado.
5. Identificar el inventario completo del pase: aplicacion APEX o paginas incluidas, paquetes, vistas, funciones, procedimientos, triggers, jobs, secuencias, grants, synonyms, datos de configuracion y scripts de estructura de tablas.
6. Asegurar respaldo de produccion antes de ejecutar cambios, sin sobredimensionar bloqueos:
   - objetos de base: `python scripts/production_deploy_tool.py backup-prod-objects --project-root . --task-id <ID_TAREA> --objects TIPO:OWNER.OBJETO ...`
   - aplicacion APEX: preferir export productivo completo; si falla por privilegios o `ORA-20987`, usar evidencia alternativa suficiente: APP_ID, workspace, paginas/componentes afectados, export TEST verificado, hash/ruta/fecha del export importado y log de import productivo
   - cambios de estructura de tabla: respaldo DDL de la tabla y, si el cambio es riesgoso, criterio de reversa o respaldo de datos coordinado
7. Comparar test contra produccion cuando el alcance lo requiera:
   - objetos de base: tablas, columnas, constraints, indices, vistas, paquetes, triggers, jobs, grants o synonyms
   - APEX: paginas, procesos, regiones o metadata afectada, registrando el mecanismo de publicacion autorizado
   - configuracion: UDC, LOV, menus, accesos, parametros y tablas generales
8. Para objetos versionados pendientes, generar el pase desde el archivo canonico del commit candidato. Si se extrae TEST con `production_deploy_tool.py export-test-objects --project-root . --task-id <ID_TAREA> --objects ...`, usarlo solo para comparar y verificar; cualquier diferencia valida debe reconciliarse primero al repo y producir un nuevo commit candidato.
9. Para aplicacion APEX incluida en el pase, generar export desde TEST del APP_ID o paginas aprobadas con `python scripts/apex_export_sql_via_python.py --application-id <APP_ID> [--page-id <PAGE_ID>] --environment test --output <archivo.sql>`, o usar export vigente si se verifica fecha, aplicacion, workspace y paginas incluidas. El paquete debe incluir respaldo APEX productivo cuando este disponible; si no esta disponible por API, no detener el pase si la evidencia alternativa del punto 6 existe.
   - No incluir reportes guardados de Interactive Report en pases normales. Si aparece `ORA-00001` en `APEX_240100.WWV_FLOW_WORKSHEET_RPTS_UK` durante `import_end` de una aplicacion completa, verificar primero que el error, APP_ID, workspace, SHA y respaldo corresponden al mismo intento; luego usar `python scripts/import_apex_sql_via_python.py <export.sql> --environment prod --pre-remove-application --cleanup-orphan-ir-reports`. Esa limpieza elimina solo reportes IR residuales de la misma app antes de repetir el import. Si no resuelve el mismo error verificable, detener nuevos reintentos destructivos, conservar la evidencia y escalar como impedimento tecnico; no restaurar TEST ni derivar a APEX Builder sin la autorizacion de cambio de mecanismo definida arriba.
10. Crear o actualizar `docs/pases-produccion/control_cambios.md` con el estado por tarea y objeto.
11. Limpiar `docs/deploy` antes de armar el nuevo pase, conservando historicos solo si ya fueron movidos a `docs/pases-produccion`; promover alli unicamente los artefactos aprobados desde `docs/tareas/<ID_TAREA>/deploy` o desde las tareas incluidas en un pase consolidado.
12. Preparar `docs/deploy/manifest_pase.md` con alcance, tareas incluidas, tareas excluidas, objetos, datos de configuracion permitidos, dependencias, validaciones y responsable. El manifiesto final debe registrar el SHA publicado que representa todo el contenido promovido.
13. Preparar `docs/deploy/deploy.sql` como archivo principal y separar los cambios en:
   - `00_backup_produccion.sql`
   - `01_estructura.sql`
   - `02_datos_configuracion.sql`
   - `03_paquetes.sql`
   - `04_validacion_post.sql`
14. `00_backup_produccion.sql` es respaldo o reversa, no debe ejecutarse dentro de `deploy.sql`.
15. Incluir en `deploy.sql` el encabezado del pase, alcance, ambiente origen, ambiente destino, responsable, orden de ejecucion y referencias a los scripts aplicables.
16. Validar que no falten datos de configuracion requeridos por LOV, UDC, menus, permisos, parametros, rutas de aprobacion o listas usadas por la funcionalidad.
   - Si el pase requiere URLs, endpoints o rutas base, confirmar con el usuario el valor productivo y registrarlo en el manifiesto. Si falta, marcar `Pendiente URL PRODUCCION` y no ejecutar el pase de esa configuracion.
17. `02_datos_configuracion.sql` solo debe incluir datos de configuracion o catalogo necesarios. Para UDC usar scripts idempotentes sobre `DATA.T_CORP_UDC`. No incluir data transaccional, data de prueba ni copias masivas desde test salvo instruccion explicita del usuario.
   - Para URLs por ambiente, incluir en `02_datos_configuracion.sql` el `MERGE` o `UPDATE` de PRODUCCION con el valor productivo confirmado; no copiar valores TEST ni inferirlos.
18. Validar que paquetes, vistas, tablas y datos queden en orden de dependencia y que el script de validacion compruebe objetos invalidos y registros clave.
19. Ejecutar `python scripts/production_deploy_tool.py validate --project-root . --task-id <ID_TAREA>` durante preparacion. Antes de PRODUCCION, repetir con `--for-production` para exigir ID, repo, rama local, rama oficial `main`, SHA base y que el commit candidato TEST/QA sea exactamente el publicado en `origin/main`.
20. Antes de declarar `Listo para pase`, validar y registrar estos gates minimos:
   - commit candidato creado antes de compilar/importar TEST.
   - TEST identificado y verificado contra el commit candidato.
   - QA aprobado para ese mismo commit.
   - commit aprobado integrado y publicado directamente en `origin/main` antes de PRODUCCION; no dejarlo solo en rama de tarea o PR.
   - TEST compilado y validado para los objetos del alcance.
   - `qa/tareas/<ID_TAREA>/reports/informe_qa.md` con recomendacion `Aprobado para cierre` para el mismo commit candidato.
   - si aplica `Pase Consolidado`, QA/regresion minima del bloque completo y manifiesto con tareas incluidas/excluidas.
   - `docs/pases-produccion/control_cambios.md` actualizado con tareas y objetos pendientes.
   - `docs/deploy/manifest_pase.md` completo.
   - `docs/deploy` validado con `production_deploy_tool.py validate`.
   - respaldo productivo definido o evidencia alternativa registrada para APEX cuando el backup por API no sea viable.
   - autorizacion productiva pendiente o confirmada, diferenciando claramente si el pase solo esta preparado o si se ejecutara. Una orden inicial que incluya expresamente TEST y PRODUCCION con condicion de QA vale como autorizacion condicionada; no requiere reconfirmacion despues de QA.
21. Si solo se pidio preparar el pase, detenerse despues de validar `docs/deploy`, informar `Pase preparado, no ejecutado`, listar pendientes para ejecucion productiva y no conectar a produccion para ejecutar DDL, DML, PL/SQL ni import APEX.
22. Ejecutar en produccion solo cuando el usuario lo autorice explicitamente con una instruccion clara como `ejecuta el pase en produccion`, `pasemos a produccion`, `aplica el deploy en produccion`, o cuando la solicitud original haya indicado expresamente `TEST y PRODUCCION si QA aprueba`. Esta ultima es autorizacion condicionada: no ejecutar antes de QA aprobado, pero tampoco pedir una confirmacion adicional despues. Una solicitud de preparar, revisar, validar o armar pase no autoriza ejecucion productiva.
23. Antes de ejecutar en produccion, confirmar que el pase corresponde solo a cambios pendientes y que no duplica cambios ya pasados.
   - confirmar tambien que el objeto productivo actual coincide con el predecesor esperado; si difiere, bloquear por `STALE_BASE` y reconciliar.
   - confirmar que el commit del manifiesto existe en `origin/main`; una rama `codex/*` o PR pendiente no cumple el gate de publicacion.
24. Ejecutar/importar en produccion de forma ordenada: respaldo disponible, estructura, datos de configuracion, paquetes/codigo, import APEX si aplica segun el mecanismo autorizado, y por ultimo validacion post. Para DDL, DML de configuracion y PL/SQL del paquete versionado usar exclusivamente `python scripts/execute_oracle_deploy.py docs/deploy/deploy.sql --environment prod --expected-sha256 <SHA256_DEPLOY> --source-repo <CHECKOUT_LIMPIO_EN_SHA_PUBLICADO> --expected-source-commit <SHA_PUBLICADO> --timing-log <LOG>`; el ejecutor conserva el SQL, resuelve solo los `@@` versionados y se detiene ante el primer error. No cambiar de cliente ni de conector despues de un fallo: informar si el cliente previo no envio DDL y usar este ejecutor oficial solo cuando la autorizacion productiva ya cubra el pase. Para APEX usar `python scripts/import_apex_sql_via_python.py <export.sql> --environment prod` como camino normal. No probar `sqlplus`, `SQLcl` ni clientes alternativos salvo autorizacion explicita y registro de por que el importador Python no aplica. El importador Python fija `g_security_group_id` desde `p_default_workspace_id` del export; si el import esta habilitado con `CURRENT_SCHEMA=DATA` y el export viene de TEST verificado, proceder con el import. Para reemplazo completo de aplicacion con reportes IR residuales, usar `--pre-remove-application --cleanup-orphan-ir-reports` solo despues de contar con respaldo productivo.
25. Despues de cada bloque ejecutado, validar compilacion o estado antes de continuar. Para objetos de base usar `python scripts/production_deploy_tool.py validate-prod-compile --objects TIPO:OWNER.OBJETO ...` o consulta equivalente a `ALL_OBJECTS`.
   - La validacion de objetos `VALID` es obligatoria para todo pase a produccion que incluya tablas, vistas, paquetes, package bodies, funciones, procedimientos, triggers, jobs, synonyms o secuencias.
   - Para paquetes, validar por separado `PACKAGE` y `PACKAGE BODY`; un body `INVALID` impide declarar la entrega tecnica completa aunque el spec este `VALID`, pero no cambia el estado de la tarea.
   - Si aparece cualquier objeto `INVALID`, consultar `ALL_ERRORS`, corregir o recompilar con la fuente vigente autorizada, repetir la validacion y dejar evidencia del estado final.
   - No cerrar el pase, no marcarlo como `Pasado` y no informar que produccion quedo correcta si falta evidencia de `ALL_OBJECTS.STATUS = 'VALID'` para los objetos del alcance.
   - `VALID` no prueba identidad de version. Para objetos versionados, extraer o normalizar el objeto productivo final y compararlo contra el commit publicado; bloquear si no coincide.
26. Si el bloque incluye jobs de `DATA`, aplicar reglas de cambio minimo:
   - Job existente: leer estado previo con `python scripts/production_deploy_tool.py describe-job --environment prod --job OWNER.NOMBRE_JOB`; modificar solo lo solicitado; preservar `start_date`, `repeat_interval`, `enabled`, zona horaria, clase, comentarios y demas atributos; volver a ejecutar `describe-job` y confirmar que solo cambio el atributo pedido.
   - Job nuevo: pedir al usuario horario/frecuencia de ejecucion antes de crearlo. No crear jobs nuevos con `repeat_interval = NULL` o `start_date` accidental salvo que el usuario indique que sera manual o de una sola ejecucion.
   - Para jobs de `DATA`, usar el camino corporativo por `DATA.PK_CORP_COMMONS.SP_CREA_JOB` como primera opcion. No usar `DBMS_SCHEDULER.SET_ATTRIBUTE`; ejecutar `python scripts/production_deploy_tool.py describe-commons-job-procedure --environment prod`, crear o ejecutar el job autorizado por Commons, validar `ALL_SCHEDULER_JOBS` y registrar evidencia.
27. Hacer validacion productiva minima con usuario autorizado y datos no sensibles:
   - objetos de base: confirmar `VALID` en `ALL_OBJECTS` y que vistas/consultas de validacion no fallen
   - paquetes/procedimientos: confirmar compilacion y existencia de firma esperada cuando aplique
   - jobs/configuracion: confirmar estado, definicion o registro configurado sin ejecutar procesos masivos
   - APEX: confirmar metadata/pagina importada y carga inicial de pantalla principal o pagina afectada sin repetir QA funcional completo
   - no crear, modificar, aprobar, cargar, eliminar ni procesar datos reales salvo autorizacion explicita
28. Despues de ejecutar o cerrar el pase, generar o actualizar `docs/pases-produccion/<YYYYMMDD_HHMM>_<descripcion>/informe_pase.md` con resumen de ejecucion, usuario, fecha/hora, ambiente origen/destino, objetos, scripts, backups, validacion post, errores, estado final y pendientes.
29. Despues de ejecutar o cerrar el pase, copiar el contenido completo a `docs/pases-produccion/<YYYYMMDD_HHMM>_<descripcion>/` junto con manifiesto, backup, informe y evidencias.
30. Actualizar `docs/pases-produccion/control_cambios.md` marcando cada tarea/objeto como `Pasado`, `Pendiente`, `Excluido` o `Fallido`.
31. Vaciar `docs/deploy` despues de archivar el pase, dejando como maximo `.gitkeep`.
32. Registrar en `docs/bitacora.md` el resultado del pase, la ruta del respaldo, la ruta de `informe_pase.md` y cualquier pendiente.
33. Si PRODUCCION termino correctamente y la validacion post esta completa, entregar al contexto invocador el resultado `Pasado`, SHA ejecutado y ruta de evidencia. Si el pase queda fallido, parcial o solo preparado, reportar ese resultado tecnico real. El skill no actualiza estados, contratos ni bitacoras de coordinacion.

Razon:
- Separar estructura, datos de configuracion y paquetes reduce omisiones, evita pisar scripts anteriores y permite revisar el pase antes de ejecutarlo.
- Archivar cada pase cerrado mantiene trazabilidad sin contaminar `docs/deploy` para la siguiente tarea.
- El control de cambios evita volver a pasar objetos ya publicados y permite identificar pendientes reales entre test y produccion.
- Restringir datos a configuracion evita contaminar produccion con data de pruebas.
- Usar una herramienta local para scaffolding, extraccion y validacion reduce preguntas repetitivas y deja criterios reproducibles antes de tocar produccion.
- Respaldar produccion antes del pase permite reversa controlada si un objeto no compila o la validacion productiva minima falla.
- En APEX, la falta de export productivo completo por API no debe paralizar un pase autorizado cuando el import productivo esta habilitado y el export TEST esta verificado; se compensa con evidencia y validacion post.
- Separar preparacion y ejecucion evita que una revision de pase termine modificando produccion sin autorizacion explicita.
- El informe final del pase deja una evidencia unica y verificable de que se ejecuto, que se valido y que pendientes quedaron.
- El `Pase Consolidado` evita pasar cambios incompletos acumulados en TEST, fuerza trazabilidad por tarea y confirma que el bloque productivo nace de GitHub y no de memoria de sesiones.

Ejemplo:
- Para una funcionalidad nueva con tabla, vista, UDC, LOV y paquete: `01_estructura.sql` crea o altera tabla y vista; `02_datos_configuracion.sql` inserta UDC/LOV/configuracion; `03_paquetes.sql` compila paquete; `04_validacion_post.sql` valida objetos y datos clave; `deploy.sql` ejecuta todo en orden.
- Para una correccion productiva de un paquete ya publicado: diagnosticar el error real en produccion, desarrollar y corregir en TEST, validar compilacion y QA si afecta pantalla, preparar `03_paquetes.sql`, pasar a produccion y ejecutar solo validacion productiva minima.

### Formato minimo de control de cambios

Crear o actualizar `docs/pases-produccion/control_cambios.md` con una tabla como:

```markdown
| ID tarea | Descripcion | Tipo | Objeto/Dato | Ambiente test | Ambiente produccion | Estado pase | Pase/Fecha | Evidencia |
|---|---|---|---|---|---|---|---|---|
| C.1 | Ajuste de reporte | Paquete | DATA.PK_MODULO | Compilado VALID | Pendiente | Pendiente | | docs/tareas/C.1/logs/... |
```

Estados de pase permitidos:

```text
Pendiente
Incluido en deploy
Pasado
Excluido
Fallido
Requiere ajuste
```

### Formato minimo del manifiesto de pase

Crear `docs/deploy/manifest_pase.md` con:

```markdown
# Manifiesto De Pase A Produccion

- Fecha:
- Ambiente origen: TEST
- Ambiente destino: PRODUCCION
- Responsable:
- Solicitud o alcance:
- ID tarea:
- Repo fuente:
- Rama local de tarea:
- Rama oficial de publicacion: main
- Commit base:
- Commit candidato validado en TEST:
- Commit aprobado y publicado en origin/main:

## Tareas incluidas

| ID | Tarea | Motivo | Checkpoint test | Estado QA |
|---|---|---|---|---|

## Tareas excluidas

| ID | Tarea | Motivo de exclusion | Pendiente para futuro pase |
|---|---|---|---|

## Objetos incluidos

| Orden | Tipo | Objeto | Archivo fuente | Commit/blob | SHA256 fuente | Script | Dependencias |
|---|---|---|---|---|---|---|---|

## Datos de configuracion incluidos

| Tipo | Tabla | Clave funcional | Script | Justificacion |
|---|---|---|---|---|

## Excluido del pase

| Elemento | Motivo |
|---|---|

## Validacion post

| Validacion | Script/Evidencia |
|---|---|

La seccion de validacion post debe incluir una fila especifica de `ALL_OBJECTS` para confirmar `VALID` de cada objeto de base incluido. Para paquetes, registrar filas separadas para `PACKAGE` y `PACKAGE BODY`.
```

### Formato minimo del informe final de pase

Crear `docs/pases-produccion/<YYYYMMDD_HHMM>_<descripcion>/informe_pase.md` con:

```markdown
# Informe De Pase A Produccion

- Fecha y hora:
- Responsable/agente:
- Usuario productivo:
- Ambiente origen: TEST
- Ambiente destino: PRODUCCION
- Solicitud o alcance:
- ID tarea:
- Commit aprobado por QA:
- Commit publicado en GitHub:
- Commit ejecutado en PRODUCCION:
- Estado final: Pasado / Fallido / Parcial / Preparado no ejecutado

## Resumen

## Scripts o imports ejecutados

| Orden | Script/import | Resultado | Evidencia |
|---|---|---|---|

## Objetos y componentes incluidos

| Tipo | Objeto / APP_ID / PAGE_ID | Estado TEST | Estado PRODUCCION | Evidencia |
|---|---|---|---|---|

## Backups y reversa

| Elemento | Ruta / evidencia | Observacion |
|---|---|---|

## Validacion post

| Validacion | Resultado | Evidencia |
|---|---|---|

## Errores o incidencias

## Pendientes
```

## 11. Entregables

Segun el caso, produce:
- resumen ejecutivo
- propuesta tecnica
- script SQL o PL/SQL
- informe QA funcional
- evidencia visual de pantallas
- inventario, hechos y evidencia fuente para el manual funcional o documento tecnico que genere `documentacion-proyecto-sistemas`
- paquete de paso a produccion en `docs/deploy` cuando aplique
- respaldo del pase cerrado en `docs/pases-produccion/<YYYYMMDD_HHMM>_<descripcion>/` cuando se haya ejecutado o cerrado
- lista de objetos no encontrados o referencias remotas validadas
