# Reutilizacion Y Commons PL/SQL

## Objetivo

Evitar duplicidad de logica reutilizable entre paquetes del mismo modulo sin convertir los paquetes Commons en contenedores genericos, SQL dinamico o dependencias ciclicas.

## Capas De Reutilizacion

| Destino | Cuando usarlo | Dependencias permitidas | Ejemplos |
|---|---|---|---|
| Rutina local PK_modulo_nombre | Un solo proceso o entidad del paquete | Tablas y reglas exclusivas del proceso | CRUD, calculo o validacion de una entidad |
| PK_modulo_COMMONS | Dos o mas consumidores del mismo modulo, con responsabilidad transversal del dominio | Solo contratos y datos compartidos por ese modulo; nunca dependencia ciclica | normalizacion, reglas de configuracion, exportacion o validacion transversal CNTR |
| PK_CORP_nombre | Dos o mas aplicaciones o modulos independientes requieren el mismo contrato corporativo | Infraestructura o tablas corporativas genericas; nunca tablas, items APEX, roles o estados exclusivos de un proyecto | correo corporativo, flujo de aprobacion, validaciones genericas, utilidades de ambiente |

Un paquete corporativo no es un Commons mas grande: es una API de plataforma. Su contrato debe ser estable, versionado y compatible hacia atras. Las aplicaciones lo consumen; no se permite que un PK_CORP_ conozca tablas funcionales de CNTR, ICOM, VTAS u otro proyecto.

## Decision Y Aprobacion

El agente debe entregar una Propuesta de reutilizacion antes de crear o ampliar cualquier Commons. La propuesta incluye problema y duplicidad comprobada, consumidores actuales y potenciales, destino sugerido, contrato spec propuesto, dependencias/tablas, seguridad, migracion, pruebas y riesgo de regresion.

| Si se cumple | Decision |
|---|---|
| Solo un consumidor o datos/reglas exclusivos | Mantener local |
| Dos o mas consumidores del mismo modulo y no hay potencial corporativo comprobable | Proponer Commons de modulo |
| Dos o mas aplicaciones o modulos independientes, sin tablas/reglas propias, con contrato generico y estable | Proponer PK_CORP_nombre |
| El proceso aun depende de una tabla, estado, usuario o autorizacion de un proyecto | No promover; mantener local o de modulo |

Crear, ampliar, mover una rutina o cambiar consumidores hacia Commons de modulo o corporativo requiere aprobacion explicita del usuario sobre esa propuesta. El detector solo genera evidencia; no modifica la arquitectura por inferencia.

## Diagnostico Obligatorio

Cuando una tarea cree o modifique un PACKAGE o PACKAGE BODY, ejecutar:

    python scripts/analyze_plsql_reuse.py --root <SOURCE_REPO_ROOT> --module <MODULO> --output <ARTEFACTO_MD>

MODULO es el prefijo funcional del objeto, por ejemplo CNTR para PK_CNTR_*; no es el APP_ID. El reporte compara paquetes PK_<MODULO>_* versionados dentro del modulo indicado. Es una señal de revision, no una prueba de equivalencia funcional.

Antes de copiar, extraer o crear una rutina, el desarrollo debe clasificar cada candidato como:

- No duplicado: coincidencia incidental o parte estructural de PL/SQL.
- Mantener local: la logica parece similar, pero depende de una tabla, flujo, autorizacion o contrato exclusivo.
- Extraer a Commons: la responsabilidad es transversal, el contrato puede ser estable y no introduce dependencia ciclica.
- Deuda aceptada: duplicidad temporal con justificacion, propietario y criterio de retiro.

## PK_<MODULO>_COMMONS

Crear o ampliar PK_<MODULO>_COMMONS solo cuando el alcance autorice la extraccion y se cumplan todos:

1. La logica aparece o se justifica para al menos dos consumidores del mismo modulo.
2. Tiene responsabilidad funcional transversal y un contrato estable.
3. No depende de tablas, estados, parametros o autorizaciones exclusivas de un paquete consumidor.
4. No requiere SQL dinamico para elegir tablas, columnas o reglas de negocio.
5. No crea dependencia ciclica con sus consumidores.
6. El nuevo PACKAGE SPEC documenta el contrato y cada consumidor usa la rutina Commons en lugar de conservar una copia.
7. Se prueban el caso principal y regresiones de todos los consumidores afectados.

Ejemplos apropiados: normalizacion comun, validacion transversal, exportacion reutilizable, reglas de auditoria o conversiones compartidas.

Ejemplos no apropiados: CRUD de una entidad concreta, MERGE contra tablas distintas escogidas dinamicamente, autorizacion especifica de una pantalla o una excepcion por registro.

El detector nunca crea PK_<MODULO>_COMMONS ni reescribe consumidores por su cuenta. Genera evidencia y propuesta; la extraccion es un cambio de arquitectura que exige alcance y validacion.

## Paquete Corporativo

Proponer un PK_CORP_nombre solo cuando se cumplan todos:

1. Hay al menos dos aplicaciones o modulos independientes que lo necesitan, o existe un requerimiento corporativo aprobado y verificable.
2. La responsabilidad es generica y no depende de tablas funcionales, paginas APEX, items, roles, estados ni configuracion exclusiva de un proyecto.
3. El contrato recibe datos genericos mediante parametros tipados; no usa SQL dinamico para adivinar tablas, columnas o reglas del consumidor.
4. La spec documenta proposito, parametros, resultados, errores, seguridad, transaccion y compatibilidad.
5. El paquete no hace COMMIT o ROLLBACK salvo excepcion corporativa expresamente aprobada y documentada.
6. Tiene propietario corporativo, version o compatibilidad de contrato y pruebas con todos los consumidores.
7. El usuario aprueba la propuesta antes de crear el package o migrar consumidores.

## Gate Pre-TEST

Para cada paquete modificado:

1. Ejecutar validate_plsql_package_standards.py sobre su spec/body y exigir PLSQL_STATIC_AUDIT_PASS.
2. Ejecutar analyze_plsql_reuse.py para el modulo y adjuntar el reporte a la auditoria pre-TEST.
3. Resolver, justificar o registrar como deuda aceptada cualquier candidato COMMONS_CANDIDATE.
4. Si se crea o modifica Commons, inventariar las rutinas extraidas y probar los consumidores afectados.

No crear una abstraccion solo porque dos fragmentos tienen el mismo texto. La duplicidad debe ser funcional, no solamente sintactica.
