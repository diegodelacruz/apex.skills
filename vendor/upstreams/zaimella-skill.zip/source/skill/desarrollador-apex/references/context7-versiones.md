# Context7 Y Versiones Oracle/APEX/HANA

## Objetivo

Usar Context7 como apoyo de documentacion tecnica externa sin perder la realidad versionada de Zaimella.

En este skill, Oracle Database, Oracle APEX y SAP HANA son tecnologias corporativas versionadas. Para esas tecnologias no se debe consultar Context7 con la version mas reciente por defecto ni consultar la base en cada tarea para redescubrir versiones si el trabajo depende de sintaxis, APIs, metadata, compatibilidad, comportamiento del motor, paquetes, integraciones, deploy o diagnostico.

## Versiones corporativas fijas

Estas versiones son la fuente de verdad del skill para Context7 y documentacion tecnica externa:

| Tecnologia | Version corporativa | Fuente de confirmacion |
| --- | --- | --- |
| Oracle Database | Oracle Database 21c Standard Edition 2 Release 21.0.0.0.0 | `validate_oracle_connectivity.py --environment test` y `v$version` en el ambiente TEST parametrizado, confirmado el 2026-07-06 |
| Oracle APEX | 24.1.3 | `APEX_RELEASE.VERSION_NO` en el ambiente TEST parametrizado, confirmado el 2026-07-06 |
| Esquema APEX activo | `APEX_240100` | referencias internas del skill y objetos APEX existentes |
| SAP HANA | 2.00.056.00.1624618329 | `M_DATABASE.VERSION` en HANA Peru PROD y HANA Guatemala PROD, confirmado el 2026-07-06 |
| Oracle REST Data Services (ORDS) | 23.1.3.r1371032 | `ORDS.INSTALLED_VERSION` en Oracle TEST y PRODUCCION, confirmado el 2026-08-12 |

No vuelvas a consultar estas versiones como parte rutinaria de cada tarea. Solo actualiza esta tabla cuando el usuario pida revisar la matriz corporativa de versiones, cuando DBA/Sistemas confirme una migracion, o cuando una evidencia formal del proyecto demuestre que el ambiente corporativo cambio.

## Regla obligatoria

Antes de usar Context7 para Oracle Database, Oracle APEX o SAP HANA:

1. Usa la version corporativa fija documentada en la tabla anterior.
2. Consulta Context7 usando esa version o la version compatible mas cercana.
3. Si Context7 no tiene documentacion exacta para esa version, usa la version compatible mas cercana y reporta la diferencia cuando pueda afectar la solucion.
4. No ejecutes consultas de version contra Oracle, APEX o HANA solo para decidir que version usar en Context7.

Para ORDS usa la version corporativa fija y las reglas de `./ords.md`. Para otras tecnologias relacionadas, como JavaScript de APEX, Python `oracledb`, Playwright, herramientas CLI o librerias auxiliares, aplica la politica general de Context7 cuando este disponible: version indicada por usuario, proyecto o ambiente; si no existe, version mas reciente disponible.

## Revalidacion excepcional de versiones

La revalidacion de versiones solo aplica si el usuario lo pide explicitamente o si hay una migracion confirmada. En ese caso, usa las fuentes siguientes y actualiza esta referencia en la misma tarea.

### Oracle Database

Fuentes aceptadas:

- salida de `scripts/validate_oracle_connectivity.py` cuando reporte motor o banner
- consulta de lectura con `scripts/oracle_sql_tool.py` al `v$version` del ambiente autorizado
- documentacion local del proyecto, `desarrollo.md`, `docs/` o bitacora, si el ambiente no esta disponible

Consulta orientativa cuando el acceso este autorizado:

```powershell
python scripts/oracle_sql_tool.py query --environment test --sql "select banner from v`$version where rownum = 1"
```

Para produccion, usar `--environment prod` solo cuando el flujo productivo este autorizado.

### Oracle APEX

Fuentes aceptadas:

- metadata del export APEX `.sql` vigente
- esquema APEX activo identificado en el export, por ejemplo `APEX_240100`
- metadata APEX disponible en base, como `APEX_RELEASE`, si el usuario y el ambiente tienen permisos
- documentacion local del proyecto o bitacora cuando no exista acceso a base

Si el export y la base no coinciden durante una revalidacion excepcional, reporta ambas versiones y decide con el usuario o con el flujo operativo cual es la fuente vigente antes de implementar cambios dependientes de version.

### SAP HANA

Fuentes aceptadas:

- configuracion corporativa por compania en `./references/conectividad-oracle.md` y `./references/erp-config/`
- validacion directa con `scripts/validate_hana_connectivity.py` cuando aplique
- consulta de metadata HANA con `scripts/hana_sql_tool.py` cuando la conexion directa este autorizada y el usuario/esquema tenga permisos sobre vistas de sistema
- evidencia del puente Oracle `@HANA_PE` o `@HANA_ABX` solo para estructura y datos disponibles por el puente; no usarla como unica prueba de version HANA

Peru y Guatemala deben respetar las reglas de conectividad HANA definidas en `./references/conectividad-oracle.md`. Guatemala no tiene ambiente HANA test en el estandar actual. Si HANA Peru TEST reporta un problema de esquema, no lo uses para revalidar version; valida con Peru PROD o Guatemala PROD bajo autorizacion correspondiente.

## Uso de Context7

Usa Context7 cuando necesites confirmar documentacion externa versionada sobre:

- sintaxis SQL, PL/SQL, paquetes, vistas de diccionario o comportamiento Oracle
- APIs, utilidades, metadata, JavaScript o componentes Oracle APEX
- comportamiento, SQL, metadata o funciones SAP HANA
- compatibilidad de ORDS, drivers, librerias o herramientas auxiliares

No uses Context7 para reemplazar:

- estandares APEX de Zaimella
- estandares de base de datos del skill
- conectividad, credenciales, ambiente o rutas corporativas
- diccionarios ERP internos
- evidencia real del export, base, HANA, logs o QA
- autorizaciones para produccion

## Salida esperada

Cuando Context7 influya en una decision tecnica relevante, informa o registra:

```text
Context7 usado:
- Tecnologia:
- Version corporativa:
- Fuente de version: skill/desarrollador-apex/references/context7-versiones.md
- Tema consultado:
- Aplicacion en el cambio:
```

Si Context7 no tiene la version exacta, indica la version compatible consultada y el riesgo o diferencia que podria afectar la solucion.
