#!/usr/bin/env python3
"""Registra páginas APEX y accesos: uno base por página/rol y varios específicos por componente."""
from __future__ import annotations

import argparse, os, re
from pathlib import Path
import oracledb

SET_RE = re.compile(r'^\s*set\s+"(ZAIMELLA_ORACLE_[A-Z_]+)=(.*)"\s*$', re.I)

def load_env() -> None:
    base = Path(os.environ.get("ZAIMELLA_ENV_DIR", Path.home() / ".zaimella"))
    for name in ("configurar_oracle_env.cmd", "configurar_oracle_env.local.cmd"):
        path = base / name
        if path.exists():
            for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
                match = SET_RE.match(line)
                if match and match.group(2).strip() and not match.group(2).startswith("<"):
                    os.environ.setdefault(match.group(1).upper(), match.group(2).strip())

def q(value: str | None) -> str:
    return "NULL" if value is None else "'" + value.replace("'", "''") + "'"

def sql(args: argparse.Namespace) -> str:
    menu = 1 if args.menu else 0
    parent = q(args.parent_page_code)
    icon = q(args.icon_css)
    role = "" if args.role_id is None else f"""
merge into data.t_admi_rolaccesos t
using (select {args.role_id} id_rol, p.id id_modulopagina from data.t_admi_modulopagina p where p.codigomodulo={q(args.module_code)} and p.codigopagina={q(args.page_code)}) s
on (t.id_rol=s.id_rol and t.id_modulopagina=s.id_modulopagina and nvl(t.codigoaccion,'~')=nvl({q(args.action_code)},'~') and nvl(t.codigo_tg,'~')=nvl({q(args.trigger_code)},'~'))
when matched then update set t.estado=1, t.usuario_aud={q(args.audit_user)}, t.fechamodificacion=sysdate, t.agregar={args.add}, t.guardar={args.save}, t.eliminar={args.delete}, t.comentar={args.comment}, t.imprimir={args.print_}, t.cancelar={args.cancel}
when not matched then insert (id_rol,id_modulopagina,estado,usuario_aud,fechacreacion,codigoaccion,codigo_tg,agregar,guardar,eliminar,comentar,imprimir,cancelar)
values (s.id_rol,s.id_modulopagina,1,{q(args.audit_user)},sysdate,{q(args.action_code)},{q(args.trigger_code)},{args.add},{args.save},{args.delete},{args.comment},{args.print_},{args.cancel});"""
    user = "" if not args.test_user else f"""
merge into data.t_admi_rolusuario t
using (select {args.role_id} id_rol from dual) s
on (t.id_rol=s.id_rol and t.codigomodulo={q(args.module_code)} and t.codigocompania={q(args.company)} and t.codigousuario={q(args.test_user)} and t.estado=1)
when not matched then insert (id_rol,codigomodulo,codigocompania,codigousuario,estado,usuario_aud,fechacreacion)
values (s.id_rol,{q(args.module_code)},{q(args.company)},{q(args.test_user)},1,{q(args.audit_user)},sysdate);"""
    menu_label = args.menu_label or args.page_name
    return f"""-- Generado por apex_menu_access_tool.py. Ejecutar solo para TEST y versionar en el deploy de la tarea.
merge into data.t_admi_modulopagina t
using (select {q(args.module_code)} codigomodulo, {q(args.page_code)} codigopagina from dual) s
on (t.codigomodulo=s.codigomodulo and t.codigopagina=s.codigopagina)
when matched then update set t.descripcion={q(args.page_name)}, t.orden={args.order}, t.rutapagina={q(args.route)}, t.estado=1, t.usuario_aud={q(args.audit_user)}, t.fechamodificacion=sysdate, t.opcionmenu={q(menu_label if menu else args.page_name)}, t.iconocss={icon}, t.codigopadre={parent}, t.nivel={args.level}
when not matched then insert (codigopagina,codigomodulo,descripcion,orden,rutapagina,estado,usuario_aud,fechacreacion,opcionmenu,iconocss,codigopadre,nivel)
values ({q(args.page_code)},{q(args.module_code)},{q(args.page_name)},{args.order},{q(args.route)},1,{q(args.audit_user)},sysdate,{q(menu_label if menu else args.page_name)},{icon},{parent},{args.level});
{role}
{user}
"""

def main() -> int:
    parser = argparse.ArgumentParser(description="Prepara o aplica alta/actualización de página, menú y accesos APEX en TEST.")
    parser.add_argument("--module-code", required=True); parser.add_argument("--page-code", required=True)
    parser.add_argument("--page-name", required=True); parser.add_argument("--route", required=True)
    parser.add_argument("--audit-user", required=True); parser.add_argument("--order", type=int, default=1)
    parser.add_argument("--level", type=int, default=3); parser.add_argument("--parent-page-code"); parser.add_argument("--icon-css")
    parser.add_argument("--menu", action="store_true"); parser.add_argument("--menu-label")
    parser.add_argument("--role-id", type=int, required=True); parser.add_argument("--test-user"); parser.add_argument("--company", default="00001")
    parser.add_argument("--action-code", help="Permiso específico de componente; omitir para el acceso base de página.")
    parser.add_argument("--trigger-code", help="Código técnico opcional asociado al permiso específico.")
    for flag, dest in (("add","add"),("save","save"),("delete","delete"),("comment","comment"),("print","print_"),("cancel","cancel")):
        parser.add_argument(f"--{flag}", dest=dest, type=int, choices=(0,1), default=1)
    parser.add_argument("--environment", choices=("test",), default="test", help="Este helper solo puede aplicar configuracion en TEST.")
    parser.add_argument("--output", required=True); parser.add_argument("--apply-test", action="store_true")
    args=parser.parse_args()
    if args.trigger_code and not args.action_code: parser.error("--trigger-code requiere --action-code")
    rendered=sql(args); output=Path(args.output); output.parent.mkdir(parents=True, exist_ok=True); output.write_text(rendered, encoding="utf-8")
    kind = "ACCESO_ESPECIFICO" if args.action_code else "ACCESO_BASE_PAGINA"
    print(f"SCRIPT_READY {output} TYPE={kind}")
    if not args.apply_test: return 0
    load_env(); required=["ZAIMELLA_ORACLE_HOST","ZAIMELLA_ORACLE_PORT","ZAIMELLA_ORACLE_SID","ZAIMELLA_ORACLE_USER","ZAIMELLA_ORACLE_PASSWORD"]
    missing=[n for n in required if not os.environ.get(n)]
    if missing: raise RuntimeError("Faltan variables Oracle TEST: " + ", ".join(missing))
    host, port, sid = os.environ["ZAIMELLA_ORACLE_HOST"], os.environ["ZAIMELLA_ORACLE_PORT"], os.environ["ZAIMELLA_ORACLE_SID"]
    if host == os.environ.get("ZAIMELLA_ORACLE_PROD_HOST") or sid == os.environ.get("ZAIMELLA_ORACLE_PROD_SID"):
        raise RuntimeError("Proteccion de ambiente: la configuracion TEST coincide con PRODUCCION; no se aplica el acceso.")
    print(f"TEST_TARGET host={host} port={port} sid={sid}")
    dsn=oracledb.makedsn(host, int(port), sid=sid)
    with oracledb.connect(user=os.environ["ZAIMELLA_ORACLE_USER"], password=os.environ["ZAIMELLA_ORACLE_PASSWORD"], dsn=dsn) as conn:
        executable = re.sub(r"^--.*$", "", rendered, flags=re.MULTILINE)
        with conn.cursor() as cur:
            cur.execute("select sys_context('USERENV','DB_NAME') from dual")
            db_name = str(cur.fetchone()[0])
            if db_name.upper() == str(os.environ.get("ZAIMELLA_ORACLE_PROD_SID", "")).upper():
                raise RuntimeError(f"Proteccion de ambiente: conectado a PRODUCCION ({db_name}); no se aplica el acceso.")
            for statement in [s.strip() for s in executable.split(";") if s.strip()]: cur.execute(statement)
        conn.commit()
    print("TEST_APPLIED OK")
    return 0

if __name__ == "__main__": raise SystemExit(main())
