#!/usr/bin/env python3
"""Valida estandares obligatorios de documentacion y legibilidad PL/SQL."""
from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import asdict, dataclass
from pathlib import Path

ROUTINE = re.compile(r"(?im)^\s*(procedure|function)\s+([a-z][a-z0-9_$#]*)\b")
PACKAGE = re.compile(r"(?im)^\s*create\s+or\s+replace\s+package(?:\s+body)?\s+")
COMMIT_ROLLBACK = re.compile(r"\b(?:commit|rollback)\b", re.IGNORECASE)
COMPLEX_MARKERS = re.compile(r"\b(?:insert\s+into|update\s+|delete\s+from|merge\s+into|for\s+\w+\s+in|exception)\b", re.IGNORECASE)
COMMENTS = re.compile(r"/\*.*?\*/|--[^\n]*", re.DOTALL)
# El asterisco de COUNT(*) no es una proyeccion de columnas y permanece valido.
SELECT_STAR = re.compile(
    r"\bselect\s+(?:distinct\s+)?(?:[a-z][a-z0-9_$#]*\s*\.\s*)?\*",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class Finding:
    severity: str
    rule: str
    file: str
    line: int
    message: str


def line(text: str, offset: int) -> int:
    return text.count("\n", 0, offset) + 1


def is_body(path: Path, text: str) -> bool:
    return "PACKAGE BODY" in text.upper() or "BODIES" in {part.upper() for part in path.parts}


def previous_comment(lines: list[str], index: int) -> bool:
    if index == 0:
        return False
    previous = lines[index - 1].strip()
    return previous.endswith("*/") or previous.startswith("--")


def routine_end(text: str, start: int, name: str) -> int:
    match = re.search(rf"(?im)^\s*end\s+{re.escape(name)}\s*;", text[start:])
    return start + match.end() if match else len(text)


def audit(path: Path) -> list[Finding]:
    text = path.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()
    findings: list[Finding] = []

    def add(severity: str, rule: str, offset: int, message: str) -> None:
        findings.append(Finding(severity, rule, str(path), line(text, offset), message))

    if not PACKAGE.search(text):
        add("ERROR", "PLSQL-PACKAGE-001", 0, "El archivo no contiene CREATE OR REPLACE PACKAGE o PACKAGE BODY.")
        return findings

    if not is_body(path, text):
        header = text[: min(len(text), 2500)]
        for required in ("Paquete:", "Objetivo:", "Responsable:"):
            if required.lower() not in header.lower():
                add("ERROR", "PLSQL-DOC-001", 0, f"El encabezado del package spec debe incluir '{required}'.")

    # Preserva longitud y saltos de linea para que los offsets de los
    # hallazgos correspondan con el archivo fuente, aun con comentarios largos.
    code_without_comments = COMMENTS.sub(
        lambda match: re.sub(r"[^\n]", " ", match.group(0)),
        text,
    )
    for match in COMMIT_ROLLBACK.finditer(code_without_comments):
        add("ERROR", "PLSQL-TRANS-001", match.start(), "No usar COMMIT o ROLLBACK dentro de paquetes consumidos por APEX sin excepcion autorizada.")

    for match in SELECT_STAR.finditer(code_without_comments):
        add(
            "ERROR",
            "PLSQL-SQL-001",
            match.start(),
            "No usar SELECT * ni alias.*; declarar solo las columnas consumidas. COUNT(*) es una agregacion permitida.",
        )

    offsets = 0
    for index, raw in enumerate(lines):
        if len(raw) > 140:
            add("ERROR", "PLSQL-FORMAT-001", offsets,
                f"La linea tiene {len(raw)} caracteres; dividir declaraciones, SQL o sentencias para conservar legibilidad.")
        offsets += len(raw) + 1

    routines = list(ROUTINE.finditer(text))
    for routine in routines:
        name = routine.group(2)
        start_line = line(text, routine.start()) - 1
        if not previous_comment(lines, start_line):
            scope = "privada o implementacion del body" if is_body(path, text) else "publica del spec"
            add("ERROR", "PLSQL-DOC-002", routine.start(),
                f"La rutina {name} ({scope}) debe tener comentario funcional propio inmediatamente antes de declararse.")
        declaration_line = lines[start_line]
        if re.search(r"\bis\b.*\b(?:begin|v_|p_)", declaration_line, re.IGNORECASE):
            add("ERROR", "PLSQL-FORMAT-002", routine.start(),
                f"La declaracion de {name} concentra parametros, variables o sentencias; usar formato multilínea.")

        end = routine_end(text, routine.start(), name)
        body = text[routine.start():end]
        if is_body(path, text) and COMPLEX_MARKERS.search(body) and not re.search(r"--|/\*", body):
            add("ERROR", "PLSQL-DOC-003", routine.start(),
                f"La rutina compleja {name} debe comentar los pasos funcionales internos relevantes.")

    for match in re.finditer(r"(?im)^\s*end\s+[a-z][a-z0-9_$#]*\s*;\s*\n\s*(procedure|function)\b", text):
        add("ERROR", "PLSQL-FORMAT-003", match.start(),
            "Separar rutinas consecutivas con una linea en blanco para mantener legibilidad.")
    return findings


def input_files(paths: list[str]) -> list[Path]:
    files: set[Path] = set()
    for raw in paths:
        path = Path(raw).resolve()
        if path.is_file():
            files.add(path)
        elif path.is_dir():
            files.update(path.rglob("PK_*.sql"))
        else:
            raise FileNotFoundError(raw)
    return sorted(files)


def main() -> int:
    parser = argparse.ArgumentParser(description="Valida documentacion, transacciones y formato de packages PL/SQL.")
    parser.add_argument("paths", nargs="+", help="Package spec/body o carpeta que contenga PK_*.sql.")
    parser.add_argument("--json", action="store_true", help="Emite resultado JSON.")
    args = parser.parse_args()
    try:
        files = input_files(args.paths)
    except FileNotFoundError as exc:
        print(f"RUTA_NO_ENCONTRADA: {exc}", file=sys.stderr)
        return 2
    if not files:
        print("SIN_PACKAGES: no se encontraron archivos PK_*.sql.", file=sys.stderr)
        return 2
    findings = [finding for path in files for finding in audit(path)]
    errors = [finding for finding in findings if finding.severity == "ERROR"]
    if args.json:
        print(json.dumps({"files": [str(path) for path in files], "findings": [asdict(item) for item in findings],
                          "result": "FAIL" if errors else "PASS"}, ensure_ascii=False, indent=2))
    else:
        for finding in findings:
            print(f"{finding.severity} {finding.rule} {finding.file}:{finding.line} {finding.message}")
        print(f"PLSQL_STATIC_AUDIT_{'FAIL' if errors else 'PASS'} files={len(files)} errors={len(errors)}")
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
