#!/usr/bin/env python3
"""Detecta candidatos de reutilizacion entre packages de un modulo PL/SQL."""
from __future__ import annotations

import argparse
import hashlib
import re
import sys
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

ROUTINE = re.compile(r"(?im)^\s*(procedure|function)\s+([a-z][a-z0-9_$#]*)\b")
COMMENT = re.compile(r"/\*.*?\*/|--[^\n]*", re.DOTALL)
STRING = re.compile(r"'(?:''|[^'])*'")
NUMBER = re.compile(r"\b\d+(?:\.\d+)?\b")
IDENTIFIER = re.compile(r"\b(?:p|v|l)_[a-z0-9_$#]+\b", re.IGNORECASE)


@dataclass(frozen=True)
class Routine:
    package: str
    name: str
    file: Path
    line: int
    normalized: str
    tokens: int


@dataclass(frozen=True)
class Section:
    routine: Routine
    normalized: str


def line_number(text: str, offset: int) -> int:
    return text.count("\n", 0, offset) + 1


def routine_end(text: str, start: int, name: str) -> int:
    match = re.search(rf"(?im)^\s*end\s+{re.escape(name)}\s*;", text[start:])
    return start + match.end() if match else len(text)


def normalize(text: str) -> str:
    text = COMMENT.sub(" ", text)
    text = STRING.sub(":TEXT", text)
    text = NUMBER.sub(":NUMBER", text)
    text = IDENTIFIER.sub(":VALUE", text)
    text = re.sub(r"\s+", " ", text.upper()).strip()
    return text


def source_files(root: Path, module: str) -> list[Path]:
    pattern = f"PK_{module.upper()}_*.sql"
    return sorted(
        path for path in root.rglob(pattern)
        if "BODIES" in {part.upper() for part in path.parts}
    )


def routines(root: Path, module: str) -> list[Routine]:
    result: list[Routine] = []
    for path in source_files(root, module):
        text = path.read_text(encoding="utf-8", errors="replace")
        package = path.stem.upper()
        for match in ROUTINE.finditer(text):
            name = match.group(2).upper()
            body = text[match.start():routine_end(text, match.start(), match.group(2))]
            normalized = normalize(body)
            tokens = len(normalized.split())
            if tokens >= 30:
                result.append(Routine(package, name, path, line_number(text, match.start()), normalized, tokens))
    return result


def sections(items: list[Routine]) -> list[Section]:
    result: list[Section] = []
    for item in items:
        statements = [
            value.strip() for value in item.normalized.split(";")
            if len(value.split()) >= 6
            and not re.match(r"^(?:PROCEDURE|FUNCTION|BEGIN|END|EXCEPTION)\b", value)
        ]
        for index in range(len(statements) - 1):
            candidate = "; ".join(statements[index:index + 2])
            if len(candidate.split()) >= 24:
                result.append(Section(item, candidate))
    return result


def similarity(left: Routine, right: Routine) -> float:
    left_tokens, right_tokens = set(left.normalized.split()), set(right.normalized.split())
    union = left_tokens | right_tokens
    return len(left_tokens & right_tokens) / len(union) if union else 0.0


def report(root: Path, module: str, items: list[Routine], threshold: float) -> str:
    exact: dict[str, list[Routine]] = defaultdict(list)
    for item in items:
        digest = hashlib.sha256(item.normalized.encode("utf-8")).hexdigest()
        exact[digest].append(item)
    candidates: list[tuple[str, Routine, Routine, float]] = []
    for group in exact.values():
        packages = {item.package for item in group}
        if len(group) > 1 and len(packages) > 1:
            for index, left in enumerate(group):
                for right in group[index + 1:]:
                    if left.package != right.package:
                        candidates.append(("EXACT_DUPLICATE", left, right, 1.0))
    for index, left in enumerate(items):
        for right in items[index + 1:]:
            if left.package == right.package:
                continue
            score = similarity(left, right)
            if score >= threshold and left.normalized != right.normalized:
                candidates.append(("COMMONS_CANDIDATE", left, right, score))
    repeated_sections: dict[str, list[Section]] = defaultdict(list)
    for item in sections(items):
        repeated_sections[hashlib.sha256(item.normalized.encode("utf-8")).hexdigest()].append(item)
    for group in repeated_sections.values():
        routines_in_group = {(item.routine.package, item.routine.name) for item in group}
        if len(routines_in_group) < 2:
            continue
        first, second = group[0].routine, group[1].routine
        candidates.append(("SECTION_DUPLICATE", first, second, 1.0))

    now = __import__("datetime").datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %Z")
    lines = [
        f"# Analisis De Reutilizacion PL/SQL - {module.upper()}",
        "",
        f"- Fecha/hora: {now}",
        f"- Fuente analizada: {root}",
        f"- Paquetes body analizados: {len({item.package for item in items})}",
        f"- Rutinas analizadas: {len(items)}",
        f"- Umbral de similitud normalizada: {threshold:.0%}",
        "",
    ]
    if len({item.package for item in items}) < 2:
        lines.extend([
            "> Observacion: hay menos de dos packages body del modulo. El reporte solo detecta repeticion interna; no justifica por si solo un Commons transversal.",
            "",
        ])
    lines.extend([
        "## Candidatos",
        "",
        "| Clasificacion | Rutina A | Rutina B | Similitud | Decision requerida |",
        "|---|---|---|---:|---|",
    ])
    if not candidates:
        lines.append("| Sin candidatos | - | - | - | No aplica |")
    else:
        seen: set[tuple[str, str, str]] = set()
        for kind, left, right, score in sorted(candidates, key=lambda item: (-item[3], item[1].package, item[2].package)):
            key = (kind, f"{left.package}.{left.name}", f"{right.package}.{right.name}")
            if key in seen:
                continue
            seen.add(key)
            left_ref = f"{left.package}.{left.name} ({left.file}:{left.line})"
            right_ref = f"{right.package}.{right.name} ({right.file}:{right.line})"
            decision = "Evaluar Commons o justificar mantener local"
            lines.append(f"| {kind} | {left_ref} | {right_ref} | {score:.0%} | {decision} |")
    lines.extend([
        "",
        "## Regla",
        "",
        "El reporte detecta similitud sintactica normalizada. No prueba que dos rutinas sean funcionalmente equivalentes ni autoriza crear PK_<MODULO>_COMMONS. Clasificar cada candidato y extraer solo con alcance, contrato estable, ausencia de dependencia ciclica y pruebas de todos los consumidores.",
        "",
    ])
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Analiza duplicidad potencial entre PK_<MODULO>_*.")
    parser.add_argument("--root", required=True, help="Raiz del repo fuente Oracle.")
    parser.add_argument("--module", required=True, help="Prefijo funcional, por ejemplo CNTR.")
    parser.add_argument("--output", help="Ruta del reporte Markdown.")
    parser.add_argument("--threshold", type=float, default=0.78, help="Similitud normalizada entre 0 y 1.")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    if not root.is_dir():
        print(f"PLSQL_REUSE_BLOCKED raiz inexistente: {root}", file=sys.stderr)
        return 2
    if not 0 < args.threshold <= 1:
        print("PLSQL_REUSE_BLOCKED --threshold debe estar entre 0 y 1.", file=sys.stderr)
        return 2
    files = source_files(root, args.module)
    if not files:
        print(f"PLSQL_REUSE_BLOCKED no hay PACKAGE BODY PK_{args.module.upper()}_*.", file=sys.stderr)
        return 2
    items = routines(root, args.module)
    if not items:
        print(
            "PLSQL_REUSE_NO_ROUTINES "
            f"packages={len(files)} min_tokens=30; no se encontraron rutinas analizables."
        )
        return 0
    text = report(root, args.module, items, args.threshold)
    print(text)
    if args.output:
        output = Path(args.output).resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(text, encoding="utf-8")
        print(f"PLSQL_REUSE_REPORT {output}")
    print(f"PLSQL_REUSE_SUMMARY packages={len({item.package for item in items})} routines={len(items)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
