#!/usr/bin/env python3
"""Valida si un usuario puede abrir por URL rápida una página APEX registrada en menú/accesos."""
from __future__ import annotations

import argparse, os, re
from pathlib import Path
import oracledb

SET_RE = re.compile(r'^\s*set\s+"(ZAIMELLA_(?:ORACLE|APEX)_[A-Z_]+)=(.*)"\s*$', re.I)

def load_env() -> None:
    root = Path(os.environ.get("ZAIMELLA_ENV_DIR", Path.home() / ".zaimella"))
    for filename in ("configurar_oracle_env.cmd", "configurar_oracle_env.local.cmd"):
        path = root / filename
        if path.exists():
            for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
                match = SET_RE.match(line)
                if match and match.group(2).strip(): os.environ.setdefault(match.group(1).upper(), match.group(2).strip())

def main() -> int:
    parser = argparse.ArgumentParser(description="Valida menú/acceso antes de usar f?p=APP_ID:PAGE_ID con sesión APEX activa.")
    parser.add_argument("--app-id", type=int, required=True)
    parser.add_argument("--module-code", required=True)
    parser.add_argument("--page-id", type=int, required=True)
    parser.add_argument("--user", required=True)
    parser.add_argument("--company", required=True)
    parser.add_argument("--base-url", help="URL base APEX TEST; si se omite usa ZAIMELLA_APEX_TEST_BASE_URL.")
    args = parser.parse_args(); load_env()
    required = ("ZAIMELLA_ORACLE_HOST", "ZAIMELLA_ORACLE_PORT", "ZAIMELLA_ORACLE_SID", "ZAIMELLA_ORACLE_USER", "ZAIMELLA_ORACLE_PASSWORD")
    missing = [name for name in required if not os.environ.get(name)]
    if missing: raise RuntimeError("Faltan variables Oracle TEST: " + ", ".join(missing))
    args.base_url = args.base_url or os.environ.get("ZAIMELLA_APEX_TEST_BASE_URL")
    if not args.base_url or args.base_url.upper().startswith("COLOQUE_AQUI"):
        raise RuntimeError("Falta --base-url o ZAIMELLA_APEX_TEST_BASE_URL en la configuracion externa.")
    sql = """
select p.codigopagina, p.descripcion, p.rutapagina, p.opcionmenu, p.codigopadre, r.descripcion rol
from data.t_admi_modulopagina p
join data.t_admi_rolaccesos a on a.id_modulopagina=p.id and a.estado=1 and a.codigoaccion is null
join data.t_admi_rol r on r.id=a.id_rol and r.estado=1
join data.t_admi_rolusuario u on u.id_rol=r.id and u.codigomodulo=p.codigomodulo and u.estado=1
where p.codigomodulo=:module_code and p.rutapagina=:page_id and p.estado=1
  and p.opcionmenu is not null and trim(p.opcionmenu) is not null
  and u.codigousuario=:user_code and u.codigocompania=:company
"""
    dsn = oracledb.makedsn(os.environ["ZAIMELLA_ORACLE_HOST"], int(os.environ["ZAIMELLA_ORACLE_PORT"]), sid=os.environ["ZAIMELLA_ORACLE_SID"])
    with oracledb.connect(user=os.environ["ZAIMELLA_ORACLE_USER"], password=os.environ["ZAIMELLA_ORACLE_PASSWORD"], dsn=dsn) as conn:
        with conn.cursor() as cur:
            cur.execute(sql, module_code=args.module_code, page_id=str(args.page_id), user_code=args.user, company=args.company)
            rows = cur.fetchall()
    if not rows:
        print("DIRECT_URL_NOT_ALLOWED: no existe menú activo y acceso base para el usuario/compañía indicados.")
        return 2
    for code, name, route, menu, parent, role in rows:
        print(f"MENU_ACCESS_OK page={code} name={name} menu={menu} parent={parent} role={role}")
    print(f"DIRECT_URL_ALLOWED {args.base_url}f?p={args.app_id}:{args.page_id}")
    return 0

if __name__ == "__main__": raise SystemExit(main())
