#!/usr/bin/env python3
"""Extrae un mapa funcional reproducible desde un export SQL de pagina Oracle APEX."""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any


CALL_RE = re.compile(r"wwv_flow_imp_page\.(create_[a-z_]+)\(\s*(.*?)^\s*\);", re.IGNORECASE | re.MULTILINE | re.DOTALL)
PARAM_RE = re.compile(r"^\s*,?\s*(p_[a-z0-9_]+)=>\s*(.*?)(?=^\s*,?\s*p_[a-z0-9_]+=>|\Z)", re.IGNORECASE | re.MULTILINE | re.DOTALL)
ID_RE = re.compile(r"wwv_flow_imp\.id\((\d+)\)", re.IGNORECASE)
LITERAL_RE = re.compile(r"^'(.*)'$", re.DOTALL)
PAGE_TARGET_RE = re.compile(r"(?:f\?p=[^\s'\"]*?:|p_page\s*=>\s*)(\d+)", re.IGNORECASE)
ITEM_TARGET_RE = re.compile(r"\b(P\d+_[A-Z0-9_]+)\b", re.IGNORECASE)


def clean(value: str | None) -> str:
    if not value:
        return ""
    value = value.strip().rstrip(",").strip()
    literal = LITERAL_RE.match(value)
    if literal:
        return literal.group(1).replace("''", "'").replace("\n", " ")
    return re.sub(r"\s+", " ", value)


def identifier(value: str | None) -> str:
    match = ID_RE.search(value or "")
    return match.group(1) if match else clean(value)


def calls(text: str) -> list[dict[str, Any]]:
    found: list[dict[str, Any]] = []
    for match in CALL_RE.finditer(text):
        params = {name.lower(): clean(value) for name, value in PARAM_RE.findall(match.group(2))}
        found.append({"type": match.group(1).lower(), "params": params})
    return found


def label(item: dict[str, Any], *names: str) -> str:
    for name in names:
        if item["params"].get(name):
            return item["params"][name]
    return "Sin nombre visible"


def build(text: str) -> dict[str, Any]:
    data = calls(text)
    page = next((x for x in data if x["type"] == "create_page"), {"params": {}})["params"]
    regions: dict[str, str] = {}
    buttons: dict[str, dict[str, str]] = {}
    events: dict[str, dict[str, Any]] = {}
    result: dict[str, Any] = {"page": {"id": page.get("p_id", ""), "name": label({"params": page}, "p_step_title", "p_name"), "alias": page.get("p_alias", ""), "mode": page.get("p_page_mode", "NORMAL")}, "regions": [], "buttons": [], "dynamic_actions": [], "branches": [], "processes": []}
    for item in data:
        p = item["params"]
        if item["type"] == "create_page_plug":
            rid = identifier(p.get("p_id")); name = label(item, "p_plug_name", "p_region_name")
            regions[rid] = name
            result["regions"].append({"id": rid, "name": name, "parent": regions.get(identifier(p.get("p_parent_plug_id")), identifier(p.get("p_parent_plug_id")) or "Pagina"), "type": p.get("p_plug_source_type", p.get("p_query_type", "Region")), "display": p.get("p_plug_display_point", "")})
        elif item["type"] == "create_page_button":
            bid = identifier(p.get("p_id")); name = label(item, "p_button_image_alt", "p_button_name")
            button = {"id": bid, "name": name, "technical_name": p.get("p_button_name", ""), "region": regions.get(identifier(p.get("p_button_plug_id")), "Pagina"), "action": p.get("p_button_action", ""), "target": p.get("p_button_redirect_url", "")}
            buttons[bid] = button; result["buttons"].append(button)
        elif item["type"] == "create_page_da_event":
            eid = identifier(p.get("p_id"))
            events[eid] = {"name": label(item, "p_name"), "trigger_type": p.get("p_triggering_element_type", ""), "trigger": p.get("p_triggering_element", "") or buttons.get(identifier(p.get("p_triggering_button_id")), {}).get("name", identifier(p.get("p_triggering_button_id"))), "condition": p.get("p_triggering_condition_type", ""), "actions": []}
        elif item["type"] == "create_page_da_action":
            event = events.setdefault(identifier(p.get("p_event_id")), {"name": "Evento no resuelto", "trigger_type": "", "trigger": "", "condition": "", "actions": []})
            event["actions"].append({"action": p.get("p_action", ""), "detail": p.get("p_attribute_01", ""), "affected": p.get("p_affected_elements", "") or regions.get(identifier(p.get("p_affected_region_id")), "")})
        elif item["type"] == "create_page_branch":
            result["branches"].append({"name": label(item, "p_branch_name"), "point": p.get("p_branch_point", ""), "target": p.get("p_branch_action", "")})
        elif item["type"] == "create_page_process":
            result["processes"].append({"name": label(item, "p_process_name"), "point": p.get("p_process_point", ""), "type": p.get("p_process_type", ""), "detail": p.get("p_attribute_01", "")})
    result["dynamic_actions"] = list(events.values())
    return result


def inbound_references(source: Path, source_root: Path, page_id: str) -> list[dict[str, str]]:
    """Encuentra links declarados por otras páginas del mismo export versionado."""
    references: list[dict[str, str]] = []
    for candidate in source_root.rglob("*.sql"):
        if candidate.resolve() == source.resolve():
            continue
        text = candidate.read_text(encoding="utf-8", errors="replace")
        candidate_calls = calls(text)
        if page_id not in {match.group(1) for item in candidate_calls for value in item["params"].values() for match in PAGE_TARGET_RE.finditer(value)}:
            continue
        caller = build(text)["page"]
        for item in candidate_calls:
            values = " ".join(item["params"].values())
            if page_id not in {match.group(1) for match in PAGE_TARGET_RE.finditer(values)}:
                continue
            origin = label(item, "p_button_image_alt", "p_button_name", "p_column_label", "p_name")
            # Un botón Volver/Cancelar es una salida de una secundaria y no convierte
            # el destino en página secundaria.
            if re.search(r"\b(volver|regresar|cancelar|retornar)\b", origin, re.IGNORECASE):
                continue
            items = sorted(set(ITEM_TARGET_RE.findall(values)))
            references.append({"page_id": caller["id"], "page_name": caller["name"], "origin": origin, "items": ", ".join(items) or "Sin items declarados", "source": str(candidate)})
    return references


def classify(report: dict[str, Any], inbound: list[dict[str, str]]) -> dict[str, Any]:
    page = report["page"]
    mode = page["mode"].upper()
    if "MODAL" in mode or "DIALOG" in mode:
        return {"type": "dialogo_modal", "reason": f"Modo APEX {mode}.", "qa_entry": "Abrir desde la página padre y la acción visible; conservar su contexto."}
    if inbound:
        callers = ", ".join(f"{item['page_id']} ({item['page_name']})" for item in inbound)
        return {"type": "secundaria_parametrizada", "reason": f"Tiene llamadas entrantes desde {callers}.", "qa_entry": "Abrir desde la página principal/padre y usar el ID, filtro o contexto entregado por esa acción."}
    return {"type": "principal", "reason": "No se detectaron llamadas entrantes en el conjunto de exports analizado.", "qa_entry": "Entrar por menú o, solo si se valida, por URL autenticada con DIRECT_URL_ALLOWED."}


def md(report: dict[str, Any], source: Path) -> str:
    page = report["page"]
    classification = report["classification"]
    lines = [f"# Mapa funcional APEX: {page['name']}", "", f"- Fuente: `{source}`", f"- Pagina: `{page['id']}` | Alias: `{page['alias'] or 'No definido'}`", "", "## Clasificacion de navegacion", f"- Tipo propuesto: `{classification['type']}`.", f"- Evidencia: {classification['reason']}", f"- Entrada QA: {classification['qa_entry']}", ""]
    if report["inbound_references"]:
        lines += ["### Llamadas entrantes detectadas"]
        lines += [f"- Página {x['page_id']} — **{x['page_name']}**, acción/columna **{x['origin']}**; items/contexto: {x['items']}." for x in report["inbound_references"]]
        lines += [""]
    lines += ["## Regiones"]
    lines += [f"- **{x['name']}** — padre: {x['parent']}; tipo: `{x['type']}`." for x in report["regions"]] or ["- No se detectaron regiones."]
    lines += ["", "## Botones y enlaces"]
    lines += [f"- **{x['name']}** ({x['region']}): `{x['action'] or 'accion no declarada'}`{(' → ' + x['target']) if x['target'] else ''}." for x in report["buttons"]] or ["- No se detectaron botones."]
    lines += ["", "## Acciones dinamicas"]
    for event in report["dynamic_actions"]:
        lines.append(f"- **{event['name']}**: al {event['trigger_type'].lower() or 'evento'} `{event['trigger'] or 'no resuelto'}`{(' con condicion ' + event['condition']) if event['condition'] else ''}.")
        lines += [f"  - `{x['action']}`{(': ' + x['detail']) if x['detail'] else ''}{(' → ' + x['affected']) if x['affected'] else ''}." for x in event["actions"]]
    lines += ["", "## Procesos y branches"]
    lines += [f"- Proceso **{x['name']}** en `{x['point']}`: `{x['type']}`{(' — ' + x['detail']) if x['detail'] else ''}." for x in report["processes"]]
    lines += [f"- Branch **{x['name']}** en `{x['point']}` → `{x['target']}`." for x in report["branches"]]
    lines += ["", "## Uso QA", "", "Este mapa describe metadata exportada; el contrato QA debe convertir el alcance en pasos visibles y validar en TEST permisos, condiciones, datos y resultado real. No sustituye evidencia visual ni habilita URL directa por sí solo.", ""]
    return "\n".join(lines)


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True, type=Path, help="Export SQL de una pagina APEX.")
    parser.add_argument("--source-root", type=Path, help="Carpeta de exports para descubrir llamadas entrantes; por defecto, la carpeta del export.")
    parser.add_argument("--output", type=Path, help="Destino del mapa; si se omite escribe a stdout.")
    parser.add_argument("--format", choices=("markdown", "json"), default="markdown")
    args = parser.parse_args()
    if not args.source.is_file():
        parser.error(f"No existe export de pagina: {args.source}")
    source_root = args.source_root or args.source.parent
    if not source_root.is_dir():
        parser.error(f"No existe carpeta de exports: {source_root}")
    report = build(args.source.read_text(encoding="utf-8", errors="replace"))
    report["inbound_references"] = inbound_references(args.source, source_root, report["page"]["id"])
    report["classification"] = classify(report, report["inbound_references"])
    output = json.dumps(report, ensure_ascii=False, indent=2) if args.format == "json" else md(report, args.source)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(output, encoding="utf-8")
        print(f"APEX_PAGE_MAP_READY {args.output}")
    else:
        print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
