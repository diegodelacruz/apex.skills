from __future__ import annotations

import argparse
import importlib.util
import os
from pathlib import Path
import re
import socket
import sys


SET_LINE_RE = re.compile(r'^\s*set\s+"(ZAIMELLA_(?:ORACLE|HANA)_[A-Z_]+)=(.*)"\s*$', re.IGNORECASE)


def parse_cmd_env_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values
    for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        match = SET_LINE_RE.match(line)
        if match:
            values[match.group(1).upper()] = match.group(2)
    return values


def external_env_paths() -> tuple[Path, Path]:
    env_dir = Path(os.environ.get("ZAIMELLA_ENV_DIR") or Path.home() / ".zaimella")
    config_path = Path(os.environ["ZAIMELLA_ORACLE_CONFIG_PATH"]) if os.environ.get("ZAIMELLA_ORACLE_CONFIG_PATH") else env_dir / "configurar_oracle_env.cmd"
    local_config_path = Path(os.environ["ZAIMELLA_ORACLE_LOCAL_CONFIG_PATH"]) if os.environ.get("ZAIMELLA_ORACLE_LOCAL_CONFIG_PATH") else env_dir / "configurar_oracle_env.local.cmd"
    return config_path, local_config_path


def load_external_env() -> None:
    config_path, local_config_path = external_env_paths()
    values: dict[str, str] = {}
    values.update(parse_cmd_env_file(config_path))
    values.update(parse_cmd_env_file(local_config_path))
    for name, value in values.items():
        if value and name not in os.environ:
            os.environ[name] = value


def is_placeholder(value: str | None) -> bool:
    return not value or value.strip().upper().startswith("COLOQUE_AQUI")


def load_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Valida conectividad Oracle usando ZAIMELLA_ORACLE_* y Python oracledb."
    )
    parser.add_argument(
        "--environment",
        choices=("current", "test", "prod", "production"),
        default="current",
        help="Usa ZAIMELLA_ORACLE_* para current/test o ZAIMELLA_ORACLE_PROD_* para prod.",
    )
    parser.add_argument("--host")
    parser.add_argument("--port")
    parser.add_argument("--sid")
    parser.add_argument("--user")
    parser.add_argument("--password")
    parser.add_argument("--timeout", type=float, default=5.0)
    args = parser.parse_args()

    prefix = "ZAIMELLA_ORACLE_PROD_" if args.environment in {"prod", "production"} else "ZAIMELLA_ORACLE_"
    args.host = args.host or os.environ.get(f"{prefix}HOST")
    args.port = args.port or os.environ.get(f"{prefix}PORT")
    args.sid = args.sid or os.environ.get(f"{prefix}SID")
    args.user = args.user or os.environ.get(f"{prefix}USER")
    args.password = args.password or os.environ.get(f"{prefix}PASSWORD")
    args.env_prefix = prefix
    return args


def declared_environment(environment: str) -> str:
    if environment in {"prod", "production"}:
        return "produccion"
    if environment == "test":
        return "pruebas"
    return "actual configurado"


def main() -> int:
    load_external_env()
    args = load_args()

    missing = [
        name
        for name, value in (
            (f"{args.env_prefix}HOST", args.host),
            (f"{args.env_prefix}PORT", args.port),
            (f"{args.env_prefix}SID", args.sid),
            (f"{args.env_prefix}USER", args.user),
            (f"{args.env_prefix}PASSWORD", args.password),
        )
        if is_placeholder(value)
    ]
    if missing:
        print("Faltan variables Oracle: " + ", ".join(missing), file=sys.stderr)
        return 2

    print(f"SID actual: {args.sid}")
    print(f"Ambiente declarado: {declared_environment(args.environment)}")

    try:
        resolved = socket.gethostbyname(args.host)
        print(f"DNS OK: {args.host} -> {resolved}")
    except OSError as exc:
        print(f"DNS ERROR: {args.host} -> {exc}", file=sys.stderr)
        return 3

    try:
        with socket.create_connection((args.host, int(args.port)), timeout=args.timeout):
            print(f"PUERTO OK: {args.host}:{args.port}")
    except OSError as exc:
        print(f"PUERTO ERROR: {args.host}:{args.port} -> {exc}", file=sys.stderr)
        return 4

    if importlib.util.find_spec("oracledb") is None:
        print("Modulo Python 'oracledb' no disponible.", file=sys.stderr)
        return 5

    import oracledb

    dsn = f"{args.host}:{args.port}/{args.sid}"
    try:
        with oracledb.connect(
            user=args.user,
            password=args.password,
            dsn=dsn,
        ) as conn:
            with conn.cursor() as cur:
                cur.execute("select user from dual")
                db_user = cur.fetchone()[0]

                cur.execute("select sys_context('USERENV','DB_NAME') from dual")
                db_name = cur.fetchone()[0]

                cur.execute("select banner from v$version where rownum = 1")
                banner = cur.fetchone()[0]
    except Exception as exc:
        print(f"CONEXION ERROR: {exc}", file=sys.stderr)
        return 6

    print(f"Usuario conectado: {db_user}")
    print(f"Base conectada: {db_name}")
    print(f"Motor detectado: {banner}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
