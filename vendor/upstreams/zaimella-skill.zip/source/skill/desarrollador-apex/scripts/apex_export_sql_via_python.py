from __future__ import annotations

import argparse
import hashlib
import os
from pathlib import Path
import re
import sys

import oracledb

SET_LINE_RE = re.compile(r'^\s*set\s+"(ZAIMELLA_(?:ORACLE|HANA)_[A-Z_]+)=(.*)"\s*$', re.IGNORECASE)


def is_placeholder(value: str | None) -> bool:
    return not value or value.strip().upper().startswith("COLOQUE_AQUI") or value.strip().startswith("<")


def parse_cmd_env_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values
    for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        match = SET_LINE_RE.match(line)
        if match:
            values[match.group(1).upper()] = match.group(2)
    return values


def load_local_env() -> None:
    env_dir = Path(os.environ.get("ZAIMELLA_ENV_DIR") or Path.home() / ".zaimella")
    paths = (
        Path(os.environ["ZAIMELLA_ORACLE_CONFIG_PATH"])
        if os.environ.get("ZAIMELLA_ORACLE_CONFIG_PATH")
        else env_dir / "configurar_oracle_env.cmd",
        Path(os.environ["ZAIMELLA_ORACLE_LOCAL_CONFIG_PATH"])
        if os.environ.get("ZAIMELLA_ORACLE_LOCAL_CONFIG_PATH")
        else env_dir / "configurar_oracle_env.local.cmd",
    )
    values: dict[str, str] = {}
    for path in paths:
        values.update(parse_cmd_env_file(path))
    for name, value in values.items():
        if not is_placeholder(value):
            os.environ.setdefault(name, value)


def resolve_connection(args: argparse.Namespace) -> None:
    prefix = "ZAIMELLA_ORACLE_PROD_" if args.environment in {"prod", "production"} else "ZAIMELLA_ORACLE_"
    args.host = args.host or os.environ.get(f"{prefix}HOST")
    args.port = args.port or os.environ.get(f"{prefix}PORT")
    args.sid = args.sid or os.environ.get(f"{prefix}SID")
    args.user = args.user or os.environ.get(f"{prefix}USER")
    args.password = args.password or os.environ.get(f"{prefix}PASSWORD")
    missing = [
        name
        for name, value in (
            (f"{prefix}HOST", args.host),
            (f"{prefix}PORT", args.port),
            (f"{prefix}SID", args.sid),
            (f"{prefix}USER", args.user),
            (f"{prefix}PASSWORD", args.password),
        )
        if is_placeholder(value)
    ]
    if missing:
        raise RuntimeError("Faltan variables Oracle: " + ", ".join(missing))
    if args.environment in {"prod", "production"} and "TEST" in args.sid.upper():
        raise RuntimeError(f"El SID no parece produccion: {args.sid}")


def latest_apex_schema(cur) -> str:
    cur.execute(
        """
        select max(username)
        from all_users
        where regexp_like(username, '^APEX_[0-9]+$')
        """
    )
    row = cur.fetchone()
    if not row or not row[0]:
        raise RuntimeError("No se encontro esquema APEX activo.")
    return row[0]


def app_context(cur, application_id: int, workspace_id: int | None) -> tuple[int, str, str, str]:
    cur.execute(
        """
        select workspace_id, workspace, application_name, owner
        from apex_applications
        where application_id = :application_id
        """,
        application_id=application_id,
    )
    row = cur.fetchone()
    if not row:
        raise RuntimeError(f"No existe APEX application_id={application_id}.")
    detected_workspace_id, workspace, application_name, owner = row
    effective_workspace_id = workspace_id or int(detected_workspace_id)
    return effective_workspace_id, workspace, application_name, owner


def output_path(args: argparse.Namespace) -> Path:
    if args.output:
        return Path(args.output)
    env = "prod" if args.environment in {"prod", "production"} else "test"
    suffix = f"page{args.page_id}" if args.page_id is not None else "full"
    return Path(f"f{args.application_id}_{suffix}_{env}_export.sql")


def export_apex(cur, args: argparse.Namespace, apex_schema: str, workspace_id: int) -> str:
    component_expr = "null"
    if args.page_id is not None:
        component_expr = f"apex_t_varchar2('PAGE:{int(args.page_id)}')"

    plsql = f"""
declare
    l_files apex_t_export_files;
begin
    {apex_schema}.wwv_flow_security.set_g_security_group_id(:workspace_id);
    l_files := apex_export.get_application(
        p_application_id => :application_id,
        p_type => 'APPLICATION_SOURCE',
        p_split => false,
        p_with_date => true,
        p_with_ir_public_reports => :with_ir_public_reports,
        p_with_ir_private_reports => :with_ir_private_reports,
        p_with_ir_notifications => :with_ir_notifications,
        p_components => {component_expr}
    );
    :content := l_files(1).contents;
end;
"""
    content = cur.var(oracledb.DB_TYPE_CLOB)
    cur.execute(
        plsql,
        workspace_id=workspace_id,
        application_id=args.application_id,
        with_ir_public_reports=args.with_ir_public_reports,
        with_ir_private_reports=args.with_ir_private_reports,
        with_ir_notifications=args.with_ir_notifications,
        content=content,
    )
    value = content.getvalue()
    return value.read() if hasattr(value, "read") else str(value)


def main() -> int:
    load_local_env()
    parser = argparse.ArgumentParser(description="Exporta una aplicacion o pagina APEX usando contexto APEX validado.")
    parser.add_argument("--application-id", type=int, required=True)
    parser.add_argument("--page-id", type=int)
    parser.add_argument("--output")
    parser.add_argument(
        "--environment",
        choices=("test", "prod", "production"),
        default="test",
        help="Usa variables ZAIMELLA_ORACLE_* para test o ZAIMELLA_ORACLE_PROD_* para produccion.",
    )
    parser.add_argument("--workspace-id", type=int)
    parser.add_argument(
        "--with-ir-public-reports",
        action="store_true",
        help="Incluye reportes publicos guardados de Interactive Report. Por defecto se excluyen para evitar conflictos en produccion.",
    )
    parser.add_argument(
        "--with-ir-private-reports",
        action="store_true",
        help="Incluye reportes privados de Interactive Report. Por defecto se excluyen.",
    )
    parser.add_argument(
        "--with-ir-notifications",
        action="store_true",
        help="Incluye notificaciones de Interactive Report. Por defecto se excluyen.",
    )
    parser.add_argument("--host")
    parser.add_argument("--port")
    parser.add_argument("--sid")
    parser.add_argument("--user")
    parser.add_argument("--password")
    args = parser.parse_args()

    try:
        resolve_connection(args)
        dsn = f"{args.host}:{args.port}/{args.sid}"
        with oracledb.connect(user=args.user, password=args.password, dsn=dsn) as conn:
            with conn.cursor() as cur:
                workspace_id, workspace, application_name, owner = app_context(
                    cur, args.application_id, args.workspace_id
                )
                apex_schema = latest_apex_schema(cur)
                data = export_apex(cur, args, apex_schema, workspace_id)

        out = output_path(args)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(data, encoding="utf-8", newline="\n")
        digest = hashlib.sha256(data.encode("utf-8")).hexdigest().upper()
        print(f"Archivo: {out}")
        print(f"SHA256: {digest}")
        print(f"Bytes: {len(data.encode('utf-8'))}")
        print(f"APEX schema: {apex_schema}")
        print(f"Workspace: {workspace} ({workspace_id})")
        print(f"Aplicacion: {args.application_id} - {application_name}")
        print(f"Owner: {owner}")
        print(f"Tipo: {'PAGE ' + str(args.page_id) if args.page_id is not None else 'APPLICATION'}")
        print(f"IR public reports: {args.with_ir_public_reports}")
        print(f"IR private reports: {args.with_ir_private_reports}")
        print(f"IR notifications: {args.with_ir_notifications}")
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
