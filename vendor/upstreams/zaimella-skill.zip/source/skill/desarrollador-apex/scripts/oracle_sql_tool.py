from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path
import re
import socket
import sys
from typing import Iterable
from uuid import uuid4


SET_LINE_RE = re.compile(r'^\s*set\s+"(ZAIMELLA_ORACLE_[A-Z_]+)=(.*)"\s*$', re.IGNORECASE)
READ_SQL_RE = re.compile(r"^\s*(select|with)\b", re.IGNORECASE | re.DOTALL)
BLOCKED_SQL_RE = re.compile(
    r"\b(insert|update|delete|merge|create|alter|drop|truncate|grant|revoke|commit|rollback|execute|exec|begin|call)\b",
    re.IGNORECASE,
)
MODULE_NAME = "CODX_ORACLE_SQL_TOOL"


def parse_cmd_env_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values
    for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        match = SET_LINE_RE.match(line)
        if match:
            values[match.group(1).upper()] = match.group(2)
    return values


def load_external_env() -> None:
    env_dir = Path(os.environ.get("ZAIMELLA_ENV_DIR") or Path.home() / ".zaimella")
    paths = (
        Path(os.environ["ZAIMELLA_ORACLE_CONFIG_PATH"])
        if os.environ.get("ZAIMELLA_ORACLE_CONFIG_PATH")
        else env_dir / "configurar_oracle_env.cmd",
        Path(os.environ["ZAIMELLA_ORACLE_LOCAL_CONFIG_PATH"])
        if os.environ.get("ZAIMELLA_ORACLE_LOCAL_CONFIG_PATH")
        else env_dir / "configurar_oracle_env.local.cmd",
    )
    values: dict[str, str] = {}
    for path in paths:
        values.update(parse_cmd_env_file(path))
    for name, value in values.items():
        if value and name not in os.environ:
            os.environ[name] = value


def is_placeholder(value: str | None) -> bool:
    return not value or value.strip().upper().startswith("COLOQUE_AQUI")


def oracle_config(environment: str, args: argparse.Namespace) -> dict[str, str | None]:
    prefix = "ZAIMELLA_ORACLE_PROD_" if environment in {"prod", "production"} else "ZAIMELLA_ORACLE_"
    return {
        "host": args.host or os.environ.get(f"{prefix}HOST"),
        "port": args.port or os.environ.get(f"{prefix}PORT"),
        "sid": args.sid or os.environ.get(f"{prefix}SID"),
        "user": args.user or os.environ.get(f"{prefix}USER"),
        "password": args.password or os.environ.get(f"{prefix}PASSWORD"),
        "prefix": prefix,
    }


def assert_oracle_config(config: dict[str, str | None]) -> int:
    missing = [
        f"{config['prefix']}{key.upper()}"
        for key in ("host", "port", "sid", "user", "password")
        if is_placeholder(config.get(key))
    ]
    if missing:
        print("Faltan variables Oracle: " + ", ".join(missing), file=sys.stderr)
        return 2
    return 0


def connect(config: dict[str, str | None], timeout: float):
    if importlib.util.find_spec("oracledb") is None:
        print("Modulo Python 'oracledb' no disponible.", file=sys.stderr)
        return None

    import oracledb

    host = str(config["host"])
    port = int(str(config["port"]))
    sid = str(config["sid"])
    try:
        socket.create_connection((host, port), timeout=timeout).close()
    except OSError as exc:
        print(f"PUERTO ERROR: {host}:{port} -> {exc}", file=sys.stderr)
        raise
    return oracledb.connect(
        user=str(config["user"]),
        password=str(config["password"]),
        dsn=f"{host}:{port}/{sid}",
    )


def configure_session(conn, args: argparse.Namespace, action: str) -> None:
    call_timeout = getattr(args, "call_timeout", 0) or 0
    if call_timeout > 0:
        conn.call_timeout = int(call_timeout * 1000)
    with conn.cursor() as cur:
        cur.callproc("DBMS_APPLICATION_INFO.SET_MODULE", [MODULE_NAME, action])
        cur.callproc("DBMS_SESSION.SET_IDENTIFIER", [f"codex:{action}:{os.getpid()}"])


def read_sql(args: argparse.Namespace) -> str:
    if args.sql and args.file:
        raise SystemExit("Usa --sql o --file, no ambos.")
    if args.sql:
        return args.sql.strip().rstrip(";")
    if args.file:
        return Path(args.file).read_text(encoding="utf-8", errors="ignore").strip().rstrip(";")
    raise SystemExit("Falta --sql o --file.")


def assert_read_sql(sql: str) -> int:
    if not READ_SQL_RE.search(sql):
        print("Solo se permiten consultas SELECT/WITH en este helper.", file=sys.stderr)
        return 3
    if BLOCKED_SQL_RE.search(sql):
        print("SQL bloqueado: contiene DML, DDL, PL/SQL o control transaccional.", file=sys.stderr)
        return 3
    return 0


def print_rows(columns: list[str], rows: list[tuple], output: str) -> None:
    if output == "json":
        print(json.dumps([dict(zip(columns, row)) for row in rows], ensure_ascii=True, default=str, indent=2))
        return
    print("\t".join(columns))
    for row in rows:
        print("\t".join("" if value is None else str(value) for value in row))


def run_query(args: argparse.Namespace) -> int:
    sql = read_sql(args)
    sql_error = assert_read_sql(sql)
    if sql_error:
        return sql_error

    config = oracle_config(args.environment, args)
    config_error = assert_oracle_config(config)
    if config_error:
        return config_error

    try:
        conn = connect(config, args.timeout)
    except OSError:
        return 4
    if conn is None:
        return 5

    with conn:
        configure_session(conn, args, "query")
        with conn.cursor() as cur:
            cur.execute(f"select * from ({sql}) where rownum <= :max_rows", max_rows=args.max_rows)
            columns = [desc[0] for desc in cur.description]
            rows = cur.fetchall()
            print_rows(columns, rows, args.output)
        conn.rollback()
    return 0


def run_explain(args: argparse.Namespace) -> int:
    sql = read_sql(args)
    sql_error = assert_read_sql(sql)
    if sql_error:
        return sql_error

    config = oracle_config(args.environment, args)
    config_error = assert_oracle_config(config)
    if config_error:
        return config_error

    statement_id = f"CODX_{uuid4().hex[:24].upper()}"
    try:
        conn = connect(config, args.timeout)
    except OSError:
        return 4
    if conn is None:
        return 5

    with conn:
        configure_session(conn, args, "explain")
        with conn.cursor() as cur:
            cur.execute(f"delete from plan_table where statement_id = '{statement_id}'")
            cur.execute(f"explain plan set statement_id = '{statement_id}' for {sql}")
            cur.execute(
                """
                select plan_table_output
                from table(dbms_xplan.display('PLAN_TABLE', :statement_id, :format))
                """,
                statement_id=statement_id,
                format=args.format,
            )
            for (line,) in cur.fetchall():
                print(line)
        conn.rollback()
    return 0


def run_sessions(args: argparse.Namespace) -> int:
    config = oracle_config(args.environment, args)
    config_error = assert_oracle_config(config)
    if config_error:
        return config_error

    try:
        conn = connect(config, args.timeout)
    except OSError:
        return 4
    if conn is None:
        return 5

    sql = """
        select
            s.inst_id,
            s.sid,
            s.serial#,
            s.username,
            s.status,
            s.module,
            s.action,
            s.client_identifier,
            s.event,
            s.sql_id,
            s.last_call_et
        from gv$session s
        where s.username = sys_context('USERENV', 'SESSION_USER')
          and s.type = 'USER'
          and s.audsid <> to_number(sys_context('USERENV', 'SESSIONID'))
          and (:only_codex = 0 or s.module like 'CODX_%' or s.client_identifier like 'codex:%')
          and (:active_only = 0 or s.status = 'ACTIVE')
        order by s.status, s.last_call_et desc
    """
    try:
        with conn:
            configure_session(conn, args, "sessions")
            with conn.cursor() as cur:
                cur.execute(sql, only_codex=1 if args.only_codex else 0, active_only=1 if args.active_only else 0)
                columns = [desc[0] for desc in cur.description]
                rows = cur.fetchall()
                print_rows(columns, rows, args.output)
            conn.rollback()
    except Exception as exc:
        print(f"No se pudo consultar gv$session con el usuario actual: {exc}", file=sys.stderr)
        return 6
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Ejecuta consultas SELECT/WITH y EXPLAIN PLAN Oracle de forma controlada.")
    connection = argparse.ArgumentParser(add_help=False)
    connection.add_argument("--environment", choices=("test", "prod", "production"), default="test")
    connection.add_argument("--host")
    connection.add_argument("--port")
    connection.add_argument("--sid")
    connection.add_argument("--user")
    connection.add_argument("--password")
    connection.add_argument("--timeout", type=float, default=5.0)
    connection.add_argument("--call-timeout", type=float, default=120.0, help="Timeout de llamada Oracle en segundos; 0 lo desactiva.")

    sql_input = argparse.ArgumentParser(add_help=False)
    sql_input.add_argument("--sql")
    sql_input.add_argument("--file")

    sub = parser.add_subparsers(dest="command", required=True)
    query_parser = sub.add_parser("query", parents=[connection, sql_input], help="Ejecuta SELECT/WITH con limite de filas.")
    query_parser.add_argument("--max-rows", "--limit", dest="max_rows", type=int, default=100)
    query_parser.add_argument("--output", choices=("table", "json"), default="table")
    query_parser.set_defaults(func=run_query)

    explain_parser = sub.add_parser("explain", parents=[connection, sql_input], help="Genera EXPLAIN PLAN sin ejecutar el query.")
    explain_parser.add_argument("--format", default="BASIC +PREDICATE +COST")
    explain_parser.set_defaults(func=run_explain)

    sessions_parser = sub.add_parser("sessions", parents=[connection], help="Lista sesiones Oracle del usuario actual para detectar validaciones colgadas.")
    sessions_parser.add_argument("--active-only", action="store_true", default=False)
    sessions_parser.add_argument("--only-codex", action="store_true", default=False)
    sessions_parser.add_argument("--output", choices=("table", "json"), default="table")
    sessions_parser.set_defaults(func=run_sessions)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    load_external_env()
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
