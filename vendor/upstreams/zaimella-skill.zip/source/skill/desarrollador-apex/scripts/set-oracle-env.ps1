param(
    [string]$EnvDir = $(if ($env:ZAIMELLA_ENV_DIR) { $env:ZAIMELLA_ENV_DIR } else { Join-Path $env:USERPROFILE ".zaimella" }),
    [string]$ConfigPath = $(if ($env:ZAIMELLA_ORACLE_CONFIG_PATH) { $env:ZAIMELLA_ORACLE_CONFIG_PATH } else { Join-Path $EnvDir "configurar_oracle_env.cmd" }),
    [string]$LocalConfigPath = $(if ($env:ZAIMELLA_ORACLE_LOCAL_CONFIG_PATH) { $env:ZAIMELLA_ORACLE_LOCAL_CONFIG_PATH } else { Join-Path $EnvDir "configurar_oracle_env.local.cmd" }),
    [switch]$CreateDefaultIfMissing
)

$requiredNames = @(
    "ZAIMELLA_ORACLE_USER",
    "ZAIMELLA_ORACLE_PASSWORD",
    "ZAIMELLA_ORACLE_HOST",
    "ZAIMELLA_ORACLE_PORT",
    "ZAIMELLA_ORACLE_SID"
)

$defaultValues = [ordered]@{
    ZAIMELLA_ORACLE_USER = "COLOQUE_AQUI_USUARIO_TEST"
    ZAIMELLA_ORACLE_PASSWORD = "COLOQUE_AQUI_PASSWORD_TEST"
    ZAIMELLA_ORACLE_HOST = "COLOQUE_AQUI_HOST_TEST"
    ZAIMELLA_ORACLE_PORT = "COLOQUE_AQUI_PUERTO_TEST"
    ZAIMELLA_ORACLE_SID = "COLOQUE_AQUI_SID_TEST"
    ZAIMELLA_ORACLE_PROD_USER = "COLOQUE_AQUI_USUARIO_PROD"
    ZAIMELLA_ORACLE_PROD_PASSWORD = "COLOQUE_AQUI_PASSWORD_PROD"
    ZAIMELLA_ORACLE_PROD_HOST = "COLOQUE_AQUI_HOST_PROD"
    ZAIMELLA_ORACLE_PROD_PORT = "COLOQUE_AQUI_PUERTO_PROD"
    ZAIMELLA_ORACLE_PROD_SID = "COLOQUE_AQUI_SID_PROD"
}

function New-DefaultConfigFile {
    param([string]$Path)

    $directory = Split-Path -Parent $Path
    if ($directory -and -not (Test-Path -LiteralPath $directory)) {
        New-Item -ItemType Directory -Path $directory -Force | Out-Null
    }

    $lines = @(
        "@echo off",
        "setlocal",
        "",
        "rem Plantilla local externa para ZAIMELLA_ORACLE_*.",
        "rem No guardar este archivo dentro del repositorio ni del skill.",
        "set ""ZAIMELLA_ORACLE_USER=$($defaultValues.ZAIMELLA_ORACLE_USER)""",
        "set ""ZAIMELLA_ORACLE_PASSWORD=$($defaultValues.ZAIMELLA_ORACLE_PASSWORD)""",
        "set ""ZAIMELLA_ORACLE_HOST=$($defaultValues.ZAIMELLA_ORACLE_HOST)""",
        "set ""ZAIMELLA_ORACLE_PORT=$($defaultValues.ZAIMELLA_ORACLE_PORT)""",
        "set ""ZAIMELLA_ORACLE_SID=$($defaultValues.ZAIMELLA_ORACLE_SID)""",
        "set ""ZAIMELLA_ORACLE_PROD_USER=$($defaultValues.ZAIMELLA_ORACLE_PROD_USER)""",
        "set ""ZAIMELLA_ORACLE_PROD_PASSWORD=$($defaultValues.ZAIMELLA_ORACLE_PROD_PASSWORD)""",
        "set ""ZAIMELLA_ORACLE_PROD_HOST=$($defaultValues.ZAIMELLA_ORACLE_PROD_HOST)""",
        "set ""ZAIMELLA_ORACLE_PROD_PORT=$($defaultValues.ZAIMELLA_ORACLE_PROD_PORT)""",
        "set ""ZAIMELLA_ORACLE_PROD_SID=$($defaultValues.ZAIMELLA_ORACLE_PROD_SID)""",
        "",
        "echo Configurando variables de entorno de usuario ZAIMELLA_ORACLE_* ...",
        "setx ZAIMELLA_ORACLE_USER ""%ZAIMELLA_ORACLE_USER%"" >nul",
        "setx ZAIMELLA_ORACLE_PASSWORD ""%ZAIMELLA_ORACLE_PASSWORD%"" >nul",
        "setx ZAIMELLA_ORACLE_HOST ""%ZAIMELLA_ORACLE_HOST%"" >nul",
        "setx ZAIMELLA_ORACLE_PORT ""%ZAIMELLA_ORACLE_PORT%"" >nul",
        "setx ZAIMELLA_ORACLE_SID ""%ZAIMELLA_ORACLE_SID%"" >nul",
        "setx ZAIMELLA_ORACLE_PROD_USER ""%ZAIMELLA_ORACLE_PROD_USER%"" >nul",
        "setx ZAIMELLA_ORACLE_PROD_PASSWORD ""%ZAIMELLA_ORACLE_PROD_PASSWORD%"" >nul",
        "setx ZAIMELLA_ORACLE_PROD_HOST ""%ZAIMELLA_ORACLE_PROD_HOST%"" >nul",
        "setx ZAIMELLA_ORACLE_PROD_PORT ""%ZAIMELLA_ORACLE_PROD_PORT%"" >nul",
        "setx ZAIMELLA_ORACLE_PROD_SID ""%ZAIMELLA_ORACLE_PROD_SID%"" >nul",
        "",
        "echo Variables guardadas para nuevas sesiones.",
        "endlocal"
    )

    Set-Content -LiteralPath $Path -Value $lines -Encoding ASCII
}

if (-not (Test-Path -LiteralPath $ConfigPath)) {
    if (-not $CreateDefaultIfMissing) {
        throw "No existe $ConfigPath"
    }

    New-DefaultConfigFile -Path $ConfigPath
    Write-Host "Se creo plantilla externa de configuracion Oracle: $ConfigPath"
}

$values = @{}
foreach ($path in @($ConfigPath, $LocalConfigPath)) {
    if (-not (Test-Path -LiteralPath $path)) {
        continue
    }

    foreach ($line in Get-Content -LiteralPath $path) {
        if ($line -match '^\s*set\s+"(ZAIMELLA_(ORACLE|HANA)_[A-Z_]+)=(.*)"\s*$') {
            $values[$matches[1]] = $matches[3]
        }
    }
}

$missing = @()
foreach ($name in $requiredNames) {
    if (-not $values.ContainsKey($name) -or [string]::IsNullOrWhiteSpace($values[$name]) -or $values[$name].Trim().ToUpperInvariant().StartsWith("COLOQUE_AQUI")) {
        $missing += $name
    }
}

if ($missing.Count -gt 0) {
    throw "Faltan variables en ${ConfigPath}: $($missing -join ', ')"
}

foreach ($name in $values.Keys) {
    Set-Item -Path "Env:$name" -Value $values[$name]
}

Write-Host "Variables ZAIMELLA_ORACLE_* cargadas en la sesion actual."
Write-Host "SID actual: $env:ZAIMELLA_ORACLE_SID"
Write-Host ("Host actual: {0}:{1}" -f $env:ZAIMELLA_ORACLE_HOST, $env:ZAIMELLA_ORACLE_PORT)
