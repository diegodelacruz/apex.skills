from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path
import re

import yaml
from hdbcli import dbapi


ROOT = Path(__file__).resolve().parent.parent
ERP_CONFIG = (
    ROOT / "references" / "erp-config"
    if (ROOT / "references" / "erp-config").exists()
    else ROOT / "desarrollador-apex" / "references" / "erp-config"
)

COMPANY_ENV_PREFIX = {
    "00003": "ZAIMELLA_HANA_PE",
    "00015": "ZAIMELLA_HANA_ABX",
}

SET_LINE_RE = re.compile(r'^\s*set\s+"(ZAIMELLA_(?:ORACLE|HANA)_[A-Z_]+)=(.*)"\s*$', re.IGNORECASE)


def load_cmd_env_file(path: Path) -> None:
    if not path.exists():
        return

    for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        match = SET_LINE_RE.match(line)
        if match:
            name = match.group(1).upper()
            value = match.group(2)
            if value and not value.strip().upper().startswith("COLOQUE_AQUI"):
                os.environ.setdefault(name, value)


def load_local_env() -> None:
    env_dir = Path(os.environ.get("ZAIMELLA_ENV_DIR") or Path.home() / ".zaimella")
    for path in (
        Path(os.environ["ZAIMELLA_ORACLE_CONFIG_PATH"])
        if os.environ.get("ZAIMELLA_ORACLE_CONFIG_PATH")
        else env_dir / "configurar_oracle_env.cmd",
        Path(os.environ["ZAIMELLA_ORACLE_LOCAL_CONFIG_PATH"])
        if os.environ.get("ZAIMELLA_ORACLE_LOCAL_CONFIG_PATH")
        else env_dir / "configurar_oracle_env.local.cmd",
    ):
        load_cmd_env_file(path)


def env_value(name: str, fallback: str | None = None) -> str | None:
    value = os.environ.get(name)
    if value and value.strip() and not value.startswith("<"):
        return value
    if fallback and str(fallback).strip() and not str(fallback).startswith("<"):
        return str(fallback)
    return None


def load_company_config(company_code: str) -> dict:
    candidates = sorted(ERP_CONFIG.glob(f"{company_code}-*.yaml"))
    if not candidates:
        raise FileNotFoundError(f"No existe configuracion ERP para compania {company_code}")
    with candidates[0].open("r", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def schema_for_environment(company_code: str, hana: dict, environment: str) -> str | None:
    prefix = COMPANY_ENV_PREFIX.get(company_code)
    env_key = f"{prefix}_{environment.upper()}_SCHEMA" if prefix else ""
    config_key = f"{environment.lower()}_schema"
    return env_value(env_key, hana.get(config_key))


def validate_connection(company_code: str, environment: str | None = None) -> int:
    load_local_env()
    config = load_company_config(company_code)
    hana = config.get("hana_connection")
    if not hana:
        print(f"La compania {company_code} no tiene conexion HANA directa configurada.")
        return 2

    prefix = COMPANY_ENV_PREFIX.get(company_code)
    user = env_value(f"{prefix}_USER", hana.get("user")) if prefix else env_value("", hana.get("user"))
    password = env_value(f"{prefix}_PASSWORD", hana.get("password")) if prefix else env_value("", hana.get("password"))
    host = env_value(f"{prefix}_HOST", hana.get("host")) if prefix else env_value("", hana.get("host"))
    port = env_value(f"{prefix}_PORT", str(hana.get("port"))) if prefix else env_value("", str(hana.get("port")))

    missing = [
        name
        for name, value in {
            "HOST": host,
            "PORT": port,
            "USER": user,
            "PASSWORD": password,
        }.items()
        if not value
    ]
    if missing:
        env_prefix = prefix or f"ZAIMELLA_HANA_{company_code}"
        print(
            f"Faltan variables HANA para compania {company_code}: "
            + ", ".join(f"{env_prefix}_{name}" for name in missing),
            file=sys.stderr,
        )
        return 2

    conn = dbapi.connect(
        address=host,
        port=int(port),
        user=user,
        password=password,
    )
    try:
        cursor = conn.cursor()
        cursor.execute('SELECT CURRENT_SCHEMA, CURRENT_USER FROM DUMMY')
        row = cursor.fetchone()
        print(f"company_code={company_code}")
        print(f"host={host}")
        print(f"port={port}")
        print(f"user={row[1]}")
        print(f"schema={row[0]}")
        if environment:
            schema = schema_for_environment(company_code, hana, environment)
            if not schema:
                print(f"No existe esquema HANA configurado para {company_code} ambiente {environment}.", file=sys.stderr)
                return 2
            cursor.execute(f'SELECT COUNT(*) FROM "{schema}"."OCRD" WHERE "CardType" = ?', ("C",))
            count = cursor.fetchone()[0]
            print(f"environment={environment}")
            print(f"validated_schema={schema}")
            print(f"ocrd_customers={count}")
        return 0
    finally:
        conn.close()


def main() -> int:
    parser = argparse.ArgumentParser(description="Valida conectividad HANA por compania.")
    parser.add_argument("company_code", help="Codigo de compania, por ejemplo 00003 o 00015")
    parser.add_argument("--environment", choices=["test", "prod"], help="Valida un esquema HANA especifico del ambiente.")
    args = parser.parse_args()
    try:
        return validate_connection(args.company_code, args.environment)
    except Exception as exc:  # pragma: no cover
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
