"""Provisiona, conserva y prueba un cliente OAuth ORDS sin exponer secretos.

En Windows cifra cada registro local con DPAPI ligado al usuario actual. El
cliente y el secreto se generan localmente, se envian a Oracle mediante binds y
nunca se imprimen. PRODUCCION exige --confirm-production.
"""

from __future__ import annotations

import argparse
import base64
import ctypes
from ctypes import wintypes
import getpass
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import secrets
import socket
import sys
import urllib.error
import urllib.parse
import urllib.request


ENV_LINE_RE = re.compile(r'^\s*set\s+"(ZAIMELLA_ORACLE_[A-Z_]+)=(.*)"\s*$', re.IGNORECASE)
IDENTIFIER_RE = re.compile(r"^[A-Z][A-Z0-9_$#]*(?:\.[A-Z][A-Z0-9_$#]*)?$", re.IGNORECASE)
STORE_MAGIC = b"ZAIMELLA_ORDS_DPAPI_V1\n"
MODULE_NAME = "CODX_ORDS_OAUTH_TOOL"
CRYPTPROTECT_UI_FORBIDDEN = 0x1


class DataBlob(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_ubyte))]


def load_external_env() -> None:
    env_dir = Path(os.environ.get("ZAIMELLA_ENV_DIR") or Path.home() / ".zaimella")
    paths = (
        Path(os.environ["ZAIMELLA_ORACLE_CONFIG_PATH"])
        if os.environ.get("ZAIMELLA_ORACLE_CONFIG_PATH")
        else env_dir / "configurar_oracle_env.cmd",
        Path(os.environ["ZAIMELLA_ORACLE_LOCAL_CONFIG_PATH"])
        if os.environ.get("ZAIMELLA_ORACLE_LOCAL_CONFIG_PATH")
        else env_dir / "configurar_oracle_env.local.cmd",
    )
    values: dict[str, str] = {}
    for path in paths:
        if not path.is_file():
            continue
        for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
            match = ENV_LINE_RE.match(line)
            if match:
                values[match.group(1).upper()] = match.group(2)
    for name, value in values.items():
        if value and not value.upper().startswith("COLOQUE_AQUI"):
            os.environ.setdefault(name, value)


def oracle_config(environment: str) -> dict[str, str]:
    prefix = "ZAIMELLA_ORACLE_PROD_" if environment == "prod" else "ZAIMELLA_ORACLE_"
    config = {key: os.environ.get(f"{prefix}{key.upper()}", "") for key in ("host", "port", "sid", "user", "password")}
    missing = [f"{prefix}{key.upper()}" for key, value in config.items() if not value or value.upper().startswith("COLOQUE_AQUI")]
    if missing:
        raise RuntimeError("Faltan variables Oracle: " + ", ".join(missing))
    return config


def connect(environment: str, timeout: float):
    if importlib.util.find_spec("oracledb") is None:
        raise RuntimeError("Modulo Python 'oracledb' no disponible.")
    import oracledb

    config = oracle_config(environment)
    socket.create_connection((config["host"], int(config["port"])), timeout=timeout).close()
    connection = oracledb.connect(
        user=config["user"],
        password=config["password"],
        dsn=f"{config['host']}:{config['port']}/{config['sid']}",
    )
    connection.call_timeout = int(timeout * 1000)
    with connection.cursor() as cursor:
        cursor.callproc("DBMS_APPLICATION_INFO.SET_MODULE", [MODULE_NAME, environment.upper()])
        cursor.callproc("DBMS_SESSION.SET_IDENTIFIER", [f"codex:ords-oauth:{os.getpid()}"])
    return connection


def _blob(data: bytes) -> tuple[DataBlob, ctypes.Array]:
    buffer = ctypes.create_string_buffer(data)
    return DataBlob(len(data), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte))), buffer


def dpapi_protect(data: bytes) -> bytes:
    if os.name != "nt":
        raise RuntimeError("El almacen integrado requiere Windows DPAPI. Usa un gestor corporativo de secretos en otra plataforma.")
    source, source_buffer = _blob(data)
    target = DataBlob()
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    if not crypt32.CryptProtectData(
        ctypes.byref(source), "Zaimella ORDS OAuth", None, None, None, CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(target)
    ):
        raise ctypes.WinError()
    try:
        return ctypes.string_at(target.pbData, target.cbData)
    finally:
        kernel32.LocalFree(target.pbData)
        del source_buffer


def dpapi_unprotect(data: bytes) -> bytes:
    if os.name != "nt":
        raise RuntimeError("El almacen integrado requiere Windows DPAPI.")
    source, source_buffer = _blob(data)
    target = DataBlob()
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    if not crypt32.CryptUnprotectData(
        ctypes.byref(source), None, None, None, None, CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(target)
    ):
        raise ctypes.WinError()
    try:
        return ctypes.string_at(target.pbData, target.cbData)
    finally:
        kernel32.LocalFree(target.pbData)
        del source_buffer


def safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", value).strip("._")


def store_path(args: argparse.Namespace) -> Path:
    root = Path(args.store_dir) if args.store_dir else Path.home() / ".zaimella" / "ords-oauth"
    return root / args.environment / f"{safe_name(args.client_name)}.dpapi"


def write_store(path: Path, record: dict[str, str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(record, sort_keys=True).encode("utf-8")
    encrypted = STORE_MAGIC + dpapi_protect(payload)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_bytes(encrypted)
    temporary.replace(path)


def read_store(path: Path) -> dict[str, str]:
    raw = path.read_bytes()
    if not raw.startswith(STORE_MAGIC):
        raise RuntimeError(f"Formato de almacen OAuth no reconocido: {path}")
    return json.loads(dpapi_unprotect(raw[len(STORE_MAGIC) :]).decode("utf-8"))


def fingerprint(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()[:16]


def validate_transport(args: argparse.Namespace) -> None:
    insecure: list[str] = []
    for label, value in (("token-url", args.token_url), ("base-url", args.base_url)):
        parsed = urllib.parse.urlparse(value)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise RuntimeError(f"{label} no es una URL HTTP(S) valida.")
        if parsed.scheme != "https":
            insecure.append(label)
    if insecure and not args.allow_insecure_http:
        raise RuntimeError(
            "OAuth exige HTTPS. El endpoint legado HTTP requiere --allow-insecure-http y una excepcion de riesgo documentada."
        )
    if insecure:
        print("ORDS_OAUTH_TRANSPORT_WARNING=LEGACY_HTTP_EXCEPTION", file=sys.stderr)


def ensure_record(args: argparse.Namespace) -> tuple[dict[str, str], bool, Path]:
    path = store_path(args)
    if path.is_file():
        record = read_store(path)
        expected = {
            "environment": args.environment,
            "client_name": args.client_name,
            "token_url": args.token_url,
            "base_url": args.base_url.rstrip("/"),
            "support_email": args.support_email,
        }
        for key, value in expected.items():
            if record.get(key) != value:
                raise RuntimeError(f"El almacen existente no coincide en {key}; no sobrescribir ni rotar automaticamente.")
        return record, False, path
    client_id = os.environ.get(args.client_id_env, "") if args.client_id_env else ""
    client_secret = os.environ.get(args.client_secret_env, "") if args.client_secret_env else ""
    if bool(client_id) != bool(client_secret):
        raise RuntimeError("El bootstrap desde vault exige ambas variables: client_id y client_secret.")
    client_id = client_id or secrets.token_hex(16)
    client_secret = client_secret or secrets.token_hex(16)
    if len(client_id) > 32 or len(client_secret) > 32:
        raise RuntimeError("ORDS 23.1 admite como maximo 32 caracteres para client_id y client_secret.")
    record = {
        "environment": args.environment,
        "client_name": args.client_name,
        "token_url": args.token_url,
        "base_url": args.base_url.rstrip("/"),
        "support_email": args.support_email,
        # ORDS 23.1 almacena ambos valores en VARCHAR2(32). Hex mantiene
        # exactamente 32 caracteres y 128 bits de entropia por valor.
        "client_id": client_id,
        "client_secret": client_secret,
    }
    write_store(path, record)
    return record, True, path


def assert_identifier(value: str, label: str) -> str:
    if not IDENTIFIER_RE.fullmatch(value):
        raise RuntimeError(f"{label} Oracle invalido: {value}")
    return value.upper()


def call_procedure(
    environment: str, package: str, procedure: str, values: list[object], timeout: float, output_count: int = 1
) -> list[object]:
    qualified_package = assert_identifier(package, "Paquete")
    procedure_name = assert_identifier(procedure, "Procedimiento")
    if "." in procedure_name:
        raise RuntimeError("El procedimiento debe indicarse sin owner ni package.")
    if output_count < 1:
        raise RuntimeError("El procedimiento debe declarar al menos un parametro OUT.")
    with connect(environment, timeout) as connection:
        with connection.cursor() as cursor:
            results = [cursor.var(str, 4000) for _ in range(output_count)]
            cursor.callproc(f"{qualified_package}.{procedure_name}", [*values, *results])
            connection.commit()
            return [item.getvalue() for item in results]


def token_request(record: dict[str, str], timeout: float) -> str:
    basic = base64.b64encode(f"{record['client_id']}:{record['client_secret']}".encode("utf-8")).decode("ascii")
    request = urllib.request.Request(
        record["token_url"],
        data=urllib.parse.urlencode({"grant_type": "client_credentials"}).encode("ascii"),
        headers={"Authorization": f"Basic {basic}", "Content-Type": "application/x-www-form-urlencoded"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        payload = json.load(response)
    token = payload.get("access_token")
    if not token:
        raise RuntimeError("ORDS no devolvio access_token.")
    return str(token)


def http_status(url: str, timeout: float, token: str | None = None) -> tuple[int, dict[str, object] | None]:
    headers = {"Authorization": f"Bearer {token}"} if token else {}
    request = urllib.request.Request(url, headers=headers, method="GET")
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read()
            payload = json.loads(raw.decode("utf-8")) if raw else None
            return response.status, payload
    except urllib.error.HTTPError as exc:
        return exc.code, None


def cmd_provision(args: argparse.Namespace) -> int:
    if args.environment == "prod" and not args.confirm_production:
        raise RuntimeError("PRODUCCION requiere --confirm-production.")
    record, created_local, path = ensure_record(args)
    result = call_procedure(
        args.environment,
        args.package,
        args.provision_procedure,
        [record["client_id"], record["client_secret"], record["support_email"]],
        args.timeout,
    )[0]
    print(f"OAUTH_PROVISION_RESULT={result}")
    print(f"LOCAL_STORE={'CREATED' if created_local else 'REUSED'}")
    print(f"LOCAL_STORE_PATH={path}")
    print(f"CLIENT_ID_SHA256={fingerprint(record['client_id'])}")
    print(f"CLIENT_SECRET_SHA256={fingerprint(record['client_secret'])}")
    return 0


def cmd_metadata(args: argparse.Namespace) -> int:
    path = store_path(args)
    record = read_store(path)
    print(f"ENVIRONMENT={record['environment']}")
    print(f"CLIENT_NAME={record['client_name']}")
    print(f"TOKEN_URL={record['token_url']}")
    print(f"BASE_URL={record['base_url']}")
    print(f"CLIENT_ID_SHA256={fingerprint(record['client_id'])}")
    print(f"CLIENT_SECRET_SHA256={fingerprint(record['client_secret'])}")
    print(f"DPAPI_USER={getpass.getuser()}")
    return 0


def cmd_recover_from_oracle(args: argparse.Namespace) -> int:
    if not args.confirm_recovery:
        raise RuntimeError("La recuperacion desde Oracle requiere --confirm-recovery.")
    if args.environment == "prod" and not args.confirm_production:
        raise RuntimeError("La recuperacion en PRODUCCION requiere --confirm-production.")
    path = store_path(args)
    if path.exists():
        raise RuntimeError("Ya existe una cache local; usar metadata/validate-db, no sobrescribir una credencial existente.")
    client_id, client_secret, result = call_procedure(
        args.environment,
        args.package,
        args.recovery_procedure,
        [],
        args.timeout,
        output_count=3,
    )
    if not client_id or not client_secret or len(str(client_id)) > 32 or len(str(client_secret)) > 32:
        raise RuntimeError("Oracle devolvio credenciales OAuth no conformes; cache local no creada.")
    record = {
        "environment": args.environment,
        "client_name": args.client_name,
        "token_url": args.token_url,
        "base_url": args.base_url.rstrip("/"),
        "support_email": args.support_email,
        "client_id": str(client_id),
        "client_secret": str(client_secret),
    }
    write_store(path, record)
    print(f"OAUTH_RECOVERY_RESULT={result}")
    print("LOCAL_STORE=RECOVERED_FROM_ORACLE")
    print(f"LOCAL_STORE_PATH={path}")
    print(f"CLIENT_ID_SHA256={fingerprint(record['client_id'])}")
    print(f"CLIENT_SECRET_SHA256={fingerprint(record['client_secret'])}")
    return 0


def cmd_validate_db(args: argparse.Namespace) -> int:
    record = read_store(store_path(args))
    result = call_procedure(
        args.environment,
        args.package,
        args.validate_oauth_procedure,
        [record["client_id"]],
        args.timeout,
    )[0]
    print(f"OAUTH_DATABASE_VALIDATION={result}")
    print(f"CLIENT_ID_SHA256={fingerprint(record['client_id'])}")
    return 0


def cmd_smoke(args: argparse.Namespace) -> int:
    record = read_store(store_path(args))
    health_url = record["base_url"].rstrip("/") + "/" + args.path.lstrip("/")
    anonymous_status, _ = http_status(health_url, args.timeout)
    if anonymous_status not in {401, 403}:
        raise RuntimeError(f"El endpoint no protegido respondio HTTP {anonymous_status}; esperado 401 o 403.")
    token = token_request(record, args.timeout)
    authenticated_status, payload = http_status(health_url, args.timeout, token)
    if authenticated_status != 200:
        raise RuntimeError(f"El endpoint autenticado respondio HTTP {authenticated_status}; esperado 200.")
    version = None
    if isinstance(payload, dict):
        version = payload.get("version")
        if version is None and isinstance(payload.get("items"), list) and payload["items"]:
            first = payload["items"][0]
            version = first.get("version") if isinstance(first, dict) else None
    if args.expected_version and str(version) != args.expected_version:
        raise RuntimeError(f"Version HTTP no conforme: {version!r}; esperada {args.expected_version!r}.")
    print(f"ANONYMOUS_HTTP={anonymous_status}")
    print("TOKEN_REQUEST=OK")
    print(f"AUTHENTICATED_HTTP={authenticated_status}")
    print(f"API_VERSION={version}")
    print("ORDS_OAUTH_SMOKE_PASS")
    return 0


def add_store_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--environment", choices=("test", "prod"), required=True)
    parser.add_argument("--client-name", required=True)
    parser.add_argument("--token-url", required=True)
    parser.add_argument("--base-url", required=True)
    parser.add_argument("--support-email", required=True)
    parser.add_argument("--store-dir")
    parser.add_argument("--client-id-env", help="Variable temporal con el client_id recuperado del vault.")
    parser.add_argument("--client-secret-env", help="Variable temporal con el secreto recuperado del vault.")
    parser.add_argument(
        "--allow-insecure-http",
        action="store_true",
        help="Permite temporalmente endpoints HTTP legados con riesgo documentado.",
    )
    parser.add_argument("--timeout", type=float, default=30.0)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    provision = subparsers.add_parser("provision", help="Crea o reutiliza el cliente contractual.")
    add_store_arguments(provision)
    provision.add_argument("--package", required=True)
    provision.add_argument("--provision-procedure", default="PROVISIONAR_OAUTH")
    provision.add_argument("--confirm-production", action="store_true")
    provision.set_defaults(func=cmd_provision)

    metadata = subparsers.add_parser("metadata", help="Muestra solo metadata y fingerprints.")
    add_store_arguments(metadata)
    metadata.set_defaults(func=cmd_metadata)

    recover = subparsers.add_parser("recover-from-oracle", help="Recupera desde Oracle una cache DPAPI perdida sin imprimir secretos.")
    add_store_arguments(recover)
    recover.add_argument("--package", required=True)
    recover.add_argument("--recovery-procedure", default="RECUPERAR_OAUTH")
    recover.add_argument("--confirm-recovery", action="store_true")
    recover.add_argument("--confirm-production", action="store_true")
    recover.set_defaults(func=cmd_recover_from_oracle)

    validate_db = subparsers.add_parser("validate-db", help="Valida en Oracle el cliente y su privilegio.")
    add_store_arguments(validate_db)
    validate_db.add_argument("--package", required=True)
    validate_db.add_argument("--validate-oauth-procedure", default="VALIDAR_OAUTH")
    validate_db.set_defaults(func=cmd_validate_db)

    smoke = subparsers.add_parser("smoke", help="Valida rechazo anonimo, token y endpoint autenticado.")
    add_store_arguments(smoke)
    smoke.add_argument("--path", default="health")
    smoke.add_argument("--expected-version")
    smoke.set_defaults(func=cmd_smoke)
    return parser


def main() -> int:
    load_external_env()
    args = build_parser().parse_args()
    try:
        validate_transport(args)
        return args.func(args)
    except Exception as exc:
        print(f"ORDS_OAUTH_TOOL_ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
