#!/usr/bin/env python3
"""Valida documentacion funcional de tablas, vistas y dominios controlados Oracle."""
from __future__ import annotations

import argparse
import re
import sys
from dataclasses import dataclass
from pathlib import Path

CREATE = re.compile(
    r"(?im)^\s*create\s+(?:or\s+replace\s+)?(table|view)\s+((?:[a-z0-9_$#]+\.)?[a-z0-9_$#]+)"
)
COMMENT_OBJECT = re.compile(
    r"(?is)comment\s+on\s+table\s+((?:[a-z0-9_$#]+\.)?[a-z0-9_$#]+)\s+is\s+'((?:''|[^'])*)'\s*;"
)
COMMENT_COLUMN = re.compile(
    r"(?is)comment\s+on\s+column\s+((?:[a-z0-9_$#]+\.)?[a-z0-9_$#]+)\.([a-z0-9_$#]+)\s+is\s+'((?:''|[^'])*)'\s*;"
)
CHECK_DOMAIN = re.compile(
    r"(?is)check\s*\(\s*([a-z0-9_$#]+)\s+in\s*\(([^)]*)\)\s*\)"
)
STRING = re.compile(r"'((?:''|[^'])*)'")
DOMAIN_NAME = re.compile(r"(?:^|_)(estado|estatus|situacion|tipo|clasificacion|clase)(?:_|$)", re.I)


@dataclass(frozen=True)
class Finding:
    rule: str
    path: Path
    line: int
    message: str


def line_number(text: str, offset: int) -> int:
    return text.count("\n", 0, offset) + 1


def object_name(path: Path, text: str) -> tuple[str, str] | None:
    match = CREATE.search(text)
    if not match:
        return None
    return match.group(1).upper(), match.group(2).upper()


def table_columns(text: str) -> set[str]:
    match = re.search(r"(?is)create\s+table\s+[\w.$#]+\s*\((.*)\)\s*;", text)
    if not match:
        return set()
    result: set[str] = set()
    for raw in match.group(1).splitlines():
        line = raw.strip().rstrip(",")
        column = re.match(r"([a-z][a-z0-9_$#]*)\s+", line, re.I)
        if column and not re.match(r"(?:constraint|primary|foreign|unique|check)\b", line, re.I):
            result.add(column.group(1).upper())
    return result


def view_domain_columns(text: str) -> set[str]:
    return {
        match.group(1).upper()
        for match in re.finditer(r"(?im)(?:\.|\b)(estado|estatus|situacion|tipo|clasificacion|clase)\w*\s*(?:,|$)", text)
    }


def catalog(text: str) -> tuple[dict[str, str], dict[str, list[str]]]:
    object_comments = {name.upper(): comment.replace("''", "'") for name, comment in COMMENT_OBJECT.findall(text)}
    column_comments = {
        f"{obj.upper()}.{column.upper()}": comment.replace("''", "'")
        for obj, column, comment in COMMENT_COLUMN.findall(text)
    }
    domains: dict[str, list[str]] = {}
    for column, raw_values in CHECK_DOMAIN.findall(text):
        values = [value.replace("''", "'").upper() for value in STRING.findall(raw_values)]
        if values:
            domains[column.upper()] = values
    return object_comments | column_comments, domains


def audit(path: Path) -> tuple[list[Finding], list[dict[str, object]]]:
    text = path.read_text(encoding="utf-8", errors="replace")
    object_info = object_name(path, text)
    if not object_info:
        return [Finding("ORACLE-DATA-001", path, 1, "No contiene CREATE TABLE ni CREATE VIEW.")], []
    object_type, name = object_info
    comments, domains = catalog(text)
    findings: list[Finding] = []
    proposals: list[dict[str, object]] = []
    if name not in comments:
        findings.append(Finding(
            "ORACLE-DATA-002", path, 1,
            f"{object_type} {name} debe incluir COMMENT ON TABLE con proposito funcional."
        ))
    candidates = table_columns(text) if object_type == "TABLE" else view_domain_columns(text)
    for column in sorted(column for column in candidates if DOMAIN_NAME.search(column)):
        key = f"{name}.{column}"
        comment = comments.get(key, "")
        position = text.upper().find(column)
        if not comment:
            findings.append(Finding(
                "ORACLE-DATA-003", path, line_number(text, max(position, 0)),
                f"La columna de dominio {key} debe incluir COMMENT ON COLUMN."
            ))
            proposals.append({"object": name, "column": column, "known_values": domains.get(column, []), "reason": "Comentario de dominio ausente"})
            continue
        if "VALORES PERMITIDOS:" not in comment.upper():
            findings.append(Finding(
                "ORACLE-DATA-004", path, line_number(text, max(position, 0)),
                f"El comentario de {key} debe incluir 'Valores permitidos:' con significado por valor."
            ))
        missing = [value for value in domains.get(column, []) if not re.search(rf"\b{re.escape(value)}\s*=", comment, re.I)]
        if missing:
            findings.append(Finding(
                "ORACLE-DATA-005", path, line_number(text, max(position, 0)),
                f"El comentario de {key} no documenta los valores controlados: {', '.join(missing)}."
            ))
        if "VALORES PERMITIDOS:" not in comment.upper() or missing:
            proposals.append({"object": name, "column": column, "known_values": domains.get(column, []), "reason": "Catalogo de dominio incompleto"})
    return findings, proposals


def proposal_markdown(items: list[dict[str, object]]) -> str:
    lines = [
        "# Propuesta De Catalogos De Dominio",
        "",
        "Este artefacto no autoriza valores ni modifica DDL. El usuario debe aprobar cada catalogo antes de agregarlo al comentario o usar un valor nuevo.",
        "",
        "| Objeto | Columna | Valores encontrados | Accion propuesta |",
        "|---|---|---|---|",
    ]
    if not items:
        lines.append("| Sin propuestas | - | - | No aplica |")
    for item in items:
        values = ", ".join(item["known_values"]) or "Sin CHECK; definir por usuario"
        lines.append(f"| {item['object']} | {item['column']} | {values} | {item['reason']}; proponer significado y solicitar aprobacion |")
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="Valida comentarios de tablas, vistas y dominios controlados.")
    parser.add_argument("paths", nargs="+", help="Archivo DDL o carpeta con tablas/vistas.")
    parser.add_argument("--module", help="Filtra T_<MODULO>_* y VT_<MODULO>_* cuando se analiza una carpeta.")
    parser.add_argument("--proposal-output", help="Archivo Markdown para propuestas de catalogos pendientes.")
    args = parser.parse_args()
    files: set[Path] = set()
    for raw in args.paths:
        path = Path(raw).resolve()
        if path.is_file():
            files.add(path)
        elif path.is_dir():
            files.update(path.rglob("T_*.sql"))
            files.update(path.rglob("VT_*.sql"))
        else:
            print(f"RUTA_NO_ENCONTRADA {raw}", file=sys.stderr)
            return 2
    if args.module:
        prefix = args.module.upper()
        files = {
            path for path in files
            if path.stem.upper().startswith((f"T_{prefix}_", f"VT_{prefix}_"))
        }
        if not files:
            print(f"SIN_OBJETOS_MODULO {args.module.upper()}", file=sys.stderr)
            return 2
    findings: list[Finding] = []
    proposals: list[dict[str, object]] = []
    for path in sorted(files):
        object_findings, object_proposals = audit(path)
        findings.extend(object_findings)
        proposals.extend(object_proposals)
    if args.proposal_output:
        output = Path(args.proposal_output).resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(proposal_markdown(proposals), encoding="utf-8")
        print(f"ORACLE_DOMAIN_PROPOSAL {output}")
    for item in findings:
        print(f"ERROR {item.rule} {item.path}:{item.line} {item.message}")
    print(f"ORACLE_DATA_AUDIT_{'FAIL' if findings else 'PASS'} files={len(files)} errors={len(findings)} proposals={len(proposals)}")
    return 1 if findings else 0


if __name__ == "__main__":
    raise SystemExit(main())
