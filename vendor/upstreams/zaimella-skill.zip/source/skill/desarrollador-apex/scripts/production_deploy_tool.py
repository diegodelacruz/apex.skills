from __future__ import annotations

import argparse
import importlib.util
import os
from pathlib import Path
import re
import socket
import sys
from typing import Iterable

SET_LINE_RE = re.compile(r'^\s*set\s+"(ZAIMELLA_(?:ORACLE|HANA)_[A-Z_]+)=(.*)"\s*$', re.IGNORECASE)


DEPLOY_FILES = {
    "00_backup_produccion.sql": "Backup previo: DDL de objetos productivos antes del pase.",
    "01_estructura.sql": "Estructura: tablas, vistas, constraints, indices, secuencias, triggers, jobs, grants y synonyms.",
    "02_datos_configuracion.sql": "Datos de configuracion: UDC, LOV, parametros, menus, permisos y catalogos autorizados.",
    "03_paquetes.sql": "Codigo PL/SQL: package specs, package bodies, funciones y procedimientos.",
    "04_validacion_post.sql": "Validacion posterior: objetos invalidos, conteos y comprobaciones funcionales minimas.",
}

TEMP_FILE_PATTERNS = (
    r"(^|[\\/])tmp([\\/]|$)",
    r"(^|[\\/])temp([\\/]|$)",
    r"(^|[\\/])prueba[s]?([\\/]|$)",
    r"(^|[\\/])test-output([\\/]|$)",
    r"(^|[\\/])evidencia[s]?([\\/]|$)",
    r"backup",
    r"respaldo",
    r"\.bak$",
    r"\.tmp$",
)

APEX_EXPORT_PATTERNS = (
    r"wwv_flow_api",
    r"begin\s+wwv_flow",
    r"prompt\s+--application/export",
    r"set\s+define\s+off.*application",
)

TEST_DATA_MARKER_PATTERN = r"\b(prueba|temporal|dummy)\b"

DML_PATTERN = (
    r"\binsert\s+into\b",
    r"\bupdate\b",
    r"\bdelete\b",
)

DATA_CODE_OBJECT_TYPES = {"PACKAGE", "PACKAGE_BODY", "FUNCTION", "PROCEDURE"}
CURRENT_SCHEMA_DATA_PATTERN = re.compile(
    r"\balter\s+session\s+set\s+current_schema\s*=\s*DATA\b",
    re.IGNORECASE,
)
CODE_DDL_PATTERN = re.compile(
    r"\bcreate\s+or\s+replace(?:\s+(?:editionable|noneditionable))?\s+"
    r"(?:package(?:\s+body)?|function|procedure)\b",
    re.IGNORECASE,
)
SCHEMA_QUALIFIED_DATA_CODE_PATTERN = re.compile(
    r"\bcreate\s+or\s+replace(?:\s+(?:editionable|noneditionable))?\s+"
    r"(?:package(?:\s+body)?|function|procedure)\s+"
    r"(?:\"DATA\"\s*\.\s*\"[^\"]+\"|DATA\s*\.\s*[A-Z0-9_$#]+)",
    re.IGNORECASE,
)


def is_placeholder(value: str | None) -> bool:
    return not value or value.strip().upper().startswith("COLOQUE_AQUI") or value.strip().startswith("<")


def parse_cmd_env_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values
    for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        match = SET_LINE_RE.match(line)
        if match:
            values[match.group(1).upper()] = match.group(2)
    return values


def load_local_env() -> None:
    env_dir = Path(os.environ.get("ZAIMELLA_ENV_DIR") or Path.home() / ".zaimella")
    paths = (
        Path(os.environ["ZAIMELLA_ORACLE_CONFIG_PATH"])
        if os.environ.get("ZAIMELLA_ORACLE_CONFIG_PATH")
        else env_dir / "configurar_oracle_env.cmd",
        Path(os.environ["ZAIMELLA_ORACLE_LOCAL_CONFIG_PATH"])
        if os.environ.get("ZAIMELLA_ORACLE_LOCAL_CONFIG_PATH")
        else env_dir / "configurar_oracle_env.local.cmd",
    )
    values: dict[str, str] = {}
    for path in paths:
        values.update(parse_cmd_env_file(path))
    for name, value in values.items():
        if not is_placeholder(value):
            os.environ.setdefault(name, value)


def deploy_dir(project_root: Path, task_id: str | None = None) -> Path:
    if task_id:
        return project_root / "docs" / "tareas" / task_id / "deploy"
    return project_root / "docs" / "deploy"


def write_if_missing(path: Path, content: str) -> bool:
    if path.exists():
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8", newline="\n")
    return True


def scaffold(args: argparse.Namespace) -> int:
    root = Path(args.project_root).resolve()
    target = deploy_dir(root, getattr(args, "task_id", None))
    target.mkdir(parents=True, exist_ok=True)

    created: list[str] = []
    manifest = target / "manifest_pase.md"
    if write_if_missing(manifest, manifest_template(args.description, getattr(args, "task_id", None))):
        created.append(str(manifest))

    deploy_sql = target / "deploy.sql"
    if write_if_missing(deploy_sql, deploy_template(args.description)):
        created.append(str(deploy_sql))

    for filename, purpose in DEPLOY_FILES.items():
        path = target / filename
        content = f"-- {purpose}\n-- Agregar solo cambios validados en TEST y pendientes de pase.\n\n"
        if filename == "03_paquetes.sql":
            content += "prompt Esquema DATA para codigo PL/SQL\nalter session set current_schema=DATA;\n\n"
        if write_if_missing(path, content):
            created.append(str(path))

    print(f"Deploy preparado: {target}")
    if created:
        print("Archivos creados:")
        for path in created:
            print(f"- {path}")
    else:
        print("No se crearon archivos; ya existian.")
    return 0


def manifest_template(description: str, task_id: str | None = None) -> str:
    return f"""# Manifiesto De Pase A Produccion

- Fecha:
- Ambiente origen: TEST
- Ambiente destino: PRODUCCION
- Responsable:
- Solicitud o alcance: {description or ""}
- ID tarea: {task_id or ""}
- Repo fuente:
- Rama local de tarea:
- Rama oficial de publicacion: main
- Commit base:
- Commit candidato validado en TEST:
- Commit aprobado y publicado en origin/main:
- Checkout limpio de verificacion (ruta y `git status --porcelain` vacio):
- SHA256 de deploy.sql ejecutable:
- Esquema objetivo de objetos Oracle: DATA

## Tareas incluidas

| ID | Tarea | Motivo | Checkpoint test | Estado QA |
|---|---|---|---|---|

## Objetos incluidos

| Orden | Tipo | Objeto | Archivo fuente | Commit/blob | SHA256 fuente | Script | Dependencias |
|---|---|---|---|---|---|---|---|

## Datos de configuracion incluidos

| Tipo | Tabla | Clave funcional | Script | Justificacion |
|---|---|---|---|---|

## Excluido del pase

| Elemento | Motivo |
|---|---|

## Validacion post

| Validacion | Script/Evidencia |
|---|---|
"""


def deploy_template(description: str) -> str:
    return f"""-- Deploy a produccion
-- Alcance: {description or ""}
-- Origen: TEST
-- Destino: PRODUCCION
-- Regla: ejecutar solo cambios validados en TEST y pendientes de pase.

set define off
set serveroutput on
whenever sqlerror exit failure rollback

prompt 01_estructura.sql
@@01_estructura.sql

prompt 02_datos_configuracion.sql
@@02_datos_configuracion.sql

prompt 03_paquetes.sql
@@03_paquetes.sql

prompt 04_validacion_post.sql
@@04_validacion_post.sql

prompt Deploy finalizado
"""


def validate(args: argparse.Namespace) -> int:
    root = Path(args.project_root).resolve()
    target = deploy_dir(root, getattr(args, "task_id", None))
    errors: list[str] = []
    warnings: list[str] = []

    if not target.exists():
        errors.append(f"No existe {target}. Ejecuta scaffold antes de preparar el pase.")
    else:
        required = ["deploy.sql", "manifest_pase.md"]
        for filename in required:
            if not (target / filename).exists():
                errors.append(f"Falta {target / filename}.")

        manifest = target / "manifest_pase.md"
        if getattr(args, "for_production", False) and manifest.exists():
            manifest_text = manifest.read_text(encoding="utf-8", errors="ignore")
            required_labels = (
                "ID tarea",
                "Repo fuente",
                "Rama local de tarea",
                "Rama oficial de publicacion",
                "Commit base",
                "Commit candidato validado en TEST",
                "Commit aprobado y publicado en origin/main",
                "Checkout limpio de verificacion (ruta y `git status --porcelain` vacio)",
                "SHA256 de deploy.sql ejecutable",
                "Esquema objetivo de objetos Oracle",
            )
            manifest_values: dict[str, str] = {}
            for label in required_labels:
                match = re.search(rf"(?m)^- {re.escape(label)}:[ \t]*([^\r\n]*)$", manifest_text)
                if not match or is_placeholder(match.group(1)):
                    errors.append(f"Manifiesto incompleto para PRODUCCION: {label}.")
                else:
                    manifest_values[label] = match.group(1).strip()

            if manifest_values.get("Rama oficial de publicacion") != "main":
                errors.append("La rama oficial de publicacion debe ser main.")
            if args.task_id and manifest_values.get("ID tarea") != args.task_id:
                errors.append("El ID tarea del manifiesto no coincide con --task-id.")
            candidate = manifest_values.get("Commit candidato validado en TEST")
            published = manifest_values.get("Commit aprobado y publicado en origin/main")
            if candidate and published and candidate != published:
                errors.append("El commit publicado en origin/main no coincide con el candidato validado en TEST/QA.")
            if manifest_values.get("Esquema objetivo de objetos Oracle", "").upper() != "DATA":
                errors.append("El manifiesto debe declarar DATA como esquema objetivo, salvo una excepcion explicitamente autorizada.")
            deploy_hash = manifest_values.get("SHA256 de deploy.sql ejecutable")
            if deploy_hash and not re.fullmatch(r"[0-9a-fA-F]{64}", deploy_hash):
                errors.append("SHA256 de deploy.sql ejecutable no tiene formato SHA-256 valido.")
            elif deploy_hash and (target / "deploy.sql").exists():
                import hashlib
                actual_hash = hashlib.sha256((target / "deploy.sql").read_bytes()).hexdigest()
                if actual_hash.lower() != deploy_hash.lower():
                    errors.append("El SHA256 registrado no coincide con deploy.sql; regenerar evidencia y no ejecutar el pase.")
            for label in ("Commit base", "Commit candidato validado en TEST", "Commit aprobado y publicado en origin/main"):
                value = manifest_values.get(label)
                if value and not re.fullmatch(r"[0-9a-fA-F]{7,40}", value):
                    errors.append(f"{label} no tiene un SHA Git valido.")

        files = [p for p in target.rglob("*") if p.is_file()]
        for path in files:
            rel = path.relative_to(root).as_posix().lower()
            if path.name != "00_backup_produccion.sql" and any(
                re.search(pattern, rel, re.IGNORECASE) for pattern in TEMP_FILE_PATTERNS
            ):
                errors.append(f"Artefacto no permitido en deploy: {path}")

            if path.suffix.lower() in {".sql", ".md", ".txt"}:
                text = path.read_text(encoding="utf-8", errors="ignore")
                lower = text.lower()
                if not args.allow_apex_export and any(re.search(pattern, lower, re.DOTALL) for pattern in APEX_EXPORT_PATTERNS):
                    errors.append(f"Export/import APEX detectado sin autorizacion: {path}")
                if path.name == "02_datos_configuracion.sql" and not args.allow_test_data:
                    has_dml = any(re.search(pattern, lower, re.IGNORECASE) for pattern in DML_PATTERN)
                    has_test_marker = re.search(TEST_DATA_MARKER_PATTERN, lower, re.IGNORECASE)
                    if has_dml and has_test_marker:
                        errors.append(f"DML con indicios de data de prueba en {path}.")
                if "apex_export" in lower or "wwv_flow_export_api" in lower:
                    warnings.append(f"Referencia a API de exportacion APEX en {path}; solo aplica a publicacion APEX autorizada.")
                if path.name == "03_paquetes.sql" and CODE_DDL_PATTERN.search(text):
                    if not CURRENT_SCHEMA_DATA_PATTERN.search(text):
                        errors.append(f"03_paquetes.sql debe fijar ALTER SESSION SET CURRENT_SCHEMA=DATA antes de recrear codigo PL/SQL de DATA: {path}")
                    if SCHEMA_QUALIFIED_DATA_CODE_PATTERN.search(text):
                        errors.append(f"03_paquetes.sql no debe recrear codigo PL/SQL como DATA.objeto directo; fija CURRENT_SCHEMA=DATA y usa fuentes sin prefijo DATA: {path}")

        deploy_sql = target / "deploy.sql"
        if deploy_sql.exists():
            text = deploy_sql.read_text(encoding="utf-8", errors="ignore").lower()
            for filename in DEPLOY_FILES:
                if filename == "00_backup_produccion.sql":
                    continue
                if filename in [p.name for p in files] and filename.lower() not in text:
                    warnings.append(f"{filename} existe pero no esta referenciado en deploy.sql.")

    for warning in warnings:
        print(f"WARN: {warning}")
    if errors:
        for error in errors:
            print(f"ERROR: {error}", file=sys.stderr)
        return 1
    print("OK: paquete de pase validado.")
    return 0


def parse_object(value: str) -> tuple[str, str, str]:
    if ":" not in value or "." not in value:
        raise argparse.ArgumentTypeError("Usa formato TIPO:OWNER.OBJETO, por ejemplo PACKAGE:DATA.PK_MODULO.")
    object_type, qualified = value.split(":", 1)
    owner, name = qualified.split(".", 1)
    return object_type.upper(), owner.upper(), name.upper()


def oracle_config(environment: str, args: argparse.Namespace) -> dict[str, str | None]:
    prefix = "ZAIMELLA_ORACLE_PROD_" if environment == "prod" else "ZAIMELLA_ORACLE_"
    return {
        "host": args.host or os.environ.get(f"{prefix}HOST"),
        "port": args.port or os.environ.get(f"{prefix}PORT"),
        "sid": args.sid or os.environ.get(f"{prefix}SID"),
        "user": args.user or os.environ.get(f"{prefix}USER"),
        "password": args.password or os.environ.get(f"{prefix}PASSWORD"),
        "prefix": prefix,
    }


def assert_oracle_config(config: dict[str, str | None], environment: str) -> int:
    missing = [
        f"{config['prefix']}{key.upper()}"
        for key in ("host", "port", "sid", "user", "password")
        if is_placeholder(config.get(key))
    ]
    if missing:
        print(f"Faltan variables Oracle {environment.upper()}: " + ", ".join(missing), file=sys.stderr)
        return 2
    return 0


def assert_environment_sid(sid: str | None, environment: str, force: bool) -> int:
    # El ambiente se determina por el prefijo de parámetros seleccionado, no por patrones locales de SID.
    return 0


def connect_oracle(config: dict[str, str | None]):
    import oracledb

    host = str(config["host"])
    port = str(config["port"])
    sid = str(config["sid"])
    try:
        socket.create_connection((host, int(port)), timeout=5).close()
    except OSError as exc:
        print(f"No hay conectividad Oracle {host}:{port}: {exc}", file=sys.stderr)
        raise
    return oracledb.connect(
        user=str(config["user"]),
        password=str(config["password"]),
        dsn=f"{host}:{port}/{sid}",
    )


def export_test_objects(args: argparse.Namespace) -> int:
    return export_objects(args, environment="test", backup=False)


def backup_prod_objects(args: argparse.Namespace) -> int:
    return export_objects(args, environment="prod", backup=True)


def export_objects(args: argparse.Namespace, environment: str, backup: bool) -> int:
    load_local_env()
    if importlib.util.find_spec("oracledb") is None:
        print("Modulo Python 'oracledb' no disponible.", file=sys.stderr)
        return 2

    root = Path(args.project_root).resolve()
    target = deploy_dir(root, getattr(args, "task_id", None))
    target.mkdir(parents=True, exist_ok=True)

    config = oracle_config(environment, args)
    config_error = assert_oracle_config(config, environment)
    if config_error:
        return config_error

    sid_error = assert_environment_sid(config.get("sid"), environment, args.force)
    if sid_error:
        return sid_error

    try:
        conn = connect_oracle(config)
    except OSError:
        return 4

    with conn:
        with conn.cursor() as cur:
            for object_type, owner, name in args.objects:
                output = target / "00_backup_produccion.sql" if backup else output_file_for_type(target, object_type)
                write_object_ddl(cur, output, object_type, owner, name, environment)
                if object_type == "PACKAGE":
                    write_object_ddl(cur, output, "PACKAGE_BODY", owner, name, environment, missing_ok=True)
                action = "Backup PRODUCCION" if backup else "Exportado desde TEST"
                print(f"{action}: {object_type} {owner}.{name} -> {output}")
    return 0


def write_object_ddl(cur, output: Path, object_type: str, owner: str, name: str, environment: str, missing_ok: bool = False) -> None:
    try:
        ddl = get_ddl(cur, object_type, owner, name)
    except Exception:
        if missing_ok:
            return
        raise
    if owner == "DATA" and object_type in DATA_CODE_OBJECT_TYPES:
        ensure_current_schema_data(output)
        ddl = normalize_data_code_ddl(ddl)
    with output.open("a", encoding="utf-8", newline="\n") as fh:
        fh.write(f"\n\nprompt {environment.upper()} {object_type} {owner}.{name}\n")
        fh.write(ddl.rstrip())
        fh.write("\n/\n")


def ensure_current_schema_data(output: Path) -> None:
    text = output.read_text(encoding="utf-8", errors="ignore") if output.exists() else ""
    if CURRENT_SCHEMA_DATA_PATTERN.search(text):
        return
    with output.open("a", encoding="utf-8", newline="\n") as fh:
        fh.write("\n\nprompt Esquema DATA para codigo PL/SQL\n")
        fh.write("alter session set current_schema=DATA;\n")


def normalize_data_code_ddl(ddl: str) -> str:
    pattern = re.compile(
        r"\b(create\s+or\s+replace(?:\s+(?:editionable|noneditionable))?\s+"
        r"(?:package(?:\s+body)?|function|procedure)\s+)"
        r"(?:\"DATA\"\s*\.\s*\"([^\"]+)\"|DATA\s*\.\s*([A-Z0-9_$#]+))",
        re.IGNORECASE,
    )

    def replace(match: re.Match[str]) -> str:
        object_name = match.group(2) or match.group(3)
        return f"{match.group(1)}{object_name}"

    return pattern.sub(replace, ddl, count=1)


def get_ddl(cur, object_type: str, owner: str, name: str) -> str:
    cur.execute(
        """
        begin
            dbms_metadata.set_transform_param(dbms_metadata.session_transform, 'SQLTERMINATOR', true);
            dbms_metadata.set_transform_param(dbms_metadata.session_transform, 'PRETTY', true);
            dbms_metadata.set_transform_param(dbms_metadata.session_transform, 'SEGMENT_ATTRIBUTES', false);
            dbms_metadata.set_transform_param(dbms_metadata.session_transform, 'STORAGE', false);
        end;
        """
    )
    cur.execute("select dbms_metadata.get_ddl(:object_type, :name, :owner) from dual", object_type=object_type, name=name, owner=owner)
    row = cur.fetchone()
    if not row or row[0] is None:
        raise RuntimeError(f"No se pudo obtener DDL para {object_type}:{owner}.{name}")
    return str(row[0])


def output_file_for_type(target: Path, object_type: str) -> Path:
    if object_type in {"PACKAGE", "PACKAGE_BODY", "FUNCTION", "PROCEDURE"}:
        return target / "03_paquetes.sql"
    return target / "01_estructura.sql"


def validate_prod_compile(args: argparse.Namespace) -> int:
    load_local_env()
    if importlib.util.find_spec("oracledb") is None:
        print("Modulo Python 'oracledb' no disponible.", file=sys.stderr)
        return 2

    config = oracle_config("prod", args)
    config_error = assert_oracle_config(config, "prod")
    if config_error:
        return config_error
    sid_error = assert_environment_sid(config.get("sid"), "prod", args.force)
    if sid_error:
        return sid_error

    try:
        conn = connect_oracle(config)
    except OSError:
        return 4

    with conn:
        with conn.cursor() as cur:
            invalids = []
            for object_type, owner, name in args.objects:
                cur.execute(
                    """
                    select owner, object_type, object_name, status
                    from all_objects
                    where owner = :owner
                      and object_name = :name
                      and object_type in (:object_type, 'PACKAGE BODY')
                    order by object_type
                    """,
                    owner=owner,
                    name=name,
                    object_type=object_type,
                )
                rows = cur.fetchall()
                if not rows:
                    invalids.append((owner, object_type, name, "NO_EXISTE"))
                    continue
                for row in rows:
                    print(f"{row[0]}.{row[2]} {row[1]} {row[3]}")
                    if row[3] != "VALID":
                        invalids.append(row)

            if invalids:
                print("Objetos invalidos o no encontrados:", file=sys.stderr)
                for row in invalids:
                    print(" - " + ".".join(str(value) for value in row), file=sys.stderr)
                return 1
    print("OK: objetos productivos VALID.")
    return 0


def describe_commons_job_procedure(args: argparse.Namespace) -> int:
    load_local_env()
    if importlib.util.find_spec("oracledb") is None:
        print("Modulo Python 'oracledb' no disponible.", file=sys.stderr)
        return 2

    config = oracle_config(args.environment, args)
    config_error = assert_oracle_config(config, args.environment)
    if config_error:
        return config_error
    sid_error = assert_environment_sid(config.get("sid"), args.environment, args.force)
    if sid_error:
        return sid_error

    try:
        conn = connect_oracle(config)
    except OSError:
        return 4

    with conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                select argument_name, position, sequence, data_type, in_out, defaulted
                from all_arguments
                where owner = 'DATA'
                  and package_name = 'PK_CORP_COMMONS'
                  and object_name = 'SP_CREA_JOB'
                order by overload nulls first, sequence
                """
            )
            rows = cur.fetchall()
            if not rows:
                print("No se encontro DATA.PK_CORP_COMMONS.SP_CREA_JOB en ALL_ARGUMENTS.", file=sys.stderr)
                return 1
            print("Firma DATA.PK_CORP_COMMONS.SP_CREA_JOB:")
            for argument_name, position, sequence, data_type, in_out, defaulted in rows:
                name = argument_name or "(return/implicit)"
                print(f"- seq={sequence} pos={position} {name} {data_type} {in_out} defaulted={defaulted}")
    return 0


def describe_job(args: argparse.Namespace) -> int:
    load_local_env()
    if importlib.util.find_spec("oracledb") is None:
        print("Modulo Python 'oracledb' no disponible.", file=sys.stderr)
        return 2

    config = oracle_config(args.environment, args)
    config_error = assert_oracle_config(config, args.environment)
    if config_error:
        return config_error
    sid_error = assert_environment_sid(config.get("sid"), args.environment, args.force)
    if sid_error:
        return sid_error

    if "." not in args.job:
        print("Usa formato OWNER.NOMBRE_JOB.", file=sys.stderr)
        return 2
    owner, job_name = args.job.split(".", 1)
    owner = owner.upper()
    job_name = job_name.upper()

    try:
        conn = connect_oracle(config)
    except OSError:
        return 4

    with conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                select owner,
                       job_name,
                       enabled,
                       state,
                       job_type,
                       job_action,
                       start_date,
                       repeat_interval,
                       next_run_date,
                       job_class,
                       comments
                from all_scheduler_jobs
                where owner = :owner
                  and job_name = :job_name
                """,
                owner=owner,
                job_name=job_name,
            )
            row = cur.fetchone()
            if not row:
                print(f"No existe job {owner}.{job_name}.")
                return 1

            labels = (
                "owner",
                "job_name",
                "enabled",
                "state",
                "job_type",
                "job_action",
                "start_date",
                "repeat_interval",
                "next_run_date",
                "job_class",
                "comments",
            )
            for label, value in zip(labels, row):
                print(f"{label}: {value}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Prepara, extrae y valida paquetes de paso a produccion APEX/Oracle.")
    sub = parser.add_subparsers(dest="command", required=True)

    scaffold_parser = sub.add_parser("scaffold", help="Crea el deploy compartido o el workspace docs/tareas/<ID>/deploy.")
    scaffold_parser.add_argument("--project-root", default=".")
    scaffold_parser.add_argument("--task-id", help="ID de tarea para aislar el deploy en docs/tareas/<ID>/deploy.")
    scaffold_parser.add_argument("--description", default="")
    scaffold_parser.set_defaults(func=scaffold)

    validate_parser = sub.add_parser("validate", help="Valida el deploy compartido o el workspace de una tarea.")
    validate_parser.add_argument("--project-root", default=".")
    validate_parser.add_argument("--task-id", help="ID de tarea cuyo deploy se validara.")
    validate_parser.add_argument("--allow-apex-export", action="store_true")
    validate_parser.add_argument("--allow-test-data", action="store_true")
    validate_parser.add_argument("--for-production", action="store_true", help="Exige linaje Git completo y commit publicado.")
    validate_parser.set_defaults(func=validate)

    export_parser = sub.add_parser("export-test-objects", help="Extrae DDL de TEST al deploy de la tarea; no sustituye la fuente Git.")
    export_parser.add_argument("--project-root", default=".")
    export_parser.add_argument("--task-id", help="ID de tarea para aislar la salida.")
    export_parser.add_argument("--objects", nargs="+", type=parse_object, required=True)
    export_parser.add_argument("--host")
    export_parser.add_argument("--port")
    export_parser.add_argument("--sid")
    export_parser.add_argument("--user")
    export_parser.add_argument("--password")
    export_parser.add_argument("--force", action="store_true")
    export_parser.set_defaults(func=export_test_objects)

    backup_parser = sub.add_parser("backup-prod-objects", help="Respalda DDL de objetos productivos antes del pase.")
    backup_parser.add_argument("--project-root", default=".")
    backup_parser.add_argument("--task-id", help="ID de tarea para aislar el respaldo.")
    backup_parser.add_argument("--objects", nargs="+", type=parse_object, required=True)
    backup_parser.add_argument("--host")
    backup_parser.add_argument("--port")
    backup_parser.add_argument("--sid")
    backup_parser.add_argument("--user")
    backup_parser.add_argument("--password")
    backup_parser.add_argument("--force", action="store_true")
    backup_parser.set_defaults(func=backup_prod_objects)

    compile_parser = sub.add_parser("validate-prod-compile", help="Valida que los objetos desplegados en produccion esten VALID.")
    compile_parser.add_argument("--objects", nargs="+", type=parse_object, required=True)
    compile_parser.add_argument("--host")
    compile_parser.add_argument("--port")
    compile_parser.add_argument("--sid")
    compile_parser.add_argument("--user")
    compile_parser.add_argument("--password")
    compile_parser.add_argument("--force", action="store_true")
    compile_parser.set_defaults(func=validate_prod_compile)

    commons_parser = sub.add_parser("describe-commons-job-procedure", help="Muestra la firma vigente de DATA.PK_CORP_COMMONS.SP_CREA_JOB.")
    commons_parser.add_argument("--environment", choices=("test", "prod"), default="prod")
    commons_parser.add_argument("--host")
    commons_parser.add_argument("--port")
    commons_parser.add_argument("--sid")
    commons_parser.add_argument("--user")
    commons_parser.add_argument("--password")
    commons_parser.add_argument("--force", action="store_true")
    commons_parser.set_defaults(func=describe_commons_job_procedure)

    job_parser = sub.add_parser("describe-job", help="Muestra atributos actuales de un job para validar cambios minimos.")
    job_parser.add_argument("--environment", choices=("test", "prod"), default="prod")
    job_parser.add_argument("--job", required=True, help="Formato OWNER.NOMBRE_JOB")
    job_parser.add_argument("--host")
    job_parser.add_argument("--port")
    job_parser.add_argument("--sid")
    job_parser.add_argument("--user")
    job_parser.add_argument("--password")
    job_parser.add_argument("--force", action="store_true")
    job_parser.set_defaults(func=describe_job)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
