#!/usr/bin/env python3
"""Preflight y reconciliación aislada de un candidato APEX contra origin/main."""
from __future__ import annotations

import argparse
import json
import re
import subprocess
from pathlib import Path


PAGE_PATH = re.compile(r"(?:^|/)APEX/(\d+)-[^/]+/PAGINAS/page_(\d+)\.sql$", re.IGNORECASE)
PROJECT_SLUG = re.compile(r"^app-[0-9]+-[a-z0-9]+(?:-[a-z0-9]+)*$")


def git(repo: Path, *args: str, check: bool = True) -> str:
    result = subprocess.run(["git", "-C", str(repo), *args], text=True, capture_output=True)
    if check and result.returncode:
        raise RuntimeError(result.stderr.strip() or result.stdout.strip() or "git falló")
    return result.stdout.strip()


def paths_between(repo: Path, first: str, last: str) -> list[str]:
    return [item for item in git(repo, "diff", "--name-only", f"{first}..{last}").splitlines() if item]


def describe_path(path: str) -> dict[str, str]:
    match = PAGE_PATH.search(path.replace("\\", "/"))
    return {"path": path, "app_id": match.group(1) if match else "", "page_id": match.group(2) if match else ""}


def merge_is_clean(repo: Path, remote: str, candidate: str) -> tuple[bool, str]:
    result = subprocess.run(["git", "-C", str(repo), "merge-tree", "--write-tree", remote, candidate], text=True, capture_output=True)
    return result.returncode == 0, (result.stderr or result.stdout).strip()


def validate_project_scope(project_slug: str, task_id: str, worktree: Path | None) -> None:
    if not PROJECT_SLUG.fullmatch(project_slug):
        raise ValueError("--project-slug debe tener formato app-<APP_ID>-<nombre-proyecto-normalizado>.")
    if not task_id.strip() or any(char in task_id for char in "/\\"):
        raise ValueError("--task-id debe ser un identificador de tarea no vacio y sin separadores de ruta.")
    if worktree:
        parts = {part.casefold() for part in worktree.resolve().parts}
        if project_slug.casefold() not in parts:
            raise ValueError("--worktree debe quedar bajo el PROJECT_SLUG contractual; no se admite un worktree identificado solo por ID_TAREA.")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", required=True, type=Path)
    parser.add_argument("--task-id", required=True)
    parser.add_argument("--project-slug", required=True, help="Identidad app-<APP_ID>-<nombre-normalizado>.")
    parser.add_argument("--base-commit", required=True)
    parser.add_argument("--candidate-commit", required=True)
    parser.add_argument("--path", action="append", default=[], help="Ruta fuente del inventario; repetir por cada ruta.")
    parser.add_argument("--worktree", type=Path)
    parser.add_argument("--apply", action="store_true")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    repo = args.repo_root.resolve()
    if not (repo / ".git").exists():
        parser.error(f"No es repositorio Git: {repo}")
    if args.apply and not args.worktree:
        parser.error("--apply requiere --worktree")
    try:
        validate_project_scope(args.project_slug, args.task_id, args.worktree)
        git(repo, "fetch", "origin")
        base = git(repo, "rev-parse", "--verify", args.base_commit)
        candidate = git(repo, "rev-parse", "--verify", args.candidate_commit)
        remote = git(repo, "rev-parse", "--verify", "origin/main")
        candidate_paths = paths_between(repo, base, candidate)
        inventory = sorted(set(args.path))
        unexpected = sorted(set(candidate_paths) - set(inventory)) if inventory else []
        missing = sorted(set(inventory) - set(candidate_paths)) if inventory else []
        remote_paths = paths_between(repo, base, remote)
        shared_paths = sorted(set(candidate_paths) & set(remote_paths))
        clean_merge, merge_detail = merge_is_clean(repo, remote, candidate) if shared_paths else (True, "Sin rutas compartidas.")
        report = {
            "project_slug": args.project_slug, "task_id": args.task_id,
            "task_key": f"{args.project_slug}/{args.task_id}",
            "base_commit": base, "candidate_commit": candidate, "origin_main": remote,
            "candidate_paths": [describe_path(path) for path in candidate_paths],
            "remote_paths": [describe_path(path) for path in remote_paths],
            "shared_paths": [describe_path(path) for path in shared_paths],
            "unexpected_candidate_paths": unexpected, "missing_inventory_paths": missing,
            "merge_clean": clean_merge, "merge_detail": merge_detail,
        }
        if unexpected or missing:
            report["decision"] = "INVENTORY_MISMATCH"
            report["next_action"] = "Corregir el inventario o separar los cambios ajenos antes de integrar."
        elif shared_paths and not clean_merge:
            report["decision"] = "USER_DECISION_REQUIRED"
            report["next_action"] = "Comparar hunks; pedir decisión solo si sus comportamientos son incompatibles y no inferibles."
        else:
            report["decision"] = "AUTO_RECONCILE_READY"
            report["next_action"] = "Crear worktree limpio desde origin/main, reaplicar el candidato y repetir TEST/QA si cambia el SHA."
        if args.apply:
            if report["decision"] != "AUTO_RECONCILE_READY":
                raise RuntimeError(f"No es seguro aplicar: {report['decision']}")
            worktree = args.worktree.resolve()
            if worktree.exists():
                raise RuntimeError(f"El worktree destino ya existe: {worktree}")
            git(repo, "worktree", "add", "--detach", str(worktree), remote)
            for commit in git(repo, "rev-list", "--reverse", f"{base}..{candidate}").splitlines():
                git(worktree, "cherry-pick", commit)
            report["integration_worktree"] = str(worktree)
            report["reconciled_candidate_commit"] = git(worktree, "rev-parse", "HEAD")
            report["worktree_status"] = git(worktree, "status", "--porcelain") or "clean"
        output = json.dumps(report, ensure_ascii=False, indent=2)
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(output + "\n", encoding="utf-8")
        print(f"APEX_INTEGRATION_{report['decision']}")
        print(output)
        return 0 if report["decision"] == "AUTO_RECONCILE_READY" else 1
    except Exception as exc:
        print(f"APEX_INTEGRATION_ERROR: {exc}")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
