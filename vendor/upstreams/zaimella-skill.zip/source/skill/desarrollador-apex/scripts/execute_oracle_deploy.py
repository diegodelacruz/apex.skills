"""Ejecuta un deploy Oracle versionado mediante python-oracledb.

Soporta sentencias terminadas en ``;``, bloques PL/SQL terminados por ``/``
y referencias relativas ``@@archivo.sql``. No interpreta ni reescribe DDL.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import os
import re
import subprocess
import sys
from datetime import datetime
from pathlib import Path


ENV_LINE = re.compile(r'^\s*set\s+"(ZAIMELLA_(?:ORACLE|HANA)_[A-Z_]+)=(.*)"\s*$', re.IGNORECASE)
INCLUDE_LINE = re.compile(r'^\s*@@([^\s]+)\s*$', re.IGNORECASE)
# Oracle permite EDITIONABLE/NONEDITIONABLE entre CREATE [OR REPLACE] y el
# tipo de objeto. Debe reconocerse aqui igual que en CODE_DDL para que un
# package body se mantenga como un bloque completo hasta el terminador "/".
PLSQL_START = re.compile(
    r"^\s*(?:declare|begin|create\s+(?:or\s+replace\s+)?"
    r"(?:(?:editionable|noneditionable)\s+)?"
    r"(?:package(?:\s+body)?|function|procedure|trigger|type))\b",
    re.IGNORECASE,
)
IGNORED_SQLPLUS = re.compile(r"^\s*(?:prompt|set|whenever)\b", re.IGNORECASE)
FORBIDDEN_SQLPLUS = re.compile(r"^\s*(?:connect|conn|host|spool|start|@)\b", re.IGNORECASE)
CODE_DDL = re.compile(
    r"^\s*create\s+(?:or\s+replace\s+)?(?:editionable\s+|noneditionable\s+)?"
    r"(package(?:\s+body)?|function|procedure)\s+"
    r"(?:(\"?[A-Z][A-Z0-9_$#]*\"?)\.)?(\"?[A-Z][A-Z0-9_$#]*\"?)",
    re.IGNORECASE,
)
ORACLE_IDENTIFIER = re.compile(r"^[A-Z][A-Z0-9_$#]*$", re.IGNORECASE)


def load_local_env() -> None:
    env_dir = Path(os.environ.get("ZAIMELLA_ENV_DIR") or Path.home() / ".zaimella")
    paths = (
        Path(os.environ["ZAIMELLA_ORACLE_CONFIG_PATH"])
        if os.environ.get("ZAIMELLA_ORACLE_CONFIG_PATH")
        else env_dir / "configurar_oracle_env.cmd",
        Path(os.environ["ZAIMELLA_ORACLE_LOCAL_CONFIG_PATH"])
        if os.environ.get("ZAIMELLA_ORACLE_LOCAL_CONFIG_PATH")
        else env_dir / "configurar_oracle_env.local.cmd",
    )
    values: dict[str, str] = {}
    for path in paths:
        if not path.is_file():
            continue
        for raw in path.read_text(encoding="utf-8", errors="ignore").splitlines():
            match = ENV_LINE.match(raw)
            if match:
                values[match.group(1).upper()] = match.group(2)
    for name, value in values.items():
        if value and name not in os.environ:
            os.environ[name] = value


def emit(message: str, timing_log: Path | None) -> None:
    line = f"{datetime.now().astimezone().isoformat(timespec='seconds')} {message}"
    print(line)
    if timing_log:
        timing_log.parent.mkdir(parents=True, exist_ok=True)
        with timing_log.open("a", encoding="utf-8", newline="\n") as fh:
            fh.write(line + "\n")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_source_commit(repo_root: Path, commit: str, require_published: bool) -> None:
    if not repo_root.is_dir():
        raise RuntimeError(f"No existe el repo fuente para verificar el commit: {repo_root}")
    status = subprocess.run(
        ["git", "-C", str(repo_root), "status", "--porcelain"],
        check=False,
        capture_output=True,
        text=True,
    )
    if status.returncode != 0:
        raise RuntimeError("No se pudo comprobar el estado del checkout fuente.")
    if status.stdout.strip():
        raise RuntimeError("El checkout fuente no esta limpio; no ejecutar desde una copia con cambios locales.")
    requested = subprocess.run(
        ["git", "-C", str(repo_root), "rev-parse", "--verify", commit],
        check=False,
        capture_output=True,
        text=True,
    )
    if requested.returncode != 0:
        raise RuntimeError(f"No se pudo resolver el commit candidato {commit} en el checkout fuente.")
    head = subprocess.run(
        ["git", "-C", str(repo_root), "rev-parse", "--verify", "HEAD"],
        check=False,
        capture_output=True,
        text=True,
    )
    if head.returncode != 0:
        raise RuntimeError("No se pudo resolver HEAD en el checkout fuente.")
    requested_sha = requested.stdout.strip().lower()
    head_sha = head.stdout.strip().lower()
    if head_sha != requested_sha:
        raise RuntimeError(
            f"El checkout fuente esta en {head_sha}, no en el commit candidato declarado {requested_sha}."
        )
    if not require_published:
        return
    resolved = subprocess.run(
        ["git", "-C", str(repo_root), "rev-parse", "--verify", "origin/main"],
        check=False,
        capture_output=True,
        text=True,
    )
    if resolved.returncode != 0:
        raise RuntimeError("No se pudo resolver origin/main en el repo fuente; ejecuta git fetch y corrige el preflight.")
    published = resolved.stdout.strip().lower()
    if requested_sha != published:
        raise RuntimeError(
            f"El commit candidato {commit} no es exactamente el publicado en origin/main ({published})."
        )


def session_identity(cur) -> tuple[str, str, str]:
    cur.execute(
        "select sys_context('USERENV','SESSION_USER'), sys_context('USERENV','CURRENT_SCHEMA'), "
        "sys_context('USERENV','DB_UNIQUE_NAME') from dual"
    )
    user, schema, database = cur.fetchone()
    return str(user), str(schema), str(database)


def assert_current_schema(cur, expected_schema: str) -> tuple[str, str, str]:
    identity = session_identity(cur)
    if identity[1].upper() != expected_schema.upper():
        raise RuntimeError(
            f"Esquema efectivo no conforme: CURRENT_SCHEMA={identity[1]}, esperado={expected_schema}."
        )
    return identity


def statements(path: Path, ancestry: tuple[Path, ...] = ()):
    path = path.resolve()
    if path in ancestry:
        raise RuntimeError("Inclusion SQL circular: " + " -> ".join(str(item) for item in (*ancestry, path)))
    if not path.is_file():
        raise RuntimeError(f"No existe el script incluido: {path}")

    current: list[str] = []
    start = 0
    plsql = False
    leading_block_comment = False
    for line_no, raw in enumerate(path.read_text(encoding="utf-8-sig", errors="replace").splitlines(keepends=True), 1):
        if not current and leading_block_comment:
            if "*/" not in raw:
                continue
            raw = raw.split("*/", 1)[1]
            leading_block_comment = False
        if not current and raw.lstrip().startswith("/*"):
            remainder = raw.lstrip()[2:]
            if "*/" not in remainder:
                leading_block_comment = True
                continue
            raw = remainder.split("*/", 1)[1]
        stripped = raw.strip()
        if not current:
            include = INCLUDE_LINE.match(raw)
            if include:
                yield from statements((path.parent / include.group(1)).resolve(), (*ancestry, path))
                continue
            if not stripped or stripped.startswith("--") or IGNORED_SQLPLUS.match(raw):
                continue
            if FORBIDDEN_SQLPLUS.match(raw):
                raise RuntimeError(f"Comando SQL*Plus no permitido en {path}:{line_no}: {stripped}")
            start = line_no
            plsql = bool(PLSQL_START.match(raw))
            current.append(raw)
        else:
            current.append(raw)

        if plsql and stripped == "/":
            yield path, start, line_no, "".join(current[:-1]).strip()
            current = []
            plsql = False
        elif not plsql and stripped.endswith(";"):
            yield path, start, line_no, "".join(current).strip().rstrip(";").strip()
            current = []
    if current:
        raise RuntimeError(f"Sentencia sin terminador en {path}:{start}")
    if leading_block_comment:
        raise RuntimeError(f"Comentario sin terminador en {path}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Ejecuta SQL versionado en Oracle y se detiene ante el primer error.")
    parser.add_argument("sql_file", help="deploy.sql o script SQL versionado")
    parser.add_argument("--environment", choices=("test", "prod"), required=True)
    parser.add_argument("--timing-log", help="Log de hitos; no incluye credenciales ni SQL.")
    parser.add_argument("--expected-sha256", help="SHA-256 del SQL exacto que se autorizo ejecutar.")
    parser.add_argument("--source-repo", help="Checkout limpio situado en el commit candidato declarado.")
    parser.add_argument(
        "--expected-source-commit",
        help="Commit candidato exacto; en PRODUCCION debe coincidir tambien con origin/main.",
    )
    parser.add_argument("--expected-schema", default="DATA", help="Esquema efectivo obligatorio para DDL de codigo.")
    args = parser.parse_args()

    expected_schema = args.expected_schema.strip().strip('"').upper()
    if not ORACLE_IDENTIFIER.fullmatch(expected_schema):
        print(f"Nombre de esquema Oracle no valido: {args.expected_schema}", file=sys.stderr)
        return 2

    if importlib.util.find_spec("oracledb") is None:
        print("Modulo Python 'oracledb' no disponible.", file=sys.stderr)
        return 2
    load_local_env()
    prefix = "ZAIMELLA_ORACLE_PROD_" if args.environment == "prod" else "ZAIMELLA_ORACLE_"
    required = ("HOST", "PORT", "SID", "USER", "PASSWORD")
    values = {name: os.environ.get(prefix + name) for name in required}
    missing = [prefix + name for name, value in values.items() if not value]
    if missing:
        print(f"Faltan variables Oracle {args.environment.upper()}: " + ", ".join(missing), file=sys.stderr)
        return 2
    try:
        blocks = list(statements(Path(args.sql_file)))
    except RuntimeError as exc:
        print(str(exc), file=sys.stderr)
        return 2
    if not blocks:
        print("El script no contiene sentencias ejecutables.", file=sys.stderr)
        return 2

    sql_path = Path(args.sql_file).resolve()
    actual_hash = sha256_file(sql_path)
    if not args.expected_sha256:
        print(f"{args.environment.upper()} exige --expected-sha256 del SQL registrado en la tarea.", file=sys.stderr)
        return 2
    if args.expected_sha256 and actual_hash.lower() != args.expected_sha256.lower():
        print("El SHA-256 del SQL a ejecutar no coincide con el artefacto autorizado.", file=sys.stderr)
        return 2
    if bool(args.source_repo) != bool(args.expected_source_commit):
        print("Usa juntos --source-repo y --expected-source-commit.", file=sys.stderr)
        return 2
    if not args.source_repo:
        print(f"{args.environment.upper()} exige verificar --source-repo y --expected-source-commit.", file=sys.stderr)
        return 2
    try:
        verify_source_commit(Path(args.source_repo).resolve(), args.expected_source_commit, args.environment == "prod")
    except RuntimeError as exc:
        print(str(exc), file=sys.stderr)
        return 2

    import oracledb

    timing_log = Path(args.timing_log) if args.timing_log else None
    dsn = f"{values['HOST']}:{values['PORT']}/{values['SID']}"
    emit(f"PREFLIGHT_OK environment={args.environment} script={sql_path.name} sha256={actual_hash} blocks={len(blocks)}", timing_log)
    try:
        with oracledb.connect(user=values["USER"], password=values["PASSWORD"], dsn=dsn) as conn:
            with conn.cursor() as cur:
                cur.execute(f"alter session set current_schema={expected_schema}")
                user, schema, database = assert_current_schema(cur, expected_schema)
                emit(
                    f"SESSION_IDENTITY_OK environment={args.environment} session_user={user} current_schema={schema} database={database}",
                    timing_log,
                )
                for number, (source, start, end, sql) in enumerate(blocks, 1):
                    try:
                        code_ddl = CODE_DDL.match(sql)
                        if code_ddl:
                            assert_current_schema(cur, expected_schema)
                            explicit_owner = code_ddl.group(2)
                            if explicit_owner and explicit_owner.strip('"').upper() != expected_schema:
                                raise RuntimeError(
                                    f"DDL fuera del esquema objetivo: owner={explicit_owner}, esperado={expected_schema}."
                                )
                        cur.execute(sql)
                        if code_ddl:
                            object_type = re.sub(r"\s+", " ", code_ddl.group(1).upper())
                            object_name = code_ddl.group(3).strip('"').upper()
                            expected_type = "PACKAGE BODY" if object_type == "PACKAGE BODY" else object_type
                            cur.execute(
                                "select status from all_objects where owner = :owner and object_name = :name and object_type = :type",
                                owner=expected_schema, name=object_name, type=expected_type,
                            )
                            row = cur.fetchone()
                            if not row or row[0] != "VALID":
                                raise RuntimeError(
                                    f"El objeto {expected_schema}.{object_name} {expected_type} no quedo VALID en el esquema objetivo."
                                )
                        emit(f"DEPLOY_BLOCK_OK number={number} source={source.name} lines={start}-{end}", timing_log)
                    except Exception as exc:
                        conn.rollback()
                        emit(f"DEPLOY_BLOCK_ERROR number={number} source={source.name} lines={start}-{end}", timing_log)
                        print(f"Oracle no ejecuto el bloque {source}:{start}-{end}: {exc}", file=sys.stderr)
                        return 1
            conn.commit()
    except Exception as exc:
        print(f"No se pudo conectar o ejecutar en {args.environment.upper()}: {exc}", file=sys.stderr)
        return 1
    emit(f"DEPLOY_OK blocks={len(blocks)}", timing_log)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
