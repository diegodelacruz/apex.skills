from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path
import re
import socket
import sys
from typing import Iterable

import yaml


ROOT = Path(__file__).resolve().parent.parent
ERP_CONFIG = (
    ROOT / "references" / "erp-config"
    if (ROOT / "references" / "erp-config").exists()
    else ROOT / "desarrollador-apex" / "references" / "erp-config"
)

COMPANY_ENV_PREFIX = {
    "00003": "ZAIMELLA_HANA_PE",
    "00015": "ZAIMELLA_HANA_ABX",
}

SET_LINE_RE = re.compile(r'^\s*set\s+"(ZAIMELLA_(?:ORACLE|HANA)_[A-Z_]+)=(.*)"\s*$', re.IGNORECASE)
READ_SQL_RE = re.compile(r"^\s*(select|with)\b", re.IGNORECASE | re.DOTALL)
BLOCKED_SQL_RE = re.compile(
    r"\b(insert|update|delete|merge|create|alter|drop|truncate|grant|revoke|commit|rollback|execute|exec|begin|call)\b",
    re.IGNORECASE,
)


def load_cmd_env_file(path: Path) -> None:
    if not path.exists():
        return

    for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        match = SET_LINE_RE.match(line)
        if match:
            name = match.group(1).upper()
            value = match.group(2)
            if value and not value.strip().upper().startswith("COLOQUE_AQUI"):
                os.environ.setdefault(name, value)


def load_local_env() -> None:
    env_dir = Path(os.environ.get("ZAIMELLA_ENV_DIR") or Path.home() / ".zaimella")
    for path in (
        Path(os.environ["ZAIMELLA_ORACLE_CONFIG_PATH"])
        if os.environ.get("ZAIMELLA_ORACLE_CONFIG_PATH")
        else env_dir / "configurar_oracle_env.cmd",
        Path(os.environ["ZAIMELLA_ORACLE_LOCAL_CONFIG_PATH"])
        if os.environ.get("ZAIMELLA_ORACLE_LOCAL_CONFIG_PATH")
        else env_dir / "configurar_oracle_env.local.cmd",
    ):
        load_cmd_env_file(path)


def env_value(name: str, fallback: str | None = None) -> str | None:
    value = os.environ.get(name)
    if value and value.strip() and not value.strip().upper().startswith("COLOQUE_AQUI") and not value.startswith("<"):
        return value
    if fallback and str(fallback).strip() and not str(fallback).strip().upper().startswith("COLOQUE_AQUI") and not str(fallback).startswith("<"):
        return str(fallback)
    return None


def load_company_config(company_code: str) -> dict:
    candidates = sorted(ERP_CONFIG.glob(f"{company_code}-*.yaml"))
    if not candidates:
        raise FileNotFoundError(f"No existe configuracion ERP para compania {company_code}")
    with candidates[0].open("r", encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def schema_for_environment(company_code: str, hana: dict, environment: str | None, schema: str | None) -> str | None:
    if schema:
        return schema
    if not environment:
        return None
    prefix = COMPANY_ENV_PREFIX.get(company_code)
    env_key = f"{prefix}_{environment.upper()}_SCHEMA" if prefix else ""
    config_key = f"{environment.lower()}_schema"
    return env_value(env_key, hana.get(config_key))


def hana_config(company_code: str, args: argparse.Namespace) -> dict[str, str | None]:
    config = load_company_config(company_code)
    hana = config.get("hana_connection")
    if not hana:
        raise RuntimeError(f"La compania {company_code} no tiene conexion HANA directa configurada.")

    prefix = COMPANY_ENV_PREFIX.get(company_code)
    return {
        "host": args.host or (env_value(f"{prefix}_HOST", hana.get("host")) if prefix else env_value("", hana.get("host"))),
        "port": args.port or (env_value(f"{prefix}_PORT", str(hana.get("port"))) if prefix else env_value("", str(hana.get("port")))),
        "user": args.user or (env_value(f"{prefix}_USER", hana.get("user")) if prefix else env_value("", hana.get("user"))),
        "password": args.password or (env_value(f"{prefix}_PASSWORD", hana.get("password")) if prefix else env_value("", hana.get("password"))),
        "schema": schema_for_environment(company_code, hana, args.environment, args.schema),
        "prefix": prefix or f"ZAIMELLA_HANA_{company_code}",
    }


def assert_hana_config(config: dict[str, str | None]) -> int:
    missing = [
        f"{config['prefix']}_{key.upper()}"
        for key in ("host", "port", "user", "password")
        if not config.get(key)
    ]
    if missing:
        print("Faltan variables HANA: " + ", ".join(missing), file=sys.stderr)
        return 2
    return 0


def connect(config: dict[str, str | None], timeout: float):
    if importlib.util.find_spec("hdbcli") is None:
        print("Modulo Python 'hdbcli' no disponible.", file=sys.stderr)
        return None

    from hdbcli import dbapi

    host = str(config["host"])
    port = int(str(config["port"]))
    try:
        socket.create_connection((host, port), timeout=timeout).close()
    except OSError as exc:
        print(f"PUERTO HANA ERROR: {host}:{port} -> {exc}", file=sys.stderr)
        raise

    return dbapi.connect(
        address=host,
        port=port,
        user=str(config["user"]),
        password=str(config["password"]),
    )


def read_sql(args: argparse.Namespace) -> str:
    if args.sql and args.file:
        raise SystemExit("Usa --sql o --file, no ambos.")
    if args.sql:
        return args.sql.strip().rstrip(";")
    if args.file:
        return Path(args.file).read_text(encoding="utf-8", errors="ignore").strip().rstrip(";")
    raise SystemExit("Falta --sql o --file.")


def assert_read_sql(sql: str) -> int:
    if not READ_SQL_RE.search(sql):
        print("Solo se permiten consultas SELECT/WITH en este helper.", file=sys.stderr)
        return 3
    if BLOCKED_SQL_RE.search(sql):
        print("SQL bloqueado: contiene DML, DDL, PL/SQL o control transaccional.", file=sys.stderr)
        return 3
    return 0


def limited_sql(sql: str, max_rows: int) -> str:
    if max_rows < 1:
        raise SystemExit("--max-rows debe ser mayor a cero.")
    return f"SELECT * FROM ({sql}) AS CODX_Q LIMIT {max_rows}"


def print_rows(columns: list[str], rows: list[tuple], output: str) -> None:
    if output == "json":
        print(json.dumps([dict(zip(columns, row)) for row in rows], ensure_ascii=True, default=str, indent=2))
        return
    print("\t".join(columns))
    for row in rows:
        print("\t".join("" if value is None else str(value) for value in row))


def run_query(args: argparse.Namespace) -> int:
    sql = read_sql(args)
    sql_error = assert_read_sql(sql)
    if sql_error:
        return sql_error

    config = hana_config(args.company_code, args)
    config_error = assert_hana_config(config)
    if config_error:
        return config_error

    try:
        conn = connect(config, args.timeout)
    except OSError:
        return 4
    if conn is None:
        return 5

    try:
        cursor = conn.cursor()
        if config.get("schema"):
            cursor.execute(f'SET SCHEMA "{config["schema"]}"')
        cursor.execute("SELECT CURRENT_SCHEMA, CURRENT_USER FROM DUMMY")
        schema, user = cursor.fetchone()
        print(f"company_code={args.company_code}", file=sys.stderr)
        print(f"environment={args.environment or ''}", file=sys.stderr)
        print(f"schema={schema}", file=sys.stderr)
        print(f"user={user}", file=sys.stderr)
        cursor.execute(limited_sql(sql, args.max_rows))
        columns = [desc[0] for desc in cursor.description]
        rows = cursor.fetchall()
        print_rows(columns, rows, args.output)
        return 0
    finally:
        conn.close()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Ejecuta consultas SELECT/WITH HANA de forma controlada.")
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("company_code", help="Codigo de compania, por ejemplo 00003 o 00015")
    common.add_argument("--environment", choices=("test", "prod"))
    common.add_argument("--schema", help="Esquema HANA explicito si no aplica ambiente.")
    common.add_argument("--sql")
    common.add_argument("--file")
    common.add_argument("--host")
    common.add_argument("--port")
    common.add_argument("--user")
    common.add_argument("--password")
    common.add_argument("--timeout", type=float, default=5.0)

    sub = parser.add_subparsers(dest="command", required=True)
    query_parser = sub.add_parser("query", parents=[common], help="Ejecuta SELECT/WITH con limite de filas.")
    query_parser.add_argument("--max-rows", "--limit", dest="max_rows", type=int, default=100)
    query_parser.add_argument("--output", choices=("table", "json"), default="table")
    query_parser.set_defaults(func=run_query)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    load_local_env()
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return args.func(args)
    except Exception as exc:  # pragma: no cover
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
