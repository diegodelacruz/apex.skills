from __future__ import annotations

import argparse
from datetime import datetime
import os
import sys
from pathlib import Path
import re

import oracledb


SET_LINE_RE = re.compile(r'^\s*set\s+"(ZAIMELLA_(?:ORACLE|HANA)_[A-Z_]+)=(.*)"\s*$', re.IGNORECASE)
WORKSPACE_ID_RE = re.compile(r"\bp_default_workspace_id\s*=>\s*(\d+)", re.IGNORECASE)


def parse_cmd_env_file(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.exists():
        return values
    for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        match = SET_LINE_RE.match(line)
        if match:
            values[match.group(1).upper()] = match.group(2)
    return values


def load_local_env() -> None:
    env_dir = Path(os.environ.get("ZAIMELLA_ENV_DIR") or Path.home() / ".zaimella")
    paths = (
        Path(os.environ["ZAIMELLA_ORACLE_CONFIG_PATH"])
        if os.environ.get("ZAIMELLA_ORACLE_CONFIG_PATH")
        else env_dir / "configurar_oracle_env.cmd",
        Path(os.environ["ZAIMELLA_ORACLE_LOCAL_CONFIG_PATH"])
        if os.environ.get("ZAIMELLA_ORACLE_LOCAL_CONFIG_PATH")
        else env_dir / "configurar_oracle_env.local.cmd",
    )
    values: dict[str, str] = {}
    for path in paths:
        values.update(parse_cmd_env_file(path))
    for name, value in values.items():
        if not is_placeholder(value):
            os.environ.setdefault(name, value)


def is_placeholder(value: str | None) -> bool:
    return not value or value.strip().upper().startswith("COLOQUE_AQUI") or value.strip().startswith("<")


def resolve_connection(args: argparse.Namespace) -> None:
    prefix = "ZAIMELLA_ORACLE_PROD_" if args.environment in {"prod", "production"} else "ZAIMELLA_ORACLE_"
    args.host = args.host or os.environ.get(f"{prefix}HOST")
    args.port = args.port or os.environ.get(f"{prefix}PORT")
    args.sid = args.sid or os.environ.get(f"{prefix}SID")
    args.user = args.user or os.environ.get(f"{prefix}USER")
    args.password = args.password or os.environ.get(f"{prefix}PASSWORD")
    missing = [
        name
        for name, value in (
            (f"{prefix}HOST", args.host),
            (f"{prefix}PORT", args.port),
            (f"{prefix}SID", args.sid),
            (f"{prefix}USER", args.user),
            (f"{prefix}PASSWORD", args.password),
        )
        if is_placeholder(value)
    ]
    if missing:
        raise RuntimeError("Faltan variables Oracle: " + ", ".join(missing))
    if args.environment in {"prod", "production"} and "TEST" in args.sid.upper():
        raise RuntimeError(f"El SID no parece produccion: {args.sid}")


def iter_sqlplus_blocks(path: Path):
    current: list[str] = []
    start_line: int | None = None
    with path.open("r", encoding="utf-8-sig", errors="replace") as f:
        for line_no, raw in enumerate(f, 1):
            stripped = raw.strip()

            if not current:
                if not stripped:
                    continue
                if stripped.lower().startswith(("prompt ", "set ", "whenever ")):
                    continue
                if stripped.startswith("--"):
                    continue

                start_line = line_no
                current.append(raw)
                continue

            if stripped == "/":
                yield start_line or line_no, line_no, "".join(current)
                current = []
                start_line = None
                continue

            current.append(raw)

    if current:
        yield start_line or 1, line_no, "".join(current)


def workspace_id_from_export(path: Path) -> int:
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    match = WORKSPACE_ID_RE.search(text)
    if not match:
        raise RuntimeError(
            "El export APEX no declara p_default_workspace_id; no se puede ejecutar un import seguro."
        )
    return int(match.group(1))


def latest_apex_schema(cur) -> str:
    cur.execute(
        """
        select max(username)
        from all_users
        where regexp_like(username, '^APEX_[0-9]+$')
        """
    )
    row = cur.fetchone()
    if not row or not row[0]:
        raise RuntimeError("No se encontro esquema APEX activo.")
    return str(row[0])


def emit_timing(message: str, log_path: Path | None = None) -> None:
    line = f"{datetime.now().astimezone().isoformat(timespec='seconds')} {message}"
    print(line)
    if log_path:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open("a", encoding="utf-8", newline="\n") as log:
            log.write(line + "\n")


def main() -> int:
    load_local_env()
    parser = argparse.ArgumentParser(description="Importa SQL/APEX usando configuracion Oracle por ambiente.")
    parser.add_argument("sql_file")
    parser.add_argument(
        "--environment",
        choices=("test", "prod", "production"),
        default="test",
        help="Usa ZAIMELLA_ORACLE_* para test o ZAIMELLA_ORACLE_PROD_* para produccion.",
    )
    parser.add_argument("--host")
    parser.add_argument("--port")
    parser.add_argument("--sid")
    parser.add_argument("--user")
    parser.add_argument("--password")
    parser.add_argument(
        "--timing-log",
        help="Archivo opcional de hitos de tiempo del import; no guardar credenciales en este archivo.",
    )
    args = parser.parse_args()

    try:
        resolve_connection(args)
    except RuntimeError as exc:
        print(str(exc), file=sys.stderr)
        return 2

    sql_path = Path(args.sql_file)
    if not sql_path.is_file():
        print(f"No existe el export APEX: {sql_path}", file=sys.stderr)
        return 2
    log_path = Path(args.timing_log) if args.timing_log else None
    try:
        workspace_id = workspace_id_from_export(sql_path)
    except RuntimeError as exc:
        print(str(exc), file=sys.stderr)
        return 2

    dsn = f"{args.host}:{args.port}/{args.sid}"

    executed = 0
    emit_timing(f"PREFLIGHT_OK export={sql_path.name} workspace_id={workspace_id}", log_path)
    with oracledb.connect(user=args.user, password=args.password, dsn=dsn) as conn:
        with conn.cursor() as cur:
            try:
                apex_schema = latest_apex_schema(cur)
                cur.execute(
                    f"begin {apex_schema}.wwv_flow_security.set_g_security_group_id(:workspace_id); end;",
                    workspace_id=workspace_id,
                )
                emit_timing(f"WORKSPACE_OK schema={apex_schema} workspace_id={workspace_id}", log_path)
            except Exception as exc:
                conn.rollback()
                print(f"No se pudo fijar el workspace APEX {workspace_id}: {exc}", file=sys.stderr)
                return 1
            for start, end, block in iter_sqlplus_blocks(sql_path):
                try:
                    cur.execute(block)
                    executed += 1
                    emit_timing(f"IMPORT_BLOCK_OK number={executed} lines={start}-{end}", log_path)
                except Exception as exc:
                    conn.rollback()
                    emit_timing(f"IMPORT_BLOCK_ERROR number={executed + 1} lines={start}-{end}", log_path)
                    print(str(exc), file=sys.stderr)
                    preview = "\n".join(block.splitlines()[:20])
                    print(preview, file=sys.stderr)
                    return 1
        conn.commit()

    emit_timing(f"IMPORT_OK blocks={executed}", log_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
