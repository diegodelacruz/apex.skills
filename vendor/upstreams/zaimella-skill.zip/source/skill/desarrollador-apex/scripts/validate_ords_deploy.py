"""Audita fuentes ORDS para impedir despliegues destructivos o con secretos."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import sys


DELETE_MODULE_RE = re.compile(r"\bords\s*\.\s*delete_module\b", re.IGNORECASE)
DEFINE_MODULE_RE = re.compile(r"\bords\s*\.\s*define_module\b", re.IGNORECASE)
DEFINE_TEMPLATE_RE = re.compile(r"\bords\s*\.\s*define_template\b", re.IGNORECASE)
DEFINE_HANDLER_RE = re.compile(r"\bords\s*\.\s*define_handler\b", re.IGNORECASE)
DEFINE_PRIVILEGE_RE = re.compile(r"\bords\s*\.\s*(?:define_privilege|set_module_privilege)\b", re.IGNORECASE)
OAUTH_IMPORT_RE = re.compile(r"\boauth\s*\.\s*import_client\b", re.IGNORECASE)
OAUTH_CREATE_RE = re.compile(r"\boauth\s*\.\s*create_client\b", re.IGNORECASE)
CLIENT_EXISTENCE_RE = re.compile(r"\buser_ords_clients\b", re.IGNORECASE)
AUTHID_DEFINER_RE = re.compile(r"\bauthid\s+definer\b", re.IGNORECASE)
PACKAGE_DDL_RE = re.compile(r"\bcreate\s+or\s+replace\s+package(?!\s+body)\b", re.IGNORECASE)
URL_RE = re.compile(r"https?://", re.IGNORECASE)
SECRET_LITERAL_RE = re.compile(
    r"\bp_client_(?:id|secret)\s*=>\s*'(?!')([^']+)'|\bclient_(?:id|secret)\s*[:=]\s*'(?!')([^']+)'",
    re.IGNORECASE,
)


def sql_files(paths: list[str]) -> list[Path]:
    result: list[Path] = []
    for raw in paths:
        path = Path(raw)
        if path.is_dir():
            result.extend(sorted(path.rglob("*.sql")))
        elif path.is_file():
            result.append(path)
        else:
            raise FileNotFoundError(f"No existe la ruta: {path}")
    return list(dict.fromkeys(item.resolve() for item in result))


def audit_file(path: Path, allow_full_replace: bool) -> list[dict[str, str]]:
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    findings: list[dict[str, str]] = []

    def add(code: str, message: str, severity: str = "ERROR") -> None:
        findings.append({"file": str(path), "severity": severity, "code": code, "message": message})

    if DELETE_MODULE_RE.search(text) and not allow_full_replace:
        add("ORDS_DELETE_MODULE_FORBIDDEN", "ORDS.DELETE_MODULE requiere reemplazo total autorizado y --allow-full-replace.")
    if URL_RE.search(text):
        add("ORDS_ABSOLUTE_URL", "La fuente ORDS no debe contener URLs absolutas de ambiente.")
    if SECRET_LITERAL_RE.search(text):
        add("ORDS_SECRET_LITERAL", "Se detecto un secreto OAuth literal en SQL.")
    if OAUTH_CREATE_RE.search(text):
        add("ORDS_RANDOM_OAUTH_CREATE", "Usa OAUTH.IMPORT_CLIENT con credenciales generadas y cifradas localmente.")
    if OAUTH_IMPORT_RE.search(text) and not CLIENT_EXISTENCE_RE.search(text):
        add("ORDS_OAUTH_NOT_IDEMPOTENT", "OAUTH.IMPORT_CLIENT debe estar protegido por una consulta a USER_ORDS_CLIENTS.")
    if PACKAGE_DDL_RE.search(text) and (DEFINE_MODULE_RE.search(text) or OAUTH_IMPORT_RE.search(text)) and not AUTHID_DEFINER_RE.search(text):
        add("ORDS_PACKAGE_NOT_DEFINER", "El paquete que administra ORDS/OAuth debe declarar AUTHID DEFINER.")
    if DEFINE_MODULE_RE.search(text):
        if not DEFINE_TEMPLATE_RE.search(text):
            add("ORDS_TEMPLATE_MISSING", "El modulo no define ningun template.")
        if not DEFINE_HANDLER_RE.search(text):
            add("ORDS_HANDLER_MISSING", "El modulo no define ningun handler.")
        if not DEFINE_PRIVILEGE_RE.search(text):
            add("ORDS_PRIVILEGE_MISSING", "El modulo no queda asociado a un privilegio ORDS.")
    return findings


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("paths", nargs="+", help="Archivos o carpetas SQL a auditar.")
    parser.add_argument("--allow-full-replace", action="store_true", help="Autoriza DELETE_MODULE solo para un reemplazo total revisado.")
    parser.add_argument("--json", action="store_true", help="Emite resultado JSON.")
    args = parser.parse_args()

    try:
        files = sql_files(args.paths)
    except FileNotFoundError as exc:
        print(str(exc), file=sys.stderr)
        return 2
    if not files:
        print("No se encontraron archivos SQL.", file=sys.stderr)
        return 2

    findings = [item for path in files for item in audit_file(path, args.allow_full_replace)]
    result = {"status": "FAIL" if findings else "PASS", "files": len(files), "findings": findings}
    if args.json:
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        for item in findings:
            print(f"{item['severity']} {item['code']} {item['file']}: {item['message']}")
        print("ORDS_STATIC_AUDIT_PASS" if not findings else f"ORDS_STATIC_AUDIT_FAIL findings={len(findings)}")
    return 1 if findings else 0


if __name__ == "__main__":
    raise SystemExit(main())
