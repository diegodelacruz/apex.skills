param(
  [string]$ProjectRoot = ".",
  [string]$ToolsRoot = "$env:USERPROFILE\.zaimella\qa-tools\playwright",
  [switch]$Force
)

$ErrorActionPreference = "Stop"

function Resolve-FullPath {
  param([string]$Path)
  $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($Path)
}

function Test-Command {
  param([string]$Name)
  $null -ne (Get-Command $Name -ErrorAction SilentlyContinue)
}

function Update-PathFromMachineEnvironment {
  $machinePath = [Environment]::GetEnvironmentVariable("Path", "Machine")
  $userPath = [Environment]::GetEnvironmentVariable("Path", "User")
  $env:Path = @($machinePath, $userPath) -join ";"
}

function Install-NodeIfMissing {
  if ((Test-Command "node") -and (Test-Command "npm")) {
    return
  }

  if (-not (Test-Command "winget")) {
    throw "Node.js/npm no estan disponibles y winget no esta disponible para instalarlos automaticamente."
  }

  Write-Output "Node.js/npm no estan disponibles. Instalando Node.js LTS con winget una sola vez..."
  winget install --id OpenJS.NodeJS.LTS --silent --accept-package-agreements --accept-source-agreements
  Update-PathFromMachineEnvironment

  if (-not (Test-Command "node") -or -not (Test-Command "npm")) {
    throw "Node.js/npm fueron instalados o solicitados, pero aun no responden en PATH. Abre una nueva terminal o revisa la instalacion."
  }
}

Install-NodeIfMissing

$ToolsRoot = Resolve-FullPath $ToolsRoot
$ProjectRoot = Resolve-FullPath $ProjectRoot
$playwrightCmd = Join-Path $ToolsRoot "node_modules\.bin\playwright.cmd"
$playwrightRunner = Join-Path $ToolsRoot "run-playwright.ps1"
$playwrightConfig = Join-Path $ToolsRoot "playwright.config.js"
$packageJson = Join-Path $ToolsRoot "package.json"
$toolsMd = Join-Path $ToolsRoot "QA_TOOLS.md"
$projectLogDir = Join-Path $ProjectRoot "docs\logs"
$projectToolsMd = Join-Path $projectLogDir "qa-tools.md"

New-Item -ItemType Directory -Force -Path $ToolsRoot | Out-Null

if (-not (Test-Path $packageJson)) {
  $packageContent = @"
{
  "name": "zaimella-qa-tools",
  "private": true,
  "description": "Herramientas QA reutilizables para Codex en Zaimella",
  "devDependencies": {}
}
"@
  Set-Content -LiteralPath $packageJson -Value $packageContent -Encoding UTF8
}

$needsInstall = $Force -or -not (Test-Path $playwrightCmd)
if ($needsInstall) {
  Push-Location $ToolsRoot
  try {
    npm install @playwright/test
    & $playwrightCmd install chromium
  }
  finally {
    Pop-Location
  }
}

$nodeVersion = (& node --version) -join " "
$npmVersion = (& npm --version) -join " "
$playwrightVersion = (& $playwrightCmd --version) -join " "
$now = Get-Date -Format "yyyy-MM-dd HH:mm:ss zzz"

$runnerContent = @'
param(
  [Parameter(ValueFromRemainingArguments = $true)]
  [string[]]$PlaywrightArgs
)

$ErrorActionPreference = "Stop"
$toolsRoot = $PSScriptRoot
$playwrightCmd = Join-Path $toolsRoot "node_modules\.bin\playwright.cmd"
$playwrightConfig = Join-Path $toolsRoot "playwright.config.js"
$env:NODE_PATH = Join-Path $toolsRoot "node_modules"
$env:PW_TEST_DIR = (Get-Location).Path

if (-not (Test-Path -LiteralPath $playwrightCmd)) {
  throw "Playwright CLI no existe en $playwrightCmd. Ejecuta ensure-playwright-env.ps1 para reparar la instalacion reutilizable."
}

$finalArgs = @()
$hasConfig = $false
foreach ($arg in $PlaywrightArgs) {
  if ($arg -eq "--config" -or $arg -like "--config=*") {
    $hasConfig = $true
  }
}

if ($PlaywrightArgs.Count -gt 0 -and $PlaywrightArgs[0] -eq "test" -and -not $hasConfig) {
  $finalArgs += "test"
  $finalArgs += "--config"
  $finalArgs += $playwrightConfig
  if ($PlaywrightArgs.Count -gt 1) {
    $finalArgs += $PlaywrightArgs[1..($PlaywrightArgs.Count - 1)]
  }
}
else {
  $finalArgs = $PlaywrightArgs
}

& $playwrightCmd @finalArgs
exit $LASTEXITCODE
'@

Set-Content -LiteralPath $playwrightRunner -Value $runnerContent -Encoding UTF8

$configContent = @'
const { defineConfig, devices } = require('@playwright/test');

module.exports = defineConfig({
  testDir: process.env.PW_TEST_DIR || process.cwd(),
  timeout: 120000,
  expect: {
    timeout: 10000,
  },
  reporter: [['list']],
  use: {
    browserName: 'chromium',
    screenshot: 'only-on-failure',
    trace: 'retain-on-failure',
    video: 'retain-on-failure',
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],
});
'@

Set-Content -LiteralPath $playwrightConfig -Value $configContent -Encoding UTF8

$md = @(
  "# Herramientas QA APEX"
  ""
  "Generado: $now"
  ""
  "## Instalacion reutilizable"
  ""
  "- Tools root: $ToolsRoot"
  "- Node: $nodeVersion"
  "- npm: $npmVersion"
  "- Playwright: $playwrightVersion"
  "- Playwright CLI: $playwrightCmd"
  "- Playwright runner: $playwrightRunner"
  "- Playwright config: $playwrightConfig"
  "- NODE_PATH QA: $(Join-Path $ToolsRoot "node_modules")"
  "- Navegador requerido: Chromium"
  ""
  "## Uso"
  ""
  "Ejecutar Playwright desde esta instalacion, sin instalar dependencias dentro del proyecto APEX:"
  ""
  '```powershell'
  "powershell -ExecutionPolicy Bypass -File `"$playwrightRunner`" --version"
  '```'
  ""
  "Para pruebas o scripts temporales, usar el runner anterior. No usar npx ni npm exec como camino normal."
  ""
  '```powershell'
  "powershell -ExecutionPolicy Bypass -File `"$playwrightRunner`" test `"<ruta-absoluta-o-relativa-al-spec>`" --project=chromium"
  '```'
  ""
  "## Regla"
  ""
  "No reinstalar en cada proyecto. Reusar esta ruta mientras el runner anterior responda."
  "No resolver caches de npx ni ajustar NODE_PATH manualmente desde cada proyecto; el runner ya fija el contexto de modulos."
  "Si falla, ejecutar una sola vez:"
  ""
  '```powershell'
  ".\scripts\ensure-playwright-env.ps1 -ProjectRoot ."
  '```'
) -join [Environment]::NewLine

Set-Content -LiteralPath $toolsMd -Value $md -Encoding UTF8

if (Test-Path $ProjectRoot) {
  New-Item -ItemType Directory -Force -Path $projectLogDir | Out-Null
  Set-Content -LiteralPath $projectToolsMd -Value $md -Encoding UTF8
}

Write-Output "TOOLS_ROOT=$ToolsRoot"
Write-Output "PLAYWRIGHT_CLI=$playwrightCmd"
Write-Output "PLAYWRIGHT_RUNNER=$playwrightRunner"
Write-Output "TOOLS_MD=$toolsMd"
Write-Output "PROJECT_TOOLS_MD=$projectToolsMd"
