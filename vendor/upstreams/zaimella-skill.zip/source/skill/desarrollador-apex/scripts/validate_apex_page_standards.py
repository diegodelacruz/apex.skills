#!/usr/bin/env python3
"""Auditoria estatica conservadora para exports de paginas Oracle APEX."""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import asdict, dataclass
from pathlib import Path


DELETE_CONFIRMATION = "¿Está seguro de eliminar el registro?"
DELETE_TERMS = re.compile(
    r"(?:^|[_\s-])(ELIMINA(?:R|CI[OÓ]N)?|BORRA(?:R|DO)?|RETIRAR|DESVINCULAR|SUPRIMIR|DELETE|REMOVE)(?:$|[_\s-])",
    re.IGNORECASE,
)
# COUNT(*) no se considera proyeccion comodin y esta permitido para contar filas.
SELECT_STAR = re.compile(
    r"\bselect\s+(?:(?:/\*.*?\*/|--[^\n]*\n)\s*)*(?:distinct\s+)?(?:[a-z][a-z0-9_$#]*\s*\.\s*)?\*",
    re.IGNORECASE | re.DOTALL,
)


@dataclass(frozen=True)
class Finding:
    severity: str
    rule: str
    file: str
    line: int
    message: str


def line_number(text: str, offset: int) -> int:
    return text.count("\n", 0, offset) + 1


def blocks(text: str, call: str):
    pattern = re.compile(rf"{re.escape(call)}\s*\(", re.IGNORECASE)
    starts = list(pattern.finditer(text))
    for index, match in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else len(text)
        yield match.start(), text[match.start():end]


def value(block: str, parameter: str) -> str | None:
    match = re.search(
        rf"{re.escape(parameter)}\s*=>\s*'((?:''|[^'])*)'",
        block,
        re.IGNORECASE,
    )
    return match.group(1).replace("''", "'") if match else None


def oracle_text_value(block: str, parameter: str) -> str | None:
    """Lee un literal APEX normal o unistr('...') y decodifica escapes Unicode."""
    match = re.search(
        rf"{re.escape(parameter)}\s*=>\s*(?:unistr\s*\(\s*)?'((?:''|[^'])*)'",
        block,
        re.IGNORECASE,
    )
    if not match:
        return None
    raw = match.group(1).replace("''", "'")
    return re.sub(
        r"\\([0-9A-Fa-f]{4})",
        lambda unicode_match: chr(int(unicode_match.group(1), 16)),
        raw,
    )


def id_value(block: str, parameter: str) -> str | None:
    match = re.search(
        rf"{re.escape(parameter)}\s*=>\s*wwv_flow_imp\.id\s*\(\s*([0-9]+)\s*\)",
        block,
        re.IGNORECASE,
    )
    return match.group(1) if match else None


def audit(path: Path) -> list[Finding]:
    text = path.read_text(encoding="utf-8", errors="replace")
    findings: list[Finding] = []

    page_match = re.search(r"wwv_flow_imp_page.create_page\s*\(", text, re.IGNORECASE)
    page_name = ""
    page_mode = "NORMAL"
    is_dialog = False
    if page_match:
        page_block_end = text.find("wwv_flow_imp_page.create_page_plug", page_match.start())
        page_block = text[page_match.start():page_block_end if page_block_end >= 0 else len(text)]
        page_name = value(page_block, "p_name") or ""
        page_mode = (value(page_block, "p_page_mode") or "NORMAL").upper()
        is_dialog = page_mode in {"MODAL", "NON_MODAL"}

    def add(severity: str, rule: str, offset: int, message: str) -> None:
        findings.append(
            Finding(severity, rule, str(path), line_number(text, offset), message)
        )

    for match in SELECT_STAR.finditer(text):
        add(
            "ERROR",
            "APEX-SQL-001",
            match.start(),
            "No usar SELECT * ni alias.* en fuentes SQL APEX; declarar solo las columnas consumidas. COUNT(*) es una agregacion permitida.",
        )

    destructive_offsets: list[int] = []

    for match in re.finditer(r"NATIVE_SQL_REPORT", text, re.IGNORECASE):
        add("ERROR", "APEX-REPORT-001", match.start(),
            "Classic/SQL Report no permitido; usar Interactive Report para consultas o listados.")

    for offset, block in blocks(text, "wwv_flow_imp_page.create_page_button"):
        name = (value(block, "p_button_name") or "").upper()
        alignment = (value(block, "p_button_alignment") or "").upper()
        position = (value(block, "p_button_position") or "").upper()
        icon_css = (value(block, "p_icon_css_classes") or "").strip()
        image_alt = (value(block, "p_button_image_alt") or "").strip()
        if DELETE_TERMS.search(name) or DELETE_TERMS.search(image_alt):
            destructive_offsets.append(offset)
        if not image_alt:
            add("ERROR", "APEX-ACTION-003", offset,
                f"El boton {name or '<SIN_NOMBRE>'} debe tener una etiqueta accesible descriptiva.")
        if re.search(r"(^|_)(ATRAS|VOLVER|REGRESAR|RETORNAR)($|_)", name):
            if alignment != "LEFT":
                add("ERROR", "APEX-ACTION-001", offset,
                    f"El boton de retorno {name or '<SIN_NOMBRE>'} debe alinearse a la izquierda.")
        if not is_dialog and not icon_css:
            add("ERROR", "APEX-ACTION-004", offset,
                f"El boton personalizado {name or '<SIN_NOMBRE>'} de una pagina normal debe definir Icon CSS Classes y mostrarse como icono.")
        if is_dialog and position == "BELOW_BOX":
            if icon_css:
                add("ERROR", "APEX-DIALOG-002", offset,
                    f"El boton final {name or '<SIN_NOMBRE>'} del dialogo debe usar texto visible sin Icon CSS Classes.")
            if alignment != "RIGHT":
                add("ERROR", "APEX-DIALOG-003", offset,
                    f"El boton final {name or '<SIN_NOMBRE>'} del dialogo debe alinearse a la derecha.")
        if is_dialog and position != "BELOW_BOX" and not icon_css:
            add("ERROR", "APEX-DIALOG-004", offset,
                f"El boton auxiliar {name or '<SIN_NOMBRE>'} del dialogo debe mostrarse como icono o trasladarse a la region final.")

    for match in re.finditer(
        r"<a\b(?=[^>]*\bt-Button\b)[^>]*>\s*([^<]*[A-Za-zÁÉÍÓÚÑáéíóúñ][^<]*)\s*</a>",
        text,
        re.IGNORECASE,
    ):
        add("ERROR", "APEX-TABLE-001", match.start(),
            "Una accion personalizada renderizada como t-Button no debe mostrar texto; usar icono con etiqueta accesible.")

    for match in re.finditer(r"<a\b(?=[^>]*\bt-Button\b)[^>]*>", text, re.IGNORECASE):
        anchor = match.group(0)
        if not re.search(r"\b(?:title|aria-label)\s*=", anchor, re.IGNORECASE):
            add("ERROR", "APEX-TABLE-002", match.start(),
                "La accion personalizada de tabla debe definir title o aria-label accesible.")

    plug_records: dict[str, dict[str, str | None]] = {}
    report_plugs: set[str] = set()
    for offset, block in blocks(text, "wwv_flow_imp_page.create_page_plug"):
        plug_id = id_value(block, "p_id")
        source_type = (value(block, "p_plug_source_type") or "").upper()
        if plug_id:
            plug_records[plug_id] = {
                "parent": id_value(block, "p_parent_plug_id"),
                "source_type": source_type,
            }
            if source_type in {"NATIVE_IR", "NATIVE_IG"}:
                report_plugs.add(plug_id)
        if source_type in {"NATIVE_IR", "NATIVE_IG"}:
            header = value(block, "p_plug_header")
            if header and header.strip():
                add("ERROR", "APEX-TABLE-003", offset,
                    "La region de tabla debe usar su nombre funcional como titulo y mantener Header Text vacio.")

    visible_item_plugs: set[str] = set()
    for _, block in blocks(text, "wwv_flow_imp_page.create_page_item"):
        display_as = (value(block, "p_display_as") or "").upper()
        plug_id = id_value(block, "p_item_plug_id")
        if plug_id and display_as != "NATIVE_HIDDEN":
            visible_item_plugs.add(plug_id)

        if display_as == "NATIVE_SELECT_LIST":
            lov = value(block, "p_lov") or ""
            if re.search(r"\bselect\b.+\bfrom\b", lov, re.IGNORECASE | re.DOTALL):
                add("REVIEW", "APEX-LOV-001", text.find(block),
                    "Select List alimentado por SQL: demostrar que el catalogo es pequeno, cerrado y de bajo crecimiento; de lo contrario usar Popup LOV o Modal LOV.")
                if re.search(
                    r"\bid_(?:persona|cliente|proveedor|empleado|producto|articulo|documento|contrato)\b",
                    lov,
                    re.IGNORECASE,
                ):
                    add("ERROR", "APEX-LOV-002", text.find(block),
                        "No usar Select List para un maestro o catalogo transaccional que puede crecer; usar Popup LOV o Modal LOV.")

    def ancestors(plug_id: str) -> set[str]:
        result: set[str] = set()
        current: str | None = plug_id
        while current and current not in result:
            result.add(current)
            record = plug_records.get(current)
            current = record.get("parent") if record else None
        return result

    if not is_dialog and visible_item_plugs and report_plugs:
        content_plugs = visible_item_plugs | report_plugs
        ancestry = [ancestors(plug_id) for plug_id in content_plugs]
        common_ancestors = set.intersection(*ancestry) if ancestry else set()
        if not common_ancestors:
            add("ERROR", "APEX-FORM-001", page_match.start() if page_match else 0,
                "Los items y tablas de Content Body deben compartir una region padre de formulario verificable.")

    for match in re.finditer(
        r"nvl\s*\(\s*:G_COMPANIA\s*,\s*'{1,2}[^']+'{1,2}\s*\)", text, re.IGNORECASE
    ):
        add("ERROR", "APEX-COMPANY-001", match.start(),
            "No usar una compania literal como fallback de :G_COMPANIA.")

    for offset, block in blocks(text, "wwv_flow_imp_page.create_page_process"):
        process_name = value(block, "p_process_name") or "<SIN_NOMBRE>"
        if DELETE_TERMS.search(process_name):
            destructive_offsets.append(offset)
        sql_pos = re.search(r"p_process_sql_clob\s*=>", block, re.IGNORECASE)
        if sql_pos and re.search(r"\b(insert\s+into|update\s+|delete\s+from)\b", block[sql_pos.start():], re.IGNORECASE):
            add("ERROR", "APEX-DML-001", offset + sql_pos.start(),
                f"El proceso {process_name} contiene DML directo; delegar la transaccion a un paquete.")

    for match in re.finditer(
        r"<(?:a|button)\b[^>]*(?:title|aria-label)\s*=\s*['\"][^'\"]*(?:elimina(?:r|ci[oó]n)?|borrar|retirar|desvincular|suprimir|delete|remove)[^'\"]*['\"][^>]*>",
        text,
        re.IGNORECASE,
    ):
        destructive_offsets.append(match.start())

    for match in re.finditer(
        r"<(?:a|button)\b[^>]*>(?:(?!</(?:a|button)>).){0,1000}(?:elimina(?:r|ci[oó]n)?|borrar|retirar|desvincular|suprimir|delete|remove)",
        text,
        re.IGNORECASE | re.DOTALL,
    ):
        destructive_offsets.append(match.start())

    has_delete_confirmation = any(
        (value(block, "p_action") or "").upper() == "NATIVE_CONFIRM"
        and oracle_text_value(block, "p_attribute_01") == DELETE_CONFIRMATION
        for _, block in blocks(text, "wwv_flow_imp_page.create_page_da_action")
    )
    if not has_delete_confirmation:
        has_delete_confirmation = any(
            oracle_text_value(text[match.start():match.start() + 1000], "p_confirm_message")
            == DELETE_CONFIRMATION
            for match in re.finditer(r"p_confirm_message\s*=>", text, re.IGNORECASE)
        )
    if not has_delete_confirmation:
        decoded_text = re.sub(
            r"\\([0-9A-Fa-f]{4})",
            lambda unicode_match: chr(int(unicode_match.group(1), 16)),
            text,
        ).replace("''", "'")
        has_delete_confirmation = bool(re.search(
            rf"apex\.message\.confirm\s*\(\s*'{re.escape(DELETE_CONFIRMATION)}'",
            decoded_text,
            re.IGNORECASE,
        ))
    if destructive_offsets and not has_delete_confirmation:
        add(
            "ERROR",
            "APEX-DELETE-001",
            min(destructive_offsets),
            f"Toda eliminacion iniciada por el usuario debe confirmar antes de ejecutarse con el mensaje exacto '{DELETE_CONFIRMATION}'.",
        )

    if page_match:
        if is_dialog and not page_name.upper().startswith("DLG"):
            add("ERROR", "APEX-DIALOG-001", page_match.start(),
                f"La pagina de dialogo '{page_name or '<SIN_NOMBRE>'}' debe iniciar con Dlg.")
        if not is_dialog:
            if not re.search(r"p_plug_source_type\s*=>\s*'NATIVE_BREADCRUMB'", text, re.IGNORECASE):
                add("ERROR", "APEX-PAGE-001", page_match.start(),
                    "La pagina normal no contiene breadcrumb corporativo.")
            if not re.search(r"t-BreadcrumbRegion--useBreadcrumbTitle", text, re.IGNORECASE):
                add("ERROR", "APEX-PAGE-002", page_match.start(),
                    "La pagina normal no usa t-BreadcrumbRegion--useBreadcrumbTitle.")

    action_bars = len(re.findall(
        r"p_plug_name\s*=>\s*'Barra de acciones'", text, re.IGNORECASE
    ))
    if action_bars > 1:
        add("ERROR", "APEX-ACTION-002", 0,
            "La pagina contiene mas de una region Barra de acciones.")

    return findings


def input_files(paths: list[str]) -> list[Path]:
    result: list[Path] = []
    for raw in paths:
        path = Path(raw).resolve()
        if path.is_file():
            result.append(path)
        elif path.is_dir():
            result.extend(sorted(path.rglob("page_*.sql")))
        else:
            raise FileNotFoundError(raw)
    return sorted(set(result))


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Valida reglas estaticas obligatorias en exports de paginas Oracle APEX."
    )
    parser.add_argument("paths", nargs="+", help="Archivos page_*.sql o carpetas que los contienen.")
    parser.add_argument("--json", action="store_true", help="Emite el resultado como JSON.")
    args = parser.parse_args()

    try:
        files = input_files(args.paths)
    except FileNotFoundError as exc:
        print(f"RUTA_NO_ENCONTRADA: {exc}", file=sys.stderr)
        return 2
    if not files:
        print("SIN_EXPORTS_APEX: no se encontraron archivos page_*.sql", file=sys.stderr)
        return 2

    findings = [finding for path in files for finding in audit(path)]
    errors = [finding for finding in findings if finding.severity == "ERROR"]
    if args.json:
        print(json.dumps({
            "files": [str(path) for path in files],
            "findings": [asdict(finding) for finding in findings],
            "result": "FAIL" if errors else "PASS",
        }, ensure_ascii=False, indent=2))
    else:
        for finding in findings:
            print(f"{finding.severity} {finding.rule} {finding.file}:{finding.line} {finding.message}")
        print(f"APEX_STATIC_AUDIT_{'FAIL' if errors else 'PASS'} files={len(files)} errors={len(errors)} reviews={len(findings) - len(errors)}")
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
