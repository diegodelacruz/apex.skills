from __future__ import annotations

"""Diagnostico de lectura para evitar exploracion manual de menu APEX."""

import argparse
import json
import sys
from typing import Any

import oracle_sql_tool as oracle


def query_environment(args: argparse.Namespace, environment: str) -> dict[str, Any]:
    config = oracle.oracle_config(environment, args)
    if oracle.assert_oracle_config(config):
        raise RuntimeError(f"Configuracion incompleta para {environment.upper()}.")
    conn = oracle.connect(config, args.timeout)
    if conn is None:
        raise RuntimeError("Modulo Python oracledb no disponible.")
    target = "p.codigopagina = :page_code" if args.page_code else "p.rutapagina = :route"
    sql = f"""
        with target_page as (
            select p.id, p.codigomodulo, p.codigopagina, p.descripcion, p.rutapagina, p.codigopadre, p.nivel, p.orden, p.opcionmenu
              from data.t_admi_modulopagina p where p.estado = 1 and p.codigomodulo = :module_code and {target}
        ), hierarchy as (
            select connect_by_root p.codigopagina target_code, level hierarchy_level, p.codigopagina, p.descripcion, p.rutapagina, p.codigopadre, p.nivel, p.orden, p.opcionmenu
              from data.t_admi_modulopagina p start with exists (select 1 from target_page t where t.codigomodulo = p.codigomodulo and t.codigopagina = p.codigopagina)
             connect by nocycle prior p.codigopadre = p.codigopagina and prior p.codigomodulo = p.codigomodulo
        ), roles as (
            select distinct ru.id_rol from data.t_admi_rolusuario ru where ru.estado = 1 and ru.codigomodulo = :module_code and ru.codigocompania = :company and ru.codigousuario = :qa_user
        )
        select 'PAGE' record_type, p.codigopagina, p.descripcion, p.rutapagina, p.codigopadre, p.nivel, p.orden, p.opcionmenu, cast(null as number) id_rol, cast(null as number) agregar, cast(null as number) guardar, cast(null as number) eliminar, cast(null as number) comentar, cast(null as number) imprimir, cast(null as number) cancelar, cast(null as number) hierarchy_level from target_page p
        union all select 'HIERARCHY', h.codigopagina, h.descripcion, h.rutapagina, h.codigopadre, h.nivel, h.orden, h.opcionmenu, null, null, null, null, null, null, null, h.hierarchy_level from hierarchy h
        union all select 'ACCESS', p.codigopagina, null, null, null, null, null, null, a.id_rol, a.agregar, a.guardar, a.eliminar, a.comentar, a.imprimir, a.cancelar, null from data.t_admi_rolaccesos a join target_page p on p.id = a.id_modulopagina join roles r on r.id_rol = a.id_rol where a.estado = 1 and a.codigoaccion is null
        union all select 'ROLE', null, null, null, null, null, null, null, r.id_rol, null, null, null, null, null, null, null from roles r
    """
    binds = {"module_code": args.module_code, "company": args.company, "qa_user": args.qa_user}
    binds["page_code" if args.page_code else "route"] = args.page_code or args.route
    with conn:
        oracle.configure_session(conn, args, f"navigation-diagnosis-{environment}")
        with conn.cursor() as cur:
            cur.execute(sql, binds)
            columns = [item[0].lower() for item in cur.description]
            rows = [dict(zip(columns, row)) for row in cur.fetchall()]
        conn.rollback()
    return {"environment": environment, "rows": rows}


def summarize(result: dict[str, Any]) -> dict[str, Any]:
    rows = result["rows"]
    page = next((r for r in rows if r["record_type"] == "PAGE"), None)
    hierarchy = [r for r in rows if r["record_type"] == "HIERARCHY"]
    roles = sorted({r["id_rol"] for r in rows if r["record_type"] == "ROLE"})
    access = [r for r in rows if r["record_type"] == "ACCESS"]
    effective_roles = sorted(set(roles) & {r["id_rol"] for r in access})
    return {"environment": result["environment"], "page": page, "hierarchy_complete": bool(page and hierarchy), "hierarchy_leaf_to_root": hierarchy, "user_roles": roles, "base_access_by_role": access, "effective_roles": effective_roles, "ready": bool(page and hierarchy and effective_roles)}


def decision(test: dict[str, Any], prod: dict[str, Any]) -> dict[str, Any]:
    if test["ready"]:
        return {"decision": "TEST_READY", "next_action": "Probar solamente la ruta visible en TEST y registrar evidencia."}
    if prod["ready"]:
        page = prod["page"]
        return {"decision": "RECONCILE_TEST_FROM_PROD", "next_action": "Generar, versionar y revisar el MERGE idempotente; aplicarlo exclusivamente en TEST con apex_menu_access_tool.py. Incluir --test-user para restaurar la asignacion al rol cuando falte.", "role_id": prod["effective_roles"][0], "page": {key: page[key] for key in ("codigopagina", "descripcion", "rutapagina", "codigopadre", "nivel", "orden", "opcionmenu")}}
    return {"decision": "USER_DECISION_REQUIRED", "next_action": "No crear ni ampliar menu/acceso. Informar la ausencia concreta y pedir autorizacion solo para el cambio de seguridad o jerarquia necesario."}


def main() -> int:
    parser = argparse.ArgumentParser(description="Diagnostica ruta, jerarquia y acceso APEX en TEST y PRODUCCION sin modificar datos.")
    parser.add_argument("--module-code", required=True)
    target = parser.add_mutually_exclusive_group(required=True)
    target.add_argument("--page-code")
    target.add_argument("--route")
    parser.add_argument("--qa-user", required=True)
    parser.add_argument("--company", default="00001")
    parser.add_argument("--timeout", type=float, default=5.0)
    parser.add_argument("--host")
    parser.add_argument("--port")
    parser.add_argument("--sid")
    parser.add_argument("--user")
    parser.add_argument("--password")
    parser.add_argument("--output", choices=("json", "summary"), default="summary")
    args = parser.parse_args()
    oracle.load_external_env()
    try:
        report = {"test": summarize(query_environment(args, "test")), "prod": summarize(query_environment(args, "prod"))}
        report["recommendation"] = decision(report["test"], report["prod"])
    except Exception as exc:
        print(f"NAVIGATION_DIAGNOSIS_ERROR: {exc}", file=sys.stderr)
        return 2
    if args.output == "json": print(json.dumps(report, ensure_ascii=False, default=str, indent=2))
    else:
        print(f"NAVIGATION_DIAGNOSIS {report['recommendation']['decision']}")
        print(report["recommendation"]["next_action"])
        if report["recommendation"]["decision"] == "RECONCILE_TEST_FROM_PROD": print("RECONCILIATION=" + json.dumps(report["recommendation"], ensure_ascii=False, default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
