from __future__ import annotations

import argparse
import io
import sys
from pathlib import Path
from zipfile import ZipFile

try:
    from docx import Document
    from PIL import Image
except ImportError as exc:  # pragma: no cover
    print(f"Falta dependencia Python: {exc.name}", file=sys.stderr)
    raise SystemExit(2)


EMU_PER_INCH = 914400
NEAR_WHITE_WARN = 0.94
ERROR_RED_WARN = 0.0003
ERROR_BLUE_WARN = 0.01
LOW_DARK_WARN = 0.002


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Audita imagenes de un DOCX para manuales de usuario de Sistemas."
    )
    parser.add_argument("docx", help="Ruta del archivo .docx a revisar.")
    parser.add_argument("--max-height-in", type=float, default=6.0)
    parser.add_argument("--min-ratio", type=float, default=1.15)
    parser.add_argument("--warn-only", action="store_true")
    return parser.parse_args()


def embedded_image_sizes(path: Path) -> list[tuple[str, int, int]]:
    sizes: list[tuple[str, int, int]] = []
    with ZipFile(path) as package:
        for name in package.namelist():
            if not name.startswith("word/media/"):
                continue
            data = package.read(name)
            try:
                image = Image.open(io.BytesIO(data))
            except Exception:
                continue
            sizes.append((name, image.width, image.height))
    return sizes


def embedded_image_metrics(path: Path) -> list[dict[str, float | int | str]]:
    metrics: list[dict[str, float | int | str]] = []
    with ZipFile(path) as package:
        for name in package.namelist():
            if not name.startswith("word/media/"):
                continue
            data = package.read(name)
            try:
                image = Image.open(io.BytesIO(data)).convert("RGB")
            except Exception:
                continue
            pixels = list(image.getdata())
            total = len(pixels) or 1
            near_white = sum(1 for r, g, b in pixels if r > 235 and g > 235 and b > 235) / total
            red = sum(1 for r, g, b in pixels if r > 180 and g < 100 and b < 100) / total
            dark = sum(1 for r, g, b in pixels if r < 80 and g < 80 and b < 80) / total
            blue = sum(1 for r, g, b in pixels if b > 150 and r < 80 and g < 160) / total
            metrics.append(
                {
                    "name": name,
                    "width": image.width,
                    "height": image.height,
                    "near_white": near_white,
                    "red": red,
                    "dark": dark,
                    "blue": blue,
                }
            )
    return metrics


def quality_findings(metric: dict[str, float | int | str]) -> list[str]:
    near_white = float(metric["near_white"])
    red = float(metric["red"])
    dark = float(metric["dark"])
    blue = float(metric["blue"])
    findings: list[str] = []

    if near_white >= NEAR_WHITE_WARN and red >= ERROR_RED_WARN and blue >= ERROR_BLUE_WARN:
        findings.append("posible pantalla de error de aplicacion o dialogo abierto incorrectamente")
    if near_white >= NEAR_WHITE_WARN and dark <= LOW_DARK_WARN and blue < 0.005:
        findings.append("posible pantalla vacia, spinner o reporte sin ejecutar")

    return findings


def main() -> int:
    args = parse_args()
    path = Path(args.docx)
    if not path.exists():
        print(f"No existe el DOCX: {path}", file=sys.stderr)
        return 2

    doc = Document(path)
    embedded = embedded_image_sizes(path)
    image_metrics = embedded_image_metrics(path)
    failures: list[str] = []

    print(f"docx={path}")
    print(f"inline_shapes={len(doc.inline_shapes)}")
    print(f"embedded_images={len(embedded)}")

    for index, shape in enumerate(doc.inline_shapes, 1):
        width_in = int(shape.width) / EMU_PER_INCH
        height_in = int(shape.height) / EMU_PER_INCH
        ratio = width_in / height_in if height_in else 0
        status = "OK"
        reasons: list[str] = []
        if height_in > args.max_height_in:
            reasons.append(f"alto {height_in:.2f}in > {args.max_height_in:.2f}in")
        if ratio < args.min_ratio:
            reasons.append(f"relacion {ratio:.2f} < {args.min_ratio:.2f}")
        if reasons:
            status = "WARN"
            failures.append(f"shape {index}: " + "; ".join(reasons))
        print(
            f"shape {index}: {status} displayed={width_in:.2f}x{height_in:.2f}in ratio={ratio:.2f}"
        )

    for index, (name, width, height) in enumerate(embedded, 1):
        ratio = width / height if height else 0
        print(f"image {index}: {name} pixels={width}x{height} ratio={ratio:.2f}")

    print("\nCalidad visual de capturas:")
    for index, metric in enumerate(image_metrics, 1):
        findings = quality_findings(metric)
        status = "WARN" if findings else "OK"
        print(
            "image {index}: {status} {name} near_white={near_white:.3f} "
            "red={red:.5f} dark={dark:.4f} blue={blue:.4f}".format(
                index=index,
                status=status,
                name=metric["name"],
                near_white=float(metric["near_white"]),
                red=float(metric["red"]),
                dark=float(metric["dark"]),
                blue=float(metric["blue"]),
            )
        )
        for finding in findings:
            failures.append(f"image {index}: {finding}")

    if failures:
        print("\nHallazgos:")
        for failure in failures:
            print(f"- {failure}")
        return 0 if args.warn_only else 1

    print("\nTodas las imagenes insertadas cumplen el criterio de proporcion configurado.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
