from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

try:
    from docx import Document
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Inches, Pt, RGBColor
except ImportError as exc:  # pragma: no cover
    print(f"Falta dependencia Python: {exc.name}", file=sys.stderr)
    raise SystemExit(2)


MAX_IMAGE_WIDTH = 7.2
MAX_IMAGE_HEIGHT = 5.6
BLUE = RGBColor(31, 78, 121)
BLACK = RGBColor(0, 0, 0)
VALID_NAVIGATION = {
    "menu",
    "application-action",
    "dialog-action",
    "report-link",
    "row-action",
    "tab-action",
    "accordion-action",
    "workflow",
}
REPORT_TYPES = {"report", "interactive-report", "grid", "table", "list"}
FORM_TYPES = {"form", "dialog-form", "upload-form", "wizard"}
DETAIL_TYPES = {"detail", "dialog-detail", "record-detail"}
COMPONENT_TYPES = {"tab", "tabs", "accordion", "section", "region"}
NEAR_WHITE_WARN = 0.94
ERROR_RED_WARN = 0.0003
ERROR_BLUE_WARN = 0.01
LOW_DARK_WARN = 0.002
FORBIDDEN_USER_MANUAL_PHRASES = (
    "describir en lenguaje funcional",
    "mejoras entregadas",
    "validacion tecnica",
    "validación técnica",
    "alcance documentado",
    "pendientes o consideraciones",
    "recurso estatico",
    "recurso estÃ¡tico",
    "404",
    "antes de publicar",
    "autorizacion explicita",
    "autorizaciÃ³n explÃ­cita",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Genera un manual funcional de cambios y mejoras desde JSON."
    )
    parser.add_argument("source_json", help="Archivo JSON con contenido del manual.")
    parser.add_argument(
        "--coverage",
        default="",
        help="Inventario JSON obligatorio de cobertura del manual; puede contener la clave coverage.",
    )
    parser.add_argument("--out", required=True, help="Ruta DOCX de salida.")
    parser.add_argument("--image-root", default="", help="Carpeta base para rutas relativas de imagenes.")
    return parser.parse_args()


def load_source(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def load_coverage(path: Path) -> list[dict[str, Any]]:
    data = load_source(path)
    if isinstance(data, dict):
        data = data.get("coverage")
    if not isinstance(data, list):
        raise ValueError("El inventario de cobertura debe ser una lista o contener la clave coverage.")
    return data


def configure(document: Document) -> None:
    section = document.sections[0]
    section.top_margin = Inches(0.65)
    section.bottom_margin = Inches(0.65)
    section.left_margin = Inches(0.7)
    section.right_margin = Inches(0.7)

    styles = document.styles
    styles["Normal"].font.name = "Arial"
    styles["Normal"].font.size = Pt(10)
    styles["Normal"].font.color.rgb = BLACK
    for style_name, size in (("Heading 1", 16), ("Heading 2", 13), ("Heading 3", 11)):
        styles[style_name].font.name = "Arial"
        styles[style_name].font.size = Pt(size)
        styles[style_name].font.color.rgb = BLUE


def paragraph(document: Document, text: str = "", bold_label: str | None = None) -> None:
    p = document.add_paragraph()
    if bold_label:
        run = p.add_run(bold_label)
        run.bold = True
        p.add_run(text)
    else:
        p.add_run(text)
    p.paragraph_format.space_after = Pt(6)


def bullets(document: Document, items: list[str]) -> None:
    for item in items:
        p = document.add_paragraph(style="List Bullet")
        p.add_run(item)
        p.paragraph_format.space_after = Pt(3)


def image_size(path: Path) -> tuple[int, int] | None:
    try:
        from PIL import Image
    except ImportError:
        return None

    try:
        with Image.open(path) as image:
            return image.width, image.height
    except Exception:
        return None


def image_quality_findings(path: Path) -> list[str]:
    try:
        from PIL import Image
    except ImportError:
        return ["no se pudo validar calidad visual porque falta Pillow"]

    try:
        image = Image.open(path).convert("RGB")
    except Exception as exc:
        return [f"no se pudo abrir imagen para validar calidad visual: {exc}"]

    pixels = list(image.getdata())
    total = len(pixels) or 1
    near_white = sum(1 for r, g, b in pixels if r > 235 and g > 235 and b > 235) / total
    red = sum(1 for r, g, b in pixels if r > 180 and g < 100 and b < 100) / total
    dark = sum(1 for r, g, b in pixels if r < 80 and g < 80 and b < 80) / total
    blue = sum(1 for r, g, b in pixels if b > 150 and r < 80 and g < 160) / total

    findings: list[str] = []
    if near_white >= NEAR_WHITE_WARN and red >= ERROR_RED_WARN and blue >= ERROR_BLUE_WARN:
        findings.append("posible pantalla de error de aplicacion o dialogo abierto incorrectamente")
    if near_white >= NEAR_WHITE_WARN and dark <= LOW_DARK_WARN and blue < 0.005:
        findings.append("posible pantalla vacia, spinner o reporte sin ejecutar")
    return findings


def add_image(document: Document, image_path: Path, caption: str) -> None:
    if not image_path.exists():
        paragraph(document, f"Pendiente de captura: {caption}")
        return

    width = MAX_IMAGE_WIDTH
    size = image_size(image_path)
    if size:
        pixel_width, pixel_height = size
        ratio = pixel_width / pixel_height if pixel_height else 1
        if ratio < 1.15:
            paragraph(
                document,
                "Pendiente de recaptura: la imagen disponible es demasiado vertical para el manual. "
                f"Usar captura de viewport de computador o dividir en varias capturas. Archivo: {image_path.name}"
            )
            return
        width = min(MAX_IMAGE_WIDTH, MAX_IMAGE_HEIGHT * ratio)

    p = document.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run().add_picture(str(image_path), width=Inches(width))

    c = document.add_paragraph()
    c.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = c.add_run(caption)
    run.italic = True
    run.font.size = Pt(9)
    c.paragraph_format.space_after = Pt(10)


def add_buttons(document: Document, buttons: list[dict[str, str]]) -> None:
    if not buttons:
        return
    document.add_heading("Botones y acciones", level=3)
    for button in buttons:
        name = button.get("name", "Boton")
        action = button.get("action", "")
        paragraph(document, action, bold_label=f"{name}: ")


def collect_buttons(change: dict[str, Any]) -> list[dict[str, str]]:
    collected: list[dict[str, str]] = []
    collected.extend(change.get("buttons", []))
    for section in change.get("sections", []):
        collected.extend(section.get("buttons", []))
    return collected


def normalized_text(*values: Any) -> str:
    return " ".join(str(value or "").lower() for value in values)


def non_empty_mapping(value: Any) -> bool:
    if not isinstance(value, dict) or not value:
        return False
    return all(str(item).strip() for item in value.values())


def capture_validation_errors(block: dict[str, Any], label: str) -> list[str]:
    if not block.get("image"):
        return []

    capture = block.get("capture")
    if not isinstance(capture, dict):
        return [f"{label}: falta objeto capture con evidencia de navegacion y estado de pantalla"]

    errors: list[str] = []
    navigation = str(capture.get("navigation", "")).strip()
    screen_type = str(capture.get("screenType", block.get("screenType", ""))).strip()
    context_text = normalized_text(
        label,
        block.get("title"),
        block.get("description"),
        block.get("caption"),
        block.get("image"),
        capture.get("path"),
        capture.get("activeComponent"),
        capture.get("componentAction"),
    )

    if capture.get("validated") is not True:
        errors.append(f"{label}: capture.validated debe ser true")
    if navigation not in VALID_NAVIGATION:
        errors.append(
            f"{label}: capture.navigation debe ser una ruta real ({', '.join(sorted(VALID_NAVIGATION))})"
        )
    if capture.get("usedDirectUrl") is True:
        errors.append(f"{label}: no se permite captura obtenida por URL directa")
    if capture.get("usedJavascriptNavigation") is True:
        errors.append(f"{label}: no se permite captura obtenida por navegacion JavaScript directa")
    if capture.get("errorsVisible") is True:
        errors.append(f"{label}: la captura tiene errores visibles")
    if capture.get("loadingVisible") is True:
        errors.append(f"{label}: la captura tiene spinner, carga pendiente o pantalla incompleta")
    if capture.get("fullPage") is True:
        errors.append(f"{label}: no se permite capture.fullPage=true en un manual; usar viewport de escritorio")

    flow_steps = capture.get("flowSteps")
    if not isinstance(flow_steps, list) or not flow_steps:
        errors.append(f"{label}: falta capture.flowSteps con el flujo real ejecutado antes de capturar")

    if screen_type in REPORT_TYPES and capture.get("dataVisible") is not True:
        errors.append(f"{label}: los reportes deben mostrar datos o resultado ejecutado antes de capturar")
    if screen_type in REPORT_TYPES and capture.get("actionExecuted") is not True:
        errors.append(f"{label}: los reportes deben ejecutar Buscar, Go, filtro o accion equivalente antes de capturar")
    if screen_type in REPORT_TYPES:
        row_count = capture.get("rowCount")
        if not isinstance(row_count, int) or row_count < 1:
            errors.append(f"{label}: los reportes deben declarar capture.rowCount mayor a 0 despues de ejecutar la consulta")
        filter_required_by_context = any(
            text in context_text
            for text in (
                "reporte sell out",
                "reportesellout",
                "fecha desde",
                "fecha hasta",
            )
        )
        if capture.get("requiresFilter") is True or filter_required_by_context:
            if capture.get("requiresFilter") is not True:
                errors.append(f"{label}: este reporte requiere filtros; capture.requiresFilter debe ser true")
            filters_used = capture.get("filtersUsed") or capture.get("filterValues") or capture.get("searchCriteria")
            if not isinstance(filters_used, (list, dict)) or not filters_used:
                errors.append(f"{label}: si el reporte requiere filtro, debe llenar o seleccionar el filtro y declarar capture.filtersUsed, capture.filterValues o capture.searchCriteria")
            if not non_empty_mapping(capture.get("filterValues")):
                errors.append(f"{label}: los reportes con filtros deben declarar capture.filterValues con valores no vacios")
    if screen_type in FORM_TYPES and capture.get("formPrepared") is not True:
        errors.append(f"{label}: los formularios deben abrirse preparados con datos de prueba o campos necesarios")
    if screen_type in FORM_TYPES:
        populated = capture.get("populatedFields") or capture.get("preparedData")
        if not isinstance(populated, (list, dict)) or not populated:
            errors.append(f"{label}: los formularios deben declarar campos o datos preparados antes de capturar")
    if screen_type in DETAIL_TYPES:
        if not str(capture.get("originPage", "")).strip():
            errors.append(f"{label}: los detalles por registro deben declarar capture.originPage")
        if not str(capture.get("originAction", "")).strip():
            errors.append(f"{label}: los detalles por registro deben declarar capture.originAction")
        if not str(capture.get("originRecord", "")).strip():
            errors.append(f"{label}: los detalles por registro deben declarar capture.originRecord")

    component_type = str(capture.get("componentType", "")).strip()
    if screen_type in COMPONENT_TYPES or component_type in COMPONENT_TYPES or capture.get("hasTabsOrAccordions") is True:
        if not str(capture.get("activeComponent", "")).strip():
            errors.append(f"{label}: las capturas de tabs, acordeones, secciones o regiones deben declarar capture.activeComponent")
        if not str(capture.get("componentAction", "")).strip():
            errors.append(f"{label}: las capturas de tabs, acordeones, secciones o regiones deben declarar capture.componentAction")

    accordion_required_by_context = any(
        text in context_text
        for text in (
            "control de sell out e inventario",
            "sell out e inventario",
            "sellout/inventario",
            "c5_sellout_inventario",
        )
    )
    if accordion_required_by_context:
        expanded_components = capture.get("expandedComponents")
        if not isinstance(expanded_components, list) or not expanded_components:
            errors.append(f"{label}: la pantalla requiere abrir acordeones/regiones internas; declarar capture.expandedComponents")
        else:
            invalid_components = [
                item for item in expanded_components
                if not isinstance(item, dict)
                or item.get("expanded") is not True
                or not str(item.get("name", "")).strip()
                or item.get("rowCount", 0) < 1
            ]
            if invalid_components:
                errors.append(
                    f"{label}: cada elemento de capture.expandedComponents debe tener name, expanded=true y rowCount mayor a 0"
                )

    if not str(capture.get("path", "")).strip():
        errors.append(f"{label}: falta capture.path con la ruta funcional usada para llegar a la pantalla")

    return errors


def project_path_exists(value: Any) -> bool:
    if not isinstance(value, str) or not value.strip():
        return False
    path = Path(value)
    if path.is_absolute():
        return path.exists()
    return (Path.cwd() / path).exists()


def evidence_validation_errors(block: dict[str, Any], label: str) -> list[str]:
    if not block.get("image"):
        return []

    capture = block.get("capture")
    if not isinstance(capture, dict):
        return []

    errors: list[str] = []
    source_screenshot = capture.get("sourceScreenshot")
    qa_report = capture.get("qaReport")

    if not project_path_exists(source_screenshot):
        errors.append(
            f"{label}: falta capture.sourceScreenshot existente con la captura QA usada como origen"
        )

    if isinstance(qa_report, list):
        report_exists = any(project_path_exists(item) for item in qa_report)
    else:
        report_exists = project_path_exists(qa_report)
    if not report_exists:
        errors.append(f"{label}: falta capture.qaReport existente que respalde la navegacion")

    if str(capture.get("navigation", "")).strip() == "dialog-action":
        if not str(capture.get("openerPage", "")).strip():
            errors.append(f"{label}: los dialogos deben declarar capture.openerPage")
        if not str(capture.get("openerAction", "")).strip():
            errors.append(f"{label}: los dialogos deben declarar capture.openerAction")

    return errors


def validate_captures(source: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    for number, change in enumerate(source.get("changes", []), 1):
        title = change.get("title", f"Cambio {number}")
        errors.extend(capture_validation_errors(change, f"{number}. {title}"))
        errors.extend(evidence_validation_errors(change, f"{number}. {title}"))
        for section_number, section in enumerate(change.get("sections", []), 1):
            section_title = section.get("title", f"Seccion {section_number}")
            errors.extend(
                capture_validation_errors(
                    section,
                    f"{number}.{section_number}. {title} / {section_title}",
                )
            )
            errors.extend(
                evidence_validation_errors(
                    section,
                    f"{number}.{section_number}. {title} / {section_title}",
                )
            )
    return errors


def validate_user_language(source: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    fields: list[tuple[str, str]] = []
    fields.append(("objective", str(source.get("objective", ""))))
    for pending_number, pending in enumerate(source.get("pending", []), 1):
        fields.append((f"pending {pending_number}", str(pending)))
    for number, change in enumerate(source.get("changes", []), 1):
        title = change.get("title", f"Cambio {number}")
        fields.append((f"{number}. {title} / description", str(change.get("description", ""))))
        for section_number, section in enumerate(change.get("sections", []), 1):
            section_title = section.get("title", f"Seccion {section_number}")
            fields.append(
                (
                    f"{number}.{section_number}. {title} / {section_title} / description",
                    str(section.get("description", "")),
                )
            )

    for label, text in fields:
        normalized = text.lower()
        for phrase in FORBIDDEN_USER_MANUAL_PHRASES:
            if phrase in normalized:
                errors.append(f"{label}: contiene frase interna no apta para usuario final: {phrase}")
    return errors


def validate_no_pending_section(source: dict[str, Any]) -> list[str]:
    if source.get("pending"):
        return [
            "El manual de usuario no debe incluir pending/Pendientes o consideraciones; "
            "pendientes, errores 404, bloqueos y autorizaciones quedan en informe QA o bitacora."
        ]
    return []


def validate_manual_coverage(source: dict[str, Any]) -> list[str]:
    coverage = source.get("coverage")
    if not isinstance(coverage, list) or not coverage:
        return [
            "falta coverage: inventario obligatorio de pantallas, dialogos y acciones del manual"
        ]

    section_titles = {
        str(change.get("title", "")).strip()
        for change in source.get("changes", [])
    }
    errors: list[str] = []
    required = ("id", "type", "navigationContract", "entryAction", "expectedOutcome", "manualSection")
    for number, item in enumerate(coverage, 1):
        label = f"coverage[{number}]"
        if not isinstance(item, dict):
            errors.append(f"{label}: debe ser un objeto")
            continue
        missing = [field for field in required if not str(item.get(field, "")).strip()]
        if missing:
            errors.append(f"{label}: faltan campos obligatorios: {', '.join(missing)}")
        if item.get("type") not in {"page", "dialog", "action", "tab", "accordion", "workflow-step"}:
            errors.append(f"{label}: type invalido")
        contract = item.get("navigationContract")
        if not project_path_exists(contract):
            errors.append(f"{label}: navigationContract no existe: {contract}")
        section = str(item.get("manualSection", "")).strip()
        if section and section not in section_titles:
            errors.append(f"{label}: manualSection no corresponde a un titulo de changes: {section}")
        if item.get("status") != "captured":
            errors.append(f"{label}: status debe ser captured para generar el manual")
    return errors


def validate_image_quality(source: dict[str, Any], image_root: Path) -> list[str]:
    errors: list[str] = []

    def validate_block(block: dict[str, Any], label: str) -> None:
        image = block.get("image")
        if not image:
            return
        image_path = image_root / image
        if not image_path.exists():
            return
        size = image_size(image_path)
        if size:
            width, height = size
            if height and width / height < 1.15:
                errors.append(
                    f"{label}: {image_path.name}: captura demasiado vertical para un viewport de escritorio; "
                    "recapturar sin fullPage y dividir el contenido en vistas normales"
                )
        for finding in image_quality_findings(image_path):
            errors.append(f"{label}: {image_path.name}: {finding}")

    for number, change in enumerate(source.get("changes", []), 1):
        title = change.get("title", f"Cambio {number}")
        validate_block(change, f"{number}. {title}")
        for section_number, section in enumerate(change.get("sections", []), 1):
            section_title = section.get("title", f"Seccion {section_number}")
            validate_block(section, f"{number}.{section_number}. {title} / {section_title}")

    return errors


def build_manual(source: dict[str, Any], out: Path, image_root: Path) -> None:
    document = Document()
    configure(document)

    title = source.get("title", "Manual de usuario - Cambios y mejoras")
    subtitle = source.get("subtitle", "")
    metadata = source.get("metadata", {})

    p = document.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(title)
    run.bold = True
    run.font.name = "Arial"
    run.font.size = Pt(18)
    run.font.color.rgb = BLUE

    if subtitle:
        p = document.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.add_run(subtitle).italic = True

    if metadata:
        document.add_heading("Datos del documento", level=1)
        for key, value in metadata.items():
            paragraph(document, str(value), bold_label=f"{key}: ")

    objective = source.get("objective")
    if objective:
        document.add_heading("Objetivo", level=1)
        paragraph(document, objective)

    scope = source.get("scope", [])
    if scope:
        document.add_heading("Cambios incluidos", level=1)
        bullets(document, [str(item) for item in scope])

    changes = source.get("changes", [])
    for number, change in enumerate(changes, 1):
        heading = change.get("title", f"Cambio {number}")
        document.add_heading(f"{number}. {heading}", level=1)
        description = change.get("description")
        if description:
            paragraph(document, description)

        image = change.get("image")
        if image:
            add_image(
                document,
                image_root / image,
                change.get("caption", heading),
            )

        for section in change.get("sections", []):
            document.add_heading(section.get("title", "Detalle"), level=2)
            if section.get("description"):
                paragraph(document, section["description"])
            if section.get("image"):
                add_image(
                    document,
                    image_root / section["image"],
                    section.get("caption", section.get("title", "Captura")),
                )

        add_buttons(document, collect_buttons(change))

    out.parent.mkdir(parents=True, exist_ok=True)
    document.save(out)


def main() -> int:
    args = parse_args()
    source_path = Path(args.source_json)
    image_root = Path(args.image_root) if args.image_root else source_path.parent
    out = Path(args.out)
    source = load_source(source_path)
    if args.coverage:
        source["coverage"] = load_coverage(Path(args.coverage))
    errors = validate_captures(source)
    errors.extend(validate_manual_coverage(source))
    errors.extend(validate_user_language(source))
    errors.extend(validate_no_pending_section(source))
    errors.extend(validate_image_quality(source, image_root))
    if errors:
        print("No se puede generar el manual: existen validaciones pendientes.", file=sys.stderr)
        for error in errors:
            print(f"- {error}", file=sys.stderr)
        return 1
    build_manual(source, out, image_root)
    print(f"Manual generado: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
