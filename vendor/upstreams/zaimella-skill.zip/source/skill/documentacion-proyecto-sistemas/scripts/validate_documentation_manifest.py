#!/usr/bin/env python3
"""Valida el contrato minimo de un entregable documental de Sistemas."""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any


PLACEHOLDER_RE = re.compile(r"<[^>]+>")


def incomplete(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, str):
        return not value.strip() or bool(PLACEHOLDER_RE.search(value))
    if isinstance(value, (list, dict)):
        return not value
    return False


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True)
    args = parser.parse_args()
    path = Path(args.manifest).resolve()
    if not path.is_file():
        print(f"DOCUMENTATION_MANIFEST_ERROR No existe: {path}")
        print("DOCUMENTATION_MANIFEST_FAIL")
        return 2
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"DOCUMENTATION_MANIFEST_ERROR JSON invalido: {exc}")
        print("DOCUMENTATION_MANIFEST_FAIL")
        return 2

    errors: list[str] = []
    for name in ("documentId", "deliverableId", "profile", "audience", "purpose", "baseline", "output", "sections"):
        if incomplete(data.get(name)):
            errors.append(f"Campo incompleto: {name}")
    if data.get("profile") not in {"funcional", "tecnico", "mixto"}:
        errors.append("Perfil no permitido")
    sections = data.get("sections", [])
    if isinstance(sections, list):
        seen: set[str] = set()
        for index, section in enumerate(sections, start=1):
            if not isinstance(section, dict):
                errors.append(f"Seccion {index}: debe ser un objeto")
                continue
            section_id = str(section.get("id", f"fila-{index}"))
            if section_id in seen:
                errors.append(f"ID de seccion duplicado: {section_id}")
            seen.add(section_id)
            for name in ("id", "title", "kind", "sourceEvidence", "status"):
                if incomplete(section.get(name)):
                    errors.append(f"{section_id}: campo incompleto {name}")
            status = section.get("status")
            if status not in {"ready", "documented", "not-applicable"}:
                errors.append(f"{section_id}: estado no permitido")
            if status == "not-applicable" and incomplete(section.get("justification")):
                errors.append(f"{section_id}: no aplica sin justificacion")
            if section.get("kind") == "screen" and status != "not-applicable":
                for name in ("capture", "qaEvidence"):
                    if incomplete(section.get(name)):
                        errors.append(f"{section_id}: pantalla sin {name}")
    else:
        errors.append("sections debe ser una lista")

    if errors:
        for error in errors:
            print(f"DOCUMENTATION_MANIFEST_ERROR {error}")
        print("DOCUMENTATION_MANIFEST_FAIL")
        return 2
    print(
        "DOCUMENTATION_MANIFEST_PASS "
        f"document={data['documentId']} profile={data['profile']} sections={len(sections)}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
