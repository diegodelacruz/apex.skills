# Perfiles De Entregables Documentales

## Regla Comun

La clasificacion depende de la audiencia y del uso del documento, no de la tecnologia. Un mismo proyecto puede requerir varios documentos; todos pertenecen al mismo plan documental y deben usar la linea base aprobada del entregable.

## Perfil Funcional

Usar para manual de usuario, guia de operacion, manual de cambios, ayuda de pantalla, procedimiento de negocio o capacitacion. Explicar proposito, acceso, precondiciones, pasos, campos, acciones, resultados, mensajes y recuperacion funcional. Evitar codigo y nombres internos salvo que sean necesarios para el usuario.

## Perfil Tecnico

Usar para arquitectura, interfaces, API, integraciones, modelo de datos, despliegue, instalacion, configuracion, operacion, monitoreo, seguridad, soporte o recuperacion. Explicar conceptos antes de detalles, definir terminos, declarar responsables, entradas, salidas, dependencias, ambientes, versiones y controles. La precision tecnica no justifica una redaccion incomprensible.

## Perfil Mixto

Usar cuando la audiencia necesita comprender el resultado funcional y tambien operarlo o mantenerlo tecnicamente. Separar como minimo:

1. Contexto y resultado funcional.
2. Uso o flujo operativo.
3. Arquitectura y componentes.
4. Interfaces, datos y controles.
5. Operacion, soporte y limites.

No duplicar contenido entre secciones. Referenciar el mismo identificador de version y evidencia.

## Formatos

El perfil no obliga un formato. El contrato puede requerir DOCX, PDF, XLSX, Markdown, HTML u otro artefacto. Cuando existan formatos fuente y final, conservar ambos y registrar cual es editable y cual es entregable.
