# Gate De Calidad Documental

Antes de declarar una salida completa:

1. Comparar el indice y las secciones contra el manifiesto.
2. Confirmar audiencia, proposito y lenguaje adecuados al perfil.
3. Confirmar que versiones, capturas, ejemplos y contratos pertenecen a la misma linea base.
4. Verificar enlaces, referencias, numeracion, tablas, pies de imagen y terminos.
5. Eliminar secretos, datos sensibles y detalles internos que la audiencia no necesita.
6. Renderizar el formato final y revisar todas las paginas: cortes, desbordes, imagenes ilegibles, espacios vacios, encabezados huerfanos y consistencia visual.
7. Verificar que capturas y diagramas sean legibles y tengan contexto; no usar imagenes decorativas para reemplazar explicaciones.
8. Confirmar que el documento no declare como ejecutado, aprobado o productivo algo que la evidencia no demuestra.
9. Registrar fuente editable, artefacto final, fecha, autor o responsable documental y version documentada.

Si una fila falla, devolver `DOCUMENTACION_INCOMPLETA`; no degradar silenciosamente el alcance.
