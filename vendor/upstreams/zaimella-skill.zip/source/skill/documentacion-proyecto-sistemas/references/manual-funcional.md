# Manual Funcional Y De Cambios

Referencia para generar manuales de usuario en Word cuando el plan documental lo requiera. Aplica a aplicaciones web, moviles o APEX, pantallas nuevas o modificadas y procesos, APIs o automatizaciones sin pantalla.

## Activacion

Generar este manual cuando el plan documental del proyecto lo requiera o por pedido explicito del usuario, por ejemplo:

- `vamos a generar el manual de usuario`
- `genera el manual de usuario`
- `manual de cambios y mejoras`
- `manual de usuario de las tareas indicadas`

No generar Word como salida automatica de QA. QA entrega evidencia; este skill genera el documento cuando existe alcance documental.

## Entregable

- Documento final Word `.docx`.
- Ruta recomendada: `docs/manuales/manual_usuario_cambios_mejoras.docx`.
- Fuente editable recomendada para generacion: `docs/manuales/manual_usuario_cambios_mejoras_fuente.json`.
- Imagenes: `docs/manuales/img/`.
- El documento debe estar escrito para usuario final, no para desarrolladores.

## Scripts Locales

Las rutas mostradas en ejemplos son referencias historicas. El orquestador entrega las rutas reales de fuente, capturas y salida; este skill no crea ni administra carpetas de proyecto.

`documentacion-proyecto-sistemas` incluye scripts para evitar recrear generadores durante cada tarea:

- `scripts/build_manual_cambios.py`: genera el Word desde una fuente JSON.
- `scripts/audit_docx_images.py`: audita imagenes insertadas en un DOCX y detecta capturas demasiado verticales, pantallas vacias, spinners, reportes sin ejecutar y posibles errores APEX visibles.

Uso recomendado desde la carpeta del proyecto evaluado:

```powershell
python "<ruta-skill>\scripts\build_manual_cambios.py" docs\manuales\manual_usuario_cambios_mejoras_fuente.json --out docs\manuales\manual_usuario_cambios_mejoras.docx --image-root docs\manuales\img
python "<ruta-skill>\scripts\audit_docx_images.py" docs\manuales\manual_usuario_cambios_mejoras.docx
```

El JSON fuente debe usar contenido claro para usuario final. Estructura base:

```json
{
  "title": "Manual de usuario - Cambios y mejoras",
  "subtitle": "Modulo o aplicacion",
  "metadata": {
    "Fecha": "2026-06-04",
    "Ambiente": "Test"
  },
  "objective": "Este manual explica los cambios realizados para que el usuario pueda consultar, cargar y revisar informacion desde las pantallas actualizadas.",
  "scope": ["Pantalla modificada o mejora funcional"],
  "changes": [
    {
      "title": "Nombre funcional del cambio",
      "description": "Descripcion no tecnica del cambio.",
      "screenType": "report",
      "image": "pantalla-principal.png",
      "caption": "Pantalla principal del cambio",
      "capture": {
        "validated": true,
        "navigation": "menu",
        "path": "Menu > Consultas > Solicitudes > Buscar",
        "screenType": "report",
        "flowSteps": [
          "Iniciar sesion en TEST",
          "Entrar por menu a Consulta de solicitudes",
          "Completar los filtros principales",
          "Ejecutar Buscar para mostrar resultados"
        ],
        "actionExecuted": true,
        "dataVisible": true,
        "formPrepared": false,
        "errorsVisible": false,
        "loadingVisible": false,
        "usedDirectUrl": false,
        "usedJavascriptNavigation": false,
        "sourceScreenshot": "qa/tareas/<ID_TAREA>/screenshots/page305-control-buscar.png",
        "qaReport": "qa/tareas/<ID_TAREA>/reports/20260604_manual_cambios_qa.json"
      },
      "buttons": [
        {
          "name": "Guardar",
          "action": "Registra la informacion ingresada y muestra confirmacion al finalizar."
        }
      ]
    }
  ],
  "pending": []
}
```

Para pantallas sin imagen, por ejemplo cambios solo PL/SQL o procesos automaticos, no se requiere `capture`.

## Formato Del Documento

Paleta y tipografia:

- Usar solo dos colores en texto: negro y azul corporativo.
- El titulo principal y los encabezados deben ir en azul.
- El cuerpo, listas, pies de foto y etiquetas deben ir en negro.
- No usar verde, rojo, naranja, morado ni otros colores en textos del manual, salvo que formen parte de una captura real de la aplicacion.
- Usar Arial como tipografia base.

Estructura minima:

1. Encabezado o portada:
   - Nombre de aplicacion, modulo o proyecto.
   - Titulo: `Manual de usuario - Cambios y mejoras`.
   - Fecha.
   - Ambiente o version si aplica.
2. Objetivo:
   - Explicar brevemente que cambios o mejoras se documentan.
3. Cambios incluidos:
   - Lista de pantallas nuevas, pantallas modificadas, mejoras funcionales o procesos sin pantalla.
4. Detalle por cambio o mejora:
   - Secciones por tema, tarea, pantalla o proceso.

No agregar seccion final de pendientes o consideraciones en el manual de usuario. Si existen pendientes, errores, bloqueos o autorizaciones por resolver, registrarlos en informe QA o bitacora.

Usar lenguaje claro, funcional y no tecnico. Evitar nombres de paquetes, SQL, procesos internos, IDs APEX, endpoints internos, cursores, jobs o detalles de codigo salvo que el usuario pida expresamente documentacion tecnica.

El objetivo y las descripciones deben estar escritos como informacion util para el usuario final. No usar frases sobre el documento o sobre la forma de redactar, como `Describir en lenguaje funcional`, `mejoras entregadas`, `alcance documentado`, `validacion tecnica`, `tareas incluidas` o expresiones similares. El generador debe rechazar esas frases cuando aparezcan en el objetivo o en descripciones.

Ejemplo correcto de objetivo:

`Este manual explica como consultar solicitudes, completar sus datos, revisar el resultado y usar las nuevas acciones disponibles.`

Ejemplo incorrecto:

`Describir en lenguaje funcional las mejoras entregadas para consulta, carga, seguimiento y control.`

## Capturas De Pantalla

Las capturas deben verse como una pantalla normal de computador, no como una captura vertical larga de toda la pagina.

Reglas:

- Antes de capturar, ejecutar el flujo funcional completo de la tarea o cambio documentado. La captura debe mostrar el resultado de ese flujo, no solo una pagina abierta.
- Si se documenta un reporte, ejecutar `Buscar`, `Go`, filtros, fechas, tab o accion necesaria hasta que el reporte muestre datos o un resultado funcional claro. No capturar el reporte recien abierto sin ejecutar la consulta cuando el usuario normalmente debe ejecutar una accion.
- Despues de ejecutar un reporte, esperar hasta que desaparezcan spinners, iconos de carga o regiones pendientes y hasta que el reporte muestre filas o un resultado claro. La espera maxima para reportes es de 5 minutos; si no carga en ese tiempo, emitir `No aprobado por carga incompleta` y no usar la captura en el manual.
- Si el reporte o pantalla requiere filtros para mostrar informacion, llenar o seleccionar filtros validos antes de capturar. En reportes con fechas, seleccionar un rango que devuelva datos reales de prueba o datos no sensibles.
- Si el reporte muestra filtros visibles de fecha, compania, cliente u otros criterios principales, esos filtros deben llenarse o seleccionarse antes de capturar.
- Si se documenta un formulario, abrirlo desde su menu, boton o link real y llenar los campos necesarios con datos de prueba o valores representativos antes de capturar. No mostrar formularios vacios salvo que la funcionalidad documentada sea precisamente el estado inicial.
- Si se documenta un dialogo o modal, abrirlo desde el boton, link, accion por fila o flujo real que lo inicializa. La captura debe conservar evidencia del contexto de origen cuando sea posible.
- Si se documenta una ventana, detalle o pantalla que trae informacion de un ID o registro, abrirla desde el boton o link original del registro. No construir la URL manualmente con el ID.
- Si se documenta una tabla, seccion, tab, region colapsable o acordeon nuevo, navegar hasta la pagina y activar el tab/acordeon/seccion antes de capturar. La captura debe mostrar el componente abierto y con informacion visible.
- Si la pantalla contiene varios acordeones o regiones del mismo flujo documentado, abrir los acordeones o regiones que correspondan a la tarea antes de capturar, igual que lo haria el usuario para revisar la informacion.
- Si el resultado esta dentro de un acordeon o region colapsable, abrirlo y capturar la grilla o informacion visible.
- No capturar pantallas abiertas por JavaScript directo ni por URL directa cuando exista una ruta funcional.
- No capturar paginas dialog APEX abiertas por URL directa. Si aparece `Dialog page cannot be rendered successfully`, registrar hallazgo o bloqueo y no usar la imagen en el manual.
- No capturar pantallas con errores APEX visibles, spinner, loading, regiones incompletas ni contenido pendiente de cargar.
- En reportes, ejecutar `Buscar`, `Go`, filtros, fechas o acciones necesarias hasta mostrar datos o resultado funcional claro antes de capturar.
- En formularios o cargadores, abrir desde el boton real y preparar datos de prueba o campos suficientes para que el usuario entienda como se llena la pantalla.
- Usar capturas de viewport normal de escritorio, preferiblemente entre `1366x768`, `1440x900` o proporcion similar.
- Evitar capturas full-page verticales o screenshots de scroll completo.
- En Word, insertar capturas con ancho maximo aproximado de `6.8` a `7.2` pulgadas.
- La altura visible de una captura principal no debe ocupar mas de media pagina cuando sea posible.
- Como guia, una captura principal deberia mantener aspecto horizontal o moderado, por ejemplo entre `1.25` y `1.80` de relacion ancho/alto.
- Si la pantalla es alta o requiere scroll, dividirla en varias capturas representativas:
  - encabezado, breadcrumb y barra de acciones
  - filtros o formulario principal
  - resultado, reporte o grilla
  - dialogo, modal o detalle
- No insertar una sola imagen vertical enorme que obligue a ocupar una pagina completa o varias paginas.
- Para tablas largas, capturar encabezado, filtros y primeras filas visibles. No capturar todo el reporte completo si genera una imagen demasiado alta.
- Cada imagen debe tener pie de foto breve y funcional.
- Si no hay acceso visual real, marcar la pantalla como `Pendiente de captura`; no inventar ni simular pantallas.

Cada captura incluida en el JSON fuente debe registrar:

- `capture.validated`: `true` solo cuando la pantalla fue revisada visualmente.
- `capture.navigation`: `menu`, `application-action`, `dialog-action`, `report-link`, `row-action`, `tab-action`, `accordion-action` o `workflow`.
- `capture.path`: ruta funcional usada para llegar a la pantalla.
- `capture.screenType`: `report`, `interactive-report`, `grid`, `form`, `dialog-form`, `upload-form`, `wizard` u otro tipo descriptivo.
- `capture.flowSteps`: pasos funcionales reales ejecutados antes de capturar.
- `capture.sourceScreenshot`: screenshot QA existente usado como origen de la imagen del manual.
- `capture.qaReport`: reporte o log QA existente que respalda la navegacion y el resultado visible.
- `capture.actionExecuted`: `true` para reportes luego de ejecutar `Buscar`, `Go`, filtro, tab o accion equivalente.
- `capture.rowCount`: cantidad de filas visibles despues de ejecutar la consulta; debe ser mayor a cero para reportes con datos.
- `capture.requiresFilter`: `true` si la pantalla necesita filtros para mostrar informacion.
- `capture.filtersUsed`, `capture.filterValues` o `capture.searchCriteria`: filtros o criterios usados cuando `requiresFilter` es `true`.
- `capture.dataVisible`: `true` para reportes con datos o resultado ejecutado.
- `capture.formPrepared`: `true` para formularios, dialogos o cargadores preparados con datos de prueba o campos necesarios.
- `capture.populatedFields` o `capture.preparedData`: campos, archivo o datos preparados para formularios y cargadores.
- `capture.openerPage` y `capture.openerAction`: obligatorios si la captura es de un dialogo o modal.
- `capture.originPage`, `capture.originAction` y `capture.originRecord`: obligatorios si la captura muestra informacion de un registro, ID o detalle abierto desde una fila.
- `capture.activeComponent` y `capture.componentAction`: obligatorios si la captura documenta un tab, acordeon, region colapsable o seccion que debe abrirse.
- `capture.expandedComponents`: obligatorio si la pantalla usa acordeones o regiones colapsables. Cada elemento debe registrar `name`, `expanded: true` y `rowCount` mayor a cero cuando el componente muestra tabla o reporte.
- `capture.errorsVisible`: `false`.
- `capture.loadingVisible`: `false`.
- `capture.usedDirectUrl`: `false`.
- `capture.usedJavascriptNavigation`: `false`.

El generador debe rechazar una captura aunque la imagen se vea limpia si no existe evidencia de flujo funcional. Detectar errores visuales no es suficiente; la regla principal es que la pantalla haya sido navegada y preparada como la usa el usuario final.

Guia de proporcion:

- Una captura cercana a `7.20 x 5.29` pulgadas es aceptable como pantalla de escritorio.
- Capturas cercanas a `7.20 x 11.02` o mas altas son demasiado verticales y deben reemplazarse por capturas de viewport o varias capturas parciales.

## Pantallas Nuevas

Por cada pantalla nueva:

- Indicar nombre funcional de la pantalla.
- Incluir print real con formato de pantalla de computador.
- Explicar para que sirve la pantalla.
- Explicar como ingresar o en que flujo se usa cuando este dato este disponible.
- Describir campos, filtros, regiones o secciones principales que el usuario debe conocer.
- Explicar todos los botones visibles y la accion que realiza cada uno.
- Si un boton abre dialogo, modal, region emergente, reporte, detalle u otra pagina, documentar tambien esa pantalla derivada con:
  - print real
  - funcionalidad
  - botones
  - acciones
  - forma de volver, cerrar o continuar el flujo

## Pantallas Modificadas

Por cada pantalla modificada:

- Indicar nombre funcional de la pantalla.
- Incluir print real actualizado.
- Describir que se modifico, mejoro o corrigio.
- Explicar que cambia para el usuario final.
- Explicar botones nuevos o modificados y su accion.
- Si la mejora cambia dialogos, modales, filtros, reportes, acciones por fila o flujos secundarios, documentarlos dentro del mismo cambio.

## Botones Y Acciones

Todo boton visible o accion equivalente del alcance debe explicarse con una frase funcional.

En cada cambio, pantalla o tema documentado debe existir un solo subtitulo `Botones y acciones`. Si el cambio incluye pantalla principal, secciones, dialogos o acciones derivadas, agrupar todos los botones relacionados bajo ese unico subtitulo en lugar de repetir el titulo varias veces.

Ejemplos:

- `Guardar`: registra la informacion ingresada y muestra un mensaje de confirmacion cuando el proceso finaliza correctamente.
- `Buscar`: filtra la informacion segun los criterios ingresados.
- `Limpiar`: borra los filtros o valores ingresados para iniciar una nueva consulta.
- `Ver detalle`: abre una ventana con la informacion completa del registro seleccionado.
- `Cancelar`: cierra la pantalla sin guardar cambios.

No describir botones con frases tecnicas como `ejecuta proceso`, `llama paquete`, `envia submit` o `dispara accion dinamica`.

## Dialogos, Modales Y Pantallas Derivadas

Si una accion abre un dialogo, modal o pantalla secundaria:

- Incluir captura real del dialogo o pantalla derivada.
- Explicar para que sirve.
- Explicar cada boton del dialogo.
- Explicar que ocurre al guardar, cancelar, cerrar o retornar.
- Explicar si al cerrar se actualiza la pantalla padre, reporte o resultado visible.

## Cambios Sin Pantalla

Para desarrollos solo PL/SQL, API, paquete, job o proceso automatico sin diseno web:

- No inventar pantallas ni prints.
- Documentar la mejora como funcionalidad o proceso.
- Explicar que problema resuelve o que mejora aporta al usuario o proceso operativo.
- Explicar cuando se ejecuta o donde se refleja el resultado, si se conoce.
- Explicar que debe observar el usuario final o area operativa.
- Evitar terminos tecnicos salvo que el usuario pida documentacion tecnica.

Ejemplo correcto:

`Se optimizo el proceso de carga de portafolio para que la informacion se consulte y actualice con mejor tiempo de respuesta. El usuario mantiene el mismo flujo de trabajo, pero el resultado debe mostrarse mas rapido al consultar los datos.`

Ejemplo incorrecto:

`Se modifico PK_IC_PORTAFOLIO.SP_CARGA y se ajusto el cursor CUR_PORTAFOLIO.`

## Calidad Del Word

- Usar una jerarquia clara de titulos.
- Evitar parrafos largos.
- Mantener pies de foto consistentes.
- Mantener capturas y su descripcion cercanas.
- No incluir una seccion final de `Pendientes o consideraciones` en el manual de usuario. Los pendientes, bloqueos, errores 404, autorizaciones de publicacion y observaciones tecnicas pertenecen al informe QA o a la bitacora.
- Evitar grandes espacios en blanco entre texto e imagen.
- Evitar imagenes borrosas, recortadas de forma confusa o demasiado pequenas.
- Ejecutar `scripts/audit_docx_images.py` antes de entregar el archivo.
- `scripts/build_manual_cambios.py` tambien debe rechazar imagenes que parezcan pantallas vacias, spinners, reportes sin ejecutar o errores APEX, aunque el JSON declare la captura como valida.
- Si `scripts/audit_docx_images.py` marca una imagen como posible pantalla vacia, spinner, reporte sin ejecutar o error APEX, recapturar la pantalla; no entregar el manual con esa imagen.
- Antes de entregar, verificar que el Word abra correctamente y que las imagenes no queden deformadas, cortadas ni excesivamente verticales.
