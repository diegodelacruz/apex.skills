# Contrato De Evidencia Documental

## Entrada Minima

Cada documento requiere un manifiesto JSON con:

- `documentId`, `deliverableId`, `profile`, `audience`, `purpose`.
- `baseline`: versiones, SHA, release o fecha de corte que identifica lo documentado.
- `output`: ruta y formato esperado.
- `sections`: una fila por tema, pantalla, flujo, API, componente, objeto o procedimiento exigido.

Cada fila de `sections` contiene:

- `id`, `title`, `sourceEvidence` y `status`.
- `kind`: `screen`, `flow`, `api`, `architecture`, `data`, `operation`, `security`, `release` u otro valor descriptivo.
- `sourceEvidence`: rutas o identificadores verificables; no usar frases generales como `segun QA`.
- `status`: `ready`, `documented` o `not-applicable` con `justification`.
- Para pantallas, `capture` y `qaEvidence` vigentes.
- Para contenido tecnico, contrato, fuente, especificacion, inventario o evidencia de ejecucion identificable.

## Reglas

- Una fila sin evidencia no puede pasar a `documented`.
- Una captura no prueba por si sola la regla de negocio; debe relacionarse con el flujo o QA que la produjo.
- Un fragmento de codigo no prueba por si solo el comportamiento productivo; declarar la version y el ambiente validado.
- Las brechas se reportan al orquestador invocador con `documentId`, `sectionId`, evidencia faltante y propietario esperado. El skill no decide a que agente tecnico llamar.
- Una excepcion `not-applicable` necesita justificacion concreta.

Ejecutar:

```powershell
python <SKILL_ROOT>/scripts/validate_documentation_manifest.py --manifest <ARCHIVO_JSON>
```
