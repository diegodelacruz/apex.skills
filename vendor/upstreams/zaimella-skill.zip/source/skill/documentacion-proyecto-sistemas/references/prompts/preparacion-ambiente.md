# Preparacion De Ambiente

1. Recibir del orquestador plan documental, ubicacion autorizada de entradas y salidas, y linea base. No inferir ni crear `<PROJECT_ROOT>` o su arquitectura.
2. Confirmar acceso de solo lectura a handoffs, evidencia QA, capturas, especificaciones y fuentes requeridas.
3. Verificar Python y dependencias de los scripts que se usaran.
4. Para DOCX, PDF o hojas de calculo, verificar el skill de artefacto correspondiente y su renderizador.
5. Crear o validar el manifiesto con `scripts/validate_documentation_manifest.py`.
6. No copiar credenciales, exports sensibles ni datos productivos al documento o a la carpeta del skill.

La preparacion no ejecuta QA ni modifica el sistema documentado.
