# Uso En AGENTS.md

## Contenido Para AGENTS.md

Usar `documentacion-proyecto-sistemas` para crear o actualizar manuales funcionales y documentacion tecnica entregable. Entregarle plan documental, audiencia, perfil, linea base, handoffs y evidencia validados. El skill redacta y audita documentos; no desarrolla, no ejecuta QA y no coordina skills tecnicos. Una brecha vuelve al orquestador invocador con la seccion y evidencia faltantes.

## Preparacion O Verificacion

- Confirmar que el manifiesto identifica todas las secciones y su evidencia.
- Mantener perfiles `funcional`, `tecnico` y `mixto` dentro del mismo plan y skill.
- Validar el artefacto final mediante renderizado antes de declararlo completo.
- No generar documentacion desde recuerdos de conversacion ni mezclar versiones.
