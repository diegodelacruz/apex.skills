# Documentacion Tecnica Entregable

## Orientacion

Documentar para quien operara, integrara, administrara, soportara o mantendra la solucion. El documento debe poder leerse sin conocer la conversacion que origino el proyecto.

## Cobertura Segun Alcance

- Arquitectura: contexto, componentes, responsabilidades, limites, dependencias, flujos y decisiones relevantes.
- API o integracion: proposito, autenticacion, ambientes, contratos, ejemplos sanitizados, codigos de respuesta, errores, idempotencia, limites y observabilidad.
- Datos: entidades, relaciones, diccionario, estados/catalogos, propietarios, retencion, sensibilidad y trazabilidad.
- Instalacion o despliegue: prerrequisitos, configuracion externa, versiones, secuencia, validacion, rollback y responsables.
- Operacion: inicio, monitoreo, alertas, reproceso, conciliacion, contingencia, escalamiento y evidencia esperada.
- Seguridad: actores, permisos, secretos externos, auditoria, segregacion y restricciones sin exponer credenciales.
- Soporte: sintomas, diagnosticos seguros, limites de accion, rutas de evidencia y responsables.

## Redaccion

- Explicar primero el resultado y luego el mecanismo.
- Definir siglas y nombres internos la primera vez.
- Usar diagramas solo cuando aclaren relaciones, secuencias o dependencias.
- Identificar comandos destructivos o productivos y sus autorizaciones; no convertir el documento en una coleccion de comandos sin contexto.
- Sanitizar usuarios, hosts, tokens, datos personales y secretos.
- Distinguir estado actual, objetivo futuro y decision pendiente.
