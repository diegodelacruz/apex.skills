---
name: documentacion-proyecto-sistemas
description: Crear, actualizar, auditar y empaquetar entregables documentales funcionales y tecnicos de proyectos de Sistemas. Usar para manuales de usuario, manuales de cambios, guias operativas, arquitectura, APIs, integraciones, modelos de datos, instalacion, soporte, release notes o documentos mixtos que deban entregarse a usuarios funcionales, tecnicos u operativos a partir de alcance, versiones y evidencia validados.
---

# Documentacion De Proyectos De Sistemas

## Limite de arquitectura

El orquestador entrega el plan documental, manifiesto, rutas de evidencia y salida autorizada. Este skill no crea ni administra la arquitectura, contratos, bitacoras, paquetes o handoffs del proyecto; redacta, renderiza, audita y devuelve el entregable en la ubicacion recibida.

Crear documentos funcionales, tecnicos o mixtos como entregables del mismo proyecto. Todos deben ser entendibles para su audiencia, corresponder a una linea base identificada y conservar trazabilidad con evidencia real.

## Limites

Las rutas citadas en ejemplos o referencias son solo ejemplos de insumos y salidas. El orquestador decide y entrega sus ubicaciones reales; el skill no las crea ni las reconfigura.

- Redactar, actualizar, renderizar, auditar y empaquetar documentos. No desarrollar, corregir ni probar el sistema documentado.
- Consumir el plan documental del proyecto y handoffs aprobados de los orquestadores de dominio. No invocar ni coordinar sus skills internos.
- Solicitar al contexto invocador la evidencia faltante. No pedir directamente a QA que corrija desarrollo ni inventar pantallas, comportamientos, endpoints, objetos, versiones o resultados.
- Mantener una sola linea base por entregable. No mezclar capturas, contratos o explicaciones de versiones distintas sin declararlo y separarlo expresamente.

## Seleccion De Perfil

Leer `references/perfiles-entregables.md` y seleccionar:

- `funcional`: explica al usuario que hace el sistema y como ejecutar sus flujos.
- `tecnico`: explica arquitectura, interfaces, datos, instalacion, operacion, seguridad o soporte para una audiencia tecnica.
- `mixto`: contiene ambas perspectivas en secciones claramente separadas, con la misma linea base.

Usar un solo skill y un solo manifiesto aunque el proyecto entregue varios documentos o perfiles.

## Flujo Obligatorio

1. Leer el plan documental, alcance, audiencia, criterios, formato, salida y linea base. Si el proyecto usa `Gestion-Proyectos`, recibir `proyecto/06_seguimiento/documentacion/plan.md` y los handoffs asociados.
2. Leer `references/contrato-evidencia.md` y construir o validar el manifiesto documental. Ejecutar `scripts/validate_documentation_manifest.py --manifest <ARCHIVO>`.
3. Contrastar cada afirmacion con contratos, handoffs, QA, capturas, especificaciones, codigo o evidencia operativa identificada. Separar hechos confirmados, decisiones y supuestos autorizados.
4. Aplicar la referencia del perfil. Para manual funcional con capturas, leer `references/manual-funcional.md`; para documentacion tecnica, leer `references/documentacion-tecnica.md`.
5. Crear el artefacto en el formato solicitado. Para Word usar el skill `documents`; para PDF usar `pdf`; para hojas de calculo usar `spreadsheets`. Seguir sus ciclos de renderizado y verificacion visual.
6. Ejecutar la revision de `references/calidad-documental.md`, validar cobertura contra el manifiesto y confirmar que todas las salidas pertenecen a la misma linea base.
7. Entregar rutas de archivos, perfil, audiencia, version documentada, evidencia fuente, cobertura y cualquier brecha real.

## Resultados

- `DOCUMENTACION_COMPLETA`: todas las secciones y evidencias requeridas estan cubiertas y el artefacto paso revision de contenido y presentacion.
- `DOCUMENTACION_INCOMPLETA`: falta una definicion, linea base o evidencia que el skill no puede producir. Identificar exactamente la fila o seccion y devolverla al contexto invocador.
- `DOCUMENTACION_NO_APLICA`: solo cuando el plan del proyecto contiene justificacion aprobada.

Un documento no se declara completo porque el archivo exista. Debe cubrir el manifiesto, ser entendible para su audiencia y pasar la validacion visual del formato final.

## Recursos

- `references/perfiles-entregables.md`: perfiles y tipos de entregable.
- `references/contrato-evidencia.md`: manifiesto y reglas de trazabilidad.
- `references/manual-funcional.md`: redaccion y capturas para usuario final.
- `references/documentacion-tecnica.md`: contenido tecnico orientado a entrega.
- `references/calidad-documental.md`: gate final comun.
- `scripts/build_manual_cambios.py`: generador reutilizable de manual funcional desde JSON.
- `scripts/audit_docx_images.py`: auditor de imagenes incorporadas en Word.
- `scripts/validate_documentation_manifest.py`: validador de cobertura, linea base y evidencia.
- `assets/documentation-manifest.template.json`: contrato inicial reutilizable por documento.
