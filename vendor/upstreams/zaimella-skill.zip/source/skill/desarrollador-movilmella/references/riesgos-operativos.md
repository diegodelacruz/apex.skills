# Riesgos Operativos Movilmella

## Riesgos criticos

- Perder trabajo offline pendiente.
- Limpiar SQLite antes de enviar datos al backend.
- Compilar PROD con entrypoint incorrecto.
- Compilar o instalar desde un worktree en vez del checkout de integración versionado en GitHub, o hacer downgrade involuntario de la aplicación.
- Acumular `build/`, `.dart_tool/`, Gradle, `.cxx` o APK/AAB en worktrees de tarea por ejecutar comandos Flutter/Android en la ruta equivocada.
- Cambiar ambiente sin advertir al usuario.
- Romper reanudacion de visita en curso.
- Sobrescribir hora real de inicio de visita.
- Permitir cierre con encuestas obligatorias pendientes.
- Guardar ubicacion invalida como real.
- Exponer credenciales, token, usuario o payload sensible en logs.
- Subir capturas, APKs, temporales o archivos generados.

## Gates antes de acciones riesgosas

Antes de tocar SQLite:

- identificar tablas afectadas
- revisar `onCreate`, `onUpgrade`, helpers y limpieza relacionada
- validar si hay datos pendientes
- evitar `deleteDatabase`, `DROP TABLE` o limpiezas generales salvo autorizacion explicita y justificacion

Antes de tocar sincronizacion:

- identificar modulo de envio/descarga
- validar orden de envio, limpieza y refresco
- conservar datos si hay error parcial
- revisar mensajes visibles para el usuario

Antes de tocar GPS:

- validar permisos Android
- validar servicio foreground/background
- validar coordenadas invalidas, baja precision y timeout
- validar justificacion fuera de rango

Antes de tocar PROD:

- confirmar autorizacion explicita
- antes de todo APK PROD, publicar el commit candidato de la tarea en GitHub y verificar el SHA remoto; bloquear si quedan commits locales pendientes
- confirmar comando con `-t lib/main_prod.dart`
- confirmar URL productiva
- no ejecutar cambios destructivos ni enviar datos de prueba

Antes de compilar, instalar o ejecutar QA Android:

- seleccionar en `desarrollo.md` el checkout de integración versionado en GitHub y, en `docs/tareas/<ID_TAREA>/tarea.md`, un único candidato con rama remota, SHA completo publicado y `version:` de `pubspec.yaml`
- comparar esos datos con el checkout de integración desde el que se ejecutará Flutter; nunca usar un worktree, aunque comparta el ID de tarea
- comprobar que paquete y `versionName`/`versionCode` del APK generado corresponden al candidato
- comparar la versión del APK con la instalada en el dispositivo antes y después de instalar
- bloquear downgrade o discrepancia de candidato; no usar `-d` ni desinstalar para sortearlo sin autorización explícita registrada

## Archivos y carpetas excluidos

No versionar ni mover al skill:

- `build/`
- `.dart_tool/`
- `android/app/.cxx/`
- APKs o app bundles generados
- `tmp_*`
- capturas de pantalla temporales
- logs con datos sensibles
- `.bak`
- credenciales locales
- exports o documentos de prueba especificos de un caso

Los worktrees de tarea deben contener solo los archivos versionados y cambios de código de su tarea. No son destino de compilación, QA ni cachés; no dejar en ellos `build/`, `.dart_tool/`, `.gradle/`, `android/app/.cxx/`, APK/AAB u otras salidas pesadas. Tras una sesión, solo se pueden eliminar esos derivados cuando se confirme que fueron generados por ella; los preexistentes requieren autorización del usuario.

## Separacion entre skill y contexto del proyecto

Debe quedar claro donde vive cada tipo de informacion:

- En el skill: reglas reutilizables, gates, comandos estandar, criterios de validacion, riesgos permanentes y referencias tecnicas generalizadas.
- En `<PROJECT_CONTEXT>/AGENTS.md` y `desarrollo.md`: reglas vigentes, checkout, rama de integracion, toolchain, convenciones y decisiones de contexto.
- En `<PROJECT_CONTEXT>/docs/bitacora.md`: tareas, avances, bloqueos, validaciones, evidencias, decisiones y lecciones aprendidas.
- En `<PROJECT_CONTEXT>/docs/evidencias/<ID_TAREA>/`: capturas, trazas, notas y archivos auxiliares necesarios para una validacion funcional.
- En `<PROJECT_CONTEXT>/docs/logs/`: logs tecnicos sin secretos ni datos sensibles.
- En carpetas temporales o rutas locales no versionadas: APKs y artefactos pesados que no deben entrar al repositorio.

La raiz del checkout Flutter no debe usarse como carpeta de pruebas. Antes de cerrar una tarea, revisar si se generaron `tmp_*`, capturas, logs o salidas auxiliares en la raiz y moverlos al contexto o eliminarlos si son descartables y fueron creados por la sesion actual.

No mover al skill:

- detalles de una tarea puntual
- IDs de visitas, PDV, usuarios, coordenadas, capturas, logs o payloads reales
- estado de una rama especifica
- resultados de una prueba concreta
- APKs, builds o temporales
- configuraciones personales o credenciales

Si una regla nace de un caso real, primero convertirla en regla general. Ejemplo: no guardar `la visita 42672 fallo al cerrar`; registrar como regla reusable `el cierre de visita debe validar encuestas obligatorias pendientes antes de marcar la visita como completada`.

## Logs

Permitir logs tecnicos temporales solo si ayudan al diagnostico y no exponen secretos.

Antes de cerrar:

- retirar logs verbosos innecesarios
- truncar payloads si quedan logs de error
- no imprimir token de autorizacion
- no dejar credenciales o passwords en texto claro

## Errores, pruebas y lecciones aprendidas

Registrar una leccion aprendida en `<PROJECT_CONTEXT>/docs/bitacora.md` cuando el trabajo deje un aprendizaje reutilizable para Movilmella.

Eventos que obligan registro:

- error funcional reproducible en visitas, encuestas, GPS, justificaciones, sincronizacion, SQLite, Finalizar Dia, ORDS/APEX o build Android
- bloqueo por ambiente, emulador, FVM, Gradle, APK, permisos Android, servicio web, credencial autorizada o dato de prueba faltante
- retrabajo causado por regla ambigua, validacion incompleta, flujo no probado en Android o diferencia entre DEV y PROD
- excepcion aprobada por el usuario, especialmente en PROD, SQLite, limpieza de datos, logs, GPS o sincronizacion
- prueba de regresion agregada por un defecto que podria repetirse
- diferencia relevante entre comportamiento offline, datos locales SQLite, payload enviado y respuesta ORDS/APEX
- selección errónea del checkout de integración, worktree, SHA, versión `pubspec` o APK durante build/instalación Android

Formato minimo:

- sintoma o error observado
- causa raiz confirmada, o hipotesis marcada como pendiente si aun no esta confirmada
- correccion aplicada o decision tomada
- prueba ejecutada y resultado
- evidencia o ruta del artefacto, sin incluir capturas pesadas ni APKs dentro del skill
- riesgo residual, pendiente o regla reusable propuesta

Reglas:

- No registrar contrasenas, tokens, payloads sensibles completos, datos personales, ubicaciones reales sensibles ni capturas con informacion no autorizada.
- No convertir observaciones aisladas sin evidencia en reglas permanentes; marcarlas como `pendiente de confirmar`.
- Si la leccion requiere endurecer el skill, proponer el cambio en el repositorio de skills y no guardar archivos de caso dentro de `desarrollador-movilmella`.
- Si se corrige un hallazgo dentro del alcance, volver a ejecutar el escenario afectado y registrar la prueba de regresion.

## Git

- Revisar estado local antes de editar y antes de cerrar.
- No revertir cambios existentes del usuario.
- No hacer commit ni push salvo instruccion explicita, excepto que el usuario solicite un APK PROD: en ese caso, publicar primero y obligatoriamente el candidato exacto de la tarea antes de compilarlo.
- Si hay cambios no relacionados, ignorarlos y reportar solo los archivos tocados por la tarea.
