# Prompt De Uso - desarrollador-movilmella

Usar este prompt en el contexto Movilmella que contiene `AGENTS.md` y `desarrollo.md`; no copiarlo al checkout Flutter.

## Seccion 1 - Contenido Para AGENTS.md

Copiar o fusionar este bloque en el `AGENTS.md` o `agents.md` del contexto:

```markdown
# Uso Obligatorio De desarrollador-movilmella

Usar el skill `desarrollador-movilmella` para cualquier cambio, correccion, diagnostico, validacion, build, prueba Android o documentacion de Movilmella.

## Fuente De Verdad

- `desarrollador-movilmella` es la fuente de verdad para frontend Flutter/FVM, arquitectura Movilmella, visitas, encuestas, GPS, justificaciones, sincronizacion, SQLite, modo offline, Finalizar Dia, builds Android DEV/PROD y QA movil provisional en Android fisico USB.
- Los worktrees se usan solo para implementar. Todo build, instalacion o QA Android se ejecuta desde el checkout de integración declarado en `desarrollo.md`, con el SHA publicado en GitHub y la versión declarada en `tarea.md`; no compilar desde un worktree.
- Cada solicitud de APK PROD autoriza y exige publicar antes el candidato exacto de la tarea: inventario exclusivo, validaciones, commit/push si contiene cambios aun no publicados y verificación del SHA remoto. Si el candidato no queda publicado, bloquear el build PROD.
- Para QA con login, usar el preflight del skill: prepara TEST, obtiene la credencial solo en memoria privada, espera ambos campos Android y confirma el usuario exacto antes de autenticar. Registrar solo `LOGIN_PREFLIGHT_READY` y datos no sensibles.
- No copiar reglas tecnicas extensas en este archivo; leerlas desde `skill/desarrollador-movilmella/SKILL.md` y sus `references/`.

## Coordinacion Con desarrollador-apex

Usar tambien `desarrollador-apex` cuando el alcance toque ORDS/APEX, paquetes Oracle, tablas, vistas, permisos, datos enviados o datos recibidos por APIs.

Movilmella valida el cliente Flutter y su QA movil provisional. `desarrollador-apex` valida backend, parametros recibidos y persistencia en Oracle dentro del modulo ORDS `MVZM`.
```

## Seccion 2 - Verificacion De Contexto Y Ambiente

El orquestador Movilmella prepara la arquitectura, contratos, bitacora y rutas. Este skill solo verifica los insumos recibidos y devuelve resultados; no crea ni administra esas ubicaciones.

### 1. Instalar O Actualizar El Skill

Confirmar repositorio descargado con:

```text
skill/desarrollador-movilmella/
```

Instalar o actualizar `desarrollador-movilmella` desde `skill/desarrollador-movilmella/` en la instalacion activa de Codex.

### 2. Preparar Proyecto Movilmella

Confirmar en `desarrollo.md`:

```text
- contexto de trabajo;
- checkout de integración Flutter local, separado de los worktrees y origen de GitHub;
- remoto canonico `https://github.com/zaimella/Zaimella-Movilmella`;
- repositorio APEX/ORDS relacionado cuando aplique.
```

Crear o validar:

```text
docs/bitacora.md
docs/tareas/
docs/evidencias/
docs/logs/
docs/pases-produccion/
```

No guardar APKs, `build/`, `.dart_tool/`, `.cxx/`, logs locales, capturas temporales, tokens, payloads sensibles ni datos reales en commits.

### 3. Validar Toolchain

Ejecutar:

```text
skill/desarrollador-movilmella/references/prompts/preparacion-ambiente.md
```

Confirmar FVM, Flutter y ADB. Antes de toda QA funcional, solicitar al usuario que conecte el celular Android de pruebas por USB y confirmar que ADB lo detecta con estado `device`; para cambios visibles, preparar una APK DEV nueva desde el checkout de integración. Contrastar ruta, SHA publicado, `pubspec.yaml`, paquete y versión del APK/dispositivo contra el candidato de `tarea.md`, bloqueando downgrade o discrepancias. Un emulador solo permite smoke tecnico aislado y no sustituye la QA funcional.

### 4. Registrar Inicio Operativo

Registrar en `<PROJECT_CONTEXT>/docs/bitacora.md`:

- tarea;
- rama;
- archivos/modulos previstos;
- ambiente DEV/PROD;
- validacion esperada;
- si requiere coordinacion con `desarrollador-apex`.

### 5. Entrega De Preparacion

Informar:

- skill instalado/actualizado;
- proyecto localizado;
- toolchain validada o bloqueo;
- bitacora preparada;
- celular USB solicitado y detectado por ADB, o impedimento externo documentado.
