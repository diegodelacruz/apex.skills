# Preparacion De Ambiente - desarrollador-movilmella

Usar este prompt antes de trabajar en Movilmella con el skill `desarrollador-movilmella`.

## Repositorio Descargado

Este prompt se ejecuta desde un contexto donde el usuario ya descargo o clono el repositorio de skills y tiene disponibles:

```text
skill/
prompts/
```

La fuente local del skill es:

```text
skill/desarrollador-movilmella/
```

## Instalar O Actualizar El Skill

- Preparar el ambiente incluye instalar o actualizar el skill `desarrollador-movilmella`.
- Si el skill no esta instalado, instalarlo desde `skill/desarrollador-movilmella/` del repositorio descargado en la instalacion activa de Codex.
- Si el skill ya existe, validar que la instalacion activa corresponde a la fuente vigente de `skill/desarrollador-movilmella/` del repositorio descargado; si no coincide, actualizarla antes de continuar.
- No reemplazar este skill con instrucciones improvisadas ni con prompts copiados al proyecto.

## Requisitos Previos

- Confirmar el contexto que contiene `AGENTS.md` y `desarrollo.md`, y leer desde este ultimo la ruta local del checkout Flutter. No asumir una ruta fija.
- Para build, instalacion o QA Android, confirmar que `desarrollo.md` declara el checkout de integración que se versiona a GitHub, y que `docs/tareas/<ID_TAREA>/tarea.md` declara un único candidato Flutter de ese checkout: rama remota, SHA completo publicado, `pubspec.yaml` `version:`, flavor, entrypoint y paquete Android. Los worktrees son solo para implementar: no seleccionar ninguno por el ID del caso ni por haber sido usado en una sesión anterior.
- Para APK PROD, preparar acceso GitHub para publicar el candidato de la tarea: la solicitud de build autoriza commit/push solo del inventario de esa tarea; el SHA debe verificarse en la rama remota autorizada antes de compilar.
- Antes de comandos Flutter/Gradle/Android, ejecutar `git rev-parse --show-toplevel` y bloquear si no coincide con el checkout de integración. Los worktrees deben conservar solo código y configuración versionable de la tarea; no generar ni conservar en ellos `build/`, `.dart_tool/`, Gradle, `.cxx`, APK/AAB o cachés pesadas.
- Para QA con login, confirmar que el contexto conserva `docs/scripts/preparar_ambiente_test_movilmella.py`, que Python puede ejecutar `scripts/preflight_movilmella_login.py` del skill y que ADB tiene un dispositivo físico autorizado. El preflight obtiene la credencial solo en memoria privada; no usar archivos, variables persistentes, bitácoras ni capturas para contraseñas.

```text
- Remoto canonico: `https://github.com/zaimella/Zaimella-Movilmella`.
- El checkout contiene solo codigo, configuracion tecnica y archivos versionados; contratos, bitacora, evidencias, pases y temporales viven en el contexto.
```

- Confirmar Flutter via FVM.
- Confirmar Android SDK y ADB, y solicitar al usuario que conecte un celular Android de pruebas por USB para la QA funcional. El usuario debe habilitar Depuracion USB y aceptar la huella RSA cuando Android la solicite.
- Confirmar acceso al backend DEV/PROD segun el alcance sin guardar credenciales en el repositorio.
- Confirmar que no se versionaran APKs, `build/`, `.dart_tool/`, `.cxx/`, logs locales, capturas temporales, tokens, payloads sensibles ni datos reales de visitas/PDV.
- Si el trabajo depende de documentacion externa vigente, confirmar Context7.
- Si el cambio es mediano, grande, multi-skill, productivo planificado o ambiguo, confirmar OpenSpec y usar `openspec/` dentro del proyecto Movilmella.

## Validaciones Iniciales

Desde el checkout Flutter declarado en `desarrollo.md`:

```powershell
git status --short --branch
fvm flutter --version
fvm flutter pub get
fvm flutter analyze
adb devices
```

Si el cambio toca modelos generados, preparar:

```powershell
fvm flutter pub run build_runner build --delete-conflicting-outputs
```

## Validacion Android Rapida En Celular USB

Para cambios visibles o funcionales acotados, preparar smoke Android DEV:

```powershell
fvm flutter build apk --debug --flavor dev -t lib/main_dev.dart
powershell -ExecutionPolicy Bypass -File .\tools\install-and-run-apk.ps1 -ApkPath build\app\outputs\flutter-apk\app-dev-debug.apk
```

Antes de compilar, solicitar la conexion del celular por USB y confirmar que `adb devices` lo muestra con estado `device`. Instalar la APK nueva en ese celular. No usar APK viejo despues de cambios de codigo. Un emulador solo admite smoke tecnico aislado; no sustituye QA funcional ni permite cerrar una validacion visible.

Antes de instalar, entrar al checkout de integración, ejecutar `git fetch` y contrastar ruta/rama remota/SHA publicado/`pubspec.yaml` con el candidato, y paquete + `versionName`/`versionCode` del APK generado. Consultar la versión instalada y bloquear downgrade o discrepancia; no usar `adb install -d` ni desinstalar sin autorización explícita registrada.

## Backend ORDS/APEX

Si la tarea toca endpoints ORDS/APEX, parametros, payloads, persistencia Oracle, permisos o errores backend, preparar tambien el uso coordinado de `desarrollador-apex`.

Movilmella valida solo el cliente Flutter. `desarrollador-apex` consulta, valida o modifica exclusivamente las APIs ORDS del modulo `MVZM`, sus parametros, los paquetes usados por ellas y la persistencia Oracle.

## Resultado Esperado

Antes de usar `desarrollador-movilmella`, el contexto debe tener:

- proyecto localizado;
- rama y estado local revisados;
- FVM/Flutter/ADB disponibles o bloqueo claro;
- bitacora `<PROJECT_CONTEXT>/docs/bitacora.md` lista o criterio para crearla;
- celular Android USB solicitado y ADB listo, o impedimento externo documentado;
- politica de artefactos excluidos clara.
