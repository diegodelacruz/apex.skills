# Validacion Android Movilmella

## Toolchain local

Fuentes principales: `AGENTS.md` y `desarrollo.md` del contexto Movilmella. El checkout Flutter se obtiene de este ultimo.

- FVM operativo.
- Android SDK: `C:\Android\Sdk`.
- ADB: `C:\Android\Sdk\platform-tools\adb.exe`.
- JDK 17 operativo.
- Dispositivo fisico QA: obligatorio para QA funcional; solicitar al usuario que lo conecte por USB antes de iniciar la prueba, identificar su serial con `adb devices` y no asumir uno fijo.
- Emulador `Movilmella_AOSP_Fast_API34`: disponible solo para smoke tecnico aislado; no sustituye el QA funcional.

Scripts locales:

- `tools/start-android-emulator.ps1`
- `tools/install-and-run-apk.ps1`
- `tools/build-install-run.ps1`

## Comandos base

Ejecutar los comandos Flutter, Gradle y ADB solo desde el checkout de integración declarado en `desarrollo.md`. Antes de cualquiera, confirmar `git rev-parse --show-toplevel`; si resulta un worktree de tarea, bloquear. Los worktrees no son una caché de builds ni un ambiente Android.

Analisis:

```powershell
fvm flutter analyze
```

Tests:

```powershell
fvm flutter test
```

Build PROD correcto:

```powershell
fvm flutter build apk --flavor prod --release -t lib/main_prod.dart
```

## Publicacion obligatoria antes de APK PROD

Toda solicitud de generar APK PROD autoriza y exige publicar el candidato Flutter de esa tarea antes de compilar. Desde el checkout de integracion, hacer `git fetch`, confirmar el predecesor de `origin/main`, revisar estado/diff/staged, stagear solo el inventario de la tarea, validar y, si existen cambios aun no publicados, crear el commit y hacer push directo a `origin/main` (o usar el PR solo si el usuario lo solicita o una proteccion lo exige). No usar `git add .`, incluir cambios ajenos ni crear commits vacios.

Tras el push, volver a hacer `git fetch` y comprobar que el SHA completo del candidato esta en la rama remota autorizada. Registrar SHA publicado, rama y resultado del push en `docs/tareas/<ID_TAREA>/tarea.md` y en `docs/bitacora.md`; solo entonces ejecutar el build PROD. Si no se puede publicar o verificar el SHA, bloquear el APK PROD: nunca compilarlo desde commits locales pendientes de GitHub.

Build DEV:

```powershell
fvm flutter build apk --flavor dev --release -t lib/main_dev.dart
```

Instalar y abrir APK:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\install-and-run-apk.ps1 -ApkPath build\app\outputs\flutter-apk\app-prod-release.apk
```

## Advertencia sobre script local

`tools/build-install-run.ps1` compila con `--flavor` y `--dart-define`, pero puede no pasar `-t lib/main_prod.dart`.

Para validacion productiva, revisar el script antes de usarlo. Si no incluye `-t lib/main_prod.dart`, usar el comando manual correcto o corregir el script cuando el alcance lo permita.

## Flujo de validacion funcional

Cuando el usuario pida probar, ejecutar o validar:

1. Abrir `desarrollo.md` y `docs/tareas/<ID_TAREA>/tarea.md`. El único origen permitido para el build es el checkout de integración declarado en `desarrollo.md`, no el worktree de la tarea. Registrar su ruta absoluta, rama remota, SHA completo publicado en GitHub, valor `version:` de `pubspec.yaml`, flavor, entrypoint y APK esperado.
2. Desde ese checkout de integración, ejecutar `git fetch`, revisar `git status`, `git branch --show-current`, `git rev-parse HEAD`, la referencia remota autorizada y `pubspec.yaml`. Bloquear si hay cambios locales, el SHA no está publicado en el remoto, o cualquiera de ruta/rama/SHA/versión no coincide con el contrato. No compilar ni instalar ante ambigüedad entre worktrees.
3. Elegir el nivel de validacion: smoke rapido, flujo funcional o build release.
4. Compilar APK nuevo del nivel elegido desde el checkout verificado. Inspeccionar el APK generado y comprobar que su paquete, `versionName` y `versionCode` corresponden al `pubspec.yaml` registrado.
5. Solicitar al usuario que conecte el dispositivo fisico Android por USB y verificar que ADB lo muestre con estado `device`. Si no esta disponible, registrar `Impedimento externo`; no reemplazar el QA funcional con emulador.
6. Consultar en el dispositivo el paquete del candidato y su versión actual. Si el APK candidato es menor, pertenece a otro paquete o no coincide con el contrato, bloquear. No usar `adb install -d`, no desinstalar ni cambiar de checkout para eludir la comparación sin autorización explícita y registrada.
7. Instalar APK nuevo con el script local o `adb -s <SERIAL> install -r <APK>`, y comprobar nuevamente el paquete y versión instalada.
8. Abrir app.
9. Recorrer el flujo indicado.
10. Revisar logs si aparece error funcional.
11. Corregir.
12. Recompilar y repetir.

No cerrar con "compila" si el cambio toca UI, GPS, visitas, encuestas, sincronizacion o SQLite.

## QA Movil En Dispositivo Fisico

### Preflight de inicio de sesión

Antes de borrar datos o intentar un login QA, ejecutar `scripts/preflight_movilmella_login.py` del skill con el preparador del contexto, la compañía, usuario si el caso lo exige, serial ADB y package del flavor. El script hace plan/ejecución TEST con acceso MVZM, espera que el login exponga los dos `EditText`, coloca la credencial privada sin imprimirla y confirma el usuario completo en la UI.

No repetir manualmente nombres de usuario parecidos, no copiar contraseñas a bitácoras ni capturas y no asumir que el campo está listo tras abrir la app. Solo después de `LOGIN_PREFLIGHT_READY` enviar el login, esperar la descarga inicial y comprobar visitas/encuestas/PDV esperados del contrato.

Conexion a solicitar antes de cada QA y configuracion inicial a cargo del usuario:

1. Conectar un Android de pruebas por USB cuando Codex solicite iniciar QA.
2. Habilitar una sola vez `Opciones de desarrollador > Depuracion USB`.
3. Aceptar una sola vez la huella RSA del equipo cuando Android la solicite.
4. Usar cuenta y datos DEV/TEST autorizados.

Ejecucion del QA:

1. Ejecutar `adb devices`; continuar solo si aparece un dispositivo con estado `device`.
2. Verificar contra `desarrollo.md` y `tarea.md` que se está en el checkout de integración, con SHA publicado y `version:` de `pubspec.yaml` del candidato Flutter antes de compilar; nunca en el worktree de tarea.
3. Compilar APK DEV nueva, registrar ruta, paquete y `versionName`/`versionCode`, y compararlos con el candidato.
4. Consultar el paquete y versión actualmente instalados; bloquear cualquier downgrade o discrepancia no autorizada.
5. Instalar con reemplazo, volver a verificar paquete/versión, abrir Movilmella y recorrer el caso definido en la tarea.
6. Capturar pantalla y extraer `logcat` filtrado si aparece un error, sin incluir tokens ni datos sensibles.
7. Registrar `Aprobado`, `No aprobado` o `Impedimento externo` en la bitacora y guardar evidencia en `<PROJECT_CONTEXT>/docs/evidencias/<ID_TAREA>/`.

El QA puede operar integramente desde ADB una vez conectado el dispositivo. Pedir intervencion del usuario para conectar el USB, y solo adicionalmente para MFA, permisos del sistema no aceptables de forma segura, camara, GPS fisico real o decisiones funcionales.

## Ambiente liviano de validacion Android

Objetivo: detectar errores basicos de compilacion, arranque, navegacion, pantalla en blanco/gris, overflow evidente, boton roto y regresion del flujo afectado con una APK DEV en el celular USB, sin ejecutar siempre un ciclo release pesado.

Usar este ambiente por defecto para cambios de UI, navegacion, textos, validaciones simples, BLoC visible, listas, formularios y correcciones funcionales acotadas:

- Solicitar primero la conexion del celular Android por USB y confirmar `adb devices` con estado `device`.
- No ejecutar `flutter clean` salvo que el fallo lo justifique.
- No borrar datos de la app ni SQLite salvo autorizacion o necesidad clara de la prueba.
- No recompilar PROD release si el cambio se puede validar con DEV/debug y no depende de ambiente productivo, firma, minificacion o endpoint PROD.
- Usar `fvm flutter analyze` antes del APK cuando el cambio toque Dart.
- Usar build debug DEV para smoke rapido cuando aplique:

```powershell
fvm flutter build apk --debug --flavor dev -t lib/main_dev.dart
```

- Instalar y abrir el APK nuevo en el dispositivo USB:

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\install-and-run-apk.ps1 -ApkPath build\app\outputs\flutter-apk\app-dev-debug.apk
```

Smoke minimo obligatorio:

- la app instala sin error
- la app abre sin crash
- no queda pantalla blanca, gris o loader infinito en el flujo afectado
- la pantalla afectada renderiza sin overflow evidente
- el boton, navegacion o accion corregida responde
- si el cambio toca datos locales, no se pierde estado pendiente sin autorizacion
- si aparece error, revisar logs, corregir y repetir el smoke

El emulador `Movilmella_AOSP_Fast_API34` puede usarse solo para diagnostico o smoke tecnico aislado, previa excepcion expresa registrada en la bitacora. No reemplaza la prueba funcional en celular USB ni permite cerrar un cambio visible como validado.

Usar validacion release/prod completa solo cuando:

- el cambio toca `main_prod.dart`, flavors, endpoints, certificados, permisos Android, Gradle, build, dependencias nativas o configuracion de release
- el usuario pide APK productivo
- el defecto solo aparece en PROD/release
- se va a publicar o entregar APK
- se valida una diferencia DEV contra PROD

## Registro de pruebas y regresiones

- Registrar en `<PROJECT_CONTEXT>/docs/bitacora.md` cada validacion relevante con candidato (checkout, rama, SHA, `pubspec`), ambiente, comando, APK generado (paquete y versión), versión previa/posterior del dispositivo, flujo recorrido, resultado y bloqueo si existe.
- Si una prueba falla y luego se corrige, repetir el mismo flujo en Android y registrar la prueba de regresion.
- Para visitas, encuestas, GPS, sincronizacion, SQLite y Finalizar Dia, registrar tambien precondiciones de datos: visita en curso, PDV, encuesta obligatoria, permisos, conectividad, datos pendientes o estado offline.
- Si no se puede validar en Android porque el celular USB no esta conectado/autorizado, o por servicio, permisos o datos de prueba, registrar bloqueo real y riesgo residual; no reemplazarlo con emulador ni con `flutter analyze`.
- Si el error evidencia una regla reusable, documentar la leccion aprendida segun `riesgos-operativos.md`.

## Evidencia y temporales

- Las capturas y logs de prueba deben quedarse fuera del skill.
- No crear ni dejar `tmp_*`, capturas, logs, trazas, salidas de comandos ni artefactos de diagnostico en la raiz del checkout Flutter.
- Si se guardan en el proyecto, usar nombres claros y no subirlos salvo que el usuario lo pida.
- No versionar `tmp_*`, APKs, `.cxx`, `build`, `.dart_tool` ni logs con datos sensibles.

Estructura recomendada para pruebas y evidencias dentro del proyecto:

```text
docs/
|- bitacora.md
|- evidencias/
|  `- android/
|     `- YYYYMMDD_HHMM_caso/
|        |- screenshots/
|        |- logs/
|        `- notas.md
`- logs/
   `- YYYYMMDD_HHMM_caso.log
```

Reglas:

- Usar `docs/evidencias/android/YYYYMMDD_HHMM_caso/` para capturas, trazas, archivos de apoyo y notas de una validacion funcional.
- Usar `docs/logs/` solo para logs que no expongan credenciales, tokens, payloads sensibles ni datos personales.
- Guardar evidencias en `<PROJECT_CONTEXT>/docs/evidencias/<ID_TAREA>/` y referenciarlas desde la bitacora; no duplicar el detalle en varios archivos.
- Si aparecen archivos `tmp_*` o temporales en la raiz, moverlos a la carpeta de evidencia del caso cuando sean necesarios, o eliminarlos si son descartables y fueron generados por la sesion actual.
- No mover temporales antiguos o de origen incierto sin revisar si pertenecen a trabajo del usuario.
- Los APKs generados se obtienen desde el checkout de integración; si deben conservarse, copiarlos solo a una ruta de entrega o evidencia autorizada fuera del worktree y no al repositorio. Al terminar el uso, limpiar derivados que ya no se requieren del checkout de integración.
- Antes de cerrar, revisar el worktree de la tarea. Si la sesión actual creó `build/`, `.dart_tool/`, `.gradle/`, `android/app/.cxx/`, APK/AAB o similares allí por error, eliminarlos después de verificar que son generados por esa sesión. No borrar artefactos preexistentes o de origen incierto sin autorización explícita.

## Comprobaciones minimas por tipo de cambio

- UI: abrir pantalla afectada, validar overflow, carga, mensajes y navegacion.
- Login: validar credenciales invalidas, login exitoso y error de red cuando sea viable.
- Visitas: validar lista, inicio, detalle, reanudacion y cierre.
- GPS: validar permisos, fuera de rango, justificacion y guardado.
- Encuestas: validar apertura, respuesta requerida, guardado, encuesta completa e incompleta.
- Sincronizacion: validar envio pendiente, descarga, errores parciales y mensajes.
- SQLite: validar migracion o limpieza con datos existentes si aplica.
