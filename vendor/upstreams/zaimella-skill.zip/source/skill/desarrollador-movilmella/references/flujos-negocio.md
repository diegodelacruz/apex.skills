# Flujos De Negocio Movilmella

## Dominio

Movilmella soporta trabajo de campo comercial y trade marketing:

- login por usuario y compania
- descarga de informacion del dia
- visitas planificadas a PDV
- visitas fuera de ruta con justificacion
- encuestas dinamicas
- novedades/comunicados
- convenios
- pedido sugerido y portafolio ideal
- captura de ubicacion GPS
- cierre de visita
- Finalizar Dia y sincronizacion
- operacion offline con envio posterior

## Login y descarga inicial

El login no solo autentica. Tambien carga configuracion, permisos, datos de usuario, PDVs, rutas, encuestas, convenios, portafolio ideal y cache relacionada.

Antes de modificar login:

- revisar `auth_bloc.dart`
- revisar `configuration_service.dart`
- revisar `FullSyncService.downloadNewData`
- validar estados de carga y errores visibles
- no bloquear trabajo offline si la conectividad falla despues de tener cache util

## Visitas

Reglas funcionales consolidadas:

- Las visitas del dia se muestran al usuario para ejecutarlas en campo.
- La lista debe priorizar pendientes y dejar realizadas al final.
- El usuario puede iniciar una visita planificada o crear una visita fuera de ruta con justificacion.
- Una visita en curso debe poder reanudarse si la app se cierra o vuelve desde segundo plano.
- La hora real de inicio no debe sobrescribirse al reabrir la app.
- El cierre no debe completarse si hay encuestas obligatorias pendientes.

Archivos frecuentes:

- `visits_bloc.dart`
- `visits_state.dart`
- `visitis_event.dart`
- `visits_page.dart`
- `visit_detail_page.dart`
- `visit_detail_ui.dart`
- `visits_helper.dart`
- `visit_location_model.dart`
- `visit_pdv_model.dart`

## GPS y justificaciones

Al iniciar y finalizar visita se valida la ubicacion actual contra la ubicacion del PDV. Si esta fuera de rango, debe pedirse justificacion.

Archivos frecuentes:

- `location_validation_service.dart`
- `location_capture_service.dart`
- `location_justification_dialog.dart`
- `location_justification_helper.dart`
- `location_justification_model.dart`
- Android: `LocationService.kt`, `MainActivity.kt`, `AndroidManifest.xml`

Gates:

- Validar permisos.
- Validar GPS apagado, permiso denegado, baja precision y timeout.
- Validar que una justificacion guardada no se duplique ni se pierda.
- Validar que la ubicacion `0,0` o invalida no se trate como ubicacion real.

## Encuestas

La app usa `packages/survey_kit` y convierte encuestas de backend a tareas navegables.

Archivos frecuentes:

- `survey_list.dart`
- `survey_ui.dart`
- `survey_page.dart`
- `survey_interactor.dart`
- `survey_view_model.dart`
- `survey_helper.dart`
- `survey_model.dart`
- `survey_title_model.dart`
- `packages/survey_kit/`

Reglas:

- Respetar configuracion de encuestas obligatorias.
- Adjuntos/imagenes pueden tener reglas especiales.
- No marcar una encuesta completa si quedan respuestas requeridas pendientes.
- Al reabrir encuesta completada con pendientes, debe permitir corregir.
- Si se modifican tipos de pregunta, validar navegacion, reglas condicionales, guardado y envio.

## Sincronizacion y Finalizar Dia

La sincronizacion envia trabajo pendiente y descarga nueva informacion sin mezclar datos antiguos.

Archivos frecuentes:

- `full_sync_service.dart`
- `finalize_day_service.dart`
- `periodic_sync_service.dart`
- `sync_health_service.dart`
- `visits_bloc.dart`
- helpers en `lib/app/database/`

Modulos de envio relevantes:

- ubicaciones
- visitas
- encuestas
- pedidos sugeridos / portafolio ideal
- novedades / comunicados
- PDVs editados

Gates:

- No limpiar cache local antes de confirmar envio correcto.
- Si falla un modulo, conservar evidencia y datos pendientes.
- No asumir que todos los endpoints devuelven lista simple; varios devuelven `items`.
- Validar reintentos y mensajes visibles cuando hay error de red.
- Validar que `lastSync` solo se actualice cuando corresponda.

## UI y experiencia

Reglas vigentes desde el proyecto:

- Login y procesos largos usan pantallas de carga modernas y unificadas.
- En drawer debe existir un solo boton visible: `Sincronizar datos`.
- En pantalla de visitas, orden de tabs: `Visitas`, `Mapa`, `Crear visita`.
- En visitas, pendientes primero por nombre y realizadas al final.
- Textos visibles en espanol.
- No dejar pantallas grises, spinners infinitos ni estados vacios sin explicacion.
