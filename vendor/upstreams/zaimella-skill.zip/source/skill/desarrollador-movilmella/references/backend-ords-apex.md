# Integracion Cliente ORDS/APEX Movilmella

Esta referencia sirve exclusivamente para diagnosticar y ajustar el cliente Flutter. No autoriza consultar, modificar ni validar ORDS, APEX, Oracle o paquetes PL/SQL: esas acciones pertenecen a `desarrollador-apex` y se restringen al modulo ORDS declarado en `desarrollo.md`.

## Base URL

La app consume ORDS/APEX con base URL segun ambiente:

- DEV: `http://sistemas.zaimella.com:8090/apex/de/`
- PROD: `http://sistemas.zaimella.com:8080/apex/de/`

No cambiar estos valores ni apuntar a produccion sin autorizacion explicita.

## Cliente API

Archivos:

- `lib/app/utils/api/api_rest_client.dart`
- `lib/app/constants/apiurl.dart`
- `lib/app/utils/api/interceptors/`
- `lib/app/utils/api/json_encoding_logger.dart`
- `lib/app/utils/api/pdv_encoding_fix.dart`

Reglas:

- Usar rutas relativas de `ApiUrlValues`.
- Mantener cabeceras UTF-8.
- No serializar `FormData` como JSON.
- No imprimir token o credenciales en logs.
- Cuando el backend devuelva payload inesperado, diagnosticar tipo real antes de forzar casts.
- Muchos endpoints pueden devolver mapas con clave `items`; validar ambos formatos si el patron local ya lo hace.

## Endpoints frecuentes

Prefijo funcional: `MovilMella/`.

- Login: `iniciarSesion/`
- Supervisor/Admin: `supervisor/`
- Cumplimiento: `cumplimiento/`
- Lugares de visita: `lugaresVisita/`
- PDV: `pdv/`
- PDV por zona: `pdvZona/`
- Encuestas: `encuesta/`, `encuestaV2/`
- Convenios: `conveniosPdv/`
- Portafolio ideal / pedido sugerido: `portafolioideal/`, `pedidoSugerido/`
- Ubicaciones: `ubicaciones/`
- Comunicados: `comunicado/`
- Configuracion: `configuracion/`
- URLs sidebar: `url/`

## Handoff con APEX/ORDS

Si el problema parece venir del backend:

- revisar request URL, metodo, body y status sin exponer secretos
- confirmar ambiente DEV/PROD
- revisar si el endpoint espera `NombreUsuario`, `Compania`, `p_usuario`, `p_compania` u otro nombre exacto
- revisar si hay SQL relacionado en `docs/sql/`
- si se requiere consultar o modificar ORDS/APEX, usar `desarrollador-apex`; Movilmella entrega URL, metodo, headers, payload y respuesta observada sin secretos
- si se requiere validar que una API `POST` o `PUT` recibio y guardo datos, `desarrollador-apex` confirma parametros recibidos, paquete/proceso ejecutado, errores Oracle y persistencia o rechazo controlado

## Produccion

- No ejecutar diagnosticos destructivos ni cambios en produccion sin autorizacion explicita.
- Si el usuario reporta un error productivo, diagnosticar con lectura y evidencia primero.
- Replicar o corregir en ambiente seguro antes de preparar paso a produccion cuando aplique.
- No pasar datos de prueba a produccion.

## SQL local de referencia

El proyecto contiene SQL puntual en `docs/sql/`, por ejemplo correcciones de coordenadas para `lugaresVisita`.

No asumir que esos scripts estan aplicados. Leerlos como evidencia historica y validar contra el requerimiento actual.
