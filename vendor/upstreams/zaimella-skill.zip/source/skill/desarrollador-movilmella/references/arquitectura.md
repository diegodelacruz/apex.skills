# Arquitectura Movilmella

## Proyecto

- Repositorio remoto canonico: `https://github.com/zaimella/Zaimella-Movilmella`.
- Ruta local: obtenerla de la seccion `Integracion Movilmella` de `desarrollo.md`; no asumir una ruta fija.
- Framework: Flutter con FVM.
- Version base documentada: Flutter `3.29.1` en `.fvmrc`.
- Paquete Dart: `mobillmella`.
- Android application id PROD: `com.zaimella.mobilmella`.
- Flavor Android DEV: `com.zaimella.mobilmella.dev`.
- Codigo principal: `lib/`.
- Paquete local modificado: `packages/survey_kit`.

## Entrypoints

- `lib/main.dart`: entrypoint general por `dart-define ENVIRONMENT`, default DEV.
- `lib/main_dev.dart`: fuerza DEV.
- `lib/main_prod.dart`: fuerza PROD. Usarlo en builds productivos.

## Ambientes

- DEV: `http://sistemas.zaimella.com:8090/apex/de/`
- PROD: `http://sistemas.zaimella.com:8080/apex/de/`
- Fuente tecnica: `lib/app/global/env/environment.dart`, `dev_config.dart`, `prod_config.dart`.

## Capas principales

- `lib/app/_childrens/`: modulos funcionales.
- `auth/`: login, permisos, descarga inicial y configuracion.
- `container/`: shell principal, drawer y navegacion.
- `home/`: resumen operativo, cumplimiento y tareas del dia.
- `visits/`: visitas, mapa, creacion fuera de ruta, detalle, encuestas, convenios, novedades, informacion y pedidos sugeridos.
- `team/`: comunicados, novedades y releases.
- `lib/app/routes/go_route.dart`: rutas GoRouter y shell principal.
- `lib/app/blocs/`: export central de BLoCs.
- `lib/app/services/`: sincronizacion, cache, configuracion, ubicacion, cierre de dia y servicios transversales.
- `lib/app/database/`: helpers SQLite.
- `lib/app/utils/api/`: cliente Dio, interceptores, logging y normalizacion JSON/UTF-8.
- `android/app/src/main/kotlin/`: servicio nativo de ubicacion, notificaciones y MethodChannel.

## Patrones locales

- Estado: `flutter_bloc` con `Event`, `State`, `Bloc`.
- Navegacion: `go_router`.
- Inyeccion: `GetIt` en `lib/app/utils/di.dart`.
- Persistencia ligera: `LocalStorageService` con SharedPreferences.
- Persistencia offline: SQLite via `DatabaseHelper` y helpers por dominio.
- API: `ApiRestClient` y `ApiUrlValues`.
- UI de modulo: patron frecuente `page`, `ui`, `interactor`, `widgets`.
- Modelos: varios usan `json_serializable` y archivos `.g.dart`.

## Base local

Archivo central: `lib/app/database/databaseHelper.dart`.

Tablas relevantes:

- `Users`
- `Permmissions`
- `Admins`
- `Locations`
- `Compliance`
- `VisitsLocation`
- `VisitsPdv`
- `Release`
- `NewsPdv`
- `Survey`
- `NotificationCatalog`
- `NotificationSaved`
- `SuggestedOrders`
- `SuggestedOrderItems`
- `EditedProducts`
- `PortafolioIdealByPdv`
- `PdvZonaCache`
- `LocationJustifications`

Reglas:

- Antes de subir version SQLite, revisar `onCreate`, `onUpgrade` y compatibilidad con datos existentes.
- No borrar datos locales si puede existir trabajo pendiente sin sincronizar.
- Para limpieza de cache o datos del dia, revisar `clearSentData()` y `clearForFreshDownload()`.
- Si Android nativo escribe una tabla, validar que el esquema Kotlin y el esquema Dart esten alineados.

## Android nativo

- `MainActivity.kt` usa MethodChannel para iniciar/detener servicio de ubicacion.
- `LocationService.kt` captura ubicaciones y guarda en SQLite nativo.
- `NotificationManagerService.kt` crea notificacion foreground.
- `AndroidManifest.xml` declara permisos de ubicacion, foreground service, storage, camara e internet.

Cuando un cambio toque ubicacion, permisos, background/foreground service o package id, solicitar la conexion de un Android real por USB y validarlo alli; el emulador no sustituye esa QA funcional.
