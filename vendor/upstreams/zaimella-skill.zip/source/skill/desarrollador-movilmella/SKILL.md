---
name: desarrollador-movilmella
description: Desarrollar, corregir, revisar, documentar y validar el frontend Flutter de Movilmella de Zaimella. Usar para cambios en el repositorio Zaimella-Movilmella, o en flujos de visitas a PDV, encuestas, ubicacion GPS, justificaciones, modo offline, SQLite, sincronizacion, Finalizar Dia, consumo de APIs ORDS, builds Android DEV/PROD, FVM, Survey Kit local o pruebas Android en dispositivo fisico USB de Movilmella.
---

# Desarrollador Movilmella

## Limite de arquitectura

El orquestador Movilmella entrega contrato de contexto, checkout o worktree, candidato, alcance y destinos de evidencia. Este skill no crea ni administra arquitectura de proyecto, bitacoras, contratos, IDs, ramas, worktrees, paquetes ni handoffs; implementa, valida y devuelve hechos tecnicos verificables.

Skill operativo para la aplicacion Flutter offline-first Movilmella. Su repositorio remoto canonico es `https://github.com/zaimella/Zaimella-Movilmella`; la ruta local del checkout se obtiene de `desarrollo.md` del contexto preparado por el orquestador `Movilmella`.

## Regla de contexto

- Trabaja solo sobre Movilmella cuando este skill se active.
- Si el usuario mezcla otro proyecto, otra tecnologia o un contexto ajeno a Movilmella, detente y pide confirmacion explicita antes de actuar fuera del proyecto.
- Antes de cambios relevantes, revisa `git status --short --branch` en el proyecto.
- No reviertas cambios del usuario ni archivos ajenos al trabajo actual.
- No hagas commit, push, publicacion ni instalacion de skills salvo instruccion explicita del usuario. Excepcion obligatoria: una solicitud de generar un APK PROD autoriza y exige publicar previamente en GitHub el candidato de esa tarea, segun el gate de `Build PROD`; no genera autorizacion para publicar cambios ajenos.
- No guardes credenciales, tokens, capturas temporales, APKs, builds, `.cxx`, `.dart_tool`, `build`, `tmp_*`, `.bak` ni evidencias locales como parte del skill o del commit.
- Los worktrees se usan para implementar tareas aisladas. Para compilar, instalar o probar en Android, usa exclusivamente el checkout de integración declarado en `desarrollo.md`, en el SHA candidato declarado en `docs/tareas/<ID_TAREA>/tarea.md` y versionado en el remoto GitHub autorizado. Nunca compiles ni instales desde un worktree de tarea; el identificador de tarea tampoco selecciona el candidato de build.
- Un worktree de tarea conserva solo código, configuración y archivos versionados necesarios para su alcance. No ejecutar en él `flutter build`, `flutter run`, `flutter test`, `flutter pub get`, Gradle ni scripts que creen `build/`, `.dart_tool/`, `.gradle/`, `android/app/.cxx/`, APK/AAB u otros artefactos pesados. Antes de un comando Android, comprobar con `git rev-parse --show-toplevel` que se está en el checkout de integración de `desarrollo.md`; si no coincide, bloquear y cambiar al checkout correcto.
- Para documentacion tecnica externa vigente, usar Context7 cuando este disponible. Respetar primero la version definida por el usuario, cliente, `.fvmrc`, `pubspec.lock`, Gradle, Android, backend o ambiente; si no existe version definida, usar la version mas reciente disponible en Context7. Context7 no reemplaza reglas de Movilmella, bitacora, validaciones Android ni evidencia funcional.
- Para cambios Movilmella medianos, grandes, multi-skill, productivos planificados o ambiguos, usar OpenSpec cuando este disponible. La especificacion vive en `openspec/changes/<id-cambio>/` del proyecto Movilmella, salvo incidente urgente con accion autorizada; OpenSpec no reemplaza `docs/bitacora.md`, reglas offline, validaciones Android ni autorizaciones PROD.

## Separacion skill vs proyecto

- El skill contiene reglas reutilizables para el frontend Flutter: flujo de trabajo, referencias, gates de riesgo, comandos de validacion, criterios de cierre y protecciones sobre offline, SQLite, GPS, sincronizacion, consumo de ORDS y builds.
- El checkout Flutter contiene solo codigo, configuracion tecnica y archivos versionados de la aplicacion. El contexto que contiene `AGENTS.md` y `desarrollo.md` guarda contratos, bitacora, evidencias, logs, pases y temporales.
- No muevas al skill informacion temporal del proyecto: rama activa, usuario funcional de prueba, capturas `tmp_*`, logs de emulador, APKs, errores de una sesion, IDs de visitas, datos de PDV, resultados de pruebas, credenciales, endpoints locales no aprobados ni decisiones de una tarea puntual.
- Si una leccion del proyecto se vuelve reusable para futuras sesiones, agregala al skill o a sus referencias solo despues de generalizarla y eliminar datos sensibles o especificos del caso.
- Si una regla solo aplica al workspace actual, guardala en el `AGENTS.md`, `desarrollo.md` o `docs/bitacora.md` del contexto, no en el skill.
  - Si una regla debe copiarse a varios proyectos o `AGENTS.md`, guardala como recurso reutilizable bajo `references/prompts/` del skill.

## Flujo unico de integracion y builds

`desarrollo.md` declara un unico checkout de integración Flutter. Es la ruta generica y persistente para integrar, compilar, instalar, generar APK/AAB y publicar; no crear checkouts o worktrees adicionales solo para un APK.

1. Una tarea nueva parte del SHA publicado vigente del checkout de integración: ejecutar `git fetch`, verificar que no tiene cambios locales y crear su worktree aislado desde ese candidato.
2. El worktree contiene exclusivamente el cambio de código y configuración versionable de la tarea. No ejecutar herramientas Flutter/Gradle/Android allí.
3. Al tener un candidato, confirmar el inventario, crear su commit de tarea y llevar ese SHA al checkout de integración de forma trazable. Para validación no productiva, el checkout puede posicionarse temporalmente en el SHA candidato; para APK PROD, el candidato debe estar publicado en la rama remota autorizada antes de compilar.
4. Ejecutar todo análisis Android, build, instalación y QA desde el checkout de integración. Copiar un APK que deba conservarse a la ubicación de evidencia/entrega autorizada fuera de ambos checkouts.
5. Al concluir, limpiar en el checkout de integración los derivados generados por la sesión (`build/`, `.dart_tool/`, Gradle y `.cxx` cuando correspondan), sin borrar código ni archivos de usuario. Actualizar el checkout al SHA publicado vigente.
6. La siguiente tarea vuelve a comenzar desde ese checkout de integración actualizado; solo entonces se crea su worktree. Si existen cambios locales o el SHA no es verificable, bloquear y resolverlo antes de abrir la tarea.

## Referencias

Lee solo las referencias aplicables:

- Arquitectura y mapa tecnico: `./references/arquitectura.md`
- Flujos funcionales criticos: `./references/flujos-negocio.md`
- Validacion Android y comandos: `./references/validacion-android.md`
- Backend ORDS/APEX y datos: `./references/backend-ords-apex.md`
- Riesgos, gates y artefactos excluidos: `./references/riesgos-operativos.md`

Reglas de seleccion:

- Para UI, navegacion, BLoC, modelos, servicios o SQLite, lee `arquitectura.md`.
- Para visitas, encuestas, GPS, justificaciones, sincronizacion, cierre de visita o Finalizar Dia, lee `flujos-negocio.md`.
- Para probar, ejecutar, validar cambios o generar APK, lee `validacion-android.md`.
- Para endpoints, payloads, ambiente DEV/PROD, errores de API o handoff con APEX/ORDS, lee `backend-ords-apex.md`.
- Para borrar datos, limpiar cache, migrar SQLite, tocar produccion, credenciales, logs o archivos temporales, lee `riesgos-operativos.md`.
- Este skill no consulta, modifica ni valida internamente ORDS, APEX, Oracle ni paquetes PL/SQL. Si el cambio o diagnostico requiere una API, sus parametros recibidos, persistencia o paquete, entregar a `desarrollador-apex` el contrato observado del cliente; ese skill realiza toda accion backend dentro del modulo ORDS autorizado por `desarrollo.md`.

## Flujo obligatorio

1. Recibir y leer el contrato y las instrucciones del contexto entregados por el orquestador al inicio de una sesion nueva o si el pedido involucra build, validacion, publicacion o reglas de trabajo.
2. Confirmar rama y estado local con `git status --short --branch`. Si habrá build, instalación o QA Android, entrar al checkout de integración declarado en `desarrollo.md` y confirmar que su rama, SHA completo publicado en el remoto autorizado y `version:` de `pubspec.yaml` coinciden con el candidato declarado en `tarea.md`; si falta, difiere, tiene cambios locales o hay más de un candidato posible, bloquear antes de compilar.
3. Identificar los archivos y modulos afectados antes de editar.
4. Cargar las referencias de este skill segun el tipo de cambio.
5. Entregar al orquestador el avance, validaciones, evidencias y hechos necesarios para que actualice la bitacora operativa.
6. Implementar con alcance minimo, siguiendo patrones existentes de BLoC, interactor/page/ui, servicios, helpers SQLite y modelos.
7. Si se modifica un modelo con `json_serializable`, `freezed` o archivos `.g.dart`, evaluar si corresponde ejecutar `fvm flutter pub run build_runner build --delete-conflicting-outputs`.
8. Ejecutar validaciones proporcionales al riesgo: `fvm flutter analyze`, pruebas unitarias si existen y validacion Android si el cambio toca flujo visible o comportamiento movil.
9. Para cambios en visitas, encuestas, ubicacion, sincronizacion o SQLite, validar funcionalmente el flujo real en Android cuando el entorno lo permita.
10. Devolver al orquestador el estado real, validaciones, evidencias y pendientes para el registro contractual.
11. Antes de cerrar una tarea, revisar que el worktree no haya recibido artefactos generados por la sesión. Eliminar únicamente los directorios pesados generados y verificables de la sesión actual; no borrar artefactos preexistentes o de origen incierto sin autorización explícita del usuario.
12. Si hubo error recurrente, bloqueo, hallazgo funcional, retrabajo, excepcion aprobada, prueba de regresion relevante o regla reusable nueva, registrar la leccion aprendida segun `./references/riesgos-operativos.md`.
13. Registrar en la respuesta final que se valido, que no se pudo validar y que riesgo residual queda.

## Bitacora operativa

- La bitacora operativa unica del proyecto es `<PROJECT_CONTEXT>/docs/bitacora.md`.
- Si falta la bitacora o su ubicacion, reportar contexto incompleto al orquestador; no crearla por cuenta propia.
- No crees bitacoras paralelas; logs, capturas, APKs locales o evidencias tecnicas deben referenciarse desde la bitacora y guardarse fuera del skill y del checkout Flutter.
- No dejes archivos `tmp_*`, capturas, logs, salidas de comandos, trazas ni artefactos de diagnostico en la raiz del checkout Flutter.
- Para pruebas y evidencias del proyecto, usa la estructura definida en `./references/validacion-android.md` dentro del contexto y referencia la ruta desde la bitacora.
- Estados sugeridos: `Pendiente`, `En progreso`, `Bloqueado`, `Validado`, `Completado`.
- Para builds, validaciones Android, cambios en SQLite, sincronizacion, backend o flujos comerciales, registra alcance, ambiente, comandos ejecutados, resultado y riesgo residual.
- Para errores, pruebas fallidas, bloqueos y lecciones aprendidas, registra sintoma, causa, correccion o decision, validacion ejecutada, evidencia, pendiente y regla reusable propuesta cuando aplique.

## Reglas tecnicas

- Usar FVM por defecto: `fvm flutter ...`.
- No reemplazar arquitectura existente por un patron nuevo sin necesidad clara.
- Mantener `ApiRestClient`, `LocalStorageService`, `GetIt`, helpers SQLite y servicios existentes como puntos de integracion.
- No mover logica de negocio compleja a widgets si ya pertenece a BLoC, servicios o helpers.
- No romper el modo offline: antes de limpiar, refrescar o sobrescribir datos locales, verificar que no se pierda trabajo pendiente.
- No asumir conectividad permanente; manejar errores de red como casos esperados.
- No cambiar endpoints, modulos ORDS, paquetes Oracle ni ejecutar acciones backend. Mantener el cliente alineado al contrato aprobado por `desarrollador-apex`.
- Evitar debug logs permanentes con tokens, credenciales, payloads sensibles o datos personales.
- Mantener textos visibles en espanol y usar `assets/i18n/es.json` cuando el patron existente lo requiera.

## Validacion Android

Cuando el usuario pida probar, ejecutar o validar cambios en Android:

1. Solicitar al usuario que conecte el celular Android de pruebas por USB y verificarlo con ADB antes de iniciar QA funcional; seguir `./references/validacion-android.md`.
2. Seleccionar y registrar el candidato de build: checkout de integración absoluto, rama remota, SHA completo publicado, `version:` de `pubspec.yaml`, flavor, entrypoint y APK esperado. No inferirlo de un worktree usado anteriormente ni de un ID de caso.
3. Compilar un APK nuevo exclusivamente desde ese checkout de integración y comprobar que el identificador de paquete y `versionName`/`versionCode` del APK coinciden con el candidato registrado.
4. Antes de instalar, consultar la versión actualmente instalada para ese mismo paquete. Bloquear un downgrade, una instalación desde otro checkout o cualquier discrepancia de versión, salvo autorización explícita y registrada del usuario para esa excepción.
5. Instalar el APK nuevo en el celular conectado y volver a comprobar paquete y versión instalada.
6. Abrir la app automaticamente.
7. Recorrer el flujo indicado por el usuario.
8. Corregir errores funcionales o visuales encontrados.
9. Recompilar y repetir hasta dejar el flujo correcto o reportar un bloqueo real.

No reutilices un APK viejo si hubo cambios de codigo.
No uses opciones de instalación que permitan downgrade ni desinstales la aplicación para sortear este gate sin autorización explícita y registrada.
No cierres como completado un cambio visible si no ejecutaste al menos smoke Android rapido o si no reportaste un bloqueo real de ambiente.
Al terminar el build/QA, conservar el APK solo en la ruta de evidencia o entrega autorizada fuera del worktree y limpiar del checkout de integración los derivados que ya no se necesiten. Nunca trasladar `build/` ni cachés al worktree de tarea.

## QA Movil Provisional

- Mientras no exista un skill `qa-movilmella` independiente, este skill ejecuta el QA funcional del frontend despues de implementar.
- Antes de cada QA funcional, solicitar que conecten el celular Android de pruebas por USB; no asumir que esta conectado aunque se haya usado antes.
- Ejecutar el QA funcional solo en un dispositivo fisico detectado por ADB. Si no se conecta o no queda autorizado, registrar `Impedimento externo` y solicitar la conexion; no sustituirlo con emulador.
- El emulador puede usarse unicamente para un smoke tecnico aislado y no equivale a QA funcional ni habilita cerrar un cambio visible como validado.
- Requerir una APK DEV nueva, instalacion sobre el dispositivo, recorrido del caso de la tarea, evidencia y registro de resultado `Aprobado`, `No aprobado` o `Impedimento externo`.
- El usuario solo prepara el dispositivo una vez: habilita depuracion USB y acepta la huella RSA. El QA opera ADB, instala, abre, captura evidencia y revisa logs.
- Si el caso exige credenciales MFA, camara, ubicacion fisica real, una accion comercial o una decision funcional no automatizable, solicitar solo esa intervencion puntual y registrar el limite.
- Este QA no reemplaza `qa-apex`: ese skill mantiene la validacion independiente de APIs `MVZM`, paquetes Oracle y persistencia en TEST.

## Preflight de login TEST

Antes de una QA que requiera iniciar sesión, no adivinar usuario, contraseña ni estado de la pantalla. Ejecutar el preflight reutilizable desde el checkout de integración, después de que `desarrollador-apex` haya preparado TEST y validado las APIs:

```powershell
python <SKILL_ROOT>/scripts/preflight_movilmella_login.py `
  --preparer <PROJECT_CONTEXT>/docs/scripts/preparar_ambiente_test_movilmella.py `
  --company <COMPANIA> --user <USUARIO_SI_APLICA> `
  --serial <ADB_SERIAL> --package <APPLICATION_ID_DEL_FLAVOR>
```

El preflight ejecuta el plan y la preparación TEST con acceso MVZM, obtiene la contraseña solo en memoria de una consola privada, abre la APK y espera los dos campos editables. Escribe usuario y contraseña sin imprimirlos y confirma que la UI recibió el usuario completo. Su salida segura es `LOGIN_PREFLIGHT_READY`; después el QA envía el login y verifica descarga inicial/escenario. Si falla, detener el intento de autenticación, registrar solo la causa no sensible y corregir usuario, escenario, acceso, dispositivo o pantalla antes de reintentar.

## Build PROD

Generar un APK PROD es una liberacion de fuente trazable: antes de ejecutar Flutter, publicar el candidato exacto en GitHub. La solicitud de ese APK autoriza exclusivamente esta publicacion, sin requerir una instruccion Git adicional.

1. Desde el checkout de integracion, ejecutar `git fetch`, confirmar que `origin/main` mantiene el predecesor esperado y revisar `git status`, `git diff --name-only` y staged files.
2. Verificar que el inventario contiene solamente archivos de la tarea actual; no usar `git add .` ni incluir cambios ajenos.
3. Ejecutar las validaciones proporcionales ya aplicables. Si el candidato contiene cambios de la tarea aun no publicados, crear su commit y hacer `git push origin HEAD:main` (o el flujo PR exigido por una proteccion tecnica o solicitado por el usuario); si ya esta publicado, no crear un commit vacio.
4. Volver a ejecutar `git fetch` y comprobar que el SHA completo del commit candidato esta publicado en la rama autorizada; registrar ese SHA en `tarea.md` y la bitacora. Si el push falla, si hay divergencia o no se puede identificar el candidato, bloquear: no generar APK PROD desde un commit local no publicado.
5. Compilar exclusivamente ese SHA publicado. El APK y el commit publicado deben quedar vinculados en el contrato y en la respuesta final.

Para produccion, no confies solo en `--flavor prod`. El entrypoint correcto es:

```powershell
fvm flutter build apk --flavor prod --release -t lib/main_prod.dart
```

Si un script local compila PROD sin `-t lib/main_prod.dart`, advierte el riesgo y ajusta la validacion o el script dentro del alcance autorizado.

## Salidas esperadas

Segun el pedido, entrega:

- diagnostico tecnico y archivos afectados
- implementacion realizada
- validaciones ejecutadas
- resultado funcional del flujo probado
- bloqueos reales si existen
- riesgos pendientes, especialmente en offline, GPS, SQLite, sincronizacion o ambiente PROD
- hechos verificables para documentacion: flujos, pantallas, contratos API, versiones Flutter/backend, impacto operativo y rutas de evidencia. `documentacion-proyecto-sistemas` redacta el entregable desde el contexto; este skill no sustituye esa autoria.
