#!/usr/bin/env python3
"""Prepara TEST y deja el login Movilmella listo por ADB sin registrar la contrasena.

El preparador del proyecto se ejecuta tres veces: plan, aplicacion TEST y lectura
privada de la credencial. La contrasena solo permanece en memoria del proceso y
nunca se imprime, escribe en archivos ni se incluye en mensajes de error.
"""
from __future__ import annotations

import argparse
import re
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path


PASSWORD_LINE = re.compile(r"^CREDENCIAL_TEST:\s*usuario=([^;]+);\s*contrasena=(.+)$", re.M)
PLAN_LINE = re.compile(r"^(?:PLAN|EJECUTADO):\s*usuario=([^;]+);\s*compania=([^;]+);", re.M)


@dataclass(frozen=True)
class Field:
    bounds: tuple[int, int, int, int]
    text: str


def run(command: list[str], *, capture: bool = True, check: bool = True, redact_output: bool = False) -> str:
    result = subprocess.run(command, text=True, capture_output=capture, check=False)
    if check and result.returncode:
        detail = "Salida privada omitida." if redact_output else (result.stderr or result.stdout).strip()
        raise RuntimeError(f"Comando fallido ({result.returncode}): {' '.join(command[:4])}. {detail}")
    return result.stdout


def preparer_command(args: argparse.Namespace, *, execute: bool, show_password: bool) -> list[str]:
    command = [sys.executable, str(args.preparer), "--company", args.company]
    if args.user:
        command.extend(["--user", args.user])
    if execute:
        command.extend(["--execute", "--grant-movilmella-access"])
    if show_password:
        command.append("--show-password")
    return command


def prepare_credentials(args: argparse.Namespace) -> tuple[str, str]:
    plan = run(preparer_command(args, execute=False, show_password=False))
    if not PLAN_LINE.search(plan):
        raise RuntimeError("El preparador no produjo un candidato TEST apto para login.")
    applied = run(preparer_command(args, execute=True, show_password=False))
    if not PLAN_LINE.search(applied):
        raise RuntimeError("El preparador no confirmó la preparación TEST.")
    secret_output = run(preparer_command(args, execute=True, show_password=True), redact_output=True)
    match = PASSWORD_LINE.search(secret_output)
    if not match or not match.group(2):
        raise RuntimeError("El preparador no confirmó una credencial TEST utilizable.")
    return match.group(1).strip(), match.group(2)


def parse_bounds(raw: str) -> tuple[int, int, int, int]:
    values = [int(value) for value in re.findall(r"-?\d+", raw)]
    if len(values) != 4:
        raise ValueError(f"Bounds Android inválidos: {raw}")
    return values[0], values[1], values[2], values[3]


def visible_edit_fields(xml_text: str) -> list[Field]:
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError as exc:
        raise RuntimeError("No fue posible leer la UI Android para login.") from exc
    fields: list[Field] = []
    for node in root.iter("node"):
        if node.attrib.get("class") != "android.widget.EditText" or node.attrib.get("visible-to-user") == "false":
            continue
        fields.append(Field(parse_bounds(node.attrib.get("bounds", "")), node.attrib.get("text", "")))
    return fields


def ui_xml(adb: str, serial: str) -> str:
    run([adb, "-s", serial, "shell", "uiautomator", "dump", "/sdcard/movilmella_login.xml"], capture=True)
    return run([adb, "-s", serial, "shell", "cat", "/sdcard/movilmella_login.xml"])


def wait_for_login_fields(adb: str, serial: str, timeout: int) -> list[Field]:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        fields = visible_edit_fields(ui_xml(adb, serial))
        if len(fields) >= 2:
            return fields[:2]
        time.sleep(1)
    raise RuntimeError("La pantalla de login no expuso usuario y contraseña antes del timeout.")


def tap(adb: str, serial: str, field: Field) -> None:
    left, top, right, bottom = field.bounds
    run([adb, "-s", serial, "shell", "input", "tap", str((left + right) // 2), str((top + bottom) // 2)])


def adb_input(value: str) -> str:
    # `input text` interpreta espacios como %s. La llamada se hace sin shell local
    # y posteriormente se valida la UI; cualquier valor que no llegue completo falla.
    return value.replace("%", "\\%").replace(" ", "%s")


def type_value(adb: str, serial: str, field: Field, value: str) -> None:
    tap(adb, serial, field)
    run([adb, "-s", serial, "shell", "input", "keyevent", "KEYCODE_MOVE_END"])
    run([adb, "-s", serial, "shell", "input", "keyevent", "KEYCODE_CTRL_A"])
    run([adb, "-s", serial, "shell", "input", "keyevent", "KEYCODE_DEL"])
    run([adb, "-s", serial, "shell", "input", "text", adb_input(value)])


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--preparer", type=Path, required=True, help="Ruta al preparar_ambiente_test_movilmella.py del contexto.")
    parser.add_argument("--company", default="00001")
    parser.add_argument("--user", help="Usuario QA deseado; se selecciona uno apto si se omite.")
    parser.add_argument("--serial", required=True, help="Serial ADB del Android físico autorizado.")
    parser.add_argument("--package", required=True, help="Package Android del flavor que se probará.")
    parser.add_argument("--adb", default="adb")
    parser.add_argument("--timeout", type=int, default=30, help="Segundos máximos para que aparezca el login.")
    args = parser.parse_args()

    if not args.preparer.is_file():
        raise SystemExit(f"No existe el preparador: {args.preparer}")
    try:
        run([args.adb, "-s", args.serial, "get-state"])
        username, password = prepare_credentials(args)
        run([args.adb, "-s", args.serial, "shell", "am", "force-stop", args.package])
        run([args.adb, "-s", args.serial, "shell", "monkey", "-p", args.package, "1"])
        username_field, password_field = wait_for_login_fields(args.adb, args.serial, args.timeout)
        type_value(args.adb, args.serial, username_field, username)
        type_value(args.adb, args.serial, password_field, password)
        verified = wait_for_login_fields(args.adb, args.serial, 5)
        if verified[0].text.strip().upper() != username.upper():
            raise RuntimeError("La UI no confirmó el usuario completo; no se envió autenticación.")
        # Android enmascara el contenido de password en UIAutomator. El valor no se
        # expone ni se registra; la pantalla queda lista para que el QA envíe login.
        print(f"LOGIN_PREFLIGHT_READY: usuario={username}; compania={args.company}; package={args.package}")
        return 0
    except Exception as exc:
        print(f"LOGIN_PREFLIGHT_ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
