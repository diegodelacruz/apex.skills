# Nuevo proyecto de Sistemas

Prepara este proyecto con la version publicada vigente del orquestador `Gestion-Proyectos`.

Lee y ejecuta completamente `D:/Users/jbalcazar/.codex/zaimella-agent-ecosystem/commands/Gestion-Proyectos.md`.

1. Actualiza idempotentemente `AGENTS.md` con el bloque canonico mediante `--check`, `--dry-run` y `--apply`.
2. Conserva reglas locales, seguridad, alcance y todos los insumos originales.
3. Crea o completa el contrato y la arquitectura del ciclo de vida desde las plantillas versionadas, incluidos los documentos `.md` por defecto.
4. Si el proyecto ya tiene archivos o carpetas, inventarialos, clasificalos y organizalos: mueve solo los archivos con destino inequivoco a la estructura canonica, sin sobrescribir, y registra cada movimiento u omision. No muevas `AGENTS.md`, contratos de dominio, `README.md`, archivos ocultos, manifiestos tecnicos ni elementos ambiguos.
5. Inventaria y correlaciona insumos; no saltes levantamiento, RI, diseno funcional ni decisiones requeridas.
6. Define entregables, sprints y paquetes solo cuando existan resultados verificables.
7. Selecciona orquestadores de dominio desde su registro de capacidades; nunca invoques directamente sus skills internos.
8. Usa `documentacion-proyecto-sistemas` para documentos funcionales y tecnicos entregables.
9. Si falta un orquestador, registra `DOMINIO_SIN_ORQUESTADOR`; no crees uno hasta tener una necesidad concreta que permita probarlo.

Informa la etapa detectada, fuentes inventariadas, decisiones pendientes y siguiente gate. No inicies desarrollo sin un paquete aprobado.
