# Configurar gestión de errores reportados APEX

Usa este prompt en un proyecto APEX ya preparado para dejar persistente el diagnóstico de errores reportados por usuarios. No reinstales skills ni reproceses la preparación general de Desarrollo-APEX.

1. Lee `AGENTS.md`, `desarrollo.md`, `docs/bitacora.md` y las guías `errores/README.md` o `casos/README.md` solo si ya existen. Conserva las reglas locales de aplicación y alcance.
2. Ejecuta `D:/Users/jbalcazar/.codex/zaimella-agent-ecosystem/scripts/update_apex_case_management_agents_md.py --project-root <PROJECT_ROOT> --check`, revisa `--dry-run` y aplica `--apply`. Confirma que el bloque único `ZAIMELLA: GESTION CASOS APEX` contiene la sección `Errores Reportados`.
3. Crea o completa sin sobrescribir información válida `errores/README.md` y la carpeta `errores/`. Debe definir plantilla, clasificación, análisis inicial solo lectura, separación frente a casos y que el cierre del reporte no autoriza cambios ni PRODUCCIÓN.
4. Si existe un reporte concreto, abre o actualiza `errores/#<NUMERO_ERROR>.md` desde `D:/Users/jbalcazar/.codex/zaimella-agent-ecosystem/commands/resources/Desarrollo-APEX/error-reportado.template.md`; si no existe, no inventes uno.

La regla persistente es: primero reproducir o reunir evidencia en lectura y revisar datos, formato, permisos, reglas, mensajes y acción del usuario. Clasificar con evidencia como `Uso o dato invalido`, `Comportamiento definido`, `Defecto funcional`, `Excepcion no controlada` o `Evidencia insuficiente`. Solo un defecto o excepción confirmados derivan a un caso correctivo separado; el error conserva el diagnóstico. No modificar TEST, fuente, GitHub ni PRODUCCIÓN para probar una hipótesis sin autorización.

Entrega las reglas aplicadas, archivos actualizados y, si existe, el número, clasificación y siguiente acción del error reportado. No implementes ni publiques cambios durante esta configuración, ni crees o reorganices la arquitectura general del proyecto.
