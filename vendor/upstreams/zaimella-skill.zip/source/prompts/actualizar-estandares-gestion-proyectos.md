# Actualizar estandares de Gestion-Proyectos

Actualiza este contexto con la version publicada vigente de `Gestion-Proyectos`.

Lee y ejecuta `D:/Users/jbalcazar/.codex/zaimella-agent-ecosystem/commands/Gestion-Proyectos.md`.

1. Actualiza el bloque administrado mediante `--check`, `--dry-run` y `--apply`.
2. Conserva reglas locales, insumos, decisiones, aceptaciones, tareas cerradas y bloques de orquestadores de dominio.
3. Completa de forma idempotente la estructura, documentos `.md` por defecto, contratos, entregables, sprints, paquetes, handoffs, documentacion y cierre.
4. Inventaria, clasifica y organiza los archivos heredados: mueve solo los que tengan destino inequivoco, sin sobrescribir, conserva nombres y registra cada movimiento u omision. No mover `AGENTS.md`, contratos de dominio, `README.md`, archivos ocultos, manifiestos tecnicos ni elementos ambiguos.
5. Migra solo coordinacion sustituida; no cambies codigo, datos, ambientes ni tareas tecnicas por actualizar estandares.
6. Verifica que cada paquete apunte a un orquestador propietario, no a un skill interno.
7. Mantiene un unico skill `documentacion-proyecto-sistemas` para entregables funcionales y tecnicos.
8. No crees orquestadores de dominio futuros sin un proyecto o necesidad concreta.

Reporta cambios aplicados, equivalencias heredadas, contradicciones y campos materiales pendientes.
