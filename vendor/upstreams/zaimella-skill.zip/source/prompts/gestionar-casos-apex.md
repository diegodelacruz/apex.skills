# Configurar gestión de casos APEX en un proyecto preparado

Usa este prompt una sola vez al iniciar, o cada vez que se actualicen las políticas de casos, en un proyecto APEX que ya tiene `AGENTS.md` y `desarrollo.md`. No reinstales skills, no reproceses la preparación general de Desarrollo-APEX ni crees una aplicación nueva.

## Objetivo persistente

Deja configurado el proyecto para atender únicamente tickets, mejoras pequeñas, correcciones, análisis y consultas de la aplicación y objetos declarados en `desarrollo.md`. Después de esta configuración, cada sesión debe seguir `AGENTS.md` sin que el usuario tenga que volver a explicar el flujo de casos.

## Aplicación obligatoria

1. Lee `AGENTS.md`, `desarrollo.md`, `docs/bitacora.md`, las instrucciones locales y `casos/README.md` solo si ya existe. Conserva reglas de negocio, seguridad, aplicación, prefijos y alcance ya definidos.
2. Ejecuta, desde el runtime publicado, `D:/Users/jbalcazar/.codex/zaimella-agent-ecosystem/scripts/update_apex_case_management_agents_md.py --project-root <PROJECT_ROOT> --check`; revisa `--dry-run` y ejecuta `--apply`. Confirma que queda un único bloque `ZAIMELLA: GESTION CASOS APEX` en `AGENTS.md` y que una segunda comprobación no requiere cambios.
3. Crea o completa sin sobrescribir información válida `casos/README.md`; debe indicar la plantilla, estados, separación frente a `errores/`, límites de `desarrollo.md` y que TEST/QA no autorizan cierre, GitHub ni PRODUCCIÓN. Crea `casos/` si falta.
4. Si existe una solicitud concreta, abre o actualiza `casos/#<NUMERO_CASO>.md` desde `D:/Users/jbalcazar/.codex/zaimella-agent-ecosystem/commands/resources/Desarrollo-APEX/caso.template.md`; si no existe solicitud, no inventes un caso ni una tarea.

## Regla de trabajo que debe quedar vigente

- El caso conserva la solicitud original, tipo (`Mejora`, `Correccion`, `Analisis` o `Consulta`), alcance, objetos, decisiones, evidencias y cambios de definición.
- Un análisis o consulta trabaja solo en lectura salvo autorización expresa de cambio. Una mejora o corrección usa únicamente TEST y la fuente versionada dentro de `desarrollo.md`.
- Un cambio crea su tarea técnica, contratos y evidencia proporcional con Desarrollo-APEX; QA funcional aplica si hay impacto visible/funcional y QA técnico acotado si solo cambia una rutina u objeto sin impacto visible declarado.
- TEST y QA aprobados dejan el caso `Listo para cierre autorizado`. El caso sigue abierto: no integrar en `origin/main`, no publicar GitHub, no ejecutar PRODUCCIÓN ni cerrar por inferencia.
- Solo una instrucción explícita del usuario autoriza cierre. GitHub y PRODUCCIÓN requieren estar nombrados explícitamente; se ejecutan únicamente para el SHA validado y se registran en el mismo caso.
- Una definición nueva del usuario se agrega al caso activo. Solo una regla reusable para todos los casos modifica el bloque administrado versionado y se reaplica mediante el actualizador.

Entrega qué reglas quedaron aplicadas, qué archivos se crearon o actualizaron y, si existe, el número/estado del caso activo. No desarrolles ni publiques funcionalidades durante esta configuración, ni crees o reorganices la arquitectura general del proyecto.
