# Sprint Del Proyecto

## Identidad

- ID proyecto: <PROJECT_ID>
- ID sprint: <SPRINT_ID>
- Nombre: <NOMBRE>
- Inicio: <STARTED_AT>
- Fin esperado: <EXPECTED_END>
- Estado: Preparacion | En ejecucion | En integracion | En aceptacion | Completado | En espera de decision

## Objetivo

- Entregables vinculados: <DELIVERABLE_IDS>
- Resultado del sprint: <RESULTADO_VERIFICABLE>
- Criterios de termino: <CRITERIOS>

## Paquetes

| ID paquete | Capability ID | Orquestador propietario | Dependencias | Estado | Handoff | Evidencia |
|---|---|---|---|---|---|---|
| <PACKAGE_ID> | <CAPABILITY_ID> | <ORQUESTADOR_O_DOMINIO_SIN_ORQUESTADOR> | <DEPENDENCIAS_O_NINGUNA> | Preparacion | Pendiente | Pendiente |

El sprint solo queda `Completado` cuando todos sus entregables y paquetes aplicables estan aceptados o cancelados con autorizacion registrada.

