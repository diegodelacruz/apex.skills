# Indice Final De Entregables

| ID entregable | Resultado aceptado | Version o linea base | Evidencia | Documentos funcionales/tecnicos | Aceptacion | Pendientes transferidos |
|---|---|---|---|---|---|---|
| <DELIVERABLE_ID> | <RESULTADO> | <VERSIONES_SHA> | <RUTAS> | <RUTAS> | <RESPONSABLE_FECHA_EVIDENCIA> | <PENDIENTES_O_NINGUNO> |

