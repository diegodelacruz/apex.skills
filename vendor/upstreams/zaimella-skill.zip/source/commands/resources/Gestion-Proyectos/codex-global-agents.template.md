<!-- ZAIMELLA:GLOBAL:GESTION-PROYECTOS:START -->
# Preparar y gestionar proyectos de Sistemas

Cuando el usuario diga `prepara este proyecto`, `inicia este proyecto`, `gestiona este proyecto` o una peticion equivalente sobre el ciclo completo:

1. Leer y ejecutar `<ECOSYSTEM_ROOT>/commands/Gestion-Proyectos.md`.
2. Leer los recursos aplicables de `<ECOSYSTEM_ROOT>/commands/resources/Gestion-Proyectos/`.
3. Actualizar `AGENTS.md` con `<ECOSYSTEM_ROOT>/scripts/update_gestion_proyectos_agents_md.py`: ejecutar `--check`, revisar `--dry-run` y aplicar `--apply` si no hay contradicciones no migrables.
4. Crear o completar el contrato, entregables, sprints, paquetes, seguimiento, documentacion y cierre sin mover fuentes heredadas.
5. Delegar cada paquete al orquestador de dominio propietario registrado; nunca invocar directamente sus skills internos.
6. Usar un unico skill `documentacion-proyecto-sistemas` para documentos funcionales y tecnicos entregables.
7. No crear nuevos orquestadores de dominio hasta que exista un proyecto o necesidad concreta para definirlos, probarlos y mejorarlos.

Despues de la preparacion, seguir el `AGENTS.md` del proyecto y los contratos persistentes.
<!-- ZAIMELLA:GLOBAL:GESTION-PROYECTOS:END -->

