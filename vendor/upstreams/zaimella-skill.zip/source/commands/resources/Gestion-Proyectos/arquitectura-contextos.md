# Arquitectura Canonica De Contextos De Proyecto

Esta es la fuente de verdad del orquestador `Gestion-Proyectos`. Los skills no crean ni administran esta estructura.

```text
<PROJECT_ROOT>/
|- AGENTS.md
|- proyecto/
|  |- proyecto.md
|  |- bitacora.md
|  |- 00_insumos/
|  |- 01_levantamiento/
|  |- 02_ri/
|  |- 03_diseno_funcional/
|  |- 04_ad/
|  |- 05_planificacion/
|  |  `- entregables.md
|  |- 06_seguimiento/
|  `- 07_cierre/
`- dominios/
   |- apex/                 # solo si un paquete APEX lo requiere
   |  |- AGENTS.md
   |  |- desarrollo.md
   |  |- docs/bitacora.md
   |  `- qa/
   |- movilmella/           # solo si un paquete Movilmella lo requiere
   |  |- AGENTS.md
   |  |- desarrollo.md
   |  `- docs/bitacora.md
   `- aws/                  # solo si un paquete AWS lo requiere
      |- AGENTS.md
      |- desarrollo-aws.md
      `- bitacora.md
```

## Reglas

1. `<PROJECT_ROOT>` contiene la gestion transversal. `proyecto/proyecto.md`, `proyecto/05_planificacion/entregables.md` y `proyecto/bitacora.md` son sus fuentes de verdad.
2. Cada `dominios/<DOMINIO>/` es el `<PROJECT_ROOT>` de su orquestador de dominio. Este prepara y mantiene su propio `AGENTS.md`, contrato, tareas, QA y bitacora tecnica segun sus recursos versionados.
3. Un paquete multidominio conserva una sola identidad transversal y se descompone en tareas internas por propietario. El paquete no se cierra hasta recibir handoffs aprobados de todos los dominios aplicables, integracion y documentacion.
4. Los repositorios de codigo viven en sus checkouts de integracion externos. Los worktrees viven bajo la raiz externa definida por cada contrato de dominio; nunca dentro de este arbol.
5. No crear un contexto de dominio vacio por anticipado. Crearlo solo cuando exista un paquete con propietario de dominio. En un proyecto de un solo dominio, el orquestador puede usar directamente la raiz del proyecto como contexto de dominio solo si no existe `Gestion-Proyectos` como capa transversal.
6. En proyectos heredados, registrar la equivalencia de las ubicaciones existentes y no mover, copiar ni borrar fuentes de manera automatica.
