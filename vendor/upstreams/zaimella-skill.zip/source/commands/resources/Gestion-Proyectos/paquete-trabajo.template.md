# Paquete De Trabajo Por Dominio

## Identidad

- ID proyecto: <PROJECT_ID>
- ID entregable: <DELIVERABLE_ID>
- ID sprint: <SPRINT_ID>
- ID paquete: <PACKAGE_ID>
- Capability ID: <CAPABILITY_ID>
- Orquestador propietario: <ORQUESTADOR_O_DOMINIO_SIN_ORQUESTADOR>
- Responsable ejecutor: <ORQUESTADOR_O_RESPONSABLE_HUMANO>
- Tarea interna del dominio: Pendiente
- Estado: Preparacion | Listo para delegar | Delegado | En ejecucion dominio | En integracion | Aceptado | En espera de decision | Cancelado autorizado

## Contrato De Resultado

- Objetivo verificable: <OBJETIVO>
- Criterios de aceptacion: <CRITERIOS>
- Alcance incluido: <INCLUYE>
- Alcance excluido: <NO_INCLUYE>
- Dependencias: <DEPENDENCIAS_O_NINGUNA>
- Insumos y decisiones confirmadas: <RUTAS_Y_DECISIONES>
- Ambiente o autorizacion conocida: <AMBIENTE_AUTORIZACION_O_NO_APLICA>

## Evidencia Y Documentacion

- Evidencia requerida: <EVIDENCIA>
- Perfil documental requerido: funcional | tecnico | mixto | No aplica justificado: <MOTIVO>
- Impacto esperado para usuario u operacion: <IMPACTO>
- Handoff esperado: `proyecto/06_seguimiento/handoffs/<PACKAGE_ID>.md`

## Historial

| Fecha/hora | Estado anterior | Estado nuevo | Motivo | Evidencia |
|---|---|---|---|---|
| <CREATED_AT> | No aplica | Preparacion | Creacion del paquete | Este contrato |
