# Matriz De Entregables

| ID entregable | Resultado y criterio de aceptacion | Responsable de aceptacion | Sprints | Paquetes | Documentacion requerida | Evidencia final | Estado |
|---|---|---|---|---|---|---|---|
| <DELIVERABLE_ID> | <RESULTADO_VERIFICABLE> | <RESPONSABLE> | <SPRINT_IDS> | <PACKAGE_IDS> | <PERFILES_DOCUMENTALES_O_NO_APLICA_JUSTIFICADO> | <RUTAS> | Pendiente |

Estados: `Pendiente`, `En definicion`, `En ejecucion`, `En integracion`, `En aceptacion`, `Aceptado`, `Cancelado autorizado`.

