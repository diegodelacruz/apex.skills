# Plan De Documentacion Del Proyecto

| ID documento | ID entregable | Perfil | Audiencia | Proposito | Secciones/cobertura | Linea base | Evidencia fuente | Salida esperada | Estado |
|---|---|---|---|---|---|---|---|---|---|
| <DOCUMENT_ID> | <DELIVERABLE_ID> | funcional | <AUDIENCIA> | <PROPOSITO> | <COBERTURA> | <VERSIONES_SHA> | <RUTAS> | <RUTA_DOCX_PDF_U_OTRA> | Pendiente |

Perfiles permitidos: `funcional`, `tecnico` o `mixto`. Usar `No aplica` solo con estado `No aplica justificado` y motivo verificable. Todos los documentos aplicables deben ser entendibles para su audiencia y usar la misma linea base aprobada del entregable.
