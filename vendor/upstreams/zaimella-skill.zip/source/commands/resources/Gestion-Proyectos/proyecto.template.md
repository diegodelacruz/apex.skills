# Contrato Del Proyecto

## Identidad

- ID proyecto: <PROJECT_ID>
- PROJECT_SLUG: <PROJECT_SLUG>
- Nombre: <NOMBRE_PROYECTO>
- Area solicitante: <AREA>
- Responsable de negocio: <RESPONSABLE_NEGOCIO>
- Responsable de Sistemas: <RESPONSABLE_SISTEMAS>
- Fecha de inicio: <CREATED_AT>
- Etapa actual: Descubrimiento | Levantamiento | RI | Diseno funcional | AD tecnico | Planificacion | Ejecucion | Integracion | Aceptacion | Documentacion | Cierre
- Estado: Activo | En espera de decision | Cerrado | Cancelado

## Objetivo Y Alcance

- Necesidad u oportunidad: <NECESIDAD>
- Objetivo verificable: <OBJETIVO>
- Incluye: <ALCANCE_INCLUIDO>
- No incluye: <ALCANCE_EXCLUIDO>
- Criterio global de exito: <CRITERIO_GLOBAL>

## Gobierno

| Rol | Responsable | Autoridad o decision |
|---|---|---|
| Dueño de negocio | <RESPONSABLE> | <DECISIONES> |
| Aceptacion funcional | <RESPONSABLE> | <DECISIONES> |
| Coordinacion Sistemas | <RESPONSABLE> | <DECISIONES> |

## Capacidades Y Propietarios

| Capability ID | Resultado requerido | Orquestador propietario | Estado | Observacion |
|---|---|---|---|---|
| <CAPABILITY_ID> | <RESULTADO> | <ORQUESTADOR_O_DOMINIO_SIN_ORQUESTADOR> | Pendiente | <OBSERVACION> |

El propietario se selecciona desde `commands/orchestrators.json`. Los skills internos del orquestador no se registran como propietarios de paquetes.

