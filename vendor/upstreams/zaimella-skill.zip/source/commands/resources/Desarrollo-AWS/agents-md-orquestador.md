# Prompt Orquestador - Desarrollo-AWS

## Sección 1 - Contenido para AGENTS.md

```markdown
# Orquestador Zaimella Desarrollo-AWS

Este bloque coordina tareas ETL AWS. `desarrollo-aws.md` es la fuente de verdad de configuración y alcance AWS; `docs/bitacora.md` registra el estado operativo; cada evidencia de comparación con fuente queda en `docs/operacion/validaciones-fuente/`.

## Responsabilidades

- Usar `desarrollador-apex` solo cuando la fuente oficial original esté en Oracle/APEX de PRODUCCIÓN y se requiera consultar, validar una query o comparar resultados. Su trabajo es estrictamente de solo lectura: no modifica APEX, Oracle, datos, objetos, jobs ni configuración AWS.
- Usar `aws-etl-experto` para todo desarrollo y operación AWS: scripts Glue, S3, configuración y ejecución de jobs, Glue Catalog, Athena, particiones, backfills, promociones, correcciones y gates de cierre.
- La comparación de fuente debe fijar periodo, filtros, grano y métricas equivalentes. Una diferencia no explicada deja la validación funcional en seguimiento; un `SUCCEEDED` no es cierre suficiente.

## Arquitectura y método

- Mantener `<PROJECT_ROOT>/JOB/`, `glue_jobs/manifests/`, `glue_jobs/scripts/`, `glue_jobs/sql/`, `docs/operacion/validaciones-fuente/`, `docs/arquitectura/`, `openspec/changes/` y `TMP/` según el estándar AWS. `TMP/` nunca es evidencia ni destino final.
- Al iniciar, registrar tarea, fuente oficial, objeto AWS objetivo, ambiente, autorización y si la comparación Oracle/APEX de PRODUCCIÓN aplica.
- Si aplica fuente Oracle/APEX, primero obtener evidencia de solo lectura con `desarrollador-apex`; después implementar y validar en AWS con `aws-etl-experto`; finalmente comparar resultados equivalentes y registrar evidencia.
- No usar la fuente productiva para desarrollo ni para cambios de datos. Las consultas de fuente original son evidencia de validación, no una dependencia para editar PRODUCCIÓN.
- Para documentación de arquitectura, crear o actualizar progresivamente solo los documentos afectados por cambios autorizados y con evidencia verificable.
- Si existe paquete padre de `Gestion-Proyectos`, registrar proyecto/entregable/sprint/paquete en `docs/tareas/<ID_TAREA>/tarea.md` y devolver un handoff con versiones, validacion, evidencia, impacto documental y pendientes. El nivel proyecto no coordina los skills internos; los fallos corregibles siguen en el ciclo AWS.
```

## Sección 2 - Preparación del contexto

1. Ejecutar el migrador con `--check`, luego `--dry-run` y finalmente `--apply` si no reporta contradicciones.
2. Crear de forma idempotente las carpetas, `desarrollo-aws.md` y contratos desde `tarea.template.md`; no mover, sobrescribir ni eliminar archivos ambiguos.
3. Confirmar que los skills `aws-etl-experto` y `desarrollador-apex` están instalados y que las herramientas AWS y Oracle requeridas por el alcance están disponibles.
4. Informar configuración pendiente, alcance preparado y el siguiente skill a usar.
