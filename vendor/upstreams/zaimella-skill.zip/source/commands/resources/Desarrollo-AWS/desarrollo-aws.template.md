# Desarrollo AWS ETL

- Creado: <CREATED_AT>
- Proyecto/contexto local: <PROJECT_PATH>
- Responsable: <PENDIENTE>
- Perfil AWS: <PENDIENTE>
- Región AWS: <PENDIENTE>
- Ambientes autorizados: <PENDIENTE>
- Buckets y prefijos S3: <PENDIENTE>
- Bases Glue/Athena: <PENDIENTE>
- Convención de jobs y utilitarios: <PENDIENTE>
- Fuente de bitácora ETL: <PENDIENTE>
- Fuente original Oracle/APEX en PRODUCCIÓN: <APLICA|NO_APLICA|PENDIENTE>
- Repositorio de arquitectura: <LOCAL|RUTA|PENDIENTE>

## Alcance y fuentes oficiales

| Dominio/tabla | Fuente oficial | Job o tabla AWS objetivo | Ambiente | Comparación Oracle/APEX requerida |
| --- | --- | --- | --- | --- |
| <PENDIENTE> | <PENDIENTE> | <PENDIENTE> | <PENDIENTE> | <SI|NO> |

## Reglas locales adicionales

- <PENDIENTE>
