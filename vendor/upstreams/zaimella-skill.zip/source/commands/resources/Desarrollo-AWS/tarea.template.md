# Tarea AWS ETL

## Identidad

- ID tarea: <ID_TAREA>
- Sesion: <SESION>
- Inicio local: <STARTED_AT>
- Fin local: Pendiente
- Duracion total/fases: Pendiente
- Estado: Preparacion | En desarrollo | En validacion | En correccion | En espera | Aprobada | Cerrada

## Vinculo Con Proyecto

- Proyecto padre: <PROJECT_ID_O_NO_APLICA>
- Entregable padre: <DELIVERABLE_ID_O_NO_APLICA>
- Sprint padre: <SPRINT_ID_O_NO_APLICA>
- Paquete padre: <PACKAGE_ID_O_NO_APLICA>
- Contrato recibido: <RUTA_O_NO_APLICA>
- Handoff de salida: <RUTA_O_NO_APLICA>

Estos campos enlazan identidades; no sustituyen subtareas, bitacora ni gates AWS. Cuando existe paquete padre, el orquestador devuelve el handoff solo despues de completar su ciclo interno.

## Alcance

- Fuente oficial: <FUENTE>
- Job, tabla o resultado AWS objetivo: <OBJETIVO>
- Ambiente y region: <AMBIENTE_REGION>
- Incluye: <ALCANCE>
- Excluye: <FUERA_DE_ALCANCE>
- Autorizacion: <AUTORIZACION>
- Comparacion Oracle/APEX de solo lectura: Si | No

## Resultados Verificables

| ID subtarea | Resultado y criterio | Componentes | Dependencias | Desarrollo | Ejecucion | Validacion | Evidencia | Estado |
|---|---|---|---|---|---|---|---|---|
| <ID_TAREA>-ST01 | <RESULTADO_VERIFICABLE> | <JOB_TABLA_RUTA> | <NINGUNA_O_IDS> | Pendiente | Pendiente | Pendiente | Pendiente | Pendiente |

## Cierre De Dominio

- Versiones/SHA:
- Ambientes validados:
- Comparacion equivalente de fuente:
- QA o validacion AWS:
- Evidencia:
- Impacto documental y hechos verificables:
- Riesgo residual/pendientes:
