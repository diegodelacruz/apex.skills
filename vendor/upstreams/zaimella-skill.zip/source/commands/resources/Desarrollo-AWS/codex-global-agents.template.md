<!-- ZAIMELLA:GLOBAL:DESARROLLO-AWS:START -->
# Preparar Proyectos AWS ETL

Cuando el usuario diga `prepara este proyecto AWS` o una petición equivalente:

1. Leer y ejecutar `<ECOSYSTEM_ROOT>/commands/Desarrollo-AWS.md`.
2. Leer los recursos de `<ECOSYSTEM_ROOT>/commands/resources/Desarrollo-AWS/`.
3. Actualizar primero `<PROJECT_ROOT>/AGENTS.md` con `<ECOSYSTEM_ROOT>/scripts/update_aws_agents_md.py`: ejecutar `--check`, revisar `--dry-run` y aplicar `--apply` si no existen contradicciones no migrables.
4. Crear o completar `desarrollo-aws.md`, la bitácora y la estructura de trabajo AWS.
5. Usar `desarrollador-apex` solo para consultas y comparaciones de solo lectura contra la fuente original Oracle/APEX en PRODUCCIÓN; usar `aws-etl-experto` para todo desarrollo, ejecución y validación en AWS.
6. Conservar reglas locales de negocio, seguridad y alcance. Preguntar solo por información necesaria y no inferible.

Después de la preparación, seguir el `AGENTS.md` del proyecto para las tareas AWS posteriores.
<!-- ZAIMELLA:GLOBAL:DESARROLLO-AWS:END -->
