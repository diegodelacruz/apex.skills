# Orquestador Movilmella

## Seccion 1 - Contenido Para AGENTS.md

```markdown
## Coordinacion Movilmella

- `desarrollo.md` es el contrato comun con Desarrollo-APEX: define el contexto, checkout de integración Flutter que se versiona a GitHub, repos vinculados, APP_ID/servicios, ambientes y worktrees. Los worktrees son solo de implementación; todo build, instalación y QA Android se ejecuta exclusivamente desde el checkout de integración. `tarea.md` es la fuente de verdad de un cambio; no duplicar sus datos en este archivo.
- Un contexto puede tener simultaneamente los bloques administrados `Movilmella` y `Desarrollo Apex`. Ambos comparten este unico `desarrollo.md`; cada orquestador aplica solo sus gates al alcance de su tarea, preserva el bloque del otro y no crea contratos ni contextos paralelos. Usar solo Movilmella para tareas Flutter; incorporar Desarrollo-APEX cuando el alcance requiera backend.
- Usar `desarrollador-movilmella` exclusivamente para frontend Flutter, FVM, Android, SQLite, offline, UX, evidencia del cliente y QA movil provisional en dispositivo Android USB. Usar `desarrollador-apex` para consultar, validar o modificar backend: solamente APIs del modulo ORDS `MVZM` y los paquetes Oracle directamente usados por ellas. No cambiar otro modulo ORDS ni objetos Oracle ajenos. Usar `qa-apex` para validacion independiente del backend/API en TEST.
- Antes de QA movil con datos reales, `desarrollador-apex` prepara TEST con `<PROJECT_CONTEXT>/docs/scripts/preparar_ambiente_test_movilmella.py`: primero ejecuta el plan y luego `--execute --grant-movilmella-access` solo para la compania/usuario declarados en `tarea.md`. Valida la cuenta TEST activa en `DATA.VT_CORP_USUARIO` y las APIs `MVZM` requeridas para login y el flujo antes de entregar el ambiente a Movilmella. La credencial TEST se usa solo en sesion privada para el login; nunca se imprime ni se registra.
- Antes de cada login QA, `desarrollador-movilmella` ejecuta el preflight de login del skill con el preparador del contexto, serial ADB y package del flavor. Debe esperar campos editables, confirmar el usuario exacto y mantener la contraseña solo en memoria privada; registrar únicamente resultado seguro `LOGIN_PREFLIGHT_READY` y datos no sensibles.
- Para toda API modificada, registrar request, response, errores, compatibilidad, checkout de integración, SHA Flutter publicado y SHA APEX/Oracle en la tarea. No habilitar QA ni PRODUCCION si el candidato y las evidencias no identifican los mismos SHAs. Antes de Android, comprobar con `git rev-parse --show-toplevel` que se está en el checkout de integración, ejecutar `git fetch`, bloquear cambios locales/discrepancias y comprobar versión del APK y del dispositivo; nunca compilar desde un worktree ni dejar en él carpetas de build o cachés pesadas.
- El checkout Flutter definido en `desarrollo.md` contiene solo codigo, configuracion tecnica y archivos versionados. La bitacora, contratos, evidencias, SQL operativo, pases y temporales viven en este contexto.
- El checkout de integración es único y funciona como ruta genérica de builds: cada tarea crea su worktree desde el SHA publicado vigente, integra su candidato de forma trazable para validarlo allí y, al cerrar, deja ese checkout en el SHA publicado y sin derivados pesados de la sesión. No crear worktrees o checkouts solo para APKs.
- Para una liberacion coordinada, publicar primero el backend compatible, validar integracion Android y API en TEST y liberar el cliente solo con aprobacion y pase a PRODUCCION autorizados. Toda solicitud de APK PROD exige publicar antes el candidato Flutter exacto de la tarea (commit/push si aun tiene cambios sin publicar) y verificar su SHA remoto; no compilar desde commits locales pendientes. GitHub publica fuente; no reemplaza TEST, QA ni autorizacion de PRODUCCION.
- Aislar las tareas por `ID_TAREA`; no usar `git add .`, no tocar cambios ajenos ni publicar una rama `codex/*` por defecto.
- Si existe paquete padre de `Gestion-Proyectos`, registrar sus identidades en `tarea.md` y devolver el handoff en la ruta recibida con SHAs, ambientes, QA, evidencia, impacto documental y pendientes. El proyecto no coordina los skills internos de Movilmella; un defecto corregible sigue en este ciclo.
```

## Seccion 2 - Preparacion Del Contexto

1. Ejecutar el migrador de `AGENTS.md` con `--check`, `--dry-run` y `--apply`.
2. Crear idempotentemente `docs/tareas/`, `docs/evidencias/`, `docs/logs/`, `docs/pases-produccion/` y `tmp/` en el contexto, no en el checkout Flutter.
3. Crear o completar `desarrollo.md` desde la plantilla compartida de Desarrollo-APEX. Completar la seccion Movilmella sin sobrescribir campos APEX existentes.
4. Crear cada `docs/tareas/<ID_TAREA>/tarea.md` desde `tarea.template.md`; registrar repos, base SHA, alcance, contrato API, modulo ORDS `MVZM`, paquetes autorizados, ambiente, gates y evidencia requerida.
5. Antes de implementar, comparar la tarea contra bitacora, `git status`, `git diff --name-only` y staged files de cada repositorio involucrado. Aislar solamente los conflictos reales.
6. Antes de QA movil que necesite visitas, encuestas, PDV, portafolio u otros datos reales, `desarrollador-apex` valida conectividad PROD/TEST, ejecuta el preparador sin `--execute`, revisa el candidato y ejecuta `--execute --grant-movilmella-access`. Confirmar despues cuenta activa TEST, login y endpoints `MVZM` del flujo; registrar solo usuario, compania, conteos y resultado, nunca la contrasena.
