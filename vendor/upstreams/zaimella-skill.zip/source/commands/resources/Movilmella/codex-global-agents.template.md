<!-- ZAIMELLA:GLOBAL:MOVILMELLA:START -->
# Preparar Proyectos Movilmella

Cuando el usuario diga `prepara este proyecto Movilmella` o una peticion equivalente:

1. Leer y ejecutar `<ECOSYSTEM_ROOT>/commands/Movilmella.md`.
2. Leer los recursos de `<ECOSYSTEM_ROOT>/commands/resources/Movilmella/` y las referencias aplicables de los tres skills coordinados.
3. Ejecutar `scripts/update_movilmella_agents_md.py` con `--check`, revisar `--dry-run` y usar `--apply` solo si preserva reglas locales y el bloque APEX existente.
4. Crear o completar el `desarrollo.md` compartido y los contratos por tarea; registrar el checkout de integración Flutter que se versiona a GitHub, separado de los worktrees. Todo build, instalación y QA Android se ejecuta desde ese checkout con SHA publicado y versión contractual; antes de QA movil con datos reales, preparar TEST mediante el script versionado del contexto y validar usuario/API con `desarrollador-apex`.
5. Conservar reglas locales de negocio, seguridad y alcance. Pedir solo informacion no inferible.

Despues de la preparacion, seguir el `AGENTS.md` del contexto para las tareas Movilmella posteriores.
<!-- ZAIMELLA:GLOBAL:MOVILMELLA:END -->
