# Tarea Movilmella

## Identidad

- ID tarea: <ID_TAREA>
- Sesion: <SESION>
- Inicio local: <STARTED_AT>
- Fin local: <PENDIENTE>
- Duracion total/fases: <PENDIENTE>
- Estado: Pendiente
- Modalidad: <MOVILMELLA_ORACLE|APEX_ORACLE|SOLO_MOVILMELLA>

## Vinculo Con Proyecto

- Proyecto padre: <PROJECT_ID_O_NO_APLICA>
- Entregable padre: <DELIVERABLE_ID_O_NO_APLICA>
- Sprint padre: <SPRINT_ID_O_NO_APLICA>
- Paquete padre: <PACKAGE_ID_O_NO_APLICA>
- Contrato recibido: <RUTA_O_NO_APLICA>
- Handoff de salida: <RUTA_O_NO_APLICA>

Estos campos enlazan identidades; no sustituyen gates, repositorios ni contrato API. Si existe paquete padre, `Movilmella` conserva toda su coordinacion interna y devuelve el handoff al completar su ciclo.

## Alcance Y Repos

- Contexto: <PROJECT_CONTEXT>
- Checkout de integración Flutter: <MOVILMELLA_INTEGRATION_CHECKOUT_DESDE_DESARROLLO_MD>
- Worktree de implementación (si aplica; prohibido para build/QA): <WORKTREE_O_NO_APLICA>
- Repo Flutter / SHA base / rama de tarea: https://github.com/zaimella/Zaimella-Movilmella / <SHA> / codex/<ID_TAREA>
- Repo APEX/Oracle / SHA base / rama: <REPO_O_NO_APLICA> / <SHA_O_NO_APLICA> / codex/<ID_TAREA>
- APP_ID/servicio ORDS: <PENDIENTE_O_NO_APLICA>
- Modulo ORDS autorizado: MVZM
- Paquetes Oracle autorizados: <SOLO_LOS_DIRECTAMENTE_USADOS_POR_LAS_APIS_DEL_ALCANCE>
- Fuera de alcance: <PENDIENTE>

## Candidato Flutter Para Build Y QA

- Checkout de integración autorizado: <MOVILMELLA_INTEGRATION_CHECKOUT_DESDE_DESARROLLO_MD>
- Rama remota / SHA completo publicado autorizados: <ORIGIN_MAIN_U_OTRA_RAMA_AUTORIZADA> / <SHA_COMPLETO>
- `pubspec.yaml` `version:` esperado: <VERSION_NAME+BUILD_NUMBER>
- Flavor / entrypoint: <DEV|PROD> / <LIB_MAIN>
- Paquete Android esperado: <APPLICATION_ID>
- APK esperado: <RUTA_RELATIVA>
- Excepción de downgrade autorizada: No

## Contrato De Integracion

| Elemento | Antes | Despues | Compatibilidad | Evidencia |
|---|---|---|---|---|
| Endpoint/request/response/error |  |  |  |  |

## Gates

- Flutter: analisis, pruebas aplicables y smoke Android cuando el cambio sea visible o funcional.
- Candidato Android: compilar exclusivamente en el checkout de integración declarado en `desarrollo.md`; nunca desde un worktree. Antes de compilar, ejecutar `git rev-parse --show-toplevel` y `git fetch`; comprobar checkout, rama remota, SHA publicado y `pubspec.yaml` contra la sección `Candidato Flutter Para Build Y QA`. Comprobar después paquete y `versionName`/`versionCode` del APK; antes y después de instalar, comparar la versión del dispositivo. Bloquear discrepancias, cambios locales o downgrade salvo excepción explícita registrada. El worktree solo conserva cambios versionables de la tarea, sin `build/`, `.dart_tool/`, Gradle, `.cxx` ni APK/AAB.
- QA movil provisional: solicitar celular Android USB, APK DEV nueva, caso funcional, evidencia y `Aprobado`/`No aprobado`/`Impedimento externo`. El emulador solo sirve para smoke tecnico aislado; no sustituye QA funcional ni permite cerrar un cambio visible como validado.
- Datos QA TEST: antes de QA con datos reales, `desarrollador-apex` ejecuta `<PROJECT_CONTEXT>/docs/scripts/preparar_ambiente_test_movilmella.py` en plan y luego con `--execute --grant-movilmella-access` para la compania/usuario de esta tarea. Validar `DATA.VT_CORP_USUARIO` TEST y las APIs `MVZM` de login/flujo; registrar usuario, conteos y resultado, sin contrasena.
- Login QA: ejecutar el preflight del skill con preparador, compañía, usuario si aplica, serial ADB y package del flavor. Exigir `LOGIN_PREFLIGHT_READY` y registrar solo usuario/compañía/package/resultado antes de enviar login; nunca registrar ni exponer la contraseña.
- Backend: `desarrollador-apex` consulta, valida o modifica exclusivamente APIs `MVZM` y sus paquetes autorizados; valida persistencia/rechazo controlado cuando aplique.
- TEST/QA: mismo SHA Flutter y APEX/Oracle identificados; QA independiente para backend/API.
- PRODUCCION: autorizacion explicita, backend compatible primero, artefacto Android y fuente Git trazables. Antes de cada APK PROD, publicar el candidato de la tarea (commit/push de su inventario exclusivo si aun no esta publicado) y comprobar el SHA completo en la rama remota autorizada; bloquear el build ante commits locales pendientes, push fallido o divergencia.

## Resultados

- SHA Flutter candidato/publicado:
- Candidato Android verificado (checkout de integración/rama remota/SHA publicado/pubspec/APK/versión previa-posterior):
- SHA APEX/Oracle candidato/publicado:
- Ambiente y validaciones:
- Preparacion datos TEST / usuario / APIs:
- Evidencias:
- Riesgo residual/pendientes:
