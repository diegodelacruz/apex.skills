# Registro De Hallazgos APEX

Este registro conserva hallazgos tecnicos u operativos de tareas y recuperaciones. No sustituye `errores/#<NUMERO_ERROR>.md`, que documenta reportes de usuarios, ni sustituye el informe QA.

## Uso

- Registrar un hallazgo cuando revele una regla, contrato, herramienta, prompt o control que pueda mejorarse de forma reutilizable.
- No incluir credenciales, datos personales, datos productivos sensibles, exports completos ni capturas. Referenciar evidencia segura por ruta, SHA o identificador.
- Un hallazgo no modifica por si solo un skill u orquestador. Al mejorar el ecosistema, revisar los hallazgos abiertos, generalizar solo la leccion reusable y registrar la decision en la bitacora del ecosistema.
- Los hallazgos automaticos del reconciliador se deduplican por su huella; no eliminar entradas historicas. Cerrar o descartar un hallazgo agregando una actualizacion que cite su identificador.

## Hallazgos

<!-- ZAIMELLA:APEX:FINDINGS:START -->
<!-- ZAIMELLA:APEX:FINDINGS:END -->
