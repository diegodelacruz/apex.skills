# Caso #<NUMERO_CASO> - <TITULO>

## Control

- Estado: Abierto | Analisis | En desarrollo TEST | En QA TEST | Listo para cierre autorizado | Cerrado | Cancelado
- Fecha de apertura: <YYYY-MM-DD HH:MM>
- Ultima actualizacion: <YYYY-MM-DD HH:MM>
- Aplicacion y objetos autorizados: <DESDE_DESARROLLO_MD>
- ID tarea: <CASE_ID_O_NO_APLICA>
- Candidato TEST / SHA: <PENDIENTE_O_NO_APLICA>
- Autorizacion de cierre, GitHub y PRODUCCION: Pendiente de instruccion expresa del usuario

## Solicitud original

> <TEXTO_LITERAL_O_RESUMEN_FIEL>

## Tipo y alcance

- Tipo: Mejora | Correccion | Analisis | Consulta
- Resultado solicitado:
- Paginas, flujos y objetos dentro del alcance de `desarrollo.md`:
- Fuera de alcance y dependencias:

## Analisis y decisiones

- Fuente consultada y ambiente:
- Hallazgos comprobados:
- Decisiones o aclaraciones del usuario:
- Cambio propuesto o respuesta de consulta:

## Ejecucion y evidencias

- Cambios en TEST / archivos / objetos:
- Validaciones tecnicas:
- QA funcional o tecnico acotado:
- Riesgos, limpieza y pendientes:

## Cierre pendiente o autorizado

- Condicion para quedar listo: <TEST_QA_O_RESPUESTA_ENTREGADA>
- Instruccion expresa de cierre recibida: <SI_NO_FECHA>
- GitHub: <NO_AUTORIZADO_PENDIENTE_PUBLICADO_SHA>
- PRODUCCION: <NO_APLICA_NO_AUTORIZADA_PENDIENTE_EJECUTADA>
- Evidencia final:
