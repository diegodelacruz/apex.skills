# Contrato ORDS/OAuth

## Identidad Y Fuente

- ID tarea: <ID_TAREA>
- Owner Oracle: <OWNER>
- Modulo ORDS: <MODULO>
- Base path: <BASE_PATH>
- Package publicador `AUTHID DEFINER`: <OWNER.PACKAGE>
- Carpeta fuente: `ORACLE/<OWNER>/ORDS/<MODULO>/`
- Deploy versionado: <RUTA_DEPLOY_SQL>
- Version API esperada: <VERSION>

## Contrato HTTP

| Metodo | Template | Privilegio | Request/binds | Respuesta | Consumidor |
|---|---|---|---|---|---|
|  |  |  |  |  |  |

## OAuth Por Ambiente

| Ambiente | Cliente contractual | Token URL externa | API base externa | Custodio/vault logico | Estado |
|---|---|---|---|---|---|
| TEST |  |  |  |  | Ausente / CREATED / REUSED |
| PRODUCCION |  |  |  |  | Ausente / CREATED / REUSED |

No registrar `client_id`, `client_secret`, access tokens ni contenido del almacen DPAPI. Registrar solo fingerprints emitidos por el helper.

## Mantenimiento Y Reversa

- Estrategia incremental sin `ORDS.DELETE_MODULE`:
- Elementos que deben preservarse:
- Backup o constatacion de ausencia:
- Reversa autorizada:
- Rotacion OAuth: No aplica al release | Cambio coordinado independiente
- Transporte: HTTPS | Excepcion HTTP legada documentada y plan TLS
- Recuperacion desde Oracle: `DATA.<PACKAGE>.RECUPERAR_OAUTH` | No aplica justificado
- Custodios con ejecucion autorizada y evidencia de sesion: <CUENTAS/ROLES_O_NO_APLICA>

## Gates TEST

| Gate | Evidencia | Estado |
|---|---|---|
| `validate_ords_deploy.py` devuelve `ORDS_STATIC_AUDIT_PASS` |  | Pendiente |
| Package publicador `VALID`; `ALL_ERRORS=0` |  | Pendiente |
| Metadata de modulo/template/handler/privilegio conforme |  | Pendiente |
| Provision/reprovision devuelve `CREATED` o `REUSED` sin rotacion |  | Pendiente |
| Anonimo 401/403; token OK; autenticado 200 |  | Pendiente |
| Mantenimiento con el mismo OAuth |  | Pendiente |
| Recuperacion de cache perdida desde Oracle sin imprimir secretos | `RECOVERED_FROM_ORACLE`, fingerprints y smoke | Pendiente |

## Gates PRODUCCION

| Gate | Evidencia | Estado |
|---|---|---|
| Autorizacion y QA TEST del mismo SHA |  | Pendiente |
| Commit exacto publicado en `origin/main`; deploy SHA-256 identico |  | Pendiente |
| Ejecucion sincrona bajo owner por package `AUTHID DEFINER` |  | Pendiente |
| Cliente creado solo si ausente; si existe, `REUSED` |  | Pendiente |
| Metadata, objeto, errores, HTTP anonimo/autenticado y version conformes |  | Pendiente |
| Sesiones propias pendientes = 0 |  | Pendiente |

## Resultado

- TEST:
- QA tecnica/funcional:
- PRODUCCION:
- Fingerprints registrados sin secretos:
- Pendientes o riesgos:
