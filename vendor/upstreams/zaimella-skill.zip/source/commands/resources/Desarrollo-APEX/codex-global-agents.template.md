<!-- ZAIMELLA:GLOBAL:DESARROLLO-APEX:START -->
# Preparar Proyectos APEX

Cuando el usuario diga `prepara este proyecto APEX` o una peticion equivalente:

1. Leer y ejecutar `<ECOSYSTEM_ROOT>/commands/Desarrollo-APEX.md` como procedimiento de preparacion.
2. Leer los recursos indicados en `<ECOSYSTEM_ROOT>/commands/resources/Desarrollo-APEX/`.
3. Actualizar primero el `AGENTS.md` de la raiz del proyecto con `<ECOSYSTEM_ROOT>/scripts/update_apex_agents_md.py`: ejecutar `--check`, revisar `--dry-run` y aplicar `--apply` si no hay contradicciones no migrables.
4. Aplicar en ese `AGENTS.md` el bloque persistente canonico de `Desarrollo-APEX`, que define cuando usar `desarrollador-apex` y `qa-apex`.
5. Crear o completar `desarrollo.md` y preparar la arquitectura, contratos y controles por tarea.
6. Verificar que el `Stop hook` global de continuidad APEX esta instalado. Si Codex lo marca como no confiable, indicar al usuario que lo revise una vez mediante `/hooks`.
7. Conservar reglas locales de negocio, seguridad y alcance. Preguntar solo por informacion importante que no pueda descubrirse de forma segura.

Despues de la preparacion, seguir el `AGENTS.md` del proyecto para las tareas APEX posteriores.
<!-- ZAIMELLA:GLOBAL:DESARROLLO-APEX:END -->
