# Reglas De Integracion Segura Del Orquestador

El bloque administrado tiene exactamente los marcadores `<!-- ZAIMELLA: Desarrollo Apex :START -->` y `<!-- ZAIMELLA: Desarrollo Apex :END -->`. El script elimina los bloques APEX administrados anteriores y las secciones heredadas de coordinación, antes de insertar este único bloque canónico.

Patrones migrables:

- los bloques previos de orquestación, desarrollo y QA generados por versiones anteriores;
- la sección `Manual De Usuario APEX` y secciones APEX de sesión única sustituidas;
- prohibiciones explícitas de iniciar una tarea nueva solo porque otra tarea está activa.
- reglas APEX heredadas que tratan un lock, checkout ocupado, error corregible o QA no aprobado como terminación o bloqueo total de la tarea.
- reglas que permiten cerrar el turno con un timeout, diagnostico, correccion, reconciliacion o reintento propio todavia pendiente, incluso si declaran que la tarea permanece abierta.

La migracion elimina esas reglas obsoletas para que no compitan con concurrencia controlada. No modifica reglas de negocio, seguridad, aprobaciones, alcance funcional, datos sensibles ni instrucciones ajenas a la coordinacion APEX.

Antes de aplicarlo, revisar el contenido externo y bloquear si ordena alguna de estas conductas para el mismo flujo APEX:

- desarrollar directamente en `C:/ZAIMELLA`;
- liberar el lock de TEST al terminar QA antes de publicar/rollback/transferir;
- que QA implemente correcciones o reescriba la navegación normal;
- publicar una rama `codex/*`, exigir PR, o ejecutar PRODUCCIÓN antes del SHA aprobado en `origin/main`.
- detener o cerrar una tarea APEX por un error corregible, lock, checkout ocupado, compilación/importación fallida o hallazgo QA, en vez de corregir, serializar la fase y continuar.
- responder como cierre `aun estoy`, `sigo corrigiendo`, `falta`, `no cierro hasta`, `hasta diagnosticar`, `queda pendiente` o una promesa futura equivalente cuando la siguiente accion es segura y pertenece al agente.

## Stop Hook De Codex

- `install_global_codex_orchestrators.py` fusiona el evento `Stop` en `~/.codex/hooks.json` sin eliminar hooks externos y apunta al script publicado del runtime.
- El hook solo solicita continuacion si coinciden proyecto con bloque canonico, tarea activa con gate terminal y ultimo mensaje que reconoce trabajo pendiente o declara un veredicto incompatible con el estado.
- `stop_hook_active=true` desactiva una segunda intervencion para evitar ciclos infinitos. El hook no cambia `tarea.md`, no ejecuta fases y no reemplaza al orquestador.
- Codex exige revisar y confiar hooks no administrados. Informar `/hooks` despues de instalar o cambiar la definicion; no afirmar que esta activo antes de esa revision.
- Fuente de contrato: `https://learn.chatgpt.com/docs/hooks#stop`.

Una regla local más estricta no es contradicción si solo agrega evidencia, aprobaciones o restricciones sin cambiar estos gates. Registrar la decisión antes de aplicar una excepción autorizada. No tratar como "más estricta" una regla heredada de una tarea a la vez: debe migrarse porque bloquea concurrencia segura sin evaluar conflicto real.
