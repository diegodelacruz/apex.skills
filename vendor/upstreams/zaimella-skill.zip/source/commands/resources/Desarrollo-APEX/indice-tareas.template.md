# Indice De Tareas APEX

> Archivo generado por `reconcile_apex_project_state.py`. No editar manualmente la tabla: actualizar los contratos `tarea.md` y ejecutar el reconciliador.

<!-- ZAIMELLA:APEX:TASK-INDEX:START -->
| ID tarea | Sesion | Estado confirmado | Cierre | QA | Produccion | SHA relevante | Ultima actividad | Siguiente accion |
|---|---|---|---|---|---|---|---|---|
<!-- ZAIMELLA:APEX:TASK-INDEX:END -->
