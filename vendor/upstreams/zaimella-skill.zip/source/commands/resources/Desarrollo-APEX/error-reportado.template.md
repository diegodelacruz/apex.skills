# Error reportado #<NUMERO_ERROR> - <TITULO>

## Control

- Estado: Reportado | En analisis | Clasificado | Derivado a caso | Cerrado informado
- Fecha de reporte: <YYYY-MM-DD HH:MM>
- Ultima actualizacion: <YYYY-MM-DD HH:MM>
- Aplicacion y objetos autorizados: <DESDE_DESARROLLO_MD>
- Caso relacionado: <NO_APLICA_O_#NUMERO_CASO>

## Reporte del usuario

> <MENSAJE_LITERAL_DEL_USUARIO>

- Usuario, compania, fecha/hora y datos usados: <SI_ESTAN_DISPONIBLES_SIN_SECRETOS>
- Pantalla, accion y resultado observado:
- Resultado que el usuario esperaba:

## Diagnostico inicial

- Reproduccion o evidencia consultada:
- Datos, reglas, permisos y formato evaluados:
- Fuente y ambiente consultados:
- Hallazgos comprobados:

## Clasificacion

- Resultado: Uso o dato invalido | Comportamiento definido | Defecto funcional | Excepcion no controlada | Evidencia insuficiente
- Explicacion y evidencia:
- Accion inmediata segura: Informar al usuario | Corregir dato autorizado | Abrir/relacionar caso | Solicitar evidencia puntual

## Seguimiento

- Instruccion posterior del usuario:
- Caso, tarea TEST, QA y SHA, si existe:
- Comunicacion de resultado al usuario:
- Cierre informado: <SI_NO_FECHA>

## Aprendizaje Reutilizable

- Requiere hallazgo operativo: Si | No | Pendiente
- Hallazgo relacionado en `docs/tareas/_control/hallazgos.md`: <ID_O_NO_APLICA>
- Leccion generalizable sin datos sensibles: <TEXTO_O_NO_APLICA>
