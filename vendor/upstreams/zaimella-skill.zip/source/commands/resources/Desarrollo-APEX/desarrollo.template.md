# Desarrollo

> Este contrato admite tareas `Movilmella + Oracle`, `APEX + Oracle` o ambas en paralelo. No crear un segundo `desarrollo.md`: completar solo las secciones aplicables al alcance.

## Campos Base

- Responsable/desarrollador: <OBLIGATORIO_SIN_DEFAULT>
- Proyecto/contexto local: <PROJECT_PATH>
- Repo fuente `zaimella-apex-oracle` remoto: https://github.com/zaimella/zaimella-apex-oracle
- Repo fuente `zaimella-apex-oracle` local: C:/ZAIMELLA
- Raiz local de worktrees por tarea: C:/ZAIMELLA-WORKTREES
- PROJECT_SLUG: app-<APP_ID>-<NOMBRE_PROYECTO_NORMALIZADO>
- Aplicaciones APEX APP_ID: <OBLIGATORIO_SIN_DEFAULT>
- Codigos/prefijos funcionales: <OBLIGATORIO_SIN_DEFAULT>

## Datos Derivados O Confirmados

- Esquema Oracle objetivo: DATA
- Patrones autorizados:
  - <PENDIENTE_SEGUN_CODIGOS>
- Carpeta APEX fuente:
- Carpeta Oracle fuente:

## Aplicaciones APEX Confirmadas

| APP_ID | Nombre aplicacion | Codigo funcional | Carpeta fuente |
|---|---|---|---|
|  |  |  |  |

## Objetos De Alcance

| Tipo | Objeto | Accion | Archivo fuente esperado | Observacion |
|---|---|---|---|---|
| PACKAGE SPEC | DATA.PK_MODULO_OBJETO | modificar | ORACLE/DATA/PAQUETES/SPECS/PK_MODULO_OBJETO.sql | ejemplo, reemplazar o eliminar |
| PACKAGE BODY | DATA.PK_MODULO_OBJETO | modificar | ORACLE/DATA/PAQUETES/BODIES/PK_MODULO_OBJETO.sql | ejemplo, reemplazar o eliminar |
| VIEW | DATA.VT_MODULO_OBJETO | crear/modificar | ORACLE/DATA/VISTAS/VT_MODULO_OBJETO.sql | ejemplo, reemplazar o eliminar |
| TABLE | DATA.T_MODULO_OBJETO | crear/modificar | ORACLE/DATA/TABLAS/T_MODULO_OBJETO.sql | ejemplo, reemplazar o eliminar |
| APEX PAGE | APP_ID/PAGE_ID | crear/modificar | APEX/<APP_ID>-<CODIGO_O_NOMBRE_APP>/PAGINAS/page_<PAGE_ID_4_DIGITS>.sql | ejemplo, reemplazar o eliminar |

## Fuera De Alcance

- Objetos compartidos no autorizados:
- Aplicaciones no incluidas:
- Datos productivos o sensibles:

## Reglas De Trabajo

- Ambiente Oracle de implementacion/compilacion: TEST (no existe ambiente DEV)
- Ambiente de validacion: TEST
- Fuente de verdad para APEX:
- Fuente de verdad para Oracle:
- Requiere QA funcional: si/no
- Requiere pase a produccion: si/no
- Restricciones o aprobaciones:
- Integracion: la ruta indicada en `Repo fuente zaimella-apex-oracle local` se usa solo para integrar, revisar y publicar; su valor por defecto es `C:/ZAIMELLA`. Las sesiones editan exclusivamente en `Raiz local de worktrees por tarea/<REPO_SLUG>/<PROJECT_SLUG>/<ID_TAREA>`; su valor por defecto es `C:/ZAIMELLA-WORKTREES`. El agente genera `PROJECT_SLUG` con APP_ID y nombre normalizado del proyecto.
- Publicacion Git: integrar la tarea aprobada y hacer push directo a `origin/main`; no publicar ramas `codex/*` ni crear PR salvo solicitud explicita o proteccion del remoto.
- Operacion por tarea: usar `docs/tareas/<ID_TAREA>/` y `qa/tareas/<ID_TAREA>/`; no compartir deploy, informe QA ni evidencias entre tareas paralelas.

## Configuracion QA APEX TEST

- URL login APEX TEST para QA: http://sistemas.zaimella.com:8090/apex/f?p=100:9999::::::
- Usuario QA APEX TEST: <OBLIGATORIO_PARA_QA_VISUAL_O_NO_APLICA>
- Login APEX TEST requiere contrasena: <SI_NO_O_NO_APLICA>
- Las credenciales o secretos requeridos se obtienen desde la configuracion externa autorizada; nunca se guardan en este contrato.

## Configuracion ORDS/OAuth (Completar Solo Si Aplica)

- Owner y modulos ORDS autorizados: <LISTA_O_NO_APLICA>
- URLs TEST de token/API: <REFERENCIAS_EXTERNAS_O_NO_APLICA>
- URLs PRODUCCION de token/API: <REFERENCIAS_EXTERNAS_O_NO_APLICA>
- Gestor corporativo y custodio logico de OAuth: <UBICACION_SIN_SECRETOS_O_NO_APLICA>
- Cache local permitida: `%USERPROFILE%/.zaimella/ords-oauth/` cifrada con DPAPI; no sustituye el vault.
- Los clientes OAuth se asignan por consumidor y ambiente, se conservan entre releases y no se incluyen sus valores en este archivo.

## Sesion Inicial

- Fecha de preparacion: <CREATED_AT>
- Procedimiento de preparacion: Desarrollo-APEX
- Estado: Pendiente de completar campos obligatorios

## Integracion Movilmella (Completar Solo Si Aplica)

- Repo fuente `Zaimella-Movilmella` remoto: https://github.com/zaimella/Zaimella-Movilmella
- Repo fuente `Zaimella-Movilmella` local: <PENDIENTE_O_NO_APLICA>
- Checkout Flutter: contiene exclusivamente codigo, configuracion tecnica y archivos versionados de la aplicacion; no contiene contratos, bitacora, evidencias, pases, SQL operativo ni temporales.
- APP_ID/servicios ORDS/APEX relacionados: <PENDIENTE_O_NO_APLICA>
- Modulo ORDS autorizado para Movilmella: MVZM
- Paquetes Oracle permitidos: solo los directamente usados por APIs `MVZM` de la tarea; enumerarlos en `tarea.md`.
- Ambientes integrados: Flutter DEV -> ORDS/APEX TEST -> PRODUCCION autorizada.
- Preparacion datos QA TEST: para una QA movil que requiera datos reales, usar `<PROJECT_CONTEXT>/docs/scripts/preparar_ambiente_test_movilmella.py` mediante `desarrollador-apex`; el contrato de tarea define compania, usuario, APIs `MVZM` y resultado. Las credenciales TEST se usan solo para la sesion de prueba y nunca se registran.
- Compatibilidad API: documentar version, request, response, error y estrategia compatible hacia atras por tarea cuando cambie un endpoint.
- Publicacion coordinada: registrar en `tarea.md` SHA Flutter, SHA APEX/Oracle, SHA validado en TEST, artefacto Android y orden de despliegue. GitHub publica fuente; no sustituye los gates de TEST ni el pase autorizado a PRODUCCION.
