# Navegacion <APP_ID>/<PAGE_ID> - <NOMBRE_FUNCIONAL>

- Estado de navegacion: Validado por Desarrollo
- Ambiente: <AMBIENTE_QA_TEST>
- Login: <URL_LOGIN_APEX_TEST_DE_DESARROLLO_MD>
- Usuario QA: <USUARIO_QA_APEX_TEST_DE_DESARROLLO_MD>
- Login requiere contrasena: <SEGUN_DESARROLLO_MD>
- Compania: <COMPANIA_O_NO_APLICA>
- Control visible de usuario: <LABEL_STATIC_ID_O_SELECTOR_VISIBLE>
- Control/accion visible de compania: <LABEL_STATIC_ID_O_SELECTOR_VISIBLE_O_NO_APLICA>
- Boton visible de ingreso: <ETIQUETA_STATIC_ID_O_SELECTOR_VISIBLE>
- Marcador de sesion correcta: usuario <USUARIO_QA_APEX_TEST_DE_DESARROLLO_MD> en <UBICACION_VISIBLE>; compania <COMPANIA> en <UBICACION_VISIBLE_O_VALIDACION_APLICABLE>
- Clasificacion de destino: principal | secundaria_parametrizada | dialogo_modal
- Regla de entrada: `principal` entra por menu o URL autenticada con `DIRECT_URL_ALLOWED`; `secundaria_parametrizada` solo desde su pagina principal con parametro/contexto; `dialogo_modal` solo desde su pagina padre con contexto.
- Pagina principal/padre: <APP_ID>/<PAGE_ID_O_NO_APLICA>
- Parametro o contexto obligatorio de entrada: <ITEM_ID_FILTRO_REGISTRO_SELECCIONADO_O_NO_APLICA>

## Diagnostico Previo De Acceso

- Resultado de `diagnose_apex_navigation_access.py`: <TEST_READY | RECONCILE_TEST_FROM_PROD | USER_DECISION_REQUIRED>
- Fecha y evidencia de salida: <YYYY-MM-DD_HHMM_RUTA_LOG_O_SALIDA>
- Decision ejecutada: <PROBAR_RUTA_TEST | RECONCILIAR_TEST_VERSIONADO | DECISION_USUARIO>
- Mapa funcional exportado: <RUTA_RELATIVA_A_MAPA_GENERADO_POR_extract_apex_page_navigation.py>
- Fuente APEX analizada: <RUTA_RELATIVA_PAGE_SQL_Y_SHA_CANDIDATO>

## Ruta Oficial

1. Iniciar sesion con <USUARIO_QA_APEX_TEST_DE_DESARROLLO_MD> y aplicar el modo de contrasena declarado en `desarrollo.md`.
2. Seleccionar compania: <ACCION_O_NO_APLICA>.
3. Entrar a la aplicacion desde: <MENU_O_LANZADOR>.
4. Abrir <PAGINA_O_REGION_ORIGEN> mediante <ETIQUETA_VISIBLE_DE_BOTON_LINK_O_ACCION>. Para `secundaria_parametrizada` o `dialogo_modal`, esta es obligatoriamente la pagina principal/padre y debe entregar el parametro o contexto documentado; no exigir menu directo al destino.
5. <PASO_INTERMEDIO_O_NO_APLICA>.
6. Llegar a <APP_ID>/<PAGE_ID> y comprobar <MARCADOR_VISIBLE_DE_CARGA>.

## Ruta Alternativa Validada

- Usar solo si falla la ruta primaria: <URL_RAPIDA_AUTENTICADA_DIRECT_URL_ALLOWED_O_PAGINA_PADRE_Y_ACCION>
- Tipo: URL rápida autenticada | página padre + acción | No aplica
- Validación realizada por desarrollo: <FECHA_RUNNER_RESULTADO>
- Restricción: no construir una URL ni una sesión por inferencia durante QA.

## Evidencia De Navegacion Probada

- Evidencia de ruta primaria: <RUTA_RELATIVA_A_CAPTURA_LOG_O_TRAZA_REAL>
- Evidencia de ruta alternativa: <RUTA_RELATIVA_A_CAPTURA_LOG_O_TRAZA_REAL>

## Trazabilidad De Dialogo O Modal

- Entrada navegable: <APP_ID>/<PAGE_ID> - <NOMBRE>, o `No aplica`.
- Paso 1: <PAGINA_ORIGEN>, <BOTON_LINK_ACCION>, resultado esperado.
- Paso intermedio: <PAGINA_O_DIALOGO>, <BOTON_LINK_ACCION>, resultado esperado; o `No aplica`.
- Paso final: <PAGINA_PADRE>, <BOTON_LINK_ACCION_QUE_ABRE_DESTINO>, resultado esperado; o `No aplica`.

## Componentes Y Funcionamiento

- Pantalla padre: <APP_ID>/<PAGE_ID_O_NO_APLICA>
- Accion que abre: <ETIQUETA_VISIBLE_Y_TIPO>
- Componentes internos que deben activarse: <TAB_ACORDEON_REGION_O_NO_APLICA>
- Accion exacta que ejecuta QA: <ACCION_PRINCIPAL>
- Proceso APEX/PLSQL o comportamiento relevante: <PROCESO_O_COMPORTAMIENTO>
- Datos minimos o precondiciones: <DATOS_TEMPORALES_PERMITIDOS_Y_PERMISOS>
- Archivo de prueba QA: <RUTA_RELATIVA_A_ARCHIVO_TEMPORAL_O_NO_APLICA>
- Resultado esperado: <RESULTADO_COMPROBABLE_ANTES_ACCION_DESPUES>
- Mensaje esperado: <MENSAJE_O_SIN_MENSAJE>
- Flujos alternos que no aplican: <DETALLE_O_NINGUNO>

## Condiciones Y Pasos Por Componente

Completar una fila por cada tabla, reporte, grilla, región, botón o componente del alcance que no se muestre o no se cargue inmediatamente. No dejar condiciones técnicas sin traducción a una acción reproducible por QA.

| Componente visible / región | Condición APEX o filtro técnico | Variable/item y valor QA que la satisface | Cómo obtiene o llena el valor | Acción visible que dispara carga/refresh | Resultado visible esperado | Espera / marcador de fin |
|---|---|---|---|---|---|---|
| <NOMBRE_VISIBLE> | <SERVER_CONDITION_WHERE_O_NO_APLICA> | <ITEM_VARIABLE_Y_VALOR> | <PASO_VISIBLE_O_DATO_PREPARADO> | <BOTON_LINK_ACCION_DINAMICA> | <COLUMNAS_FILAS_MENSAJE_O_ESTADO> | <SPINNER_O_MARCADOR> |

Si una condición depende de un valor derivado, explicar el origen funcional de ese valor (por ejemplo, compañía, registro seleccionado, fecha, estado o parámetro recibido), no solo su nombre técnico. Si no hay condición, escribir `No aplica` de forma explícita.

## Evidencia

- Marcador de carga correcta: <TITULO_REGION_ITEM_O_BOTON_VISIBLE>
- URL rápida con sesión autenticada: `f?p=<APP_ID>:<PAGE_ID>` | permitida solo para `principal` normal, activa y con acceso validado; debe usarse como ruta alternativa solo si desarrollo obtuvo `DIRECT_URL_ALLOWED`. `No aplica` para `secundaria_parametrizada` y `dialogo_modal`.
- Espera recomendada: esperar marcador visible y fin de spinners APEX; no depender de `networkidle`.
- Ultima validacion: <YYYY-MM-DD>, <USUARIO>, <RESULTADO>

> El orquestador crea este contrato si no existe y copia URL, usuario QA y modo de contrasena desde `desarrollo.md`; no mantiene valores paralelos. Si la tarea modifica el destino, desarrollo actualiza este mismo contrato contra el SHA candidato, sin crear un duplicado. Desarrollo prueba la ruta primaria y la alternativa en TEST con la identidad contractual, registra fecha, resultado y evidencia, reemplaza todos los marcadores y ejecuta `python <RUNTIME_ROOT>/scripts/validate_apex_navigation_contract.py --navigation <ARCHIVO>`. Solo un resultado `NAVIGATION_CONTRACT_OK` permite marcar `Validado por Desarrollo` e invocar QA. QA no deduce, completa ni diagnostica una ruta rechazada; si el contrato falla, el orquestador devuelve la tarea a desarrollo. Si el login termina como `nobody` o sin compania, QA aplica exclusivamente la recuperacion corporativa publicada en sesion limpia.
