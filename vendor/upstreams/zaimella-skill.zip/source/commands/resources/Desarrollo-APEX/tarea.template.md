# Tarea APEX/Oracle

## Identidad

- ID tarea: <ID_TAREA>
- Clave global de tarea: <PROJECT_SLUG>/<ID_TAREA>
- Sesion: <SESION>
- Conversacion Codex: <ID_O_ENLACE_SI_ESTA_DISPONIBLE>
- Ultima sesion Codex registrada: <YYYY-MM-DD HH:MM:SS ZONA_HORARIA>
- Fecha de apertura: <CREATED_AT>
- Responsable: <RESPONSABLE>
- Estado: Preparacion | En desarrollo | Lista para QA | En QA | En correccion | En espera | Aprobada para cierre | Bloqueada | Cerrada
- Cierre: Pendiente | Cerrada por pase productivo | Cerrada por aprobacion del usuario | Cerrada sin pase productivo | Reabierta explicitamente
- Fecha/hora de cierre: <YYYY-MM-DD HH:MM:SS ZONA_HORARIA | Pendiente>
- Autorizacion o instruccion de cierre: <CITA/REFERENCIA EN BITACORA | Pendiente>
- Evidencia que permite cerrar: <RUTAS, SHA, QA, PASE O `No aplica` JUSTIFICADO>

Transiciones obligatorias: `Preparacion -> En desarrollo -> Lista para QA -> En QA -> Aprobada para cierre`. Si QA identifica una brecha u hallazgo, volver a `En correccion -> Lista para QA -> En QA`; no usar `Bloqueada` para una correccion que desarrollo puede resolver. Un lock, conflicto integrable o dependencia temporal deja solo la fase afectada `En espera`, sin detener el resto. `Bloqueada` exige evidencia de que la base de datos o el ambiente objetivo obligatorio siguen inaccesibles tras diagnostico y reintentos razonables, o que el agente necesita una decision material del usuario no definida en la tarea ni inferible desde la tarea, contratos, requerimiento, evidencias, fuente o metadata accesibles, y decidirla alteraria alcance, comportamiento, seguridad o datos.

## Vinculo Con Proyecto

- Proyecto padre: <PROJECT_ID_O_NO_APLICA>
- Entregable padre: <DELIVERABLE_ID_O_NO_APLICA>
- Sprint padre: <SPRINT_ID_O_NO_APLICA>
- Paquete padre: <PACKAGE_ID_O_NO_APLICA>
- Contrato recibido: <RUTA_O_NO_APLICA>
- Handoff de salida: <RUTA_O_NO_APLICA>

Estos campos enlazan identidades; no sustituyen las subtareas ni gates APEX. Si existe paquete padre, `Desarrollo-APEX` conserva toda su coordinacion interna y devuelve el handoff solo al terminar su ciclo.

<!-- ZAIMELLA:APEX:SUBTASKS:START -->
## Subtareas Del Sprint

Toda tarea contiene una o mas subtareas: una subtarea representa un resultado funcional verificable, aunque varias compartan pagina, paquete, tabla u ORDS. No se agrupan resultados distintos bajo una sola fila. En tareas compuestas, OpenSpec es obligatorio y su `tasks.md` debe usar estos mismos IDs y criterios.

| ID subtarea | Objetivo y criterio de aceptacion | Destinos y objetos | Dependencias | Desarrollo | TEST | QA | Evidencia | SHA final | Estado |
|---|---|---|---|---|---|---|---|---|---|
| <ID_TAREA>-ST01 | <RESULTADO_VERIFICABLE> | <PAGINAS_OBJETOS_ORDS> | <NINGUNA_O_IDS> | Pendiente | Pendiente | Pendiente | Pendiente | Pendiente | Pendiente |

Estados de evidencia: antes de QA, cada subtarea debe tener `Desarrollo=Completado`, `TEST=Aprobado`, evidencia y SHA final; para cierre tambien `QA=Aprobado` y `Estado=Aprobada`. `No aplica` solo se permite con justificacion y autorizacion expresa del usuario en la misma fila. Ejecutar `python <RUNTIME_ROOT>/scripts/validate_apex_task_coverage.py --task <PROJECT_ROOT>/docs/tareas/<ID_TAREA>/tarea.md --phase pre-qa` antes de invocar QA y repetir con `--phase close` antes de aprobar cierre. Un resultado global no sustituye la cobertura por subtarea.
<!-- ZAIMELLA:APEX:SUBTASKS:END -->

## Historial De Transiciones

| Fecha/hora | Sesion | Estado anterior | Estado nuevo | Motivo | Evidencia, SHA o ambiente |
|---|---|---|---|---|---|
| <CREATED_AT> | <SESION> | No aplica | Preparacion | Apertura de tarea | Contrato creado |

Agregar una fila por cada cambio de estado, cierre, reapertura o correccion de registro. No reemplazar filas anteriores; la recuperacion usa este historial junto con la evidencia externa.

## Tiempos De Actividad

- Inicio de actividad: <YYYY-MM-DD HH:MM:SS ZONA_HORARIA>
- Fin de actividad: <YYYY-MM-DD HH:MM:SS ZONA_HORARIA | Pendiente>
- Duracion total: <DURACION | Pendiente>

| Fase | Inicio | Fin | Duracion | Resultado o causa de espera |
|---|---|---|---|---|
| Preparacion y analisis |  |  |  |  |
| Desarrollo o correccion |  |  |  |  |
| Integracion y TEST |  |  |  |  |
| QA |  |  |  |  |
| Produccion y validacion post | No aplica | No aplica | No aplica | Requiere autorizacion |

El orquestador registra la hora local al iniciar y finalizar cada fase, y al cerrar la actividad calcula la duracion total. No registra cada comando: solo una espera real, timeout, lock o reintento que explique una fase. Si una fase se repite, agrega una fila nueva con el sufijo `#2`, sin sobrescribir la ejecucion anterior. Esta trazabilidad es obligatoria para toda tarea; no es un gate adicional ni condiciona el avance tecnico.

<!-- ZAIMELLA:APEX:TASK-TERMINAL-GATE:START -->
## Gate Terminal De Respuesta

Terminar una respuesta o devolver el control al usuario es terminar el turno, aunque `Estado` continue abierto. Escribir `no cierro la tarea`, `aun estoy`, `sigo corrigiendo`, `falta`, `antes de finalizar` o una expresion equivalente no autoriza a terminar el turno.

- [ ] No queda diagnostico, recuperacion, correccion, reconciliacion, reintento QA ni siguiente fase normal segura pendiente.
- [ ] `validate_apex_task_coverage.py --phase close` finaliza `APEX_TASK_COVERAGE_PASS`; todas las subtareas tienen desarrollo, TEST, QA, evidencia y SHA final conformes.
- [ ] La tarea termino todo el alcance y gates; o existe causa taxativa de `Bloqueada` con evidencia y una unica pregunta al usuario.
- [ ] La respuesta final contiene un veredicto terminal inequivoco: `COMPLETA` o `BLOQUEADA`.
- [ ] La respuesta final no contiene avances, promesas ni trabajo propio diferido como `hasta diagnosticar`, `queda pendiente`, `continuare despues`, `aun estoy`, `sigo corrigiendo`, `falta` o `antes de finalizar`.

Si alguna casilla no se cumple, emitir solo un avance intermedio y ejecutar inmediatamente la siguiente herramienta o accion segura en el mismo turno. Un avance nunca puede ser el ultimo mensaje del turno.
<!-- ZAIMELLA:APEX:TASK-TERMINAL-GATE:END -->

## Fuente De Verdad Y Recuperacion

- Ultima reconciliacion de sesion: <RUTA `docs/tareas/_control/recuperacion-...md` | No ejecutada>
- Estado de evidencia: No verificado | Parcial | Verificado | Contradictorio
- Ultima transicion confirmada: <FECHA/HORA, ESTADO Y EVIDENCIA>
- Prohibicion de cierre verbal: una afirmacion en chat no cambia este contrato, la bitacora ni el estado.

Toda transicion de estado debe registrar fecha/hora, sesion, estado anterior, estado nuevo, motivo, evidencia y SHA/ambiente cuando aplique. No se sobrescriben transiciones anteriores. `Cerrada` exige QA aprobado cuando aplique. Si hubo PRODUCCION, exige informe de pase, SHA exacto ejecutado y validacion post; si no hubo PRODUCCION, exige la instruccion explicita de cierre del usuario y registrar `No aplica` o el pase pendiente en la seccion Produccion. Abrir una tarea nueva no cierra automaticamente ninguna tarea anterior. Si el usuario autoriza expresamente pasar a una nueva tarea, el orquestador cierra solo la tarea identificada, registra la sesion y la evidencia, y no altera otras sesiones. Si falta una evidencia o existe contradiccion, usar `POR_RECONCILIAR` en la recuperacion y conservar la tarea abierta o en espera hasta resolverlo.

## Rutas Y Git

- Proyecto/contexto: <PROJECT_PATH>
- Repo de integracion: <SOURCE_REPO_ROOT_DESDE_DESARROLLO_MD>
- PROJECT_SLUG: app-<APP_ID>-<NOMBRE_PROYECTO_NORMALIZADO>
- Worktree de tarea: <WORKTREES_ROOT_DESDE_DESARROLLO_MD>/<REPO_SLUG>/<PROJECT_SLUG>/<ID_TAREA>
- Worktree limpio de integración (solo si se requiere): <WORKTREES_ROOT_DESDE_DESARROLLO_MD>/<REPO_SLUG>/<PROJECT_SLUG>/_integracion/<ID_TAREA>
- Rama de tarea: codex/<PROJECT_SLUG>/<ID_TAREA>
- Rama oficial de publicacion: main
- Commit base: <COMMIT_BASE>
- Commit candidato compilado en TEST:
- Commit aprobado por QA:
- Commit publicado en `origin/main`:
- Reporte de integración Git: `docs/tareas/<ID_TAREA>/logs/integracion-git.json` | Pendiente
- Commit candidato reconciliado desde `origin/main`:
- Checkout limpio que genero los artefactos (ruta y `git status --porcelain` vacio):
- SHA256 del SQL ejecutado en TEST:
- SHA256 del SQL autorizado para PRODUCCION:

## Alcance Y Reservas

| Tipo | APP_ID/PAGE_ID/objeto | Archivo fuente canonico | Accion | Reserva completa | Dependencias |
|---|---|---|---|---|---|
|  |  |  |  | Pendiente |  |

Para paquetes Oracle, reservar `PACKAGE` o `PACKAGE BODY` completo. Procedimientos y funciones internos no constituyen unidades de concurrencia separadas.

## Workspace Operativo

- Desarrollo, deploy y logs: `docs/tareas/<ID_TAREA>/`
- QA, reporte y evidencias: `qa/tareas/<ID_TAREA>/`
- `docs/deploy/`: reservado para el pase final integrado o consolidado; no usarlo como workspace paralelo.

## Contrato De Navegacion QA

| Destino APP_ID/PAGE_ID o flujo | Archivo operativo | Estado | Pendiente no inferible |
|---|---|---|---|
|  | `qa/tareas/<ID_TAREA>/navigation/page-<APP_ID>-<PAGE_ID>.md` | Pendiente |  |

Para cada alcance visible o funcional, crear el archivo desde `commands/resources/Desarrollo-APEX/navegacion.template.md`. Desarrollo debe completarlo con la ruta real, accion, datos minimos, resultado y mensaje esperado antes de integrar en TEST. QA no crea ni reconstruye este contrato durante una corrida normal.

## Contrato ORDS/OAuth

- Archivo: `docs/tareas/<ID_TAREA>/ords.md` o `No aplica` justificado
- Plantilla: `commands/resources/Desarrollo-APEX/ords.template.md`
- Modulo/privilegio/cliente por ambiente:
- Custodia logica (sin secretos):
- Resultado TEST:
- Resultado PRODUCCION:

## Auditoria Pre-TEST

- Archivo: `docs/tareas/<ID_TAREA>/auditoria_pre_test.md`
- Plantilla: `commands/resources/Desarrollo-APEX/auditoria-pre-test.template.md`
- Commit auditado:
- Paginas/flujos auditados:
- Patron corporativo comparado:
- Validador estatico:
- Reconciliacion fuente/TEST:
- Objetos Oracle auditados:
- Rutinas PL/SQL auditadas:
- Estrategia de identidad verificada contra DDL:
- Rendimiento SQL/`EXPLAIN PLAN` evaluado:
- Resultado: Pendiente

## Gates

| Gate | Evidencia | Estado |
|---|---|---|
| Worktree y rama propios creados desde commit base vigente |  | Pendiente |
| Alcance reservado sin conflicto con otra tarea |  | Pendiente |
| Desarrollo completó y comprobó todo el alcance contra inventario, contratos y criterios de esta tarea |  | Pendiente |
| Cada flujo acordado conserva su mecanismo primario; no se sustituyo por contingencia o supuesto | Evidencia extremo a extremo o `No aplica` justificado | Pendiente |
| Navegacion QA completa —ruta primaria y alternativa validada— para cada alcance visible/funcional | `qa/tareas/<ID_TAREA>/navigation/` | Pendiente |
| OpenSpec vigente cubre el inventario real cuando el gate aplica | `openspec/changes/<ID_CAMBIO>/` o `No aplica` justificado | Pendiente |
| Auditoria pre-TEST completa por cada pagina/dialogo/flujo | `docs/tareas/<ID_TAREA>/auditoria_pre_test.md` | Pendiente |
| Auditoria pre-TEST completa por cada objeto Oracle y rutina PL/SQL modificada | `docs/tareas/<ID_TAREA>/auditoria_pre_test.md` | Pendiente |
| Cada rutina modificada de `PACKAGE`/`PACKAGE BODY` tiene comentario propio y la logica compleja esta comentada | Inventario y evidencia por rutina en auditoria pre-TEST | Pendiente |
| Validador estatico PL/SQL finaliza `PLSQL_STATIC_AUDIT_PASS` sobre cada package spec/body modificado | Comando y salida en auditoria pre-TEST | Pendiente |
| Analisis de reutilizacion del modulo clasifica candidatos Commons o justifica su ausencia | Reporte analyze_plsql_reuse.py en auditoria pre-TEST | Pendiente |
| Propuesta de reutilizacion aprobada antes de crear o migrar PK_modulo_COMMONS o PK_CORP_nombre | Propuesta, aprobacion expresa y plan de migracion/regresion | No aplica |
| Validador de tablas/vistas finaliza `ORACLE_DATA_AUDIT_PASS` sobre cada objeto modificado | Comando, salida y propuesta de dominios en auditoria pre-TEST | Pendiente |
| Si aplica ORDS, contrato completo y `ORDS_STATIC_AUDIT_PASS` | `docs/tareas/<ID_TAREA>/ords.md` y auditoria pre-TEST | No aplica |
| OAuth se conserva por consumidor+ambiente; provision/reprovision y fingerprints no cambian | Evidencia sin secretos de `ords_oauth_tool.py` | No aplica |
| Recuperacion desde Oracle reconstruye solo una cache perdida y conserva los fingerprints | `RECOVERED_FROM_ORACLE`, package contractual y smoke sin secretos | No aplica |
| ORDS protegido rechaza anonimo y responde con token/version esperada | HTTP 401/403, token OK y HTTP 200 | No aplica |
| Estados, tipos y clasificaciones nuevos o cambiados tienen propuesta aprobada y comentario catalogado | Propuesta aprobada, COMMENT ON COLUMN y pruebas | No aplica |
| La generacion de identificadores coincide con el DDL vigente; no hay secuencia manual redundante frente a `IDENTITY` | DDL, insercion y evidencia en auditoria pre-TEST | Pendiente |
| Rendimiento SQL y `EXPLAIN PLAN` documentados cuando aplican; indice solo con justificacion y autorizacion | Auditoria pre-TEST o `No aplica` justificado | Pendiente |
| Validador estatico APEX finaliza PASS sobre todos los exports del alcance | Comando y salida en auditoria pre-TEST | Pendiente |
| Reserva TEST registrada y sin conflicto real; incluye objetos/páginas/archivos, flujo QA y datos temporales | `docs/tareas/_control/test.lock` | Pendiente |
| Diff integrado contiene solo la tarea y conserva cambios previos |  | Pendiente |
| Preflight `prepare_apex_integration.py` finaliza `AUTO_RECONCILE_READY`; rutas, APP_ID/PAGE_ID y hunks verificados | `docs/tareas/<ID_TAREA>/logs/integracion-git.json` | Pendiente |
| Worktree limpio creado desde `origin/main` y candidato propio reaplicado; sin cambios ajenos | Reporte de integración y `git status --porcelain` | Pendiente |
| Commit candidato creado antes de compilar TEST |  | Pendiente |
| TEST compilado/importado exactamente desde commit candidato |  | Pendiente |
| SQL de TEST coincide con SHA256 registrado y fue generado desde checkout limpio |  | Pendiente |
| Export oficial posterior de TEST comparado semanticamente y diferencias funcionales reconciliadas | `docs/tareas/<ID_TAREA>/auditoria_pre_test.md` | Pendiente |
| `tarea.md`, reserva propia en `test.lock`, fuente Git y TEST identifican el mismo candidato final |  | Pendiente |
| Regresiones previas y pruebas del cambio ejecutadas |  | Pendiente |
| QA valido el mismo commit candidato |  | Pendiente |
| Commit QA integrado y publicado directamente en `origin/main` |  | Pendiente |
| Lock de TEST liberado despues de push aprobado o rollback |  | Pendiente |
| Usuario autorizo ejecucion en PRODUCCION |  | Pendiente |
| PRODUCCION previa coincide con predecesor esperado |  | Pendiente |
| Ejecutable de PRODUCCION coincide con SHA256 autorizado y commit exacto en `origin/main` |  | Pendiente |
| Sesion productiva evidencia `SESSION_USER`, `CURRENT_SCHEMA=DATA` y base efectiva |  | Pendiente |
| PRODUCCION final coincide con commit publicado |  | Pendiente |

## Linaje De Objetos

| Objeto | Commit/blob fuente | SHA256 fuente | TEST despues | PROD antes | PROD despues (owner/tipo/estado) | Resultado |
|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |

## Resultado QA

- Tipo: Funcional | Técnico acotado
- Reporte: `qa/tareas/<ID_TAREA>/reports/informe_qa.md`
- Recomendacion: Pendiente
- Commit validado:

## Produccion

- Estado: No autorizada | Preparada | Pasada | Fallida | Parcial
- Autorizacion: Pendiente / Explicita / Condicionada a QA OK por solicitud inicial
- Tipo de pase: Normal | Pase Rapido APEX | Pase Tecnico Rapido Oracle | Pase ORDS/OAuth
- Pase:
- Commit ejecutado:
- Respaldo:
- Validacion post:

Para `Pase Tecnico Rapido Oracle` de un unico `PACKAGE` o `PACKAGE BODY` ya aprobado en TEST, la validacion post es exclusivamente tecnica: ejecucion integra del SQL, objeto `VALID`, `ALL_ERRORS=0`, fuente/SHA y sesiones propias `0`. No abrir APEX ni repetir QA visual o la accion funcional en PRODUCCION.
