<!-- ZAIMELLA: GESTION CASOS APEX :START -->
# Gestion De Casos APEX

- Este contexto atiende solicitudes puntuales de una aplicacion. `desarrollo.md` define la aplicacion, paginas, objetos y limites autorizados; no ampliar el alcance a otra aplicacion u objeto por semejanza.
- Abrir cada solicitud en `casos/#<NUMERO_CASO>.md` desde la plantilla `<ECOSYSTEM_ROOT>/commands/resources/Desarrollo-APEX/caso.template.md` antes de analizar, cambiar o responder una consulta. Registrar la solicitud original, tipo, alcance, hallazgos, decisiones, evidencias y estado.
- Clasificar el caso como `Mejora`, `Correccion`, `Analisis` o `Consulta`. Analisis y consultas son de solo lectura salvo autorizacion expresa de cambio. Una mejora o correccion solo modifica TEST y la fuente versionada dentro del alcance; PRODUCCION nunca queda autorizada al abrir el caso.
- Para un cambio, crear una tarea tecnica y sus evidencias con el orquestador Desarrollo-APEX. Usar QA funcional cuando haya impacto visible o funcional; para un objeto/rutina aislado sin impacto visible declarado, documentar y ejecutar el caso tecnico acotado en TEST.
- Mantener el caso abierto cuando el cambio este validado en TEST/QA como `Listo para cierre autorizado`. No cerrar, publicar a GitHub, integrar en `origin/main`, ejecutar PRODUCCION ni liberar un pase por inferencia, por QA aprobada o porque el desarrollo parezca terminado.
- Solo una instruccion expresa del usuario para cerrar autoriza el cierre del caso. Si tambien ordena GitHub o PRODUCCION, ejecutar exclusivamente esas acciones autorizadas con el mismo SHA validado; si no las menciona, conservarlas pendientes y registrar la decision.
- Toda nueva instruccion, correccion de alcance o definicion se agrega al mismo archivo del caso y prevalece para ese caso; actualizar este bloque solo mediante el recurso versionado cuando la regla sea reusable para todos los casos.
- `docs/bitacora.md` registra el avance operativo y `casos/#<NUMERO_CASO>.md` conserva el contexto funcional y las decisiones. No crear bitacoras paralelas.

## Errores Reportados

- Registrar cada error reportado por usuarios en `errores/#<NUMERO_ERROR>.md` desde `<ECOSYSTEM_ROOT>/commands/resources/Desarrollo-APEX/error-reportado.template.md`. Un error reportado no es automáticamente un caso de desarrollo.
- Iniciar en modo análisis y solo lectura: reconstruir la acción, revisar datos, formato, permisos, reglas vigentes, mensajes y evidencia disponible. No cambiar lógica, datos, TEST ni PRODUCCIÓN para confirmar una hipótesis sin autorización.
- Clasificar con evidencia como `Uso o dato invalido`, `Comportamiento definido`, `Defecto funcional`, `Excepcion no controlada` o `Evidencia insuficiente`. Informar el uso correcto o el dato erróneo cuando corresponda; no etiquetar como defecto una regla vigente solo porque el resultado no era el esperado.
- Si se confirma un defecto funcional o excepción no controlada, mantener el registro del error como diagnóstico y abrir o relacionar un caso separado antes de cualquier corrección. El caso sigue las reglas de TEST, QA, GitHub, PRODUCCIÓN y cierre autorizado.
- Cerrar el registro del error solo después de comunicar su clasificación o enlazar el caso correctivo; cerrar el registro no autoriza ni equivale a cerrar el caso ni a publicar cambios.
## Hallazgos Operativos Y De Mejora

- docs/tareas/_control/hallazgos.md conserva problemas de contratos, gates, prompts, herramientas, skills, orquestacion o QA que revelen una mejora reusable. No es un backlog automatico ni sustituye la trazabilidad funcional de casos, errores o QA.
- Registrar los hallazgos manuales mediante register_apex_finding.py, sin credenciales, datos sensibles ni capturas; incluir evidencia segura, severidad, alcance sugerido, tarea y sesion cuando existan.
- El reconciliador APEX puede registrar hallazgos automaticos sobre faltantes o contradicciones de continuidad. No eliminarlos ni duplicarlos; actualizar su estado o agregar una decision posterior.
- Antes de cambiar un skill u orquestador, revisar los hallazgos abiertos relacionados. Generalizar solo patrones repetibles y registrar la mejora en la bitacora del ecosistema; un hallazgo particular no autoriza cambios fuera del alcance.

<!-- ZAIMELLA: GESTION CASOS APEX :END -->
