# Auditoria Pre-TEST APEX

## Identidad

- ID tarea: <ID_TAREA>
- Commit candidato auditado: <SHA_CANDIDATO>
- Fecha: <YYYY-MM-DD>
- Responsable de desarrollo: <RESPONSABLE>
- Pagina o flujo corporativo de referencia: <APP_ID/PAGE_ID_O_NO_APLICA_JUSTIFICADO>
- Evidencia de auditoria estatica: <COMANDO_Y_RESULTADO>

## Cobertura Por Pagina O Flujo

Completar una fila por cada pagina, dialogo o flujo visible/funcional creado o modificado. `No aplica` exige justificacion; una celda vacia equivale a pendiente.

| APP_ID/PAGE_ID o flujo | Tipo | Titulo/breadcrumb | Barra/retorno/acciones | Regiones y estado vacio | Reporte o grilla | Formulario/LOV | Compania y seguridad | Condiciones y claves previas | Dialogos/retorno/refresh | Paquetes/mensajes | Responsive/visual | Resultado |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |  |  |  |  |  | Pendiente |

## Cobertura Por Objeto Oracle Y Rutina

Completar una fila por cada objeto Oracle creado o modificado. Para cada `PACKAGE` o `PACKAGE BODY`, completar una fila adicional por cada procedimiento o funcion modificada. `No aplica` exige justificacion; una celda vacia equivale a pendiente.

| Tipo y objeto | Archivo fuente | Rutina modificada | Comentario funcional propio | Logica compleja comentada o no aplica | Validador PL/SQL/datos | Comentarios y dominios de datos | Compilacion y `ALL_ERRORS` | Estrategia de identificador y DDL verificados | Resultado |
|---|---|---|---|---|---|---|---|---|---|
|  |  | No aplica |  | No aplica | `PLSQL_STATIC_AUDIT_PASS`, `ORACLE_DATA_AUDIT_PASS` o No aplica | `Valores permitidos:` / No aplica |  | No aplica | Pendiente |

## Reutilizacion PL/SQL

- Modulo analizado: <MODULO_O_NO_APLICA>
- Comando y reporte: `python scripts/analyze_plsql_reuse.py --root <SOURCE_REPO_ROOT> --module <MODULO> --output <ARTEFACTO_MD>`
- Candidatos detectados: <NINGUNO_O_LISTA>
- Clasificacion y decision: No duplicado | Mantener local | Extraer a Commons | Deuda aceptada
- Commons creado/modificado y consumidores regresionados: <NO_APLICA_O_EVIDENCIA>

## ORDS Y OAuth

- Contrato: `docs/tareas/<ID_TAREA>/ords.md` o <NO_APLICA_JUSTIFICADO>
- Auditor estatico: `python scripts/validate_ords_deploy.py <RUTAS_SQL>` -> <ORDS_STATIC_AUDIT_PASS_NO_APLICA>
- Package publicador `AUTHID DEFINER`, owner, compilacion y errores: <EVIDENCIA_O_NO_APLICA>
- Metadata modulo/template/handler/privilegio: <EVIDENCIA_O_NO_APLICA>
- OAuth estable: <CREATED_REUSED_FINGERPRINTS_SIN_SECRETOS_O_NO_APLICA>
- Recuperacion Oracle->DPAPI: <PROCEDIMIENTO_FINGERPRINTS_SMOKE_O_NO_APLICA>
- HTTP anonimo/token/autenticado/version: <EVIDENCIA_O_NO_APLICA>
- Mantenimiento sin recrear OAuth: <EVIDENCIA_O_NO_APLICA>

## Rendimiento SQL Y Planes De Ejecucion

Completar una fila por cada SQL al que aplique el gate de rendimiento. Para consultas simples excluidas, registrar `No aplica` y la razon. QA valida el escenario/tiempo indicado, no interpreta el plan ni decide indices.

| Archivo/objeto y ubicacion | Escenario/binds TEST y volumen | Comando y evidencia `EXPLAIN PLAN` | Operaciones, tablas e indices relevantes | Riesgo o hallazgo | Decision tecnica | Criterio entregado a QA | Resultado |
|---|---|---|---|---|---|---|---|
|  |  |  |  |  | Sin cambio / Reescritura SQL / Indice propuesto / Indice implementado / No aplica |  | Pendiente |

## Estructura Visual Y Componentes

Completar una fila por cada componente aplicable. Los IDs de template cambian entre aplicaciones; registrar el nombre resuelto desde metadata APEX o desde la pagina corporativa de referencia, no inferirlo solo por el numero.

| Pagina/flujo | Componente | Ubicacion y jerarquia | Template por nombre | Titulo/origen del titulo | Presentacion de acciones | Accesibilidad | Resultado |
|---|---|---|---|---|---|---|---|
|  | Region padre de formulario | Todos los componentes funcionales de Content Body son descendientes |  |  |  |  | Pendiente |
|  | Tabla/reporte/grilla | Dentro de la region padre cuando aplique | Zaimella Tabla | Nombre funcional de region; Header Text vacio | Acciones personalizadas solo con iconos | title/aria-label/alternativa | Pendiente |
|  | Barra de acciones | Breadcrumb Bar; retorno izquierda y demas acciones derecha | Zaimella Barra de Acciones / botones Icon | No aplica | Sin texto visible | Icono y etiqueta alternativa | Pendiente |
|  | Botones finales de dialogo | Region final Botones | Zaimella Grupo Botones / botones Text | No aplica | Texto visible | Etiqueta funcional | Pendiente |

## Decision De Componentes De Lista

Completar una fila por cada `Select List`, `Popup LOV` o `Modal LOV`. Un `Select List` SQL sin evidencia de catalogo pequeno, cerrado y de bajo crecimiento no cumple.

| Pagina/item | Origen | Cantidad aproximada o medida | Crecimiento esperado | Campos de busqueda/columnas necesarias | Componente elegido | LOV reutilizada | Justificacion | Resultado |
|---|---|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |  | Pendiente |

## Comparacion Con Patron Corporativo

| Elemento | Implementacion de referencia | Implementacion candidata | Diferencia justificada | Resultado |
|---|---|---|---|---|
| Template de pagina y breadcrumb |  |  |  | Pendiente |
| Barra de acciones y posiciones |  |  |  | Pendiente |
| Templates de botones, iconos y accesibilidad |  |  |  | Pendiente |
| Region padre y jerarquia de Content Body |  |  |  | Pendiente |
| Tablas: template, titulo, Header Text y acciones |  |  |  | Pendiente |
| Regiones, reportes y estados vacios |  |  |  | Pendiente |
| Items, decision LOV y distribucion |  |  |  | Pendiente |
| Dialogos, botones finales y retorno |  |  |  | Pendiente |

## Reconciliacion De TEST

- Fuente importada en TEST: <RUTA_Y_SHA>
- Export oficial posterior desde TEST: <RUTA_Y_SHA256>
- Comparacion semantica fuente vs TEST: <COMANDO_O_EVIDENCIA>
- Diferencias generadas por APEX sin efecto funcional: <LISTA_O_NINGUNA>
- Diferencias funcionales reconciliadas al repositorio: <LISTA_Y_NUEVO_SHA_O_NINGUNA>
- TEST reimportado desde el candidato final reconciliado: <SI_NO_EVIDENCIA>
- `tarea.md`, reserva propia en `test.lock`, fuente Git y TEST corresponden al mismo candidato: <SI_NO_EVIDENCIA>

## Cierre De Desarrollo

- Auditoria por objeto Oracle y rutina PL/SQL: <CUMPLE_NO_CUMPLE>
- Reutilizacion PL/SQL y Commons: <CUMPLE_NO_CUMPLE_NO_APLICA>
- Estrategia de identificadores verificada contra DDL: <CUMPLE_NO_CUMPLE_NO_APLICA>
- Rendimiento SQL y planes de ejecucion: <CUMPLE_NO_CUMPLE_NO_APLICA>
- ORDS/OAuth: <CUMPLE_NO_CUMPLE_NO_APLICA>

- Alcance completo contra inventario y criterios: <CUMPLE_NO_CUMPLE>
- Auditoria estatica: <PASS_FAIL>
- Auditoria manual por pagina/flujo: <CUMPLE_NO_CUMPLE>
- Navegacion primaria y alternativa validadas: <CUMPLE_NO_CUMPLE>
- Candidato listo para QA independiente: <SI_NO>
- Hallazgos pendientes: <NINGUNO_O_LISTA>

Desarrollo solo puede declarar `Lista para QA` cuando todos los destinos estén auditados, TEST corresponda al candidato final y no existan hallazgos pendientes de desarrollo.
