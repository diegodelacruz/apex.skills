---
description: Orquestador de preparación APEX: actualiza AGENTS.md, desarrollo.md y la arquitectura por tarea.
argument-hint: "[PROJECT_PATH]"
---

Este archivo es el orquestador de Zaimella para desarrollo Oracle APEX. Para iniciarlo o actualizar sus estándares desde una sesión abierta, copiar el prompt correspondiente de `prompts/`.

No es un skill de Codex. No buscar, invocar ni reportar ausente `$orquestador-desarrollo-apex`; leer y ejecutar estas instrucciones como procedimiento de contexto.

Cuando `Gestion-Proyectos` delegue un paquete `apex-oracle-ords`, registrar sus IDs y rutas en `tarea.md`. Este orquestador conserva por completo su coordinacion de desarrollo, TEST, QA, Git y PRODUCCION; el nivel proyecto no dirige skills internos. Al finalizar o requerir una decision material, devolver `handoff-dominio.template.md` con versiones, evidencia, cobertura de subtareas, impacto documental y resultado. Un hallazgo corregible se mantiene en el ciclo interno y no se devuelve como bloqueo del proyecto.

Este comando asume que ya fue instalado por el bootstrap inicial del repositorio. No reinstala comandos; actualiza skills, MCP/herramientas cuando aplique, refresca el `AGENTS.md` del proyecto y prepara la arquitectura de trabajo.

Objetivo:

Continuidad entre sesiones: al abrir una sesion Codex nueva para un proyecto APEX preparado, despues de un reinicio o perdida de contexto, ejecutar antes de analizar, crear, continuar o cerrar tareas:

    python <RUNTIME_ROOT>/scripts/reconcile_apex_project_state.py --project-root <PROJECT_ROOT> --write

Tambien ejecutar el reconciliador en modo lectura cuando el usuario pregunte por donde nos quedamos, que esta pendiente, estado de tareas, continuemos o equivalente:

    python <RUNTIME_ROOT>/scripts/reconcile_apex_project_state.py --project-root <PROJECT_ROOT>

La salida persistente identifica tareas confirmadas, abiertas, en espera y POR_RECONCILIAR; no sustituirla por memoria de chat. Registrar un hallazgo reusable con el script register_apex_finding.py cuando una regla, contrato, prompt, herramienta o gate revele una mejora transversal. Los reportes de usuarios siguen en errores/ y no se duplican como hallazgos sin una leccion tecnica generalizable.

Regla de medicion: toda actividad creada con este orquestador registra en su `tarea.md` hora local de inicio y fin, duracion total y duracion por fase. Solo anota esperas reales, timeouts, locks o reintentos que expliquen la demora; la medicion no es un gate adicional.

Regla de cobertura: `ID_TAREA` representa el sprint completo. Al abrirlo, descomponer cada resultado funcional independiente en `ID_SUBTAREA` y registrarlo en `tarea.md`; si hay más de una subtarea, tres o más destinos, o mezcla APEX/Oracle/ORDS, crear OpenSpec y reflejar los mismos IDs en `openspec/changes/<ID_CAMBIO>/tasks.md`. Antes de QA ejecutar `validate_apex_task_coverage.py --phase pre-qa`; antes de aprobar cierre repetir con `--phase close`. No se permite completar, publicar ni cerrar por el éxito del objetivo principal mientras cualquier subtarea siga pendiente, sin prueba o sin QA.

Regla de pase tecnico: si PRODUCCION contiene exclusivamente un `PACKAGE` o `PACKAGE BODY` ya aprobado en TEST para el mismo SHA, ejecutar `Pase Tecnico Rapido Oracle`: respaldo, SQL integro, objeto `VALID`, errores `0`, fuente/SHA y sesiones propias `0`; no repetir QA visual, Browser, smoke web ni la accion funcional en PRODUCCION.

Regla ORDS/OAuth: para cualquier modulo REST, crear `docs/tareas/<ID_TAREA>/ords.md` desde `ords.template.md` y aplicar `desarrollador-apex/references/ords.md`. Publicar mediante package `AUTHID DEFINER` del owner, sin habilitar para REST a la cuenta tecnica; `ORDS.DELETE_MODULE` no pertenece al mantenimiento ordinario. Un cliente se conserva por consumidor+ambiente y no se recrea por release. TEST y PRODUCCION exigen auditor ORDS, metadata, rechazo anonimo, token, HTTP autenticado y continuidad de fingerprints sin registrar secretos.

1. Actualizar el repositorio local de skills desde GitHub.
2. Validar herramientas CLI requeridas, incluyendo Node/npm y OpenSpec.
3. Instalar o actualizar skills y MCP en la IA seleccionada; no reinstalar comandos desde este flujo.
4. Migrar `AGENTS.md` del proyecto a un único bloque administrado `<!-- ZAIMELLA: Desarrollo Apex :START -->`; ese bloque define cómo y cuándo se usan `desarrollador-apex` y `qa-apex`. Si el contexto tambien usa Movilmella, conservar su bloque administrado independiente; ambos coexisten y comparten el mismo `desarrollo.md`.
5. Eliminar bloques y secciones APEX heredados o incompatibles antes de insertar el bloque canónico, sin alterar reglas locales de negocio, seguridad o alcance que no pertenezcan al flujo APEX.
6. Preparar o verificar la arquitectura concreta del proyecto/contexto segun `commands/resources/Desarrollo-APEX/agents-md-orquestador.md`: estructura operativa por tarea, `desarrollo.md` desde `desarrollo.template.md`, `tarea.md` desde `tarea.template.md`, recuperacion de sesion desde `recuperacion-sesion.template.md`, auditoria desde `auditoria-pre-test.template.md` y un contrato operativo por cada alcance visible/funcional desde `navegacion.template.md`. `desarrollo.md` conserva la URL de login QA APEX TEST definida por defecto en la plantilla y, cuando el proyecto requiera QA visual, completa desde parametros externos el usuario QA y si el login requiere contrasena; esos valores son la unica fuente para los contratos de navegacion y el skill QA. Los flujos definidos son vinculantes: no convertir una contingencia en mecanismo principal ni alterar actores, secuencia, endpoints, datos, respuestas o criterios de termino sin una decision explicita del usuario. Desarrollo debe probar cada ruta y ejecutar `python <RUNTIME_ROOT>/scripts/validate_apex_navigation_contract.py --navigation <ARCHIVO>`; el orquestador bloquea la invocacion de QA si no devuelve `NAVIGATION_CONTRACT_OK` y devuelve la tarea a desarrollo sin pedir a QA que diagnostique o complete la ruta. Migrar ademas el gate terminal de todas las tareas activas con `scripts/update_apex_task_terminal_gate.py`; las tareas cerradas permanecen intactas. Completar datos inferibles desde requerimiento, fuente y metadata; ante una definicion material faltante, contradiccion o impedimento del flujo, exponerla y pedir una unica decision, sin asumir una solucion. No permitir TEST sin auditoria completa por destino APEX y por objeto/rutina Oracle modificada, ni QA sin los insumos del tipo aplicable, auditoria de estandares Oracle y reconciliacion fuente/TEST. Preparar tambien repo de integracion y worktrees aislados cuando `desarrollo.md` este completo.
   Si el inventario contiene ORDS/OAuth, crear ademas `docs/tareas/<ID_TAREA>/ords.md` desde `commands/resources/Desarrollo-APEX/ords.template.md`; no copiar la politica tecnica extensa al proyecto.
7. Aplicar la politica Git del orquestador: la identidad de toda tarea es `PROJECT_SLUG/ID_TAREA`; usar ramas `codex/<PROJECT_SLUG>/<ID_TAREA>` y worktrees bajo `<PROJECT_SLUG>`, nunca un codigo de tarea aislado. Dos proyectos pueden reutilizar el mismo `ID_TAREA` sin compartir historial, candidato ni reporte. La publicacion oficial es directa a `origin/main`, sin PR salvo instruccion explicita o proteccion del remoto.

Regla de reconciliacion Git: un avance de `origin/main` no es `Bloqueada` ni requiere autorizacion por sí solo. Antes de alegar conflicto, comparar el inventario de la tarea con el delta remoto y demostrar `APP_ID`, `PAGE_ID`, ruta completa y hunk solapado; el número de página repetido en módulos o aplicaciones distintos no prueba colisión. Sin solapamiento, crear/reconstruir automáticamente un worktree limpio desde el `origin/main` actual, reaplicar solo los cambios de la tarea, crear candidato nuevo y repetir TEST/QA si cambia el contenido. Con solapamiento técnico resoluble, reconciliar conservando ambos cambios y repetir TEST/QA. Solo pedir una decisión del usuario cuando los mismos hunks expresen comportamientos incompatibles y la resolución no sea inferible; mientras tanto la tarea queda `En correccion` o la fase puntual `En espera`, nunca `Bloqueada`.

Gate de navegacion y acceso QA: antes de redactar el contrato, Desarrollo ejecuta `extract_apex_page_navigation.py` sobre el export SQL candidato y adjunta su mapa funcional; no reanaliza manualmente componentes ya extraibles. El mapa clasifica cada destino como: (1) `principal`, pagina normal que QA puede abrir desde menu o por URL autenticada con `DIRECT_URL_ALLOWED`; (2) `secundaria_parametrizada`, que exige un ID/filtro/contexto y debe abrirse desde la pagina principal que lo provee; o (3) `dialogo_modal`, que debe abrirse desde su pagina padre y contexto. Los tipos 2 y 3 no requieren menu ni URL directa y su ausencia no es un defecto. Ante una ruta, grupo o accion visible ausente para el tipo aplicable, ejecuta despues `diagnose_apex_navigation_access.py` (TEST y PRODUCCION de solo lectura) con modulo, pagina/ruta, usuario QA y compania. La salida es determinista: `TEST_READY` habilita la ruta visual; `RECONCILE_TEST_FROM_PROD` obliga generar, versionar y aplicar en TEST el `MERGE` idempotente del mismo rol existente con `apex_menu_access_tool.py --environment test`; `USER_DECISION_REQUIRED` solo puede pedir una decision si la jerarquia, rol o seguridad necesaria no es inferible. Un hallazgo QA de navegacion devuelve automaticamente la misma tarea a Desarrollo para esta correccion acotada, nuevo candidato y nueva evidencia; QA se reinvoca despues, sin pedir autorizacion para ajustar navegacion o acceso QA existente en TEST. No explorar menus con QA/Browser para descubrir la ruta antes de esos diagnosticos. QA no recibe un contrato rechazado antes de agotar esta secuencia.
8. En Codex, verificar que el `Stop hook` global de continuidad APEX fue instalado por `install_global_codex_orchestrators.py`. Informar al usuario que debe revisarlo y confiarlo una vez mediante `/hooks`; no tratar esa revision como impedimento para continuar el trabajo seguro de la sesion actual.

## Gestion De Casos De Una Aplicacion

Cuando un proyecto APEX preparado atienda tickets, mejoras pequeñas, correcciones, análisis o consultas de una aplicación concreta, aplicar `commands/resources/Desarrollo-APEX/casos-agents.template.md` con `scripts/update_apex_case_management_agents_md.py`. Usar `caso.template.md` para abrir `casos/#<NUMERO_CASO>.md`. La validación en TEST/QA puede dejar el caso listo, pero GitHub, PRODUCCIÓN y el cierre requieren la instrucción expresa del usuario.

Los errores reportados por usuarios se registran separadamente en `errores/#<NUMERO_ERROR>.md` con `error-reportado.template.md`. Primero se diagnostican en lectura y se clasifican; solo un defecto funcional o excepción no controlada confirmado deriva a un caso correctivo.

Comando recomendado desde un clon del repo `zaimella-skill`:

```powershell
python .\scripts\zaimella_agent_setup.py --agents both --no-commands --apply-command Desarrollo-APEX --project-path .
```

Si solo se usa Codex:

```powershell
python .\scripts\zaimella_agent_setup.py --agents codex --no-commands --apply-command Desarrollo-APEX --project-path .
```

Si solo se usa Antigravity:

```powershell
python .\scripts\zaimella_agent_setup.py --agents antigravity --no-commands --apply-command Desarrollo-APEX --project-path .
```

Despues de ejecutar:

- leer el `AGENTS.md` actualizado del proyecto;
- ejecutar la `Seccion 2 - Preparacion Del Contexto` de `commands/resources/Desarrollo-APEX/agents-md-orquestador.md`;
- ejecutar la preparacion indicada por los prompts de ambiente;
- usar `desarrollador-apex` solo para desarrollo APEX/Oracle y preparacion tecnica;
- si QA queda como `nobody` o sin compania, ejecutar primero la recuperacion del login corporativo TEST publicada por `qa-apex` y revisar el contrato de navegacion; no pedir al usuario otra vez el usuario QA parametrizado, compania ni el mecanismo ya documentado. Un problema QA TEST no es una credencial para PRODUCCION: impedir el pase mientras QA no apruebe, pero continuar diagnostico/correccion/reintento en TEST.
- completar cada tarea activa como ciclo autonomo: `desarrollador-apex` implementa, audita cada destino y cada objeto Oracle del alcance, valida los estandares aplicables y reconcilia TEST con el candidato final; el orquestador invoca `qa-apex` para validacion independiente del mismo SHA. La auditoria Oracle debe demostrar por cada rutina modificada su comentario funcional, los comentarios de logica compleja cuando apliquen y que la estrategia de identidad usada coincide con el DDL vigente de la tabla. Los skills solo emiten resultados tecnicos: nunca marcan una tarea `Bloqueada`. Un `No aprobado`, defecto, error reproducible, dato insuficiente reconstruible o validacion fallida obliga inmediatamente a registrar `En correccion`, devolver el hallazgo a Desarrollo, crear nuevo candidato y repetir TEST/QA; esta regla prevalece sobre cualquier intento de cerrar el turno como `BLOQUEADA`. Ante timeout o `Impedimento tecnico`, diagnostica y ejecuta recuperacion/reintento en el mismo turno; ante `Impedimento externo`, primero completa toda inferencia y descubrimiento seguro desde la tarea, contratos, requerimiento, evidencias, fuente y metadata accesibles. Solo puede quedar `Bloqueada` si el ambiente/base obligatorio sigue inaccesible despues de recuperacion razonable o si el agente necesita una decision material del usuario no definida ni inferible sin cambiar alcance, comportamiento, seguridad o datos; debe mostrar las alternativas y formular una unica pregunta concreta. `No cerrar la tarea` no significa que se pueda terminar el turno: no emitir respuesta final mientras exista una accion segura y ejecutable propia o de la siguiente fase normal. `Aun estoy`, `sigo corrigiendo`, `falta`, `hasta diagnosticar`, `queda pendiente` o `continuare despues` son solo avances intermedios y deben ir seguidos inmediatamente por una accion del mismo turno; nunca pueden ser el ultimo mensaje. La respuesta final debe declarar `COMPLETA` o `BLOQUEADA`.
- para trabajo prolongado en Codex, recomendar `/goal` con el alcance y definicion de terminado de la tarea. El `Stop hook` global es una defensa adicional: si el ultimo mensaje reconoce trabajo pendiente, solicita una continuacion automatica una sola vez; `stop_hook_active` evita recursiones infinitas. El hook no cambia estados, no reemplaza QA y no autoriza a declarar bloqueos.
