---
description: Orquestador del ciclo completo de proyectos de Sistemas y de la delegacion a orquestadores de dominio.
argument-hint: "[PROJECT_PATH]"
---

# Gestion-Proyectos

Este archivo es el orquestador de proyectos tecnologicos de Sistemas Zaimella. No es un skill. Preparar y gobernar el proyecto sin sustituir la metodologia ni entrar en la coordinacion interna de APEX, Movilmella, AWS u otro dominio.

## Objetivo

Conducir una iniciativa desde sus insumos y definiciones hasta los entregables, ejecucion, integracion, documentacion, aceptacion, cierre y lecciones aprendidas. Mantener trazabilidad entre proyecto, entregable, sprint, paquete de trabajo y la tarea interna que cree el orquestador de dominio.

## Recuperacion

Al iniciar una sesion nueva, retomar el proyecto o responder consultas de estado, ejecutar:

```powershell
python <RUNTIME_ROOT>/scripts/reconcile_project_state.py --project-root <PROJECT_ROOT>
```

Usar `--write` cuando se deba persistir `proyecto/06_seguimiento/_control/estado-reconciliado.md`. La conversacion no sustituye contratos, handoffs, evidencias ni aceptaciones.

## Preparacion

1. Leer `commands/resources/Gestion-Proyectos/` y las reglas locales.
2. Ejecutar `scripts/update_gestion_proyectos_agents_md.py --project-root <PROJECT_ROOT> --check`, revisar `--dry-run` y aplicar `--apply` si no existen contradicciones no migrables.
3. Crear de forma idempotente la arquitectura de `proyecto/` desde las plantillas versionadas. En proyectos heredados, inventariar, clasificar y organizar los archivos con destino inequivoco; moverlos sin sobrescritura y registrar cada movimiento u omision. No mover `AGENTS.md`, contratos de dominio, `README.md`, archivos ocultos, manifiestos tecnicos ni elementos ambiguos.
   La estructura canonica y la relacion entre contexto transversal y contextos de dominio viven en `commands/resources/Gestion-Proyectos/arquitectura-contextos.md`.
4. Usar `metodologia-proyectos` para el ciclo de vida y `levantamiento-procesos` para reconstruir AS-IS cuando aplique. No pedirles desarrollo tecnico.
5. Crear entregables, sprints y paquetes solo desde definiciones aprobadas o con pendientes explicitamente identificados.

## Regla de propiedad por dominio

- Seleccionar un orquestador de dominio registrado por `capability_id` ejecutando `python <RUNTIME_ROOT>/scripts/resolve_project_orchestrator.py --capability-id <CAPABILITY_ID>`; no seleccionar ni invocar sus skills internos.
- Preferir el orquestador compuesto mas especifico que cubra el resultado completo. Un paquete Movilmella con backend `MVZM` pertenece a `Movilmella`; un ETL AWS con Oracle como fuente pertenece a `Desarrollo-AWS`.
- Dividir en varios paquetes solo cuando existan resultados independientes, propietarios distintos o una exclusion declarada por el orquestador propietario.
- Si no existe orquestador, registrar `DOMINIO_SIN_ORQUESTADOR` y asignar responsable humano o dejar el paquete sin delegar. No crear un orquestador preventivamente ni improvisar con un skill tecnico ajeno. Un nuevo orquestador se diseña cuando exista un proyecto o necesidad concreta que permita probarlo y mejorarlo.
- El orquestador de proyectos nunca decide worktrees, locks, QA interno, orden de despliegue ni correcciones propias del dominio.
- Cuando un paquete requiera un dominio, prepara o actualiza su contexto bajo `<PROJECT_ROOT>/dominios/<DOMINIO>/` e invoca alli al orquestador propietario. Esa carpeta se convierte en el `<PROJECT_ROOT>` del dominio y contiene su propio `AGENTS.md`, contrato operativo y bitacora tecnica. No coloca repositorios ni worktrees dentro del proyecto.

## Jerarquia y cobertura

La jerarquia es `Proyecto -> Entregable -> Sprint -> Paquete de trabajo -> Tarea/subtareas internas del dominio`. Un sprint no queda completo por finalizar su paquete principal: todos los entregables y paquetes asociados deben tener resultado, evidencia y estado contractual.

Antes de delegar, integrar, documentar o cerrar, ejecutar:

```powershell
python <RUNTIME_ROOT>/scripts/validate_project_delivery_coverage.py --project-root <PROJECT_ROOT> --phase <dispatch|integration|documentation|close>
```

## Handoff de dominio

Cada paquete usa `paquete-trabajo.template.md`. El orquestador de dominio devuelve `handoff-dominio.template.md` con la misma identidad, resultado, versiones, ambientes, QA, evidencia, impacto documental, produccion y pendientes. Validar el par con `validate_project_handoff.py`.

Un `No aprobado`, defecto o validacion fallida que el dominio pueda resolver conserva el paquete `En ejecucion dominio` y debe volver al ciclo interno de correccion del orquestador propietario. Solo usar `En espera de decision` si falta una decision material de alcance, comportamiento, seguridad o datos que no puede inferirse. Una espera tecnica o archivo abierto afecta solo la fase correspondiente.

## Integracion, documentacion y cierre

- El QA de componente pertenece al orquestador de dominio. La integracion del proyecto comprueba escenarios extremo a extremo entre paquetes aprobados sin implementar correcciones.
- Definir desde planificacion los documentos entregables. Usar `documentacion-proyecto-sistemas` para documentos funcionales, tecnicos o mixtos; el skill consume evidencia y no hace QA del sistema.
- QA de dominio produce capturas y evidencia real. El skill documental redacta y renderiza. Una brecha documental vuelve mediante este orquestador al propietario de la evidencia; no se solicita a QA que corrija desarrollo.
- Cerrar solo con entregables aceptados, integracion aplicable, documentos completos sobre la linea base correcta, pendientes transferidos y lecciones sustentadas.

## Comando recomendado

```powershell
python .\scripts\zaimella_agent_setup.py --agents codex --no-commands --apply-command Gestion-Proyectos --project-path <PROJECT_ROOT>
```
