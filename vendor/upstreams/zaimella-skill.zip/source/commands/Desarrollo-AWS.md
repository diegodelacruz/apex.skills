---
description: Orquestador de preparación AWS ETL: separa la validación Oracle/APEX de solo lectura y el desarrollo operativo en AWS.
argument-hint: "[PROJECT_PATH]"
---

# Desarrollo-AWS

No es un skill. Para iniciarlo o actualizar sus estándares desde una sesión abierta, copiar el prompt correspondiente de `prompts/`.

## Objetivo

Preparar un proyecto ETL AWS con un único bloque administrado en `AGENTS.md`, estructura de trabajo, bitácora y contrato `desarrollo-aws.md`.

Cuando `Gestion-Proyectos` delegue un paquete `aws-etl-with-oracle-source`, registrar sus identidades en `docs/tareas/<ID_TAREA>/tarea.md`. Desarrollo-AWS conserva la coordinacion interna de consulta Oracle y ejecucion AWS; el nivel proyecto no llama directamente a sus skills. Devolver el handoff contractual con versiones, validaciones, evidencia, impacto documental y riesgo. Una diferencia o fallo corregible continua dentro de este orquestador.

## Separación obligatoria de responsabilidades

- `desarrollador-apex` se usa solo si la fuente oficial original está en Oracle/APEX de PRODUCCIÓN. Su alcance es lectura: conectividad, `SELECT`, validación de queries, planes cuando apliquen y comparación de resultados contra el job o Athena. No modifica APEX, Oracle, objetos, datos, jobs ni despliegues AWS.
- `aws-etl-experto` realiza todo el desarrollo y la operación ETL en AWS: scripts Glue, S3, configuración de jobs, catálogo, Athena, particiones, ejecuciones, correcciones, backfills, promociones y evidencia de cierre.
- La validación contra fuente original no convierte Oracle/APEX en fuente técnica editable ni habilita cambios en PRODUCCIÓN. La evidencia se registra como comparación, con filtros, periodo, agregados, resultados y diferencias.

## Preparación

1. Leer `commands/resources/Desarrollo-AWS/` y las instrucciones locales del proyecto.
2. Ejecutar `scripts/update_aws_agents_md.py --project-root <PROJECT_ROOT> --check`; revisar `--dry-run` y usar `--apply` solo si no hay contradicciones no migrables.
3. Crear o completar `desarrollo-aws.md` desde su plantilla, preparar `docs/`, `JOB/`, `glue_jobs/` y `TMP/` de manera idempotente.
4. Antes de evidencia AWS real, validar el perfil y la región definidos por el proyecto. Antes de evidencia Oracle/APEX de PRODUCCIÓN, `desarrollador-apex` valida la conectividad productiva con sus herramientas oficiales.
5. Conservar reglas locales de negocio, seguridad, permisos, fuentes y alcance. Pedir solo datos que impidan operar de manera segura.

## Método por tarea

1. Crear `docs/tareas/<ID_TAREA>/tarea.md` desde la plantilla y registrar alcance y estado en `docs/bitacora.md`.
2. Identificar la fuente oficial, el job o tabla objetivo y la autorización de cambio.
3. Si aplica comparación con fuente Oracle/APEX de PRODUCCIÓN, invocar `desarrollador-apex` exclusivamente en modo lectura y guardar la evidencia en `docs/operacion/validaciones-fuente/`.
4. Invocar `aws-etl-experto` para implementar, ejecutar y validar el cambio AWS bajo su estándar.
5. Comparar los resultados AWS con la evidencia de fuente usando el mismo periodo, filtros, grano y métricas. Una diferencia no explicada impide declarar la validación funcional conforme.
6. Aplicar el gate de cierre AWS y actualizar la bitácora. No cerrar solo por un run `SUCCEEDED`.

Comando recomendado:

```powershell
python .\scripts\zaimella_agent_setup.py --agents codex --no-commands --apply-command Desarrollo-AWS --project-path .
```
