#!/usr/bin/env python3
"""Continua una tarea APEX cuando el ultimo mensaje reconoce trabajo pendiente."""
from __future__ import annotations

import json
import re
import sys
import unicodedata
from pathlib import Path

PROJECT_MARKER = "<!-- ZAIMELLA: Desarrollo Apex :START -->"
TASK_GATE_MARKER = "<!-- ZAIMELLA:APEX:TASK-TERMINAL-GATE:START -->"
STATE = re.compile(r"(?mi)^\s*-?\s*Estado\s*:\s*(.+?)\s*$")
CLOSED = re.compile(r"\bcerrad[ao]s?\b", re.I)
BLOCKED = re.compile(r"\bbloquead[ao]s?\b", re.I)
PROGRESS_PATTERNS = (
    r"\bno esta complet",
    r"\bsigue activa\b",
    r"\baun (?:estoy|continua|sigue)",
    r"\btodavia\b",
    r"\bsigo (?:corrigiendo|trabajando|validando|diagnosticando)",
    r"\bno cierro\b",
    r"\bfalta(?:n)?\b",
    r"\bqueda(?:n)? pendiente",
    r"\bcontinuare\b",
    r"\bantes de (?:cerrar|finalizar|completar)",
    r"\bhasta (?:corregir|completar|dejar|pasar|repetir|obtener)",
    r"\brepetir qa\b",
    r"\bpasar qa\b",
    r"\bno es correcto cerr",
)
APEX_CONTEXT = re.compile(
    r"\b(?:apex|qa|test|tarea|candidato|sha|pagina|reporte|boton|accion|importad[oa]|auditoria)\b"
)
TERMINAL = re.compile(r"(?mi)^\s*(?:resultado\s+terminal\s*:\s*)?(COMPLETA|BLOQUEADA)\s*[.!]?\s*$")
INVALID_BLOCK_REASON = re.compile(
    r"\b(?:qa\s*(?:no\s*)?aprobad[oa]|(?:no\s*)?aprobad[oa].{0,40}\bqa|"
    r"hallazgo\s+qa|validaci[oó]n\s+fallid|defecto\s+(?:pendiente|reproducible)|"
    r"error\s+corregible|correcci[oó]n\s+pendiente)\b",
    re.IGNORECASE,
)


def normalized(value: str) -> str:
    plain = "".join(
        char
        for char in unicodedata.normalize("NFD", value.casefold())
        if unicodedata.category(char) != "Mn"
    )
    return re.sub(r"\s+", " ", plain).strip()


def project_root(cwd: Path) -> Path | None:
    for candidate in (cwd, *cwd.parents):
        agents = candidate / "AGENTS.md"
        if agents.is_file() and PROJECT_MARKER in agents.read_text(encoding="utf-8", errors="ignore"):
            return candidate
    return None


def task_contracts(root: Path) -> list[tuple[str, str, bool]]:
    tasks_root = root / "docs" / "tareas"
    if not tasks_root.is_dir():
        return []
    contracts: list[tuple[str, str, bool]] = []
    for path in sorted(tasks_root.rglob("tarea.md")):
        if "_control" in path.relative_to(tasks_root).parts:
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        if TASK_GATE_MARKER not in text:
            continue
        match = STATE.search(text)
        state = match.group(1).strip() if match else "Sin estado explicito"
        terminal = bool(CLOSED.search(state) or BLOCKED.search(state))
        contracts.append((path.parent.name, state, terminal))
    return contracts


def mentions_task(message: str, task_id: str) -> bool:
    value = normalized(task_id)
    return bool(re.search(rf"(?<![a-z0-9]){re.escape(value)}(?![a-z0-9])", message))


def continuation_reason(payload: dict[str, object]) -> str | None:
    if payload.get("hook_event_name") != "Stop" or payload.get("stop_hook_active") is True:
        return None
    raw_cwd = payload.get("cwd")
    last = payload.get("last_assistant_message")
    if not isinstance(raw_cwd, str) or not isinstance(last, str) or not last.strip():
        return None
    root = project_root(Path(raw_cwd).resolve())
    if root is None:
        return None
    contracts = task_contracts(root)
    message = normalized(last)
    # Un agente puede haber escrito indebidamente Bloqueada antes de que el hook
    # evalúe la continuidad. QA no aprobada y defectos corregibles deben regresar
    # a En correccion, por lo que se vigilan también esos contratos terminales.
    invalidly_blocked = [
        (task_id, state)
        for task_id, state, terminal in contracts
        if terminal and BLOCKED.search(state) and INVALID_BLOCK_REASON.search(message)
    ]
    if invalidly_blocked:
        inventory = ", ".join(f"{task_id} ({state})" for task_id, state in invalidly_blocked)
        return (
            "CONTINUIDAD APEX: QA no aprobada, un defecto o una validacion fallida no permiten "
            f"declarar BLOQUEADA: {inventory}. Registra En correccion, devuelve el hallazgo a "
            "Desarrollo, genera un nuevo candidato y repite TEST/QA."
        )
    tasks = [(task_id, state) for task_id, state, terminal in contracts if not terminal]
    if not tasks:
        return None

    referenced = [item for item in tasks if mentions_task(message, item[0])]
    mentioned_any = any(mentions_task(message, task_id) for task_id, _, _ in contracts)
    if mentioned_any and not referenced:
        return None
    has_context = bool(referenced) or bool(APEX_CONTEXT.search(message))
    if not has_context:
        return None
    progress = any(re.search(pattern, message) for pattern in PROGRESS_PATTERNS)
    verdict = TERMINAL.search(last)
    if not referenced and not progress and verdict is None:
        return None

    relevant = referenced or tasks
    inventory = ", ".join(f"{task_id} ({state})" for task_id, state in relevant)
    if verdict:
        return (
            "CONTINUIDAD APEX: el mensaje intenta declarar un resultado terminal, "
            f"pero el contrato conserva tareas activas: {inventory}. Actualiza primero "
            "los contratos y gates con evidencia real, o sigue ejecutando la siguiente accion segura."
        )
    return (
        "CONTINUIDAD APEX: el ultimo mensaje reconoce trabajo pendiente en "
        f"{inventory}; es un avance, no una salida final. No respondas con otro resumen. "
        "Ejecuta inmediatamente la siguiente herramienta o accion segura y continua el ciclo "
        "Desarrollo -> TEST -> QA -> correccion hasta cerrar o demostrar una causa taxativa de BLOQUEADA."
    )


def main() -> int:
    try:
        payload = json.load(sys.stdin)
        if not isinstance(payload, dict):
            raise ValueError("La entrada del hook debe ser un objeto JSON.")
        reason = continuation_reason(payload)
        output = {"continue": False, "stopReason": reason} if reason else {}
        print(json.dumps(output, ensure_ascii=True))
        return 0
    except Exception as exc:
        print(json.dumps({"systemMessage": f"APEX Stop hook omitido: {exc}"}, ensure_ascii=True))
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
