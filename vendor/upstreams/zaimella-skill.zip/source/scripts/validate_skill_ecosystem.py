#!/usr/bin/env python3
"""Audita e instala skills Zaimella con staging, unicidad y paridad exacta."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

ALLOWED_ROOT = {"SKILL.md", "agents", "references", "scripts", "assets"}
FORBIDDEN_NAMES = {"__pycache__", ".ds_store"}
FORBIDDEN_SUFFIXES = {".pyc", ".tmp", ".log", ".bak"}

def files(root: Path) -> dict[str, str]:
    return {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob("*") if p.is_file()}

def frontmatter(path: Path) -> dict[str, str]:
    text = path.read_text(encoding="utf-8", errors="ignore")
    match = re.match(r"\A---\r?\n(.*?)\r?\n---", text, re.S)
    if not match: raise ValueError("frontmatter YAML ausente")
    values = {}
    for line in match.group(1).splitlines():
        if ":" not in line: raise ValueError("frontmatter no plano")
        key, value = line.split(":", 1); values[key.strip()] = value.strip().strip('"')
    if set(values) != {"name", "description"}: raise ValueError("frontmatter debe contener solo name y description")
    if not values["name"] or not values["description"]: raise ValueError("name/description vacíos")
    return values

def emit(level: str, message: str, errors: list[str], warnings: list[str]) -> None:
    print(f"{level} {message}")
    (errors if level == "ERROR" else warnings).append(message)

def audit_skill(skill: Path, validator: Path | None, errors: list[str], warnings: list[str]) -> str | None:
    if not (skill / "SKILL.md").is_file(): emit("ERROR", f"{skill}: falta SKILL.md", errors, warnings); return None
    try: data = frontmatter(skill / "SKILL.md")
    except ValueError as exc: emit("ERROR", f"{skill}: {exc}", errors, warnings); return None
    name = data["name"]
    if skill.name != name: emit("ERROR", f"{skill}: folder != name ({name})", errors, warnings)
    for item in skill.iterdir():
        if item.name not in ALLOWED_ROOT: emit("ERROR", f"{skill}: contenido no publicable {item.name}", errors, warnings)
    for item in skill.rglob("*"):
        if item.name.lower() in FORBIDDEN_NAMES or item.suffix.lower() in FORBIDDEN_SUFFIXES:
            emit("ERROR", f"{skill}: temporal/prohibido {item.relative_to(skill)}", errors, warnings)
    for ref in re.findall(r"references/([A-Za-z0-9_./-]+\.(?:md|yaml))", (skill / "SKILL.md").read_text(encoding="utf-8", errors="ignore")):
        if not (skill / "references" / ref.split("references/", 1)[-1]).exists() and not (skill / "references" / Path(ref).name).exists():
            emit("ERROR", f"{skill}: referencia inexistente {ref}", errors, warnings)
    prompt_dir = skill / "references" / "prompts"
    if not prompt_dir.is_dir() or len(list(prompt_dir.glob("*.md"))) < 2:
        emit("ERROR", f"{skill}: faltan los dos prompts mínimos en {prompt_dir}", errors, warnings)
    if validator and validator.exists():
        result = subprocess.run([sys.executable, str(validator), str(skill)], text=True, capture_output=True)
        if result.returncode: emit("ERROR", f"{skill}: quick_validate falló: {(result.stdout + result.stderr).strip()}", errors, warnings)
        else: print(f"OK QUICK_VALIDATE {name}")
    return name

def cross_audit(source: Path, errors: list[str], warnings: list[str]) -> None:
    prompts_root = source / "prompts"
    if not prompts_root.is_dir():
        emit("ERROR", "falta carpeta prompts", errors, warnings)
    else:
        for item in prompts_root.iterdir():
            if item.is_dir():
                emit("ERROR", f"prompts: no se permiten subcarpetas ({item.name})", errors, warnings)
        expected = {
            "gestionar-casos-apex.md",
            "gestionar-errores-reportados-apex.md",
            "preparar-nuevo-gestion-proyectos.md",
            "actualizar-estandares-gestion-proyectos.md",
        }
        actual = {path.name for path in prompts_root.glob("*.md")}
        if actual != expected:
            emit("ERROR", "prompts debe contener exactamente los prompts registrados de preparacion, actualizacion y gestion", errors, warnings)
    required = {
        "skill/desarrollador-apex/SKILL.md": ("nunca marca una tarea `Bloqueada`", "No adquieras, mantengas, interpretes ni liberes locks", "Todo flujo funcional o tecnico definido", "./references/ords.md", "ORDS_STATIC_AUDIT_PASS", "no crea ni administra carpetas de proyecto"),
        "skill/desarrollador-apex/references/estandares-apex.md": ("template de boton `Icon`", "template de region `Zaimella Tabla`", "Header Text", "region padre de formulario", "Select List` alimentado por SQL", "¿Está seguro de eliminar el registro?"),
        "skill/desarrollador-apex/scripts/validate_apex_page_standards.py": ("APEX-ACTION-004", "APEX-TABLE-003", "APEX-FORM-001", "APEX-LOV-001", "APEX-LOV-002", "APEX-DELETE-001"),
        "skill/desarrollador-apex/scripts/validate_plsql_package_standards.py": ("PLSQL_STATIC_AUDIT_", "PLSQL-DOC-001", "PLSQL-TRANS-001", "PLSQL-FORMAT-001"),
        "skill/desarrollador-apex/scripts/analyze_plsql_reuse.py": ("SECTION_DUPLICATE", "PK_<MODULO>_COMMONS", "ni autoriza crear"),
        "skill/desarrollador-apex/scripts/validate_oracle_data_object_standards.py": ("ORACLE_DATA_AUDIT_", "Valores permitidos:", "ORACLE-DATA-003", "ORACLE_DOMAIN_PROPOSAL"),
        "skill/desarrollador-apex/references/reutilizacion-plsql.md": ("PK_<MODULO>_COMMONS", "no crea", "dependencia ciclica", "regresion"),
        "skill/desarrollador-apex/references/ords.md": ("AUTHID DEFINER", "consumidor", "DPAPI", "vault", "HTTPS", "ORDS.DELETE_MODULE", "REUSED"),
        "skill/desarrollador-apex/scripts/validate_ords_deploy.py": ("ORDS_STATIC_AUDIT_", "ORDS_DELETE_MODULE_FORBIDDEN", "ORDS_SECRET_LITERAL", "ORDS_PACKAGE_NOT_DEFINER"),
        "skill/desarrollador-apex/scripts/ords_oauth_tool.py": ("CryptProtectData", "--confirm-production", "--allow-insecure-http", "CLIENT_SECRET_SHA256", "REUSED"),
        "skill/qa-apex/SKILL.md": ("nunca marca una tarea `Bloqueada`", "No adquirir, mantener, liberar ni interpretar locks", "Un timeout aislado no es resultado terminal", "El flujo definido por el usuario", "No redacta el documento", "documentacion-proyecto-sistemas", "no crea ni administra estructura de proyecto"),
        "skill/qa-apex/references/estandares-qa-apex.md": ("QA no crea, exige, interpreta, conserva ni libera locks", "QA no implementa", "## Gate terminal y recuperacion de timeout", "¿Está seguro de eliminar el registro?"),
        "skill/qa-apex/references/auditoria-estandares-apex.md": ("template `Zaimella Tabla`", "Header Text", "region padre de formulario", "Maestros o catalogos transaccionales", "¿Está seguro de eliminar el registro?"),
        "commands/Desarrollo-APEX.md": ("AGENTS.md", "orquestador", "Los skills solo emiten resultados tecnicos: nunca marcan una tarea `Bloqueada`", "No emitir respuesta final mientras exista una accion segura", "No cerrar la tarea` no significa", "update_apex_task_terminal_gate.py", "Stop hook", "/goal", "Los flujos definidos son vinculantes", "ords.template.md"),
        "commands/resources/Desarrollo-APEX/agents-md-orquestador.md": ("## Gate Terminal De Respuesta", "Un timeout aislado nunca satisface el gate terminal", "no terminar el turno", "un avance nunca puede ser el ultimo mensaje", "`COMPLETA` o `BLOQUEADA`", "update_apex_task_terminal_gate.py", "continue: false", "stopReason", "stop_hook_active=true", "Todo flujo definido por requerimiento", "ORDS_STATIC_AUDIT_PASS"),
        "commands/resources/Desarrollo-APEX/auditoria-pre-test.template.md": ("## Estructura Visual Y Componentes", "## Decision De Componentes De Lista", "Zaimella Tabla", "Header Text vacio", "## ORDS Y OAuth"),
        "commands/resources/Desarrollo-APEX/tarea.template.md": ("<!-- ZAIMELLA:APEX:TASK-TERMINAL-GATE:START -->", "<!-- ZAIMELLA:APEX:TASK-TERMINAL-GATE:END -->", "## Gate Terminal De Respuesta", "un avance nunca puede ser el ultimo mensaje", "`COMPLETA` o `BLOQUEADA`", "## Contrato ORDS/OAuth"),
        "commands/resources/Desarrollo-APEX/ords.template.md": ("## OAuth Por Ambiente", "Custodio/vault", "ORDS_STATIC_AUDIT_PASS", "Anonimo 401/403", "REUSED"),
        "scripts/update_apex_task_terminal_gate.py": ("TASK-TERMINAL-GATE:START", "TASK_GATE_SKIPPED_CLOSED", "--project-root", "--dry-run", "--apply"),
        "scripts/apex_stop_guard.py": ("hook_event_name", "stop_hook_active", "last_assistant_message", "continue", "stopReason", "TASK-TERMINAL-GATE:START"),
        "scripts/install_global_codex_orchestrators.py": ("apex_stop_guard.py", "HOOK_REVIEW_REQUIRED", "hooks.json", "commandWindows"),
        "scripts/zaimella_agent_setup.py": ("update_apex_task_terminal_gate.py", "install_global_codex_orchestrators.py"),
        "skill/documentacion-proyecto-sistemas/SKILL.md": ("funcional", "tecnico", "mixto", "DOCUMENTACION_INCOMPLETA", "validate_documentation_manifest.py", "No desarrollar, corregir ni probar", "no crea ni administra la arquitectura"),
        "skill/documentacion-proyecto-sistemas/references/contrato-evidencia.md": ("documentId", "deliverableId", "baseline", "sourceEvidence"),
        "skill/documentacion-proyecto-sistemas/references/prompts/preparacion-ambiente.md": ("linea base", "validate_documentation_manifest.py"),
        "skill/documentacion-proyecto-sistemas/references/prompts/uso-en-agents.md": ("funcional", "tecnico", "no desarrolla", "no ejecuta QA"),
        "skill/metodologia-proyectos/references/etapas/ad/uso_skills_tecnicos.md": ("orquestador de dominio", "nunca por skill tecnico directo", "DOMINIO_SIN_ORQUESTADOR", "necesidad concreta"),
        "commands/Gestion-Proyectos.md": ("Proyecto -> Entregable -> Sprint -> Paquete de trabajo", "capability_id", "DOMINIO_SIN_ORQUESTADOR", "documentacion-proyecto-sistemas", "validate_project_delivery_coverage.py", "validate_project_handoff.py", "dominios/<DOMINIO>"),
        "commands/resources/Gestion-Proyectos/agents-md-orquestador.md": ("No invocar, coordinar ni corregir sus skills internos", "orquestador compuesto mas especifico", "DOMINIO_SIN_ORQUESTADOR", "Un hallazgo corregible permanece dentro del ciclo", "documentacion-proyecto-sistemas", "Los skills no crean ni administran arquitectura", "dominios/<DOMINIO>"),
        "commands/resources/Gestion-Proyectos/arquitectura-contextos.md": ("<PROJECT_ROOT>", "dominios/", "desarrollo.md", "desarrollo-aws.md", "repositorios de codigo viven", "worktrees viven"),
        "prompts/preparar-nuevo-gestion-proyectos.md": ("documentos `.md` por defecto", "mueve solo los archivos con destino inequivoco", "No muevas `AGENTS.md`", "DOMINIO_SIN_ORQUESTADOR"),
        "prompts/actualizar-estandares-gestion-proyectos.md": ("documentos `.md` por defecto", "mueve solo los que tengan destino inequivoco", "No mover `AGENTS.md`", "No crees orquestadores de dominio futuros"),
        "prompts/gestionar-casos-apex.md": ("No desarrolles ni publiques funcionalidades", "ni crees o reorganices la arquitectura general"),
        "prompts/gestionar-errores-reportados-apex.md": ("No implementes ni publiques cambios", "ni crees o reorganices la arquitectura general"),
        "commands/resources/Gestion-Proyectos/paquete-trabajo.template.md": ("ID proyecto", "ID entregable", "ID sprint", "ID paquete", "Capability ID", "Responsable ejecutor", "Criterios de aceptacion"),
        "commands/resources/Gestion-Proyectos/handoff-dominio.template.md": ("APROBADO_DOMINIO", "EN_CORRECCION_DOMINIO", "Responsable ejecutor", "Componentes y versiones/SHA", "Impacto documental", "Hechos y evidencia para documentacion"),
        "commands/orchestrators.json": ("Gestion-Proyectos", "project-lifecycle", "apex-oracle-ords", "movilmella-fullstack", "aws-etl-with-oracle-source", "internal_skills"),
        "scripts/update_gestion_proyectos_agents_md.py": ("Gestion Proyectos :START", "--dry-run", "--apply"),
        "scripts/validate_project_handoff.py": ("PROJECT_HANDOFF_PASS", "APROBADO_DOMINIO", "IDENTITY_FIELDS"),
        "scripts/validate_project_delivery_coverage.py": ("PROJECT_COVERAGE_PASS", "dispatch", "integration", "documentation", "close"),
        "scripts/reconcile_project_state.py": ("SIN_HANDOFF", "POR_RECONCILIAR", "--write"),
        "scripts/resolve_project_orchestrator.py": ("PROJECT_ORCHESTRATOR_OWNER", "PROJECT_ORCHESTRATOR_UNASSIGNED", "DOMINIO_SIN_ORQUESTADOR", "capability-id"),
        "commands/resources/Desarrollo-AWS/tarea.template.md": ("## Vinculo Con Proyecto", "## Resultados Verificables", "Handoff de salida"),
    }
    for rel, terms in required.items():
        path = source / rel
        if not path.exists(): emit("ERROR", f"falta skill transversal {rel}", errors, warnings); continue
        lower = path.read_text(encoding="utf-8", errors="ignore").lower()
        for term in terms:
            if term.lower() not in lower: emit("ERROR", f"{rel}: omite gate requerido '{term}'", errors, warnings)
    registry_path = source / "commands" / "orchestrators.json"
    try:
        registry = json.loads(registry_path.read_text(encoding="utf-8"))
        orchestrators = registry["orchestrators"]
        names = [item["name"] for item in orchestrators]
        if len(names) != len(set(names)):
            emit("ERROR", "commands/orchestrators.json: nombres duplicados", errors, warnings)
        owners: dict[str, str] = {}
        for item in orchestrators:
            for key in ("name", "level", "capabilities", "internal_skills", "global_template"):
                if key not in item:
                    emit("ERROR", f"commands/orchestrators.json: {item.get('name')} omite {key}", errors, warnings)
            template = source / item["global_template"]
            if not template.is_file():
                emit("ERROR", f"commands/orchestrators.json: plantilla inexistente {template}", errors, warnings)
            if item.get("level") == "domain":
                for capability in item.get("capabilities", []):
                    if capability in owners:
                        emit("ERROR", f"commands/orchestrators.json: capability {capability} tiene dos propietarios", errors, warnings)
                    owners[capability] = item["name"]
    except (OSError, KeyError, TypeError, json.JSONDecodeError) as exc:
        emit("ERROR", f"commands/orchestrators.json invalido: {exc}", errors, warnings)
    qa = source / "skill/qa-apex"
    for path in qa.rglob("*.md"):
        text = path.read_text(encoding="utf-8", errors="ignore")
        if re.search(r"QA funcional encuentra errores.{0,120}debe correg", text, flags=re.I|re.S):
            emit("ERROR", f"{path}: QA corrige desarrollo", errors, warnings)
        if re.search(r"(?:emitir|resultado|recomendacion).{0,80}`Bloqueado`", text, flags=re.I|re.S):
            emit("ERROR", f"{path}: QA usa Bloqueado como salida propia", errors, warnings)
    documentation_builder = source / "skill/documentacion-proyecto-sistemas/scripts/build_manual_cambios.py"
    if documentation_builder.is_file() and "allow-unvalidated" in documentation_builder.read_text(encoding="utf-8", errors="ignore"):
        emit("ERROR", f"{documentation_builder}: permite omitir validaciones documentales", errors, warnings)
    for root in (source / "skill/desarrollador-apex", source / "skill/qa-apex"):
        for path in root.rglob("*.md"):
            text = path.read_text(encoding="utf-8", errors="ignore")
            if re.search(r"\b(?:al adquirir|una vez adquirido|adquiere|libera)\b.{0,40}\b(?:test\.)?lock\b", text, flags=re.I|re.S):
                emit("ERROR", f"{path}: skill controla locks", errors, warnings)
            if re.search(r"cerrar automaticamente.{0,100}\btarea\b", text, flags=re.I|re.S):
                emit("ERROR", f"{path}: skill cierra estados de tarea", errors, warnings)
    hashes: dict[str, list[str]] = {}
    for path in (source / "skill").rglob("*"):
        if path.is_file() and path.name != "SKILL.md": hashes.setdefault(hashlib.sha256(path.read_bytes()).hexdigest(), []).append(str(path.relative_to(source)))
    for group in hashes.values():
        if len(group) > 1: emit("WARN", "contenido idéntico a revisar: " + ", ".join(group), errors, warnings)

def install(source_skill: Path, dest_root: Path, validator: Path | None, errors: list[str]) -> None:
    name = frontmatter(source_skill / "SKILL.md")["name"]
    dest_root.mkdir(parents=True, exist_ok=True)
    same_name = []
    for candidate in dest_root.iterdir():
        if candidate.is_dir() and (candidate / "SKILL.md").exists():
            try:
                if frontmatter(candidate / "SKILL.md")["name"] == name: same_name.append(candidate)
            except ValueError: errors.append(f"instalación inválida existente: {candidate}")
    target = dest_root / name
    if any(item != target for item in same_name): errors.append(f"duplicado activo de {name}: {same_name}")
    if errors: return
    stage = dest_root / f".{name}.stage"
    backup = dest_root / f".{name}.backup"
    for item in (stage, backup):
        if item.exists(): shutil.rmtree(item)
    shutil.copytree(source_skill, stage)
    if validator and validator.exists() and subprocess.run([sys.executable, str(validator), str(stage)]).returncode:
        errors.append(f"validación posterior falló: {name}"); shutil.rmtree(stage); return
    if files(source_skill) != files(stage): errors.append(f"paridad staging falló: {name}"); shutil.rmtree(stage); return
    if target.exists(): target.replace(backup)
    try:
        stage.replace(target)
        if files(source_skill) != files(target): raise RuntimeError("paridad final falló")
        print(f"OK INSTALLED {name} FILES={len(files(target))}")
        if backup.exists(): shutil.rmtree(backup)
    except Exception as exc:
        if target.exists(): shutil.rmtree(target)
        if backup.exists(): backup.replace(target)
        errors.append(f"instalación revertida {name}: {exc}")

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", default=".")
    parser.add_argument("--dest", help="Instala en esta carpeta de skills si la auditoría pasa.")
    parser.add_argument("--skill", action="append", help="Nombre de skill; por defecto audita todos.")
    parser.add_argument("--validator", default=None)
    args = parser.parse_args(); root = Path(args.repo_root).resolve(); skills = root / "skill"
    validator = Path(args.validator).resolve() if args.validator else None
    selected = [skills / n for n in args.skill] if args.skill else sorted(p for p in skills.iterdir() if p.is_dir())
    errors: list[str]=[]; warnings: list[str]=[]; names: dict[str, Path]={}
    for item in selected:
        name=audit_skill(item, validator, errors, warnings)
        if name:
            if name in names: emit("ERROR", f"name duplicado {name}: {names[name]} y {item}", errors, warnings)
            names[name]=item
    cross_audit(root, errors, warnings)
    if errors:
        print(f"AUDIT_FAILED errors={len(errors)} warnings={len(warnings)}"); return 2
    print(f"AUDIT_OK skills={len(selected)} warnings={len(warnings)}")
    if args.dest:
        for item in selected: install(item, Path(args.dest).resolve(), validator, errors)
        if errors: print("INSTALL_FAILED " + " | ".join(errors)); return 2
    return 0

if __name__ == "__main__": raise SystemExit(main())
