#!/usr/bin/env python3
"""Inserta o actualiza el bloque administrado del orquestador Movilmella."""
from __future__ import annotations

import argparse
import difflib
import hashlib
import re
from pathlib import Path

START = "<!-- ZAIMELLA: Movilmella :START -->"
END = "<!-- ZAIMELLA: Movilmella :END -->"


def canonical_block() -> str:
    prompt = Path(__file__).resolve().parents[1] / "commands" / "resources" / "Movilmella" / "agents-md-orquestador.md"
    text = prompt.read_text(encoding="utf-8")
    match = re.search(r"## Seccion 1 - Contenido Para AGENTS\.md\s*\n\s*```markdown\s*\n(.*?)\n```", text, re.S)
    if not match:
        raise ValueError("No se encontro el bloque canonico Movilmella.")
    return match.group(1).strip()


def migrate(current: str) -> str:
    block = re.compile(r"<!-- ZAIMELLA:\s*Movilmella\s*:START -->.*?<!-- ZAIMELLA:\s*Movilmella\s*:END -->", re.S)
    managed = f"{START}\n{canonical_block()}\n{END}"
    if block.search(current):
        updated = block.sub(managed, current, count=1)
        return updated.rstrip() + "\n"
    return (current.rstrip() + "\n\n" if current.strip() else "") + managed + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", required=True)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check", action="store_true")
    mode.add_argument("--dry-run", action="store_true")
    mode.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    path = Path(args.project_root).resolve() / "AGENTS.md"
    current = path.read_text(encoding="utf-8") if path.exists() else ""
    try:
        updated = migrate(current)
    except ValueError as exc:
        print(f"AGENTS_BLOCKED {exc}")
        return 2
    print(f"AGENTS_PATH {path}")
    print(f"CHANGE_REQUIRED {str(current != updated).lower()}")
    if args.check:
        return 0
    if args.dry_run:
        print("".join(difflib.unified_diff(current.splitlines(True), updated.splitlines(True), fromfile=str(path), tofile=str(path))), end="")
        return 0
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".md.zaimella-tmp")
    temporary.write_text(updated, encoding="utf-8")
    temporary.replace(path)
    print(f"AGENTS_UPDATED sha256={hashlib.sha256(updated.encode()).hexdigest()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
