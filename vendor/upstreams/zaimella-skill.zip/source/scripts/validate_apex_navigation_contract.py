#!/usr/bin/env python3
"""Valida que un contrato de navegacion APEX este listo antes de invocar QA visual."""

from __future__ import annotations

import argparse
import re
from pathlib import Path


REQUIRED_LABELS = (
    "Ambiente:", "Login:", "Usuario QA:", "Compania:",
    "Control visible de usuario:", "Boton visible de ingreso:",
    "Marcador de sesion correcta:", "## Ruta Oficial",
    "## Ruta Alternativa Validada", "## Componentes Y Funcionamiento",
    "Clasificacion de destino:", "Regla de entrada:",
    "Pagina principal/padre:", "Parametro o contexto obligatorio de entrada:",
    "Mapa funcional exportado:", "Fuente APEX analizada:",
    "Accion exacta que ejecuta QA:", "Datos minimos o precondiciones:",
    "Resultado esperado:", "Evidencia de ruta primaria:",
    "Evidencia de ruta alternativa:", "Ultima validacion:",
)
PLACEHOLDER = re.compile(r"<[^>]+>|\bpendiente\b|\bpor definir\b|\bse verificara\b", re.IGNORECASE)


def meaningful_value(line: str) -> bool:
    _, _, value = line.partition(":")
    return bool(value.strip()) and not PLACEHOLDER.search(value)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--navigation", required=True, type=Path)
    args = parser.parse_args()
    path = args.navigation
    if not path.is_file():
        print(f"NAVIGATION_CONTRACT_FAIL: no existe {path}")
        return 2
    text = path.read_text(encoding="utf-8", errors="replace")
    errors: list[str] = []
    if "- Estado de navegacion: Validado por Desarrollo" not in text:
        errors.append("falta Estado de navegacion: Validado por Desarrollo")
    for label in REQUIRED_LABELS:
        matches = [line for line in text.splitlines() if label.casefold() in line.casefold()]
        if not matches:
            errors.append(f"falta {label}")
        elif label.endswith(":") and not any(meaningful_value(line) for line in matches):
            errors.append(f"sin valor operativo: {label}")
    if PLACEHOLDER.search(text):
        errors.append("contiene marcador, Pendiente, por definir o 'se verificara'")
    classification_line = next(
        (line for line in text.splitlines() if "Clasificacion de destino:" in line), ""
    )
    classification = classification_line.partition(":")[2].strip().casefold()
    allowed_classifications = {"principal", "secundaria_parametrizada", "dialogo_modal"}
    if classification not in allowed_classifications:
        errors.append("Clasificacion de destino debe ser principal, secundaria_parametrizada o dialogo_modal")
    for label in ("Pagina principal/padre:", "Parametro o contexto obligatorio de entrada:"):
        line = next((value for value in text.splitlines() if label.casefold() in value.casefold()), "")
        value = line.partition(":")[2].strip()
        if classification in {"secundaria_parametrizada", "dialogo_modal"} and value.casefold() == "no aplica":
            errors.append(f"{classification} exige valor operativo: {label}")
    quick_url_line = next(
        (line for line in text.splitlines() if "URL rápida con sesión autenticada:" in line), ""
    )
    quick_url_value = quick_url_line.partition(":")[2].strip().casefold()
    if quick_url_value != "no aplica" and "DIRECT_URL_ALLOWED" not in text:
        errors.append("declara URL rapida sin evidencia DIRECT_URL_ALLOWED")
    if classification in {"secundaria_parametrizada", "dialogo_modal"} and quick_url_value != "no aplica":
        errors.append(f"{classification} no admite URL rapida directa")
    if not re.search(r"^1\.\s+.+", text, flags=re.MULTILINE):
        errors.append("Ruta Oficial no contiene un primer paso ejecutable")
    if not re.search(r"Validacion realizada por desarrollo:\s*[^\n]+", text, flags=re.IGNORECASE):
        errors.append("falta evidencia de validacion de la ruta alternativa")
    for label in ("Evidencia de ruta primaria:", "Evidencia de ruta alternativa:"):
        line = next((value for value in text.splitlines() if label.casefold() in value.casefold()), "")
        _, _, value = line.partition(":")
        evidence = value.strip().strip("`")
        if evidence and not PLACEHOLDER.search(evidence) and evidence.casefold() != "no aplica":
            evidence_path = Path(evidence)
            if not evidence_path.is_absolute():
                evidence_path = path.parent / evidence_path
            if not evidence_path.is_file():
                errors.append(f"evidencia no encontrada: {label} {evidence}")
    label = "Mapa funcional exportado:"
    line = next((value for value in text.splitlines() if label.casefold() in value.casefold()), "")
    _, _, value = line.partition(":")
    source_map = value.strip().strip("`")
    if source_map and not PLACEHOLDER.search(source_map):
        map_path = Path(source_map)
        if not map_path.is_absolute():
            map_path = path.parent / map_path
        if not map_path.is_file():
            errors.append(f"mapa funcional no encontrado: {source_map}")
    if re.search(r"\b(subir|cargar)\b.{0,80}\b(archivo|adjunto)\b", text, flags=re.IGNORECASE):
        label = "Archivo de prueba QA:"
        line = next((value for value in text.splitlines() if label.casefold() in value.casefold()), "")
        _, _, value = line.partition(":")
        test_data = value.strip().strip("`")
        if not line or not test_data or PLACEHOLDER.search(test_data) or test_data.casefold() == "no aplica":
            errors.append("falta archivo de prueba QA para escenario de carga")
        else:
            data_path = Path(test_data)
            if not data_path.is_absolute():
                data_path = path.parent / data_path
            if not data_path.is_file():
                errors.append(f"archivo de prueba QA no encontrado: {test_data}")
    if errors:
        print("NAVIGATION_CONTRACT_FAIL")
        for error in errors:
            print(f"- {error}")
        return 1
    print(f"NAVIGATION_CONTRACT_OK: {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
