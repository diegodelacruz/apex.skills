#!/usr/bin/env python3
"""Migra la arquitectura APEX heredada a un único bloque Desarrollo-APEX."""
from __future__ import annotations

import argparse
import difflib
import hashlib
import re
import sys
import unicodedata
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

MARKER = "ZAIMELLA: Desarrollo Apex "
START = f"<!-- {MARKER}:START -->"
END = f"<!-- {MARKER}:END -->"
MANAGED_BLOCK = re.compile(
    r"<!-- (?P<name>ZAIMELLA:(?:\s*Desarrollo\s+Apex\s*|ORQUESTADOR-DESARROLLO-APEX|COMMAND-Desarrollo-APEX(?:-(?:ORCHESTRATOR|PROMPT-[^:]+))?|COMMAND:Desarrollo-APEX:(?:ORCHESTRATOR|PROMPT:.*?))):START -->"
    r".*?<!-- (?P=name):END -->",
    re.S,
)
HEADING = re.compile(r"^(#{1,6})[ \t]+(.+?)[ \t]*$", re.M)
LEGACY_COMMENTS = re.compile(
    r"(?mi)^<!--\s*La\s+pol[ií]tica\s+APEX\s+se\s+administra\s+mediante\s+orquestador-desarrollo-apex\.\s*-->\s*$"
)
POTENTIAL_CONFLICTS = (
    (r"C:/ZAIMELLA.{0,100}(desarroll|editar)", "Desarrollo directo en checkout de integración."),
    (r"(liber|soltar).{0,100}(lock).{0,100}(QA|resultado)", "Lock liberado al terminar QA."),
    (r"qa(?:-apex)?.{0,100}(correg|implement|actualiz).{0,100}(codigo|pantalla|navegaci)", "QA implementa correcciones."),
    (r"(detener|bloquear|pausar).{0,120}(tarea|desarrollo).{0,120}(QA|lock|checkout|compil|import)", "Politica de continuidad APEX incompatible."),
    (r"(timeout|runner|QA).{0,160}(terminar|finalizar|cerrar).{0,100}(turno|sesion|tarea)", "Gate terminal APEX incompatible."),
    (r"(PR obligatorio|push.{0,80}codex/|producci.n.{0,100}(antes|sin).{0,100}origin/main)", "Política Git/producción incompatible."),
)
CANONICAL_HEADINGS = (
    "## Contratos",
    "## Arquitectura",
    "## Método De Trabajo",
    "## Politica De Continuidad",
    "## Gate Terminal De Respuesta",
    "## Gates No Negociables",
)


def command_block() -> str:
    prompt = Path(__file__).resolve().parents[1] / "commands" / "resources" / "Desarrollo-APEX" / "agents-md-orquestador.md"
    text = prompt.read_text(encoding="utf-8")
    match = re.search(r"## Seccion 1 - Contenido Para AGENTS\.md\s*\n\s*```markdown\s*\n(.*?)\n```", text, re.S)
    if not match:
        raise ValueError("No se encontró el bloque canónico en agents-md-orquestador.md.")
    block = match.group(1).strip()
    missing = [heading for heading in CANONICAL_HEADINGS if heading not in block]
    if missing:
        raise ValueError("Bloque canónico incompleto: " + ", ".join(missing))
    if "D:/.../proyecto/contexto" in block:
        raise ValueError("Bloque canónico contiene una ruta de proyecto ambigua.")
    return block


def managed_block() -> str:
    return f"{START}\n{command_block()}\n{END}\n"


def normalized_title(value: str) -> str:
    plain = "".join(
        char for char in unicodedata.normalize("NFD", value.casefold()) if unicodedata.category(char) != "Mn"
    )
    return re.sub(r"\s+", " ", plain).strip()


def is_legacy_apex_section(title: str) -> bool:
    value = normalized_title(title)
    return value == "manual de usuario apex" or value.startswith("arquitectura de trabajo apex") or value in {
        "flujo secuencial obligatorio",
        "regla de cierre por tarea",
        "prohibiciones de avance",
        "resultado esperado en cada tarea",
    }


def remove_legacy_sections(text: str) -> tuple[str, int]:
    """Elimina una sección completa hasta el próximo encabezado del mismo nivel o superior."""
    lines = text.splitlines(keepends=True)
    retained: list[str] = []
    removed = 0
    index = 0
    while index < len(lines):
        match = HEADING.match(lines[index].rstrip("\r\n"))
        if not match or not is_legacy_apex_section(match.group(2)):
            retained.append(lines[index])
            index += 1
            continue
        level = len(match.group(1))
        removed += 1
        index += 1
        while index < len(lines):
            next_heading = HEADING.match(lines[index].rstrip("\r\n"))
            if next_heading and len(next_heading.group(1)) <= level:
                break
            index += 1
    return "".join(retained), removed


def migrate(current: str) -> tuple[str, list[str]]:
    legacy_blocks = 0

    def remove_managed(match: re.Match[str]) -> str:
        nonlocal legacy_blocks
        if not re.fullmatch(r"ZAIMELLA:\s*Desarrollo\s+Apex\s*", match.group("name")):
            legacy_blocks += 1
        return ""

    migrated = MANAGED_BLOCK.sub(remove_managed, current)
    migrated, sections = remove_legacy_sections(migrated)
    migrated, comments = LEGACY_COMMENTS.subn("", migrated)
    changes: list[str] = []
    if legacy_blocks:
        changes.append(f"Bloques APEX administrados heredados eliminados: {legacy_blocks}.")
    if sections:
        changes.append(f"Secciones APEX heredadas migradas: {sections}.")
    if comments:
        changes.append(f"Comentarios APEX heredados eliminados: {comments}.")
    return migrated.strip(), changes


def conflicts(text: str) -> list[str]:
    return [message for pattern, message in POTENTIAL_CONFLICTS if re.search(pattern, text, flags=re.I | re.S)]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", required=True)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check", action="store_true")
    mode.add_argument("--dry-run", action="store_true")
    mode.add_argument("--apply", action="store_true")
    args = parser.parse_args()

    path = Path(args.project_root).resolve() / "AGENTS.md"
    current = path.read_text(encoding="utf-8") if path.exists() else ""
    try:
        external, migrations = migrate(current)
        updated = (external + "\n\n" if external else "") + managed_block()
    except ValueError as exc:
        print(f"AGENTS_BLOCKED {exc}")
        return 2
    found = conflicts(external)
    for item in migrations:
        print(f"LEGACY_MIGRATION {item}")
    for item in found:
        print(f"POTENTIAL_CONFLICT {item}")
    print(f"AGENTS_PATH {path}")
    print(f"CHANGE_REQUIRED {str(current != updated).lower()}")
    if args.check:
        return 2 if found else 0
    if found:
        print("AGENTS_BLOCKED Resolver conflictos potenciales antes de aplicar.")
        return 2
    if args.dry_run:
        sys.stdout.writelines(difflib.unified_diff(current.splitlines(True), updated.splitlines(True), fromfile=str(path), tofile=str(path)))
        return 0
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".md.zaimella-tmp")
    temporary.write_text(updated, encoding="utf-8")
    temporary.replace(path)
    print(f"AGENTS_UPDATED sha256={hashlib.sha256(updated.encode()).hexdigest()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
