#!/usr/bin/env python3
"""Inserta el bloque canónico Desarrollo-AWS sin sobrescribir reglas locales."""
from __future__ import annotations

import argparse
import difflib
import hashlib
import re
from pathlib import Path

MARKER = "ZAIMELLA: Desarrollo AWS "
START = f"<!-- {MARKER}:START -->"
END = f"<!-- {MARKER}:END -->"
MANAGED = re.compile(r"<!-- ZAIMELLA:(?:\s*Desarrollo\s+AWS\s*|ORQUESTADOR-DESARROLLO-AWS):START -->.*?<!-- ZAIMELLA:(?:\s*Desarrollo\s+AWS\s*|ORQUESTADOR-DESARROLLO-AWS):END -->", re.S)
CONFLICTS = (
    (r"desarrollador-apex.{0,100}(modific|actualiz|desarroll).{0,100}AWS", "APEX asignado a desarrollo AWS."),
    (r"aws-etl-experto.{0,100}(modific|actualiz).{0,100}(Oracle|APEX|producci.n)", "AWS asignado a modificar fuente Oracle/APEX."),
    (r"fuente.{0,80}producci.n.{0,80}(INSERT|UPDATE|DELETE|ALTER|CREATE|DROP)", "Cambios sobre fuente productiva."),
)


def canonical_block() -> str:
    prompt = Path(__file__).resolve().parents[1] / "commands" / "resources" / "Desarrollo-AWS" / "agents-md-orquestador.md"
    text = prompt.read_text(encoding="utf-8")
    match = re.search(r"## Sección 1 - Contenido para AGENTS\.md\s*\n\s*```markdown\s*\n(.*?)\n```", text, re.S)
    if not match:
        raise ValueError("No se encontró el bloque canónico Desarrollo-AWS.")
    return match.group(1).strip()


def migrate(current: str) -> str:
    external = MANAGED.sub("", current).strip()
    return (external + "\n\n" if external else "") + f"{START}\n{canonical_block()}\n{END}\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", required=True)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check", action="store_true")
    mode.add_argument("--dry-run", action="store_true")
    mode.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    path = Path(args.project_root).resolve() / "AGENTS.md"
    current = path.read_text(encoding="utf-8") if path.exists() else ""
    conflicts = [message for pattern, message in CONFLICTS if re.search(pattern, current, re.I | re.S)]
    for item in conflicts:
        print(f"POTENTIAL_CONFLICT {item}")
    print(f"AGENTS_PATH {path}")
    if args.check:
        return 2 if conflicts else 0
    if conflicts:
        print("AGENTS_BLOCKED Resolver contradicciones antes de aplicar.")
        return 2
    updated = migrate(current)
    print(f"CHANGE_REQUIRED {str(current != updated).lower()}")
    if args.dry_run:
        print("".join(difflib.unified_diff(current.splitlines(True), updated.splitlines(True), fromfile=str(path), tofile=str(path))), end="")
        return 0
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(".md.zaimella-tmp")
    temp.write_text(updated, encoding="utf-8")
    temp.replace(path)
    print(f"AGENTS_UPDATED sha256={hashlib.sha256(updated.encode()).hexdigest()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
