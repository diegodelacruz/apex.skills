#!/usr/bin/env python3
"""Inserta o actualiza el contrato canonico de subtareas en tareas APEX activas."""
from __future__ import annotations

import argparse
import difflib
import re
import sys
from pathlib import Path

START = "<!-- ZAIMELLA:APEX:SUBTASKS:START -->"
END = "<!-- ZAIMELLA:APEX:SUBTASKS:END -->"
STATE = re.compile(r"(?mi)^\s*-?\s*Estado\s*:\s*(.+?)\s*$")
CLOSED = re.compile(r"\bcerrad[ao]s?\b", re.I)
HISTORY = re.compile(r"(?m)^## Historial De Transiciones\s*$")


def canonical() -> str:
    template = Path(__file__).resolve().parents[1] / "commands" / "resources" / "Desarrollo-APEX" / "tarea.template.md"
    text = template.read_text(encoding="utf-8")
    if text.count(START) != 1 or text.count(END) != 1:
        raise ValueError("tarea.template.md no contiene un unico contrato canonico de subtareas.")
    begin = text.index(START)
    finish = text.index(END, begin) + len(END)
    return text[begin:finish]


def closed(text: str) -> bool:
    match = STATE.search(text)
    return bool(match and CLOSED.search(match.group(1)))


def migrate(text: str, block: str) -> str:
    if text.count(START) != text.count(END) or text.count(START) > 1:
        raise ValueError("marcadores de subtareas invalidos.")
    if START in text:
        begin = text.index(START)
        finish = text.index(END, begin) + len(END)
        return text[:begin] + block + text[finish:]
    history = HISTORY.search(text)
    if not history:
        return text.rstrip() + "\n\n" + block + "\n"
    return text[:history.start()].rstrip() + "\n\n" + block + "\n\n" + text[history.start():]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", required=True, type=Path)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check", action="store_true")
    mode.add_argument("--dry-run", action="store_true")
    mode.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    try:
        block = canonical()
    except ValueError as exc:
        print(f"TASK_SUBTASKS_BLOCKED {exc}")
        return 2
    tasks = args.project_root.resolve() / "docs" / "tareas"
    paths = sorted(path for path in tasks.rglob("tarea.md")) if tasks.is_dir() else []
    changes: list[tuple[Path, str, str]] = []
    for path in paths:
        if "_control" in path.relative_to(tasks).parts:
            continue
        current = path.read_text(encoding="utf-8")
        if closed(current):
            print(f"TASK_SUBTASKS_SKIPPED_CLOSED {path}")
            continue
        try:
            updated = migrate(current, block)
        except ValueError as exc:
            print(f"TASK_SUBTASKS_BLOCKED {path}: {exc}")
            return 2
        if updated != current:
            changes.append((path, current, updated))
            print(f"TASK_SUBTASKS_CHANGE_REQUIRED {path}")
    print(f"TASK_SUBTASKS_SUMMARY changes={len(changes)}")
    if args.check:
        return 0
    if args.dry_run:
        for path, current, updated in changes:
            sys.stdout.writelines(difflib.unified_diff(current.splitlines(True), updated.splitlines(True), fromfile=str(path), tofile=str(path)))
        return 0
    for path, _, updated in changes:
        temporary = path.with_suffix(".md.zaimella-tmp")
        temporary.write_text(updated, encoding="utf-8")
        temporary.replace(path)
        print(f"TASK_SUBTASKS_UPDATED {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
