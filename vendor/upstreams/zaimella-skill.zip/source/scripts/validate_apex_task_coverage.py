#!/usr/bin/env python3
"""Valida la cobertura de subtareas de una tarea/sprint APEX."""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

HEADING = re.compile(r"(?m)^## Subtareas Del Sprint\s*$")
NEXT_HEADING = re.compile(r"(?m)^## ")
PLACEHOLDER = re.compile(r"<[^>]+>|\b(?:pendiente|por definir|n/?a)\b", re.I)


def section(text: str) -> str:
    found = HEADING.search(text)
    if not found:
        raise ValueError("falta la seccion '## Subtareas Del Sprint'.")
    next_heading = NEXT_HEADING.search(text, found.end())
    return text[found.end():next_heading.start() if next_heading else len(text)]


def rows(value: str) -> list[dict[str, str]]:
    lines = [line.strip() for line in value.splitlines() if line.strip().startswith("|")]
    if len(lines) < 3:
        raise ValueError("la matriz de subtareas no tiene encabezado y al menos una subtarea.")
    header = [cell.strip().casefold() for cell in lines[0].strip("|").split("|")]
    expected = ["id subtarea", "objetivo y criterio de aceptacion", "destinos y objetos", "dependencias", "desarrollo", "test", "qa", "evidencia", "sha final", "estado"]
    if header != expected:
        raise ValueError("el encabezado de la matriz de subtareas no coincide con el contrato canonico.")
    result: list[dict[str, str]] = []
    for line in lines[2:]:
        cells = [cell.strip() for cell in line.strip("|").split("|")]
        if len(cells) != len(expected):
            raise ValueError("una fila de subtarea tiene columnas incompletas.")
        result.append(dict(zip(expected, cells)))
    return result


def allowed_no_apply(value: str) -> bool:
    return value.casefold().startswith("no aplica autorizado:") and len(value.split(":", 1)[1].strip()) > 3


def validate(task: Path, phase: str) -> list[str]:
    matrix = rows(section(task.read_text(encoding="utf-8")))
    errors: list[str] = []
    seen: set[str] = set()
    for row in matrix:
        identifier = row["id subtarea"]
        prefix = f"{identifier or '<SIN_ID>'}:"
        if not identifier or PLACEHOLDER.search(identifier):
            errors.append(f"{prefix} ID subtarea pendiente.")
        elif identifier in seen:
            errors.append(f"{prefix} ID subtarea duplicado.")
        seen.add(identifier)
        for column in ("objetivo y criterio de aceptacion", "destinos y objetos", "dependencias", "evidencia", "sha final"):
            if not row[column] or PLACEHOLDER.search(row[column]):
                errors.append(f"{prefix} {column} pendiente.")
        if row["desarrollo"].casefold() != "completado" and not allowed_no_apply(row["desarrollo"]):
            errors.append(f"{prefix} Desarrollo debe ser Completado.")
        if row["test"].casefold() != "aprobado" and not allowed_no_apply(row["test"]):
            errors.append(f"{prefix} TEST debe ser Aprobado.")
        if phase == "close" and row["qa"].casefold() != "aprobado" and not allowed_no_apply(row["qa"]):
            errors.append(f"{prefix} QA debe ser Aprobado para cierre.")
        expected_state = "aprobada" if phase == "close" else "lista para qa"
        if row["estado"].casefold() != expected_state and not allowed_no_apply(row["estado"]):
            errors.append(f"{prefix} Estado debe ser '{expected_state}'.")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task", required=True, type=Path)
    parser.add_argument("--phase", choices=("pre-qa", "close"), required=True)
    args = parser.parse_args()
    if not args.task.is_file():
        print(f"APEX_TASK_COVERAGE_FAIL tarea no encontrada: {args.task}")
        return 2
    try:
        errors = validate(args.task, args.phase)
    except ValueError as exc:
        print(f"APEX_TASK_COVERAGE_FAIL {exc}")
        return 2
    for error in errors:
        print(f"ERROR {error}")
    print(f"APEX_TASK_COVERAGE_{'PASS' if not errors else 'FAIL'} phase={args.phase}")
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
