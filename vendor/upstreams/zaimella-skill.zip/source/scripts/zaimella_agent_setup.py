#!/usr/bin/env python3
"""Instala el ecosistema de skills, comandos y MCP de Zaimella."""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path


REPO_URL = "https://github.com/jefersonKel/zaimella-skill.git"
COMMANDS = {
    "Gestion-Proyectos": {
        "skills": ["metodologia-proyectos", "levantamiento-procesos", "documentacion-proyecto-sistemas"],
        "preparation_prompts": [
            "skill/metodologia-proyectos/references/prompts/preparacion-ambiente.md",
            "skill/documentacion-proyecto-sistemas/references/prompts/preparacion-ambiente.md",
        ],
        "templates": {
            "proyecto/proyecto.md": "commands/resources/Gestion-Proyectos/proyecto.template.md",
            "proyecto/05_planificacion/entregables.md": "commands/resources/Gestion-Proyectos/entregables.template.md",
            "proyecto/06_seguimiento/documentacion/plan.md": "commands/resources/Gestion-Proyectos/plan-documentacion.template.md",
            "proyecto/07_cierre/indice-entregables.md": "commands/resources/Gestion-Proyectos/indice-entregables.template.md",
        },
    },
    "Desarrollo-APEX": {
        "skills": ["desarrollador-apex", "qa-apex"],
        "preparation_prompts": [
            "skill/desarrollador-apex/references/prompts/preparacion-ambiente.md",
            "skill/qa-apex/references/prompts/preparacion-ambiente.md",
        ],
        "context_template": "commands/resources/Desarrollo-APEX/desarrollo.template.md",
        "task_template": "commands/resources/Desarrollo-APEX/tarea.template.md",
        "navigation_template": "commands/resources/Desarrollo-APEX/navegacion.template.md",
    },
    "Movilmella": {
        "skills": ["desarrollador-movilmella", "desarrollador-apex", "qa-apex"],
        "preparation_prompts": [
            "skill/desarrollador-movilmella/references/prompts/preparacion-ambiente.md",
            "skill/desarrollador-apex/references/prompts/preparacion-ambiente.md",
            "skill/qa-apex/references/prompts/preparacion-ambiente.md",
        ],
        "context_template": "commands/resources/Desarrollo-APEX/desarrollo.template.md",
        "task_template": "commands/resources/Movilmella/tarea.template.md",
    },
    "Desarrollo-AWS": {
        "skills": ["aws-etl-experto", "desarrollador-apex"],
        "preparation_prompts": [
            "skill/aws-etl-experto/references/prompts/preparacion-ambiente.md",
            "skill/desarrollador-apex/references/prompts/preparacion-ambiente.md",
        ],
        "context_template": "commands/resources/Desarrollo-AWS/desarrollo-aws.template.md",
        "task_template": "commands/resources/Desarrollo-AWS/tarea.template.md",
    }
}
LEGACY_COMMAND_FILES = ["DESARROLLADOR-APEX.md"]


@dataclass(frozen=True)
class AgentTarget:
    name: str
    skills_dir: Path
    commands_dir: Path
    mcp_kind: str
    mcp_config: Path


def repo_root() -> Path:
    root = Path(__file__).resolve().parents[1]
    if (root / "skill").is_dir() and (root / "prompts").is_dir():
        return root
    raise SystemExit("Este script debe ejecutarse desde un clon del repo zaimella-skill.")


def default_targets() -> dict[str, AgentTarget]:
    home = Path.home()
    codex_home = Path(os.environ.get("CODEX_HOME", home / ".codex"))
    antigravity_home = Path(os.environ.get("ZAIMELLA_ANTIGRAVITY_HOME", home / ".gemini" / "antigravity"))
    return {
        "codex": AgentTarget(
            name="codex",
            skills_dir=codex_home / "skills",
            commands_dir=codex_home / "prompts",
            mcp_kind="codex-toml",
            mcp_config=codex_home / "config.toml",
        ),
        "antigravity": AgentTarget(
            name="antigravity",
            skills_dir=antigravity_home / "skills",
            commands_dir=antigravity_home / "commands",
            mcp_kind="prepared-json",
            mcp_config=antigravity_home / "mcp" / "zaimella-mcp.json",
        ),
    }


def ask_agents() -> list[str]:
    print("Con que IA vas a trabajar?")
    print("1. Codex")
    print("2. Antigravity")
    print("3. Ambas")
    while True:
        answer = input("Selecciona 1, 2 o 3: ").strip().lower()
        if answer in {"1", "codex", "c"}:
            return ["codex"]
        if answer in {"2", "antigravity", "a"}:
            return ["antigravity"]
        if answer in {"3", "ambas", "both", "b"}:
            return ["codex", "antigravity"]
        print("Opcion no valida.")


def run(command: list[str], cwd: Path | None = None) -> None:
    subprocess.run(command, cwd=str(cwd) if cwd else None, check=True)


def command_output(command: list[str]) -> str:
    result = subprocess.run(command, check=True, capture_output=True, text=True)
    return (result.stdout or result.stderr).strip()


def parse_node_version(raw: str) -> tuple[int, int, int]:
    text = raw.strip().lstrip("v")
    parts = text.split(".")
    if len(parts) < 2:
        raise ValueError(f"Version Node.js no reconocida: {raw}")
    major = int(parts[0])
    minor = int(parts[1])
    patch = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 0
    return major, minor, patch


def prepare_cli_tools() -> None:
    print("Preparando herramientas CLI...")

    node = shutil.which("node")
    npm = shutil.which("npm")
    if not node:
        print("TOOL_BLOCKED openspec: Node.js no esta instalado o no esta en PATH.")
        print("Requisito OpenSpec: Node.js >= 20.19.0.")
        return
    if not npm:
        print("TOOL_BLOCKED openspec: npm no esta instalado o no esta en PATH.")
        print("Requisito OpenSpec: npm disponible con Node.js >= 20.19.0.")
        return

    node_version = command_output([node, "--version"])
    try:
        parsed = parse_node_version(node_version)
    except ValueError as exc:
        print(f"TOOL_BLOCKED openspec: {exc}")
        return

    if parsed < (20, 19, 0):
        print(f"TOOL_BLOCKED openspec: Node.js {node_version} es menor que 20.19.0.")
        return

    npm_version = command_output([npm, "--version"])
    print(f"TOOL_OK node {node_version}")
    print(f"TOOL_OK npm {npm_version}")

    openspec = shutil.which("openspec")
    if not openspec:
        print("TOOL_INSTALL openspec @fission-ai/openspec@latest")
        run([npm, "install", "-g", "@fission-ai/openspec@latest"])
        openspec = shutil.which("openspec")

    if not openspec:
        print("TOOL_BLOCKED openspec: instalacion finalizo pero openspec no aparece en PATH.")
        return

    openspec_version = command_output([openspec, "--version"])
    print(f"TOOL_OK openspec {openspec_version}")


def ensure_repo_updated(root: Path, skip_update: bool) -> None:
    if skip_update:
        return
    if not (root / ".git").is_dir():
        print("No se ejecuta git pull porque esta carpeta no es un repo Git.")
        return
    if shutil.which("git") is None:
        print("Git no esta disponible; se omite actualizacion del repo.")
        return
    print("Actualizando repo de skills...")
    run(["git", "pull", "--ff-only"], cwd=root)


def copy_clean(src: Path, dst: Path) -> None:
    if not src.exists():
        raise SystemExit(f"No existe la fuente: {src}")
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        if dst.is_dir():
            shutil.rmtree(dst)
        else:
            dst.unlink()
    if src.is_dir():
        shutil.copytree(src, dst)
    else:
        shutil.copy2(src, dst)


def install_skills(root: Path, target: AgentTarget) -> None:
    auditor = root / "scripts" / "validate_skill_ecosystem.py"
    if not auditor.exists():
        raise SystemExit(f"No existe auditor obligatorio de skills: {auditor}")
    run([sys.executable, str(auditor), "--repo-root", str(root), "--dest", str(target.skills_dir)])


def install_commands(root: Path, target: AgentTarget) -> None:
    commands_root = root / "commands"
    if not commands_root.is_dir():
        return
    target.commands_dir.mkdir(parents=True, exist_ok=True)
    for legacy_name in LEGACY_COMMAND_FILES:
        legacy_path = target.commands_dir / legacy_name
        if legacy_path.exists():
            legacy_path.unlink()
            print(f"COMMAND_REMOVED {target.name} {legacy_name} -> {target.commands_dir}")
    for command_file in sorted(commands_root.glob("*.md")):
        copy_clean(command_file, target.commands_dir / command_file.name)
        print(f"COMMAND_INSTALLED {target.name} {command_file.stem} -> {target.commands_dir}")


def load_context7(root: Path) -> dict:
    path = root / "mcp" / "context7.json"
    if not path.exists():
        raise SystemExit(f"No existe definicion MCP: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def backup_file(path: Path) -> None:
    if not path.exists():
        return
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = path.with_name(f"{path.name}.bak-{stamp}")
    shutil.copy2(path, backup)
    print(f"BACKUP {path} -> {backup}")


def install_mcp(root: Path, target: AgentTarget) -> None:
    context7 = load_context7(root)
    target.mcp_config.parent.mkdir(parents=True, exist_ok=True)

    if target.mcp_kind == "codex-toml":
        existing = target.mcp_config.read_text(encoding="utf-8") if target.mcp_config.exists() else ""
        block = (
            "\n[mcp_servers.context7]\n"
            f"command = \"{context7['command']}\"\n"
            f"args = {json.dumps(context7['args'])}\n"
            f"startup_timeout_ms = {int(context7['startup_timeout_ms'])}\n"
        )
        if "[mcp_servers.context7]" in existing:
            pattern = r"\n?\[mcp_servers\.context7\]\n(?:[^\[]|\[(?!mcp_servers\.))*"
            updated = re.sub(pattern, block + "\n", existing, count=1)
            if updated == existing:
                print(f"MCP_EXISTS {target.name} context7 -> {target.mcp_config}")
                return
            backup_file(target.mcp_config)
            target.mcp_config.write_text(updated.rstrip() + "\n", encoding="utf-8")
            print(f"MCP_UPDATED {target.name} context7 -> {target.mcp_config}")
            return
        backup_file(target.mcp_config)
        target.mcp_config.write_text(existing.rstrip() + block + "\n", encoding="utf-8")
        print(f"MCP_INSTALLED {target.name} context7 -> {target.mcp_config}")
        return

    payload = {
        "mcpServers": {
            "context7": {
                "command": context7["command"],
                "args": context7["args"],
                "startup_timeout_ms": context7["startup_timeout_ms"],
            }
        },
        "note": "Configuracion preparada por Zaimella. Si Antigravity usa otra ruta de MCP, importar este bloque alli.",
    }
    backup_file(target.mcp_config)
    target.mcp_config.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(f"MCP_PREPARED {target.name} context7 -> {target.mcp_config}")


def extract_agents_block(prompt_path: Path) -> str:
    text = prompt_path.read_text(encoding="utf-8")
    marker = "## Seccion 1 - Contenido Para AGENTS.md"
    start = text.find(marker)
    if start < 0:
        raise SystemExit(f"No existe seccion AGENTS.md en {prompt_path}")
    fence = text.find("```markdown", start)
    if fence < 0:
        raise SystemExit(f"No existe fence markdown en {prompt_path}")
    block_start = text.find("\n", fence) + 1
    block_end = text.find("```", block_start)
    if block_end < 0:
        raise SystemExit(f"No cierra fence markdown en {prompt_path}")
    return text[block_start:block_end].strip()


def marked_block(current: str, marker: str, block: str) -> str:
    safe = "".join(ch if ch.isalnum() or ch in "._-" else "-" for ch in marker)
    start = f"<!-- ZAIMELLA:{safe}:START -->"
    end = f"<!-- ZAIMELLA:{safe}:END -->"
    new = f"{start}\n{block}\n{end}"
    if start in current and end in current:
        before = current[: current.index(start)]
        after = current[current.index(end) + len(end) :]
        return before.rstrip() + "\n\n" + new + "\n" + after.lstrip()
    if not current.strip():
        return new + "\n"
    return current.rstrip() + "\n\n" + new + "\n"


def prepare_desarrollo_apex_context(root: Path, project_path: Path, spec: dict) -> None:
    dirs = [
        "docs",
        "docs/tareas",
        "docs/tareas/_control",
        "docs/sql",
        "docs/deploy",
        "docs/pases-produccion",
        "docs/logs",
        "docs/manuales",
        "docs/manuales/img",
        "qa/tareas",
        "tmp",
    ]
    for rel in dirs:
        path = project_path / rel
        path.mkdir(parents=True, exist_ok=True)
        print(f"DIR_READY {path}")

    migrate_existing_project_files(project_path)

    bitacora = project_path / "docs" / "bitacora.md"
    if not bitacora.exists():
        bitacora.write_text(
            "# Bitacora Operativa\n\n"
            "| Fecha | Sesion | ID tarea | Alcance | Ambiente | Estado | Evidencia | Pendientes |\n"
            "|---|---|---|---|---|---|---|---|\n",
            encoding="utf-8",
        )
        print(f"BITACORA_CREATED {bitacora}")
    else:
        print(f"BITACORA_EXISTS {bitacora}")

    template_path = root / spec["context_template"]
    if not template_path.exists():
        raise SystemExit(f"No existe plantilla de desarrollo.md: {template_path}")
    task_template_path = root / spec["task_template"]
    if not task_template_path.exists():
        raise SystemExit(f"No existe plantilla de tarea: {task_template_path}")
    print(f"TASK_TEMPLATE_READY {task_template_path}")

    desarrollo = project_path / "desarrollo.md"
    if desarrollo.exists():
        print(f"DESARROLLO_EXISTS {desarrollo}")
    else:
        text = template_path.read_text(encoding="utf-8")
        text = text.replace("<PROJECT_PATH>", project_path.as_posix())
        text = text.replace("<CREATED_AT>", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        desarrollo.write_text(text.rstrip() + "\n", encoding="utf-8")
        print(f"DESARROLLO_CREATED {desarrollo}")

    complete_desarrollo_interactively(desarrollo, project_path)
    prepare_source_repo_from_desarrollo(desarrollo)


def prepare_movilmella_context(root: Path, project_path: Path, spec: dict) -> None:
    """Prepara el contexto operativo sin modificar el checkout Flutter declarado despues."""
    for rel in ("docs", "docs/tareas", "docs/evidencias", "docs/logs", "docs/pases-produccion", "tmp"):
        path = project_path / rel
        path.mkdir(parents=True, exist_ok=True)
        print(f"DIR_READY {path}")

    bitacora = project_path / "docs" / "bitacora.md"
    if not bitacora.exists():
        bitacora.write_text(
            "# Bitacora Operativa Movilmella\n\n"
            "| Fecha | Sesion | ID tarea | Alcance | Ambiente | Estado | Evidencia | Pendientes |\n"
            "|---|---|---|---|---|---|---|---|\n",
            encoding="utf-8",
        )
        print(f"BITACORA_CREATED {bitacora}")
    else:
        print(f"BITACORA_EXISTS {bitacora}")

    desarrollo = project_path / "desarrollo.md"
    if not desarrollo.exists():
        template_path = root / spec["context_template"]
        text = template_path.read_text(encoding="utf-8")
        text = text.replace("<PROJECT_PATH>", project_path.as_posix())
        text = text.replace("<CREATED_AT>", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        desarrollo.write_text(text.rstrip() + "\n", encoding="utf-8")
        print(f"DESARROLLO_CREATED {desarrollo}")
    else:
        print(f"DESARROLLO_EXISTS {desarrollo}")

    task_template = root / spec["task_template"]
    if not task_template.exists():
        raise SystemExit(f"No existe plantilla Movilmella de tarea: {task_template}")
    print(f"TASK_TEMPLATE_READY {task_template}")


def prepare_desarrollo_aws_context(root: Path, project_path: Path, spec: dict) -> None:
    """Prepara carpetas AWS sin alterar archivos existentes ni fuentes productivas."""
    for rel in (
        "docs",
        "docs/tareas",
        "docs/operacion",
        "docs/operacion/validaciones-fuente",
        "docs/arquitectura",
        "JOB",
        "glue_jobs/manifests",
        "glue_jobs/scripts",
        "glue_jobs/sql",
        "openspec/changes",
        "TMP",
    ):
        path = project_path / rel
        path.mkdir(parents=True, exist_ok=True)
        print(f"DIR_READY {path}")

    bitacora = project_path / "docs" / "bitacora.md"
    if not bitacora.exists():
        bitacora.write_text(
            "# Bitacora Operativa AWS ETL\n\n"
            "| Fecha | Tarea | Fuente oficial | Objeto AWS | Ambiente | Estado | Evidencia | Pendientes |\n"
            "|---|---|---|---|---|---|---|---|\n",
            encoding="utf-8",
        )
        print(f"BITACORA_CREATED {bitacora}")
    else:
        print(f"BITACORA_EXISTS {bitacora}")

    task_template = root / spec["task_template"]
    if not task_template.exists():
        raise SystemExit(f"No existe plantilla Desarrollo-AWS de tarea: {task_template}")
    print(f"TASK_TEMPLATE_READY {task_template}")

    contract = project_path / "desarrollo-aws.md"
    if contract.exists():
        print(f"DESARROLLO_AWS_EXISTS {contract}")
        return
    template = root / spec["context_template"]
    if not template.exists():
        raise SystemExit(f"No existe plantilla Desarrollo-AWS: {template}")
    text = template.read_text(encoding="utf-8")
    text = text.replace("<PROJECT_PATH>", project_path.as_posix())
    text = text.replace("<CREATED_AT>", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    contract.write_text(text.rstrip() + "\n", encoding="utf-8")
    print(f"DESARROLLO_AWS_CREATED {contract}")

def classify_gestion_project_file(path: Path) -> str | None:
    """Clasifica solo archivos raiz con destino documental inequivoco."""
    name = path.name.lower()
    suffix = path.suffix.lower()
    if name in {"agents.md", "readme.md", "desarrollo.md", "desarrollo-aws.md"}:
        return None
    if name.startswith(".") or name in {"package.json", "package-lock.json", "pyproject.toml"}:
        return None
    if suffix in {".docx", ".pdf", ".ppt", ".pptx"}:
        return "proyecto/00_insumos/ri" if "ri" in name else "proyecto/00_insumos/documentos"
    if suffix in {".xlsx", ".xls", ".csv", ".tsv"}:
        return "proyecto/00_insumos/hojas_calculo"
    if suffix in {".png", ".jpg", ".jpeg", ".webp", ".gif", ".svg"}:
        return "proyecto/00_insumos/imagenes"
    if suffix in {".mp3", ".wav", ".m4a", ".mp4", ".mov", ".avi", ".mkv"}:
        return "proyecto/00_insumos/audio_video"
    return None


def migrate_gestion_project_files(project_path: Path) -> None:
    """Organiza sin sobrescritura solo insumos raiz que no son ambiguos."""
    entries: list[str] = []
    for item in sorted(project_path.iterdir(), key=lambda candidate: candidate.name.lower()):
        if not item.is_file():
            continue
        target_rel = classify_gestion_project_file(item)
        if not target_rel:
            continue
        target_dir = project_path / target_rel
        target_dir.mkdir(parents=True, exist_ok=True)
        target = target_dir / item.name
        if target.exists():
            entries.append(f"- OMITIDO destino existe: `{item.name}` -> `{target_rel}/{item.name}`")
            print(f"PROJECT_MIGRATION_SKIPPED destino existe {item} -> {target}")
            continue
        shutil.move(str(item), str(target))
        entries.append(f"- MOVIDO: `{item.name}` -> `{target_rel}/{item.name}`")
        print(f"PROJECT_MIGRATION_MOVED {item} -> {target}")

    if not entries:
        print(f"PROJECT_MIGRATION_NOOP {project_path}")
        return
    log_path = project_path / "proyecto" / "06_seguimiento" / "migracion-arquitectura.md"
    timestamp = datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %z")
    with log_path.open("a", encoding="utf-8") as fh:
        fh.write(f"\n## {timestamp} - Gestion-Proyectos\n\n")
        fh.write("\n".join(entries))
        fh.write("\n")
    print(f"PROJECT_MIGRATION_LOG {log_path}")


def prepare_gestion_proyectos_context(root: Path, project_path: Path, spec: dict) -> None:
    """Prepara contratos de proyecto sin mover ni sobrescribir insumos heredados."""
    directories = (
        "dominios",
        "proyecto/00_insumos/documentos",
        "proyecto/00_insumos/ri",
        "proyecto/00_insumos/hojas_calculo",
        "proyecto/00_insumos/imagenes",
        "proyecto/00_insumos/audio_video",
        "proyecto/00_insumos/transcripciones",
        "proyecto/00_insumos/conversaciones",
        "proyecto/00_insumos/notas",
        "proyecto/01_levantamiento/evidencia",
        "proyecto/01_levantamiento/extracciones",
        "proyecto/01_levantamiento/procesos",
        "proyecto/01_levantamiento/analisis",
        "proyecto/02_ri/documentos",
        "proyecto/03_diseno_funcional/to_be",
        "proyecto/03_diseno_funcional/casos_uso",
        "proyecto/03_diseno_funcional/prototipos",
        "proyecto/03_diseno_funcional/propuesta",
        "proyecto/04_ad/documentos",
        "proyecto/05_planificacion/sprints",
        "proyecto/06_seguimiento/paquetes",
        "proyecto/06_seguimiento/handoffs",
        "proyecto/06_seguimiento/integracion",
        "proyecto/06_seguimiento/documentacion",
        "proyecto/06_seguimiento/_control",
        "proyecto/07_cierre/entregables",
    )
    for rel in directories:
        path = project_path / rel
        path.mkdir(parents=True, exist_ok=True)
        print(f"DIR_READY {path}")

    bitacora = project_path / "proyecto" / "bitacora.md"
    if not bitacora.exists():
        bitacora.write_text(
            "# Bitacora Del Proyecto\n\n"
            "| Fecha/hora | Etapa | Entregable/sprint/paquete | Cambio o decision | Evidencia | Siguiente paso |\n"
            "|---|---|---|---|---|---|\n",
            encoding="utf-8",
        )
        print(f"BITACORA_CREATED {bitacora}")
    else:
        print(f"BITACORA_EXISTS {bitacora}")

    for destination, source in spec["templates"].items():
        target = project_path / destination
        template = root / source
        if not template.is_file():
            raise SystemExit(f"No existe plantilla Gestion-Proyectos: {template}")
        if target.exists():
            print(f"PROJECT_CONTRACT_EXISTS {target}")
            continue
        text = template.read_text(encoding="utf-8")
        text = text.replace("<PROJECT_ROOT>", project_path.as_posix())
        text = text.replace("<CREATED_AT>", datetime.now().astimezone().isoformat(timespec="seconds"))
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text.rstrip() + "\n", encoding="utf-8")
        print(f"PROJECT_CONTRACT_CREATED {target}")

    migrate_gestion_project_files(project_path)


def unique_destination(path: Path) -> Path | None:
    if not path.exists():
        return path
    return None


def classify_project_file(path: Path) -> str | None:
    name = path.name.lower()
    suffix = path.suffix.lower()
    if name in {"agents.md", "desarrollo.md", "readme.md"}:
        return None
    if name.startswith(".") or name in {"package.json", "package-lock.json", "pyproject.toml"}:
        return None
    if suffix == ".sql":
        if any(token in name for token in ("deploy", "pase", "produccion", "prod")):
            return "docs/legacy-import"
        return "docs/sql"
    if name in {"informe_qa.md", "qa_report.md"} or ("informe" in name and "qa" in name):
        return "qa/legacy-import"
    if suffix in {".png", ".jpg", ".jpeg", ".webp"}:
        if "manual" in name:
            return "docs/manuales/img"
        return "qa/legacy-import"
    if suffix in {".trace", ".har"}:
        return "qa/legacy-import"
    if suffix == ".log":
        return "docs/legacy-import"
    if suffix in {".docx", ".pdf"}:
        if "manual" in name:
            return "docs/manuales"
        return "docs"
    if suffix == ".md":
        if "manual" in name:
            return "docs/manuales"
        if "bitacora" in name:
            return "docs"
        return "docs"
    return None


def migrate_existing_project_files(project_path: Path) -> None:
    entries: list[str] = []
    for item in sorted(project_path.iterdir(), key=lambda p: p.name.lower()):
        if not item.is_file():
            continue
        target_rel = classify_project_file(item)
        if not target_rel:
            continue
        target_dir = project_path / target_rel
        target_dir.mkdir(parents=True, exist_ok=True)
        target = unique_destination(target_dir / item.name)
        if not target:
            message = f"MIGRATION_SKIPPED destino existe {item} -> {target_dir / item.name}"
            print(message)
            entries.append(f"- SKIPPED destino existe: `{item.name}` -> `{target_rel}/{item.name}`")
            continue
        shutil.move(str(item), str(target))
        message = f"MIGRATION_MOVED {item} -> {target}"
        print(message)
        entries.append(f"- MOVED `{item.name}` -> `{target_rel}/{item.name}`")

    if not entries:
        print(f"MIGRATION_NOOP {project_path}")
        return

    log_path = project_path / "docs" / "logs" / "desarrollo-apex-migracion.md"
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with log_path.open("a", encoding="utf-8") as fh:
        fh.write(f"\n## {timestamp} - /Desarrollo-APEX\n\n")
        fh.write("\n".join(entries))
        fh.write("\n")
    print(f"MIGRATION_LOG {log_path}")


def read_desarrollo_field(text: str, label: str) -> str | None:
    pattern = rf"^- {re.escape(label)}:\s*(.+?)\s*$"
    match = re.search(pattern, text, flags=re.MULTILINE)
    return match.group(1).strip() if match else None


def field_is_incomplete(value: str | None) -> bool:
    if value is None:
        return True
    stripped = value.strip()
    return not stripped or "<" in stripped or ">" in stripped


def update_desarrollo_field(text: str, label: str, value: str) -> tuple[str, bool]:
    pattern = rf"(?m)^- {re.escape(label)}:\s*.*$"
    replacement = f"- {label}: {value}"
    if re.search(pattern, text):
        return re.sub(pattern, replacement, text, count=1), True
    return text, False


def prompt_required_field(label: str, question: str, current: str | None = None) -> str | None:
    suffix = f" [{current}]" if current and not field_is_incomplete(current) else ""
    answer = input(f"{question}{suffix}: ").strip()
    if answer:
        return answer
    if current and not field_is_incomplete(current):
        return current
    return None


def complete_desarrollo_interactively(desarrollo: Path, project_path: Path) -> None:
    text = desarrollo.read_text(encoding="utf-8")
    fields = [
        (
            "Responsable/desarrollador",
            "Responsable/desarrollador",
            None,
        ),
        (
            "Proyecto/contexto local",
            "Ruta local del proyecto/contexto",
            project_path.as_posix(),
        ),
        (
            "Repo fuente `zaimella-apex-oracle` local",
            "Ruta local del checkout zaimella-apex-oracle",
            "C:/ZAIMELLA",
        ),
        (
            "Aplicaciones APEX APP_ID",
            "APP_ID de la aplicacion o aplicaciones APEX",
            None,
        ),
        (
            "Codigos/prefijos funcionales",
            "Codigos/prefijos funcionales autorizados",
            None,
        ),
    ]

    missing = [
        (label, question, default)
        for label, question, default in fields
        if field_is_incomplete(read_desarrollo_field(text, label))
    ]
    if not missing:
        print(f"DESARROLLO_COMPLETE {desarrollo}")
        return

    if not sys.stdin.isatty():
        print(f"DESARROLLO_PENDING campos obligatorios incompletos -> {desarrollo}")
        return

    print("Completemos desarrollo.md. Deja vacio solo si quieres mantener el valor actual.")
    changed = False
    for label, question, default in missing:
        current = read_desarrollo_field(text, label)
        proposed = default if field_is_incomplete(current) else current
        value = prompt_required_field(label, question, proposed)
        if not value:
            print(f"DESARROLLO_PENDING campo sin completar: {label}")
            continue
        text, updated = update_desarrollo_field(text, label, value)
        changed = changed or updated

    if changed:
        desarrollo.write_text(text.rstrip() + "\n", encoding="utf-8")
        print(f"DESARROLLO_UPDATED {desarrollo}")
    else:
        print(f"DESARROLLO_PENDING sin cambios -> {desarrollo}")


def prepare_source_repo_from_desarrollo(desarrollo: Path) -> None:
    text = desarrollo.read_text(encoding="utf-8")
    if "<OBLIGATORIO_SIN_DEFAULT>" in text:
        print(f"SOURCE_REPO_PENDING desarrollo.md incompleto -> {desarrollo}")
        return

    repo_value = read_desarrollo_field(text, "Repo fuente `zaimella-apex-oracle` local")
    if not repo_value or "<" in repo_value or ">" in repo_value:
        print(f"SOURCE_REPO_PENDING ruta local no definida -> {desarrollo}")
        return

    repo_path = Path(repo_value).expanduser()
    official = "https://github.com/zaimella/zaimella-apex-oracle"
    if shutil.which("git") is None:
        print("SOURCE_REPO_BLOCKED git no disponible")
        return

    if repo_path.exists() and (repo_path / ".git").is_dir():
        try:
            origin = command_output(["git", "-C", str(repo_path), "remote", "get-url", "origin"])
        except subprocess.CalledProcessError:
            print(f"SOURCE_REPO_BLOCKED origin no legible -> {repo_path}")
            return
        if origin.rstrip("/") != official.rstrip("/"):
            print(f"SOURCE_REPO_BLOCKED origin distinto -> {repo_path} ({origin})")
            return
        status = command_output(["git", "-C", str(repo_path), "status", "--porcelain"])
        if status:
            print(f"SOURCE_REPO_DIRTY no se ejecuta pull para no perder cambios -> {repo_path}")
            print(status)
            return
        run(["git", "-C", str(repo_path), "pull", "--ff-only"])
        print(f"SOURCE_REPO_READY {repo_path}")
        return

    if repo_path.exists() and any(repo_path.iterdir()):
        print(f"SOURCE_REPO_BLOCKED ruta ocupada no git -> {repo_path}")
        return

    repo_path.parent.mkdir(parents=True, exist_ok=True)
    run(["git", "clone", official, str(repo_path)])
    print(f"SOURCE_REPO_CLONED {repo_path}")


def apply_command(root: Path, project_path: Path, command: str) -> None:
    spec = COMMANDS[command]
    if command == "Gestion-Proyectos":
        run([
            sys.executable,
            str(root / "scripts" / "update_gestion_proyectos_agents_md.py"),
            "--project-root",
            str(project_path),
            "--apply",
        ])
        prepare_gestion_proyectos_context(root, project_path, spec)
        return

    if command == "Desarrollo-APEX":
        # Un solo migrador es la fuente de verdad: evita que la instalacion
        # vuelva a introducir bloques separados de desarrollo, QA u orquestacion.
        run([
            sys.executable,
            str(root / "scripts" / "update_apex_agents_md.py"),
            "--project-root",
            str(project_path),
            "--apply",
        ])
        prepare_desarrollo_apex_context(root, project_path, spec)
        run([
            sys.executable,
            str(root / "scripts" / "update_apex_task_terminal_gate.py"),
            "--project-root",
            str(project_path),
            "--apply",
        ])
        return

    if command == "Movilmella":
        run([
            sys.executable,
            str(root / "scripts" / "update_movilmella_agents_md.py"),
            "--project-root",
            str(project_path),
            "--apply",
        ])
        prepare_movilmella_context(root, project_path, spec)
        return

    if command == "Desarrollo-AWS":
        run([
            sys.executable,
            str(root / "scripts" / "update_aws_agents_md.py"),
            "--project-root",
            str(project_path),
            "--apply",
        ])
        prepare_desarrollo_aws_context(root, project_path, spec)
        return

    raise ValueError(f"Comando sin aplicador definido: {command}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Instala skills, comandos y MCP de Zaimella.")
    parser.add_argument("--agents", nargs="+", choices=["codex", "antigravity", "both"])
    parser.add_argument("--project-path", default=None, help="Proyecto donde aplicar AGENTS.md.")
    parser.add_argument("--apply-command", choices=sorted(COMMANDS), default=None)
    parser.add_argument("--skip-repo-update", action="store_true")
    parser.add_argument("--no-tools", action="store_true", help="No validar ni instalar herramientas CLI como OpenSpec.")
    parser.add_argument("--no-mcp", action="store_true")
    parser.add_argument("--no-commands", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = repo_root()
    ensure_repo_updated(root, args.skip_repo_update)

    if not args.no_tools:
        prepare_cli_tools()

    selected = args.agents or ask_agents()
    if "both" in selected:
        selected = ["codex", "antigravity"]
    selected = list(dict.fromkeys(selected))

    targets = default_targets()
    for agent in selected:
        target = targets[agent]
        install_skills(root, target)
        if not args.no_commands:
            install_commands(root, target)
        if not args.no_mcp:
            install_mcp(root, target)

    if "codex" in selected and not args.no_commands:
        run([
            sys.executable,
            str(root / "scripts" / "install_global_codex_orchestrators.py"),
            "--apply",
        ])

    if args.apply_command:
        project_path = Path(args.project_path or Path.cwd()).resolve()
        if not project_path.exists():
            raise SystemExit(f"No existe el proyecto destino: {project_path}")
        apply_command(root, project_path, args.apply_command)

    print("ZAIMELLA_AGENT_SETUP_OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
