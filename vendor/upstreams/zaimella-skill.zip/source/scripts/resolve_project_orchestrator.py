#!/usr/bin/env python3
"""Resuelve de forma determinista el propietario de una capacidad de dominio."""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--capability-id", required=True)
    parser.add_argument(
        "--registry",
        default=Path(__file__).resolve().parents[1] / "commands" / "orchestrators.json",
    )
    args = parser.parse_args()
    registry = Path(args.registry).resolve()
    try:
        data = json.loads(registry.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"PROJECT_ORCHESTRATOR_REGISTRY_ERROR {exc}")
        return 2

    owners = [
        item
        for item in data.get("orchestrators", [])
        if item.get("level") == "domain"
        and args.capability_id in item.get("capabilities", [])
    ]
    if not owners:
        print(
            "PROJECT_ORCHESTRATOR_UNASSIGNED "
            f"capability={args.capability_id} owner=DOMINIO_SIN_ORQUESTADOR"
        )
        return 0
    if len(owners) > 1:
        names = ",".join(sorted(str(item.get("name")) for item in owners))
        print(
            "PROJECT_ORCHESTRATOR_CONFLICT "
            f"capability={args.capability_id} owners={names}"
        )
        return 2
    owner = owners[0]
    print(
        "PROJECT_ORCHESTRATOR_OWNER "
        f"capability={args.capability_id} owner={owner['name']}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
