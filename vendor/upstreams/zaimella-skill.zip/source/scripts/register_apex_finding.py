#!/usr/bin/env python3
"""Registra un hallazgo APEX reutilizable sin mezclarlo con un error reportado."""
from __future__ import annotations

import argparse
import re
from datetime import datetime
from pathlib import Path

FINDINGS_END = "<!-- ZAIMELLA:APEX:FINDINGS:END -->"


def resource_template() -> Path:
    return Path(__file__).resolve().parents[1] / "commands" / "resources" / "Desarrollo-APEX" / "hallazgos.template.md"


def main() -> int:
    parser = argparse.ArgumentParser(description="Agrega un hallazgo al registro operativo APEX.")
    parser.add_argument("--project-root", required=True)
    parser.add_argument("--title", required=True)
    parser.add_argument("--evidence", required=True)
    parser.add_argument("--type", required=True, choices=("Regla", "Contrato", "Herramienta", "Prompt", "Skill", "Orquestador", "QA"))
    parser.add_argument("--scope", required=True, choices=("Proyecto", "Skill", "Orquestador", "Herramienta", "QA"))
    parser.add_argument("--severity", default="Media", choices=("Baja", "Media", "Alta", "Critica"))
    parser.add_argument("--task-id", default="No aplica")
    parser.add_argument("--session", default="No aplica")
    parser.add_argument("--recommendation", default="Pendiente de analizar")
    args = parser.parse_args()

    project_root = Path(args.project_root).resolve()
    if not project_root.is_dir():
        print(f"APEX_FINDING_BLOCKED project-root inexistente: {project_root}")
        return 2
    path = project_root / "docs" / "tareas" / "_control" / "hallazgos.md"
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.write_text(resource_template().read_text(encoding="utf-8"), encoding="utf-8")
    text = path.read_text(encoding="utf-8")
    if text.count(FINDINGS_END) != 1:
        print("APEX_FINDING_BLOCKED marcador de hallazgos invalido")
        return 2
    today = datetime.now().astimezone().strftime("%Y%m%d")
    number = len(re.findall(r"(?m)^### H-", text)) + 1
    finding_id = f"H-{today}-{number:03d}"
    timestamp = datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %Z")
    entry = "\n".join([
        f"### {finding_id} - {args.title}",
        "",
        f"- Fecha/hora: {timestamp}",
        f"- Tipo: {args.type}",
        f"- Severidad: {args.severity}",
        f"- Tarea/Sesion: {args.task_id} / {args.session}",
        f"- Alcance sugerido: {args.scope}",
        f"- Evidencia: {args.evidence}",
        f"- Recomendacion: {args.recommendation}",
        "- Estado: Nuevo",
        "",
    ])
    path.write_text(text.replace(FINDINGS_END, entry + FINDINGS_END), encoding="utf-8")
    print(f"APEX_FINDING_REGISTERED id={finding_id} path={path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
