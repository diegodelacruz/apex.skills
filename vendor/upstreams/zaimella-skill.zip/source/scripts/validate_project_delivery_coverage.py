#!/usr/bin/env python3
"""Valida cobertura contractual antes de delegar, integrar, documentar o cerrar."""
from __future__ import annotations

import argparse
import re
from pathlib import Path


PLACEHOLDER_RE = re.compile(r"<[^>]+>")
FIELD_RE = re.compile(r"^- ([^:]+):\s*(.*)$")


def incomplete(value: str) -> bool:
    value = value.strip()
    return not value or bool(PLACEHOLDER_RE.search(value)) or value in {"Pendiente", "Por definir"}


def identifier_list(value: str) -> set[str]:
    return set(re.findall(r"[A-Za-z0-9][A-Za-z0-9_.-]*", value))


def fields(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        match = FIELD_RE.match(line.strip())
        if match:
            result[match.group(1).strip()] = match.group(2).strip()
    return result


def table_rows(path: Path) -> list[dict[str, str]]:
    lines = path.read_text(encoding="utf-8").splitlines()
    rows: list[dict[str, str]] = []
    for index, line in enumerate(lines):
        if not line.strip().startswith("|") or index + 1 >= len(lines):
            continue
        separator = lines[index + 1].strip()
        if not separator.startswith("|") or not re.fullmatch(r"[|:\- ]+", separator):
            continue
        headers = [cell.strip() for cell in line.strip().strip("|").split("|")]
        cursor = index + 2
        while cursor < len(lines) and lines[cursor].strip().startswith("|"):
            values = [cell.strip() for cell in lines[cursor].strip().strip("|").split("|")]
            if len(values) == len(headers):
                rows.append(dict(zip(headers, values)))
            cursor += 1
    return rows


def validate_project_contract(root: Path, errors: list[str]) -> str:
    path = root / "proyecto" / "proyecto.md"
    if not path.is_file():
        errors.append(f"Falta contrato de proyecto: {path}")
        return ""
    project = fields(path)
    for name in (
        "ID proyecto",
        "PROJECT_SLUG",
        "Nombre",
        "Estado",
        "Objetivo verificable",
        "Criterio global de exito",
    ):
        if incomplete(project.get(name, "")):
            errors.append(f"proyecto.md: campo incompleto {name}")
    return project.get("ID proyecto", "")


def validate_packages(
    root: Path, phase: str, project_id: str, errors: list[str]
) -> dict[str, str]:
    package_dir = root / "proyecto" / "06_seguimiento" / "paquetes"
    handoff_dir = root / "proyecto" / "06_seguimiento" / "handoffs"
    sprint_dir = root / "proyecto" / "05_planificacion" / "sprints"
    packages = sorted(package_dir.glob("*.md")) if package_dir.is_dir() else []
    if not packages:
        errors.append("No existen paquetes de trabajo")
        return {}
    package_links: dict[str, str] = {}
    required = (
        "ID proyecto",
        "ID entregable",
        "ID sprint",
        "ID paquete",
        "Capability ID",
        "Orquestador propietario",
        "Responsable ejecutor",
        "Objetivo verificable",
        "Criterios de aceptacion",
        "Alcance incluido",
        "Alcance excluido",
        "Dependencias",
        "Evidencia requerida",
        "Perfil documental requerido",
    )
    for package_path in packages:
        package = fields(package_path)
        package_id = package.get("ID paquete", package_path.stem)
        for name in required:
            if incomplete(package.get(name, "")):
                errors.append(f"{package_path.name}: campo incompleto {name}")
        if project_id and package.get("ID proyecto") != project_id:
            errors.append(f"{package_id}: ID proyecto no coincide con proyecto.md")
        deliverable_id = package.get("ID entregable", "")
        package_links[package_id] = deliverable_id
        sprint_id = package.get("ID sprint", "")
        sprint_path = sprint_dir / f"{sprint_id}.md"
        if not sprint_path.is_file():
            errors.append(f"{package_id}: falta contrato de sprint {sprint_path}")
        else:
            sprint = fields(sprint_path)
            for name in (
                "ID proyecto",
                "ID sprint",
                "Nombre",
                "Estado",
                "Entregables vinculados",
                "Resultado del sprint",
                "Criterios de termino",
            ):
                if incomplete(sprint.get(name, "")):
                    errors.append(f"{sprint_path.name}: campo incompleto {name}")
            if sprint.get("ID proyecto") != project_id or sprint.get("ID sprint") != sprint_id:
                errors.append(f"{package_id}: identidad de sprint inconsistente")
            if deliverable_id not in identifier_list(sprint.get("Entregables vinculados", "")):
                errors.append(f"{package_id}: entregable no vinculado en {sprint_path.name}")
            if package_id not in identifier_list(sprint_path.read_text(encoding="utf-8")):
                errors.append(f"{package_id}: paquete no listado en {sprint_path.name}")
        owner = package.get("Orquestador propietario", "")
        if phase == "dispatch":
            if owner == "DOMINIO_SIN_ORQUESTADOR" and package.get("Responsable ejecutor") in {
                "",
                "No aplica",
                None,
            }:
                errors.append(f"{package_id}: dominio sin orquestador ni responsable humano")
            state = package.get("Estado", "").split("|")[0].strip()
            if state not in {
                "Listo para delegar",
                "Delegado",
                "En ejecucion dominio",
                "En integracion",
                "Aceptado",
                "Cancelado autorizado",
            }:
                errors.append(f"{package_id}: estado no delegable {state!r}")
        if phase in {"integration", "documentation", "close"}:
            handoff_path = handoff_dir / f"{package_id}.md"
            if not handoff_path.is_file():
                errors.append(f"{package_id}: falta handoff {handoff_path}")
                continue
            handoff = fields(handoff_path)
            result = handoff.get("Resultado", "")
            if result not in {"APROBADO_DOMINIO", "CANCELADO_AUTORIZADO"}:
                errors.append(f"{package_id}: resultado no integrable {result!r}")
    return package_links


def validate_deliverable_links(
    root: Path, package_links: dict[str, str], errors: list[str]
) -> set[str]:
    path = root / "proyecto" / "05_planificacion" / "entregables.md"
    if not path.is_file():
        errors.append(f"Falta matriz de entregables: {path}")
        return set()
    rows = table_rows(path)
    if not rows:
        errors.append("La matriz de entregables no contiene filas")
        return set()
    by_id: dict[str, dict[str, str]] = {}
    for row in rows:
        deliverable_id = row.get("ID entregable", "")
        for name in (
            "ID entregable",
            "Resultado y criterio de aceptacion",
            "Responsable de aceptacion",
            "Sprints",
            "Paquetes",
            "Documentacion requerida",
            "Estado",
        ):
            if incomplete(row.get(name, "")):
                errors.append(f"{deliverable_id or 'Entregable sin ID'}: campo incompleto {name}")
        if deliverable_id in by_id:
            errors.append(f"ID entregable duplicado: {deliverable_id}")
        by_id[deliverable_id] = row
    for package_id, deliverable_id in package_links.items():
        row = by_id.get(deliverable_id)
        if row is None:
            errors.append(f"{package_id}: entregable {deliverable_id!r} no existe en la matriz")
        elif package_id not in identifier_list(row.get("Paquetes", "")):
            errors.append(f"{package_id}: no esta relacionado en la fila {deliverable_id}")
    return set(by_id)


def validate_documentation(
    root: Path, close: bool, deliverable_ids: set[str], errors: list[str]
) -> None:
    path = root / "proyecto" / "06_seguimiento" / "documentacion" / "plan.md"
    if not path.is_file():
        errors.append(f"Falta plan documental: {path}")
        return
    rows = table_rows(path)
    if not rows:
        errors.append("El plan documental no contiene documentos")
        return
    required = (
        "ID documento",
        "ID entregable",
        "Perfil",
        "Audiencia",
        "Proposito",
        "Secciones/cobertura",
        "Linea base",
        "Evidencia fuente",
        "Salida esperada",
        "Estado",
    )
    for row in rows:
        doc_id = row.get("ID documento", "Documento sin ID")
        for name in required:
            if incomplete(row.get(name, "")):
                errors.append(f"{doc_id}: campo documental incompleto {name}")
        if row.get("ID entregable") not in deliverable_ids:
            errors.append(f"{doc_id}: entregable documental inexistente")
        if row.get("Perfil") not in {"funcional", "tecnico", "mixto", "No aplica"}:
            errors.append(f"{doc_id}: perfil documental no permitido")
        if row.get("Perfil") == "No aplica" and row.get("Estado") != "No aplica justificado":
            errors.append(f"{doc_id}: perfil No aplica sin estado justificado")
        allowed = {"Listo para generar", "Completo", "No aplica justificado"}
        if close:
            allowed = {"Completo", "No aplica justificado"}
        if row.get("Estado") not in allowed:
            errors.append(f"{doc_id}: estado documental no valido para la fase")


def validate_close(root: Path, errors: list[str]) -> None:
    deliverables = root / "proyecto" / "05_planificacion" / "entregables.md"
    if not deliverables.is_file():
        errors.append(f"Falta matriz de entregables: {deliverables}")
    else:
        rows = table_rows(deliverables)
        if not rows:
            errors.append("La matriz de entregables no contiene filas")
        for row in rows:
            deliverable_id = row.get("ID entregable", "Entregable sin ID")
            if row.get("Estado") not in {"Aceptado", "Cancelado autorizado"}:
                errors.append(f"{deliverable_id}: entregable sin aceptacion final")
            if incomplete(row.get("Evidencia final", "")):
                errors.append(f"{deliverable_id}: falta evidencia final")
    index_path = root / "proyecto" / "07_cierre" / "indice-entregables.md"
    if not index_path.is_file() or PLACEHOLDER_RE.search(index_path.read_text(encoding="utf-8")):
        errors.append("Falta indice final completo de entregables")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", required=True)
    parser.add_argument(
        "--phase",
        required=True,
        choices=("dispatch", "integration", "documentation", "close"),
    )
    args = parser.parse_args()
    root = Path(args.project_root).resolve()
    errors: list[str] = []
    project_id = validate_project_contract(root, errors)
    package_links = validate_packages(root, args.phase, project_id, errors)
    deliverable_ids = validate_deliverable_links(root, package_links, errors)
    if args.phase in {"documentation", "close"}:
        validate_documentation(root, args.phase == "close", deliverable_ids, errors)
    if args.phase == "close":
        validate_close(root, errors)
    if errors:
        for error in errors:
            print(f"PROJECT_COVERAGE_ERROR {error}")
        print(f"PROJECT_COVERAGE_FAIL phase={args.phase}")
        return 2
    print(f"PROJECT_COVERAGE_PASS phase={args.phase}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
