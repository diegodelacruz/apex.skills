[CmdletBinding()]
param(
  [string]$RepoUrl = "https://github.com/jefersonKel/zaimella-skill.git",
  [string]$RepoPath = (Join-Path $env:USERPROFILE ".zaimella\zaimella-skill"),
  [ValidateSet("codex", "claude", "antigravity", "all")]
  [string[]]$Agents = @("codex"),
  [switch]$SkipRepoUpdate,
  [switch]$NoCommands
)

$ErrorActionPreference = "Stop"

function Get-RepoRoot {
  $localRoot = Split-Path -Parent $PSScriptRoot
  if ((Test-Path (Join-Path $localRoot "skill")) -and (Test-Path (Join-Path $localRoot "prompts"))) {
    if (-not $SkipRepoUpdate -and (Test-Path (Join-Path $localRoot ".git"))) {
      if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
        throw "Git no esta instalado. No se puede actualizar el repo local antes de instalar."
      }
      git -C $localRoot pull --ff-only | Out-Host
    }
    return (Resolve-Path $localRoot).Path
  }

  if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    throw "Git no esta instalado. Instale Git o ejecute este script desde un clon local del repo."
  }

  if (Test-Path $RepoPath) {
    if (-not (Test-Path (Join-Path $RepoPath ".git"))) {
      throw "RepoPath existe pero no es repo Git: $RepoPath"
    }
    if (-not $SkipRepoUpdate) {
      git -C $RepoPath pull --ff-only | Out-Host
    }
  } else {
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $RepoPath) | Out-Null
    git clone $RepoUrl $RepoPath | Out-Host
  }

  return (Resolve-Path $RepoPath).Path
}

function Get-AgentTargets([string[]]$SelectedAgents) {
  $expanded = @()
  foreach ($agent in $SelectedAgents) {
    if ($agent -eq "all") {
      $expanded += @("codex", "claude", "antigravity")
    } else {
      $expanded += $agent
    }
  }
  $expanded = $expanded | Select-Object -Unique

  $codexHome = if ($env:CODEX_HOME) { $env:CODEX_HOME } else { Join-Path $env:USERPROFILE ".codex" }

  $targets = @()
  foreach ($agent in $expanded) {
    switch ($agent) {
      "codex" {
        $targets += [pscustomobject]@{
          Agent = "codex"
          Skills = Join-Path $codexHome "skills"
          Commands = Join-Path $codexHome "prompts"
        }
      }
      "claude" {
        $targets += [pscustomobject]@{
          Agent = "claude"
          Skills = Join-Path $env:USERPROFILE ".claude\skills"
          Commands = Join-Path $env:USERPROFILE ".claude\commands"
        }
      }
      "antigravity" {
        $targets += [pscustomobject]@{
          Agent = "antigravity"
          Skills = Join-Path $env:USERPROFILE ".gemini\antigravity\skills"
          Commands = Join-Path $env:USERPROFILE ".gemini\antigravity\commands"
        }
      }
    }
  }
  return $targets
}

function Copy-CleanDirectory([string]$Source, [string]$Destination) {
  if (-not (Test-Path $Source)) {
    throw "Fuente no existe: $Source"
  }
  $parent = Split-Path -Parent $Destination
  New-Item -ItemType Directory -Force -Path $parent | Out-Null
  if (Test-Path $Destination) {
    Remove-Item -LiteralPath $Destination -Recurse -Force
  }
  Copy-Item -LiteralPath $Source -Destination $Destination -Recurse -Force
}

$repoRoot = Get-RepoRoot
$skillRoot = Join-Path $repoRoot "skill"
$commandRoot = Join-Path $repoRoot "commands"

if (-not (Test-Path $skillRoot)) {
  throw "No existe la carpeta skill/ en $repoRoot"
}

$targets = Get-AgentTargets $Agents
$skills = Get-ChildItem -Path $skillRoot -Directory

foreach ($target in $targets) {
  New-Item -ItemType Directory -Force -Path $target.Skills | Out-Null
  foreach ($skill in $skills) {
    Copy-CleanDirectory -Source $skill.FullName -Destination (Join-Path $target.Skills $skill.Name)
    Write-Output "SKILL_INSTALLED`t$($target.Agent)`t$($skill.Name)`t$($target.Skills)"
  }

  if (-not $NoCommands -and (Test-Path $commandRoot)) {
    New-Item -ItemType Directory -Force -Path $target.Commands | Out-Null
    foreach ($legacyName in @("DESARROLLADOR-APEX.md")) {
      $legacyPath = Join-Path $target.Commands $legacyName
      if (Test-Path -LiteralPath $legacyPath) {
        Remove-Item -LiteralPath $legacyPath -Force
        Write-Output "COMMAND_REMOVED`t$($target.Agent)`t$($legacyName)`t$($target.Commands)"
      }
    }
    Get-ChildItem -Path $commandRoot -Filter "*.md" -File | ForEach-Object {
      Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $target.Commands $_.Name) -Force
      Write-Output "COMMAND_INSTALLED`t$($target.Agent)`t$($_.BaseName)`t$($target.Commands)"
    }
  }
}

Write-Output "ZAIMELLA_AGENT_ECOSYSTEM_OK`t$repoRoot"
