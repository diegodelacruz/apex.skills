[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)]
  [ValidateSet("Desarrollo-APEX", "QA-APEX", "AWS-ETL", "MOVILMELLA", "METODOLOGIA")]
  [string]$Command,

  [string]$ProjectPath = (Get-Location).Path,
  [switch]$InstallFirst,
  [ValidateSet("codex", "claude", "antigravity", "all")]
  [string[]]$Agents = @("codex"),
  [switch]$DryRun
)

$ErrorActionPreference = "Stop"

function Get-RepoRoot {
  $root = Split-Path -Parent $PSScriptRoot
  if ((Test-Path (Join-Path $root "skill")) -and (Test-Path (Join-Path $root "prompts"))) {
    return (Resolve-Path $root).Path
  }
  throw "Este comando debe ejecutarse desde el repo zaimella-skill o desde un clon actualizado."
}

function Get-CommandSpec([string]$CommandName) {
  switch ($CommandName) {
    "Desarrollo-APEX" {
      return @{
        Skills = @("desarrollador-apex", "qa-apex")
        UsagePrompts = @(
          "skill/desarrollador-apex/references/prompts/uso-en-agents.md",
          "skill/qa-apex/references/prompts/uso-en-agents.md"
        )
        PreparationPrompts = @(
          "skill/desarrollador-apex/references/prompts/preparacion-ambiente.md",
          "skill/qa-apex/references/prompts/preparacion-ambiente.md"
        )
      }
    }
    "QA-APEX" {
      return @{
        Skills = @("qa-apex")
        UsagePrompts = @("skill/qa-apex/references/prompts/uso-en-agents.md")
        PreparationPrompts = @("skill/qa-apex/references/prompts/preparacion-ambiente.md")
      }
    }
    "AWS-ETL" {
      return @{
        Skills = @("aws-etl-experto")
        UsagePrompts = @("skill/aws-etl-experto/references/prompts/uso-en-agents.md")
        PreparationPrompts = @("skill/aws-etl-experto/references/prompts/preparacion-ambiente.md")
      }
    }
    "MOVILMELLA" {
      return @{
        Skills = @("desarrollador-movilmella")
        UsagePrompts = @("skill/desarrollador-movilmella/references/prompts/uso-en-agents.md")
        PreparationPrompts = @("skill/desarrollador-movilmella/references/prompts/preparacion-ambiente.md")
      }
    }
    "METODOLOGIA" {
      return @{
        Skills = @("metodologia-proyectos")
        UsagePrompts = @("skill/metodologia-proyectos/references/prompts/uso-en-agents.md")
        PreparationPrompts = @("skill/metodologia-proyectos/references/prompts/preparacion-ambiente.md")
      }
    }
  }
}

function Get-AgentsMdBlock([string]$PromptPath) {
  $text = Get-Content -Raw -Path $PromptPath
  $pattern = '(?s)## Seccion 1 - Contenido Para AGENTS\.md.*?```markdown\s*(.*?)\s*```'
  $match = [regex]::Match($text, $pattern)
  if (-not $match.Success) {
    throw "No se pudo extraer la seccion AGENTS.md de $PromptPath"
  }
  return $match.Groups[1].Value.Trim()
}

function Set-MarkedBlock([string]$Current, [string]$Marker, [string]$Block) {
  $safeMarker = $Marker -replace '[^A-Za-z0-9_.-]', '-'
  $start = "<!-- ZAIMELLA:${safeMarker}:START -->"
  $end = "<!-- ZAIMELLA:${safeMarker}:END -->"
  $newBlock = "$start`r`n$Block`r`n$end"

  $escapedStart = [regex]::Escape($start)
  $escapedEnd = [regex]::Escape($end)
  $pattern = "(?s)$escapedStart.*?$escapedEnd"

  if ([regex]::IsMatch($Current, $pattern)) {
    return [regex]::Replace($Current, $pattern, [System.Text.RegularExpressions.MatchEvaluator]{ param($m) $newBlock })
  }

  if ([string]::IsNullOrWhiteSpace($Current)) {
    return "$newBlock`r`n"
  }

  return $Current.TrimEnd() + "`r`n`r`n" + $newBlock + "`r`n"
}

function Initialize-DesarrolloApexContext([string]$RepoRoot, [string]$ProjectRoot, [switch]$DryRun) {
  $dirs = @(
    "docs",
    "docs/tareas",
    "docs/tareas/_control",
    "docs/sql",
    "docs/deploy",
    "docs/pases-produccion",
    "docs/logs",
    "docs/manuales",
    "docs/manuales/img",
    "qa/tareas",
    "tmp"
  )

  foreach ($rel in $dirs) {
    $path = Join-Path $ProjectRoot $rel
    if ($DryRun) {
      Write-Output "DRY_RUN_DIR_READY`t$path"
    } else {
      New-Item -ItemType Directory -Force -Path $path | Out-Null
      Write-Output "DIR_READY`t$path"
    }
  }

  Move-ExistingApexProjectFiles -ProjectRoot $ProjectRoot -DryRun:$DryRun

  $bitacora = Join-Path $ProjectRoot "docs/bitacora.md"
  if (Test-Path -LiteralPath $bitacora) {
    Write-Output "BITACORA_EXISTS`t$bitacora"
  } elseif ($DryRun) {
    Write-Output "DRY_RUN_BITACORA_CREATE`t$bitacora"
  } else {
    $bitacoraContent = @"
# Bitacora Operativa

| Fecha | Sesion | ID tarea | Alcance | Ambiente | Estado | Evidencia | Pendientes |
|---|---|---|---|---|---|---|---|
"@
    Set-Content -LiteralPath $bitacora -Value $bitacoraContent -Encoding UTF8
    Write-Output "BITACORA_CREATED`t$bitacora"
  }

  $templatePath = Join-Path $RepoRoot "commands/resources/Desarrollo-APEX/desarrollo.template.md"
  if (-not (Test-Path -LiteralPath $templatePath)) {
    throw "No existe plantilla de desarrollo.md: $templatePath"
  }
  $taskTemplatePath = Join-Path $RepoRoot "commands/resources/Desarrollo-APEX/tarea.template.md"
  if (-not (Test-Path -LiteralPath $taskTemplatePath)) {
    throw "No existe plantilla de tarea: $taskTemplatePath"
  }
  Write-Output "TASK_TEMPLATE_READY`t$taskTemplatePath"
  $navigationTemplatePath = Join-Path $RepoRoot "commands/resources/Desarrollo-APEX/navegacion.template.md"
  if (-not (Test-Path -LiteralPath $navigationTemplatePath)) {
    throw "No existe plantilla de navegacion QA: $navigationTemplatePath"
  }
  Write-Output "NAVIGATION_TEMPLATE_READY`t$navigationTemplatePath"

  $desarrollo = Join-Path $ProjectRoot "desarrollo.md"
  if (Test-Path -LiteralPath $desarrollo) {
    Write-Output "DESARROLLO_EXISTS`t$desarrollo"
  } elseif ($DryRun) {
    Write-Output "DRY_RUN_DESARROLLO_CREATE`t$desarrollo"
  } else {
    $content = Get-Content -Raw -LiteralPath $templatePath
    $content = $content.Replace("<PROJECT_PATH>", ($ProjectRoot -replace "\\", "/"))
    $content = $content.Replace("<CREATED_AT>", (Get-Date -Format "yyyy-MM-dd HH:mm:ss"))
    Set-Content -LiteralPath $desarrollo -Value $content.TrimEnd() -Encoding UTF8
    Write-Output "DESARROLLO_CREATED`t$desarrollo"
  }

  Initialize-ZaimellaApexSourceRepo -DesarrolloPath $desarrollo -DryRun:$DryRun
}

function Get-ApexProjectTargetRel([System.IO.FileInfo]$File) {
  $name = $File.Name.ToLowerInvariant()
  $suffix = $File.Extension.ToLowerInvariant()
  if ($name -in @("agents.md", "desarrollo.md", "readme.md")) {
    return $null
  }
  if ($name.StartsWith(".") -or $name -in @("package.json", "package-lock.json", "pyproject.toml")) {
    return $null
  }
  if ($suffix -eq ".sql") {
    if ($name -match "deploy|pase|produccion|prod") {
      return "docs/legacy-import"
    }
    return "docs/sql"
  }
  if ($name -in @("informe_qa.md", "qa_report.md") -or ($name.Contains("informe") -and $name.Contains("qa"))) {
    return "qa/legacy-import"
  }
  if ($suffix -in @(".png", ".jpg", ".jpeg", ".webp")) {
    if ($name.Contains("manual")) {
      return "docs/manuales/img"
    }
    return "qa/legacy-import"
  }
  if ($suffix -in @(".trace", ".har")) {
    return "qa/legacy-import"
  }
  if ($suffix -eq ".log") {
    return "docs/legacy-import"
  }
  if ($suffix -in @(".docx", ".pdf")) {
    if ($name.Contains("manual")) {
      return "docs/manuales"
    }
    return "docs"
  }
  if ($suffix -eq ".md") {
    if ($name.Contains("manual")) {
      return "docs/manuales"
    }
    return "docs"
  }
  return $null
}

function Move-ExistingApexProjectFiles([string]$ProjectRoot, [switch]$DryRun) {
  $entries = @()
  Get-ChildItem -LiteralPath $ProjectRoot -File -Force | Sort-Object Name | ForEach-Object {
    $targetRel = Get-ApexProjectTargetRel $_
    if (-not $targetRel) {
      return
    }
    $targetDir = Join-Path $ProjectRoot $targetRel
    $target = Join-Path $targetDir $_.Name
    if (Test-Path -LiteralPath $target) {
      Write-Output ("MIGRATION_SKIPPED`tDestino existe`t{0}`t{1}" -f $_.FullName, $target)
      $entries += ("- SKIPPED destino existe: {0} -> {1}/{0}" -f $_.Name, $targetRel)
      return
    }
    if ($DryRun) {
      Write-Output ("DRY_RUN_MIGRATION_MOVE`t{0}`t{1}" -f $_.FullName, $target)
      $entries += ("- DRY_RUN {0} -> {1}/{0}" -f $_.Name, $targetRel)
      return
    }
    New-Item -ItemType Directory -Force -Path $targetDir | Out-Null
    Move-Item -LiteralPath $_.FullName -Destination $target
    Write-Output ("MIGRATION_MOVED`t{0}`t{1}" -f $_.FullName, $target)
    $entries += ("- MOVED {0} -> {1}/{0}" -f $_.Name, $targetRel)
  }

  if ($entries.Count -eq 0) {
    Write-Output ("MIGRATION_NOOP`t{0}" -f $ProjectRoot)
    return
  }

  if ($DryRun) {
    Write-Output ("DRY_RUN_MIGRATION_LOG`t{0}" -f (Join-Path $ProjectRoot "docs/logs/desarrollo-apex-migracion.md"))
    return
  }

  $logPath = Join-Path $ProjectRoot "docs/logs/desarrollo-apex-migracion.md"
  $stamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
  $block = "`r`n## $stamp - /Desarrollo-APEX`r`n`r`n" + ($entries -join "`r`n") + "`r`n"
  Add-Content -LiteralPath $logPath -Value $block -Encoding UTF8
  Write-Output ("MIGRATION_LOG`t{0}" -f $logPath)
}

function Get-DesarrolloField([string]$Text, [string]$Label) {
  $pattern = "(?m)^- " + [regex]::Escape($Label) + ":\s*(.+?)\s*$"
  $match = [regex]::Match($Text, $pattern)
  if ($match.Success) {
    return $match.Groups[1].Value.Trim()
  }
  return $null
}

function Initialize-ZaimellaApexSourceRepo([string]$DesarrolloPath, [switch]$DryRun) {
  if (-not (Test-Path -LiteralPath $DesarrolloPath)) {
    Write-Output "SOURCE_REPO_PENDING`tdesarrollo.md no existe`t$DesarrolloPath"
    return
  }

  $text = Get-Content -Raw -LiteralPath $DesarrolloPath
  if ($text.Contains("<OBLIGATORIO_SIN_DEFAULT>")) {
    Write-Output "SOURCE_REPO_PENDING`tdesarrollo.md incompleto`t$DesarrolloPath"
    return
  }

  $repoValue = Get-DesarrolloField -Text $text -Label 'Repo fuente `zaimella-apex-oracle` local'
  if ([string]::IsNullOrWhiteSpace($repoValue) -or $repoValue.Contains("<") -or $repoValue.Contains(">")) {
    Write-Output "SOURCE_REPO_PENDING`truta local no definida`t$DesarrolloPath"
    return
  }

  $official = "https://github.com/zaimella/zaimella-apex-oracle"
  if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    Write-Output "SOURCE_REPO_BLOCKED`tgit no disponible"
    return
  }

  $repoPath = $repoValue
  if ((Test-Path -LiteralPath $repoPath) -and (Test-Path -LiteralPath (Join-Path $repoPath ".git"))) {
    $origin = (git -C $repoPath remote get-url origin).Trim()
    if ($origin.TrimEnd("/") -ne $official.TrimEnd("/")) {
      Write-Output "SOURCE_REPO_BLOCKED`torigin distinto`t$repoPath`t$origin"
      return
    }
    $status = git -C $repoPath status --porcelain
    if ($status) {
      Write-Output "SOURCE_REPO_DIRTY`tno se ejecuta pull para no perder cambios`t$repoPath"
      $status | Out-Host
      return
    }
    git -C $repoPath pull --ff-only | Out-Host
    Write-Output "SOURCE_REPO_READY`t$repoPath"
    return
  }

  if (Test-Path -LiteralPath $repoPath) {
    $children = @(Get-ChildItem -LiteralPath $repoPath -Force -ErrorAction SilentlyContinue)
    if ($children.Count -gt 0) {
      Write-Output "SOURCE_REPO_BLOCKED`truta ocupada no git`t$repoPath"
      return
    }
  }

  if ($DryRun) {
    Write-Output "DRY_RUN_SOURCE_REPO_CLONE`t$repoPath"
    return
  }

  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $repoPath) | Out-Null
  git clone $official $repoPath | Out-Host
  Write-Output "SOURCE_REPO_CLONED`t$repoPath"
}

$repoRoot = Get-RepoRoot
$projectRoot = (Resolve-Path $ProjectPath).Path
$agentsPath = Join-Path $projectRoot "AGENTS.md"
$spec = Get-CommandSpec $Command

if ($InstallFirst) {
  & (Join-Path $repoRoot "scripts/Install-ZaimellaAgentEcosystem.ps1") -Agents $Agents -NoCommands
}

if ($Command -eq "Desarrollo-APEX") {
  # El migrador Python es la única fuente de verdad para este comando. No se
  # fusionan prompts independientes porque recrearían bloques duplicados.
  $migrationMode = if ($DryRun) { "--dry-run" } else { "--apply" }
  & python (Join-Path $repoRoot "scripts/update_apex_agents_md.py") --project-root $projectRoot $migrationMode
  if ($LASTEXITCODE -ne 0) {
    throw "No se pudo migrar AGENTS.md con Desarrollo-APEX."
  }
  Initialize-DesarrolloApexContext -RepoRoot $repoRoot -ProjectRoot $projectRoot -DryRun:$DryRun
  return
}

$content = if (Test-Path $agentsPath) { Get-Content -Raw -Path $agentsPath } else { "" }
foreach ($promptRel in $spec.UsagePrompts) {
  $promptPath = Join-Path $repoRoot $promptRel
  $block = Get-AgentsMdBlock $promptPath
  $marker = "COMMAND:{0}:PROMPT:{1}" -f $Command, $promptRel
  $content = Set-MarkedBlock -Current $content -Marker $marker -Block $block
}

if ($DryRun) {
  Write-Output $content
  Write-Output "DRY_RUN_OK`t$agentsPath"
} else {
  Set-Content -Path $agentsPath -Value $content -Encoding UTF8
  Write-Output "AGENTS_UPDATED`t$agentsPath"
}
