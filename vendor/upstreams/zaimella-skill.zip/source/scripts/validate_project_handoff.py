#!/usr/bin/env python3
"""Valida identidad y cobertura entre un paquete de proyecto y su handoff."""
from __future__ import annotations

import argparse
import re
from pathlib import Path


FIELD_RE = re.compile(r"^- ([^:]+):\s*(.*)$")
PLACEHOLDER_RE = re.compile(r"<[^>]+>")
IDENTITY_FIELDS = (
    "ID proyecto",
    "ID entregable",
    "ID sprint",
    "ID paquete",
    "Capability ID",
    "Orquestador propietario",
    "Responsable ejecutor",
)
APPROVED_FIELDS = (
    "Tarea interna del dominio",
    "Componentes y versiones/SHA",
    "Ambientes validados",
    "Resultado QA del dominio",
    "Evidencia",
    "Criterios cumplidos",
    "Cambios visibles o impacto operativo",
    "Impacto documental",
    "Hechos y evidencia para documentacion",
    "Riesgo residual",
    "Pendientes",
)
RESULTS = {
    "APROBADO_DOMINIO",
    "EN_CORRECCION_DOMINIO",
    "IMPEDIMENTO_EXTERNO",
    "DECISION_MATERIAL_REQUERIDA",
    "CANCELADO_AUTORIZADO",
}


def fields(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        match = FIELD_RE.match(line.strip())
        if match:
            result[match.group(1).strip()] = match.group(2).strip()
    return result


def incomplete(value: str | None) -> bool:
    if not value:
        return True
    return bool(PLACEHOLDER_RE.search(value)) or value in {"Pendiente", "Por definir"}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package", required=True)
    parser.add_argument("--handoff", required=True)
    args = parser.parse_args()

    package_path = Path(args.package).resolve()
    handoff_path = Path(args.handoff).resolve()
    errors: list[str] = []
    for path in (package_path, handoff_path):
        if not path.is_file():
            errors.append(f"No existe: {path}")
    if errors:
        for error in errors:
            print(f"PROJECT_HANDOFF_ERROR {error}")
        print("PROJECT_HANDOFF_FAIL")
        return 2

    package = fields(package_path)
    handoff = fields(handoff_path)
    for name in IDENTITY_FIELDS:
        left = package.get(name)
        right = handoff.get(name)
        if incomplete(left) or incomplete(right):
            errors.append(f"Identidad incompleta: {name}")
        elif left != right:
            errors.append(f"Identidad distinta en {name}: paquete={left!r}, handoff={right!r}")

    result = handoff.get("Resultado", "")
    if result not in RESULTS:
        errors.append(f"Resultado no permitido: {result!r}")
    if result == "APROBADO_DOMINIO":
        for name in APPROVED_FIELDS:
            if incomplete(handoff.get(name)):
                errors.append(f"Handoff aprobado sin campo completo: {name}")
        if handoff.get("Produccion", "") not in {
            "No autorizada",
            "No aplica",
            "Pendiente",
            "Ejecutada",
            "Fallida",
        }:
            errors.append("Estado de Produccion no permitido")
    elif result == "DECISION_MATERIAL_REQUERIDA" and incomplete(
        handoff.get("Decision material solicitada")
    ):
        errors.append("Falta la pregunta material no inferible")
    elif result == "IMPEDIMENTO_EXTERNO" and incomplete(handoff.get("Pendientes")):
        errors.append("Falta describir el impedimento externo")

    if errors:
        for error in errors:
            print(f"PROJECT_HANDOFF_ERROR {error}")
        print("PROJECT_HANDOFF_FAIL")
        return 2
    print(f"PROJECT_HANDOFF_PASS package={package['ID paquete']} result={result}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
