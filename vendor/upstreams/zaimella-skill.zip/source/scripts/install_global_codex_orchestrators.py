#!/usr/bin/env python3
"""Sincroniza el runtime y los bloques globales de los orquestadores de Codex."""
from __future__ import annotations

import argparse
import difflib
import json
import os
from pathlib import Path
import shutil
import sys

def orchestrators(source: Path) -> list[dict[str, str]]:
    path = source / "commands" / "orchestrators.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    items = data.get("orchestrators")
    if not isinstance(items, list) or not items:
        raise ValueError("commands/orchestrators.json no contiene orquestadores.")
    for item in items:
        if not isinstance(item, dict) or not isinstance(item.get("name"), str) or not isinstance(item.get("global_template"), str):
            raise ValueError("Registro de orquestador invalido.")
    return items


def template(source: Path, runtime: Path, item: dict[str, str]) -> str:
    path = source / item["global_template"]
    return path.read_text(encoding="utf-8").replace("<ECOSYSTEM_ROOT>", runtime.as_posix()).strip()


def sync_runtime(source: Path, runtime: Path) -> None:
    stage = runtime.with_name(runtime.name + ".stage")
    backup = runtime.with_name(runtime.name + ".backup")
    for path in (stage, backup):
        if path.exists():
            shutil.rmtree(path)
    stage.mkdir(parents=True)
    for name in ("commands", "prompts", "scripts", "skill", "mcp"):
        origin = source / name
        if origin.is_dir():
            shutil.copytree(origin, stage / name, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    if runtime.exists():
        runtime.replace(backup)
    try:
        stage.replace(runtime)
        if backup.exists():
            shutil.rmtree(backup)
    except Exception:
        if runtime.exists():
            shutil.rmtree(runtime)
        if backup.exists():
            backup.replace(runtime)
        raise


def markers(block: str) -> tuple[str, str]:
    start = next((line for line in block.splitlines() if line.startswith("<!-- ZAIMELLA:") and line.endswith(":START -->")), None)
    if not start:
        raise ValueError("La plantilla global no contiene marcador START.")
    return start, start.replace(":START -->", ":END -->")


def merge(current: str, block: str) -> str:
    start, end = markers(block)
    starts, ends = current.count(start), current.count(end)
    if starts != ends or starts > 1:
        raise ValueError(f"Marcadores globales invalidos para {start}: START={starts}, END={ends}.")
    if not starts:
        return block + "\n" if not current.strip() else current.rstrip() + "\n\n" + block + "\n"
    begin, finish = current.index(start), current.index(end) + len(end)
    before, after = current[:begin].rstrip(), current[finish:].lstrip()
    return (before + "\n\n" if before else "") + block + ("\n\n" + after if after else "\n")


def apex_stop_handler(runtime: Path) -> dict[str, object]:
    script = runtime / "scripts" / "apex_stop_guard.py"
    python = Path(sys.executable)
    return {
        "type": "command",
        "command": f'"{python.as_posix()}" "{script.as_posix()}"',
        "commandWindows": f'"{python}" "{script}"',
        "timeout": 30,
        "statusMessage": "Verificando continuidad APEX",
    }


def merge_apex_stop_hook(current: str, runtime: Path) -> str:
    data = json.loads(current) if current.strip() else {}
    if not isinstance(data, dict):
        raise ValueError("hooks.json debe contener un objeto JSON.")
    hooks = data.setdefault("hooks", {})
    if not isinstance(hooks, dict):
        raise ValueError("hooks.json: 'hooks' debe ser un objeto.")
    groups = hooks.setdefault("Stop", [])
    if not isinstance(groups, list):
        raise ValueError("hooks.json: 'hooks.Stop' debe ser una lista.")

    retained: list[object] = []
    for group in groups:
        if not isinstance(group, dict):
            retained.append(group)
            continue
        handlers = group.get("hooks")
        if not isinstance(handlers, list):
            retained.append(group)
            continue
        filtered = [
            item
            for item in handlers
            if not (
                isinstance(item, dict)
                and "apex_stop_guard.py" in (
                    str(item.get("command", "")) + str(item.get("commandWindows", ""))
                )
            )
        ]
        if filtered:
            copy = dict(group)
            copy["hooks"] = filtered
            retained.append(copy)
    retained.append({"hooks": [apex_stop_handler(runtime)]})
    hooks["Stop"] = retained
    return json.dumps(data, ensure_ascii=False, indent=2) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--ecosystem-root", default=Path(__file__).resolve().parents[1])
    parser.add_argument("--codex-home", default=os.environ.get("CODEX_HOME") or Path.home() / ".codex")
    parser.add_argument("--runtime-root", default=None)
    parser.add_argument("--orchestrator", action="append", help="Nombre del orquestador; por defecto todos.")
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check", action="store_true")
    mode.add_argument("--dry-run", action="store_true")
    mode.add_argument("--apply", action="store_true")
    args = parser.parse_args()

    root = Path(args.ecosystem_root).resolve()
    codex_home = Path(args.codex_home).resolve()
    runtime = Path(args.runtime_root).resolve() if args.runtime_root else codex_home / "zaimella-agent-ecosystem"
    path = codex_home / "AGENTS.md"
    hooks_path = codex_home / "hooks.json"
    current = path.read_text(encoding="utf-8") if path.exists() else ""
    current_hooks = hooks_path.read_text(encoding="utf-8") if hooks_path.exists() else ""
    try:
        selected = orchestrators(root)
        if args.orchestrator:
            requested = set(args.orchestrator)
            selected = [item for item in selected if item["name"] in requested]
            missing = requested - {item["name"] for item in selected}
            if missing:
                raise ValueError("Orquestador no registrado: " + ", ".join(sorted(missing)))
        updated = current
        for item in selected:
            updated = merge(updated, template(root, runtime, item))
        if any(item["name"] == "Desarrollo-APEX" for item in selected):
            updated_hooks = merge_apex_stop_hook(current_hooks, runtime)
        else:
            updated_hooks = current_hooks
    except ValueError as exc:
        print(f"GLOBAL_AGENTS_BLOCKED {exc}")
        return 2
    changed = current != updated
    hooks_changed = current_hooks != updated_hooks
    print(f"GLOBAL_AGENTS_PATH {path}")
    print(f"RUNTIME_PATH {runtime}")
    print(f"RUNTIME_READY {str(runtime.is_dir()).lower()}")
    print("ORCHESTRATORS " + ",".join(item["name"] for item in selected))
    print(f"CHANGE_REQUIRED {str(changed).lower()}")
    print(f"GLOBAL_HOOKS_PATH {hooks_path}")
    print(f"HOOK_CHANGE_REQUIRED {str(hooks_changed).lower()}")
    if any(item["name"] == "Desarrollo-APEX" for item in selected):
        print("HOOK_REVIEW_REQUIRED Abrir /hooks y confiar el Stop hook de Desarrollo-APEX.")
    if args.check:
        return 0
    if args.dry_run:
        print("".join(difflib.unified_diff(current.splitlines(True), updated.splitlines(True), fromfile=str(path), tofile=str(path))), end="")
        print("".join(difflib.unified_diff(current_hooks.splitlines(True), updated_hooks.splitlines(True), fromfile=str(hooks_path), tofile=str(hooks_path))), end="")
        return 0
    sync_runtime(root, runtime)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".md.zaimella-tmp")
    temporary.write_text(updated, encoding="utf-8")
    temporary.replace(path)
    hooks_path.parent.mkdir(parents=True, exist_ok=True)
    hooks_temporary = hooks_path.with_suffix(".json.zaimella-tmp")
    hooks_temporary.write_text(updated_hooks, encoding="utf-8")
    hooks_temporary.replace(hooks_path)
    print("GLOBAL_AGENTS_UPDATED")
    print("GLOBAL_HOOKS_UPDATED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
