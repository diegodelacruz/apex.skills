#!/usr/bin/env python3
"""Inserta o actualiza el gate terminal canonico en tareas APEX activas."""
from __future__ import annotations

import argparse
import difflib
import re
import sys
from pathlib import Path

START = "<!-- ZAIMELLA:APEX:TASK-TERMINAL-GATE:START -->"
END = "<!-- ZAIMELLA:APEX:TASK-TERMINAL-GATE:END -->"
HEADING = "## Gate Terminal De Respuesta"
STATE = re.compile(r"(?mi)^\s*-?\s*Estado\s*:\s*(.+?)\s*$")
CLOSED = re.compile(r"\bcerrad[ao]s?\b", re.I)
LEGACY_GATE = re.compile(
    r"(?ms)^## Gate Terminal De Respuesta\s*\r?\n.*?(?=^##\s|\Z)"
)
ROUTES_HEADING = re.compile(r"(?m)^## Rutas Y Git\s*$")


def canonical_gate() -> str:
    template = (
        Path(__file__).resolve().parents[1]
        / "commands"
        / "resources"
        / "Desarrollo-APEX"
        / "tarea.template.md"
    )
    text = template.read_text(encoding="utf-8")
    if text.count(START) != 1 or text.count(END) != 1:
        raise ValueError("tarea.template.md no contiene un unico gate terminal canonico.")
    begin = text.index(START)
    finish = text.index(END, begin) + len(END)
    block = text[begin:finish]
    if HEADING not in block or "COMPLETA" not in block or "BLOQUEADA" not in block:
        raise ValueError("El gate terminal canonico esta incompleto.")
    return block


def is_closed(text: str) -> bool:
    match = STATE.search(text)
    return bool(match and CLOSED.search(match.group(1)))


def migrate(text: str, gate: str) -> str:
    starts, ends = text.count(START), text.count(END)
    if starts != ends or starts > 1:
        raise ValueError(f"marcadores invalidos START={starts} END={ends}")
    if starts:
        begin = text.index(START)
        finish = text.index(END, begin) + len(END)
        return text[:begin] + gate + text[finish:]

    legacy = LEGACY_GATE.search(text)
    if legacy:
        suffix = text[legacy.end():]
        separator = "" if suffix.startswith(("\n", "\r")) else "\n"
        return text[:legacy.start()] + gate + "\n" + separator + suffix

    routes = ROUTES_HEADING.search(text)
    if routes:
        prefix = text[:routes.start()].rstrip()
        suffix = text[routes.start():].lstrip()
        return prefix + "\n\n" + gate + "\n\n" + suffix
    return text.rstrip() + "\n\n" + gate + "\n"


def task_files(project_root: Path) -> list[Path]:
    tasks = project_root / "docs" / "tareas"
    if not tasks.is_dir():
        return []
    return sorted(
        path
        for path in tasks.rglob("tarea.md")
        if "_control" not in path.relative_to(tasks).parts
    )


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Actualiza el gate terminal de las tareas APEX activas sin tocar las cerradas."
    )
    parser.add_argument("--project-root", required=True)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check", action="store_true")
    mode.add_argument("--dry-run", action="store_true")
    mode.add_argument("--apply", action="store_true")
    args = parser.parse_args()

    project_root = Path(args.project_root).resolve()
    try:
        gate = canonical_gate()
    except ValueError as exc:
        print(f"TASK_GATE_BLOCKED {exc}")
        return 2

    paths = task_files(project_root)
    changed: list[tuple[Path, str, str]] = []
    closed = 0
    for path in paths:
        current = path.read_text(encoding="utf-8")
        if is_closed(current):
            closed += 1
            print(f"TASK_GATE_SKIPPED_CLOSED {path}")
            continue
        try:
            updated = migrate(current, gate)
        except ValueError as exc:
            print(f"TASK_GATE_BLOCKED {path}: {exc}")
            return 2
        if current != updated:
            changed.append((path, current, updated))
            print(f"TASK_GATE_CHANGE_REQUIRED {path}")
        else:
            print(f"TASK_GATE_CURRENT {path}")

    print(f"TASK_GATE_SUMMARY active={len(paths) - closed} closed={closed} changes={len(changed)}")
    if args.check:
        return 0
    if args.dry_run:
        for path, current, updated in changed:
            sys.stdout.writelines(
                difflib.unified_diff(
                    current.splitlines(True),
                    updated.splitlines(True),
                    fromfile=str(path),
                    tofile=str(path),
                )
            )
        return 0
    for path, _, updated in changed:
        temporary = path.with_suffix(".md.zaimella-tmp")
        temporary.write_text(updated, encoding="utf-8")
        temporary.replace(path)
        print(f"TASK_GATE_UPDATED {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
