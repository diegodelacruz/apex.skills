#!/usr/bin/env python3
"""Reconcilia el estado persistente de un proyecto APEX despues de una nueva sesion."""
from __future__ import annotations

import argparse
import re
import subprocess
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

INDEX_START = "<!-- ZAIMELLA:APEX:TASK-INDEX:START -->"
INDEX_END = "<!-- ZAIMELLA:APEX:TASK-INDEX:END -->"
FINDINGS_END = "<!-- ZAIMELLA:APEX:FINDINGS:END -->"
RECOVERY_START = "<!-- ZAIMELLA:APEX:SESSION-RECOVERY:START -->"
RECOVERY_END = "<!-- ZAIMELLA:APEX:SESSION-RECOVERY:END -->"
PLACEHOLDER = re.compile(r"<[^>]+>|^$|^Pendiente$", re.IGNORECASE)


@dataclass
class Task:
    task_id: str
    session: str
    state: str
    closure: str
    qa: str
    production: str
    sha: str
    modified: str
    confirmed: str
    next_action: str
    findings: list[str]


def clean(value: str, default: str = "No registrado") -> str:
    value = re.sub(r"\s+", " ", value.strip())
    return default if PLACEHOLDER.match(value) else value


def markdown_cell(value: str) -> str:
    value = re.sub(r"\s+", " ", value.strip())
    return (value or "No registrado").replace("|", "/")


def field(text: str, label: str, default: str = "No registrado") -> str:
    match = re.search(rf"(?mi)^\s*-\s*{re.escape(label)}\s*:\s*(.*?)\s*$", text)
    return clean(match.group(1), default) if match else clean(default)


def section(text: str, heading: str) -> str:
    match = re.search(
        rf"(?ms)^##\s+{re.escape(heading)}\s*$\r?\n(.*?)(?=^##\s|\Z)", text
    )
    return match.group(1) if match else ""


def source_repo(development: str) -> dict[str, str]:
    label = "Repo fuente \x60zaimella-apex-oracle\x60 local"
    value = field(development, label, "No disponible")
    path = Path(value) if value else None
    if not path or not path.is_dir() or not (path / ".git").exists():
        return {"path": value or "No disponible", "head": "No verificado", "status": "No verificado"}

    def git(*args: str) -> str:
        completed = subprocess.run(
            ["git", "-C", str(path), *args],
            text=True,
            encoding="utf-8",
            errors="replace",
            capture_output=True,
            check=False,
        )
        return completed.stdout.strip() if completed.returncode == 0 else "No verificado"

    return {"path": str(path), "head": git("rev-parse", "HEAD"), "status": git("status", "--porcelain")}


def state_for(text: str, task_id: str, modified: str) -> Task:
    qa_section = section(text, "Resultado QA")
    prod_section = section(text, "Produccion")
    state = field(text, "Estado")
    closure = field(text, "Cierre", "No registrado (legado)")
    qa = field(qa_section, "Recomendacion", "Pendiente")
    production = field(prod_section, "Estado", "No registrada")
    sha = field(text, "Commit publicado en \x60origin/main\x60", "No registrado")
    if sha == "No registrado":
        sha = field(text, "Commit aprobado por QA", "No registrado")
    if sha == "No registrado":
        sha = field(text, "Commit candidato compilado en TEST", "No registrado")
    findings: list[str] = []
    state_normalized = state.casefold()
    prod_normalized = production.casefold()
    if "cerrada" in state_normalized:
        if "pasada" in prod_normalized:
            post = field(prod_section, "Validacion post", "No registrado")
            executed = field(prod_section, "Commit ejecutado", "No registrado")
            if post == "No registrado" or executed == "No registrado":
                confirmed = "POR_RECONCILIAR"
                next_action = "Completar o localizar evidencia de PRODUCCION"
                findings.append("Cierre productivo sin validacion post o SHA ejecutado")
            else:
                confirmed = "CERRADA_CONFIRMADA"
                next_action = "Sin accion"
        elif closure != "No registrado (legado)":
            confirmed = "CERRADA_CONFIRMADA"
            next_action = "Sin accion"
        else:
            confirmed = "CERRADA_HISTORICA"
            next_action = "Sin accion; completar evidencia solo si se reabre"
    elif "bloqueada" in state_normalized:
        confirmed = "BLOQUEADA"
        next_action = "Revisar impedimento y su unica decision requerida"
    elif "espera" in state_normalized:
        confirmed = "EN_ESPERA"
        next_action = "Resolver o serializar solo la fase indicada"
    else:
        confirmed = "ABIERTA"
        if "aprobada para cierre" in state_normalized:
            next_action = "Esperar cierre o pase autorizado"
        elif "qa" in state_normalized:
            next_action = "Continuar QA o atender resultado QA"
        else:
            next_action = "Continuar la siguiente fase y gate pendiente"
    return Task(
        task_id=task_id,
        session=field(text, "Sesion"),
        state=state,
        closure=closure,
        qa=qa,
        production=production,
        sha=sha,
        modified=modified,
        confirmed=confirmed,
        next_action=next_action,
        findings=findings,
    )


def collect(project_root: Path) -> tuple[list[Task], list[str], dict[str, str]]:
    development_path = project_root / "desarrollo.md"
    bitacora_path = project_root / "docs" / "bitacora.md"
    issues: list[str] = []
    development = development_path.read_text(encoding="utf-8") if development_path.exists() else ""
    if not development:
        issues.append("Falta desarrollo.md")
    if not bitacora_path.exists():
        issues.append("Falta docs/bitacora.md")
    task_root = project_root / "docs" / "tareas"
    if not task_root.is_dir():
        issues.append("Falta docs/tareas/")
        return [], issues, source_repo(development)
    tasks: list[Task] = []
    for path in sorted(task_root.rglob("tarea.md")):
        if "_control" in path.relative_to(task_root).parts:
            continue
        text = path.read_text(encoding="utf-8")
        modified = datetime.fromtimestamp(path.stat().st_mtime).astimezone().strftime("%Y-%m-%d %H:%M")
        tasks.append(state_for(text, path.parent.name, modified))
    return tasks, issues, source_repo(development)


def report(project_root: Path, tasks: list[Task], issues: list[str], repo: dict[str, str]) -> str:
    now = datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %Z")
    counts: dict[str, int] = {}
    for task in tasks:
        counts[task.confirmed] = counts.get(task.confirmed, 0) + 1
    lines = [
        "# Recuperacion De Sesion APEX",
        "",
        f"- Fecha/hora: {now}",
        f"- Proyecto/contexto: {project_root}",
        f"- Fuente Git: {repo['path']}",
        f"- HEAD Git: {repo['head']}",
        f"- Git status: {'No verificado' if repo['status'] == 'No verificado' else ('limpio' if not repo['status'] else 'con cambios locales')}",
        f"- Resumen: {'; '.join(f'{key}={value}' for key, value in sorted(counts.items())) or 'sin tareas'}",
        "",
        "## Estado Confirmado",
        "",
        "| ID tarea | Sesion | Estado registrado | Estado confirmado | Cierre | QA | Produccion | SHA relevante | Ultima actividad | Siguiente accion |",
        "|---|---|---|---|---|---|---|---|---|---|",
    ]
    for task in tasks:
        lines.append("| " + " | ".join(markdown_cell(value) for value in (
            task.task_id, task.session, task.state, task.confirmed, task.closure,
            task.qa, task.production, task.sha, task.modified, task.next_action,
        )) + " |")
    lines.extend(["", "## Fuentes y Alertas", ""])
    if issues:
        lines.extend(f"- {issue}" for issue in issues)
    else:
        lines.append("- Contratos y bitacora requeridos encontrados.")
    for task in tasks:
        for finding in task.findings:
            lines.append(f"- {task.task_id}: {finding}.")
    lines.extend([
        "",
        "La conversacion orienta la recuperacion, pero no altera estos estados. "
        "Resolver primero cualquier POR_RECONCILIAR antes de retomar esa tarea.",
        "",
    ])
    return "\n".join(lines)


def template_path(name: str) -> Path:
    return Path(__file__).resolve().parents[1] / "commands" / "resources" / "Desarrollo-APEX" / name


def replace_block(text: str, start: str, end: str, body: str) -> str:
    if text.count(start) != 1 or text.count(end) != 1:
        raise ValueError("marcadores canonicos invalidos")
    before, rest = text.split(start, 1)
    _, after = rest.split(end, 1)
    return f"{before}{start}\n{body.rstrip()}\n{end}{after}"


def write_outputs(project_root: Path, report_text: str, tasks: list[Task], issues: list[str]) -> list[Path]:
    control = project_root / "docs" / "tareas" / "_control"
    control.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().astimezone().strftime("%Y%m%d-%H%M%S")
    recovery_path = control / f"recuperacion-{timestamp}.md"
    recovery_template = template_path("recuperacion-sesion.template.md").read_text(encoding="utf-8")
    recovery_path.write_text(
        replace_block(recovery_template, RECOVERY_START, RECOVERY_END, report_text),
        encoding="utf-8",
    )
    written = [recovery_path]

    index_path = control / "indice-tareas.md"
    if not index_path.exists():
        index_path.write_text(template_path("indice-tareas.template.md").read_text(encoding="utf-8"), encoding="utf-8")
    index_rows = [
        "| ID tarea | Sesion | Estado confirmado | Cierre | QA | Produccion | SHA relevante | Ultima actividad | Siguiente accion |",
        "|---|---|---|---|---|---|---|---|---|",
    ]
    for task in tasks:
        index_rows.append("| " + " | ".join(markdown_cell(value) for value in (
            task.task_id, task.session, task.confirmed, task.closure, task.qa,
            task.production, task.sha, task.modified, task.next_action,
        )) + " |")
    index_path.write_text(
        replace_block(index_path.read_text(encoding="utf-8"), INDEX_START, INDEX_END, "\n".join(index_rows)),
        encoding="utf-8",
    )
    written.append(index_path)

    finding_path = control / "hallazgos.md"
    if not finding_path.exists():
        finding_path.write_text(template_path("hallazgos.template.md").read_text(encoding="utf-8"), encoding="utf-8")
    automatic = list(issues)
    automatic.extend(f"{task.task_id}: {finding}" for task in tasks for finding in task.findings)
    if automatic:
        findings_text = finding_path.read_text(encoding="utf-8")
        additions: list[str] = []
        for issue in automatic:
            fingerprint = re.sub(r"[^A-Z0-9]+", "-", issue.upper()).strip("-")[:80]
            marker = f"<!-- ZAIMELLA:APEX:FINDING:{fingerprint} -->"
            if marker not in findings_text:
                additions.extend([
                    marker,
                    f"### H-AUTO-{fingerprint}",
                    "",
                    "- Tipo: Continuidad o contrato",
                    "- Severidad: Media",
                    f"- Observacion: {issue}",
                    "- Evidencia: reporte de recuperacion vigente",
                    "- Alcance sugerido: Proyecto u orquestador",
                    "- Estado: Nuevo",
                    "",
                ])
        if additions:
            finding_path.write_text(
                findings_text.replace(FINDINGS_END, "\n".join(additions) + FINDINGS_END),
                encoding="utf-8",
            )
            written.append(finding_path)
    return written


def main() -> int:
    parser = argparse.ArgumentParser(description="Lee contratos APEX persistentes y reconstruye el estado de tareas.")
    parser.add_argument("--project-root", required=True)
    parser.add_argument("--write", action="store_true", help="Guarda recuperacion, indice y hallazgos automaticos.")
    parser.add_argument("--output", help="Archivo opcional para el reporte en modo lectura.")
    args = parser.parse_args()
    project_root = Path(args.project_root).resolve()
    if not project_root.is_dir():
        print(f"APEX_RECOVERY_BLOCKED project-root inexistente: {project_root}")
        return 2
    tasks, issues, repo = collect(project_root)
    report_text = report(project_root, tasks, issues, repo)
    print(report_text)
    if args.output:
        Path(args.output).resolve().write_text(report_text, encoding="utf-8")
    if args.write:
        try:
            written = write_outputs(project_root, report_text, tasks, issues)
        except ValueError as exc:
            print(f"APEX_RECOVERY_BLOCKED {exc}", file=sys.stderr)
            return 2
        print("APEX_RECOVERY_WRITTEN " + ", ".join(str(path) for path in written))
    unresolved = sum(task.confirmed == "POR_RECONCILIAR" for task in tasks)
    print(f"APEX_RECOVERY_SUMMARY tasks={len(tasks)} unresolved={unresolved} issues={len(issues)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
