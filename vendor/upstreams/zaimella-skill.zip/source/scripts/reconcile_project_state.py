#!/usr/bin/env python3
"""Reconstruye un indice de estado desde los contratos persistentes del proyecto."""
from __future__ import annotations

import argparse
import re
from datetime import datetime
from pathlib import Path


FIELD_RE = re.compile(r"^- ([^:]+):\s*(.*)$")


def fields(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        match = FIELD_RE.match(line.strip())
        if match:
            result[match.group(1).strip()] = match.group(2).strip()
    return result


def summarize(root: Path) -> str:
    package_dir = root / "proyecto" / "06_seguimiento" / "paquetes"
    handoff_dir = root / "proyecto" / "06_seguimiento" / "handoffs"
    lines = [
        "# Estado Reconciliado Del Proyecto",
        "",
        f"- Generado: {datetime.now().astimezone().isoformat(timespec='seconds')}",
        f"- Raiz: `{root}`",
        "- Fuente: contratos persistentes; la conversacion no cambia estados.",
        "",
        "## Paquetes Y Handoffs",
        "",
        "| ID paquete | Entregable | Sprint | Capability | Propietario | Ejecutor | Estado paquete | Resultado dominio | Tarea dominio |",
        "|---|---|---|---|---|---|---|---|---|",
    ]
    packages = sorted(package_dir.glob("*.md")) if package_dir.is_dir() else []
    for package_path in packages:
        package = fields(package_path)
        package_id = package.get("ID paquete", package_path.stem)
        handoff_path = handoff_dir / f"{package_id}.md"
        handoff = fields(handoff_path) if handoff_path.is_file() else {}
        row = (
            package_id,
            package.get("ID entregable", "POR_RECONCILIAR"),
            package.get("ID sprint", "POR_RECONCILIAR"),
            package.get("Capability ID", "POR_RECONCILIAR"),
            package.get("Orquestador propietario", "POR_RECONCILIAR"),
            package.get("Responsable ejecutor", "POR_RECONCILIAR"),
            package.get("Estado", "POR_RECONCILIAR"),
            handoff.get("Resultado", "SIN_HANDOFF"),
            handoff.get("Tarea interna del dominio", "No registrada"),
        )
        lines.append("| " + " | ".join(value.replace("|", "/") for value in row) + " |")
    if not packages:
        lines.append("| Sin paquetes |  |  |  |  |  |  |  |  |")
    lines.extend(
        [
            "",
            "## Contratos Detectados",
            "",
            f"- Proyecto: {'SI' if (root / 'proyecto' / 'proyecto.md').is_file() else 'NO'}",
            f"- Entregables: {'SI' if (root / 'proyecto' / '05_planificacion' / 'entregables.md').is_file() else 'NO'}",
            f"- Plan documental: {'SI' if (root / 'proyecto' / '06_seguimiento' / 'documentacion' / 'plan.md').is_file() else 'NO'}",
            f"- Indice final: {'SI' if (root / 'proyecto' / '07_cierre' / 'indice-entregables.md').is_file() else 'NO'}",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", required=True)
    parser.add_argument("--write", action="store_true")
    args = parser.parse_args()
    root = Path(args.project_root).resolve()
    report = summarize(root)
    if args.write:
        output = root / "proyecto" / "06_seguimiento" / "_control" / "estado-reconciliado.md"
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(report, encoding="utf-8")
        print(f"PROJECT_STATE_WRITTEN {output}")
    else:
        print(report)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
