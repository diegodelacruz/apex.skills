#!/usr/bin/env python3
"""Inserta o actualiza el bloque de gestión de casos APEX en un proyecto."""
from __future__ import annotations

import argparse
import difflib
import hashlib
import re
from pathlib import Path

START = "<!-- ZAIMELLA: GESTION CASOS APEX :START -->"
END = "<!-- ZAIMELLA: GESTION CASOS APEX :END -->"
PATTERN = re.compile(re.escape(START) + r".*?" + re.escape(END), re.S)


def canonical_block() -> str:
    path = Path(__file__).resolve().parents[1] / "commands" / "resources" / "Desarrollo-APEX" / "casos-agents.template.md"
    text = path.read_text(encoding="utf-8").strip()
    if text.count(START) != 1 or text.count(END) != 1:
        raise ValueError("Plantilla de gestión de casos inválida.")
    return text


def updated(current: str) -> str:
    block = canonical_block()
    if PATTERN.search(current):
        return PATTERN.sub(block, current, count=1).rstrip() + "\n"
    return (current.rstrip() + "\n\n" if current.strip() else "") + block + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", required=True)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--check", action="store_true")
    mode.add_argument("--dry-run", action="store_true")
    mode.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    target = Path(args.project_root).resolve() / "AGENTS.md"
    current = target.read_text(encoding="utf-8") if target.exists() else ""
    result = updated(current)
    changed = current != result
    digest = hashlib.sha256(result.encode("utf-8")).hexdigest()
    if args.check:
        print(f"CASE_MANAGEMENT_CHECK changed={str(changed).lower()} sha256={digest}")
    elif args.dry_run:
        print("".join(difflib.unified_diff(current.splitlines(True), result.splitlines(True), fromfile=str(target), tofile=str(target))))
    elif changed:
        target.write_text(result, encoding="utf-8")
        print(f"CASE_MANAGEMENT_APPLIED sha256={digest}")
    else:
        print(f"CASE_MANAGEMENT_UNCHANGED sha256={digest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
