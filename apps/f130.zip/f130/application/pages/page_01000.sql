prompt --application/pages/page_01000
begin
--   Manifest
--     PAGE: 01000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>1000
,p_name=>'dlgLogs'
,p_alias=>'DLGLOGS'
,p_page_mode=>'MODAL'
,p_step_title=>'Logs'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Form-inputContainer, .t-Form-labelContainer {',
'    padding-top: 2px;',
'    padding-bottom: 2px;',
'    padding-left: 2px;',
'}',
'',
'.apex-item-display-only {',
'    min-height: 0px;',
'    font-weight: 100;',
'    line-height: 12px;',
'}',
'',
'.t-Form-label {',
'    padding: 2px;',
'    line-height: 12px;',
'    display: block;',
'    font-weight: 900;',
'}',
'',
'.a-IRR-toolbar {',
'    padding: 1px !IMPORTANT;',
'}',
'',
'.a-IRR-headerLabel, .a-IRR-headerLink {',
'    padding: 3px;',
'}',
'.a-IRR-table td {',
'    padding: 1px 1px;',
'}',
'',
'.longText {',
'    font-size: smaller;',
'}',
'',
'.t-Dialog-body {',
'    padding: 2px;',
'}',
'',
'.title {',
'    padding: 6px;',
'    font-size: large;',
'    background: lightgreen;    ',
'}',
'',
'.a-Button.a-IRR-button {',
'    padding: 2px;',
'}',
'',
'.t-IRR-region {',
'    margin-bottom: 6px;',
'}',
'',
'.t-Button, .ui-button {',
'    padding: 0px !IMPORTANT;',
'}',
'',
'.t-Button .t-Icon.fa {',
'    padding: 0px !IMPORTANT;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20231206170811Z')
,p_last_updated_on=>wwv_flow_imp.dz('20231107211618Z')
,p_last_updated_by=>'DCUEVA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(124267313484950503)
,p_plug_name=>'Logs'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'     PASO, ',
'     TO_CHAR(FECHA, ''DD/MON'') AS DIA,',
'     TO_CHAR(FECHA, ''HH24:MI:SS'') AS HORA,',
'     DESCRIPCION  AS PROCESO,',
'     OBSERVACION AS DETALLE',
'',
'FROM    ',
'    ( SELECT ENTRY, FECHA, PASO, DESCRIPCION, OBSERVACION FROM T_APEX_LOG WHERE APLICACION=''COMP'' AND USUARIO=:APP_USER ORDER BY ENTRY DESC',
'    ) INFO',
'WHERE ROWNUM  <= 200;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Logs'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(124267413364950504)
,p_max_row_count=>'500'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>124267413364950504
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124267776419950507)
,p_db_column_name=>'PASO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Paso'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124268166371950511)
,p_db_column_name=>'DETALLE'
,p_display_order=>40
,p_column_identifier=>'F'
,p_column_label=>'Detalle'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124268205393950512)
,p_db_column_name=>'DIA'
,p_display_order=>50
,p_column_identifier=>'G'
,p_column_label=>unistr('D\00CDa')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124268362010950513)
,p_db_column_name=>'HORA'
,p_display_order=>60
,p_column_identifier=>'H'
,p_column_label=>'Hora'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124268450508950514)
,p_db_column_name=>'PROCESO'
,p_display_order=>70
,p_column_identifier=>'I'
,p_column_label=>'Proceso'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(124279184553089467)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1242792'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PASO:DIA:HORA:PROCESO:DETALLE:'
,p_created_on=>wwv_flow_imp.dz('20231206170811Z')
,p_updated_on=>wwv_flow_imp.dz('20231206170811Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
