prompt --application/pages/page_00237
begin
--   Manifest
--     PAGE: 00237
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>237
,p_name=>unistr('Detalle requsici\00F3n')
,p_alias=>unistr('DETALLE-REQUSICI\00D3N')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Detalle requsici\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20240410163446Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240321162918Z')
,p_last_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(182396899870520018)
,p_name=>'Requisicion'
,p_template=>wwv_flow_imp.id(296121421643169165)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT Y.CONCEPTO,Y.REQUISICION',
'FROM t_cmex_provision X,t_cmex_provision_detalle Y ',
'WHERE ID_CMEX_MESATRABAJO=:P237_ID_MESATRABAJO',
'AND X.ID=ID_CABECERA',
'AND REQUISICION IS NOT NULL',
';'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(182396919704520019)
,p_query_column_id=>1
,p_column_alias=>'CONCEPTO'
,p_column_display_sequence=>10
,p_column_heading=>'Concepto'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(93018914532751121)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(182397192802520021)
,p_query_column_id=>2
,p_column_alias=>'REQUISICION'
,p_column_display_sequence=>30
,p_column_heading=>'Requisicion'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182396747110520017)
,p_name=>'P237_ID_MESATRABAJO'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
