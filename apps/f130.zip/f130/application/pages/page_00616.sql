prompt --application/pages/page_00616
begin
--   Manifest
--     PAGE: 00616
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>616
,p_name=>'CGZM - Cancelar Solicitud'
,p_alias=>'CGZM-CANCELAR-SOLICITUD'
,p_page_mode=>'MODAL'
,p_step_title=>'Cancelar Solicitud - Motivo'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(regOcultos).hide();'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_created_on=>wwv_flow_imp.dz('20250124202059Z')
,p_last_updated_on=>wwv_flow_imp.dz('20250528171151Z')
,p_created_by=>'DDELACRUZ'
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(573020522792464726)
,p_plug_name=>'Ocultos'
,p_region_name=>'regOcultos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250124202403Z')
,p_updated_on=>wwv_flow_imp.dz('20250124202403Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(573020606108464727)
,p_plug_name=>'Datos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250124202403Z')
,p_updated_on=>wwv_flow_imp.dz('20250124202403Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(573021253683464733)
,p_plug_name=>'Botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121809343169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':p616_idcab is not null and :p616_accion is not null'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250124204046Z')
,p_updated_on=>wwv_flow_imp.dz('20250124210417Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(573021157060464732)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(573021253683464733)
,p_button_name=>'GUARDAR'
,p_button_static_id=>'btnCancelar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_warn_on_unsaved_changes=>null
,p_created_on=>wwv_flow_imp.dz('20250124203517Z')
,p_updated_on=>wwv_flow_imp.dz('20250205144859Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(573020722438464728)
,p_name=>'P616_IDCAB'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(573020522792464726)
,p_prompt=>'ID Cab'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250124202403Z')
,p_updated_on=>wwv_flow_imp.dz('20250124202403Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(573020814629464729)
,p_name=>'P616_MOTIVO'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(573020606108464727)
,p_prompt=>'Motivo'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>3
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250124202403Z')
,p_updated_on=>wwv_flow_imp.dz('20250205141515Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(573020914953464730)
,p_name=>'P616_ACCION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(573020522792464726)
,p_prompt=>'Accion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250124202403Z')
,p_updated_on=>wwv_flow_imp.dz('20250124202403Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(591849953260691401)
,p_name=>'P616_PORCENTAJEPAGO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(573020606108464727)
,p_prompt=>'% Pago'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>10
,p_display_when=>'P616_ACCION'
,p_display_when2=>'PAGO'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'0'
,p_attribute_02=>'100'
,p_attribute_03=>'right'
,p_attribute_04=>'decimal'
,p_created_on=>wwv_flow_imp.dz('20250205141515Z')
,p_updated_on=>wwv_flow_imp.dz('20250205141757Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(573021353775464734)
,p_name=>'Guardar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(573021157060464732)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20250124205332Z')
,p_updated_on=>wwv_flow_imp.dz('20250528171151Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(573021493596464735)
,p_event_id=>wwv_flow_imp.id(573021353775464734)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
,p_created_on=>wwv_flow_imp.dz('20250124205332Z')
,p_updated_on=>wwv_flow_imp.dz('20250124205332Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(573021570213464736)
,p_event_id=>wwv_flow_imp.id(573021353775464734)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_idcab		number;',
'v_accion	varchar2(100);',
'v_motivo	varchar2(1000);',
'v_respuesta	number;',
'v_texto		varchar2(1000);',
'v_estadopago	varchar2(25);',
'v_porcpago	number;',
'v_porcanti	number;',
'begin',
'	v_idcab		:= :p616_idcab;',
'	v_accion	:= :p616_accion;',
'	v_motivo	:= :p616_motivo;',
'	v_porcanti	:= :p616_porcentajepago;',
'',
'	if v_motivo is null then',
'		return;',
'	end if;',
'',
'	if v_accion = ''CANCELAR'' then',
'		v_texto := ''[''||to_char(sysdate,''dd/mm/yyyy hh24:mi'')||'' - ''||:app_user||'' - CANCELAR] ''||v_motivo;',
'',
'		pk_comp_gestionocgrupozm.sp_log(v_idcab);',
'',
'		update t_comp_ordencompraextcab x',
'		set x.estado = ''CANCELADO''',
'			, x.observacion = case when trim(x.observacion) is not null then x.observacion||chr(10)||v_texto else v_texto end',
'		where x.id = v_idcab;',
'',
'		pk_comp_gestionocgrupozm.sp_notificar(:g_compania,:app_user,v_idcab,''CANCELAR'',v_respuesta);',
'		pk_comp_gestionocgrupozm.sp_log(v_idcab);',
'	elsif v_accion = ''PAGO'' then',
'		v_texto := ''[''||to_char(sysdate,''dd/mm/yyyy hh24:mi'')||'' - ''||:app_user||'' - PAGO] ''||v_motivo;',
'',
'		begin',
'			select nvl(porcpago,0) into v_porcpago from t_comp_ordencompraextcab where id = v_idcab;',
'			exception when others then v_porcpago := 0;',
'		end;',
'',
'		-- if (v_porcpago = 0 and v_porcanti < 100) or (v_porcpago > 0 and v_porcanti < 100) then',
'		if v_porcpago >= 0 and v_porcanti < 100 then',
'			v_estadopago := ''ANTICIPO'';',
'		elsif v_porcpago >= 0 and v_porcanti = 100 then',
'			v_estadopago := ''APROBADO'';',
'		end if;',
'',
'		pk_comp_gestionocgrupozm.sp_log(v_idcab);',
'',
'		update t_comp_ordencompraextcab x',
'		set x.estadopago = v_estadopago, x.porcpago = v_porcanti',
'			, x.observacion = case when trim(x.observacion) is not null then x.observacion||chr(10)||v_texto else v_texto end',
'		where x.id = v_idcab;',
'',
'		pk_comp_gestionocgrupozm.sp_notificar(:g_compania,:app_user,v_idcab,''CONFIRMARPAGO'',v_respuesta);',
'		pk_comp_gestionocgrupozm.sp_log(v_idcab);',
'	elsif v_accion = ''PAGOREALIZADO'' then',
'		v_texto := ''[''||to_char(sysdate,''dd/mm/yyyy hh24:mi'')||'' - ''||:app_user||'' - PAGO REALIZADO] ''||v_motivo;',
'',
'		begin',
'			select estadopago into v_estadopago from t_comp_ordencompraextcab where id = v_idcab;',
'			exception when others then v_estadopago := null;',
'		end;',
'',
'		if v_estadopago = ''APROBADO'' then',
'			v_estadopago := ''PAGADO'';',
'		elsif instr(v_estadopago,''ANTICIPO'') > 0 then',
'			v_estadopago := ''ANTICIPO PAGADO'';',
'		end if;',
'',
'		pk_comp_gestionocgrupozm.sp_log(v_idcab);',
'',
'		update t_comp_ordencompraextcab x',
'		set x.estadopago = v_estadopago',
'			, x.observacion = case when trim(x.observacion) is not null then x.observacion||chr(10)||v_texto else v_texto end',
'		where x.id = v_idcab;',
'',
'		pk_comp_gestionocgrupozm.sp_notificar(:g_compania,:app_user,v_idcab,''PAGOREALIZADO'',v_respuesta);',
'		pk_comp_gestionocgrupozm.sp_log(v_idcab);',
'	end if;',
'end;'))
,p_attribute_02=>'P616_IDCAB,P616_ACCION,P616_MOTIVO,P616_PORCENTAJEPAGO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250124205332Z')
,p_updated_on=>wwv_flow_imp.dz('20250528171151Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(573021663654464737)
,p_event_id=>wwv_flow_imp.id(573021353775464734)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
,p_created_on=>wwv_flow_imp.dz('20250124205403Z')
,p_updated_on=>wwv_flow_imp.dz('20250124205403Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(573022159744464742)
,p_event_id=>wwv_flow_imp.id(573021353775464734)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
,p_created_on=>wwv_flow_imp.dz('20250124205843Z')
,p_updated_on=>wwv_flow_imp.dz('20250124205843Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(573022655709464747)
,p_name=>'Motivo'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P616_MOTIVO'
,p_condition_element=>'P616_MOTIVO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keyup'
,p_created_on=>wwv_flow_imp.dz('20250127163359Z')
,p_updated_on=>wwv_flow_imp.dz('20250127164154Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(573022762477464748)
,p_event_id=>wwv_flow_imp.id(573022655709464747)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(573021157060464732)
,p_created_on=>wwv_flow_imp.dz('20250127163359Z')
,p_updated_on=>wwv_flow_imp.dz('20250127163359Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(573022830559464749)
,p_event_id=>wwv_flow_imp.id(573022655709464747)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(573021157060464732)
,p_created_on=>wwv_flow_imp.dz('20250127163359Z')
,p_updated_on=>wwv_flow_imp.dz('20250127163359Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
