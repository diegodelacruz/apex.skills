prompt --application/pages/page_00133
begin
--   Manifest
--     PAGE: 00133
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>133
,p_name=>unistr('\00DAltimo Precio')
,p_step_title=>unistr('\00DAltimo Precio')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230708132654Z')
,p_last_updated_on=>wwv_flow_imp.dz('20230510201635Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(283712025813000909)
,p_plug_name=>unistr('Par\00E1metros')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(524904931910907304)
,p_plug_name=>'Reporte'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct num01 codcorto',
'	, txt01 codproducto',
'	, trim(txt02) codantiguo',
'	, txt03 producto',
'	, txt04 tipoproducto',
'	, txt05 codtipoinv',
'	, txt06 codcategoria',
'	, txt07 codsubcategoria',
'	, num02 ordencompra',
'	, txt08 tipooc',
'	, num03 requisicion',
'	, txt09 tiporq',
'	, num04 codproveedor',
'	, txt10 proveedor',
'	, fecha01 fechaoc',
'	, num06 codrequisitor',
'	, txt11 requisitor',
'	, fecha02 fecharq',
'    , num08 precio',
'from data.t_apex_temporal',
'where flag = ''D'' and control01 = :g_compania and control02 = :app_modulo and control03 = :app_user and control04 = ''data.pk_comp_reportes.sp_temporal'' and nvl(num02,0) > 0;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(524905036938907305)
,p_max_row_count=>'1000000'
,p_max_rows_per_page=>'1000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'CSV:HTML:XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>524905036938907305
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274375595763292168)
,p_db_column_name=>'CODCORTO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>unistr('C\00F3d. Corto')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274377546641292169)
,p_db_column_name=>'CODPRODUCTO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>unistr('C\00F3d. Producto')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250130431100278340)
,p_db_column_name=>'REQUISICION'
,p_display_order=>160
,p_column_identifier=>'R'
,p_column_label=>unistr('Requisici\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250130940121278345)
,p_db_column_name=>'CODREQUISITOR'
,p_display_order=>210
,p_column_identifier=>'W'
,p_column_label=>unistr('C\00F3d. Requisitor')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250131020484278346)
,p_db_column_name=>'FECHAOC'
,p_display_order=>220
,p_column_identifier=>'X'
,p_column_label=>'Fecha OC'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250131110660278347)
,p_db_column_name=>'CODPROVEEDOR'
,p_display_order=>230
,p_column_identifier=>'Y'
,p_column_label=>unistr('C\00F3d. Proveedor')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250131254712278348)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>240
,p_column_identifier=>'Z'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274406385016425803)
,p_db_column_name=>'CODSUBCATEGORIA'
,p_display_order=>290
,p_column_identifier=>'AE'
,p_column_label=>unistr('Subcategor\00EDa')
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(129813847190977848)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274406507644425805)
,p_db_column_name=>'REQUISITOR'
,p_display_order=>310
,p_column_identifier=>'AG'
,p_column_label=>'Requisitor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274406796761425807)
,p_db_column_name=>'CODANTIGUO'
,p_display_order=>330
,p_column_identifier=>'AI'
,p_column_label=>unistr('C\00F3d. Antiguo')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(283711252505000901)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>340
,p_column_identifier=>'AJ'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(283711313635000902)
,p_db_column_name=>'TIPOPRODUCTO'
,p_display_order=>350
,p_column_identifier=>'AK'
,p_column_label=>'T. prod.'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(283711446478000903)
,p_db_column_name=>'CODTIPOINV'
,p_display_order=>360
,p_column_identifier=>'AL'
,p_column_label=>'Tipo Inv.'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(129811530306971265)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(283711515084000904)
,p_db_column_name=>'CODCATEGORIA'
,p_display_order=>370
,p_column_identifier=>'AM'
,p_column_label=>unistr('Categor\00EDa')
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(129812558354975445)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(283711621309000905)
,p_db_column_name=>'ORDENCOMPRA'
,p_display_order=>380
,p_column_identifier=>'AN'
,p_column_label=>'Orden Compra'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(283711758188000906)
,p_db_column_name=>'TIPOOC'
,p_display_order=>390
,p_column_identifier=>'AO'
,p_column_label=>'Tipo OC'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(283711819802000907)
,p_db_column_name=>'TIPORQ'
,p_display_order=>400
,p_column_identifier=>'AP'
,p_column_label=>'Tipo RQ'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(283711986171000908)
,p_db_column_name=>'FECHARQ'
,p_display_order=>410
,p_column_identifier=>'AQ'
,p_column_label=>'Fecha RQ'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(283712386900000912)
,p_db_column_name=>'PRECIO'
,p_display_order=>420
,p_column_identifier=>'AR'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(545382327431233758)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2743803'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ORDENCOMPRA:TIPOOC:FECHAOC:REQUISICION:TIPORQ:FECHARQ:REQUISITOR:PROVEEDOR:CODPRODUCTO:CODANTIGUO:PRODUCTO:PRECIO:'
,p_sort_column_1=>'CODBODEGA'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'ANNO'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'MES'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'CODPRODUCTO'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20230708132654Z')
,p_updated_on=>wwv_flow_imp.dz('20230708132654Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1626318799930756219)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(274381090513292175)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1626318799930756219)
,p_button_name=>'BUSCAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(283712199586000910)
,p_name=>'P133_CATEGORIA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(283712025813000909)
,p_prompt=>unistr('Categor\00EDa')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select distinct upper(drdl01)||'' (''||drky||'')'' d, drky from f4101@jdedtadl inner join vt_jde_udcjde on drsy = ''41'' and drrt = ''P4'' and trim(imprp4) = drky order by 1'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(283712278803000911)
,p_name=>'P133_SUBCATEGORIA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(283712025813000909)
,p_prompt=>unistr('Subcategor\00EDa')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct upper(drdl01)||'' (''||drky||'')'' d, drky from f4101@jdedtadl inner join vt_jde_udcjde on drsy = ''41'' and drrt = ''01'' and trim(imprp6) = drky',
'where trim(imprp4) = :p133_categoria',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_cascade_parent_items=>'P133_CATEGORIA'
,p_ajax_items_to_submit=>'P133_CATEGORIA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(274382160066292222)
,p_name=>'Buscar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(274381090513292175)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(274382608917292224)
,p_event_id=>wwv_flow_imp.id(274382160066292222)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra()'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(274383611876292224)
,p_event_id=>wwv_flow_imp.id(274382160066292222)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	pk_comp_reportes.sp_temporal(',
'		p_compania			=> :g_compania',
'		, p_usuario			=> :app_user',
'		, p_categoria		=> :p133_categoria',
'		, p_subcategoria	=> :p133_subcategoria',
'	);',
'end;'))
,p_attribute_02=>'P133_CATEGORIA,P133_SUBCATEGORIA'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(274384190428292225)
,p_event_id=>wwv_flow_imp.id(274382160066292222)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(524904931910907304)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(274383131162292224)
,p_event_id=>wwv_flow_imp.id(274382160066292222)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra()'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(274381722710292222)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Separador'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	execute immediate ''ALTER SESSION SET NLS_NUMERIC_CHARACTERS =''''.,'''''';',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>274381722710292222
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(274381482368292219)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Categoir\00EDas')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_log_app varchar2(100);',
'begin',
'	v_log_app := ''apex.130.132.prerendering'';',
'	insert into data.t_apex_temporal (flag,control01,control02,control03,control04,txt01,txt02,txt03,txt04)',
'	select distinct ''APEX'',:g_compania,:app_modulo,:app_user,v_log_app,trim(imprp4) imprp4, a.drdl01||'' (''||a.drky||'')'', trim(imprp7) imprp7, b.drdl01||'' (''||b.drky||'')''',
'	from f4101@jdedtadl',
'	inner join vt_jde_udcjde a on a.drsy = ''41'' and a.drrt = ''P4'' and trim(imprp4) = a.drky',
'	inner join vt_jde_udcjde b on b.drsy = ''41'' and b.drrt = ''02'' and trim(imprp7) = b.drky;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>274381482368292219
);
wwv_flow_imp.component_end;
end;
/
