prompt --application/pages/page_00620
begin
--   Manifest
--     PAGE: 00620
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>620
,p_name=>'Crear Orden de Compra'
,p_alias=>'CREAR-ORDEN-DE-COMPRA'
,p_step_title=>'Crear Orden de Compra'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();',
'$(regOcultos).hide();'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'02'
,p_last_updated_on=>wwv_flow_imp.dz('20260728214047Z')
,p_last_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(400899139297019031)
,p_plug_name=>'Crear Orden de Compra'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296122226350169167)
,p_plug_display_sequence=>5
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'1=2'
,p_plug_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(400899290373019032)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>15
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(400900422547019044)
,p_plug_name=>'Adjunto'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P620_ID is not null'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(401418117865412526)
,p_plug_name=>'Archivos'
,p_parent_plug_id=>wwv_flow_imp.id(400900422547019044)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select filename archivo',
'	, fecha fecha_carga',
'	, dbms_lob.getlength(blobcontent) blobcontent',
'	, numeroarchivo',
'	, tipo tipoarchivo',
'	, case',
unistr('		when (:p620_estado in (''INGRESADO'',''SOLICITADO'',''GESTI\00D3N'') and observacion = observacion)'),
'			or (:p620_estado = ''APROBADO'' and observacion = ''APROBADO'') or (:p620_estado = ''EN RUTA'' and observacion = ''EN RUTA'') then ''<span aria-hidden="true" class="fa fa-trash-o"></span>''',
'		else null end eliminar',
'	, pk_commons.f_googledocview(numeroarchivo,mimetype) enlace',
'from files.t_apex_archivos',
'where 1 = 1',
'	and tabla = ''T_COMP_ORDENCOMPRAEXTCAB''',
'	and id_tabla = :p620_id',
'	and nvl(tipo,''X'') = nvl(tipo,''X'')',
'order by numeroarchivo desc'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P620_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Adjuntos'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(489798634548163406)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>489798634548163406
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(489798786563163407)
,p_db_column_name=>'ARCHIVO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Archivo'
,p_column_link=>'#ENLACE#'
,p_column_linktext=>'#ARCHIVO#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(489798851119163408)
,p_db_column_name=>'FECHA_CARGA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fecha Carga'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(489798951049163409)
,p_db_column_name=>'BLOBCONTENT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Archivo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(489799098856163410)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Numeroarchivo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(489799189137163411)
,p_db_column_name=>'ELIMINAR'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'-'
,p_column_link=>'javascript: $s(''P620_IDBORRAR'','''');$s(''P620_IDBORRAR'',''#NUMEROARCHIVO#'');'
,p_column_linktext=>'#ELIMINAR#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(573018068004464701)
,p_db_column_name=>'TIPOARCHIVO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Tipo'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(573004918697433826)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(582143678227768550)
,p_db_column_name=>'ENLACE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Enlace'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(489808150866167047)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'4898082'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TIPOARCHIVO:ARCHIVO:FECHA_CARGA:ELIMINAR:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(489800026470163420)
,p_plug_name=>unistr('Par\00E1metros Archivos')
,p_parent_plug_id=>wwv_flow_imp.id(400900422547019044)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('(:p620_estado in (''INGRESADO'',''SOLICITADO'',''GESTI\00D3N'') and :p620_estadopago is null) or'),
'(:p620_estado in (''APROBADO'') and :p620_estadopago is null) or',
'(:p620_estado in (''APROBADO'') and :p620_estadopago = ''APROBADO'') or',
'(:p620_estado = ''EN RUTA'' and :p620_usuarioflujo = :p620_usuario)or',
'(:p620_estado = ''EN RUTA'' and :P620_USERCOMP = :p620_usuario)'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(400900567682019045)
,p_plug_name=>'Aprobar'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121809343169165)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':p620_id is not null and :p620_estado = ''EN RUTA'' and :p620_usuarioflujo = :p620_usuario'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(415952492935075108)
,p_plug_name=>'Ocultos'
,p_region_name=>'regOcultos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>70
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(564757882762585101)
,p_plug_name=>unistr('Detalle Aprobaci\00F3n')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select x.*, nvl(x.cantordenada,0)*nvl(x.precio,0) totallinea',
'from t_comp_ordencompraextdet x',
'where x.idcab = :p620_id'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P620_ID'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':p620_estado in (''EN RUTA'',''APROBADO'',''RECHAZADO'',''CANCELADO'')'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Detalle Aprobaci\00F3n')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(582141245914768526)
,p_max_row_count=>'1000000'
,p_allow_report_saving=>'N'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_download_filename=>'&P620_ID.'
,p_enable_mail_download=>'N'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>582141245914768526
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(582141305686768527)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(582141400109768528)
,p_db_column_name=>'USERCREA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Usercrea'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(582141552420768529)
,p_db_column_name=>'FECHCREA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fechcrea'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(582141602790768530)
,p_db_column_name=>'USERMODI'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Usermodi'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(582141721579768531)
,p_db_column_name=>'FECHMODI'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fechmodi'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(582141881750768532)
,p_db_column_name=>'IDCAB'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Idcab'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(582141939281768533)
,p_db_column_name=>'IDORG'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Idorg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(582142037022768534)
,p_db_column_name=>'ESTADO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(582142124365768535)
,p_db_column_name=>'FECHACOMP'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fechacomp'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(582142239196768536)
,p_db_column_name=>'FECHADESP'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fechadesp'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(582142336068768537)
,p_db_column_name=>'CODPRODUCTO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>unistr('C\00F3d. Producto')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(582142470986768538)
,p_db_column_name=>'DESCPRODUCTO'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(582142544326768539)
,p_db_column_name=>'CTGPRODUCTO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Ctgproducto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(582142681426768540)
,p_db_column_name=>'UNIDADMEDIDA'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'UM'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(582142703573768541)
,p_db_column_name=>'CANTORDENADA'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Cant. Ordenada'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(582142865385768542)
,p_db_column_name=>'CANTRECIBIDA'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Cantrecibida'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(582142917183768543)
,p_db_column_name=>'CANTTEMPORAL'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Canttemporal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(582143082589768544)
,p_db_column_name=>'PRECIO'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(582143157675768545)
,p_db_column_name=>'OBSPROVEEDOR'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Obs. Proveedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(582143202546768546)
,p_db_column_name=>'OBSAPROBADOR'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Obs. Aprobador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(582143376193768547)
,p_db_column_name=>'OBSRECEPCION'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Obs. Recepcion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(582143459580768548)
,p_db_column_name=>'OBSCOMPRADOR'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Obs. Comprador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(582143595759768549)
,p_db_column_name=>'TOTALLINEA'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(231636790374854203)
,p_db_column_name=>'CODPROVEEDOR'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>unistr('C\00F3d. Proveedor*')
,p_column_type=>'STRING'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>'1 = 1'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(231636849782854204)
,p_db_column_name=>'DESCPROVEEDOR'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Proveedor*'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>'1 = 1'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(582430170338722967)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5824302'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODPROVEEDOR:DESCPROVEEDOR:CODPRODUCTO:DESCPRODUCTO:UNIDADMEDIDA:CANTORDENADA:PRECIO:TOTALLINEA:OBSPROVEEDOR:OBSAPROBADOR:'
,p_sort_column_1=>'DESCPROVEEDOR'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'ID'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_sum_columns_on_break=>'TOTALLINEA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(802038884505863517)
,p_plug_name=>'Detalle'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select x.*',
'	, nvl(x.cantordenada,0)*nvl(x.precio,0) totallinea',
'from t_comp_ordencompraextdet x',
'where x.idcab = :p620_id'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P620_ID'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>unistr(':P620_ID is not null and :p620_estado in (''INGRESADO'',''SOLICITADO'',''GESTI\00D3N'')')
,p_plug_display_when_cond2=>'PLSQL'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P620_ESTADO IN (''EN RUTA'',''APROBADO'') OR',
unistr('(:P620_ROL=''USUARIO'' AND :P620_ESTADO IN (''GESTI\00D3N''))')))
,p_plug_read_only_when2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Detalle'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231636584209854201)
,p_name=>'CODPROVEEDOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODPROVEEDOR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>unistr('C\00F3d. Proveedor*')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>260
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>50
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>unistr(':p620_companiades in (''00007'',''00008'',''00012'',''00013'') and :p620_estado in (''GESTI\00D3N'',''APROBADO'',''EN RUTA'',''RECHAZADO'')')
,p_display_condition2=>'PLSQL'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(231636675595854202)
,p_name=>'DESCPROVEEDOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCPROVEEDOR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Proveedor*'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>270
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>150
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>unistr(':p620_companiades in (''00007'',''00008'',''00012'',''00013'') and :p620_estado in (''GESTI\00D3N'',''APROBADO'',''EN RUTA'',''RECHAZADO'')')
,p_display_condition2=>'PLSQL'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(400899494613019034)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(400899598936019035)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(560593056822966401)
,p_name=>'IDORG'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IDORG'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>240
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(560593121352966402)
,p_name=>'TOTALLINEA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOTALLINEA'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('Total L\00EDnea')
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>250
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>unistr(':P620_ESTADO in (''GESTI\00D3N'',''EN RUTA'',''APROBADO'',''RECHAZADO'')')
,p_display_condition2=>'PLSQL'
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(802039045617863519)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(802039175238863520)
,p_name=>'USERCREA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'USERCREA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(802039236110863521)
,p_name=>'FECHCREA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHCREA'
,p_data_type=>'TIMESTAMP'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>50
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(802039325319863522)
,p_name=>'USERMODI'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'USERMODI'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>60
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(802039456350863523)
,p_name=>'FECHMODI'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHMODI'
,p_data_type=>'TIMESTAMP'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>70
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(802039563901863524)
,p_name=>'IDCAB'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IDCAB'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>80
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P620_ID'
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(802039619053863525)
,p_name=>'ESTADO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ESTADO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>90
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(802039699711863526)
,p_name=>'FECHACOMP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHACOMP'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>100
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(802039884704863527)
,p_name=>'FECHADESP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHADESP'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>110
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(802039945300863528)
,p_name=>'CODPRODUCTO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODPRODUCTO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>unistr('C\00F3d. Producto')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
,p_is_required=>false
,p_max_length=>50
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(802040037854863529)
,p_name=>'DESCPRODUCTO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCPRODUCTO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Producto'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>130
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
,p_is_required=>false
,p_max_length=>250
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(802040108718863530)
,p_name=>'CTGPRODUCTO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CTGPRODUCTO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_AUTO_COMPLETE'
,p_heading=>'Cat. Producto'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>140
,p_value_alignment=>'LEFT'
,p_attribute_01=>'CONTAINS_CASE'
,p_attribute_04=>'Y'
,p_attribute_05=>'0'
,p_attribute_09=>'1'
,p_attribute_10=>'Y'
,p_item_attributes=>'onChange="this.value=this.value.toUpperCase();"'
,p_is_required=>false
,p_max_length=>100
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select upper(b.ctgproducto)',
'from t_comp_ordencompraextcab a inner join t_comp_ordencompraextdet b on a.id = b.idcab',
'where b.ctgproducto is not null and a.companiades = :P620_COMPANIADES'))
,p_lov_display_extra=>false
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'NEVER'
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(802040223539863531)
,p_name=>'UNIDADMEDIDA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UNIDADMEDIDA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'U.M.'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>150
,p_value_alignment=>'CENTER'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
,p_is_required=>false
,p_max_length=>10
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(802040286069863532)
,p_name=>'CANTORDENADA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CANTORDENADA'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Cant. Orden'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>160
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_format_mask=>'999999999999990D0000'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(802040385543863533)
,p_name=>'CANTRECIBIDA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CANTRECIBIDA'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Cant. Recibida'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>170
,p_value_alignment=>'RIGHT'
,p_attribute_01=>'0.00001'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'999G999G999G999G990D0000'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P620_ESTADO in (''ENVIADO'')'
,p_display_condition2=>'PLSQL'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(802040533797863534)
,p_name=>'CANTTEMPORAL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CANTTEMPORAL'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>180
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(802040661013863535)
,p_name=>'PRECIO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PRECIO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Precio'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>190
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'text'
,p_format_mask=>'999999999999990D0000'
,p_is_required=>false
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>unistr(':P620_ESTADO in (''GESTI\00D3N'',''EN RUTA'',''APROBADO'',''RECHAZADO'')')
,p_display_condition2=>'PLSQL'
,p_readonly_condition_type=>'EXPRESSION'
,p_readonly_condition=>unistr(':P620_ESTADO not in (''GESTI\00D3N'')')
,p_readonly_condition2=>'PLSQL'
,p_readonly_for_each_row=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(802040754000863536)
,p_name=>'OBSPROVEEDOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OBSPROVEEDOR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Obs. Proveedor'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>200
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>1000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P620_ESTADO not in (''EN RUTA'',''APROBADO'',''RECHAZADO'')'
,p_display_condition2=>'PLSQL'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(802040804377863537)
,p_name=>'OBSAPROBADOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OBSAPROBADOR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Obs. Aprobador'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>210
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>1000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(802040928604863538)
,p_name=>'OBSRECEPCION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OBSRECEPCION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>220
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(802040989282863539)
,p_name=>'OBSCOMPRADOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OBSCOMPRADOR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Obs. Comprador'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>230
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>1000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P620_ESTADO not in (''INGRESADO'',''SOLICITADO'')'
,p_display_condition2=>'PLSQL'
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(802038906083863518)
,p_internal_uid=>802038906083863518
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>false
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU:RESET'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(802152881066113830)
,p_interactive_grid_id=>wwv_flow_imp.id(802038906083863518)
,p_static_id=>'4008611'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(802153006673113832)
,p_report_id=>wwv_flow_imp.id(802152881066113830)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231642697931858691)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(231636584209854201)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>120
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(231643500641858704)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(231636675595854202)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>200
,p_sort_order=>1
,p_sort_direction=>'ASC'
,p_sort_nulls=>'FIRST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(401360662172650714)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(400899494613019034)
,p_is_visible=>true
,p_is_frozen=>true
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(560601152714982989)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>26
,p_column_id=>wwv_flow_imp.id(560593056822966401)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(560602187069982994)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>21
,p_column_id=>wwv_flow_imp.id(560593121352966402)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>100
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(802153514231113837)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(802039045617863519)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(802154348424113843)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(802039175238863520)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(802155206091113846)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(802039236110863521)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(802156152807113848)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(802039325319863522)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(802157066305113850)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(802039456350863523)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(802157980645113852)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(802039563901863524)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(802158786900113854)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(802039619053863525)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(802159689942113856)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(802039699711863526)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(802160626261113858)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(802039884704863527)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(802161533951113861)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(802039945300863528)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>120
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(802162456138113863)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(802040037854863529)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>200
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(802163369141113865)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(802040108718863530)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(802164237149113867)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(802040223539863531)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>100
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(802165114669113869)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>18
,p_column_id=>wwv_flow_imp.id(802040286069863532)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>100
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(802165988040113871)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(802040385543863533)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(802166914671113873)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>19
,p_column_id=>wwv_flow_imp.id(802040533797863534)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(802167821828113875)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>20
,p_column_id=>wwv_flow_imp.id(802040661013863535)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>100
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(802168767941113877)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>22
,p_column_id=>wwv_flow_imp.id(802040754000863536)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>200
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(802169675564113879)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>23
,p_column_id=>wwv_flow_imp.id(802040804377863537)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>200
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(802170534529113881)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>24
,p_column_id=>wwv_flow_imp.id(802040928604863538)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(802171457323113883)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_display_seq=>25
,p_column_id=>wwv_flow_imp.id(802040989282863539)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>200
);
wwv_flow_imp_page.create_ig_report_aggregate(
 p_id=>wwv_flow_imp.id(138595000002)
,p_view_id=>wwv_flow_imp.id(802153006673113832)
,p_function=>'SUM'
,p_column_id=>wwv_flow_imp.id(560593121352966402)
,p_show_grand_total=>false
,p_is_enabled=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(802084039253098724)
,p_plug_name=>'Cabecera'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'T_COMP_ORDENCOMPRAEXTCAB'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'1 = 1',
'and (nvl(lower(:app_user),''nobody'') != ''nobody'' or :p620_id is not null)'))
,p_plug_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(138060689091475701)
,p_plug_name=>'Pago Recurrente'
,p_parent_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_icon_css_classes=>'fa-calendar-alarm'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--customIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(295605160997037667)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P620_RECURRENTE'
,p_plug_display_when_cond2=>'SI'
,p_plug_read_only_when_type=>'ALWAYS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(415952042859075104)
,p_plug_name=>'Datos Iniciales'
,p_parent_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(415952281562075106)
,p_plug_name=>'Datos Complementarios'
,p_parent_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_plug_display_when_condition=>'P620_ESTADO'
,p_plug_display_when_cond2=>'INGRESADO'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':p620_estado in (''EN RUTA'',''APROBADO'') OR',
unistr('(:p620_rol = ''USUARIO'' and :p620_estado in (''GESTI\00D3N'')) or'),
'(:p620_usercrea = :p620_usuario and :p620_estado in (''SOLICITADO''))'))
,p_plug_read_only_when2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(400900619379019046)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(400900567682019045)
,p_button_name=>'APROBAR'
,p_button_static_id=>'btnAprobar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Aprobar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:102:&SESSION.::&DEBUG.::G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO:&G_COMPANIA.,&APP_MODULO.,&P620_USUARIO.,&P620_ENTIDADCLASE.,&P620_ID.,&P620_USUARIOFLUJO.'
,p_updated_on=>wwv_flow_imp.dz('20260312211703Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(401303212047249501)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(400899290373019032)
,p_button_name=>'CANCEL'
,p_button_static_id=>'btnCancel'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:&P620_PAGRETORNO.:&SESSION.::&DEBUG.:::'
,p_button_condition=>'P620_BANDERAINGRESO'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(400900793587019047)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(400900567682019045)
,p_button_name=>'RECHAZAR'
,p_button_static_id=>'btnRechazar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Rechazar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:103:&SESSION.::&DEBUG.:RP,:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO:&G_COMPANIA.,&APP_MODULO.,&P620_USUARIO.,&P620_ENTIDADCLASE.,&P620_ID.,&P620_USUARIOFLUJO.'
,p_updated_on=>wwv_flow_imp.dz('20260312211703Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(573021028429464731)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(400899290373019032)
,p_button_name=>'CANCELAROC'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Cancelar Orden'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:616:&SESSION.::&DEBUG.:616:P616_IDCAB,P616_ACCION:&P620_ID.,CANCELAR'
,p_button_condition=>'P620_ESTADO'
,p_button_condition2=>'APROBADO'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-ban'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(415952707934075111)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(400899290373019032)
,p_button_name=>'PDF'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'PDF'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:window.open("http://jasper.zaimella.com:8090/jasperserver/flow.html?_flowId=viewReportFlow&standAlone=true&_repFormat=pdf&output=pdf&_flowId=viewReportFlow&ParentFolderUri=/PRODUCCION/COMPRAS&reportUnit=/PRODUCCION/COMPRAS/rptCompras_GZML&j_username=desarrollo&j_password=desarrollo&_repLocale=en_US&_repEncoding=UTF-8&P_IDCOMPRA=&P620_ID.","mywindow");'
,p_button_condition=>':P620_ID is not null AND :P620_ESTADO in (''EN RUTA'',''APROBADO'') AND :P620_COMPANIADES<>''00015'''
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-file-pdf-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(401416954672412514)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(400899290373019032)
,p_button_name=>'COMENTARIOS'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Comentarios'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:105:&SESSION.::&DEBUG.::G_OBJETO_ID,G_OBJETO,G_ETAPA,G_COMPANIA,G_MODULO,G_USUARIO:&P620_ID.,GRUPOZML,EN PROCESO,&G_COMPANIA.,&APP_MODULO.,&P620_USUARIO.'
,p_button_condition=>':P620_ID is not null AND :P620_ESTADO  IN (''EN RUTA'',''APROBADO'',''RECHAZADO'') AND :P620_COMPANIADES<>''00015'''
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-comment'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(405193623219791342)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(400899290373019032)
,p_button_name=>'DIVIDIR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Dividir'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:615:&SESSION.::&DEBUG.::P615_IDORDEN:&P620_ID.'
,p_button_condition=>unistr(':P620_ESTADO=''GESTI\00D3N'' AND :P620_BANDERADETALLE>1')
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-pie-chart'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(401417156370412516)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(400899290373019032)
,p_button_name=>'ENVIARSOLICITUD'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Enviar Solicitud'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P620_ID is not null and :P620_ESTADO in (''INGRESADO'') AND NVL(:P620_BANDERADETALLE,0)>0'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-paper-plane-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(400900124500019041)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(400899290373019032)
,p_button_name=>'RUTAAPROBACION'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Enviar a Ruta'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:101:&SESSION.::&DEBUG.::G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_ETAPA,G_TIPO1,G_TIPO2,G_TIPO3,G_PAGINA,G_OBJETO_DESCRIPCION:&G_COMPANIA.,&APP_MODULO.,&P620_USUARIO.,GRUPOZML,&P620_ID.,EN PROCESO,GRUPOZML,&P620_COMPANIADES.,&P620_RUTACTG.,COMPP620,&P620_OBSERVACION.'
,p_confirm_message=>unistr('\00BFEst\00E1 seguro de enviar la Orden de Compra a Ruta de Aprobaci\00F3n?')
,p_confirm_style=>'information'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'1 = 1',
'and :P620_ID is not null',
unistr('and :P620_ESTADO in (''GESTI\00D3N'')'),
'AND :P620_BANDERADETALLE = :P620_BANDERAPRECIO',
'AND :P620_DESCPROVEEDOR IS NOT NULL',
'AND :P620_CODPROVEEDOR IS NOT NULL',
'AND :P620_MONEDA IS NOT NULL',
'AND :P620_TERMPAGO IS NOT NULL',
'and :p620_usercomp = :app_user',
'AND (case when :p620_catcompra in (''025'') and :p620_evento is null then 0 else 1 end) = 1'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-paper-plane-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(599459015000255601)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(400899290373019032)
,p_button_name=>'VERRUTA'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Ver Ruta'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:104:&SESSION.::&DEBUG.::G_OBJETO,G_OBJETO_ID,G_TODO:&P620_ENTIDADCLASE.,&P620_ID.,TRUE'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(',
'	1 = 1',
'	and :P620_ID is not null',
'	and :P620_ESTADO in (''EN RUTA'',''APROBADO'',''RECHAZADO'')',
'    -- and :P620_CATCOMPRA<>''000'' AND :P620_COMPANIADES<>''00015''',
') or',
'(',
'	1 = 2--nvl(trim(:p620_idflujo),0) > 0 and :P620_ENTIDADCLASE<>''OCSAP'' AND :P620_COMPANIADES<>''00015''',
')'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-road'
,p_updated_on=>wwv_flow_imp.dz('20260310214509Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(565940650986039401)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_imp.id(400899290373019032)
,p_button_name=>'PAGO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Confirmar Pago'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:616:&SESSION.::&DEBUG.:616:P616_IDCAB,P616_ACCION:&P620_ID.,PAGO'
,p_button_condition=>':p620_estado in (''APROBADO'') and :P620_ESTADOPAGO is null'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-dollar'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(661163180145890506)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_imp.id(400899290373019032)
,p_button_name=>'PAGOREALIZADO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Pago Realizado'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:616:&SESSION.::&DEBUG.:616:P616_IDCAB,P616_ACCION:&P620_ID.,PAGOREALIZADO'
,p_button_condition=>':p620_estado in (''APROBADO'') and :P620_ESTADOPAGO is not null'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-badge-dollar'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(441714463368476801)
,p_button_sequence=>130
,p_button_plug_id=>wwv_flow_imp.id(400899290373019032)
,p_button_name=>'NEGAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>unistr('Negar Gesti\00F3n')
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>unistr(':p620_estado in (''SOLICITADO'',''GESTI\00D3N'')')
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-hand-stop-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(401302009464249500)
,p_button_sequence=>140
,p_button_plug_id=>wwv_flow_imp.id(400899290373019032)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Delete'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>':P620_ID is not null and :P620_ESTADO=''INGRESADO'''
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-trash-o'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(401302493290249501)
,p_button_sequence=>150
,p_button_plug_id=>wwv_flow_imp.id(400899290373019032)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar Cambios'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('(:p620_id is not null and :p620_estado in (''INGRESADO'',''ENVIADO'',''GESTI\00D3N'',''RECEPCI\00D3N'',''SOLICITADO''))'),
'or',
'(:p620_id is not null and :p620_estado = ''EN RUTA'' and :p620_usuarioflujo = :p620_usuario AND :P620_COMPANIADES<>''00015'')',
'or',
'(:p620_id is not null and :p620_estado = ''APROBADO'' and :p620_ordencompraerp is null)'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(401302856557249501)
,p_button_sequence=>160
,p_button_plug_id=>wwv_flow_imp.id(400899290373019032)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Crear'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'1 = 1',
'and :p620_id is null',
'and nvl(lower(:app_user),''nobody'') != ''nobody'''))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(120308903322502012)
,p_button_sequence=>170
,p_button_plug_id=>wwv_flow_imp.id(400899290373019032)
,p_button_name=>'PAGORECURRENTE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Pago Recurrente'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:617:&SESSION.::&DEBUG.:617:P617_IDCAB,P617_ESTADO:&P620_ID.,&P620_ESTADO.'
,p_button_condition=>unistr(':p620_estado in (''APROBADO'',''GESTI\00D3N'') and :P620_COMPANIADES <> ''00001''')
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-calendar-alarm'
,p_updated_on=>wwv_flow_imp.dz('20260728214047Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(405193369425791339)
,p_branch_name=>'go to 610'
,p_branch_action=>'f?p=&APP_ID.:610:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(401302493290249501)
,p_branch_sequence=>11
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'P620_ROL'
,p_branch_condition_text=>'ADMINISTRADOR'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(573018102160464702)
,p_branch_name=>'go to 610'
,p_branch_action=>'f?p=&APP_ID.:610:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(401302009464249500)
,p_branch_sequence=>21
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17218460574783924)
,p_name=>'P620_SAPBORRADOR'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(415952281562075106)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17218579658783925)
,p_name=>'P620_SAPFINAL'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(415952281562075106)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48433134798838024)
,p_name=>'P620_ENTIDADCLASE'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_prompt=>'Ro Obs'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(120308222350502005)
,p_name=>'P620_EVENTO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(415952042859075104)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_prompt=>'Evento'
,p_source=>'SCTGCOMPRA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select descripcion, id_tabla',
'from data.t_corp_udc',
'where 1 = 1',
'	and id_cabecera = ''COMP_CGZ04''',
'	and substr(id_tabla,1,length(to_number(:p620_catcompra))) = to_char(to_number(:p620_catcompra))',
'	and activo = ''1''',
'order by descripcion'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_cascade_parent_items=>'P620_CATCOMPRA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P620_HABILITAEVENTOS'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr(':p620_estado not in (''INGRESADO'',''SOLICITADO'',''GESTI\00D3N'') or'),
'(:p620_estado in (''EN RUTA'',''APROBADO'')) or',
unistr('(:p620_rol = ''USUARIO'' and :p620_estado in (''GESTI\00D3N'')) or'),
'(:p620_usercrea = :p620_usuario and :p620_estado in (''SOLICITADO''))'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(120308506529502008)
,p_name=>'P620_HABILITAEVENTOS'
,p_item_sequence=>320
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_prompt=>'Habilitaeventos'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(138060713142475702)
,p_name=>'P620_RECURRENTE'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_prompt=>'Recurrente'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(138060849064475703)
,p_name=>'P620_PR_FRECUENCIA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(138060689091475701)
,p_prompt=>'Frecuencia'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_NEG_FRECUENCIA'
,p_lov=>'.'||wwv_flow_imp.id(230185465636915585)||'.'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(138060902842475704)
,p_name=>'P620_PR_NUMEROPAGOS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(138060689091475701)
,p_prompt=>unistr('N\00FAm. Pagos')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(138061068125475705)
,p_name=>'P620_PR_FECHAPRIMERPAGO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(138060689091475701)
,p_prompt=>'Fecha Primer Pago'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--large'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(400900841707019048)
,p_name=>'P620_USUARIOFLUJO'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(400900921215019049)
,p_name=>'P620_APROBACION_EXITO'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(400901059638019050)
,p_name=>'P620_TERMINA_FLUJO'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401303645101249502)
,p_name=>'P620_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(415952042859075104)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_prompt=>'Orden de Compra: '
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401304059434249502)
,p_name=>'P620_USERCREA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_item_default=>':APP_USER'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'New'
,p_source=>'USERCREA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>25
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401304438903249503)
,p_name=>'P620_FECHCREA'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_item_default=>'SYSDATE'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'New'
,p_source=>'FECHCREA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401304825752249503)
,p_name=>'P620_USERMODI'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_item_default=>'P620_USUARIO'
,p_item_default_type=>'ITEM'
,p_prompt=>'New'
,p_source=>'USERMODI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>25
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401305201768249504)
,p_name=>'P620_FECHMODI'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_prompt=>'New'
,p_source=>'FECHMODI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401305685960249504)
,p_name=>'P620_USERRQST'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(415952281562075106)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_item_default=>':APP_USER'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Solicitante: '
,p_source=>'USERRQST'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>25
,p_read_only_when=>'P620_ESTADO'
,p_read_only_when2=>'INGRESADO'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401306097823249504)
,p_name=>'P620_USERCOMP'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(415952281562075106)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_prompt=>'Comprador: '
,p_source=>'USERCOMP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_CGZ_COMPRADOR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION2 D,VALOR R',
'FROM T_CORP_UDC',
'WHERE ID_CABECERA=''COMP_CGZ00''',
'AND ID_TABLA<>''*''',
'ORDER BY 1;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cSize=>30
,p_cMaxlength=>25
,p_begin_on_new_line=>'N'
,p_read_only_when=>'P620_ESTADO'
,p_read_only_when2=>'SOLICITADO'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401306459531249504)
,p_name=>'P620_TIPODOC'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_item_default=>'ODC'
,p_prompt=>'New'
,p_source=>'TIPODOC'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>10
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401306807377249505)
,p_name=>'P620_COMPANIAORI'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_item_default=>':g_compania'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'New'
,p_source=>'COMPANIAORI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>5
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401307230474249505)
,p_name=>'P620_COMPANIADES'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(415952042859075104)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_prompt=>'Compania Destino:   '
,p_source=>'COMPANIADES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_CGZ_COMPANIA'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id_tabla clave, descripcion valor',
'from t_corp_udc where id_cabecera = ''COMP_CGZCM'' and id_tabla != ''00000'' and activo = ''1''',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_read_only_when=>'P620_ID'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401307624773249505)
,p_name=>'P620_ESTADO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(415952042859075104)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_item_default=>'INGRESADO'
,p_prompt=>'Estado: '
,p_source=>'ESTADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>':p620_ID IS NOT NULL'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401308099815249505)
,p_name=>'P620_IDRUTA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_prompt=>'New'
,p_source=>'IDRUTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401308469372249506)
,p_name=>'P620_IDFLUJO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_prompt=>'New'
,p_source=>'IDFLUJO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401308850390249506)
,p_name=>'P620_CODPROVEEDOR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(415952281562075106)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_prompt=>unistr('C\00F3d. Proveedor: ')
,p_source=>'CODPROVEEDOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>50
,p_read_only_when=>unistr(':P620_ESTADO NOT IN (''GESTI\00D3N'')')
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>unistr('C\00F3digo del Proveedor en el ERP de la compa\00F1\00EDa destino.')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401309256851249506)
,p_name=>'P620_DESCPROVEEDOR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(415952281562075106)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_prompt=>'Proveedor:'
,p_source=>'DESCPROVEEDOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>150
,p_begin_on_new_line=>'N'
,p_read_only_when=>unistr(':P620_ESTADO NOT IN (''GESTI\00D3N'')')
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>unistr('Nombre/Descripci\00F3n del Proveedor en el ERP de la compa\00F1\00EDa destino.')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401309676480249506)
,p_name=>'P620_FECHAPLAN'
,p_source_data_type=>'DATE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(415952042859075104)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_item_default=>'SYSDATE+1'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Entrega Requerida (ETA):'
,p_source=>'FECHAPLAN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':p620_estado in (''EN RUTA'',''APROBADO'',''RECHAZADO'',''CANCELADO'') or',
'--',
unistr('(:p620_rol = ''USUARIO'' and :p620_estado in (''GESTI\00D3N'')) or'),
'(:p620_usercrea = :p620_usuario and :p620_estado in (''SOLICITADO''))'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401310091874249507)
,p_name=>'P620_TERMPAGO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(415952281562075106)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_prompt=>unistr('T\00E9rm. Pago: ')
,p_source=>'TERMPAGO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TERMINOSDEPAGO2'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  l_sql   CLOB := ''select d, r from ('';',
'  l_sep   VARCHAR2(20) := '''';',
'',
'  PROCEDURE add_src(p_sql IN CLOB, p_probe IN VARCHAR2) IS',
'  BEGIN',
'    -- Intentamos conectar al dblink. Si falla, no agregamos ese origen.',
'    BEGIN',
'      EXECUTE IMMEDIATE p_probe;       -- por ej. ''select 1 from dual@jdedtadl''',
'      l_sql := l_sql || l_sep || p_sql;',
'      l_sep := '' UNION ALL '';',
'    EXCEPTION',
'      WHEN OTHERS THEN',
'        NULL; -- ignoramos el error del dblink',
'    END;',
'  END;',
'BEGIN',
'  -- 1) JDE (siempre lo intentamos)',
'  add_src(',
'    q''[',
'      SELECT CAST(pnptc || '' - '' || TRIM(pnptd) AS VARCHAR2(70)) AS d,',
'             CAST(pnptc AS VARCHAR2(10)) AS r',
'      FROM f0014@jdedtadl',
'    ]'',',
'    ''select 1 from dual@jdedtadl''',
'  );',
'',
unistr('  -- 2) HANA GT (solo si aplica compa\00F1\00EDa)'),
'  IF NVL(:P620_COMPANIADES, ''X'') = ''00006'' THEN',
'    add_src(',
'      q''[',
'        SELECT CAST("GroupNum" || '' - '' || "PymntGroup" AS VARCHAR2(70)) AS d,',
'               CAST(TO_CHAR("GroupNum") AS VARCHAR2(10)) AS r',
'        FROM OCTG@HANAGT',
'      ]'',',
'      ''select 1 from dual@HANAGT''',
'    );',
'  END IF;',
'',
unistr('  -- 3) HANA ABX (solo si aplica compa\00F1\00EDa)'),
'  IF NVL(:P620_COMPANIADES, ''X'') = ''00015'' THEN',
'    add_src(',
'      q''[',
'        SELECT CAST("GroupNum" || '' - '' || "PymntGroup" AS VARCHAR2(70)) AS d,',
'               CAST(TO_CHAR("GroupNum") AS VARCHAR2(10)) AS r',
'        FROM OCTG@HANA_ABX',
'      ]'',',
'      ''select 1 from dual@HANA_ABX''',
'    );',
'  END IF;',
'',
unistr('  -- 3) HANA PE (solo si aplica compa\00F1\00EDa)'),
'  IF NVL(:P620_COMPANIADES, ''X'') = ''00003'' THEN',
'    add_src(',
'      q''[',
'        SELECT CAST("GroupNum" || '' - '' || "PymntGroup" AS VARCHAR2(70)) AS d,',
'               CAST(TO_CHAR("GroupNum") AS VARCHAR2(10)) AS r',
'        FROM OCTG@HANA_PE',
'      ]'',',
'      ''select 1 from dual@HANA_PE''',
'    );',
'  END IF;',
'',
unistr('  -- Si ning\00FAn origen qued\00F3 disponible, devolvemos 0 filas'),
'  IF l_sep IS NULL THEN',
'    RETURN ''select cast(null as varchar2(70)) d, cast(null as varchar2(10)) r from dual where 1=0'';',
'  END IF;',
'',
'  l_sql := l_sql || '')'';',
'  RETURN l_sql;',
'END;',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when=>unistr(':P620_ESTADO NOT IN (''GESTI\00D3N'')')
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401310481454249507)
,p_name=>'P620_INCOTERM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(415952281562075106)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_prompt=>'Incoterm: '
,p_source=>'INCOTERM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_INCOTERMS'
,p_lov=>'select DRKY ||'' - ''||upper(DRDL01) d,DRKY r from vt_jde_udcjde where drsy=''42'' and drrt=''FR'' and drky is not null order by upper(DRKY)'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_read_only_when=>unistr(':P620_ESTADO NOT IN (''GESTI\00D3N'')')
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401310835670249507)
,p_name=>'P620_MONEDA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(415952281562075106)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_item_default=>'USD'
,p_prompt=>'Moneda: '
,p_source=>'MONEDA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_NEG_MONEDA'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRKY||'' - ''||DRDL01 DESCRIPCION, DRKY VALOR',
'from vt_jde_udcjde',
'where drsy = ''74R''and drrt = ''CR'' and drky in (''EUR'',''USD'',''BOB'',''DOP'',''PEN'',''QTZ'')'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when=>unistr(':P620_ESTADO NOT IN (''GESTI\00D3N'')')
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401311233320249507)
,p_name=>'P620_ESTADOPAGO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_prompt=>'New'
,p_source=>'ESTADOPAGO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>10
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401311616314249508)
,p_name=>'P620_OBSERVACION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(415952042859075104)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_prompt=>unistr('Observaci\00F3n: ')
,p_source=>'OBSERVACION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>2000
,p_cHeight=>2
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_estado	varchar2(25);',
'v_usuario	varchar2(25);',
'v_usrflujo	varchar2(25);',
'begin',
'	v_estado	:= upper(trim(:p620_estado));',
'	v_usuario	:= upper(trim(:p620_usuario));',
'	v_usrflujo	:= upper(trim(:p620_usuarioflujo));',
'',
'	if v_estado in (''APROBADO'',''RECHAZADO'',''CANCELADO'',''SOLICITADO'') then',
'		return true;',
unistr('	elsif v_estado = ''GESTI\00D3N'' then'),
'		if :p620_rol = ''USUARIO'' then',
'			return true;',
'		else',
'			return false;',
'		end if;',
'	elsif v_estado = ''EN RUTA'' then',
'		if v_usrflujo != v_usuario then',
'			return true;',
'		else',
'			return false;',
'		end if;',
'	end if;',
'end;'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'FUNCTION_BODY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>unistr('Justificaci\00F3n de la compra. Visible durante todo el proceso.')
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401312079590249508)
,p_name=>'P620_COMENTARIO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(415952042859075104)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_prompt=>'Comentario: '
,p_source=>'COMENTARIO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>2000
,p_cHeight=>2
,p_begin_on_new_line=>'N'
,p_display_when=>unistr(':P620_ESTADO in (''INGRESADO'',''SOLICITADO'',''GESTI\00D3N'')')
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':p620_estado in (''EN RUTA'',''APROBADO'') OR',
unistr('(:p620_rol = ''USUARIO'' and :p620_estado in (''GESTI\00D3N'')) or'),
'(:p620_usercrea = :p620_usuario and :p620_estado in (''SOLICITADO''))'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>unistr('Instrucci\00F3n para el comprador. Visible durante la gesti\00F3n.')
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401416443692412509)
,p_name=>'P620_ENVIO_EXITO'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401417603754412521)
,p_name=>'P620_ARCHIVO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(489800026470163420)
,p_prompt=>'Archivo'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401418027837412525)
,p_name=>'P620_NUMERODOCUMENTO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401963262482798715)
,p_name=>'P620_NUMEROARCHIVO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(405192428996791330)
,p_name=>'P620_ROL'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(405193225630791338)
,p_name=>'P620_BANDERADETALLE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(411397825732050340)
,p_name=>'P620_BANDERAPRECIO'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(415953101453075115)
,p_name=>'P620_BANDERARECEPCION'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(415953861116075122)
,p_name=>'P620_USUARIO'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(415953967837075123)
,p_name=>'P620_PAGRETORNO'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(429205128045107301)
,p_name=>'P620_CATCOMPRA'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(415952042859075104)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_prompt=>'Cat. Compra: '
,p_source=>'CATCOMPRA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_CGZ_CATCOMPRA'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select descripcion D, id_tabla R',
'from data.t_corp_udc ',
'where id_cabecera = ''COMP_CGZ01'' and activo = ''1'' and id_tabla != ''000'' ',
'order by descripcion;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr(':p620_estado not in (''INGRESADO'',''SOLICITADO'',''GESTI\00D3N'') or'),
'(:p620_estado in (''EN RUTA'',''APROBADO'')) or',
unistr('(:p620_rol = ''USUARIO'' and :p620_estado in (''GESTI\00D3N'')) or'),
'(:p620_usercrea = :p620_usuario and :p620_estado in (''SOLICITADO''))'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(443072399541413614)
,p_name=>'P620_BANDERAINGRESO'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_prompt=>'Banderaingreso'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(443072532268413616)
,p_name=>'P620_RUTACTG'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_prompt=>'Rutactg'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(489799201546163412)
,p_name=>'P620_IDBORRAR'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_prompt=>'Idborrar'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(489799965192163419)
,p_name=>'P620_TIPOARCHIVO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(489800026470163420)
,p_prompt=>'Tipo Archivo:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_CGZ_TIPOARCHIVO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id_tabla, descripcion',
'from t_corp_udc',
'where id_cabecera = ''COMP_CGZ03'' and id_tabla != ''000''',
'order by descripcion'))
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(492947177183579701)
,p_name=>'P620_FLUJO'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_prompt=>'Flujo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(492947221353579702)
,p_name=>'P620_MENSAJE'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_prompt=>'Mensaje'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(492947346519579703)
,p_name=>'P620_TOKEN'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_prompt=>'Token'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(564760122632585124)
,p_name=>'P620_COMPANIADESTINO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_item_default=>':g_compania'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'New'
,p_source=>'COMPANIAORI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>5
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(597848286628369501)
,p_name=>'P620_RO_OBS'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(415952492935075108)
,p_prompt=>'Ro Obs'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(599459160715255602)
,p_name=>'P620_ORDENCOMPRAERP'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(415952042859075104)
,p_item_source_plug_id=>wwv_flow_imp.id(802084039253098724)
,p_prompt=>unistr('N\00FAm. OC ERP:')
,p_source=>'ORDENCOMPRAERP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>25
,p_begin_on_new_line=>'N'
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':p620_estado in (''EN RUTA'',''RECHAZADO'',''CANCELADO'') or',
'--',
unistr('(:p620_rol = ''USUARIO'' and :p620_estado in (''GESTI\00D3N'')) or'),
'(:p620_usercrea = :p620_usuario and :p620_estado in (''SOLICITADO''))'))
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>unistr('N\00FAmero de la Orden de Compra generada en el ERP de la compa\00F1\00EDa destino.')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(411396923404050331)
,p_validation_name=>'Validar FP 1'
,p_validation_sequence=>50
,p_validation=>'TO_DATE(SYSDATE,''DD/MM/YYYY'') < TO_DATE(:P620_FECHAPLAN,''DD/MM/YYYY'')'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'La Fecha de Entrega Requerida (ETA) no puede ser menor a la Fecha Actual.'
,p_when_button_pressed=>wwv_flow_imp.id(401302856557249501)
,p_associated_item=>wwv_flow_imp.id(401309676480249506)
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(411397029952050332)
,p_validation_name=>'Validar FP 2'
,p_validation_sequence=>60
,p_validation=>'TO_DATE(SYSDATE,''DD/MM/YYYY'') < TO_DATE(:P620_FECHAPLAN,''DD/MM/YYYY'')'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'La Fecha de Entrega Requerida (ETA) no puede ser menor a la Fecha Actual.'
,p_when_button_pressed=>wwv_flow_imp.id(401302493290249501)
,p_associated_item=>wwv_flow_imp.id(401309676480249506)
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(411397227521050334)
,p_tabular_form_region_id=>wwv_flow_imp.id(802038884505863517)
,p_validation_name=>'Cantidad Ordenada'
,p_validation_sequence=>70
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'	IF pk_commons.safe_to_number(:CANTORDENADA) < 0 THEN',
'		RETURN FALSE;',
'	ELSE',
'		RETURN TRUE;',
'	END IF;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'Valor no puede ser negativo'
,p_always_execute=>'Y'
,p_associated_column=>'CANTORDENADA'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(411397757513050339)
,p_tabular_form_region_id=>wwv_flow_imp.id(802038884505863517)
,p_validation_name=>'Precio'
,p_validation_sequence=>80
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'	IF :PRECIO < 0 THEN',
'		RETURN FALSE;',
'	ELSE',
'		RETURN TRUE;',
'	END IF;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'El precio no puede ser negativo.'
,p_only_for_changed_rows=>'N'
,p_associated_column=>'PRECIO'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(415952865593075112)
,p_tabular_form_region_id=>wwv_flow_imp.id(802038884505863517)
,p_validation_name=>'Cantidad Recibida'
,p_validation_sequence=>90
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'	IF :CANTRECIBIDA < 0 THEN',
'		RETURN FALSE;',
'	ELSE',
'		RETURN TRUE;',
'	END IF;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'Cantidad Recibida no puede ser negativo.'
,p_always_execute=>'Y'
,p_associated_column=>'CANTRECIBIDA'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(401415674244412501)
,p_name=>unistr('Cierre di\00E1logo: Aprobar')
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(400900619379019046)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_updated_on=>wwv_flow_imp.dz('20260123173715Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401415744966412502)
,p_event_id=>wwv_flow_imp.id(401415674244412501)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P620_TERMINA_FLUJO'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'apex.item( "P620_TERMINA_FLUJO" ).setValue(0);',
'mostrarBarra();',
'if(this.data.G_EXITO==''true''){',
'	mensaje(''exito'', this.data.G_MENSAJE);',
'	if(isTerminoFlujo){',
'		apex.item( "P620_TERMINA_FLUJO" ).setValue(1);',
'	}',
'}',
'else{',
'	mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401415994477412504)
,p_event_id=>wwv_flow_imp.id(401415674244412501)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_respuesta number;',
'v_idmesa	number;',
'v_tabla		data.t_comp_ordencompraextprc%rowtype;',
'begin',
'	v_idmesa := :p620_id;',
'	if :p620_termina_flujo = 1 then',
'		data.pk_comp_gestionocgrupozm.sp_gestionaprobacion(:g_compania,:app_user,v_idmesa,''APROBAR'');',
'		:p620_mensaje := ''Solicitud ''||v_idmesa||'' aprobada'';',
'	end if;',
'end;'))
,p_attribute_02=>'P620_ID,P620_TERMINA_FLUJO'
,p_attribute_03=>'P620_MENSAJE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260123173715Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401416016283412505)
,p_event_id=>wwv_flow_imp.id(401415674244412501)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var token = apex.item("P620_TOKEN").getValue();',
'if(this.data.G_EXITO==''true''){',
'	if(token==''0''){',
'		$(''#btnCancel'').trigger("click");',
'	}else{',
'		$(''#btnAprobar'').hide();',
'		$(''#btnRechazar'').hide();',
'	}',
'}',
'ocultarBarra();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(401416147207412506)
,p_name=>unistr('Cierre di\00E1logo: Rechazar')
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(400900793587019047)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_updated_on=>wwv_flow_imp.dz('20260123173715Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(560166126817877036)
,p_event_id=>wwv_flow_imp.id(401416147207412506)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mostrarBarra();',
'var trama = JSON.parse(this.data.G_RESULTADO);',
'console.log(trama);',
'var isTerminoFlujo = trama.resultado.terminoFlujo;',
'apex.item("P620_FLUJO").setValue(0);',
'if(this.data.G_EXITO==''true''){',
'	apex.item("P620_FLUJO").setValue(1);',
'}',
'else{',
'	mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401416221757412507)
,p_event_id=>wwv_flow_imp.id(401416147207412506)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_respuesta	number;',
'v_idmesa	number;',
'v_sesionid           varchar2(100);',
'begin',
'	v_idmesa := :p620_id;',
'	if :p620_flujo = 1 then',
'		data.pk_comp_gestionocgrupozm.sp_gestionaprobacion(:g_compania,:app_user,v_idmesa,''RECHAZAR'');',
'		:p620_mensaje := ''Solicitud ''||v_idmesa||'' rechazada'';',
'	end if;',
'end;'))
,p_attribute_02=>'P620_FLUJO,P620_ID'
,p_attribute_03=>'P620_MENSAJE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260123173715Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401416356886412508)
,p_event_id=>wwv_flow_imp.id(401416147207412506)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let v_mensaje=$v("P620_MENSAJE");',
'if (!v_mensaje.toUpperCase().includes("ERROR")){',
'	mensajeExito (v_mensaje);',
'} else {',
'	mensajeError (v_mensaje);',
'}'))
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P620_MENSAJE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(492947422564579704)
,p_event_id=>wwv_flow_imp.id(401416147207412506)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var token = apex.item("P620_TOKEN").getValue();',
'ocultarBarra();',
'if(this.data.G_EXITO==''true''){',
'	if(token==''0''){',
'		$(''#btnCancel'').trigger("click");',
'	}else{',
'		$(''#btnAprobar'').hide();',
'		$(''#btnRechazar'').hide();',
'	}',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(401416529043412510)
,p_name=>unistr('Cierre di\00E1logo: Env\00EDo Flujo')
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(400900124500019041)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P620_ESTADO'
,p_display_when_cond2=>unistr('GESTI\00D3N')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401416684125412511)
,p_event_id=>wwv_flow_imp.id(401416529043412510)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P620_ENVIO_EXITO'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log(this.data)',
'if(this.data.G_EXITO==''true''){',
'	mensaje(''exito'', this.data.G_MENSAJE);',
'	apex.item( "P620_ENVIO_EXITO" ).setValue(1);',
'}',
'else{ ',
'	mensaje(''error'', this.data.G_MENSAJE);',
'	apex.item( "P620_ENVIO_EXITO" ).setValue(0);',
'}',
'mostrarBarra();'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401416774582412512)
,p_event_id=>wwv_flow_imp.id(401416529043412510)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_idmesa	number;',
'v_idfapr	number;',
'begin',
'	v_idmesa := :p620_id;',
'',
'	if :p620_envio_exito = 1 then',
'		select max(id) into v_idfapr from t_flujo_aprobacion_cab',
'		where codmodulo = ''COMP'' and entidad_clase = ''GRUPOZML'' and entidad_id = to_char(v_idmesa);',
'',
'		pk_comp_gestionocgrupozm.sp_log(v_idmesa);',
'		-- update t_comp_ordencompraextcab set estado = ''EN RUTA'' where id = v_idmesa;',
'		update t_comp_ordencompraextcab x set (x.estado,x.idflujo,x.idruta) = (',
'			select ''EN RUTA'',y.id,y.codruta from t_flujo_aprobacion_cab y where y.id = v_idfapr',
'		) where x.id = v_idmesa;',
'		pk_comp_gestionocgrupozm.sp_log(v_idmesa);',
'	end if;',
'end;'))
,p_attribute_02=>'P620_ID,P620_ENVIO_EXITO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401416819277412513)
,p_event_id=>wwv_flow_imp.id(401416529043412510)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ocultarBarra();',
'$(''#btnCancel'').trigger("click");'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(401417207205412517)
,p_name=>'Confirmar'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(401417156370412516)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mousedown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401417348261412518)
,p_event_id=>wwv_flow_imp.id(401417207205412517)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEst\00E1 seguro de enviar la solicitud?')
,p_attribute_02=>'Solicitud'
,p_attribute_03=>'success'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(560165749744877032)
,p_event_id=>wwv_flow_imp.id(401417207205412517)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401417477565412519)
,p_event_id=>wwv_flow_imp.id(401417207205412517)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_estado varchar2(25);',
'v_respuesta number;',
'v_idcab	number;',
'v_comprador varchar2(25);',
'begin',
'	v_idcab := :p620_id;',
'	pk_comp_gestionocgrupozm.sp_log(v_idcab);',
'',
'	begin',
'		-- Cuando el solicitante es el mismo comprador. Se autoasigna',
'		select upper(trim(valor)) into v_comprador',
'		from data.t_corp_udc',
'		where 1 = 1',
'			and id_cabecera = ''COMP_CGZ00'' and descripcion = ''COMPRADOR''',
'			and id_tabla = :g_compania',
'			and valor = :app_user',
'			and instr(valor2,:p620_catcompra) >= 0',
'			and activo = ''1''',
'			and rownum = 1;',
'',
'		exception when others then v_comprador := pk_comp_gestionocgrupozm.f_comprador(:p620_companiades,:p620_catcompra);',
'	end;',
'',
'	if v_comprador is not null then',
unistr('		v_estado := ''GESTI\00D3N'';'),
'		update data.t_comp_ordencompraextcab',
'		set estado = v_estado,usercomp = v_comprador',
'		where id = v_idcab;',
'	else',
'		v_estado := ''SOLICITADO'';',
'		update data.t_comp_ordencompraextcab set estado = v_estado where id = v_idcab;',
'	end if;',
'	pk_comp_gestionocgrupozm.sp_notificar(:g_compania,:app_user,p_idmesa=>v_idcab,p_opcion=>v_estado,p_respuesta=>v_respuesta);',
'	pk_comp_gestionocgrupozm.sp_log(v_idcab);',
'end;'))
,p_attribute_02=>'P620_ID,P620_COMPANIADES,P620_CATCOMPRA'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401417534565412520)
,p_event_id=>wwv_flow_imp.id(401417207205412517)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ocultarBarra();',
'$(''#btnCancel'').trigger("click");'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(401417737703412522)
,p_name=>'Cargar Archivo'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P620_ARCHIVO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401417866279412523)
,p_event_id=>wwv_flow_imp.id(401417737703412522)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(401963320987798716)
,p_name=>'Eliminar archivo'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P620_NUMEROARCHIVO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401963466965798717)
,p_event_id=>wwv_flow_imp.id(401963320987798716)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Archivo'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEst\00E1 seguro de eliminar el archivo?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401963587888798718)
,p_event_id=>wwv_flow_imp.id(401963320987798716)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'pk_apex_archivos.sp_eliminaarchivo(:p620_numeroarchivo);'
,p_attribute_02=>'P620_NUMEROARCHIVO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(401963679027798719)
,p_event_id=>wwv_flow_imp.id(401963320987798716)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(401418117865412526)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(415952958528075113)
,p_name=>'Recepcion'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(401302493290249501)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mousedown'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>unistr(':P620_ESTADO IN (''ENVIADO'',''RECEPCI\00D3N'')')
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(415953000919075114)
,p_event_id=>wwv_flow_imp.id(415952958528075113)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('UPDATE T_COMP_ORDENCOMPRAEXTCAB SET ESTADO=''RECEPCI\00D3N'''),
'WHERE ID=:P620_ID AND :P620_ESTADO=''ENVIADO''',
'AND EXISTS (SELECT ''X'' FROM T_COMP_ORDENCOMPRAEXTDET',
'            WHERE IDCAB=:P620_ID',
'            AND NVL(CANTRECIBIDA,0)>0 );'))
,p_attribute_02=>'P620_ID,P620_ESTADO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(415956562467075149)
,p_name=>'Notificar_comprador'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(401302493290249501)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'mousedown'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P620_ESTADO'
,p_display_when_cond2=>'SOLICITADO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(415956654991075150)
,p_event_id=>wwv_flow_imp.id(415956562467075149)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_respuesta number;',
'begin',
'    pk_comp_gestionocgrupozm.SP_LOG(:P620_ID);',
'    pk_comp_gestionocgrupozm.SP_NOTIFICAR(:G_COMPANIA, :app_user, :P620_ID,''SOLICITADO'',v_respuesta);',
'    pk_comp_gestionocgrupozm.SP_LOG(:P620_ID);',
'end;'))
,p_attribute_02=>'P620_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(441714559575476802)
,p_name=>unistr('Negar Gesti\00F3n')
,p_event_sequence=>120
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(441714463368476801)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(441714793128476804)
,p_event_id=>wwv_flow_imp.id(441714559575476802)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEst\00E1 seguro de devolver esta solicitud?')
,p_attribute_02=>unistr('Negar Gesti\00F3n')
,p_attribute_03=>'warning'
,p_attribute_06=>unistr('S\00ED')
,p_attribute_07=>'No'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(441714601320476803)
,p_event_id=>wwv_flow_imp.id(441714559575476802)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(441714846748476805)
,p_event_id=>wwv_flow_imp.id(441714559575476802)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_idmesa number;',
'v_respuesta	number;',
'begin',
'	v_idmesa := :p620_id;',
'	pk_comp_gestionocgrupozm.sp_log(v_idmesa);',
'	pk_comp_gestionocgrupozm.sp_notificar(:g_compania,:app_user,v_idmesa,''DEVOLVER'',v_respuesta);',
'',
'	if v_respuesta = 1 then',
'		update t_comp_ordencompraextcab x set x.estado = ''INGRESADO'', usercomp = null where id = v_idmesa;',
'	end if;',
'	pk_comp_gestionocgrupozm.sp_log(v_idmesa);',
'end;'))
,p_attribute_02=>'P620_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(441714955404476806)
,p_event_id=>wwv_flow_imp.id(441714559575476802)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ocultarBarra();',
'$(''#btnCancel'').trigger("click");'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(443075889176413649)
,p_name=>unistr('Define Ruta Aprobaci\00F3n')
,p_event_sequence=>140
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P620_CATCOMPRA'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(443075925310413650)
,p_event_id=>wwv_flow_imp.id(443075889176413649)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	:p620_rutactg := pk_comp_gestionocgrupozm.f_rutaaprobacion(:p620_companiades,:p620_catcompra,:p620_evento);',
'end;'))
,p_attribute_02=>'P620_COMPANIADES,P620_CATCOMPRA,P620_EVENTO'
,p_attribute_03=>'P620_RUTACTG'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(120308309638502006)
,p_name=>'Habilita Eventos'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P620_CATCOMPRA'
,p_condition_element=>'P620_CATCOMPRA'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(120308495511502007)
,p_event_id=>wwv_flow_imp.id(120308309638502006)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	:p620_habilitaeventos := data.pk_comp_gestionocgrupozm.f_habilitasctg(:g_compania,:p620_catcompra);',
'end;'))
,p_attribute_02=>'P620_CATCOMPRA'
,p_attribute_03=>'P620_HABILITAEVENTOS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(489799327581163413)
,p_name=>'Borrar Archivo'
,p_event_sequence=>160
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P620_IDBORRAR'
,p_condition_element=>'P620_IDBORRAR'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(489799412174163414)
,p_event_id=>wwv_flow_imp.id(489799327581163413)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(489799557602163415)
,p_event_id=>wwv_flow_imp.id(489799327581163413)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	pk_apex_archivos.sp_eliminaarchivo(:p620_idborrar);',
'end;'))
,p_attribute_02=>'P620_IDBORRAR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(489799604301163416)
,p_event_id=>wwv_flow_imp.id(489799327581163413)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(489799769225163417)
,p_event_id=>wwv_flow_imp.id(489799327581163413)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(400900422547019044)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(489799884837163418)
,p_event_id=>wwv_flow_imp.id(489799327581163413)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(573022257166464743)
,p_name=>'Cerrar - Cancelar'
,p_event_sequence=>170
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(573021028429464731)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(573022304707464744)
,p_event_id=>wwv_flow_imp.id(573022257166464743)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mostrarBarra();',
'$(''#btnCancel'').trigger("click");'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(591850049561691402)
,p_name=>'Cerrar - Pago'
,p_event_sequence=>180
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(565940650986039401)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(591850157552691403)
,p_event_id=>wwv_flow_imp.id(591850049561691402)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mostrarBarra();',
'$(''#btnCancel'').trigger("click");'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(661163249723890507)
,p_name=>'Cerrar - Pago Realizado'
,p_event_sequence=>190
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(661163180145890506)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(661163362708890508)
,p_event_id=>wwv_flow_imp.id(661163249723890507)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mostrarBarra();',
'$(''#btnCancel'').trigger("click");'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(120308674383502009)
,p_name=>'Habilita'
,p_event_sequence=>220
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P620_HABILITAEVENTOS'
,p_condition_element=>'P620_HABILITAEVENTOS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(120308723603502010)
,p_event_id=>wwv_flow_imp.id(120308674383502009)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P620_EVENTO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(120308898001502011)
,p_event_id=>wwv_flow_imp.id(120308674383502009)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P620_EVENTO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(401966418119798747)
,p_process_sequence=>5
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Secuencial'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_secuencial number := 0;',
'begin',
'	select pk_comp_gestionocgrupozm.f_secuencia(:p620_companiades,to_char(sysdate,''yyyy'')) into v_secuencial from dual;',
'',
'	:p620_id		:= v_secuencial;',
'	:p620_userrqst	:= :p620_usuario;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(401302856557249501)
,p_internal_uid=>401966418119798747
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(401319479722249513)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(802084039253098724)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Cabecera Compra'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>401319479722249513
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(400899687488019036)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(802038884505863517)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Detalle Compra - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>400899687488019036
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(400900088492019040)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Borrar Detalle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_idmesa number;',
'begin',
'	v_idmesa := :p620_id;',
'	delete from t_comp_ordencompraextdet where idcab = v_idmesa;',
'',
'	delete from files.t_apex_archivos where tipo = ''COMP'' and tabla = ''T_COMP_ORDENCOMPRAEXTCAB'' and id_tabla = v_idmesa;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(401302009464249500)
,p_internal_uid=>400900088492019040
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(401417977410412524)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Archivo'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_numeroarchivo number;',
'begin',
'	begin',
'		select numeroarchivo into v_numeroarchivo',
'		from files.vt_apex_archivos where tabla = ''T_COMP_ORDENCOMPRAEXTCAB'' and id_tabla = :p620_id and observacion = ''COMPRASGRUPOZML'';',
'',
'		exception when no_data_found then v_numeroarchivo := null;',
'	end;',
'',
'	if v_numeroarchivo is not null then ',
'		pk_apex_archivos.sp_eliminaarchivo(v_numeroarchivo);',
'		v_numeroarchivo := null;',
'	end if;',
'',
'	pk_apex_archivos.sp_creararchivo(:p620_archivo,''T_COMP_ORDENCOMPRAEXTCAB'',:p620_id,:p620_tipoarchivo,:p620_estado,:p620_usuario,v_numeroarchivo);',
'	:p620_numerodocumento := v_numeroarchivo;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>unistr(':p620_estado in (''INGRESADO'',''GESTI\00D3N'',''APROBADO'',''EN RUTA'')')
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>401417977410412524
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(405192211630791328)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Log'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :p620_estado = ''SOLICITADO'' and :p620_usercomp is not null then',
unistr('	update t_comp_ordencompraextcab set estado = ''GESTI\00D3N'' where id = :p620_id;'),
'end if;',
'pk_comp_gestionocgrupozm.sp_log(:p620_id);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(401302493290249501)
,p_internal_uid=>405192211630791328
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(415953655763075120)
,p_process_sequence=>5
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetUp'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_tipo			varchar2(50);',
'v_usuarioflujo	varchar2(50);',
'v_idcab			number;',
'v_sesionid		varchar2(100);',
'v_route_id		varchar2(100);',
'v_response		clob;',
'v_compania_sap	varchar2(5)   :=''00015'';',
'v_log_app		varchar2(100);',
'v_log_dsc		varchar2(100);',
'v_log_msg		varchar2(100);',
'v_log_obs		varchar2(100);',
'begin',
'	v_log_app := ''apex.130.620.SetUp'';',
'	:p620_token		:= 0;',
'	if :g_detalle_id is not null and :g_token is not null then -- Aprobacion con token (desde link del correo)',
'		v_log_dsc := ''Ingreso por Enlace: ID : ''||:g_detalle_id||'', TK: ''||:g_token;',
'',
'/*        -- para las compras que se crean en SAP',
'        ',
'        PK_SAP_COMPRAS_WS.SP_LOGIN(v_compania_sap,v_sesionid,v_route_id,v_response);',
'',
unistr('        -- si v_sesionid no es nulo continu\00F3 con el proceso'),
'        IF v_sesionid IS NOT NULL THEN',
'           -- inserto en las tablas de compras del grupo Zaimella todas las compras pendientes de SAP',
'           PK_SAP_COMPRAS_WS.SP_INSERTA_OC_BORRADOR_OPTIMIZADO(v_compania_sap,v_sesionid);',
'',
'           -- me desconecto de SAP',
'',
'           PK_SAP_COMPRAS_WS.SP_LOGOUT(v_sesionid,v_route_id,v_response);',
'        END IF;',
' */       ',
'		pk_corp_flujoaprobacion.sp_buscaraprobacion(:g_detalle_id,:g_token,:g_compania,v_usuarioflujo,v_tipo,:g_idnegociacion);',
'',
'		:p620_id				:= :g_idnegociacion;',
'		:p620_usuarioflujo		:= v_usuarioflujo;',
'		:p620_usuario			:= v_usuarioflujo;',
'		:p620_banderaingreso	:= 0;',
'		:p620_token				:= 1;',
'        :p620_entidadclase		:= v_tipo;',
'	else',
unistr('		v_log_dsc := ''Ingreso por Aplicaci\00F3n: Usuario: ''||:app_user;'),
'		:p620_usuario			:= :app_user;',
'		:p620_banderaingreso	:= 1;',
'	end if;',
'',
'	v_idcab := nvl(:p620_id,0);',
'',
'	if nvl(lower(:app_user),''nobody'') = ''nobody'' then',
'		:p620_banderaingreso	:= 0;',
'	end if;',
'',
'	v_log_msg := ''v_idcab: ''||v_idcab||'', v_usuarioflujo: ''||v_usuarioflujo||'', v_tipo: ''||v_tipo||'', p620_banderaingreso: ''||:p620_banderaingreso;',
'	data.pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,v_log_msg,null,null);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>415953655763075120
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(401319079450249513)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(802084039253098724)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Cabecera Compra'
,p_internal_uid=>401319079450249513
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(405192313622791329)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Rol'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_estado	varchar2(25);',
'v_compania	varchar2(5);',
'v_idmesa	number;',
'v_usuario	varchar2(25);',
'v_rol		varchar2(25);',
'v_log_app	varchar2(100);',
'v_log_dsc	varchar2(100);',
'v_log_msg	varchar2(100);',
'v_log_obs	varchar2(100);',
'v_borradorsap    number;',
'v_finalsap    number;',
'begin',
'	v_log_app	:= ''apex.130.620.Rol'';',
'	v_estado	:= nvl(:p620_estado,''INGRESADO'');',
'	v_compania	:= :p620_companiades;',
'	v_idmesa	:= :p620_id;',
'	v_usuario	:= :p620_usuario;',
'',
'	begin',
'		if v_estado = ''SOLICITADO'' then',
'			select descripcion into v_rol',
'			from t_corp_udc',
'			where id_cabecera = ''COMP_CGZ00'' and descripcion = ''ADMINISTRADOR''',
'				and (id_tabla = v_compania or id_tabla=''*'')',
'				and valor = v_usuario',
'				and rownum = 1;',
unistr('		elsif v_estado = ''GESTI\00D3N'' then'),
'			select descripcion into v_rol',
'			from t_corp_udc',
'			where id_cabecera = ''COMP_CGZ00'' and descripcion = ''COMPRADOR''',
'				and id_tabla = v_compania',
'				and valor = v_usuario',
'				and rownum = 1;',
'		else',
'			v_rol := ''USUARIO'';',
'		end if;',
'',
'		exception when others then v_rol := ''USUARIO'';',
'	end;',
'	:p620_rol := v_rol;',
'',
unistr('	-- Cuenta el n\00FAmero de l\00EDneas del detalle'),
'	select count(*) into :p620_banderadetalle	from t_comp_ordencompraextdet where idcab = v_idmesa;',
'',
unistr('	-- Cuenta el n\00FAmero de l\00EDneas del detalle con precio'),
'	select count(*) into :p620_banderaprecio	from t_comp_ordencompraextdet where idcab = v_idmesa and precio is not null;',
'',
unistr('	-- Defino la Ruta de Aprobaci\00F3n'),
'	:p620_rutactg	:= pk_comp_gestionocgrupozm.f_rutaaprobacion(:p620_companiades,:p620_catcompra,:p620_evento);',
'',
'	v_log_dsc := ''p620_estado: ''||:p620_estado||'', p620_usuario: ''||:p620_usuario||'', p620_rol: ''||:p620_rol||'', p620_rutactg: ''||:p620_rutactg;',
'	pk_commons.sp_apex_log(v_log_app,v_idmesa,v_log_dsc,v_log_msg,v_log_obs,null);',
'',
'	:p620_habilitaeventos := data.pk_comp_gestionocgrupozm.f_habilitasctg(:g_compania,:p620_catcompra);',
'',
'	if nvl(:p620_recurrente,''NO'') = ''SI'' then',
'	begin',
'		select FRECUENCIA, NUMEROPAGOS, FECHAPRIMERPAGO',
'		into :p620_pr_frecuencia, :p620_pr_numeropagos, :p620_pr_fechaprimerpago',
'		from DATA.t_comp_ordencompraextprc',
'		where 1 = 1',
'			and idcab = v_idmesa',
'			and rownum = 1;',
'',
'		exception when others then :p620_recurrente := ''NO'';',
'	end;',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>405192313622791329
);
wwv_flow_imp.component_end;
end;
/
