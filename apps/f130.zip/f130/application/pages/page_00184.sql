prompt --application/pages/page_00184
begin
--   Manifest
--     PAGE: 00184
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>184
,p_name=>'Form Gastos Estandar'
,p_step_title=>'Form Gastos Estandar'
,p_reload_on_submit=>'A'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'01'
,p_created_on=>wwv_flow_imp.dz('20230825163644Z')
,p_last_updated_on=>wwv_flow_imp.dz('20230823190116Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(92557179523941042)
,p_plug_name=>'Form Cabecera'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_read_only_when_type=>'FUNCTION_BODY'
,p_plug_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P184_ESTADO IN (''INGRESADO'',''RECHAZADO'') THEN ',
'    RETURN FALSE;',
'END IF;',
'',
'RETURN TRUE;'))
,p_plug_read_only_when2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(93009761580886633)
,p_plug_name=>'TABULAR'
,p_parent_plug_id=>wwv_flow_imp.id(92557179523941042)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P184_ID IS NOT NULL'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(93008223056886618)
,p_name=>'Valores Estandar'
,p_parent_plug_id=>wwv_flow_imp.id(93009761580886633)
,p_template=>wwv_flow_imp.id(296121421643169165)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'t-Report--stretch:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_TABFORM'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ID, IDCAB, OBJETO, MONTO, OBSERVACION',
'FROM DATA.T_CMEX_ESTANDARGASTOSDET',
'WHERE IDCAB = :P184_ID'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P184_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>30
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(93008386949886619)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_hidden_column=>'Y'
,p_display_as=>'HIDDEN'
,p_pk_col_source_type=>'T'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(93008400124886620)
,p_query_column_id=>2
,p_column_alias=>'IDCAB'
,p_column_display_sequence=>3
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_hidden_column=>'Y'
,p_display_as=>'HIDDEN'
,p_derived_column=>'N'
,p_column_default=>'P184_ID'
,p_column_default_type=>'ITEM'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(93008565739886621)
,p_query_column_id=>3
,p_column_alias=>'OBJETO'
,p_column_display_sequence=>4
,p_column_heading=>'Objeto'
,p_use_as_row_header=>'N'
,p_default_sort_column_sequence=>1
,p_display_as=>'SELECT_LIST_FROM_LOV'
,p_named_lov=>wwv_flow_imp.id(93018914532751121)
,p_lov_show_nulls=>'YES'
,p_css_classes=>'selectlist apex-item-select'
,p_cattributes=>'style = "width : 99%;"'
,p_derived_column=>'N'
,p_lov_display_extra=>'YES'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(93008624960886622)
,p_query_column_id=>4
,p_column_alias=>'MONTO'
,p_column_display_sequence=>5
,p_column_heading=>'Monto'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_display_as=>'TEXT'
,p_css_classes=>'text_field apex-item-text'
,p_cattributes=>'style = "width : 99%;"'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(93008740534886623)
,p_query_column_id=>5
,p_column_alias=>'OBSERVACION'
,p_column_display_sequence=>6
,p_column_heading=>unistr('Observaci\00F3n')
,p_use_as_row_header=>'N'
,p_display_as=>'TEXTAREA'
,p_column_height=>3
,p_css_classes=>'textarea apex-item-textarea'
,p_cattributes=>'style = "width : 99%;"'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(93008876080886624)
,p_query_column_id=>6
,p_column_alias=>'CHECK$01'
,p_column_display_sequence=>1
,p_column_heading=>'&nbsp;'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'FUNCTION_BODY'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P184_ESTADO IN (''INGRESADO'',''RECHAZADO'') THEN ',
'    RETURN TRUE;',
'END IF;',
'',
'RETURN FALSE;'))
,p_display_when_condition2=>'PLSQL'
,p_display_as=>'CHECKBOX'
,p_derived_column=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(93009600015886632)
,p_plug_name=>'BotonesTabular'
,p_parent_plug_id=>wwv_flow_imp.id(93009761580886633)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295609041229037671)
,p_plug_display_sequence=>5
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P184_ESTADO IN (''INGRESADO'',''RECHAZADO'') THEN ',
'    RETURN TRUE;',
'END IF;',
'',
'RETURN FALSE;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(93007693461886612)
,p_plug_name=>'Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(93008038029886616)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(93007693461886612)
,p_button_name=>'REGRESAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:183:&SESSION.::&DEBUG.:RP,183::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(93008910673886625)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(93009600015886632)
,p_button_name=>'AGREGAR_RUBRO'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Agregar Rubro'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.widget.tabular.addRow();'
,p_icon_css_classes=>'fa-clipboard-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(93007734986886613)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(93007693461886612)
,p_button_name=>'GUARDAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P184_ESTADO IN (''INGRESADO'',''RECHAZADO'') THEN ',
'    RETURN TRUE;',
'END IF;',
'',
'RETURN FALSE;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(93009125435886627)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(93009600015886632)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(93009402852886630)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(93009600015886632)
,p_button_name=>'DELETE_RUBRO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Eliminar Rubro Seleccionado'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-trash'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(93010019980886636)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(93007693461886612)
,p_button_name=>'ENVIAR_APROBACION'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>unistr('Enviar Aprobaci\00F3n')
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_contador NUMBER;',
'v_flujo  NUMBER;',
'BEGIN ',
'',
'SELECT COUNT(IDCAB) INTO v_contador',
'FROM DATA.T_CMEX_ESTANDARGASTOSDET',
'WHERE IDCAB = :P184_ID;',
'',
'    IF v_contador > 0 THEN ',
'',
'        IF :P184_ESTADO IN (''INGRESADO'',''RECHAZADO'') THEN ',
'            RETURN TRUE;',
'        END IF;',
'    END IF;',
'',
'RETURN FALSE ;',
'',
'',
'END;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-clipboard-arrow-up'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(93009889618886634)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(93007693461886612)
,p_button_name=>'APROBAR_FLUJO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Aprobar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_lectura NUMBER;',
'BEGIN ',
'    SELECT ',
'    pk_cmex_mesatrabajo.F_ESTANDAR_APROBACION_FLUJO(P_ID_CAB => :P184_ID, P_MODULO => ''CMEX'', P_TIPOMODULO => :P184_MODULO, P_ENTIDAD => ''CMEX_GASTOESTANDAR'', P_ETAPA => NULL, P_USUARIO => :APP_USER, P_ESTADO_BUSCAR => ''EN_PROCESO'') ',
'    INTO v_lectura',
'    FROM DUAL;',
'',
'    IF v_lectura = 1 AND :P184_ESTADO = ''EN RUTA'' THEN ',
'        RETURN TRUE;',
'    END IF;',
'',
'RETURN FALSE;',
'END;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(93009963575886635)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(93007693461886612)
,p_button_name=>'RECHAZAR_FLUJO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Rechazar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_lectura NUMBER;',
'BEGIN ',
'    SELECT ',
'    pk_cmex_mesatrabajo.F_ESTANDAR_APROBACION_FLUJO(P_ID_CAB => :P184_ID, P_MODULO => ''CMEX'', P_TIPOMODULO => :P184_MODULO, P_ENTIDAD => ''CMEX_GASTOESTANDAR'', P_ETAPA => ''ESTANDAR'', P_USUARIO => :APP_USER ,  P_ESTADO_BUSCAR => ''EN_PROCESO'' ) ',
'    INTO v_lectura',
'    FROM DUAL;',
'',
'    IF v_lectura = 1 AND :P184_ESTADO = ''EN RUTA'' THEN ',
'        RETURN TRUE;',
'    END IF;',
'',
'RETURN FALSE;',
'END;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-times-circle-o'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(93007919717886615)
,p_branch_name=>'Go To Page 184'
,p_branch_action=>'f?p=&APP_ID.:184:&SESSION.::&DEBUG.:RP,184:P184_ID:&P184_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'REQUEST_IN_CONDITION'
,p_branch_condition=>'PROCESS_GUARDAR_CAB, DELETE_RUBRO,SAVE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(93110699565453102)
,p_branch_name=>'Go To 183'
,p_branch_action=>'f?p=&APP_ID.:183:&SESSION.::&DEBUG.:RP,183::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
,p_branch_condition_type=>'REQUEST_IN_CONDITION'
,p_branch_condition=>'ENVIAR_APROBACION,APROBAR_FLUJO,RECHAZAR_FLUJO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(92557212301941043)
,p_name=>'P184_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(92557179523941042)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(92557392650941044)
,p_name=>'P184_FECHAINI'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(92557179523941042)
,p_prompt=>'Fecha Inicial'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(92557479522941045)
,p_name=>'P184_FECHAFIN'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(92557179523941042)
,p_prompt=>'Fecha Final'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(92557594060941046)
,p_name=>'P184_OBSERVACION'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(92557179523941042)
,p_prompt=>'Observacion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(92557690534941047)
,p_name=>'P184_ESTADO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(92557179523941042)
,p_item_default=>'INGRESADO'
,p_prompt=>'Estado'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(92557782746941048)
,p_name=>'P184_APROBADOR'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(92557179523941042)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(92557820378941049)
,p_name=>'P184_MODULO'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(92557179523941042)
,p_prompt=>'Modulo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT CODIGOMODULO AS D, CODIGOMODULO AS R FROM T_CMEX_MESATRABAJO',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93010979192886645)
,p_name=>'P184_ACCION'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(92557179523941042)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(93111252752453108)
,p_validation_name=>'FechaValidaInicia'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_conta NUMBER;',
'BEGIN ',
'    BEGIN ',
'        SELECT 1 INTO v_conta FROM DATA.T_CMEX_ESTANDARGASTOS',
'        WHERE :P184_FECHAINI BETWEEN FECHAINI AND FECHAFIN',
'        AND ESTADO = ''APROBADO''',
'        AND MODULO = :P184_MODULO;',
'        EXCEPTION WHEN NO_DATA_FOUND THEN',
'            v_conta := 0;',
'    END;',
'',
'    IF v_conta = 1 THEN RETURN ''Error en la definicion de la fecha, se encuentra contemplada en un esquema anterior'';',
'    END IF;',
'    ',
'   -- IF :P184_FECHAINI < SYSDATE-1 THEN  RETURN ''Error en la definicion de la fecha, menor a la fecha actual ''; END IF;',
'',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_validation_condition=>'GUARDAR,ENVIAR_APROBACION'
,p_validation_condition_type=>'REQUEST_IN_CONDITION'
,p_associated_item=>wwv_flow_imp.id(92557392650941044)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(93111361628453109)
,p_validation_name=>'FechaValidaFin'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_conta NUMBER;',
'BEGIN ',
'    BEGIN ',
'        SELECT 1 INTO v_conta FROM DATA.T_CMEX_ESTANDARGASTOS',
'        WHERE :P184_FECHAFIN BETWEEN FECHAINI AND FECHAFIN',
'        AND ESTADO = ''APROBADO''',
'        AND MODULO = :P184_MODULO;',
'        EXCEPTION WHEN NO_DATA_FOUND THEN',
'            v_conta := 0;',
'    END;',
'',
unistr('    IF v_conta = 1 THEN RETURN ''Error en la definic\00F3n de la fecha, contemplada anteriormente'';'),
'    END IF;',
'    ',
'    IF :P184_FECHAFIN < :P184_FECHAINI THEN RETURN ''Error en la definicion de la fecha, menor a la fecha inicial''; END IF;',
'',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_validation_condition=>'GUARDAR,ENVIAR_APROBACION'
,p_validation_condition_type=>'REQUEST_IN_CONDITION'
,p_associated_item=>wwv_flow_imp.id(92557479522941045)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(93010186946886637)
,p_name=>'ENVIA_APROBACION'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(93010019980886636)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(93010226144886638)
,p_event_id=>wwv_flow_imp.id(93010186946886637)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEsta seguro de realizar el envio? No podr\00E1 realizar cambios mientas se encuentre en fase de aprobaci\00F3n.')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(93010334870886639)
,p_event_id=>wwv_flow_imp.id(93010186946886637)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'ENVIAR_APROBACION'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(93011020989886646)
,p_name=>'AprobarParametro'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(93009889618886634)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(93111144895453107)
,p_event_id=>wwv_flow_imp.id(93011020989886646)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
' $("input").prop(''disabled'', false);',
' $("select").prop(''disabled'', false);',
' $("textarea").prop(''disabled'', false);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(93011144502886647)
,p_event_id=>wwv_flow_imp.id(93011020989886646)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P184_ACCION'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(93011273309886648)
,p_event_id=>wwv_flow_imp.id(93011020989886646)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'APROBAR_FLUJO'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(93011350534886649)
,p_name=>'RechazarFlujo'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(93009963575886635)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(93111097896453106)
,p_event_id=>wwv_flow_imp.id(93011350534886649)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
' $("input").prop(''disabled'', false);',
' $("select").prop(''disabled'', false);',
' $("textarea").prop(''disabled'', false);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(93011422758886650)
,p_event_id=>wwv_flow_imp.id(93011350534886649)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P184_ACCION'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(93110554043453101)
,p_event_id=>wwv_flow_imp.id(93011350534886649)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'RECHAZAR_FLUJO'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(93110822818453104)
,p_name=>'New'
,p_event_sequence=>40
,p_condition_element=>'P184_ESTADO'
,p_triggering_condition_type=>'IN_LIST'
,p_triggering_expression=>'APROBADO,EN RUTA'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(93110964772453105)
,p_event_id=>wwv_flow_imp.id(93110822818453104)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
' $("input").prop(''disabled'', true);',
' $("select").prop(''disabled'', true);',
' $("textarea").prop(''disabled'', true);'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(93026646718943589)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CargarDatos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'IF :P184_ID IS NOT NULL THEN ',
'    SELECT FECHAINI, FECHAFIN, OBSERVACION, ESTADO, APROBADOR,  MODULO',
'     INTO :P184_FECHAINI, :P184_FECHAFIN, :P184_OBSERVACION, :P184_ESTADO , :P184_APROBADOR , :P184_MODULO',
'    FROM DATA.T_CMEX_ESTANDARGASTOS WHERE ID = :P184_ID;',
'END IF;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>93026646718943589
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(93007808921886614)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'PROCESS_GUARDAR_CAB'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN ',
'DATA.pk_cmex_mesatrabajo.SP_GASTOSESTANDAR_CAB (P_ID => :P184_ID , ',
'                                                       P_FECHAINI => :P184_FECHAINI , ',
'                                                       P_FECHAFIN  => :P184_FECHAFIN , ',
'                                                       P_MODULO => :P184_MODULO , ',
'                                                       P_OBSERVACION => :P184_OBSERVACION , ',
'                                                       P_ESTADO => :P184_ESTADO );',
'END;',
'',
'IF :P184_ID IS NULL THEN ',
'',
'    SELECT MAX(ID) INTO :P184_ID FROM DATA.T_CMEX_ESTANDARGASTOS',
'    WHERE FECHAINI = :P184_FECHAINI AND FECHAFIN = :P184_FECHAFIN',
'    AND ESTADO = :P184_ESTADO AND MODULO = :P184_MODULO ;',
'',
'END IF;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(93007734986886613)
,p_internal_uid=>93007808921886614
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(93009270207886628)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(93008223056886618)
,p_process_type=>'NATIVE_TABFORM_UPDATE'
,p_process_name=>'ApplyMRU'
,p_attribute_02=>'T_CMEX_ESTANDARGASTOSDET'
,p_attribute_03=>'ID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(93009125435886627)
,p_process_success_message=>'#MRU_COUNT# filas actualizadas, #MRI_COUNT# filas insertadas'
,p_internal_uid=>93009270207886628
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(93009325569886629)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(93008223056886618)
,p_process_type=>'NATIVE_TABFORM_DELETE'
,p_process_name=>'ApplyMRD'
,p_attribute_02=>'T_CMEX_ESTANDARGASTOSDET'
,p_attribute_03=>'ID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(93009402852886630)
,p_process_success_message=>'#MRD_COUNT# registros eliminados'
,p_internal_uid=>93009325569886629
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(93010413649886640)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ENVIAR_FLUJO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN ',
'',
'    pk_cmex_mesatrabajo.SP_ENVIO_APROBACION_GASTOSEST(P_ID_CAB => :P184_ID, P_USUARIO => :APP_USER, P_MODULO => ''CMEX'', P_COMPANIA => :G_COMPANIA, P_TIPOMODULO => :P184_MODULO);',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(93010019980886636)
,p_internal_uid=>93010413649886640
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(93010860462886644)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'APROBAR_RECHAZAR_FLUJO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pk_cmex_mesatrabajo.SP_APROB_RECH_GASTOESTANDAR(P_ID_CAB => :P184_ID,',
'                                                       P_USUARIO=>:APP_USER ,',
'                                                       P_MODULO=> ''CMEX'' ,',
'                                                       P_COMPANIA=> :G_COMPANIA ,',
'                                                       P_ACCION => :P184_ACCION  --- 1 => APROBAR / 0 => RECHAZAR ',
'                                                      );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'APROBAR_FLUJO,RECHAZAR_FLUJO'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>93010860462886644
);
wwv_flow_imp.component_end;
end;
/
