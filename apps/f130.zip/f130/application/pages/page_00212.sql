prompt --application/pages/page_00212
begin
--   Manifest
--     PAGE: 00212
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>212
,p_name=>'dlgselectproveedoragrupado'
,p_alias=>'DLGSELECTPROVEEDORAGRUPADO'
,p_page_mode=>'MODAL'
,p_step_title=>'Seleccionar Proveedor Agrupado'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-table {',
'     min-width: 1500px;',
'}',
'.a-IRR-table td {',
'    padding: 0px;',
'    padding-right: 2px;',
'    padding-left: 2px;    ',
'}',
'.t-Form-inputContainer, .t-Form-labelContainer {',
'    padding: 0px;',
'    padding-left: 10px;',
'}',
'',
'.container{',
'    background: lightskyblue;',
'}'))
,p_page_css_classes=>'panelAgrupado'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240521202504Z')
,p_last_updated_on=>wwv_flow_imp.dz('20250529192103Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(288154423247909986)
,p_plug_name=>'Negociaciones'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>130
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    NEG_ID, ',
'    CAB_ID, ',
'    DET_ID, ',
'    NEG_TIPO, ',
'    NEG_ESQUEMA, ',
'    NEG_CODESQUEMA, ',
'    NEG_RECURRENTE, ',
'    NEG_PERIODICIDAD, ',
'    det_VIGENTE VIGENTE, ',
'    NEG_ESTADOFLUJO, ',
'    CAB_ESCALA, ',
'    CAB_ACUMULA, ',
'    CAB_TIPOPRECIO, ',
'    CAB_FORMULA, ',
'    DET_CODPRODUCTO, ',
'    ',
'    DET_CODPROVEEDOR, ',
'    DET_CODPROVEEDOR DET_CODPROVEEDOR_SELECT,',
'    ',
'    DET_CODPRODUCTOPRV || '' -'' || DET_DESPRODUCTOPRV || '' -'' || DET_UMPRODUCTOPRV',
'                AS PROD_PROVEEDOR,',
'                ',
'    DET_TIEMPOENTREGA, ',
'    DET_FORMAPAGO, ',
'    DET_INCOTERM, ',
'    DET_CANTDESDE, ',
'    DET_CANTHASTA, ',
'    DET_PRECIO,',
'    ',
'    CASE ',
'        WHEN DET_PRECIO = 0    THEN ''<span title="Seleccionar ESTE Proveedor" class="fa fa-times-circle" style="color: red;"/>''',
'        WHEN NEG_TIPO   = ''FJ'' THEN ''<span title="Seleccionar ESTE Proveedor" class="fa fa-hand-o-right" style="color: darkgreen;"/>''',
'            WHEN NEG_TIPO = ''ES'' THEN',
'                CASE ',
'                    WHEN :P212_CANTIDAD BETWEEN DET_CANTDESDE AND DET_CANTHASTA THEN ''<span title="Seleccionar ESTE Proveedor" class="fa fa-hand-o-right" style="color: darkblue;"/>''',
'                    ELSE ''<span title="Fuerad de escala" class="fa fa-times-circle" style="color: red;"/>''',
'                END',
'        ELSE '' ''',
'    END AS ICONO_SELECCIONAR,',
'    ',
'    CASE ',
'        WHEN DET_PRECIO = 0    THEN ''style="color: red;"''',
'        WHEN NEG_TIPO   = ''FJ'' THEN ''style="color: green;"''',
'            WHEN NEG_TIPO = ''ES'' THEN',
'                CASE ',
'                    WHEN :P212_CANTIDAD BETWEEN DET_CANTDESDE AND DET_CANTHASTA THEN ''style="color: blue;"''',
'                    ELSE ''style="color: orange;"''',
'                END',
'        ELSE '' ''        ',
'    END AS COLOR_PRECIO,',
'',
'    CASE ',
unistr('        WHEN DET_PRECIO = 0    THEN ''JavaScript:alert("Revisar los \00EDndices o f\00F3rmulas de las negociacaciones.");'''),
'        WHEN NEG_TIPO   = ''FJ'' THEN ''JavaScript:$s("P212_DET_ID_SELECCIONADO", "");$s("P212_DET_ID_SELECCIONADO",''||DET_ID||'');''',
'        WHEN NEG_TIPO   = ''FM'' THEN ''JavaScript:$s("P212_DET_ID_SELECCIONADO", "");$s("P212_DET_ID_SELECCIONADO",''||DET_ID||'');''        ',
'        WHEN NEG_TIPO   = ''ES'' THEN',
'            CASE ',
'                WHEN :P212_CANTIDAD BETWEEN DET_CANTDESDE AND DET_CANTHASTA THEN ''JavaScript:$s("P212_DET_ID_SELECCIONADO", "");$s("P212_DET_ID_SELECCIONADO",''||DET_ID||'');''',
'                ELSE ''JavaScript:alert("Fuera de escala.");''',
'            END',
'        ELSE '' ''',
'    END AS ACCION_JAVASCRIPT   ',
'',
'FROM ',
'    vt_comp_negociacionsel',
'WHERE ',
'    DET_CODPRODUCTO=:P212_CODIGOCORTOPRODUCTO',
'        AND    ',
'    det_VIGENTE=''SI'' ',
'        AND     ',
'    NEG_ESTADOFLUJO=''APROBADO''  -- SOLO VIGENTES Y APROBADAS',
'        AND',
'    (',
'        (:P212_RESERVA=1 AND DET_PUEDERESERVAR=1)',
'            OR',
'        :P212_RESERVA=0',
'    )',
';        ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Negociaciones'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SI algunos precios tienen valor ',
unistr('<span style="color: red; font-weight: 900;">CERO ($0.0000) </span>. Entonces revisar los \00EDndices o f\00F3rmulas de las negociacaciones.')))
,p_updated_on=>wwv_flow_imp.dz('20250529192103Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(288154539283909987)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>288154539283909987
,p_updated_on=>wwv_flow_imp.dz('20250529192103Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200242939045153725)
,p_db_column_name=>'ICONO_SELECCIONAR'
,p_display_order=>10
,p_column_identifier=>'AA'
,p_column_label=>'.'
,p_column_link=>'#ACCION_JAVASCRIPT#'
,p_column_linktext=>'#ICONO_SELECCIONAR#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200233764972153717)
,p_db_column_name=>'NEG_ID'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Neg Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200234133343153717)
,p_db_column_name=>'CAB_ID'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Cab Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200234586305153718)
,p_db_column_name=>'DET_ID'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Det Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200234995628153718)
,p_db_column_name=>'NEG_TIPO'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(134249042425086839)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200235389887153719)
,p_db_column_name=>'NEG_ESQUEMA'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Esquema'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(134249283510088347)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200235787208153719)
,p_db_column_name=>'NEG_CODESQUEMA'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'Neg Codesquema'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200236185430153719)
,p_db_column_name=>'NEG_RECURRENTE'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Recurr.'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(134249933350095820)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200236536024153720)
,p_db_column_name=>'NEG_PERIODICIDAD'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'Period.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200236930211153720)
,p_db_column_name=>'VIGENTE'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Vigente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200237375055153720)
,p_db_column_name=>'NEG_ESTADOFLUJO'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200237722382153721)
,p_db_column_name=>'CAB_ESCALA'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'Cab Escala'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200238194887153721)
,p_db_column_name=>'CAB_ACUMULA'
,p_display_order=>130
,p_column_identifier=>'L'
,p_column_label=>'Acum.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200238513683153721)
,p_db_column_name=>'CAB_TIPOPRECIO'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>'Tipo Precio'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(134248652638070866)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200238904941153721)
,p_db_column_name=>'CAB_FORMULA'
,p_display_order=>150
,p_column_identifier=>'N'
,p_column_label=>'Cab Formula'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200239314040153722)
,p_db_column_name=>'DET_CODPRODUCTO'
,p_display_order=>160
,p_column_identifier=>'O'
,p_column_label=>'Det Codproducto'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200239772582153722)
,p_db_column_name=>'DET_CODPROVEEDOR'
,p_display_order=>170
,p_column_identifier=>'P'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200242583429153724)
,p_db_column_name=>'PROD_PROVEEDOR'
,p_display_order=>180
,p_column_identifier=>'Z'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200240198343153722)
,p_db_column_name=>'DET_TIEMPOENTREGA'
,p_display_order=>190
,p_column_identifier=>'T'
,p_column_label=>'Tiempo Ent.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200240555516153722)
,p_db_column_name=>'DET_FORMAPAGO'
,p_display_order=>200
,p_column_identifier=>'U'
,p_column_label=>'Forma Pago'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(134250431110099274)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200240954518153722)
,p_db_column_name=>'DET_INCOTERM'
,p_display_order=>210
,p_column_identifier=>'V'
,p_column_label=>'INCOTERM'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200241369487153723)
,p_db_column_name=>'DET_CANTDESDE'
,p_display_order=>220
,p_column_identifier=>'W'
,p_column_label=>'Cant. Desde'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200241784883153723)
,p_db_column_name=>'DET_CANTHASTA'
,p_display_order=>230
,p_column_identifier=>'X'
,p_column_label=>'Cant. Hasta'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200242137665153723)
,p_db_column_name=>'DET_PRECIO'
,p_display_order=>240
,p_column_identifier=>'Y'
,p_column_label=>'Precio'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span #COLOR_PRECIO#>',
'    #DET_PRECIO#',
'</span>'))
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200243343854153725)
,p_db_column_name=>'DET_CODPROVEEDOR_SELECT'
,p_display_order=>250
,p_column_identifier=>'AB'
,p_column_label=>'Det Codproveedor Select'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200243716875153725)
,p_db_column_name=>'COLOR_PRECIO'
,p_display_order=>260
,p_column_identifier=>'AC'
,p_column_label=>'Color Precio'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200244149330153725)
,p_db_column_name=>'ACCION_JAVASCRIPT'
,p_display_order=>270
,p_column_identifier=>'AD'
,p_column_label=>'Accion Javascript'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(288601733227212481)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'883687'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ICONO_SELECCIONAR:DET_CODPROVEEDOR:NEG_TIPO:NEG_ESQUEMA:NEG_RECURRENTE:NEG_PERIODICIDAD:CAB_ACUMULA:CAB_TIPOPRECIO:DET_TIEMPOENTREGA:DET_FORMAPAGO:DET_INCOTERM:DET_CANTDESDE:DET_CANTHASTA:DET_PRECIO:PROD_PROVEEDOR:NEG_ESTADOFLUJO:VIGENTE:'
,p_sort_column_1=>'DET_PRECIO'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20240521202504Z')
,p_updated_on=>wwv_flow_imp.dz('20240521202504Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(288686314992400186)
,p_plug_name=>'Proveedor Actual'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>120
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P212_PROVEEDOR_ID_PRE_SEL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(373474423507874982)
,p_plug_name=>'Mensaje Reserva'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>140
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span style="color:green;">',
'*Solo se listan negociaciones adecuadas para una compra tipo RESERVA.',
'</span>'))
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P212_RESERVA'
,p_plug_display_when_cond2=>'1'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(200245403940153736)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(288686314992400186)
,p_button_name=>'ELIMINAR_PROVEEDOR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Dejar sin Proveedor'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(200253144439153762)
,p_branch_name=>'SET SALTO'
,p_branch_action=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.::P201_SALTAR_SELECT_PROVEEDOR:1#idSeccionSeguimientos&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(200245403940153736)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200245824280153737)
,p_name=>'P212_PROVEEDOR_ID_PRE_SEL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(288686314992400186)
,p_prompt=>'Proveedor Actual'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_JDE_LIBRODIRECCIONES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DISTINCT nombres as r,',
'       codigo as d',
'  from VT_JDE_LIBRODIRECCIONES',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200246606515153755)
,p_name=>'P212_DET_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200247076725153755)
,p_name=>'P212_DET_ID_SELECCIONADO'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200247438207153755)
,p_name=>'P212_RESERVA'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200247871574153755)
,p_name=>'P212_CODIGOCORTOPRODUCTO'
,p_item_sequence=>60
,p_prompt=>unistr('C\00F3d. Prod.')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200248212561153756)
,p_name=>'P212_CANTIDAD'
,p_item_sequence=>70
,p_prompt=>'Cantidad'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200248643123153756)
,p_name=>'P212_UNIDADMEDIDA'
,p_item_sequence=>80
,p_prompt=>'UM'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200249031560153756)
,p_name=>'P212_PRODUCTO'
,p_item_sequence=>90
,p_prompt=>'Producto'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200249401477153756)
,p_name=>'P212_DESCRIPCION'
,p_item_sequence=>110
,p_prompt=>unistr('Descripci\00F3n')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(200250297375153759)
,p_name=>'Eliminar proveedor'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(200245403940153736)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(200250771267153759)
,p_event_id=>wwv_flow_imp.id(200250297375153759)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_COMP_GESTIONCOMPRAS.SP_DEL_GRUPO_PPGESTION_NEGCION(:P212_CODIGOCORTOPRODUCTO, :APP_USER, :G_COMPANIA);',
''))
,p_attribute_02=>'P212_CODIGOCORTOPRODUCTO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(200251207979153760)
,p_event_id=>wwv_flow_imp.id(200250297375153759)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(200251634792153760)
,p_name=>'ON PROVEEDOR SELECCIONADO'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P212_DET_ID_SELECCIONADO'
,p_condition_element=>'P212_DET_ID_SELECCIONADO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(200252688571153761)
,p_event_id=>wwv_flow_imp.id(200251634792153760)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_COMP_GESTIONCOMPRAS.SP_SET_GRUPO_PPGESTION_NEGCION (',
'    :P212_CODIGOCORTOPRODUCTO, ',
'    :P212_DET_ID_SELECCIONADO,',
'    :APP_USER,',
'    :G_COMPANIA',
');'))
,p_attribute_02=>'P212_DET_ID_SELECCIONADO, P212_CODIGOCORTOPRODUCTO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(200252137197153760)
,p_event_id=>wwv_flow_imp.id(200251634792153760)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(200249867503153757)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('-- INFORMACI\00D3N DEL PRODUCTO'),
'SELECT',
'    IMDSC1, ',
'    IMLITM||'' - ''||IMDSC1||'' - ''||IMUOM3, ',
'    IMUOM3',
'INTO',
'    :P212_PRODUCTO,',
'    :P212_DESCRIPCION,',
'    :P212_UNIDADMEDIDA    ',
'FROM ',
'    F4101@JDEDTADL           PRODUCTO',
'WHERE ',
'    IMITM=:P212_CODIGOCORTOPRODUCTO',
';    ',
'',
unistr('-- PARA SABER SI ESTA L\00CDNEA TIENE UN PROVEEDOR PRE-SELECCIONADO'),
':P212_PROVEEDOR_ID_PRE_SEL := NULL;',
'IF :P212_DET_ID IS NOT NULL THEN',
'    SELECT ',
'        DET_CODPROVEEDOR',
'    INTO ',
'        :P212_PROVEEDOR_ID_PRE_SEL     ',
'    FROM vt_comp_negociacionsel',
'    WHERE DET_ID = :P212_DET_ID;',
'END IF',
';    ',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>200249867503153757
,p_updated_on=>wwv_flow_imp.dz('20250529191838Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
