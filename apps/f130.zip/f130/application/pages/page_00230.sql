prompt --application/pages/page_00230
begin
--   Manifest
--     PAGE: 00230
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>230
,p_name=>'Devoluciones MP Notas Credito'
,p_alias=>'DEVOLUCIONES-MP-NOTAS-CREDITO1'
,p_step_title=>'Devoluciones MP Notas Credito'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20250221161023Z')
,p_last_updated_on=>wwv_flow_imp.dz('20250227181152Z')
,p_last_updated_by=>'FGUEVARA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1215658481476985218)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1425464956304040629)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1425465063130040630)
,p_plug_name=>'O4s'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CASE WHEN ESTADO_COMPRAS IN (''PENDIENTE REVISAR'',''POR NOTIFICAR APR'',''POR NOTIFICAR RCHZ'')',
'        THEN ''<span title="Ir al detalle" class="fa fa-pencil"></span>''',
'    END                   AS ICONO_LINK, ',
'',
'    INFORME_NUMERO        AS INFORME_NUMERO, ',
'    TO_CHAR(INFORME_ENV_PROVEEDOR, ''DD/MM/YYYY HH24:MI'')',
'                          AS INFORME_ENV_PROVEEDOR,',
'    PRODUCTO_NOMBRE       AS PRODUCTO_NOMBRE, ',
'    PROVEEDOR_CODIGO      AS PROVEEDOR_CODIGO, ',
'    O4_NUMERO             AS O4_NUMERO, ',
'    O4_FECHA              AS O4_FECHA, ',
'    PESO_BRUTO            AS PESO_BRUTO, ',
'',
'    UNIDAD_MEDIDA         AS UNIDAD_MEDIDA,',
'    UNIDAD_DESPACHO       AS UNIDAD_DESPACHO,',
'    CANTIDAD_UND_DESPACHO AS CANTIDAD_UND_DESPACHO,',
'',
'    SUBSTR(NOTA_CREDITO_MP, 25, 3)||''-''||SUBSTR(NOTA_CREDITO_MP, 28, 3)||''-''||SUBSTR(NOTA_CREDITO_MP, 31, 9)',
'                          AS NOTA_CREDITO_MP, ',
'    SUBSTR(NOTA_CREDITO_FEE, 25, 3)||''-''||SUBSTR(NOTA_CREDITO_FEE, 28, 3)||''-''||SUBSTR(NOTA_CREDITO_FEE, 31, 9)',
'                          AS NOTA_CREDITO_FEE, ',
'    TO_CHAR(FECHA_NOTIF_COMPRAS, ''DD/MM/YYYY HH24:MI'')',
'                          AS FECHA_NOTIF_COMPRAS, ',
'    TO_CHAR(FECHA_NOTIF_PROVEEDOR, ''DD/MM/YYYY HH24:MI'')',
'                          AS FECHA_NOTIF_PROVEEDOR,',
'    FECHA_APROBADO        AS FECHA_APROBADO, ',
'    FECHA_RECHAZADO       AS FECHA_RECHAZADO, ',
'    OBSERVACION           AS OBSERVACION, ',
'    CODIGOCORTOPRODUCTO   AS CODIGOCORTOPRODUCTO,',
'    --------------------------------',
'    ESTADO_COMPRAS        AS ESTADO,',
'    CASE',
'        WHEN FECHA_APROBADO  IS NOT NULL THEN ''SI''',
'        WHEN FECHA_RECHAZADO IS NOT NULL THEN ''NO''',
'        ELSE ''-''',
'    END                   AS APROBADO',
'',
'FROM ',
'    VT_EXTE_DEVOLUCION_MESA_PROVDR',
'WHERE',
'   INFORME_ESTADO not in (''0'', ''6'', ''7'') and ',
'    PROVEEDOR_CODIGO = :P230_PROVEEDOR',
'        AND ',
'    O4_FECHA BETWEEN TO_DATE(:P230_FECHA_DESDE, ''DD/MM/YYYY'') AND TO_DATE(:P230_FECHA_HASTA, ''DD/MM/YYYY'')',
'        AND',
'    (',
'        (:P230_GRUPO = ''0'' OR :P230_GRUPO IS NULL)',
'            OR',
'        (:P230_GRUPO = ''1'' AND ESTADO_COMPRAS IN (''PENDIENTE REVISAR'',''POR NOTIFICAR APR'',''POR NOTIFICAR RCHZ''))',
'            OR',
'        (:P230_GRUPO = ''2'' AND ESTADO_COMPRAS IN (''NOTIFICADO APROBADO'',''NOTIFICADO RECHAZADO'', ''NOTIFICADO''))',
'    )	',
';'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'O4s'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20250227181152Z')
,p_updated_by=>'FGUEVARA'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1425465134830040631)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>1425465134830040631
,p_updated_on=>wwv_flow_imp.dz('20250227181152Z')
,p_updated_by=>'FGUEVARA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(522233977350715465)
,p_db_column_name=>'ICONO_LINK'
,p_display_order=>10
,p_column_identifier=>'R'
,p_column_label=>'.'
,p_column_link=>'f?p=&APP_ID.:226:&SESSION.::&DEBUG.:226:P226_O4_NUMERO,P226_CODIGOCORTOPRODUCTO:#O4_NUMERO#,#CODIGOCORTOPRODUCTO#'
,p_column_linktext=>'#ICONO_LINK#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(522228709801715463)
,p_db_column_name=>'O4_NUMERO'
,p_display_order=>20
,p_column_identifier=>'D'
,p_column_label=>'O4'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(522227526669715462)
,p_db_column_name=>'INFORME_NUMERO'
,p_display_order=>30
,p_column_identifier=>'A'
,p_column_label=>unistr('Inf. N\00FAm.')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(522235185705715466)
,p_db_column_name=>'INFORME_ENV_PROVEEDOR'
,p_display_order=>40
,p_column_identifier=>'X'
,p_column_label=>'Inf. Enviado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(522229139911715463)
,p_db_column_name=>'O4_FECHA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'O4 Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(522227968206715462)
,p_db_column_name=>'PRODUCTO_NOMBRE'
,p_display_order=>60
,p_column_identifier=>'B'
,p_column_label=>'Materia Prima'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(522229993357715464)
,p_db_column_name=>'NOTA_CREDITO_MP'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'N. C. MP'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(522230380004715464)
,p_db_column_name=>'NOTA_CREDITO_FEE'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'N. C. Fee'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(522230755219715464)
,p_db_column_name=>'FECHA_APROBADO'
,p_display_order=>90
,p_column_identifier=>'J'
,p_column_label=>'F. Aprobado'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(522231175596715464)
,p_db_column_name=>'FECHA_RECHAZADO'
,p_display_order=>100
,p_column_identifier=>'K'
,p_column_label=>'F. Rechazado'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(522231552896715464)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>110
,p_column_identifier=>'L'
,p_column_label=>unistr('Observaci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(522231983250715464)
,p_db_column_name=>'ESTADO'
,p_display_order=>120
,p_column_identifier=>'M'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(522229570844715463)
,p_db_column_name=>'PESO_BRUTO'
,p_display_order=>140
,p_column_identifier=>'F'
,p_column_label=>'Peso'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(522228398226715463)
,p_db_column_name=>'PROVEEDOR_CODIGO'
,p_display_order=>150
,p_column_identifier=>'C'
,p_column_label=>'Proveedor Codigo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(522232312190715465)
,p_db_column_name=>'UNIDAD_MEDIDA'
,p_display_order=>160
,p_column_identifier=>'N'
,p_column_label=>'Und. Med.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(522232730721715465)
,p_db_column_name=>'UNIDAD_DESPACHO'
,p_display_order=>170
,p_column_identifier=>'O'
,p_column_label=>'Und. Etq.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(522233124296715465)
,p_db_column_name=>'CANTIDAD_UND_DESPACHO'
,p_display_order=>180
,p_column_identifier=>'P'
,p_column_label=>'Cant. Und. Etq.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(522233584791715465)
,p_db_column_name=>'APROBADO'
,p_display_order=>190
,p_column_identifier=>'Q'
,p_column_label=>'Aprobado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(522227149630715461)
,p_db_column_name=>'CODIGOCORTOPRODUCTO'
,p_display_order=>200
,p_column_identifier=>'S'
,p_column_label=>'Codigocortoproducto'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(522234397768715466)
,p_db_column_name=>'FECHA_NOTIF_COMPRAS'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Notif a Comp'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(522234759856715466)
,p_db_column_name=>'FECHA_NOTIF_PROVEEDOR'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Notif. al Prvdr.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1438521504509303479)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'4565517'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ICONO_LINK:O4_NUMERO:INFORME_NUMERO:INFORME_ENV_PROVEEDOR:PRODUCTO_NOMBRE:NOTA_CREDITO_MP:NOTA_CREDITO_FEE:ESTADO:FECHA_NOTIF_PROVEEDOR:PESO_BRUTO:UNIDAD_DESPACHO:CANTIDAD_UND_DESPACHO:'
,p_created_on=>wwv_flow_imp.dz('20250221161023Z')
,p_updated_on=>wwv_flow_imp.dz('20250221161023Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(522226040363715458)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1425464956304040629)
,p_button_name=>'NOTIFICAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Notificar'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-send'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(522226417224715459)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1425464956304040629)
,p_button_name=>'Buscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Buscar'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(522224163908715456)
,p_name=>'P230_PROVEEDOR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1215658481476985218)
,p_prompt=>'Proveedor'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'SELECT CODIGOPROVEEDOR||'' ''||DESCRIPCION, CODIGOPROVEEDOR fROM VT_JDE_MAESTROPROVEEDOR'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(522224521915715457)
,p_name=>'P230_GRUPO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1215658481476985218)
,p_prompt=>'Grupo'
,p_source=>'1'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:TODAS;0,PENDIENTES;1,NOTIFICADAS;2'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(522224972103715457)
,p_name=>'P230_FECHA_DESDE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1215658481476985218)
,p_item_default=>'trunc(ADD_MONTHS(trunc(sysdate),-1),''MONTH'') '
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Desde'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'STATIC'
,p_attribute_07=>'+0d'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:NUMBER-OF-MONTH'
,p_attribute_13=>'HIDDEN'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(522225365988715457)
,p_name=>'P230_FECHA_HASTA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1215658481476985218)
,p_item_default=>'trunc(sysdate)'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Hasta'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'STATIC'
,p_attribute_07=>'+0d'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:NUMBER-OF-MONTH'
,p_attribute_13=>'HIDDEN'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(522236209076715471)
,p_validation_name=>'NOTIFICAR'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    V_COUNT NUMBER;',
'BEGIN',
'    SELECT COUNT(1)  INTO V_COUNT',
'    FROM   VT_EXTE_DEVOLUCION_MESA_PROVDR',
'    WHERE',
'        PROVEEDOR_CODIGO = :P230_PROVEEDOR',
'            AND',
'               INFORME_ESTADO not in (''0'', ''6'', ''7'') and ',
'        ESTADO_COMPRAS IN (''POR NOTIFICAR APR'',''POR NOTIFICAR RCHZ'');',
'    IF V_COUNT = 0 THEN',
'        RETURN ''Nada pendiente por notificar'';',
'    END IF;',
'END;',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(522226040363715458)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
,p_updated_on=>wwv_flow_imp.dz('20250227181152Z')
,p_updated_by=>'FGUEVARA'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(522236815844715472)
,p_name=>'Buscar'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P230_FECHA_DESDE,P230_FECHA_HASTA,P230_PROVEEDOR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(522237288691715473)
,p_name=>'Notificar'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(522226040363715458)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(522237775713715473)
,p_event_id=>wwv_flow_imp.id(522237288691715473)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Enviar todos los pendientes de notificar a los PROVEEDORES ?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(522238267417715474)
,p_event_id=>wwv_flow_imp.id(522237288691715473)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'NOTIFICAR'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(522236404295715472)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'NOTIFICAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_EXTE_GESTION_DEVOLUCION.SP_COMPRAS_NOTIFICA_NCS(',
'    :P230_PROVEEDOR',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(522226040363715458)
,p_internal_uid=>522236404295715472
);
wwv_flow_imp.component_end;
end;
/
