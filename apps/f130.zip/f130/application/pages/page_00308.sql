prompt --application/pages/page_00308
begin
--   Manifest
--     PAGE: 00308
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>308
,p_name=>'Anticipos'
,p_alias=>'ANTICIPOS'
,p_step_title=>'Anticipos'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function to_Number(v) {',
'  v = v.replace(/[^0-9.,-]/g, '''');',
'  if (v.indexOf('','') > -1 && v.indexOf(''.'') > -1) {',
unistr('    // europeo: 9.999.999,99 \00BF eliminar puntos, cambiar coma por punto'),
'    return parseFloat(v.replace(/\./g, '''').replace('','', ''.''));',
'  } else if (v.indexOf('','') > -1) {',
unistr('    // solo coma: 99,87 \00BF cambiar coma por punto'),
'    return parseFloat(v.replace('','', ''.''));',
'  } else {',
unistr('    // solo puntos o limpio: 99.87 \00BF parse tal cual'),
'    return parseFloat(v);',
'  }',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(regOcultos).hide();',
'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'02'
,p_created_on=>wwv_flow_imp.dz('20250625173510Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260213173105Z')
,p_created_by=>'DDELACRUZ'
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(82754790764302404)
,p_plug_name=>'Ocultos'
,p_region_name=>'regOcultos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>130
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250625173704Z')
,p_updated_on=>wwv_flow_imp.dz('20250717194905Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(94660177766207242)
,p_plug_name=>unistr('Aprobaci\00F3n')
,p_parent_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250709060022Z')
,p_updated_on=>wwv_flow_imp.dz('20250709060022Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(82806930007416210)
,p_plug_name=>'Anticipos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>30
,p_query_type=>'TABLE'
,p_query_table=>'T_COMP_ANTICIPOSCAB'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_read_only_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_plug_read_only_when=>'P308_ESTADO'
,p_plug_read_only_when2=>'INGRESADO'
,p_created_on=>wwv_flow_imp.dz('20250625173511Z')
,p_updated_on=>wwv_flow_imp.dz('20250709054759Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(97153388103731618)
,p_plug_name=>'Alerta'
,p_parent_plug_id=>wwv_flow_imp.id(82806930007416210)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(295605160997037667)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>unistr('<p><strong>Se debe registrar \00FAnicamente el porcentaje o el monto correspondiente a cada pago. Si se ingresan ambos valores, el sistema priorizar\00E1 el porcentaje.</strong></p>')
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250709163515Z')
,p_updated_on=>wwv_flow_imp.dz('20250717212250Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(95595174073145230)
,p_plug_name=>'Detalle Editable'
,p_region_name=>'regDetalleEditable'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>80
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select x.*',
'	, case',
'		when x.estado = ''PAGADO'' then null',
'		when x.estado in ''PENDIENTE'' and x.fechapago is not null and (nvl(x.porcentaje,0) > 0 or nvl(x.monto,0) > 0)',
unistr('			-- then ''<span class="fa fa-check" aria-hidden="true" style="color: #ff0000; cursor: pointer;" title="Solicitar Aprobaci\00F3n"></span>'''),
unistr('			then ''<span class="fa fa-check confirmar-aprobacion" data-id="'' || x.id || ''" aria-hidden="true" style="color: #ff0000; cursor: pointer;" title="Solicitar Aprobaci\00F3n"></span>'''),
'		end confirmarpago',
'from data.t_comp_anticiposdet x',
'where x.idcab = :p308_id'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P308_ID'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':p308_id is not null and :p308_estado in (''INGRESADO'',''APROBADO'') AND 1 = 2'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_created_on=>wwv_flow_imp.dz('20250708141117Z')
,p_updated_on=>wwv_flow_imp.dz('20250716204047Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(95595317926145232)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20250708142034Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(95595449981145233)
,p_name=>'USERCREA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'USERCREA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20250708141741Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(95595560349145234)
,p_name=>'FECHCREA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHCREA'
,p_data_type=>'TIMESTAMP'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>50
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20250708141741Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(95595650244145235)
,p_name=>'USERMODI'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'USERMODI'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>60
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20250708141741Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(95595713066145236)
,p_name=>'FECHMODI'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHMODI'
,p_data_type=>'TIMESTAMP'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>70
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20250708141741Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(95595876115145237)
,p_name=>'IDCAB'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IDCAB'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>80
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20250708141741Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(95595916410145238)
,p_name=>'IDODC'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IDODC'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>90
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20250708141741Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(95596029643145239)
,p_name=>'IDPAGO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IDPAGO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'ID Pago'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>100
,p_value_alignment=>'CENTER'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20250708142034Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(95596192755145240)
,p_name=>'FECHAPAGO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHAPAGO'
,p_data_type=>'DATE'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER_APEX'
,p_heading=>'Fecha Pago'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>110
,p_value_alignment=>'CENTER'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'ITEM'
,p_attribute_05=>'P308_FECHAMIN'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'TODAY-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20250714183746Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(95596265356145241)
,p_name=>'PORCENTAJE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PORCENTAJE'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'% Pago'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>120
,p_value_alignment=>'CENTER'
,p_attribute_01=>'0'
,p_attribute_02=>'100'
,p_attribute_03=>'right'
,p_attribute_04=>'decimal'
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20250708142156Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(95596336893145242)
,p_name=>'MONTO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MONTO'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Monto'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>130
,p_value_alignment=>'RIGHT'
,p_attribute_01=>'0'
,p_attribute_03=>'right'
,p_attribute_04=>'decimal'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20250708143347Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(95596496273145243)
,p_name=>'MONTOPAGADO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MONTOPAGADO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>140
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20250708141741Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(95596581380145244)
,p_name=>'ESTADO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ESTADO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Estado'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>150
,p_value_alignment=>'CENTER'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20250708142156Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(95596615649145245)
,p_name=>'OBSERVACIONINI'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OBSERVACIONINI'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>unistr('Observaci\00F3n*')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>160
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>500
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20250708142156Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(95596744168145246)
,p_name=>'OBSERVACIONFIN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OBSERVACIONFIN'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>170
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20250708141741Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(95596832749145247)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>'1 = 2'
,p_display_condition2=>'PLSQL'
,p_updated_on=>wwv_flow_imp.dz('20250708141742Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(95596907214145248)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'Y'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>'1 = 2'
,p_display_condition2=>'PLSQL'
,p_updated_on=>wwv_flow_imp.dz('20250708141742Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(103815900100660211)
,p_name=>'CONFIRMARPAGO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CONFIRMARPAGO'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_LINK'
,p_heading=>'-'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>180
,p_value_alignment=>'CENTER'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_include_in_export=>false
,p_escape_on_http_output=>false
,p_updated_on=>wwv_flow_imp.dz('20250715170113Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(95595215960145231)
,p_internal_uid=>95595215960145231
,p_is_editable=>true
,p_edit_operations=>'u'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>false
,p_fixed_row_height=>false
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:ACTIONS_MENU:RESET:SAVE'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>true
,p_download_formats=>'XLSX'
,p_enable_mail_download=>false
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_updated_on=>wwv_flow_imp.dz('20250715164644Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(97057945350585593)
,p_interactive_grid_id=>wwv_flow_imp.id(95595215960145231)
,p_static_id=>'970580'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
,p_updated_on=>wwv_flow_imp.dz('20250714182801Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(97058129682585594)
,p_report_id=>wwv_flow_imp.id(97057945350585593)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(97058613515585596)
,p_view_id=>wwv_flow_imp.id(97058129682585594)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(95595317926145232)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(97059531641585602)
,p_view_id=>wwv_flow_imp.id(97058129682585594)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(95595449981145233)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(97060435545585607)
,p_view_id=>wwv_flow_imp.id(97058129682585594)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(95595560349145234)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(97061378490585612)
,p_view_id=>wwv_flow_imp.id(97058129682585594)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(95595650244145235)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(97062212811585619)
,p_view_id=>wwv_flow_imp.id(97058129682585594)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(95595713066145236)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(97063130618585624)
,p_view_id=>wwv_flow_imp.id(97058129682585594)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(95595876115145237)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(97064006459585630)
,p_view_id=>wwv_flow_imp.id(97058129682585594)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(95595916410145238)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(97064923484585635)
,p_view_id=>wwv_flow_imp.id(97058129682585594)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(95596029643145239)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>75
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(97065811730585640)
,p_view_id=>wwv_flow_imp.id(97058129682585594)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(95596192755145240)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>150
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(97066710105585645)
,p_view_id=>wwv_flow_imp.id(97058129682585594)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(95596265356145241)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>150
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(97067664200585651)
,p_view_id=>wwv_flow_imp.id(97058129682585594)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(95596336893145242)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>150
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(97068546888585656)
,p_view_id=>wwv_flow_imp.id(97058129682585594)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(95596496273145243)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(97069470062585661)
,p_view_id=>wwv_flow_imp.id(97058129682585594)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(95596581380145244)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>150
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(97070213493585666)
,p_view_id=>wwv_flow_imp.id(97058129682585594)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(95596615649145245)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(97071150317585671)
,p_view_id=>wwv_flow_imp.id(97058129682585594)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(95596744168145246)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(97096471704612086)
,p_view_id=>wwv_flow_imp.id(97058129682585594)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(95596832749145247)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(104173802732815086)
,p_view_id=>wwv_flow_imp.id(97058129682585594)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(103815900100660211)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>50
);
wwv_flow_imp_page.create_ig_report_aggregate(
 p_id=>wwv_flow_imp.id(77090000001)
,p_view_id=>wwv_flow_imp.id(97058129682585594)
,p_function=>'SUM'
,p_column_id=>wwv_flow_imp.id(95596336893145242)
,p_show_grand_total=>false
,p_is_enabled=>true
);
wwv_flow_imp_page.create_ig_report_aggregate(
 p_id=>wwv_flow_imp.id(210179000001)
,p_view_id=>wwv_flow_imp.id(97058129682585594)
,p_function=>'SUM'
,p_column_id=>wwv_flow_imp.id(95596265356145241)
,p_show_grand_total=>true
,p_is_enabled=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(103816976881660221)
,p_plug_name=>'Datos de Pagos'
,p_title=>'Nuevo'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size480x320'
,p_plug_template=>wwv_flow_imp.id(295627185797037684)
,p_plug_display_sequence=>60
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P308_BANDERADET'
,p_plug_display_when_cond2=>'1'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250715172353Z')
,p_updated_on=>wwv_flow_imp.dz('20250717202539Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(106673202105649413)
,p_plug_name=>'botonesDet'
,p_region_name=>'secBotonesDet'
,p_parent_plug_id=>wwv_flow_imp.id(103816976881660221)
,p_region_template_options=>'#DEFAULT#:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121809343169165)
,p_plug_display_sequence=>50
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P308_BANDERADET'
,p_plug_display_when_cond2=>'1'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250716193151Z')
,p_updated_on=>wwv_flow_imp.dz('20250717150952Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(107714277969174607)
,p_plug_name=>'DatosTabla'
,p_parent_plug_id=>wwv_flow_imp.id(103816976881660221)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250717150952Z')
,p_updated_on=>wwv_flow_imp.dz('20250717150952Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(107718014187174645)
,p_plug_name=>'DetalleCompleto'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>90
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':p308_id is not null and :p308_estado in (''APROBADO'',''EN RUTA'',''TERMINADO'')'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'N',
  'rds_mode', 'STANDARD',
  'remember_selection', 'USER')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250717201924Z')
,p_updated_on=>wwv_flow_imp.dz('20250717203024Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(94656171394207202)
,p_plug_name=>'Detalle'
,p_region_name=>'rptDetalleFinal'
,p_parent_plug_id=>wwv_flow_imp.id(107718014187174645)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select x.*',
'	, 	case',
'		when x.estado = ''APROBADO'' then null',
'		when x.estado in (''PENDIENTE'') then ',
'			''<span class="fa fa-send-o" aria-hidden="true" cursor: pointer;" title="Enviar a ruta"></span>''',
'		end enviarruta',
'	, 	case',
'		when x.estado = ''PAGADO'' then null',
'		when x.estado in (''APROBADO'') and nvl(x.montopagado,0) > 0',
'			then ''<span class="fa fa-check" aria-hidden="true" style="color: #ff0000; cursor: pointer;" title="Confirmar Pago"></span>''',
'		end confirmarpago',
'	, 	''<span aria-hidden="true" class="fa fa-envelope-o"></span>'' notificar',
'	,	case',
'			when x.estado = ''PAGADO''',
'				then x.observacionfin',
'				else apex_item.text(',
'					p_idx => 1,',
'					p_value => x.observacionfin,',
'					p_item_id => x.id,',
'					p_attributes =>   ''class="TX01" style=''''text-align: left; width: 200px;'''''' ',
'				) ',
'		END txtobservacionfin',
'	,  	CASE ',
'			when x.estado = ''PAGADO''',
'				then to_char(x.montopagado,''FML999G999G999G999G990D00'')',
'				else apex_item.text(',
'					p_idx => 2,',
'					p_value => x.montopagado,',
'					p_item_id => x.id,',
'					p_attributes =>''data-value="''||x.MONTO||''" class="TX02" style=''''text-align: right; width: 80px;'''''' ',
'				)',
'		end	txtmontopagado',
'from data.t_comp_anticiposdet x where x.idcab = :p308_id'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P308_ID'
,p_plug_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_read_only_when=>'P308_ESTADO'
,p_plug_read_only_when2=>'EN RUTA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_created_on=>wwv_flow_imp.dz('20250705224455Z')
,p_updated_on=>wwv_flow_imp.dz('20250717205512Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(94656270711207203)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>94656270711207203
,p_created_on=>wwv_flow_imp.dz('20250705224455Z')
,p_updated_on=>wwv_flow_imp.dz('20250717204536Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94656345898207204)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250705224455Z')
,p_updated_on=>wwv_flow_imp.dz('20250705230336Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94656401518207205)
,p_db_column_name=>'USERCREA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Usercrea'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250705224455Z')
,p_updated_on=>wwv_flow_imp.dz('20250705230336Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94656581453207206)
,p_db_column_name=>'FECHCREA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fechcrea'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_tz_dependent=>'N'
,p_created_on=>wwv_flow_imp.dz('20250705224455Z')
,p_updated_on=>wwv_flow_imp.dz('20250705230336Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94656628340207207)
,p_db_column_name=>'USERMODI'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Usermodi'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250705224455Z')
,p_updated_on=>wwv_flow_imp.dz('20250705230336Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94656766025207208)
,p_db_column_name=>'FECHMODI'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fechmodi'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_tz_dependent=>'N'
,p_created_on=>wwv_flow_imp.dz('20250705224455Z')
,p_updated_on=>wwv_flow_imp.dz('20250705230336Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94656830407207209)
,p_db_column_name=>'IDCAB'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Idcab'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250705224455Z')
,p_updated_on=>wwv_flow_imp.dz('20250705230336Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94656948529207210)
,p_db_column_name=>'IDODC'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Idodc'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250705224455Z')
,p_updated_on=>wwv_flow_imp.dz('20250705230336Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94657090379207211)
,p_db_column_name=>'IDPAGO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'ID'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250705224455Z')
,p_updated_on=>wwv_flow_imp.dz('20250708195352Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94657133499207212)
,p_db_column_name=>'FECHAPAGO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fecha Pago'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250705224455Z')
,p_updated_on=>wwv_flow_imp.dz('20250708195308Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94657278904207213)
,p_db_column_name=>'PORCENTAJE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'% Pago'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250705224455Z')
,p_updated_on=>wwv_flow_imp.dz('20250708195308Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94657392192207214)
,p_db_column_name=>'MONTO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Monto'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250705224455Z')
,p_updated_on=>wwv_flow_imp.dz('20250708195308Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94657495096207215)
,p_db_column_name=>'MONTOPAGADO'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Monto Pagado'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250705224455Z')
,p_updated_on=>wwv_flow_imp.dz('20250716163517Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94657585332207216)
,p_db_column_name=>'ESTADO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Estado'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250705224455Z')
,p_updated_on=>wwv_flow_imp.dz('20250708195308Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94657865921207219)
,p_db_column_name=>'CONFIRMARPAGO'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'-'
,p_column_link=>'javascript:$s(''P308_IDCONFIRMAR'','''');$s(''P308_IDCONFIRMAR'',''#ID#'');'
,p_column_linktext=>'#CONFIRMARPAGO#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P308_REGRESAR'
,p_display_condition2=>'FINZ'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250705225627Z')
,p_updated_on=>wwv_flow_imp.dz('20250717141419Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94657906311207220)
,p_db_column_name=>'NOTIFICAR'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'-'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_created_on=>wwv_flow_imp.dz('20250705225627Z')
,p_updated_on=>wwv_flow_imp.dz('20250717193634Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94658236253207223)
,p_db_column_name=>'OBSERVACIONINI'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>unistr('Observaci\00F3n*')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250706182403Z')
,p_updated_on=>wwv_flow_imp.dz('20250708195331Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94658323578207224)
,p_db_column_name=>'OBSERVACIONFIN'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>unistr('Observaci\00F3n')
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250706182403Z')
,p_updated_on=>wwv_flow_imp.dz('20250706183440Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94658465770207225)
,p_db_column_name=>'TXTOBSERVACIONFIN'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>unistr('Observaci\00F3n')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P308_REGRESAR'
,p_display_condition2=>'FINZ'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250706183417Z')
,p_updated_on=>wwv_flow_imp.dz('20250717141419Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94659085980207231)
,p_db_column_name=>'TXTMONTOPAGADO'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Monto Pagado'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P308_REGRESAR'
,p_display_condition2=>'FINZ'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250706185023Z')
,p_updated_on=>wwv_flow_imp.dz('20250717141419Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(106674038131649421)
,p_db_column_name=>'ENVIARRUTA'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'-'
,p_column_link=>'javascript:$s(''P308_IDAPROBACION'','''');$s(''P308_IDAPROBACION'',''#ID#'');'
,p_column_linktext=>'#ENVIARRUTA#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250716205211Z')
,p_updated_on=>wwv_flow_imp.dz('20250717203742Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(94670436689306664)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'946705'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CONFIRMARPAGO:ENVIARRUTA:NOTIFICAR:IDPAGO:ESTADO:FECHAPAGO:PORCENTAJE:MONTO:MONTOPAGADO:OBSERVACIONINI:TXTMONTOPAGADO:TXTOBSERVACIONFIN:'
,p_sort_column_1=>'IDPAGO'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_sum_columns_on_break=>'PORCENTAJE:MONTO:MONTOPAGADO'
,p_created_on=>wwv_flow_imp.dz('20250705225810Z')
,p_updated_on=>wwv_flow_imp.dz('20250717142319Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(107715209377174617)
,p_plug_name=>'Adjuntos'
,p_parent_plug_id=>wwv_flow_imp.id(107718014187174645)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--scrollBody:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295630388916037685)
,p_plug_display_sequence=>110
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUMEROARCHIVO,',
'       FILENAME,',
'       BLOBCONTENT,',
'       MIMETYPE,',
'       RIDE,',
'       FECHA,',
'       NOMBREUSUARIO,',
'       TABLA,',
'       ID_TABLA,',
'       TIPO,',
'       OBSERVACION,',
'       ESTADO,',
'       ''<span class="fa fa-trash-o"/>'' borra     ',
'  from FILES.VT_APEX_ARCHIVOS',
' where TABLA=''T_COMP_ANTICIPOSDET'' ',
'  AND ',
'ID_TABLA=:P308_ID',
'  AND',
'TIPO=''ARCHIVO_ANTICIPOS'''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_created_on=>wwv_flow_imp.dz('20250717194905Z')
,p_updated_on=>wwv_flow_imp.dz('20250725163550Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(107715458342174619)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>107715458342174619
,p_created_on=>wwv_flow_imp.dz('20250717194906Z')
,p_updated_on=>wwv_flow_imp.dz('20250725163550Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(107715568607174620)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Numeroarchivo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250717194906Z')
,p_updated_on=>wwv_flow_imp.dz('20250725163550Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(107715777598174622)
,p_db_column_name=>'BLOBCONTENT'
,p_display_order=>20
,p_column_identifier=>'C'
,p_column_label=>'Archivo'
,p_column_type=>'NUMBER'
,p_format_mask=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment:#FILENAME#:FILES'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250717194906Z')
,p_updated_on=>wwv_flow_imp.dz('20250717201221Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(107716786097174632)
,p_db_column_name=>'BORRA'
,p_display_order=>30
,p_column_identifier=>'M'
,p_column_label=>'-'
,p_column_link=>'javascript: $s(''P308_IDARCHIVO'',''''); $s(''P308_IDARCHIVO'',#NUMEROARCHIVO#);'
,p_column_linktext=>'#BORRA#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250717194906Z')
,p_updated_on=>wwv_flow_imp.dz('20250717201359Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(107715638865174621)
,p_db_column_name=>'FILENAME'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250717194906Z')
,p_updated_on=>wwv_flow_imp.dz('20250717201212Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(107715895848174623)
,p_db_column_name=>'MIMETYPE'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Mimetype'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250717194906Z')
,p_updated_on=>wwv_flow_imp.dz('20250717201212Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(107715948830174624)
,p_db_column_name=>'RIDE'
,p_display_order=>70
,p_column_identifier=>'E'
,p_column_label=>'Ride'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250717194906Z')
,p_updated_on=>wwv_flow_imp.dz('20250717201212Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(107716056175174625)
,p_db_column_name=>'FECHA'
,p_display_order=>80
,p_column_identifier=>'F'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_tz_dependent=>'N'
,p_created_on=>wwv_flow_imp.dz('20250717194906Z')
,p_updated_on=>wwv_flow_imp.dz('20250717201212Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(107716107300174626)
,p_db_column_name=>'NOMBREUSUARIO'
,p_display_order=>90
,p_column_identifier=>'G'
,p_column_label=>'Nombreusuario'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250717194906Z')
,p_updated_on=>wwv_flow_imp.dz('20250717201212Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(107716205828174627)
,p_db_column_name=>'TABLA'
,p_display_order=>100
,p_column_identifier=>'H'
,p_column_label=>'Tabla'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250717194906Z')
,p_updated_on=>wwv_flow_imp.dz('20250717201212Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(107716383323174628)
,p_db_column_name=>'ID_TABLA'
,p_display_order=>110
,p_column_identifier=>'I'
,p_column_label=>'Id Tabla'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250717194906Z')
,p_updated_on=>wwv_flow_imp.dz('20250717201212Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(107716423914174629)
,p_db_column_name=>'TIPO'
,p_display_order=>120
,p_column_identifier=>'J'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250717194906Z')
,p_updated_on=>wwv_flow_imp.dz('20250717201212Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(107716533593174630)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>130
,p_column_identifier=>'K'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250717194906Z')
,p_updated_on=>wwv_flow_imp.dz('20250717201212Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(107716696550174631)
,p_db_column_name=>'ESTADO'
,p_display_order=>140
,p_column_identifier=>'L'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250717194906Z')
,p_updated_on=>wwv_flow_imp.dz('20250717201212Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(108642408483372827)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1086425'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMEROARCHIVO:FILENAME:BLOBCONTENT:MIMETYPE:RIDE:FECHA:NOMBREUSUARIO:TABLA:ID_TABLA:TIPO:OBSERVACION:ESTADO:BORRA'
,p_created_on=>wwv_flow_imp.dz('20250717194909Z')
,p_updated_on=>wwv_flow_imp.dz('20250717194909Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(218528311163754747)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250705223212Z')
,p_updated_on=>wwv_flow_imp.dz('20250717201954Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(499116503605254328)
,p_plug_name=>'Aprobar'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121809343169165)
,p_plug_display_sequence=>120
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':p308_id is not null and :p308_estado = ''EN RUTA'' and :p308_flujo_usuario = :p308_usuario'
,p_plug_display_when_cond2=>'PLSQL'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250709055254Z')
,p_updated_on=>wwv_flow_imp.dz('20250717203922Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(98217037380235298)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(499116503605254328)
,p_button_name=>'APROBAR'
,p_button_static_id=>'btnAprobar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Aprobar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:102:&SESSION.::&DEBUG.::G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO:&G_COMPANIA.,&APP_MODULO.,&P308_USUARIO.,ANTICIPO,&P308_ID.,&P308_USUARIOFLUJO.'
,p_created_on=>wwv_flow_imp.dz('20250709055254Z')
,p_updated_on=>wwv_flow_imp.dz('20250709144756Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(98216265505235297)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(499116503605254328)
,p_button_name=>'RECHAZAR'
,p_button_static_id=>'btnRechazar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Rechazar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:103:&SESSION.::&DEBUG.:RP,:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO:&G_COMPANIA.,&APP_MODULO.,&P308_USUARIO.,ANTICIPO,&P308_ID.,&P308_USUARIOFLUJO.'
,p_created_on=>wwv_flow_imp.dz('20250709055254Z')
,p_updated_on=>wwv_flow_imp.dz('20250709144756Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(103817438721660226)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(106673202105649413)
,p_button_name=>'AGREGAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--primary:t-Button--pillStart'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Agregar'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-plus'
,p_button_cattributes=>'t-Button lto501922125670200608_0'
,p_grid_new_row=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250716144308Z')
,p_updated_on=>wwv_flow_imp.dz('20250717171447Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(82817518000416246)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(218528311163754747)
,p_button_name=>'CANCEL'
,p_button_static_id=>'btnCancel'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Cancel'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:206:&SESSION.::&DEBUG.:::'
,p_button_condition=>'nvl(:P308_REGRESAR,''NA'') = ''COMP'''
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-arrow-left'
,p_created_on=>wwv_flow_imp.dz('20250625173511Z')
,p_updated_on=>wwv_flow_imp.dz('20250710144344Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(100018039037054201)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(218528311163754747)
,p_button_name=>'CANCEL_FINZ'
,p_button_static_id=>'btnCancelFinz'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Cancel'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=109:136:&SESSION.::&DEBUG.:RP,::'
,p_button_condition=>'nvl(:P308_REGRESAR,''NA'') = ''FINZ'''
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-arrow-left'
,p_created_on=>wwv_flow_imp.dz('20250710144344Z')
,p_updated_on=>wwv_flow_imp.dz('20250710144502Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(82818932560416252)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(218528311163754747)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Delete'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>':p308_id is not null and :p308_estado = ''INGRESADO'''
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-trash-o'
,p_database_action=>'DELETE'
,p_created_on=>wwv_flow_imp.dz('20250625173511Z')
,p_updated_on=>wwv_flow_imp.dz('20250717203128Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(106674773706649428)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(218528311163754747)
,p_button_name=>'AGREGAR_PAGO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Agregar Pago'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P308_BANDERADET=1 and :P308_ESTADO!=''TERMINADO'' and :P308_REGRESAR=''COMP'''
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-plus'
,p_created_on=>wwv_flow_imp.dz('20250716220835Z')
,p_updated_on=>wwv_flow_imp.dz('20250717205512Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(82819370666416252)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(218528311163754747)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'RIGHT'
,p_button_condition=>':p308_id is not null and :p308_estado in (''INGRESADO'') AND :P308_REGRESAR=''COMP'''
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'UPDATE'
,p_created_on=>wwv_flow_imp.dz('20250625173511Z')
,p_updated_on=>wwv_flow_imp.dz('20250717205512Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(82819716540416253)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(218528311163754747)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar*'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'RIGHT'
,p_button_condition=>':P308_ID is null and :P308_ESTADO!=''TERMINADO'''
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'INSERT'
,p_created_on=>wwv_flow_imp.dz('20250625173511Z')
,p_updated_on=>wwv_flow_imp.dz('20260213173105Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(94656087984207201)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(218528311163754747)
,p_button_name=>'SEND'
,p_button_static_id=>'btnSend'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>unistr('Enviar a Aprobaci\00F3n')
,p_button_position=>'BOTTOM'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_confirm_message=>unistr('\00BFEst\00E1 seguro de confirmar los pagos anticipados? No podr\00E1 realizar cambios posteriores.')
,p_confirm_style=>'danger'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'1 = 1',
'and :p308_estado = ''INGRESADO''',
'and nvl(:p308_cantidadpagos,0) > 1',
'and :p308_justificacion is not null',
'-- and (:p308_banderaporc = 100 or :p308_banderamnt = :p308_valororden)'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-send-o'
,p_created_on=>wwv_flow_imp.dz('20250705224455Z')
,p_updated_on=>wwv_flow_imp.dz('20250717205512Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(97153444481731619)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(218528311163754747)
,p_button_name=>'RUTA'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Ruta'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:104:&SESSION.::&DEBUG.::G_OBJETO,G_OBJETO_ID,G_TODO:ANTICIPO,&P308_ID.,TRUE'
,p_button_condition=>':p308_id is not null and :p308_estado != ''INGRESADO'''
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-road'
,p_created_on=>wwv_flow_imp.dz('20250709195727Z')
,p_updated_on=>wwv_flow_imp.dz('20250717205512Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(107714796546174612)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(218528311163754747)
,p_button_name=>'TERMINAR_PROCESO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Terminar Proceso'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_estadocab varchar2(25);',
'v_estadodet varchar2(25);',
'v_cantidad	number;',
'begin',
'	v_estadocab := :p308_estado;',
'',
'	begin',
'		select count(*) into v_cantidad from data.t_comp_anticiposdet',
'		where idcab = :p308_id and estado in (''PENDIENTE'',''EN RUTA'');',
'',
'		if v_cantidad > 0 then',
'			v_estadodet := ''PENDIENTE'';',
'		else',
'			v_estadodet := ''PAGADO'';',
'		end if;',
'	end;',
'',
'	if v_estadocab = ''APROBADO'' and v_estadodet = ''PAGADO'' then',
'		return true;',
'	else',
'		return false;',
'	end if;',
'end;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-times-circle-o'
,p_created_on=>wwv_flow_imp.dz('20250717192827Z')
,p_updated_on=>wwv_flow_imp.dz('20250923145259Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(97152769744731612)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(94656171394207202)
,p_button_name=>'GUARDARDETALLE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar Cambios'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:308:&SESSION.::&DEBUG.:RP,308:P308_TIPOORDEN,P308_ORDENCOMPRA,P308_REGRESAR:&P308_TIPOORDEN.,&P308_ORDENCOMPRA.,FINZ'
,p_button_condition=>'P308_REGRESAR'
,p_button_condition2=>'FINZAS'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-save'
,p_created_on=>wwv_flow_imp.dz('20250708203808Z')
,p_updated_on=>wwv_flow_imp.dz('20250717205512Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(106672256584649403)
,p_branch_name=>'BRANCH 206'
,p_branch_action=>'f?p=&APP_ID.:206:&SESSION.::&DEBUG.:RR,::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(82818932560416252)
,p_branch_sequence=>10
,p_created_on=>wwv_flow_imp.dz('20250716171530Z')
,p_updated_on=>wwv_flow_imp.dz('20250716184553Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82756722325302424)
,p_name=>'P308_BANDERADET'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_prompt=>'Banderadet'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250703210327Z')
,p_updated_on=>wwv_flow_imp.dz('20250716171806Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82758838843302445)
,p_name=>'P308_FECHAMIN'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_prompt=>'Fechamin'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250703214903Z')
,p_updated_on=>wwv_flow_imp.dz('20250716171806Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82807251520416216)
,p_name=>'P308_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(82806930007416210)
,p_item_source_plug_id=>wwv_flow_imp.id(82806930007416210)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250625173511Z')
,p_updated_on=>wwv_flow_imp.dz('20250703201443Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82807676578416224)
,p_name=>'P308_USERCREA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_item_source_plug_id=>wwv_flow_imp.id(82806930007416210)
,p_prompt=>'Usercrea'
,p_source=>'USERCREA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>25
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20250625173511Z')
,p_updated_on=>wwv_flow_imp.dz('20250716192228Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82808044354416227)
,p_name=>'P308_FECHCREA'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_item_source_plug_id=>wwv_flow_imp.id(82806930007416210)
,p_prompt=>'Fechcrea'
,p_source=>'FECHCREA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250625173511Z')
,p_updated_on=>wwv_flow_imp.dz('20250716192228Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82808868644416240)
,p_name=>'P308_USERMODI'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_item_source_plug_id=>wwv_flow_imp.id(82806930007416210)
,p_prompt=>'Usermodi'
,p_source=>'USERMODI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>25
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20250625173511Z')
,p_updated_on=>wwv_flow_imp.dz('20250716192228Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82809280380416240)
,p_name=>'P308_FECHMODI'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_item_source_plug_id=>wwv_flow_imp.id(82806930007416210)
,p_prompt=>'Fechmodi'
,p_source=>'FECHMODI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250625173511Z')
,p_updated_on=>wwv_flow_imp.dz('20250716192228Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82810081044416240)
,p_name=>'P308_COMPANIA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_item_source_plug_id=>wwv_flow_imp.id(82806930007416210)
,p_item_default=>'G_COMPANIA'
,p_item_default_type=>'ITEM'
,p_prompt=>'Compania'
,p_source=>'COMPANIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>5
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20250625173511Z')
,p_updated_on=>wwv_flow_imp.dz('20250625174026Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82810472918416241)
,p_name=>'P308_ORDENCOMPRA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(82806930007416210)
,p_item_source_plug_id=>wwv_flow_imp.id(82806930007416210)
,p_prompt=>'Orden Compra'
,p_source=>'ORDENCOMPRA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20250625173511Z')
,p_updated_on=>wwv_flow_imp.dz('20250708174512Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82810880510416241)
,p_name=>'P308_TIPOORDEN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(82806930007416210)
,p_item_source_plug_id=>wwv_flow_imp.id(82806930007416210)
,p_prompt=>'Tipo Orden'
,p_source=>'TIPOORDEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20250625173511Z')
,p_updated_on=>wwv_flow_imp.dz('20250716171806Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82811220140416241)
,p_name=>'P308_TIPOANTICIPO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_item_source_plug_id=>wwv_flow_imp.id(82806930007416210)
,p_item_default=>'000'
,p_prompt=>'Tipo Anticipo'
,p_source=>'TIPOANTICIPO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TIPOANTICIPO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id_tabla, descripcion',
'from data.t_corp_udc',
'where id_cabecera = ''COMP_ANTTA'' and activo = 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20250625173511Z')
,p_updated_on=>wwv_flow_imp.dz('20250717170814Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82811690632416241)
,p_name=>'P308_CANTIDADPAGOS'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_item_source_plug_id=>wwv_flow_imp.id(82806930007416210)
,p_prompt=>'Cantidad Pagos'
,p_source=>'CANTIDADPAGOS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'2'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_created_on=>wwv_flow_imp.dz('20250625173511Z')
,p_updated_on=>wwv_flow_imp.dz('20250717170428Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82812024125416242)
,p_name=>'P308_ESTADO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(82806930007416210)
,p_item_source_plug_id=>wwv_flow_imp.id(82806930007416210)
,p_item_default=>'INGRESADO'
,p_prompt=>'Estado'
,p_source=>'ESTADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>25
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20250625173511Z')
,p_updated_on=>wwv_flow_imp.dz('20250716171806Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82812483595416242)
,p_name=>'P308_IDFLUJO'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_item_source_plug_id=>wwv_flow_imp.id(82806930007416210)
,p_prompt=>'Idflujo'
,p_source=>'IDFLUJO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_created_on=>wwv_flow_imp.dz('20250625173511Z')
,p_updated_on=>wwv_flow_imp.dz('20250708173742Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82812865953416242)
,p_name=>'P308_JUSTIFICACION'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(82806930007416210)
,p_item_source_plug_id=>wwv_flow_imp.id(82806930007416210)
,p_prompt=>unistr('Justificaci\00F3n')
,p_source=>'JUSTIFICACION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>1000
,p_cHeight=>2
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'Y'
,p_attribute_03=>'Y'
,p_attribute_04=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250625173511Z')
,p_updated_on=>wwv_flow_imp.dz('20250729205010Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(94657723145207218)
,p_name=>'P308_IDDETALLE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_prompt=>'Iddetalle'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250705224455Z')
,p_updated_on=>wwv_flow_imp.dz('20250716171806Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(94658853797207229)
,p_name=>'P308_VALORDETALLE'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_prompt=>'Valordetalle'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250706184531Z')
,p_updated_on=>wwv_flow_imp.dz('20250716171806Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(94658976138207230)
,p_name=>'P308_TOTALORDEN'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(82806930007416210)
,p_prompt=>'Total Orden'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20250706184607Z')
,p_updated_on=>wwv_flow_imp.dz('20250716171806Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(94659842463207239)
,p_name=>'P308_FLUJO_DESCRIPCION'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(94660177766207242)
,p_prompt=>'Flujo Descripcion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250709044222Z')
,p_updated_on=>wwv_flow_imp.dz('20250709060022Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(94659973098207240)
,p_name=>'P308_BANDERAAPB'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(94660177766207242)
,p_prompt=>'Banderaapb'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250709055402Z')
,p_updated_on=>wwv_flow_imp.dz('20250709060022Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(94660294371207243)
,p_name=>'P308_FLUJO_IDDETALLE'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(94660177766207242)
,p_prompt=>'Flujo Iddetalle'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250709060022Z')
,p_updated_on=>wwv_flow_imp.dz('20250709060022Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(94660475399207245)
,p_name=>'P308_USUARIO'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(94660177766207242)
,p_prompt=>'Usuario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250709060053Z')
,p_updated_on=>wwv_flow_imp.dz('20250709060053Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(94660566079207246)
,p_name=>'P308_FLUJO_USUARIO'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(94660177766207242)
,p_prompt=>'Flujo Usuario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250709060319Z')
,p_updated_on=>wwv_flow_imp.dz('20250709060319Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(94660674066207247)
,p_name=>'P308_FLUJO_TOKEN'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(94660177766207242)
,p_prompt=>'Flujo Token'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250709060341Z')
,p_updated_on=>wwv_flow_imp.dz('20250709060341Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(94660990602207250)
,p_name=>'P308_FLUJO_TERMINA'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(94660177766207242)
,p_prompt=>'Flujo Termina'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250709062246Z')
,p_updated_on=>wwv_flow_imp.dz('20250715153441Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(95597158566145250)
,p_name=>'P308_BANDERAPORC'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_prompt=>'Banderaporc'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250708144017Z')
,p_updated_on=>wwv_flow_imp.dz('20250716171806Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(97151621575731601)
,p_name=>'P308_BANDERAMNT'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_prompt=>'Banderamnt'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250708144017Z')
,p_updated_on=>wwv_flow_imp.dz('20250716171806Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(97151705814731602)
,p_name=>'P308_BANDERAMPG'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_prompt=>'Banderampg'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250708144017Z')
,p_updated_on=>wwv_flow_imp.dz('20250716171806Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(97151813415731603)
,p_name=>'P308_BANDERAQTY'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_prompt=>'Banderaqty'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250708144330Z')
,p_updated_on=>wwv_flow_imp.dz('20250716171806Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(97151943903731604)
,p_name=>'P308_VALORORDEN'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_prompt=>'Valororden'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250708173741Z')
,p_updated_on=>wwv_flow_imp.dz('20250716192228Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(97152047193731605)
,p_name=>'P308_BANDERAING'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_prompt=>'Banderaing'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250708174621Z')
,p_updated_on=>wwv_flow_imp.dz('20250716171807Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(97152140079731606)
,p_name=>'P308_IDCONFIRMAR'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_prompt=>'Idconfirmar'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250708191209Z')
,p_updated_on=>wwv_flow_imp.dz('20250716171807Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(97153201379731617)
,p_name=>'P308_ENVIO_EXITO'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(94660177766207242)
,p_prompt=>'Envio Exito'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250708211244Z')
,p_updated_on=>wwv_flow_imp.dz('20250709060022Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(97153682530731621)
,p_name=>'P308_REGRESAR'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_prompt=>'Regresar'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250710142341Z')
,p_updated_on=>wwv_flow_imp.dz('20250716171807Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98430971008415305)
,p_name=>'P308_FLUJO'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_imp.id(94660177766207242)
,p_prompt=>'Flujo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250709062754Z')
,p_updated_on=>wwv_flow_imp.dz('20250709062754Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(103816079157660212)
,p_name=>'P308_IDAPROBACION'
,p_item_sequence=>320
,p_item_plug_id=>wwv_flow_imp.id(94660177766207242)
,p_prompt=>'Idaprobacion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250714183534Z')
,p_updated_on=>wwv_flow_imp.dz('20250714183534Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(103816166305660213)
,p_name=>'P308_VALORAPROBACION'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_imp.id(94660177766207242)
,p_prompt=>'Valoraprobacion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250714183534Z')
,p_updated_on=>wwv_flow_imp.dz('20250714183534Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(103817061862660222)
,p_name=>'P308_DET_IDPAGO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_prompt=>'ID Pago'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20250715172353Z')
,p_updated_on=>wwv_flow_imp.dz('20250716192624Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(103817224938660224)
,p_name=>'P308_DET_FECHAPAGO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(107714277969174607)
,p_item_default=>'select trunc(sysdate) from dual;'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Fecha Pago'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'STATIC'
,p_attribute_04=>'-0d'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON'
,p_attribute_13=>'HIDDEN'
,p_attribute_15=>'IMAGE'
,p_created_on=>wwv_flow_imp.dz('20250715172353Z')
,p_updated_on=>wwv_flow_imp.dz('20250717150952Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(106672455685649405)
,p_name=>'P308_ORDEN_COMPRA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_prompt=>'Orden Compra'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20250716171805Z')
,p_updated_on=>wwv_flow_imp.dz('20250716183959Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(106672523885649406)
,p_name=>'P308_TIPO_ORDEN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_prompt=>'Tipo Orden'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20250716171806Z')
,p_updated_on=>wwv_flow_imp.dz('20250716183959Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(106673502434649416)
,p_name=>'P308_DET_OBSERVACION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(107714277969174607)
,p_prompt=>unistr('Observaci\00F3n')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250716194738Z')
,p_updated_on=>wwv_flow_imp.dz('20250717150952Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(106673679189649417)
,p_name=>'P308_DET_MONTO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(107714277969174607)
,p_prompt=>'Monto'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'0'
,p_attribute_03=>'right'
,p_attribute_04=>'decimal'
,p_created_on=>wwv_flow_imp.dz('20250716194807Z')
,p_updated_on=>wwv_flow_imp.dz('20250717151454Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(106674646198649427)
,p_name=>'P308_MENSAJEFLUJO'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_imp.id(94660177766207242)
,p_prompt=>'Mensajeflujo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250716211507Z')
,p_updated_on=>wwv_flow_imp.dz('20250716211507Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(107714172073174606)
,p_name=>'P308_MONTOPENDIENTE'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_prompt=>'Montopendiente'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250717141620Z')
,p_updated_on=>wwv_flow_imp.dz('20250717144841Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(107714320820174608)
,p_name=>'P308_NUMERO_PAGOS'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_prompt=>'Numero Pagos'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250717153609Z')
,p_updated_on=>wwv_flow_imp.dz('20250717153609Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(107716873625174633)
,p_name=>'P308_ANEXOS_ARCHIVOS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(107715209377174617)
,p_prompt=>'Seleccione Archivo:'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_display_when=>':P308_BANDERADET=1 and :P308_ESTADO IN (''APROBADO'')'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'N'
,p_attribute_12=>'NATIVE'
,p_created_on=>wwv_flow_imp.dz('20250717195122Z')
,p_updated_on=>wwv_flow_imp.dz('20250717205109Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(107717381385174638)
,p_name=>'P308_IDARCHIVO'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_prompt=>'Idarchivo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250717201308Z')
,p_updated_on=>wwv_flow_imp.dz('20250717201308Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(107718593728174650)
,p_name=>'P308_ESCARGAARCHIVOS'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(82754790764302404)
,p_prompt=>'Escargaarchivos'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250717220136Z')
,p_updated_on=>wwv_flow_imp.dz('20250717220136Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(120307927831502002)
,p_name=>'P308_INFORMACIONADICIONAL'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(82806930007416210)
,p_prompt=>unistr('Informaci\00F3n OC')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20250729205009Z')
,p_updated_on=>wwv_flow_imp.dz('20250729205009Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(82808534616416239)
,p_validation_name=>'P308_FECHCREA must be timestamp'
,p_validation_sequence=>20
,p_validation=>'P308_FECHCREA'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>'#LABEL# must be a valid timestamp.'
,p_associated_item=>wwv_flow_imp.id(82808044354416227)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
,p_created_on=>wwv_flow_imp.dz('20250625173511Z')
,p_updated_on=>wwv_flow_imp.dz('20250625173511Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(82809729157416240)
,p_validation_name=>'P308_FECHMODI must be timestamp'
,p_validation_sequence=>40
,p_validation=>'P308_FECHMODI'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>'#LABEL# must be a valid timestamp.'
,p_associated_item=>wwv_flow_imp.id(82809280380416240)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
,p_created_on=>wwv_flow_imp.dz('20250625173511Z')
,p_updated_on=>wwv_flow_imp.dz('20250625173511Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(82755513466302412)
,p_name=>'Tipo Anticipo '
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P308_TIPOANTICIPO'
,p_condition_element=>'P308_TIPOANTICIPO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'001'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20250703202327Z')
,p_updated_on=>wwv_flow_imp.dz('20250709162004Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(82755796038302414)
,p_event_id=>wwv_flow_imp.id(82755513466302412)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P308_CANTIDADPAGOS := 2'
,p_attribute_03=>'P308_CANTIDADPAGOS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250703202511Z')
,p_updated_on=>wwv_flow_imp.dz('20250703202519Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(82755958433302416)
,p_event_id=>wwv_flow_imp.id(82755513466302412)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P308_CANTIDADPAGOS := 2'
,p_attribute_03=>'P308_CANTIDADPAGOS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250703202636Z')
,p_updated_on=>wwv_flow_imp.dz('20250703202636Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(94658514206207226)
,p_name=>'Guardar Comentario'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.TX01'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20250706183841Z')
,p_updated_on=>wwv_flow_imp.dz('20250707142723Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94658666592207227)
,p_event_id=>wwv_flow_imp.id(94658514206207226)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var i=$(this.triggeringElement).attr(''id'');',
'var v=$(this.triggeringElement).val();',
'console.log("Cambio ID: "+i+", Valor: "+v)',
'apex.item("P308_IDDETALLE").setValue(i);',
'apex.item("P308_VALORDETALLE").setValue(v);',
unistr('mensajeExito(''Observaci\00F3n Guardada'');')))
,p_created_on=>wwv_flow_imp.dz('20250706183842Z')
,p_updated_on=>wwv_flow_imp.dz('20250707142723Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94658796878207228)
,p_event_id=>wwv_flow_imp.id(94658514206207226)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	update data.t_comp_anticiposdet x set x.observacionfin = :p308_valordetalle where id = :p308_iddetalle;',
'	commit;',
'	:p308_iddetalle		:= null;',
'	:p308_valordetalle	:= null;',
'end;'))
,p_attribute_02=>'P308_IDDETALLE,P308_VALORDETALLE'
,p_attribute_03=>'P308_IDDETALLE,P308_VALORDETALLE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250706184532Z')
,p_updated_on=>wwv_flow_imp.dz('20250707141453Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(103815497923660206)
,p_name=>'Guardar Fecha Pago'
,p_event_sequence=>40
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.TX01'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
,p_created_on=>wwv_flow_imp.dz('20250714145400Z')
,p_updated_on=>wwv_flow_imp.dz('20250717141948Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(103815536397660207)
,p_event_id=>wwv_flow_imp.id(103815497923660206)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var i=$(this.triggeringElement).attr(''id'');',
'var v=$(this.triggeringElement).val();',
'console.log("Cambio ID: "+i+", Valor: "+v)',
'apex.item("P308_IDDETALLE").setValue(i);',
'apex.item("P308_VALORDETALLE").setValue(v);',
'mensajeExito(''Fecha de Pago Guardada'');'))
,p_created_on=>wwv_flow_imp.dz('20250714145400Z')
,p_updated_on=>wwv_flow_imp.dz('20250714145400Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(103815637679660208)
,p_event_id=>wwv_flow_imp.id(103815497923660206)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	update data.t_comp_anticiposdet x set x.fechapago = :p308_valordetalle where id = :p308_iddetalle;',
'	commit;',
'	:p308_iddetalle		:= null;',
'	:p308_valordetalle	:= null;',
'end;'))
,p_attribute_02=>'P308_IDDETALLE,P308_VALORDETALLE'
,p_attribute_03=>'P308_IDDETALLE,P308_VALORDETALLE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250714145400Z')
,p_updated_on=>wwv_flow_imp.dz('20250714145400Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(94659152222207232)
,p_name=>'Guardar Monto Pagado'
,p_event_sequence=>50
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.TX02'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20250706185141Z')
,p_updated_on=>wwv_flow_imp.dz('20250717174302Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94659221107207233)
,p_event_id=>wwv_flow_imp.id(94659152222207232)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var i=$(this.triggeringElement).attr(''id'');',
'var m=$(this.triggeringElement).attr(''data-value'');',
'var v=$(this.triggeringElement).val();',
'console.log("Cambio monto: "+m+" ID: "+i+", Valor: "+v)',
'  m = Math.round(m.replace(",", ".")  * 100) / 100;',
'',
'  v = Math.round(v.replace(",", ".")  * 100) / 100;',
'console.log("Cambio monto: "+m+" ID: "+i+", Valor: "+v)',
'',
'apex.item("P308_IDDETALLE").setValue(i);',
'// if (v>m){',
'// 	mensajeError(''Valor ingresado no puede ser mayor al monto solicitado'');',
'// 	return false;',
'// }',
'if (v > 0) {',
'	apex.item("P308_VALORDETALLE").setValue(v);',
'	mensajeExito(''Monto Pagado Guardado'');',
'} else {',
'	mensajeError(''Valor no permitido'');',
'	return false;',
'}',
''))
,p_created_on=>wwv_flow_imp.dz('20250706185141Z')
,p_updated_on=>wwv_flow_imp.dz('20250717174302Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94659388383207234)
,p_event_id=>wwv_flow_imp.id(94659152222207232)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_valordetalle number;',
'begin',
'	v_valordetalle := data.pk_commons.safe_to_number(:p308_valordetalle);',
'	update data.t_comp_anticiposdet x set x.montopagado = v_valordetalle',
'	where id = :p308_iddetalle and v_valordetalle > 0;',
'	commit;',
'	:p308_iddetalle		:= null;',
'	:p308_valordetalle	:= null;',
'end;'))
,p_attribute_02=>'P308_IDDETALLE,P308_VALORDETALLE'
,p_attribute_03=>'P308_IDDETALLE,P308_VALORDETALLE,P308_MONTOPENDIENTE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250706185141Z')
,p_updated_on=>wwv_flow_imp.dz('20250717154121Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(107714691780174611)
,p_event_id=>wwv_flow_imp.id(94659152222207232)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250717174021Z')
,p_updated_on=>wwv_flow_imp.dz('20250717174132Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(97152265086731607)
,p_name=>'Confirmar Pago'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P308_IDCONFIRMAR'
,p_condition_element=>'P308_IDCONFIRMAR'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20250708191441Z')
,p_updated_on=>wwv_flow_imp.dz('20250717143938Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(97152388682731608)
,p_event_id=>wwv_flow_imp.id(97152265086731607)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('\00BFEst\00E1 seguro de confirmar el pago?'),
unistr('Esta acci\00F3n bloquear\00E1 posibles acciones futuras sobre el pago y enviar\00E1 una notificaci\00F3n.')))
,p_attribute_02=>'Confirmar Pago'
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-warning'
,p_attribute_06=>'Confirmar'
,p_attribute_07=>'Cancelar'
,p_created_on=>wwv_flow_imp.dz('20250708191442Z')
,p_updated_on=>wwv_flow_imp.dz('20250708194013Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(97152487511731609)
,p_event_id=>wwv_flow_imp.id(97152265086731607)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_id		number;',
'v_estado	varchar2(25);',
'v_respuesta number;',
'begin',
'	v_id		:= :p308_idconfirmar;',
'	v_estado	:= ''PAGADO'';',
'	update data.t_comp_anticiposdet x set x.estado = v_estado where id = v_id;',
'	commit;',
'	data.pk_comp_gestioncompras.sp_notificar(:g_compania,:app_user,:p308_idconfirmar,null,''PAGO_ANTICIPO'',v_respuesta);',
'	-- TODO',
'end;'))
,p_attribute_02=>'P308_ID,P308_IDCONFIRMAR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250708191442Z')
,p_updated_on=>wwv_flow_imp.dz('20250717143938Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(97152583493731610)
,p_event_id=>wwv_flow_imp.id(97152265086731607)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(94656171394207202)
,p_created_on=>wwv_flow_imp.dz('20250708191442Z')
,p_updated_on=>wwv_flow_imp.dz('20250708191442Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(106674226335649423)
,p_name=>'Enviar Ruta Detalle'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P308_IDDETALLERUTA'
,p_condition_element=>'P308_IDDETALLERUTA'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20250716205755Z')
,p_updated_on=>wwv_flow_imp.dz('20250716210109Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(106674392299649424)
,p_event_id=>wwv_flow_imp.id(106674226335649423)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEst\00E1 seguro de envar a ruta el el pago?')
,p_attribute_02=>'Confirmar Pago'
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-send'
,p_attribute_06=>'Confirmar'
,p_attribute_07=>'Cancelar'
,p_created_on=>wwv_flow_imp.dz('20250716205755Z')
,p_updated_on=>wwv_flow_imp.dz('20250716205856Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(106674486257649425)
,p_event_id=>wwv_flow_imp.id(106674226335649423)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_id number;',
'v_iddetalle number;',
'v_resultado number;',
'v_log_app	varchar2(50);',
'v_log_dsc	varchar2(999);',
'v_log_msg	varchar2(999);',
'v_log_obs	varchar2(999);',
'begin',
'	v_log_app := ''apex.130.308.P308_IDDETALLERUTA'';',
'	v_log_dsc := ''p308_id: ''||:p308_id||'', P308_IDDETALLERUTA: ''||:P308_IDDETALLERUTA;',
'	data.pk_commons.sp_apex_log(v_log_app ,0,v_log_dsc,null,null,null);',
'',
'	v_id := :p308_id;',
'	v_iddetalle := :p308_idaprobacion;',
'',
'	data.pk_corp_flujoaprobacion.sp_flujoenviar(',
'		p_id => v_id,',
'		p_objeto => ''ANTICIPO'',',
'		p_objetodescripcion => :p308_justificacion,',
'		p_usuario => :p308_usuario,',
'		p_modulo => :g_modulo,',
'		p_compania => :g_compania,',
'		p_tipo1 => ''ANTICIPO'',',
'		p_tipo2 => :p308_tipoorden,',
'		p_exito => v_resultado); -- 1 exito, 2 termina, 0 error',
'	:p308_flujo_termina := v_resultado;',
'',
'	if v_resultado = 1 then',
'		update data.t_comp_anticiposdet x set x.estado = ''EN RUTA'' where id = v_iddetalle;',
'	elsif v_resultado = 2 then',
'		update data.t_comp_anticiposdet x set x.estado = ''APROBADO'' where id = v_iddetalle;',
'	end if;',
'',
'end;'))
,p_attribute_02=>'P308_ID,P308_IDCONFIRMAR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250716205755Z')
,p_updated_on=>wwv_flow_imp.dz('20250716210109Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(106674547951649426)
,p_event_id=>wwv_flow_imp.id(106674226335649423)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(94656171394207202)
,p_created_on=>wwv_flow_imp.dz('20250716205755Z')
,p_updated_on=>wwv_flow_imp.dz('20250716205755Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(94660712767207248)
,p_name=>'Aprobar'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(98217037380235298)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_created_on=>wwv_flow_imp.dz('20250709062246Z')
,p_updated_on=>wwv_flow_imp.dz('20250717173659Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94660825391207249)
,p_event_id=>wwv_flow_imp.id(94660712767207248)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P308_FLUJO_TERMINA'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'apex.item( "P308_FLUJO_TERMINA" ).setValue(0);',
'mostrarBarra();',
'if(this.data.G_EXITO==''true''){',
'	mensaje(''exito'', this.data.G_MENSAJE);',
'	if(isTerminoFlujo){',
'		apex.item( "P308_FLUJO_TERMINA" ).setValue(1);',
'	}',
'}',
'else{',
'	mensaje(''error'', this.data.G_MENSAJE);',
'}'))
,p_created_on=>wwv_flow_imp.dz('20250709062247Z')
,p_updated_on=>wwv_flow_imp.dz('20250715153442Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(98430587004415301)
,p_event_id=>wwv_flow_imp.id(94660712767207248)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_respuesta number;',
'v_id	number;',
'begin',
'	v_id := :p308_id;',
'	if :p308_flujo_termina = 1 then',
'		update t_comp_anticiposcab set estado = ''APROBADO'' where id 	= v_id and estado = ''EN RUTA'';',
'		update t_comp_anticiposdet set estado = ''APROBADO'' where idcab 	= v_id and estado = ''EN RUTA'';',
'		data.pk_comp_gestioncompras.sp_notificar(:g_compania,:app_user,v_id,null,''ANTICIPO_APROBADO'',v_respuesta);',
'		:P308_ESTADO:=''APROBADO'';',
'	end if;',
'end;'))
,p_attribute_02=>'P308_ID,P308_FLUJO_TERMINA'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250709062612Z')
,p_updated_on=>wwv_flow_imp.dz('20250717173659Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(98430626540415302)
,p_event_id=>wwv_flow_imp.id(94660712767207248)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var token = apex.item("P308_FLUJO_TOKEN").getValue();',
'if(this.data.G_EXITO==''true''){',
'	if(token==''0''){',
'		$(''#btnCancel'').trigger("click");',
'	}else{',
'		$(''#btnAprobar'').hide();',
'		$(''#btnRechazar'').hide();',
'	}',
'}',
'ocultarBarra();'))
,p_created_on=>wwv_flow_imp.dz('20250709062612Z')
,p_updated_on=>wwv_flow_imp.dz('20250709062612Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(98430718888415303)
,p_name=>'Rechazar'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(98216265505235297)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_created_on=>wwv_flow_imp.dz('20250709062754Z')
,p_updated_on=>wwv_flow_imp.dz('20250717204536Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(98430800074415304)
,p_event_id=>wwv_flow_imp.id(98430718888415303)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mostrarBarra();',
'var trama = JSON.parse(this.data.G_RESULTADO);',
'console.log(trama);',
'var isTerminoFlujo = trama.resultado.terminoFlujo;',
'apex.item("P308_FLUJO").setValue(0);',
'if(this.data.G_EXITO==''true''){',
'	apex.item("P308_FLUJO").setValue(1);',
'}',
'else{',
'	mensaje(''error'', this.data.G_MENSAJE);',
'}'))
,p_created_on=>wwv_flow_imp.dz('20250709062754Z')
,p_updated_on=>wwv_flow_imp.dz('20250709062754Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(98431038334415306)
,p_event_id=>wwv_flow_imp.id(98430718888415303)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_respuesta	number;',
'v_id	number;',
'begin',
'	v_id := :p308_id;',
'	if :p308_flujo = 1 then',
'		update t_comp_anticiposcab set estado = ''APROBADO''  where id 	= v_id and estado = ''EN RUTA'';',
'		update t_comp_anticiposdet set estado = ''PENDIENTE'' where idcab = v_id and estado = ''EN RUTA'';',
'	end if;',
'end;'))
,p_attribute_02=>'P308_ID,P308_FLUJO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250709063028Z')
,p_updated_on=>wwv_flow_imp.dz('20250717204536Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(98431138525415307)
,p_event_id=>wwv_flow_imp.id(98430718888415303)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let v_mensaje=$v("P308_FLUJO_DESCRIPCION");',
'if (!v_mensaje.toUpperCase().includes("ERROR")){',
'	mensajeExito (v_mensaje);',
'} else {',
'	mensajeError (v_mensaje);',
'}'))
,p_created_on=>wwv_flow_imp.dz('20250709063231Z')
,p_updated_on=>wwv_flow_imp.dz('20250709063231Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(98431256055415308)
,p_event_id=>wwv_flow_imp.id(98430718888415303)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var token = apex.item("P308_FLUJO_TOKEN").getValue();',
'ocultarBarra();',
'if(this.data.G_EXITO==''true''){',
'	if(token==''0''){',
'		$(''#btnCancel'').trigger("click");',
'	}else{',
'		$(''#btnAprobar'').hide();',
'		$(''#btnRechazar'').hide();',
'	}',
'}'))
,p_created_on=>wwv_flow_imp.dz('20250709063231Z')
,p_updated_on=>wwv_flow_imp.dz('20250709063231Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(103816235108660214)
,p_name=>'Enviar Pago Individual'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P308_IDAPROBACION'
,p_condition_element=>'P308_IDAPROBACION'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20250714184428Z')
,p_updated_on=>wwv_flow_imp.dz('20250716220244Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(103816474481660216)
,p_event_id=>wwv_flow_imp.id(103816235108660214)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEst\00E1 seguro de enviar a aprobaci\00F3n el pago?')
,p_attribute_02=>unistr('Confirmaci\00F3n')
,p_attribute_03=>'information'
,p_attribute_04=>'fa-money-check-pen'
,p_attribute_06=>unistr('S\00ED')
,p_attribute_07=>'Cancelar'
,p_created_on=>wwv_flow_imp.dz('20250714184428Z')
,p_updated_on=>wwv_flow_imp.dz('20250714184428Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(103816577337660217)
,p_event_id=>wwv_flow_imp.id(103816235108660214)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
,p_created_on=>wwv_flow_imp.dz('20250715153442Z')
,p_updated_on=>wwv_flow_imp.dz('20250715153442Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(103816603266660218)
,p_event_id=>wwv_flow_imp.id(103816235108660214)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_id number;',
'v_iddetalle number;',
'v_resultado number;',
'v_log_app	varchar2(50);',
'v_log_dsc	varchar2(999);',
'v_log_msg	varchar2(999);',
'v_log_obs	varchar2(999);',
'begin',
'	v_log_app := ''apex.130.308.p308_idaprobacion'';',
'	v_log_dsc := ''p308_id: ''||:p308_id||'', p308_idaprobacion: ''||:p308_idaprobacion;',
'	data.pk_commons.sp_apex_log(v_log_app ,0,v_log_dsc,null,null,null);',
'',
'	v_id := :p308_id;',
'	v_iddetalle := :p308_idaprobacion;',
'',
'	data.pk_corp_flujoaprobacion.sp_flujoenviar(',
'		p_id => v_id,',
'		p_objeto => ''ANTICIPO'',',
'		p_objetodescripcion => :P308_DET_OBSERVACION,',
'		p_usuario => :p308_usuario,',
'		p_modulo => :app_modulo,',
'		p_compania => :g_compania, ',
'		p_codigopagina		=> ''COMPP308'',',
'		p_tipo1 => ''ANTICIPO'',',
'		p_tipo2 => :p308_tipoorden,',
'		p_exito => v_resultado); -- 1 exito, 2 termina, 0 error',
'		:p308_flujo_termina := v_resultado;',
'		:P308_MENSAJEFLUJO:=pk_corp_flujoaprobacion.G_MENSAJE;',
'',
'	if v_resultado = 1 then',
'		update data.t_comp_anticiposdet x set x.estado = ''EN RUTA'' where id = v_iddetalle;',
'		update data.t_comp_anticiposcab x set x.estado = ''EN RUTA'' where id = v_id;',
'	elsif v_resultado = 2 then',
'		update data.t_comp_anticiposdet x set x.estado = ''APROBADO'' where id = v_iddetalle;',
'		update data.t_comp_anticiposcab x set x.estado = ''APROBADO'' where id = v_id;',
'	end if;',
'',
'end;'))
,p_attribute_02=>'P308_ID,P308_IDAPROBACION,P308_JUSTIFICACION,P308_USUARIO,P308_TIPOORDEN'
,p_attribute_03=>'P308_FLUJO_TERMINA,P308_MENSAJEFLUJO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250715153442Z')
,p_updated_on=>wwv_flow_imp.dz('20250716220244Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(103816793208660219)
,p_event_id=>wwv_flow_imp.id(103816235108660214)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ocultarBarra();',
'if ($v("P308_FLUJO_TERMINA")==="0"){',
'	mensajeError($v("P308_MENSAJEFLUJO"));',
'	return false',
'}',
'',
''))
,p_created_on=>wwv_flow_imp.dz('20250715162527Z')
,p_updated_on=>wwv_flow_imp.dz('20250716220117Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(103816808999660220)
,p_event_id=>wwv_flow_imp.id(103816235108660214)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250715162624Z')
,p_updated_on=>wwv_flow_imp.dz('20250715162624Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(103817556976660227)
,p_name=>'Agregar Pago'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(103817438721660226)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20250716150554Z')
,p_updated_on=>wwv_flow_imp.dz('20250717191955Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(106673871981649419)
,p_event_id=>wwv_flow_imp.id(103817556976660227)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'validacion'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let mensaje="";',
'document.querySelector(".t-Button--closeAlert")?.click();',
'let total = $v("P308_MONTOPENDIENTE") ;',
'let monto=$v("P308_DET_MONTO") ;',
'console.log("total:"+total+" "+to_Number(total));',
'console.log("monto:"+monto+" "+to_Number(monto));',
'',
'if(to_Number(total)===0 || to_Number(monto)===0){',
'	mensaje=mensaje+"<li>Monto no valido</li>";',
'}',
'// if(to_Number(monto)>to_Number(total)){',
unistr('// 	mensaje=mensaje+"<li>El monto ingresado es mayor al valor pendiente de la \00F3rden:"+total+"</li>";'),
'// }',
'if ($v("P308_DET_OBSERVACION")===""){',
'	mensaje=mensaje+"<li>Observacion es requerido</li>";',
'}',
'',
'if (mensaje!==""){',
'	mensajeError(mensaje);',
'	return false;',
'}'))
,p_created_on=>wwv_flow_imp.dz('20250716200115Z')
,p_updated_on=>wwv_flow_imp.dz('20250717191955Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(103817673688660228)
,p_event_id=>wwv_flow_imp.id(103817556976660227)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
,p_created_on=>wwv_flow_imp.dz('20250716150554Z')
,p_updated_on=>wwv_flow_imp.dz('20250716200644Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(103817895163660230)
,p_event_id=>wwv_flow_imp.id(103817556976660227)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_qty number;',
'begin',
'	:p308_det_monto:=replace(:p308_det_monto,''$'','''');',
'	if :p308_det_idpago is not null and :p308_det_fechapago is not null and :p308_det_monto is not null then',
'		begin',
'			select count(1) into v_qty from data.t_comp_anticiposdet',
'			where idcab = :p308_id and idpago = :p308_det_idpago;',
'		end;',
'',
'		if v_qty = 0 then',
'			insert into data.t_comp_anticiposdet (idcab, idodc, estado, idpago, fechapago, monto,porcentaje, OBSERVACIONINI)',
'			values (:p308_id,:p308_ordencompra,''PENDIENTE'',:p308_det_idpago,:p308_det_fechapago,:p308_det_monto, 100*(:p308_det_monto/:p308_valororden),:P308_DET_OBSERVACION);',
'		else',
'			update data.t_comp_anticiposdet',
'			set fechapago = :p308_det_fechapago, monto = :p308_det_monto, porcentaje = 100*(:p308_det_monto/:p308_valororden),OBSERVACIONINI=:P308_DET_OBSERVACION',
'			where idcab = :p308_id and idpago = :p308_det_idpago;',
'		end if;',
'	end if;',
'end;'))
,p_attribute_02=>'P308_VALORORDEN,P308_ID,P308_ORDENCOMPRA,P308_DET_IDPAGO,P308_DET_FECHAPAGO,P308_DET_MONTO,P308_DET_OBSERVACION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250716150555Z')
,p_updated_on=>wwv_flow_imp.dz('20250716203724Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(103817925756660231)
,p_event_id=>wwv_flow_imp.id(103817556976660227)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(95595174073145230)
,p_created_on=>wwv_flow_imp.dz('20250716150629Z')
,p_updated_on=>wwv_flow_imp.dz('20250716200644Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(103818039593660232)
,p_event_id=>wwv_flow_imp.id(103817556976660227)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(94656171394207202)
,p_created_on=>wwv_flow_imp.dz('20250716150639Z')
,p_updated_on=>wwv_flow_imp.dz('20250716200644Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(107714099843174605)
,p_event_id=>wwv_flow_imp.id(103817556976660227)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(103816976881660221)
,p_attribute_01=>'$(this.affectedElements).dialog(''close'')'
,p_created_on=>wwv_flow_imp.dz('20250717134811Z')
,p_updated_on=>wwv_flow_imp.dz('20250717134837Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(103817740267660229)
,p_event_id=>wwv_flow_imp.id(103817556976660227)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
,p_created_on=>wwv_flow_imp.dz('20250716150555Z')
,p_updated_on=>wwv_flow_imp.dz('20250717134812Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(107713627458174601)
,p_name=>'abrirDialogoDetalle'
,p_event_sequence=>120
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(106674773706649428)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20250717134341Z')
,p_updated_on=>wwv_flow_imp.dz('20250717173112Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(107713773866174602)
,p_event_id=>wwv_flow_imp.id(107713627458174601)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(103816976881660221)
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log($v("P308_MONTOPENDIENTE"));',
'',
'var maxVal = Math.round($v("P308_MONTOPENDIENTE").replace(",", ".") * 100)/ 100 || 0;',
'console.log(maxVal );',
'',
'//apex.item("P308_DET_MONTO").node.max = maxVal  ;',
'$s("P308_DET_MONTO", maxVal.toString().replace(".", ","));',
'$(this.affectedElements).dialog(''open'')'))
,p_created_on=>wwv_flow_imp.dz('20250717134341Z')
,p_updated_on=>wwv_flow_imp.dz('20250717173112Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(107714865207174613)
,p_name=>'terminar proceso'
,p_event_sequence=>130
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(107714796546174612)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20250717193021Z')
,p_updated_on=>wwv_flow_imp.dz('20250717210312Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(107718177773174646)
,p_event_id=>wwv_flow_imp.id(107714865207174613)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('\00BFEst\00E1 seguro de Terminar el proceso?'),
unistr('No se podr\00E1 hacer cambios a los anticipos de esta orden de compra.')))
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-times-circle'
,p_attribute_06=>'SI'
,p_attribute_07=>'NO'
,p_created_on=>wwv_flow_imp.dz('20250717210004Z')
,p_updated_on=>wwv_flow_imp.dz('20250717210312Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(107714902993174614)
,p_event_id=>wwv_flow_imp.id(107714865207174613)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'UPDATE t_comp_anticiposcab SET ESTADO=''TERMINADO'' WHERE ID = :P308_ID;'
,p_attribute_02=>'P308_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250717193021Z')
,p_updated_on=>wwv_flow_imp.dz('20250717210004Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(107715085339174615)
,p_event_id=>wwv_flow_imp.id(107714865207174613)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mensajeExito("Proceso actualizado correctamente");'
,p_created_on=>wwv_flow_imp.dz('20250717193126Z')
,p_updated_on=>wwv_flow_imp.dz('20250717210005Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(107715174226174616)
,p_event_id=>wwv_flow_imp.id(107714865207174613)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250717193419Z')
,p_updated_on=>wwv_flow_imp.dz('20250717210005Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(107716951496174634)
,p_name=>'Cargar Archivo'
,p_event_sequence=>140
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P308_ANEXOS_ARCHIVOS'
,p_condition_element=>'P308_ANEXOS_ARCHIVOS'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20250717195253Z')
,p_updated_on=>wwv_flow_imp.dz('20250717220138Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(107717183467174636)
,p_event_id=>wwv_flow_imp.id(107716951496174634)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
,p_created_on=>wwv_flow_imp.dz('20250717195253Z')
,p_updated_on=>wwv_flow_imp.dz('20250717195253Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(107718254592174647)
,p_event_id=>wwv_flow_imp.id(107716951496174634)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'carga_archivos'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250717215110Z')
,p_updated_on=>wwv_flow_imp.dz('20250717220136Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(107717408420174639)
,p_name=>'BORRARARCHVOS'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P308_IDARCHIVO'
,p_condition_element=>'P308_IDARCHIVO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20250717201623Z')
,p_updated_on=>wwv_flow_imp.dz('20250717201832Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(107717590871174640)
,p_event_id=>wwv_flow_imp.id(107717408420174639)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEsta seguro de eliminar el archivo?')
,p_created_on=>wwv_flow_imp.dz('20250717201623Z')
,p_updated_on=>wwv_flow_imp.dz('20250717201623Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(107717710392174642)
,p_event_id=>wwv_flow_imp.id(107717408420174639)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
,p_created_on=>wwv_flow_imp.dz('20250717201803Z')
,p_updated_on=>wwv_flow_imp.dz('20250717201803Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(107717667479174641)
,p_event_id=>wwv_flow_imp.id(107717408420174639)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete from files.T_APEX_ARCHIVOS where numeroarchivo=:P308_IDARCHIVO;',
':P308_IDARCHIVO:=null;'))
,p_attribute_02=>'P308_IDARCHIVO'
,p_attribute_03=>'P308_IDARCHIVO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250717201623Z')
,p_updated_on=>wwv_flow_imp.dz('20250717201803Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(107717918785174644)
,p_event_id=>wwv_flow_imp.id(107717408420174639)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(107715209377174617)
,p_created_on=>wwv_flow_imp.dz('20250717201832Z')
,p_updated_on=>wwv_flow_imp.dz('20250717201832Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(107717895080174643)
,p_event_id=>wwv_flow_imp.id(107717408420174639)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
,p_created_on=>wwv_flow_imp.dz('20250717201803Z')
,p_updated_on=>wwv_flow_imp.dz('20250717201832Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(82820520594416257)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(82806930007416210)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Anticipos'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Datos almacenados correctamente'
,p_internal_uid=>82820520594416257
,p_created_on=>wwv_flow_imp.dz('20250625173511Z')
,p_updated_on=>wwv_flow_imp.dz('20250717170040Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(95597039872145249)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(95595174073145230)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Detalle Editable - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Datos almacenados correctamente'
,p_internal_uid=>95597039872145249
,p_created_on=>wwv_flow_imp.dz('20250708141541Z')
,p_updated_on=>wwv_flow_imp.dz('20250717170040Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(103815794247660209)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Aprobaci\00F3n')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_id	number;',
'begin',
'	v_id := :p308_id;',
'	update data.t_comp_anticiposcab set estado = ''EN RUTA'' where id = v_id;',
'	update data.t_comp_anticiposcab set estado = ''APROBADO'' where id = v_id;',
'	update data.t_comp_anticiposdet set estado = ''PENDIENTE'' where idcab = v_id;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'No se pudo actualizar los registros.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(94656087984207201)
,p_internal_uid=>103815794247660209
,p_created_on=>wwv_flow_imp.dz('20250714155702Z')
,p_updated_on=>wwv_flow_imp.dz('20250717213926Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(106672819119649409)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CAMBIO_OC'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	:p308_tipo_orden :=NVL(:p308_tipo_orden ,:p308_tipoorden );',
'	:p308_orden_compra :=NVL(:p308_orden_compra ,:p308_ordencompra );',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>106672819119649409
,p_created_on=>wwv_flow_imp.dz('20250716183708Z')
,p_updated_on=>wwv_flow_imp.dz('20250716184108Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(107717288545174637)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CARGA_SOPORTE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'V_NUMEROARCHIVO NUMBER;',
'BEGIN',
'    IF(:P308_ANEXOS_ARCHIVOS IS NOT NULL) THEN',
'        PK_APEX_ARCHIVOS.SP_CREARARCHIVO(:P308_ANEXOS_ARCHIVOS,''T_COMP_ANTICIPOSDET'',:P308_ID,''ARCHIVO_ANTICIPOS'','''',:APP_USER, V_NUMEROARCHIVO);',
':P308_ESCARGAARCHIVOS:=1;',
'    END IF; ',
'END;',
' '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'carga_archivos'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>107717288545174637
,p_created_on=>wwv_flow_imp.dz('20250717195438Z')
,p_updated_on=>wwv_flow_imp.dz('20250717220217Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(82756547520302422)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetUp'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_id			number;',
'v_ordencompra	number;',
'v_tipoorden		varchar2(10);',
'v_tipo			varchar2(50);',
'v_objeto 			varchar2(99);',
'v_objetoid 			varchar2(99);',
'v_compania			varchar2(10);',
'v_usuarioflujo		varchar2(50);',
'v_idflujo			number;',
'v_aprobacion		number;',
'v_ingreso			varchar2(2);',
'begin',
'	v_aprobacion := 1;',
' ',
'	if :g_detalle_id is not null and :g_token is not null then',
'		v_ingreso			:= ''E'';	-- Enlace',
'',
'		pk_corp_flujoaprobacion.sp_buscaraprobacion(:g_detalle_id,:g_token,v_compania,v_usuarioflujo,v_objeto,v_objetoid);',
'',
'		:g_compania			:= v_compania;',
'		:p308_usuario		:= v_usuarioflujo;',
'',
'		begin',
'			select ordencompra,tipoorden into v_ordencompra,v_tipoorden from t_comp_anticiposcab where id = v_objetoid and idflujo is not null;',
'',
'			exception when others then v_aprobacion := 0;',
'		end;',
'',
'		:p308_tipoorden		:= v_tipoorden;',
'		:p308_ordencompra	:= v_ordencompra;',
'',
'',
'',
'	else',
'',
'',
unistr('		v_ingreso			:= ''A''; -- Aplicaci\00F3n'),
'		:p308_usuario		:= :app_user;',
'		v_tipoorden			:= NVL(:p308_tipoorden,:p308_tipo_orden);',
'		v_ordencompra		:= NVL(:p308_ordencompra,:p308_orden_compra);',
'		v_compania			:= :g_compania;',
' ',
'',
'		begin',
'			select id,nvl(idflujo,0) into v_objetoid,v_idflujo',
'			from t_comp_anticiposcab where ordencompra = v_ordencompra and tipoorden = v_tipoorden;',
'',
'			exception when others then v_objetoid := null; v_aprobacion := 0;',
'		end;',
'',
'		if v_aprobacion = 1 and v_idflujo > 0 then',
'		begin',
'			select usuario into v_usuarioflujo',
'			from data.vt_flujo_aprobacion',
'			where idflujo = v_idflujo and detalle_estado = ''EN_PROCESO'' and entidad_id = v_objetoid;',
'',
'			exception when others then v_usuarioflujo := ''ORCL'';',
'		end;',
'		end if;',
'',
'	end if;',
'',
'	v_id				:= v_objetoid;',
'	:p308_id			:= v_id;',
'	:p308_flujo_usuario	:= v_usuarioflujo;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>82756547520302422
,p_created_on=>wwv_flow_imp.dz('20250703205125Z')
,p_updated_on=>wwv_flow_imp.dz('20250716184219Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(82820111482416256)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(82806930007416210)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Anticipos'
,p_internal_uid=>82820111482416256
,p_created_on=>wwv_flow_imp.dz('20250625173511Z')
,p_updated_on=>wwv_flow_imp.dz('20250716173028Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(82756813196302425)
,p_process_sequence=>40
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetUp Detalle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_id			number;',
'v_qty			number;',
'v_pagos			number;',
'v_ordencompra	number;',
'v_tipoorden		varchar2(5);',
'v_qtyprc		number;',
'v_qtymnt		number;',
'v_estado 		varchar2(25);',
'v_banderadet	number;',
'begin',
'	:p308_cantidadpagos:=nvl(:p308_cantidadpagos,2);',
'	v_id 			:= nvl(:p308_id,0);',
'	v_pagos			:= nvl(:p308_cantidadpagos,2);',
'	v_ordencompra	:= :p308_ordencompra;',
'	v_tipoorden		:= :p308_tipoorden;',
'	v_estado		:= :p308_estado;',
'	',
'	',
'	begin -- Datos de la OC',
'		select valor',
'			, to_char(valor,''FML999G999G999G999G990D00'')',
'			, ''Solicitud de Anticipo para la Orden de Compra ''||documentotipo||''-''||documento||'' del proveedor ''||proveedor||''.''',
'		into :p308_valororden,:p308_totalorden,:p308_flujo_descripcion',
'		from data.vt_comp_f4301',
'		where documentotipo = v_tipoorden and documento = v_ordencompra;',
'',
'		exception when others then :p308_valororden := -1; :p308_totalorden := to_char(0,''FML999G999G999G999G990D00''); :p308_flujo_descripcion := null;',
'	end;',
'	if (:P308_ESCARGAARCHIVOS is null)then',
'		delete from data.t_comp_anticiposdet where idcab = v_id and estado = ''PENDIENTE'';',
'	end if;',
'',
'	if v_estado = ''APROBADO'' then',
'		begin',
'			select max(id) into :p308_iddetalle',
'			from data.t_comp_anticiposdet',
'			where idcab = v_id and estado = ''REGISTRADO'';',
'',
'			exception when others then :p308_iddetalle := null; :p308_det_fechapago := sysdate; :p308_det_monto := null;',
'			',
'		end;',
'',
'		if :p308_iddetalle is not null then',
'			select idpago,fechapago,monto into :p308_det_idpago,:p308_det_fechapago,:p308_det_monto',
'			from data.t_comp_anticiposdet',
'			where id = :p308_iddetalle;',
'		else',
'			select nvl(max(idpago),0) + 1 into :p308_det_idpago',
'			from data.t_comp_anticiposdet',
'			where idcab = v_id;-- and estado = ''APROBADO'';',
'		end if;',
'',
'		:p308_banderadet := 1;',
'		select',
'		    to_number(:p308_valororden) - ( ( nvl(SUM(CASE WHEN ESTADO=''APROBADO'' THEN MONTO ELSE 0 END ),0) + nvl(SUM(CASE WHEN ESTADO=''PAGADO'' THEN MONTOPAGADO ELSE 0 END ) ,0 ) ) ) MONTOPENDIENTE',
'		    into :P308_MONTOPENDIENTE',
'		from data.t_comp_anticiposdet x where x.idcab = :p308_id;',
'		if (:P308_MONTOPENDIENTE<0)then :P308_MONTOPENDIENTE:=0;end if;',
'	end if;',
'',
'	:P308_ESCARGAARCHIVOS:=null;',
'',
'	begin',
'		select pk_comp_ordenescompra.f_comentario@jdedtadl(/*min sig:*/p_compania=>:g_compania,p_tipooc=>:p308_tipoorden, p_ordencompra =>:p308_ordencompra)',
'		into :p308_informacionadicional',
'		from dual;',
'',
unistr('		exception when others then :p308_informacionadicional := ''No se ingres\00F3 informaci\00F3n adicional en la Orden de Compra'';'),
'	end;',
'',
'/*',
'	select count(*) into v_qty',
'	from data.t_comp_anticiposdet where idcab = v_id;',
'',
'	if v_id > 0 and v_pagos > 0 and v_qty = 0 then',
'		:p308_fechamin	:= sysdate;',
'',
'		insert into data.t_comp_anticiposdet (idcab,idodc,idpago,estado)',
'		select v_id,v_ordencompra,level,''INGRESADO''',
'		from dual',
'		connect by level <= v_pagos;',
'	end if;',
'',
'	if v_qty > 0 then',
'		select sum(porcentaje),sum(monto),sum(montopagado),count(id)',
'		into :p308_banderaporc,:p308_banderamnt,:p308_banderampg,:p308_banderaqty',
'		from data.t_comp_anticiposdet',
'		where idcab = v_id and fechapago is not null;',
'	end if;',
'',
'	begin',
'		select sum(case when porcentaje is null then 0 else 1 end) qtyprc, sum(case when porcentaje is null then 0 else 1 end) qtymnt',
'		into v_qtyprc,v_qtymnt',
'		from data.t_comp_anticiposdet where idcab = v_id;',
'',
'		if :p308_estado = ''INGRESADO'' and v_qtyprc > 0 and v_qtymnt >= 0 then',
'			update data.t_comp_anticiposdet x set x.monto = (x.porcentaje/100)*:p308_valororden where idcab = v_id;',
'		elsif :p308_estado = ''INGRESADO'' and v_qtyprc = 0 and v_qtymnt > 0 then',
'			update data.t_comp_anticiposdet x set x.porcentaje = round(100*(x.monto/:p308_valororden),2) where idcab = v_id;',
'		end if;',
'	end;',
'*/',
':P308_TIPOANTICIPO:=''000'';',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>82756813196302425
,p_created_on=>wwv_flow_imp.dz('20250703211616Z')
,p_updated_on=>wwv_flow_imp.dz('20250729205210Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
