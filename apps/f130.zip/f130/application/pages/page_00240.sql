prompt --application/pages/page_00240
begin
--   Manifest
--     PAGE: 00240
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>240
,p_name=>unistr('Estado Importaci\00F3n Muestras')
,p_alias=>unistr('ESTADO-IMPORTACI\00D3N-MUESTRAS')
,p_step_title=>unistr('Estado Importaci\00F3n Muestras')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240410163626Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240321164955Z')
,p_last_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(179496601556796515)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(179496741151796516)
,p_plug_name=>'Muestras'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT X.ID ID_MUESTRA,X.USERCREA,X.FECHACREA,       ',
'       REGIMEN,IDPROCESO,',
'       X.CODIGOPROVEEDOR,CENTRODECOSTO,',
'       NUMEROFACTURA,X.PAISORIGEN,Y.ID ID_MESA,ETAPA,CODIGOETAPA ,Y.FECHATURNO,',
'       CASE WHEN UPPER(X.FORWARDER) LIKE ''%UPS%'' THEN ''S''',
'            WHEN UPPER(X.FORWARDER) LIKE ''%DHL%'' THEN ''S'' ',
'            WHEN UPPER(X.FORWARDER) LIKE ''%FEDEX%'' THEN ''S'' ELSE ''N'' END COURRIER',
'FROM T_CMEX_MUESTRAS X, T_CMEX_MESATRABAJO Y',
'WHERE X.ID = Y.ID_MUESTRA(+)'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Muestras'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(179496899427796517)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MALBAN'
,p_internal_uid=>179496899427796517
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(179497040455796519)
,p_db_column_name=>'USERCREA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Usuario Iniciador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(179497192953796520)
,p_db_column_name=>'FECHACREA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fecha Inicio'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(179497563208796524)
,p_db_column_name=>'REGIMEN'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>unistr('R\00E9gimen')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(179497693689796525)
,p_db_column_name=>'IDPROCESO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>unistr('Id Importaci\00F3n')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(179497881081796527)
,p_db_column_name=>'CODIGOPROVEEDOR'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(165398581949586903)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(179497982252796528)
,p_db_column_name=>'CENTRODECOSTO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Centro de Costo'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(179827823702629097)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(179498071469796529)
,p_db_column_name=>'NUMEROFACTURA'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Numerofactura'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(179498132603796530)
,p_db_column_name=>'PAISORIGEN'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Paisorigen'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(179498940810796538)
,p_db_column_name=>'ETAPA'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Archivos Muestra'
,p_column_link=>'f?p=100:401:&SESSION.::&DEBUG.::P401_TABLA,P401_ID,P401_ESTADO,P401_REGIMEN:T_CMEX_MUESTRAS,#ID_MUESTRA#,0,#REGIMEN##ID#,0,#REGIMEN#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(179499039241796539)
,p_db_column_name=>'ID_MUESTRA'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Id Muestra'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(179499104686796540)
,p_db_column_name=>'ID_MESA'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Archivos Etapa'
,p_column_link=>'f?p=100:401:&SESSION.::&DEBUG.::P401_TABLA,P401_ID,P401_ESTADO,P401_REGIMEN:T_CMEX_MESATRABAJO,#ID_MESA#,0,#REGIMEN#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-view.png" class="apex-edit-view" alt="">'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(179499215982796541)
,p_db_column_name=>'CODIGOETAPA'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Etapa'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(74279793258956227)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(179499762964796546)
,p_db_column_name=>'FECHATURNO'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Fecha Ingreso a ZM'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182397304325520023)
,p_db_column_name=>'COURRIER'
,p_display_order=>260
,p_column_identifier=>'AA'
,p_column_label=>'Courrier'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(78141453854944977)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(181848349856738395)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1818484'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'USERCREA:FECHACREA:REGIMEN:IDPROCESO:CODIGOPROVEEDOR:CENTRODECOSTO:ETAPA:CODIGOETAPA:ID_MESA:FECHATURNO:COURRIER:'
,p_created_on=>wwv_flow_imp.dz('20240410163626Z')
,p_updated_on=>wwv_flow_imp.dz('20240410163626Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(181840124872723677)
,p_plug_name=>unistr('Importaci\00F3n de Muestras')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296122226350169167)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp.component_end;
end;
/
