prompt --application/pages/page_00166
begin
--   Manifest
--     PAGE: 00166
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>166
,p_name=>unistr('COMEX - Form. Costos de Importaci\00F3n')
,p_step_title=>unistr('COMEX - Form. Costos de Importaci\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_on=>wwv_flow_imp.dz('20260409205759Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79244817990195233)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79326260245185255)
,p_plug_name=>unistr('Formulario Costos de Importaci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(84897478757918104)
,p_plug_name=>'Detalle de Costos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(84276306146476149)
,p_name=>'Detalles Costos Provision'
,p_parent_plug_id=>wwv_flow_imp.id(84897478757918104)
,p_template=>wwv_flow_imp.id(296120613521169165)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       ESTADO,',
'       ID_BATCH,',
'       CODIGOMODULO,',
'       ORDENCOMPRA,',
'       APEX_ITEM.TEXT(2,MTOSEGURO,null,null, ''class = "number_field apex-item-text" disabled = "true"'') MTOSEGURO,',
'       APEX_ITEM.TEXT(2,MTOFLTINT,null,null, ''class = "number_field apex-item-text" disabled = "true"'') MTOFLTINT,',
'       APEX_ITEM.TEXT(2,MTOGTOLOC,null,null, ''class = "number_field apex-item-text" disabled = "true"'') MTOGTOLOC,',
'       APEX_ITEM.TEXT(2,MTOGTOTHC,null,null, ''class = "number_field apex-item-text" disabled = "true"'') MTOGTOTHC,',
'       APEX_ITEM.TEXT(2,MTOADVLRM,null,null, ''class = "number_field apex-item-text" disabled = "true"'') MTOADVLRM,',
'       APEX_ITEM.TEXT(2,MTOIMPIVA,null,null, ''class = "number_field apex-item-text" disabled = "true"'') MTOIMPIVA,',
'       APEX_ITEM.TEXT(2,MTOFODNFA,null,null, ''class = "number_field apex-item-text" disabled = "true"'') MTOFODNFA,',
'       APEX_ITEM.TEXT(2,MTOALMCNJ,null,null, ''class = "number_field apex-item-text" disabled = "true"'') MTOALMCNJ,',
'       APEX_ITEM.TEXT(2,MTOAUTPRV,null,null, ''class = "number_field apex-item-text" disabled = "true"'') MTOAUTPRV,',
'       APEX_ITEM.TEXT(2,MTOHNAGAD,null,null, ''class = "number_field apex-item-text" disabled = "true"'') MTOHNAGAD,',
'       APEX_ITEM.TEXT(2,MTOFLTLOC,null,null, ''class = "number_field apex-item-text" disabled = "true"'') MTOFLTLOC,',
'       APEX_ITEM.TEXT(2,MTODEVCNT,null,null, ''class = "number_field apex-item-text" disabled = "true"'') MTODEVCNT,',
'       APEX_ITEM.TEXT(2,MTODEMORA,null,null, ''class = "number_field apex-item-text" disabled = "true"'') MTODEMORA,',
'       APEX_ITEM.TEXT(2,MTOIMPISD,null,null, ''class = "number_field apex-item-text" disabled = "true"'') MTOIMPISD,',
'       APEX_ITEM.TEXT(2,MTOOI,null,null, ''class = "number_field apex-item-text" disabled = "true"'') MTOOI,',
'       APEX_ITEM.TEXT(2,MTOICEADV,null,null, ''class = "number_field apex-item-text" disabled = "true"'') MTOICEADV,',
'       APEX_ITEM.TEXT(2,MTOFACHUM,null,null, ''class = "number_field apex-item-text" disabled = "true"'') MTOFACHUM,',
'       APEX_ITEM.TEXT(2,MTOIMPICE,null,null, ''class = "number_field apex-item-text" disabled = "true"'') MTOIMPICE,',
'       CODIGOPROVEEDOR,',
'       TIPOMERCA,',
'       REFERENDO,',
'       FECHALIQADN,',
'       FECHACIECST,',
'       ORDENAGTADN,',
'       PUERTOORI,',
'       PUERTODES,',
'       USERCREA,',
'       FECHACREA,',
'       USERMODI,',
'       FECHAMODI,',
'       ID_CMEX_MESATRABAJO,',
'       TIPOREGISTRO,',
'       ID_GRUPO',
'  from T_CMEX_PROVISION',
' where ID_CMEX_MESATRABAJO = :P166_ID_CMEX_MESATRABAJO',
'        AND TIPOREGISTRO = ''PROVISION'''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295657610309037706)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84793246250622727)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84793391192622728)
,p_query_column_id=>2
,p_column_alias=>'ESTADO'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84793444057622729)
,p_query_column_id=>3
,p_column_alias=>'ID_BATCH'
,p_column_display_sequence=>3
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84793558299622730)
,p_query_column_id=>4
,p_column_alias=>'CODIGOMODULO'
,p_column_display_sequence=>4
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84793613314622731)
,p_query_column_id=>5
,p_column_alias=>'ORDENCOMPRA'
,p_column_display_sequence=>5
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84793766780622732)
,p_query_column_id=>6
,p_column_alias=>'MTOSEGURO'
,p_column_display_sequence=>6
,p_column_heading=>'Seguro'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84793849955622733)
,p_query_column_id=>7
,p_column_alias=>'MTOFLTINT'
,p_column_display_sequence=>7
,p_column_heading=>'Flete Internacional'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84793966738622734)
,p_query_column_id=>8
,p_column_alias=>'MTOGTOLOC'
,p_column_display_sequence=>8
,p_column_heading=>'Gasto Local'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84794087026622735)
,p_query_column_id=>9
,p_column_alias=>'MTOGTOTHC'
,p_column_display_sequence=>9
,p_column_heading=>'THC'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84794165106622736)
,p_query_column_id=>10
,p_column_alias=>'MTOADVLRM'
,p_column_display_sequence=>10
,p_column_heading=>'AdValorem'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84794279447622737)
,p_query_column_id=>11
,p_column_alias=>'MTOIMPIVA'
,p_column_display_sequence=>11
,p_column_heading=>'IVA'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84794332652622738)
,p_query_column_id=>12
,p_column_alias=>'MTOFODNFA'
,p_column_display_sequence=>12
,p_column_heading=>'FODINFA'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84794403347622739)
,p_query_column_id=>13
,p_column_alias=>'MTOALMCNJ'
,p_column_display_sequence=>13
,p_column_heading=>'Almacenaje'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84794544734622740)
,p_query_column_id=>14
,p_column_alias=>'MTOAUTPRV'
,p_column_display_sequence=>14
,p_column_heading=>'Autorizaciones Previas'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84794635923622741)
,p_query_column_id=>15
,p_column_alias=>'MTOHNAGAD'
,p_column_display_sequence=>15
,p_column_heading=>'Hon. Agente de Aduana'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84794753394622742)
,p_query_column_id=>16
,p_column_alias=>'MTOFLTLOC'
,p_column_display_sequence=>16
,p_column_heading=>'Flete Interno'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84794897256622743)
,p_query_column_id=>17
,p_column_alias=>'MTODEVCNT'
,p_column_display_sequence=>17
,p_column_heading=>unistr('Devoluci\00F3n Contenedor')
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84794941736622744)
,p_query_column_id=>18
,p_column_alias=>'MTODEMORA'
,p_column_display_sequence=>18
,p_column_heading=>'Demoraje'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84795081861622745)
,p_query_column_id=>19
,p_column_alias=>'MTOIMPISD'
,p_column_display_sequence=>21
,p_column_heading=>'ISD (Finanzas)'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84795192467622746)
,p_query_column_id=>20
,p_column_alias=>'MTOOI'
,p_column_display_sequence=>22
,p_column_heading=>'Monto Orden'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84869035342910013)
,p_query_column_id=>21
,p_column_alias=>'MTOICEADV'
,p_column_display_sequence=>19
,p_column_heading=>'ICE AdValorem'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84869125755910014)
,p_query_column_id=>22
,p_column_alias=>'MTOFACHUM'
,p_column_display_sequence=>20
,p_column_heading=>'Factor Humedad'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84868700913910010)
,p_query_column_id=>23
,p_column_alias=>'MTOIMPICE'
,p_column_display_sequence=>23
,p_column_heading=>'ICE'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84795212576622747)
,p_query_column_id=>24
,p_column_alias=>'CODIGOPROVEEDOR'
,p_column_display_sequence=>24
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84795319041622748)
,p_query_column_id=>25
,p_column_alias=>'TIPOMERCA'
,p_column_display_sequence=>25
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84795454463622749)
,p_query_column_id=>26
,p_column_alias=>'REFERENDO'
,p_column_display_sequence=>26
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84795542356622750)
,p_query_column_id=>27
,p_column_alias=>'FECHALIQADN'
,p_column_display_sequence=>27
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84867854310910001)
,p_query_column_id=>28
,p_column_alias=>'FECHACIECST'
,p_column_display_sequence=>28
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84867996025910002)
,p_query_column_id=>29
,p_column_alias=>'ORDENAGTADN'
,p_column_display_sequence=>29
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84868042934910003)
,p_query_column_id=>30
,p_column_alias=>'PUERTOORI'
,p_column_display_sequence=>30
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84868168303910004)
,p_query_column_id=>31
,p_column_alias=>'PUERTODES'
,p_column_display_sequence=>31
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84868265394910005)
,p_query_column_id=>32
,p_column_alias=>'USERCREA'
,p_column_display_sequence=>32
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84868306687910006)
,p_query_column_id=>33
,p_column_alias=>'FECHACREA'
,p_column_display_sequence=>33
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84868458080910007)
,p_query_column_id=>34
,p_column_alias=>'USERMODI'
,p_column_display_sequence=>34
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84868544247910008)
,p_query_column_id=>35
,p_column_alias=>'FECHAMODI'
,p_column_display_sequence=>35
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84868644284910009)
,p_query_column_id=>36
,p_column_alias=>'ID_CMEX_MESATRABAJO'
,p_column_display_sequence=>36
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84868827150910011)
,p_query_column_id=>37
,p_column_alias=>'TIPOREGISTRO'
,p_column_display_sequence=>37
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84868949985910012)
,p_query_column_id=>38
,p_column_alias=>'ID_GRUPO'
,p_column_display_sequence=>38
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(84869259816910015)
,p_name=>'Detalles Costos REAL'
,p_parent_plug_id=>wwv_flow_imp.id(84897478757918104)
,p_template=>wwv_flow_imp.id(296120613521169165)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_new_grid_row=>false
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select APEX_ITEM.TEXT(1,ID,null,null, ''class = "number_field apex-item-text"'') ID,',
'       ESTADO,',
'       ID_BATCH,',
'       CODIGOMODULO,',
'       ORDENCOMPRA,',
'       APEX_ITEM.TEXT(2,MTOSEGURO,null,null, ''class = "number_field apex-item-text"'') MTOSEGURO,',
'       APEX_ITEM.TEXT(3,MTOFLTINT,null,null, ''class = "number_field apex-item-text"'') MTOFLTINT,',
'       APEX_ITEM.TEXT(4,MTOGTOLOC,null,null, ''class = "number_field apex-item-text"'') MTOGTOLOC,',
'       APEX_ITEM.TEXT(5,MTOGTOTHC,null,null, ''class = "number_field apex-item-text"'') MTOGTOTHC,',
'       APEX_ITEM.TEXT(6,MTOADVLRM,null,null, ''class = "number_field apex-item-text"'') MTOADVLRM,',
'       APEX_ITEM.TEXT(7,MTOIMPIVA,null,null, ''class = "number_field apex-item-text"'') MTOIMPIVA,',
'       APEX_ITEM.TEXT(8,MTOFODNFA,null,null, ''class = "number_field apex-item-text"'') MTOFODNFA,',
'       APEX_ITEM.TEXT(9,MTOALMCNJ,null,null, ''class = "number_field apex-item-text"'') MTOALMCNJ,',
'       APEX_ITEM.TEXT(10,MTOAUTPRV,null,null, ''class = "number_field apex-item-text"'') MTOAUTPRV,',
'       APEX_ITEM.TEXT(11,MTOHNAGAD,null,null, ''class = "number_field apex-item-text"'') MTOHNAGAD,',
'       APEX_ITEM.TEXT(12,MTOFLTLOC,null,null, ''class = "number_field apex-item-text"'') MTOFLTLOC,',
'       APEX_ITEM.TEXT(13,MTODEVCNT,null,null, ''class = "number_field apex-item-text"'') MTODEVCNT,',
'       APEX_ITEM.TEXT(14,MTODEMORA,null,null, ''class = "number_field apex-item-text"'') MTODEMORA,',
'       APEX_ITEM.TEXT(15,MTOIMPISD,null,null, ''class = "number_field apex-item-text"'') MTOIMPISD,',
'       APEX_ITEM.TEXT(16,MTOOI,null,null, ''class = "number_field apex-item-text"'') MTOOI,',
'       APEX_ITEM.TEXT(17,MTOICEADV,null,null, ''class = "number_field apex-item-text"'') MTOICEADV,',
'       APEX_ITEM.TEXT(18,MTOFACHUM,null,null, ''class = "number_field apex-item-text"'') MTOFACHUM,',
'       CODIGOPROVEEDOR,',
'       TIPOMERCA,',
'       REFERENDO,',
'       FECHALIQADN,',
'       FECHACIECST,',
'       ORDENAGTADN,',
'       PUERTOORI,',
'       PUERTODES,',
'       USERCREA,',
'       FECHACREA,',
'       USERMODI,',
'       FECHAMODI,',
'       ID_CMEX_MESATRABAJO,',
'       MTOIMPICE,',
'       TIPOREGISTRO,',
'       ID_GRUPO',
'       ',
'  from T_CMEX_PROVISION',
' where ID_CMEX_MESATRABAJO = :P166_ID_CMEX_MESATRABAJO',
'     AND TIPOREGISTRO = ''REAL'''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295657610309037706)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84869355307910016)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84869427127910017)
,p_query_column_id=>2
,p_column_alias=>'ESTADO'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84869502623910018)
,p_query_column_id=>3
,p_column_alias=>'ID_BATCH'
,p_column_display_sequence=>3
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84869632728910019)
,p_query_column_id=>4
,p_column_alias=>'CODIGOMODULO'
,p_column_display_sequence=>4
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84869777054910020)
,p_query_column_id=>5
,p_column_alias=>'ORDENCOMPRA'
,p_column_display_sequence=>5
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84869805601910021)
,p_query_column_id=>6
,p_column_alias=>'MTOSEGURO'
,p_column_display_sequence=>6
,p_column_heading=>'Seguro'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84869953564910022)
,p_query_column_id=>7
,p_column_alias=>'MTOFLTINT'
,p_column_display_sequence=>7
,p_column_heading=>'Flete Internacional'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84870058875910023)
,p_query_column_id=>8
,p_column_alias=>'MTOGTOLOC'
,p_column_display_sequence=>8
,p_column_heading=>'Gasto Local'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84870138703910024)
,p_query_column_id=>9
,p_column_alias=>'MTOGTOTHC'
,p_column_display_sequence=>9
,p_column_heading=>'THC'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84870275151910025)
,p_query_column_id=>10
,p_column_alias=>'MTOADVLRM'
,p_column_display_sequence=>10
,p_column_heading=>'AdValorem'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84870361689910026)
,p_query_column_id=>11
,p_column_alias=>'MTOIMPIVA'
,p_column_display_sequence=>11
,p_column_heading=>'IVA'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84870487755910027)
,p_query_column_id=>12
,p_column_alias=>'MTOFODNFA'
,p_column_display_sequence=>12
,p_column_heading=>'FODINFA'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84870546641910028)
,p_query_column_id=>13
,p_column_alias=>'MTOALMCNJ'
,p_column_display_sequence=>13
,p_column_heading=>'Almacenaje'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84870627013910029)
,p_query_column_id=>14
,p_column_alias=>'MTOAUTPRV'
,p_column_display_sequence=>14
,p_column_heading=>'Autorizaciones Previas'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84870775426910030)
,p_query_column_id=>15
,p_column_alias=>'MTOHNAGAD'
,p_column_display_sequence=>15
,p_column_heading=>'Hon. Agente de Aduana'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84870833859910031)
,p_query_column_id=>16
,p_column_alias=>'MTOFLTLOC'
,p_column_display_sequence=>16
,p_column_heading=>'Flete Interno'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84870945317910032)
,p_query_column_id=>17
,p_column_alias=>'MTODEVCNT'
,p_column_display_sequence=>17
,p_column_heading=>unistr('Devoluci\00F3n Contenedor')
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84871058255910033)
,p_query_column_id=>18
,p_column_alias=>'MTODEMORA'
,p_column_display_sequence=>18
,p_column_heading=>'Demoraje'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84871145059910034)
,p_query_column_id=>19
,p_column_alias=>'MTOIMPISD'
,p_column_display_sequence=>19
,p_column_heading=>'ISD (Finanzas)'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84871202919910035)
,p_query_column_id=>20
,p_column_alias=>'MTOOI'
,p_column_display_sequence=>20
,p_column_heading=>'Monto OI'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84897234260918102)
,p_query_column_id=>21
,p_column_alias=>'MTOICEADV'
,p_column_display_sequence=>21
,p_column_heading=>'ICE AdValorem'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84897341130918103)
,p_query_column_id=>22
,p_column_alias=>'MTOFACHUM'
,p_column_display_sequence=>22
,p_column_heading=>'Factor Humedad'
,p_use_as_row_header=>'N'
,p_column_format=>'PCT_GRAPH:::'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84871356368910036)
,p_query_column_id=>23
,p_column_alias=>'CODIGOPROVEEDOR'
,p_column_display_sequence=>24
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84871416116910037)
,p_query_column_id=>24
,p_column_alias=>'TIPOMERCA'
,p_column_display_sequence=>25
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84871524172910038)
,p_query_column_id=>25
,p_column_alias=>'REFERENDO'
,p_column_display_sequence=>26
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84871640858910039)
,p_query_column_id=>26
,p_column_alias=>'FECHALIQADN'
,p_column_display_sequence=>27
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84871753434910040)
,p_query_column_id=>27
,p_column_alias=>'FECHACIECST'
,p_column_display_sequence=>28
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84871849688910041)
,p_query_column_id=>28
,p_column_alias=>'ORDENAGTADN'
,p_column_display_sequence=>29
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84871984975910042)
,p_query_column_id=>29
,p_column_alias=>'PUERTOORI'
,p_column_display_sequence=>30
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84872097906910043)
,p_query_column_id=>30
,p_column_alias=>'PUERTODES'
,p_column_display_sequence=>31
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84872197920910044)
,p_query_column_id=>31
,p_column_alias=>'USERCREA'
,p_column_display_sequence=>32
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84872216317910045)
,p_query_column_id=>32
,p_column_alias=>'FECHACREA'
,p_column_display_sequence=>33
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84872304686910046)
,p_query_column_id=>33
,p_column_alias=>'USERMODI'
,p_column_display_sequence=>34
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84872447976910047)
,p_query_column_id=>34
,p_column_alias=>'FECHAMODI'
,p_column_display_sequence=>35
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84872569926910048)
,p_query_column_id=>35
,p_column_alias=>'ID_CMEX_MESATRABAJO'
,p_column_display_sequence=>36
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84872671947910049)
,p_query_column_id=>36
,p_column_alias=>'MTOIMPICE'
,p_column_display_sequence=>23
,p_column_heading=>'ICE'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84872783024910050)
,p_query_column_id=>37
,p_column_alias=>'TIPOREGISTRO'
,p_column_display_sequence=>37
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84897123774918101)
,p_query_column_id=>38
,p_column_alias=>'ID_GRUPO'
,p_column_display_sequence=>38
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(79326912846185255)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(79244817990195233)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Cancel'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:165:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(79326861544185255)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(79244817990195233)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Delete'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P166_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-trash'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(79326718295185255)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(79244817990195233)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P166_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(79326639320185255)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(79244817990195233)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P166_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(79328550741185260)
,p_branch_action=>'f?p=&APP_ID.:166:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79328993234185263)
,p_name=>'P166_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(79326260245185255)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79329308877185272)
,p_name=>'P166_ID_CMEX_MESATRABAJO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(79326260245185255)
,p_use_cache_before_default=>'NO'
,p_source=>'ID_CMEX_MESATRABAJO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79329665674185274)
,p_name=>'P166_ID_CMEX_LIQUIDACIONIMP'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(79326260245185255)
,p_use_cache_before_default=>'NO'
,p_source=>'ID_CMEX_LIQUIDACIONIMP'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79330098518185274)
,p_name=>'P166_VALORTOTALFACTURAS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(79326260245185255)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Valor Total Facturas'
,p_source=>'VALORTOTALFACTURAS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79330449392185279)
,p_name=>'P166_TIPOCARGA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(79326260245185255)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Tipo Carga'
,p_source=>'TIPOCARGA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>15
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79330810802185279)
,p_name=>'P166_VALORPROVISION'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(79326260245185255)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Valor Provision'
,p_source=>'VALORPROVISION'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79331233719185279)
,p_name=>'P166_VALORREAL'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(79326260245185255)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Valor Real'
,p_source=>'VALORREAL'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79331606073185279)
,p_name=>'P166_DIFERENCIA'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(79326260245185255)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Diferencia'
,p_source=>'DIFERENCIA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79332032557185280)
,p_name=>'P166_TOTALES'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(79326260245185255)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Totales'
,p_source=>'TOTALES'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79332478191185280)
,p_name=>'P166_TOTAL_SINIVA'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(79326260245185255)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Total Sin IVA'
,p_source=>'TOTAL_SINIVA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79332879024185280)
,p_name=>'P166_FECHACIERRECOSTOS'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(79326260245185255)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fecha Cierre Costos'
,p_source=>'FECHACIERRECOSTOS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(79333679804185282)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from T_CMEX_COSTOIMPORTACION'
,p_attribute_02=>'T_CMEX_COSTOIMPORTACION'
,p_attribute_03=>'P166_ID'
,p_attribute_04=>'ID'
,p_internal_uid=>79333679804185282
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(79334007852185282)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of T_CMEX_COSTOIMPORTACION'
,p_attribute_02=>'T_CMEX_COSTOIMPORTACION'
,p_attribute_03=>'P166_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>79334007852185282
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(79334453239185283)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(79326861544185255)
,p_internal_uid=>79334453239185283
);
wwv_flow_imp.component_end;
end;
/
