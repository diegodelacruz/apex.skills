prompt --application/pages/page_00113
begin
--   Manifest
--     PAGE: 00113
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>113
,p_name=>'Mesa de Trabajo*'
,p_alias=>'MESA-DE-TRABAJO'
,p_step_title=>'Mesa de Trabajo*'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();',
'$(regOcultos).hide();'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'label.ocultar-label {',
'	display: none !important;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_on=>wwv_flow_imp.dz('20250828210836Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(76535608729016705)
,p_plug_name=>unistr('Par\00E1metros')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>40
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(153422242328389022)
,p_plug_name=>'Grupos'
,p_region_name=>'rptGrupoAprobacion'
,p_parent_plug_id=>wwv_flow_imp.id(76535608729016705)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apex_item.checkbox(1,compania||''|''||codmodulo||''|''||idgrupo||''|''||aprobador||''|''||criterio||''|''||agrupador,''checked class="chkF01"'') seleccion',
'	, ''<i class="fa fa-tasks-alt" style="color:#000080;" title="Ver Detalle"></i>'' as verdetalle',
'	, case',
unistr('		when x.grupoobjeto = ''ORDENCOMPRA'' then ''\00D3rdenes de Compra'''),
unistr('		when x.grupoobjeto = ''LIQUIDACION'' then ''Liquidaci\00F3n Gastos'''),
'		when x.grupoobjeto = ''PAGORECURRENTE'' then ''Pago Recurrente''',
unistr('		when x.grupoobjeto = ''NEGOCIACION'' then ''Negociaci\00F3n'''),
unistr('		when x.grupoobjeto = ''NOTACREDITO'' then ''Notas de Cr\00E9dito'''),
'		end descgrupoobjeto',
'	, x.*',
'from data.vt_corp_grupoaprobacion x',
'where estado = ''AGRUPADO'' and aprobador = :p113_usuario'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_updated_on=>wwv_flow_imp.dz('20250827211704Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(153422345158389023)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>unistr('Sin pendientes de aprobaci\00F3n')
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_computation=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>153422345158389023
,p_updated_on=>wwv_flow_imp.dz('20250827211704Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153422453039389024)
,p_db_column_name=>'SELECCION'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'<input type="checkbox" id="selectallgrp">'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(76537148371016720)
,p_db_column_name=>'VERDETALLE'
,p_display_order=>20
,p_column_identifier=>'BD'
,p_column_label=>'-'
,p_column_link=>'f?p=&APP_ID.:114:&SESSION.::&DEBUG.::P114_IDGRUPO,P114_APROBADOR,P114_CODAGRUPADOR,P114_CODCRITERIO,P114_GRUPOOBJETO:#IDGRUPO#,#APROBADOR#,#CODAGRUPADOR#,#CODCRITERIO#,#GRUPOOBJETO#'
,p_column_linktext=>'#VERDETALLE#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153423084741389030)
,p_db_column_name=>'APROBADOR'
,p_display_order=>30
,p_column_identifier=>'G'
,p_column_label=>'Aprobador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153423601991389036)
,p_db_column_name=>'ESTADO'
,p_display_order=>40
,p_column_identifier=>'M'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153426054670389060)
,p_db_column_name=>'IDGRUPO'
,p_display_order=>50
,p_column_identifier=>'AJ'
,p_column_label=>'Idgrupo'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153426279483389062)
,p_db_column_name=>'COMPANIA'
,p_display_order=>60
,p_column_identifier=>'AL'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153426351646389063)
,p_db_column_name=>'CODMODULO'
,p_display_order=>70
,p_column_identifier=>'AM'
,p_column_label=>'Codmodulo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153426471269389064)
,p_db_column_name=>'CRITERIO'
,p_display_order=>80
,p_column_identifier=>'AN'
,p_column_label=>'Criterio'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153426543893389065)
,p_db_column_name=>'AGRUPADOR'
,p_display_order=>90
,p_column_identifier=>'AO'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(76538284482016731)
,p_db_column_name=>'CODAGRUPADOR'
,p_display_order=>190
,p_column_identifier=>'BE'
,p_column_label=>'Codagrupador'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(76538362137016732)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>200
,p_column_identifier=>'BF'
,p_column_label=>unistr('Cant. \00D3rdenes')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(76538417399016733)
,p_db_column_name=>'MONTO'
,p_display_order=>210
,p_column_identifier=>'BG'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(76538502234016734)
,p_db_column_name=>'OBJETOS'
,p_display_order=>220
,p_column_identifier=>'BH'
,p_column_label=>unistr('\00CDtems')
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137036867059932502)
,p_db_column_name=>'CODCRITERIO'
,p_display_order=>230
,p_column_identifier=>'BI'
,p_column_label=>'Codcriterio'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137036923428932503)
,p_db_column_name=>'CLASIFICADOR01'
,p_display_order=>240
,p_column_identifier=>'BJ'
,p_column_label=>'Clasificador01'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137037080242932504)
,p_db_column_name=>'CLASIFICADOR02'
,p_display_order=>250
,p_column_identifier=>'BK'
,p_column_label=>'Clasificador02'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137037153867932505)
,p_db_column_name=>'CLASIFICADOR03'
,p_display_order=>260
,p_column_identifier=>'BL'
,p_column_label=>'Clasificador03'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137037249339932506)
,p_db_column_name=>'CLASIFICADOR04'
,p_display_order=>270
,p_column_identifier=>'BM'
,p_column_label=>'Clasificador04'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137037384244932507)
,p_db_column_name=>'CLASIFICADOR05'
,p_display_order=>280
,p_column_identifier=>'BN'
,p_column_label=>'Clasificador05'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137037409927932508)
,p_db_column_name=>'CLASIFICADOR06'
,p_display_order=>290
,p_column_identifier=>'BO'
,p_column_label=>'Clasificador06'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137037555457932509)
,p_db_column_name=>'CLASIFICADOR07'
,p_display_order=>300
,p_column_identifier=>'BP'
,p_column_label=>'Clasificador07'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137037680972932510)
,p_db_column_name=>'CLASIFICADOR08'
,p_display_order=>310
,p_column_identifier=>'BQ'
,p_column_label=>'Clasificador08'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137037756079932511)
,p_db_column_name=>'CLASIFICADOR09'
,p_display_order=>320
,p_column_identifier=>'BR'
,p_column_label=>'Clasificador09'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137037860712932512)
,p_db_column_name=>'CLASIFICADOR10'
,p_display_order=>330
,p_column_identifier=>'BS'
,p_column_label=>'Clasificador10'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145803873602570233)
,p_db_column_name=>'DESCGRUPOOBJETO'
,p_display_order=>340
,p_column_identifier=>'BU'
,p_column_label=>'Grupo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145803980735570234)
,p_db_column_name=>'GRUPOOBJETO'
,p_display_order=>350
,p_column_identifier=>'BV'
,p_column_label=>'GrupoObjeto'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(153439469658473301)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'765035'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SELECCION:VERDETALLE:DESCGRUPOOBJETO:AGRUPADOR:CANTIDAD:MONTO'
,p_sort_column_1=>'DESCGRUPOOBJETO'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'MONTO'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'DESCGRUPOOBJETO'
,p_break_enabled_on=>'DESCGRUPOOBJETO'
,p_sum_columns_on_break=>'MONTO:CANTIDAD'
,p_updated_on=>wwv_flow_imp.dz('20250827211704Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(83006860617513763)
,p_plug_name=>'Barra de accion'
,p_region_name=>'rptBarraAcciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(146172060581254501)
,p_plug_name=>'Ocultos'
,p_region_name=>'regOcultos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(146172549142254506)
,p_plug_name=>'Aviso'
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('<!-- Aviso: Sin pendientes de aprobaci\00F3n -->'),
'<div class="notice-empty" role="status" aria-live="polite">',
'  <svg class="icon" viewBox="0 0 24 24" aria-hidden="true">',
'    <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2"></circle>',
'    <path d="M9 12l2 2 4-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>',
'  </svg>',
unistr('  <span class="title">Sin pendientes de aprobaci\00F3n</span>'),
'</div>',
'',
'<style>',
'  .notice-empty{',
'    --accent: #0daf4a; /* tono ejecutivo, verde corporativo */',
'    display:flex; align-items:center; gap:12px;',
'    padding:14px 16px; border-radius:12px;',
'    border:1px solid rgba(13,175,74,.35);',
'    background:#ffffff;',
'    color:#222222; font:500 15px/1.3 system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;',
'    box-shadow:0 1px 2px rgba(0,0,0,.05);',
'    animation:fade-in .25s ease-out;',
'  }',
'  .notice-empty .icon{ width:20px; height:20px; color:var(--accent); flex:0 0 20px; }',
'  .notice-empty .title{ font-weight:600; letter-spacing:.2px; }',
'',
'  @keyframes fade-in{',
'    from{opacity:0; transform:translateY(-2px)}',
'    to{opacity:1; transform:translateY(0)}',
'  }',
'',
'  /* Buen contraste en modo oscuro */',
'  @media (prefers-color-scheme: dark){',
'    .notice-empty{',
'      border-color: rgba(13,175,74,.55);',
'      background: rgba(13,175,74,.14);',
'      color:#b7f0c8; box-shadow:0 1px 2px rgba(0,0,0,.25);',
'    }',
'  }',
'</style>',
''))
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(77178884617453511)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(83006860617513763)
,p_button_name=>'APROBAR'
,p_button_static_id=>'btnAprobar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Aprobar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-thumbs-up'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(77179299335453512)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(83006860617513763)
,p_button_name=>'RECHAZAR'
,p_button_static_id=>'btnRechazar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Rechazar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-thumbs-down'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152012172472268233)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(83006860617513763)
,p_button_name=>'MESATRABAJO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Mesa de Trabajo'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:100:G_REFERENCIAMT,P100_REDIRECCIONA:100,1'
,p_icon_css_classes=>'fa-home'
,p_created_on=>wwv_flow_imp.dz('20250827204331Z')
,p_updated_on=>wwv_flow_imp.dz('20250827210352Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76935398610014032)
,p_name=>'P113_CODAGRUPADOR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(76535608729016705)
,p_prompt=>'Codagrupador'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LOV_GRUPOSAPROBACION'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id_tabla, descripcion',
'from data.t_corp_udc',
'where id_cabecera = ''COMP_GRAPR'' and valor = ''COMP'' and activo = ''1'' order by id_tabla'))
,p_grid_label_column_span=>0
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_css_classes=>'ocultar-label'
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'6'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(146172187144254502)
,p_name=>'P113_USUARIO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(146172060581254501)
,p_prompt=>'Usuario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(146172200934254503)
,p_name=>'P113_ORIGEN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(146172060581254501)
,p_prompt=>'Origen'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(76536608509016715)
,p_name=>'Agrupador'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P113_CODAGRUPADOR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76536933503016718)
,p_event_id=>wwv_flow_imp.id(76536608509016715)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76536735567016716)
,p_event_id=>wwv_flow_imp.id(76536608509016715)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	data.pk_comp_reportes.sp_generagruposaprobacion(',
'		p_compania   => :g_compania,',
'		p_usuario    => :p113_usuario,',
'		p_aprobador  => :p113_usuario,',
'		p_criterio   => :p113_codagrupador',
'	);',
'end;'))
,p_attribute_02=>'P113_USUARIO,P113_CODAGRUPADOR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76536822071016717)
,p_event_id=>wwv_flow_imp.id(76536608509016715)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(153422242328389022)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76537084809016719)
,p_event_id=>wwv_flow_imp.id(76536608509016715)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(146509157859648216)
,p_name=>'Selecciona Todo Grupo'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectallgrp'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#rptGrupoAprobacion'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(146509536480648225)
,p_event_id=>wwv_flow_imp.id(146509157859648216)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#rptGrupoAprobacion #selectallgrp'' ).is('':checked'')) {',
'    $(''#rptGrupoAprobacion input[type=checkbox][name=f01]'').prop(''checked'',true);',
'} else {',
'    $(''#rptGrupoAprobacion input[type=checkbox][name=f01]'').prop(''checked'',false);',
'}'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(146172354838254504)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetUp'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	begin	-- Usuarios',
'		:p113_usuario := ''JMALDONADO'';',
'		-- :p113_usuario := :app_user;',
'	end;',
'',
'	begin',
'		if nvl(:g_refenciamt,0) > 0 then',
'			:g_refenciamt := :g_refenciamt;',
'		end if;',
'	end;',
'',
'	begin',
'		data.pk_comp_reportes.sp_generagruposaprobacion(',
'			p_compania   => :g_compania,',
'			p_usuario    => :p113_usuario,',
'			p_aprobador  => :p113_usuario,',
'			p_criterio   => ''060''--:p113_codagrupador',
'		);',
'	end;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>146172354838254504
,p_updated_on=>wwv_flow_imp.dz('20250828210836Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(146172617987254507)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Aprobar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_opcion	varchar2(25);',
'v_dato		varchar2(4000);',
'v_log_app	varchar2(100);',
'v_log_dsc	varchar2(999);',
'v_log_msg	varchar2(999);',
'begin',
'	v_log_app	:= ''apex.130.113.Aprobar'';',
'	v_opcion	:= ''APROBAR'';',
'	for i in 1..apex_application.g_f01.count loop',
'		declare',
'			v_compania	varchar2(5);',
'			v_modulo	varchar2(4);',
'			v_idgrupo	number;',
'			v_aprobador	varchar2(25);',
'			v_criterio	varchar2(25);',
'			v_agrupador	varchar2(1000);',
'		begin',
'			v_dato := apex_application.g_f01(i);',
'',
'			v_compania	:= regexp_substr(v_dato, ''[^|]+'', 1, 1);',
'			v_modulo	:= regexp_substr(v_dato, ''[^|]+'', 1, 2);',
'			v_idgrupo	:= regexp_substr(v_dato, ''[^|]+'', 1, 3);',
'			v_aprobador	:= regexp_substr(v_dato, ''[^|]+'', 1, 4);',
'			v_criterio	:= regexp_substr(v_dato, ''[^|]+'', 1, 5);',
'			v_agrupador	:= regexp_substr(v_dato, ''[^|]+'', 1, 6);',
'',
'			v_log_dsc := ''v_compania: ''||v_compania||'', v_modulo: ''||v_modulo||'', v_idgrupo: ''||v_idgrupo;',
'			v_log_dsc := v_log_dsc||'', v_aprobador: ''||v_aprobador||'', v_criterio: ''||v_criterio||'', v_agrupador: ''||v_agrupador;',
'',
'			data.pk_comp_reportes.sp_gestionaprobaciongrupo(',
'				  p_compania		=> v_compania',
'				, p_modulo			=> v_modulo',
'				, p_aplicacion		=> :app_id',
'				, p_pagina			=> :app_page_id',
'				, p_usuario			=> :p113_usuario',
'				, p_aprobador		=> v_aprobador',
'				, p_idgrupo			=> v_idgrupo',
'				, p_grupoobjeto		=> null',
'				, p_objetos			=> null',
'				, p_opcion			=> v_opcion',
'				, p_respuesta		=> v_log_msg',
'			);',
'			data.pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,v_log_msg,null,null);',
'		end;',
'	end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(77178884617453511)
,p_internal_uid=>146172617987254507
,p_updated_on=>wwv_flow_imp.dz('20250828050144Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(146172755056254508)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Rechazar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_opcion	varchar2(25);',
'v_dato		varchar2(4000);',
'v_log_app	varchar2(100);',
'v_log_dsc	varchar2(999);',
'v_log_msg	varchar2(999);',
'begin',
'	v_log_app	:= ''apex.130.113.Rechazar'';',
'	v_opcion	:= ''RECHAZAR'';',
'	for i in 1..apex_application.g_f01.count loop',
'		declare',
'			v_compania	varchar2(5);',
'			v_modulo	varchar2(4);',
'			v_idgrupo	number;',
'			v_aprobador	varchar2(25);',
'			v_criterio	varchar2(25);',
'			v_agrupador	varchar2(1000);',
'		begin',
'			v_dato := apex_application.g_f01(i);',
'',
'			v_compania	:= regexp_substr(v_dato, ''[^|]+'', 1, 1);',
'			v_modulo	:= regexp_substr(v_dato, ''[^|]+'', 1, 2);',
'			v_idgrupo	:= regexp_substr(v_dato, ''[^|]+'', 1, 3);',
'			v_aprobador	:= regexp_substr(v_dato, ''[^|]+'', 1, 4);',
'			v_criterio	:= regexp_substr(v_dato, ''[^|]+'', 1, 5);',
'			v_agrupador	:= regexp_substr(v_dato, ''[^|]+'', 1, 6);',
'',
'			v_log_dsc := ''v_compania: ''||v_compania||'', v_modulo: ''||v_modulo||'', v_idgrupo: ''||v_idgrupo;',
'			v_log_dsc := v_log_dsc||'', v_aprobador: ''||v_aprobador||'', v_criterio: ''||v_criterio||'', v_agrupador: ''||v_agrupador;',
'',
'			data.pk_comp_reportes.sp_gestionaprobaciongrupo(',
'				  p_compania		=> v_compania',
'				, p_modulo			=> v_modulo',
'				, p_aplicacion		=> :app_id',
'				, p_pagina			=> :app_page_id',
'				, p_usuario			=> :p113_usuario',
'				, p_aprobador		=> v_aprobador',
'				, p_idgrupo			=> v_idgrupo',
'				, p_grupoobjeto		=> null',
'				, p_objetos			=> null',
'				, p_opcion			=> v_opcion',
'				, p_respuesta		=> v_log_msg',
'			);',
'			data.pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,v_log_msg,null,null);',
'		end;',
'	end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(77179299335453512)
,p_internal_uid=>146172755056254508
,p_updated_on=>wwv_flow_imp.dz('20250828050144Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
