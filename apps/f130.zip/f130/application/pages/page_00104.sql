prompt --application/pages/page_00104
begin
--   Manifest
--     PAGE: 00104
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>104
,p_name=>'Dlg contrato orden'
,p_page_mode=>'MODAL'
,p_step_title=>'Contrato orden de pago'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20230708132652Z')
,p_last_updated_on=>wwv_flow_imp.dz('20200617155126Z')
,p_last_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6309534710673183)
,p_plug_name=>'Datos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(6311574683673203)
,p_name=>'Detalle'
,p_template=>wwv_flow_imp.id(296120613521169165)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'       DESCRIPCION PRODUCTO,',
'       CANTIDAD,',
'       PRECIO,',
'       COSTO,',
'       DESCRIPCIONADICIONAL DESCRIPCION',
'  from VT_JDE_ORDENCOMPRACONTRATO',
'where COMPANIA=:G_COMPANIA AND DOCUMENTONUMERO=:P104_NUMERO',
'AND DOCUMENTOTIPO=:P104_TIPO;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6311636261673204)
,p_query_column_id=>1
,p_column_alias=>'PRODUCTO'
,p_column_display_sequence=>1
,p_column_heading=>'Producto'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6311777365673205)
,p_query_column_id=>2
,p_column_alias=>'CANTIDAD'
,p_column_display_sequence=>2
,p_column_heading=>'Cantidad'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6311892237673206)
,p_query_column_id=>3
,p_column_alias=>'PRECIO'
,p_column_display_sequence=>3
,p_column_heading=>'Precio'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6311999064673207)
,p_query_column_id=>4
,p_column_alias=>'COSTO'
,p_column_display_sequence=>4
,p_column_heading=>'Costo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(11392298094511858)
,p_query_column_id=>5
,p_column_alias=>'DESCRIPCION'
,p_column_display_sequence=>5
,p_column_heading=>'Descripcion'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6309682256673184)
,p_name=>'P104_NUMERO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(6309534710673183)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6309794810673185)
,p_name=>'P104_TIPO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(6309534710673183)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6309868817673186)
,p_name=>'P104_COMPANIA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(6309534710673183)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6311315790673200)
,p_name=>'P104_FRECUENCIA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6309534710673183)
,p_prompt=>'Frecuencia'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6311330656673201)
,p_name=>'P104_PAGOS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(6309534710673183)
,p_prompt=>'Numero de pagos'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6311528523673202)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'V_CONTADOR NUMBER;',
'',
'BEGIN',
'',
'    SELECT COUNT(1) INTO V_CONTADOR FROM VT_JDE_ORDENCOMPRACONTRATO ',
'    where COMPANIA=:G_COMPANIA AND DOCUMENTONUMERO=:P104_NUMERO AND DOCUMENTOTIPO=:P104_TIPO;',
'    ',
'    IF(V_CONTADOR>0) THEN',
'',
'        select FRECUENCIAPAGO, NUMEROPAGO INTO',
'            :P104_FRECUENCIA, :P104_PAGOS',
'          from VT_JDE_ORDENCOMPRA_CAB ',
'        where COMPANIA=:G_COMPANIA AND DOCUMENTO=:P104_NUMERO AND DOCUMENTOTIPO=:P104_TIPO;',
'        ',
'    ELSE',
'         :P104_FRECUENCIA :='''';',
'         :P104_PAGOS :='''';',
'    END IF;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>6311528523673202
);
wwv_flow_imp.component_end;
end;
/
