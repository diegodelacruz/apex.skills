prompt --application/pages/page_00265
begin
--   Manifest
--     PAGE: 00265
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>265
,p_name=>unistr('Configuraci\00F3n para OC')
,p_alias=>unistr('CONFIGURACI\00D3N-PARA-OC')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Configuraci\00F3n para OC')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(regOcultos).hide();'
,p_step_template=>wwv_flow_imp.id(295596898750037659)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'300'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_created_on=>wwv_flow_imp.dz('20251112204417Z')
,p_last_updated_on=>wwv_flow_imp.dz('20251117155812Z')
,p_created_by=>'DDELACRUZ'
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(224410425431993407)
,p_plug_name=>'Ocultos'
,p_region_name=>'regOcultos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20251112204850Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152326Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(224412815240993431)
,p_plug_name=>'Region1'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P265_REGION1'
,p_plug_display_when_cond2=>'1'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20251112210625Z')
,p_updated_on=>wwv_flow_imp.dz('20251112210625Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(224412923715993432)
,p_plug_name=>'Region2'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P265_REGION2'
,p_plug_display_when_cond2=>'1'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20251112210625Z')
,p_updated_on=>wwv_flow_imp.dz('20251112211352Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(224413056238993433)
,p_plug_name=>'Region3'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>50
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P265_REGION3'
,p_plug_display_when_cond2=>'1'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20251112210625Z')
,p_updated_on=>wwv_flow_imp.dz('20251112211352Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(224413142585993434)
,p_plug_name=>'Region4'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>60
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P265_REGION4'
,p_plug_display_when_cond2=>'1'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20251112210625Z')
,p_updated_on=>wwv_flow_imp.dz('20251112211352Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(224413659433993439)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(224412815240993431)
,p_button_name=>'BTNFECHACOMPROMISO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-save'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_created_on=>wwv_flow_imp.dz('20251112215928Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152153Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(224414252022993445)
,p_button_sequence=>230
,p_button_plug_id=>wwv_flow_imp.id(224412923715993432)
,p_button_name=>'BTNPROVEEDOR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-save'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
,p_created_on=>wwv_flow_imp.dz('20251113135048Z')
,p_updated_on=>wwv_flow_imp.dz('20251113153754Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(224410545895993408)
,p_name=>'P265_COMPANIA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(224410425431993407)
,p_prompt=>'Compania'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20251112204850Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152152Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(224410655634993409)
,p_name=>'P265_MODULO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(224410425431993407)
,p_prompt=>'Modulo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20251112204850Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152152Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(224410796301993410)
,p_name=>'P265_USUARIO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(224410425431993407)
,p_prompt=>'Usuario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20251112204850Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152152Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(224410827835993411)
,p_name=>'P265_TIPORQ'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(224410425431993407)
,p_prompt=>'Tiporq'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20251112204850Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152152Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(224410998659993412)
,p_name=>'P265_NUMERORQ'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(224410425431993407)
,p_prompt=>'Numerorq'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20251112204851Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152152Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(224411046472993413)
,p_name=>'P265_TIPOOC'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(224410425431993407)
,p_prompt=>'Tipooc'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20251112204851Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152152Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(224411138535993414)
,p_name=>'P265_NUMEROOC'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(224410425431993407)
,p_prompt=>'Numerooc'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20251112204851Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152152Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(224411242210993415)
,p_name=>'P265_OPCION1'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(224410425431993407)
,p_prompt=>'Opcion1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20251112205040Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152152Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(224411693264993419)
,p_name=>'P265_OPCION2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(224410425431993407)
,p_prompt=>'Opcion2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20251112205040Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152152Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(224411741698993420)
,p_name=>'P265_OPCION3'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(224410425431993407)
,p_prompt=>'Opcion3'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20251112205041Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152152Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(224411920709993422)
,p_name=>'P265_OPCION4'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(224410425431993407)
,p_prompt=>'Opcion4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20251112205041Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152152Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(224412094938993423)
,p_name=>'P265_FLAG1'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(224410425431993407)
,p_prompt=>'Flag1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20251112205941Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152152Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(224412128296993424)
,p_name=>'P265_FLAG2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(224410425431993407)
,p_prompt=>'Flag2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20251112205941Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152152Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(224412200310993425)
,p_name=>'P265_FLAG3'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(224410425431993407)
,p_prompt=>'Flag3'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20251112205941Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152153Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(224412358329993426)
,p_name=>'P265_FLAG4'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(224410425431993407)
,p_prompt=>'Flag4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20251112205941Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152153Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(224412482884993427)
,p_name=>'P265_REGION1'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(224410425431993407)
,p_prompt=>'Region1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20251112210408Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152153Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(224412559550993428)
,p_name=>'P265_REGION2'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(224410425431993407)
,p_prompt=>'Region2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20251112210408Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152153Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(224412677895993429)
,p_name=>'P265_REGION3'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(224410425431993407)
,p_prompt=>'Region3'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20251112210408Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152153Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(224412757616993430)
,p_name=>'P265_REGION4'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(224410425431993407)
,p_prompt=>'Region4'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20251112210408Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152153Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(224413302721993436)
,p_name=>'P265_FECHACOMPROMISO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(224412815240993431)
,p_item_default=>'sysdate + 1'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Compromiso'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'STATIC'
,p_attribute_04=>'+1d'
,p_attribute_06=>'NONE'
,p_attribute_09=>'2'
,p_attribute_11=>'N'
,p_attribute_12=>'TODAY-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'IMAGE'
,p_created_on=>wwv_flow_imp.dz('20251112211352Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152152Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(224413454853993437)
,p_name=>'P265_TITULO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(224410425431993407)
,p_prompt=>'Titulo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20251112212413Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152151Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(224413528884993438)
,p_name=>'P265_MENSAJE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(224410425431993407)
,p_prompt=>'Mensaje'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20251112213130Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152151Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(250925472105574143)
,p_name=>'P265_PROVEEDOR'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(224412923715993432)
,p_prompt=>'Proveedor'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_JDE_PROVEEDORES_HAB'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'	TRIM(ABALPH) AS DESCRIPCION,',
'	TRIM(ABTAX) AS IDENTIFICACION,',
'	ABAN8  AS CODIGO',
'FROM f0101@jdedtadl inner join f0401@jdedtadl on aban8 = a6an8',
'where 1 = 1',
'	and decode(a6ato,'' '',''Y'',''Y'',''Y'',''N'') = ''Y''',
'ORDER BY ABALPH'))
,p_cSize=>30
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_created_on=>wwv_flow_imp.dz('20251113134939Z')
,p_updated_on=>wwv_flow_imp.dz('20251113153942Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(224413782420993440)
,p_name=>'Guardar FC'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(224413659433993439)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20251112220555Z')
,p_updated_on=>wwv_flow_imp.dz('20251117155017Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(224413864600993441)
,p_event_id=>wwv_flow_imp.id(224413782420993440)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
,p_created_on=>wwv_flow_imp.dz('20251112220555Z')
,p_updated_on=>wwv_flow_imp.dz('20251112220555Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(224413964130993442)
,p_event_id=>wwv_flow_imp.id(224413782420993440)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	UPDATE ',
'		T_COMP_PRODTO_PROVEEDR_GESTION  GESTION',
'	SET',
'	GESTION.FECHA_COMPROMISO      = :p265_fechacompromiso',
'	WHERE 1 = 1',
'		and usuario = :p265_usuario',
'		and documentotipo_oc is null',
'		and documento_oc is null;',
'end;'))
,p_attribute_02=>'P265_USUARIO,P265_FECHACOMPROMISO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20251112220556Z')
,p_updated_on=>wwv_flow_imp.dz('20251117155017Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(224414110588993444)
,p_event_id=>wwv_flow_imp.id(224413782420993440)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ocultarBarra();',
'mensajeExito("Datos Actualizados");'))
,p_created_on=>wwv_flow_imp.dz('20251112220556Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152801Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(224414308159993446)
,p_name=>'Guardar PRV'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(224414252022993445)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20251113151036Z')
,p_updated_on=>wwv_flow_imp.dz('20251117155812Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(224414499460993447)
,p_event_id=>wwv_flow_imp.id(224414308159993446)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
,p_created_on=>wwv_flow_imp.dz('20251113151036Z')
,p_updated_on=>wwv_flow_imp.dz('20251113151036Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(224414540174993448)
,p_event_id=>wwv_flow_imp.id(224414308159993446)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_proveedortipo		varchar2(10);',
'v_codproveedor		varchar2(25);',
'v_usuario			varchar2(25);',
'',
'v_opcion1	varchar2(100);',
'v_opcion2	varchar2(100);',
'v_opcion3	varchar2(100);',
'v_opcion4	varchar2(100);',
'',
'v_negdetid	number;',
'',
'v_log_app	varchar2(100);',
'v_log_dsc	varchar2(999);',
'v_log_msg	varchar2(999);',
'v_log_obs	varchar2(999);',
'v_log_qty	number;',
'begin',
'	v_log_app		:= ''apex.130.265.ad.proveedor'';',
'',
'	v_opcion1		:= :p265_opcion1;',
'	v_opcion2		:= :p265_opcion2;',
'	v_opcion3		:= :p265_opcion3;',
'	v_opcion4		:= :p265_opcion4;',
'',
'	v_log_dsc := ''v_opcion1: ''||v_opcion1||'', v_opcion2: ''||v_opcion2||'', v_opcion3: ''||v_opcion3||'', v_opcion4: ''||v_opcion4;',
'',
'	v_codproveedor	:= :p265_proveedor;',
'	v_usuario		:= :p265_usuario;',
'',
'    -- Tipo de proveedor',
'    select tipo ',
'    into   v_proveedortipo',
'    from   vt_jde_maestroproveedor ',
'    where  codigoproveedor = v_codproveedor;',
'',
'	v_log_msg := ''v_usuario: ''||v_usuario||'', v_codproveedor: ''||v_codproveedor||'', v_proveedortipo: ''||v_proveedortipo;',
'',
'	data.pk_commons.sp_apex_log(v_log_app,1,v_log_dsc,v_log_msg,v_log_obs,null);',
'',
'    if v_opcion1 = ''NOINV'' then',
'		update ',
'			t_comp_prodto_proveedr_gestion  gestion',
'		set',
'			gestion.codproveedor	= v_codproveedor,',
'			gestion.proveedortipo	= v_proveedortipo',
'		where 1 = 1',
'			and usuario = v_usuario',
'			and documentotipo_oc is null',
'			and documento_oc is null;',
'		v_log_qty := sql%rowcount;',
'		v_log_obs := ''Registros afectados: ''||v_log_qty;',
'',
'		data.pk_commons.sp_apex_log(v_log_app,2,v_log_dsc,v_log_msg,v_log_obs,null);',
'	end if;',
'',
'	if v_opcion1 = ''INV'' then',
'		for item in (',
'			select * from data.vt_comp_pendiente_generar_oc',
'			where 1 = 1',
'				and tipo_requisicion in (''H1'',''H3'')',
'				and compania = :g_compania',
'				and usuario = v_usuario',
'				and fecha_procesado is null',
'		) loop',
'		begin',
'			v_negdetid := 0;',
'			begin',
'				v_log_obs := ''item.codigocortoproducto: ''||item.codigocortoproducto||'', item.id: ''||item.id;',
'',
'				select det_id into v_negdetid',
'				from data.vt_comp_negociacionsel',
'				where 1 = 1',
'					and det_codproducto = item.codigocortoproducto',
'					and det_codproveedor = v_codproveedor',
'					and det_vigente = ''SI''',
'					and neg_esquemahab = ''SI''',
'					and neg_estadoflujo = ''APROBADO''',
'					and rownum = 1;',
'',
'				exception when others then v_negdetid := -1;',
'			end;',
'',
'			if v_negdetid > 0 then',
'				v_log_obs := ''data.pk_comp_gestioncompras.sp_set_ppgestion_negociacion(''||item.id||'',''||v_negdetid||'');'';',
'				data.pk_comp_gestioncompras.sp_set_ppgestion_negociacion(item.id,v_negdetid);',
'				commit;',
'			else',
'				v_log_obs := ''v_negdetid: ''||v_negdetid||'' => continue'';',
'				continue;',
'			end if;',
'			data.pk_commons.sp_apex_log(v_log_app,2,v_log_dsc,v_log_msg,v_log_obs,null);',
'		end;',
'		end loop;',
'	end if;',
'end;'))
,p_attribute_02=>'P265_OPCION1,P265_OPCION2,P265_OPCION3,P265_OPCION4,P265_USUARIO,P265_PROVEEDOR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20251113151036Z')
,p_updated_on=>wwv_flow_imp.dz('20251117155812Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(224414674684993449)
,p_event_id=>wwv_flow_imp.id(224414308159993446)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ocultarBarra();',
'mensajeExito("Datos Actualizados");'))
,p_created_on=>wwv_flow_imp.dz('20251113151036Z')
,p_updated_on=>wwv_flow_imp.dz('20251113152801Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(224413253958993435)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetUp'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_titulo	varchar2(100);',
'v_mensaje	varchar2(500);',
'v_compania	varchar2(5);',
'v_modulo	varchar2(4);',
'v_usuario	varchar2(25);',
'v_tiporq	varchar2(10);',
'v_numerorq	varchar2(25);',
'v_tipooc	varchar2(10);',
'v_numerooc	varchar2(25);',
'v_opcion1	varchar2(100);',
'v_opcion2	varchar2(100);',
'v_opcion3	varchar2(100);',
'v_opcion4	varchar2(100);',
'v_flag1		varchar2(100);',
'v_flag2		varchar2(100);',
'v_flag3		varchar2(100);',
'v_flag4		varchar2(100);',
'v_region1	varchar2(100);',
'v_region2	varchar2(100);',
'v_region3	varchar2(100);',
'v_region4	varchar2(100);',
'begin',
'	v_region1 := 0; v_region2 := 0; v_region3 := 0; v_region4 := 0;',
'',
'	begin',
'		v_compania	:= :p265_compania;',
'		v_modulo	:= :p265_modulo;',
'		v_usuario	:= :p265_usuario;',
'		v_tiporq	:= :p265_tiporq;',
'		v_numerorq	:= :p265_numerorq;',
'		v_tipooc	:= :p265_tipooc;',
'		v_numerooc	:= :p265_numerooc;',
'		v_opcion1	:= :p265_opcion1;',
'		v_opcion2	:= :p265_opcion2;',
'		v_opcion3	:= :p265_opcion3;',
'		v_opcion4	:= :p265_opcion4;',
'	end;',
'',
'	begin	-- Fecha de Compromiso',
'		if v_opcion1 = v_opcion1 and v_opcion2 = ''FECHACOMPROMISO'' then',
'			v_region1	:= 1;',
unistr('			v_titulo	:= ''Modificaci\00F3n de la Fecha de Compromiso'';'),
'		end if;	-- Proveedor',
'',
'		if v_opcion1 = v_opcion1 and v_opcion2 = ''PROVEEDOR'' then',
'			v_region2	:= 1;',
unistr('			v_titulo	:= ''Modificaci\00F3n del Proveedor'';'),
'		end if;',
'	end;',
'',
'	begin	-- Habilita Regiones',
unistr('		v_mensaje	:= ''Se va a realizar un cambio masivo a los registros de la requisici\00F3n'';'),
'',
'		:p265_region1 := v_region1;',
'		:p265_region2 := v_region2;',
'		:p265_region3 := v_region3;',
'		:p265_region4 := v_region4;',
'',
'		:p265_titulo := v_titulo;',
'		:p265_mensaje := v_mensaje;',
'	end;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>224413253958993435
,p_created_on=>wwv_flow_imp.dz('20251112211203Z')
,p_updated_on=>wwv_flow_imp.dz('20251114213358Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
