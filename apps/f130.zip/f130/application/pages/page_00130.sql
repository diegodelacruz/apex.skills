prompt --application/pages/page_00130
begin
--   Manifest
--     PAGE: 00130
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>130
,p_name=>'OI - Mesa de Trabajo'
,p_step_title=>unistr('Cierre de \00D3rdenes de Importaci\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230708132654Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260409211051Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44411030417481237)
,p_plug_name=>'Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44411124413481238)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(62291506842561002)
,p_plug_name=>'mesa'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61812614523560239)
,p_plug_name=>'Mesa de trabajo'
,p_parent_plug_id=>wwv_flow_imp.id(62291506842561002)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  mesaFinal.*',
'    , (SELECT  PK_CORP_FLUJOAPROBACION.F_MESAICONORUTA(APROBADOR) FROM DUAL) RUTA',
'    , (SELECT  PK_CORP_FLUJOAPROBACION.F_MESAORDEN(CSS) FROM DUAL) ORDEN',
'    FROM (SELECT mesa.* ,(SELECT  PK_CORP_FLUJOAPROBACION.F_GESTIONCOLOR(:APP_USER, APROBADOR, NULL, :G_COMPANIA, :APP_MODULO) FROM DUAL) CSS',
'          FROM VT_COMP_MESATRABAJO_CIERREOI mesa',
'              where compania = :G_COMPANIA',
'              AND ( ',
'                 (:P130_TIPO=2 AND trunc(FECHA_INICIO) between :P130_FECHA_INICIO and :P130_FECHA_FIN )',
'                  OR',
'                 (:P130_TIPO=1 AND APROBADOR IS NOT NULL  AND  PK_CORP_FLUJOAPROBACION.F_APROBADORFLUJO(:APP_USER, APROBADOR, :APP_MODULO, :G_COMPANIA)=1)',
'              )',
'          ) mesaFinal;'))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(61812720890560240)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'HTML:CSV'
,p_enable_mail_download=>'N'
,p_owner=>'JALTAMIRANO'
,p_internal_uid=>61812720890560240
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61812822092560241)
,p_db_column_name=>'PROCESO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Proceso'
,p_column_link=>'f?p=&APP_ID.:131:&SESSION.::&DEBUG.:RP,131:P131_NUMEROORDEN:#PROCESO#'
,p_column_linktext=>'<span class=''#CSS#''>Proceso: #PROCESO#</span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61812920539560242)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61813027691560243)
,p_db_column_name=>'ESTADO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61813179860560244)
,p_db_column_name=>'APROBADOR'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Aprobador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61813215141560245)
,p_db_column_name=>'USUARIOULTIMO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Usuarioultimo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61813473601560247)
,p_db_column_name=>'FECHA_INICIO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fecha Inicio'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61813575422560248)
,p_db_column_name=>'FECHA_FIN'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Fecha Fin'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61813670671560249)
,p_db_column_name=>'CSS'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Css'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(62291469467561001)
,p_db_column_name=>'ORDEN'
,p_display_order=>100
,p_column_identifier=>'K'
,p_column_label=>'Orden'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61813757750560250)
,p_db_column_name=>'RUTA'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Ruta'
,p_column_link=>'f?p=100:104:&SESSION.::&DEBUG.:RP:G_OBJETO,G_OBJETO_ID,G_TODO:COMPRAS,#PROCESO#,true'
,p_column_linktext=>'#RUTA#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(61813342806560246)
,p_db_column_name=>'COMPANIA'
,p_display_order=>120
,p_column_identifier=>'F'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(62316801403692950)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'623169'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PROCESO:DESCRIPCION:ESTADO:APROBADOR:USUARIOULTIMO:FECHA_INICIO:FECHA_FIN:COMPANIA:RUTA:'
,p_sort_column_1=>'FECHA_INICIO'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20230708132654Z')
,p_updated_on=>wwv_flow_imp.dz('20230708132654Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(44411330102481240)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(44411030417481237)
,p_button_name=>'Buscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(44411280674481239)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(44411030417481237)
,p_button_name=>'Crear'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Crear'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:131:&SESSION.::&DEBUG.:RP,131::'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(62291637732561003)
,p_name=>'P130_TIPO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(44411124413481238)
,p_item_default=>'1'
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_UDC_ESTADOMESA'
,p_lov=>'SELECT DESCRIPCION, ID_TABLA FROM T_CORP_UDC WHERE id_cabecera=''ESTADOMESA'' ORDER BY id_tabla;'
,p_cHeight=>1
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(62291773301561004)
,p_name=>'P130_FECHA_INICIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(44411124413481238)
,p_prompt=>'Fecha Inicio'
,p_source=>'SELECT ADD_MONTHS(SYSDATE,-1)FROM DUAL'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(62291892547561005)
,p_name=>'P130_FECHA_FIN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(44411124413481238)
,p_prompt=>'Fecha Fin'
,p_source=>'SELECT SYSDATE FROM DUAL'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp.component_end;
end;
/
