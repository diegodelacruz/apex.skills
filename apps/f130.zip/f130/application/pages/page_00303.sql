prompt --application/pages/page_00303
begin
--   Manifest
--     PAGE: 00303
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>303
,p_name=>'Fechas de Entrega'
,p_step_title=>'Fechas de Entrega'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230708132659Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260702194115Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(88942640052347214)
,p_plug_name=>'Detalles'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with w4305 as (',
'	select pldoco, pldcto, pllgty, pk_commons.f_jde2g(max(plissu)) plissu',
'	from f4305@jdedtadl',
'	where :p303_bandera = 1',
'	group by pldoco, pldcto, pllgty',
'), comentarios as (',
'	select tiporeg, ordencompra, tipooc, linea',
'		, listagg(''[''||to_char(fechcrea,''dd/mm/yyyy hh24:mi'')||''] ''||informacion,chr(10)) within group (order by id) informacion',
'	from data.t_comp_infoadicionaloc',
'	where :p303_bandera = 1 and registro = ''COM''',
'	group by tiporeg, ordencompra, tipooc, linea',
')',
'select a.rqdoco',
'	, a.rqdcto',
'	-- , rq.pdnxtr rqnxtr',
'	-- , rq.pdlttr rqlttr',
'	, a.ocdoco',
'	, a.ocdcto',
'	, oc.pdlttr||''-''||oc.pdnxtr stdoc',
'	-- , oc.pdnxtr ocnxtr',
'	-- , oc.pdlttr oclttr',
'	, a.oidoco',
'	, a.oidcto',
'	-- , oi.pdnxtr oinxtr',
'	-- , oi.pdlttr oilttr',
'	, a.oclnid/1000 oclnid',
'	, oc.pdan8 codproveedor',
'	, oc.pdan8 proveedor',
'	, trim(oc.pdlitm) codproducto',
'	, trim(oc.pddsc1)||'' ''||trim(oc.pddsc2) producto',
'	, oc.pduom um',
'	, oc.pduorg/10000 cantpedoc',
'	, oi.pduorg/10000 cantpedoi',
'	, oc.pdurec/10000 cantrecoc',
'	, oi.pdurec/10000 cantrecoi',
'	, oc.pduopn/10000 cantpenoc',
'	, oi.pduopn/10000 cantpenoi',
'	, oc.pdprrc/10000 preciouoc',
'	, oi.pdprrc/10000 preciouoi',
'	, oc.pdaexp/100 montoutoc',
'	, decode(nvl(a.oidoco,0),0,0,oi.pdaexp)/100 montoutoi',
'	, pk_commons.f_jde2g(rq.pddrqj) fingrq',
'	, pk_commons.f_jde2g(oc.pddrqj) fechoc',
'	, pk_commons.f_jde2g(oc.pdtrdj) faproc	-- U',
'	, case when a.ocdcto in (''BM'',''BN'') then oc1.plissu else null end etdoc	-- V',
'	, case when a.ocdcto in (''BM'',''BN'') then oc2.plissu else case when a.ocdcto in (''CM'',''CN'') then a.ocpddj else null end end fepoc	-- W',
'	, oc3.plissu etdoi	-- X',
'	, oc4.plissu feroi	-- Y',
'	, case when a.oidoco is not null then oc5.plissu else (case when a.ocaddj is null then data.pk_commons.f_jde2g(oc.pddgl) else a.ocaddj end) end feroi2	-- X(2) OC Cerradas.',
'	, case when a.oidoco is not null then oc4.plissu else trunc(sysdate) end',
'		- (case when a.ocdcto in (''BM'',''BN'') then oc2.plissu else case when a.ocdcto in (''CM'',''CN'') then a.ocpddj else null end end) dfireavsprm	-- Z',
'	, (case when a.oidoco is not null then oc5.plissu else a.ocaddj end)',
'		- (case when a.ocdcto in (''BM'',''BN'') then oc2.plissu else case when a.ocdcto in (''CM'',''CN'') then a.ocpddj else null end end) dfireavsprm2	-- Y(2) OC Cerradas.',
'	, case when a.oidoco is not null then oc3.plissu - pk_commons.f_jde2g(oc.pdtrdj) else null end ltpro	-- AA',
'	, case when a.oidoco is not null then oc4.plissu - oc3.plissu else null end ltimp	-- AB',
'	, oc.pdptc',
'	, oc.pdanby',
'	, rq.pdan8 codreqtr',
'	, rq.pdan8 reqtr',
'	, c.categoria',
'	, c.subcategoriaproducto',
'	, ''<span title="Fechas"class="fa fa-calendar-o"/>'' cambiofechas',
'	-- , ''<span title="Comentarios"class="fa fa-comments-o"/>'' comentario',
'	, ''<span title="Comentarios"class="fa fa-comments''||case when nvl(coc.informacion,''X'') != ''X'' or nvl(cln.informacion,''X'') != ''X'' then ''"/>'' else ''-o"/>'' end comentario',
'	, coc.informacion informacionoc',
'	, cln.informacion informacionln',
'from data.vt_comp_ordencompra a',
'left join f4311@jdedtadl rq on a.ocitm = rq.pditm and a.rqdcto = rq.pddcto and a.rqdoco = rq.pddoco and rq.pdkcoo = rq.pdkcoo and rq.pdsfxo = rq.pdsfxo and a.oclnid = a.oclnid',
'inner join f4311@jdedtadl oc on a.ocitm = oc.pditm and a.ocdcto = oc.pddcto and a.ocdoco = oc.pddoco and oc.pdkcoo = oc.pdkcoo and oc.pdsfxo = oc.pdsfxo and a.oclnid = a.oclnid',
'left join f4311@jdedtadl oi on a.ocitm = oi.pditm and a.oidcto = oi.pddcto and a.oidoco = oi.pddoco and oi.pdkcoo = oi.pdkcoo and oi.pdsfxo = oi.pdsfxo and a.oclnid = a.oclnid',
'left join w4305 oc1 on a.ocdcto = oc1.pldcto and a.ocdoco = oc1.pldoco and oc1.pllgty = ''1''',
'left join w4305 oc2 on a.ocdcto = oc2.pldcto and a.ocdoco = oc2.pldoco and oc2.pllgty = ''3''',
'left join w4305 oc3 on a.oidcto = oc3.pldcto and a.oidoco = oc3.pldoco and oc3.pllgty = ''1''',
'left join w4305 oc4 on a.oidcto = oc4.pldcto and a.oidoco = oc4.pldoco and oc4.pllgty = ''2''',
'left join w4305 oc5 on a.oidcto = oc5.pldcto and a.oidoco = oc5.pldoco and oc5.pllgty = ''2''',
'inner join vt_jde_productos c on a.ocitm = c.codigocorto',
'left join comentarios coc on a.ocdoco = coc.ordencompra and a.ocdcto = coc.tipooc and coc.tiporeg = ''O'' and coc.linea = 0',
'left join comentarios cln on a.ocdoco = cln.ordencompra and a.ocdcto = cln.tipooc and a.oclnid = cln.linea and cln.tiporeg = ''L''',
'where :p303_bandera = 1',
'and a.ocdcto != ''OI''',
'and (a.ocdcto = :p303_tipoorden or :p303_tipoorden is null)',
'and a.octrdj between pk_commons.f_g2jde(:p303_fechadesde) and pk_commons.f_g2jde(:p303_fechahasta)',
'and (oc.pdanby = :p303_comprador or :p303_comprador is null)',
'and	(case when a.oidcto is null then (case when oc.pdnxtr = ''999'' then (case when a.ocdcto = ''CM'' and oc.pdurec = 0 then -1 else 0 end) else 1 end) else',
'	(case when oc.pdnxtr = ''999'' and oi.pdnxtr = ''999'' then 0 else 1 end) end) = (case when :p303_tipo = ''C'' then 0 else 1 end);'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P303_TIPOORDEN,P303_FECHADESDE,P303_FECHAHASTA,P303_COMPRADOR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Detalles'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20260702194115Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(75516919009693735)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'JALTAMIRANO'
,p_internal_uid=>75516919009693735
,p_updated_on=>wwv_flow_imp.dz('20260702194115Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(288722113044113148)
,p_db_column_name=>'RQDOCO'
,p_display_order=>510
,p_column_identifier=>'AV'
,p_column_label=>unistr('N\00FAm. RQ.')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(288722242674113149)
,p_db_column_name=>'RQDCTO'
,p_display_order=>520
,p_column_identifier=>'AW'
,p_column_label=>'TRQ'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(288722332954113150)
,p_db_column_name=>'OCDOCO'
,p_display_order=>530
,p_column_identifier=>'AX'
,p_column_label=>unistr('N\00FAm. OC')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293275552521548101)
,p_db_column_name=>'OCDCTO'
,p_display_order=>540
,p_column_identifier=>'AY'
,p_column_label=>'TOC'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293275691348548102)
,p_db_column_name=>'OIDOCO'
,p_display_order=>550
,p_column_identifier=>'AZ'
,p_column_label=>unistr('N\00FAm. OI')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293275716147548103)
,p_db_column_name=>'OIDCTO'
,p_display_order=>560
,p_column_identifier=>'BA'
,p_column_label=>'TOI'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293275877248548104)
,p_db_column_name=>'OCLNID'
,p_display_order=>570
,p_column_identifier=>'BB'
,p_column_label=>unistr('N\00FAm. L\00EDn. OC')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(288720473595113131)
,p_db_column_name=>'CODPROVEEDOR'
,p_display_order=>580
,p_column_identifier=>'AE'
,p_column_label=>unistr('C\00F3d. Prov.')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(75517286448693738)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>590
,p_column_identifier=>'C'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293275982995548105)
,p_db_column_name=>'CODPRODUCTO'
,p_display_order=>600
,p_column_identifier=>'BC'
,p_column_label=>unistr('C\00F3d. Producto')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293276052564548106)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>610
,p_column_identifier=>'BD'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(75517740053693743)
,p_db_column_name=>'UM'
,p_display_order=>620
,p_column_identifier=>'H'
,p_column_label=>'UM'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(288721944358113146)
,p_db_column_name=>'CATEGORIA'
,p_display_order=>630
,p_column_identifier=>'AT'
,p_column_label=>unistr('Categor\00EDa')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(288722065003113147)
,p_db_column_name=>'SUBCATEGORIAPRODUCTO'
,p_display_order=>640
,p_column_identifier=>'AU'
,p_column_label=>unistr('Subcategor\00EDa')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293276173254548107)
,p_db_column_name=>'CANTPEDOC'
,p_display_order=>650
,p_column_identifier=>'BE'
,p_column_label=>'Cant. Sol. OC'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293276234085548108)
,p_db_column_name=>'CANTPEDOI'
,p_display_order=>660
,p_column_identifier=>'BF'
,p_column_label=>'Cant. Sol. OI'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293276373388548109)
,p_db_column_name=>'CANTRECOC'
,p_display_order=>670
,p_column_identifier=>'BG'
,p_column_label=>'Cant. Rec. OC'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(288720865156113135)
,p_db_column_name=>'CANTRECOI'
,p_display_order=>680
,p_column_identifier=>'AI'
,p_column_label=>'Cant. Rec. OI'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293276494497548110)
,p_db_column_name=>'CANTPENOC'
,p_display_order=>690
,p_column_identifier=>'BH'
,p_column_label=>'Cant. Pen. OC'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P303_TIPO'
,p_display_condition2=>'A'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(288720949725113136)
,p_db_column_name=>'CANTPENOI'
,p_display_order=>700
,p_column_identifier=>'AJ'
,p_column_label=>'Cant. Pen. OI'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P303_TIPO'
,p_display_condition2=>'A'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293276575257548111)
,p_db_column_name=>'PRECIOUOC'
,p_display_order=>710
,p_column_identifier=>'BI'
,p_column_label=>'Precio Un. OC'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293276622352548112)
,p_db_column_name=>'PRECIOUOI'
,p_display_order=>720
,p_column_identifier=>'BJ'
,p_column_label=>'Precio Un. OI'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293276704144548113)
,p_db_column_name=>'MONTOUTOC'
,p_display_order=>730
,p_column_identifier=>'BK'
,p_column_label=>'Mnt. Prod. OC'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293276838178548114)
,p_db_column_name=>'MONTOUTOI'
,p_display_order=>740
,p_column_identifier=>'BL'
,p_column_label=>'Mnt. Prod. OI'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293276966821548115)
,p_db_column_name=>'FINGRQ'
,p_display_order=>750
,p_column_identifier=>'BM'
,p_column_label=>'Fe. RQ.'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293277047008548116)
,p_db_column_name=>'FECHOC'
,p_display_order=>760
,p_column_identifier=>'BN'
,p_column_label=>'Fe. OC'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293277115753548117)
,p_db_column_name=>'FAPROC'
,p_display_order=>810
,p_column_identifier=>'BO'
,p_column_label=>'Fe. Apro. OC'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293277240693548118)
,p_db_column_name=>'ETDOC'
,p_display_order=>820
,p_column_identifier=>'BP'
,p_column_label=>'ETD OC'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293277347197548119)
,p_db_column_name=>'FEPOC'
,p_display_order=>830
,p_column_identifier=>'BQ'
,p_column_label=>'Fe. Prm. OC'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293277418065548120)
,p_db_column_name=>'ETDOI'
,p_display_order=>840
,p_column_identifier=>'BR'
,p_column_label=>'ETD OI'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293277590621548121)
,p_db_column_name=>'FEROI'
,p_display_order=>850
,p_column_identifier=>'BS'
,p_column_label=>'Fe. Real OI'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293278190232548127)
,p_db_column_name=>'FEROI2'
,p_display_order=>860
,p_column_identifier=>'BX'
,p_column_label=>'Fe. Real OI*'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293277634747548122)
,p_db_column_name=>'DFIREAVSPRM'
,p_display_order=>870
,p_column_identifier=>'BT'
,p_column_label=>'Real VS. Prom.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293278213031548128)
,p_db_column_name=>'DFIREAVSPRM2'
,p_display_order=>880
,p_column_identifier=>'BY'
,p_column_label=>'Real VS. Prom.*'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293277791378548123)
,p_db_column_name=>'PDPTC'
,p_display_order=>890
,p_column_identifier=>'BU'
,p_column_label=>'Cond. Pago'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(291135880889049209)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293277858471548124)
,p_db_column_name=>'PDANBY'
,p_display_order=>900
,p_column_identifier=>'BV'
,p_column_label=>'Comprador'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293277983012548125)
,p_db_column_name=>'REQTR'
,p_display_order=>910
,p_column_identifier=>'BW'
,p_column_label=>'Requisitor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(288721773528113144)
,p_db_column_name=>'LTPRO'
,p_display_order=>920
,p_column_identifier=>'AR'
,p_column_label=>'LT PRO'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(288721871469113145)
,p_db_column_name=>'LTIMP'
,p_display_order=>930
,p_column_identifier=>'AS'
,p_column_label=>'LT IMP'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(76784295253515007)
,p_db_column_name=>'CAMBIOFECHAS'
,p_display_order=>940
,p_column_identifier=>'V'
,p_column_label=>'Cambio Fechas'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(158731131671706401)
,p_db_column_name=>'COMENTARIO'
,p_display_order=>950
,p_column_identifier=>'AB'
,p_column_label=>'-'
,p_column_link=>'f?p=&APP_ID.:128:&SESSION.::&DEBUG.:RP,128:P128_TIPOREGISTRO,P128_PROVEEDOR,P128_ORDENCOMPRA,P128_TIPOOC,P128_LINEA,P128_PERSONA:COM,#CODPROVEEDOR#,#OCDOCO#,#OCDCTO#,#OCLNID#,#CODREQTR#'
,p_column_linktext=>'#COMENTARIO#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(293280242608548148)
,p_db_column_name=>'STDOC'
,p_display_order=>960
,p_column_identifier=>'BZ'
,p_column_label=>unistr('Est. L\00EDn.')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309876802316927811)
,p_db_column_name=>'CODREQTR'
,p_display_order=>970
,p_column_identifier=>'CA'
,p_column_label=>'Codreqtr'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309877191208927814)
,p_db_column_name=>'INFORMACIONOC'
,p_display_order=>980
,p_column_identifier=>'CB'
,p_column_label=>'Com. OC'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(309877248442927815)
,p_db_column_name=>'INFORMACIONLN'
,p_display_order=>990
,p_column_identifier=>'CC'
,p_column_label=>'Com. LN'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(76821897959521697)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'768219'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100
,p_report_columns=>'COMENTARIO:RQDOCO:RQDCTO:OCDOCO:OCDCTO:OIDOCO:OIDCTO:STDOC:OCLNID:CODPROVEEDOR:PROVEEDOR:CODPRODUCTO:PRODUCTO:UM:CATEGORIA:SUBCATEGORIAPRODUCTO:CANTPEDOC:CANTPEDOI:CANTRECOC:CANTRECOI:CANTPENOC:CANTPENOI:PRECIOUOC:PRECIOUOI:MONTOUTOC:MONTOUTOI:FINGRQ'
||':FECHOC:FAPROC:ETDOC:FEPOC:ETDOI:FEROI:FEROI2:DFIREAVSPRM:DFIREAVSPRM2:LTPRO:LTIMP:PDPTC:PDANBY:REQTR:'
,p_sort_column_1=>'OCDCTO'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'OCDOCO'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'OCLNID'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20230708132659Z')
,p_updated_on=>wwv_flow_imp.dz('20230708132659Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(89233383152677177)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1125616174926257879)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(44653976701562673)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1125616174926257879)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44658562671562678)
,p_name=>'P303_TIPOORDEN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(89233383152677177)
,p_prompt=>'Tipo de Orden: '
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:BM;BM,BN;BN,CE;CE,CN;CN,CM;CM'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44658903990562678)
,p_name=>'P303_COMPRADOR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(89233383152677177)
,p_prompt=>'Comprador: '
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct apellidos||'' ''||nombres a, pdanby b from f4311@jdedtadl,vt_corp_usuario',
'where pdanby = coderp',
'and pddcto in (''CM'',''BM'',''CE'',''CN'',''BN'',''OI'')',
'and pdtrdj between pk_commons.f_g2jde(:p303_fechadesde) and pk_commons.f_g2jde(:p303_fechahasta)',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_cascade_parent_items=>'P303_FECHADESDE,P303_FECHAHASTA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44659304114562680)
,p_name=>'P303_FECHADESDE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(89233383152677177)
,p_item_default=>'trunc(add_months(sysdate,-1),''month'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Desde:'
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'both'
,p_attribute_05=>'N'
,p_attribute_07=>'MONTH_AND_YEAR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44659714835562680)
,p_name=>'P303_FECHAHASTA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(89233383152677177)
,p_item_default=>'sysdate'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Hasta:'
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'both'
,p_attribute_05=>'N'
,p_attribute_07=>'MONTH_AND_YEAR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(250535840671615229)
,p_name=>'P303_TIPO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(89233383152677177)
,p_item_default=>'A'
,p_prompt=>unistr('\00D3rdenes')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:Abiertas;A,Cerradas;C'
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(293278368660548129)
,p_name=>'P303_BANDERA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(89233383152677177)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46725951488540115)
,p_name=>'Actualiza Reporte'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(88942640052347214)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46726386835540117)
,p_event_id=>wwv_flow_imp.id(46725951488540115)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(293278043204548126)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Separador'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	execute immediate ''ALTER SESSION SET NLS_NUMERIC_CHARACTERS =''''.,'''''';',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>293278043204548126
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(293278475930548130)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('B\00FAsqueda')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    :P303_BANDERA := 1;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(44653976701562673)
,p_internal_uid=>293278475930548130
);
wwv_flow_imp.component_end;
end;
/
