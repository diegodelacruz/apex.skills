prompt --application/pages/page_00242
begin
--   Manifest
--     PAGE: 00242
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>242
,p_name=>unistr('Revisi\00F3n Flete')
,p_alias=>unistr('REVISI\00D3N-FLETE')
,p_step_title=>unistr('Revisi\00F3n Flete')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240410163754Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240321201004Z')
,p_last_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(182397402438520024)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(182397506180520025)
,p_plug_name=>unistr('Revisi\00F3n Flete')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT IDPROCESO,NVL(FLETECOTIZADO,0) FLETECOTIZADO, NVL(GASTOSLOCALCOTIZADO,0) GASTOSLOCALCOTIZADO,',
'NVL((SELECT MONTOPROVISION',
' FROM T_CMEX_MESATRABAJO Y,t_cmex_provision Z, t_cmex_provision_DETALLE V',
' WHERE X.ID=Y.ID_MUESTRA AND Z.ID_CMEX_MESATRABAJO=Y.ID AND Z.ID=V.ID_CABECERA ',
' AND V.CONCEPTO IN (130)),0) FLETE_INTER,',
'NVL((SELECT MONTOPROVISION',
' FROM T_CMEX_MESATRABAJO Y,t_cmex_provision Z, t_cmex_provision_DETALLE V',
' WHERE X.ID=Y.ID_MUESTRA AND Z.ID_CMEX_MESATRABAJO=Y.ID AND Z.ID=V.ID_CABECERA ',
' AND V.CONCEPTO IN (155)),0) GASTOSLOCALES, USERCREA,CODIGOPROVEEDOR,',
' (SELECT FECHATURNO FROM T_CMEX_MESATRABAJO Y WHERE X.ID=Y.ID_MUESTRA) FECHATURNO',
'FROM T_CMEX_MUESTRAS X',
'WHERE EXISTS (SELECT ''X''',
'            FROM T_CMEX_MESATRABAJO L',
'            WHERE TO_CHAR(FECHATURNO,''DD/MM/YYYY'') BETWEEN TO_DATE(:P242_FECHADESDE,''DD/MM/YYYY'') AND TO_DATE(:P242_FECHAHASTA,''DD/MM/YYYY'')',
'            AND L.ID_MUESTRA=X.ID)',
'ORDER BY 1',
';'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Revisi\00F3n Flete')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(182398397535520033)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MALBAN'
,p_internal_uid=>182398397535520033
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182398499619520034)
,p_db_column_name=>'IDPROCESO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>unistr('Id Importaci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182398546912520035)
,p_db_column_name=>'FLETECOTIZADO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Flete Cotizado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182398677610520036)
,p_db_column_name=>'GASTOSLOCALCOTIZADO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Gastos Local Cotizado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182398725656520037)
,p_db_column_name=>'FLETE_INTER'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Flete Internacional Facturado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182398807094520038)
,p_db_column_name=>'GASTOSLOCALES'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Gastos Locales Facturados'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182398916675520039)
,p_db_column_name=>'USERCREA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Usuario Iniciador'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182399083177520040)
,p_db_column_name=>'CODIGOPROVEEDOR'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(165398581949586903)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182399240257520042)
,p_db_column_name=>'FECHATURNO'
,p_display_order=>80
,p_column_identifier=>'I'
,p_column_label=>'Fecha turno'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(182742707666581274)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1827428'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'IDPROCESO:FLETECOTIZADO:GASTOSLOCALCOTIZADO:FLETE_INTER:GASTOSLOCALES:USERCREA:CODIGOPROVEEDOR:FECHATURNO:'
,p_created_on=>wwv_flow_imp.dz('20240410163754Z')
,p_updated_on=>wwv_flow_imp.dz('20240410163754Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(182399386584520043)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(182700336295165325)
,p_plug_name=>'Flete Internacional  Aprobado vs Facturado'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296122226350169167)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(182399692918520046)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(182397402438520024)
,p_button_name=>'Buscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Buscar'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182399473980520044)
,p_name=>'P242_FECHADESDE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(182399386584520043)
,p_prompt=>'Fecha desde: '
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182399551421520045)
,p_name=>'P242_FECHAHASTA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(182399386584520043)
,p_prompt=>'Fecha hasta: '
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp.component_end;
end;
/
