prompt --application/pages/page_00241
begin
--   Manifest
--     PAGE: 00241
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>241
,p_name=>unistr('Liquidaci\00F3n Costos Muestras')
,p_alias=>unistr('LIQUIDACI\00D3N-COSTOS-MUESTRAS')
,p_step_title=>unistr('Liquidaci\00F3n Costos Muestras')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'th#P182396514032520015_1,th#P182396514032520015_2 {',
'    display: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240410163712Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240611150718Z')
,p_last_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(179499865964796547)
,p_plug_name=>'barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(179499922459796548)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(182392617245477168)
,p_plug_name=>unistr('Liquidaci\00F3n Costos Muestras')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296122226350169167)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(182395512439520005)
,p_plug_name=>unistr('Importaci\00F3n Muestras')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT X.CODIGOPROVEEDOR,X.CENTRODECOSTO,NAVIERA,CONCEPTO,SUM(MONTOPROVISION) VALOR, 1 ORDEN',
'FROM T_CMEX_MUESTRAS X, T_CMEX_MESATRABAJO Y,t_cmex_provision Z, t_cmex_provision_DETALLE V',
'WHERE X.ID=Y.ID_MUESTRA AND Z.ID_CMEX_MESATRABAJO=Y.ID AND Z.ID=V.ID_CABECERA',
'AND MONTOPROVISION>0',
'AND Y.FECHAETA BETWEEN TO_DATE(:P241_FECHAETAINI,''DD/MM/YYYY'') AND TO_DATE(:P241_FECHAETAHASTA,''DD/MM/YYYY'')',
'AND (X.CODIGOPROVEEDOR=:P241_PROVEEDOR OR :P241_PROVEEDOR=99999)',
'AND (TRIM(X.CENTRODECOSTO)=TRIM(:P241_CENTRODECOSTOS) OR :P241_CENTRODECOSTOS=99999)',
'--AND (TRIM(X.USERCREA)=TRIM(:P241_SOLICITANTE) OR :P241_SOLICITANTE=''99999'')',
'GROUP BY X.CODIGOPROVEEDOR,X.CENTRODECOSTO,NAVIERA,CONCEPTO',
'UNION ALL',
'SELECT X.CODIGOPROVEEDOR,X.CENTRODECOSTO,NAVIERA,''TOTAL'' CONCEPTO,SUM(MONTOPROVISION) VALOR, 2 ORDEN',
'FROM T_CMEX_MUESTRAS X, T_CMEX_MESATRABAJO Y,t_cmex_provision Z, t_cmex_provision_DETALLE V',
'WHERE X.ID=Y.ID_MUESTRA AND Z.ID_CMEX_MESATRABAJO=Y.ID AND Z.ID=V.ID_CABECERA',
'AND MONTOPROVISION>0',
'AND Y.FECHAETA BETWEEN TO_DATE(:P241_FECHAETAINI,''DD/MM/YYYY'') AND TO_DATE(:P241_FECHAETAHASTA,''DD/MM/YYYY'')',
'AND (X.CODIGOPROVEEDOR=:P241_PROVEEDOR OR :P241_PROVEEDOR=99999)',
'AND (TRIM(X.CENTRODECOSTO)=TRIM(:P241_CENTRODECOSTOS) OR :P241_CENTRODECOSTOS=99999)',
'--AND (TRIM(X.USERCREA)=TRIM(:P241_SOLICITANTE) OR :P241_SOLICITANTE=''99999'')',
'GROUP BY X.CODIGOPROVEEDOR,X.CENTRODECOSTO,NAVIERA',
';'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Importaci\00F3n Muestras')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(182395664096520006)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MALBAN'
,p_internal_uid=>182395664096520006
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182395742921520007)
,p_db_column_name=>'CODIGOPROVEEDOR'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(165398581949586903)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182395885802520008)
,p_db_column_name=>'CENTRODECOSTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Centro de Costo'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(179827823702629097)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182395955623520009)
,p_db_column_name=>'NAVIERA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Naviera'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182396080113520010)
,p_db_column_name=>'CONCEPTO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Concepto'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(93018914532751121)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182396261944520012)
,p_db_column_name=>'VALOR'
,p_display_order=>50
,p_column_identifier=>'F'
,p_column_label=>'Valor'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182396514032520015)
,p_db_column_name=>'ORDEN'
,p_display_order=>80
,p_column_identifier=>'I'
,p_column_label=>'Orden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(182407513547320683)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'PIVOT'
,p_report_alias=>'1824076'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_view_mode=>'REPORT'
,p_report_columns=>'CODIGOPROVEEDOR:CENTRODECOSTO:NAVIERA:CONCEPTO'
,p_created_on=>wwv_flow_imp.dz('20240410163712Z')
,p_updated_on=>wwv_flow_imp.dz('20240410163712Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_worksheet_pivot(
 p_id=>wwv_flow_imp.id(182664033803273026)
,p_report_id=>wwv_flow_imp.id(182407513547320683)
,p_pivot_columns=>'ORDEN:CONCEPTO'
,p_row_columns=>'CODIGOPROVEEDOR:CENTRODECOSTO:NAVIERA'
,p_created_on=>wwv_flow_imp.dz('20240410163712Z')
,p_updated_on=>wwv_flow_imp.dz('20240410163712Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_worksheet_pivot_agg(
 p_id=>wwv_flow_imp.id(182664422397273026)
,p_pivot_id=>wwv_flow_imp.id(182664033803273026)
,p_display_seq=>1
,p_function_name=>'SUM'
,p_column_name=>'VALOR'
,p_db_column_name=>'PFC1'
,p_column_label=>'Valor'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_sum=>'N'
,p_created_on=>wwv_flow_imp.dz('20240410163712Z')
,p_updated_on=>wwv_flow_imp.dz('20240410163712Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(182395429736520004)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(179499865964796547)
,p_button_name=>'Buscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Buscar'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(179500021682796549)
,p_name=>'P241_FECHAETAINI'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(179499922459796548)
,p_prompt=>'Fecha desde: '
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(179500194924796550)
,p_name=>'P241_FECHAETAHASTA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(179499922459796548)
,p_prompt=>'Fecha hasta:'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182395193807520001)
,p_name=>'P241_PROVEEDOR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(179499922459796548)
,p_prompt=>'Proveedor : '
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_CMEX_PROVEEDORES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CODIGOJDE ||'' - ''||RAZONSOCIAL D, CODIGOJDE R',
'FROM VT_COMP_JDEPROVEEDOR',
'UNION',
'SELECT CAST(''99999 - OTROS'' AS NCHAR(40)) D, 99999 R',
'FROM DUAL;      '))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'TODOS'
,p_lov_null_value=>'99999'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240611150718Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182395203483520002)
,p_name=>'P241_CENTRODECOSTOS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(179499922459796548)
,p_prompt=>'Centro de Costos: '
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_CMEX_CENTROCOSTOS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT (ID_TABLA)||'' ''||DESCRIPCION D, (ID_TABLA) R',
'FROM T_CORP_UDC',
'WHERE id_cabecera=''NSEF_CCOST''',
'AND ACTIVO=1 AND VALOR2 IS NOT NULL',
'ORDER BY 2',
';'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'TODOS'
,p_lov_null_value=>'99999'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(182395308864520003)
,p_name=>'P241_SOLICITANTE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(179499922459796548)
,p_prompt=>'Solicitante'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NOMBRES ||'' ''||APELLIDOS D,NOMBREUSUARIO R',
'FROM VT_CORP_USUARIO',
'WHERE NOMBRES IS NOT NULL AND ESTADO=1',
'ORDER BY 1;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'TODOS'
,p_lov_null_value=>'99999'
,p_cSize=>30
,p_colspan=>6
,p_display_when=>'1=2'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp.component_end;
end;
/
