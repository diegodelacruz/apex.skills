prompt --application/pages/page_00105
begin
--   Manifest
--     PAGE: 00105
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>105
,p_name=>'Costo Proveedor'
,p_step_title=>'Costo Proveedor'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230812063216Z')
,p_last_updated_on=>wwv_flow_imp.dz('20230812063520Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(180651308540338037)
,p_name=>'Archivos'
,p_template=>wwv_flow_imp.id(296121421643169165)
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select numeroarchivo',
', dbms_lob.getlength(blobcontent) blobcontent',
', filename',
'from files.t_apex_archivos where tabla = ''T_ADJT_P5541061'' and id_tabla = :p105_numero'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'No hay archivos cargados.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(100730791288735222)
,p_query_column_id=>1
,p_column_alias=>'NUMEROARCHIVO'
,p_column_display_sequence=>1
,p_column_heading=>unistr('N\00FAm. Archivo')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(100731124678735224)
,p_query_column_id=>2
,p_column_alias=>'BLOBCONTENT'
,p_column_display_sequence=>2
,p_column_heading=>'Descargar'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment:descargar:FILES'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(100731536029735224)
,p_query_column_id=>3
,p_column_alias=>'FILENAME'
,p_column_display_sequence=>3
,p_column_heading=>'Archivo'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(347157175513115658)
,p_plug_name=>'Datos principales'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(347157847801115665)
,p_plug_name=>'Detalle'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120613521169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select proceso',
'	, tipo',
'	, cbitm',
'	, codigoproducto',
'	, producto',
'	, unidad',
'	, cban8',
'	, proveedor',
'	, moneda',
'	, valornuevo',
'	, cbprrc1',
'	, variacion1*100 variacion1',
'	, cbprrc2',
'	, variacion2*100 variacion2',
'	, cbprrc3',
'	, variacion3*100 variacion3',
'	, justificacion',
'from vt_comp_costoproveedor',
'where proceso = :p105_numero;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_updated_on=>wwv_flow_imp.dz('20230812063313Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(347158771635115674)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'No existe detalle'
,p_show_nulls_as=>'-'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>347158771635115674
,p_updated_on=>wwv_flow_imp.dz('20230812063313Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(340845779532805026)
,p_db_column_name=>'PROCESO'
,p_display_order=>10
,p_column_identifier=>'Q'
,p_column_label=>'Proceso'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(341334034679055395)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>30
,p_column_identifier=>'A'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(341337969768055400)
,p_db_column_name=>'UNIDAD'
,p_display_order=>40
,p_column_identifier=>'N'
,p_column_label=>'UM'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(340845869547805027)
,p_db_column_name=>'TIPO'
,p_display_order=>50
,p_column_identifier=>'R'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(340846055481805029)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>60
,p_column_identifier=>'T'
,p_column_label=>'Proveedor'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(340846129346805030)
,p_db_column_name=>'VALORNUEVO'
,p_display_order=>70
,p_column_identifier=>'U'
,p_column_label=>'Nuevo Costo'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(340846350208805032)
,p_db_column_name=>'MONEDA'
,p_display_order=>100
,p_column_identifier=>'W'
,p_column_label=>'Moneda'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(340846513885805034)
,p_db_column_name=>'JUSTIFICACION'
,p_display_order=>110
,p_column_identifier=>'Y'
,p_column_label=>unistr('Justificaci\00F3n')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(193206821831644506)
,p_db_column_name=>'CODIGOPRODUCTO'
,p_display_order=>120
,p_column_identifier=>'Z'
,p_column_label=>unistr('C\00F3d. Producto')
,p_column_type=>'STRING'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(201057761551262430)
,p_db_column_name=>'CBITM'
,p_display_order=>130
,p_column_identifier=>'AA'
,p_column_label=>'Cbitm'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(201057803816262431)
,p_db_column_name=>'CBAN8'
,p_display_order=>140
,p_column_identifier=>'AB'
,p_column_label=>'Cban8'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(201057922483262432)
,p_db_column_name=>'CBPRRC1'
,p_display_order=>150
,p_column_identifier=>'AC'
,p_column_label=>'Costo Act.'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(201058076656262433)
,p_db_column_name=>'VARIACION1'
,p_display_order=>160
,p_column_identifier=>'AD'
,p_column_label=>'% var. act.'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(201058193186262434)
,p_db_column_name=>'CBPRRC2'
,p_display_order=>170
,p_column_identifier=>'AE'
,p_column_label=>'Costo Ant. 1'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(201058228835262435)
,p_db_column_name=>'VARIACION2'
,p_display_order=>180
,p_column_identifier=>'AF'
,p_column_label=>'% var. ant 1'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(201058392206262436)
,p_db_column_name=>'CBPRRC3'
,p_display_order=>190
,p_column_identifier=>'AG'
,p_column_label=>'Costo Ant. 2'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(201058431079262437)
,p_db_column_name=>'VARIACION3'
,p_display_order=>200
,p_column_identifier=>'AH'
,p_column_label=>'% var. ant 2'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(347193920713552513)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3413395'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PROVEEDOR:PRODUCTO:UNIDAD:MONEDA:VALORNUEVO:CBPRRC1:VARIACION1:CBPRRC2:VARIACION2:CBPRRC3:VARIACION3:JUSTIFICACION:'
,p_sum_columns_on_break=>'TOTAL'
,p_created_on=>wwv_flow_imp.dz('20230812063216Z')
,p_updated_on=>wwv_flow_imp.dz('20230812063216Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(347195248683565129)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(347195574758565132)
,p_plug_name=>'Botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121809343169165)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P105_ES_APROBADOR'
,p_plug_display_when_cond2=>'1'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(341340230143055407)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(347195248683565129)
,p_button_name=>'ATRAS'
,p_button_static_id=>'btnAtras'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Atras'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:RP::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(341342148231055410)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(347195574758565132)
,p_button_name=>'APROBAR'
,p_button_static_id=>'btnAprobar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Aprobar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:102:&SESSION.::&DEBUG.:RP:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO,G_MONTO:&G_COMPANIA.,&APP_MODULO.,&P105_USUARIO.,&P105_TIPO.,&P105_NUMERO.,&P105_APROBADOR.,&P105_MONTO.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(341342533907055410)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(347195574758565132)
,p_button_name=>'RECHAZAR'
,p_button_static_id=>'btnRechazar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Rechazar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:103:&SESSION.::&DEBUG.:RP:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO:&G_COMPANIA.,&APP_MODULO.,&P105_USUARIO.,&P105_TIPO.,&P105_NUMERO.,&P105_APROBADOR.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(341341097617055409)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(347195248683565129)
,p_button_name=>'COMENTARIO'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Comentario'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:105:&SESSION.::&DEBUG.:RP:G_OBJETO,G_OBJETO_ID,G_MODULO,G_COMPANIA,G_USUARIO:&P105_TIPO.,&P105_NUMERO.,&APP_MODULO.,&G_COMPANIA.,&P105_USUARIO.'
,p_icon_css_classes=>'fa-comment'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(341341457548055409)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(347195248683565129)
,p_button_name=>'VER_RUTA'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Ver Ruta'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:104:&SESSION.::&DEBUG.:RP:G_OBJETO,G_OBJETO_ID,G_TODO:&P105_TIPO.,&P105_NUMERO.,true'
,p_icon_css_classes=>'fa-road'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(341326902881055382)
,p_name=>'P105_CONTRATO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(347157175513115658)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(341327368178055384)
,p_name=>'P105_TOKEN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(347157175513115658)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(341327718526055385)
,p_name=>'P105_USUARIO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(347157175513115658)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(341328164752055385)
,p_name=>'P105_APROBADOR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(347157175513115658)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(341328543016055385)
,p_name=>'P105_FLUJO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(347157175513115658)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(341329384711055387)
,p_name=>'P105_ES_APROBADOR'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(347157175513115658)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(341329784380055387)
,p_name=>'P105_MONTO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(347157175513115658)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(341330593076055387)
,p_name=>'P105_ESTADO'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(347157175513115658)
,p_prompt=>'Estado:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(341330902481055389)
,p_name=>'P105_NUMERO'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(347157175513115658)
,p_prompt=>'Proceso:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(341331376203055389)
,p_name=>'P105_TIPO'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(347157175513115658)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(341332525397055390)
,p_name=>'P105_FECHA_ORDEN'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(347157175513115658)
,p_prompt=>'Fecha :'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(341333367072055390)
,p_name=>'P105_DESCRIPCION'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(347157175513115658)
,p_prompt=>unistr('Descripci\00F3n:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(341344045457055417)
,p_name=>unistr('Cierre di\00E1logo: aprobar')
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(341342148231055410)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(341344560806055417)
,p_event_id=>wwv_flow_imp.id(341344045457055417)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'mostrarBarra();',
'// P105_FLUJO = 0 ERROR , 1 SE APROBO CON EXITO, 2 TERMINO FLUJO',
'apex.item("P105_FLUJO").setValue(0);',
'',
'if(this.data.G_EXITO==''true''){',
'    apex.item("P105_FLUJO").setValue(1);',
'    mensaje(''exito'', this.data.G_MENSAJE);',
'    if(isTerminoFlujo){',
'        apex.item("P105_FLUJO").setValue(2);',
'    }',
'}',
'else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(341345006084055418)
,p_event_id=>wwv_flow_imp.id(341344045457055417)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    ',
'IF(:P105_FLUJO =2) THEN -- TERMINO FLUJO',
'',
'    PK_COMP_ORDENESCOMPRA.SP_APROBARCOSTOPROVEEDOR(',
'    p_numero=>:P105_NUMERO,',
'    P_COMPANIA=>:G_COMPANIA );',
'',
'END IF;'))
,p_attribute_02=>'P105_FLUJO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(341345516657055418)
,p_event_id=>wwv_flow_imp.id(341344045457055417)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var token = apex.item("P105_TOKEN").getValue();',
'ocultarBarra();',
'if(this.data.G_EXITO==''true''){',
'    if(token==''0''){',
'        $(''#btnAtras'').trigger("click");',
'    }else{',
'        $(''#btnAprobar'').hide();',
'        $(''#btnRechazar'').hide();',
'    }',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(341345936796055418)
,p_name=>unistr('Cierre di\00E1logo: rechazar')
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(341342533907055410)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(341346488954055420)
,p_event_id=>wwv_flow_imp.id(341345936796055418)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'// P105_FLUJO = 0 ERROR , 1 EXITO',
'apex.item( "P105_FLUJO" ).setValue(0);',
'',
'',
'if(this.data.G_EXITO==''true''){',
'    apex.item( "P105_FLUJO" ).setValue(1);',
'}',
'else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(341346991115055420)
,p_event_id=>wwv_flow_imp.id(341345936796055418)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF(:P105_FLUJO =1) THEN -- RECHAZO CON EXITO',
'    PK_COMP_ORDENESCOMPRA.SP_RECHAZARCOSTOPROVEEDOR(',
'        p_numero=>:P105_NUMERO,',
'     P_COMPANIA=>:G_COMPANIA);',
'END IF;'))
,p_attribute_02=>'P105_FLUJO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(341347453836055420)
,p_event_id=>wwv_flow_imp.id(341345936796055418)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var token = apex.item("P105_TOKEN").getValue();',
'',
'if(this.data.G_EXITO==''true''){',
'    if(token==''0''){',
'        $(''#btnAtras'').trigger("click");',
'    }else{',
'        $(''#btnAprobar'').hide();',
'        $(''#btnRechazar'').hide();',
'    }',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(341347844455055421)
,p_name=>'Seleccion'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.chkF01'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(341348339224055421)
,p_event_id=>wwv_flow_imp.id(341347844455055421)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if(document.querySelectorAll(''.chkF01'').length == [].filter.call( document.querySelectorAll(''.chkF01''), function( el ) {return !el.checked}).length){',
'    //NO SELECCION NADA',
'     $(''#btnAprobar'').hide();',
'}else{',
'    //SELECCIONO ALGO',
'     $(''#btnAprobar'').show();',
'}',
'',
'var lineas =""; ',
'document.querySelectorAll(''.chkF01'').forEach(function(seleccion) {',
'    if(!seleccion.checked){',
'        var linea = seleccion.value',
'        if(lineas==""){',
'            lineas = linea;',
'        }else{',
'            lineas = lineas+'',''+linea;',
'        }      ',
'    }',
'    ',
'});',
'apex.item("P105_SINSELECCION").setValue(lineas);',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(341343221005055415)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga de Datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'V_CONTADOR  NUMBER;',
'BEGIN',
'    :P105_USUARIO := :APP_USER;',
'    :P105_TOKEN :=0;',
'',
'    IF(:G_DETALLE_ID IS NOT NULL AND :G_TOKEN IS NOT NULL) THEN --APROBACION CON TOKEN (DESDE LINK DEL CORREO)',
'        PK_CORP_FLUJOAPROBACION.SP_BUSCARAPROBACION(:G_DETALLE_ID,:G_TOKEN,:G_COMPANIA,:P105_APROBADOR,:P105_TIPO,:P105_NUMERO);',
'        :P105_USUARIO := :P105_APROBADOR;',
'        :P105_TOKEN := 1;',
'    END IF;',
'',
'    :P105_ES_APROBADOR := PK_CORP_FLUJOAPROBACION.F_APROBADORFLUJO(:P105_USUARIO, :P105_APROBADOR, :APP_MODULO ,:G_COMPANIA);',
'',
'    SELECT  COUNT(1) INTO V_CONTADOR FROM VT_COMP_MESATRABAJO_COSTO WHERE PROCESO = :P105_NUMERO;',
'',
'    IF V_CONTADOR = 0 THEN RETURN; END IF;',
'',
'    -- CABECERA',
'    SELECT to_char(FECHA_INICIO,''dd/mm/yyyy hh24:mi''), ESTADO',
'    INTO :P105_FECHA_ORDEN, :P105_ESTADO',
'    FROM VT_COMP_MESATRABAJO_COSTO WHERE PROCESO = :P105_NUMERO AND ROWNUM = 1;',
'',
'    SELECT CBCALCIT INTO :P105_DESCRIPCION FROM F554106X@JDEDTADL WHERE ROWNUM = 1 AND CBPYID = :P105_NUMERO;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>341343221005055415
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(341343694674055415)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Borrar datos'
,p_attribute_01=>'CLEAR_CACHE_FOR_ITEMS'
,p_attribute_03=>'P105_FLUJO,G_TOKEN,G_DETALLE_ID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>341343694674055415
);
wwv_flow_imp.component_end;
end;
/
