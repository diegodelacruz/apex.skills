prompt --application/pages/page_00213
begin
--   Manifest
--     PAGE: 00213
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>213
,p_name=>'Libro de Direcciones'
,p_alias=>'LIBRO-DE-DIRECCIONES'
,p_step_title=>'Libro de Direcciones'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20250101033732Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260325220436Z')
,p_created_by=>'DDELACRUZ'
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(599459347419255604)
,p_plug_name=>'Libro de Direcciones'
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--fillLabels:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_imp.id(295637154502037690)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250213142352Z')
,p_updated_on=>wwv_flow_imp.dz('20250213142508Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(555326632950828801)
,p_plug_name=>'Proveedores'
,p_parent_plug_id=>wwv_flow_imp.id(599459347419255604)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with w_neg as(',
'	select det_codproveedor, max(neg_id) neg_id',
'	from vt_comp_negociacion',
'	where neg_estadoflujo = ''APROBADO'' and sysdate between neg_vigenciadesde and neg_vigenciahasta',
'	group by det_codproveedor',
'	union',
'	select det_codproveedor, max(neg_id) neg_id',
'	from vt_comp_negociacion',
'	where neg_estadoflujo = ''APROBADO'' and det_codproveedor not in (',
'		select det_codproveedor',
'		from vt_comp_negociacion',
'		where neg_estadoflujo = ''APROBADO'' and sysdate between neg_vigenciadesde and neg_vigenciahasta',
'		group by det_codproveedor',
'	)',
'	group by det_codproveedor',
'), w_det as (',
'	select a.det_codproveedor codproveedor',
'		, listagg(distinct a.det_formapago||'' - ''||upper(PNPTD),'', '') det_formapago',
'		, listagg(distinct categoria,'', '') det_categoria',
'	from vt_comp_negociacion a',
'	inner join vt_jde_productos on det_codproducto = codigocorto',
'	inner join w_neg on a.neg_id = w_neg.neg_id and a.det_codproveedor = w_neg.det_codproveedor',
'	left join f0014@jdedtadl on a.det_formapago = trim(pnptc)',
'	group by a.det_codproveedor',
'), w_cor as (',
'	select eaan8, eaidln, listagg(distinct lower(eaemal),'', '') eaemal',
'	from f01151@jdedtadl where pk_commons.f_escorreo(trim(eaemal)) = 1',
'	group by eaan8, eaidln',
'), w_wiw as (',
'	select wwan8, wwidln, trim(wwmlnm) wwmlnm from f0111@jdedtadl',
'), w_crc as (',
'	select wwan8, decode(eaemal,null,wwmlnm,wwmlnm||'' (''||eaemal||'')'') wwctct',
'	from w_wiw',
'	left join w_cor on eaan8 = wwan8 and eaidln = wwidln',
'), w_ctc as (',
'	select wwan8, listagg(wwctct,'', '') wwctct from w_crc group by wwan8',
')',
'select a.*',
unistr('	, decode(b.fechaenv,null,''NO'',''S\00CD'') enviadoprotecciondatos'),
unistr('	, decode(b.respuesta,null,''NO'',0,''NO'',''S\00CD'') protecciondatos'),
'	, w_det.det_formapago',
'	, w_det.det_categoria',
'	, w_ctc.wwctct',
'	, nvl(c.contrato,''N'') contrato',
'	, nvl(c.evaluacion,''N'') evaluacion',
'	, c.fechprimcompra',
unistr('	, ''<span class="fa fa-gear" title="Configuraci\00F3n" aria-hidden="true" style="color: #000080;"></span>'' configurar'),
'from vt_jde_maestroproveedor a',
'left join t_lega_acuerdodatospersonales b on a.codigoproveedor = b.coddireccion',
'left join data.t_comp_proveedorctg c on a.codigoproveedor = to_number(c.codproveedor)',
'left join w_det on a.codigoproveedor = w_det.codproveedor',
'left join w_ctc on a.codigoproveedor = w_ctc.wwan8'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Proveedores'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_created_on=>wwv_flow_imp.dz('20250101033832Z')
,p_updated_on=>wwv_flow_imp.dz('20260325220436Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(555326779013828802)
,p_max_row_count=>'1000000'
,p_max_rows_per_page=>'100'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>555326779013828802
,p_created_on=>wwv_flow_imp.dz('20250101034258Z')
,p_updated_on=>wwv_flow_imp.dz('20260325220436Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(555326848118828803)
,p_db_column_name=>'CODIGOPROVEEDOR'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>unistr('C\00F3d. Proveedor')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250101034258Z')
,p_updated_on=>wwv_flow_imp.dz('20250101034533Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(555326918309828804)
,p_db_column_name=>'TIPO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250101034258Z')
,p_updated_on=>wwv_flow_imp.dz('20250101034533Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(555327052335828805)
,p_db_column_name=>'AREAFISCAL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>unistr('\00C1rea Fiscal')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250101034258Z')
,p_updated_on=>wwv_flow_imp.dz('20250101034533Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(555327195244828806)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250101034258Z')
,p_updated_on=>wwv_flow_imp.dz('20250101034533Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(555327282063828807)
,p_db_column_name=>'IDENTIFICACION'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>unistr('Identificaci\00F3n')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250101034258Z')
,p_updated_on=>wwv_flow_imp.dz('20250101034533Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(555327331109828808)
,p_db_column_name=>'UNIDADNEGOCIO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'UN'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250101034258Z')
,p_updated_on=>wwv_flow_imp.dz('20250101034533Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(555327468334828809)
,p_db_column_name=>'TIPOIDENTIFICACION'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Tipo ID'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250101034258Z')
,p_updated_on=>wwv_flow_imp.dz('20250101034533Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(555327509206828810)
,p_db_column_name=>'TIPOPROVEEDOR'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Tipo Proveedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250101034258Z')
,p_updated_on=>wwv_flow_imp.dz('20250101034533Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(555327669289828811)
,p_db_column_name=>'MONEDA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250101034258Z')
,p_updated_on=>wwv_flow_imp.dz('20250101034533Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(555327776716828812)
,p_db_column_name=>'PROTECCIONDATOS'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Acepta PD'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250101034258Z')
,p_updated_on=>wwv_flow_imp.dz('20250206145358Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(585059760795907233)
,p_db_column_name=>'ENVIADOPROTECCIONDATOS'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Enviado PD'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250206145304Z')
,p_updated_on=>wwv_flow_imp.dz('20250206145304Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(599462362669255634)
,p_db_column_name=>'DET_FORMAPAGO'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Forma Pago'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250214180716Z')
,p_updated_on=>wwv_flow_imp.dz('20250214220905Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(599462446949255635)
,p_db_column_name=>'DET_CATEGORIA'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>unistr('Cats. Negociaci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250214180716Z')
,p_updated_on=>wwv_flow_imp.dz('20250214180716Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(599462532799255636)
,p_db_column_name=>'WWCTCT'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Contacto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250214220905Z')
,p_updated_on=>wwv_flow_imp.dz('20250214220905Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(675435818493489604)
,p_db_column_name=>'CONFIGURAR'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'-'
,p_column_link=>'f?p=&APP_ID.:261:&SESSION.::&DEBUG.:261:P261_COMPANIA,P261_CODPROVEEDOR:&G_COMPANIA.,#CODIGOPROVEEDOR#'
,p_column_linktext=>'#CONFIGURAR#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':app_user in (''DDELACRUZ'',''WAIMINGNG'',''JNARANJO'',''CLOPEZ'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250417155513Z')
,p_updated_on=>wwv_flow_imp.dz('20260325220436Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(675437811857489624)
,p_db_column_name=>'HABILITADO'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Hab.'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250417182254Z')
,p_updated_on=>wwv_flow_imp.dz('20250417182254Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(675437924714489625)
,p_db_column_name=>'CONTRATO'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Cont.'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250417182254Z')
,p_updated_on=>wwv_flow_imp.dz('20250417182254Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(675438017925489626)
,p_db_column_name=>'EVALUACION'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Eval.'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250417182254Z')
,p_updated_on=>wwv_flow_imp.dz('20250417182254Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(680427746821803001)
,p_db_column_name=>'FECHPRIMCOMPRA'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'F. Prim. Compra'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250421194813Z')
,p_updated_on=>wwv_flow_imp.dz('20250421194813Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(555336308084859879)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5553364'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100
,p_report_columns=>'CONFIGURAR:HABILITADO:CONTRATO:EVALUACION:CODIGOPROVEEDOR:TIPO:AREAFISCAL:DESCRIPCION:IDENTIFICACION:UNIDADNEGOCIO:TIPOIDENTIFICACION:TIPOPROVEEDOR:MONEDA:DET_FORMAPAGO:FECHPRIMCOMPRA:DET_CATEGORIA:ENVIADOPROTECCIONDATOS:PROTECCIONDATOS:WWCTCT:'
,p_created_on=>wwv_flow_imp.dz('20250101034300Z')
,p_updated_on=>wwv_flow_imp.dz('20250421194928Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(599459470100255605)
,p_plug_name=>'Clientes'
,p_parent_plug_id=>wwv_flow_imp.id(599459347419255604)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.*',
'from vt_jde_cliente a'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Clientes'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_created_on=>wwv_flow_imp.dz('20250213142352Z')
,p_updated_on=>wwv_flow_imp.dz('20250213144658Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(599459536662255606)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>599459536662255606
,p_created_on=>wwv_flow_imp.dz('20250213142353Z')
,p_updated_on=>wwv_flow_imp.dz('20250213144658Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(599460766063255618)
,p_db_column_name=>'CODIGO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Codigo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250213142353Z')
,p_updated_on=>wwv_flow_imp.dz('20250213144035Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(599460860477255619)
,p_db_column_name=>'CODIGOGRUPO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>unistr('C\00F3d. Grupo')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250213142353Z')
,p_updated_on=>wwv_flow_imp.dz('20250213144035Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(599460923149255620)
,p_db_column_name=>'GRUPO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Grupo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250213142353Z')
,p_updated_on=>wwv_flow_imp.dz('20250213142353Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(599461090960255621)
,p_db_column_name=>'NOMBRES'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250213142353Z')
,p_updated_on=>wwv_flow_imp.dz('20250213144035Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(599461161055255622)
,p_db_column_name=>'DIRECCION'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>unistr('Direcci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250213142353Z')
,p_updated_on=>wwv_flow_imp.dz('20250213144035Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(599461245219255623)
,p_db_column_name=>'CODIGOCANAL'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>unistr('C\00F3d. Canal')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250213142353Z')
,p_updated_on=>wwv_flow_imp.dz('20250213144035Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(599461377676255624)
,p_db_column_name=>'CANAL'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Canal'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250213142353Z')
,p_updated_on=>wwv_flow_imp.dz('20250213144110Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(599461454467255625)
,p_db_column_name=>'CODIGOPAIS'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>unistr('C\00F3d Pa\00EDs')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250213142353Z')
,p_updated_on=>wwv_flow_imp.dz('20250213144035Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(599461541736255626)
,p_db_column_name=>'CODIGOORIGEN'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>unistr('C\00F3d. Origen')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250213142353Z')
,p_updated_on=>wwv_flow_imp.dz('20250213144035Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(599461617464255627)
,p_db_column_name=>'ESTADO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Estado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250213142353Z')
,p_updated_on=>wwv_flow_imp.dz('20250213144035Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(599461768601255628)
,p_db_column_name=>'RUC'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'RUC'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250213142353Z')
,p_updated_on=>wwv_flow_imp.dz('20250213144035Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(599461898404255629)
,p_db_column_name=>'EJECUTIVO'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'ID Ejecutivo'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250213142353Z')
,p_updated_on=>wwv_flow_imp.dz('20250213144035Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(599461988888255630)
,p_db_column_name=>'CODIGOEJECUTIVO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>unistr('C\00F3d. Ejecutivo')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250213142353Z')
,p_updated_on=>wwv_flow_imp.dz('20250213144035Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(599462024003255631)
,p_db_column_name=>'CANALALTERNO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Canal Alt.'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250213142353Z')
,p_updated_on=>wwv_flow_imp.dz('20250213144035Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(600568365668873521)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'6005684'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100
,p_report_columns=>'CODIGO:CODIGOGRUPO:GRUPO:NOMBRES:CANAL:ESTADO:RUC:EJECUTIVO:CODIGOEJECUTIVO:'
,p_created_on=>wwv_flow_imp.dz('20250213142355Z')
,p_updated_on=>wwv_flow_imp.dz('20250213144649Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(675435631800489602)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_log_app	varchar2(100);',
'v_log_dsc	varchar2(1000);',
'v_compania	varchar2(10);',
'begin',
'	v_log_app := ''apex.130.213.Cargar'';',
'	v_log_dsc := ''g_compania: ''||:g_compania;',
'	pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,null,null,null);',
'	v_compania := :g_compania;',
'	pk_comp_gestionproveedor.sp_obtenerproveedores(v_compania);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>675435631800489602
,p_created_on=>wwv_flow_imp.dz('20250417154835Z')
,p_updated_on=>wwv_flow_imp.dz('20250417154835Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
