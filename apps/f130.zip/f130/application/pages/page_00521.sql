prompt --application/pages/page_00521
begin
--   Manifest
--     PAGE: 00521
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>521
,p_name=>unistr('COMEX - Exportaci\00F3n')
,p_alias=>unistr('COMEX-EXPORTACI\00D3N')
,p_step_title=>unistr('COMEX - Exportaci\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.conBorde {',
'    border: solid 2px darkgray;',
'    padding: 6px ! IMPORTANT;',
'}',
'div.formulario {',
'    padding: 0px 0px;',
'}',
'.barraRegion .t-Region-headerItems--title	 {',
'    background: rgb(229, 252, 189);',
'    padding: 2px;',
'}',
'',
'.alertaVariasPlacas{',
'    border: solid 4px darkred ! IMPORTANT;',
'    margin: auto;',
'    padding-left: 5px;',
'    padding-right: 5px;',
'    width: 100%;',
'    text-align: center;',
'    color: darkred;',
'}',
'',
'.c80 {',
'display: block; width: 80px; ',
'}',
'.c100 {',
'display: block; width: 100px; ',
'}',
'.c120 {',
'display: block; width: 120px; ',
'}',
'.c140 {',
'display: block; width: 140px; ',
'}',
'.c160 {',
'display: block; width: 160px; ',
'}',
'.c180 {',
'display: block; width: 180px; ',
'}',
'.c200 {',
'display: block; width: 200px; ',
'}',
'.c250 {',
'display: block; width: 250px; ',
'}',
'',
'#downloadDAE .a-IRR-header {',
'    display: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20241113165842Z')
,p_last_updated_on=>wwv_flow_imp.dz('20241112160444Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(326290901975333106)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(326291188488333108)
,p_plug_name=>'NUEVO'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'P521_EXPORTACION_REGISTRO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(326291216578333109)
,p_plug_name=>'ATADO A BOOKING'
,p_parent_plug_id=>wwv_flow_imp.id(326291188488333108)
,p_region_css_classes=>'conBorde'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(326291476516333111)
,p_plug_name=>'NO atado a booking'
,p_parent_plug_id=>wwv_flow_imp.id(326291188488333108)
,p_region_css_classes=>'conBorde'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(326292024447333117)
,p_plug_name=>'REGISTRO'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P521_EXPORTACION_REGISTRO'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>':P521_EDITAR_REGISTRO = 0'
,p_plug_read_only_when2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(329868107818317103)
,p_plug_name=>'Facturas'
,p_parent_plug_id=>wwv_flow_imp.id(326292024447333117)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ID                AS ID, ',
'    FACTURA_TIPO ||''-''||FACTURA_NUMERO   ',
'                      AS FACTURA, ',
'',
'    CONTENEDOR_NUMERO AS CONTENEDOR_NUMERO,',
'    TURNO_IDVEHICULO  AS TURNO_IDVEHICULO,',
'',
'    PESO              AS PESO,',
'',
'    TRUNC(FECHA_PLAN_CARGUE) AS FECHA_PLAN_CARGUE,',
'',
'    FECHA_REGISTRO    AS FECHA_REGISTRO,',
'    ID   AS  ICONO_BORRAR',
'FROM',
'    VT_CMEX_EXPORTACN_FACTURA_PESO',
'WHERE',
'    EXPORTACION_REGISTRO = :P521_EXPORTACION_REGISTRO',
';',
'',
'',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Facturas'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(329868286976317104)
,p_max_row_count=>'1000000'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>329868286976317104
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(329868304190317105)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(329868689615317108)
,p_db_column_name=>'FECHA_REGISTRO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(332266588607974013)
,p_db_column_name=>'CONTENEDOR_NUMERO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Contenedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(332266614244974014)
,p_db_column_name=>'TURNO_IDVEHICULO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Placa'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(332266713999974015)
,p_db_column_name=>'PESO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Peso Neto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(332266889972974016)
,p_db_column_name=>'FACTURA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Factura'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(332265950361974007)
,p_db_column_name=>'ICONO_BORRAR'
,p_display_order=>100
,p_column_identifier=>'E'
,p_column_label=>'-'
,p_column_link=>'javascript:apex.item("P521_FACTURA_ELIMINAR").setValue("#ICONO_BORRAR#");'
,p_column_linktext=>'<span class="fa fa-trash"></span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P521_EDITAR_COORDINACION = 1'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(332267957938974027)
,p_db_column_name=>'FECHA_PLAN_CARGUE'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Cargue'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(330057218117656898)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_report_alias=>'3300573'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FACTURA:CONTENEDOR_NUMERO:TURNO_IDVEHICULO:PESO:FECHA_PLAN_CARGUE:ICONO_BORRAR:'
,p_created_on=>wwv_flow_imp.dz('20241113165842Z')
,p_updated_on=>wwv_flow_imp.dz('20241113165842Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(332268772573974035)
,p_plug_name=>unistr('Novedades Exportaci\00F3n')
,p_parent_plug_id=>wwv_flow_imp.id(326292024447333117)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(343097240908056504)
,p_plug_name=>'Contenedores'
,p_parent_plug_id=>wwv_flow_imp.id(326292024447333117)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_css_classes=>'barraRegion '
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    DATOS_GESTION_DET_ID      AS DATOS_GESTION_DET_ID,',
'    EXPORTACION_REGISTRO      AS EXPORTACION_REGISTRO,',
'    CONTENEDOR_NUMERO         AS CONTENEDOR_NUMERO,',
'    TURNO_ID                  AS TURNO_ID,',
'    TURNO_IDVEHICULO          AS TURNO_IDVEHICULO,',
'',
'',
'    TO_CHAR(FECHA_NOTIF_VERIFICADORA, ''DD/MM/YYYY HH24:MI'')',
'                              AS FECHA_NOTIF_VERIFICADORA,',
'    ''<span class="fa fa-window-search"></span>''',
'                              AS ICONO_DETALLES,',
'    CASE ',
'        WHEN FECHA_NOTIF_VERIFICADORA IS NOT NULL THEN ''<span class="fa fa-envelope-user"></span>''',
'        ELSE ''-''',
'    END                       AS NOTIF_VERIFICADORA,                              ',
'    CASE ',
'        WHEN FECHA_UPLOAD_VERIFICADORA IS NOT NULL THEN ''<span class="fa fa-paperclip"></span>''',
'        ELSE ''-''',
'    END                       AS UPLOAD_VERIFICADORA,',
'',
'',
'    TO_CHAR(FECHA_NOTIF_TRANSPORTISTA, ''DD/MM/YYYY HH24:MI'')',
'                              AS FECHA_NOTIF_TRANSPORTISTA,',
'    ''<span class="fa fa-truck"></span>''    ',
'                              AS ICONO_TRANSPORTISTA,',
'    CASE ',
'        WHEN FECHA_NOTIF_TRANSPORTISTA IS NOT NULL THEN ''<span class="fa fa-envelope-user"></span>''',
'        ELSE ''-''',
'    END                       AS NOTIF_TRANSPORTISTA,',
'    CASE ',
'        WHEN FECHA_UPLOAD_TRANSPORTISTA IS NOT NULL THEN ''<span class="fa fa-paperclip"></span>''',
'        ELSE ''-''',
'    END                       AS UPLOAD_TRANSPORTISTA,',
'',
'    COUNT(1)                  AS COUNT,',
'    SUM(PESO)                 AS PESO',
'',
'',
'FROM ',
'    VT_CMEX_EXPORTACN_FACTURA_PESO ',
'WHERE',
'    EXPORTACION_REGISTRO=:P521_EXPORTACION_REGISTRO',
'GROUP BY',
'    DATOS_GESTION_DET_ID,',
'    EXPORTACION_REGISTRO,',
'    CONTENEDOR_NUMERO,',
'    TURNO_ID,',
'    TURNO_IDVEHICULO,',
'    FECHA_NOTIF_VERIFICADORA,',
'    FECHA_UPLOAD_VERIFICADORA,',
'    FECHA_NOTIF_TRANSPORTISTA,',
'    FECHA_UPLOAD_TRANSPORTISTA',
';'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Contenedores'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(343097318754056505)
,p_max_row_count=>'1000000'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>343097318754056505
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(343097487563056506)
,p_db_column_name=>'DATOS_GESTION_DET_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(343097587000056507)
,p_db_column_name=>'EXPORTACION_REGISTRO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Registro'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(343097632575056508)
,p_db_column_name=>'CONTENEDOR_NUMERO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Contenedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(343097744201056509)
,p_db_column_name=>'TURNO_ID'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Turno ID'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(343097819979056510)
,p_db_column_name=>'TURNO_IDVEHICULO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Placa'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(343098131570056513)
,p_db_column_name=>'COUNT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Facts'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(343098226613056514)
,p_db_column_name=>'PESO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Peso Bruto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(343098391038056515)
,p_db_column_name=>'FECHA_NOTIF_VERIFICADORA'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Notif. Verif.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(352516671049436549)
,p_db_column_name=>'NOTIF_VERIFICADORA'
,p_display_order=>110
,p_column_identifier=>'R'
,p_column_label=>'Notif. Verificadora'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(352516489892436547)
,p_db_column_name=>'UPLOAD_VERIFICADORA'
,p_display_order=>120
,p_column_identifier=>'P'
,p_column_label=>'Archivos Verific.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(352512817742436511)
,p_db_column_name=>'ICONO_DETALLES'
,p_display_order=>130
,p_column_identifier=>'N'
,p_column_label=>'o[]'
,p_column_link=>'f?p=&APP_ID.:526:&SESSION.::&DEBUG.:526:P526_DATOS_GESTION_DET_ID,P526_EXPORTACION_REGISTRO,P526_EDITAR_COORDINACION,P526_EDITAR_TRANSITO:#DATOS_GESTION_DET_ID#,#EXPORTACION_REGISTRO#,&P521_EDITAR_COORDINACION.,&P521_EDITAR_TRANSITO.'
,p_column_linktext=>'#ICONO_DETALLES#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(343098486121056516)
,p_db_column_name=>'FECHA_NOTIF_TRANSPORTISTA'
,p_display_order=>140
,p_column_identifier=>'K'
,p_column_label=>'Notif. Trans.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(352516785583436550)
,p_db_column_name=>'NOTIF_TRANSPORTISTA'
,p_display_order=>150
,p_column_identifier=>'S'
,p_column_label=>'Notif. Transportista'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(352516504622436548)
,p_db_column_name=>'UPLOAD_TRANSPORTISTA'
,p_display_order=>160
,p_column_identifier=>'Q'
,p_column_label=>'Archivos Transp.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(352516159748436544)
,p_db_column_name=>'ICONO_TRANSPORTISTA'
,p_display_order=>170
,p_column_identifier=>'O'
,p_column_label=>'o[]'
,p_column_link=>'f?p=&APP_ID.:528:&SESSION.::&DEBUG.:528:P528_DATOS_GESTION_DET_ID,P528_EXPORTACION_REGISTRO,P528_EDITAR_COORDINACION:#DATOS_GESTION_DET_ID#,#EXPORTACION_REGISTRO#,&P521_EDITAR_COORDINACION.'
,p_column_linktext=>'#ICONO_TRANSPORTISTA#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(343113363511629809)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3431134'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DATOS_GESTION_DET_ID:CONTENEDOR_NUMERO:TURNO_IDVEHICULO:PESO:NOTIF_VERIFICADORA:UPLOAD_VERIFICADORA:ICONO_DETALLES:NOTIF_TRANSPORTISTA:UPLOAD_TRANSPORTISTA:ICONO_TRANSPORTISTA:'
,p_created_on=>wwv_flow_imp.dz('20241113165842Z')
,p_updated_on=>wwv_flow_imp.dz('20241113165842Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(326292191262333118)
,p_plug_name=>unistr('1. COORDINACI\00D3N')
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody:margin-bottom-sm'
,p_plug_template=>wwv_flow_imp.id(295619229174037679)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_css_classes=>'barraRegion '
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P521_EXPORTACION_REGISTRO'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'NOT (',
'    :P521_EDITAR_COORDINACION = 1',
'        OR',
'    :P521_EDITAR_TRANSITO = 1',
')'))
,p_plug_read_only_when2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(326300329140385979)
,p_plug_name=>'&P521_TITULO.'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296122226350169167)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(327478124828678427)
,p_plug_name=>unistr('2. TR\00C1NSITO')
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(295619229174037679)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_css_classes=>'barraRegion '
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P521_ESTADO NOT IN (''COORDINACION'')'
,p_plug_display_when_cond2=>'PLSQL'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>':P521_EDITAR_TRANSITO = 0'
,p_plug_read_only_when2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(364782691367500920)
,p_plug_name=>'Contenedores'
,p_parent_plug_id=>wwv_flow_imp.id(327478124828678427)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_css_classes=>'barraRegion '
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH',
'    W_CONTENEDORES_FACTURAS AS',
'    (',
'        SELECT ',
'            DATOS_GESTION_DET_ID      AS DATOS_GESTION_DET_ID,',
'            SUM(CASE WHEN DOCUMENTO_TIPO = ''BL_SPLIT'' THEN 1 ELSE 0 END) ',
'                                      AS COUNT_BL_SPLIT',
'        FROM ',
'            VT_CMEX_EXPORTACION_FACTURAS ',
'        WHERE',
'            EXPORTACION_REGISTRO=:P521_EXPORTACION_REGISTRO',
'        GROUP BY',
'            DATOS_GESTION_DET_ID',
'    )',
'    SELECT ',
'',
'        ''<span title="Ir al detalle" class="fa fa-pencil" id="''||DET.ID||''_DET"></span>''',
'                                 AS ICONO_LINK,',
'        WCF.DATOS_GESTION_DET_ID AS DATOS_GESTION_DET_ID,',
'        ',
'        DET.CONTENEDOR_NUMERO    AS CONTENEDOR_NUMERO,',
'        ',
'        DET.TURNO_ID             AS TURNO_ID,',
'        DET.TURNO_EMPRESA        AS TURNO_EMPRESA,',
'        DET.TURNO_IDVEHICULO     AS TURNO_IDVEHICULO,',
'        ',
'        DET.CONOCIMIENTO_EMBARQUE        AS CONOCIMIENTO_EMBARQUE,',
'        DET.CONOCIMIENTO_EMBARQUE_NUEVO  AS CONOCIMIENTO_EMBARQUE_NUEVO,',
'        DET.FECHA_INGRESO_PUERTO         AS FECHA_INGRESO_PUERTO,',
'        DET.FECHA_ETA                    AS FECHA_ETA,',
'        DET.FECHA_ZARPE                  AS FECHA_ZARPE,',
'        DET.PATIO_RETIRO                 AS PATIO_RETIRO,',
'        DET.INSPECCIONES                 AS INSPECCIONES,',
'',
'        CASE',
'            WHEN DET.CONOCIMIENTO_EMBARQUE_NUEVO IS NOT NULL AND DET.FECHA_ETA IS NOT NULL ',
'                THEN  ''<span title="Notificar SPLIT" class="fa fa-send" id="''||DET.ID||''_DET"></span>''',
'                ELSE ''''',
'        END                              AS ICONO_SPLIT,',
'        TO_CHAR(DET.FECHA_NOTIFICA_SPLIT, ''DD/MM/YYYY HH24:MI'')',
'                                         AS FECHA_NOTIFICA_SPLIT,',
'',
'',
'        CASE',
'            WHEN DET.FECHA_ZARPE IS NOT NULL ',
'                THEN  ''<span title="Notificar Zarpe" class="fa fa-send" id="''||DET.ID||''_DET"></span>''',
'                ELSE ''''',
'        END                              AS ICONO_ZARPE,',
'        TO_CHAR(DET.FECHA_NOTIFICA_ZARPE, ''DD/MM/YYYY HH24:MI'')',
'                                         AS FECHA_NOTIFICA_ZARPE',
'    FROM ',
'        W_CONTENEDORES_FACTURAS       WCF,',
'        VT_CMEX_DATOS_GESTION_DETALLE DET',
'    WHERE',
'        WCF.DATOS_GESTION_DET_ID = DET.ID',
';',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(364782712593500921)
,p_max_row_count=>'1000000'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>364782712593500921
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(364782885299500922)
,p_db_column_name=>'DATOS_GESTION_DET_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(364785145113500945)
,p_db_column_name=>'ICONO_LINK'
,p_display_order=>20
,p_column_identifier=>'W'
,p_column_label=>'^'
,p_column_link=>'f?p=&APP_ID.:529:&SESSION.::&DEBUG.:529:P529_EXPORTACION_REGISTRO,P529_DATOS_GESTION_DET_ID,P529_EDITAR_COORDINACION,P529_EDITAR_TRANSITO:&P521_EXPORTACION_REGISTRO.,#DATOS_GESTION_DET_ID#,&P521_EDITAR_COORDINACION.,&P521_EDITAR_TRANSITO.'
,p_column_linktext=>'#ICONO_LINK#'
,p_column_link_attr=>'class="openDialog"'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(364783068846500924)
,p_db_column_name=>'CONTENEDOR_NUMERO'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Contenedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(364783184163500925)
,p_db_column_name=>'TURNO_ID'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Turno ID'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(364783251570500926)
,p_db_column_name=>'TURNO_IDVEHICULO'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Placa'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(364784454983500938)
,p_db_column_name=>'TURNO_EMPRESA'
,p_display_order=>70
,p_column_identifier=>'P'
,p_column_label=>'Transportista'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(364784595552500939)
,p_db_column_name=>'CONOCIMIENTO_EMBARQUE'
,p_display_order=>80
,p_column_identifier=>'Q'
,p_column_label=>'Concmto. Embarq.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(364784656045500940)
,p_db_column_name=>'CONOCIMIENTO_EMBARQUE_NUEVO'
,p_display_order=>90
,p_column_identifier=>'R'
,p_column_label=>'Nuevo Concmto. Embarq.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(364785096479500944)
,p_db_column_name=>'FECHA_INGRESO_PUERTO'
,p_display_order=>100
,p_column_identifier=>'V'
,p_column_label=>'Ing. Puerto'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(364784710068500941)
,p_db_column_name=>'FECHA_ETA'
,p_display_order=>110
,p_column_identifier=>'S'
,p_column_label=>'ETA'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(364784874366500942)
,p_db_column_name=>'FECHA_ZARPE'
,p_display_order=>120
,p_column_identifier=>'T'
,p_column_label=>'Zarpe'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(364784941837500943)
,p_db_column_name=>'INSPECCIONES'
,p_display_order=>130
,p_column_identifier=>'U'
,p_column_label=>'Inspecciones'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(365936367219565747)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(366738767339091002)
,p_db_column_name=>'PATIO_RETIRO'
,p_display_order=>140
,p_column_identifier=>'X'
,p_column_label=>'Patio Retiro'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(366748229517141612)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(370139444245700528)
,p_db_column_name=>'ICONO_SPLIT'
,p_display_order=>150
,p_column_identifier=>'Y'
,p_column_label=>'Split'
,p_column_link=>'javascript:apex.item("P521_DETALLE_ID_SPLIT_NOTIF").setValue("#DATOS_GESTION_DET_ID#");'
,p_column_linktext=>'#ICONO_SPLIT#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(370140347907700537)
,p_db_column_name=>'FECHA_NOTIFICA_SPLIT'
,p_display_order=>160
,p_column_identifier=>'Z'
,p_column_label=>'Notf. SPLIT'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(370140402534700538)
,p_db_column_name=>'ICONO_ZARPE'
,p_display_order=>170
,p_column_identifier=>'AA'
,p_column_label=>'Zarpe'
,p_column_link=>'javascript:apex.item("P521_DETALLE_ID_ZARPE_NOTIF").setValue("#DATOS_GESTION_DET_ID#");'
,p_column_linktext=>'#ICONO_ZARPE#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(370140564032700539)
,p_db_column_name=>'FECHA_NOTIFICA_ZARPE'
,p_display_order=>180
,p_column_identifier=>'AB'
,p_column_label=>'Notf. Zarpe'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(365703749451141990)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3657038'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DATOS_GESTION_DET_ID:ICONO_LINK:CONTENEDOR_NUMERO:TURNO_IDVEHICULO:TURNO_EMPRESA:CONOCIMIENTO_EMBARQUE:CONOCIMIENTO_EMBARQUE_NUEVO:FECHA_INGRESO_PUERTO:FECHA_ETA:FECHA_ZARPE:PATIO_RETIRO:INSPECCIONES:ICONO_SPLIT:FECHA_NOTIFICA_SPLIT:ICONO_ZARPE:FECHA'
||'_NOTIFICA_ZARPE:'
,p_created_on=>wwv_flow_imp.dz('20241113165842Z')
,p_updated_on=>wwv_flow_imp.dz('20241113165842Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(370136751064700501)
,p_plug_name=>'Notificar Cliente'
,p_parent_plug_id=>wwv_flow_imp.id(327478124828678427)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_region_attributes=>'style="background: #FFF0F0"'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>50
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(370137686340700510)
,p_plug_name=>'Notificar COURIER'
,p_parent_plug_id=>wwv_flow_imp.id(327478124828678427)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_region_attributes=>'style="background: #F0FFF0"'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>60
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(327478209260678428)
,p_plug_name=>'3. COSTOS'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(295619229174037679)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_css_classes=>'barraRegion '
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P521_ESTADO NOT IN (''COORDINACION'', ''TRANSITO'')'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(388534494370038201)
,p_name=>unistr('Costos de Exportaci\00F3n')
,p_parent_plug_id=>wwv_flow_imp.id(327478209260678428)
,p_template=>wwv_flow_imp.id(295609041229037671)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from data.vt_cmex_provision@zaip',
'where idmesa = :p521_exportacion_registro'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>25
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No hay registros del Costo de Exportaciones'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(388535099394038207)
,p_query_column_id=>1
,p_column_alias=>'IDMESA'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(388535141733038208)
,p_query_column_id=>2
,p_column_alias=>'IDPROVISION'
,p_column_display_sequence=>20
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(388535265903038209)
,p_query_column_id=>3
,p_column_alias=>'CODIGOMODULO'
,p_column_display_sequence=>30
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(388535343050038210)
,p_query_column_id=>4
,p_column_alias=>'ESTADO'
,p_column_display_sequence=>40
,p_column_heading=>'Estado'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(388535438129038211)
,p_query_column_id=>5
,p_column_alias=>'BATCH'
,p_column_display_sequence=>50
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(388535546575038212)
,p_query_column_id=>6
,p_column_alias=>'ORDENCOMPRA'
,p_column_display_sequence=>60
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(388535692700038213)
,p_query_column_id=>7
,p_column_alias=>'MTOOI'
,p_column_display_sequence=>70
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(388535703874038214)
,p_query_column_id=>8
,p_column_alias=>'CODIGOPROVEEDOR'
,p_column_display_sequence=>80
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(388535819652038215)
,p_query_column_id=>9
,p_column_alias=>'TIPOMERCA'
,p_column_display_sequence=>90
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(388535959434038216)
,p_query_column_id=>10
,p_column_alias=>'REFERENDO'
,p_column_display_sequence=>100
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(388536036968038217)
,p_query_column_id=>11
,p_column_alias=>'ORDENAGTADN'
,p_column_display_sequence=>110
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(388536191104038218)
,p_query_column_id=>12
,p_column_alias=>'TIPOREGISTRO'
,p_column_display_sequence=>120
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(388536295682038219)
,p_query_column_id=>13
,p_column_alias=>'CONCEPTO'
,p_column_display_sequence=>130
,p_column_heading=>'Concepto'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(388536334943038220)
,p_query_column_id=>14
,p_column_alias=>'MONTOPROVISION'
,p_column_display_sequence=>140
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(388536471752038221)
,p_query_column_id=>15
,p_column_alias=>'MONTOREAL'
,p_column_display_sequence=>150
,p_column_heading=>'Monto'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(388536581010038222)
,p_query_column_id=>16
,p_column_alias=>'MONTOESTANDAR'
,p_column_display_sequence=>160
,p_column_heading=>'Monto Est.'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(327478352185678429)
,p_plug_name=>'4. ARRIBADO'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(295619229174037679)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_css_classes=>'barraRegion '
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P521_ESTADO NOT IN (''COORDINACION'', ''TRANSITO'', ''COSTOS'')'
,p_plug_display_when_cond2=>'PLSQL'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>':P521_EDITAR_ARRIBADO = 0'
,p_plug_read_only_when2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(372960374345615020)
,p_plug_name=>'DAE'
,p_parent_plug_id=>wwv_flow_imp.id(327478352185678429)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>50
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(372959969841615016)
,p_plug_name=>'DAE Regualrizado'
,p_region_name=>'downloadDAE'
,p_parent_plug_id=>wwv_flow_imp.id(372960374345615020)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NUMEROARCHIVO, FILENAME',
'FROM   FILES.T_APEX_ARCHIVOS',
'WHERE  NUMEROARCHIVO = :P521_DAE_REAL_NUMEROARCHIVO;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P521_DAE_REAL_NUMEROARCHIVO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'DAE Regualrizado'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(372960098832615017)
,p_max_row_count=>'1000000'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>372960098832615017
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(372960122120615018)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'DAE regularizado'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_format_mask=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment:#FILENAME#:FILES'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(372960277787615019)
,p_db_column_name=>'FILENAME'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(372977950091108417)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3729780'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMEROARCHIVO:FILENAME'
,p_created_on=>wwv_flow_imp.dz('20241113165842Z')
,p_updated_on=>wwv_flow_imp.dz('20241113165842Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(372960448487615021)
,p_plug_name=>unistr('Notificaci\00F3n')
,p_parent_plug_id=>wwv_flow_imp.id(327478352185678429)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_region_attributes=>'style="background: #F0F0FF;"'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>60
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(328862173391565401)
,p_plug_name=>'ARCHIVOS'
,p_region_template_options=>'#DEFAULT#:is-expanded:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(295619229174037679)
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_css_classes=>'barraRegion '
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P521_EXPORTACION_REGISTRO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(329869382432317115)
,p_plug_name=>'ARCHIVOS'
,p_parent_plug_id=>wwv_flow_imp.id(328862173391565401)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    DOC.NUMEROARCHIVO         AS NUMEROARCHIVO,',
'    DOC.TIPO                  AS TIPO,',
'    DOC.CO_CODE               AS CO_CODE,',
'    DOC.FACTURA_TIPO||''-''||DOC.FACTURA_NUMERO',
'                          AS FACTURA,',
'    DOC.CONTENEDOR_NUMERO     AS CONTENEDOR,',
'    DOC.OBSERVACION           AS OBSERVACION,',
'    DOC.FECHA_REGISTRO        AS FECHA,',
'',
'    LENGTH(BLOBCONTENT)       AS BLOBCONTENT,',
'    AA.FILENAME               AS FILENAME,',
'',
'    DOC.NUMEROARCHIVO         AS ICONO_BORRAR',
'FROM ',
'    T_CMEX_EXPORTACION_DOCUMENTO   DOC,',
'    FILES.T_APEX_ARCHIVOS          AA',
'WHERE',
'    DOC.NUMEROARCHIVO = AA.NUMEROARCHIVO',
'        AND',
'    DOC.EXPORTACION_REGISTRO = :P521_EXPORTACION_REGISTRO',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'ARCHIVOS'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(329869461091317116)
,p_max_row_count=>'1000000'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>329869461091317116
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(329869585736317117)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Numeroarchivo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(329869633442317118)
,p_db_column_name=>'TIPO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(364781140049500905)
,p_db_column_name=>'CO_CODE'
,p_display_order=>30
,p_column_identifier=>'M'
,p_column_label=>unistr('C\00F3d. CO')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(329870517378317127)
,p_db_column_name=>'BLOBCONTENT'
,p_display_order=>40
,p_column_identifier=>'J'
,p_column_label=>'Archivo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::inline:#FILENAME#:FILES'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(329869983646317121)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>unistr('Observaci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(329870163579317123)
,p_db_column_name=>'FACTURA'
,p_display_order=>60
,p_column_identifier=>'G'
,p_column_label=>'Factura'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(329870244184317124)
,p_db_column_name=>'CONTENEDOR'
,p_display_order=>70
,p_column_identifier=>'H'
,p_column_label=>'Contenedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(329870394465317125)
,p_db_column_name=>'FECHA'
,p_display_order=>80
,p_column_identifier=>'I'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(329870678796317128)
,p_db_column_name=>'FILENAME'
,p_display_order=>90
,p_column_identifier=>'K'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(332265346123974001)
,p_db_column_name=>'ICONO_BORRAR'
,p_display_order=>100
,p_column_identifier=>'L'
,p_column_label=>'.'
,p_column_link=>'javascript:apex.item("P521_ARCHIVO_ELIMINAR").setValue("#ICONO_BORRAR#");'
,p_column_linktext=>'<span class="fa fa-trash"></span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P521_EDITAR_COORDINACION = 1',
'    OR',
':P521_EDITAR_TRANSITO     = 1',
'    OR',
':P521_EDITAR_COSTOS       = 1',
'    OR',
':P521_EDITAR_ARRIBADO     = 1'))
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(330713810704745170)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3307139'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TIPO:BLOBCONTENT:CO_CODE:CONTENEDOR:FACTURA:OBSERVACION:ICONO_BORRAR:'
,p_created_on=>wwv_flow_imp.dz('20241113165842Z')
,p_updated_on=>wwv_flow_imp.dz('20241113165842Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(326291024214333107)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(326290901975333106)
,p_button_name=>'REGRESAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:520:&SESSION.::&DEBUG.:520::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(371909369205428009)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(326290901975333106)
,p_button_name=>'HISTORIA'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:503:&SESSION.::&DEBUG.:503:P503_P_ID:&P521_EXPORTACION_REGISTRO.'
,p_button_condition=>'P521_EXPORTACION_REGISTRO'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-h-square'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(329867907450317101)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(326290901975333106)
,p_button_name=>'ABRE_AGREGAR_FACTURA'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Agregar Factura'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:522:&SESSION.::&DEBUG.:522:P522_EXPORTACION_REGISTRO,P522_CLIENTE:&P521_EXPORTACION_REGISTRO.,&P521_CLIENTE.'
,p_button_condition=>':P521_EDITAR_COORDINACION=1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(327479335803678439)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(326290901975333106)
,p_button_name=>'GRABAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Grabar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P521_EDITAR_COORDINACION = 1',
'    OR',
':P521_EDITAR_TRANSITO = 1',
'    OR',
':P521_EDITAR_COSTOS = 1',
'    OR',
':P521_EDITAR_ARRIBADO =1'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(327478557863678431)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(326291216578333109)
,p_button_name=>'CREAR_CON_BOOKING'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Crear Con Booking'
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(370136922333700503)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(370136751064700501)
,p_button_name=>'NOTIFICA_DOCUMENTOS'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Notifica Documentos'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P521_EDITAR_TRANSITO = 1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>2
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(372959383657615010)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(372960374345615020)
,p_button_name=>'SUBIR_DAE_REGULARIZADO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Subir DAE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P521_EDITAR_ARRIBADO = 1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_grid_column_attributes=>'style="text-align: right;"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>2
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(372960786030615024)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(372960448487615021)
,p_button_name=>'NOTIFICAR_ARRIBADO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Notificar Arribado'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P521_EDITAR_ARRIBADO = 1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_grid_column_attributes=>'style="text-align: right;"'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(327478645631678432)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(326291476516333111)
,p_button_name=>'CREAR_SIN_BOOKING'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Crear Sin Booking'
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(332268985750974037)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(332268772573974035)
,p_button_name=>'ABRE_NOTIFICAR_NOVEDAD'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Notificar Novedad'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:524:&SESSION.::&DEBUG.:524:P524_EXPORTACION_REGISTRO:&P521_EXPORTACION_REGISTRO.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P521_EDITAR_COORDINACION = 1',
'    OR',
':P521_EDITAR_TRANSITO = 1',
'    OR',
':P521_EDITAR_COSTOS = 1'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-eye'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>1
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(370138192108700515)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(370137686340700510)
,p_button_name=>'NOTIFICAR_COURIER'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Notificar Courier'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P521_EDITAR_TRANSITO = 1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_grid_column_attributes=>'style="text-align: right;"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(328862203712565402)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(328862173391565401)
,p_button_name=>'SUBIR_ARCHIVO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Subir Archivo'
,p_button_position=>'LEFT_OF_TITLE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:523:&SESSION.::&DEBUG.:523:P523_EXPORTACION_REGISTRO:&P521_EXPORTACION_REGISTRO.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P521_EDITAR_COORDINACION = 1',
'    OR',
':P521_EDITAR_TRANSITO = 1',
'    OR',
':P521_EDITAR_COSTOS = 1',
'    OR',
':P521_EDITAR_ARRIBADO =1'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-file-plus'
,p_button_cattributes=>'style="padding: 0px"'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(326290520290333102)
,p_name=>'P521_EXPORTACION_REGISTRO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(326300329140385979)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(326290651122333103)
,p_name=>'P521_TITULO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(326300329140385979)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(326290772918333104)
,p_name=>'P521_BOOKING_ID'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(326292024447333117)
,p_prompt=>'BKG ID'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(326290833003333105)
,p_name=>'P521_FECHA_MINIMA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(326300329140385979)
,p_source=>'SELECT TO_CHAR(SYSDATE+4, ''YYYY-MM-DD'') FROM DUAL;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(326291585362333112)
,p_name=>'P521_BOOKING_SELECCIONADO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(326291216578333109)
,p_prompt=>'Booking'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_CMEX_BOOKING'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ID,',
'    NUMERO_BK,',
'    CLIENTE_NOMBRES,',
'    TRUNC(FECHA_PLAN_CARGUE) FECHA_PLAN_CARGUE',
'FROM VT_CMEX_BOOKING_MESA_TRABAJO',
'WHERE 1=1',
'-- AND ESTADO=''COMPLETADO''',
'-- AND NUMERO_BK IS NOT NULL',
';',
''))
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(326291605811333113)
,p_name=>'P521_CLIENTE_SELECCIONADO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(326291476516333111)
,p_prompt=>'Cliente'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'SELECT CODIGO||'' ''||NOMBRES, CODIGO FROM VT_JDE_CLIENTE;'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(326291780215333114)
,p_name=>'P521_MODALIDAD_SELECCIONADA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(326291476516333111)
,p_prompt=>'Modalidad'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:Terrestre;TERRESTRE,Aereo;AEREO'
,p_grid_label_column_span=>4
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327475536289678401)
,p_name=>'P521_CLIENTE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(326292024447333117)
,p_prompt=>'Cliente'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'SELECT CODIGO||'' ''||NOMBRES, CODIGO FROM VT_JDE_CLIENTE;'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327475684139678402)
,p_name=>'P521_MODALIDAD'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(326292024447333117)
,p_prompt=>'Modalidad'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_CMEX_MODALIDAD'
,p_lov=>'.'||wwv_flow_imp.id(166958819380978655)||'.'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327475750133678403)
,p_name=>'P521_INCOTERM'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(326292024447333117)
,p_prompt=>'Incoterm'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_INCOTERMS'
,p_lov=>'select DRKY ||'' - ''||upper(DRDL01) d,DRKY r from vt_jde_udcjde where drsy=''42'' and drrt=''FR'' and drky is not null order by upper(DRKY)'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327475855264678404)
,p_name=>'P521_REFRENDO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(326292191262333118)
,p_prompt=>'Refrendo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327475977610678405)
,p_name=>'P521_REFRENDO_FECHA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(326292191262333118)
,p_prompt=>'Refrendo Fecha'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327476016507678406)
,p_name=>'P521_NUMERO_BK'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(326292024447333117)
,p_prompt=>unistr('N\00FAmero BK')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327476216539678408)
,p_name=>'P521_TERMINAL_PORTUARIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(326292191262333118)
,p_prompt=>'Terminal Portuario'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'',
'    DESCRIPCION AS NOMBRE,',
'    ID_TABLA    AS ID',
'',
'FROM T_CORP_UDC',
'WHERE ID_CABECERA=''RCDP_TERMI''',
'ORDER BY DESCRIPCION',
';'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327476364040678409)
,p_name=>'P521_NAVIERA'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(326292024447333117)
,p_prompt=>'Naviera'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>'select distinct naviera from t_cmex_mesatrabajo order by 1;'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'Y'
,p_attribute_05=>'7'
,p_attribute_09=>'1'
,p_attribute_10=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327476458944678410)
,p_name=>'P521_PUERTO_DESTINO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(326292024447333117)
,p_prompt=>'Puerto Destino'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>'select DISTINCT PUERTODESTINO_EXP from t_cmex_mesatrabajo WHERE PUERTODESTINO_EXP IS NOT NULL;'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'Y'
,p_attribute_05=>'7'
,p_attribute_09=>'1'
,p_attribute_10=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327476604240678412)
,p_name=>'P521_FORWARDER'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(326292024447333117)
,p_prompt=>'Forwarder'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>'select distinct forwarder from t_cmex_mesatrabajo ORDER BY 1;'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'Y'
,p_attribute_05=>'7'
,p_attribute_09=>'1'
,p_attribute_10=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327476742472678413)
,p_name=>'P521_DESTINO'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(326292024447333117)
,p_prompt=>'Destino'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ID_TABLA||'' - ''||DESCRIPCION AS NOMBRE,',
'    ID_TABLA    AS ID',
'FROM T_CORP_UDC',
'WHERE ID_CABECERA=''1228''',
'ORDER BY DESCRIPCION;',
'    '))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327476873552678414)
,p_name=>'P521_PATIO_RETIRO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(326292191262333118)
,p_prompt=>'Patio Retiro'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_CMEX_PATIO_RETIRO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    DESCRIPCION AS NOMBRE,',
'    ID_TABLA    AS ID    ',
'FROM T_CORP_UDC',
'WHERE ID_CABECERA=''CMEX_BDGS''',
'ORDER BY DESCRIPCION',
';'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>':P521_MODALIDAD = ''AEREO'' OR :P521_MODALIDAD = ''TERRESTRE'''
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327476982324678415)
,p_name=>'P521_ETA_APROX'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(326292191262333118)
,p_prompt=>'ETA Aprox.'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327477028492678416)
,p_name=>'P521_CUT_OFF_FISICO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(326292191262333118)
,p_prompt=>unistr('Cut Off F\00CDsico')
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327477123562678417)
,p_name=>'P521_CUT_OFF_DOCUMENTAL'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(326292191262333118)
,p_prompt=>'Cut Off Doc.'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327477215300678418)
,p_name=>'P521_FECHA_ZARPE_ESTIMADA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(326292191262333118)
,p_prompt=>'Fecha Zarpe'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327477379570678419)
,p_name=>'P521_ESTADO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(326292024447333117)
,p_prompt=>'Etapa'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327477425227678420)
,p_name=>'P521_FECHA_REGISTRO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(326292024447333117)
,p_prompt=>'Fecha'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327477552054678421)
,p_name=>'P521_USUARIO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(326292024447333117)
,p_prompt=>'Usuario'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327477673824678422)
,p_name=>'P521_EDITAR_COORDINACION'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(326300329140385979)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF ',
'    :P521_ESTADO = ''COORDINACION'' ',
'        AND',
'    (',
'        :P521_USUARIO = :APP_USER',
'            OR',
'    	PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES(''CMEX'', :APP_USER, :APP_PAGE_ID, ''COORDINACION'')=1 ',
'    )',
'THEN ',
'    RETURN 1;',
'ELSE ',
'    RETURN 0;    ',
'END IF;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327477746312678423)
,p_name=>'P521_EDITAR_TRANSITO'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(326300329140385979)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF ',
'    :P521_ESTADO = ''TRANSITO'' ',
'        AND',
'    (',
'        :P521_USUARIO = :APP_USER',
'            OR',
'    	PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES(''CMEX'', :APP_USER, :APP_PAGE_ID, ''TRANSITO'')=1 ',
'    )',
'THEN ',
'    RETURN 1;',
'ELSE ',
'    RETURN 0;    ',
'END IF;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327477886079678424)
,p_name=>'P521_EDITAR_COSTOS'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(326300329140385979)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF ',
'    :P521_ESTADO = ''COSTOS'' ',
'        AND',
'    (',
'        :P521_USUARIO = :APP_USER',
'            OR',
'    	PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES(''CMEX'', :APP_USER, :APP_PAGE_ID, ''COSTOS'')=1 ',
'    )',
'THEN ',
'    RETURN 1;',
'ELSE ',
'    RETURN 0;    ',
'END IF;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327477946227678425)
,p_name=>'P521_EDITAR_ARRIBADO'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(326300329140385979)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF ',
'    :P521_ESTADO = ''ARRIBADO'' ',
'        AND',
'    (',
'        :P521_USUARIO = :APP_USER',
'            OR',
'    	PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES(''CMEX'', :APP_USER, :APP_PAGE_ID, ''ARRIBADO'')=1 ',
'    )',
'THEN ',
'    RETURN 1;',
'ELSE ',
'    RETURN 0;    ',
'END IF;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327478476225678430)
,p_name=>'P521_EDITAR_REGISTRO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(326300329140385979)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF ',
'    :P521_BOOKING_ID IS NULL ',
'        AND',
'    :P521_ESTADO = ''COORDINACION'' ',
'        AND',
'    (',
'        :P521_USUARIO = :APP_USER',
'            OR',
'    	PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES(''CMEX'', :APP_USER, :APP_PAGE_ID, ''COORDINACION'')=1 ',
'    )',
'THEN ',
'    RETURN 1;',
'ELSE ',
'    RETURN 0;    ',
'END IF;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(329869105992317113)
,p_name=>'P521_FACTURA_ELIMINAR'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(326300329140385979)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(329869286588317114)
,p_name=>'P521_ARCHIVO_ELIMINAR'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(326300329140385979)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(332266934743974017)
,p_name=>'P521_CUENTA_PLACAS'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(326300329140385979)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    COUNT(DISTINCT TURNO_IDVEHICULO)',
'FROM',
'    VT_CMEX_EXPORTACION_FACTURAS',
'WHERE',
'    EXPORTACION_REGISTRO = :P521_EXPORTACION_REGISTRO',
';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(332267042194974018)
,p_name=>'P521_ALERTA_VARIAS_PLACAS'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(326292024447333117)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Alerta Varias Placas'
,p_source=>unistr('Est\00E1 registrando &P521_CUENTA_PLACAS. veh\00EDculos distintos')
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'xxx'
,p_tag_css_classes=>'alertaVariasPlacas'
,p_tag_attributes=>'yyy'
,p_grid_label_column_span=>0
,p_display_when=>':P521_CUENTA_PLACAS > 1'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(332267578379974023)
,p_name=>'P521_SCROLL'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(326300329140385979)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(332268874466974036)
,p_name=>'P521_NOVEDAD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(332268772573974035)
,p_prompt=>'Novedad'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_EXPORTACION_NOVEDAD'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    DESCRIPCION  AS  DESCRIPCION,',
'    ID_TABLA     AS  CODE',
'FROM',
'    T_CORP_UDC ',
'WHERE ',
'    ID_CABECERA=''CMEX_EXPN''',
'ORDER BY DESCRIPCION',
';'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(332269048577974038)
,p_name=>'P521_NOVEDAD_FECHA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(332268772573974035)
,p_prompt=>'Fecha'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(364782170176500915)
,p_name=>'P521_CONTENEDORES_40'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(327478124828678427)
,p_prompt=>'Cont. 40'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(364782281051500916)
,p_name=>'P521_CONTENEDORES_20'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(327478124828678427)
,p_prompt=>'Cont. 20'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(364782362498500917)
,p_name=>'P521_PALLETS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(327478124828678427)
,p_prompt=>'Pallets'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(364784345734500937)
,p_name=>'P521_CARGA_ROLEADA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(327478124828678427)
,p_prompt=>'Carga Roleada'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'1'
,p_attribute_03=>'Si'
,p_attribute_04=>'0'
,p_attribute_05=>'No'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(370136870393700502)
,p_name=>'P521_FECHA_NOTIFICA_DOCUMENTOS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(370136751064700501)
,p_prompt=>'Notificado Documentos'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(370137838469700512)
,p_name=>'P521_FECHA_NOTIFICA_COURIER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(370137686340700510)
,p_prompt=>'Notificado Courier'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(370137952519700513)
,p_name=>'P521_COURIER'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(370137686340700510)
,p_prompt=>'Courier'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_CMEX_COURIER'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    DESCRIPCION AS NAME,',
'    ID_TABLA    AS VALUE',
'FROM',
'    T_CORP_UDC',
'WHERE',
'    ID_CABECERA=''CMEX_TRANS''',
';',
'',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(370138026454700514)
,p_name=>'P521_COURIER_GUIA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(370137686340700510)
,p_prompt=>unistr('Gu\00EDa')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(370139554861700529)
,p_name=>'P521_DETALLE_ID_SPLIT_NOTIF'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(326300329140385979)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(370140603413700540)
,p_name=>'P521_DETALLE_ID_ZARPE_NOTIF'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(326300329140385979)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(372958438092615001)
,p_name=>'P521_ETA_REAL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(327478352185678429)
,p_prompt=>'ETA Real'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(372958535556615002)
,p_name=>'P521_DAE_REGULARIZADA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(327478352185678429)
,p_prompt=>'DAE Regul.'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'1'
,p_attribute_03=>'SI'
,p_attribute_04=>'0'
,p_attribute_05=>'NO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(372958644964615003)
,p_name=>'P521_DAE_REAL_NUMEROARCHIVO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(327478352185678429)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(372958841836615005)
,p_name=>'P521_FECHA_NOTIFICA_ARRIBADO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(372960448487615021)
,p_prompt=>'Notif. Arribado'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(372959240507615009)
,p_name=>'P521_UPLOAD_DAE_REGULZDO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(372960374345615020)
,p_prompt=>'DAE Regularizado'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_display_when=>':P521_EDITAR_ARRIBADO = 1'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
,p_attribute_13=>'Seleccione archivo DAE regularizado'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(327478741423678433)
,p_validation_name=>'CREAR_CON_BOOKING'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P521_BOOKING_SELECCIONADO IS NULL THEN',
'    RETURN ''Debe seleccionar un BOOKING'';',
'END IF;',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(327478557863678431)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(327478959790678435)
,p_validation_name=>'CREAR_SIN_BOOKING'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P521_CLIENTE_SELECCIONADO IS NULL THEN',
'    RETURN ''Debe seleccionar un CLIENTE'';',
'END IF;',
'',
'IF :P521_MODALIDAD_SELECCIONADA IS NULL THEN',
'    RETURN ''Debe seleccionar una modalidad'';',
'END IF;',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(327478645631678432)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(370138858106700522)
,p_validation_name=>'NOTIFICAR_COURIER'
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P521_COURIER IS NULL THEN',
'    RETURN ''Debe Seleccionar un COURIER de la lista'';',
'END IF;',
'',
'IF :P521_COURIER_GUIA IS NULL THEN',
unistr('    RETURN ''Debe ingresar un n\00FAmero de gu\00EDa'';'),
'END IF;',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(370138192108700515)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(372959482265615011)
,p_validation_name=>'SUBIR_DAE_REGULARIZADO'
,p_validation_sequence=>40
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P521_UPLOAD_DAE_REGULZDO IS NULL THEN',
'    RETURN ''Debe seleccionar un archivo DAE regularizado'';',
'END IF;',
'',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(372959383657615010)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(373904932757832301)
,p_validation_name=>'NOTIFICAR_ARRIBADO'
,p_validation_sequence=>50
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P521_ETA_REAL IS NULL THEN',
'    RETURN ''Debe ingresar la fecha ETA Real'';',
'END IF;',
'',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(372960786030615024)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(332265417322974002)
,p_name=>'ARCHIVO_ELIMINAR'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P521_ARCHIVO_ELIMINAR'
,p_condition_element=>'P521_ARCHIVO_ELIMINAR'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(332265592188974003)
,p_event_id=>wwv_flow_imp.id(332265417322974002)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Eliminar el ARCHIVO ?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(332265635255974004)
,p_event_id=>wwv_flow_imp.id(332265417322974002)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_EXPORTACION.SP_ELIMINA_DOCUMENTO(',
'    :P521_ARCHIVO_ELIMINAR',
');'))
,p_attribute_02=>'P521_ARCHIVO_ELIMINAR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(332265782411974005)
,p_event_id=>wwv_flow_imp.id(332265417322974002)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P521_ARCHIVO_ELIMINAR'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(332265812447974006)
,p_event_id=>wwv_flow_imp.id(332265417322974002)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(329869382432317115)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(332266067736974008)
,p_name=>'FACTURA_ELIMINAR'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P521_FACTURA_ELIMINAR'
,p_condition_element=>'P521_FACTURA_ELIMINAR'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(332266150249974009)
,p_event_id=>wwv_flow_imp.id(332266067736974008)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Eliminar FACTURA ?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(332266295859974010)
,p_event_id=>wwv_flow_imp.id(332266067736974008)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_EXPORTACION.SP_ELIMINA_FACTURA(',
'    :P521_FACTURA_ELIMINAR',
');'))
,p_attribute_02=>'P521_FACTURA_ELIMINAR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(332266352746974011)
,p_event_id=>wwv_flow_imp.id(332266067736974008)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P521_FACTURA_ELIMINAR'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(332267822530974026)
,p_event_id=>wwv_flow_imp.id(332266067736974008)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s(''P521_SCROLL'', $(window).scrollTop());'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(332267272942974020)
,p_event_id=>wwv_flow_imp.id(332266067736974008)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(332267680895974024)
,p_name=>'SCROLL'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(332267789295974025)
,p_event_id=>wwv_flow_imp.id(332267680895974024)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(window).scrollTop($v(''P521_SCROLL''));'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(352512350062436506)
,p_name=>'VERIFICADORA_NOTIFICAR'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P521_CONTENEDOR_VERIFDRA_NOTIF'
,p_condition_element=>'P521_CONTENEDOR_VERIFDRA_NOTIF'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(352512464749436507)
,p_event_id=>wwv_flow_imp.id(352512350062436506)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Enviar NOTIFICACI\00D3N VERIFICADORA ?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(352512509448436508)
,p_event_id=>wwv_flow_imp.id(352512350062436506)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_EXPORTACION.SP_NOTIFICA_VERIFICADORA(',
'    :P521_EXPORTACION_REGISTRO, ',
'    :P521_CONTENEDOR_VERIFDRA_NOTIF, ',
'    NULL',
');'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(352512667550436509)
,p_event_id=>wwv_flow_imp.id(352512350062436506)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P521_CONTENEDOR_VERIFDRA_NOTIF'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(352512745704436510)
,p_event_id=>wwv_flow_imp.id(352512350062436506)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(343097240908056504)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(370137078173700504)
,p_name=>'NOTIFICA DOCUMENTOS'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(370136922333700503)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370137444426700508)
,p_event_id=>wwv_flow_imp.id(370137078173700504)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Scroll'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s(''P521_SCROLL'', $(window).scrollTop());'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370137100420700505)
,p_event_id=>wwv_flow_imp.id(370137078173700504)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Notificar al cliente ?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370137555743700509)
,p_event_id=>wwv_flow_imp.id(370137078173700504)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'Spinner'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.util.showSpinner();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370137275647700506)
,p_event_id=>wwv_flow_imp.id(370137078173700504)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_EXPORTACION.SP_NOTIFICA_CLIENTE_DOCMNTOS (',
'    :P521_EXPORTACION_REGISTRO,',
'    NULL',
');'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370137381441700507)
,p_event_id=>wwv_flow_imp.id(370137078173700504)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(370138272770700516)
,p_name=>'NOTIFICA COURIER'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(370138192108700515)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370138308145700517)
,p_event_id=>wwv_flow_imp.id(370138272770700516)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Scroll'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s(''P521_SCROLL'', $(window).scrollTop());'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370138423251700518)
,p_event_id=>wwv_flow_imp.id(370138272770700516)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Enviar el COURIER al cliente ?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370138745754700521)
,p_event_id=>wwv_flow_imp.id(370138272770700516)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'NOTIFICAR_COURIER'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(370139632634700530)
,p_name=>'SPLIT_NOTIFICAR'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P521_DETALLE_ID_SPLIT_NOTIF'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370140001005700534)
,p_event_id=>wwv_flow_imp.id(370139632634700530)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Scroll'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s(''P521_SCROLL'', $(window).scrollTop());'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370139752986700531)
,p_event_id=>wwv_flow_imp.id(370139632634700530)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Notificar SPLIT al cliente ?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370140115690700535)
,p_event_id=>wwv_flow_imp.id(370139632634700530)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_EXPORTACION.SP_NOTIFICA_SPLIT (',
'    :P521_EXPORTACION_REGISTRO,',
'    :P521_DETALLE_ID_SPLIT_NOTIF,',
'    NULL',
');'))
,p_attribute_02=>'P521_DETALLE_ID_SPLIT_NOTIF'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370139877178700532)
,p_event_id=>wwv_flow_imp.id(370139632634700530)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P521_DETALLE_ID_SPLIT_NOTIF'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370139971213700533)
,p_event_id=>wwv_flow_imp.id(370139632634700530)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(370140739863700541)
,p_name=>'ZARPE_NOTIFICAR'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P521_DETALLE_ID_ZARPE_NOTIF'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370140838578700542)
,p_event_id=>wwv_flow_imp.id(370140739863700541)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'Scroll'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'$s(''P521_SCROLL'', $(window).scrollTop());'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370140944734700543)
,p_event_id=>wwv_flow_imp.id(370140739863700541)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Notificar ZARPE al cliente ?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370141083731700544)
,p_event_id=>wwv_flow_imp.id(370140739863700541)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_EXPORTACION.SP_NOTIFICA_ZARPE (',
'    :P521_EXPORTACION_REGISTRO,',
'    :P521_DETALLE_ID_ZARPE_NOTIF,',
'    NULL',
');'))
,p_attribute_02=>'P521_DETALLE_ID_ZARPE_NOTIF'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370141115370700545)
,p_event_id=>wwv_flow_imp.id(370140739863700541)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P521_DETALLE_ID_ZARPE_NOTIF'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'Y'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(370141236619700546)
,p_event_id=>wwv_flow_imp.id(370140739863700541)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(372958962800615006)
,p_name=>'GRABAR TODAS'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(327479335803678439)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'!(',
'    $v("P521_ESTADO") !== "" &&',
'    $v("P521_ESTADO") === "ARRIBADO" &&',
'    $v("P521_ETA_REAL") !== "" &&',
'    $v("P521_DAE_REGULARIZADA") === "1" &&',
'    $v("P521_DAE_REAL_NUMEROARCHIVO") !== ""',
')'))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(372959035665615007)
,p_event_id=>wwv_flow_imp.id(372958962800615006)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Scroll'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s(''P521_SCROLL'', $(window).scrollTop());'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(372959114478615008)
,p_event_id=>wwv_flow_imp.id(372958962800615006)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'GRABAR'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(372959611950615013)
,p_name=>'SUBIR_DAE_REGULARIZADO'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(372959383657615010)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(372959703026615014)
,p_event_id=>wwv_flow_imp.id(372959611950615013)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Scroll'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s(''P521_SCROLL'', $(window).scrollTop());'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(372959808207615015)
,p_event_id=>wwv_flow_imp.id(372959611950615013)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'SUBIR_DAE_REGULARIZADO'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(373905142259832303)
,p_name=>'NOTIFICAR_ARRIBADO'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(372960786030615024)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(373905255161832304)
,p_event_id=>wwv_flow_imp.id(373905142259832303)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Scroll'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s(''P521_SCROLL'', $(window).scrollTop());'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(373905384114832305)
,p_event_id=>wwv_flow_imp.id(373905142259832303)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Enviar notificaci\00F3n de CARGA ARRIBADA al cliente ?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(373905448825832306)
,p_event_id=>wwv_flow_imp.id(373905142259832303)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'NOTIFICAR_ARRIBADO'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(373906117178832313)
,p_name=>'GRABAR FINALIZADO'
,p_event_sequence=>120
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(327479335803678439)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$v("P521_ESTADO") !== "" &&',
'$v("P521_ESTADO") === "ARRIBADO" &&',
'$v("P521_ETA_REAL") !== "" &&',
'$v("P521_DAE_REGULARIZADA") === "1" &&',
'$v("P521_DAE_REAL_NUMEROARCHIVO") !== ""',
''))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(373906391296832315)
,p_event_id=>wwv_flow_imp.id(373906117178832313)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Esta acci\00F3n dar\00E1 por FINALIZADO el proceso y ya no se podr\00E1 hacer cambios ni notificaciones'),
'<br>',
'Desea continuar ?'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(373906280305832314)
,p_event_id=>wwv_flow_imp.id(373906117178832313)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Scroll 0'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s(''P521_SCROLL'', 0);'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(373906440347832316)
,p_event_id=>wwv_flow_imp.id(373906117178832313)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'GRABAR'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(327478892463678434)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CREAR_CON_BOOKING'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_EXPORTACION.SP_EXPORTACION_NUEVO(',
'        :G_COMPANIA,               -- P_COMPANIA',
'        :APP_USER,                 -- P_USUARIO ',
'        :P521_BOOKING_SELECCIONADO,-- P_BOOKING_ID ',
'        NULL,                      -- P_CLIENTE_ID ',
'        NULL,                      -- P_MODALIDAD ',
'        ---------------------------',
'        :P521_EXPORTACION_REGISTRO -- P_REGISTRO ',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(327478557863678431)
,p_internal_uid=>327478892463678434
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(327479057540678436)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CREAR_SIN_BOOKING'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_EXPORTACION.SP_EXPORTACION_NUEVO(',
'        :G_COMPANIA,                 -- P_COMPANIA',
'        :APP_USER,                   -- P_USUARIO ',
'        NULL,                        -- P_BOOKING_ID ',
'        :P521_CLIENTE_SELECCIONADO,  -- P_CLIENTE_ID ',
'        :P521_MODALIDAD_SELECCIONADA,-- P_MODALIDAD ',
'        ---------------------------',
'        :P521_EXPORTACION_REGISTRO   -- P_REGISTRO ',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(327478645631678432)
,p_internal_uid=>327479057540678436
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(327479437811678440)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GRABAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_EXPORTACION.SP_GRABA_EXPORTACION (',
'        :P521_EXPORTACION_REGISTRO, -- P_REGISTRO',
'        --------------------------------',
'        :P521_NUMERO_BK,            -- P_NUMERO_BK',
'        :P521_REFRENDO,             -- P_REFRENDO',
'        :P521_REFRENDO_FECHA,       -- P_REFRENDO_FECHA',
'        --------------------------------',
'        :P521_INCOTERM,             -- P_INCOTERM',
'        :P521_TERMINAL_PORTUARIO,   -- P_TERMINAL_PORTUARIO',
'        :P521_NAVIERA,              -- P_NAVIERA',
'        :P521_PUERTO_DESTINO,       -- P_PUERTO_DESTINO',
'        :P521_FORWARDER,            -- P_FORWARDER',
'        :P521_DESTINO,              -- P_DESTINO',
'        :P521_PATIO_RETIRO,         -- P_PATIO_RETIRO',
'        :P521_CUT_OFF_DOCUMENTAL,   -- P_CUT_OFF_DOCUMENTAL',
'        :P521_CUT_OFF_FISICO,       -- P_CUT_OFF_FISICO',
'        :P521_ETA_APROX,            -- P_ETA_APROX',
'        :P521_FECHA_ZARPE_ESTIMADA, -- P_FECHA_ZARPE_ESTIMADA',
'        --------------------------------',
'        :P521_CARGA_ROLEADA,        -- P_CARGA_ROLEADA',
'        ---------------------------------------',
'        :P521_ETA_REAL,             -- P_ETA_REAL',
'        :P521_DAE_REGULARIZADA      -- P_DAE_REGULARIZADA',
'    );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(327479335803678439)
,p_internal_uid=>327479437811678440
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(370138985994700523)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'NOTIFICAR_COURIER'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_EXPORTACION.SP_NOTIFICA_CLIENTE_COURIER (',
'    :P521_EXPORTACION_REGISTRO,',
'    :P521_COURIER,',
'    :P521_COURIER_GUIA,',
'    NULL',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(370138192108700515)
,p_internal_uid=>370138985994700523
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(372959552047615012)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SUBIR_DAE_REGULARIZADO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_EXPORTACION.SP_GRABA_UPLOAD_ARRIBADO(',
'        :P521_EXPORTACION_REGISTRO,',
'        :P521_ETA_REAL,',
'        :P521_DAE_REGULARIZADA,',
'        :APP_USER',
'    );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(372959383657615010)
,p_internal_uid=>372959552047615012
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(373905010692832302)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'NOTIFICAR_ARRIBADO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_EXPORTACION.SP_NOTIFICA_CLIENTE_ARRIBADO (',
'        :P521_EXPORTACION_REGISTRO,',
'        :P521_ETA_REAL,',
'        NULL',
'    );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(372960786030615024)
,p_internal_uid=>373905010692832302
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(326291961075333116)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Carga EXPORTACI\00D3N')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P521_EXPORTACION_REGISTRO IS NOT NULL THEN',
'',
'    SELECT',
'        CLIENTE,',
'        MODALIDAD,',
'        ESTADO,',
'        USUARIO,',
'        BOOKING_ID,',
'',
'        NUMERO_BK, ',
'        REFRENDO, ',
'        REFRENDO_FECHA, ',
'',
'        INCOTERM, ',
'        TERMINAL_PORTUARIO, ',
'        NAVIERA, ',
'        PUERTO_DESTINO, ',
'        FORWARDER, ',
'        DESTINO, ',
'        PATIO_RETIRO, ',
'        CUT_OFF_DOCUMENTAL, ',
'        CUT_OFF_FISICO, ',
'        ETA_APROX, ',
'        FECHA_ZARPE_ESTIMADA,',
'',
'        NOVEDAD,',
'        TO_CHAR(NOVEDAD_FECHA, ''DD/MM/YYYY HH24:MI''),',
'',
'        TO_CHAR(FECHA_REGISTRO, ''DD/MM/YYYY HH24:MI''),',
'',
'        ---------------------------------------',
'        CARGA_ROLEADA,',
'        TO_CHAR(FECHA_NOTIFICA_DOCUMENTOS, ''DD/MM/YYYY HH24:MI''),',
'        COURIER,',
'        COURIER_GUIA,',
'        TO_CHAR(FECHA_NOTIFICA_COURIER, ''DD/MM/YYYY HH24:MI''),',
'',
'        ---------------------------------------',
'        ETA_REAL,',
'        DAE_REGULARIZADA,',
'        DAE_REAL_NUMEROARCHIVO,',
'        TO_CHAR(FECHA_NOTIFICA_ARRIBADO, ''DD/MM/YYYY HH24:MI'')',
'    INTO',
'        :P521_CLIENTE,',
'        :P521_MODALIDAD,',
'        :P521_ESTADO,',
'        :P521_USUARIO,',
'        :P521_BOOKING_ID,',
'',
'        :P521_NUMERO_BK, ',
'        :P521_REFRENDO, ',
'        :P521_REFRENDO_FECHA,',
'',
'        :P521_INCOTERM,',
'        :P521_TERMINAL_PORTUARIO,',
'        :P521_NAVIERA,',
'        :P521_PUERTO_DESTINO,',
'        :P521_FORWARDER,',
'        :P521_DESTINO,',
'        :P521_PATIO_RETIRO,',
'        :P521_CUT_OFF_DOCUMENTAL,',
'        :P521_CUT_OFF_FISICO,',
'        :P521_ETA_APROX,',
'        :P521_FECHA_ZARPE_ESTIMADA,',
'',
'        :P521_NOVEDAD,',
'        :P521_NOVEDAD_FECHA,',
'',
'        :P521_FECHA_REGISTRO,',
'        ---------------------------------------',
'        :P521_CARGA_ROLEADA,',
'        :P521_FECHA_NOTIFICA_DOCUMENTOS,',
'        :P521_COURIER,',
'        :P521_COURIER_GUIA,',
'        :P521_FECHA_NOTIFICA_COURIER,',
'        ---------------------------------------',
'        :P521_ETA_REAL,',
'        :P521_DAE_REGULARIZADA,',
'        :P521_DAE_REAL_NUMEROARCHIVO,',
'        :P521_FECHA_NOTIFICA_ARRIBADO',
'    FROM ',
'        T_CMEX_EXPORTACION',
'    WHERE ',
'        REGISTRO = :P521_EXPORTACION_REGISTRO;    ',
'        ',
'END IF;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>326291961075333116
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(364782456287500918)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga BOOKING'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P521_BOOKING_ID IS NOT NULL THEN',
'    SELECT',
'        CONTENEDORES_40,',
'        CONTENEDORES_20,',
'        PALLETS',
'    INTO',
'        :P521_CONTENEDORES_40,',
'        :P521_CONTENEDORES_20,',
'        :P521_PALLETS    ',
'    FROM',
'        T_CMEX_BOOKING',
'    WHERE',
'        ID = :P521_BOOKING_ID',
'    ;',
'END IF;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>364782456287500918
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(326291817805333115)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Carga T\00EDtulo')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    IF :P521_EXPORTACION_REGISTRO IS NULL THEN',
unistr('        :P521_TITULO := ''Nueva EXPORTACI\00D3N'';'),
'    END IF;',
'',
'    IF :P521_EXPORTACION_REGISTRO IS NOT NULL THEN',
'        :P521_TITULO := ''Nr. ''||:P521_EXPORTACION_REGISTRO||'' : ''||PK_CMEX_EXPORTACION.F_ETAPA_VISUAL(:P521_ESTADO)||'' : ''||:P521_MODALIDAD;',
'    END IF;',
'END;',
'',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>326291817805333115
);
wwv_flow_imp.component_end;
end;
/
