prompt --application/pages/page_00179
begin
--   Manifest
--     PAGE: 00179
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>179
,p_name=>'Comprobacion Facturas y Verificadora Exportaciones'
,p_step_title=>'Comprobacion Facturas y Verificadora Exportaciones'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230825163644Z')
,p_last_updated_on=>wwv_flow_imp.dz('20241114043802Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(86277986733501526)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(86280096649501547)
,p_plug_name=>'Periodo'
,p_region_name=>'dlgPeriodo'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size480x320'
,p_plug_template=>wwv_flow_imp.id(295627185797037684)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(86365604530898802)
,p_plug_name=>'FormularioPeriodo'
,p_parent_plug_id=>wwv_flow_imp.id(86280096649501547)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(86515657157362120)
,p_plug_name=>'Factura'
,p_region_name=>'dlgArchivo'
,p_region_template_options=>'#DEFAULT#:js-dialog-size600x400'
,p_plug_template=>wwv_flow_imp.id(295627185797037684)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(86515716747362121)
,p_plug_name=>'Form'
,p_parent_plug_id=>wwv_flow_imp.id(86515657157362120)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(86516488571362128)
,p_plug_name=>unistr('Pesta\00F1as')
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_imp.id(295637154502037690)
,p_plug_display_sequence=>50
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(86367631091898822)
,p_plug_name=>'Reporte Verificadora'
,p_parent_plug_id=>wwv_flow_imp.id(86516488571362128)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       SEMANA,',
'       FECHA,',
'       CLIENTE,',
'       PROFORMA,',
'       FACTURA,',
'       REFERENDO,',
'       NUMEROCERTIFICADO,',
'       ANTINARCOTICOS,',
'       VALOR ,',
'       INSPECTOR,',
'       OBSERVACIONES,',
'       OBSERVACIONADICIONAL,',
'       ESTADO,',
'       USERCREA,',
'       FECHCREA,',
'       USERMODI,',
'       FECHMODI,',
'       MES,',
'       ANIO, ',
'       BANDERAS',
'  from T_CMEX_ARCHIVOSVERIFICADORES'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(86369936913898845)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:180:&SESSION.::&DEBUG.:RP,180:P180_ID:#ID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'NETBY3'
,p_internal_uid=>86369936913898845
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86370072744898846)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86370186005898847)
,p_db_column_name=>'SEMANA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Semana'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86370266976898848)
,p_db_column_name=>'FECHA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86370310342898849)
,p_db_column_name=>'CLIENTE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86370468764898850)
,p_db_column_name=>'PROFORMA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Proforma'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86513709034362101)
,p_db_column_name=>'FACTURA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Factura'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86513840321362102)
,p_db_column_name=>'REFERENDO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Referendo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86513943269362103)
,p_db_column_name=>'NUMEROCERTIFICADO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>unistr('N\00FAmero Certificado')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86514049250362104)
,p_db_column_name=>'ANTINARCOTICOS'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>unistr('Antinarc\00F3ticos')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86514244588362106)
,p_db_column_name=>'INSPECTOR'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Inspector'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86514353951362107)
,p_db_column_name=>'OBSERVACIONES'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86514401723362108)
,p_db_column_name=>'OBSERVACIONADICIONAL'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>unistr('Observaci\00F3n Adicional')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86514534337362109)
,p_db_column_name=>'ESTADO'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86514604920362110)
,p_db_column_name=>'USERCREA'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Usercrea'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86514767502362111)
,p_db_column_name=>'FECHCREA'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Fechcrea'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86514813428362112)
,p_db_column_name=>'USERMODI'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Usermodi'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86514928268362113)
,p_db_column_name=>'FECHMODI'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Fechmodi'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86515098637362114)
,p_db_column_name=>'MES'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Mes'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86515171998362115)
,p_db_column_name=>'ANIO'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>unistr('A\00F1o')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86923098204816323)
,p_db_column_name=>'VALOR'
,p_display_order=>210
,p_column_identifier=>'V'
,p_column_label=>'Valor'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86923174336816324)
,p_db_column_name=>'BANDERAS'
,p_display_order=>220
,p_column_identifier=>'W'
,p_column_label=>'Banderas'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(86560448849364202)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'865605'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEMANA:FECHA:CLIENTE:PROFORMA:FACTURA:REFERENDO:NUMEROCERTIFICADO:VALOR:ANTINARCOTICOS:INSPECTOR:OBSERVACIONES:OBSERVACIONADICIONAL:ESTADO:MES:ANIO:'
,p_sort_column_1=>'SEMANA'
,p_sort_direction_1=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20230825163644Z')
,p_updated_on=>wwv_flow_imp.dz('20230825163644Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(87448070682983589)
,p_report_id=>wwv_flow_imp.id(86560448849364202)
,p_name=>'Valores a Revisar'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BANDERAS'
,p_operator=>'contains'
,p_expr=>'VALOR'
,p_condition_sql=>' (case when (upper("BANDERAS") like ''%''||upper(#APXWS_EXPR#)||''%'') then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# ''VALOR''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_font_color=>'#FA0505'
,p_created_on=>wwv_flow_imp.dz('20230825163644Z')
,p_updated_on=>wwv_flow_imp.dz('20230825163644Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(86516535637362129)
,p_plug_name=>'Reporte Facturas'
,p_parent_plug_id=>wwv_flow_imp.id(86516488571362128)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'TABLE'
,p_query_table=>'T_CMEX_FACTURASFEDEXPORT_CAB'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_updated_on=>wwv_flow_imp.dz('20241114043802Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(86516611414362130)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:181:&SESSION.::&DEBUG.:RP,181:P181_ID,P181_ESTABLECIMIENTO,P181_PTOEMISION,P181_SECUENCIA:#ID#,#ESTAB#,#PUNTOEMISION#,#SECUENCIA#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'NETBY3'
,p_internal_uid=>86516611414362130
,p_updated_on=>wwv_flow_imp.dz('20241114043802Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86516752784362131)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86516867919362132)
,p_db_column_name=>'RUC'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Ruc'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86516971152362133)
,p_db_column_name=>'CLAVEACCESO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Clave Acceso'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86517014194362134)
,p_db_column_name=>'CODDOC'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>unistr('C\00F3digo Documento')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86517187193362135)
,p_db_column_name=>'ESTAB'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Establecimiento'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86517295930362136)
,p_db_column_name=>'PUNTOEMISION'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>unistr('Punto Emisi\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86517313168362137)
,p_db_column_name=>'SECUENCIA'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Secuencia'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86517453816362138)
,p_db_column_name=>'VALOR'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Valor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86517529672362139)
,p_db_column_name=>'FECHAEMISION'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>unistr('Fecha Emisi\00F3n')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(86803418014862347)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'868035'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'RUC:CLAVEACCESO:SECUENCIA:FECHAEMISION:'
,p_created_on=>wwv_flow_imp.dz('20230825163644Z')
,p_updated_on=>wwv_flow_imp.dz('20241114043802Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(86278081776501527)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(86277986733501526)
,p_button_name=>'CargarDatos'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Cargar Archivo Verificadora'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-upload'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(86365797488898803)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(86365604530898802)
,p_button_name=>'CARGAR'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Cargar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:300:&SESSION.::&DEBUG.:RP,300:G_MODULO,G_PAGINA:&APP_ID.,179'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(86516136938362125)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(86515716747362121)
,p_button_name=>'SUBIR_FACTURA'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Procesar Factura'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(86515543268362119)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(86277986733501526)
,p_button_name=>'CargarFactura'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Cargar Factura'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-file'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(86924527585816338)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(86277986733501526)
,p_button_name=>'VerReporteVerificacion'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>unistr('Ver Reporte Verificaci\00F3n')
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:182:&SESSION.::&DEBUG.:RP,182::'
,p_icon_css_classes=>'fa-eye'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86280139596501548)
,p_name=>'P179_MES'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(86365604530898802)
,p_prompt=>'Mes'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Enero;01,Febrero;02,Marzo;03,Abril;04,Mayo;05,Junio;06,Julio;07,Agosto;08,Septiembre;09,Octubre;10,Noviembre;11,Diciembre;12'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86280266360501549)
,p_name=>'P179_ANO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(86365604530898802)
,p_prompt=>unistr('A\00F1o')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT EXTRACT(YEAR  FROM SYSDATE) AS D,  EXTRACT(YEAR  FROM SYSDATE) AS R FROM DUAL',
'UNION ',
'SELECT EXTRACT(YEAR  FROM ADD_MONTHS(SYSDATE, -12)) AS D,  EXTRACT(YEAR  FROM ADD_MONTHS(SYSDATE, -12)) AS R FROM DUAL'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86515827580362122)
,p_name=>'P179_ARCHIVOS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(86515716747362121)
,p_prompt=>'Factura'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'NATIVE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(86280331128501550)
,p_name=>'mostrar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(86278081776501527)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86365504254898801)
,p_event_id=>wwv_flow_imp.id(86280331128501550)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal("dlgPeriodo");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(86367471505898820)
,p_name=>'EliminarDatos'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(86365797488898803)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86367505161898821)
,p_event_id=>wwv_flow_imp.id(86367471505898820)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DELETE FROM  DATA.T_CMEX_ARCHIVOSVERIFICADORES',
'WHERE MES = :179_MES AND ANIO = :P179_ANO;'))
,p_attribute_02=>'P179_ANO,P179_MES'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(86515912041362123)
,p_name=>'AbrirModal'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(86515543268362119)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86516063817362124)
,p_event_id=>wwv_flow_imp.id(86515912041362123)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'openModal("dlgArchivo");'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(86369749452898843)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete'
,p_process_sql_clob=>'DELETE FROM T_CMEX_ARCHIVOSVERIFICADORES;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>86369749452898843
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(86516382813362127)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ProcesarFactura'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'DATA.pk_cmex_mesatrabajo.SP_PROCESARFACTURA_EXP(:P179_ARCHIVOS);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>86516382813362127
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(86516202515362126)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'EliminaValoresMesAnio'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P179_ANO := NULL;',
':P179_MES := NULL;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>86516202515362126
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(86279797292501544)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'MigrarDatosAPEX_EXCEL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_id NUMBER;',
'BEGIN ',
'',
'DELETE FROM DATA.T_CMEX_ARCHIVOSVERIFICADORES WHERE MES = :P179_MES AND ANIO = :P179_ANO;',
'',
'INSERT INTO DATA.T_CMEX_ARCHIVOSVERIFICADORES (ID, SEMANA, FECHA, CLIENTE, PROFORMA, FACTURA, REFERENDO, NUMEROCERTIFICADO, ANTINARCOTICOS, VALOR, INSPECTOR, OBSERVACIONES, ESTADO, USERCREA, FECHCREA, MES, ANIO )',
'SELECT      NULL as ID, TO_NUMBER(C02) AS SEMANA, to_date(''1899-12-30'', ''YYYY-MM-DD'') + TO_NUMBER(C03) AS FECHA , C04 AS CLIENTE, C05 AS PROFORMA, C06 AS FACTURA, C07 AS REFERENDO,',
'            C08 AS NUMEROCERTIFICADO, C09 AS ANTINARCOTICOS, TO_NUMBER(C10) AS VALOR, C11 AS INSPECTOR, C12 AS OBSERVACIONES, ''NO MODIFICADO'' AS ESTADO, :APP_USER, SYSDATE, :P179_MES,:P179_ANO',
' FROM VT_APEX_EXCEL',
' WHERE (C02 IS NOT NULL AND TRIM(C02) <> ''SEMANA'');',
' ',
' FOR registroID IN (SELECT ID, SEMANA, FECHA, CLIENTE, PROFORMA, FACTURA, REFERENDO, NUMEROCERTIFICADO,  ANTINARCOTICOS, VALOR, INSPECTOR, OBSERVACIONES, ESTADO, USERCREA, FECHCREA, MES, ANIO',
'                    FROM  DATA.T_CMEX_ARCHIVOSVERIFICADORES WHERE FACTURA LIKE ''%/%''AND MES = :P179_MES AND ANIO = :P179_ANO )',
' LOOP',
'     FOR linea IN ( SELECT ROWNUM AS NUMERO, REGEXP_SUBSTR(registroID.FACTURA, ''[^/]+'', 1, level) AS PARTE',
'            FROM dual CONNECT BY REGEXP_SUBSTR(registroID.FACTURA, ''[^/]+'', 1, level) IS NOT NULL)',
'            LOOP',
'            APEX_DEBUG_MESSAGE.ENABLE_DEBUG_MESSAGES(p_level => 3);',
'',
'                APEX_DEBUG_MESSAGE.LOG_MESSAGE(',
'                p_message => ''  = '' ||  linea.PARTE ,',
'                p_level => 1 );    ',
'            ',
'              IF linea.NUMERO = 1 THEN',
'                   UPDATE DATA.T_CMEX_ARCHIVOSVERIFICADORES',
'                   SET FACTURA = linea.PARTE,',
'                       BANDERAS = BANDERAS || ''/VALOR''',
'                   WHERE ID = registroID.ID;',
'             ELSE ',
'                 INSERT INTO DATA.T_CMEX_ARCHIVOSVERIFICADORES (ID, SEMANA, FECHA, CLIENTE, PROFORMA, FACTURA, REFERENDO, NUMEROCERTIFICADO, ANTINARCOTICOS, VALOR, INSPECTOR, OBSERVACIONES, ESTADO, USERCREA, FECHCREA, MES, ANIO, BANDERAS )',
'                 VALUES(NULL, registroID.SEMANA, registroID.FECHA, registroID.CLIENTE, registroID.PROFORMA, linea.PARTE, registroID.REFERENDO, registroID.NUMEROCERTIFICADO, registroID.ANTINARCOTICOS,',
'                          registroID.VALOR, registroID.INSPECTOR, registroID.OBSERVACIONES, registroID.ESTADO, :APP_USER, SYSDATE , :P179_MES, :P179_ANO, ''VALOR'');',
'             END IF;',
'                ',
'            END LOOP;',
' END LOOP;',
'',
'      BEGIN ',
'       SELECT ID into v_id FROM APEX_180200.wwv_flow_collections$ c WHERE c.collection_name=''TABLA_EXCEL'' AND SESSION_ID = :APP_SESSION;',
'       DELETE FROM APEX_180200.wwv_flow_collection_members$ m WHERE m.collection_id = v_id;',
'       DELETE FROM APEX_180200.wwv_flow_collections$ c WHERE c.collection_name=''TABLA_EXCEL'' AND ID = v_id ;',
'       EXCEPTION WHEN NO_DATA_FOUND THEN v_id := 0;',
'      END;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>86279797292501544
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(86922270904816315)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'EliminaValoresItems'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P179_ANO := NULL;',
':P179_MES := NULL;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>86922270904816315
);
wwv_flow_imp.component_end;
end;
/
