prompt --application/pages/page_00182
begin
--   Manifest
--     PAGE: 00182
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>182
,p_name=>unistr('Reporte Verificaci\00F3n Exportaciones Facturas')
,p_step_title=>unistr('Reporte Verificaci\00F3n Exportaciones Facturas')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230825163644Z')
,p_last_updated_on=>wwv_flow_imp.dz('20220914145601Z')
,p_last_updated_by=>'NETBY3'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(86923881133816331)
,p_plug_name=>'Reporte de Verificacion de Facturas y Exportaciones'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295630388916037685)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT mesa.ID, mesa.CODIGOPROVEEDOR, verificadora.CLIENTE,  pedidos.FACTURA, aduana.REFRENDO',
'FROM DATA.T_CMEX_MESATRABAJO mesa, ',
'DATA.T_CMEX_TRAMITESADUANA aduana,',
'DATA.T_CMEX_PEDIDOSEXPORTACIONES pedidos,',
'DATA.T_CMEX_ARCHIVOSVERIFICADORES verificadora',
'WHERE mesa.ID = aduana.ID_CMEX_MESATRABAJO',
'AND mesa.ID = pedidos.ID_CMEX_MESATRABAJO',
'AND REPLACE (verificadora.REFERENDO,''-'') = REPLACE(aduana.REFRENDO, ''-'')',
'AND pedidos.FACTURA = verificadora.FACTURA',
'AND mesa.CODIGOMODULO = ''EXP''',
'AND verificadora.REFERENDO IS NOT NULL;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(86923920729816332)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'NETBY3'
,p_internal_uid=>86923920729816332
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86924097976816333)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86924178414816334)
,p_db_column_name=>'CODIGOPROVEEDOR'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Codigoproveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86924211432816335)
,p_db_column_name=>'CLIENTE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86924381355816336)
,p_db_column_name=>'FACTURA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Factura'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86924414675816337)
,p_db_column_name=>'REFRENDO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Refrendo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(87647096306541041)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'876471'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:CODIGOPROVEEDOR:CLIENTE:FACTURA:REFRENDO'
,p_created_on=>wwv_flow_imp.dz('20230825163644Z')
,p_updated_on=>wwv_flow_imp.dz('20230825163644Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(86924662478816339)
,p_plug_name=>unistr('Barra de navegaci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(86924751828816340)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(86924662478816339)
,p_button_name=>'Regresar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:179:&SESSION.::&DEBUG.:RP,179::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp.component_end;
end;
/
