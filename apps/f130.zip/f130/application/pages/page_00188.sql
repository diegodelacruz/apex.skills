prompt --application/pages/page_00188
begin
--   Manifest
--     PAGE: 00188
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>188
,p_name=>'Descarga de Archivos'
,p_step_title=>'Descarga de Archivos'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20230825163644Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260213195652Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(205128459333583349)
,p_name=>'Archivos'
,p_template=>wwv_flow_imp.id(295630388916037685)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select numeroarchivo',
'	, dbms_lob.getlength(blobcontent) blobcontent',
'	, filename',
'	, observacion',
'	, data.pk_commons.f_googledocview(numeroarchivo,mimetype) enlacearchivo',
'from files.t_apex_archivos',
'where tabla = ''T_CMEX_MESATRABAJO'' and id_tabla = :p188_id_tabla and nvl(estado,1) = 1'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No hay archivos. Verifique el enlace enviado o el usuario responsable no ha cargado los archivos necesarios.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20251003153014Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(205128821501583356)
,p_query_column_id=>1
,p_column_alias=>'NUMEROARCHIVO'
,p_column_display_sequence=>1
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(205129225613583358)
,p_query_column_id=>2
,p_column_alias=>'BLOBCONTENT'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251003153014Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(205129628802583358)
,p_query_column_id=>3
,p_column_alias=>'FILENAME'
,p_column_display_sequence=>3
,p_column_heading=>'Archivo'
,p_use_as_row_header=>'N'
,p_column_link=>'#ENLACEARCHIVO#'
,p_column_linktext=>'#FILENAME#'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20251003153014Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(205131653662583359)
,p_query_column_id=>4
,p_column_alias=>'OBSERVACION'
,p_column_display_sequence=>4
,p_column_heading=>unistr('Observaci\00F3n')
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(193111860302648724)
,p_query_column_id=>5
,p_column_alias=>'ENLACEARCHIVO'
,p_column_display_sequence=>14
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251003153014Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(201059211508262445)
,p_name=>'P188_ID_TABLA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(205128459333583349)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(201059342175262446)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Actualiza'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	-- Borra archivos duplicados',
'	delete from files.t_apex_archivos a',
'	where',
'		rowid >',
'		(',
'			select min(rowid) from files.t_apex_archivos b',
'			where b.tabla = a.tabla',
'			and b.id_tabla = a.id_tabla',
'			and nvl(b.tipo,''XX'') = nvl(a.tipo,''XX'')',
'			and b.filename = a.filename',
'			and b.mimetype = a.mimetype',
'			and nvl(b.estado,''XX'') = nvl(a.estado,''XX'')',
'		)',
'	and a.tabla = ''T_CMEX_MESATRABAJO'' and a.id_tabla = :p188_id_tabla and a.tipo = a.tipo;',
'	',
'	update files.t_apex_archivos x set x.estado = ''1''',
'	where x.tabla = ''T_CMEX_MESATRABAJO'' and x.id_tabla = :p188_id_tabla and x.tipo = x.tipo and nvl(x.estado,''0'') = ''0'';',
'',
'	-- Normaliza los nombres con espacios innesarios.',
'	update files.t_apex_archivos x set x.filename = trim(replace(x.filename,''  '','' ''))',
'	where x.tabla = ''T_CMEX_MESATRABAJO'' and x.id_tabla = :p188_id_tabla and x.tipo = x.tipo and nvl(x.estado,''1'') = ''1'';',
'	commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>201059342175262446
,p_updated_on=>wwv_flow_imp.dz('20260213195652Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
