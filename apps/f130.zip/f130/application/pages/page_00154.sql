prompt --application/pages/page_00154
begin
--   Manifest
--     PAGE: 00154
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>154
,p_name=>'COMEX - Carga Archivos'
,p_page_mode=>'MODAL'
,p_step_title=>'COMEX - Carga Archivos'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function borrar( numeroarchivo ){',
'  apex.item("P154_NUMEROARCHIVO_BORRAR").setValue(numeroarchivo);',
'}     ',
'    ',
'',
''))
,p_step_template=>wwv_flow_imp.id(295596898750037659)
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230708132655Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260409203750Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74061156465884728)
,p_plug_name=>'ARCHIVOS'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P154_ESTADO IS NULL OR :P154_ESTADO = ''A'''
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74061265347884729)
,p_plug_name=>'Listado Archivos'
,p_region_name=>'regListadoArchivos'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUMEROARCHIVO,',
'      dbms_lob.getlength(blobcontent) blobcontent,',
'       FILENAME,',
'       ID_TABLA,',
'        (SELECT DESCRIPCION FROM DATA.T_CORP_UDC WHERE ID_CABECERA = :P154_CABECERA AND VALOR = T.TIPO) TIPO_D,',
'       TIPO,',
'       OBSERVACION,',
'       FECHA,',
'       NOMBREUSUARIO,',
'       NUMEROARCHIVO AS BORRAR',
'  from FILES.T_APEX_ARCHIVOS T',
'  WHERE ESTADO = ''1'' AND TABLA = :P154_TABLA',
'  AND ID_TABLA = :P154_ID_MESATRABAJO',
'  AND TIPO IN (SELECT VALOR FROM DATA.T_CORP_UDC WHERE ID_CABECERA = :P154_CABECERA);'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(74061450076884731)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'No se encontraron archivos'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'NETBY3'
,p_internal_uid=>74061450076884731
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(74239227585161007)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>50
,p_column_identifier=>'B'
,p_column_label=>'Numero Archivo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(74061822743884735)
,p_db_column_name=>'FILENAME'
,p_display_order=>70
,p_column_identifier=>'A'
,p_column_label=>'Nombre Archivo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(74239659914161011)
,p_db_column_name=>'ID_TABLA'
,p_display_order=>100
,p_column_identifier=>'F'
,p_column_label=>'Id Tabla'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(82475692999309041)
,p_db_column_name=>'TIPO_D'
,p_display_order=>110
,p_column_identifier=>'P'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(74239747311161012)
,p_db_column_name=>'TIPO'
,p_display_order=>120
,p_column_identifier=>'G'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(74239873497161013)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>130
,p_column_identifier=>'H'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(74240063406161015)
,p_db_column_name=>'FECHA'
,p_display_order=>140
,p_column_identifier=>'J'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(74240190080161016)
,p_db_column_name=>'NOMBREUSUARIO'
,p_display_order=>150
,p_column_identifier=>'K'
,p_column_label=>'Nombreusuario'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(74240477214161019)
,p_db_column_name=>'BLOBCONTENT'
,p_display_order=>160
,p_column_identifier=>'N'
,p_column_label=>'Descargar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment:<span class="fa fa-download" aria-hidden="true"></span>:FILES'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(74241593124161030)
,p_db_column_name=>'BORRAR'
,p_display_order=>170
,p_column_identifier=>'O'
,p_column_label=>'Accion'
,p_column_link=>'javascript:borrar(#BORRAR#);'
,p_column_linktext=>'<span title="Eliminar" class="fa fa-trash"/>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(74251251686231930)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'742513'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FILENAME:TIPO_D:BLOBCONTENT:OBSERVACION:FECHA:BORRAR:'
,p_created_on=>wwv_flow_imp.dz('20230708132655Z')
,p_updated_on=>wwv_flow_imp.dz('20230708132655Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74241020816161025)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74241406347161029)
,p_plug_name=>'Carga Archivos Etapa 2'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_region_attributes=>'style = "display : none;"'
,p_plug_template=>wwv_flow_imp.id(296122226350169167)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(82474740299309032)
,p_plug_name=>'Parametros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_region_attributes=>'style="display:none;"'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74241100891161026)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(74241020816161025)
,p_button_name=>'CARGAR_ARCHIVO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Cargar Archivo'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74241391511161028)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(74241020816161025)
,p_button_name=>'REGRESAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(82475468759309039)
,p_branch_name=>'Go to page 171'
,p_branch_action=>'f?p=&APP_ID.:171:&SESSION.::&DEBUG.:RP,171:P171_ID:&P154_ID_MESATRABAJO.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(74241391511161028)
,p_branch_sequence=>10
,p_branch_condition_type=>'EXPRESSION'
,p_branch_condition=>':P154_TABLA = ''T_CMEX_MESATRABAJO'''
,p_branch_condition_text=>'PLSQL'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(86017899804573435)
,p_branch_name=>'Go to 178'
,p_branch_action=>'f?p=&APP_ID.:178:&SESSION.::&DEBUG.:RP,178:P178_ID:&P154_ID_MESATRABAJO.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(74241391511161028)
,p_branch_sequence=>20
,p_branch_condition_type=>'EXPRESSION'
,p_branch_condition=>':P154_TABLA = ''T_CMEX_MUESTRASCOURIER_EXP'' AND :P154_CABECERA = ''CMEX_MCEXF'''
,p_branch_condition_text=>'PLSQL'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(82475545378309040)
,p_branch_name=>'Go To Page 154'
,p_branch_action=>'f?p=&APP_ID.:154:&SESSION.::&DEBUG.:RP,154:P154_ID_MESATRABAJO,P154_ETAPA,P154_MODULO,P154_CABECERA,P154_TABLA:&P154_ID_MESATRABAJO.,&P154_ETAPA.,&P154_MODULO.,&P154_CABECERA.,&P154_TABLA.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(74241100891161026)
,p_branch_sequence=>30
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74061302836884730)
,p_name=>'P154_ARCHIVO'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(74061156465884728)
,p_prompt=>'Archivo'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'NATIVE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74240727581161022)
,p_name=>'P154_ID_MESATRABAJO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(82474740299309032)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74240903224161024)
,p_name=>'P154_TIPOARCHIVO'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(74061156465884728)
,p_prompt=>'Tipo archivo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_sql	varchar2(1000);',
'begin',
'	v_sql := ''select ''''Seleccione'''' as d, null as r from dual'';',
'',
'	if :p154_modulo = ''EXP'' and :p154_etapa = ''ET2'' and :p154_cabecera = ''CMEX_FIET2'' then',
'	    v_sql := ''select descripcion||decode(valor2,''''U'''',''''*'''',''''V'''',''''*'''',null) d, valor from data.t_corp_udc where id_cabecera = ''''CMEX_FIET2'''' order by 1''; ',
'	end if;',
'',
'	if :p154_modulo = ''EXP'' and :p154_etapa = ''ET4'' and :p154_cabecera = ''CMEX_FIET4'' then ',
'	    v_sql := ''select descripcion||decode(valor2,''''U'''',''''*'''',''''V'''',''''*'''',null) d, valor from data.t_corp_udc where id_cabecera = ''''CMEX_FIET4'''' order by 1''; ',
'	end if;',
'',
'	if :p154_modulo = ''EXP'' and :p154_cabecera = ''CMEX_MCEXF'' then ',
'	    v_sql := ''select descripcion||decode(valor2,''''U'''',''''*'''',''''V'''',''''*'''',null) d, valor from data.t_corp_udc where id_cabecera = ''''CMEX_MCEXF'''' order by 1''; ',
'	end if;',
'',
'	return v_sql;',
'end;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74241256514161027)
,p_name=>'P154_OBSERVACION'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(74061156465884728)
,p_prompt=>'Observacion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74241607311161031)
,p_name=>'P154_NUMEROARCHIVO_BORRAR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(74061265347884729)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82474882441309033)
,p_name=>'P154_MODULO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(82474740299309032)
,p_prompt=>'Modulo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82474972513309034)
,p_name=>'P154_ETAPA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(82474740299309032)
,p_prompt=>'Etapa'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82475747964309042)
,p_name=>'P154_CABECERA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(82474740299309032)
,p_prompt=>'Cabecera'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83056966020593303)
,p_name=>'P154_PEDIDO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(74061156465884728)
,p_prompt=>'Documento de Pedido'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov_language=>'PLSQL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_sql VARCHAR2(1000);',
'v_tipoDoc VARCHAR2(1);',
'BEGIN',
'',
'v_sql := ''SELECT ''''ERROR'''' AS D, ''''ERROR'''' AS R FROM  DUAL'';',
'    BEGIN',
'            SELECT VALOR2 INTO v_tipoDoc FROM T_CORP_UDC WHERE ID_CABECERA = :P154_CABECERA AND VALOR = :P154_TIPOARCHIVO;',
'    EXCEPTION WHEN NO_DATA_FOUND THEN ',
'            v_tipoDoc := NULL;',
'    END;',
'    IF :P154_MODULO = ''EXP'' AND :P154_ETAPA = ''ET2'' AND :P154_CABECERA = ''CMEX_FIET2'' AND v_tipoDoc = ''V'' THEN',
'         v_sql := ''SELECT FACTURA AS D, FACTURA AS R FROM DATA.T_CMEX_PEDIDOSEXPORTACIONES WHERE ID_CMEX_MESATRABAJO = '' || :P154_ID_MESATRABAJO;    ',
'END IF;',
'',
'RETURN v_sql;',
'',
'END;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_cascade_parent_items=>'P154_TIPOARCHIVO'
,p_ajax_items_to_submit=>'P154_TIPOARCHIVO,P154_MODULO,P154_CABECERA,P154_ID_MESATRABAJO,P154_ETAPA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86017605189573433)
,p_name=>'P154_ESTADO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(82474740299309032)
,p_prompt=>'Estado'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86017708800573434)
,p_name=>'P154_TABLA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(82474740299309032)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Tabla'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(74241980310161034)
,p_name=>'Eliminar'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P154_NUMEROARCHIVO_BORRAR'
,p_condition_element=>'P154_NUMEROARCHIVO_BORRAR'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(74242144247161036)
,p_event_id=>wwv_flow_imp.id(74241980310161034)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEsta seguro de eliminar el documento?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(74242096867161035)
,p_event_id=>wwv_flow_imp.id(74241980310161034)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'data.PK_APEX_ARCHIVOS.SP_ELIMINAARCHIVO (:P154_NUMEROARCHIVO_BORRAR);'
,p_attribute_02=>'P154_NUMEROARCHIVO_BORRAR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(74242204307161037)
,p_event_id=>wwv_flow_imp.id(74241980310161034)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(74061265347884729)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83057017987593304)
,p_name=>'MostrarVinculo'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P154_TIPOARCHIVO'
,p_condition_element=>'P154_TIPOARCHIVO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83057105262593305)
,p_event_id=>wwv_flow_imp.id(83057017987593304)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P154_PEDIDO'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.server.process("VerificaArchivoVinculo",',
'   {pageItems: "#P151_ID,#P154_CABECERA,#P154_TIPOARCHIVO"},',
'    {dataType: "json",',
'    success: function(pData){',
'                console.log(pData);',
'                if (pData.tipo > 0){',
'                    apex.item("P154_PEDIDO").show();',
'                }else {',
'                    apex.item("P154_PEDIDO").setValue('''');',
'                    apex.item("P154_PEDIDO").hide();',
'                }',
'      }',
'   }',
');',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83057392594593307)
,p_event_id=>wwv_flow_imp.id(83057017987593304)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P154_PEDIDO'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(74240603266161021)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SubirArchivos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_valor number;',
'begin',
'    IF :P154_PEDIDO IS NOT NULL THEN ',
'        data.pk_apex_archivos.sp_creararchivo(:P154_ARCHIVO,:P154_TABLA,:P154_ID_MESATRABAJO,:P154_TIPOARCHIVO,''[''|| :P154_PEDIDO ||''] ''|| :P154_OBSERVACION,:app_user,v_valor);',
'        ',
'    ELSE ',
'        data.pk_apex_archivos.sp_creararchivo(:P154_ARCHIVO,:P154_TABLA,:P154_ID_MESATRABAJO,:P154_TIPOARCHIVO,:P154_OBSERVACION,:app_user,v_valor);',
'    END IF;',
'    ',
'    update files.t_apex_archivos set estado = 1 where numeroarchivo = v_valor;',
'end;',
'',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error al subir el archivo'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(74241100891161026)
,p_internal_uid=>74240603266161021
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(82475306171309038)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'LimpiarCamposNecesarios'
,p_attribute_01=>'CLEAR_CACHE_FOR_ITEMS'
,p_attribute_03=>'P154_ARCHIVO,P154_TIPOARCHIVO,P154_OBSERVACION'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(74241100891161026)
,p_internal_uid=>82475306171309038
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(83057212066593306)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'VerificaArchivoVinculo'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_res NUMBER;',
'v_tipoDoc VARCHAR2(1);',
'BEGIN ',
'',
'BEGIN',
'    SELECT VALOR2 INTO v_tipoDoc FROM DATA.T_CORP_UDC WHERE ID_CABECERA = :P154_CABECERA AND VALOR = :P154_TIPOARCHIVO;',
'EXCEPTION WHEN NO_DATA_FOUND THEN',
'    v_tipoDoc := NULL;',
'END;',
'   IF v_tipoDoc = ''V'' THEN',
'       v_res := 1;',
'   ELSE ',
'       v_res := -1;',
'   END IF;',
'   ',
'apex_json.open_object;',
'apex_json.write(''tipo'', v_res);',
'apex_json.close_object;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>83057212066593306
);
wwv_flow_imp.component_end;
end;
/
