prompt --application/pages/page_00206
begin
--   Manifest
--     PAGE: 00206
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>206
,p_name=>'Detalles OC'
,p_alias=>'DETALLES_OC'
,p_step_title=>'Detalles OC'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'document.addEventListener("DOMContentLoaded", function () {',
'	setTimeout(function () {',
'		window.scrollTo(0, 0);',
unistr('	}, 50); // peque\00F1o delay para evitar interferencias del layout'),
'});',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-table td {',
'    padding: 2px;',
'}',
'',
'.a-IRR-toolbar{',
'    background: transparent;',
'}',
'',
'.gestionReserva div{',
'    background: lightyellow;',
'}',
'',
'.a-IRR-table tr td[headers*="colReservaIcono"]{background-color: rgb(255,216,206);}',
'.a-IRR-table tr td[headers*="colReservaPrecio"] {background-color: rgb(255,216,206);}',
'',
'.t-Report-colHead {',
'    padding: 1px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240821214552Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260112212946Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(119159802243955315)
,p_plug_name=>unistr('Gesti\00F3n Apex')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ID, ',
'    COMPANIA, ',
'    USUARIO, ',
'    CODIGOCORTOPRODUCTO, ',
'    UNIDADMEDIDA, ',
'    TIPO_REQUISICION, ',
'',
'    BODEGA, ',
'    BODEGATIPO, ',
'    REQUISITOR,',
'    DESTINO,',
'',
'    CANTIDAD, ',
'    CANTIDAD_MANUAL, ',
'    JUSTIFICACION,',
'    EMAILS, ',
'    FECHA_COMPROMISO, ',
'    GST.DET_ID, ',
'    CODIGOPRODUCTOPROVEEDOR, ',
'    PROVEEDORTIPO, ',
'    PRECIOUNITARIO, ',
'    VERSION, ',
'',
'    LINEA, ',
'    OBSERVACION, ',
'    FECHA_REGISTRO, ',
'    FECHA_REG_NEGOCIACION, ',
'    FECHA_PROCESADO, ',
'    PRECIOUNITARIOEXTERNO, ',
'    MODULOEXTERNO,',
'',
'    RESERVA,',
'    ',
'    CASE',
'        WHEN RESERVA = 1 AND FECHA_REACTIVA_RESERVA IS NULL THEN ''<span title="Compra RESERVA" class="fa fa-check-square" style="color: red;font-weight: bolder;"/>''',
'        WHEN RESERVA = 1 AND FECHA_REACTIVA_RESERVA IS NOT NULL THEN ''<span title="Compra RESERVA" class="fa fa-check-square" style="color: green;font-weight: bolder;"/>''        ',
'        ELSE  '' ''',
'    END   AS ICONO_RESERVAR,',
'',
'    CASE',
'        WHEN CON_REQUISICION=1 THEN ''S''',
'        WHEN CON_REQUISICION=0 THEN ''N''',
'        ELSE TO_CHAR(CON_REQUISICION)',
'    END AS CON_REQUISICION',
'',
'FROM     ',
'    T_COMP_PRODTO_PROVEEDR_GESTION  GST',
'WHERE',
'    DOCUMENTOTIPO_OC = :P206_DOCUMENTOTIPO_OC',
'        AND',
'    DOCUMENTO_OC     = :P206_DOCUMENTO_OC',
';'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Gesti\00F3n APEX')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(119159939405955316)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>119159939405955316
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119160002152955317)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119160159744955318)
,p_db_column_name=>'COMPANIA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119160243464955319)
,p_db_column_name=>'USUARIO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119160304518955320)
,p_db_column_name=>'CODIGOCORTOPRODUCTO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Cod. Corto'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(138446098695834445)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119160407861955321)
,p_db_column_name=>'UNIDADMEDIDA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'UM'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119160554640955322)
,p_db_column_name=>'TIPO_REQUISICION'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'TRQ'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119160642155955323)
,p_db_column_name=>'BODEGA'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119160877888955325)
,p_db_column_name=>'BODEGATIPO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Bod. TP'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(193639559028054003)
,p_db_column_name=>'REQUISITOR'
,p_display_order=>100
,p_column_identifier=>'AD'
,p_column_label=>'Requisitor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(193639642750054004)
,p_db_column_name=>'DESTINO'
,p_display_order=>110
,p_column_identifier=>'AE'
,p_column_label=>'Destino'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119160948413955326)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>120
,p_column_identifier=>'J'
,p_column_label=>'Cant. Sol.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119161009601955327)
,p_db_column_name=>'CANTIDAD_MANUAL'
,p_display_order=>130
,p_column_identifier=>'K'
,p_column_label=>'Cant. Orden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119161192030955328)
,p_db_column_name=>'EMAILS'
,p_display_order=>140
,p_column_identifier=>'L'
,p_column_label=>'Emails'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119161272131955329)
,p_db_column_name=>'FECHA_COMPROMISO'
,p_display_order=>150
,p_column_identifier=>'M'
,p_column_label=>'Fecha Compromiso'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119161303325955330)
,p_db_column_name=>'DET_ID'
,p_display_order=>160
,p_column_identifier=>'N'
,p_column_label=>'Det. Neg ID'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119161489068955331)
,p_db_column_name=>'CODIGOPRODUCTOPROVEEDOR'
,p_display_order=>170
,p_column_identifier=>'O'
,p_column_label=>'Cod. Prod Prov.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119161599105955332)
,p_db_column_name=>'PROVEEDORTIPO'
,p_display_order=>180
,p_column_identifier=>'P'
,p_column_label=>'Prov. TP'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119161667964955333)
,p_db_column_name=>'PRECIOUNITARIO'
,p_display_order=>190
,p_column_identifier=>'Q'
,p_column_label=>'P. Unit.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119161795409955334)
,p_db_column_name=>'VERSION'
,p_display_order=>200
,p_column_identifier=>'R'
,p_column_label=>unistr('Versi\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119161852080955335)
,p_db_column_name=>'LINEA'
,p_display_order=>210
,p_column_identifier=>'S'
,p_column_label=>unistr('L\00EDnea')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119161942499955336)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>220
,p_column_identifier=>'T'
,p_column_label=>unistr('Observaci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119162082501955337)
,p_db_column_name=>'FECHA_REGISTRO'
,p_display_order=>230
,p_column_identifier=>'U'
,p_column_label=>'Fecha Reg.'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119162138941955338)
,p_db_column_name=>'FECHA_REG_NEGOCIACION'
,p_display_order=>240
,p_column_identifier=>'V'
,p_column_label=>'Fecha Reg Neg.'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119162275326955339)
,p_db_column_name=>'FECHA_PROCESADO'
,p_display_order=>250
,p_column_identifier=>'W'
,p_column_label=>'Fecha OC'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy hh24:mi'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119162324394955340)
,p_db_column_name=>'PRECIOUNITARIOEXTERNO'
,p_display_order=>260
,p_column_identifier=>'X'
,p_column_label=>'P. Unit EX'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119162486276955341)
,p_db_column_name=>'MODULOEXTERNO'
,p_display_order=>270
,p_column_identifier=>'Y'
,p_column_label=>'MODEX'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123876233882603906)
,p_db_column_name=>'CON_REQUISICION'
,p_display_order=>280
,p_column_identifier=>'Z'
,p_column_label=>'Req.'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(140143597079242104)
,p_db_column_name=>'JUSTIFICACION'
,p_display_order=>290
,p_column_identifier=>'AA'
,p_column_label=>unistr('Justificaci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(163556108570845805)
,p_db_column_name=>'RESERVA'
,p_display_order=>300
,p_column_identifier=>'AB'
,p_column_label=>'Reserva'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(163556260958845806)
,p_db_column_name=>'ICONO_RESERVAR'
,p_display_order=>310
,p_column_identifier=>'AC'
,p_column_label=>'Rsrv.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(119229112201625709)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1192292'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LINEA:USUARIO:TIPO_REQUISICION:CODIGOCORTOPRODUCTO:PROVEEDORTIPO:BODEGA:PRECIOUNITARIO:CANTIDAD:CANTIDAD_MANUAL:UNIDADMEDIDA:REQUISITOR:DESTINO:FECHA_COMPROMISO:FECHA_PROCESADO:JUSTIFICACION:ICONO_RESERVAR:'
,p_sort_column_1=>'LINEA'
,p_sort_direction_1=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20240821214552Z')
,p_updated_on=>wwv_flow_imp.dz('20240821214552Z')
,p_created_by=>'JASANZA'
,p_updated_by=>'JASANZA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(119162534004955342)
,p_plug_name=>'Detalle'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    LINEA,',
'    CODIGOCORTOPRODUCTO,',
'    CODIGOPRODUCTO||'' - ''||PRODUCTO||'' - ''||DESCRIPCION AS PRODUCTO,',
'    UNIDADMEDIDA,',
'    PROVEEDOR,',
'    CANTIDAD,',
'    CANTIDAD_RECIBIDA, ',
'    PRECIO, ',
'    TOTAL, ',
'    ESTADO_ANT||''-''||ESTADO_SIG AS ESTADO, ',
'    FECHAENTREGAJDE, ',
'    COMPANIA, ',
'',
'    BODEGA,',
'    REQUISITOR,',
'    DESTINO,',
'    CASE WHEN ESTADO_ANT||''-''||ESTADO_SIG = :P206_ESTADO AND :P206_DOCUMENTOTIPO_OC = ''CN'' THEN ',
'            APEX_ITEM.CHECKBOX2(p_idx => 1, p_value => linea , p_attributes  => '''') ',
'        ELSE '''' END    seleccion ',
'FROM ',
'    VT_COMP_F4311',
'WHERE',
'    DOCUMENTOTIPO=:P206_DOCUMENTOTIPO_OC',
'        AND',
'    DOCUMENTO    =:P206_DOCUMENTO_OC',
';'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'JDE F4311'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(119162650606955343)
,p_max_row_count=>'1000000'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>119162650606955343
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119162755613955344)
,p_db_column_name=>'LINEA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>unistr('L\00EDnea')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119162895183955345)
,p_db_column_name=>'CODIGOCORTOPRODUCTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Cod. Corto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119162940612955346)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119163097811955347)
,p_db_column_name=>'UNIDADMEDIDA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'UM'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119163130722955348)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119163241197955349)
,p_db_column_name=>'CANTIDAD_RECIBIDA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Cat.Rec.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119163383588955350)
,p_db_column_name=>'PRECIO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'P. Unit.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119231944589703201)
,p_db_column_name=>'TOTAL'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119232226853703204)
,p_db_column_name=>'FECHAENTREGAJDE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Entrga JDE'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119232344769703205)
,p_db_column_name=>'COMPANIA'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119232464525703206)
,p_db_column_name=>'BODEGA'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119232513432703207)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123878626525603930)
,p_db_column_name=>'ESTADO'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(193639777351054005)
,p_db_column_name=>'REQUISITOR'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Requisitor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(193639833032054006)
,p_db_column_name=>'DESTINO'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Destino'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(292856178501051547)
,p_db_column_name=>'SELECCION'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'-'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(119241394221709837)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1192414'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SELECCION:LINEA:CODIGOCORTOPRODUCTO:PRODUCTO:CANTIDAD:UNIDADMEDIDA:PROVEEDOR:REQUISITOR:DESTINO:PRECIO:TOTAL:BODEGA:ESTADO:'
,p_sum_columns_on_break=>'TOTAL'
,p_created_on=>wwv_flow_imp.dz('20240821214552Z')
,p_updated_on=>wwv_flow_imp.dz('20240821214552Z')
,p_created_by=>'JASANZA'
,p_updated_by=>'JASANZA'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(191806592001883402)
,p_name=>'Comentarios'
,p_parent_plug_id=>wwv_flow_imp.id(119162534004955342)
,p_template=>wwv_flow_imp.id(296121421643169165)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ',
'    W_COMENTARIOS AS (',
'        SELECT',
'            DOCUMENTOTIPO,',
'            DOCUMENTO,',
'            LINEA,',
'        ',
'            PK_COMP_ORDENESCOMPRA.F_COMENTARIO@JDEDTADL(',
'                            p_compania    => :G_COMPANIA,',
'                            p_tipooc      => DOCUMENTOTIPO,',
'                            p_ordencompra => DOCUMENTO,',
'                            p_tipo        => ''P'',',
'                            p_linea       => LINEA',
'                        ) AS COMENTARIO_PROVEEDOR,',
'        ',
'            PK_COMP_ORDENESCOMPRA.F_COMENTARIO@JDEDTADL(',
'                            p_compania    => :G_COMPANIA,',
'                            p_tipooc      => DOCUMENTOTIPO,',
'                            p_ordencompra => DOCUMENTO,',
'                            p_tipo        => ''A'',',
'                            p_linea       => LINEA',
'                        )  AS COMENTARIO_APROBADOR',
'        FROM ',
'            VT_COMP_F4311',
'        WHERE',
'            DOCUMENTOTIPO=:P206_DOCUMENTOTIPO_OC',
'                AND',
'            DOCUMENTO    =:P206_DOCUMENTO_OC',
'    )',
'    SELECT',
'        DOCUMENTOTIPO, DOCUMENTO, LINEA, COMENTARIO_PROVEEDOR, COMENTARIO_APROBADOR',
'    FROM',
'        W_COMENTARIOS',
'    WHERE ',
'        TRIM(COMENTARIO_PROVEEDOR) IS NOT NULL',
'            OR',
'        TRIM(COMENTARIO_APROBADOR) IS NOT NULL',
';'))
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(191806632465883403)
,p_query_column_id=>1
,p_column_alias=>'DOCUMENTOTIPO'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(191806704345883404)
,p_query_column_id=>2
,p_column_alias=>'DOCUMENTO'
,p_column_display_sequence=>20
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(191806834264883405)
,p_query_column_id=>3
,p_column_alias=>'LINEA'
,p_column_display_sequence=>30
,p_column_heading=>unistr('L\00EDnea')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(191806927916883406)
,p_query_column_id=>4
,p_column_alias=>'COMENTARIO_PROVEEDOR'
,p_column_display_sequence=>40
,p_column_heading=>'Comentario Proveedor'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(191807040999883407)
,p_query_column_id=>5
,p_column_alias=>'COMENTARIO_APROBADOR'
,p_column_display_sequence=>50
,p_column_heading=>'Comentario Aprobador'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(123875884337603902)
,p_plug_name=>'Detalles de  &P206_DOCUMENTOTIPO_OC. &P206_DOCUMENTO_OC.'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296122226350169167)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(123875982344603903)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(123877276815603916)
,p_plug_name=>'Archivos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with w_requisiciones as (',
'		select distinct documentotipo, documento',
'		from t_comp_f4311_gestion',
'		where 1 = 1 ',
'			and documentotipo_oc = :p206_documentotipo_oc',
'			and documento_oc = :p206_documento_oc',
') select numeroarchivo id',
'	, numeroarchivo',
'	, filename',
'	-- , dbms_lob.getlength(blobcontent) blobcontent',
'	, mimetype',
'	, fecha',
'	, nombreusuario usuario',
'	, documentotipo  as documentotipo',
'	, to_char(documento) as documento',
'	, documentotipo||''-''||to_char(documento) as docjde',
'	, data.pk_commons.f_googledocview(numeroarchivo,mimetype) enlacearchivo',
'from files.t_apex_archivos,w_requisiciones',
'where 1 = 1',
'	and tabla = ''T_COMP_ORDENES''',
'	and id_tabla = documento',
'	and tipo = documentotipo',
'union all',
'select numeroarchivo id',
'	, numeroarchivo',
'	, filename',
'	-- , dbms_lob.getlength(blobcontent) blobcontent',
'	, mimetype',
'	, fecha',
'	, nombreusuario usuario',
'	, tipo     as documentotipo',
'	, id_tabla as documento',
'	, tipo||'' ''||to_char(id_tabla) as docjde',
'	, data.pk_commons.f_googledocview(numeroarchivo,mimetype) enlacearchivo',
'from files.t_apex_archivos',
'where 1 = 1',
'	and tabla = ''T_COMP_ORDENES''',
'	and id_tabla = :p206_documento_oc',
'	and tipo = :p206_documentotipo_oc'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Archivos'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20250625172215Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(123877309523603917)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>123877309523603917
,p_updated_on=>wwv_flow_imp.dz('20250625172215Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123877462164603918)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123877521704603919)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>unistr('N\00FAmero')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123877604633603920)
,p_db_column_name=>'FILENAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Archivo'
,p_column_link=>'#ENLACEARCHIVO#'
,p_column_linktext=>'#FILENAME#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250625172215Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123877855233603922)
,p_db_column_name=>'MIMETYPE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123877953573603923)
,p_db_column_name=>'FECHA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Fecha'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250625172215Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123878048611603924)
,p_db_column_name=>'USUARIO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123878138339603925)
,p_db_column_name=>'DOCUMENTOTIPO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'DT'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123878276700603926)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'DOC'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123878374690603927)
,p_db_column_name=>'DOCJDE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Doc'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(82754420295302401)
,p_db_column_name=>'ENLACEARCHIVO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Enlacearchivo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250625171617Z')
,p_updated_on=>wwv_flow_imp.dz('20250625171617Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(124192657542387066)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1241927'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FILENAME:FECHA:'
,p_created_on=>wwv_flow_imp.dz('20240821214552Z')
,p_updated_on=>wwv_flow_imp.dz('20250625172131Z')
,p_created_by=>'JASANZA'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(124270087148950530)
,p_plug_name=>'Fechas'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    PLDCTO  AS DOCUMENTOTIPO, ',
'    PLDOCO  AS DOCUMENTO, ',
'    PLLGTY  AS UDC, ',
'    PLKCOO  AS COMPANIA, ',
'    PK_COMMONS.F_JDE2G(PLISSU)',
'            AS FECHA, ',
'    PLDL01  AS  LABEL,',
'',
'    CASE ',
'        WHEN :P206_SUBIR_ANEXOS=1 THEN  ''<span title="Seleccionar Proveedor" class="fa fa-pencil" style="color: black;font-weight: bolder;"/>''',
'        ELSE '' ''',
'    END    AS ICONO_EDITAR',
'',
'FROM F4305@jdedtadl',
'WHERE ',
'    PLDCTO = :P206_DOCUMENTOTIPO_OC',
'        AND',
'    PLDOCO = :P206_DOCUMENTO_OC',
'        AND',
'    PLKCOO = :G_COMPANIA',
'ORDER BY PLLGTY,PLISSU;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Fechas'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20250709210351Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(124270142247950531)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>true
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>124270142247950531
,p_updated_on=>wwv_flow_imp.dz('20250709210351Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124270205928950532)
,p_db_column_name=>'DOCUMENTOTIPO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'TP'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124270329232950533)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124270584800950535)
,p_db_column_name=>'COMPANIA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124270740248950537)
,p_db_column_name=>'LABEL'
,p_display_order=>50
,p_column_identifier=>'F'
,p_column_label=>'Nombre'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250625172831Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124270628114950536)
,p_db_column_name=>'FECHA'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Fecha'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250625172300Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124270814913950538)
,p_db_column_name=>'UDC'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Udc'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(125100869894353301)
,p_db_column_name=>'ICONO_EDITAR'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'-'
,p_column_link=>'f?p=&APP_ID.:207:&SESSION.::&DEBUG.:207:P207_DOCUMENTOTIPO,P207_DOCUMENTO,P207_UDC:#DOCUMENTOTIPO#,#DOCUMENTO#,#UDC#'
,p_column_linktext=>'#ICONO_EDITAR#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250709210351Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(124578081409868219)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1245781'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LABEL:FECHA:ICONO_EDITAR:'
,p_created_on=>wwv_flow_imp.dz('20240821214552Z')
,p_updated_on=>wwv_flow_imp.dz('20240821214552Z')
,p_created_by=>'JASANZA'
,p_updated_by=>'JASANZA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(125101359367353306)
,p_plug_name=>'Head'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'&P206_CABECERA_OC.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(171544478048797804)
,p_plug_name=>'Gestionar reserva'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>60
,p_plug_grid_column_css_classes=>'gestionReserva'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ID, ',
'    LINEA, ',
'    CODIGOCORTOPRODUCTO, ',
'    NVL(CANTIDAD_MANUAL, CANTIDAD) AS CANTIDAD, ',
'    DOCUMENTOTIPO_OC, ',
'    DOCUMENTO_OC, ',
'    RESERVA, ',
'    FECHA_REACTIVA_RESERVA, ',
'    -------------',
'    DET_ID, ',
'    DET_PRECIO,',
'    -------------',
'',
'    NVL(CANTIDAD_MANUAL, CANTIDAD)  * DET_PRECIO AS TOTAL',
'',
'FROM     ',
'    VT_COMP_GESTION_NEGOCIACION  GSTNEG',
'WHERE',
'    DOCUMENTOTIPO_OC = :P206_DOCUMENTOTIPO_OC',
'        AND',
'    DOCUMENTO_OC     = :P206_DOCUMENTO_OC',
';'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P206_DE_RESERVA > 0 AND :P206_RESERVA_REACTIVADA=0'
,p_plug_display_when_cond2=>'PLSQL'
,p_plug_header=>unistr('Esta OC de reserva est\00E1 pendiente. Revise los precios actuales y si est\00E1 conforme env\00EDe a su aprobaci\00F3n.')
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(171544584851797805)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>171544584851797805
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(171544651878797806)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(171545809126797818)
,p_db_column_name=>'DET_ID'
,p_display_order=>20
,p_column_identifier=>'D'
,p_column_label=>'Det. Neg ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(171547240077797832)
,p_db_column_name=>'RESERVA'
,p_display_order=>30
,p_column_identifier=>'F'
,p_column_label=>'Reserva'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(171546377813797823)
,p_db_column_name=>'LINEA'
,p_display_order=>40
,p_column_identifier=>'E'
,p_column_label=>unistr('L\00EDnea')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(171544998550797809)
,p_db_column_name=>'CODIGOCORTOPRODUCTO'
,p_display_order=>60
,p_column_identifier=>'B'
,p_column_label=>'Producto'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(138446098695834445)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(171547769494797837)
,p_db_column_name=>'DET_PRECIO'
,p_display_order=>70
,p_column_identifier=>'J'
,p_column_label=>'P. Unit. Actual'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(181826955945053602)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>80
,p_column_identifier=>'M'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(171547408410797834)
,p_db_column_name=>'DOCUMENTOTIPO_OC'
,p_display_order=>90
,p_column_identifier=>'G'
,p_column_label=>'Documentotipo Oc'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(171547581482797835)
,p_db_column_name=>'DOCUMENTO_OC'
,p_display_order=>100
,p_column_identifier=>'H'
,p_column_label=>'Documento Oc'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(171547670323797836)
,p_db_column_name=>'FECHA_REACTIVA_RESERVA'
,p_display_order=>110
,p_column_identifier=>'I'
,p_column_label=>'Fecha Reactiva Reserva'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(171547942087797839)
,p_db_column_name=>'TOTAL'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(171631805294718764)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1716319'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LINEA:CODIGOCORTOPRODUCTO:DET_PRECIO:TOTAL'
,p_sum_columns_on_break=>'TOTAL'
,p_created_on=>wwv_flow_imp.dz('20240821214552Z')
,p_updated_on=>wwv_flow_imp.dz('20240821214552Z')
,p_created_by=>'JASANZA'
,p_updated_by=>'JASANZA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(123876040618603904)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(123875982344603903)
,p_button_name=>'REGRESAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Regresar'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(123878824054603932)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(123875982344603903)
,p_button_name=>'RECARGAR_ARCHIVOS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Recargar Archivos'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(123876165363603905)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(123875982344603903)
,p_button_name=>'ADJUNTOS'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Adjuntos'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:401:&SESSION.::&DEBUG.::P401_TIPO,P401_ID,P401_TABLA,P401_ESTADO:&P206_DOCUMENTOTIPO_OC.,&P206_DOCUMENTO_OC.,T_COMP_ORDENES,&P206_SUBIR_ANEXOS.'
,p_icon_css_classes=>'fa fa-paperclip'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(123878747886603931)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(123875982344603903)
,p_button_name=>'DUPLICAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Duplicar'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.:::'
,p_confirm_message=>'Esto duplica los productos de esta OC para generar una nueva OC'
,p_icon_css_classes=>'fa-copy'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(82754660522302403)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(123875982344603903)
,p_button_name=>'ANTICIPOS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Anticipos'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:308:&SESSION.::&DEBUG.:308:P308_TIPOORDEN,P308_ORDENCOMPRA,P308_REGRESAR:&P206_DOCUMENTOTIPO_OC.,&P206_DOCUMENTO_OC.,COMP'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''x'' from data.vt_comp_f4311',
'where 1 = 1',
'	and documento = :p206_documento_oc',
'	and documentotipo = :p206_documentotipo_oc',
'	and (',
'		(estado_ant = ''280'' and  estado_sig = ''999'') or',
'		(estado_ant = ''400'' and  estado_sig = ''400'') or',
'		(estado_ant = ''280'' and  estado_sig = ''400'') or ',
'		(estado_ant = ''400'' and  estado_sig = ''999''))'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-hand-coins'
,p_created_on=>wwv_flow_imp.dz('20250625173345Z')
,p_updated_on=>wwv_flow_imp.dz('20260112212946Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(171548003253797840)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(171544478048797804)
,p_button_name=>'REACTIVAR_RESERVA'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>unistr('Actualizar precios y enviar a aprobaci\00F3n')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P206_F4311_ESTADO'
,p_button_condition2=>'280-400'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(292856396114051549)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(119162534004955342)
,p_button_name=>'CANCELAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>unistr('Cancelar Selecci\00F3n')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT 1',
'FROM VT_COMP_F4311',
'WHERE DOCUMENTOTIPO =:P206_DOCUMENTOTIPO_OC',
'    AND DOCUMENTO =:P206_DOCUMENTO_OC',
'    AND ESTADO_ANT||''-''||ESTADO_SIG = :P206_ESTADO ',
'    AND DOCUMENTOTIPO = ''CN'';'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-clipboard fam-x fam-is-danger'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(125101466608353307)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(124270087148950530)
,p_button_name=>'Add'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Add'
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_redirect_url=>'f?p=&APP_ID.:208:&SESSION.::&DEBUG.:208:P208_DOCUMENTOTIPO,P208_DOCUMENTO:&P206_DOCUMENTOTIPO_OC.,&P206_DOCUMENTO_OC.'
,p_icon_css_classes=>'fa-calendar-plus-o'
,p_updated_on=>wwv_flow_imp.dz('20250625170824Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(123880503710603949)
,p_branch_action=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(123878747886603931)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(119159653969955313)
,p_name=>'P206_DOCUMENTOTIPO_OC'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(125101359367353306)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(119159751421955314)
,p_name=>'P206_DOCUMENTO_OC'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(125101359367353306)
,p_prompt=>'Doc.'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(123877068212603914)
,p_name=>'P206_SUBIR_ANEXOS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(123875884337603902)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(165410884743441903)
,p_name=>'P206_DE_RESERVA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(123875884337603902)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(169025058299309311)
,p_name=>'P206_RESERVA_REACTIVADA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(123875884337603902)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171544377510797803)
,p_name=>'P206_F4301_VALOR'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(125101359367353306)
,p_prompt=>'Valor'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(173241410143721303)
,p_name=>'P206_F4311_ESTADO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(125101359367353306)
,p_prompt=>'Estado'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(190516445855868244)
,p_name=>'P206_CABECERA_OC'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(123875884337603902)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(300494078990195405)
,p_name=>'P206_ESTADO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(123875884337603902)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(300494191993195406)
,p_name=>'P206_MENSAJE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(125101359367353306)
,p_display_as=>'NATIVE_HIDDEN'
,p_display_when=>'P206_MENSAJE'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(124267196380950501)
,p_name=>'Duplicar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(123878747886603931)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(124267263166950502)
,p_event_id=>wwv_flow_imp.id(124267196380950501)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'SP_DUPLICA_GESTION_OC'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_COMP_GESTIONCOMPRAS.SP_DUPLICA_GESTION_OC(',
'    :P206_DOCUMENTOTIPO_OC,',
'    :P206_DOCUMENTO_OC,',
'    :APP_USER,',
'    :G_COMPANIA',
');'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(125101185327353304)
,p_name=>unistr('Regresar Di\00E1logo Fecha')
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(124270087148950530)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(125101286832353305)
,p_event_id=>wwv_flow_imp.id(125101185327353304)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(125101513292353308)
,p_name=>'Dialog return'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(125101466608353307)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(125101621427353309)
,p_event_id=>wwv_flow_imp.id(125101513292353308)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(171548124799797841)
,p_name=>'Reactivar Reserva'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(171548003253797840)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(171548269166797842)
,p_event_id=>wwv_flow_imp.id(171548124799797841)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Confirma'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Actualizar precios y enviar a aprobaci\00F3n ?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(171548336356797843)
,p_event_id=>wwv_flow_imp.id(171548124799797841)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'PK_COMP_GESTIONCOMPRAS.SP_REACTIVA_RESERVA(:P206_DOCUMENTOTIPO_OC, :P206_DOCUMENTO_OC);'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(171548411143797844)
,p_event_id=>wwv_flow_imp.id(171548124799797841)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(292856439144051550)
,p_name=>'Cancela'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(292856396114051549)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(300493624369195401)
,p_event_id=>wwv_flow_imp.id(292856439144051550)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEst\00E1 seguro de cancelar las l\00EDneas seleccionadas?')
,p_attribute_02=>unistr('Confirmaci\00F3n')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(300493755902195402)
,p_event_id=>wwv_flow_imp.id(292856439144051550)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(300493893633195403)
,p_event_id=>wwv_flow_imp.id(292856439144051550)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'CANCELAR'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(292856067365051546)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CANCELAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    v_linea varchar2(3000) ;',
'    v_NUMEROORDEN NUMBER;',
'    v_TIPOORDEN VARCHAR2(200);',
'    v_MENSAJE VARCHAR2(200);',
'begin ',
'    APEX_DEBUG.ENABLE(apex_debug.c_log_level_info);',
'',
'    IF APEX_APPLICATION.G_F01.COUNT = 0 THEN',
'        RAISE_APPLICATION_ERROR(-20000, ''Seleccione al menos una linea de la OC para cancelar.'');',
'    END IF;',
'    FOR i IN 1..APEX_APPLICATION.G_F01.COUNT LOOP ',
'        if ( i = 1 ) then',
'            v_linea := trim(APEX_APPLICATION.G_F01(i));',
'        else',
'            v_linea := v_linea||'',''||trim(APEX_APPLICATION.G_F01(i)) ;',
'        end if;    ',
'    END LOOP;',
'    PK_COMP_ORDENESCOMPRA.SP_CANCELAROCLINEA(',
'            P_NUMERO => :P206_DOCUMENTO_OC ,',
'            P_TIPO => :P206_DOCUMENTOTIPO_OC,',
'            P_COMPANIA => :G_COMPANIA,',
'            P_LINEAS => v_linea, -- si linea es null cancela a toda las lineas de la orden que esten pendientes',
'            P_NUMEROORDEN => v_NUMEROORDEN, --SI ES EXITOSO TE DEVUELVE EL MISMO NUMERO DE ORDEN ANULADA',
'            P_TIPOORDEN => v_TIPOORDEN, -- SI ES EXITOSO TE DEVUELVE EL MISMO TIPO ORDEN ANULADA',
'            P_MENSAJE => v_MENSAJE',
'          );',
'          ',
'    :P206_MENSAJE := v_NUMEROORDEN ||'' - ''|| v_TIPOORDEN ||'' - ''||v_MENSAJE;        ',
'end;    ',
'     '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(292856396114051549)
,p_internal_uid=>292856067365051546
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(171544221297797802)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cabecera'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    TO_CHAR(VALOR, ''FML999G999G999G999G990D00'')',
'INTO',
'    :P206_F4301_VALOR',
'FROM VT_COMP_F4301',
'WHERE',
'    documentotipo = :P206_DOCUMENTOTIPO_OC',
'    AND',
'    documento = :P206_DOCUMENTO_OC',
';    ',
'',
'SELECT ',
'    MAX(ESTADO_ANT||''-''||ESTADO_SIG)',
'INTO',
'    :P206_F4311_ESTADO',
'FROM VT_COMP_F4311',
'WHERE',
'    documentotipo = :P206_DOCUMENTOTIPO_OC',
'    AND',
'    documento = :P206_DOCUMENTO_OC',
';',
'',
'',
':P206_CABECERA_OC := PK_COMP_ORDENESCOMPRA.F_COMENTARIO@JDEDTADL(',
'                p_compania    => :G_COMPANIA,',
'                p_tipooc      => :P206_DOCUMENTOTIPO_OC,',
'                p_ordencompra => :P206_DOCUMENTO_OC',
'            );',
'',
':P206_ESTADO := ''400-400'' ;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>171544221297797802
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(165410793709441902)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'De reserva'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P206_RESERVA_REACTIVADA := 0;',
'',
'SELECT',
'    COUNT(1) INTO :P206_DE_RESERVA',
'FROM     ',
'    T_COMP_PRODTO_PROVEEDR_GESTION',
'WHERE',
'    DOCUMENTOTIPO_OC = :P206_DOCUMENTOTIPO_OC',
'        AND',
'    DOCUMENTO_OC     = :P206_DOCUMENTO_OC',
'        AND',
'    RESERVA = 1',
';',
'',
'SELECT',
'    COUNT(1) INTO :P206_RESERVA_REACTIVADA',
'FROM     ',
'    T_COMP_PRODTO_PROVEEDR_GESTION',
'WHERE',
'    DOCUMENTOTIPO_OC = :P206_DOCUMENTOTIPO_OC',
'        AND',
'    DOCUMENTO_OC     = :P206_DOCUMENTO_OC',
'        AND',
'    FECHA_REACTIVA_RESERVA IS NOT NULL',
';'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>165410793709441902
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(123877118591603915)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Permisos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P206_SUBIR_ANEXOS := PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES (',
'      P_CODIGOMODULO => :APP_MODULO ',
'    , P_CODIGOUSUARIO => :APP_USER',
'    , P_RUTAPAGINA => 201',
'    , P_CODIGOACCION => ''SUBIR_ANEXOS'');'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>123877118591603915
);
wwv_flow_imp.component_end;
end;
/
