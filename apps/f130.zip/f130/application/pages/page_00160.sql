prompt --application/pages/page_00160
begin
--   Manifest
--     PAGE: 00160
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>160
,p_name=>'COMEX - Part. Arancelaria'
,p_step_title=>'COMEX - Part. Arancelaria'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230708132656Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260409204306Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(75899842935799023)
,p_plug_name=>'Partidas Arancelarias'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296122226350169167)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(75899958212799024)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(76030096444444915)
,p_plug_name=>'Partidas Arancelarias'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels:margin-top-none'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "ID", ',
'"PARTIDA",',
'"DESCRIPCION",',
'"FECHAAPLICACION",',
'"RESOLUCIONNUMERO",',
'"CREDITOTRIBUTARIO",',
'"VIGENCIAINICIO",',
'"VIGENCIAFIN",',
'"PORCENTAJEISD"',
'from "#OWNER#"."T_CMEX_PARTIDAARANCELARIA" ',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(76030456842444915)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No se encontraron datos.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:161:&APP_SESSION.::::P161_ID:#ID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-page.png" class="apex-edit-page" alt="">'
,p_owner=>'NETBY3'
,p_internal_uid=>76030456842444915
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(76030562985444917)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(76030980835444919)
,p_db_column_name=>'PARTIDA'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Partida'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(76031326300444919)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(76031702471444920)
,p_db_column_name=>'FECHAAPLICACION'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>unistr('Fecha Aplicaci\00F3n')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(76032140746444920)
,p_db_column_name=>'RESOLUCIONNUMERO'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>unistr('Nro. Resoluci\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(76032554472444922)
,p_db_column_name=>'CREDITOTRIBUTARIO'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>unistr('Cr\00E9dito Tributario')
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(76048126086578034)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(76032935961444922)
,p_db_column_name=>'VIGENCIAINICIO'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Inicio'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(76033349219444923)
,p_db_column_name=>'VIGENCIAFIN'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Fin'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(76574141809781345)
,p_db_column_name=>'PORCENTAJEISD'
,p_display_order=>18
,p_column_identifier=>'I'
,p_column_label=>'% ISD'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(76034439341465584)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'760345'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PARTIDA:FECHAAPLICACION:RESOLUCIONNUMERO:CREDITOTRIBUTARIO:VIGENCIAINICIO:VIGENCIAFIN:PORCENTAJEISD:'
,p_created_on=>wwv_flow_imp.dz('20230708132656Z')
,p_updated_on=>wwv_flow_imp.dz('20230708132656Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(75900336938799028)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(75899958212799024)
,p_button_name=>'DESCARGAR'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Descargar Formato'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'#APP_IMAGES#Formatos/FORMATO_PARTIDASARANCELARIASCREDITOSTRIBUTARIOS.xlsx'
,p_icon_css_classes=>'fa-file-arrow-down'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(75900229277799027)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(75899958212799024)
,p_button_name=>'CARGARMASIVA'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Carga Masiva'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:300:&SESSION.::&DEBUG.:RP,300:G_MODULO,G_PAGINA:&APP_ID.,160'
,p_icon_css_classes=>'fa-upload'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(76033703055444923)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(75899958212799024)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Nuevo'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:161:&SESSION.::&DEBUG.:161'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(75901073524799035)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_element=>'window'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'window'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75901336522799038)
,p_event_id=>wwv_flow_imp.id(75901073524799035)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'window'
,p_attribute_01=>'alert(''asdwda'');'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(75900875234799033)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CargarDatos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_num NUMBER;',
'v_id NUMBER;',
'BEGIN',
'SELECT COUNT(*) INTO  v_num FROM DATA.VT_APEX_EXCEL;',
'',
'IF  v_num > 0 THEN',
'',
'    INSERT INTO DATA.T_CMEX_PARTIDAARANCELARIA (PARTIDA, DESCRIPCION, FECHAAPLICACION, RESOLUCIONNUMERO, CREDITOTRIBUTARIO, VIGENCIAINICIO, VIGENCIAFIN, PORCENTAJEISD)',
'    SELECT C02, C03, to_date(''1899-12-30'', ''YYYY-MM-DD'') + TO_NUMBER(C04), C05, C06,  to_date(''1899-12-30'', ''YYYY-MM-DD'') + TO_NUMBER(C07), to_date(''1899-12-30'', ''YYYY-MM-DD'') + TO_NUMBER(C08), TO_NUMBER(REPLACE(C09,''.'','','')) FROM VT_APEX_EXCEL;',
'   -- WHERE ( C02, C03, to_date(''1899-12-30'', ''YYYY-MM-DD'') + TO_NUMBER(C04), C05, C06,  to_date(''1899-12-30'', ''YYYY-MM-DD'') + TO_NUMBER(C07), to_date(''1899-12-30'', ''YYYY-MM-DD'') + TO_NUMBER(C08), TO_NUMBER(C09)) NOT IN ',
'     --     (SELECT PARTIDA, DESCRIPCION, FECHAAPLICACION, RESOLUCIONNUMERO, CREDITOTRIBUTARIO, VIGENCIAINICIO, VIGENCIAFIN, PORCENTAJEISD FROM T_CMEX_PARTIDAARANCELARIA);',
'          ',
'      SELECT ID into v_id FROM APEX_180200.wwv_flow_collections$ c WHERE c.collection_name=''TABLA_EXCEL'' AND SESSION_ID = :APP_SESSION;',
'       DELETE FROM APEX_180200.wwv_flow_collection_members$ m WHERE m.collection_id = v_id;',
'       DELETE FROM APEX_180200.wwv_flow_collections$ c WHERE c.collection_name=''TABLA_EXCEL'' AND ID = v_id ;',
'END IF;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>75900875234799033
);
wwv_flow_imp.component_end;
end;
/
