prompt --application/pages/page_00144
begin
--   Manifest
--     PAGE: 00144
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>144
,p_name=>unistr('Negociaci\00F3n - F\00F3rmulas')
,p_step_title=>unistr('Negociaci\00F3n - F\00F3rmulas')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(secItems).hide();',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-button.a-IRR-sortWidget-button[data-option="hide"], .a-IRR-button.a-IRR-sortWidget-button[data-option="freeze"]{',
'    display:none;',
'}',
'.a-IG-controls-item--aggregate, .a-IG-controls-item--controlBreak, .a-IG-controls-item--groupBy, .a-IG-reportSummary-item--aggregate, .a-IG-reportSummary-item--controlBreak, .a-IG-reportSummary-item--groupBy, .a-IRR-controls-item--aggregate, .a-IRR-c'
||'ontrols-item--controlBreak, .a-IRR-controls-item--groupBy, .a-IRR-reportSummary-item--aggregate, .a-IRR-reportSummary-item--controlBreak, .a-IRR-reportSummary-item--groupBy {',
'    --a-report-controls-cell-label-icon-background-color: #3b83bd;',
'    --a-report-controls-cell-label-hover-background-color: #e6f0f7;',
'    display: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'17'
,p_created_on=>wwv_flow_imp.dz('20231206173429Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260409202800Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43435985008543038)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(140080415255614949)
,p_plug_name=>'formula'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43435836095543037)
,p_name=>'P144_USUARIO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(140080415255614949)
,p_prompt=>'Usuario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140080539057614950)
,p_name=>'P144_FORMULA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(140080415255614949)
,p_prompt=>'Formula'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140325919789969801)
,p_name=>'P144_NEG_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(140080415255614949)
,p_prompt=>'Neg Id'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140326009567969802)
,p_name=>'P144_CAB_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(140080415255614949)
,p_prompt=>'Cab Id'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp.component_end;
end;
/
