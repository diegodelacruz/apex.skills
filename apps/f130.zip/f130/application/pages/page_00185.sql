prompt --application/pages/page_00185
begin
--   Manifest
--     PAGE: 00185
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>185
,p_name=>unistr('Etapas Importaci\00F3n')
,p_step_title=>unistr('Etapas Importaci\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230825163644Z')
,p_last_updated_on=>wwv_flow_imp.dz('20221129153639Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(100227328188408438)
,p_plug_name=>unistr('Etapas Importaci\00F3n')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.id',
'	, a.codigoetapa||'' - ''||c.descripcion etapa',
'	, a.tipooc||'' - ''||a.ordencompra ordencompra',
'	, a.codigoproveedor codproveedor',
'	, b.descripcion proveedor',
'	, nvl(a.cnt20pies,0) cnt20pies',
'	, nvl(a.cnt40pies,0) cnt40pies',
'	, a.cargaliberada',
'	, a.fechacas',
'	, a.fechadav',
'	, a.fechaeta',
'	, a.fechaetd',
'	, a.fechacargaliberada fechalib',
'	, decode(a.codigoetapa,''ET9'',null,extract(day from(sysdate - a.fechmodi))) diasetapa',
'from data.t_cmex_mesatrabajo a',
'inner join vt_jde_maestroproveedor b on a.codigoproveedor = b.codigoproveedor',
'inner join t_corp_udc c on a.codigoetapa = c.valor and c.id_cabecera = ''CMEX_ET_IM''',
'where a.codigomodulo = ''IMP'' and a.ordencompra is not null;'))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(100227462217408438)
,p_name=>unistr('Etapas Importaci\00F3n')
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>100227462217408438
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100227879270408449)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100228228529408450)
,p_db_column_name=>'ETAPA'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Etapa'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100228691548408450)
,p_db_column_name=>'ORDENCOMPRA'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100229011667408450)
,p_db_column_name=>'CODPROVEEDOR'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>unistr('C\00F3d. Proveedor')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100229428570408450)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100229884720408453)
,p_db_column_name=>'CNT20PIES'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'CNT 20'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100230263699408453)
,p_db_column_name=>'CNT40PIES'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'CNT 40'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100230667383408453)
,p_db_column_name=>'CARGALIBERADA'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Carga liberada'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100231092225408455)
,p_db_column_name=>'FECHACAS'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Fecha CAS'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100231411662408455)
,p_db_column_name=>'FECHADAV'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Fecha DAV'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100231822810408455)
,p_db_column_name=>'FECHAETA'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Fecha ETA'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100232287263408455)
,p_db_column_name=>'FECHAETD'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Fecha ETD'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100232625186408460)
,p_db_column_name=>'FECHALIB'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Fecha Lib.'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100233029174408460)
,p_db_column_name=>'DIASETAPA'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>unistr('D\00EDas etapa')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(100233493720410628)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1002335'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ETAPA:ORDENCOMPRA:CODPROVEEDOR:PROVEEDOR:CNT20PIES:CNT40PIES:CARGALIBERADA:FECHACAS:FECHADAV:FECHAETA:FECHAETD:FECHALIB:DIASETAPA:'
,p_sort_column_1=>'ID'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20230825163644Z')
,p_updated_on=>wwv_flow_imp.dz('20230825163644Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
