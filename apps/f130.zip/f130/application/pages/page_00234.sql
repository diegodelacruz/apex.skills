prompt --application/pages/page_00234
begin
--   Manifest
--     PAGE: 00234
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>234
,p_name=>unistr('Detalle Aprobaci\00F3n')
,p_alias=>unistr('DETALLE-APROBACI\00D3N')
,p_step_title=>unistr('Detalle Aprobaci\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_created_on=>wwv_flow_imp.dz('20240410162859Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240611171106Z')
,p_last_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(165433297186288045)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(170970993511253576)
,p_plug_name=>unistr('Detalle Importaci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296122226350169167)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(171014405894642849)
,p_plug_name=>'DETALLE'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(171062982786714405)
,p_plug_name=>'Botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121809343169165)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P234_APROBADOR=:APP_USER OR :APP_USER=''MALBAN'''
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20240611171106Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(171063047137714406)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(171062982786714405)
,p_button_name=>'Aprobar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Aprobar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:102:&SESSION.::&DEBUG.::G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID:&G_COMPANIA.,CMEX,&APP_USER.,IMPORTACION_MUESTRAS,&P234_ID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(171063152781714407)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(171062982786714405)
,p_button_name=>'Rechazar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Rechazar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:103:&SESSION.::&DEBUG.::G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO:&G_COMPANIA.,CMEX,&APP_USER.,IMPORTACION_MUESTRAS,&P234_ID.,&P234_APROBADOR.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(187246469576684713)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(165433297186288045)
,p_button_name=>'COMENTARIO'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Comentario'
,p_button_redirect_url=>'f?p=100:105:&SESSION.::&DEBUG.::G_OBJETO_ID,G_OBJETO,G_ETAPA,G_COMPANIA,G_MODULO:&P234_ID.,IMPORTACION_MUESTRAS,BORRADOR,&G_COMPANIA.,CMEX'
,p_icon_css_classes=>'fa-comments-o'
,p_updated_on=>wwv_flow_imp.dz('20240425141635Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(165433665544288049)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(165433297186288045)
,p_button_name=>'Retornar'
,p_button_static_id=>'btnAtras'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Retornar'
,p_button_redirect_url=>'f?p=&APP_ID.:176:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-box-arrow-out-north'
,p_updated_on=>wwv_flow_imp.dz('20240424212122Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(171064094872714416)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(171014405894642849)
,p_button_name=>'Adjuntos'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>unistr('Ver Documentos de Importaci\00F3n')
,p_button_redirect_url=>'f?p=100:401:&SESSION.::&DEBUG.::P401_TABLA,P401_ID,P401_ESTADO,P401_REGIMEN:T_CMEX_MUESTRAS,&P234_ID.,0,&P234_REGIMEN.'
,p_grid_new_row=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240426141032Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(275144725237581327)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(171014405894642849)
,p_button_name=>'Detalle'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>unistr('Ver Detalle de Importaci\00F3n')
,p_button_redirect_url=>'f?p=&APP_ID.:250:&SESSION.::&DEBUG.::P250_ID:&P234_ID.'
,p_grid_new_row=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240424195956Z')
,p_updated_on=>wwv_flow_imp.dz('20240424204331Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(165433353659288046)
,p_name=>'P234_IDPROCESO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(171014405894642849)
,p_prompt=>'Registro:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(165433528104288048)
,p_name=>'P234_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171014158097642846)
,p_name=>'P234_USUARIOCREA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(171014405894642849)
,p_prompt=>'Ingresado por: '
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171014231043642847)
,p_name=>'P234_PROVEEDOR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(171014405894642849)
,p_prompt=>'Proveedor'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_CMEX_PROVEEDORES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CODIGOJDE ||'' - ''||RAZONSOCIAL D, CODIGOJDE R',
'FROM VT_COMP_JDEPROVEEDOR',
'UNION',
'SELECT CAST(''99999 - OTROS'' AS NCHAR(40)) D, 99999 R',
'FROM DUAL;      '))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240611150718Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171014518750642850)
,p_name=>'P234_CENTRODECOSTO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(171014405894642849)
,p_prompt=>'Cargado a Centro de Costos: '
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_CMEX_CENTROCOSTOS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT (ID_TABLA)||'' ''||DESCRIPCION D, (ID_TABLA) R',
'FROM T_CORP_UDC',
'WHERE id_cabecera=''NSEF_CCOST''',
'AND ACTIVO=1 AND VALOR2 IS NOT NULL',
'ORDER BY 2',
';'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240424195312Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171062513590714401)
,p_name=>'P234_GENERAPAGO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(171014405894642849)
,p_prompt=>'Genera Pago al Exterior: '
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_SINO'
,p_lov=>'.'||wwv_flow_imp.id(78141453854944977)||'.'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171062648862714402)
,p_name=>'P234_FLETECOTIZADO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(171014405894642849)
,p_prompt=>'Flete Internacional Cotizado:'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171062721366714403)
,p_name=>'P234_GASTOSLOCAL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(171014405894642849)
,p_prompt=>'Gastos Locales Cotizados: '
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171062808955714404)
,p_name=>'P234_LEYENDA'
,p_item_sequence=>35
,p_item_plug_id=>wwv_flow_imp.id(171014405894642849)
,p_source=>unistr('* Todos los valores que se incurran en la importaci\00F3n ser\00E1n cargados al centro de costos')
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_column=>5
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171063249968714408)
,p_name=>'P234_TERMINA_FLUJO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(171062982786714405)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171064490618714420)
,p_name=>'P234_APROBADOR'
,p_item_sequence=>25
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(275146725218581347)
,p_name=>'P234_REGIMEN'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(171014405894642849)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
,p_created_on=>wwv_flow_imp.dz('20240426141031Z')
,p_updated_on=>wwv_flow_imp.dz('20240426141031Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(316594320971598827)
,p_name=>'P234_NUEVOPROVEEDOR'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(171014405894642849)
,p_prompt=>'Nuevo Proveedor:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P234_PROVEEDOR'
,p_display_when2=>'99999'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240611170833Z')
,p_updated_on=>wwv_flow_imp.dz('20240611170849Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(171063326041714409)
,p_name=>unistr('Cierre di\00E1logo: aprobar')
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(171063047137714406)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(171063431719714410)
,p_event_id=>wwv_flow_imp.id(171063326041714409)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'apex.item( "P234_TERMINA_FLUJO" ).setValue(0);',
'',
'if(this.data.G_EXITO==''true''){',
'    mensaje(''exito'', this.data.G_MENSAJE);',
'    if(isTerminoFlujo){',
'        apex.item( "P234_TERMINA_FLUJO" ).setValue(1);',
'    }',
'    else{',
'    $(''#btnAtras'').trigger("click");',
'    }',
'}',
'else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(171063521508714411)
,p_name=>unistr('Cierre di\00E1logo: aprobar exito')
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(171063047137714406)
,p_condition_element=>'P234_TERMINA_FLUJO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(171063759040714413)
,p_event_id=>wwv_flow_imp.id(171063521508714411)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(171063673391714412)
,p_event_id=>wwv_flow_imp.id(171063521508714411)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  V_INCOTERM VARCHAR2(10);',
'  V_TIPOMATERIAL VARCHAR2(12);',
'  V_IDMESATRABABAJO NUMBER :=0;',
'',
'BEGIN',
'-- OBTENGO tipo de material',
'BEGIN',
'   SELECT TIPOMUESTRA INTO V_TIPOMATERIAL',
'   FROM T_CMEX_MUESTRASDET',
'   WHERE IDCABECERA=:P234_ID AND ROWNUM=1;',
'  EXCEPTION WHEN NO_DATA_FOUND THEN V_TIPOMATERIAL:='''';',
'END;',
'',
'-- OBTENGO INCOTERM',
'BEGIN',
'   SELECT ICOTERM INTO V_INCOTERM',
'   FROM T_CMEX_MUESTRAS',
'   WHERE ID=:P234_ID;',
'  EXCEPTION WHEN NO_DATA_FOUND THEN V_INCOTERM:='''';',
'',
'END;',
'-- cambio el estado a 2',
'UPDATE T_CMEX_MUESTRAS SET ESTADO=2, ETAPA=''ET1''',
'WHERE ID=:P234_ID;',
unistr('-- s\00F3lo para pruebas obtengo el m\00E1ximo secuencial + 1 de la tabla T_CMEX_MESATRABAJO'),
'-- inserto en la tabla t_cmex_mesatrabajo',
'INSERT INTO T_CMEX_MESATRABAJO (ID,CODIGOMODULO,CODIGOETAPA,CODIGOPROVEEDOR,NUMFACTURA,PAISORIGEN,USERCREA,FECHCREA,INCOTERM,FORWARDER,',
'                                 ID_MUESTRA,REGIMENMUESTRA)',
'SELECT (SELECT MAX(ID)+1 FROM T_CMEX_MESATRABAJO),',
' ''IMP'',''ET1'',CODIGOPROVEEDOR,NUMEROFACTURA,PAISORIGEN,USERCREA,FECHACREA,ICOTERM,FORWARDER,:P234_ID,REGIMEN',
'FROM T_CMEX_MUESTRAS',
'WHERE ID=:P234_ID;',
'',
'SELECT ID INTO V_IDMESATRABABAJO',
'FROM T_CMEX_MESATRABAJO',
'WHERE ID_MUESTRA=:P234_ID;',
'',
'-- inserto en la tabla t_cmex_datoscomplementarios',
'--pk_cmex_mesatrabajo.sp_datos_complementarios(:P234_ID,V_INCOTERM,null,V_TIPOMATERIAL,null);',
'pk_cmex_mesatrabajo.sp_datos_complementarios(V_IDMESATRABABAJO,V_INCOTERM,null,V_TIPOMATERIAL,null);',
'END;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(171063849116714414)
,p_event_id=>wwv_flow_imp.id(171063521508714411)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ocultarBarra();',
'$(''#btnAtras'').trigger("click");'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(171064179406714417)
,p_name=>unistr('Cierre di\00E1logo: rechazar')
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(171063152781714407)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(171064233413714418)
,p_event_id=>wwv_flow_imp.id(171064179406714417)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- cambio el estado a 0',
'UPDATE T_CMEX_MUESTRAS SET ESTADO=0',
'WHERE ID=:P234_ID;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(171064302881714419)
,p_event_id=>wwv_flow_imp.id(171064179406714417)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>' $(''#btnAtras'').trigger("click");'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(171014399455642848)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'DATOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    SELECT USERCREA,CODIGOPROVEEDOR,CENTRODECOSTO,PAGOEXTERIOR,FLETECOTIZADO,GASTOSLOCALCOTIZADO,REGIMEN,NUEVOPROVEEDOR',
'    INTO :P234_USUARIOCREA,:P234_PROVEEDOR,:P234_CENTRODECOSTO,:P234_GENERAPAGO,:P234_FLETECOTIZADO,:P234_GASTOSLOCAL,:P234_REGIMEN,',
'         :P234_NUEVOPROVEEDOR',
'    FROM T_CMEX_MUESTRAS',
'    WHERE ID=:P234_ID;',
'  EXCEPTION WHEN NO_DATA_FOUND THEN NULL;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>171014399455642848
,p_updated_on=>wwv_flow_imp.dz('20240611170833Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp.component_end;
end;
/
