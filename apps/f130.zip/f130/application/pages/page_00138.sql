prompt --application/pages/page_00138
begin
--   Manifest
--     PAGE: 00138
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>138
,p_name=>unistr('Negociaci\00F3n - Aprobaci\00F3n')
,p_step_title=>'Negociacion - Aprobacion Individual'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(secItems).hide();',
'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-button.a-IRR-sortWidget-button[data-option="hide"], .a-IRR-button.a-IRR-sortWidget-button[data-option="freeze"]{',
'    display:none;',
'}',
'.a-IG-controls-item--aggregate, .a-IG-controls-item--controlBreak, .a-IG-controls-item--groupBy, .a-IG-reportSummary-item--aggregate, .a-IG-reportSummary-item--controlBreak, .a-IG-reportSummary-item--groupBy, .a-IRR-controls-item--aggregate, .a-IRR-c'
||'ontrols-item--controlBreak, .a-IRR-controls-item--groupBy, .a-IRR-reportSummary-item--aggregate, .a-IRR-reportSummary-item--controlBreak, .a-IRR-reportSummary-item--groupBy {',
'    --a-report-controls-cell-label-icon-background-color: #3b83bd;',
'    --a-report-controls-cell-label-hover-background-color: #e6f0f7;',
'    display: block;',
'}',
'#Detalle_control_panel{',
'    display:block;',
'}',
'',
'.a-IRR-chartView, .a-IRR-controlsContainer, .a-IRR-detailView, .a-IRR-groupByView, .a-IRR-iconViewTable, .a-IRR-pivotView {',
'    border-top-color: #E6E6E6;',
'    display: block;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240219180125Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260409202608Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(119040363538330406)
,p_plug_name=>'Editar Cod Producto Proveedor'
,p_region_name=>'editDetalle'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size480x320:t-Form--noPadding'
,p_region_attributes=>'style="height: 170px; width: 527px"'
,p_plug_template=>wwv_flow_imp.id(295627185797037684)
,p_plug_display_sequence=>40
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(119040891023330411)
,p_plug_name=>'Edicion Producto Proveedor'
,p_parent_plug_id=>wwv_flow_imp.id(119040363538330406)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(119040905118330412)
,p_plug_name=>'Botones'
,p_parent_plug_id=>wwv_flow_imp.id(119040363538330406)
,p_region_template_options=>'#DEFAULT#:t-Form--noPadding:t-Form--labelsAbove'
,p_plug_template=>wwv_flow_imp.id(296121809343169165)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(128660503377446205)
,p_plug_name=>'Negociaciones'
,p_region_name=>'rptNegociaciones'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'G_IDNEGOCIACION'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(133922424961985510)
,p_plug_name=>unistr('Negociaci\00F3n &P138_ID_NEGOCIACION.')
,p_parent_plug_id=>wwv_flow_imp.id(128660503377446205)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>35
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20240501171052Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(206431199611010949)
,p_plug_name=>unistr('Informaci\00F3n de Pagos Recurrentes')
,p_parent_plug_id=>wwv_flow_imp.id(133922424961985510)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>80
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P138_RECURRENTE'
,p_plug_display_when_cond2=>'SI'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20240221165256Z')
,p_updated_on=>wwv_flow_imp.dz('20240501171052Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(133923357418985519)
,p_plug_name=>'Cabecera'
,p_parent_plug_id=>wwv_flow_imp.id(128660503377446205)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>45
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id',
'	, idneg',
'	, escala',
'	, acumula',
'	, tipoprecio',
'	, formula',
'	, unidadnegocio',
'	, unidadnegociogasto',
'	, moneda',
'	, toleranciatip',
'	, toleranciadsd',
'	, toleranciahst',
'	, justificacion',
'	, ''<span title = "Editar" class = "fa fa-pencil-square-o "/>'' detalle',
'from t_comp_negociacioncab',
'where idneg = :p138_id_negociacion'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P138_ID_NEGOCIACION'
,p_plug_display_condition_type=>'NEVER'
,p_plug_read_only_when_type=>'ALWAYS'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Cebecera'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20240501172435Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(129511022657771223)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(129511172160771224)
,p_name=>'ESCALA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ESCALA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Escala'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>20
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>20
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P138_ESQUEMA'
,p_display_condition2=>'ES'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(129511263373771225)
,p_name=>'ACUMULA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACUMULA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Acumula'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>20
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P138_ESQUEMA'
,p_display_condition2=>'ES'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(129511359997771226)
,p_name=>'TIPOPRECIO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIPOPRECIO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Tipo Precio'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_02=>'LOV'
,p_attribute_05=>'PLAIN'
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(134248652638070866)
,p_lov_display_extra=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(129511401667771227)
,p_name=>'FORMULA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FORMULA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>unistr('F\00F3rmula')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_02=>'LOV'
,p_attribute_05=>'PLAIN'
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(66566332119154689)
,p_lov_display_extra=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P138_BANDERA_TIPO_PRECIO'
,p_display_condition2=>'1'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(129511597907771228)
,p_name=>'UNIDADNEGOCIO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UNIDADNEGOCIO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Unidad Negocio'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_02=>'LOV'
,p_attribute_05=>'PLAIN'
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(44764979228098231)
,p_lov_display_extra=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20240412194644Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(129511655516771229)
,p_name=>'MONEDA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MONEDA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Moneda'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20240412194644Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(129511764306771230)
,p_name=>'TOLERANCIATIP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOLERANCIATIP'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>90
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20240412194644Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(129511816432771231)
,p_name=>'TOLERANCIADSD'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOLERANCIADSD'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>100
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20240412194644Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(129511964933771232)
,p_name=>'TOLERANCIAHST'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOLERANCIAHST'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>110
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20240412194644Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(129512020622771233)
,p_name=>'JUSTIFICACION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'JUSTIFICACION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>unistr('Justificaci\00F3n')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20240412194644Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(129512173404771234)
,p_name=>'DETALLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DETALLE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'<span title="Editar"class="fa fa-pencil-square-o "/>'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>130
,p_value_alignment=>'CENTER'
,p_attribute_05=>'HTML'
,p_link_target=>'f?p=&APP_ID.:145:&SESSION.::&DEBUG.:RP,145:P145_CABECERA_ID,P145_NEGOCIACION_ID:&ID.,&IDNEG.'
,p_link_text=>'&DETALLE.'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_include_in_export=>false
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>'(:P138_ES_EDICION = 1 and :P138_ESTADO_FLUJO in(''APROBADO'',''VIGENTE''))'
,p_display_condition2=>'PLSQL'
,p_updated_on=>wwv_flow_imp.dz('20240412221432Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(129512261149771235)
,p_name=>'IDNEG'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IDNEG'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>140
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20240412194644Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(260169949805355607)
,p_name=>'UNIDADNEGOCIOGASTO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UNIDADNEGOCIOGASTO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'UN Gasto'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_02=>'LOV'
,p_attribute_05=>'PLAIN'
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(77363400278805753)
,p_lov_display_extra=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20240416144906Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(129510911333771222)
,p_internal_uid=>129510911333771222
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>false
,p_pagination_type=>'SET'
,p_show_total_row_count=>false
,p_show_toolbar=>false
,p_toolbar_buttons=>null
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>false
,p_download_formats=>null
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_updated_on=>wwv_flow_imp.dz('20240412221447Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(131760353758623157)
,p_interactive_grid_id=>wwv_flow_imp.id(129510911333771222)
,p_static_id=>'1317604'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
,p_updated_on=>wwv_flow_imp.dz('20240412221401Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(131760572067623157)
,p_report_id=>wwv_flow_imp.id(131760353758623157)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(131761021593623162)
,p_view_id=>wwv_flow_imp.id(131760572067623157)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(129511022657771223)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(131761993191623166)
,p_view_id=>wwv_flow_imp.id(131760572067623157)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(129511172160771224)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(131762893717623169)
,p_view_id=>wwv_flow_imp.id(131760572067623157)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(129511263373771225)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(131763756665623171)
,p_view_id=>wwv_flow_imp.id(131760572067623157)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(129511359997771226)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>100
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(131764613244623173)
,p_view_id=>wwv_flow_imp.id(131760572067623157)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(129511401667771227)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(131765555922623176)
,p_view_id=>wwv_flow_imp.id(131760572067623157)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(129511597907771228)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>350
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(131766470617623178)
,p_view_id=>wwv_flow_imp.id(131760572067623157)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(129511655516771229)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>75
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(131767349514623180)
,p_view_id=>wwv_flow_imp.id(131760572067623157)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(129511764306771230)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(131768222994623182)
,p_view_id=>wwv_flow_imp.id(131760572067623157)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(129511816432771231)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(131769185427623184)
,p_view_id=>wwv_flow_imp.id(131760572067623157)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(129511964933771232)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(131770005413623186)
,p_view_id=>wwv_flow_imp.id(131760572067623157)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(129512020622771233)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(131770988711623188)
,p_view_id=>wwv_flow_imp.id(131760572067623157)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(129512173404771234)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>40
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(131783800450683778)
,p_view_id=>wwv_flow_imp.id(131760572067623157)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(129512261149771235)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(285718188365997338)
,p_view_id=>wwv_flow_imp.id(131760572067623157)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(260169949805355607)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>350
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(150497240952530305)
,p_plug_name=>'Reportes'
,p_parent_plug_id=>wwv_flow_imp.id(128660503377446205)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>55
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'N',
  'rds_mode', 'STANDARD',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(129512869036771241)
,p_plug_name=>unistr('Detalle de Negociaci\00F3n')
,p_region_name=>'rptDetalle'
,p_parent_plug_id=>wwv_flow_imp.id(150497240952530305)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct det_id id',
'	, cab_id idcab',
'	, (select codigoproducto||'' - ''||nombreproducto||'' ''||codigoalterno||'' - [''||unidadcompra||'']'' d from vt_jde_productos where codigocorto = det_codproducto and codestado <> ''o'') codigoproducto',
'	, det_codproducto codproducto',
'	, det_codproductoprv codproductoprv',
'	, det_desproductoprv desproductoprv',
'	, det_umproductoprv umproductoprv',
'	, (select codigoproveedor||'' - ''||descripcion d from vt_jde_maestroproveedor where codigoproveedor = det_codproveedor) codproveedor',
unistr('	, decode(det_tiempoentrega,0,''Inmediato'',det_tiempoentrega ||'' d\00EDas'') tiempoentrega'),
'	, (select upper(trim(pnptd)) d from f0014@jdedtadl where pnptc = det_formapago and trim(pnptc) is not null) formapago',
'	, (select drky ||'' - ''||upper(drdl01) d from vt_jde_udcjde where drky = det_incoterm and drsy = ''42'' and drrt = ''FR'' and drky is not null ) incoterm',
'	, det_cantdesde cantdesde',
'	, det_canthasta canthasta',
'	, decode(cab_tipoprecio,''FM'',det_preciocal,det_precio) precio',
'	, det_preciocal preciocalculado',
'	, det_comentario comentario',
'	, null ver',
'	-- , case when exists (select 1 from vt_comp_negociacionhoc h where h.pditm = d.det_codproducto) then ''<span class="fa fa-analytics"></span>'' else null end ver',
'	, case when (trim(det_codproductoprv) is null or trim(det_desproductoprv) is null) then ''<span class="fa fa-edit"></span>'' else '''' end edit',
'	, det_precio_p1',
'	, variacion_p1',
'	, data.pk_comp_negociacion.f_neg_semaforo(decode(cab_tipoprecio,''FM'',det_preciocal,det_precio),det_precio_p1) p1_semaforo',
'	, (case when variacion_p1<0 then 1 when variacion_p1>0 then -1 else 0 end) p1_orden',
'	, d.ultimacompra',
'	, decode(d.ultimacompra,null,null,''<span class="fa fa-history"></span>'') ultimascompras',
'	, cab_moneda moneda',
'from vt_comp_negociaciondet d',
'left join vt_comp_negociacionpas p on neg_id = neg_id_act',
'	and det_codproducto = det_codproducto_act',
'	and det_codproveedor = det_codproveedor_act',
'	and det_cantdesde = det_cantdesde_act',
'	and det_canthasta = det_canthasta_act',
'	and nvl(det_tiempoentrega,0) = nvl(det_tiempoentrega_act,0)',
'	and nvl(det_formapago,'' '') = nvl(det_formapago_act,'' '')',
'	and nvl(det_incoterm,'' '') = nvl(det_incoterm_act,'' '')',
'where neg_id = :p138_id_negociacion'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P138_ID_CABECERA,P138_ID_NEGOCIACION'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Detalle'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20260402165257Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(129512967904771242)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_sort=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>129512967904771242
,p_updated_on=>wwv_flow_imp.dz('20260402165257Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129513043496771243)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129513160796771244)
,p_db_column_name=>'IDCAB'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Idcab'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129513762396771250)
,p_db_column_name=>'CODPRODUCTOPRV'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>unistr('C\00F3d. Producto Prov.')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':p138_esquema = ''PV'' and :g_gestion_presidente = 0'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240909034831Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132102025797164501)
,p_db_column_name=>'DESPRODUCTOPRV'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Des. Producto Prov.'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':p138_esquema = ''PV''-- and :g_gestion_presidente = 0'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260402165257Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132102161672164502)
,p_db_column_name=>'UMPRODUCTOPRV'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'UM'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':p138_esquema = ''PV'' and :g_gestion_presidente = 0'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240909034911Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132102318763164504)
,p_db_column_name=>'TIEMPOENTREGA'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Tiempo de Entrega'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132102482695164505)
,p_db_column_name=>'FORMAPAGO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Forma Pago'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132102514988164506)
,p_db_column_name=>'INCOTERM'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Incoterm'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132102601493164507)
,p_db_column_name=>'CANTDESDE'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Cant. Desde'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P138_TIPO_NEGOCIACION'
,p_display_condition2=>'ES'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132102775614164508)
,p_db_column_name=>'CANTHASTA'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Cant. Hasta'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P138_TIPO_NEGOCIACION'
,p_display_condition2=>'ES'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132102825947164509)
,p_db_column_name=>'PRECIO'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Precio'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P138_BANDERA_TIPO_PRECIO'
,p_display_condition2=>'0'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153681495790519604)
,p_db_column_name=>'DET_PRECIO_P1'
,p_display_order=>180
,p_column_identifier=>'AA'
,p_column_label=>unistr('\00DAlt. Precio')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>'(:P138_OBJETO = ''NEGOCIACION'') or (:P138_RECURRENTE = ''NO'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240909040546Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153681504337519605)
,p_db_column_name=>'VARIACION_P1'
,p_display_order=>190
,p_column_identifier=>'AB'
,p_column_label=>'% Var.'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>'(:P138_OBJETO = ''NEGOCIACION'') or (:P138_RECURRENTE = ''NO'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240501054519Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153681678008519606)
,p_db_column_name=>'P1_SEMAFORO'
,p_display_order=>200
,p_column_identifier=>'AC'
,p_column_label=>'<span style="color:white; font-size:small" class="fa fa-dot-circle-o"></span>'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>'(:P138_OBJETO = ''NEGOCIACION'') or (:P138_RECURRENTE = ''NO'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240501054519Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153681761748519607)
,p_db_column_name=>'P1_ORDEN'
,p_display_order=>210
,p_column_identifier=>'AD'
,p_column_label=>'Orden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132103154880164512)
,p_db_column_name=>'COMENTARIO'
,p_display_order=>220
,p_column_identifier=>'T'
,p_column_label=>'Comentario'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132103439371164515)
,p_db_column_name=>'VER'
,p_display_order=>240
,p_column_identifier=>'W'
,p_column_label=>'Evol.'
,p_column_link=>'f?p=&APP_ID.:142:&SESSION.::&DEBUG.:RP,142:P142_ID_NEGOCIACION,P142_PAGINA,P142_ID_DETALLE,P142_PRODUCTO,P142_VIGENCIA:&P138_ID_NEGOCIACION.,&APP_PAGE_ID.,#ID#,#CODPRODUCTO#,&P138_VIGENCIA_DESDE. - &P138_VIGENCIA_HASTA.'
,p_column_linktext=>'#VER#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P138_RECURRENTE = ''NO'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240909035529Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132103542734164516)
,p_db_column_name=>'EDIT'
,p_display_order=>250
,p_column_identifier=>'X'
,p_column_label=>'Edit'
,p_column_link=>'javascript: $s("P138_ID_DETALLE",'''');$s("P138_ID_DETALLE",#ID#);$s("P138_PRODUCTO",'''');$s("P138_PRODUCTO",''#CODPRODUCTO#'');$s("P138_CODPRODUCTOPRV",'''');$s("P138_CODPRODUCTOPRV",''#CODPRODUCTOPRV#'');$s("P138_DESPRODUCTOPRV",'''');$s("P138_DESPRODUCTOPRV"'
||',''#DESPRODUCTOPRV#''); openModal(''editDetalle'');'
,p_column_linktext=>'#EDIT#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXISTS'
,p_display_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct neg_id',
'from vt_comp_negociaciondet d ',
'where :p138_edit_negociacion = 1',
'and neg_id = :p138_id_negociacion',
'and (cab_id= :p138_id_cabecera or :p138_id_cabecera is null) ',
'and  (trim(det_codproductoprv) is null or trim(det_desproductoprv) is null)'))
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240221195828Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132103661837164517)
,p_db_column_name=>'CODIGOPRODUCTO'
,p_display_order=>260
,p_column_identifier=>'Y'
,p_column_label=>'Producto'
,p_allow_sorting=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P138_ESQUEMA'
,p_display_condition2=>'PV'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132103721208164518)
,p_db_column_name=>'CODPROVEEDOR'
,p_display_order=>270
,p_column_identifier=>'Z'
,p_column_label=>'Proveedor'
,p_allow_sorting=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P138_ESQUEMA'
,p_display_condition2=>'PD'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(207337345782084001)
,p_db_column_name=>'PRECIOCALCULADO'
,p_display_order=>280
,p_column_identifier=>'AE'
,p_column_label=>unistr('Precio Calc. F\00F3rm.')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P138_BANDERA_TIPO_PRECIO'
,p_display_condition2=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(232459479318576504)
,p_db_column_name=>'CODPRODUCTO'
,p_display_order=>290
,p_column_identifier=>'AF'
,p_column_label=>'Codproducto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240221190204Z')
,p_updated_on=>wwv_flow_imp.dz('20240221190204Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(411012433373960507)
,p_db_column_name=>'ULTIMACOMPRA'
,p_display_order=>300
,p_column_identifier=>'AG'
,p_column_label=>unistr('\00DAlt. Compra')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P138_RECURRENTE'
,p_display_condition2=>'NO'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240909034616Z')
,p_updated_on=>wwv_flow_imp.dz('20240909040133Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(411012556646960508)
,p_db_column_name=>'ULTIMASCOMPRAS'
,p_display_order=>310
,p_column_identifier=>'AH'
,p_column_label=>'<span style="color:black; font-size:small" class="fa fa-history"></span>'
,p_column_link=>'f?p=&APP_ID.:225:&SESSION.::&DEBUG.:225:P225_IDNEG,P225_IDCAB,P225_IDDET:&P138_ID_NEGOCIACION.,#IDCAB#,#ID#'
,p_column_linktext=>'#ULTIMASCOMPRAS#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P138_RECURRENTE'
,p_display_condition2=>'NO'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240909040133Z')
,p_updated_on=>wwv_flow_imp.dz('20240909041841Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(599463038239255641)
,p_db_column_name=>'MONEDA'
,p_display_order=>320
,p_column_identifier=>'AI'
,p_column_label=>'Moneda'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250218220835Z')
,p_updated_on=>wwv_flow_imp.dz('20250218220947Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(132114937955171490)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1321150'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_view_mode=>'REPORT'
,p_report_columns=>'CODIGOPRODUCTO:DESPRODUCTOPRV:TIEMPOENTREGA:FORMAPAGO:INCOTERM:PRECIO:DET_PRECIO_P1:CANTDESDE:CANTHASTA:EDIT:PRECIOCALCULADO:VARIACION_P1:P1_SEMAFORO:MONEDA:COMENTARIO:'
,p_sort_column_1=>'CODIGOPRODUCTO'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'CODPROVEEDOR'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'CANTDESDE'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'CANTDESDE'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'P1_ORDEN'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20240219180127Z')
,p_updated_on=>wwv_flow_imp.dz('20250530152155Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(195279226114101419)
,p_plug_name=>'Archivos Soporte'
,p_region_name=>'rptSoporte'
,p_parent_plug_id=>wwv_flow_imp.id(150497240952530305)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(295630388916037685)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select numeroarchivo',
'	, filename',
'	, blobcontent',
'	, mimetype',
'	, ride',
'	, fecha',
'	, nombreusuario',
'	, tabla',
'	, id_tabla',
'	, tipo',
'	, observacion',
'	, estado',
'	, pk_commons.f_googledocview(numeroarchivo,mimetype) enlacearchivo',
'	, ''<span class="fa fa-trash"/>'' borra',
'from files.vt_apex_archivos',
'where tabla = ''T_COMP_NEGOCIACION'' ',
'	and to_number(substr(id_tabla,2,5)) = :p138_id_negociacion',
'	and tipo = ''ARCHIVO_CABECERA'''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Archivos Adjuntos'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20250218215121Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(195279452306101421)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'No hay archivos adjuntos.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>195279452306101421
,p_updated_on=>wwv_flow_imp.dz('20250218215121Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(150528841061110107)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Numeroarchivo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(150529699651110108)
,p_db_column_name=>'BLOBCONTENT'
,p_display_order=>20
,p_column_identifier=>'C'
,p_column_label=>'Archivo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_updated_on=>wwv_flow_imp.dz('20250218215042Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(150530019537110108)
,p_db_column_name=>'MIMETYPE'
,p_display_order=>30
,p_column_identifier=>'D'
,p_column_label=>'Tipo'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(150530810291110109)
,p_db_column_name=>'FECHA'
,p_display_order=>40
,p_column_identifier=>'F'
,p_column_label=>'Fecha'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy hh24:mi'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(150531245190110109)
,p_db_column_name=>'NOMBREUSUARIO'
,p_display_order=>50
,p_column_identifier=>'G'
,p_column_label=>'Usuario'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(150529288392110108)
,p_db_column_name=>'FILENAME'
,p_display_order=>60
,p_column_identifier=>'B'
,p_column_label=>'Archivo'
,p_column_link=>'#ENLACEARCHIVO#'
,p_column_linktext=>'#FILENAME#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250218215042Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(150531647335110109)
,p_db_column_name=>'TABLA'
,p_display_order=>70
,p_column_identifier=>'H'
,p_column_label=>'Tabla'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(150532036450110110)
,p_db_column_name=>'ID_TABLA'
,p_display_order=>80
,p_column_identifier=>'I'
,p_column_label=>'Id Tabla'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(150532418978110110)
,p_db_column_name=>'TIPO'
,p_display_order=>90
,p_column_identifier=>'J'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(150533269652110111)
,p_db_column_name=>'ESTADO'
,p_display_order=>100
,p_column_identifier=>'L'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(150532845927110111)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(150530490126110109)
,p_db_column_name=>'RIDE'
,p_display_order=>130
,p_column_identifier=>'E'
,p_column_label=>'Ride'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(150533649042110112)
,p_db_column_name=>'BORRA'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>'-'
,p_column_link=>'javascript: $s("P140_ID_NUMEROARCHIVO","");$s("P140_ID_NUMEROARCHIVO",#NUMEROARCHIVO#);'
,p_column_linktext=>'#BORRA#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P138_ES_EDICION = 1'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(599462962915255640)
,p_db_column_name=>'ENLACEARCHIVO'
,p_display_order=>150
,p_column_identifier=>'N'
,p_column_label=>'Enlacearchivo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250218214754Z')
,p_updated_on=>wwv_flow_imp.dz('20250218214754Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(195581802316889464)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'450533'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FILENAME:FECHA:NOMBREUSUARIO:BORRA:'
,p_created_on=>wwv_flow_imp.dz('20240219180127Z')
,p_updated_on=>wwv_flow_imp.dz('20250218215105Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(153682309835519613)
,p_plug_name=>'Evolucion de Precio(Promedio) de Compra'
,p_parent_plug_id=>wwv_flow_imp.id(128660503377446205)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>120
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with',
' ac as (select 0 ord_act,round(avg(det_precio_act),4)det_precio_act,det_codproducto_act from vt_comp_negociacionpas where neg_id_act=:P138_ID_NEGOCIACION AND (CAB_ID_ACT=:P138_ID_CABECERA or :P138_ID_CABECERA IS NULL) group by  det_codproducto_act)',
',p1 as (select 1 ord_p1 ,round(avg(det_precio_p1 ),4)det_precio_p1 ,det_codproducto_p1  from vt_comp_negociacionpas where neg_id_act=:P138_ID_NEGOCIACION AND (CAB_ID_ACT=:P138_ID_CABECERA or :P138_ID_CABECERA IS NULL) group by  det_codproducto_p1 )',
',p2 as (select 2 ord_p2 ,round(avg(det_precio_p2 ),4)det_precio_p2 ,det_codproducto_p2  from vt_comp_negociacionpas where neg_id_act=:P138_ID_NEGOCIACION AND (CAB_ID_ACT=:P138_ID_CABECERA or :P138_ID_CABECERA IS NULL) group by  det_codproducto_p2 )',
',p3 as (select 3 ord_p3 ,round(AVG(det_precio_p3 ),4)det_precio_p3 ,det_codproducto_p3  from vt_comp_negociacionpas where neg_id_act=:P138_ID_NEGOCIACION AND (CAB_ID_ACT=:P138_ID_CABECERA or :P138_ID_CABECERA IS NULL) group by  det_codproducto_p3 )',
',res as (',
'    select * from ac union ',
'    select * from p1 union ',
'    select * from p2 union ',
'    select * from p3   ',
'), det as (',
'select ',
unistr('     ''Negociaci\00F3n ''||decode(ord_act,0,''Act'',''P''||ord_act)Negociacion'),
'    ,CODIGOPRODUCTO||'' - ''|| NOMBREPRODUCTO||'' ''||CODIGOALTERNO ||''(''||CODIGOCORTO||'')''||'' - [''||UNIDADCOMPRA||'']'' NOMBREPRODUCTO',
'    ,DET_PRECIO_ACT',
'    ,det_codproducto_act',
'--    ,(select DET_PRECIO_ACT from ac where ac.det_codproducto_act= res.DET_CODPRODUCTO_ACT) DET_PRECIO_ACT_1',
'from res',
'inner join vt_jde_productos on DET_CODPRODUCTO_ACT =codigocorto',
')',
'select NEGOCIACION, NOMBREPRODUCTO, DET_PRECIO_ACT from det where DET_CODPRODUCTO_ACT in (',
'    select DET_CODPRODUCTO_ACT from (select distinct DET_CODPRODUCTO_ACT from det) where rownum<=5',
')',
'order by NOMBREPRODUCTO, NEGOCIACION'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_ajax_items_to_submit=>'P138_ID_NEGOCIACION,P138_ID_CABECERA'
,p_plug_display_condition_type=>'NEVER'
,p_updated_on=>wwv_flow_imp.dz('20250218214251Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(153682444824519614)
,p_region_id=>wwv_flow_imp.id(153682309835519613)
,p_chart_type=>'bar'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'on'
,p_data_cursor_behavior=>'smooth'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_position=>'bottom'
,p_legend_font_family=>'Arial'
,p_legend_font_style=>'normal'
,p_legend_font_size=>'8'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ){ ',
'    options.dataFilter = function( data ) { ',
'        console.log(data);',
'        var s ;',
'        var c ;',
'        var colors = ["#33b2df","#546E7A","#d4526e","#13d8aa","#A5978B","#2b908f","#f9a3a4","#90ee7e","#f48024","#69d2e7"];',
'        for (s=0;s<data.series.length;s++) {',
'            c= colors[s];',
'            if (data.series[s].name==" - "){',
'                data.series[s].color = "#00000000";',
'                data.series[s].shortDesc = "";',
'            }else{',
'                data.series[s].color = c;',
'            }',
'        }',
'        return data;',
'    };',
'    return options;',
'}'))
,p_updated_on=>wwv_flow_imp.dz('20240221200517Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(153682535135519615)
,p_chart_id=>wwv_flow_imp.id(153682444824519614)
,p_seq=>10
,p_name=>'Precios'
,p_location=>'REGION_SOURCE'
,p_series_name_column_name=>'NEGOCIACION'
,p_items_value_column_name=>'DET_PRECIO_ACT'
,p_items_label_column_name=>'NOMBREPRODUCTO'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'start'
,p_items_label_font_size=>'8'
,p_updated_on=>wwv_flow_imp.dz('20240221200517Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(153682659422519616)
,p_chart_id=>wwv_flow_imp.id(153682444824519614)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(153682760260519617)
,p_chart_id=>wwv_flow_imp.id(153682444824519614)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'currency'
,p_decimal_places=>4
,p_currency=>'$'
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'start'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'on'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(133921734569985503)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(133921998655985505)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody:t-Form--noPadding'
,p_plug_template=>wwv_flow_imp.id(295630388916037685)
,p_plug_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(133922044893985506)
,p_plug_name=>'Botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121809343169165)
,p_plug_display_sequence=>50
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(149734495023703447)
,p_plug_name=>unistr('No existe informaci\00F3n para aprobaci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--customIcons:t-Alert--danger:t-Alert--accessibleHeading'
,p_plug_template=>wwv_flow_imp.id(295605160997037667)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>unistr('<span style="color: #ff0000a3;font-size: xx-large;font-family: fantasy;">No existe informaci\00F3n para aprobaci\00F3n.</span>')
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'G_IDNEGOCIACION'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20240522200138Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133922149320985507)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(133922044893985506)
,p_button_name=>'Aprobar'
,p_button_static_id=>'btnAprobar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Aprobar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:102:&SESSION.::&DEBUG.:RP,102:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_OBJETO_DESCRIPCION:&G_COMPANIA.,&APP_MODULO.,&P138_USUARIO.,&P138_OBJETO.,&P138_IDOBJETO.,&P138_OBJETO_DESCRIPCION.'
,p_button_condition=>'P138_ES_APROBADOR'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_updated_on=>wwv_flow_imp.dz('20240221192344Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133922251412985508)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(133922044893985506)
,p_button_name=>'Rechazar'
,p_button_static_id=>'btnRechazar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Rechazar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:103:&SESSION.::&DEBUG.:RP,103:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO,G_OBJETO_DESCRIPCION:&G_COMPANIA.,&APP_MODULO.,&P138_USUARIO.,&P138_OBJETO.,&P138_IDOBJETO.,&P138_APROBADOR.,&P138_OBJETO_DESCRIPCION.'
,p_button_condition=>'P138_ES_APROBADOR'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_updated_on=>wwv_flow_imp.dz('20240221192344Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(143507795586026716)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(133921734569985503)
,p_button_name=>'Atras'
,p_button_static_id=>'btnAtras'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Atras'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:&P138_PAGRETORNO.:&SESSION.::&DEBUG.:::'
,p_button_condition=>'G_PAGNEGOCIACION'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(407636539169393916)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(133921734569985503)
,p_button_name=>'Responsable'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Responsable PR'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:217:&SESSION.::&DEBUG.:RP,217:P217_IDNEGOCIACION:&P138_ID_NEGOCIACION.'
,p_button_condition=>'P138_RECURRENTE'
,p_button_condition2=>'SI'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-user-arrow-up'
,p_created_on=>wwv_flow_imp.dz('20240812194605Z')
,p_updated_on=>wwv_flow_imp.dz('20240812194820Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(300485682963773230)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(133921734569985503)
,p_button_name=>'PagoRecurrente'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Pago Recurrente'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:224:&SESSION.::&DEBUG.:RP,224:P224_IDNEG:&P138_ID_NEGOCIACION.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''x'' from t_comp_negociacion',
'where 1 = 1',
'    and id = :p138_id_negociacion',
'    and recurrente = ''SI''',
'    and estadoflujo = ''APROBADO''',
'    and nvl(estadopagos,''RECHAZADO'') = ''RECHAZADO'''))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-alarm-clock'
,p_created_on=>wwv_flow_imp.dz('20240522152243Z')
,p_updated_on=>wwv_flow_imp.dz('20240812201947Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133922651686985512)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(133921734569985503)
,p_button_name=>'NegPasadas'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Neg. Pasadas'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:143:&SESSION.::&DEBUG.:RP,:P143_NEG_ID_ACTUAL,P143_TIPO:&P138_ID_NEGOCIACION.,1'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  1',
'FROM DATA.VT_COMP_NEGOCIACIONPAS ',
'WHERE 1=1 ',
'and (DET_CODPROVEEDOR_ACT = DET_CODPROVEEDOR_p1 and DET_CODPROVEEDOR_ACT = DET_CODPROVEEDOR_p2 and DET_CODPROVEEDOR_ACT = DET_CODPROVEEDOR_p3) ',
'and neg_id_act = :P138_ID_NEGOCIACION'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa fa-file-archive-o'
,p_updated_on=>wwv_flow_imp.dz('20240812194702Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133922757056985513)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(133921734569985503)
,p_button_name=>'NegProveedor'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Neg. Proveedor'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:143:&SESSION.::&DEBUG.:RP,143:P143_NEG_ID_ACTUAL,P143_TIPO:&P138_ID_NEGOCIACION.,2'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  1',
'FROM DATA.VT_COMP_NEGOCIACIONPAS ',
'WHERE 1=1 ',
'and (DET_CODPROVEEDOR_ACT <> DET_CODPROVEEDOR_p1 OR DET_CODPROVEEDOR_ACT <> DET_CODPROVEEDOR_p2 OR DET_CODPROVEEDOR_ACT <> DET_CODPROVEEDOR_p3 ) ',
'and neg_id_act = :P138_ID_NEGOCIACION'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-table-file'
,p_updated_on=>wwv_flow_imp.dz('20240522152243Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(139897883222798814)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(133921734569985503)
,p_button_name=>'Copiar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Copiar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>':P138_ACCIONCOPIAR = 1 and :P138_ESTADO_FLUJO != ''EN RUTA'''
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-files-o'
,p_updated_on=>wwv_flow_imp.dz('20260105210756Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(140735565110225104)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(133921734569985503)
,p_button_name=>'Validar'
,p_button_static_id=>'btnValidar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Enviar Flujo'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NEG_ESTADOFLUJO, CAB_ESTADOFLUJO, DET_ESTADOFLUJO, NEG_ID, CAB_ID, DET_ID,DET_CANTDESDE, DET_CANTHASTA, DET_PRECIO, DET_PRECIOANT ',
'FROM vt_comp_negociacion A',
'where NEG_ID =:P138_ID_NEGOCIACION',
'AND NEG_ESTADOFLUJO=''APROBADO'' AND CAB_ESTADOFLUJO=''APROBADO'' AND DET_ESTADOFLUJO=''CREACION''',
'and (:P138_ES_EDICION=1 and :P138_ESTADO_FLUJO=''APROBADO'')'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-send'
,p_updated_on=>wwv_flow_imp.dz('20240522152244Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(140642413383536246)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_imp.id(133921734569985503)
,p_button_name=>'Enviar'
,p_button_static_id=>'btnEnviar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>unistr('f?p=100:101:&SESSION.::&DEBUG.:RP,:G_MODULO,G_OBJETO,G_OBJETO_ID,G_USUARIO,G_TIPO1,G_COMENTARIO:&APP_MODULO.,NEGOCIACION,&P138_ID_NEGOCIACION.,&P138_USUARIO.,NEGOCIACION,Reenv\00EDo de Negociaci\00F3n &P138_ID_NEGOCIACION. con vigencia entre &P138_VIGENCIA_DESDE. - &P138_VIGENCIA_HASTA.')
,p_icon_css_classes=>'fa-send'
,p_button_cattributes=>'style="display:none"'
,p_updated_on=>wwv_flow_imp.dz('20240522152244Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(48005165732361920)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_imp.id(133921734569985503)
,p_button_name=>'BorrarAprobado'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Borrar Aprobado'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'(:P138_ES_EDICION=1 and :P138_ESTADO_FLUJO=''APROBADO'')'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-trash'
,p_updated_on=>wwv_flow_imp.dz('20240522152244Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(132270477325622540)
,p_button_sequence=>130
,p_button_plug_id=>wwv_flow_imp.id(133921734569985503)
,p_button_name=>unistr('CancelarNegociaci\00F3n')
,p_button_static_id=>'btnCancelar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>unistr('Cancelar Negociaci\00F3n')
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:220:&SESSION.::&DEBUG.:RP,220:P220_ID_NEGOCIACION,P220_TIPO:&P138_ID_NEGOCIACION.,1'
,p_button_condition=>'(:P138_ES_EDICION=1 and :P138_ESTADO_FLUJO IN (''APROBADO'',''VIGENTE''))'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-times-rectangle-o'
,p_updated_on=>wwv_flow_imp.dz('20240522152244Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(141063076285133006)
,p_button_sequence=>140
,p_button_plug_id=>wwv_flow_imp.id(133921734569985503)
,p_button_name=>'CambiarFecha'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Extender Vigencia'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:220:&SESSION.::&DEBUG.:RP,220:P220_ID_NEGOCIACION,P220_TIPO:&P138_ID_NEGOCIACION.,2'
,p_button_condition=>'(:P138_ES_EDICION=1 and :P138_ESTADO_FLUJO IN (''APROBADO'',''VIGENTE'',''CADUCADO''))'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-calendar-edit'
,p_updated_on=>wwv_flow_imp.dz('20240522152244Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(143510177493026740)
,p_button_sequence=>150
,p_button_plug_id=>wwv_flow_imp.id(133921734569985503)
,p_button_name=>unistr('Evoluci\00F3n')
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>unistr('Evoluci\00F3n')
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:142:&SESSION.::&DEBUG.:RP,142:P142_ID_NEG,P142_PAGINA,P142_ID_DETALLE,P142_ID_NEG:&P138_ID_NEGOCIACION.,&APP_ID_PAGE.,0,&P138_ID_NEGOCIACION.'
,p_button_condition=>'G_IDNEGOCIACION'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-analytics'
,p_updated_on=>wwv_flow_imp.dz('20240522152244Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(119041020700330413)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(119040905118330412)
,p_button_name=>'Editar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Editar'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133922555155985511)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_button_name=>'Atras_100'
,p_button_static_id=>'btnAtras100'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Atras'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::'
,p_button_condition=>'G_PAGNEGOCIACION'
,p_button_condition2=>'100'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-arrow-left'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(138960731207199224)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_button_name=>'Atras_137'
,p_button_static_id=>'btnAtras137'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Atras'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:137:&SESSION.::&DEBUG.:::'
,p_button_condition=>'G_PAGNEGOCIACION'
,p_button_condition2=>'137'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-arrow-left'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(139898012802798816)
,p_branch_name=>'goto 139'
,p_branch_action=>'f?p=&APP_ID.:139:&SESSION.::&DEBUG.:RP,139:G_IDNEGOCIACION,G_EDITNEGOCIACION:&P138_IDNEGOCIACION_NUEVO.,1&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(139897883222798814)
,p_branch_sequence=>10
,p_branch_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_branch_condition=>'P138_IDNEGOCIACION_NUEVO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48005961039361928)
,p_name=>'P138_BORROAPROBADA'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Borroaprobada'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(119040208376330405)
,p_name=>'P138_ID_DETALLE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Id Detalle'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(119040444037330407)
,p_name=>'P138_PRODUCTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(119040891023330411)
,p_prompt=>'Producto Zaimella'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(119040521753330408)
,p_name=>'P138_CODPRODUCTOPRV'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(119040891023330411)
,p_prompt=>unistr('C\00F3d. Producto Proveedor')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(119040638385330409)
,p_name=>'P138_DESPRODUCTOPRV'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(119040891023330411)
,p_prompt=>'Desproductoprv'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135560515285707445)
,p_name=>'P138_ID_NEGOCIACION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Id Negociacion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135560627956707446)
,p_name=>'P138_TIPO_NEGOCIACION'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(133922424961985510)
,p_prompt=>'Volumen:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_NEG_TIPO'
,p_lov=>'SELECT VALOR D, ID_TABLA R FROM "DATA"."T_CORP_UDC" WHERE ACTIVO = 1 AND ID_CABECERA = ''COMP_NGTIP'';'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when_type=>'NEVER'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20240501143807Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135560706652707447)
,p_name=>'P138_ESQUEMA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(133922424961985510)
,p_prompt=>'Tipo Esquema:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_NEG_ESQUEMA'
,p_lov=>'SELECT VALOR D, ID_TABLA R FROM "DATA"."T_CORP_UDC" WHERE ACTIVO = 1 AND ID_CABECERA = ''COMP_NGESQ'';'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20240501143807Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135560867762707448)
,p_name=>'P138_COD_ESQUEMA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(133922424961985510)
,p_prompt=>'Proveedor:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_NEG_CODIGOESQ'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select D descripcion,R codigo from (',
'with prd as (',
'SELECT   CODIGOPRODUCTO || '' - '' ||  NOMBREPRODUCTO || '' ''|| CODIGOALTERNO  || '' - ['' ||  UNIDADCOMPRA || '']'' d  ,CODIGOCORTO r,  ''PD'' tipo FROM vt_jde_productos WHERE  CODESTADO<>''O'' GROUP BY  CODIGOPRODUCTO || '' - '' ||  NOMBREPRODUCTO || '' ''|| CODI'
||'GOALTERNO     || '' - ['' ||  UNIDADCOMPRA || '']''  ,CODIGOCORTO ,NOMBREPRODUCTO order by NOMBREPRODUCTO ',
'),',
'prv as (',
'SELECT   CODIGOPROVEEDOR || '' - '' ||  DESCRIPCION d, CODIGOPROVEEDOR r,  ''PV'' FROM  VT_JDE_MAESTROPROVEEDOR GROUP BY CODIGOPROVEEDOR || '' - '' ||  DESCRIPCION , CODIGOPROVEEDOR , DESCRIPCION ORDER BY DESCRIPCION',
')',
' select d,r from prd union all',
' select d,r from prv',
' )'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20240501143807Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135560976586707449)
,p_name=>'P138_RECURRENTE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(206431199611010949)
,p_prompt=>'Pago Recurrente:'
,p_display_as=>'NATIVE_YES_NO'
,p_display_when_type=>'NEVER'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'SI'
,p_attribute_03=>'SI'
,p_attribute_04=>'NO'
,p_attribute_05=>'NO'
,p_updated_on=>wwv_flow_imp.dz('20240501171052Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135561075062707450)
,p_name=>'P138_PERIODICIDAD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(206431199611010949)
,p_prompt=>'Periodicidad:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20240501171052Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136510002498950101)
,p_name=>'P138_VIGENCIA_DESDE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(133922424961985510)
,p_prompt=>'Vigencia Desde:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20240501143807Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136510130279950102)
,p_name=>'P138_VIGENCIA_HASTA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(133922424961985510)
,p_prompt=>'Vigencia Hasta:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20240501143807Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136510243072950103)
,p_name=>'P138_ID_CABECERA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Id Cabecera'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136510312641950104)
,p_name=>'P138_EDIT_NEGOCIACION'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Edit Negociacion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136510448630950105)
,p_name=>'P138_ES_EDICION'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Es Edicion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136510572574950106)
,p_name=>'P138_MENSAJE_ERROR'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Mensaje Error'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136510681863950107)
,p_name=>'P138_ESQUEMA_ACT'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Esquema Act'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136510749918950108)
,p_name=>'P138_COD_ESQUEMA_ACT'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Cod Esquema Act'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136510839388950109)
,p_name=>'P138_ELIMINA_DETALLE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Elimina Detalle'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136510916963950110)
,p_name=>'P138_TITULO'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Titulo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136511051631950111)
,p_name=>'P138_ES_APROBADOR'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Es Aprobador'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136511145688950112)
,p_name=>'P138_USUARIO'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Usuario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136511270551950113)
,p_name=>'P138_TIPO'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136511309211950114)
,p_name=>'P138_APROBADOR'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Aprobador'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136566551079245405)
,p_name=>'P138_ENVIO_EXITO'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Envio Exito'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136566689377245406)
,p_name=>'P138_TERMINO'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Termino'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(137371180161651917)
,p_name=>'P138_ESTADO_FLUJO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(133922424961985510)
,p_prompt=>'Estado'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20240501143807Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(138961099280199227)
,p_name=>'P138_OBSERVACION'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(133922424961985510)
,p_prompt=>unistr('Observaci\00F3n')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_05=>'HTML_UNSAFE'
,p_updated_on=>wwv_flow_imp.dz('20240501143807Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(139898149560798817)
,p_name=>'P138_IDNEGOCIACION_NUEVO'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Idnegociacion Nuevo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(139899000598798826)
,p_name=>'P138_ACCIONCOPIAR'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Accioncopiar'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140642739001536249)
,p_name=>'P138_VALIDAR'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Validar'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(141064654948133022)
,p_name=>'P138_OBJETO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Objeto'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(141065976479133035)
,p_name=>'P138_PAGRETORNO'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Pagretorno'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(145673345971365223)
,p_name=>'P138_IRMESA'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Irmesa'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(149734305589703446)
,p_name=>'P138_IDOBJETO'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Idobjeto'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(150497599142530308)
,p_name=>'P138_ARCHIVO_IDTABLA'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Archivo Idtabla'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(206431257979010950)
,p_name=>'P138_FRECUENCIA'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(206431199611010949)
,p_prompt=>'Frecuencia:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_NEG_FRECUENCIA'
,p_lov=>'.'||wwv_flow_imp.id(230185465636915585)||'.'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240221165256Z')
,p_updated_on=>wwv_flow_imp.dz('20240531211655Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(207337466978084002)
,p_name=>'P138_BANDERA_TIPO_PRECIO'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Bandera Tipo Precio'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(232459167347576501)
,p_name=>'P138_TIPOPAGO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(206431199611010949)
,p_prompt=>'Tipo Pago:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_NEG_TIPOPAGO'
,p_lov=>'.'||wwv_flow_imp.id(231130202278619882)||'.'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240221165256Z')
,p_updated_on=>wwv_flow_imp.dz('20240501171818Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(232459276160576502)
,p_name=>'P138_NUMEROPAGOS'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(206431199611010949)
,p_prompt=>unistr('N\00FAm. Pagos:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240221165256Z')
,p_updated_on=>wwv_flow_imp.dz('20240501171818Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(232459337387576503)
,p_name=>'P138_FECHAPRIMERPAGO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(206431199611010949)
,p_prompt=>'Primer Pago:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240221165256Z')
,p_updated_on=>wwv_flow_imp.dz('20240501171818Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(232459548053576505)
,p_name=>'P138_TIPO2'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Tipo2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20240221192343Z')
,p_updated_on=>wwv_flow_imp.dz('20240221192343Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(232459682181576506)
,p_name=>'P138_OBJETO_DESCRIPCION'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Objeto Descripcion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20240221192344Z')
,p_updated_on=>wwv_flow_imp.dz('20240221192344Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(257472865352266501)
,p_name=>'P138_TIPOMONTO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(206431199611010949)
,p_prompt=>'Tipo Monto:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_NEG_TIPOMONTO'
,p_lov=>'.'||wwv_flow_imp.id(240341499876606572)||'.'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240314162306Z')
,p_updated_on=>wwv_flow_imp.dz('20240501171818Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(257472996947266502)
,p_name=>'P138_TIPORECEPCION'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(206431199611010949)
,p_prompt=>unistr('Tipo Recepci\00F3n:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_NEG_TIPORECEPCION'
,p_lov=>'.'||wwv_flow_imp.id(257467648715249911)||'.'
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240314162306Z')
,p_updated_on=>wwv_flow_imp.dz('20240501171818Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(260170678360355614)
,p_name=>'P138_REQUISITOR'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(206431199611010949)
,p_prompt=>'Requisitor'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P138_REQUISITOR'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240412220531Z')
,p_updated_on=>wwv_flow_imp.dz('20240510143240Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(260170727807355615)
,p_name=>'P138_COSTO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(206431199611010949)
,p_prompt=>'Costo Total:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240412220531Z')
,p_updated_on=>wwv_flow_imp.dz('20240501171818Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(599462197189255632)
,p_name=>'P138_TERMINA_FLUJO'
,p_item_sequence=>320
,p_item_plug_id=>wwv_flow_imp.id(133921998655985505)
,p_prompt=>'Termina Flujo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250213181655Z')
,p_updated_on=>wwv_flow_imp.dz('20250213181655Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(136512628585950127)
,p_name=>'CambioSeleccionCabecera'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(133923357418985519)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data.selectedRecords[0] != undefined'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(136512763235950128)
,p_event_id=>wwv_flow_imp.id(136512628585950127)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var value = this.data.selectedRecords[0][0];',
'console.log(this.data.selectedRecords);',
'',
'$s("P138_ID_CABECERA",value);',
'var idTablaArchvivo= ''N''+("00000" + $v("P138_ID_NEGOCIACION")).slice(-5)+''C''+("00000" + $v("P138_ID_CABECERA")).slice(-5) ;',
'$s("P138_ARCHIVO_IDTABLA",idTablaArchvivo);',
'console.log($v("P138_ID_CABECERA"))',
'console.log($v("P138_ARCHIVO_IDTABLA"))',
'',
'apex.region("rptDetalle").refresh();',
'apex.region("rptSoporte").refresh();',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(136566349168245403)
,p_name=>unistr('Cierre di\00E1logo: aprobar')
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(133922149320985507)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_updated_on=>wwv_flow_imp.dz('20240223214117Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(136566436130245404)
,p_event_id=>wwv_flow_imp.id(136566349168245403)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'console.log(trama);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'',
'mostrarBarra();',
'',
'// P138_FLUJO = 0 ERROR , 1 SE APROBO CON EXITO, 2 TERMINO FLUJO',
'apex.item("P138_ENVIO_EXITO").setValue(0);',
'',
'if(this.data.G_EXITO==''true''){',
'    apex.item("P138_ENVIO_EXITO").setValue(1);',
'  ',
'    if(isTerminoFlujo){',
'        mensaje(''exito'', this.data.G_MENSAJE+''. '' + ''<br />Termina el flujo'' );',
'        apex.item("P138_TERMINO").setValue(1);',
'        console.log("P138_TERMINO:"+$v("P138_TERMINO")); ',
'    }else{',
'          mensaje(''exito'', this.data.G_MENSAJE);',
'    }',
'    console.log("P138_ENVIO_EXITO:"+$v("P138_ENVIO_EXITO"));',
'     ',
'}',
'else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(136566755878245407)
,p_event_id=>wwv_flow_imp.id(136566349168245403)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare  ',
'v_exito 	number;',
'v_idneg		number;',
'v_termino 	number;',
'v_usuario 	varchar(250);',
'begin',
'	v_usuario		:= :p138_usuario;',
'	v_exito			:= :p138_envio_exito;',
'	v_termino		:= nvl(:p138_termino,0);',
'	v_idneg			:= :p138_id_negociacion;',
'',
'	if v_exito = 1 and v_termino = 1 then',
'		data.pk_comp_negociacion.sp_aprobarnegociacion(p_compania => :g_compania, p_usuario => v_usuario, p_idneg => v_idneg);',
'	end if;',
'end;'))
,p_attribute_02=>'APP_MODULO,P138_APROBADOR,P138_USUARIO,P138_ENVIO_EXITO,P138_TERMINO,P138_ID_NEGOCIACION,P138_ESQUEMA,G_COMPANIA'
,p_attribute_03=>'P138_MENSAJE_ERROR'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240223214117Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(136566885547245408)
,p_event_id=>wwv_flow_imp.id(136566349168245403)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ocultarBarra();',
'if(this.data.G_EXITO==''true''){',
'    $(''#btnAtras'').trigger("click");',
'    $(''#btnAprobar'').hide();',
'    $(''#btnRechazar'').hide();',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(137372043909651926)
,p_name=>unistr('Cierre di\00E1logo: rechazar')
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(133922251412985508)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_updated_on=>wwv_flow_imp.dz('20240223213106Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(137372198604651927)
,p_event_id=>wwv_flow_imp.id(137372043909651926)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'mostrarBarra();',
'apex.item( "P138_ENVIO_EXITO" ).setValue(0);',
'if(this.data.G_EXITO==''true''){',
'     apex.item("P138_ENVIO_EXITO").setValue(1);',
'    mensaje(''exito'', this.data.G_MENSAJE);',
'    if(isTerminoFlujo){',
'        apex.item("P138_TERMINO").setValue(1);',
'    }',
'}',
'else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}',
'',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(137372290981651928)
,p_event_id=>wwv_flow_imp.id(137372043909651926)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :p138_envio_exito = 1 then',
'	if :p138_objeto = ''NEGOCIACIONEXP'' then',
'		update t_comp_negociacion set estadoflujo = ''APROBADO'', vigenciahasta = vigenciahastaant, vigenciahastaant = null',
'		where id = :p138_id_negociacion;',
'	else',
'		data.pk_comp_negociacion.sp_rechazarnegociacion(p_compania => :g_compania, p_usuario => :p138_usuario, p_idneg => :p138_id_negociacion);',
'	end if;',
'	commit;',
'end if;'))
,p_attribute_02=>'P138_ENVIO_EXITO,P138_ID_NEGOCIACION,P138_TIPO_NEGOCIACION,P138_USUARIO,P138_OBJETO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240223213105Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(137372319873651929)
,p_event_id=>wwv_flow_imp.id(137372043909651926)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if(this.data.G_EXITO==''true''){',
'    ocultarBarra();',
'    $(''#btnAtras'').trigger("click");',
'    $(''#btnAprobar'').hide();',
'    $(''#btnRechazar'').hide();',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(140642595968536247)
,p_name=>unistr('Cierre di\00E1logo: env\00EDo flujo')
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(140642413383536246)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'Number($v("P138_VALIDAR"))==0;'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_updated_on=>wwv_flow_imp.dz('20240909033246Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140642648714536248)
,p_event_id=>wwv_flow_imp.id(140642595968536247)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'console.log(trama);',
'console.log(isTerminoFlujo);',
'apex.item( "P138_TERMINA_FLUJO" ).setValue(0);',
'apex.item( "P138_ENVIO_EXITO" ).setValue(0);',
'console.log(this.data.G_EXITO);',
'if(this.data.G_EXITO==''true''){',
'     mensaje(''exito'', this.data.G_MENSAJE);',
'     apex.item("P138_ENVIO_EXITO" ).setValue(1);',
'    if(isTerminoFlujo){',
'        apex.item( "P138_TERMINA_FLUJO" ).setValue(1);',
'    }',
'}',
'else{ ',
'     mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140735345157225102)
,p_event_id=>wwv_flow_imp.id(140642595968536247)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_valida	number;',
'v_estado	varchar2(20);',
'v_idneg		number;',
'begin',
'	v_idneg := :p138_id_negociacion;',
'	if :p138_envio_exito = 1 then ',
'		v_estado := case when nvl(:p138_termina_flujo,0) = 1 then ''APROBADO'' else ''EN_PROCESO'' end;',
'',
'		:p138_es_edicion:=-1;',
'',
'		insert into t_tmp_a (flag,num01,num02,num03)',
'		select ''DET_APRB''',
'			, neg_id',
'			, cab_id',
'			, det_id',
'		from vt_comp_negociacion',
'		where neg_id = v_idneg',
'			and neg_estadoflujo = ''APROBADO''',
'			and cab_estadoflujo = ''APROBADO''',
'			and det_estadoflujo = ''CREACION''',
'			and neg_id = v_idneg',
'			and cab_id = :p138_id_cabecera;',
'',
'		update t_comp_negociaciondet	set estadoflujo = v_estado, usuarioflujo = :p138_usuario where id in (select num03 from t_tmp_a);',
'		update t_comp_negociacion		set estadoflujo = v_estado, usuarioflujo = :p138_usuario where id in (select num01 from t_tmp_a);',
'		commit;',
'',
'		if v_estado = ''EN_PROCESO'' then',
'			pk_comp_negociacion.sp_historialocs(p_compania => :g_compania, p_usuario => :app_user, p_idneg => v_idneg);',
'		end if;',
'	end if;',
'end;'))
,p_attribute_02=>'P138_ENVIO_EXITO,P138_TERMINA_FLUJO,P138_ID_CABECERA,P138_ID_NEGOCIACION,P138_USUARIO'
,p_attribute_03=>'P138_ES_EDICION'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240909033246Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140735487670225103)
,p_event_id=>wwv_flow_imp.id(140642595968536247)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v("P138_ENVIO_EXITO")==1){',
'    $(''#btnValidar'').hide();',
'    $(''#btnEnviar'').hide();',
'    $(''#btnAtras'').trigger("click");',
'} ',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(140735607818225105)
,p_name=>'Valida Envio Flujo'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(140735565110225104)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140735765385225106)
,p_event_id=>wwv_flow_imp.id(140735607818225105)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_valida number;',
'begin',
'    v_valida:=0;',
'    :P138_VALIDAR:=v_valida;    ',
'    if(v_valida=0) then  ',
'        v_valida:= PK_COMP_NEGOCIACION.F_NEG_VALIDA_NEGVSCAB(:P138_ID_NEGOCIACION);',
'         DBMS_OUTPUT.PUT_LINE(''PK_COMP_NEGOCIACION.F_NEG_VALIDA_NEGVSCAB:''||v_valida);',
'    end if;',
'    if(v_valida=0) then  ',
'        v_valida:= PK_COMP_NEGOCIACION.F_NEG_VALIDA_NEGVSDET(:P138_ID_NEGOCIACION);',
'         DBMS_OUTPUT.PUT_LINE(''PK_COMP_NEGOCIACION.F_NEG_VALIDA_NEGVSDET:''||v_valida);',
'    end if;',
'    if(v_valida=0) then  ',
'        v_valida:= PK_COMP_NEGOCIACION.F_NEG_VALIDA_CABVSDET(:P138_ID_NEGOCIACION);',
'         DBMS_OUTPUT.PUT_LINE(''PK_COMP_NEGOCIACION.F_NEG_VALIDA_CABVSDET:''||v_valida);',
'    end if;',
'    if(v_valida=0) then  ',
'        v_valida:= PK_COMP_NEGOCIACION.F_NEG_VALIDAVIGENCIA (:P138_ID_NEGOCIACION); ',
'        DBMS_OUTPUT.PUT_LINE(''PK_COMP_NEGOCIACION.F_NEG_VALIDAVIGENCIA:''||v_valida);',
'    end if;',
'    if(v_valida=0) then  ',
'        v_valida:= PK_COMP_NEGOCIACION.F_NEG_VALIDADETALLE_APROBADAS(:P138_ID_NEGOCIACION);',
'         DBMS_OUTPUT.PUT_LINE(''PK_COMP_NEGOCIACION.F_NEG_VALIDADETALLE_APROBADAS:''||v_valida);',
'    end if;',
'    if(v_valida=0) then  ',
'        v_valida:= PK_COMP_NEGOCIACION.F_NEG_VALIDAMISMODETALLE(:P138_ID_NEGOCIACION);',
'        DBMS_OUTPUT.PUT_LINE(''PK_COMP_NEGOCIACION.F_NEG_VALIDAMISMODETALLE:''||v_valida);',
'    end if;',
'    :P138_VALIDAR:=v_valida;',
'    if (:P138_VALIDAR is null)then',
'    :P138_VALIDAR:=0;',
'    end if;',
'     :P138_VALIDAR:=0;',
'end;'))
,p_attribute_02=>'P138_ID_NEGOCIACION'
,p_attribute_03=>'P138_VALIDAR'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140735849684225107)
,p_event_id=>wwv_flow_imp.id(140735607818225105)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'valida = $v("P138_VALIDAR");',
'if (valida==0){',
'    $("#btnEnviar").trigger("click");',
'}',
'else if(valida==1){',
'    mensaje(''error'',''Negociacion se cruza con una existente Aprobada/Vigente'');',
'}',
'else if(valida==2){',
'    mensaje(''error'',''Variables de la presente negociacion se cruza con una existente Aprobada/Vigente'');',
'}',
'else if(valida==3){',
'    mensaje(''error'',''Variables en detalle de la presente negociacion se cruza con una existente Aprobada/Vigente'');',
'}',
'else if(valida==4){',
'    mensaje(''error'',''Fecha de vigencia ingresadas se sobreponen a las negociaciones Aprobadas/Vigentes'');',
'}',
'else if(valida==5){',
unistr('    mensaje(''error'',''Uno de sus detalles se equipara a una negociaci\00F3n Aprobadas/Vigentes'');'),
'}',
'else if(valida==6){',
unistr('    mensaje(''error'',''Uno de sus detalles se equipara a otro dentro de esta misma negociaci\00F3n'');'),
'}',
'$s("P138_VALIDAR","");',
'ocultarBarra();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(140736351561225112)
,p_name=>'Columa EDITAR: Cerrar cuadro dialogo en columna'
,p_event_sequence=>60
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(133923357418985519)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140737120307225120)
,p_event_id=>wwv_flow_imp.id(140736351561225112)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(48005278046361921)
,p_name=>'BorrarAprobado'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(48005165732361920)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48005315899361922)
,p_event_id=>wwv_flow_imp.id(48005278046361921)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEsta seguro de eliminar una negociaci\00F3n aprobada?')
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-question'
,p_attribute_06=>unistr('S\00CD')
,p_attribute_07=>'NO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48005690309361925)
,p_event_id=>wwv_flow_imp.id(48005278046361921)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE v_exito number;',
'BEGIN',
'    PK_COMP_NEGOCIACION.sp_borrarnegociacionaprobada (',
'                :p138_id_negociacion,',
'                v_exito',
'            );',
'            :P138_BORROAPROBADA:= v_exito;',
'END;',
''))
,p_attribute_02=>'P138_ID_NEGOCIACION'
,p_attribute_03=>'P138_BORROAPROBADA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48005791445361926)
,p_event_id=>wwv_flow_imp.id(48005278046361921)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
' if ($v("P138_BORROAPROBADA")>0){',
'    $(''#btnAtras'').trigger("click");',
unistr('    mensaje(''exito'',''Negociaci\00F3n N.:''+$v("p138_idnegociacion_nuevo")+'' eliminada correctamente'');'),
'}else{',
unistr('    mensaje(''error'',''Error en borrar negociaci\00F3n, favor comuniquese con su administrador'');'),
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(119041108339330414)
,p_name=>'Edita Datos'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(119041020700330413)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(119041248113330415)
,p_event_id=>wwv_flow_imp.id(119041108339330414)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Valida Datos '
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let v_mensaje="";',
'var v_codproductoprv=$v("P138_CODPRODUCTOPRV");',
'var v_desproductoprv=$v("P138_DESPRODUCTOPRV");',
'let v_validar=1;',
'',
'if (v_codproductoprv==""){',
'    v_validar=0;',
unistr('    v_mensaje= v_mensaje+("c\00F3digo de producto proveedor debe tener valor<br/>");'),
'}',
'if (v_desproductoprv==""){',
'    v_validar=0;',
unistr('    v_mensaje=v_mensaje+("descripci\00F3n de producto proveedor debe tener valor<br/>");'),
'}',
'if (v_validar==0){',
'    mensajeError(v_mensaje);',
'}',
'$s("P138_VALIDAR",v_validar);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(119041714135330420)
,p_event_id=>wwv_flow_imp.id(119041108339330414)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Editar datos'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update t_comp_negociaciondet',
'set ',
'CODPRODUCTOPRV=trim(:P138_CODPRODUCTOPRV),',
'DESPRODUCTOPRV=trim(:P138_DESPRODUCTOPRV)',
'where id= :P138_ID_DETALLE;',
'sp_negociacion_facturas(0);'))
,p_attribute_02=>'P138_CODPRODUCTOPRV,P138_DESPRODUCTOPRV,P138_ID_DETALLE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(119041897407330421)
,p_event_id=>wwv_flow_imp.id(119041108339330414)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'cerrarDialogo'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'closeModal(''editDetalle'');',
'//apex.region("Detalle").refresh();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(138958521114199202)
,p_name=>'Cancelar Negociacion'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(132270477325622540)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>':P138_ESTADO_FLUJO NOT IN (''VIGENTE'',''APROBADO'')'
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(138958635164199203)
,p_event_id=>wwv_flow_imp.id(138958521114199202)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#btnAtras'').trigger("click");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(141065720147133033)
,p_name=>'CloseDialogCambioFecha'
,p_event_sequence=>120
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(141063076285133006)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>':P138_ESTADO_FLUJO NOT IN (''VIGENTE'',''APROBADO'')'
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(141065884140133034)
,p_event_id=>wwv_flow_imp.id(141065720147133033)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    $(''#btnAtras'').trigger("click");',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(145673416080365224)
,p_name=>'New'
,p_event_sequence=>130
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P138_IRMESA'
,p_display_when_cond2=>'1'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(145673546571365225)
,p_event_id=>wwv_flow_imp.id(145673416080365224)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#btnAtras'').trigger("click");'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(139897985524798815)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Negociacion - Copiar '
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_COMP_NEGOCIACION.sp_copiarnegociacion (',
'            :p138_id_negociacion,',
'            :p138_usuario,',
'            :p138_idnegociacion_nuevo',
'        );',
'if (:p138_idnegociacion_nuevo>0)then',
unistr('    apex_application.g_print_success_message :=''Negociaci\00F3n N.:''||:p138_idnegociacion_nuevo||'' generada correctamente'';'),
'else',
'    apex_error.add_error (',
unistr('        p_message          => ''Error en copiar negociaci\00F3n, favor comuniquese con su administrador'','),
'        p_display_location =>apex_error.c_inline_in_notification ',
'    );',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(139897883222798814)
,p_internal_uid=>139897985524798815
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(135559832282707438)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Setup Interface'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_contador number;',
'v_idnegociacion number;',
'v_tipo varchar2(50);',
'v_objeto_descripcion	varchar2(500);',
'v_log_app	varchar2(100);',
'v_log_dsc	varchar2(999);',
'v_log_msg	varchar2(999);',
'v_log_obs	varchar2(999);',
'begin',
'	v_log_app := ''apex.130.138.setup'';',
'	:p138_tipo2				:= null;',
'	if :g_detalle_id is not null and :g_token is not null then -- Aprobacion con token (desde link del correo)',
'		v_log_dsc := ''Enlace: g_detalle_id: ''||:g_detalle_id||'', g_token: ''||:g_token;',
'		pk_corp_flujoaprobacion.sp_buscaraprobacion(:g_detalle_id,:g_token,:g_compania,:p138_aprobador,v_tipo,:g_idnegociacion);',
'',
'		select decode(estadoflujo,''EN_PROCESO'',''EN RUTA'',estadoflujo) into :p138_estado_flujo from t_comp_negociacion where id = :g_idnegociacion;',
'',
'		:p138_usuario := :p138_aprobador;',
'',
'		begin',
'			select entidad_clase into :p138_objeto',
'			from t_flujo_aprobacion_cab a',
'				inner join t_flujo_aprobacion_det b on a.id = b.flujo_id where b.id = :g_detalle_id and b.token = :g_token;',
'',
'			exception when others then :p138_objeto := ''NEGOCIACION'';',
'		end;',
'		v_log_dsc := v_log_dsc||'', g_compania: ''||:g_compania||'', g_idnegociacion: ''||:g_idnegociacion||'', v_tipo: ''||v_tipo||'', p138_aprobador: ''||:p138_aprobador;',
'		v_log_dsc := v_log_dsc||'', p138_objeto: ''||:p138_objeto;',
'	else',
'		:p138_usuario		:= :app_user;',
'		:p138_aprobador 	:= :app_user;',
'		:p138_pagretorno	:= :g_pagnegociacion;',
unistr('		v_log_dsc			:= ''Aplicaci\00F3n: p138_usuario: ''||:p138_usuario||'', p138_aprobador: ''||:p138_aprobador||'', p138_pagretorno: ''||:p138_pagretorno;'),
'	end if;',
'	',
'	v_idnegociacion := to_number(:g_idnegociacion);',
'	:p138_idobjeto := v_idnegociacion;',
'',
'	v_log_dsc := v_log_dsc||'', p138_idobjeto: ''||:p138_idobjeto||'', v_idnegociacion: ''||v_idnegociacion;',
'',
'	:p138_es_edicion		:= 0;',
'	:p138_edit_negociacion	:= 0;',
'	:p138_id_cabecera		:= 0;',
'	:p138_es_aprobador		:= 0;',
'	:p138_accioncopiar		:= 0;',
'	:p138_id_negociacion	:= to_number(v_idnegociacion);',
'	:p138_estado_flujo		:= case :p138_estado_flujo when ''APROBADO/VIGENTE'' then ''VIGENTE'' else :p138_estado_flujo end;',
'',
'	begin',
'		select 1 into :p138_bandera_tipo_precio from t_comp_negociacioncab where idneg = v_idnegociacion and tipoprecio = ''FM'' and rownum = 1;',
'',
'		exception when others then :p138_bandera_tipo_precio := 0;',
'	end;',
'',
'	if :p138_estado_flujo = ''EN RUTA'' then',
'		select  aprobador ,pk_corp_flujoaprobacion.f_aprobadorflujo(:p138_usuario,aprobador,:app_modulo,:g_compania)',
'		into    :p138_aprobador ,:p138_es_aprobador',
'		from vt_comp_mesatrabajoneg',
'		where to_number(idnegociacion) = to_number(:p138_id_negociacion);',
'	end if;',
'',
'	if :p138_estado_flujo not in (''CANCELADO'',''RECHAZADO'') then',
'		:p138_accioncopiar := pk_admi_gestionparametros.f_admi_accesoacciones(:app_modulo,:p138_usuario,:app_page_id,''COPIAR_APROBADO'');',
'		:p138_es_edicion := pk_admi_gestionparametros.f_admi_accesoacciones(:app_modulo,:p138_usuario,:app_page_id,''EDITAR_APROBADO'');',
'	end if;',
'',
'	v_log_msg := ''p138_estado_flujo: ''||:p138_estado_flujo||'', p138_bandera_tipo_precio: ''||:p138_bandera_tipo_precio;',
'	v_log_msg := v_log_msg||'', p138_aprobador: ''||:p138_aprobador||'', p138_es_aprobador: ''||:p138_es_aprobador;',
'	v_log_msg := v_log_msg||'', p138_accioncopiar: ''||:p138_accioncopiar||'', p138_es_edicion: ''||:p138_es_edicion;',
'',
'	data.pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,v_log_msg,v_log_obs,null);',
'',
'	select tipo,esquema,codesquema,recurrente,periodicidad,vigenciadesde,vigenciahasta,esquema,codesquema,observacion',
'		, frecuencia,numeropagos,tipopago,fechaprimerpago,tiporecepcion,tipomonto',
'	into   :p138_tipo_negociacion,:p138_esquema,:p138_cod_esquema,:p138_recurrente,:p138_periodicidad,:p138_vigencia_desde,:p138_vigencia_hasta,:p138_esquema_act,:p138_cod_esquema_act,:p138_observacion',
'		, :p138_frecuencia,:p138_numeropagos,:p138_tipopago,:p138_fechaprimerpago,:p138_tiporecepcion,:p138_tipomonto',
'	from   t_comp_negociacion n',
'	where to_number(id) = to_number(:p138_id_negociacion);',
'',
unistr('	v_objeto_descripcion := ''Negociaci\00F3n'';'),
'',
'	if nvl(:p138_recurrente,''NO'') = ''SI'' then',
'		v_objeto_descripcion	:= v_objeto_descripcion||'' de Pago Recurrente'';',
'		:p138_tipo2				:= ''CN'';',
'',
'		begin',
'			select to_char(:p138_numeropagos*sum(nvl(det_preciocal,0)),''FML999G999G999G999G990D00'') into :p138_costo',
'			from vt_comp_negociaciondet where neg_recurrente = ''SI'' and neg_tipomonto = ''FJ'' and neg_id = v_idnegociacion;',
'',
'			exception when others then :p138_costo := 0;',
'		end;',
'',
'		begin',
'			select trim(apellidos)||'' ''||trim(nombres) into :p138_requisitor',
'			from t_corp_udc a inner join vt_corp_usuario b on a.valor = b.nombreusuario and a.id_cabecera = ''COMP_PRRSP''',
'			where a.id_tabla = lpad(v_idnegociacion,5,''0'') and rownum = 1;',
'',
'			exception when others then :p138_requisitor := null;',
'		end;',
'	end if;',
'	v_objeto_descripcion := v_objeto_descripcion||'' con vigencia entre ''||:p138_vigencia_desde||'' - ''||:p138_vigencia_hasta;',
'',
'	:p138_objeto_descripcion := v_objeto_descripcion;',
'',
'	exception when others then ',
'		:g_idnegociacion := null;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>135559832282707438
,p_updated_on=>wwv_flow_imp.dz('20260105213034Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
