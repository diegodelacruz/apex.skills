prompt --application/pages/page_00132
begin
--   Manifest
--     PAGE: 00132
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>132
,p_name=>'Saldo Inventario'
,p_step_title=>'Saldo Inventario'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230708132654Z')
,p_last_updated_on=>wwv_flow_imp.dz('20230419195731Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(250533565434615206)
,p_plug_name=>unistr('Par\00E1metros')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(250534015972615211)
,p_plug_name=>'Reporte'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select txt01 codbodega',
'	, num01 anno',
'	, num02 mes',
'	, num03 codcorto',
'	, num04 cantidad',
'	, num05 cantidadacm',
'	, num06 monto',
'	, num07 montoacm',
'	, decode(nvl(num05,0),0,0,num07/num05) precio',
'	, txt02 codproducto',
'	, txt03 producto',
'	, txt04 codcategoria',
'	, txt05 codtipo',
'	, txt06 codclase',
'	, txt06 categoria',
'	, txt07 tipo',
'	, txt08 clase',
'from data.t_apex_temporal',
'where control01 = :g_compania and control02 = :app_modulo and control03 = :app_user and control04 = ''data.pk_comp_reportes.sp_saldoinventario'';'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(250534121000615212)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'CSV:HTML:XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>250534121000615212
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250534218347615213)
,p_db_column_name=>'CODBODEGA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>unistr('C\00F3d. Bodega')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250534338360615214)
,p_db_column_name=>'ANNO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>unistr('A\00F1o')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250534445707615215)
,p_db_column_name=>'MES'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Mes'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250534513768615216)
,p_db_column_name=>'CODCORTO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>unistr('C\00F3d. Corto')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250534609930615217)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250534760996615218)
,p_db_column_name=>'CANTIDADACM'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Cant. Acm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250534815164615219)
,p_db_column_name=>'MONTO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999999999999990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250534983655615220)
,p_db_column_name=>'MONTOACM'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Monto Acm.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999999999999990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250535047322615221)
,p_db_column_name=>'CODPRODUCTO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>unistr('C\00F3d. Producto')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250535151953615222)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250535296735615223)
,p_db_column_name=>'CODCATEGORIA'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>unistr('C\00F3d. Categor\00EDa')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250535312531615224)
,p_db_column_name=>'CODCLASE'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>unistr('C\00F3d. Clase')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250535424386615225)
,p_db_column_name=>'CATEGORIA'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>unistr('Categor\00EDa')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250535550389615226)
,p_db_column_name=>'CLASE'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Clase'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250535684180615227)
,p_db_column_name=>'PRECIO'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999999999999990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250129910150278335)
,p_db_column_name=>'CODTIPO'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>unistr('C\00F3d. Tipo')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250130089547278336)
,p_db_column_name=>'TIPO'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(271011411492941665)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2710115'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODBODEGA:ANNO:MES:CODPRODUCTO:PRODUCTO:TIPO:CATEGORIA:CANTIDAD:CANTIDADACM:MONTO:MONTOACM:PRECIO:'
,p_sort_column_1=>'CODBODEGA'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'ANNO'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'MES'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'CODPRODUCTO'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20230708132654Z')
,p_updated_on=>wwv_flow_imp.dz('20230708132654Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1351947883992464126)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(270984992918768921)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1351947883992464126)
,p_button_name=>'BUSCAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(250129800878278334)
,p_name=>'P132_TIPO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(250533565434615206)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_coderp number;',
'begin',
'	begin',
'		select pdanby into v_coderp',
'		from f4311@jdedtadl, vt_corp_usuario',
'		where pdanby = coderp and nombreusuario = :app_user and pddcto in (''CM'',''BM'',''CE'',''CN'', ''BN'',''OI'')',
'        and pdtrdj between data.pk_commons.f_g2jde(:p132_fechadesde) and data.pk_commons.f_g2jde(:p132_fechahasta)',
'        and rownum = 1;',
'',
'		exception when no_data_found then v_coderp := null;',
'	end;',
'',
'	return v_coderp;',
'end;'))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Tipo:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct txt04, txt03 from data.t_apex_temporal',
'where control01 = :g_compania and control02 = :app_modulo and control03 = :app_user and control04 = ''apex.130.132.prerendering''',
'order by 1;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(270986970041776282)
,p_name=>'P132_FECHADESDE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(250533565434615206)
,p_item_default=>'trunc(add_months(sysdate,-1),''month'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Desde:'
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(270987347385776282)
,p_name=>'P132_FECHAHASTA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(250533565434615206)
,p_item_default=>'sysdate'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Hasta:'
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(270987717875776285)
,p_name=>'P132_DIVISION'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(250533565434615206)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_coderp number;',
'begin',
'	begin',
'		select pdanby into v_coderp',
'		from f4311@jdedtadl, vt_corp_usuario',
'		where pdanby = coderp and nombreusuario = :app_user and pddcto in (''CM'',''BM'',''CE'',''CN'', ''BN'',''OI'')',
'        and pdtrdj between data.pk_commons.f_g2jde(:p132_fechadesde) and data.pk_commons.f_g2jde(:p132_fechahasta)',
'        and rownum = 1;',
'',
'		exception when no_data_found then v_coderp := null;',
'	end;',
'',
'	return v_coderp;',
'end;'))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>unistr('Categor\00EDa:')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct txt02, txt01 from data.t_apex_temporal',
'where control01 = :g_compania and control02 = :app_modulo and control03 = :app_user and control04 = ''apex.130.132.prerendering'' and txt03 = :p132_tipo',
'order by 1;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_cascade_parent_items=>'P132_TIPO'
,p_ajax_items_to_submit=>'P132_TIPO'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(250533678678615207)
,p_name=>'Buscar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(270984992918768921)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(250533790063615208)
,p_event_id=>wwv_flow_imp.id(250533678678615207)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra()'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(250533968721615210)
,p_event_id=>wwv_flow_imp.id(250533678678615207)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	pk_comp_reportes.sp_saldoinventario(',
'		p_compania		=> :g_compania',
'		, p_usuario		=> :app_user',
'		, p_division	=> :p132_division',
'		, p_tipo		=> :p132_tipo',
'		, p_desde		=> :p132_fechadesde',
'		, p_hasta		=> :p132_fechahasta',
'	);',
'end;'))
,p_attribute_02=>'P132_DIVISION,P132_TIPO,P132_FECHADESDE,P132_FECHAHASTA'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(250535717515615228)
,p_event_id=>wwv_flow_imp.id(250533678678615207)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(250534015972615211)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(250533844260615209)
,p_event_id=>wwv_flow_imp.id(250533678678615207)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra()'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(250130366530278339)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Separador'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	execute immediate ''ALTER SESSION SET NLS_NUMERIC_CHARACTERS =''''.,'''''';',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>250130366530278339
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(250130268406278338)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Categoir\00EDas')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_log_app varchar2(100);',
'begin',
'	v_log_app := ''apex.130.132.prerendering'';',
'	insert into data.t_apex_temporal (flag,control01,control02,control03,control04,txt01,txt02,txt03,txt04)',
'	select distinct ''APEX'',:g_compania,:app_modulo,:app_user,v_log_app,trim(imprp4) imprp4, a.drdl01||'' (''||a.drky||'')'', trim(imprp7) imprp7, b.drdl01||'' (''||b.drky||'')''',
'	from f4101@jdedtadl',
'	inner join vt_jde_udcjde a on a.drsy = ''41'' and a.drrt = ''P4'' and trim(imprp4) = a.drky',
'	inner join vt_jde_udcjde b on b.drsy = ''41'' and b.drrt = ''02'' and trim(imprp7) = b.drky;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>250130268406278338
);
wwv_flow_imp.component_end;
end;
/
