prompt --application/pages/page_00135
begin
--   Manifest
--     PAGE: 00135
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>135
,p_name=>'Req. Pendiente'
,p_step_title=>'Req. Pendiente'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230808134140Z')
,p_last_updated_on=>wwv_flow_imp.dz('20250721162056Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(810761285132717009)
,p_plug_name=>'Reporte'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'	clob01 json_completo',
unistr('	-- Campos extra\00EDdos del JSON (solo cuando exito = 1)'),
'	, case when json_value(clob01, ''$.exito'') = ''1'' then json_value(clob01, ''$.goc_id'') else null end as json_goc_id',
'	, case when json_value(clob01, ''$.exito'') = ''1'' then json_value(clob01, ''$.pddcto'') else null end as json_pddcto',
'	, case when json_value(clob01, ''$.exito'') = ''1'' then json_value(clob01, ''$.pddoco'') else null end as json_pddoco',
'	, case when json_value(clob01, ''$.exito'') = ''1'' then json_value(clob01, ''$.pddcto'')||''-''||json_value(clob01, ''$.pddoco'') else null end as ultorden',
'	, case when json_value(clob01, ''$.exito'') = ''1'' then json_value(clob01, ''$.pdlnid'') else null end as json_pdlnid',
'	, case when json_value(clob01, ''$.exito'') = ''1'' then data.pk_commons.safe_to_number(json_value(clob01, ''$.qtyorg'')) else null end as json_qtyorg',
'	, case when json_value(clob01, ''$.exito'') = ''1'' then data.pk_commons.safe_to_number(json_value(clob01, ''$.qtyman'')) else null end as json_qtyman',
'	, case when json_value(clob01, ''$.exito'') = ''1'' then data.pk_commons.safe_to_number(json_value(clob01, ''$.prcman'')) else null end as json_prcman',
'	, case when json_value(clob01, ''$.exito'') = ''1'' then data.pk_commons.safe_to_number(json_value(clob01, ''$.prcman'')) else null end as ultprecio',
'	, case when json_value(clob01, ''$.exito'') = ''1'' then json_value(clob01, ''$.goc_fecha'') else null end as json_goc_fecha',
'	, case when json_value(clob01, ''$.exito'') = ''1'' then json_value(clob01, ''$.pdoorn'') else null end as json_pdoorn',
'	, case when json_value(clob01, ''$.exito'') = ''1'' then json_value(clob01, ''$.pdocto'') else null end as json_pdocto',
'	, case when json_value(clob01, ''$.exito'') = ''1'' then json_value(clob01, ''$.pdogno'') else null end as json_pdogno',
'	, case when json_value(clob01, ''$.exito'') = ''1'' then json_value(clob01, ''$.pdlitm'') else null end as json_pdlitm',
'	, case when json_value(clob01, ''$.exito'') = ''1'' then json_value(clob01, ''$.neg_id'') else null end as json_neg_id',
'	, case when json_value(clob01, ''$.exito'') = ''1'' then json_value(clob01, ''$.neg_vigenciadesde'') else null end as json_neg_vigenciadesde',
'	, case when json_value(clob01, ''$.exito'') = ''1'' then json_value(clob01, ''$.neg_vigenciahasta'') else null end as json_neg_vigenciahasta',
'	, pk_comp_ordenescompra.f_comentario@jdedtadl(control01,p_tipooc=>txt01,p_ordencompra=>num01,p_tipo=>''A'',p_linea=>num04) infoadicional',
'	, num01 requisicion',
'	, txt01 tiporq',
'	, num02 codrequisitor',
'	, txt02 requisitor',
'	, fecha03 fecharq',
'	, trunc(sysdate) - fecha03 dias',
'	, num04/1000 linea',
'	, num05 codcorto',
'	, txt05 codproducto',
'	, num06 codcortoa',
'	, txt06 codproductoa',
'	, txt07 productorq',
'	, num08 cantidad',
'	-- , num09 ultprecio',
'	, num10 validador',
'	-- , txt10 ultorden',
'	, num11 codproveedor',
'	, txt11 proveedor',
'	, txt08 infoproveedor',
'	, txt12 producto',
'	, txt13 um',
'	, case when txt12 = txt07 then 1 else 0 end difdesc',
'	, data.pk_jde_inventario.f_disponibleproducto(txt05,null) inventarioactual',
'from data.t_apex_temporal',
'where 1 = 1',
'	and flag = ''A''',
'	and control01 = :g_compania',
'	and control02 = :app_modulo',
'	and control03 = :app_user',
'	and control04 = ''data.pk_comp_reportes.sp_requisicionespendientes'''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_updated_on=>wwv_flow_imp.dz('20250721162056Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(810761390160717010)
,p_max_row_count=>'1000000'
,p_max_rows_per_page=>'1000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>810761390160717010
,p_updated_on=>wwv_flow_imp.dz('20250721162056Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(285858649987809723)
,p_db_column_name=>'CODCORTO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>unistr('C\00F3d. Corto')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(285859053125809723)
,p_db_column_name=>'CODPRODUCTO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>unistr('C\00F3d. Producto')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(285856687975809716)
,p_db_column_name=>'REQUISICION'
,p_display_order=>160
,p_column_identifier=>'R'
,p_column_label=>unistr('Requisici\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(285857036947809723)
,p_db_column_name=>'CODREQUISITOR'
,p_display_order=>210
,p_column_identifier=>'W'
,p_column_label=>unistr('C\00F3d. Requisitor')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(285857844519809723)
,p_db_column_name=>'CODPROVEEDOR'
,p_display_order=>230
,p_column_identifier=>'Y'
,p_column_label=>unistr('C\00F3d. Proveedor')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(285858207708809723)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>240
,p_column_identifier=>'Z'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(285859845966809723)
,p_db_column_name=>'REQUISITOR'
,p_display_order=>310
,p_column_identifier=>'AG'
,p_column_label=>'Requisitor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(285860602600809725)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>340
,p_column_identifier=>'AJ'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(285863083821809727)
,p_db_column_name=>'TIPORQ'
,p_display_order=>400
,p_column_identifier=>'AP'
,p_column_label=>'Tipo RQ'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(285863483679809727)
,p_db_column_name=>'FECHARQ'
,p_display_order=>410
,p_column_identifier=>'AQ'
,p_column_label=>'Fecha RQ'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274406955218425809)
,p_db_column_name=>'DIAS'
,p_display_order=>420
,p_column_identifier=>'AS'
,p_column_label=>unistr('D\00EDas')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274407048709425810)
,p_db_column_name=>'LINEA'
,p_display_order=>430
,p_column_identifier=>'AT'
,p_column_label=>unistr('L\00EDnea')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274407131186425811)
,p_db_column_name=>'CODCORTOA'
,p_display_order=>440
,p_column_identifier=>'AU'
,p_column_label=>unistr('C\00F3d. Corto Ant.')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274407208243425812)
,p_db_column_name=>'CODPRODUCTOA'
,p_display_order=>450
,p_column_identifier=>'AV'
,p_column_label=>unistr('C\00F3d. Anterior')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274407340887425813)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>460
,p_column_identifier=>'AW'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274407546325425815)
,p_db_column_name=>'VALIDADOR'
,p_display_order=>480
,p_column_identifier=>'AY'
,p_column_label=>'Validador'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274407667100425816)
,p_db_column_name=>'ULTORDEN'
,p_display_order=>490
,p_column_identifier=>'AZ'
,p_column_label=>unistr('\00DAlt. OC')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(71364581388493126)
,p_db_column_name=>'INFOPROVEEDOR'
,p_display_order=>500
,p_column_identifier=>'BA'
,p_column_label=>'Info. Proveedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(411015537742960538)
,p_db_column_name=>'PRODUCTORQ'
,p_display_order=>510
,p_column_identifier=>'BC'
,p_column_label=>'Producto RQ'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240913164839Z')
,p_updated_on=>wwv_flow_imp.dz('20240913164839Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(411015627074960539)
,p_db_column_name=>'DIFDESC'
,p_display_order=>520
,p_column_identifier=>'BD'
,p_column_label=>'Dif. Desc.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240913165627Z')
,p_updated_on=>wwv_flow_imp.dz('20240913165627Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(110390130856827609)
,p_db_column_name=>'JSON_COMPLETO'
,p_display_order=>530
,p_column_identifier=>'BE'
,p_column_label=>'Json Completo'
,p_column_type=>'CLOB'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250718220711Z')
,p_updated_on=>wwv_flow_imp.dz('20250718220711Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(110390206291827610)
,p_db_column_name=>'JSON_GOC_ID'
,p_display_order=>540
,p_column_identifier=>'BF'
,p_column_label=>'Json Goc Id'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250718220711Z')
,p_updated_on=>wwv_flow_imp.dz('20250718220711Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(110390377522827611)
,p_db_column_name=>'JSON_PDDCTO'
,p_display_order=>550
,p_column_identifier=>'BG'
,p_column_label=>'Json Pddcto'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250718220711Z')
,p_updated_on=>wwv_flow_imp.dz('20250718220711Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(110390468141827612)
,p_db_column_name=>'JSON_PDDOCO'
,p_display_order=>560
,p_column_identifier=>'BH'
,p_column_label=>'Json Pddoco'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250718220711Z')
,p_updated_on=>wwv_flow_imp.dz('20250718220711Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(110390502033827613)
,p_db_column_name=>'JSON_PDLNID'
,p_display_order=>570
,p_column_identifier=>'BI'
,p_column_label=>'Json Pdlnid'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250718220711Z')
,p_updated_on=>wwv_flow_imp.dz('20250718220711Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(110391029415827618)
,p_db_column_name=>'JSON_GOC_FECHA'
,p_display_order=>620
,p_column_identifier=>'BN'
,p_column_label=>unistr('Fecha \00DAlt. OC')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250718220712Z')
,p_updated_on=>wwv_flow_imp.dz('20250718220829Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(110391179526827619)
,p_db_column_name=>'JSON_PDOORN'
,p_display_order=>630
,p_column_identifier=>'BO'
,p_column_label=>'Json Pdoorn'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250718220712Z')
,p_updated_on=>wwv_flow_imp.dz('20250718220712Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(110391236981827620)
,p_db_column_name=>'JSON_PDOCTO'
,p_display_order=>640
,p_column_identifier=>'BP'
,p_column_label=>'Json Pdocto'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250718220712Z')
,p_updated_on=>wwv_flow_imp.dz('20250718220829Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(110391306912827621)
,p_db_column_name=>'JSON_PDOGNO'
,p_display_order=>650
,p_column_identifier=>'BQ'
,p_column_label=>'Json Pdogno'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250718220712Z')
,p_updated_on=>wwv_flow_imp.dz('20250718220712Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(110391465265827622)
,p_db_column_name=>'JSON_PDLITM'
,p_display_order=>660
,p_column_identifier=>'BR'
,p_column_label=>'Json Pdlitm'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250718220712Z')
,p_updated_on=>wwv_flow_imp.dz('20250718220712Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(110391547472827623)
,p_db_column_name=>'JSON_NEG_ID'
,p_display_order=>670
,p_column_identifier=>'BS'
,p_column_label=>'ID Neg.'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250718220712Z')
,p_updated_on=>wwv_flow_imp.dz('20250718220829Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(110391616560827624)
,p_db_column_name=>'JSON_NEG_VIGENCIADESDE'
,p_display_order=>680
,p_column_identifier=>'BT'
,p_column_label=>'Json Neg Vigenciadesde'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250718220712Z')
,p_updated_on=>wwv_flow_imp.dz('20250718220712Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(110391731396827625)
,p_db_column_name=>'JSON_NEG_VIGENCIAHASTA'
,p_display_order=>690
,p_column_identifier=>'BU'
,p_column_label=>'Json Neg Vigenciahasta'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250718220712Z')
,p_updated_on=>wwv_flow_imp.dz('20250718220712Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(110391839953827626)
,p_db_column_name=>'UM'
,p_display_order=>700
,p_column_identifier=>'BV'
,p_column_label=>'UM'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250718220829Z')
,p_updated_on=>wwv_flow_imp.dz('20250718220829Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(110391902204827627)
,p_db_column_name=>'JSON_QTYORG'
,p_display_order=>710
,p_column_identifier=>'BW'
,p_column_label=>'Cant. Solicitada'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250718222151Z')
,p_updated_on=>wwv_flow_imp.dz('20250721153307Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(110392052860827628)
,p_db_column_name=>'JSON_QTYMAN'
,p_display_order=>720
,p_column_identifier=>'BX'
,p_column_label=>'Cant. Manual'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250718222151Z')
,p_updated_on=>wwv_flow_imp.dz('20250721153307Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(110392186319827629)
,p_db_column_name=>'JSON_PRCMAN'
,p_display_order=>730
,p_column_identifier=>'BY'
,p_column_label=>'Precio Man.'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250718222151Z')
,p_updated_on=>wwv_flow_imp.dz('20250721153307Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(110392278895827630)
,p_db_column_name=>'ULTPRECIO'
,p_display_order=>740
,p_column_identifier=>'BZ'
,p_column_label=>unistr('\00DAlt. Precio')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250718222151Z')
,p_updated_on=>wwv_flow_imp.dz('20250721153307Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103818156100660233)
,p_db_column_name=>'INFOADICIONAL'
,p_display_order=>750
,p_column_identifier=>'CA'
,p_column_label=>'Info. Adicional'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250721154801Z')
,p_updated_on=>wwv_flow_imp.dz('20250721154801Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103818238096660234)
,p_db_column_name=>'INVENTARIOACTUAL'
,p_display_order=>760
,p_column_identifier=>'CB'
,p_column_label=>'Inv. Actual'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250721162056Z')
,p_updated_on=>wwv_flow_imp.dz('20250721162056Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(831238680653043463)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2858642'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100
,p_report_columns=>'REQUISICION:TIPORQ:FECHARQ:DIAS:REQUISITOR:CODPRODUCTO:PRODUCTORQ:PRODUCTO:CANTIDAD:ULTORDEN:JSON_GOC_FECHA:PROVEEDOR:JSON_NEG_ID:'
,p_sort_column_1=>'0'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'TIPORQ'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'REQUISICION'
,p_sort_direction_3=>'DESC'
,p_sort_column_4=>'LINEA'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20230808134140Z')
,p_updated_on=>wwv_flow_imp.dz('20250721154928Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1912174141152564465)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(285855661651808249)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1912174141152564465)
,p_button_name=>'BUSCAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(274407759153425817)
,p_name=>'Buscar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(285855661651808249)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(274407855348425818)
,p_event_id=>wwv_flow_imp.id(274407759153425817)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(274407929076425819)
,p_event_id=>wwv_flow_imp.id(274407759153425817)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	pk_comp_reportes.sp_requisicionespendientes(p_compania=>:g_compania,p_usuario=>:app_user);',
'end;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(274408009244425820)
,p_event_id=>wwv_flow_imp.id(274407759153425817)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(810761285132717009)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(274408183151425821)
,p_event_id=>wwv_flow_imp.id(274407759153425817)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp.component_end;
end;
/
