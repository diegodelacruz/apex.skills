prompt --application/pages/page_00300
begin
--   Manifest
--     PAGE: 00300
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>300
,p_name=>'Reporte - Compras Recibidas'
,p_alias=>'COMPRAS-RECIBIDAS'
,p_step_title=>'Compras Recibidas'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.oc-acc details { border: 1px solid #e5e7eb; border-radius: 10px; margin: 10px 0; padding: 8px 10px; background: #fff; }',
'  .oc-acc summary { cursor: pointer; list-style: none; }',
'  .oc-acc summary::-webkit-details-marker { display:none; }',
'  .oc-row { display: grid; grid-template-columns: 2fr repeat(7, 1fr); gap: 8px; align-items: center; }',
'  .oc-h { font-weight: 700; color: #111827; }',
'  .oc-k { color: #6b7280; font-size: 12px; }',
'  .oc-v { font-weight: 600; }',
'  .oc-num { text-align: right; }',
'  .oc-body { margin-top: 10px; padding-top: 10px; border-top: 1px dashed #e5e7eb; }',
'  .oc-meta { display:flex; gap: 18px; flex-wrap: wrap; margin-bottom: 10px; }',
'  .oc-tag { background:#f9fafb; border:1px solid #e5e7eb; border-radius: 999px; padding: 6px 10px; font-size: 12px; }',
'  table.oc-t { width:100%; border-collapse: collapse; }',
'  table.oc-t th, table.oc-t td { border-bottom:1px solid #f3f4f6; padding: 8px; font-size: 12px; }',
'  table.oc-t th { text-align:left; color:#374151; }',
'  table.oc-t td.oc-num, table.oc-t th.oc-num { text-align:right; }',
'/* Esto ya estaba */',
'.t-fht-thead{',
'  overflow: auto !important;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'25'
,p_last_updated_on=>wwv_flow_imp.dz('20260413195207Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(254508569863360316)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(254508899292360319)
,p_plug_name=>'Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(378297191276923533)
,p_plug_name=>'Reportes'
,p_title=>'Reportes'
,p_region_name=>'rptSelector'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:t-TabsRegion-mod--fillLabels:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_imp.id(295637154502037690)
,p_plug_display_sequence=>60
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20260305133847Z')
,p_updated_on=>wwv_flow_imp.dz('20260305143122Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(254815677742713889)
,p_plug_name=>'Compras Recibidas'
,p_region_name=>'rptDetalle'
,p_parent_plug_id=>wwv_flow_imp.id(378297191276923533)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with reporte as (',
'	select num01  as ordencompra',
'		, txt01  as tipooc',
'		, num02  as ordenimportacion',
'		, txt02  as tipooi',
'		, num03  as numlinea',
'		, txt03  as codproveedor',
'		, txt04  as proveedor',
'		, txt05  as codterminospago',
'		, txt06  as terminospago',
'		, txt07  as incoterm',
'		, txt08  as codcortoproducto',
'		, txt09  as codproducto',
'		, txt10  as producto',
'		, txt11  as um',
'		, txt12  as facturaproveedor',
'		, txt13  as refrendo',
'		, fecha01 as fechaingresokardex',
'		, fecha02 as fechaorden',
'		, fecha03 as fechacompromisooriginal',
'		, num10  as totalfactura',
'		, num11  as fobtotal',
'		, num12  as cfr',
'		, num13  as cif',
'		, num14  as fob',
'		, num15  as tasacambio',
'		, num20  as cantsolicitada',
'		, num21  as cantrecibida',
'		, num22  as costounitario',
'		, (num20 * num22) as montoordenado',
'		, (num21 * num22) as montorecibido',
'		, num23  as advalorem',
'		, num24  as almacenaje',
'		, num25  as flete',
'		, num26  as fleteinternacional',
'		, num27  as fodinfa',
'		, num28  as bodegaje',
'		, num29  as honorariosagente',
'		, num30  as isd',
'		, num31  as seguro',
'		, num32  as thc',
'		, num33  as vistobueno',
'		, num34  as factorhumedad',
'		, num35  as revisioncontenedor',
'	from data.t_apex_temporal',
'	inner join data.vt_jde_productos on txt08 = to_char(codigocorto)',
'	where 1 = 1',
'		and flag = ''qry1''',
'		and control01 = :g_compania',
'		and control02 = ''COMP''',
'		and control03 = :app_user',
'		and control04 = ''data.pk_comp_reportes.sp_comprasrecibidas''',
'		and (coddivisionman = :p300_division or :p300_division is null)',
'), calc as (',
'	select r.*',
'		, sum(nvl(r.montorecibido,0)) over (partition by r.ordenimportacion, r.tipooi) as montorecibidototal',
'		, sum(nvl(r.montoordenado,0))  over (partition by r.ordenimportacion, r.tipooi) as montoordenadototal',
'		, decode(',
'			sum(nvl(r.montorecibido,0)) over (partition by r.ordenimportacion, r.tipooi),0, 0,',
'			nvl(r.montorecibido,0)/sum(nvl(r.montorecibido,0)) over (partition by r.ordenimportacion, r.tipooi)) as porcrecibido',
'	from reporte r',
') select',
'	  ordencompra',
'	, tipooc',
'	, ordenimportacion',
'	, tipooi',
'	, numlinea',
'	, codproveedor',
'	, proveedor',
'	, codterminospago',
'	, terminospago',
'	, incoterm',
'	, codcortoproducto',
'	, codproducto',
'	, producto',
'	, um',
'	, facturaproveedor',
'	, refrendo',
'	, fechaingresokardex',
'	, fechaorden',
'	, fechacompromisooriginal',
'	, totalfactura',
'	, fobtotal',
'	, cfr',
'	, cif',
'	, fob',
'	, cantsolicitada',
'	, cantrecibida',
'	, costounitario',
'	, montoordenado',
'	, montorecibido',
'	, montoordenadototal',
'	, montorecibidototal',
'	, porcrecibido*100 porcrecibido',
'	-- ------------------------------------------------------------',
'	, nvl(tasacambio,0)                          as tasacambio',
'	, porcrecibido * nvl(tasacambio,0)           as tasacambiodet',
'	, nvl(advalorem,0)                           as advalorem',
'	, porcrecibido * nvl(advalorem,0)            as advaloremdet',
'	, nvl(almacenaje,0)                          as almacenaje',
'	, porcrecibido * nvl(almacenaje,0)           as almacenajedet',
'	, nvl(flete,0)                               as flete',
'	, porcrecibido * nvl(flete,0)                as fletedet',
'	, nvl(fleteinternacional,0)                  as fleteinternacional',
'	, porcrecibido * nvl(fleteinternacional,0)   as fleteinternacionaldet',
'	, nvl(fodinfa,0)                             as fodinfa',
'	, porcrecibido * nvl(fodinfa,0)              as fodinfadet',
'	, nvl(bodegaje,0)                            as bodegaje',
'	, porcrecibido * nvl(bodegaje,0)             as bodegajedet',
'	, nvl(honorariosagente,0)                    as honorariosagente',
'	, porcrecibido * nvl(honorariosagente,0)     as honorariosagentedet',
'	, nvl(isd,0)                                 as isd',
'	, porcrecibido * nvl(isd,0)                  as isddet',
'	, nvl(seguro,0)                              as seguro',
'	, porcrecibido * nvl(seguro,0)               as segurodet',
'	, nvl(thc,0)                                 as thc',
'	, porcrecibido * nvl(thc,0)                  as thcdet',
'	, nvl(vistobueno,0)                          as vistobueno',
'	, porcrecibido * nvl(vistobueno,0)           as vistobuenodet',
'	, nvl(factorhumedad,0)                       as factorhumedad',
'	, porcrecibido * nvl(factorhumedad,0)        as factorhumedaddet',
'	, nvl(revisioncontenedor,0)                  as revisioncontenedor',
'	, porcrecibido * nvl(revisioncontenedor,0)   as revisioncontenedordet',
'	-- ------------------------------------------------------------',
'	, (nvl(costounitario,0) * nvl(cantrecibida,0))',
'		+ (porcrecibido * nvl(tasacambio,0))',
'		+ (porcrecibido * nvl(advalorem,0))',
'		+ (porcrecibido * nvl(almacenaje,0))',
'		+ (porcrecibido * nvl(flete,0))',
'		+ (porcrecibido * nvl(fleteinternacional,0))',
'		+ (porcrecibido * nvl(fodinfa,0))',
'		+ (porcrecibido * nvl(bodegaje,0))',
'		+ (porcrecibido * nvl(honorariosagente,0))',
'		+ (porcrecibido * nvl(isd,0))',
'		+ (porcrecibido * nvl(seguro,0))',
'		+ (porcrecibido * nvl(thc,0))',
'		+ (porcrecibido * nvl(vistobueno,0))',
'		+ (porcrecibido * nvl(factorhumedad,0))',
'		+ (porcrecibido * nvl(revisioncontenedor,0)) as costopuestoplantadet',
'from calc'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P300_DIVISION'
,p_updated_on=>wwv_flow_imp.dz('20260305144137Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(254815769122713889)
,p_name=>'Reporte Compra Recibida'
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'JALTAMIRANO'
,p_internal_uid=>254815769122713889
,p_updated_on=>wwv_flow_imp.dz('20260305141920Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79125228502624782)
,p_db_column_name=>'ORDENCOMPRA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'No. Orden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79125642370624783)
,p_db_column_name=>'TIPOOC'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Tipo OC'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79126071698624784)
,p_db_column_name=>'ORDENIMPORTACION'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'No. OI'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79126442321624784)
,p_db_column_name=>'TIPOOI'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Tipo OI'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298876402537448501)
,p_db_column_name=>'NUMLINEA'
,p_display_order=>14
,p_column_identifier=>'BL'
,p_column_label=>'LID'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226153711Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298876562165448502)
,p_db_column_name=>'CODPROVEEDOR'
,p_display_order=>24
,p_column_identifier=>'BM'
,p_column_label=>unistr('C\00F3d. Proveedor')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226153711Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79128026305624786)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>34
,p_column_identifier=>'H'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251226154410Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298876633514448503)
,p_db_column_name=>'CODTERMINOSPAGO'
,p_display_order=>44
,p_column_identifier=>'BN'
,p_column_label=>unistr('C\00F3d. Term. Pago')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226153711Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79128457853624786)
,p_db_column_name=>'TERMINOSPAGO'
,p_display_order=>54
,p_column_identifier=>'I'
,p_column_label=>unistr('T\00E9rm. Pago')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251226154410Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298876792133448504)
,p_db_column_name=>'INCOTERM'
,p_display_order=>64
,p_column_identifier=>'BO'
,p_column_label=>'Incoterm'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226153711Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298876971618448506)
,p_db_column_name=>'CODPRODUCTO'
,p_display_order=>74
,p_column_identifier=>'BQ'
,p_column_label=>unistr('C\00F3d. Producto')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226153711Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298876872594448505)
,p_db_column_name=>'CODCORTOPRODUCTO'
,p_display_order=>84
,p_column_identifier=>'BP'
,p_column_label=>unistr('C\00F3d. Corto Prd.')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226153711Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298877065481448507)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>94
,p_column_identifier=>'BR'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226153321Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298877105391448508)
,p_db_column_name=>'UM'
,p_display_order=>104
,p_column_identifier=>'BS'
,p_column_label=>'UM'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226153711Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79131637632624790)
,p_db_column_name=>'FACTURAPROVEEDOR'
,p_display_order=>114
,p_column_identifier=>'Q'
,p_column_label=>'Factura'
,p_column_type=>'STRING'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79132054630624791)
,p_db_column_name=>'REFRENDO'
,p_display_order=>124
,p_column_identifier=>'R'
,p_column_label=>'Refrendo'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79126886174624785)
,p_db_column_name=>'FECHAINGRESOKARDEX'
,p_display_order=>134
,p_column_identifier=>'E'
,p_column_label=>'Fecha Ingreso'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251226153711Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79142814581624804)
,p_db_column_name=>'FECHAORDEN'
,p_display_order=>144
,p_column_identifier=>'AV'
,p_column_label=>'Fecha Orden'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251226153711Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79143246348624805)
,p_db_column_name=>'FECHACOMPROMISOORIGINAL'
,p_display_order=>154
,p_column_identifier=>'AW'
,p_column_label=>'Fecha Comp. Original'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251226153711Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79130809805624789)
,p_db_column_name=>'TOTALFACTURA'
,p_display_order=>164
,p_column_identifier=>'O'
,p_column_label=>'Total Factura'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298877235107448509)
,p_db_column_name=>'FOBTOTAL'
,p_display_order=>194
,p_column_identifier=>'BT'
,p_column_label=>'FOB Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155749Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298877384047448510)
,p_db_column_name=>'CFR'
,p_display_order=>204
,p_column_identifier=>'BU'
,p_column_label=>'CFR'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155749Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298877443519448511)
,p_db_column_name=>'CIF'
,p_display_order=>214
,p_column_identifier=>'BV'
,p_column_label=>'CIF'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155749Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298877586783448512)
,p_db_column_name=>'FOB'
,p_display_order=>224
,p_column_identifier=>'BW'
,p_column_label=>'FOB'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155749Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298877698427448513)
,p_db_column_name=>'CANTSOLICITADA'
,p_display_order=>234
,p_column_identifier=>'BX'
,p_column_label=>'Cant. Sol.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155514Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298877747198448514)
,p_db_column_name=>'CANTRECIBIDA'
,p_display_order=>244
,p_column_identifier=>'BY'
,p_column_label=>'Cant. Rec.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155514Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79130064768624788)
,p_db_column_name=>'COSTOUNITARIO'
,p_display_order=>254
,p_column_identifier=>'M'
,p_column_label=>'Cost. Unitario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251226155514Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298877826078448515)
,p_db_column_name=>'MONTOORDENADO'
,p_display_order=>274
,p_column_identifier=>'BZ'
,p_column_label=>'Monto Sol.*'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155514Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298878046890448517)
,p_db_column_name=>'MONTOORDENADOTOTAL'
,p_display_order=>284
,p_column_identifier=>'CB'
,p_column_label=>'Monto Sol.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155514Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298877993061448516)
,p_db_column_name=>'MONTORECIBIDO'
,p_display_order=>294
,p_column_identifier=>'CA'
,p_column_label=>'Monto Rec.*'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155514Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298878123849448518)
,p_db_column_name=>'MONTORECIBIDOTOTAL'
,p_display_order=>314
,p_column_identifier=>'CC'
,p_column_label=>'Monto Rec.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155514Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298878206190448519)
,p_db_column_name=>'PORCRECIBIDO'
,p_display_order=>324
,p_column_identifier=>'CD'
,p_column_label=>'% Rec.*'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155858Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298878342761448520)
,p_db_column_name=>'TASACAMBIO'
,p_display_order=>334
,p_column_identifier=>'CE'
,p_column_label=>'Tasa Cambio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155514Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298878432379448521)
,p_db_column_name=>'TASACAMBIODET'
,p_display_order=>344
,p_column_identifier=>'CF'
,p_column_label=>'Tasa Cambio*'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155514Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298878585626448522)
,p_db_column_name=>'ADVALOREM'
,p_display_order=>354
,p_column_identifier=>'CG'
,p_column_label=>'Ad Valorem'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155514Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298878685058448523)
,p_db_column_name=>'ADVALOREMDET'
,p_display_order=>364
,p_column_identifier=>'CH'
,p_column_label=>'Ad Valorem*'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155514Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298878775933448524)
,p_db_column_name=>'ALMACENAJE'
,p_display_order=>374
,p_column_identifier=>'CI'
,p_column_label=>'Almacenaje'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155514Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298878865149448525)
,p_db_column_name=>'ALMACENAJEDET'
,p_display_order=>384
,p_column_identifier=>'CJ'
,p_column_label=>'Almacenaje*'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155514Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298878943966448526)
,p_db_column_name=>'FLETE'
,p_display_order=>394
,p_column_identifier=>'CK'
,p_column_label=>'Flete'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155514Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298879065901448527)
,p_db_column_name=>'FLETEDET'
,p_display_order=>404
,p_column_identifier=>'CL'
,p_column_label=>'Flete*'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155514Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298879153003448528)
,p_db_column_name=>'FLETEINTERNACIONAL'
,p_display_order=>414
,p_column_identifier=>'CM'
,p_column_label=>'Flete Int.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155514Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298879209779448529)
,p_db_column_name=>'FLETEINTERNACIONALDET'
,p_display_order=>424
,p_column_identifier=>'CN'
,p_column_label=>'Flete Int.*'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155514Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298879377951448530)
,p_db_column_name=>'FODINFA'
,p_display_order=>434
,p_column_identifier=>'CO'
,p_column_label=>'Fodinfa'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155514Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298879486124448531)
,p_db_column_name=>'FODINFADET'
,p_display_order=>444
,p_column_identifier=>'CP'
,p_column_label=>'Fodinfa*'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155514Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298879539054448532)
,p_db_column_name=>'BODEGAJE'
,p_display_order=>454
,p_column_identifier=>'CQ'
,p_column_label=>'Bodegaje'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155515Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298879605936448533)
,p_db_column_name=>'BODEGAJEDET'
,p_display_order=>464
,p_column_identifier=>'CR'
,p_column_label=>'Bodegaje*'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155515Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298879742179448534)
,p_db_column_name=>'HONORARIOSAGENTE'
,p_display_order=>474
,p_column_identifier=>'CS'
,p_column_label=>'Hon. Agente'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155515Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298879815619448535)
,p_db_column_name=>'HONORARIOSAGENTEDET'
,p_display_order=>484
,p_column_identifier=>'CT'
,p_column_label=>'Hon. Agente*'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155515Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298879938210448536)
,p_db_column_name=>'ISD'
,p_display_order=>494
,p_column_identifier=>'CU'
,p_column_label=>'ISD'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155515Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298880007925448537)
,p_db_column_name=>'ISDDET'
,p_display_order=>504
,p_column_identifier=>'CV'
,p_column_label=>'ISD*'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155515Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298880124348448538)
,p_db_column_name=>'SEGURO'
,p_display_order=>514
,p_column_identifier=>'CW'
,p_column_label=>'Seguro'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155515Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298880239847448539)
,p_db_column_name=>'SEGURODET'
,p_display_order=>524
,p_column_identifier=>'CX'
,p_column_label=>'Seguro*'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155515Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298880342156448540)
,p_db_column_name=>'THC'
,p_display_order=>534
,p_column_identifier=>'CY'
,p_column_label=>'THC'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155515Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298880408857448541)
,p_db_column_name=>'THCDET'
,p_display_order=>544
,p_column_identifier=>'CZ'
,p_column_label=>'THC*'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155515Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298880512389448542)
,p_db_column_name=>'VISTOBUENO'
,p_display_order=>554
,p_column_identifier=>'DA'
,p_column_label=>'Visto Bueno'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155515Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298880677798448543)
,p_db_column_name=>'VISTOBUENODET'
,p_display_order=>564
,p_column_identifier=>'DB'
,p_column_label=>'Visto Bueno*'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155515Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298880718474448544)
,p_db_column_name=>'FACTORHUMEDAD'
,p_display_order=>574
,p_column_identifier=>'DC'
,p_column_label=>'Factor Hum.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155515Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298880832063448545)
,p_db_column_name=>'FACTORHUMEDADDET'
,p_display_order=>584
,p_column_identifier=>'DD'
,p_column_label=>'Factor Hum.*'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155515Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298880973976448546)
,p_db_column_name=>'REVISIONCONTENEDOR'
,p_display_order=>594
,p_column_identifier=>'DE'
,p_column_label=>'Rev. Cont.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155515Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298881095510448547)
,p_db_column_name=>'REVISIONCONTENEDORDET'
,p_display_order=>604
,p_column_identifier=>'DF'
,p_column_label=>'Rev. Cont.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155515Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298881143018448548)
,p_db_column_name=>'COSTOPUESTOPLANTADET'
,p_display_order=>614
,p_column_identifier=>'DG'
,p_column_label=>'Costo Puesto Planta*'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251226153321Z')
,p_updated_on=>wwv_flow_imp.dz('20251226155515Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(254841147609725664)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1757188'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ORDENCOMPRA:TIPOOC:ORDENIMPORTACION:TIPOOI:NUMLINEA:CODPROVEEDOR:PROVEEDOR:TERMINOSPAGO:INCOTERM:CODPRODUCTO:PRODUCTO:UM:FACTURAPROVEEDOR:REFRENDO:FECHAINGRESOKARDEX:FECHAORDEN:FECHACOMPROMISOORIGINAL:TOTALFACTURA:FOBTOTAL:CFR:CIF:FOB:CANTSOLICITADA:'
||'CANTRECIBIDA:COSTOUNITARIO:MONTOORDENADOTOTAL:MONTOORDENADO:MONTORECIBIDOTOTAL:MONTORECIBIDO:PORCRECIBIDO:ADVALOREM:ADVALOREMDET:ALMACENAJE:ALMACENAJEDET:BODEGAJE:BODEGAJEDET:CODTERMINOSPAGO:FACTORHUMEDAD:FACTORHUMEDADDET:FLETE:FLETEINTERNACIONAL:FLE'
||'TEINTERNACIONALDET:FLETEDET:FODINFA:FODINFADET:HONORARIOSAGENTE:HONORARIOSAGENTEDET:ISD:ISDDET:REVISIONCONTENEDOR:REVISIONCONTENEDORDET:SEGURO:SEGURODET:THC:THCDET:TASACAMBIO:TASACAMBIODET:VISTOBUENO:VISTOBUENODET:COSTOPUESTOPLANTADET:'
,p_updated_on=>wwv_flow_imp.dz('20251226155917Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(378297338524923535)
,p_plug_name=>'Resumen'
,p_region_name=>'rptResumen'
,p_parent_plug_id=>wwv_flow_imp.id(378297191276923533)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>60
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_html clob;',
'',
'    procedure add(p in varchar2) is',
'    begin',
'        if l_html is null then',
'            dbms_lob.createtemporary(l_html, true);',
'        end if;',
'        dbms_lob.append(l_html, p);',
'    end;',
'',
'    function fmt_num(p in number) return varchar2 is',
'    begin',
'        return to_char(nvl(p, 0), ''FM999G999G999G990D00'');',
'    end;',
'',
'    function fmt_int(p in number) return varchar2 is',
'    begin',
'        return to_char(nvl(p, 0), ''FM999G999G999G990'');',
'    end;',
'',
'    function fmt_date(p in date) return varchar2 is',
'    begin',
'        if p is null then',
'            return ''-'';',
'        end if;',
'        return to_char(p, ''YYYY-MM-DD'');',
'    end;',
'begin',
'    add(''<div class="oc-acc">'');',
'',
'    add(''',
'<div class="oc-row oc-h" style="padding:6px 2px;">',
'  <div>Proveedor</div>',
'  <div class="oc-num">Cant. solicitada</div>',
'  <div class="oc-num">Cant. recibida</div>',
'  <div class="oc-num">Var. cant.</div>',
unistr('  <div class="oc-num">Avg Var. d\00EDas (por producto)</div>'),
'  <div class="oc-num">USD ordenado</div>',
'  <div class="oc-num">USD recibido</div>',
'  <div class="oc-num">Var. USD</div>',
'</div>',
''');',
'',
'    for r in (',
'        with reporte as (',
'            select num01  as ordencompra',
'                , txt01  as tipooc',
'                , num02  as ordenimportacion',
'                , txt02  as tipooi',
'                , num03  as numlinea',
'                , txt03  as codproveedor',
'                , txt04  as proveedor',
'                , txt05  as codterminospago',
'                , txt06  as terminospago',
'                , txt07  as incoterm',
'                , txt08  as codcortoproducto',
'                , txt09  as codproducto',
'                , txt10  as producto',
'                , txt11  as um',
'                , txt12  as facturaproveedor',
'                , txt13  as refrendo',
'                , fecha01 as fechaingresokardex',
'                , fecha02 as fechaorden',
'                , fecha03 as fechacompromisooriginal',
'                , num10  as totalfactura',
'                , num11  as fobtotal',
'                , num12  as cfr',
'                , num13  as cif',
'                , num14  as fob',
'                , num15  as tasacambio',
'                , num20  as cantsolicitada',
'                , num21  as cantrecibida',
'                , num22  as costounitario',
'                , (num20 * num22) as montoordenado',
'                , (num21 * num22) as montorecibido',
'                , num23  as advalorem',
'                , num24  as almacenaje',
'                , num25  as flete',
'                , num26  as fleteinternacional',
'                , num27  as fodinfa',
'                , num28  as bodegaje',
'                , num29  as honorariosagente',
'                , num30  as isd',
'                , num31  as seguro',
'                , num32  as thc',
'                , num33  as vistobueno',
'                , num34  as factorhumedad',
'                , num35  as revisioncontenedor',
'            from data.t_apex_temporal',
'            inner join data.vt_jde_productos',
'                    on txt08 = to_char(codigocorto)',
'            where 1 = 1',
'                and flag = ''qry1''',
'                and control01 = :g_compania',
'                and control02 = ''COMP''',
'                and control03 = :app_user',
'                and control04 = ''data.pk_comp_reportes.sp_comprasrecibidas''',
'                and (coddivisionman = :p300_division or :p300_division is null)',
'        ),',
'        calc as (',
'            select r.*',
'                , sum(nvl(r.montorecibido,0)) over (partition by r.ordenimportacion, r.tipooi) as montorecibidototal',
'                , sum(nvl(r.montoordenado,0))  over (partition by r.ordenimportacion, r.tipooi) as montoordenadototal',
'                , decode(',
'                    sum(nvl(r.montorecibido,0)) over (partition by r.ordenimportacion, r.tipooi),0, 0,',
'                    nvl(r.montorecibido,0)/sum(nvl(r.montorecibido,0)) over (partition by r.ordenimportacion, r.tipooi)',
'                  ) as porcrecibido',
'            from reporte r',
'        ),',
'        src as (',
'            select',
'                  codproveedor',
'                , proveedor',
'                , codproducto',
'                , producto',
'                , fechacompromisooriginal',
'                , fechaingresokardex',
'                , cantsolicitada',
'                , cantrecibida',
'                , montoordenado',
'                , montorecibido',
'                , (',
'                    (nvl(costounitario,0) * nvl(cantrecibida,0))',
'                    + (porcrecibido * nvl(tasacambio,0))',
'                    + (porcrecibido * nvl(advalorem,0))',
'                    + (porcrecibido * nvl(almacenaje,0))',
'                    + (porcrecibido * nvl(flete,0))',
'                    + (porcrecibido * nvl(fleteinternacional,0))',
'                    + (porcrecibido * nvl(fodinfa,0))',
'                    + (porcrecibido * nvl(bodegaje,0))',
'                    + (porcrecibido * nvl(honorariosagente,0))',
'                    + (porcrecibido * nvl(isd,0))',
'                    + (porcrecibido * nvl(seguro,0))',
'                    + (porcrecibido * nvl(thc,0))',
'                    + (porcrecibido * nvl(vistobueno,0))',
'                    + (porcrecibido * nvl(factorhumedad,0))',
'                    + (porcrecibido * nvl(revisioncontenedor,0))',
'                  ) as costopuestoplantadet',
'            from calc',
'        ),',
'        prod_dates as (',
'            select',
'                proveedor,',
'                codproducto,',
'                producto,',
'                max(fechacompromisooriginal) as max_prometida,',
'                max(fechaingresokardex)      as max_real,',
'                (max(fechaingresokardex) - max(fechacompromisooriginal)) as var_dias_prod',
'            from src',
'            where fechaingresokardex is not null',
'              and fechacompromisooriginal is not null',
'            group by proveedor, codproducto, producto',
'        ),',
'        prov as (',
'            select',
'                s.proveedor,',
'                sum(nvl(s.cantsolicitada,0))                              as sum_cant_sol,',
'                sum(nvl(s.cantrecibida,0))                                as sum_cant_rec,',
'                sum(nvl(s.cantrecibida,0)) - sum(nvl(s.cantsolicitada,0)) as var_cant,',
'                sum(nvl(s.montoordenado,0))                               as sum_usd_ord,',
'                sum(nvl(s.montorecibido,0))                               as sum_usd_rec,',
'                sum(nvl(s.montorecibido,0)) - sum(nvl(s.montoordenado,0)) as var_usd,',
'                (select max(d.max_prometida) from prod_dates d where d.proveedor = s.proveedor) as max_prometida,',
'                (select max(d.max_real)      from prod_dates d where d.proveedor = s.proveedor) as max_real,',
'                (select avg(d.var_dias_prod) from prod_dates d where d.proveedor = s.proveedor) as avg_var_dias_prod',
'            from src s',
'            group by s.proveedor',
'        )',
'        select *',
'        from prov',
'        order by proveedor',
'    ) loop',
'        add(''<details>'');',
'        add(''<summary><div class="oc-row">'');',
'',
'        add(''<div><div class="oc-v">''||apex_escape.html(r.proveedor)||''</div><div class="oc-k">Click para ver productos</div></div>'');',
'        add(''<div class="oc-num oc-v">''||fmt_int(r.sum_cant_sol)||''</div>'');',
'        add(''<div class="oc-num oc-v">''||fmt_int(r.sum_cant_rec)||''</div>'');',
'        add(''<div class="oc-num oc-v">''||fmt_int(r.var_cant)||''</div>'');',
'        add(''<div class="oc-num oc-v">''||to_char(nvl(r.avg_var_dias_prod,0),''FM999G999G990D0'')||''</div>'');',
'        add(''<div class="oc-num oc-v">''||fmt_num(r.sum_usd_ord)||''</div>'');',
'        add(''<div class="oc-num oc-v">''||fmt_num(r.sum_usd_rec)||''</div>'');',
'        add(''<div class="oc-num oc-v">''||fmt_num(r.var_usd)||''</div>'');',
'',
'        add(''</div></summary>'');',
'',
'        add(''<div class="oc-body">'');',
'        add(''<div class="oc-meta">'');',
unistr('        add(''<div class="oc-tag"><b>M\00E1x. comprometida:</b> ''||fmt_date(r.max_prometida)||''</div>'');'),
unistr('        add(''<div class="oc-tag"><b>M\00E1x. ingreso kardex:</b> ''||fmt_date(r.max_real)||''</div>'');'),
unistr('        add(''<div class="oc-tag"><b>Avg Var. d\00EDas (por producto):</b> ''||to_char(nvl(r.avg_var_dias_prod,0),''FM999G999G990D0'')||''</div>'');'),
'        add(''</div>'');',
'',
'        add(''<table class="oc-t">'');',
'        add(''<thead><tr>''||',
'              ''<th>Producto</th>''||',
'              ''<th class="oc-num">Cant. solicitada</th>''||',
'              ''<th class="oc-num">Cant. recibida</th>''||',
'              ''<th class="oc-num">Var. cant.</th>''||',
unistr('              ''<th class="oc-num">M\00E1x. comprometida</th>''||'),
unistr('              ''<th class="oc-num">M\00E1x. ingreso kardex</th>''||'),
unistr('              ''<th class="oc-num">Var. d\00EDas</th>''||'),
'              ''<th class="oc-num">USD ordenado</th>''||',
'              ''<th class="oc-num">USD recibido</th>''||',
'              ''<th class="oc-num">Var. USD</th>''||',
'              ''<th class="oc-num">CPP planta det.</th>''||',
'              ''</tr></thead><tbody>'');',
'',
'        for p in (',
'            with reporte as (',
'                select num02 as ordenimportacion',
'                    , txt02 as tipooi',
'                    , txt04 as proveedor',
'                    , txt08 as codcortoproducto',
'                    , txt09 as codproducto',
'                    , txt10 as producto',
'                    , fecha01 as fechaingresokardex',
'                    , fecha03 as fechacompromisooriginal',
'                    , num20 as cantsolicitada',
'                    , num21 as cantrecibida',
'                    , num22 as costounitario',
'                    , (num20 * num22) as montoordenado',
'                    , (num21 * num22) as montorecibido',
'                    , num15 as tasacambio',
'                    , num23 as advalorem',
'                    , num24 as almacenaje',
'                    , num25 as flete',
'                    , num26 as fleteinternacional',
'                    , num27 as fodinfa',
'                    , num28 as bodegaje',
'                    , num29 as honorariosagente',
'                    , num30 as isd',
'                    , num31 as seguro',
'                    , num32 as thc',
'                    , num33 as vistobueno',
'                    , num34 as factorhumedad',
'                    , num35 as revisioncontenedor',
'                from data.t_apex_temporal',
'                inner join data.vt_jde_productos',
'                        on txt08 = to_char(codigocorto)',
'                where 1 = 1',
'                    and flag = ''qry1''',
'                    and control01 = :g_compania',
'                    and control02 = ''COMP''',
'                    and control03 = :app_user',
'                    and control04 = ''data.pk_comp_reportes.sp_comprasrecibidas''',
'                    and (coddivisionman = :p300_division or :p300_division is null)',
'            ),',
'            calc as (',
'                select r.*',
'                    , sum(nvl(r.montorecibido,0)) over (partition by r.ordenimportacion, r.tipooi) as montorecibidototal',
'                    , decode(',
'                        sum(nvl(r.montorecibido,0)) over (partition by r.ordenimportacion, r.tipooi),0, 0,',
'                        nvl(r.montorecibido,0)/sum(nvl(r.montorecibido,0)) over (partition by r.ordenimportacion, r.tipooi)',
'                      ) as porcrecibido',
'                from reporte r',
'            ),',
'            src as (',
'                select',
'                      proveedor',
'                    , codproducto',
'                    , producto',
'                    , fechacompromisooriginal',
'                    , fechaingresokardex',
'                    , cantsolicitada',
'                    , cantrecibida',
'                    , montoordenado',
'                    , montorecibido',
'                    , (',
'                        (nvl(costounitario,0) * nvl(cantrecibida,0))',
'                        + (porcrecibido * nvl(tasacambio,0))',
'                        + (porcrecibido * nvl(advalorem,0))',
'                        + (porcrecibido * nvl(almacenaje,0))',
'                        + (porcrecibido * nvl(flete,0))',
'                        + (porcrecibido * nvl(fleteinternacional,0))',
'                        + (porcrecibido * nvl(fodinfa,0))',
'                        + (porcrecibido * nvl(bodegaje,0))',
'                        + (porcrecibido * nvl(honorariosagente,0))',
'                        + (porcrecibido * nvl(isd,0))',
'                        + (porcrecibido * nvl(seguro,0))',
'                        + (porcrecibido * nvl(thc,0))',
'                        + (porcrecibido * nvl(vistobueno,0))',
'                        + (porcrecibido * nvl(factorhumedad,0))',
'                        + (porcrecibido * nvl(revisioncontenedor,0))',
'                      ) as costopuestoplantadet',
'                from calc',
'            ),',
'            agg_qty as (',
'                select',
'                    proveedor,',
'                    codproducto,',
'                    producto,',
'                    sum(nvl(cantsolicitada,0)) as sum_cant_sol,',
'                    sum(nvl(cantrecibida,0))   as sum_cant_rec,',
'                    sum(nvl(cantrecibida,0)) - sum(nvl(cantsolicitada,0)) as var_cant,',
'                    sum(nvl(montoordenado,0))  as sum_usd_ord,',
'                    sum(nvl(montorecibido,0))  as sum_usd_rec,',
'                    sum(nvl(montorecibido,0)) - sum(nvl(montoordenado,0)) as var_usd,',
'                    sum(nvl(costopuestoplantadet,0)) as sum_cpp_det',
'                from src',
'                where proveedor = r.proveedor',
'                group by proveedor, codproducto, producto',
'            ),',
'            agg_dates as (',
'                select',
'                    proveedor,',
'                    codproducto,',
'                    max(fechacompromisooriginal) as max_prometida,',
'                    max(fechaingresokardex)      as max_real,',
'                    (max(fechaingresokardex) - max(fechacompromisooriginal)) as var_dias_prod',
'                from src',
'                where proveedor = r.proveedor',
'                  and fechaingresokardex is not null',
'                  and fechacompromisooriginal is not null',
'                group by proveedor, codproducto',
'            )',
'            select',
'                q.codproducto,',
'                q.producto,',
'                q.sum_cant_sol,',
'                q.sum_cant_rec,',
'                q.var_cant,',
'                d.max_prometida,',
'                d.max_real,',
'                d.var_dias_prod,',
'                q.sum_usd_ord,',
'                q.sum_usd_rec,',
'                q.var_usd,',
'                q.sum_cpp_det',
'            from agg_qty q',
'            left join agg_dates d',
'                   on d.proveedor   = q.proveedor',
'                  and d.codproducto = q.codproducto',
'            order by q.producto',
'        ) loop',
'            add(''<tr>'');',
'            add(''<td>''||apex_escape.html(p.codproducto||'' - ''||p.producto)||''</td>'');',
'            add(''<td class="oc-num">''||fmt_int(p.sum_cant_sol)||''</td>'');',
'            add(''<td class="oc-num">''||fmt_int(p.sum_cant_rec)||''</td>'');',
'            add(''<td class="oc-num">''||fmt_int(p.var_cant)||''</td>'');',
'            add(''<td class="oc-num">''||fmt_date(p.max_prometida)||''</td>'');',
'            add(''<td class="oc-num">''||fmt_date(p.max_real)||''</td>'');',
'            add(''<td class="oc-num">''||to_char(nvl(p.var_dias_prod,0),''FM999G999G990D0'')||''</td>'');',
'            add(''<td class="oc-num">''||fmt_num(p.sum_usd_ord)||''</td>'');',
'            add(''<td class="oc-num">''||fmt_num(p.sum_usd_rec)||''</td>'');',
'            add(''<td class="oc-num">''||fmt_num(p.var_usd)||''</td>'');',
'            add(''<td class="oc-num">''||fmt_num(p.sum_cpp_det)||''</td>'');',
'            add(''</tr>'');',
'        end loop;',
'',
'        add(''</tbody></table>'');',
'        add(''</div></details>'');',
'    end loop;',
'',
'    add(''</div>'');',
'',
'    return l_html;',
'end;'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P300_DIVISION'
,p_created_on=>wwv_flow_imp.dz('20260305133847Z')
,p_updated_on=>wwv_flow_imp.dz('20260305151556Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(79124522559624763)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(254508899292360319)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Buscar'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79123080500624755)
,p_name=>'P300_FECHADESDE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(254508569863360316)
,p_item_default=>'trunc(add_months(sysdate,-1),''month'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha desde'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20260305042622Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79123447493624760)
,p_name=>'P300_FECHAHASTA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(254508569863360316)
,p_item_default=>'last_day(add_months(sysdate,-1))'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha hasta'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20260305042648Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79123877307624760)
,p_name=>'P300_BANDERA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(254508569863360316)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260305141314Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(378297401503923536)
,p_name=>'P300_DIVISION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(254508569863360316)
,p_prompt=>'Division'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_UDC_41_P3'
,p_lov=>'select drky, drdl01 from data.vt_jde_udcjde where drsy = ''41'' and drrt = ''P3'' order by drky'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20260305141314Z')
,p_updated_on=>wwv_flow_imp.dz('20260305142405Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(378297740218923539)
,p_name=>'Activar Tab'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P300_DIVISION'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20260305143122Z')
,p_updated_on=>wwv_flow_imp.dz('20260305143716Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(378297870135923540)
,p_event_id=>wwv_flow_imp.id(378297740218923539)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.region("rptDetalle").refresh();',
'apex.region("rptResumen").refresh();',
''))
,p_created_on=>wwv_flow_imp.dz('20260305143122Z')
,p_updated_on=>wwv_flow_imp.dz('20260305143716Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(79147186576624817)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cambia punto decimal'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'EXECUTE IMMEDIATE ''ALTER SESSION SET NLS_NUMERIC_CHARACTERS =''''.,'''''';',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>79147186576624817
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(224410084099993403)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Valida'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_qty number;',
'begin',
'	:p300_bandera := 1;',
'',
'	select count(1) into v_qty',
'	from t_apex_temporal',
'	where (',
'		flag = ''qry1''',
'		and control01 = :g_compania',
'		and control02 = ''COMP''',
'		and control03 = :app_user',
'		and control04 = ''data.pk_comp_reportes.sp_comprasrecibidas''',
'		)',
'		and num05 != 0;',
'',
'	if v_qty = 0 then',
'		:p300_bandera := 0;',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>224410084099993403
,p_created_on=>wwv_flow_imp.dz('20251106152357Z')
,p_updated_on=>wwv_flow_imp.dz('20251106152357Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(79146710312624816)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Buscar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	:p300_bandera := 0;',
'	pk_comp_reportes.sp_comprasrecibidas(:g_compania,:app_user,:p300_fechadesde,:p300_fechahasta);',
'	:p300_bandera := 1;',
'	:p300_division := null;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(79124522559624763)
,p_internal_uid=>79146710312624816
,p_updated_on=>wwv_flow_imp.dz('20260305152123Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
