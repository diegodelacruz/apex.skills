prompt --application/pages/page_00517
begin
--   Manifest
--     PAGE: 00517
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>517
,p_name=>'COMEX - dlg Documento Upload'
,p_alias=>'COMEX-DLG-DOCUMENTO-UPLOAD'
,p_page_mode=>'MODAL'
,p_step_title=>'COMEX - Documento Upload'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_created_on=>wwv_flow_imp.dz('20241024191447Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260714194145Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(318298891114653226)
,p_plug_name=>'Body'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(318299273611653230)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(318298891114653226)
,p_button_name=>'GRABAR_DOCUMENTO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Grabar Documento'
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(318299568645653233)
,p_branch_name=>'Go to 511 GRABAR_DOCUMENTO'
,p_branch_action=>'f?p=&APP_ID.:511:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'EXPRESSION'
,p_branch_condition=>':P517_ORIGEN IS NULL OR :P517_ORIGEN=''DOCUMENTAL'''
,p_branch_condition_text=>'PLSQL'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(368940341417139301)
,p_branch_name=>'Go to 521 GRABAR_DOCUMENTO'
,p_branch_action=>'f?p=&APP_ID.:521:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>20
,p_branch_condition_type=>'EXPRESSION'
,p_branch_condition=>':P517_ORIGEN = ''EXPORTACION'''
,p_branch_condition_text=>'PLSQL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(318298978767653227)
,p_name=>'P517_DATOS_GESTION_DETALLE_ID'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(318299004911653228)
,p_name=>'P517_TIPO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(318298891114653226)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_CMEX_TIPO_DOC'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'	VALOR AS NAME,',
'	ID_TABLA AS VALUE',
'FROM T_CORP_UDC ',
'WHERE ID_CABECERA=''CMEX_TDOC'';',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20260714194145Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(318299193530653229)
,p_name=>'P517_DOCUMENTO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(318298891114653226)
,p_prompt=>'Documento'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(318299608055653234)
,p_name=>'P517_DATOS_GESTION_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(318299963957653237)
,p_name=>'P517_CLIENTE'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(318300024122653238)
,p_name=>'P517_FAC_VINCULADAS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(318298891114653226)
,p_prompt=>'Fac Vinculadas'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT NOMBRE, CODIGO FROM (',
'    SELECT ',
'        SDDCT||''-''||SDDOC  AS NOMBRE,',
'        SDDCT||''-''||SDDOC  AS CODIGO',
'    FROM F42119@JDEDTADL',
'    WHERE',
'        SDDCT = ''FE''',
'        AND',
'        SDAN8 = :P517_CLIENTE',
'        AND ',
'        SDTRDJ > PK_COMMONS.F_G2JDE(SYSDATE-465)',
'    ORDER BY SDTRDJ DESC',
');',
''))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>', '
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(368940496290139302)
,p_name=>'P517_ORIGEN'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(318299355662653231)
,p_validation_name=>'GRABAR_DOCUMENTO'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P517_TIPO IS NULL THEN',
'    RETURN ''Debe seleccionar un tipo de DOCUMENTO'';',
'END IF;',
'',
'IF :P517_DOCUMENTO IS NULL THEN',
'    RETURN ''Debe seleccionar un archivo DOCUMENTO'';',
'END IF;',
'',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(318299481991653232)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GRABAR_DOCUMENTO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_DATOS_GESTION.SP_GRABA_DOCUMENTO(',
'    :P517_DATOS_GESTION_DETALLE_ID,',
'    :P517_TIPO,',
'    :P517_FAC_VINCULADAS,',
'    :APP_USER',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>318299481991653232
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(318299886369653236)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga Datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Recupera el ID de la cabecera',
'SELECT',
'    DATOS_GESTION_ID',
'INTO',
'    :P517_DATOS_GESTION_ID',
'FROM ',
'    T_CMEX_DATOS_GESTION_DETALLE',
'WHERE',
'    ID = :P517_DATOS_GESTION_DETALLE_ID',
';',
'',
'-- Recupera el AN8 cliente de la cabecera',
'SELECT',
'    CLIENTE',
'INTO',
'    :P517_CLIENTE',
'FROM ',
'     T_CMEX_DATOS_GESTION',
'WHERE',
'    ID = :P517_DATOS_GESTION_ID',
';',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>318299886369653236
);
wwv_flow_imp.component_end;
end;
/
