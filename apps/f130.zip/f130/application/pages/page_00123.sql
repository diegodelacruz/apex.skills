prompt --application/pages/page_00123
begin
--   Manifest
--     PAGE: 00123
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>123
,p_name=>'Informacion Justificacion'
,p_page_mode=>'MODAL'
,p_step_title=>'Informacion Justificacion'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'17'
,p_created_on=>wwv_flow_imp.dz('20230708132653Z')
,p_last_updated_on=>wwv_flow_imp.dz('20220217031911Z')
,p_last_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(85405913548162962)
,p_plug_name=>'Items'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(43892644636246112)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(85405913548162962)
,p_button_name=>'Actualizar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Actualizar'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43473145004068923)
,p_name=>'P123_CODIGODOCUMENTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(85405913548162962)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43473553038068924)
,p_name=>'P123_TIPO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(85405913548162962)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43473998509068926)
,p_name=>'P123_LINEA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(85405913548162962)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43474357486068926)
,p_name=>'P123_INFORMACION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(85405913548162962)
,p_use_cache_before_default=>'NO'
,p_prompt=>'New'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'(select IALONGMSG from f564310@jdedtadl',
'where iadcto = :P123_TIPO and iadoco = :P123_CODIGODOCUMENTO AND IALNID = :P123_LINEA) INFO',
'from dual'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(295681811193037723)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(43474736781068927)
,p_name=>'Seleccionado_Click'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.chkF01'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43475237334068927)
,p_event_id=>wwv_flow_imp.id(43474736781068927)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var lineas =""; ',
'document.querySelectorAll(''.chkF01'').forEach(function(seleccion) {',
'    if(seleccion.checked){',
'        var linea = seleccion.value',
'        if(lineas==""){',
'            lineas = linea;',
'        }else{',
'            ',
'            lineas = lineas+'',''+linea;',
'        }      ',
'    }else{',
'        ',
'    }',
'    ',
'});',
'',
'apex.item("P123_SELECCIONPROVEEDOR").setValue(lineas);',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43476278085068929)
,p_event_id=>wwv_flow_imp.id(43474736781068927)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_proveedor number;',
'v_costo number;',
'v_moneda nvarchar2(5);',
'BEGIN',
'--ACTUALIZO VALORES DEL PROVEEDOR SELECCIONADO',
'BEGIN',
'select PCAN8, CBPRRC, CBCRCD',
'into v_proveedor, v_costo, v_moneda',
'from f43090@jdedtadl ',
'LEFT JOIN F41061@JDEDTADL ON pcitm = CBITM AND PCAN8 = CBAN8 ',
'LEFT JOIN vt_jde_librodirecciones ON PCAN8 = CODIGO',
'where PCNROU = ''IMPT''',
'AND (dp.f_g2jde(sysdate) between PCCEFJ  and PCCXPJ) and (dp.f_g2jde(sysdate) between CBEFTJ  and CBEXDJ)',
'AND TRIM(pclitm) = :P123_CODIGOPRODUCTO',
'AND trim(PCMCU) = trim(:P123_BODEGA)',
'AND PCAN8 = :P123_SELECCIONPROVEEDOR;',
'exception',
'when NO_DATA_FOUND then',
'v_proveedor := NULL;',
'END;',
'--',
'--Actualizo los valores',
'update t_comp_generaoc',
'set PROVEEDOR = v_proveedor, ',
'PRECIOUNITARIO = v_costo, ',
'MONEDA = v_moneda',
'where KEYID = :P123_KEYID;',
'COMMIT;',
'update t_comp_generaoc',
'set TOTALCOMPRA = (CANTIDADSUGERIDACOMPRA * PRECIOUNITARIO)/10000',
'where KEYID = :P123_KEYID;',
'COMMIT;',
'END;',
''))
,p_attribute_02=>'P123_INFORMACION,P123_CODIGODOCUMENTO,P123_TIPO,P123_LINEA'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43475792385068927)
,p_event_id=>wwv_flow_imp.id(43474736781068927)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(43892736649246113)
,p_name=>unistr('Actualiza Justificaci\00F3n Linea')
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(43892644636246112)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43892823452246114)
,p_event_id=>wwv_flow_imp.id(43892736649246113)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update f564310@jdedtadl set IALONGMSG = (select :P123_INFORMACION from dual)',
'where iadcto = :P123_TIPO and iadoco = :P123_CODIGODOCUMENTO AND IALNID = :P123_LINEA;'))
,p_attribute_02=>'P123_INFORMACION,P123_TIPO,P123_CODIGODOCUMENTO,P123_LINEA'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43892925271246115)
,p_event_id=>wwv_flow_imp.id(43892736649246113)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp.component_end;
end;
/
