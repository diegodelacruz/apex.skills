prompt --application/pages/page_00120
begin
--   Manifest
--     PAGE: 00120
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>120
,p_name=>unistr('Generaci\00F3n de OC desde H1-H3')
,p_step_title=>unistr('Generaci\00F3n de OC desde H1-H3')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230708132653Z')
,p_last_updated_on=>wwv_flow_imp.dz('20230711143910Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6986204338096935)
,p_plug_name=>unistr('Generaci\00F3n de OC desde H1-H3')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295639738305037692)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6986801284096936)
,p_plug_name=>unistr('Generaci\00F3n de OC desde H1-H3')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'      x.documento,',
'      (case when x.codsolicitante in (select coderp from vt_corp_usuario where nombreusuario = :app_user and rownum = 1) ',
'          then '''' ',
'          else ',
'              apex_page.get_url (',
'                  p_application	=> 130,',
'                  p_page 			=> 121,',
'                  p_items			=> ''P121_NUM_REQ,P121_TIPO_REQ,P121_NOMBRECOMPRADOR,P121_SOLICITANTE,P121_BODEGA,P121_FECHA_REQ'',',
'                  p_values		    =>  DOCUMENTO||'',''||DOCUMENTOTIPO||'',''||NOMBRECOMPRADOR||'',''||CODSOLICITANTE||'',''||TRIM(BODEGA)||'',''||TO_CHAR(FECHAREQUERIMIENTO)',
'              )   ',
'      end) URL',
'	, d.nombres solicitante',
'	, x.fecharequerimiento',
'	, trunc(sysdate - x.fecharequerimiento) dias_ingreso_req',
'	, x.nombrecomprador',
'	, x.codsolicitante',
'	, x.bodega',
'from (',
'	select pddoco documento',
'		, pddcto documentotipo',
'		, pdan8 codsolicitante',
'		, pk_commons.f_jde2g(pdtrdj) fecharequerimiento',
'		, comprador nombrecomprador',
'		, count(comprador) num_items',
'		, pdmcu bodega',
'	from f4311@jdedtadl',
'	left join vt_jde_productos on pditm = codigocorto',
'	where (pddcto = ''H3'' and pdlttr = 110 and pdnxtr = 120) or (pddcto = ''H1'' and pdlttr = 100 and pdnxtr = 130)',
'	group by pddoco, pddcto, pdan8, pdtrdj, comprador, pdmcu',
') x',
'left join vt_jde_librodirecciones d on x.codsolicitante = d.codigo',
'where x.num_items = (',
'	select max(count(comprador))',
'	from f4311@jdedtadl',
'	left join vt_jde_productos',
'		on pditm = codigocorto and ((pddcto = ''H3'' and pdlttr = 110 and pdnxtr = 120) or (pddcto = ''H1'' and pdlttr = 100 and pdnxtr = 130))',
'	-- where (pddcto = ''H3'' and pdlttr = 110 and pdnxtr = 120) or (pddcto = ''H1'' and pdlttr = 100 and pdnxtr = 130)',
'	where pddoco = x.documento and pddcto = x.documentotipo',
'	group by pddoco,pddcto,pdan8,pdtrdj,comprador,pdmcu)',
'and (',
'	x.nombrecomprador	in (select coderp from vt_corp_usuario where nombreusuario = :app_user and rownum = 1)',
'	or',
'	x.codsolicitante	in (select coderp from vt_corp_usuario where nombreusuario = :app_user and rownum = 1)',
'	-- or x.nombrecomprador = 0',
'	)',
'and trunc(x.fecharequerimiento) between :P120_FECHA_INICIO and :P120_FECHA_FIN',
'and (x.documentotipo = :p120_tipo_req or :p120_tipo_req is null)',
'order by trunc(sysdate - x.fecharequerimiento) desc;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P120_FECHA_INICIO,P120_FECHA_FIN,P120_TIPO_REQ'
,p_updated_on=>wwv_flow_imp.dz('20230711143910Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(6986944485096936)
,p_name=>unistr('Generaci\00F3n de OC desde H1-H3')
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'CVACA'
,p_internal_uid=>6986944485096936
,p_updated_on=>wwv_flow_imp.dz('20230711143910Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6987382871096946)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Documento'
,p_column_link=>'#URL#'
,p_column_linktext=>'#DOCUMENTO#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6988154776096949)
,p_db_column_name=>'SOLICITANTE'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Solicitante'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6988560266096949)
,p_db_column_name=>'FECHAREQUERIMIENTO'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6988917830096949)
,p_db_column_name=>'DIAS_INGRESO_REQ'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>unistr('D\00EDas Ingreso')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6961289579024045)
,p_db_column_name=>'CODSOLICITANTE'
,p_display_order=>16
,p_column_identifier=>'G'
,p_column_label=>'Codsolicitante'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43402264974364928)
,p_db_column_name=>'NOMBRECOMPRADOR'
,p_display_order=>26
,p_column_identifier=>'H'
,p_column_label=>'Comprador'
,p_column_type=>'NUMBER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(542214344158004745)
,p_db_column_name=>'BODEGA'
,p_display_order=>36
,p_column_identifier=>'I'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100912779772357731)
,p_db_column_name=>'URL'
,p_display_order=>46
,p_column_identifier=>'J'
,p_column_label=>'Url'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(6989856451097264)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'69899'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENTO:SOLICITANTE:FECHAREQUERIMIENTO:DIAS_INGRESO_REQ::CODSOLICITANTE:BODEGA:URL'
,p_created_on=>wwv_flow_imp.dz('20230708132653Z')
,p_updated_on=>wwv_flow_imp.dz('20230708132653Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(101683898201600190)
,p_report_id=>wwv_flow_imp.id(6989856451097264)
,p_name=>'Sin Atencion'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIAS_INGRESO_REQ'
,p_operator=>'>='
,p_expr=>'8'
,p_condition_sql=>' (case when ("DIAS_INGRESO_REQ" >= to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# >= #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FF7755'
,p_created_on=>wwv_flow_imp.dz('20230708132653Z')
,p_updated_on=>wwv_flow_imp.dz('20230708132653Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12819295800173034)
,p_plug_name=>'Barra de accion'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12821751452174999)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6991971939112778)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(12819295800173034)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3543139433486112)
,p_name=>'P120_TIPO_REQ'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(12821751452174999)
,p_prompt=>unistr('Tipo Requisici\00F3n: ')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:H1;H1,H3;H3'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Todos'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6960305358024036)
,p_name=>'P120_NOMBRECOMPRADOR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(12821751452174999)
,p_prompt=>'Comprador:'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select APELLIDOS || '' '' || NOMBRES  FROM VT_CORP_USUARIO',
'WHERE NOMBREUSUARIO = :APP_USER'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6995983557114744)
,p_name=>'P120_FECHA_INICIO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(12821751452174999)
,p_prompt=>'Fecha Inicio'
,p_format_mask=>'dd/mm/yyyy'
,p_source=>'trunc(ADD_MONTHS(SYSDATE,-1),''month'')'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6996373137114744)
,p_name=>'P120_FECHA_FIN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(12821751452174999)
,p_prompt=>'Fecha fin'
,p_format_mask=>'dd/mm/yyyy'
,p_source=>'SELECT  SYSDATE FROM DUAL'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp.component_end;
end;
/
