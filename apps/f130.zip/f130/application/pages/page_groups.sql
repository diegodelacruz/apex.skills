prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 130
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(295708094990037776)
,p_group_name=>'Administration'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(316585522945694029)
,p_group_name=>'Reports'
,p_group_desc=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('Grupo reservado para p\00E1ginas de consulta, reportes y an\00E1lisis.'),
unistr('Las p\00E1ginas 401 a 499 deben ser exclusivamente de solo lectura.'),
unistr('La p\00E1gina 400 documenta esta convenci\00F3n.')))
);
wwv_flow_imp.component_end;
end;
/
