prompt --application/pages/page_00106
begin
--   Manifest
--     PAGE: 00106
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>106
,p_name=>unistr('Detalle Nota de Cr\00E9dito')
,p_step_title=>unistr('Detalle Nota de Cr\00E9dito')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20250210224908Z')
,p_last_updated_on=>wwv_flow_imp.dz('20250217203654Z')
,p_last_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79918992225602806)
,p_plug_name=>unistr('Datos de la Nota de Cr\00E9dito')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(79919852511602815)
,p_name=>unistr('Notas de Cr\00E9dito')
,p_template=>wwv_flow_imp.id(296121421643169165)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    nc.lote,',
'    ( idpromocion )                                                                            idpromocion,',
'    decode(usercre, ''ICOM'', NULL, codigocliente)                                               codigocliente,',
'    SUM(valor) OVER(PARTITION BY nc.lote, idpromocion, decode(usercre, ''ICOM'', NULL, codigocliente), nvl(v.NOMBRE, motivo)) valor,',
'    nvl(v.NOMBRE, motivo)                                                                                      motivo,',
'    MAX(fechacrea) OVER(PARTITION BY nc.lote)                                                     fechacrea,',
'    MAX(usercre)OVER(PARTITION BY nc.lote)                                                        usercre,',
'    decode(MAX(usercre)OVER(PARTITION BY nc.lote), ''ICOM'', COUNT(1) OVER(PARTITION BY idpromocion,nc.lote), ROW_NUMBER() OVER( PARTITION BY nc.lote ORDER BY idpromocion DESC )) linea',
'FROM',
'    t_back_notasdecredito nc',
'    left join vt_icom_validacion_lote_nc v on (nc.idpromocion=IDINVERSION and v.lote=nc.LOTE)',
'WHERE',
'    nc.lote = :p106_lote;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P106_LOTE'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_report_total_text_format=>'Total'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250217203654Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(79919917731602816)
,p_query_column_id=>1
,p_column_alias=>'LOTE'
,p_column_display_sequence=>1
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(79920057835602817)
,p_query_column_id=>2
,p_column_alias=>'IDPROMOCION'
,p_column_display_sequence=>2
,p_column_heading=>unistr('ID Promoci\00F3n')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(79920141311602818)
,p_query_column_id=>3
,p_column_alias=>'CODIGOCLIENTE'
,p_column_display_sequence=>3
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(79920770808602824)
,p_query_column_id=>4
,p_column_alias=>'VALOR'
,p_column_display_sequence=>7
,p_column_heading=>'Monto'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(79920370874602820)
,p_query_column_id=>5
,p_column_alias=>'MOTIVO'
,p_column_display_sequence=>4
,p_column_heading=>'Motivo'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(79920455324602821)
,p_query_column_id=>6
,p_column_alias=>'FECHACREA'
,p_column_display_sequence=>5
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(79920514798602822)
,p_query_column_id=>7
,p_column_alias=>'USERCRE'
,p_column_display_sequence=>6
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(79920633746602823)
,p_query_column_id=>8
,p_column_alias=>'LINEA'
,p_column_display_sequence=>8
,p_use_as_row_header=>'N'
,p_default_sort_column_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(79920905803602826)
,p_name=>'Archivos'
,p_template=>wwv_flow_imp.id(296121421643169165)
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select numeroarchivo',
', dbms_lob.getlength(blobcontent) blobcontent',
', filename',
'from files.t_apex_archivos where tabla = ''T_BACK_NOTASDECREDITO'' and id_tabla = :p106_lote'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'No hay archivos cargados.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(79921051687602827)
,p_query_column_id=>1
,p_column_alias=>'NUMEROARCHIVO'
,p_column_display_sequence=>1
,p_column_heading=>unistr('N\00FAm. Archivo')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(79921179588602828)
,p_query_column_id=>2
,p_column_alias=>'BLOBCONTENT'
,p_column_display_sequence=>2
,p_column_heading=>'Descargar'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment:descargar:FILES'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(79921263052602829)
,p_query_column_id=>3
,p_column_alias=>'FILENAME'
,p_column_display_sequence=>3
,p_column_heading=>'Archivo'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(85785593618451218)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(79919626089602813)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(85785593618451218)
,p_button_name=>'REGRESAR'
,p_button_static_id=>'btnRegresar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(504187656389607912)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(85785593618451218)
,p_button_name=>'APROBAR'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Aprobar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:102:&SESSION.::&DEBUG.:102:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO:&G_COMPANIA.,BACK,&APP_USER.,GENERACION_NOTA_CREDITO,&P106_LOTE.,&P106_APROBADOR.'
,p_button_condition=>'P106_APROBADOR'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-thumbs-up'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(77054377570485620)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(85785593618451218)
,p_button_name=>'RECHAZAR'
,p_button_static_id=>'btnAprobar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Rechazar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:103:&SESSION.::&DEBUG.:RP:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO:&G_COMPANIA.,BACK,&APP_USER.,GENERACION_NOTA_CREDITO,&P106_LOTE.,&P106_APROBADOR.'
,p_button_condition=>'P106_APROBADOR'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-thumbs-down'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(56184125674868225)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(85785593618451218)
,p_button_name=>'COMENTARIOS'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Comentarios'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:105:&SESSION.::&DEBUG.:105:G_MODULO,G_OBJETO,G_OBJETO_ID,G_COMPANIA,G_USUARIO,G_USUARIO_FLUJO:BACK,GENERACION_NOTA_CREDITO,&P106_LOTE.,&G_COMPANIA.,&APP_USER.,&P106_APROBADOR.'
,p_icon_css_classes=>'fa-comment'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77054230575485619)
,p_name=>'P106_TOKEN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(79918992225602806)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79919095309602807)
,p_name=>'P106_CLIENTE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(79918992225602806)
,p_prompt=>'Cliente'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79919138942602808)
,p_name=>'P106_VALOR'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(79918992225602806)
,p_prompt=>'Valor'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79919200997602809)
,p_name=>'P106_IVA'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(79918992225602806)
,p_prompt=>'IVA'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79919387477602810)
,p_name=>'P106_TOTAL'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(79918992225602806)
,p_prompt=>'Total'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79919414313602811)
,p_name=>'P106_LOTE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(79918992225602806)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79921502162602832)
,p_name=>'P106_APROBADOR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(79918992225602806)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79921912541602836)
,p_name=>'P106_FLUJO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(79918992225602806)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(489755690774779650)
,p_name=>'P106_USUARIOCREA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(79918992225602806)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(79921702999602834)
,p_name=>unistr('Aprueba Cerrar di\00E1logo')
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(504187656389607912)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79921877292602835)
,p_event_id=>wwv_flow_imp.id(79921702999602834)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo = trama.resultado.terminoFlujo;',
'var lineas = ""; ',
'mostrarBarra();',
'apex.item("P106_FLUJO").setValue(0);',
'if(this.data.G_EXITO == ''true''){',
'    apex.item("P106_FLUJO").setValue(1);',
'    mensaje(''exito'', this.data.G_MENSAJE);',
'    if(isTerminoFlujo){',
'        apex.item("P106_FLUJO").setValue(2);',
'    }',
'}',
'else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79922042440602837)
,p_event_id=>wwv_flow_imp.id(79921702999602834)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :p106_flujo = 2 then',
'	pk_back_notadecredito.sp_apruebanc(:p106_lote,''0'');',
'end if;'))
,p_attribute_02=>'P106_FLUJO,P106_LOTE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77054143725485618)
,p_event_id=>wwv_flow_imp.id(79921702999602834)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var token = apex.item("P106_TOKEN").getValue();',
'',
'if(apex.item("P106_FLUJO").getValue() > 0){',
'    $(''#btnRegresar'').trigger("click");',
'}',
'',
'ocultarBarra();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(77054415713485621)
,p_name=>unistr('Rechaza Cerrar di\00E1logo')
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(77054377570485620)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77054581609485622)
,p_event_id=>wwv_flow_imp.id(77054415713485621)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'',
'apex.item( "P106_FLUJO" ).setValue(0);',
'',
'if(this.data.G_EXITO == ''true''){',
'    apex.item( "P106_FLUJO" ).setValue(1);',
'}',
'else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77054749889485624)
,p_event_id=>wwv_flow_imp.id(77054415713485621)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :p106_flujo = 1 then',
'	pk_back_notadecredito.sp_rechazanc(:p106_lote,''0'');',
'end if;'))
,p_attribute_02=>'P106_FLUJO,P106_LOTE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77054638571485623)
,p_event_id=>wwv_flow_imp.id(77054415713485621)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var token = apex.item("P106_TOKEN").getValue();',
'',
'if(apex.item("P106_FLUJO").getValue() > 0){',
'    $(''#btnRegresar'').trigger("click");',
'}',
'',
'ocultarBarra();'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(79919570563602812)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga Datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_contador number;',
'begin',
'	select nombres into :p106_cliente from vt_jde_cliente',
'	where codigo = (select min(codigocliente) from t_back_notasdecredito where lote = :p106_lote);',
'',
'	select count(*) into v_contador from vt_back_mesatrabajo',
'	where compania = :g_compania',
'		and pk_corp_flujoaprobacion.f_aprobadorflujo(:app_user,aprobador,''BACK'',:g_compania) = 1;',
'',
'	if v_contador > 0 then :p106_aprobador := 1; end if;',
'',
'	pk_back_notadecredito.sp_sumainicial(:p106_lote,:p106_valor,:p106_iva,:p106_total);',
'end;',
'',
'DECLARE v_usuariocrea VARCHAR2(30);',
'begin',
'    select MAX(USERCRE) USERCRE into v_usuariocrea',
'    from T_BACK_NOTASDECREDITO',
'    where LOTE = :p106_lote;',
'    ',
'    :P106_USUARIOCREA:=v_usuariocrea;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>79919570563602812
);
wwv_flow_imp.component_end;
end;
/
