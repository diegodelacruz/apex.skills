prompt --application/pages/page_00201
begin
--   Manifest
--     PAGE: 00201
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>201
,p_name=>'Generar OCs'
,p_alias=>'GENERAR-OCS'
,p_step_title=>'Generar OCs &P201_TIPO_H_ENCURSO.'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(regOcultos).hide();',
'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* ==========================================================================',
unistr('   HOJA DE ESTILOS UI/UX - P\00C1GINA 201 (GENERAR OCS)'),
'   ========================================================================== */',
'',
unistr('/* --- 1. ESTILOS DE ESTRUCTURA Y REGIONES (Contexto Espec\00EDfico) --- */'),
'',
'/* Hace transparente la barra de herramientas del Reporte Interactivo */',
'.a-IRR-toolbar {',
'    background: transparent;',
'}',
'',
unistr('/* Colores de fondo para diferenciar regiones l\00F3gicas */'),
'.selectNeg div {',
unistr('    background: bisque;       /* Selecci\00F3n Negociaci\00F3n */'),
'}',
'',
'.selectAgrupado div {',
'    background: lightskyblue; /* Agrupamiento */',
'}',
'',
'.gestionH2 div {',
unistr('    background: cornsilk;     /* Gesti\00F3n H2 */'),
'}',
'',
'.generaOC div {',
unistr('    background: darkseagreen; /* Generaci\00F3n Final */'),
'}',
'',
'',
'/* ==========================================================================',
unistr('   2. MEJORA DE COLUMNAS (Jerarqu\00EDa Visual)'),
'   ========================================================================== */',
'',
unistr('/* --- Columna: DOCUMENTO (ID S\00F3lido) --- */'),
'/* Uso: Agregar class="doc-solido" en Link Attributes de la columna */',
'a.doc-solido {',
'    color: #2c3e50 !important;      /* Gris oscuro para denotar dato maestro */',
unistr('    font-weight: 700 !important;    /* Negrita para jerarqu\00EDa visual */'),
'    text-decoration: none !important;',
unistr('    transition: color 0.2s ease;    /* Transici\00F3n suave al interactuar */'),
'}',
'',
'a.doc-solido:hover {',
'    color: #00a65a !important;      /* Verde Corporativo al pasar el mouse */',
'    text-decoration: underline !important;',
'}',
'',
'',
'/* ==========================================================================',
'   3. SISTEMA DE COMENTARIOS (Popover Silencioso)',
'   ========================================================================== */',
'/* Uso: En HTML Expression: ',
'   <div class="comentario-wrap">#DATA#<span class="comentario-full">#DATA#</span></div> ',
'*/',
'',
'/* --- Estado Reposo (Vista de Tabla) --- */',
'.comentario-wrap {',
'    position: relative;        /* Ancla para el elemento flotante */',
unistr('    width: 35vw;               /* Ancho din\00E1mico: 35% de la pantalla */'),
unistr('    min-width: 300px;          /* No menos de 300px (Laptop peque\00F1a) */'),
unistr('    max-width: 600px;          /* No m\00E1s de 600px (Pantallas 4k) */'),
'    ',
unistr('    /* Truncado inteligente a 3 l\00EDneas */'),
'    display: -webkit-box;',
'    -webkit-box-orient: vertical;',
'    -webkit-line-clamp: 3;',
'    overflow: hidden;',
'    ',
unistr('    /* Tipograf\00EDa optimizada para lectura r\00E1pida */'),
'    white-space: normal;',
unistr('    text-transform: lowercase; /* Transforma visualmente a min\00FAsculas */'),
'    font-size: 0.95em;',
'    line-height: 1.4;',
'    color: #404040;',
unistr('    cursor: help;              /* Indica al usuario que hay m\00E1s info */'),
'}',
'',
unistr('/* Capitalizaci\00F3n simulada (Solo primera letra) */'),
'.comentario-wrap::first-letter {',
'    text-transform: uppercase;',
'}',
'',
'/* --- Estado Expandido (Tarjeta Flotante) --- */',
'.comentario-full {',
'    display: none;             /* Oculto por defecto para no ensuciar la UI */',
'    ',
'    /* Posicionamiento: Flota sobre la celda original */',
'    position: absolute;',
'    top: -10px;                ',
'    left: -10px;               ',
'    z-index: 9999;             /* Capa superior absoluta */',
'    ',
'    /* Dimensiones de la tarjeta */',
'    width: 100%;               ',
'    min-width: 320px;          ',
'    ',
unistr('    /* Est\00E9tica de "Tarjeta Elevada" */'),
'    background-color: #FFFFFF; ',
'    color: #333333;            ',
'    padding: 15px;             ',
'    border-radius: 4px;',
'    border: 1px solid #dce4ec; ',
'    box-shadow: 0 5px 20px rgba(0,0,0,0.2); /* Sombra difusa */',
'    ',
'    /* Formato de Datos: Muestra el texto real sin alteraciones */',
'    text-transform: none;      ',
'    white-space: normal;',
'    font-size: 1em;            ',
'}',
'',
unistr('/* --- Interacci\00F3n (Hover) --- */'),
'.comentario-wrap:hover {',
'    overflow: visible;         /* Permite que el hijo salga de la caja */',
'}',
'',
'.comentario-wrap:hover .comentario-full {',
'    display: block;            /* Muestra la tarjeta flotante */',
'}',
'',
'',
'/* ==========================================================================',
unistr('   4. HIGHLIGHT DE FILAS (Navegaci\00F3n Asistida)'),
'   ========================================================================== */',
'',
'/* Ilumina la celda/fila al pasar el mouse para evitar errores de lectura */',
'.a-IRR-table tbody tr:hover > td {',
'    background-color: #e0f3e6 !important; /* Verde menta muy suave */',
'    color: #000000 !important;             /* Maximiza contraste del texto */',
'    transition: background-color 0.1s ease-in-out;',
'}',
'',
unistr('/* Ajuste espec\00EDfico para que el Link Documento no se pierda en el fondo verde */'),
'.a-IRR-table tbody tr:hover > td .doc-solido {',
unistr('    color: #006e3b !important; /* Verde m\00E1s oscuro e intenso */'),
'    text-decoration: underline !important;',
'}',
'',
'/* =========================================',
'   4. DATOS SECUNDARIOS (Bodega / Originador)',
'   ========================================= */',
unistr('/* 1. Primero la clase gen\00E9rica */'),
'.dato-secundario {',
'    font-size: 0.85em;',
'    color: #606060;        /* Gris suave */',
'    font-weight: 500;',
'    letter-spacing: 0.5px;',
'    vertical-align: middle;',
'}',
'',
unistr('/* 2. Luego la clase espec\00EDfica (para que sobrescriba el color y peso) */'),
'.badge-gestion {',
'    background-color: #f0f2f5;',
'    color: #444;           /* Gris oscuro (GANA este color) */',
'    padding: 2px 8px;',
'    border-radius: 12px;',
'    font-size: 0.85em;     /* Redundante pero inofensivo */',
'    font-weight: 600;      /* Semi-bold (GANA este peso) */',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240919133731Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260702213820Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(85917880935651803)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(117083535157036718)
,p_plug_name=>'Buscar & Gestionar'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:t-TabsRegion-mod--fillLabels:t-TabsRegion-mod--pill:t-TabsRegion-mod--large'
,p_plug_template=>wwv_flow_imp.id(295637154502037690)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'SESSION')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20251113155409Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(85918099246651805)
,p_plug_name=>'Requisiciones'
,p_parent_plug_id=>wwv_flow_imp.id(117083535157036718)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20250521193724Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(85918475626651809)
,p_plug_name=>'Requisiciones'
,p_parent_plug_id=>wwv_flow_imp.id(85918099246651805)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with',
unistr('-- 1. Primero filtrar requisiciones candidatas (acceso m\00EDnimo a vistas)'),
'w_requisiciones_base AS (',
'	select req.phdcto as documentotipo',
'		, req.phdoco as documento',
'		, req.phmcu as bodegacodigo',
'		, req.phtrdj as fecha',
'		, req.phorby as usuario_creador',
'		, req.mcdc as unidadnegocio_des',
'		, req.photot as valor',
'		, req.phkcoo as compania',
'	from data.vt_comp_ordencompracab req',
'	where req.phdcto in (''H1'',''H2'',''H3'')',
'		and req.phkcoo = :g_compania',
'		and req.phtrdj between to_date(:p201_desde,''dd/mm/yyyy'') and to_date(:p201_hasta,''dd/mm/yyyy'')',
'		and (:p201_new_tipo_req is null or req.phdcto = :p201_new_tipo_req)',
'		and data.pk_comp_gestioncompras.f_gestionporun(:g_compania,req.phmcu,:app_user) = 1',
'),',
'-- 2. Filtrar solo documentos con generar_oc = 1 (un solo acceso a la vista)',
'w_docs_con_oc as (',
'	select distinct rd.documentotipo, rd.documento',
'	from data.vt_comp_f4311 rd',
'	inner join w_requisiciones_base rb on rd.documentotipo = rb.documentotipo and rd.documento = rb.documento',
'	where rd.generar_oc = 1',
'),',
'-- 3. Requisiciones filtradas finales',
'w_requisiciones_filtradas AS (',
'    select rb.*',
'    from w_requisiciones_base rb',
'    inner join w_docs_con_oc doc on rb.documentotipo = doc.documentotipo and rb.documento = doc.documento',
'),',
'-- 4. Procesados simplificado',
'w_procesados as (',
'    select documentotipo, documento',
'    from data.t_comp_f4311_gestion',
'    where fecha_procesado is not null and documentotipo_oc is not null and documento_oc is not null',
'    group by documentotipo, documento',
'),',
unistr('-- 5. Conteo de l\00EDneas SOLO para documentos filtrados'),
'w_f4311_count as (',
'    select pddcto as documentotipo, pddoco as documento, count(*) as count_lineas',
'    from data.vt_comp_ordencompradet',
'    inner join w_requisiciones_filtradas rf on pddcto = rf.documentotipo and pddoco = rf.documento',
'    where pddcto in (''H1'',''H2'',''H3'')',
'    group by pddcto, pddoco',
'),',
unistr('-- 6. Gesti\00F3n con conteo SOLO para documentos filtrados'),
'w_gestion_count AS (',
'    select g.documentotipo',
'		, g.documento',
'		, count(*) as count_gestion',
'		, listagg(distinct usuario, '', '') within group (order by usuario) as usuarios',
'    from data.t_comp_f4311_gestion g',
'    inner join w_requisiciones_filtradas rf on g.documentotipo = rf.documentotipo and g.documento = rf.documento',
'    group by g.documentotipo, g.documento',
'),',
'-- 7. Usuarios combinado',
'w_usuarios AS (',
'	select f.documentotipo, f.documento, f.count_lineas,',
'		case',
'			when g.count_gestion is null or g.count_gestion = 0 then null',
'			when g.count_gestion < f.count_lineas then g.usuarios || '' *PARCIAL*''',
'			when g.count_gestion = f.count_lineas then g.usuarios',
'			else null',
'		end as usuario',
'    from w_f4311_count f',
'    left join w_gestion_count g on f.documentotipo = g.documentotipo and f.documento = g.documento',
') select req.documentotipo',
'	, req.documento',
'	, req.bodegacodigo',
'	, req.bodegacodigo AS bodegacod',
'	, req.fecha',
'	, trunc(sysdate) - req.fecha as dias',
'	, req.usuario_creador as usuario',
'	, req.unidadnegocio_des as centro_costo',
'	, cast(null as varchar2(10)) as estado -- Campo estado no necesario',
'	, req.valor',
'	, proc.documentotipo as existente',
'	, req.documentotipo || ''-'' || req.documento as boton_seleccionar',
'	, pk_comp_ordenescompra.f_comentario@jdedtadl(req.compania, req.documentotipo, req.documento) as comentario',
'	, case',
'		when data.pk_apex_archivos.f_cantidadarchivos(',
'            p_tabla => ''T_COMP_ORDENES'',',
'            p_idtabla => req.documento,',
'            p_tipo => req.documentotipo',
'        ) > 0',
'        then ''<span title="Ver archivos adjuntos" class="fa fa-paperclip" style="color: #555555;"></span>''',
'		else null',
'    end as adjunto',
'	, u.usuario as gestion_por',
'	, u.count_lineas',
'from w_requisiciones_filtradas req',
'left join w_procesados proc on req.documentotipo = proc.documentotipo and req.documento = proc.documento',
'left join w_usuarios u on req.documentotipo = u.documentotipo and req.documento = u.documento'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Requisiciones'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20260702213820Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(85918612787651811)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'DCUEVA'
,p_internal_uid=>85918612787651811
,p_updated_on=>wwv_flow_imp.dz('20260702213820Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85918764528651812)
,p_db_column_name=>'DOCUMENTOTIPO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85918829380651813)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Documento'
,p_column_link=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.:202:P202_DOCUMENTO,P202_DOCUMENTOTIPO,P202_BOTON_AGREGAR:#DOCUMENTO#,#DOCUMENTOTIPO#,1'
,p_column_linktext=>'#DOCUMENTO#'
,p_column_link_attr=>'class="doc-solido"'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251126195116Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(102483307600410701)
,p_db_column_name=>'BODEGACOD'
,p_display_order=>30
,p_column_identifier=>'L'
,p_column_label=>'Bod.C.'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_updated_on=>wwv_flow_imp.dz('20251126211647Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85918901368651814)
,p_db_column_name=>'BODEGACODIGO'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Bodega'
,p_column_html_expression=>'<span class="dato-secundario">#BODEGACODIGO#</span>'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(102052470684402594)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251126211647Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85919051985651815)
,p_db_column_name=>'FECHA'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85919162694651816)
,p_db_column_name=>'DIAS'
,p_display_order=>70
,p_column_identifier=>'E'
,p_column_label=>unistr('D\00EDas')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85919252298651817)
,p_db_column_name=>'USUARIO'
,p_display_order=>80
,p_column_identifier=>'F'
,p_column_label=>'Originador'
,p_column_html_expression=>'<span class="dato-secundario">#USUARIO#</span>'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251126211336Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85919311590651818)
,p_db_column_name=>'CENTRO_COSTO'
,p_display_order=>90
,p_column_identifier=>'G'
,p_column_label=>'Centro Costo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85919499321651819)
,p_db_column_name=>'ESTADO'
,p_display_order=>100
,p_column_identifier=>'H'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85919643371651821)
,p_db_column_name=>'VALOR'
,p_display_order=>110
,p_column_identifier=>'I'
,p_column_label=>'Valor'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85921543070651840)
,p_db_column_name=>'BOTON_SELECCIONAR'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'-'
,p_column_link=>'javascript:void(null);'
,p_column_linktext=>unistr('<span class="t-Icon fa fa-plus req-sel" title="Agregar todos los ITEMS de esta requisici\00F3n" aria-hidden="true"></span>')
,p_column_link_attr=>'data-tipo=#DOCUMENTOTIPO#  data-doc=#DOCUMENTO# style="display: block"'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251126200242Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(117085290615036735)
,p_db_column_name=>'EXISTENTE'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'PROCESADO'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123876464387603908)
,p_db_column_name=>'ADJUNTO'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'<span class="fa fa-paperclip" aria-hidden="true"></span>'
,p_column_link=>'f?p=100:401:&SESSION.::&DEBUG.::P401_TIPO,P401_ID,P401_TABLA,P401_ESTADO:#DOCUMENTOTIPO#,#DOCUMENTO#,T_COMP_ORDENES,0'
,p_column_linktext=>'#ADJUNTO#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251126210536Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(135329054604177502)
,p_db_column_name=>'GESTION_POR'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>unistr('Gesti\00F3n')
,p_column_html_expression=>'<span class="dato-secundario">#GESTION_POR#</span>'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251126213945Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(141993260732401409)
,p_db_column_name=>'COMENTARIO'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Comentario'
,p_column_html_expression=>'<div class="comentario-wrap">#COMENTARIO#<span class="comentario-full">#COMENTARIO#</span></div>'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251126211227Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184015830518703702)
,p_db_column_name=>'COUNT_LINEAS'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>unistr('\00CDtems')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250521194011Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(85953364869254562)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'859534'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENTOTIPO:DOCUMENTO:ADJUNTO:DIAS:FECHA:BODEGACODIGO:USUARIO:GESTION_POR:COUNT_LINEAS:COMENTARIO:'
,p_sort_column_1=>'FECHA'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'DOCUMENTOTIPO'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'DOCUMENTO'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20240919133731Z')
,p_updated_on=>wwv_flow_imp.dz('20251126212342Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(117083733105036720)
,p_plug_name=>'&P201_MRK_OC.'
,p_parent_plug_id=>wwv_flow_imp.id(117083535157036718)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20251202204506Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(86194492254944608)
,p_plug_name=>'Items seleccionados'
,p_region_name=>'rptItemsSeleccionados'
,p_parent_plug_id=>wwv_flow_imp.id(117083733105036720)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'',
'    APEX_ITEM.HIDDEN(P_IDX =>1, P_VALUE =>F4311.DOCUMENTOTIPO||''-''||F4311.DOCUMENTO||''-''||F4311.LINEA )',
'        ||',
'    APEX_ITEM.CHECKBOX2(P_IDX =>2, P_VALUE =>F4311.DOCUMENTOTIPO||''-''||F4311.DOCUMENTO||''-''||F4311.LINEA )',
'                            AS CB,',
'',
'    F4311.DOCUMENTOTIPO,',
'    F4311.DOCUMENTO,',
'    F4311.LINEA,',
'',
'    F4311.ESTADO_ANT||''-''||F4311.ESTADO_SIG AS ESTADO,',
'    ',
'    F4311.CODIGOPRODUCTO,',
'    F4311.CODIGOCORTOPRODUCTO,',
'    F4311.CODIGOPRODUCTO||'' - ''||F4311.PRODUCTO||'' - ''||F4311.UNIDADMEDIDA',
'                            AS PRODUCTO,',
'    F4311.DESCRIPCION,',
'    F4311.CANTIDAD,',
'    TRIM(GESTION.BODEGA)    AS BODEGA,',
'',
'    F4311.DOCUMENTOTIPO||''-''||F4311.DOCUMENTO||''-''||F4311.LINEA AS BOTON_BORRAR,',
'',
'	CASE WHEN pk_apex_archivos.f_cantidadarchivos(',
'		p_tabla 		=> ''T_COMP_ORDENES'',',
'		p_idtabla		=> F4311.DOCUMENTO,',
'		p_tipo 			=> F4311.DOCUMENTOTIPO) > 0 THEN ''<span class="fa fa-paperclip" aria-hidden="true"></span>'' ',
'        ',
'    END AS adjunto,',
'    ',
'    pk_comp_ordenescompra.f_comentario@jdedtadl(:g_compania,F4311.DOCUMENTOTIPO,F4311.DOCUMENTO,''A'',F4311.LINEA) com_aprobador,',
'    pk_comp_ordenescompra.f_comentario@jdedtadl(:g_compania,F4311.DOCUMENTOTIPO,F4311.DOCUMENTO,''P'',F4311.LINEA) com_proveedor',
'',
'FROM ',
'    VT_COMP_F4311        F4311,',
'    T_COMP_F4311_GESTION GESTION',
'WHERE ',
'    F4311.LINEA=GESTION.LINEA',
'    AND',
'    F4311.DOCUMENTOTIPO=GESTION.DOCUMENTOTIPO',
'    AND',
'    F4311.DOCUMENTO=GESTION.DOCUMENTO',
'    AND',
'    GESTION.FECHA_PROCESADO IS NULL',
'    AND',
'    GESTION.USUARIO = :APP_USER',
'    ;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P201_NEW_TIPO_REQ IN (''H1'',''H3'');'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Items seleccionados'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(86194533199944609)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>unistr('No hay items seleccionados. Busque las requisiciones y presione el \00EDcono + para agregar items.')
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_textbox=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'DCUEVA'
,p_internal_uid=>86194533199944609
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87337718486438801)
,p_db_column_name=>'CB'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'<input type="checkbox" id="selectunselectall">'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_static_id=>'cbItemSeleccionado'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103542984936998501)
,p_db_column_name=>'BODEGA'
,p_display_order=>20
,p_column_identifier=>'S'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(102052470684402594)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86194653828944610)
,p_db_column_name=>'DOCUMENTOTIPO'
,p_display_order=>30
,p_column_identifier=>'A'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86194775355944611)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>'Documento'
,p_column_link=>'f?p=&APP_ID.:202:&SESSION.::&DEBUG.:202:P202_DOCUMENTOTIPO,P202_DOCUMENTO:#DOCUMENTOTIPO#,#DOCUMENTO#'
,p_column_linktext=>'#DOCUMENTO#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86194862671944612)
,p_db_column_name=>'LINEA'
,p_display_order=>50
,p_column_identifier=>'C'
,p_column_label=>'LN'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86194985440944613)
,p_db_column_name=>'CODIGOPRODUCTO'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>unistr('C\00F3d. Prod.')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86195048019944614)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>70
,p_column_identifier=>'E'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(89399886707825502)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>80
,p_column_identifier=>'R'
,p_column_label=>unistr('Descripci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86195305792944617)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'Cant.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86195740298944621)
,p_db_column_name=>'BOTON_BORRAR'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'-'
,p_column_link=>'javascript:void(null);'
,p_column_linktext=>'<span class="t-Icon fa fa-trash borrar-item" aria-hidden="true"></span>'
,p_column_link_attr=>'data-tipo=#DOCUMENTOTIPO#  data-doc=#DOCUMENTO#  data-linea=#LINEA# style="display: block"'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87924590280756338)
,p_db_column_name=>'CODIGOCORTOPRODUCTO'
,p_display_order=>110
,p_column_identifier=>'L'
,p_column_label=>'Codigocortoproducto'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123876640703603910)
,p_db_column_name=>'ADJUNTO'
,p_display_order=>130
,p_column_identifier=>'U'
,p_column_label=>'@'
,p_column_link=>'f?p=100:401:&SESSION.::&DEBUG.::P401_TIPO,P401_ID,P401_TABLA,P401_ESTADO:#DOCUMENTOTIPO#,#DOCUMENTO#,T_COMP_ORDENES,0'
,p_column_linktext=>'#ADJUNTO#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(123878409762603928)
,p_db_column_name=>'ESTADO'
,p_display_order=>140
,p_column_identifier=>'V'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(141993301020401410)
,p_db_column_name=>'COM_APROBADOR'
,p_display_order=>150
,p_column_identifier=>'W'
,p_column_label=>'Com. Aprobador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(141993468386401411)
,p_db_column_name=>'COM_PROVEEDOR'
,p_display_order=>160
,p_column_identifier=>'X'
,p_column_label=>'Com. Proveedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(86204361196034646)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'862044'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CB:DOCUMENTOTIPO:DOCUMENTO:LINEA:PRODUCTO:DESCRIPCION:CANTIDAD:ESTADO:COM_APROBADOR:COM_PROVEEDOR:ADJUNTO:BOTON_BORRAR'
,p_sort_column_1=>'DOCUMENTOTIPO'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'DOCUMENTO'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'LINEA'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20240919133731Z')
,p_updated_on=>wwv_flow_imp.dz('20240919133731Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(87339055194438814)
,p_plug_name=>unistr('Seleccionar Proveedor y Negociaci\00F3n')
,p_region_name=>'idRegionSeleccionarProveedor'
,p_parent_plug_id=>wwv_flow_imp.id(117083733105036720)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>20
,p_plug_grid_column_css_classes=>'selectNeg'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id',
'	, producto',
'	, tipo_requisicion',
'	, con_requisicion',
'	, cantidad',
'	, fecha_compromiso',
'	, det_id',
'	, preciounitario',
'	, preciototal',
'	, codigocortoproducto',
'	, bodega',
'	, bodegatipo',
'	, det_codproveedor',
'	, proveedortipo',
'	, version',
'	, prod_proveedor',
'	, case',
'		when nvl(cantidad_manual,cantidad) > 0 ',
'		-- then ''<span title="Seleccionar Proveedor" class="fa fa-book" style="color: black;font-weight: bolder;"/>''',
'		then ''<span title="Seleccionar Proveedor" class="fa fa-search" style="color: #888888;"></span>''',
'		else '''' end icono_proveedor',
'	, case',
'		when cantidad_manual is not null',
'		then ''<span title="Editar Cantidad" class="fa fa-pencil" style="color: #F0AD4E;"></span>''',
'		else ''<span title="Editar Cantidad" class="fa fa-pencil" style="color: #888888;"></span>''',
'		end icono_editar',
'/*',
'	, case',
'		when cantidad_manual is not null',
'		then ''*<span title="Seleccionar Proveedor" class="fa fa-search" style="color: #888888;"></span>''',
'		else ''<span title="Seleccionar Proveedor" class="fa fa-search" style="color: #888888;"></span>''',
'		end icono_editar',
'*/',
'	, case ',
'		when con_requisicion = 0 or modo_agrupado is not null then ''block''',
'		else ''none''',
'		end as boton_eliminar',
'	, case',
'		when modo_agrupado is not null then ''block''',
'		else ''none''',
'		end as boton_duplicar',
'	, case',
'		when',
'			(det_puedereservar is null and pk_comp_gestioncompras.f_puede_reservar(codigocortoproducto) = 1)',
'				or',
'			(det_puedereservar is not null and det_puedereservar = 1)',
'			then',
'				case',
'					-- when reserva = 1 then ''<span title="Compra RESERVA" class="fa fa-check-square" style="color: red;font-weight: bolder;"/>''',
'					when reserva = 1 then ''<span title="Compra RESERVADA" class="fa fa-check-square" style="color: #00a65a;"></span>''',
'					-- else  ''<span title="Marca compra RESERVA" class="fa fa-square-o" style="color: black;font-weight: bolder;"/>''',
'					else  ''<span title="Marcar como RESERVA" class="fa fa-square-o" style="color: #888888;"></span>''',
'					end',
'			else '' ''',
'			end as icono_reservar',
'from data.vt_comp_pendiente_generar_oc',
'where 1 = 1',
'	and tipo_requisicion in (''H1'',''H3'')',
'	and compania = :g_compania    ',
'	and usuario = :app_user',
'	and fecha_procesado is null'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P201_NEW_TIPO_REQ IN (''H1'',''H3'');'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Gesti\00F3n por producto')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<b>IMPORTANTE:</b>',
'<br>',
unistr('1.- Cuando se cambie la cantidad de un producto ya sea manualmente o debido a cambios en las requisiciones seleccionadas, se debe establecer una nueva negociaci\00F3n.'),
''))
,p_updated_on=>wwv_flow_imp.dz('20251114151239Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(87339124680438815)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>unistr('No hay productos para gestionar. Busque las requisiciones y presione el \00EDcono + para agregar productos.')
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'DCUEVA'
,p_internal_uid=>87339124680438815
,p_updated_on=>wwv_flow_imp.dz('20251114151239Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103543058176998502)
,p_db_column_name=>'TIPO_REQUISICION'
,p_display_order=>10
,p_column_identifier=>'U'
,p_column_label=>'Tipo'
,p_column_html_expression=>'<span title="#ID#">#TIPO_REQUISICION#</span>'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103543264467998504)
,p_db_column_name=>'BODEGA'
,p_display_order=>20
,p_column_identifier=>'W'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103543352948998505)
,p_db_column_name=>'BODEGATIPO'
,p_display_order=>30
,p_column_identifier=>'X'
,p_column_label=>'BT'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87339960470438823)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>50
,p_column_identifier=>'H'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92799703859640804)
,p_db_column_name=>'FECHA_COMPROMISO'
,p_display_order=>60
,p_column_identifier=>'T'
,p_column_label=>'F. Comp'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251008144337Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87339768723438821)
,p_db_column_name=>'PRECIOUNITARIO'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'P. Unit.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(106308098612728601)
,p_db_column_name=>'DET_CODPROVEEDOR'
,p_display_order=>80
,p_column_identifier=>'AA'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87339814158438822)
,p_db_column_name=>'PRECIOTOTAL'
,p_display_order=>90
,p_column_identifier=>'G'
,p_column_label=>'P. Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91371191862973013)
,p_db_column_name=>'ICONO_EDITAR'
,p_display_order=>100
,p_column_identifier=>'Q'
,p_column_label=>'-'
,p_column_link=>'f?p=&APP_ID.:204:&SESSION.::&DEBUG.:204:P204_PPGESTION_ID,P204_MODO_AGRUPADO:#ID#,&P201_MODO_AGRUPADO.'
,p_column_linktext=>'#ICONO_EDITAR#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251114151239Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91370006128973002)
,p_db_column_name=>'ICONO_PROVEEDOR'
,p_display_order=>110
,p_column_identifier=>'L'
,p_column_label=>'-'
,p_column_link=>'f?p=&APP_ID.:203:&SESSION.::&DEBUG.:203:P203_PPGESTION_ID:#ID#'
,p_column_linktext=>'#ICONO_PROVEEDOR#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'ITEM_IS_ZERO'
,p_display_condition=>'P201_MODO_AGRUPADO'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251114151239Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(158618796381852601)
,p_db_column_name=>'ICONO_RESERVAR'
,p_display_order=>120
,p_column_identifier=>'AE'
,p_column_label=>'RSV.'
,p_column_link=>'JavaScript:$s("P201_RESERVA_ID", "");$s("P201_RESERVA_ID",''#ID#'');'
,p_column_linktext=>'#ICONO_RESERVAR#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'ITEM_IS_ZERO'
,p_display_condition=>'P201_MODO_AGRUPADO'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251114151239Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91370120943973003)
,p_db_column_name=>'CODIGOCORTOPRODUCTO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Codigocortoproducto'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91370420432973006)
,p_db_column_name=>'ID'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91370532292973007)
,p_db_column_name=>'DET_ID'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Det Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91370984788973011)
,p_db_column_name=>'PROD_PROVEEDOR'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Prod. Proveedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103543454166998506)
,p_db_column_name=>'PROVEEDORTIPO'
,p_display_order=>170
,p_column_identifier=>'Y'
,p_column_label=>'PT'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103543167815998503)
,p_db_column_name=>'CON_REQUISICION'
,p_display_order=>180
,p_column_identifier=>'V'
,p_column_label=>'Con Requisicion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(103543579545998507)
,p_db_column_name=>'VERSION'
,p_display_order=>190
,p_column_identifier=>'Z'
,p_column_label=>unistr('Versi\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(117082036036036703)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>200
,p_column_identifier=>'AD'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20241105215519Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200196008860652311)
,p_db_column_name=>'BOTON_DUPLICAR'
,p_display_order=>210
,p_column_identifier=>'AF'
,p_column_label=>'||'
,p_column_link=>'javascript:void(null);'
,p_column_linktext=>'<span class="t-Icon fa fa-copy grp-dup" title="Duplicar" aria-hidden="true"></span>'
,p_column_link_attr=>'data-grpid=#ID#   style="display: #BOTON_DUPLICAR#"'
,p_column_type=>'STRING'
,p_display_condition_type=>'ITEM_IS_NOT_ZERO'
,p_display_condition=>'P201_MODO_AGRUPADO'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(113731751965020321)
,p_db_column_name=>'BOTON_ELIMINAR'
,p_display_order=>220
,p_column_identifier=>'AC'
,p_column_label=>'-'
,p_column_link=>'javascript:void(null);'
,p_column_linktext=>'<span class="t-Icon fa fa-trash-o grp-del" title="Eliminar producto manual" aria-hidden="true"></span>'
,p_column_link_attr=>'data-grpid=#ID#   style="display: #BOTON_ELIMINAR#"'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(87524918090719909)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_report_alias=>'875250'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_view_mode=>'REPORT'
,p_report_columns=>'TIPO_REQUISICION:BODEGA:PRODUCTO:DET_CODPROVEEDOR:ICONO_PROVEEDOR:FECHA_COMPROMISO:CANTIDAD:ICONO_EDITAR:PRECIOUNITARIO:PRECIOTOTAL:BOTON_DUPLICAR:ICONO_RESERVAR:BOTON_ELIMINAR:'
,p_sort_column_1=>'PRODUCTO'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'FECHA_COMPROMISO'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_sum_columns_on_break=>'PRECIOTOTAL'
,p_created_on=>wwv_flow_imp.dz('20240919133731Z')
,p_updated_on=>wwv_flow_imp.dz('20240919133731Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(200196803623652319)
,p_plug_name=>'Seleccione el proveedor'
,p_parent_plug_id=>wwv_flow_imp.id(87339055194438814)
,p_region_css_classes=>'selectAgrupado'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    PRODUCTO,',
'    CODIGOCORTOPRODUCTO,',
'    DET_CODPROVEEDOR,',
'    DET_ID,',
'    SUM(NVL(CANTIDAD_MANUAL, CANTIDAD)) AS CANTIDAD,',
'    ''<span title="Seleccionar Proveedor" class="fa fa-book" style="color: black;font-weight: bolder;"/>'' AS ICONO_PROVEEDOR',
'    ',
'FROM ',
'    VT_COMP_PENDIENTE_GENERAR_OC',
'WHERE',
'    COMPANIA      = :G_COMPANIA    ',
'        AND',
'    USUARIO       = :APP_USER',
'        AND',
'    FECHA_PROCESADO IS NULL ',
'GROUP BY ',
'    PRODUCTO,',
'    CODIGOCORTOPRODUCTO,',
'    DET_CODPROVEEDOR,',
'    DET_ID',
';'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'ITEM_IS_NOT_ZERO'
,p_plug_display_when_condition=>'P201_MODO_AGRUPADO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Seleccione el proveedor'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(200196995115652320)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>200196995115652320
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200197075831652321)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200197167070652322)
,p_db_column_name=>'CODIGOCORTOPRODUCTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Codigocortoproducto'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200197235090652323)
,p_db_column_name=>'DET_CODPROVEEDOR'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200197397372652324)
,p_db_column_name=>'DET_ID'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Det Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200197418420652325)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200197575034652326)
,p_db_column_name=>'ICONO_PROVEEDOR'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'#'
,p_column_link=>'f?p=&APP_ID.:212:&SESSION.::&DEBUG.:212:P212_DET_ID,P212_CODIGOCORTOPRODUCTO,P212_CANTIDAD,P212_RESERVA:#DET_ID#,#CODIGOCORTOPRODUCTO#,#CANTIDAD#,0'
,p_column_linktext=>'#ICONO_PROVEEDOR#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(200228310245096290)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2002284'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PRODUCTO:DET_CODPROVEEDOR:ICONO_PROVEEDOR:CANTIDAD:'
,p_created_on=>wwv_flow_imp.dz('20240919133731Z')
,p_updated_on=>wwv_flow_imp.dz('20240919133731Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(117082157901036704)
,p_plug_name=>'Generar Orden de Compra'
,p_parent_plug_id=>wwv_flow_imp.id(117083733105036720)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>40
,p_plug_grid_column_css_classes=>'generaOC '
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'',
'    TIPO_REQUISICION               AS TIPO_REQUISICION,',
'    CODBODEGA                      AS CODBODEGA,',
'    BODEGA                         AS BODEGA,',
'',
'    CODPROVEEDOR                   AS DET_CODPROVEEDOR,',
'    MODO_AGRUPADO                  AS MODO_AGRUPADO,',
'    RESERVA                        AS,',
'',
'    DET_CODPROVEEDOR||'' | ''||NVL(VERSION, ''S/V'')||''-''||FORMAPAGO||''-''||INCOTERM||',
'        CASE',
'            WHEN RESERVA = 0 ',
'                THEN NULL',
'                ELSE '' | <span style="color:red;">RESERVA</span>''',
'        END    ',
'    AS DESC_PROVEEDOR,',
'',
'    VERSION                        AS VERSION,',
'    ',
'    CASE',
'        WHEN RESERVA = 0 ',
'            THEN ROUND(sum(NVL(PRECIOTOTAL,0)),4) ',
'            ELSE 0.0001',
'    END AS MONTO,',
'',
'    TO_CHAR(',
'        CASE',
'            WHEN RESERVA = 0 ',
'                THEN ROUND(sum(NVL(PRECIOTOTAL,0)),4) ',
'                ELSE 0.0001',
'        END',
'        , ''9999999990.00''',
'    )',
'    AS P211_MONTO,',
'',
'    SUM(CANTIDAD)                  AS CANTIDAD,',
'    SUM(CANTIDAD)                  AS CANTIDAD_COL,',
'',
'    COUNT(1)                       AS CANT_PROD,',
'    MAX(FECHA_COMPROMISO)          AS FECHA_COMPROMISO,',
'    ------------------------',
'    ''block''                        AS DISPLAY,',
'    CODPROVEEDOR                   AS BOTON_GENERAR,',
'    CASE',
'        WHEN RESERVA = 0 ',
'            THEN ''color: black;''',
'            ELSE ''color: red;''',
'    END AS COLOR_RESERVA',
'',
'FROM ',
'    VT_COMP_PENDIENTE_GENERAR_OC',
'WHERE',
'    COMPANIA     = :G_COMPANIA',
'        AND',
'    USUARIO      = :APP_USER',
'        AND',
'    CODPROVEEDOR IS NOT NULL',
'        AND',
'    FECHA_COMPROMISO IS NOT NULL',
'        AND',
'    FECHA_PROCESADO IS NULL',
'    ',
'GROUP BY ',
'    COMPANIA, ',
'    TIPO_REQUISICION, ',
'    CODBODEGA, ',
'    BODEGA, ',
'    VERSION, ',
'    CODPROVEEDOR, ',
'    DET_CODPROVEEDOR, ',
'    RESERVA,',
'    FORMAPAGO,',
'    INCOTERM,',
'    MODO_AGRUPADO',
';',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Generar Orden de Compra'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<b>IMPORTANTE:</b>',
'<br>',
unistr('1.- Para generar una OC para un determinado producto se requiere establecer para dicho producto: una negociaci\00F3n y su fecha de compromiso.'),
'<br>',
unistr('2.- Para generar una OC para un determinado proveedor, <u><b>TODOS</b></u> los productos de dicho proveeder deben tener establecido: una negociaci\00F3n y su fecha de compromiso.')))
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(117082277445036705)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>unistr('Para generar OCs los productos deben tener su respectiva negociaci\00F3n y fecha de compromiso.')
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'DCUEVA'
,p_internal_uid=>117082277445036705
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(117082306425036706)
,p_db_column_name=>'TIPO_REQUISICION'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(117082462464036707)
,p_db_column_name=>'CODBODEGA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Codbodega'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(117082577959036708)
,p_db_column_name=>'BODEGA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(158619383836852607)
,p_db_column_name=>'DESC_PROVEEDOR'
,p_display_order=>50
,p_column_identifier=>'M'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(117082774527036710)
,p_db_column_name=>'VERSION'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>unistr('Versi\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(117082890927036711)
,p_db_column_name=>'MONTO'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(190516218303868242)
,p_db_column_name=>'P211_MONTO'
,p_display_order=>80
,p_column_identifier=>'Q'
,p_column_label=>'P211 Monto'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200197688120652327)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>90
,p_column_identifier=>'R'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'ITEM_IS_NOT_ZERO'
,p_display_condition=>'P201_MODO_AGRUPADO'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(211842917661642301)
,p_db_column_name=>'CANTIDAD_COL'
,p_display_order=>100
,p_column_identifier=>'T'
,p_column_label=>'Cantidad Col'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(117082928312036712)
,p_db_column_name=>'CANT_PROD'
,p_display_order=>110
,p_column_identifier=>'G'
,p_column_label=>'Prods.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200198287909652333)
,p_db_column_name=>'MODO_AGRUPADO'
,p_display_order=>120
,p_column_identifier=>'S'
,p_column_label=>'Modo Agrupado'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(117083053885036713)
,p_db_column_name=>'FECHA_COMPROMISO'
,p_display_order=>130
,p_column_identifier=>'H'
,p_column_label=>'Compromiso'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(117083230746036715)
,p_db_column_name=>'BOTON_GENERAR'
,p_display_order=>140
,p_column_identifier=>'J'
,p_column_label=>'+'
,p_column_link=>'f?p=&APP_ID.:211:&SESSION.::&DEBUG.:Y,,211:P211_GOC_TIPO_REQUISICION,P211_GOC_CODBODEGA,P211_GOC_DET_CODPROVEEDOR,P211_GOC_RESERVA,P211_MONTO,P211_FECHA_COMPROMISO,P211_MODO_AGRUPADO,P211_CANTIDAD:#TIPO_REQUISICION#,#CODBODEGA#,#DET_CODPROVEEDOR#,#RE'
||'SERVA#,#P211_MONTO#,#FECHA_COMPROMISO#,#MODO_AGRUPADO#,#CANTIDAD_COL#'
,p_column_linktext=>'<span class="t-Icon fa fa-check-circle-o genera-oc" aria-hidden="true" title="Enviar a JDE" ></span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'ITEM_IS_ZERO'
,p_display_condition=>'P201_MODO_AGRUPADO'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(117083841865036721)
,p_db_column_name=>'DISPLAY'
,p_display_order=>150
,p_column_identifier=>'K'
,p_column_label=>'Display'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(158619251170852606)
,p_db_column_name=>'COLOR_RESERVA'
,p_display_order=>160
,p_column_identifier=>'L'
,p_column_label=>'Color Reserva'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(158619460948852608)
,p_db_column_name=>'DET_CODPROVEEDOR'
,p_display_order=>170
,p_column_identifier=>'N'
,p_column_label=>'Det Codproveedor'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(163555841294845802)
,p_db_column_name=>'RESERVA'
,p_display_order=>180
,p_column_identifier=>'O'
,p_column_label=>'Reserva'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(117115984563503495)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1171160'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TIPO_REQUISICION:BODEGA:DESC_PROVEEDOR:CANTIDAD:MONTO:CANT_PROD:FECHA_COMPROMISO:BOTON_GENERAR:'
,p_sort_column_1=>'FECHA_COMPROMISO'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20240919133731Z')
,p_updated_on=>wwv_flow_imp.dz('20240919133731Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(184016026117703704)
,p_plug_name=>'Gestionar no Inventariables'
,p_region_name=>'rptItemsH2'
,p_parent_plug_id=>wwv_flow_imp.id(117083733105036720)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>30
,p_plug_grid_column_css_classes=>'gestionH2 '
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    APEX_ITEM.HIDDEN(P_IDX =>1, P_VALUE =>P.ID )',
'        ||',
'    APEX_ITEM.CHECKBOX2(P_IDX =>2, P_VALUE => P.ID )',
'                            AS CB',
'	, P.ID',
'	, P.PRODUCTO',
'	, P.TIPO_REQUISICION',
'	, P.CON_REQUISICION',
'	, NVL(P.CANTIDAD_MANUAL, P.CANTIDAD)  AS CANTIDAD',
'	, P.FECHA_COMPROMISO',
'	, P.DET_ID',
'	, P.PRECIOUNITARIO',
'	, P.PRECIOTOTAL',
'	, P.CODIGOCORTOPRODUCTO',
'	, P.BODEGA',
'	, P.BODEGATIPO',
'	, P.REQUISITOR',
'	, P.DESTINO CODDESTINO',
'	, P.DESTINO',
'	, P.MANUAL_CODPROVEEDOR',
'	, P.PROVEEDORTIPO',
'	, P.VERSION',
'	, P.DESCRIPCION1',
'	, P.DESCRIPCION2',
'	, CASE',
'		WHEN P.CANTIDAD_MANUAL IS NOT NULL',
'			THEN ''*<span title="Proveedor" class="fa fa-pencil" style="color: #888888;"></span>''',
'			ELSE ''<span title="Proveedor" class="fa fa-pencil" style="color: #888888;"></span>''',
'		END AS ICONO_EDITAR',
'	, P.ID AS BOTON_BORRAR',
'FROM',
'	VT_COMP_PENDIENTE_GENERAR_OC P',
'WHERE 1 = 1',
'		and',
'	P.TIPO_REQUISICION = ''H2''',
'		and',
'	P.COMPANIA      = :G_COMPANIA    ',
'		and',
'	P.USUARIO       = :APP_USER',
'		and',
'	P.FECHA_PROCESADO IS NULL     ',
'    '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P201_NEW_TIPO_REQ IN (''H2'');'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Gestionar no inventariables H2'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20251126153700Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(184016123764703705)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>184016123764703705
,p_updated_on=>wwv_flow_imp.dz('20251126153700Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184017962526703723)
,p_db_column_name=>'CB'
,p_display_order=>10
,p_column_identifier=>'H'
,p_column_label=>'<input type="checkbox" id="selectunselectH2">'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_static_id=>'itemSeleccionadoH2'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184016727394703711)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>20
,p_column_identifier=>'F'
,p_column_label=>'Producto'
,p_column_html_expression=>'<span title="id=#ID#" >#PRODUCTO#</span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184016354228703707)
,p_db_column_name=>'PRECIOUNITARIO'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'P. Unit.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184016411701703708)
,p_db_column_name=>'CODIGOCORTOPRODUCTO'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Codigocortoproducto'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184016544026703709)
,p_db_column_name=>'BODEGA'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184016621018703710)
,p_db_column_name=>'BODEGATIPO'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Bodegatipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184018438006703728)
,p_db_column_name=>'ID'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184018554446703729)
,p_db_column_name=>'TIPO_REQUISICION'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Tipo Requisicion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184018646114703730)
,p_db_column_name=>'CON_REQUISICION'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Con Requisicion'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184018716301703731)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Cant.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(187266699292064701)
,p_db_column_name=>'MANUAL_CODPROVEEDOR'
,p_display_order=>130
,p_column_identifier=>'X'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(185688337882482745)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184018820227703732)
,p_db_column_name=>'FECHA_COMPROMISO'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>'Fecha Comp.'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251126153543Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184019522043703739)
,p_db_column_name=>'DESCRIPCION1'
,p_display_order=>150
,p_column_identifier=>'T'
,p_column_label=>unistr('Descripci\00F3n 1')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184019601440703740)
,p_db_column_name=>'DESCRIPCION2'
,p_display_order=>160
,p_column_identifier=>'U'
,p_column_label=>unistr('Descripci\00F3n 2')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184018912651703733)
,p_db_column_name=>'DET_ID'
,p_display_order=>170
,p_column_identifier=>'N'
,p_column_label=>'Det Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184019019614703734)
,p_db_column_name=>'PRECIOTOTAL'
,p_display_order=>180
,p_column_identifier=>'O'
,p_column_label=>'P. Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184019235732703736)
,p_db_column_name=>'PROVEEDORTIPO'
,p_display_order=>190
,p_column_identifier=>'Q'
,p_column_label=>'Proveedortipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184019360628703737)
,p_db_column_name=>'VERSION'
,p_display_order=>200
,p_column_identifier=>'R'
,p_column_label=>'Version'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184019728621703741)
,p_db_column_name=>'ICONO_EDITAR'
,p_display_order=>210
,p_column_identifier=>'V'
,p_column_label=>'*'
,p_column_link=>'f?p=&APP_ID.:209:&SESSION.::&DEBUG.::P209_PPGESTION_ID:#ID#'
,p_column_linktext=>'#ICONO_EDITAR#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251112194759Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(184017057915703714)
,p_db_column_name=>'BOTON_BORRAR'
,p_display_order=>220
,p_column_identifier=>'G'
,p_column_label=>'-'
,p_column_link=>'javascript:void(null);'
,p_column_linktext=>'<span title="Borrar" class="fa fa-trash-o" style="color: #888888;"></span>'
,p_column_link_attr=>'data-id=#ID# style="display: block"'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>'1 = 0'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251112193557Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(193639398540054001)
,p_db_column_name=>'REQUISITOR'
,p_display_order=>230
,p_column_identifier=>'Y'
,p_column_label=>'Requisitor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251112171928Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(193639458336054002)
,p_db_column_name=>'DESTINO'
,p_display_order=>240
,p_column_identifier=>'Z'
,p_column_label=>'Desc. Destino'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251126153644Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(266496459563507001)
,p_db_column_name=>'CODDESTINO'
,p_display_order=>250
,p_column_identifier=>'AA'
,p_column_label=>'Destino'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251126153247Z')
,p_updated_on=>wwv_flow_imp.dz('20251126153644Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(184031803522195747)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1840319'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ICONO_EDITAR:CODDESTINO:REQUISITOR:MANUAL_CODPROVEEDOR:PRODUCTO:DESCRIPCION1:DESCRIPCION2:FECHA_COMPROMISO:CANTIDAD:PRECIOUNITARIO:PRECIOTOTAL:CB:'
,p_sum_columns_on_break=>'PRECIOTOTAL'
,p_created_on=>wwv_flow_imp.dz('20240919133731Z')
,p_updated_on=>wwv_flow_imp.dz('20251126153700Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(266496558721507002)
,p_plug_name=>'Ocultos'
,p_region_name=>'regOcultos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20251126175740Z')
,p_updated_on=>wwv_flow_imp.dz('20251126175740Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(119159435960955311)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(85917880935651803)
,p_button_name=>'REGRESAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
,p_updated_on=>wwv_flow_imp.dz('20251126154402Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(124268008582950510)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(85917880935651803)
,p_button_name=>'LOGS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Logs'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:1000:&SESSION.::&DEBUG.:1000::'
,p_button_condition=>'1 = 0'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-eye-slash'
,p_updated_on=>wwv_flow_imp.dz('20251126154418Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(201196921743461301)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(117082157901036704)
,p_button_name=>'GENERAR_OCS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--warning'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Generar Ocs'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:200:G_NAVEGACION_AGRUPADO:1'
,p_button_condition=>'P201_MODO_AGRUPADO'
,p_button_condition_type=>'ITEM_IS_NOT_ZERO'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85919524533651820)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(85917880935651803)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
,p_updated_on=>wwv_flow_imp.dz('20251126154418Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(141896564471069215)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(87339055194438814)
,p_button_name=>'BOTONSALTO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Botonsalto'
,p_button_alignment=>'RIGHT'
,p_button_condition_type=>'NEVER'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(173241638043721305)
,p_button_sequence=>200
,p_button_plug_id=>wwv_flow_imp.id(266496558721507002)
,p_button_name=>'GOTO_200'
,p_button_static_id=>'GOTO_200'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Goto 200'
,p_button_redirect_url=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:::'
,p_button_cattributes=>'style="display:none;"'
,p_grid_new_row=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20251126175949Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(200195227808652303)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(117082157901036704)
,p_button_name=>'AGRUPADO_ON'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Iniciar Agrupar OCs'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P201_MODO_AGRUPADO'
,p_button_condition_type=>'ITEM_IS_ZERO'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(200195644469652307)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(117082157901036704)
,p_button_name=>'AGRUPADO_OFF'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Agrupado OFF'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P201_MODO_AGRUPADO'
,p_button_condition_type=>'ITEM_IS_NOT_ZERO'
,p_button_cattributes=>'style="display: none;"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(91373629796973038)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(86194492254944608)
,p_button_name=>'AGREGAR_SIN_REQ'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>unistr('Agregar Sin Requisici\00F3n')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:205:&SESSION.::&DEBUG.:205:P205_TIPO_REQ:&P201_NEW_TIPO_REQ.'
,p_button_condition=>'P201_NEW_TIPO_REQ'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-cart-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(187267933455064714)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(184016026117703704)
,p_button_name=>'AGREGAR_SIN_REQ_H2'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Agregar s/RQ'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:205:&SESSION.::&DEBUG.:205:P205_TIPO_REQ:&P201_NEW_TIPO_REQ.'
,p_button_condition=>'P201_NEW_TIPO_REQ'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-cart-plus'
,p_updated_on=>wwv_flow_imp.dz('20251112181639Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(251157763636140707)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(87339055194438814)
,p_button_name=>'BOTON_PROVEEDOR_INV'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Proveedor'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:265:&SESSION.::&DEBUG.:265:P265_COMPANIA,P265_MODULO,P265_USUARIO,P265_OPCION1,P265_OPCION2:&G_COMPANIA.,&APP_MODULO.,&APP_USER.,INV,PROVEEDOR'
,p_icon_css_classes=>'fa-user-pointer'
,p_created_on=>wwv_flow_imp.dz('20251114164833Z')
,p_updated_on=>wwv_flow_imp.dz('20251201150758Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(224414709514993450)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(184016026117703704)
,p_button_name=>'BOTON_PROVEEDOR_H2'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Proveedor'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:265:&SESSION.::&DEBUG.:265:P265_COMPANIA,P265_MODULO,P265_USUARIO,P265_OPCION1,P265_OPCION2:&G_COMPANIA.,&APP_MODULO.,&APP_USER.,NOINV,PROVEEDOR'
,p_icon_css_classes=>'fa-user-pointer'
,p_created_on=>wwv_flow_imp.dz('20251113151341Z')
,p_updated_on=>wwv_flow_imp.dz('20251117163123Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(251157640668140706)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(87339055194438814)
,p_button_name=>'BOTON_FECHACOMPROMISO_INV'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Fecha Compromiso'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:265:&SESSION.::&DEBUG.:265:P265_COMPANIA,P265_MODULO,P265_USUARIO,P265_OPCION1,P265_OPCION2:&G_COMPANIA.,&APP_MODULO.,&APP_USER.,INV,FECHACOMPROMISO'
,p_icon_css_classes=>'fa-calendar-o'
,p_created_on=>wwv_flow_imp.dz('20251114164833Z')
,p_updated_on=>wwv_flow_imp.dz('20251201150758Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(87337834277438802)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(86194492254944608)
,p_button_name=>'BORRAR_SELECCIONADOS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>unistr('Borrar Selecci\00F3n')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_confirm_message=>'Eliminar los ITEMS marcados con check [v]'
,p_icon_css_classes=>'fa-check-square-o'
,p_updated_on=>wwv_flow_imp.dz('20251112171548Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(224410381635993406)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(184016026117703704)
,p_button_name=>'BOTON_FECHACOMPROMISO_H2'
,p_button_static_id=>'btnFechaCompromisoNINV'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Fecha Compromiso'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:265:&SESSION.::&DEBUG.:265:P265_COMPANIA,P265_MODULO,P265_USUARIO,P265_OPCION1,P265_OPCION2:&G_COMPANIA.,&APP_MODULO.,&APP_USER.,NOINV,FECHACOMPROMISO'
,p_icon_css_classes=>'fa-calendar-o'
,p_created_on=>wwv_flow_imp.dz('20251112181736Z')
,p_updated_on=>wwv_flow_imp.dz('20251117163123Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(87338095149438804)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(86194492254944608)
,p_button_name=>'BORRAR_TODOS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Borrar Todo'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_confirm_message=>'Eliminar todos los ITEMS.'
,p_icon_css_classes=>'fa-trash-o'
,p_updated_on=>wwv_flow_imp.dz('20251112171548Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(184018279658703726)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(184016026117703704)
,p_button_name=>'BORRAR_SELECCIONADOS_H2'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>unistr('Borrar Selecci\00F3n')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_confirm_message=>unistr('\00BFEst\00E1 seguro de eliminar los elementos seleccionados?')
,p_icon_css_classes=>'fa-check-square-o'
,p_updated_on=>wwv_flow_imp.dz('20251114212436Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(184016870545703712)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(184016026117703704)
,p_button_name=>'BORRAR_TODOS_H2'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Borrar Todo'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_confirm_message=>unistr('\00BFEst\00E1 seguro de eliminar todos los elementos?')
,p_icon_css_classes=>'fa-trash-o'
,p_updated_on=>wwv_flow_imp.dz('20251114212436Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85917973534651804)
,p_name=>'P201_REQ_SEL_TIPO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(266496558721507002)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20251126175948Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85918197070651806)
,p_name=>'P201_DESDE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(85918099246651805)
,p_prompt=>'Desde'
,p_source=>'SELECT SYSDATE-7 FROM DUAL;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_13=>'SELECTABLE'
,p_attribute_15=>'FOCUS'
,p_updated_on=>wwv_flow_imp.dz('20250521193619Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85918220964651807)
,p_name=>'P201_HASTA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(85918099246651805)
,p_prompt=>'Hasta'
,p_source=>'SELECT SYSDATE FROM DUAL;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_13=>'SELECTABLE'
,p_attribute_15=>'FOCUS'
,p_updated_on=>wwv_flow_imp.dz('20250521193619Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85918371663651808)
,p_name=>'P201_NEW_TIPO_REQ'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(85918099246651805)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    TRIM(DRKY)||'' ''||TRIM(DRDL01) AS LABEL,',
'    TRIM(DRKY)   AS VALUE',
'FROM vt_jde_udcjde where DRSY=''00'' AND DRRT =''DT'' AND DRKY IN(''H1'',''H2'',''H3'')',
'ORDER BY DRKY;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_read_only_when=>'P201_TIPO_H_ENCURSO'
,p_read_only_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20250521193533Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85921488057651839)
,p_name=>'P201_REQ_SEL_DOC'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(266496558721507002)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20251126175948Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86195581505944619)
,p_name=>'P201_REQ_BORRA_TIPO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(266496558721507002)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20251126175948Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86195652677944620)
,p_name=>'P201_REQ_BORRA_DOC'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(266496558721507002)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20251126175948Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86196213767944626)
,p_name=>'P201_REQ_BORRA_LINEA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(266496558721507002)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20251126175948Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(87921103502756304)
,p_name=>'P201_TIPO_H_ENCURSO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(266496558721507002)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20251126175947Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(88455289336246526)
,p_name=>'P201_COPY_CODIGOPROVEEDOR'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(266496558721507002)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20251126175948Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(88455367362246527)
,p_name=>'P201_COPY_CODIGOCORTOPRODUCTO'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(266496558721507002)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20251126175948Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(113731606159020320)
,p_name=>'P201_GRP_BORRA_ID'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(266496558721507002)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20251126175948Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(117083956393036722)
,p_name=>'P201_GOC_TIPO_REQUISICION'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(266496558721507002)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20251126175948Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(117084033266036723)
,p_name=>'P201_GOC_CODBODEGA'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(266496558721507002)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20251126175948Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(117084116816036724)
,p_name=>'P201_GOC_DET_CODPROVEEDOR'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(266496558721507002)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20251126175948Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(141896038867069210)
,p_name=>'P201_SALTAR_SELECT_PROVEEDOR'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(266496558721507002)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20251126175948Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(158618843321852602)
,p_name=>'P201_RESERVA_ID'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(266496558721507002)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20251126175949Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(163555746250845801)
,p_name=>'P201_GOC_RESERVA'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(266496558721507002)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20251126175948Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(184017462227703718)
,p_name=>'P201_REQ_BORRA_H2_ID'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(266496558721507002)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20251126175948Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200195008591652301)
,p_name=>'P201_MODO_AGRUPADO'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(266496558721507002)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20251126175948Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200196390104652314)
,p_name=>'P201_GRP_DUPLICA_ID'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(266496558721507002)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20251126175948Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(266496842339507005)
,p_name=>'P201_MRK_OC'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(266496558721507002)
,p_prompt=>'Mrk Oc'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20251202195442Z')
,p_updated_on=>wwv_flow_imp.dz('20251202195442Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85921686147651841)
,p_name=>'Agregar items [+]'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.req-sel'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85921883495651843)
,p_event_id=>wwv_flow_imp.id(85921686147651841)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_name=>'set P201_REQ_SEL_TIPO'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P201_REQ_SEL_TIPO'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''tipo'')'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85921979680651844)
,p_event_id=>wwv_flow_imp.id(85921686147651841)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_name=>'set P201_REQ_SEL_DOC'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P201_REQ_SEL_DOC'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''doc'')'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86194305192944607)
,p_event_id=>wwv_flow_imp.id(85921686147651841)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'SP_AGREGA_ITEMS_OC_BORRADOR'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_COMP_GESTIONCOMPRAS.SP_AGREGA_ITEMS_OC_BORRADOR(:P201_REQ_SEL_TIPO, :P201_REQ_SEL_DOC, :APP_USER, :G_COMPANIA);',
''))
,p_attribute_02=>'P201_REQ_SEL_TIPO,P201_REQ_SEL_DOC'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86195879030944622)
,p_event_id=>wwv_flow_imp.id(85921686147651841)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_name=>'Clear'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P201_REQ_SEL_TIPO := null;',
':P201_REQ_SEL_DOC  := null;',
'',
''))
,p_attribute_02=>'P201_REQ_SEL_TIPO,P201_REQ_SEL_DOC'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86195438392944618)
,p_event_id=>wwv_flow_imp.id(85921686147651841)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(88454575578246519)
,p_name=>'Establecer proveedor COPY'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.copiar-proveedor'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(88454670571246520)
,p_event_id=>wwv_flow_imp.id(88454575578246519)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Esta acci\00F3n sobre escribe los proveedores establecidos')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(88454789576246521)
,p_event_id=>wwv_flow_imp.id(88454575578246519)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_name=>'set P201_COPY_CODIGOPROVEEDOR'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P201_COPY_CODIGOPROVEEDOR'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''codigoproveedor'')'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(88454894155246522)
,p_event_id=>wwv_flow_imp.id(88454575578246519)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_name=>'set P201_COPY_CODIGOCORTOPRODUCTO'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P201_COPY_CODIGOCORTOPRODUCTO'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''codigocortoproducto'')'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(88454954810246523)
,p_event_id=>wwv_flow_imp.id(88454575578246519)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'SP_COPY_ITEM_PROVEEDOR_BORRADOR'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_COMP_GESTIONCOMPRAS.SP_COPY_ITEM_PROVEEDOR_BORRADOR(:P201_COPY_CODIGOPROVEEDOR, :P201_COPY_CODIGOCORTOPRODUCTO, :APP_USER);',
''))
,p_attribute_02=>'P201_COPY_CODIGOPROVEEDOR,P201_COPY_CODIGOCORTOPRODUCTO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(88455046247246524)
,p_event_id=>wwv_flow_imp.id(88454575578246519)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_name=>'Clear'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P201_COPY_CODIGOPROVEEDOR:= null;',
':P201_COPY_CODIGOCORTOPRODUCTO:= null;',
'',
''))
,p_attribute_02=>'P201_REQ_SEL_TIPO,P201_REQ_SEL_DOC'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(88455101256246525)
,p_event_id=>wwv_flow_imp.id(88454575578246519)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(86195909746944623)
,p_name=>'Eliminar ITEM'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.borrar-item'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86196050855944624)
,p_event_id=>wwv_flow_imp.id(86195909746944623)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Confirm'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Eliminar este ITEM de la nueva OC ?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86196101997944625)
,p_event_id=>wwv_flow_imp.id(86195909746944623)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_name=>'set P201_REQ_BORRA_TIPO'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P201_REQ_BORRA_TIPO'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''tipo'')'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86196372913944627)
,p_event_id=>wwv_flow_imp.id(86195909746944623)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_name=>'set P201_REQ_BORRA_DOC'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P201_REQ_SEL_DOC,P201_REQ_BORRA_DOC'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''doc'')'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86196431822944628)
,p_event_id=>wwv_flow_imp.id(86195909746944623)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_name=>'set P201_REQ_BORRA_LINEA'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P201_REQ_BORRA_LINEA'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''linea'')'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86197122630944635)
,p_event_id=>wwv_flow_imp.id(86195909746944623)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_name=>'SP_ELIMINA_ITEM_OC_BORRADOR'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_COMP_GESTIONCOMPRAS.SP_ELIMINA_ITEM_OC_BORRADOR(',
'    :P201_REQ_BORRA_TIPO,',
'    :P201_REQ_BORRA_DOC,',
'    :P201_REQ_BORRA_LINEA,',
'    :APP_USER,',
'    :G_COMPANIA',
');',
' '))
,p_attribute_02=>'P201_REQ_BORRA_TIPO,P201_REQ_BORRA_DOC,P201_REQ_BORRA_LINEA'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86196774533944631)
,p_event_id=>wwv_flow_imp.id(86195909746944623)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_name=>'Clear'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P201_REQ_BORRA_TIPO   := null;',
':P201_REQ_BORRA_DOC    := null;',
':P201_REQ_BORRA_LINEA  := null;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86197034757944634)
,p_event_id=>wwv_flow_imp.id(86195909746944623)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(87338823052438812)
,p_name=>unistr('Regresar Di\00E1logo')
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(85918475626651809)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(87338904965438813)
,p_event_id=>wwv_flow_imp.id(87338823052438812)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(88453461248246508)
,p_name=>unistr('Regresar Di\00E1logo PROVEEDOR')
,p_event_sequence=>50
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(86194492254944608)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(88453591424246509)
,p_event_id=>wwv_flow_imp.id(88453461248246508)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(91370691950973008)
,p_name=>'Close dialog'
,p_event_sequence=>60
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(87339055194438814)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(91370724231973009)
,p_event_id=>wwv_flow_imp.id(91370691950973008)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'BOTONSALTO'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(113731364733020317)
,p_name=>'Refresca luego de agregar'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(91373629796973038)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(113731497160020318)
,p_event_id=>wwv_flow_imp.id(113731364733020317)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(113731822288020322)
,p_name=>'Eliminar agrupado'
,p_event_sequence=>80
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.grp-del'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(113731961759020323)
,p_event_id=>wwv_flow_imp.id(113731822288020322)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Eliminar este l\00EDnea ?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(113732073402020324)
,p_event_id=>wwv_flow_imp.id(113731822288020322)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_name=>'set P201_GRP_BORRA_ID'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P201_GRP_BORRA_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''grpid'')'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(113732104164020325)
,p_event_id=>wwv_flow_imp.id(113731822288020322)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'SP_ELIMINA_SIN_REQUISICION'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'PK_COMP_GESTIONCOMPRAS.SP_ELIMINA_SIN_REQUISICION(:P201_GRP_BORRA_ID);'
,p_attribute_02=>'P201_GRP_BORRA_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(113732229668020326)
,p_event_id=>wwv_flow_imp.id(113731822288020322)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_name=>'Clear'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':SP_ELIMINA_SIN_REQUISICION := NULL;'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(113732397059020327)
,p_event_id=>wwv_flow_imp.id(113731822288020322)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(141896758045069217)
,p_name=>'PAGE LOAD'
,p_event_sequence=>100
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(141896881993069218)
,p_event_id=>wwv_flow_imp.id(141896758045069217)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log("P201_SALTAR_SELECT_PROVEEDOR: "+apex.item("P201_SALTAR_SELECT_PROVEEDOR").getValue());',
'if (apex.item("P201_SALTAR_SELECT_PROVEEDOR").getValue()==''1''){',
'    apex.item( "P201_SALTAR_SELECT_PROVEEDOR" ).setValue( ''0'', null, true );',
'    console.log("P201_SALTAR_SELECT_PROVEEDOR: "+apex.item("P201_SALTAR_SELECT_PROVEEDOR").getValue()+ '' B'');',
'    document.getElementById(''idRegionSeleccionarProveedor'').scrollIntoView();',
'}',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(158618914842852603)
,p_name=>'ON CHANGE RESERVA'
,p_event_sequence=>110
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P201_RESERVA_ID'
,p_condition_element=>'P201_RESERVA_ID'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(158619010017852604)
,p_event_id=>wwv_flow_imp.id(158618914842852603)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'PK_COMP_GESTIONCOMPRAS.SP_SWITCH_RESERVA(:P201_RESERVA_ID);'
,p_attribute_02=>'P201_RESERVA_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(158619187788852605)
,p_event_id=>wwv_flow_imp.id(158618914842852603)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(183038204161694601)
,p_name=>'Seleccionar todos items seleccionados'
,p_event_sequence=>120
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>' #selectunselectall'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#rptItemsSeleccionados'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(183038317010694602)
,p_event_id=>wwv_flow_imp.id(183038204161694601)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Ejecuta JS'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#rptItemsSeleccionados #selectunselectall'' ).is('':checked'')) {',
'    $(''#rptItemsSeleccionados input[type=checkbox][name=f02]'').prop(''checked'',true);',
'} else {',
'    $(''#rptItemsSeleccionados input[type=checkbox][name=f02]'').prop(''checked'',false);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(184017148464703715)
,p_name=>'Borrar ITEM H2'
,p_event_sequence=>130
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.borrar-item-h2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(184017253567703716)
,p_event_id=>wwv_flow_imp.id(184017148464703715)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Eliminar este ITEM H2 de la nueva OC ?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(184017360422703717)
,p_event_id=>wwv_flow_imp.id(184017148464703715)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_name=>'set P201_REQ_BORRA_H2_ID'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P201_REQ_BORRA_H2_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''id'')'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(184017565425703719)
,p_event_id=>wwv_flow_imp.id(184017148464703715)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_COMP_GESTIONCOMPRAS.SP_ELIMINA_PPGESTION_H2(',
'    :P201_REQ_BORRA_H2_ID',
');'))
,p_attribute_02=>'P201_REQ_BORRA_H2_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(184017864366703722)
,p_event_id=>wwv_flow_imp.id(184017148464703715)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'Clear'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P201_REQ_BORRA_H2_ID  := null;'
,p_attribute_02=>'P201_REQ_BORRA_H2_ID'
,p_attribute_03=>'P201_REQ_BORRA_H2_ID'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(184017772291703721)
,p_event_id=>wwv_flow_imp.id(184017148464703715)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(184018067800703724)
,p_name=>'Seleccionar todos H2'
,p_event_sequence=>140
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectunselectH2'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#rptItemsH2'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(184018159695703725)
,p_event_id=>wwv_flow_imp.id(184018067800703724)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Ejecuta JS'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#rptItemsH2 #selectunselectH2'' ).is('':checked'')) {',
'    $(''#rptItemsH2 input[type=checkbox][name=f02]'').prop(''checked'',true);',
'} else {',
'    $(''#rptItemsH2 input[type=checkbox][name=f02]'').prop(''checked'',false);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(186073984456073202)
,p_name=>'Close dialog editar H2'
,p_event_sequence=>150
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(184016026117703704)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(186074014484073203)
,p_event_id=>wwv_flow_imp.id(186073984456073202)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(200195300922652304)
,p_name=>'Agrupado ON'
,p_event_sequence=>160
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(200195227808652303)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(200195441013652305)
,p_event_id=>wwv_flow_imp.id(200195300922652304)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'PK_COMP_GESTIONCOMPRAS.SP_MODO_AGRUPADO_ON(:APP_USER, :G_COMPANIA);'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(200195513813652306)
,p_event_id=>wwv_flow_imp.id(200195300922652304)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(200195748946652308)
,p_name=>'Agrupado OFF'
,p_event_sequence=>170
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(200195644469652307)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(200195850975652309)
,p_event_id=>wwv_flow_imp.id(200195748946652308)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'PK_COMP_GESTIONCOMPRAS.SP_MODO_AGRUPADO_OFF(:APP_USER, :G_COMPANIA);'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(200195985810652310)
,p_event_id=>wwv_flow_imp.id(200195748946652308)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(200196115846652312)
,p_name=>'Duplica PPGESTION'
,p_event_sequence=>180
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.grp-dup'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(200196275737652313)
,p_event_id=>wwv_flow_imp.id(200196115846652312)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Duplicar esta l\00EDnea ?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(200196484230652315)
,p_event_id=>wwv_flow_imp.id(200196115846652312)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_name=>'set P201_GRP_DUPLICA_ID'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P201_GRP_DUPLICA_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$(this.triggeringElement).parent().data(''grpid'')'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(200196573185652316)
,p_event_id=>wwv_flow_imp.id(200196115846652312)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'SP_DUPLICA_PPGESTION'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'PK_COMP_GESTIONCOMPRAS.SP_DUPLICA_PPGESTION(:P201_GRP_DUPLICA_ID);'
,p_attribute_02=>'P201_GRP_DUPLICA_ID'
,p_attribute_03=>'P201_GRP_DUPLICA_ID'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(200196683198652317)
,p_event_id=>wwv_flow_imp.id(200196115846652312)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'Clear'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P201_GRP_DUPLICA_ID := :NULL;'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(200196701819652318)
,p_event_id=>wwv_flow_imp.id(200196115846652312)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(251157153461140701)
,p_name=>'Cierra FC'
,p_event_sequence=>190
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(224410381635993406)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
,p_created_on=>wwv_flow_imp.dz('20251113152509Z')
,p_updated_on=>wwv_flow_imp.dz('20251117161126Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(251157234928140702)
,p_event_id=>wwv_flow_imp.id(251157153461140701)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20251113152509Z')
,p_updated_on=>wwv_flow_imp.dz('20251117161126Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(255362699565949403)
,p_name=>'Cierra FC_INV'
,p_event_sequence=>200
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(251157640668140706)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
,p_created_on=>wwv_flow_imp.dz('20251117160656Z')
,p_updated_on=>wwv_flow_imp.dz('20251117161109Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(255362746251949404)
,p_event_id=>wwv_flow_imp.id(255362699565949403)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20251117160657Z')
,p_updated_on=>wwv_flow_imp.dz('20251117161109Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(251157378470140703)
,p_name=>'Cierra PRV'
,p_event_sequence=>210
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(224414709514993450)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
,p_created_on=>wwv_flow_imp.dz('20251113152509Z')
,p_updated_on=>wwv_flow_imp.dz('20251117161126Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(251157486301140704)
,p_event_id=>wwv_flow_imp.id(251157378470140703)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20251113152509Z')
,p_updated_on=>wwv_flow_imp.dz('20251117161126Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(255362469027949401)
,p_name=>'Cierra PRV_INV'
,p_event_sequence=>220
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(251157763636140707)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
,p_created_on=>wwv_flow_imp.dz('20251117160656Z')
,p_updated_on=>wwv_flow_imp.dz('20251117161108Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(255362503976949402)
,p_event_id=>wwv_flow_imp.id(255362469027949401)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20251117160656Z')
,p_updated_on=>wwv_flow_imp.dz('20251117161108Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(87338187673438805)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'BORRAR_TODOS'
,p_process_sql_clob=>'PK_COMP_GESTIONCOMPRAS.SP_ELIMINA_ITEMS_OC_BORRADOR(:APP_USER, :G_COMPANIA);'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(87338095149438804)
,p_internal_uid=>87338187673438805
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(87337997551438803)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'BORRAR_SELECCIONADOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    V_TEXTO     VARCHAR2(40);',
'    V_TIPO      VARCHAR2(4);',
'    V_DOCUMENTO VARCHAR2(10);',
'    V_LINEA     VARCHAR2(10);',
'BEGIN',
'    FOR I IN 1..APEX_APPLICATION.G_F01.COUNT LOOP',
'        FOR J IN 1..APEX_APPLICATION.G_F02.COUNT LOOP',
'            IF APEX_APPLICATION.G_F01(I) = APEX_APPLICATION.G_F02(J) THEN',
'                V_TEXTO := APEX_APPLICATION.G_F02(J);',
'                V_TIPO  := SUBSTR(V_TEXTO, 1, INSTR(V_TEXTO, ''-'')-1);',
'                V_TEXTO := SUBSTR(V_TEXTO, INSTR(V_TEXTO, ''-'')+1);',
'                V_DOCUMENTO := SUBSTR(V_TEXTO, 1, INSTR(V_TEXTO, ''-'')-1);',
'                V_LINEA     := SUBSTR(V_TEXTO, INSTR(V_TEXTO, ''-'')+1);',
'                ',
'                PK_COMP_GESTIONCOMPRAS.SP_ELIMINA_ITEM_OC_BORRADOR(V_TIPO, TO_NUMBER(V_DOCUMENTO), TO_NUMBER(V_LINEA), :APP_USER, :G_COMPANIA);',
'            END IF;',
'        END LOOP;',
'    END LOOP;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(87337834277438802)
,p_internal_uid=>87337997551438803
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(141896652227069216)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'BOTONSALTO'
,p_process_sql_clob=>':P201_SALTAR_SELECT_PROVEEDOR := 1;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(141896564471069215)
,p_internal_uid=>141896652227069216
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(184016963393703713)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'BORRAR_TODOS_H2'
,p_process_sql_clob=>'PK_COMP_GESTIONCOMPRAS.SP_ELIMINA_ITEMS_H2(:APP_USER, :G_COMPANIA);'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(184016870545703712)
,p_internal_uid=>184016963393703713
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(184018356552703727)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'BORRAR_SELECCIONADOS_H2'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    V_ID     VARCHAR2(40);',
'BEGIN',
'    FOR I IN 1..APEX_APPLICATION.G_F01.COUNT LOOP',
'        FOR J IN 1..APEX_APPLICATION.G_F02.COUNT LOOP',
'            IF APEX_APPLICATION.G_F01(I) = APEX_APPLICATION.G_F02(J) THEN',
'                V_ID := APEX_APPLICATION.G_F02(J);',
'                ',
'                PK_COMP_GESTIONCOMPRAS.SP_ELIMINA_PPGESTION_H2(TO_NUMBER(V_ID));',
'            END IF;',
'        END LOOP;',
'    END LOOP;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(184018279658703726)
,p_internal_uid=>184018356552703727
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(87921245233756305)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga H1 H2 H3'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    SELECT ',
'        DISTINCT DOCUMENTOTIPO',
'        INTO :P201_TIPO_H_ENCURSO',
'    FROM T_COMP_F4311_GESTION ',
'    WHERE FECHA_PROCESADO IS NULL',
'        AND',
'    USUARIO=:APP_USER',
'    ;',
'',
'EXCEPTION ',
'    WHEN NO_DATA_FOUND THEN',
'        BEGIN',
'            SELECT ',
'                DISTINCT TIPO_REQUISICION',
'                INTO :P201_TIPO_H_ENCURSO',
'            FROM T_COMP_PRODTO_PROVEEDR_GESTION ',
'            WHERE FECHA_PROCESADO IS NULL',
'                AND',
'            USUARIO=:APP_USER;',
'        EXCEPTION ',
'            WHEN NO_DATA_FOUND THEN            ',
'                :P201_TIPO_H_ENCURSO := NULL;            ',
'        END;',
'END;',
'',
'IF :P201_TIPO_H_ENCURSO IS NOT NULL THEN',
'    :P201_NEW_TIPO_REQ := :P201_TIPO_H_ENCURSO;',
'END IF;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>87921245233756305
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(86193792532944601)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Reset'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P201_REQ_SEL_TIPO := null;',
':P201_REQ_SEL_DOC  := null;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>86193792532944601
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(200195157012652302)
,p_process_sequence=>40
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Modo Agrupado'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT COUNT(1)',
'INTO   :P201_MODO_AGRUPADO',
'FROM   T_COMP_PRODTO_PROVEEDR_GESTION ',
'WHERE ',
'    COMPANIA     = :G_COMPANIA',
'        AND',
'    USUARIO      = :APP_USER',
'        AND',
'    FECHA_PROCESADO IS NULL',
'        AND',
'    MODO_AGRUPADO IS NOT NULL;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>200195157012652302
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(251157544663140705)
,p_process_sequence=>50
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Flags'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
unistr('v_titulo_base   varchar2(100) := ''Gesti\00F3n Productos''; -- El nombre real de tu pesta\00F1a'),
'v_html_final    varchar2(4000);',
'v_contador      number := 0;',
'begin',
unistr('	-- 1. Calcular el conteo (Tu l\00F3gica original)'),
'	begin',
'		select count(1) into v_contador',
'		from vt_comp_f4311 f4311, t_comp_f4311_gestion gestion',
'		where 1 = 1 ',
'			and f4311.linea = gestion.linea',
'			and f4311.documentotipo = gestion.documentotipo',
'			and f4311.documento = gestion.documento',
'			and gestion.fecha_procesado is null',
'			and gestion.usuario = :app_user;',
'',
'		exception when others then v_contador := 0;',
'	end;',
'',
unistr('    -- 2. Construir la se\00F1al visual'),
'	if v_contador > 0 then',
'		-- UX MEJORADA: ',
unistr('		-- Usamos ''fa-circle'' (s\00F3lido).'),
'		-- Ajustamos margen izquierdo para separar del texto.',
unistr('		-- Ajustamos alineaci\00F3n vertical para que se vea centrado.'),
'		v_html_final := v_titulo_base || ',
'			'' <span class="fa fa-circle" '' ||',
'			''style="color: #D9534F; font-size: 10px; vertical-align: middle; margin-left: 6px;" '' ||',
unistr('			''title="Tienes items en gesti\00F3n"></span>'';'),
'	else',
'		v_html_final := v_titulo_base;',
'	end if;',
'',
'    -- 3. Asignar al Item',
'    :P201_MRK_OC := v_html_final;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>251157544663140705
,p_created_on=>wwv_flow_imp.dz('20251113160423Z')
,p_updated_on=>wwv_flow_imp.dz('20251202204335Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
