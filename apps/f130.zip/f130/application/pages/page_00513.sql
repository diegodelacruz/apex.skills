prompt --application/pages/page_00513
begin
--   Manifest
--     PAGE: 00513
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>513
,p_name=>'COMEX - dlg  Sello Naviera UPLOAD'
,p_alias=>'COMEX-DLG-SELLO-NAVIERA-UPLOAD'
,p_page_mode=>'MODAL'
,p_step_title=>'COMEX - Sello Naviera UPLOAD'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_created_on=>wwv_flow_imp.dz('20241002172722Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240920163705Z')
,p_last_updated_by=>'DCUEVA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(311041426596669849)
,p_plug_name=>'Body'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(311036928733669804)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(311041426596669849)
,p_button_name=>'GRABAR_SELLO_NAVIERA'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Grabar Sello Naviera'
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308951390478579004)
,p_name=>'P513_TIPO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(311041426596669849)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT ID_TABLA AS TIPO, VALOR AS CODIGO FROM T_CORP_UDC WHERE ID_CABECERA=''CMEX_SLNVR'';'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(311036657058669801)
,p_name=>'P513_DATOS_GESTION_DETALLE_ID'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(311036784823669802)
,p_name=>'P513_SELLO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(311041426596669849)
,p_prompt=>'Sello'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(311036803718669803)
,p_name=>'P513_IMAGEN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(311041426596669849)
,p_prompt=>'Imagen'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
,p_attribute_13=>'FOTO DEL SELLO'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(311037076742669805)
,p_validation_name=>'GRABAR_SELLO_NAVIERA'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P513_IMAGEN IS NULL THEN',
'    RETURN ''Debe seleccionar un archivo de imagen'';',
'END IF;',
'',
'IF :P513_TIPO IS NULL THEN',
'    RETURN ''Debe seleccionar un tipo de sello'';',
'END IF;',
'',
'IF :P513_SELLO IS NULL THEN',
'    RETURN ''Debe ingresar el texto del sello'';',
'END IF;',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(311037195269669806)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GRABAR_SELLO_NAVIERA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_DATOS_GESTION.SP_GRABA_SELLO_NAVIERA(',
'    :P513_DATOS_GESTION_DETALLE_ID,',
'    :P513_TIPO,',
'    :P513_SELLO,',
'    :APP_USER',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(311036928733669804)
,p_internal_uid=>311037195269669806
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(311037208002669807)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'CLOSE DIALOG'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(311036928733669804)
,p_internal_uid=>311037208002669807
);
wwv_flow_imp.component_end;
end;
/
