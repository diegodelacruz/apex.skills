prompt --application/pages/page_00122
begin
--   Manifest
--     PAGE: 00122
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>122
,p_name=>unistr('Selecci\00F3n Proveedor')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Selecci\00F3n Proveedor')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230708132653Z')
,p_last_updated_on=>wwv_flow_imp.dz('20230131214112Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(41936574298094050)
,p_plug_name=>'Items'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43316448361601103)
,p_plug_name=>'Seleccione Proveedor'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct apex_item.checkbox(1,cban8,''class="chkF01"'') seleccion',
'	, cban8 codigoproveedor',
'	, nombres nombre',
'	, cbprrc/10000 costounitario',
'	, cbcrcd moneda',
'from f41061@jdedtadl',
'inner join vt_jde_librodirecciones on cban8 = codigo',
'where data.pk_commons.f_g2jde(sysdate) between cbeftj and cbexdj',
'and trim(cblitm) = :p122_codigoproducto'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P122_CODIGOPRODUCTO,P122_BODEGA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(43320056317601139)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'N'
,p_owner=>'CVACA'
,p_internal_uid=>43320056317601139
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43320516496601144)
,p_db_column_name=>'SELECCION'
,p_display_order=>10
,p_column_identifier=>'E'
,p_column_label=>'_'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43320133002601140)
,p_db_column_name=>'CODIGOPROVEEDOR'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Codigoproveedor'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43320298954601141)
,p_db_column_name=>'NOMBRE'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Nombre'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43320376330601142)
,p_db_column_name=>'COSTOUNITARIO'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Costounitario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43320417827601143)
,p_db_column_name=>'MONEDA'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(43378016999029224)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'433781'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODIGOPROVEEDOR:NOMBRE:COSTOUNITARIO:MONEDA:SELECCION'
,p_created_on=>wwv_flow_imp.dz('20230708132653Z')
,p_updated_on=>wwv_flow_imp.dz('20230708132653Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43316247278601101)
,p_name=>'P122_CODIGOPRODUCTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(41936574298094050)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43316393492601102)
,p_name=>'P122_BODEGA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(41936574298094050)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43318196979601120)
,p_name=>'P122_KEYID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(41936574298094050)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43320857189601147)
,p_name=>'P122_SELECCIONPROVEEDOR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(41936574298094050)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(43321045789601149)
,p_name=>'Seleccionado_Click'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.chkF01'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43321128912601150)
,p_event_id=>wwv_flow_imp.id(43321045789601149)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var lineas =""; ',
'document.querySelectorAll(''.chkF01'').forEach(function(seleccion) {',
'    if(seleccion.checked){',
'        var linea = seleccion.value',
'        if(lineas==""){',
'            lineas = linea;',
'        }else{',
'            ',
'            lineas = lineas+'',''+linea;',
'        }      ',
'    }else{',
'        ',
'    }',
'    ',
'});',
'',
'apex.item("P122_SELECCIONPROVEEDOR").setValue(lineas);',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43382716832124402)
,p_event_id=>wwv_flow_imp.id(43321045789601149)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_proveedor number;',
'v_costo number;',
'v_moneda nvarchar2(5);',
'begin',
'	begin',
'		select distinct cban8, cbprrc, cbcrcd into v_proveedor, v_costo, v_moneda',
'		from f41061@jdedtadl',
'		inner join vt_jde_librodirecciones on cban8 = codigo',
'		where (data.pk_commons.f_g2jde(sysdate) between cbeftj and cbexdj)',
'			and trim(cblitm) = :p122_codigoproducto',
'			and cban8 = :p122_seleccionproveedor;',
'',
'		exception when no_data_found then v_proveedor := null;',
'	end;',
'',
'	update t_comp_generaoc set proveedor = v_proveedor',
'		, preciounitario = v_costo',
'		, moneda = v_moneda',
'	where keyid = :p122_keyid;',
'',
'	update t_comp_generaoc set totalcompra = (cantidadsugeridacompra*preciounitario)/10000',
'	where keyid = :p122_keyid;',
'	commit;',
'end;',
''))
,p_attribute_02=>'P122_SELECCIONPROVEEDOR,P122_CODIGOPRODUCTO,P122_BODEGA,P122_KEYID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43382822978124403)
,p_event_id=>wwv_flow_imp.id(43321045789601149)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(43319923990601138)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(43316448361601103)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Seleccione Proveedor - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>43319923990601138
);
wwv_flow_imp.component_end;
end;
/
