prompt --application/pages/page_00131
begin
--   Manifest
--     PAGE: 00131
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>131
,p_name=>unistr('OI - Cierre Orden de Importaci\00F3n')
,p_step_title=>'Cierre de OIs'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20230708132654Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260409211143Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61809047270560203)
,p_plug_name=>unistr('ENVIAR APROBACI\00D3N')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P131_NUMEROORDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61809465145560207)
,p_plug_name=>'BOTONES'
,p_parent_plug_id=>wwv_flow_imp.id(61809047270560203)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121809343169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P131_APROBADOR = :APP_USER and :P131_ESTADOORDEN <> 999'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(106216406617022626)
,p_plug_name=>'Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(106216500613022627)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(106216988545022632)
,p_name=>'Detalle de la OI'
,p_template=>wwv_flow_imp.id(296121421643169165)
,p_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with ordenes as (',
'  select replace(:p131_numeroorden,'' '','''') numeroorden from dual',
')',
'select PDDOCO NUMEROORDEN, PDDCTO TIPOORDEN, PDLNID/1000 NUMEROLINEA, PDDSC1||'' ''||PDDSC2 DESCRIPCIONLINEA, PDUORG/10000 CANTIDADORDENADA, PDUREC/10000 CANTIDADRECIBIDA',
', PDUOPN/10000 CANTIDADPENDIENTE, PDUOM UNIDADMEDIDA, PDAOPN/100 DIFERENCIACOSTO, PDLTTR ULTIMOESTADO, PDNXTR SIGUIENTEESTADO',
', case when PDNXTR<>999 then ''<span aria-hidden="true" class="fa fa-check-circle-o ENVIAR_RUTA" id="''||PDDOCO||''"></span>'' else '''' end enviar',
', ''<span aria-hidden="true" class="fa fa-comment-o"></span>'' comentario',
', ''<span aria-hidden="true" class="fa fa-road"></span>'' ruta',
'',
'from   f4311@JDEDTADL',
'where  PDDCTO = ''OI''  ',
'AND PDDOCO in ( ',
'  select regexp_substr (',
'           numeroorden,',
'           ''[^,]+'',',
'           1,',
'           level',
'         ) value',
'  from ordenes',
'  connect by level <= ',
'    length ( numeroorden ) - ',
'    length ( replace ( numeroorden, '','' ) ) + 1',
');'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(44411773030481244)
,p_query_column_id=>1
,p_column_alias=>'NUMEROORDEN'
,p_column_display_sequence=>1
,p_column_heading=>unistr('N\00FAmero Orden')
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_default_sort_column_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(44411806810481245)
,p_query_column_id=>2
,p_column_alias=>'TIPOORDEN'
,p_column_display_sequence=>3
,p_column_heading=>'Tipo Orden'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(44411999476481246)
,p_query_column_id=>3
,p_column_alias=>'NUMEROLINEA'
,p_column_display_sequence=>2
,p_column_heading=>unistr('N\00FAmero L\00EDnea')
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_default_sort_column_sequence=>2
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(44412068808481247)
,p_query_column_id=>4
,p_column_alias=>'DESCRIPCIONLINEA'
,p_column_display_sequence=>4
,p_column_heading=>unistr('Descripci\00F3n L\00EDnea')
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(44412155948481248)
,p_query_column_id=>5
,p_column_alias=>'CANTIDADORDENADA'
,p_column_display_sequence=>5
,p_column_heading=>'Cantidad Ordenada'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D0000'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(44412238577481249)
,p_query_column_id=>6
,p_column_alias=>'CANTIDADRECIBIDA'
,p_column_display_sequence=>6
,p_column_heading=>'Cantidad Recibida'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D0000'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(44412301718481250)
,p_query_column_id=>7
,p_column_alias=>'CANTIDADPENDIENTE'
,p_column_display_sequence=>7
,p_column_heading=>'Cantidad Pendiente'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D0000'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(61808891014560201)
,p_query_column_id=>8
,p_column_alias=>'UNIDADMEDIDA'
,p_column_display_sequence=>8
,p_column_heading=>'Unidad Medida'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(61808993161560202)
,p_query_column_id=>9
,p_column_alias=>'DIFERENCIACOSTO'
,p_column_display_sequence=>9
,p_column_heading=>'Diferencia Costo'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(62292025940561007)
,p_query_column_id=>10
,p_column_alias=>'ULTIMOESTADO'
,p_column_display_sequence=>10
,p_column_heading=>unistr('\00DAltimo estado')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(62292175674561008)
,p_query_column_id=>11
,p_column_alias=>'SIGUIENTEESTADO'
,p_column_display_sequence=>11
,p_column_heading=>'Siguiente estado'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(62292664636561013)
,p_query_column_id=>12
,p_column_alias=>'ENVIAR'
,p_column_display_sequence=>12
,p_column_heading=>'Enviar'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=100:101:&SESSION.::&DEBUG.:RP:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_ETAPA,G_OBJETO_DESCRIPCION,G_PAGINA,G_TIPO1:&G_COMPANIA.,&APP_MODULO.,&APP_USER.,&APP_OBJETO.,#NUMEROORDEN#,APROBACION,CIERRE_OI,&APP_PAGE.,OI'
,p_column_linktext=>'#ENVIAR#'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(62292921469561016)
,p_query_column_id=>13
,p_column_alias=>'COMENTARIO'
,p_column_display_sequence=>14
,p_column_heading=>'COMENTARIO'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=100:105:&SESSION.::&DEBUG.:RP:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_ETAPA,G_OBJETO_DESCRIPCION,G_PAGINA,G_TIPO1:&G_COMPANIA.,&APP_MODULO.,&APP_USER.,&APP_OBJETO.,#NUMEROORDEN#,APROBACION,CIERRE_OI,&APP_PAGE.,OI'
,p_column_linktext=>'#COMENTARIO#'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(62292882257561015)
,p_query_column_id=>14
,p_column_alias=>'RUTA'
,p_column_display_sequence=>13
,p_column_heading=>'Ruta'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=100:104:&SESSION.::&DEBUG.:RP:G_OBJETO,G_OBJETO_ID,G_TODO:&APP_OBJETO.,#NUMEROORDEN#,true'
,p_column_linktext=>'#RUTA#'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(61809516737560208)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(61809465145560207)
,p_button_name=>'APROBAR'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Aprobar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:102:&SESSION.::&DEBUG.:RP:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO:&G_COMPANIA.,&APP_MODULO.,&APP_USER.,&APP_OBJETO.,&P131_NUMEROORDEN.,&P131_APROBADOR.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(61810813089560221)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(106216406617022626)
,p_button_name=>'REGRESAR'
,p_button_static_id=>'btnAtras'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:130:&SESSION.::&DEBUG.:RP::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(61806421824541395)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(106216406617022626)
,p_button_name=>'Buscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(61809715636560210)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(61809465145560207)
,p_button_name=>'RECHAZAR'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Rechazar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:103:&SESSION.::&DEBUG.:RP:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID:&G_COMPANIA.,&APP_MODULO.,&APP_USER.,&APP_OBJETO.,&P131_NUMEROORDEN.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61807464034541397)
,p_name=>'P131_NUMEROORDEN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(106216500613022627)
,p_prompt=>unistr('N\00FAmero OI')
,p_post_element_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<ul>',
'    <li>OIs separado por comas (,)</li>',
'</ul>'))
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cattributes_element=>'id="NUMEROORDEN"'
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61809166792560204)
,p_name=>'P131_APROBADOR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(61809047270560203)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61809201929560205)
,p_name=>'P131_ENVIO_EXITO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(61809047270560203)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61810289425560215)
,p_name=>'P131_MENSAJE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(106216500613022627)
,p_prompt=>'Mensaje'
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'HTML'
,p_attribute_02=>'INTERMEDIATE'
,p_attribute_03=>'MULTILINE'
,p_attribute_04=>'180'
,p_attribute_07=>'Y'
,p_attribute_25=>'CKEDITOR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(62294537827561032)
,p_name=>'P131_ESTADOORDEN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(106216500613022627)
,p_prompt=>'Estado pendiente'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(61809864052560211)
,p_name=>'Dialogo cierre: aprobar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(61809516737560208)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61809931858560212)
,p_event_id=>wwv_flow_imp.id(61809864052560211)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'mostrarBarra();',
'if(this.data.G_EXITO==''true''){',
'   ',
'     mensaje(''exito'', this.data.G_MENSAJE);',
'    ',
'    if(isTerminoFlujo){',
'        apex.item( "P131_ENVIO_EXITO" ).setValue(2);',
'        console.log(''2'');',
'    }else{',
'        apex.item( "P131_ENVIO_EXITO" ).setValue(1);',
'        console.log(''1'');',
'    }',
'}',
'else{ ',
'    mensaje(''Error'', this.data.G_MENSAJE);',
'    apex.item( "P131_ENVIO_EXITO" ).setValue(0);',
'    console.log(''0'');',
'}',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61810199499560214)
,p_event_id=>wwv_flow_imp.id(61809864052560211)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  P_NUMEROORDEN NUMBER;',
'  P_TIPOORDEN VARCHAR2(200);',
'  P_MENSAJE VARCHAR2(200);',
'BEGIN  ',
'    IF(:P131_ENVIO_EXITO = 2) THEN ',
'        PK_COMP_ORDENESCOMPRA.SP_CANCELAROCLINEA(',
'            P_NUMERO => :P131_NUMEROORDEN ,',
'            P_TIPO => ''OI'',',
'            P_COMPANIA => ''00001'',',
'            P_LINEAS => NULL, -- si linea es null cancela a toda las lineas de la orden que esten pendientes',
'            P_NUMEROORDEN => P_NUMEROORDEN, --SI ES EXITOSO TE DEVUELVE EL MISMO NUMERO DE ORDEN ANULADA',
'            P_TIPOORDEN => P_TIPOORDEN, -- SI ES EXITOSO TE DEVUELVE EL MISMO TIPO ORDEN ANULADA',
'            P_MENSAJE => P_MENSAJE',
'          );',
'      :P131_MENSAJE := P_NUMEROORDEN ||'' - ''|| P_TIPOORDEN ||'' - ''||P_MENSAJE;    ',
'    END IF;',
'END;'))
,p_attribute_02=>'P131_ENVIO_EXITO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61810033337560213)
,p_event_id=>wwv_flow_imp.id(61809864052560211)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if($v(''P131_ENVIO_EXITO'')==''0''){',
'   ocultarBarra();',
'}else{',
'   $(''#btnAtras'').trigger("click");',
'}',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(61810578012560218)
,p_name=>unistr('ENV\00CDO A APROBACI\00D3N')
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(106216988545022632)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61810645043560219)
,p_event_id=>wwv_flow_imp.id(61810578012560218)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mostrarBarra();',
'if(this.data.G_EXITO==''true''){',
'      mensaje(''exito'', this.data.G_MENSAJE);',
'',
'     apex.item( "P131_ENVIO_EXITO" ).setValue(1);',
'}',
'else{ ',
'   mensaje(''error'', this.data.G_MENSAJE);',
'     apex.item( "P131_ENVIO_EXITO" ).setValue(0);',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61810715663560220)
,p_event_id=>wwv_flow_imp.id(61810578012560218)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ocultarBarra();',
'$(''#btnAtras'').click();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(62294049779561027)
,p_name=>'New'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P131_ERROR'
,p_condition_element=>'P131_ERROR'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(62294124461561028)
,p_event_id=>wwv_flow_imp.id(62294049779561027)
,p_event_result=>'TRUE'
,p_action_sequence=>100
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log("Erro: "+ $v("P131_VALIDA"));',
'$s("P131_ERROR", 0);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(62294306904561030)
,p_event_id=>wwv_flow_imp.id(62294049779561027)
,p_event_result=>'TRUE'
,p_action_sequence=>110
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'error'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(62294479421561031)
,p_event_id=>wwv_flow_imp.id(62294049779561027)
,p_event_result=>'TRUE'
,p_action_sequence=>120
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(61811169460560224)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Muestra aprobador'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'v_enruta number;',
'begin',
'    --Comprobamos si estpa en ruta para obtener datos',
'    select max(id) into v_enruta FROM t_flujo_aprobacion_cab X ',
'    WHERE CODMODULO = ''COMP'' AND ENTIDAD_CLASE = ''COMPRAS'' AND ENTIDAD_DESCRIPCION =''CIERRE_OI'' AND ESTADO <> ''RECHAZADO'' AND ENTIDAD_ID = :p131_numeroorden;',
'',
'    if v_enruta is not null then',
'        --Muestra aprobador',
'        select USUARIOACTUAL into :p131_aprobador from t_flujo_aprobacion_cab X ',
'        WHERE CODMODULO = ''COMP'' AND ENTIDAD_CLASE = ''COMPRAS'' AND ENTIDAD_DESCRIPCION =''CIERRE_OI'' and ENTIDAD_ID = :p131_numeroorden;',
'        --Muestra primer mensaje',
'        SELECT nvl(max(cast(ZCONTENIDO as varchar2(100))),''No hay comentario'') into :p131_mensaje FROM t_comentario x ',
'        WHERE CODMODULO = ''COMP'' AND CLASEOBJETO = ''COMPRAS'' AND TIPOCOMENTARIO = ''MOTIVO_INICIO_FLUJO'' and IDOBJETO = :p131_numeroorden;',
'        -- Obtener estado para ocultar botones',
'        SELECT min(PDNXTR) into :p131_estadoorden FROM f4311@JDEDTADL WHERE PDDCTO = ''OI'' and PDDOCO = :p131_numeroorden; ',
'    else',
'        :p131_aprobador := '''';',
'        :p131_mensaje := '''';',
'        :p131_estadoorden := '''';',
'    end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>61811169460560224
);
wwv_flow_imp.component_end;
end;
/
