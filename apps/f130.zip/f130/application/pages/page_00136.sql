prompt --application/pages/page_00136
begin
--   Manifest
--     PAGE: 00136
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>136
,p_name=>'Cruce OC-Factura'
,p_step_title=>'Cruce OC-Factura'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230708132654Z')
,p_last_updated_on=>wwv_flow_imp.dz('20230525153227Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(569621667157955511)
,p_plug_name=>unistr('Par\00E1metros')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(810814573255861906)
,p_plug_name=>'Reporte'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select num01 ordencompra',
'	, txt01 tipooc',
'	, num02 requisicion',
'	, txt02 tiporq',
'	, fecha01 fechaoc ',
'	, num04 linea',
'	, num05 codcorto',
'	, txt06 codproducto',
'	, txt03 descipcion',
'	, num06 codproveedor',
'	, txt04 proveedor',
'	, num07 estadosig',
'	, num08 estadoant',
'	, num09 cantord',
'	, num10 cantrec',
'	, num11 precuni',
'	, num12 montoord',
'	, num13 totalord',
'	, num14 montorec',
'	, num15 totalrec',
'	, txt05 factura',
'	, fecha02 fechafc',
'	, num17 mtofacln',
'	, num18 montofac',
'from data.t_apex_temporal',
'where flag = ''A'' and control01 = :g_compania and control02 = :app_modulo and control03 = :app_user and control04 = ''data.pk_comp_reportes.sp_facturaoc'''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(810814678283861907)
,p_max_row_count=>'1000000'
,p_max_rows_per_page=>'1000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_download_formats=>'CSV:HTML:XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>810814678283861907
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(285912332802954608)
,p_db_column_name=>'CODCORTO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>unistr('C\00F3d. Corto')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(285910327642954606)
,p_db_column_name=>'REQUISICION'
,p_display_order=>160
,p_column_identifier=>'R'
,p_column_label=>unistr('Requisici\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(285911197043954608)
,p_db_column_name=>'FECHAOC'
,p_display_order=>220
,p_column_identifier=>'X'
,p_column_label=>'Fecha OC'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(285911537001954608)
,p_db_column_name=>'CODPROVEEDOR'
,p_display_order=>230
,p_column_identifier=>'Y'
,p_column_label=>unistr('C\00F3d. Proveedor')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(285911988202954608)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>240
,p_column_identifier=>'Z'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(285915987719954609)
,p_db_column_name=>'ORDENCOMPRA'
,p_display_order=>380
,p_column_identifier=>'AN'
,p_column_label=>'Orden Compra'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(285916361852954612)
,p_db_column_name=>'TIPOOC'
,p_display_order=>390
,p_column_identifier=>'AO'
,p_column_label=>'Tipo OC'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(285916792335954612)
,p_db_column_name=>'TIPORQ'
,p_display_order=>400
,p_column_identifier=>'AP'
,p_column_label=>'Tipo RQ'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274408427531425824)
,p_db_column_name=>'LINEA'
,p_display_order=>410
,p_column_identifier=>'AS'
,p_column_label=>unistr('L\00EDnea')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274408572284425825)
,p_db_column_name=>'DESCIPCION'
,p_display_order=>420
,p_column_identifier=>'AT'
,p_column_label=>unistr('Descipci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274408659496425826)
,p_db_column_name=>'ESTADOSIG'
,p_display_order=>430
,p_column_identifier=>'AU'
,p_column_label=>'Est. Sig.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274408724560425827)
,p_db_column_name=>'ESTADOANT'
,p_display_order=>440
,p_column_identifier=>'AV'
,p_column_label=>'Est. Ant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274408884503425828)
,p_db_column_name=>'CANTORD'
,p_display_order=>450
,p_column_identifier=>'AW'
,p_column_label=>'Cant. Ordenada'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274408993526425829)
,p_db_column_name=>'CANTREC'
,p_display_order=>460
,p_column_identifier=>'AX'
,p_column_label=>'Cant. Recibida'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274409005879425830)
,p_db_column_name=>'PRECUNI'
,p_display_order=>470
,p_column_identifier=>'AY'
,p_column_label=>'Precio Unitario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274409131649425831)
,p_db_column_name=>'MONTOORD'
,p_display_order=>480
,p_column_identifier=>'AZ'
,p_column_label=>'Monto Ord.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274409200370425832)
,p_db_column_name=>'TOTALORD'
,p_display_order=>490
,p_column_identifier=>'BA'
,p_column_label=>'Total Ord.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274409325937425833)
,p_db_column_name=>'MONTOREC'
,p_display_order=>500
,p_column_identifier=>'BB'
,p_column_label=>'Monto Rec.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274409476672425834)
,p_db_column_name=>'TOTALREC'
,p_display_order=>510
,p_column_identifier=>'BC'
,p_column_label=>'Total Rec.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274409566041425835)
,p_db_column_name=>'FACTURA'
,p_display_order=>520
,p_column_identifier=>'BD'
,p_column_label=>'Factura'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274409614875425836)
,p_db_column_name=>'FECHAFC'
,p_display_order=>530
,p_column_identifier=>'BE'
,p_column_label=>'Fecha Fac.'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274409753207425837)
,p_db_column_name=>'MTOFACLN'
,p_display_order=>540
,p_column_identifier=>'BF'
,p_column_label=>'Mnt. Prod.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274409896991425838)
,p_db_column_name=>'MONTOFAC'
,p_display_order=>550
,p_column_identifier=>'BG'
,p_column_label=>'Mnt. Factura'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(274409923953425839)
,p_db_column_name=>'CODPRODUCTO'
,p_display_order=>560
,p_column_identifier=>'BH'
,p_column_label=>unistr('C\00F3d. Producto')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(831291968776188360)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2859179'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100
,p_report_columns=>'ORDENCOMPRA:TIPOOC:LINEA:ESTADOSIG:ESTADOANT:FECHAOC:REQUISICION:TIPORQ:PROVEEDOR:CODPRODUCTO:DESCIPCION:PRECUNI:CANTORD:MONTOORD:TOTALORD:CANTREC:MONTOREC:TOTALREC:FACTURA:FECHAFC:MTOFACLN:MONTOFAC:'
,p_sort_column_1=>'TIPOOC'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'ORDENCOMPRA'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'LINEA'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20230708132654Z')
,p_updated_on=>wwv_flow_imp.dz('20230708132654Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1912228441275710821)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(285918616805954616)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1912228441275710821)
,p_button_name=>'BUSCAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(274408290313425822)
,p_name=>'P136_DESDE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(569621667157955511)
,p_item_default=>'trunc(add_months(sysdate,-1),''month'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Desde'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(274408333138425823)
,p_name=>'P136_HASTA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(569621667157955511)
,p_item_default=>'sysdate'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Hasta'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(285919370420954616)
,p_name=>'P136_TIPOOC'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(569621667157955511)
,p_prompt=>'Tipo OC'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:BM;BM,BN;BN,CM;CM,CN;CN'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(285920922923954628)
,p_name=>'Buscar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(285918616805954616)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(285922969808954630)
,p_event_id=>wwv_flow_imp.id(285920922923954628)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra()'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(285921910393954630)
,p_event_id=>wwv_flow_imp.id(285920922923954628)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	pk_comp_reportes.sp_facturaoc(',
'		p_compania	=> :g_compania',
'		, p_usuario	=> :app_user',
'		, p_tipooc	=> :p136_tipooc',
'		, p_desde	=> :p136_desde',
'		, p_hasta	=> :p136_hasta);',
'end;'))
,p_attribute_02=>'P136_TIPOOC,P136_DESDE,P136_HASTA'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(285922446029954630)
,p_event_id=>wwv_flow_imp.id(285920922923954628)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(810814573255861906)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(285921438014954628)
,p_event_id=>wwv_flow_imp.id(285920922923954628)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra()'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(285920561738954628)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Separador'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	execute immediate ''ALTER SESSION SET NLS_NUMERIC_CHARACTERS =''''.,'''''';',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>285920561738954628
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(285920131501954627)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Categoir\00EDas')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_log_app varchar2(100);',
'begin',
'	v_log_app := ''apex.130.132.prerendering'';',
'	insert into data.t_apex_temporal (flag,control01,control02,control03,control04,txt01,txt02,txt03,txt04)',
'	select distinct ''APEX'',:g_compania,:app_modulo,:app_user,v_log_app,trim(imprp4) imprp4, a.drdl01||'' (''||a.drky||'')'', trim(imprp7) imprp7, b.drdl01||'' (''||b.drky||'')''',
'	from f4101@jdedtadl',
'	inner join vt_jde_udcjde a on a.drsy = ''41'' and a.drrt = ''P4'' and trim(imprp4) = a.drky',
'	inner join vt_jde_udcjde b on b.drsy = ''41'' and b.drrt = ''02'' and trim(imprp7) = b.drky;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>285920131501954627
);
wwv_flow_imp.component_end;
end;
/
