prompt --application/pages/page_00529
begin
--   Manifest
--     PAGE: 00529
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>529
,p_name=>'COMEX - dlgExportacionContenedor'
,p_alias=>'COMEX-DLGEXPORTACIONCONTENEDOR'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Exportaci\00F3n Contenedor')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20241113165843Z')
,p_last_updated_on=>wwv_flow_imp.dz('20241113165352Z')
,p_last_updated_by=>'DCUEVA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(364785256925500946)
,p_plug_name=>'CABECERA'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(365923439076512902)
,p_plug_name=>'CONTENEDOR'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(368940509343139303)
,p_plug_name=>'ARCHIVOS'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    j.tipo           AS TIPO,',
'    j.fac_vinculadas AS fac_vinculadas,',
'',
'    F.NUMEROARCHIVO  AS NUMEROARCHIVO,',
'    dbms_lob.getlength(F.BLOBCONTENT) ',
'                     AS BLOBCONTENT,',
'    F.FILENAME       AS FILENAME,',
'    F.MIMETYPE       AS MIMETYPE',
'from ',
'    FILES.T_APEX_ARCHIVOS        F,',
'    T_CMEX_DATOS_GESTION_DETALLE d,',
'    json_table (',
'        d.DOCUMENTOS, ''$[*]'' columns (',
'            id             NUMBER        path ''$.id'', ',
'            tipo           VARCHAR2(500) path ''$.tipo'',',
'            fac_vinculadas VARCHAR2(500) path ''$.fac_vinculadas'',',
'            archivo_id     NUMBER        path ''$.archivo_id''',
'        )',
'    ) j ',
'where ',
'    j.archivo_id = F.numeroarchivo',
'        AND',
'    d.id=:P529_DATOS_GESTION_DET_ID',
'        AND',
'    F.TABLA=''T_CMEX_DATOS_GESTION_DETALLE.DOCUMENTO'' ',
';',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'ARCHIVOS'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(368940672315139304)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>368940672315139304
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(368940756663139305)
,p_db_column_name=>'TIPO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(321856031790171313)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(368940840995139306)
,p_db_column_name=>'FAC_VINCULADAS'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fac Vinculadas'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(368940927521139307)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Numeroarchivo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(368941066282139308)
,p_db_column_name=>'BLOBCONTENT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_format_mask=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment:#FILENAME#:FILES'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(368941180674139309)
,p_db_column_name=>'FILENAME'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(368941288750139310)
,p_db_column_name=>'MIMETYPE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Mimetype'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(369137714682804202)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3691378'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TIPO:BLOBCONTENT:'
,p_created_on=>wwv_flow_imp.dz('20241113165843Z')
,p_updated_on=>wwv_flow_imp.dz('20241113165843Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(389759422591083401)
,p_plug_name=>'NUEVO'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(365924144582512909)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_imp.id(365923439076512902)
,p_button_name=>'GRABAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--success'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Grabar'
,p_button_alignment=>'RIGHT'
,p_button_condition=>':P529_EDITAR_COORDINACION=1  OR :P529_EDITAR_TRANSITO=1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_button_cattributes=>'style = "float: right"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(370139036670700524)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(368940509343139303)
,p_button_name=>'SUBIR_ARCHIVO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Subir Archivo'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:517:&SESSION.::&DEBUG.:517:P517_DATOS_GESTION_DETALLE_ID,P517_ORIGEN:&P529_DATOS_GESTION_DET_ID.,EXPORTACION'
,p_button_condition=>':P529_EDITAR_COORDINACION=1  OR :P529_EDITAR_TRANSITO=1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_button_cattributes=>'style="float: right;"'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(365924625237512914)
,p_branch_name=>'REGRESAR'
,p_branch_action=>'f?p=&APP_ID.:521:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(364785434773500948)
,p_name=>'P529_EDITAR_COORDINACION'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(364785520563500949)
,p_name=>'P529_EDITAR_TRANSITO'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(364785608343500950)
,p_name=>'P529_EXPORTACION_REGISTRO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(364785256925500946)
,p_prompt=>'Registro'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(365923383246512901)
,p_name=>'P529_DATOS_GESTION_DET_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(364785256925500946)
,p_prompt=>'ID'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(365923545910512903)
,p_name=>'P529_CONOCIMIENTO_EMBARQUE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(365923439076512902)
,p_prompt=>'Conocimiento Embarque'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(365923681135512904)
,p_name=>'P529_CONOCIMIENTO_EMBARQUE_NVO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(389759422591083401)
,p_prompt=>'Nuevo Conocimiento Embarque'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(365923782302512905)
,p_name=>'P529_FECHA_INGRESO_PUERTO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(365923439076512902)
,p_prompt=>'Ingreso Puerto'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(365923812246512906)
,p_name=>'P529_FECHA_ETA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(389759422591083401)
,p_prompt=>'Nueva Fecha Eta'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(365923953883512907)
,p_name=>'P529_FECHA_ZARPE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(365923439076512902)
,p_prompt=>'Fecha Zarpe'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(365924016813512908)
,p_name=>'P529_INSPECCIONES'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(365923439076512902)
,p_prompt=>'Inspecciones'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_CMEX_TIPO_INSPECIONES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    VALOR AS NAME,',
'    ID_TABLA AS CODIGO',
'FROM',
'    T_CORP_UDC',
'WHERE',
'    ID_CABECERA = ''CMEX_TINSP''',
'ORDER BY ',
'    VALOR;'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(365924228115512910)
,p_name=>'P529_CONTENEDOR_NUMERO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(364785256925500946)
,p_prompt=>'Contenedor'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(366738658621091001)
,p_name=>'P529_PATIO_RETIRO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(365923439076512902)
,p_prompt=>'Patio Retiro'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_CMEX_PATIO_RETIRO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    DESCRIPCION AS NOMBRE,',
'    ID_TABLA    AS ID    ',
'FROM T_CORP_UDC',
'WHERE ID_CABECERA=''CMEX_BDGS''',
'ORDER BY DESCRIPCION',
';'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(365924419629512912)
,p_validation_name=>'GRABAR'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P529_CONOCIMIENTO_EMBARQUE_NVO IS NOT NULL AND :P529_FECHA_ETA IS     NULL THEN',
'    RETURN ''Debe ingresar la Nueva Fecha ETA'';',
'END IF;',
'',
'IF :P529_CONOCIMIENTO_EMBARQUE_NVO IS     NULL AND :P529_FECHA_ETA IS NOT NULL THEN',
'    RETURN ''Debe ingresar Nuevo Conocimiento Embarque'';',
'END IF;',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(365924144582512909)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(365924595099512913)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GRABAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_EXPORTACION.SP_GRABA_EXPORTACION_CONTENDR(',
'        :P529_EXPORTACION_REGISTRO,',
'        :P529_DATOS_GESTION_DET_ID,',
'',
'        :P529_CONOCIMIENTO_EMBARQUE,',
'        :P529_CONOCIMIENTO_EMBARQUE_NVO,',
'        :P529_FECHA_INGRESO_PUERTO,',
'        :P529_FECHA_ETA,',
'        :P529_FECHA_ZARPE,',
'        :P529_PATIO_RETIRO,',
'        :P529_INSPECCIONES',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(365924144582512909)
,p_internal_uid=>365924595099512913
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(365924352959512911)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga Contenedor'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    CONTENEDOR_NUMERO,',
'    CONOCIMIENTO_EMBARQUE,',
'    CONOCIMIENTO_EMBARQUE_NUEVO,',
'    FECHA_INGRESO_PUERTO,',
'    FECHA_ETA,',
'    FECHA_ZARPE,',
'    PATIO_RETIRO,',
'    INSPECCIONES',
'INTO',
'    :P529_CONTENEDOR_NUMERO,',
'    :P529_CONOCIMIENTO_EMBARQUE,',
'    :P529_CONOCIMIENTO_EMBARQUE_NVO,',
'    :P529_FECHA_INGRESO_PUERTO,',
'    :P529_FECHA_ETA,',
'    :P529_FECHA_ZARPE,',
'    :P529_PATIO_RETIRO,',
'    :P529_INSPECCIONES',
'FROM',
'    T_CMEX_DATOS_GESTION_DETALLE DET',
'WHERE',
'    DET.ID = :P529_DATOS_GESTION_DET_ID',
';'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>365924352959512911
);
wwv_flow_imp.component_end;
end;
/
