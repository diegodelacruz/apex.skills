prompt --application/pages/page_00202
begin
--   Manifest
--     PAGE: 00202
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>202
,p_name=>'dlgDetalleRequision'
,p_alias=>'DLGDETALLEREQUISION'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Detalle Requisici\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-table td {',
'    padding: 0px;',
'    padding-right: 2px;',
'    padding-left: 2px;    ',
'}',
'.t-Form-inputContainer, .t-Form-labelContainer {',
'    padding: 0px;',
'    padding-left: 10px;',
'}'))
,p_page_template_options=>'ui-dialog--stretch'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240408131720Z')
,p_last_updated_on=>wwv_flow_imp.dz('20251112194226Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(85919753428651822)
,p_plug_name=>'Cabecera'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(85920029378651825)
,p_plug_name=>'Detalle'
,p_parent_plug_id=>wwv_flow_imp.id(85919753428651822)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>80
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    F4311.LINEA               AS LINEA,',
'    F4311.DOCUMENTOTIPO       AS DOCUMENTOTIPO,',
'    F4311.DOCUMENTO           AS DOCUMENTO,',
'    F4311.CODIGOCORTOPRODUCTO AS CODIGOCORTOPRODUCTO,',
'    F4311.CODIGOPRODUCTO      AS CODIGOPRODUCTO,',
'    F4311.PRODUCTO            AS PRODUCTO,',
'    F4311.DESCRIPCION         AS DESCRIPCION,',
'    F4311.CANTIDAD            AS CANTIDAD,',
'    F4311.UNIDADMEDIDA        AS UNIDADMEDIDA,',
'    F4311.ESTADO_ANT||''-''||F4311.ESTADO_SIG AS ESTADO,',
'    ',
'    GESTION.USUARIO           AS GESTION_POR,',
'    CASE WHEN F4311.ESTADO_SIG = ''999'' ',
'        THEN ''background: lightsalmon;'' ',
'        ELSE ''''',
'    END                        AS ESTILO',
'FROM ',
'    VT_COMP_F4311        F4311,',
'    T_COMP_F4311_GESTION GESTION',
'WHERE ',
'    F4311.LINEA         = GESTION.LINEA(+)',
'        AND',
'    F4311.DOCUMENTOTIPO = GESTION.DOCUMENTOTIPO(+)',
'        AND ',
'    F4311.DOCUMENTO     = GESTION.DOCUMENTO(+)',
'        AND',
'    F4311.DOCUMENTOTIPO = :P202_DOCUMENTOTIPO',
'        AND ',
'    F4311.DOCUMENTO     = :P202_DOCUMENTO',
';'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Detalle'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20251112194226Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(85920187330651826)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_finder_drop_down=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>85920187330651826
,p_updated_on=>wwv_flow_imp.dz('20251112194226Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85920264287651827)
,p_db_column_name=>'LINEA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>unistr('L\00CDnea')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250521190855Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85920321169651828)
,p_db_column_name=>'DOCUMENTOTIPO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Documentotipo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85920419654651829)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85920592493651830)
,p_db_column_name=>'CODIGOCORTOPRODUCTO'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>unistr('C\00F3d. Corto')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250521190856Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85920758027651832)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Cant.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85920838268651833)
,p_db_column_name=>'UNIDADMEDIDA'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'UM'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250521190856Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85920641205651831)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>80
,p_column_identifier=>'E'
,p_column_label=>unistr('Descripci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87920894127756301)
,p_db_column_name=>'CODIGOPRODUCTO'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>unistr('C\00F3d. Prod.')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250521190856Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87920988583756302)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(135328909612177501)
,p_db_column_name=>'ESTADO'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Estado'
,p_column_html_expression=>'<span style="#ESTILO#">#ESTADO#</span>'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(135329157162177503)
,p_db_column_name=>'GESTION_POR'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>unistr('Gesti\00F3n')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250521190856Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(182982190654007603)
,p_db_column_name=>'ESTILO'
,p_display_order=>130
,p_column_identifier=>'N'
,p_column_label=>'Estilo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(86096835285527868)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'860969'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LINEA:CODIGOPRODUCTO:PRODUCTO:DESCRIPCION:CANTIDAD:UNIDADMEDIDA:ESTADO:GESTION_POR:'
,p_sort_column_1=>'LINEA'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20240408131720Z')
,p_updated_on=>wwv_flow_imp.dz('20251112194226Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(87338465593438808)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(85919753428651822)
,p_button_name=>'AGREGAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(295682704716037726)
,p_button_image_alt=>'Agregar items pendientes'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P202_BOTON_AGREGAR'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-plus-square-o'
,p_grid_column_attributes=>'style="width: fit-content;     background: lightskyblue;     border-radius: 3px;     padding: 5px;     margin: 10px;"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85919870396651823)
,p_name=>'P202_DOCUMENTOTIPO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(85919753428651822)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85919964552651824)
,p_name=>'P202_DOCUMENTO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(85919753428651822)
,p_prompt=>'Documento'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85920957486651834)
,p_name=>'P202_FECHA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(85919753428651822)
,p_prompt=>'Fecha'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85921131103651836)
,p_name=>'P202_USUARIO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(85919753428651822)
,p_prompt=>'Originador'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85921252139651837)
,p_name=>'P202_VALOR'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(85919753428651822)
,p_prompt=>'Valor'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(87338228845438806)
,p_name=>'P202_BOTON_AGREGAR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(85919753428651822)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(87338579619438809)
,p_name=>'Agregar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(87338465593438808)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(163556004331845804)
,p_event_id=>wwv_flow_imp.id(87338579619438809)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.widget.waitPopup();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(87338610351438810)
,p_event_id=>wwv_flow_imp.id(87338579619438809)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_COMP_GESTIONCOMPRAS.SP_AGREGA_ITEMS_OC_BORRADOR(:P202_DOCUMENTOTIPO, :P202_DOCUMENTO, :APP_USER, :G_COMPANIA);',
''))
,p_attribute_02=>'P202_DOCUMENTOTIPO,P202_DOCUMENTO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(87338711171438811)
,p_event_id=>wwv_flow_imp.id(87338579619438809)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(85921061322651835)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga REQ'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    FECHA, USUARIO, VALOR',
'INTO    ',
'    :P202_FECHA, :P202_USUARIO, :P202_VALOR',
'FROM  ',
'    VT_COMP_F4301',
'WHERE ',
'    DOCUMENTOTIPO=:P202_DOCUMENTOTIPO',
'    AND',
'    DOCUMENTO=:P202_DOCUMENTO',
';'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>85921061322651835
);
wwv_flow_imp.component_end;
end;
/
