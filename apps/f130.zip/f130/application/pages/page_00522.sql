prompt --application/pages/page_00522
begin
--   Manifest
--     PAGE: 00522
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>522
,p_name=>'COMEX - dlg Factura Selecciona'
,p_alias=>'COMEX-DLG-FACTURA-SELECCIONA'
,p_page_mode=>'MODAL'
,p_step_title=>'COMEX - Factura Selecciona'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_created_on=>wwv_flow_imp.dz('20241018210601Z')
,p_last_updated_on=>wwv_flow_imp.dz('20241008162709Z')
,p_last_updated_by=>'DCUEVA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(648157023162921171)
,p_plug_name=>'Body'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(329858752129267994)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(648157023162921171)
,p_button_name=>'GRABAR_FACTURA'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Grabar Factura'
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(329862847657268026)
,p_branch_name=>'Go to 521 GRABAR_FACTURA'
,p_branch_action=>'f?p=&APP_ID.:521:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(329858752129267994)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(329859949087268004)
,p_name=>'P522_FAC_VINCULADA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(648157023162921171)
,p_prompt=>'Factura'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    FAC.FACTURA||'' - ''||FAC.CONTENEDOR_NUMERO||'' - ''||FAC.TURNO_IDVEHICULO ',
'                AS FACTURA_DET,',
'    FAC.FACTURA AS FACTURA',
'FROM ',
'    VT_CMEX_DATOS_GESTION_FACTURAS  FAC',
'    LEFT JOIN',
'    T_CMEX_EXPORTACION_FACTURA      EXF',
'        ON FAC.FACTURA = EXF.FACTURA_TIPO||''-''||EXF.FACTURA_NUMERO',
'WHERE',
'    CLIENTE = :P522_CLIENTE',
'        AND ',
'    EXF.FACTURA_NUMERO IS NULL',
'ORDER BY FAC.FACTURA DESC;',
'',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(329860357099268020)
,p_name=>'P522_CLIENTE'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(329868094148317102)
,p_name=>'P522_EXPORTACION_REGISTRO'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(329861643822268023)
,p_validation_name=>'GRABAR_FACTURA'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P522_FAC_VINCULADA IS NULL THEN',
'    RETURN ''Debe seleccionar una factura'';',
'END IF;',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(329858752129267994)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(329861980527268023)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GRABAR_FACTURA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_EXPORTACION.SP_GRABA_FACTURA(',
'    :P522_EXPORTACION_REGISTRO,',
'    SUBSTR(:P522_FAC_VINCULADA, 1, 2),',
'    TO_NUMBER(SUBSTR(:P522_FAC_VINCULADA,4))',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(329858752129267994)
,p_internal_uid=>329861980527268023
);
wwv_flow_imp.component_end;
end;
/
