prompt --application/pages/page_00305
begin
--   Manifest
--     PAGE: 00305
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>305
,p_name=>'Compra Recibida'
,p_step_title=>'Compra Recibida'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230708132700Z')
,p_last_updated_on=>wwv_flow_imp.dz('20230710143300Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(175386150348735605)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(175386479777735608)
,p_plug_name=>'Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(175693258228089178)
,p_plug_name=>'Compra Recibida'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ordencompra',
'	, tipooc',
'	, ordenimportacion',
'	, tipooi',
'	, fechaingresokardex',
'	, descripcion',
'	, codigoitem',
'	, proveedor',
'	, terminospago',
'	, codigoproveedor',
'	, cantidadoriginalsolicitada',
'	, cantidadrecibida',
'	, costounitario',
'	, cantidadrecibida*costounitario usdrecibidos',
'	, totalfactura',
'	, round(((cantidadrecibida)*(costounitario))/(totalfactura),4)*100 participacion',
'	, facturaproveedor',
'	, refrendo',
'	, tiponegociacion',
'	, contenedor40',
'	, contenedor20',
'	, pallet',
'	, fobtotal1 fobtotal1',
'	, fobtotal2 fobtotal2',
'	, fleteinternacionaltotal fleteinternacionaltotal',
'	, fleteinternacionaltotal*(round(((cantidadrecibida)*(costounitario))/(totalfactura),4)) fleteinternacionaldetalle',
'	, (fobtotal2 + fleteinternacionaltotal) cfrtotal',
'	, (fobtotal2 + fleteinternacionaltotal) * (round(((cantidadrecibida)*(costounitario))/(totalfactura),4)) cfrdetalle',
'	, segurototal segurototal',
'	, (segurototal)*(round(((cantidadrecibida)*(costounitario))/(totalfactura),4)) segurodetalle',
'	, vistobuenototal vistobuenototal',
'	, (vistobuenototal)*(round(((cantidadrecibida)*(costounitario))/(totalfactura),4)) vistobuenodetalle',
'	, thctotal thctotal',
'	, (thctotal)*(round(((cantidadrecibida)*(costounitario))/(totalfactura),4)) thcdetalle',
'	, advaloremdetalle advaloremdetalle',
'	, fodinfatotal fodinfatotal',
'	, (fodinfatotal)*(round(((cantidadrecibida)*(costounitario))/(totalfactura),4)) fodinfadetalle',
'	, almacenajetotal almacenajetotal',
'	, (almacenajetotal)*(round(((cantidadrecibida)*(costounitario))/(totalfactura),4)) almacenajedetalle',
'	, agentetotal agentetotal',
'	, (agentetotal)*(round(((cantidadrecibida)*(costounitario))/(totalfactura),4)) agentedetalle',
'	, fletetotal fletetotal',
'	, (fletetotal)*(round(((cantidadrecibida)*(costounitario))/(totalfactura),4)) fletedetalle',
'	, factorhumedadtotal factorhumedadtotal',
'	, (factorhumedadtotal)*(round(((cantidadrecibida)*(costounitario))/(totalfactura),4)) factorhumedaddetalle',
'	, divisasdetalle divisasdetalle',
'	, nvl(',
'		nvl((fobtotal2 + fleteinternacionaltotal) * (round(((cantidadrecibida)*(costounitario))/(totalfactura),4)),0)',
'		+nvl((segurototal)*(round(((cantidadrecibida)*(costounitario))/(totalfactura),4)),0)',
'		+nvl((vistobuenototal)*(round(((cantidadrecibida)*(costounitario))/(totalfactura),4)),0)',
'		+nvl((thctotal)*(round(((cantidadrecibida)*(costounitario))/(totalfactura),4)),0)',
'		+nvl(advaloremdetalle,0)',
'		+nvl((fodinfatotal)*(round(((cantidadrecibida)*(costounitario))/(totalfactura),4)),0)',
'		+nvl((almacenajetotal)*(round(((cantidadrecibida)*(costounitario))/(totalfactura),4)),0)',
'		+nvl((agentetotal)*(round(((cantidadrecibida)*(costounitario))/(totalfactura),4)),0)',
'		+nvl((fletetotal)*(round(((cantidadrecibida)*(costounitario))/(totalfactura),4)),0)',
'		+nvl((factorhumedadtotal)*(round(((cantidadrecibida)*(costounitario))/(totalfactura),4)),0)',
'		+nvl(divisasdetalle,0)',
'		,0) costopuestoplanta',
'	, fechaorden',
'	, fechacompromisooriginal',
'	, codigocortoitem',
'	, y.departamento',
'	, y.divmanufactura',
'	, y.centrotrabajo',
'	, y.categoria',
'	, y.subcategoriaproducto',
'	, y.tipoproducto',
'from ',
'(',
'	select a.pddoco ordencompra',
'		, a.pddcto tipooc',
'		, b.pddoco ordenimportacion',
'		, b.pddcto tipooi',
'		, to_date(d.iltrdj + 1900000,''yyyyddd'') fechaingresokardex',
'		, trim(b.pddsc1)||'' ''||b.pddsc2 descripcion',
'		, to_char(b.pdlitm) codigoitem',
'		, b.pditm codigocortoitem',
'		, (select x.abalph from f0101@jdedtadl x where x.aban8 = b.pdan8) PROVEEDOR',
'		, (select to_char(x.PNPTD) from F0014@JDEDTADL x WHERE x.PNPTC = b.PDPTC) TERMINOSPAGO',
'		, b.PDAN8 CODIGOPROVEEDOR',
'		, d.ILTRQT/10000 CANTIDADRECIBIDA',
'		, b.PDUOM UM',
'		, d.ILUNCS/10000 COSTOUNITARIO',
'		, ROUND((SELECT SUM(x.PDAEXP/100) from f4311@jdedtadl x where b.PDDOCO = x.PDDOCO AND b.PDDCTO = x.PDDCTO AND x.PDLTTR = 385 AND x.PDNXTR = 999 and x.PDAEXP != 0),2) TOTALFACTURA',
'		, IM_VRC_FACT FACTURAPROVEEDOR',
'		, (SELECT to_char(x.PLEXR) FROM F4305@jdedtadl x WHERE x.PLDOCO = b.PDDOCO and x.pllgty = 3 and rownum = 1) REFRENDO',
'		, to_char(b.PDFRTH) TIPONEGOCIACION',
'		, IM_NUM_CONT_40 CONTENEDOR40',
'		, IM_NUM_CONT_20 CONTENEDOR20',
'		, IM_NUM_BULTO_PALET PALLET',
'		, (select sum(x.pdaexp)/100 from f4311@JDEDTADL x WHERE x.PDDOCO = b.PDDOCO AND x.PDDCTO = b.PDDCTO) FOBTOTAL1',
'		, (',
'			(select sum(x.pdaexp)/100 from f4311@JDEDTADL x WHERE x.PDDOCO = b.PDDOCO AND x.PDDCTO = b.PDDCTO)',
'			-',
'			(SELECT sum(distinct x.IMAA/100) FROM f56im10@jdedtadl x WHERE x.IMDOCO = b.PDDOCO AND IMACC2 in (005))',
'			) FOBTOTAL2',
'		, (SELECT sum(x.imaa)/100 from f56im10@jdedtadl x where x.imdoco = to_char(b.pddoco) and imacc2 in (130)) FLETEINTERNACIONALTOTAL',
'		, (SELECT sum(x.glaa)/100 from f0911@jdedtadl x where x.glpo = to_char(b.pddoco) and x.glpdct = b.PDDCTO AND trim(x.GLABR1) =''149'') SEGUROTOTAL',
'		, (SELECT sum(x.glaa)/100 from f0911@jdedtadl x where x.glpo = to_char(b.pddoco) and x.glpdct = b.PDDCTO AND trim(x.GLABR1) =''155'') VISTOBUENOTOTAL',
'		, (SELECT sum(x.glaa)/100 from f0911@jdedtadl x where x.glpo = to_char(b.pddoco) and x.glpdct = b.PDDCTO AND trim(x.GLABR1) =''151'') THCTOTAL',
'		, (SELECT sum(ROUND((x.IMAA/100),2)) FROM f56im10@jdedtadl x WHERE x.IMDOCO = b.PDDOCO AND x.IMDCTO = b.PDDCTO AND x.IMLNID = b.PDLNID AND x.IMLITM = b.PDLITM AND IMACC2 in (100) and IMAA != 0) ADVALOREMDETALLE',
'		, (SELECT sum(x.glaa)/100 FROM F0911@jdedtadl x WHERE x.GLPO = to_char(b.PDDOCO) and x.GLPDCT = b.PDDCTO AND trim(x.GLABR1) =''132'') FODINFATOTAL',
'		, (SELECT sum(x.glaa)/100 FROM F0911@jdedtadl x WHERE x.GLPO = to_char(b.PDDOCO) and x.GLPDCT = b.PDDCTO AND trim(x.GLABR1) =''102'') ALMACENAJETOTAL',
'		, (SELECT sum(x.glaa)/100 FROM F0911@jdedtadl x WHERE x.GLPO = to_char(b.PDDOCO) and x.GLPDCT = b.PDDCTO AND trim(x.GLABR1) =''136'') AGENTETOTAL',
'		, (SELECT sum(x.glaa)/100 FROM F0911@jdedtadl x WHERE x.GLPO = to_char(b.PDDOCO) and x.GLPDCT = b.PDDCTO AND trim(x.GLABR1) =''129'') FLETETOTAL',
'		, (SELECT sum(x.glaa)/100 FROM F0911@jdedtadl x WHERE x.GLPO = to_char(b.PDDOCO) and x.GLPDCT = b.PDDCTO AND trim(x.GLABR1) =''158'') FACTORHUMEDADTOTAL',
'		, (SELECT sum(ROUND((x.imaa/100),2)) FROM f56im10@jdedtadl x WHERE x.IMDOCO = b.PDDOCO AND x.IMDCTO = b.PDDCTO AND x.IMLNID = b.PDLNID AND x.IMLITM = b.PDLITM AND IMACC2 in (139) and IMAA != 0) DIVISASDETALLE',
'		, to_date(a.pddrqj+ 1900000,''yyyyddd'') fechaorden',
'		, to_date(a.pdopdj+ 1900000,''yyyyddd'') fechacompromisooriginal',
'		, a.pduorg/10000 cantidadoriginalsolicitada',
'	from f4311@jdedtadl a',
'	left join f4311@jdedtadl b on to_char(a.pddoco) = b.pdoorn and a.pddcto = b.pdocto and a.pditm = b.pditm and a.PDLNID = b.PDOGNO',
'	left join dp.t_mp_importaciones c on to_char(a.pddoco) = im_vrc_doco_bm_jde and to_char(b.pddoco) = im_vrc_doco_oi_jde and a.pddcto = im_tipo_doc',
'	left join f4111@jdedtadl d on d.ildoco = b.pddoco and d.ildcto = b.pddcto and d.illnid = b.pdlnid and d.ilitm = b.pditm',
'	where a.pddcto in (''CE'',''BM'',''BN'')',
'		and d.ILDCT = ''OV''',
'		and d.iltrqt <> 0',
'		and (a.pdlttr != 220 and a.pdnxtr != 240)',
'		and extract(year from to_date(d.iltrdj + 1900000,''yyyyddd'')) >= extract(year from sysdate) -3',
'		and d.iltrdj between (to_number(to_char(to_date(:p305_fechadesde),''yyyyddd'')) - 1900000) and (to_number(to_char(to_date(:p305_fechahasta),''yyyyddd'')) - 1900000)',
'	union all',
'	select a.pddoco ordencompra',
'		, a.pddcto tipooc',
'		, a.pddoco ordenimportacion',
'		, a.pddcto tipooi',
'		, case when (b.iltrdj IS NULL and a.pdaddj > 0) then to_date(a.pdaddj + 1900000,''yyyyddd'') else to_date(b.iltrdj + 1900000,''yyyyddd'') end FECHAINGRESOKARDEX',
'		, trim(a.pddsc1)||'' ''||a.pddsc2 descripcion',
'		, to_char(a.pdlitm) codigoitem',
'		, a.pditm codigocortoitem',
'		, (select x.abalph from f0101@jdedtadl x where x.aban8 = a.pdan8) proveedor',
'		, (select to_char(x.pnptd) from f0014@jdedtadl x where x.pnptc = a.pdptc) terminospago',
'		, a.pdan8 codigoproveedor',
'		, case when (b.iltrdj is null and a.pdaddj >0)  then a.pdurec/10000 else b.iltrqt/10000 end cantidadrecibida',
'		, a.pduom um',
'		, a.pdprrc/10000 costounitario',
'		, round((select sum(x.pdaexp/100) from f4311@jdedtadl x where a.pddoco = x.pddoco and a.pddcto = x.pddcto and x.pdaexp != 0),2) totalfactura',
'		, '''' FACTURAPROVEEDOR',
'		, '''' REFRENDO',
'		, '''' TIPONEGOCIACION',
'		, 0 CONTENEDOR40',
'		, 0 CONTENEDOR20',
'		, 0 PALLET',
'		, (select sum(x.PDAEXP/100) from f4311@JDEDTADL x WHERE x.PDDOCO = a.PDDOCO AND x.PDDCTO = a.PDDCTO) FOBTOTAL1',
'		, (select sum(x.PDAEXP/100) from f4311@JDEDTADL x WHERE x.PDDOCO = a.PDDOCO AND x.PDDCTO = a.PDDCTO) FOBTOTAL2',
'		, 0 FLETEINTERNACIONALTOTAL',
'		, 0 segurototal',
'		, 0 vistobuenototal',
'		, 0 thctotal',
'		, 0 advaloremdetalle',
'		, 0 fodinfatotal',
'		, 0 almacenajetotal',
'		, 0 agentetotal',
'		, 0 fletetotal',
'		, 0 factorhumedadtotal',
'		, 0 divisasdetalle',
'		, to_date(a.pddrqj+ 1900000,''yyyyddd'') fechaorden',
'		, to_date(a.pdopdj+ 1900000,''yyyyddd'') fechacompromisooriginal',
'		, a.pduorg/10000 cantidadoriginalsolicitada',
'	from f4311@jdedtadl a',
'	left join f4111@jdedtadl b on b.ildoco = a.pddoco and b.ildcto = a.pddcto and b.illnid = a.pdlnid and b.ilitm = a.pditm',
'	where a.pddcto in (''CM'',''CN'',''CT'',''CB'',''CP'')',
'		and (a.pdlttr != 220 and a.pdnxtr != 240)',
'		and case when (b.iltrdj is null and a.pdaddj > 0) then a.pdurec/10000 else b.iltrqt/10000 end != 0',
'		and (',
'			(extract(year from to_date(b.iltrdj + 1900000,''yyyyddd'')) >= extract(year from sysdate) -3)',
'			or',
'			(a.pdaddj > 0 and (extract(year from to_date(a.pdaddj + 1900000,''yyyyddd'')) >= extract(year from sysdate)-3))',
'			)',
'		and ((b.iltrqt <> 0) or (a.pdurec <> 0))',
'		and (',
'			(b.iltrdj between (to_number(to_char(to_date(:p305_fechadesde),''yyyyddd'')) - 1900000) and (to_number(to_char(to_date(:p305_fechahasta),''yyyyddd'')) - 1900000))',
'			or',
'			(a.pdaddj between (to_number(to_char(to_date(:p305_fechadesde),''yyyyddd'')) - 1900000) and (to_number(to_char(to_date(:p305_fechahasta),''yyyyddd'')) - 1900000)))',
'		) x, vt_jde_productos y',
'where x.codigocortoitem = y.codigocorto',
'and cantidadrecibida != 0'))
,p_plug_source_type=>'NATIVE_IR'
,p_updated_on=>wwv_flow_imp.dz('20230710143300Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(175693349608089178)
,p_name=>'Reporte Compra Recibida'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'JALTAMIRANO'
,p_internal_uid=>175693349608089178
,p_updated_on=>wwv_flow_imp.dz('20230710142334Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175693772163089206)
,p_db_column_name=>'ORDENCOMPRA'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'No. Orden'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175694113995089211)
,p_db_column_name=>'TIPOOC'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Tipo OC'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175694571344089211)
,p_db_column_name=>'ORDENIMPORTACION'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'No. OI'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175694956986089212)
,p_db_column_name=>'TIPOOI'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Tipo OI'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175695359523089212)
,p_db_column_name=>'FECHAINGRESOKARDEX'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Fecha Ingreso'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175695799234089214)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>unistr('Descripci\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175696132746089214)
,p_db_column_name=>'CODIGOITEM'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>unistr('C\00F3digo')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175696508768089215)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175696904176089215)
,p_db_column_name=>'TERMINOSPAGO'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>unistr('T\00E9rminos de Pago')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175697372727089215)
,p_db_column_name=>'CODIGOPROVEEDOR'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>unistr('C\00F3digo Proveedor')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175697795835089217)
,p_db_column_name=>'CANTIDADORIGINALSOLICITADA'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Cant. Solicitada'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175698154071089217)
,p_db_column_name=>'CANTIDADRECIBIDA'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Cant. Recibida'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175698553725089217)
,p_db_column_name=>'COSTOUNITARIO'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Cost. Unitario'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175698976989089217)
,p_db_column_name=>'USDRECIBIDOS'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'USD Recibidos'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175699386119089219)
,p_db_column_name=>'TOTALFACTURA'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Total factura'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175699789208089219)
,p_db_column_name=>'PARTICIPACION'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Participacion'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175700130502089219)
,p_db_column_name=>'FACTURAPROVEEDOR'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Factura'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175700560422089219)
,p_db_column_name=>'REFRENDO'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>'Refrendo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175700947296089220)
,p_db_column_name=>'TIPONEGOCIACION'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>unistr('Negociaci\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175701373742089222)
,p_db_column_name=>'CONTENEDOR40'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Cont.40'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175701714619089223)
,p_db_column_name=>'CONTENEDOR20'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Cont.20'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175702158707089223)
,p_db_column_name=>'PALLET'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Pallet'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175702501915089223)
,p_db_column_name=>'FOBTOTAL1'
,p_display_order=>23
,p_column_identifier=>'W'
,p_column_label=>'Fobtotal1'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175702950600089225)
,p_db_column_name=>'FOBTOTAL2'
,p_display_order=>24
,p_column_identifier=>'X'
,p_column_label=>'Fobtotal2'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175703325363089225)
,p_db_column_name=>'FLETEINTERNACIONALTOTAL'
,p_display_order=>25
,p_column_identifier=>'Y'
,p_column_label=>'Fleteinternacionaltotal'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175703712996089225)
,p_db_column_name=>'FLETEINTERNACIONALDETALLE'
,p_display_order=>26
,p_column_identifier=>'Z'
,p_column_label=>'Fleteinternacionaldetalle'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175704102883089225)
,p_db_column_name=>'CFRTOTAL'
,p_display_order=>27
,p_column_identifier=>'AA'
,p_column_label=>'Cfrtotal'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175704526620089226)
,p_db_column_name=>'CFRDETALLE'
,p_display_order=>28
,p_column_identifier=>'AB'
,p_column_label=>'Cfrdetalle'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175704925400089226)
,p_db_column_name=>'SEGUROTOTAL'
,p_display_order=>29
,p_column_identifier=>'AC'
,p_column_label=>'Segurototal'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175705300743089226)
,p_db_column_name=>'SEGURODETALLE'
,p_display_order=>30
,p_column_identifier=>'AD'
,p_column_label=>'Segurodetalle'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175705782221089226)
,p_db_column_name=>'VISTOBUENOTOTAL'
,p_display_order=>31
,p_column_identifier=>'AE'
,p_column_label=>'Vistobuenototal'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175706133690089228)
,p_db_column_name=>'VISTOBUENODETALLE'
,p_display_order=>32
,p_column_identifier=>'AF'
,p_column_label=>'Vistobuenodetalle'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175706588191089228)
,p_db_column_name=>'THCTOTAL'
,p_display_order=>33
,p_column_identifier=>'AG'
,p_column_label=>'Thctotal'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175706953300089228)
,p_db_column_name=>'THCDETALLE'
,p_display_order=>34
,p_column_identifier=>'AH'
,p_column_label=>'Thcdetalle'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175707382529089228)
,p_db_column_name=>'ADVALOREMDETALLE'
,p_display_order=>35
,p_column_identifier=>'AI'
,p_column_label=>'Advaloremdetalle'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175707798726089230)
,p_db_column_name=>'FODINFATOTAL'
,p_display_order=>36
,p_column_identifier=>'AJ'
,p_column_label=>'Fodinfatotal'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175708179402089230)
,p_db_column_name=>'FODINFADETALLE'
,p_display_order=>37
,p_column_identifier=>'AK'
,p_column_label=>'Fodinfadetalle'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175708561967089230)
,p_db_column_name=>'ALMACENAJETOTAL'
,p_display_order=>38
,p_column_identifier=>'AL'
,p_column_label=>'Almacenajetotal'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175708926896089231)
,p_db_column_name=>'ALMACENAJEDETALLE'
,p_display_order=>39
,p_column_identifier=>'AM'
,p_column_label=>'Almacenajedetalle'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175709363406089231)
,p_db_column_name=>'AGENTETOTAL'
,p_display_order=>40
,p_column_identifier=>'AN'
,p_column_label=>'Agentetotal'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175709721910089231)
,p_db_column_name=>'AGENTEDETALLE'
,p_display_order=>41
,p_column_identifier=>'AO'
,p_column_label=>'Agentedetalle'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175710154780089231)
,p_db_column_name=>'FLETETOTAL'
,p_display_order=>42
,p_column_identifier=>'AP'
,p_column_label=>'Fletetotal'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175710570021089233)
,p_db_column_name=>'FLETEDETALLE'
,p_display_order=>43
,p_column_identifier=>'AQ'
,p_column_label=>'Fletedetalle'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175710948764089233)
,p_db_column_name=>'FACTORHUMEDADTOTAL'
,p_display_order=>44
,p_column_identifier=>'AR'
,p_column_label=>'Factorhumedadtotal'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175711334093089233)
,p_db_column_name=>'FACTORHUMEDADDETALLE'
,p_display_order=>45
,p_column_identifier=>'AS'
,p_column_label=>'Factorhumedaddetalle'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175711764991089233)
,p_db_column_name=>'DIVISASDETALLE'
,p_display_order=>46
,p_column_identifier=>'AT'
,p_column_label=>'Divisasdetalle'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175712169096089234)
,p_db_column_name=>'COSTOPUESTOPLANTA'
,p_display_order=>47
,p_column_identifier=>'AU'
,p_column_label=>'Costo Puesto Planta'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175712568478089234)
,p_db_column_name=>'FECHAORDEN'
,p_display_order=>48
,p_column_identifier=>'AV'
,p_column_label=>'Fecha Orden'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175712981014089234)
,p_db_column_name=>'FECHACOMPROMISOORIGINAL'
,p_display_order=>49
,p_column_identifier=>'AW'
,p_column_label=>'Fecha Compromiso Original'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175713301494089236)
,p_db_column_name=>'CODIGOCORTOITEM'
,p_display_order=>50
,p_column_identifier=>'AX'
,p_column_label=>'Codigocortoitem'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175713769556089236)
,p_db_column_name=>'DEPARTAMENTO'
,p_display_order=>51
,p_column_identifier=>'AY'
,p_column_label=>'Departamento'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175714119448089236)
,p_db_column_name=>'DIVMANUFACTURA'
,p_display_order=>52
,p_column_identifier=>'AZ'
,p_column_label=>'Div manufactura'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175714557288089236)
,p_db_column_name=>'CENTROTRABAJO'
,p_display_order=>53
,p_column_identifier=>'BA'
,p_column_label=>'Centro trabajo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175714935161089239)
,p_db_column_name=>'CATEGORIA'
,p_display_order=>54
,p_column_identifier=>'BB'
,p_column_label=>'Categoria'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175715346678089239)
,p_db_column_name=>'SUBCATEGORIAPRODUCTO'
,p_display_order=>55
,p_column_identifier=>'BC'
,p_column_label=>unistr('Subcategor\00EDa producto')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(175715723615089239)
,p_db_column_name=>'TIPOPRODUCTO'
,p_display_order=>56
,p_column_identifier=>'BD'
,p_column_label=>'Tipo producto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(175718728095100953)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1757188'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ORDENCOMPRA:TIPOOC:ORDENIMPORTACION:TIPOOI:FECHAINGRESOKARDEX:DESCRIPCION:CODIGOITEM:PROVEEDOR:TERMINOSPAGO:CODIGOPROVEEDOR:CANTIDADORIGINALSOLICITADA:CANTIDADRECIBIDA:COSTOUNITARIO:USDRECIBIDOS:TOTALFACTURA:PARTICIPACION:FACTURAPROVEEDOR:REFRENDO:TI'
||'PONEGOCIACION:CONTENEDOR40:CONTENEDOR20:PALLET:FOBTOTAL1:FOBTOTAL2:FLETEINTERNACIONALTOTAL:FLETEINTERNACIONALDETALLE:CFRTOTAL:CFRDETALLE:SEGUROTOTAL:SEGURODETALLE:VISTOBUENOTOTAL:VISTOBUENODETALLE:THCTOTAL:THCDETALLE:ADVALOREMDETALLE:FODINFATOTAL:FOD'
||'INFADETALLE:ALMACENAJETOTAL:ALMACENAJEDETALLE:AGENTETOTAL:AGENTEDETALLE:FLETETOTAL:FLETEDETALLE:FACTORHUMEDADTOTAL:FACTORHUMEDADDETALLE:DIVISASDETALLE:COSTOPUESTOPLANTA:FECHAORDEN:FECHACOMPROMISOORIGINAL:CODIGOCORTOITEM:DEPARTAMENTO:DIVMANUFACTURA:CE'
||'NTROTRABAJO:CATEGORIA:SUBCATEGORIAPRODUCTO:TIPOPRODUCTO'
,p_created_on=>wwv_flow_imp.dz('20230708132700Z')
,p_updated_on=>wwv_flow_imp.dz('20230708132700Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(175386586788735609)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(175386479777735608)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Buscar'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(175386201695735606)
,p_name=>'P305_FECHAHASTA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(175386150348735605)
,p_item_default=>'sysdate'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha hasta'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20230710143137Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(175386320483735607)
,p_name=>'P305_FECHADESDE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(175386150348735605)
,p_item_default=>'trunc(add_months(sysdate,-1),''month'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha desde'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20230710143137Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(175386894619735612)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cambia punto decimal'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	execute immediate ''ALTER SESSION SET NLS_NUMERIC_CHARACTERS =''''.,'''''';',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>175386894619735612
);
wwv_flow_imp.component_end;
end;
/
