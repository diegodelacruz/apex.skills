prompt --application/pages/page_00190
begin
--   Manifest
--     PAGE: 00190
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>190
,p_name=>'Archivos COMEX'
,p_alias=>'ARCHIVOS-COMEX'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Archivos COMEX'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20230825163645Z')
,p_last_updated_on=>wwv_flow_imp.dz('20251003152556Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61446137573698522)
,p_plug_name=>unistr('Par\00E1metros')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'APP_USER'
,p_plug_display_when_cond2=>'DDELACRUZ'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61446510462698526)
,p_plug_name=>'Cargar'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P190_FLAG2'
,p_plug_display_when_cond2=>'B'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20230828162428Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(268065642168889287)
,p_name=>'Archivos'
,p_template=>wwv_flow_imp.id(295630388916037685)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.numeroarchivo',
'	, dbms_lob.getlength(a.blobcontent) blobcontent',
'	, a.filename',
'	, a.observacion',
'	, a.tipo',
'	, data.pk_commons.f_googledocview(a.numeroarchivo,a.mimetype) enlacearchivo',
'	, ''-'' eliminar',
'from files.t_apex_archivos a inner join t_cmex_mesatrabajo b on a.tabla = a.tabla and a.id_tabla = to_char(b.id) and a.tipo = a.tipo',
'where 1 = 1',
'	and (',
'		(tabla = ''T_CMEX_MESATRABAJO'' and id_tabla = :p190_idmesa)',
'		or ',
'		(tabla = ''T_CMEX_MUESTRAS'' and id_tabla = :p190_idmuestra)',
'		or',
'		(tabla = ''T_CMEX_EXPORTACION'' and id_tabla = :p190_idmesa)',
'		)',
'and tipo = tipo and nvl(estado,1) = 1;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No hay archivos. Verifique el enlace enviado o el usuario responsable no ha cargado los archivos necesarios.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20251003152556Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(62937417401305945)
,p_query_column_id=>1
,p_column_alias=>'NUMEROARCHIVO'
,p_column_display_sequence=>1
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(62937823792305946)
,p_query_column_id=>2
,p_column_alias=>'BLOBCONTENT'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251003152556Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(62938286786305947)
,p_query_column_id=>3
,p_column_alias=>'FILENAME'
,p_column_display_sequence=>22
,p_column_heading=>'Archivo'
,p_use_as_row_header=>'N'
,p_column_link=>'#ENLACEARCHIVO#'
,p_column_linktext=>'#FILENAME#'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20251003152414Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(62938613043305947)
,p_query_column_id=>4
,p_column_alias=>'OBSERVACION'
,p_column_display_sequence=>42
,p_column_heading=>unistr('Observaci\00F3n')
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(61446890220698529)
,p_query_column_id=>5
,p_column_alias=>'TIPO'
,p_column_display_sequence=>12
,p_default_sort_column_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251003152556Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(193111752886648723)
,p_query_column_id=>6
,p_column_alias=>'ENLACEARCHIVO'
,p_column_display_sequence=>62
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251003152256Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(64132937854537816)
,p_query_column_id=>7
,p_column_alias=>'ELIMINAR'
,p_column_display_sequence=>52
,p_column_heading=>'Eliminar'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:$s(''P190_NUMEROARCHIVO'','''');$s(''P190_NUMEROARCHIVO'',''#NUMEROARCHIVO#'');'
,p_column_linktext=>'<span title="Eliminar" class="fa fa-trash-o"/>'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_display_when_condition=>'P190_IDETAPA'
,p_display_when_condition2=>'ET9'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20251003152230Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(70577890386986401)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(61446510462698526)
,p_button_name=>'CARGAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Cargar Archivo'
,p_icon_css_classes=>'fa-cloud-upload'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>1
,p_created_on=>wwv_flow_imp.dz('20230827051352Z')
,p_updated_on=>wwv_flow_imp.dz('20230827051352Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61446274412698523)
,p_name=>'P190_IDMESA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(61446137573698522)
,p_prompt=>'ID Mesa'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20230827035607Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61446334739698524)
,p_name=>'P190_IDPROV'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(61446137573698522)
,p_prompt=>unistr('Provisi\00F3n')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20230827035607Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(70571150304804041)
,p_name=>'P190_TIPOARCHIVO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(61446510462698526)
,p_prompt=>'Tipo archivo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select descripcion||decode(pk_cmex_mesatrabajo.f_archivoetapa(id_tabla,:p190_idmodulo,:p190_idetapa),2,''*'',null) dis, id_tabla from data.t_corp_udc',
'where id_cabecera = ''CMEX_TARC'' and activo = ''1'' and pk_cmex_mesatrabajo.f_archivoetapa(id_tabla,:p190_idmodulo,:p190_idetapa) > 0 order by id_tabla,descripcion'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20230827044212Z')
,p_updated_on=>wwv_flow_imp.dz('20230831152600Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(70571596337804044)
,p_name=>'P190_ARCHIVOS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(61446510462698526)
,p_prompt=>'Archivos'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'N'
,p_attribute_12=>'NATIVE'
,p_created_on=>wwv_flow_imp.dz('20230827044212Z')
,p_updated_on=>wwv_flow_imp.dz('20230827044403Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(70571975847804044)
,p_name=>'P190_NUMEROARCHIVO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(268065642168889287)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_created_on=>wwv_flow_imp.dz('20230827044212Z')
,p_updated_on=>wwv_flow_imp.dz('20230828170818Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(250536644557615237)
,p_name=>'P190_IDETAPA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(61446137573698522)
,p_prompt=>'ID Etapa'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20230827035243Z')
,p_updated_on=>wwv_flow_imp.dz('20230827035608Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(250536869763615239)
,p_name=>'P190_IDMODULO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(61446137573698522)
,p_prompt=>'ID Modulo'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20230827035243Z')
,p_updated_on=>wwv_flow_imp.dz('20230827035608Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(250537085659615241)
,p_name=>'P190_FLAG1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(61446137573698522)
,p_prompt=>'Flag 1'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20230827035607Z')
,p_updated_on=>wwv_flow_imp.dz('20230827035607Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(250537149604615242)
,p_name=>'P190_FLAG2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(61446137573698522)
,p_prompt=>'Flag 2'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20230827035607Z')
,p_updated_on=>wwv_flow_imp.dz('20230827035607Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(250537964511615250)
,p_name=>'P190_OBSERVACION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(61446510462698526)
,p_prompt=>unistr('Observaci\00F3n')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20230827051148Z')
,p_updated_on=>wwv_flow_imp.dz('20230827051148Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(404089000114906613)
,p_name=>'P190_IDMUESTRA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(61446137573698522)
,p_prompt=>'Idmuestra'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20240902212449Z')
,p_updated_on=>wwv_flow_imp.dz('20240902212449Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(64133089899537817)
,p_name=>'Eliminar'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P190_NUMEROARCHIVO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20230828171004Z')
,p_updated_on=>wwv_flow_imp.dz('20250312174832Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(64133248145537819)
,p_event_id=>wwv_flow_imp.id(64133089899537817)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_numeroarchivo number;',
'v_observacion varchar2(100);',
'begin',
'	v_numeroarchivo := :p190_numeroarchivo;',
'	v_observacion	:= :app_user||'', Eliminado el ''||to_char(sysdate,''dd/mm/yyyy hh24:mi'');',
'	update files.t_apex_archivos x set x.estado = 0, ride = v_observacion where numeroarchivo = v_numeroarchivo;',
'	-- pk_apex_archivos.sp_eliminaarchivo(:p190_numeroarchivo);',
'end;'))
,p_attribute_02=>'P190_NUMEROARCHIVO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20230828171004Z')
,p_updated_on=>wwv_flow_imp.dz('20250312174832Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(64133465313537821)
,p_event_id=>wwv_flow_imp.id(64133089899537817)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(268065642168889287)
,p_created_on=>wwv_flow_imp.dz('20230828171033Z')
,p_updated_on=>wwv_flow_imp.dz('20230828171033Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(250537296957615243)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar Datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_flag1		varchar2(1);',
'v_flag2		varchar2(1);',
'v_idmesa	number;',
'v_idmodulo	varchar2(3);',
'v_idetapa	varchar2(3);',
'begin',
unistr('	-- El ID de la mesa de trabajo siempre debe venir como par\00E1metro.'),
'	-- Las banderas son:',
unistr('	--	A: Buscar\00E1 la etapa actual y mostrar\00E1 los datos de la etapa.'),
unistr('	--	B: Buscar\00E1 todos los archivos y no podr\00E1 cargar.'),
'	v_flag1 := :p190_flag1; v_flag2 := :p190_flag2;',
'	v_idmesa	:= :p190_idmesa;',
'	v_idmodulo	:= :p190_idmodulo;',
'	v_idetapa	:= :p190_idetapa;',
'',
'	if v_flag1 = ''A'' and v_idetapa is null then',
'		select codigomodulo,codigoetapa into v_idmodulo,v_idetapa',
'		from data.t_cmex_mesatrabajo where id = v_idmesa and rownum = 1;',
'		v_flag2 := ''A'';',
'	elsif v_flag1 = ''A'' and v_idetapa is not null then',
'		select codigomodulo into v_idmodulo',
'		from data.t_cmex_mesatrabajo where id = v_idmesa and rownum = 1;',
'		v_flag2 := ''B'';',
'	end if;',
'',
'	:p190_flag2		:= v_flag2;',
'	:p190_idmodulo	:= v_idmodulo;',
'	:p190_idetapa	:= v_idetapa;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>250537296957615243
,p_created_on=>wwv_flow_imp.dz('20230827044015Z')
,p_updated_on=>wwv_flow_imp.dz('20230827050934Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(70572405995806296)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar Archivo'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'v_numeroarchivo number;',
'begin',
'	if :p190_archivos is not null then',
'		pk_apex_archivos.sp_creararchivo(:p190_archivos,''T_CMEX_MESATRABAJO'',:p190_idmesa,:p190_tipoarchivo,:p190_observacion,:app_user,v_numeroarchivo);',
'		update files.t_apex_archivos x set estado = ''1'' where numeroarchivo = v_numeroarchivo;',
'	end if; ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'No se pudo cargar el archivo.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(70577890386986401)
,p_process_success_message=>'Archivo cargado.'
,p_internal_uid=>70572405995806296
,p_created_on=>wwv_flow_imp.dz('20230827044235Z')
,p_updated_on=>wwv_flow_imp.dz('20250312173948Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
