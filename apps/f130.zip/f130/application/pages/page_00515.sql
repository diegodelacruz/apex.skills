prompt --application/pages/page_00515
begin
--   Manifest
--     PAGE: 00515
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>515
,p_name=>'COMEX . dlg Selecciona Turno'
,p_alias=>'COMEX-DLG-SELECCIONA-TURNO'
,p_page_mode=>'MODAL'
,p_step_title=>'COMEX . Selecciona Turno'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_created_on=>wwv_flow_imp.dz('20241018210600Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260402164711Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(311041525835669850)
,p_plug_name=>'Body'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(312480135868335103)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(311041525835669850)
,p_button_name=>'ATAR_TURNO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Atar Turno'
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(312480495625335106)
,p_branch_name=>'ATAR_TURNO'
,p_branch_action=>'f?p=&APP_ID.:511:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(312479969241335101)
,p_name=>'P515_DATOS_GESTION_DETALLE_ID'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(312480079327335102)
,p_name=>'P515_TURNO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(311041525835669850)
,p_prompt=>'Turno'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select substr(to_char(fechadesde_hora),1,10)||'' ''||upper(trim(nombres))||'' - ''||trim(idvehiculo) as descripcion,',
'	id as turno_id',
'from data.vt_cmex_turnos_acpe t',
'where 1 = 1',
'	and trunc(t.fechadesde) between trunc(sysdate-450) and trunc(sysdate+365)',
'	and (instr(descripcionturno,''EXPO'') > 0 or motivo = 2)',
'order by fechadesde_hora desc'))
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET_FILTER'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_updated_on=>wwv_flow_imp.dz('20260402164711Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(312480217218335104)
,p_validation_name=>'ATAR_TURNO'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P515_TURNO IS NULL THEN',
'    RETURN ''Debe seleccionar un turno.'';',
'END IF;',
'',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(312480135868335103)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(312480333528335105)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ATAR_TURNO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_DATOS_GESTION.SP_DATOS_GESTION_DETALLE_TURNO(',
'    :P515_DATOS_GESTION_DETALLE_ID,',
'    :P515_TURNO',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(312480135868335103)
,p_internal_uid=>312480333528335105
);
wwv_flow_imp.component_end;
end;
/
