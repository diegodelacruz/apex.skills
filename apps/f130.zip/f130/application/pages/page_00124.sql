prompt --application/pages/page_00124
begin
--   Manifest
--     PAGE: 00124
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>124
,p_name=>'Seleccion Proveedor OC'
,p_page_mode=>'MODAL'
,p_step_title=>'Seleccion Proveedor OC'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'17'
,p_created_on=>wwv_flow_imp.dz('20230708132653Z')
,p_last_updated_on=>wwv_flow_imp.dz('20220526145547Z')
,p_last_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(85791222713912657)
,p_plug_name=>'Items'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(46415070522667026)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(85791222713912657)
,p_button_name=>'SeleccionarProveedor'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(295682704716037726)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Seleccionar'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-check'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43858479947818627)
,p_name=>'P124_DOCUMENTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(85791222713912657)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43858870826818629)
,p_name=>'P124_DOCUMENTOTIPO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(85791222713912657)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43859635716818629)
,p_name=>'P124_SELECCIONPROVEEDOR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(85791222713912657)
,p_prompt=>'Buscar Proveedor'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CODIGOPROVEEDOR || '' - ''|| DESCRIPCION a, CODIGOPROVEEDOR b from vt_jde_maestroproveedor',
'order by descripcion'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_colspan=>6
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(43860084743818630)
,p_name=>'Busca Proveedor'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(46415070522667026)
,p_condition_element=>'P124_SELECCIONPROVEEDOR'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43861511260818630)
,p_event_id=>wwv_flow_imp.id(43860084743818630)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_proveedor number;',
'v_costo number;',
'v_moneda nvarchar2(5);',
'BEGIN',
'--ACTUALIZO VALORES DEL PROVEEDOR SELECCIONADO',
'BEGIN',
'',
'select distinct',
'CODIGOPROVEEDOR, 0, MONEDA',
'into v_proveedor, v_costo, v_moneda',
'from VT_JDE_MAESTROPROVEEDOR ',
'where ',
'CODIGOPROVEEDOR = :P124_SELECCIONPROVEEDOR ;',
'exception',
'when NO_DATA_FOUND then',
'v_proveedor := NULL;',
'END;',
'--',
'--Actualizo los valores',
'update t_comp_generaoc',
'set PROVEEDOR = v_proveedor, ',
'PRECIOUNITARIO = v_costo, ',
'MONEDA = v_moneda',
'where DOCUMENTO = :P124_DOCUMENTO',
'and DOCUMENTOTIPO = :P124_DOCUMENTOTIPO',
'and estado = 0',
'AND ((PRECIOUNITARIO IS NULL) OR (PRECIOUNITARIO =0));',
'COMMIT;',
'END;',
''))
,p_attribute_02=>'P124_SELECCIONPROVEEDOR,P124_DOCUMENTO,P124_DOCUMENTOTIPO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46414900777667025)
,p_event_id=>wwv_flow_imp.id(43860084743818630)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_proveedor number;',
'v_costo number;',
'v_moneda nvarchar2(5);',
'BEGIN',
'--ACTUALIZO VALORES DEL PROVEEDOR SELECCIONADO PARA TODAS LAS LINEAS',
'FOR i in (select KEYID, CODIGOPRODUCTO, BODEGA',
'from t_comp_generaoc',
'where DOCUMENTOTIPO = :P124_DOCUMENTOTIPO',
'and DOCUMENTO = :P124_DOCUMENTO',
'AND ESTADO = 0 AND ((PRECIOUNITARIO =0)))',
'LOOP',
'BEGIN',
'select DISTINCT CBAN8, CBPRRC, CBCRCD',
'into v_proveedor, v_costo, v_moneda',
'from F41061@JDEDTADL',
'LEFT JOIN vt_jde_librodirecciones ON CBAN8 = CODIGO',
'where (dp.f_g2jde(sysdate) between CBEFTJ  and CBEXDJ)',
'AND TRIM(CBlitm) = i.CODIGOPRODUCTO',
'AND CBAN8 = :P124_SELECCIONPROVEEDOR;',
'exception',
'when NO_DATA_FOUND then',
'v_proveedor := NULL;',
'END;',
'--',
'--Actualizo los valores',
'if v_proveedor is not null then',
'update t_comp_generaoc',
'set PROVEEDOR = v_proveedor, ',
'PRECIOUNITARIO = v_costo, ',
'MONEDA = v_moneda',
'where KEYID = i.KEYID;',
'COMMIT;',
'update t_comp_generaoc',
'set TOTALCOMPRA = (CANTIDADSUGERIDACOMPRA * PRECIOUNITARIO)/10000',
'where KEYID = i.KEYID;',
'end if;',
'COMMIT;',
'end loop;',
'END;'))
,p_attribute_02=>'P124_SELECCIONPROVEEDOR,P124_DOCUMENTO,P124_DOCUMENTOTIPO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43861065720818630)
,p_event_id=>wwv_flow_imp.id(43860084743818630)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46415178060667027)
,p_name=>'Busca Proveedor_1'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P124_SELECCIONPROVEEDOR'
,p_condition_element=>'P124_SELECCIONPROVEEDOR'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46415264724667028)
,p_event_id=>wwv_flow_imp.id(46415178060667027)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_proveedor number;',
'v_costo number;',
'v_moneda nvarchar2(5);',
'BEGIN',
'--ACTUALIZO VALORES DEL PROVEEDOR SELECCIONADO PARA TODAS LAS LINEAS',
'FOR i in (select KEYID, CODIGOPRODUCTO, BODEGA',
'from t_comp_generaoc',
'where DOCUMENTOTIPO = :P124_DOCUMENTOTIPO',
'and DOCUMENTO = :P124_DOCUMENTO',
'AND ESTADO = 0)',
'LOOP',
'BEGIN',
'select PCAN8, CBPRRC, CBCRCD',
'into v_proveedor, v_costo, v_moneda',
'from f43090@jdedtadl ',
'LEFT JOIN F41061@JDEDTADL ON pcitm = CBITM AND PCAN8 = CBAN8 ',
'LEFT JOIN vt_jde_librodirecciones ON PCAN8 = CODIGO',
'where PCNROU = ''IMPT''',
'AND (dp.f_g2jde(sysdate) between PCCEFJ  and PCCXPJ) and (dp.f_g2jde(sysdate) between CBEFTJ  and CBEXDJ)',
'AND TRIM(pclitm) = i.CODIGOPRODUCTO',
'AND trim(PCMCU) = trim(i.BODEGA)',
'AND PCAN8 = :P124_SELECCIONPROVEEDOR;',
'exception',
'when NO_DATA_FOUND then',
'v_proveedor := NULL;',
'END;',
'--',
'--Actualizo los valores',
'if v_proveedor is not null then',
'update t_comp_generaoc',
'set PROVEEDOR = v_proveedor, ',
'PRECIOUNITARIO = v_costo, ',
'MONEDA = v_moneda',
'where KEYID = i.KEYID;',
'COMMIT;',
'update t_comp_generaoc',
'set TOTALCOMPRA = (CANTIDADSUGERIDACOMPRA * PRECIOUNITARIO)/10000',
'where KEYID = i.KEYID;',
'end if;',
'COMMIT;',
'end loop;',
'END;'))
,p_attribute_02=>'P124_SELECCIONPROVEEDOR,P124_DOCUMENTO,P124_DOCUMENTOTIPO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46415315052667029)
,p_event_id=>wwv_flow_imp.id(46415178060667027)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46415403087667030)
,p_event_id=>wwv_flow_imp.id(46415178060667027)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_proveedor number;',
'v_costo number;',
'v_moneda nvarchar2(5);',
'BEGIN',
'--ACTUALIZO VALORES DEL PROVEEDOR SELECCIONADO',
'BEGIN',
'',
'select distinct',
'CODIGOPROVEEDOR, 0, MONEDA',
'into v_proveedor, v_costo, v_moneda',
'from VT_JDE_MAESTROPROVEEDOR ',
'where ',
'CODIGOPROVEEDOR = :P124_SELECCIONPROVEEDOR ;',
'exception',
'when NO_DATA_FOUND then',
'v_proveedor := NULL;',
'END;',
'--',
'--Actualizo los valores',
'update t_comp_generaoc',
'set PROVEEDOR = v_proveedor, ',
'PRECIOUNITARIO = v_costo, ',
'MONEDA = v_moneda',
'where DOCUMENTO = :P124_DOCUMENTO',
'and DOCUMENTOTIPO = :P124_DOCUMENTOTIPO',
'and estado = 0;',
'COMMIT;',
'END;',
''))
,p_attribute_02=>'P124_SELECCIONPROVEEDOR,P124_DOCUMENTO,P124_DOCUMENTOTIPO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp.component_end;
end;
/
