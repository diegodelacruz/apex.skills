prompt --application/pages/page_00217
begin
--   Manifest
--     PAGE: 00217
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>217
,p_name=>'Pago Recurrente - Responsable'
,p_alias=>'PAGO-RECURRENTE-RESPONSABLE'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Pago Recurrente - Responsable'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(regItems).hide();'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'21'
,p_created_on=>wwv_flow_imp.dz('20240226220111Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260206140601Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(157085618090941001)
,p_plug_name=>'Pagos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_read_only_when=>'P217_HABILITAPAGOS'
,p_plug_read_only_when2=>'0'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250828214538Z')
,p_updated_on=>wwv_flow_imp.dz('20250829145039Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(255046862254448348)
,p_plug_name=>unistr('\00CDtems')
,p_region_name=>'regItems'
,p_region_template_options=>'t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(295605160997037667)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20240314141237Z')
,p_updated_on=>wwv_flow_imp.dz('20240815141932Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(157085914440941004)
,p_plug_name=>unistr('Par\00E1metros')
,p_parent_plug_id=>wwv_flow_imp.id(255046862254448348)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>30
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250829144005Z')
,p_updated_on=>wwv_flow_imp.dz('20250829144009Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(257265699905638501)
,p_plug_name=>'Responsables'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>'select * from t_corp_udc where id_cabecera = ''COMP_PRRSP'' and id_tabla = lpad(:p217_idnegociacion,5,''0'')'
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P217_IDNEGOCIACION'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P217_UNIDADNEGOCIO'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Responsables'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_created_on=>wwv_flow_imp.dz('20240314143734Z')
,p_updated_on=>wwv_flow_imp.dz('20240815143727Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(257265894117638503)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20240314150158Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(257265947877638504)
,p_name=>'ID_CABECERA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID_CABECERA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'TG'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>40
,p_value_alignment=>'CENTER'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'COMP_PRRSP'
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20240314152440Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(257266072567638505)
,p_name=>'ID_TABLA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID_TABLA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>unistr('ID Negociaci\00F3n')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>50
,p_value_alignment=>'CENTER'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_default_type=>'EXPRESSION'
,p_default_language=>'PLSQL'
,p_default_expression=>'lpad(:p217_idnegociacion,5,''0'')'
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20240314152440Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(257266174602638506)
,p_name=>'DESCRIPCION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPCION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Unidad Negocio'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>60
,p_value_alignment=>'CENTER'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_default_type=>'EXPRESSION'
,p_default_language=>'PLSQL'
,p_default_expression=>'trim(:p217_unidadnegocio)'
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20240314152440Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(257266256596638507)
,p_name=>'VALOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VALOR'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>'Requisitor'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET_FILTER'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'3'
,p_attribute_07=>unistr('Persona que ingresa la Requisici\00F3n')
,p_is_required=>false
,p_max_length=>1000
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(86097416900927959)
,p_lov_display_extra=>false
,p_lov_display_null=>false
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20240314152440Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(257266354286638508)
,p_name=>'VALOR2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VALOR2'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>'Validador'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET_FILTER'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'3'
,p_is_required=>false
,p_max_length=>1000
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(86097416900927959)
,p_lov_display_extra=>false
,p_lov_display_null=>false
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20240314152440Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(257266431198638509)
,p_name=>'ACTIVO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACTIVO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Activo'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>90
,p_value_alignment=>'CENTER'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20240314152352Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(257266559098638510)
,p_name=>'DESCRIPCION2'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPCION2'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>unistr('Observaci\00F3n')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20240314152440Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(257266645963638511)
,p_name=>'CODIGOCOMPANIA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODIGOCOMPANIA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>unistr('Compa\00F1\00EDa')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>110
,p_value_alignment=>'CENTER'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'G_COMPANIA'
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20240314152352Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(257266742094638512)
,p_name=>'VIGENCIADESDE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VIGENCIADESDE'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>120
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20240314145913Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(257266863142638513)
,p_name=>'VIGENCIAHASTA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VIGENCIAHASTA'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>130
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20240314145913Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(257266956602638514)
,p_name=>'DESCRIPCION3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPCION3'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>140
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20240314145913Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(257267094555638515)
,p_name=>'VALOR3'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VALOR3'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>150
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20240314145913Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(257267250673638517)
,p_name=>'APEX$ROW_ACTION'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_updated_on=>wwv_flow_imp.dz('20240314145912Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(257267350181638518)
,p_name=>'APEX$ROW_SELECTOR'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240314145912Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(257265702869638502)
,p_internal_uid=>257265702869638502
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>false
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>false
,p_show_toolbar=>true
,p_toolbar_buttons=>'SAVE'
,p_add_button_label=>'Agregar'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>true
,p_download_formats=>'XLSX'
,p_enable_mail_download=>false
,p_fixed_header=>'NONE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_updated_on=>wwv_flow_imp.dz('20240815143727Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(257272465494643142)
,p_interactive_grid_id=>wwv_flow_imp.id(257265702869638502)
,p_static_id=>'2572725'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
,p_updated_on=>wwv_flow_imp.dz('20240314151416Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(257272619371643142)
,p_report_id=>wwv_flow_imp.id(257272465494643142)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(257273028181643147)
,p_view_id=>wwv_flow_imp.id(257272619371643142)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(257265894117638503)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(257273932952643150)
,p_view_id=>wwv_flow_imp.id(257272619371643142)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(257265947877638504)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(257274883525643152)
,p_view_id=>wwv_flow_imp.id(257272619371643142)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(257266072567638505)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>125
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(257275725930643154)
,p_view_id=>wwv_flow_imp.id(257272619371643142)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(257266174602638506)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>125
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(257276604979643156)
,p_view_id=>wwv_flow_imp.id(257272619371643142)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(257266256596638507)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>275
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(257277547692643158)
,p_view_id=>wwv_flow_imp.id(257272619371643142)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(257266354286638508)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>275
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(257278429464643160)
,p_view_id=>wwv_flow_imp.id(257272619371643142)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(257266431198638509)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(257279378275643162)
,p_view_id=>wwv_flow_imp.id(257272619371643142)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(257266559098638510)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(257280213084643164)
,p_view_id=>wwv_flow_imp.id(257272619371643142)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(257266645963638511)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(257281124533643167)
,p_view_id=>wwv_flow_imp.id(257272619371643142)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(257266742094638512)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(257282092224643169)
,p_view_id=>wwv_flow_imp.id(257272619371643142)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(257266863142638513)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(257282927057643172)
,p_view_id=>wwv_flow_imp.id(257272619371643142)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(257266956602638514)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(257283883796643175)
,p_view_id=>wwv_flow_imp.id(257272619371643142)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(257267094555638515)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(257325188488772941)
,p_view_id=>wwv_flow_imp.id(257272619371643142)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(257267250673638517)
,p_is_visible=>true
,p_is_frozen=>true
,p_width=>35
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(371022697255652435)
,p_plug_name=>'Objetos de Costo'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from dual',
'where 1 = 1',
'	and :p217_unidadnegocio is not null'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20240815141931Z')
,p_updated_on=>wwv_flow_imp.dz('20250828214538Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(371023333156652442)
,p_plug_name=>'Mensaje'
,p_parent_plug_id=>wwv_flow_imp.id(371022697255652435)
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(295605160997037667)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>unistr('Estos Objetos de Costo deben ser completados \00FAnicamente cuando Finanzas los haya solicitado.')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20240815142706Z')
,p_updated_on=>wwv_flow_imp.dz('20240815143321Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(371023565082652444)
,p_plug_name=>'Objetos'
,p_parent_plug_id=>wwv_flow_imp.id(371022697255652435)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20240815142754Z')
,p_updated_on=>wwv_flow_imp.dz('20240815142754Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(371023105101652440)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(371023565082652444)
,p_button_name=>'GUARDAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_created_on=>wwv_flow_imp.dz('20240815142338Z')
,p_updated_on=>wwv_flow_imp.dz('20240815153626Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(371023206364652441)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(371023565082652444)
,p_button_name=>'BORRAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Borrar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''x''',
'from data.t_corp_udc',
'where 1 = 1',
'and id_cabecera = ''COMP_PRRSP'' and id_tabla = lpad(:p217_idnegociacion,5,''0'') and valor3 is not null;'))
,p_button_condition_type=>'EXISTS'
,p_created_on=>wwv_flow_imp.dz('20240815142338Z')
,p_updated_on=>wwv_flow_imp.dz('20240815160755Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(157086129355941006)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(157085618090941001)
,p_button_name=>'AGREGAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Agregar'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P217_HABILITAPAGOS'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-plus-circle-o'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250829145207Z')
,p_updated_on=>wwv_flow_imp.dz('20250829145607Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(157085716641941002)
,p_name=>'P217_PAGOS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(157085618090941001)
,p_prompt=>'Pagos'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20250828214538Z')
,p_updated_on=>wwv_flow_imp.dz('20250829144008Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(157085845451941003)
,p_name=>'P217_CANTIDAD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(157085618090941001)
,p_prompt=>'Agregar Pagos'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'1'
,p_attribute_03=>'right'
,p_attribute_04=>'numeric'
,p_created_on=>wwv_flow_imp.dz('20250828214538Z')
,p_updated_on=>wwv_flow_imp.dz('20250828214550Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(157086096648941005)
,p_name=>'P217_HABILITAPAGOS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(157085914440941004)
,p_prompt=>'Habilitapagos'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250829144007Z')
,p_updated_on=>wwv_flow_imp.dz('20250829144007Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(255046954958448349)
,p_name=>'P217_IDNEGOCIACION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(255046862254448348)
,p_prompt=>unistr('ID Negociaci\00F3n')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240314141335Z')
,p_updated_on=>wwv_flow_imp.dz('20240314141335Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(255047011178448350)
,p_name=>'P217_UNIDADNEGOCIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(255046862254448348)
,p_prompt=>'Unidad Negocio:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240314141631Z')
,p_updated_on=>wwv_flow_imp.dz('20240314145503Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(371022776456652436)
,p_name=>'P217_MARCA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(371023565082652444)
,p_prompt=>'Marca'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20240815142112Z')
,p_updated_on=>wwv_flow_imp.dz('20240815142807Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(371022834604652437)
,p_name=>'P217_CLIENTE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(371023565082652444)
,p_prompt=>'Cliente'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20240815142112Z')
,p_updated_on=>wwv_flow_imp.dz('20240815142807Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(371022972041652438)
,p_name=>'P217_LINEANEGOCIO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(371023565082652444)
,p_prompt=>unistr('L\00EDnea de Negocio')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20240815142112Z')
,p_updated_on=>wwv_flow_imp.dz('20240815142807Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(371023096281652439)
,p_name=>'P217_CANAL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(371023565082652444)
,p_prompt=>'Canal'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20240815142112Z')
,p_updated_on=>wwv_flow_imp.dz('20240815142807Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(371023624483652445)
,p_name=>'Guardar OCs'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(371023105101652440)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20240815153626Z')
,p_updated_on=>wwv_flow_imp.dz('20250918174850Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(371023740046652446)
,p_event_id=>wwv_flow_imp.id(371023624483652445)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
,p_created_on=>wwv_flow_imp.dz('20240815153626Z')
,p_updated_on=>wwv_flow_imp.dz('20240815153626Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(371023848661652447)
,p_event_id=>wwv_flow_imp.id(371023624483652445)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_idneg number;',
'v_json	varchar2(1000);',
'v_obj1	varchar2(10);',
'v_obj2	varchar2(10);',
'v_obj3	varchar2(10);',
'v_obj4	varchar2(10);',
'v_log_app varchar2(100);',
'v_log_dsc varchar2(999);',
'begin',
'	v_log_app := ''apex.130.217.GuardarObjetosDeCosto'';',
'	v_idneg	:= :p217_idnegociacion;',
'	v_obj1	:= trim(:p217_marca);',
'	v_obj2	:= trim(:p217_cliente);',
'	v_obj3	:= trim(:p217_lineanegocio);',
'	v_obj4	:= trim(:p217_canal);',
'',
unistr('	v_log_dsc := ''Par\00E1metros: ID Neg.: ''||v_idneg||'', Marca: ''||nvl(v_obj1,''-NO-'')||'', Cliente: ''||nvl(v_obj2,''-NO-'')||'', L\00EDnea de Negocio: ''||nvl(v_obj3,''-NO-'')||'', Canal: ''||nvl(v_obj4,''-NO-'');'),
'	data.pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,null,null,null);',
'',
'	begin',
'		select json_arrayagg(',
'			json_object(',
'				''idneg''		value idneg',
'				, ''linea''	value linea',
'				, ''abt1''	value abt1',
'				, ''abr1''	value marca',
'				, ''abt2''	value abt2',
'				, ''abr2''	value cliente',
'				, ''abt3''	value abt3',
'				, ''abr3''	value lineanegocio',
'				, ''abt4''	value abt4',
'				, ''abr4''	value canal',
'			)) into v_json',
'		from (',
'			select rownum linea',
'				, v_idneg idneg',
'				, ''4'' abt1',
'				, v_obj1 marca',
'				, ''C'' abt2',
'				, v_obj2 cliente',
'				, ''7'' abt3',
'				, v_obj3 lineanegocio',
'				, ''3'' abt4',
'				, v_obj4 canal',
'			from dual where v_obj1 is not null or v_obj2 is not null or v_obj3 is not null or v_obj4 is not null',
'			);',
'',
'		exception when others then v_json := null;',
'	end;',
'',
'	data.pk_commons.sp_apex_log(v_log_app,1,v_log_dsc,null,null,v_json);',
'',
'	if v_json is not null then',
'		update t_corp_udc x set x.valor3 = v_json where x.id_cabecera = ''COMP_PRRSP'' and x.id_tabla = lpad(v_idneg,5,''0'');',
'	end if;',
'end;'))
,p_attribute_02=>'P217_IDNEGOCIACION,P217_MARCA,P217_CLIENTE,P217_LINEANEGOCIO,P217_CANAL'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240815153626Z')
,p_updated_on=>wwv_flow_imp.dz('20250918174850Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(371023925367652448)
,p_event_id=>wwv_flow_imp.id(371023624483652445)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
,p_created_on=>wwv_flow_imp.dz('20240815153626Z')
,p_updated_on=>wwv_flow_imp.dz('20240815153626Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(371024031467652449)
,p_event_id=>wwv_flow_imp.id(371023624483652445)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240815153626Z')
,p_updated_on=>wwv_flow_imp.dz('20240815153626Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(371024180270652450)
,p_name=>'Borrar OCs'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(371023206364652441)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20240815160429Z')
,p_updated_on=>wwv_flow_imp.dz('20240815160429Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(411011810152960501)
,p_event_id=>wwv_flow_imp.id(371024180270652450)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEst\00E1 seguro de eliminar los Objetos de Costo?')
,p_attribute_02=>'Eliminar Objetos de Costo'
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-warning'
,p_created_on=>wwv_flow_imp.dz('20240815160429Z')
,p_updated_on=>wwv_flow_imp.dz('20240815160429Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(411011969456960502)
,p_event_id=>wwv_flow_imp.id(371024180270652450)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
,p_created_on=>wwv_flow_imp.dz('20240815160429Z')
,p_updated_on=>wwv_flow_imp.dz('20240815160429Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(411012072775960503)
,p_event_id=>wwv_flow_imp.id(371024180270652450)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_idneg number;',
'v_log_app varchar2(100);',
'v_log_dsc varchar2(999);',
'begin',
'	v_log_app := ''apex.130.217.BorrarObjetosDeCosto'';',
'	v_idneg	:= :p217_idnegociacion;',
'',
unistr('	v_log_dsc := ''Par\00E1metros: ID Neg.: ''||v_idneg;'),
'	data.pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,null,null,null);',
'',
'	update t_corp_udc x set x.valor3 = null where x.id_cabecera = ''COMP_PRRSP'' and x.id_tabla = lpad(v_idneg,5,''0'');',
'end;'))
,p_attribute_02=>'P217_IDNEGOCIACION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240815160429Z')
,p_updated_on=>wwv_flow_imp.dz('20240815160429Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(411012151015960504)
,p_event_id=>wwv_flow_imp.id(371024180270652450)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
,p_created_on=>wwv_flow_imp.dz('20240815160429Z')
,p_updated_on=>wwv_flow_imp.dz('20240815160429Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(411012232153960505)
,p_event_id=>wwv_flow_imp.id(371024180270652450)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240815160429Z')
,p_updated_on=>wwv_flow_imp.dz('20240815160429Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(157086277660941007)
,p_name=>'Agregar Pagos'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(157086129355941006)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20250829145608Z')
,p_updated_on=>wwv_flow_imp.dz('20260206140601Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(157086506348941010)
,p_event_id=>wwv_flow_imp.id(157086277660941007)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
,p_created_on=>wwv_flow_imp.dz('20250829151501Z')
,p_updated_on=>wwv_flow_imp.dz('20250829151501Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(157086341004941008)
,p_event_id=>wwv_flow_imp.id(157086277660941007)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_pagos 	number;',
'v_log_app	varchar2(100);',
'v_log_dsc	varchar2(999);',
'v_idneg		number;',
'begin',
'	v_log_app	:= ''apex.130.217.AgregarPagos'';',
'	v_idneg		:= :p217_idnegociacion;',
'	v_pagos		:= :p217_cantidad;',
'	v_log_dsc	:= ''p217_idnegociacion: ''||:p217_idnegociacion||'', p217_cantidad: ''||:p217_cantidad;',
'',
'	data.pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,null,null,null);',
'	data.pk_comp_negociacion.sp_extenderpagos(:g_compania,:app_user,v_idneg,v_pagos);',
'end;'))
,p_attribute_02=>'P217_IDNEGOCIACION,P217_CANTIDAD'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250829145608Z')
,p_updated_on=>wwv_flow_imp.dz('20260206140601Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(157086497349941009)
,p_event_id=>wwv_flow_imp.id(157086277660941007)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
,p_created_on=>wwv_flow_imp.dz('20250829151501Z')
,p_updated_on=>wwv_flow_imp.dz('20250829151501Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(257267127393638516)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetUp'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_unidad	varchar2(25);',
'v_idneg		number;',
'v_log_qty	number;',
'v_json		varchar2(1000);',
'begin',
'	v_idneg := to_number(:p217_idnegociacion);',
'',
'	begin',
'		select trim(b.unidadnegocio) into v_unidad',
'		from t_comp_negociacion a inner join t_comp_negociacioncab b on a.id = b.idneg',
'		where a.id = v_idneg and a.recurrente = ''SI'';',
'',
'		exception when others then v_unidad := null; v_idneg := null;',
'	end;',
'',
'	begin',
'		select case when nvl(a.estadopagos,''PENDIENTE'') = ''APROBADO'' then 1 else 0 end, numeropagos',
'		into :p217_habilitapagos, :p217_pagos',
'		from t_comp_negociacion a inner join t_comp_negociacioncab b on a.id = b.idneg',
'		where a.id = v_idneg and a.recurrente = ''SI'';',
'',
'		exception when others then :p217_habilitapagos := 0;',
'	end;',
'',
'	:p217_idnegociacion := v_idneg;',
'	:p217_unidadnegocio	:= v_unidad;',
'',
'	:p217_marca			:= null;',
'	:p217_cliente		:= null;',
'	:p217_lineanegocio	:= null;',
'	:p217_canal			:= null;',
'',
'	select count(1) into v_log_qty',
'	from data.t_corp_udc',
'	where 1 = 1',
'		and id_cabecera = ''COMP_PRRSP'' and id_tabla = lpad(v_idneg,5,''0'') and valor3 is not null;',
'',
'	if v_log_qty > 0 then',
'		select jt.abr1, jt.abr2, jt.abr3, jt.abr4',
'		into :p217_marca,:p217_cliente,:p217_lineanegocio,:p217_canal',
'		from data.t_corp_udc a, json_table(a.valor3,''$[*]'' columns',
'			idneg	number			path ''$.idneg'',',
'			linea	number			path ''$.linea'',',
'			abt1	varchar2(10)	path ''$.abt1'',',
'			abr1	varchar2(10)	path ''$.abr1'',',
'			abt2	varchar2(10)	path ''$.abt2'',',
'			abr2	varchar2(10)	path ''$.abr2'',',
'			abt3	varchar2(10)	path ''$.abt3'',',
'			abr3	varchar2(10)	path ''$.abr3'',',
'			abt4	varchar2(10)	path ''$.abt4'',',
'			abr4	varchar2(10)	path ''$.abr4''',
'		) jt',
'		where 1 = 1',
'			and id_cabecera = ''COMP_PRRSP'' and id_tabla = lpad(v_idneg,5,''0'') and rownum = 1;',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>257267127393638516
,p_created_on=>wwv_flow_imp.dz('20240314145424Z')
,p_updated_on=>wwv_flow_imp.dz('20250829144854Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(257267475093638519)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(257265699905638501)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Responsables - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>257267475093638519
,p_created_on=>wwv_flow_imp.dz('20240314145912Z')
,p_updated_on=>wwv_flow_imp.dz('20240314145912Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
