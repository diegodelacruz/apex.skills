prompt --application/pages/page_00140
begin
--   Manifest
--     PAGE: 00140
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>140
,p_name=>unistr('Negociaci\00F3n - Detalle')
,p_step_title=>unistr('Negociaci\00F3n &P140_ID_NEGOCIACION.')
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(secItems).hide();',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-button.a-IRR-sortWidget-button[data-option="hide"], .a-IRR-button.a-IRR-sortWidget-button[data-option="freeze"]{',
'    display:none;',
'}',
'.a-IG-controls-item--aggregate, .a-IG-controls-item--controlBreak, .a-IG-controls-item--groupBy, .a-IG-reportSummary-item--aggregate, .a-IG-reportSummary-item--controlBreak, .a-IG-reportSummary-item--groupBy, .a-IRR-controls-item--aggregate, .a-IRR-c'
||'ontrols-item--controlBreak, .a-IRR-controls-item--groupBy, .a-IRR-reportSummary-item--aggregate, .a-IRR-reportSummary-item--controlBreak, .a-IRR-reportSummary-item--groupBy {',
'    --a-report-controls-cell-label-icon-background-color: #3b83bd;',
'    --a-report-controls-cell-label-hover-background-color: #e6f0f7;',
'    display: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240119194618Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260409202541Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(45078445008050212)
,p_plug_name=>'Detalles de Negociaciones'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:js-showMaximizeButton:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(295630388916037685)
,p_plug_display_sequence=>40
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'N',
  'rds_mode', 'STANDARD',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44750670754991328)
,p_plug_name=>'Archivos Soporte'
,p_parent_plug_id=>wwv_flow_imp.id(45078445008050212)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(295630388916037685)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUMEROARCHIVO,',
'       FILENAME,',
'       BLOBCONTENT,',
'       MIMETYPE,',
'       RIDE,',
'       FECHA,',
'       NOMBREUSUARIO,',
'       TABLA,',
'       ID_TABLA,',
'       TIPO,',
'       OBSERVACION,',
'       ESTADO,',
'       ''<span class="fa fa-trash"/>'' borra     ',
'  from FILES.VT_APEX_ARCHIVOS',
' where TABLA=''T_COMP_NEGOCIACION'' ',
'  AND ',
'ID_TABLA=:P140_ARCHIVO_IDTABLA',
'  AND',
'TIPO=''ARCHIVO_CABECERA'''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Archivos Adjuntos'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20240122193930Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(44750896946991330)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>44750896946991330
,p_updated_on=>wwv_flow_imp.dz('20240122193930Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44750911054991331)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Numeroarchivo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44751108799991333)
,p_db_column_name=>'BLOBCONTENT'
,p_display_order=>20
,p_column_identifier=>'C'
,p_column_label=>'Archivo'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_format_mask=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment:#FILENAME#:FILES'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44751217637991334)
,p_db_column_name=>'MIMETYPE'
,p_display_order=>30
,p_column_identifier=>'D'
,p_column_label=>'Tipo'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44751465312991336)
,p_db_column_name=>'FECHA'
,p_display_order=>40
,p_column_identifier=>'F'
,p_column_label=>'Fecha'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122193930Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44751564515991337)
,p_db_column_name=>'NOMBREUSUARIO'
,p_display_order=>50
,p_column_identifier=>'G'
,p_column_label=>'Usuario'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44751052335991332)
,p_db_column_name=>'FILENAME'
,p_display_order=>60
,p_column_identifier=>'B'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44751603056991338)
,p_db_column_name=>'TABLA'
,p_display_order=>70
,p_column_identifier=>'H'
,p_column_label=>'Tabla'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44751703779991339)
,p_db_column_name=>'ID_TABLA'
,p_display_order=>80
,p_column_identifier=>'I'
,p_column_label=>'Id Tabla'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44751819918991340)
,p_db_column_name=>'TIPO'
,p_display_order=>90
,p_column_identifier=>'J'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44752061041991342)
,p_db_column_name=>'ESTADO'
,p_display_order=>100
,p_column_identifier=>'L'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44751965257991341)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44751344682991335)
,p_db_column_name=>'RIDE'
,p_display_order=>130
,p_column_identifier=>'E'
,p_column_label=>'Ride'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45203775497008026)
,p_db_column_name=>'BORRA'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>'-'
,p_column_link=>'javascript: $s("P140_ID_NUMEROARCHIVO","");$s("P140_ID_NUMEROARCHIVO",#NUMEROARCHIVO#);'
,p_column_linktext=>'#BORRA#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(45053246957779373)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'450533'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BLOBCONTENT:FECHA:NOMBREUSUARIO:BORRA:'
,p_created_on=>wwv_flow_imp.dz('20240119194618Z')
,p_updated_on=>wwv_flow_imp.dz('20240119194618Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(271084323270227347)
,p_plug_name=>unistr('Detalle de Negociaci\00F3n')
,p_region_name=>'Detalle'
,p_parent_plug_id=>wwv_flow_imp.id(45078445008050212)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295630388916037685)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id',
'	, idcab',
'	, usercrea',
'	, usermodi',
'	, codproducto',
'	, codproductoprv',
'	, desproductoprv',
'	, umproductoprv',
'	, codproveedor',
'	, tiempoentrega',
'	, formapago',
'	, incoterm',
'	, cantdesde',
'	, canthasta',
'	, cantmaxima',
'	, precio',
'	, precioant',
'	, rfletetip',
'	, rfletemto',
'	, estado',
'	, comentario',
'	, estadoflujo ',
'	, ''<span alt="hola" class="fa fa-combo-chart"></span>'' ver',
'	-- , case when imstkt = ''O'' then -1 else 1 end ordenobs',
'from data.t_comp_negociaciondet',
'-- inner join f4101@jdedtadl on codproducto = imitm',
'where idcab = :p140_id_cabecera'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P140_ID_CABECERA'
,p_updated_on=>wwv_flow_imp.dz('20260302151338Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(45077897158050206)
,p_name=>'RFLETETIP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'RFLETETIP'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>210
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20240308211413Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(45077928748050207)
,p_name=>'RFLETEMTO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'RFLETEMTO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>220
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20240308211413Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(45205003745008039)
,p_name=>'VER'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'VER'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_LINK'
,p_heading=>'-'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>260
,p_value_alignment=>'CENTER'
,p_link_target=>'f?p=&APP_ID.:142:&SESSION.::&DEBUG.:142:P142_ID_DETALLE,P142_PAGINA:&ID.,&APP_PAGE_ID.'
,p_link_text=>'&VER.'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P140_ESQUEMA'
,p_display_condition2=>'xPV'
,p_escape_on_http_output=>false
,p_updated_on=>wwv_flow_imp.dz('20260302043348Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(62378315695452806)
,p_name=>'DESPRODUCTOPRV'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESPRODUCTOPRV'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Desc. Producto Proveedor'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>250
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P140_ESQUEMA'
,p_display_condition2=>'PV'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(79930946076477323)
,p_name=>'UMPRODUCTOPRV'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UMPRODUCTOPRV'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'UM. Producto Proveedor'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>5
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P140_ESQUEMA'
,p_display_condition2=>'PV'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(135558811234707428)
,p_name=>'ESTADOFLUJO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ESTADOFLUJO'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Estadoflujo'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>250
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>10
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'CREACION'
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20240308211414Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(138495791969026928)
,p_name=>'CODPRODUCTOPRV'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODPRODUCTOPRV'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>unistr('C\00F3d. Producto Proveedor')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>25
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P140_ESQUEMA'
,p_display_condition2=>'PV'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(251383689970645421)
,p_name=>'CANTMAXIMA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CANTMAXIMA'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('Cant. M\00E1xima')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>180
,p_value_alignment=>'RIGHT'
,p_attribute_01=>'0'
,p_attribute_02=>'99999999'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'0'
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P140_RECURRENTE'
,p_display_condition2=>'SI'
,p_updated_on=>wwv_flow_imp.dz('20240308211413Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(271084518641227349)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Id'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(271084652631227350)
,p_name=>'IDCAB'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IDCAB'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Idcab'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P140_ID_CABECERA'
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(271084760327227351)
,p_name=>'USERCREA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'USERCREA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Usercrea'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>20
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(271084833677227352)
,p_name=>'USERMODI'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'USERMODI'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Usermodi'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>20
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(271084874481227353)
,p_name=>'CODPRODUCTO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODPRODUCTO'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>'Producto'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_attribute_07=>'Productos'
,p_attribute_08=>'600'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d descripcion,r codigo from (',
'	with prd as (',
'		select codigoproducto||'' - ''||nombreproducto||'' ''||codigoalterno||'' - ['' ||unidadcompra|| '']'' d,codigocorto r, ''PD'' tipo',
'		from vt_jde_productos',
'		where 1 = 1',
'			and codestado <> ''O''',
'			and codigoproducto not like ''S___'' ',
'		group by codigoproducto||'' - ''||nombreproducto||'' ''||codigoalterno||'' - [''||unidadcompra||'']'',codigocorto,nombreproducto',
'		order by nombreproducto',
'	), prv as (',
'		select codigoproveedor||'' - ''||descripcion d, codigoproveedor r,''PV''',
'		from vt_jde_maestroproveedor',
'		group by codigoproveedor||'' - ''||descripcion,codigoproveedor,descripcion',
'		order by descripcion',
') select d,r from prd union all select d,r from prv)'))
,p_lov_display_extra=>false
,p_lov_display_null=>false
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>false
,p_include_in_export=>true
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P140_ESQUEMA'
,p_display_condition2=>'PV'
,p_updated_on=>wwv_flow_imp.dz('20250204161951Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(271084994535227354)
,p_name=>'CODPROVEEDOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODPROVEEDOR'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>'Proveedor'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_attribute_07=>'Proveedores'
,p_attribute_08=>'600'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select D descripcion,R codigo from (',
'with prd as (',
'SELECT  CODIGOPRODUCTO  || '' - '' ||  NOMBREPRODUCTO  d  ,CODIGOCORTO r,  ''PV'' tipo FROM vt_jde_productos WHERE :P140_ESQUEMA=''PV'' AND CODESTADO<>''O'' and tipoinventario=''IN10'' GROUP BY CODIGOPRODUCTO  || '' - '' ||  NOMBREPRODUCTO ,CODIGOCORTO ,NOMBREPR'
||'ODUCTO  order by NOMBREPRODUCTO ',
'),',
'prv as (',
'SELECT  CODIGOPROVEEDOR || '' - '' ||  DESCRIPCION d, CODIGOPROVEEDOR r,  ''PD'' tipo FROM VT_JDE_MAESTROPROVEEDOR WHERE :P140_ESQUEMA=''PD'' GROUP BY CODIGOPROVEEDOR || '' - '' ||  DESCRIPCION,CODIGOPROVEEDOR,DESCRIPCION  order by DESCRIPCION ',
')',
' select d,r from prd union all',
' select d,r from prv',
' )'))
,p_lov_display_extra=>false
,p_lov_display_null=>false
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>false
,p_include_in_export=>true
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P140_ESQUEMA'
,p_display_condition2=>'PD'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(271085102419227355)
,p_name=>'TIEMPOENTREGA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIEMPOENTREGA'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Tiempo de Entrega'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>130
,p_value_alignment=>'RIGHT'
,p_attribute_01=>'0'
,p_attribute_02=>'365'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_item_width=>5
,p_item_placeholder=>'En dias'
,p_is_required=>false
,p_max_length=>10
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(271085223221227356)
,p_name=>'FORMAPAGO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FORMAPAGO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Forma Pago'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>140
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(134250431110099274)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_lov_null_text=>'Seleccione'
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(271085353440227357)
,p_name=>'INCOTERM'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'INCOTERM'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Incoterm'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>150
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(74803172029355163)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_lov_null_text=>'Seleccione'
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(271085458514227358)
,p_name=>'CANTDESDE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CANTDESDE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Cant. Desde'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>160
,p_value_alignment=>'RIGHT'
,p_attribute_01=>'1'
,p_attribute_02=>'99999999'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'1'
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P140_TIPO_NEGOCIACION'
,p_display_condition2=>'ES'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(271085510892227359)
,p_name=>'CANTHASTA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CANTHASTA'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Cant. Hasta'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>170
,p_value_alignment=>'RIGHT'
,p_attribute_01=>'1'
,p_attribute_02=>'99999999'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'1'
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P140_TIPO_NEGOCIACION'
,p_display_condition2=>'ES'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(271085623926227360)
,p_name=>'PRECIO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PRECIO'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Precio'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>190
,p_value_alignment=>'RIGHT'
,p_attribute_01=>'0'
,p_attribute_02=>'99999999.99'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_format_mask=>'999G999G999G999G990D0000'
,p_is_required=>false
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_readonly_condition=>'P140_TIPO_PRECIO'
,p_readonly_condition2=>'FM'
,p_readonly_for_each_row=>false
,p_updated_on=>wwv_flow_imp.dz('20240308211414Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(271085761557227361)
,p_name=>'PRECIOANT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PRECIOANT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>200
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20240308211414Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(271085835960227362)
,p_name=>'ESTADO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ESTADO'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Estado'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>230
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>10
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'CREACION'
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20240308211414Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(271085968261227363)
,p_name=>'COMENTARIO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'COMENTARIO'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Comentario'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>240
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>500
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20240308211414Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(271086472937227369)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_enable_hide=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(271086631816227370)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
,p_enable_hide=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(271084461749227348)
,p_internal_uid=>271084461749227348
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>false
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SET'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU:SAVE'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>false
,p_download_formats=>null
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (config) {',
'    return cargarToolbar(config);',
'}'))
,p_updated_on=>wwv_flow_imp.dz('20260302151338Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(271117493078645189)
,p_interactive_grid_id=>wwv_flow_imp.id(271084461749227348)
,p_static_id=>'378708'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_rows_per_page=>25
,p_show_row_number=>false
,p_settings_area_expanded=>true
,p_updated_on=>wwv_flow_imp.dz('20260302151338Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(271117604697645189)
,p_report_id=>wwv_flow_imp.id(271117493078645189)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(9620281424017)
,p_view_id=>wwv_flow_imp.id(271117604697645189)
,p_display_seq=>23
,p_column_id=>wwv_flow_imp.id(135558811234707428)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(45109482665855079)
,p_view_id=>wwv_flow_imp.id(271117604697645189)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(45077897158050206)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>111.997
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(45110208459855082)
,p_view_id=>wwv_flow_imp.id(271117604697645189)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(45077928748050207)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>108.997
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(46785046306504656)
,p_view_id=>wwv_flow_imp.id(271117604697645189)
,p_display_seq=>22
,p_column_id=>wwv_flow_imp.id(45205003745008039)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(62396253600004099)
,p_view_id=>wwv_flow_imp.id(271117604697645189)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(62378315695452806)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>316
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(81179755114294503)
,p_view_id=>wwv_flow_imp.id(271117604697645189)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(79930946076477323)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>120
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(138512992314890891)
,p_view_id=>wwv_flow_imp.id(271117604697645189)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(138495791969026928)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>187
,p_sort_order=>1
,p_sort_direction=>'DESC'
,p_sort_nulls=>'FIRST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(251598502716183029)
,p_view_id=>wwv_flow_imp.id(271117604697645189)
,p_display_seq=>24
,p_column_id=>wwv_flow_imp.id(251383689970645421)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(271118141926645191)
,p_view_id=>wwv_flow_imp.id(271117604697645189)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(271084518641227349)
,p_is_visible=>false
,p_is_frozen=>true
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(271118643949645192)
,p_view_id=>wwv_flow_imp.id(271117604697645189)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(271084652631227350)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(271119097127645192)
,p_view_id=>wwv_flow_imp.id(271117604697645189)
,p_display_seq=>20
,p_column_id=>wwv_flow_imp.id(271084760327227351)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(271119600246645194)
,p_view_id=>wwv_flow_imp.id(271117604697645189)
,p_display_seq=>19
,p_column_id=>wwv_flow_imp.id(271084833677227352)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(271120117971645195)
,p_view_id=>wwv_flow_imp.id(271117604697645189)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(271084874481227353)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>523
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(271120666618645195)
,p_view_id=>wwv_flow_imp.id(271117604697645189)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(271084994535227354)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>330
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(271121134705645197)
,p_view_id=>wwv_flow_imp.id(271117604697645189)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(271085102419227355)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>122
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(271121669804645198)
,p_view_id=>wwv_flow_imp.id(271117604697645189)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(271085223221227356)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>346
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(271122165561645198)
,p_view_id=>wwv_flow_imp.id(271117604697645189)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(271085353440227357)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>261
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(271122663526645200)
,p_view_id=>wwv_flow_imp.id(271117604697645189)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(271085458514227358)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>90
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(271123102050645201)
,p_view_id=>wwv_flow_imp.id(271117604697645189)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(271085510892227359)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>84
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(271123651641645201)
,p_view_id=>wwv_flow_imp.id(271117604697645189)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(271085623926227360)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>108
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(271124090296645203)
,p_view_id=>wwv_flow_imp.id(271117604697645189)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(271085761557227361)
,p_is_visible=>false
,p_is_frozen=>false
,p_width=>127
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(271124593234645205)
,p_view_id=>wwv_flow_imp.id(271117604697645189)
,p_display_seq=>21
,p_column_id=>wwv_flow_imp.id(271085835960227362)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(271125132451645205)
,p_view_id=>wwv_flow_imp.id(271117604697645189)
,p_display_seq=>18
,p_column_id=>wwv_flow_imp.id(271085968261227363)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>250
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(271130422122673311)
,p_view_id=>wwv_flow_imp.id(271117604697645189)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(271086472937227369)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(131995224228393704)
,p_plug_name=>'Barra de acciones'
,p_region_name=>'rptAcciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>50
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(271084113656227345)
,p_plug_name=>'Negociacion No. &P140_ID_NEGOCIACION.'
,p_region_template_options=>'#DEFAULT#:t-Form--noPadding:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(231097788777534313)
,p_plug_name=>'Recurrente'
,p_parent_plug_id=>wwv_flow_imp.id(271084113656227345)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>80
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P140_RECURRENTE'
,p_plug_display_when_cond2=>'SI'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20240220182114Z')
,p_updated_on=>wwv_flow_imp.dz('20240220182526Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(271084255311227346)
,p_plug_name=>'Cabecera'
,p_region_template_options=>'#DEFAULT#:t-Form--noPadding:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(271086007315227364)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--noPadding:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>60
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(135606140392196042)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(131995224228393704)
,p_button_name=>'Atras'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Atras'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:139:&SESSION.::&DEBUG.:RP,139::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(59253116116950216)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(131995224228393704)
,p_button_name=>'Carga_Detalles'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Carga Automatica'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_confirm_message=>unistr('\00BFEsta seguro de cargar los detalles para la negociaci\00F3n?')
,p_confirm_style=>'warning'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'',
'from t_comp_negociaciondet where idcab =:P140_ID_CABECERA;'))
,p_button_condition_type=>'NOT_EXISTS'
,p_icon_css_classes=>'fa-upload-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(143510711310026746)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(131995224228393704)
,p_button_name=>'Evolucion'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>unistr('Evoluci\00F3n')
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:142:&SESSION.::&DEBUG.:RR,142:P142_ID_NEG,P142_PAGINA,P142_ID_DETALLE:&P140_ID_NEGOCIACION.,&APP_ID_PAGE.,0'
,p_icon_css_classes=>'fa-line-chart'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(48006688149361935)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(131995224228393704)
,p_button_name=>'Bajar_template'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Descargar plantilla'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'#APP_FILES#Formatos/Detalle_Negociaciones.xlsx'
,p_button_execute_validations=>'N'
,p_confirm_message=>'Esta seguro de desacargar el archivo?'
,p_confirm_style=>'warning'
,p_icon_css_classes=>'fa-download'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(138399806747690541)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(131995224228393704)
,p_button_name=>'Subir_Archivo'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Carga Masiva'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:300:&SESSION.::&DEBUG.:RP,300::'
,p_confirm_message=>'Esta seguro que reviso el archivo antes de subirlo'
,p_confirm_style=>'warning'
,p_icon_css_classes=>'fa-upload'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43434417649543023)
,p_name=>'P140_ID_DETALLE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(271086007315227364)
,p_prompt=>'Id Detalle'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44750707234991329)
,p_name=>'P140_ANEXOS_ARCHIVOS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(44750670754991328)
,p_prompt=>'Seleccione Archivo:'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44752149260991343)
,p_name=>'P140_ARCHIVO_IDTABLA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(271086007315227364)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44752649293991348)
,p_name=>'P140_UNIDADNEGOCIO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(271084255311227346)
,p_prompt=>'Unidad de Negocio:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_NEG_UNIDADNEGOCIO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select tipo1||'' - ''||nombre descripcion,trim(tipo1) codigo',
'from t_admi_ruta a',
'where codigomodulo = ''COMP'' and tipo2 = ''CN'' order by nombre'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20240416150039Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44752755994991349)
,p_name=>'P140_MONEDA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(271084255311227346)
,p_prompt=>'Moneda:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_NEG_MONEDA'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRKY||'' - ''||DRDL01 DESCRIPCION, DRKY VALOR',
'from vt_jde_udcjde',
'where drsy = ''74R''and drrt = ''CR'' and drky in (''EUR'',''USD'',''BOB'',''DOP'',''PEN'',''QTZ'')'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20250212215622Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44752839122991350)
,p_name=>'P140_TIPOTOLERANCIA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(271084255311227346)
,p_prompt=>'Tipo Tolerancia:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_NEG_TIPOTOLERANCIA'
,p_lov=>'.'||wwv_flow_imp.id(50696667460910822)||'.'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20240220183049Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45077382778050201)
,p_name=>'P140_TOLERANCIADSD'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(271086007315227364)
,p_prompt=>'Tolerancia Desde'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45077425556050202)
,p_name=>'P140_TOLERANCIAHST'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(271086007315227364)
,p_prompt=>'Tolerancia Hasta'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45077528170050203)
,p_name=>'P140_TOLERANCIAAMP'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(271086007315227364)
,p_prompt=>'Tolerancia Amplitud:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_NEG_AMPTOLERANCIA'
,p_lov=>'.'||wwv_flow_imp.id(44763956876051445)||'.'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45077690925050204)
,p_name=>'P140_TOLERANCIARNG'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(271084255311227346)
,p_prompt=>'Rango Tolerancia:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P140_TOLERANCIARNG'
,p_display_when2=>'Desde: % Hasta: % '
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20240220183049Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45203883913008027)
,p_name=>'P140_ID_NUMEROARCHIVO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(271086007315227364)
,p_prompt=>'Id Numeroarchivo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(48006329720361932)
,p_name=>'P140_VALIDAR'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(271086007315227364)
,p_prompt=>'Validar'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135606811103196044)
,p_name=>'P140_ESCALA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(271084255311227346)
,p_prompt=>'Escala:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_NEG_ESCALA'
,p_lov=>'SELECT VALOR D, ID_TABLA R FROM "DATA"."T_CORP_UDC" WHERE ACTIVO = 1 AND ID_CABECERA = ''COMP_NGESC'';'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>'P140_TIPO_NEGOCIACION'
,p_display_when2=>'ES'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135607262945196045)
,p_name=>'P140_ACUMULA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(271084255311227346)
,p_prompt=>'Acumula:'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_display_when=>'P140_TIPO_NEGOCIACION'
,p_display_when2=>'ES'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'SI'
,p_attribute_03=>unistr('S\00CD')
,p_attribute_04=>'NO'
,p_attribute_05=>'NO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135607667693196045)
,p_name=>'P140_TIPO_PRECIO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(271084255311227346)
,p_prompt=>'Tipo Precio:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_NEG_TIPOPRECIO'
,p_lov=>'SELECT VALOR D, ID_TABLA R FROM "DATA"."T_CORP_UDC" WHERE ACTIVO = 1 AND ID_CABECERA = ''COMP_NGTPR'';'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135608021562196047)
,p_name=>'P140_FORMULA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(271084255311227346)
,p_prompt=>'Formula:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when=>'P140_TIPO_PRECIO'
,p_display_when2=>'FM'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20240220183049Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135608431698196047)
,p_name=>'P140_JUSTIFICACION'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(271084255311227346)
,p_prompt=>unistr('Justificaci\00F3n:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when=>'P140_JUSTIFICACION'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20240220183049Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135609179324196047)
,p_name=>'P140_TIPO_NEGOCIACION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(271084113656227345)
,p_prompt=>unistr('Tipo Negociaci\00F3n:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_NEG_TIPO'
,p_lov=>'SELECT VALOR D, ID_TABLA R FROM "DATA"."T_CORP_UDC" WHERE ACTIVO = 1 AND ID_CABECERA = ''COMP_NGTIP'';'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135609562560196047)
,p_name=>'P140_ESQUEMA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(271084113656227345)
,p_prompt=>'Tipo Esquema:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_NEG_ESQUEMA'
,p_lov=>'SELECT VALOR D, ID_TABLA R FROM "DATA"."T_CORP_UDC" WHERE ACTIVO = 1 AND ID_CABECERA = ''COMP_NGESQ'';'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135609900926196047)
,p_name=>'P140_COD_ESQUEMA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(271084113656227345)
,p_prompt=>'Esquema:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_NEG_CODIGOESQ'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select D descripcion,R codigo from (',
'with prd as (',
'SELECT   CODIGOPRODUCTO || '' - '' ||  NOMBREPRODUCTO || '' ''|| CODIGOALTERNO  || '' - ['' ||  UNIDADCOMPRA || '']'' d  ,CODIGOCORTO r,  ''PD'' tipo FROM vt_jde_productos WHERE  CODESTADO<>''O'' GROUP BY  CODIGOPRODUCTO || '' - '' ||  NOMBREPRODUCTO || '' ''|| CODI'
||'GOALTERNO     || '' - ['' ||  UNIDADCOMPRA || '']''  ,CODIGOCORTO ,NOMBREPRODUCTO order by NOMBREPRODUCTO ',
'),',
'prv as (',
'SELECT   CODIGOPROVEEDOR || '' - '' ||  DESCRIPCION d, CODIGOPROVEEDOR r,  ''PV'' FROM  VT_JDE_MAESTROPROVEEDOR GROUP BY CODIGOPROVEEDOR || '' - '' ||  DESCRIPCION , CODIGOPROVEEDOR , DESCRIPCION ORDER BY DESCRIPCION',
')',
' select d,r from prd union all',
' select d,r from prv',
' )'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135610387051196047)
,p_name=>'P140_RECURRENTE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(231097788777534313)
,p_prompt=>'Pago Recurrente:'
,p_display_as=>'NATIVE_YES_NO'
,p_display_when_type=>'NEVER'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'SI'
,p_attribute_03=>'SI'
,p_attribute_04=>'NO'
,p_attribute_05=>'NO'
,p_updated_on=>wwv_flow_imp.dz('20240220182450Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135610778333196047)
,p_name=>'P140_PERIODICIDAD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(231097788777534313)
,p_prompt=>'Periodicidad:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20240220182450Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135611106538196048)
,p_name=>'P140_VIGENCIA_DESDE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(271084113656227345)
,p_prompt=>'Vigencia Desde:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135611535968196048)
,p_name=>'P140_VIGENCIA_HASTA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(271084113656227345)
,p_prompt=>'Vigencia Hasta:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135623177663196059)
,p_name=>'P140_ID_CABECERA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(271086007315227364)
,p_prompt=>'Id Cabecera'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135623565201196059)
,p_name=>'P140_ID_NEGOCIACION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(271086007315227364)
,p_prompt=>'Id Negociacion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135623960251196059)
,p_name=>'P140_USUARIO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(271086007315227364)
,p_prompt=>'Usuario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140738075761225129)
,p_name=>'P140_VALIDADETALLE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(271086007315227364)
,p_prompt=>'Validadetalle'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(231097879850534314)
,p_name=>'P140_FRECUENCIA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(231097788777534313)
,p_prompt=>'Frecuencia:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_NEG_FRECUENCIA'
,p_lov=>'.'||wwv_flow_imp.id(230185465636915585)||'.'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240220182114Z')
,p_updated_on=>wwv_flow_imp.dz('20240531211655Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(231098001467534316)
,p_name=>'P140_NUMEROPAGOS'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(231097788777534313)
,p_prompt=>unistr('N\00FAm. Pagos:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240220182114Z')
,p_updated_on=>wwv_flow_imp.dz('20240314164914Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(231098148403534317)
,p_name=>'P140_TIPOPAGO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(231097788777534313)
,p_prompt=>'Tipo Pago:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_NEG_TIPOPAGO'
,p_lov=>'.'||wwv_flow_imp.id(231130202278619882)||'.'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240220182114Z')
,p_updated_on=>wwv_flow_imp.dz('20240314164914Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(231098296168534318)
,p_name=>'P140_FECHAPRIMERPAGO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(231097788777534313)
,p_prompt=>'Primer Pago:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240220182114Z')
,p_updated_on=>wwv_flow_imp.dz('20240314164914Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(257268284660638527)
,p_name=>'P140_TIPOMONTO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(231097788777534313)
,p_prompt=>'Tipo Monto:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_NEG_TIPOMONTO'
,p_lov=>'.'||wwv_flow_imp.id(240341499876606572)||'.'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240314164914Z')
,p_updated_on=>wwv_flow_imp.dz('20240314164914Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(257268380333638528)
,p_name=>'P140_TIPORECEPCION'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(231097788777534313)
,p_prompt=>unistr('Tipo Recepci\00F3n:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_NEG_TIPORECEPCION'
,p_lov=>'.'||wwv_flow_imp.id(257467648715249911)||'.'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240314164914Z')
,p_updated_on=>wwv_flow_imp.dz('20240314164914Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(135619737606196058)
,p_tabular_form_region_id=>wwv_flow_imp.id(271084323270227347)
,p_validation_name=>'No Vacio Producto'
,p_validation_sequence=>10
,p_validation=>'CODPRODUCTO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#COLUMN_HEADER# debe tener un valor'
,p_validation_condition=>'P140_ESQUEMA'
,p_validation_condition2=>'PV'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_exec_cond_for_each_row=>'Y'
,p_associated_column=>'CODPRODUCTO'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(135620133936196058)
,p_tabular_form_region_id=>wwv_flow_imp.id(271084323270227347)
,p_validation_name=>'No Vacio Proveedor'
,p_validation_sequence=>50
,p_validation=>'CODPROVEEDOR'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#COLUMN_HEADER# debe tener un valor'
,p_validation_condition=>'P140_ESQUEMA'
,p_validation_condition2=>'PD'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_exec_cond_for_each_row=>'Y'
,p_associated_column=>'CODPROVEEDOR'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(138594430764971821)
,p_tabular_form_region_id=>wwv_flow_imp.id(271084323270227347)
,p_validation_name=>'Es numero'
,p_validation_sequence=>60
,p_validation=>'TIEMPOENTREGA'
,p_validation_type=>'ITEM_IS_NUMERIC'
,p_error_message=>'#COLUMN_HEADER# debe ser un numero'
,p_associated_column=>'TIEMPOENTREGA'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
,p_updated_on=>wwv_flow_imp.dz('20240131193402Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(135620541059196058)
,p_tabular_form_region_id=>wwv_flow_imp.id(271084323270227347)
,p_validation_name=>'No Vacio Tiempo Entrega'
,p_validation_sequence=>70
,p_validation=>'TIEMPOENTREGA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#COLUMN_HEADER# debe tener un valor'
,p_associated_column=>'TIEMPOENTREGA'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
,p_updated_on=>wwv_flow_imp.dz('20240131193443Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(135620983328196058)
,p_tabular_form_region_id=>wwv_flow_imp.id(271084323270227347)
,p_validation_name=>'No Vacio FormaPago'
,p_validation_sequence=>80
,p_validation=>'FORMAPAGO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#COLUMN_HEADER# debe tener un valor'
,p_associated_column=>'FORMAPAGO'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
,p_updated_on=>wwv_flow_imp.dz('20240131193512Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(135621342779196058)
,p_tabular_form_region_id=>wwv_flow_imp.id(271084323270227347)
,p_validation_name=>'No Vacio Incoterm'
,p_validation_sequence=>90
,p_validation=>'INCOTERM'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#COLUMN_HEADER# debe tener un valor'
,p_associated_column=>'INCOTERM'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
,p_updated_on=>wwv_flow_imp.dz('20240131193553Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(135621792274196058)
,p_tabular_form_region_id=>wwv_flow_imp.id(271084323270227347)
,p_validation_name=>'No Vacio Precio Act'
,p_validation_sequence=>100
,p_validation=>'PRECIO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#COLUMN_HEADER# debe tener un valor'
,p_validation_condition=>'P140_TIPO_PRECIO'
,p_validation_condition2=>'FM'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_exec_cond_for_each_row=>'Y'
,p_associated_column=>'PRECIO'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
,p_updated_on=>wwv_flow_imp.dz('20240328180439Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(135622184824196058)
,p_tabular_form_region_id=>wwv_flow_imp.id(271084323270227347)
,p_validation_name=>'No Vacio Valor Ant'
,p_validation_sequence=>110
,p_validation=>'PRECIOANT'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#COLUMN_HEADER# debe tener un valor'
,p_validation_condition_type=>'NEVER'
,p_associated_column=>'PRECIOANT'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(138595180193971828)
,p_tabular_form_region_id=>wwv_flow_imp.id(271084323270227347)
,p_validation_name=>'Valida Rango Cantidades'
,p_validation_sequence=>120
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_contador number;',
'BEGIN',
'	select PK_COMP_NEGOCIACION.F_NEG_VALIDAVOLUMEN(',
'	P_NEG_ID=>:p140_id_negociacion,',
'	P_CAB_ID=>:IDCAB,',
'	P_DET_ID=>:ID,',
'	P_CANTDESDE=>:CANTDESDE,',
'	P_CANTHASTA=>:CANTHASTA,',
'	P_codproducto=>:codproducto,',
'	P_codproveedor=>:codproveedor,',
'	P_FORMAPAGO=>:FORMAPAGO,',
'	P_INCOTERM=>:INCOTERM,',
'	P_TIEMPOENTREGA=>:TIEMPOENTREGA',
'	) into V_CONTADOR from dual;',
'',
'	if (v_contador >0) then',
'		RETURN true;',
'	else',
'		RETURN false;',
'	END IF;',
'',
'-- dbms_output.put_line('' :codproducto:'' ||  :codproducto);',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'Hay solapamiento de Cantidades'
,p_always_execute=>'Y'
,p_validation_condition_type=>'NEVER'
,p_associated_column=>'CANTHASTA'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
,p_updated_on=>wwv_flow_imp.dz('20240131195812Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(140638867835536210)
,p_tabular_form_region_id=>wwv_flow_imp.id(271084323270227347)
,p_validation_name=>'No Vacio Cantidad Desde'
,p_validation_sequence=>130
,p_validation=>'CANTDESDE'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>'#COLUMN_HEADER# debe tener un valor mayor a cero'
,p_validation_condition=>'P140_TIPO_NEGOCIACION'
,p_validation_condition2=>'ES'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_exec_cond_for_each_row=>'Y'
,p_associated_column=>'CANTDESDE'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(140638929910536211)
,p_tabular_form_region_id=>wwv_flow_imp.id(271084323270227347)
,p_validation_name=>'No Vacio Cantidad Hasta'
,p_validation_sequence=>140
,p_validation=>'CANTHASTA'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>'#COLUMN_HEADER# debe tener un valor mayor a cero'
,p_validation_condition=>'P140_TIPO_NEGOCIACION'
,p_validation_condition2=>'ES'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_exec_cond_for_each_row=>'Y'
,p_associated_column=>'CANTHASTA'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(138496844913026939)
,p_name=>'Subir Archivo'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(138399806747690541)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_updated_on=>wwv_flow_imp.dz('20260302172158Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48006793001361936)
,p_event_id=>wwv_flow_imp.id(138496844913026939)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mostrarBarra();',
'$s("P140_VALIDAR","");'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(138497041307026941)
,p_event_id=>wwv_flow_imp.id(138496844913026939)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Carga Masiva Archivo plantilla'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_valida number;',
'v_texto	varchar2(100);',
'v_var	number;',
'v_idneg	number;',
'begin',
'	:p140_validar := '''';',
'	data.pk_comp_negociacion.sp_negociacion_subir_excel(:p140_esquema,:p140_id_cabecera,:p140_usuario,:p140_tipo_negociacion,:p140_validar);',
'',
'	if trim(:p140_validar) is null then',
'		select idneg into v_idneg from data.t_comp_negociacioncab where id = :p140_id_cabecera and rownum = 1;',
'',
'		begin',
'			select round(avg(variacion_p1),2) into v_var from data.vt_comp_negociacionpas where neg_id_act = v_idneg;',
'',
'			if v_var is not null then',
unistr('				v_texto := ''Variaci\00F3n del ''||v_var||''% por negociaci\00F3n con el proveedor.'';'),
'			end if;',
'',
'			exception when others then v_texto := null;',
'		end;',
'',
'		update data.t_comp_negociacion t',
'			set t.observacion = case',
'				when not regexp_like(',
unistr('					translate(upper(t.observacion), ''\00C1\00C9\00CD\00D3\00DA\00C0\00C8\00CC\00D2\00D9\00C4\00CB\00CF\00D6\00DC\00C2\00CA\00CE\00D4\00DB\00C3\00D5'', ''AEIOUAEIOUAEIOUAEIOUAO''),''VARIACION'''),
'				) then case',
'						when t.observacion is null then v_texto',
'						when substr(trim(t.observacion), -1) != ''.'' then trim(t.observacion) || ''. '' || v_texto',
'						else trim(t.observacion) || '' '' || v_texto',
'					end',
'						else t.observacion',
'					end',
'		where 1 = 1',
'			and v_texto is not null',
'			and id = v_idneg;		',
'	end if;',
'end;'))
,p_attribute_02=>'P140_ESQUEMA,P140_ID_CABECERA,P140_USUARIO'
,p_attribute_03=>'P140_VALIDAR'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260302172158Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(48006598436361934)
,p_event_id=>wwv_flow_imp.id(138496844913026939)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ocultarBarra();',
'setTimeout('''', 5000);',
'let v_mensaje =($v("P140_VALIDAR"));',
'let v_tipo="error";',
'if (v_mensaje==""){',
'    v_mensaje="Datos Importados con exito";',
'    v_tipo="exito";',
'    $s("P140_VALIDAR","");',
'}',
'mensaje(v_tipo,v_mensaje);',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(138497134865026942)
,p_event_id=>wwv_flow_imp.id(138496844913026939)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P140_VALIDAR'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(44752353403991345)
,p_name=>'Cargar Archivo'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P140_ANEXOS_ARCHIVOS'
,p_condition_element=>'P140_ANEXOS_ARCHIVOS'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44752433787991346)
,p_event_id=>wwv_flow_imp.id(44752353403991345)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44752593538991347)
,p_event_id=>wwv_flow_imp.id(44752353403991345)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(45203983010008028)
,p_name=>'Borrar Archivo'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P140_ID_NUMEROARCHIVO'
,p_condition_element=>'P140_ID_NUMEROARCHIVO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45204497111008033)
,p_event_id=>wwv_flow_imp.id(45203983010008028)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEsta seguro de eliminar el archivo?')
,p_attribute_03=>'warning'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45204254002008031)
,p_event_id=>wwv_flow_imp.id(45203983010008028)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'        delete from files.T_APEX_ARCHIVOS where numeroarchivo=:P140_ID_NUMEROARCHIVO;',
':P140_ID_NUMEROARCHIVO:=null;'))
,p_attribute_02=>'P140_ID_NUMEROARCHIVO'
,p_attribute_03=>'P140_ID_NUMEROARCHIVO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45204049559008029)
,p_event_id=>wwv_flow_imp.id(45203983010008028)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(44750670754991328)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(59253379677950218)
,p_name=>'CargaDetalles'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(59253116116950216)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59253576118950220)
,p_event_id=>wwv_flow_imp.id(59253379677950218)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra()'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59253410336950219)
,p_event_id=>wwv_flow_imp.id(59253379677950218)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    PK_COMP_NEGOCIACION.sp_negociacion_cargadetalle(:p140_id_cabecera,:p140_esquema,:P140_COD_ESQUEMA,:app_user);',
'end;',
'',
''))
,p_attribute_02=>'P140_ID_CABECERA,P140_ESQUEMA,P140_COD_ESQUEMA,APP_USER'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59253836320950223)
,p_event_id=>wwv_flow_imp.id(59253379677950218)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(45078445008050212)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59253757203950222)
,p_event_id=>wwv_flow_imp.id(59253379677950218)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra()'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(62380199838452824)
,p_name=>'ActualizaDetalle'
,p_event_sequence=>70
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(271084323270227347)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridsave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(62380324231452826)
,p_event_id=>wwv_flow_imp.id(62380199838452824)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(135622424032196058)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(271084323270227347)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Detalle- Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_process_error_message=>'Error al almacenar datos'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Datos almacenados correctamente'
,p_internal_uid=>135622424032196058
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(44752226276991344)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar Archivo Soporte'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'V_NUMEROARCHIVO NUMBER;',
'BEGIN',
'    IF(:P140_ANEXOS_ARCHIVOS IS NOT NULL) THEN',
'        PK_APEX_ARCHIVOS.SP_CREARARCHIVO(:P140_ANEXOS_ARCHIVOS,''T_COMP_NEGOCIACION'',:P140_ARCHIVO_IDTABLA,''ARCHIVO_CABECERA'','''',:APP_USER, V_NUMEROARCHIVO);',
'    END IF;',
' ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>44752226276991344
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(59253921741950224)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga_Automatica_Detalles'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    PK_COMP_NEGOCIACION.sp_negociacion_cargadetalle(:p140_id_cabecera,:p140_esquema,:P140_COD_ESQUEMA,:app_user);',
'end;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(59253116116950216)
,p_internal_uid=>59253921741950224
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(135624987263196081)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Setup Page'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_contador	number;',
'v_idneg		number;',
'v_idcab		number;',
'begin',
'	v_idneg					:= :p140_id_negociacion;',
'	v_idcab					:= :p140_id_cabecera;',
'	v_contador				:= 0;',
'',
'	:p140_usuario			:= :app_user;',
'	:p140_archivo_idtabla	:= ''N''||lpad(v_idneg,5,''0'')||''C''||lpad(:p140_id_cabecera,4,''0'');',
'',
'	select tipo,esquema,codesquema,recurrente,periodicidad,vigenciadesde,vigenciahasta',
'		, frecuencia,numeropagos,tipopago,fechaprimerpago,tipomonto,tiporecepcion',
'	into :p140_tipo_negociacion,:p140_esquema,:p140_cod_esquema,:p140_recurrente,:p140_periodicidad,:p140_vigencia_desde,:p140_vigencia_hasta',
'		, :p140_frecuencia,:p140_numeropagos,:p140_tipopago,:p140_fechaprimerpago,:p140_tipomonto,:p140_tiporecepcion',
'	from t_comp_negociacion ',
'	where id = v_idneg;',
'',
'	select escala,acumula,tipoprecio,formula,justificacion,unidadnegocio,moneda,toleranciatip',
'		, toleranciadsd,toleranciahst,''Desde: ''||toleranciadsd || ''% Hasta: '' || toleranciahst||''% '' ,toleranciaamp',
'	into :p140_escala,:p140_acumula,:p140_tipo_precio,:p140_formula,:p140_justificacion,:p140_unidadnegocio,:p140_moneda,:p140_tipotolerancia',
'		, :p140_toleranciadsd,:p140_toleranciahst,:p140_toleranciarng,:p140_toleranciaamp',
'	from t_comp_negociacioncab',
'	where id = :p140_id_cabecera;',
'',
'	if :p140_tipo_precio = ''FM'' then',
'		select formula into :p140_formula from t_comp_negociacionform where id = to_number(:p140_formula);',
'	end if;',
'',
'	begin',
'		select count(1) into v_contador from t_comp_negociaciondet where id is null;',
'		if v_contador > 0 then',
'			delete from t_comp_negociaciondet where id is null;',
'		end if;',
'',
'		select count(1) into v_contador from t_comp_negociaciondet where codproducto is null and codproveedor is null;',
'',
'		if v_contador > 0 then',
'			delete from t_comp_negociaciondet where codproducto is null and codproveedor is null;',
'		end if;',
'	end;',
'',
'	:p140_id_numeroarchivo := null;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>135624987263196081
,p_updated_on=>wwv_flow_imp.dz('20240314164914Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
