prompt --application/pages/page_00102
begin
--   Manifest
--     PAGE: 00102
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>102
,p_name=>'Actividades Comerciales'
,p_page_mode=>'MODAL'
,p_step_title=>'Actividades Comerciales'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20230708132652Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240925173958Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(5874038769509806)
,p_name=>'Detalle'
,p_template=>wwv_flow_imp.id(296120613521169165)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION FROM VT_JDE_ORDENES_ACT_COM',
'WHERE DOCUMENTO=:P102_NUMERO AND DOCUMENTIPO =:P102_TIPO AND LINEA=:P102_LINEA;'))
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'No contiene actividades comerciales'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(6107041915249074)
,p_query_column_id=>1
,p_column_alias=>'DESCRIPCION'
,p_column_display_sequence=>1
,p_column_heading=>'Descripcion'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5874183315509807)
,p_plug_name=>'Informacion'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6105449294249058)
,p_name=>'P102_NUMERO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(5874183315509807)
,p_prompt=>'Numero'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6105627978249059)
,p_name=>'P102_TIPO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(5874183315509807)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6105640290249060)
,p_name=>'P102_PRODUCTO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(5874183315509807)
,p_prompt=>'Producto'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_05=>'HTML_UNSAFE'
,p_updated_on=>wwv_flow_imp.dz('20240325134857Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6105736878249061)
,p_name=>'P102_LINEA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(5874183315509807)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(411015744626960540)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetUp'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_log_app varchar2 (100);',
'v_log_dsc varchar2 (100);',
'v_log_msg varchar2 (100);',
'v_log_obs varchar2 (100);',
'v_log_qry varchar2 (100);',
'begin',
'	v_log_app := ''apex.130.102'';',
'	pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,v_log_msg,v_log_obs,v_log_qry);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>411015744626960540
,p_created_on=>wwv_flow_imp.dz('20240924215716Z')
,p_updated_on=>wwv_flow_imp.dz('20240924215716Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
