prompt --application/pages/page_00304
begin
--   Manifest
--     PAGE: 00304
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>304
,p_name=>unistr('Distribuci\00F3n de Compras')
,p_step_title=>unistr('Distribuci\00F3n de Compras')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230708132700Z')
,p_last_updated_on=>wwv_flow_imp.dz('20221212174106Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(135682360710988644)
,p_plug_name=>'Reporte de Porcentajes'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select num01',
'	, trim(pr.abalph) proveedor',
'	, txt01',
'	, ct.drdl01 categoria',
'	, txt02',
'	, sb.drdl01 subcategoria',
'	, num02',
'	, trim(em.abalph) comprador',
'	, num03 total',
'	, num04 totalprv',
'	, 100*(num03/num04) prcprv',
'	, num05 totalctg',
'	, 100*(num03/num05) prcctg',
'	, num06 totalstg',
'	, 100*(num03/num06) prcstg',
'from data.t_apex_temporal',
'inner join f0101@jdedtadl pr on num01 = pr.aban8',
'inner join f0101@jdedtadl em on num02 = em.aban8',
'left join vt_jde_udcjde  ct on txt01 = ct.drky and ct.drsy = ''41'' and ct.drrt = ''P4''',
'left join vt_jde_udcjde  sb on trim(txt02) = sb.drky and sb.drsy = ''41'' and sb.drrt = ''01''',
'where flag = ''apex.130.304'' and control01 = :app_user;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P304_CATEGORIA,P304_FECHADESDE,P304_FECHAHASTA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(46778458574923906)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'CSV:HTML'
,p_enable_mail_download=>'N'
,p_owner=>'CVACA'
,p_internal_uid=>46778458574923906
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101728994222292501)
,p_db_column_name=>'NUM01'
,p_display_order=>10
,p_column_identifier=>'G'
,p_column_label=>unistr('C\00F3d. Proveedor')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101729035772292502)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>20
,p_column_identifier=>'H'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101729187244292503)
,p_db_column_name=>'TXT01'
,p_display_order=>30
,p_column_identifier=>'I'
,p_column_label=>unistr('C\00F3d. Categor\00EDa')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101729280080292504)
,p_db_column_name=>'CATEGORIA'
,p_display_order=>40
,p_column_identifier=>'J'
,p_column_label=>'Categoria'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101729378388292505)
,p_db_column_name=>'TXT02'
,p_display_order=>50
,p_column_identifier=>'K'
,p_column_label=>unistr('C\00F3d. Subcategor\00EDa')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101729410444292506)
,p_db_column_name=>'SUBCATEGORIA'
,p_display_order=>60
,p_column_identifier=>'L'
,p_column_label=>'Subcategoria'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101729548198292507)
,p_db_column_name=>'NUM02'
,p_display_order=>70
,p_column_identifier=>'M'
,p_column_label=>unistr('C\00F3d. Comprador')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101729641338292508)
,p_db_column_name=>'COMPRADOR'
,p_display_order=>80
,p_column_identifier=>'N'
,p_column_label=>'Comprador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101729762693292509)
,p_db_column_name=>'TOTAL'
,p_display_order=>90
,p_column_identifier=>'O'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101729869702292510)
,p_db_column_name=>'TOTALPRV'
,p_display_order=>100
,p_column_identifier=>'P'
,p_column_label=>'Total Prov.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101729980048292511)
,p_db_column_name=>'PRCPRV'
,p_display_order=>110
,p_column_identifier=>'Q'
,p_column_label=>'% prov.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101730023958292512)
,p_db_column_name=>'TOTALCTG'
,p_display_order=>120
,p_column_identifier=>'R'
,p_column_label=>'Total Cat.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101730115896292513)
,p_db_column_name=>'PRCCTG'
,p_display_order=>130
,p_column_identifier=>'S'
,p_column_label=>'% cat.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101730210666292514)
,p_db_column_name=>'TOTALSTG'
,p_display_order=>140
,p_column_identifier=>'T'
,p_column_label=>'Total Subc.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(101730366517292515)
,p_db_column_name=>'PRCSTG'
,p_display_order=>150
,p_column_identifier=>'U'
,p_column_label=>'% subc.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(46795683618312801)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_report_alias=>'467957'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100
,p_report_columns=>'COMPRADOR:PROVEEDOR:CATEGORIA:SUBCATEGORIA:TOTAL:TOTALPRV:PRCPRV:TOTALCTG:PRCCTG:TOTALSTG:PRCSTG:'
,p_sort_column_1=>'CATEGORIA'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'SUBCATEGORIA'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'PROVEEDOR'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'0:0:0'
,p_break_enabled_on=>'0:0:0'
,p_created_on=>wwv_flow_imp.dz('20230708132700Z')
,p_updated_on=>wwv_flow_imp.dz('20230708132700Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(135973103811318607)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1172355895584899309)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(46740760422641432)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1172355895584899309)
,p_button_name=>'BUSCAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46752424955641456)
,p_name=>'P304_CATEGORIA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(135973103811318607)
,p_prompt=>unistr('Categor\00EDa')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select distinct categoria||'' (''||codcategoria||'')'' d, codcategoria from vt_jde_productos order by 1'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46752811509641456)
,p_name=>'P304_SUBCATEGORIA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(135973103811318607)
,p_prompt=>unistr('Subcategor\00EDa')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select distinct subcategoriaproducto||'' (''||codsubcategoria||'')'' d, codsubcategoria from vt_jde_productos where (codcategoria = :p304_categoria or :p304_categoria is null) and codsubcategoria != ''      '' order by 1'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_cascade_parent_items=>'P304_CATEGORIA'
,p_ajax_items_to_submit=>'P304_CATEGORIA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46753256506641456)
,p_name=>'P304_FECHADESDE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(135973103811318607)
,p_item_default=>'trunc(add_months(sysdate,-1),''month'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Desde'
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>10
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(46753614236641456)
,p_name=>'P304_FECHAHASTA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(135973103811318607)
,p_item_default=>'sysdate'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Hasta'
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>10
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46754002422641456)
,p_name=>'Actualiza Reporte'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(135682360710988644)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46754515385641458)
,p_event_id=>wwv_flow_imp.id(46754002422641456)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(101730476865292516)
,p_name=>'Procesar'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(46740760422641432)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(101730517274292517)
,p_event_id=>wwv_flow_imp.id(101730476865292516)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(101730697328292518)
,p_event_id=>wwv_flow_imp.id(101730476865292516)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_ctg		varchar2(10);',
'v_sct		varchar2(10);',
'v_usr		varchar2(25);',
'v_flg		varchar2(99);',
'v_jde_dsd	number;',
'v_jde_hst	number;',
'begin',
'	commit;',
'	set transaction read write;',
'',
'	execute immediate ''truncate table t_tmp_b drop storage'';',
'',
'	select data.pk_commons.f_g2jde(:p304_fechadesde),data.pk_commons.f_g2jde(:p304_fechahasta) into v_jde_dsd,v_jde_hst from dual;',
'	v_ctg := :p304_categoria;',
'	v_sct := :p304_subcategoria;',
'	v_usr := :app_user;',
'	v_flg := ''apex.130.304'';',
'	',
'',
'	insert into t_tmp_b (flag,num01,txt01,txt02,num02,num03)',
'	select ''A'' flag,pdan8, imprp4, imprp6, pdanby, sum(pdaexp)/100 pdaexp',
'	from f4311@jdedtadl inner join f4101@jdedtadl on pditm = imitm',
'	where pddcto in (''CM'',''BM'',''CE'',''CN'', ''BN'',''OI'')',
'		and ((pdlttr = 280 and pdnxtr = 400) or (pdlttr = 400 and pdnxtr = 400) or (pdlttr = 400 and pdnxtr = 999))',
'		and (pdtrdj between v_jde_dsd and v_jde_hst)',
'	group by ''A'',pdan8,imprp4,imprp6, pdanby;',
'',
'	insert into t_tmp_b (flag,txt01)',
'	select distinct ''B'' flag,imprp4	 ctg from data.vt_jde_productorecodificado where (aimprp4 = v_ctg or imprp4 = v_ctg) or v_ctg is null',
'	union',
'	select distinct ''B'' flag,aimprp4 ctg from data.vt_jde_productorecodificado where (aimprp4 = v_ctg or imprp4 = v_ctg) or v_ctg is null;',
'',
'	insert into t_tmp_b (flag,txt02)',
'	select distinct ''C'' flag,imprp6  sct from data.vt_jde_productorecodificado where (aimprp6 = v_sct or imprp6 = v_sct) or v_sct is null',
'	union',
'	select distinct ''C'' flag,aimprp6 sct from data.vt_jde_productorecodificado where (aimprp6 = v_sct or imprp4 = v_sct) or v_sct is null;',
'',
'	insert into t_tmp_b (flag,num01,txt01,txt02,num02,num03)',
'	select ''D'' flag,num01,txt01,txt02,num02,num03 from t_tmp_b',
'	where flag = ''A''',
'		and txt01 in (select txt01 from t_tmp_b where flag = ''B'' and trim(txt01) is not null)',
'		and txt02 in (select txt02 from t_tmp_b where flag = ''C'' and trim(txt02) is not null);',
'',
'	-- Total Proveedor',
'	update t_tmp_b x set x.num04 = (select sum(y.num03) from t_tmp_b y where x.flag = y.flag and x.num01 = y.num01)',
'	where x.flag = ''D'' and exists (select sum(y.num03) from t_tmp_b y where x.flag = y.flag and x.num01 = y.num01);',
'',
unistr('	-- Total Categor\00EDa'),
'	update t_tmp_b x set x.num05 = (select sum(y.num03) from t_tmp_b y where x.flag = y.flag and x.txt01 = y.txt01)',
'	where x.flag = ''D'' and exists (select sum(y.num03) from t_tmp_b y where x.flag = y.flag and x.txt01 = y.txt01);',
'',
unistr('	-- Total Subcategor\00EDa'),
'	update t_tmp_b x set x.num06 = (select sum(y.num03) from t_tmp_b y where x.flag = y.flag and x.txt02 = y.txt02)',
'	where x.flag = ''D'' and exists (select sum(y.num03) from t_tmp_b y where x.flag = y.flag and x.txt02 = y.txt02);',
'',
'	delete from data.t_apex_temporal where flag = v_flg and control01 = v_usr;',
'',
'	insert into data.t_apex_temporal (flag,control01,num01,txt01,txt02,num02,num03,num04,num05,num06)',
'	select v_flg,v_usr,num01,trim(txt01),trim(txt02),num02,num03,num04,num05,num06 from t_tmp_b where flag = ''D'';',
'	commit;',
'end;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(101730794844292519)
,p_event_id=>wwv_flow_imp.id(101730476865292516)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(135682360710988644)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(101730891179292520)
,p_event_id=>wwv_flow_imp.id(101730476865292516)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp.component_end;
end;
/
