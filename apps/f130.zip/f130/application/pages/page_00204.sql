prompt --application/pages/page_00204
begin
--   Manifest
--     PAGE: 00204
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>204
,p_name=>'dlgEditarCantidadEmails'
,p_alias=>'DLGEDITARCANTIDADEMAILS'
,p_page_mode=>'MODAL'
,p_step_title=>'Cantidad y Fecha Compromiso'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_created_on=>wwv_flow_imp.dz('20240919133732Z')
,p_last_updated_on=>wwv_flow_imp.dz('20241105211121Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(91371528695973017)
,p_plug_name=>'Formulario'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(190516845399868248)
,p_plug_name=>'Comentarios para orden de compra'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(91371695243973018)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(190516845399868248)
,p_button_name=>'GRABAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Grabar'
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'Y'
,p_grid_column_span=>4
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91371053958973012)
,p_name=>'P204_PPGESTION_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(91371528695973017)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91371206065973014)
,p_name=>'P204_CANTIDAD_MANUAL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(91371528695973017)
,p_prompt=>'Cantidad'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_inline_help_text=>unistr('Si cambia la cantidad debe establecer una nueva negociaci\00F3n y dar una justificaci\00F3n.')
,p_attribute_01=>'0.0001'
,p_attribute_03=>'left'
,p_attribute_04=>'numeric'
,p_updated_on=>wwv_flow_imp.dz('20241105211121Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91371442436973016)
,p_name=>'P204_EMAILS'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(91371528695973017)
,p_prompt=>'Emails'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>1
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_inline_help_text=>unistr('Ingrese las direcci\00F3nes de email separadas por coma.')
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91372703410973029)
,p_name=>'P204_CANTIDAD_ORGINAL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(91371528695973017)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91372975512973031)
,p_name=>'P204_CANTIDAD_REQUERIDA'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(91371528695973017)
,p_prompt=>'Cantidad Original'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>4
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(92799410414640801)
,p_name=>'P204_FECHA_COMPROMISO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(91371528695973017)
,p_prompt=>'Fecha Compromiso'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'ITEM'
,p_attribute_05=>'P204_MINIMUN_DATE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(92799530810640802)
,p_name=>'P204_MINIMUN_DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(91371528695973017)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140143218569242101)
,p_name=>'P204_JUSTIFICACION'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(91371528695973017)
,p_prompt=>unistr('Justificaci\00F3n')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_inline_help_text=>unistr('Coloque una justificaci\00F3n en caso de cambiar la cantidad.')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(189983785508771001)
,p_name=>'P204_COMENTARIO_PROVEEDOR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(190516845399868248)
,p_prompt=>'Prov.'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>1500
,p_cHeight=>2
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'Y'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(189983867495771002)
,p_name=>'P204_COMENTARIO_APROBADOR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(190516845399868248)
,p_prompt=>'Apr.'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>2
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'Y'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(327479546975678441)
,p_name=>'P204_MODO_AGRUPADO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(91371528695973017)
,p_prompt=>'New'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(140143456730242103)
,p_validation_name=>unistr('Poner Justificaci\00F3n')
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P204_CANTIDAD_ORGINAL <> :P204_CANTIDAD_MANUAL AND (:P204_JUSTIFICACION IS NULL OR LENGTH(:P204_JUSTIFICACION) <5 ) ',
'    THEN RETURN FALSE;',
'    ELSE RETURN TRUE;',
'END IF;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>unistr('Debe poner una justificaci\00F3n.')
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(91372519906973027)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Grabar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_COMP_GESTIONCOMPRAS.SP_SET_PPGESTION_CANT_EMAILS(',
'    :P204_PPGESTION_ID,',
'    :P204_CANTIDAD_MANUAL,',
'    :P204_JUSTIFICACION,',
'    :P204_EMAILS,',
'    :P204_FECHA_COMPROMISO,',
'    :P204_MODO_AGRUPADO',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>91372519906973027
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(189983975547771003)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Grabar Comentarios'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_COMP_GESTIONCOMPRAS.SP_SET_PPGESTION_COMENTARIOS(',
'    :P204_PPGESTION_ID,',
'    :P204_COMENTARIO_PROVEEDOR,',
'    :P204_COMENTARIO_APROBADOR',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>189983975547771003
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(91372447045973026)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(91371695243973018)
,p_internal_uid=>91372447045973026
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(92799677624640803)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Minimum Date'
,p_process_sql_clob=>':P204_MINIMUN_DATE := TO_CHAR(TRUNC(SYSDATE+1), ''DD-MM-RRRR'');'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>92799677624640803
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(91371333981973015)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga Datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    CANTIDAD,',
'    NVL(CANTIDAD_MANUAL, CANTIDAD),',
'    EMAILS,',
'    FECHA_COMPROMISO,',
'    JUSTIFICACION,',
'',
'    NVL(CANTIDAD_MANUAL, CANTIDAD),',
'    ',
'    COMENTARIO_PROVEEDOR,',
'    COMENTARIO_APROBADOR',
'INTO ',
'    :P204_CANTIDAD_REQUERIDA,',
'    :P204_CANTIDAD_MANUAL,',
'    :P204_EMAILS,',
'    :P204_FECHA_COMPROMISO,',
'    :P204_JUSTIFICACION,',
'',
'    :P204_CANTIDAD_ORGINAL,',
'',
'    :P204_COMENTARIO_PROVEEDOR,',
'    :P204_COMENTARIO_APROBADOR',
'FROM',
'    T_COMP_PRODTO_PROVEEDR_GESTION  ',
'WHERE ',
'    ID = :P204_PPGESTION_ID',
';'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>91371333981973015
);
wwv_flow_imp.component_end;
end;
/
