prompt --application/pages/page_00155
begin
--   Manifest
--     PAGE: 00155
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>155
,p_name=>unistr('COMEX - Liq. Importaci\00F3n')
,p_step_title=>unistr('COMEX - Liq. Importaci\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240414045151Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260409203833Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(75901591346799040)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(75901692376799041)
,p_plug_name=>'Reporte'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select prov.id',
'	, nvl(prov.estado,''PENDIENTE'') estado',
'	, vt_mesa.ID ID_MESA',
'	, vt_mesa.TIPOOC TIPO',
'	, vt_mesa.ORDENCOMPRA DOC_ORDEN_COMPRA',
'    , to_char(decode(nvl(vt_mesa.ID_MUESTRA,0),0,vt_mesa.TIPOOC||''-''||vt_mesa.ORDENCOMPRA,vt_mesa.IDPROCESO)) ORDEN_IMPORTACION',
'	, vt_mesa.CODIGOPROVEEDOR P_DISPLAY',
'	, vt_mesa.CODIGOPROVEEDOR PROVEEDOR',
'	, vt_mesa.fechaOIConvertida',
'	, prov.FECHALIQADN',
'	, aduana.FECHAPAGO_LIQ',
'	, prov.ID_BATCH',
'	, (',
'		select numeroarchivo from files.t_apex_archivos where estado = ''1'' and tabla = ''T_CMEX_MESATRABAJO'' and id_tabla = vt_mesa.id',
'		and tipo = (select valor from data.t_corp_udc where id_cabecera = ''CMEX_ET4FI'' and valor = ''ET4_1'')',
'		) as archivo_dai',
'	, (',
'		select numeroarchivo from files.t_apex_archivos where estado = ''1'' and tabla = ''T_CMEX_MESATRABAJO'' and id_tabla = vt_mesa.id',
'		and tipo = (select valor from data.t_corp_udc where id_cabecera = ''CMEX_ET4FI'' and valor = ''ET4_2'')',
'		) as archivo_confirmacion_pago',
'	, (',
'		select numeroarchivo from files.t_apex_archivos where estado = ''1'' and tabla = ''T_CMEX_MESATRABAJO'' and id_tabla = vt_mesa.id',
'		and tipo = (select valor from data.t_corp_udc where id_cabecera = ''CMEX_ET4FI'' and valor = ''ET4_4'')',
'		) as archivo_liquidacion_aduana',
'	, vt_mesa.ordenagente',
'	, d_comple.tipomercaderia',
'	, aduana.refrendo',
'	, ''IMP'' codigomodulo',
'	, ''<span class="fa fa-download" aria-hidden="true"></span>'' icono',
'from',
'data.vt_cmex_mesatrabajo vt_mesa',
'inner join data.t_cmex_tramitesaduana aduana on vt_mesa.id = aduana.id_cmex_mesatrabajo',
'inner join data.t_cmex_datoscomplementarios d_comple on vt_mesa.id = d_comple.id_cmex_mesatrabajo',
'	and aduana.id_cmex_mesatrabajo = d_comple.id_cmex_mesatrabajo',
'	and vt_mesa.codigoetapa in (select valor from t_corp_udc where id_tabla >= 5 and id_cabecera = ''CMEX_ET_IM'')',
'left join data.t_cmex_provision prov on vt_mesa.id = prov.id_cmex_mesatrabajo',
'	and prov.tiporegistro = ''PROVISION''',
'union',
'select prov.id',
'	, nvl(prov.estado,''PENDIENTE'') estado',
'	, to_number(vt_mesa.registro) id_mesa',
'	, null TIPO',
'	, null DOC_ORDEN_COMPRA',
'    , to_char(''EXP-''||vt_mesa.registro) ORDEN_IMPORTACION',
'	, vt_mesa.cliente P_DISPLAY',
'	, vt_mesa.cliente PROVEEDOR',
'	, null fechaOIConvertida',
'	, prov.FECHALIQADN',
'	, null FECHAPAGO_LIQ',
'	, prov.ID_BATCH',
'	, null archivo_dai',
'	, null archivo_confirmacion_pago',
'	, null archivo_liquidacion_aduana',
'	, null ordenagente',
'	, null tipomercaderia',
'	, null refrendo',
'	, ''EXP'' codigomodulo',
'	, ''<span class="fa fa-download" aria-hidden="true"></span>'' icono',
'from data.t_cmex_exportacion vt_mesa',
'left join data.t_cmex_provision prov on vt_mesa.registro = prov.id_cmex_mesatrabajo',
'where 1 = 1',
'	and vt_mesa.estado = vt_mesa.estado;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_updated_on=>wwv_flow_imp.dz('20241127194025Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(75901732547799042)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'NETBY3'
,p_internal_uid=>75901732547799042
,p_updated_on=>wwv_flow_imp.dz('20241127194025Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78321884658948306)
,p_db_column_name=>'ORDEN_IMPORTACION'
,p_display_order=>10
,p_column_identifier=>'AS'
,p_column_label=>'Orden'
,p_column_link=>'f?p=&APP_ID.:162:&SESSION.::&DEBUG.:RP,162:P162_CODIGOMODULO,P162_CODIGOPROVEEDOR,P162_ID_CMEX_MESATRABAJO,P162_ORDENCOMPRA,P162_ORDENAGTADN,P162_TIPOMERCA,P162_REFERENDO,P162_ID,P162_MODULO_EXT:#CODIGOMODULO#,#P_DISPLAY#,#ID_MESA#,#ORDEN_IMPORTACION'
||'#,#ORDENAGENTE#,#TIPOMERCADERIA#,#REFRENDO#,#ID#,CMEX'
,p_column_linktext=>'#ORDEN_IMPORTACION#'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20241106220256Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78321745179948305)
,p_db_column_name=>'DOC_ORDEN_COMPRA'
,p_display_order=>20
,p_column_identifier=>'AR'
,p_column_label=>'Doc Orden Compra'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78321673318948304)
,p_db_column_name=>'TIPO'
,p_display_order=>30
,p_column_identifier=>'AQ'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(76149426667799216)
,p_db_column_name=>'FECHALIQADN'
,p_display_order=>50
,p_column_identifier=>'X'
,p_column_label=>'Fecha Liq. Aduana'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(77455192494149644)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>60
,p_column_identifier=>'AI'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78325680448948344)
,p_db_column_name=>'P_DISPLAY'
,p_display_order=>70
,p_column_identifier=>'AZ'
,p_column_label=>'P Display'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(77455373271149646)
,p_db_column_name=>'FECHAPAGO_LIQ'
,p_display_order=>90
,p_column_identifier=>'AK'
,p_column_label=>'Fecha Pago Liq.'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(77455473445149647)
,p_db_column_name=>'ARCHIVO_DAI'
,p_display_order=>100
,p_column_identifier=>'AL'
,p_column_label=>'DAI'
,p_column_link=>'f?p=&APP_ID.:&APP_PAGE_ID.:&SESSION.:APPLICATION_PROCESS=G_PROC_DESCARGARARCHIVO:&DEBUG.::G_NUMEROARCHIVO:#ARCHIVO_DAI#'
,p_column_linktext=>'#ICONO#'
,p_column_link_attr=>'target="_blank" download'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(77455571840149648)
,p_db_column_name=>'ARCHIVO_CONFIRMACION_PAGO'
,p_display_order=>110
,p_column_identifier=>'AM'
,p_column_label=>'Conf. Pago'
,p_column_link=>'f?p=&APP_ID.:155:&SESSION.:APPLICATION_PROCESS=G_PROC_DESCARGARARCHIVO:&DEBUG.:RP:G_NUMEROARCHIVO:#ARCHIVO_CONFIRMACION_PAGO#'
,p_column_linktext=>'#ICONO#'
,p_column_link_attr=>'target="_blank" download'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78321481396948302)
,p_db_column_name=>'ARCHIVO_LIQUIDACION_ADUANA'
,p_display_order=>120
,p_column_identifier=>'AO'
,p_column_label=>'Liq. Aduana'
,p_column_link=>'f?p=&APP_ID.:155:&SESSION.:APPLICATION_PROCESS=G_PROC_DESCARGARARCHIVO:&DEBUG.:RP:G_NUMEROARCHIVO:#ARCHIVO_LIQUIDACION_ADUANA#'
,p_column_linktext=>'#ICONO#'
,p_column_link_attr=>'target="_blank" download'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78321930083948307)
,p_db_column_name=>'ID'
,p_display_order=>130
,p_column_identifier=>'AT'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78322067482948308)
,p_db_column_name=>'ID_MESA'
,p_display_order=>140
,p_column_identifier=>'AU'
,p_column_label=>'Id Mesa'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78322143714948309)
,p_db_column_name=>'ORDENAGENTE'
,p_display_order=>150
,p_column_identifier=>'AV'
,p_column_label=>'Ordenagente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78322227880948310)
,p_db_column_name=>'TIPOMERCADERIA'
,p_display_order=>160
,p_column_identifier=>'AW'
,p_column_label=>'Tipomercaderia'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(76269012237424569)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78322379638948311)
,p_db_column_name=>'REFRENDO'
,p_display_order=>170
,p_column_identifier=>'AX'
,p_column_label=>'Refrendo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78325451823948342)
,p_db_column_name=>'ESTADO'
,p_display_order=>180
,p_column_identifier=>'AY'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(80463909111347031)
,p_db_column_name=>'FECHAOICONVERTIDA'
,p_display_order=>190
,p_column_identifier=>'BB'
,p_column_label=>'Fechaoiconvertida'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94271419489663816)
,p_db_column_name=>'ID_BATCH'
,p_display_order=>200
,p_column_identifier=>'BC'
,p_column_label=>'Id Batch'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94273927676663841)
,p_db_column_name=>'CODIGOMODULO'
,p_display_order=>210
,p_column_identifier=>'BD'
,p_column_label=>unistr('M\00F3dulo')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(94274458326663846)
,p_db_column_name=>'ICONO'
,p_display_order=>220
,p_column_identifier=>'BE'
,p_column_label=>'Icono'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_format_mask=>'PCT_GRAPH:::'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(76164117134818015)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'761642'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODIGOMODULO:ORDEN_IMPORTACION:ESTADO:PROVEEDOR:FECHAPAGO_LIQ:ARCHIVO_DAI:ARCHIVO_CONFIRMACION_PAGO:ARCHIVO_LIQUIDACION_ADUANA:'
,p_sort_column_1=>'ESTADO'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'ORDEN_IMPORTACION'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'CODIGOMODULO'
,p_sort_direction_3=>'DESC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'CODIGOMODULO:0:0:0:0:0'
,p_break_enabled_on=>'0:0:0:0:0:CODIGOMODULO'
,p_created_on=>wwv_flow_imp.dz('20240414045151Z')
,p_updated_on=>wwv_flow_imp.dz('20240414045151Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(293585978486535393)
,p_report_id=>wwv_flow_imp.id(76164117134818015)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'ESTADO'
,p_operator=>'!='
,p_expr=>'PROCESADO'
,p_condition_sql=>'"ESTADO" != #APXWS_EXPR#'
,p_condition_display=>'#APXWS_COL_NAME# != ''PROCESADO''  '
,p_enabled=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240414045151Z')
,p_updated_on=>wwv_flow_imp.dz('20240414045151Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85320372504939429)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(75901591346799040)
,p_button_name=>'REPORTE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>unistr('Reporte Hist\00F3rico')
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:194:&SESSION.::&DEBUG.:194::'
,p_icon_css_classes=>'fa-clipboard-chart '
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(76151169844799233)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(75901591346799040)
,p_button_name=>'AGREGAR_IMPORTACION'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>unistr('Agregar Importaci\00F3n')
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:162:&SESSION.::&DEBUG.:RP,162:P162_CODIGOMODULO:IMP'
,p_icon_css_classes=>'fa-sm fa-clipboard-arrow-down'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(94273811983663840)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(75901591346799040)
,p_button_name=>'AGREGAR_EXPORTACION'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>unistr('Agregar Exportaci\00F3n')
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:162:&SESSION.::&DEBUG.:RP,162:P162_CODIGOMODULO:EXP'
,p_icon_css_classes=>'fa-clipboard-arrow-up'
);
wwv_flow_imp.component_end;
end;
/
