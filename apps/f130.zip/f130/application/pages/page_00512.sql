prompt --application/pages/page_00512
begin
--   Manifest
--     PAGE: 00512
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>512
,p_name=>unistr('COMEX - dlg Datos Gesti\00F3n Detalle')
,p_alias=>unistr('COMEX-DLG-DATOS-GESTI\00D3N-DETALLE')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('COMEX - Datos Gesti\00F3n Detalle')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(regOcultos).hide();'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'div.formulario {',
'    padding: 0px 0px;',
'}',
'',
'.dim .col-2 {',
'    text-align: right;',
'}',
'',
'.barraRegion .t-Region-headerItems--title	 {',
'    background: lightsteelblue;',
'    padding: 2px;',
'}',
'',
'.t-Button, .ui-button {',
'    padding: 0px 18px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20241018210600Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260714194308Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(306663162745898750)
,p_plug_name=>'#&P512_DATOS_GESTION_DETALLE_ID.  Control del Contenedor &P512_TIPO_CARGA.'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>190
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_css_classes=>'barraRegion'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>'NOT (:P512_CAB_ESTADO=''REGISTRADO'' AND :P512_CAB_USUARIO = :APP_USER)'
,p_plug_read_only_when2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(308251631700332034)
,p_plug_name=>'Personal Estibaje'
,p_parent_plug_id=>wwv_flow_imp.id(306663162745898750)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>70
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH W_CEDULAS AS (',
'    SELECT',
'        ID,',
'        TRIM(REGEXP_SUBSTR(PERSONAL_ESTIBAJE, ''[^,]+'', 1, LEVEL)) AS CEDULA',
'    FROM',
'        T_CMEX_DATOS_GESTION_DETALLE',
'    WHERE',
'        ID = :P512_DATOS_GESTION_DETALLE_ID',
'    CONNECT BY',
'        REGEXP_SUBSTR(PERSONAL_ESTIBAJE, ''[^,]+'', 1, LEVEL) IS NOT NULL',
'    AND PRIOR ID = ID',
'    AND PRIOR SYS_GUID() IS NOT NULL',
')',
'SELECT',
'    C.CEDULA   AS CEDULA,',
'    UDC.VALOR  AS NOMBRES,',
'    C.CEDULA   AS ICONO_BORRAR',
'FROM',
'    W_CEDULAS C',
'LEFT OUTER JOIN',
'    T_CORP_UDC UDC ON C.CEDULA = UDC.ID_TABLA',
'WHERE',
'    UDC.ID_CABECERA = ''CMEX_PERS'';',
'    ',
'    '))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Personal Estibaje'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(308251791082332035)
,p_max_row_count=>'1000000'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>308251791082332035
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(308252059853332038)
,p_db_column_name=>'CEDULA'
,p_display_order=>10
,p_column_identifier=>'B'
,p_column_label=>unistr('C\00E9dula')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(308251934555332037)
,p_db_column_name=>'NOMBRES'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Personal Estibaje'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(308252975534332047)
,p_db_column_name=>'ICONO_BORRAR'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'.'
,p_column_link=>'javascript:apex.item("P512_PERSONA_ESTIBAJE_ELIMINAR").setValue("#CEDULA#");'
,p_column_linktext=>'<span class="fa fa-trash"></span>'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P512_CAB_ESTADO=''REGISTRADO'' AND :P512_CAB_USUARIO = :APP_USER'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(308857301685181126)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3088574'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CEDULA:NOMBRES:ICONO_BORRAR:'
,p_sort_column_1=>'NOMBRES'
,p_sort_direction_1=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20241018210600Z')
,p_updated_on=>wwv_flow_imp.dz('20241018210600Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(308248338111332001)
,p_plug_name=>'#&P512_DATOS_GESTION_DETALLE_ID. Datos del Contenedor'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>210
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_css_classes=>'barraRegion'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>'NOT (:P512_CAB_ESTADO=''REGISTRADO'' AND :P512_CAB_USUARIO = :APP_USER)'
,p_plug_read_only_when2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(311037303130669808)
,p_plug_name=>'SELLOS NAVIERA'
,p_parent_plug_id=>wwv_flow_imp.id(308248338111332001)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>130
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    j.tipo,',
'    j.sello,',
'',
'    F.NUMEROARCHIVO AS NUMEROARCHIVO,',
'    dbms_lob.getlength(F.BLOBCONTENT) AS BLOBCONTENT,',
'    F.FILENAME      AS FILENAME,',
'    F.MIMETYPE      AS MIMETYPE,',
'',
'    j.id            AS ICONO_BORRAR',
'from ',
'    FILES.T_APEX_ARCHIVOS     F,',
'    T_CMEX_DATOS_GESTION_DETALLE d,',
'    json_table (',
'        d.SELLOS_NAVIERA, ''$[*]'' columns (',
'            id     NUMBER        path ''$.id'', ',
'            tipo   VARCHAR2(500) path ''$.tipo'',',
'            sello  VARCHAR2(500) path ''$.sello'',',
'            imagen NUMBER        path ''$.imagen''',
'        )',
'    ) j ',
'where ',
'    j.imagen = F.numeroarchivo',
'        AND',
'    d.id=:P512_DATOS_GESTION_DETALLE_ID',
'        AND',
'    F.TABLA=''T_CMEX_DATOS_GESTION_DETALLE.SELLO_NAVIERA'' ',
';',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'SELLOS NAVIERA'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(311037461100669809)
,p_max_row_count=>'1000000'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>311037461100669809
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(311038813370669823)
,p_db_column_name=>'TIPO'
,p_display_order=>10
,p_column_identifier=>'K'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(311038998717669824)
,p_db_column_name=>'SELLO'
,p_display_order=>20
,p_column_identifier=>'L'
,p_column_label=>'Sello Naviera'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(311038380588669818)
,p_db_column_name=>'FILENAME'
,p_display_order=>30
,p_column_identifier=>'F'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(311038432949669819)
,p_db_column_name=>'MIMETYPE'
,p_display_order=>40
,p_column_identifier=>'G'
,p_column_label=>'Mimetype'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(311038522094669820)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>50
,p_column_identifier=>'H'
,p_column_label=>'Numeroarchivo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(311038776516669822)
,p_db_column_name=>'BLOBCONTENT'
,p_display_order=>60
,p_column_identifier=>'J'
,p_column_label=>unistr('Im\00E1gen')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment:#FILENAME#:FILES'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(311039141247669826)
,p_db_column_name=>'ICONO_BORRAR'
,p_display_order=>70
,p_column_identifier=>'M'
,p_column_label=>'.'
,p_column_link=>'javascript:apex.item("P512_SELLO_NAVIERA_ELIMINAR").setValue("#ICONO_BORRAR#");'
,p_column_linktext=>'<span class="fa fa-trash"></span>'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(311050184118873806)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3110502'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TIPO:SELLO:BLOBCONTENT:'
,p_created_on=>wwv_flow_imp.dz('20241018210600Z')
,p_updated_on=>wwv_flow_imp.dz('20241018210600Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(311040542259669840)
,p_plug_name=>'#&P512_DATOS_GESTION_DETALLE_ID. Turno &P512_TURNO_ID.'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>200
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_css_classes=>'barraRegion'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>'NOT (:P512_CAB_ESTADO=''REGISTRADO'' AND :P512_CAB_USUARIO = :APP_USER)'
,p_plug_read_only_when2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(313665801315288550)
,p_plug_name=>'#&P512_DATOS_GESTION_DETALLE_ID. CARGUE'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>220
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_css_classes=>'barraRegion'
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P512_CAB_ESTADO NOT IN (''REGISTRADO'')'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20260714194308Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(318297491771653212)
,p_plug_name=>'#&P512_DATOS_GESTION_DETALLE_ID. DOCUMENTOS'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>230
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_css_classes=>'barraRegion'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    j.tipo           AS TIPO,',
'    j.fac_vinculadas AS fac_vinculadas,',
'',
'    F.NUMEROARCHIVO  AS NUMEROARCHIVO,',
'    dbms_lob.getlength(F.BLOBCONTENT) ',
'                     AS BLOBCONTENT,',
'    F.FILENAME       AS FILENAME,',
'    F.MIMETYPE       AS MIMETYPE,',
'',
'    j.id             AS ICONO_BORRAR',
'from ',
'    FILES.T_APEX_ARCHIVOS        F,',
'    T_CMEX_DATOS_GESTION_DETALLE d,',
'    json_table (',
'        d.DOCUMENTOS, ''$[*]'' columns (',
'            id             NUMBER        path ''$.id'', ',
'            tipo           VARCHAR2(500) path ''$.tipo'',',
'            fac_vinculadas VARCHAR2(500) path ''$.fac_vinculadas'',',
'            archivo_id     NUMBER        path ''$.archivo_id''',
'        )',
'    ) j ',
'where ',
'    j.archivo_id = F.numeroarchivo',
'        AND',
'    d.id=:P512_DATOS_GESTION_DETALLE_ID',
'        AND',
'    F.TABLA=''T_CMEX_DATOS_GESTION_DETALLE.DOCUMENTO'' ',
';',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P512_CAB_ESTADO NOT IN (''REGISTRADO'',''CARGUE'') and 1 = 1'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'DOCUMENTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20260714194308Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(318297994086653217)
,p_max_row_count=>'1000000'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>318297994086653217
,p_updated_on=>wwv_flow_imp.dz('20260714194229Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(318298043477653218)
,p_db_column_name=>'TIPO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(321856031790171313)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260714194229Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(318298129378653219)
,p_db_column_name=>'FAC_VINCULADAS'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fac Vinculadas'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(318298283865653220)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Numeroarchivo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(318298383962653221)
,p_db_column_name=>'BLOBCONTENT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment:#FILENAME#:FILES'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(318298453804653222)
,p_db_column_name=>'FILENAME'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(318298561447653223)
,p_db_column_name=>'MIMETYPE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Mimetype'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(318298677246653224)
,p_db_column_name=>'ICONO_BORRAR'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'.'
,p_column_link=>'javascript:apex.item("P512_DOCUMENTO_ELIMINAR").setValue("#ICONO_BORRAR#");'
,p_column_linktext=>'<span class="fa fa-trash"></span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P512_EDITAR_DOCUMENTAL = 1'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(318432239985421918)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3184323'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TIPO:BLOBCONTENT:FAC_VINCULADAS:ICONO_BORRAR:'
,p_created_on=>wwv_flow_imp.dz('20241018210600Z')
,p_updated_on=>wwv_flow_imp.dz('20241018210600Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(537676868046736901)
,p_plug_name=>'Ocultos'
,p_region_name=>'regOcultos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>5
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20260714185758Z')
,p_updated_on=>wwv_flow_imp.dz('20260714185848Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(308248496537332002)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(308248338111332001)
,p_button_name=>'GRABAR_C'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--small:t-Button--success:t-Button--padLeft:t-Button--padRight:t-Button--padTop:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Grabar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>':P512_CAB_ESTADO=''REGISTRADO'' AND :P512_CAB_USUARIO = :APP_USER'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(332268227126974030)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(311040542259669840)
,p_button_name=>'GRABAR_B'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--small:t-Button--success:t-Button--padLeft:t-Button--padRight:t-Button--padTop:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Grabar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>':P512_CAB_ESTADO=''REGISTRADO'' AND :P512_CAB_USUARIO = :APP_USER'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(332268392590974031)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(306663162745898750)
,p_button_name=>'GRABAR_A'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--small:t-Button--success:t-Button--padLeft:t-Button--padRight:t-Button--padTop:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Grabar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>':P512_CAB_ESTADO=''REGISTRADO'' AND :P512_CAB_USUARIO = :APP_USER'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(311039893158669833)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(311037303130669808)
,p_button_name=>'NUEVO_SELLO_NAVIERA'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Nuevo Sello Naviera'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:513:&SESSION.::&DEBUG.:513:P513_DATOS_GESTION_DETALLE_ID:&P512_DATOS_GESTION_DETALLE_ID.'
,p_button_condition=>':P512_CAB_ESTADO=''REGISTRADO'' AND :P512_CAB_USUARIO = :APP_USER'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(318298769076653225)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(318297491771653212)
,p_button_name=>'NUEVO_DOCUMENTO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Nuevo Documento'
,p_button_redirect_url=>'f?p=&APP_ID.:517:&SESSION.::&DEBUG.:517:P517_DATOS_GESTION_DETALLE_ID:&P512_DATOS_GESTION_DETALLE_ID.'
,p_button_condition=>':P512_EDITAR_DOCUMENTAL = 1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_grid_new_row=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260714193212Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(318296865206653206)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(313665801315288550)
,p_button_name=>'DESCARGA_AISV'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(295682704716037726)
,p_button_image_alt=>'Descarga Archivo AISV'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'&P512_AISV_LINK.'
,p_button_execute_validations=>'N'
,p_button_condition=>'P512_AISV_ARCHIVO'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-download'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(318297002368653208)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(313665801315288550)
,p_button_name=>'DESCARGA_DAE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(295682704716037726)
,p_button_image_alt=>'Descarga Archivo DAE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'&P512_DAE_LINK.'
,p_button_execute_validations=>'N'
,p_button_condition=>'P512_DAE_ARCHIVO'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-download'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(308252295311332040)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(306663162745898750)
,p_button_name=>'ESTIBAJE_AGREGAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Agregar'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P512_CAB_ESTADO=''REGISTRADO'' AND :P512_CAB_USUARIO = :APP_USER'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(312480707952335109)
,p_button_sequence=>170
,p_button_plug_id=>wwv_flow_imp.id(311040542259669840)
,p_button_name=>'ABRE_ATAR_TURNO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Atar Turno'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:515:&SESSION.::&DEBUG.:515:P515_DATOS_GESTION_DETALLE_ID:&P512_DATOS_GESTION_DETALLE_ID.'
,p_button_condition=>':P512_CAB_ESTADO=''REGISTRADO'' AND :P512_CAB_USUARIO = :APP_USER'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(308251134028332029)
,p_branch_name=>'Go To Page 511 GRABAR'
,p_branch_action=>'f?p=&APP_ID.:511:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308248535079332003)
,p_name=>'P512_DATOS_GESTION_DETALLE_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(537676868046736901)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260714185848Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308248775805332005)
,p_name=>'P512_CONTROL_ZAIMELLA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(306663162745898750)
,p_prompt=>'Control Zaimella'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_CMEX_PRBD'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ID_TABLA||'' - ''||VALOR AS VALOR, ',
'    ID_TABLA',
'FROM',
'T_CORP_UDC WHERE ID_CABECERA=''CMEX_PRBD'' ORDER BY VALOR'))
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250430213425Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308248883122332006)
,p_name=>'P512_INSPECTOR_BIVAC'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(306663162745898750)
,p_prompt=>'Inspector BIVAC'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_CMEX_PRVR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ID_TABLA||'' - ''||VALOR AS VALOR, ',
'    ID_TABLA',
'FROM',
'T_CORP_UDC WHERE ID_CABECERA=''CMEX_PRVR'' ORDER BY VALOR'))
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250430212827Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308248971560332007)
,p_name=>'P512_INSPECTOR_CAMPAMENTO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(306663162745898750)
,p_prompt=>'Inspector Campamento'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_CMEX_PRCC'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ID_TABLA||'' - ''||VALOR AS VALOR, ',
'    ID_TABLA',
'FROM',
'T_CORP_UDC WHERE ID_CABECERA=''CMEX_PRCC'' ORDER BY VALOR'))
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250430212827Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308249137464332009)
,p_name=>'P512_CONTENEDOR_TIPO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(308248338111332001)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TIPO_CONTENEDOR'
,p_lov=>'.'||wwv_flow_imp.id(312467351177195672)||'.'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_display_when=>'P512_CAB_TIPO_CARGA'
,p_display_when2=>'SUELTA'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308249225479332010)
,p_name=>'P512_CONTENEDOR_NUMERO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(308248338111332001)
,p_prompt=>unistr('N\00FAmero')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when=>'P512_CAB_TIPO_CARGA'
,p_display_when2=>'SUELTA'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308249457358332012)
,p_name=>'P512_TURNO_ID'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(311040542259669840)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308249581916332013)
,p_name=>'P512_DATOS_GESTION_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(537676868046736901)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260714185848Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308249798015332015)
,p_name=>'P512_CAB_TIPO_CARGA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(537676868046736901)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260714185848Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308249873302332016)
,p_name=>'P512_CONTENEDOR_ANCHO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(308248338111332001)
,p_prompt=>'Ancho :'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column_css_classes=>'dim'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308249936165332017)
,p_name=>'P512_CONTENEDOR_LARGO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(308248338111332001)
,p_prompt=>'Largo :'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_column_css_classes=>'dim'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308250074570332018)
,p_name=>'P512_CONTENEDOR_ALTO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(308248338111332001)
,p_prompt=>'Alto :'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column_css_classes=>'dim'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308250103393332019)
,p_name=>'P512_M3'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(308248338111332001)
,p_prompt=>'M3 ='
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_grid_column_css_classes=>'dim'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308250294958332020)
,p_name=>'P512_FECHA_REGISTRO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(537676868046736901)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260714185848Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308250302100332021)
,p_name=>'P512_SELLO_ZAIMELLA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(308248338111332001)
,p_prompt=>'Sello Zaimella'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308250566404332023)
,p_name=>'P512_SELLO_VERIFICADORA'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(308248338111332001)
,p_prompt=>'Sello Verificadora'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308250831878332026)
,p_name=>'P512_PROFORMA'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(308248338111332001)
,p_prompt=>'Proforma'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308250992650332027)
,p_name=>'P512_PEDIDOS'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(308248338111332001)
,p_prompt=>'Pedidos'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH',
'    W_PEDIDOS_BOOKING AS (',
'        SELECT',
'            TRIM(REGEXP_SUBSTR(PEDIDOS, ''[^,]+'', 1, LEVEL)) AS PEDIDO',
'        FROM',
'            T_CMEX_BOOKING',
'         WHERE',
'            ID = :P512_CAB_BOOKING_ID',
'        CONNECT BY',
'            REGEXP_SUBSTR(PEDIDOS, ''[^,]+'', 1, LEVEL) IS NOT NULL',
'        AND PRIOR ID = ID',
'        AND PRIOR SYS_GUID() IS NOT NULL',
'    )',
'    SELECT',
'        PEDIDO   AS NOMBRE,',
'        PEDIDO   AS CODIGO',
'    FROM     ',
'        W_PEDIDOS_BOOKING',
'    WHERE',
'        PEDIDO NOT IN (',
'            SELECT DISTINCT',
'                TRIM(REGEXP_SUBSTR(PEDIDOS, ''[^,]+'', 1, LEVEL)) AS PEDIDO',
'            FROM ',
'                T_CMEX_DATOS_GESTION_DETALLE ',
'            WHERE ',
'                DATOS_GESTION_ID = :P512_DATOS_GESTION_ID',
'                    AND',
'                PEDIDOS IS NOT NULL',
'            CONNECT BY',
'                REGEXP_SUBSTR(PEDIDOS, ''[^,]+'', 1, LEVEL) IS NOT NULL        ',
'        );'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_display_when=>'P512_CAB_BOOKING_ID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>', '
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308251014316332028)
,p_name=>'P512_CHECK_DE_SEGURIDAD'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(308248338111332001)
,p_prompt=>'Check Seguridad'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308252198768332039)
,p_name=>'P512_PERSONA_ESTIBAJE_AGREGAR'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(306663162745898750)
,p_prompt=>'Persona Estibaje'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_CMEX_PRST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ID_TABLA||'' - ''||VALOR AS VALOR, ',
'    ID_TABLA',
'FROM',
'T_CORP_UDC WHERE ID_CABECERA=''CMEX_PRST'' ORDER BY VALOR'))
,p_cSize=>30
,p_display_when=>':P512_CAB_ESTADO=''REGISTRADO'' AND :P512_CAB_USUARIO = :APP_USER'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250430213135Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308253053676332048)
,p_name=>'P512_PERSONA_ESTIBAJE_ELIMINAR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(537676868046736901)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260714185848Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308951244583579003)
,p_name=>'P512_CAB_BOOKING_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(537676868046736901)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260714185848Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(311039207000669827)
,p_name=>'P512_SELLO_NAVIERA_ELIMINAR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(537676868046736901)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260714185848Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(311040756158669842)
,p_name=>'P512_TURNO_FECHADESDE'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(311040542259669840)
,p_prompt=>'Fecha'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(311040839859669843)
,p_name=>'P512_TURNO_IDVEHICULO'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(311040542259669840)
,p_prompt=>'Placa'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(311040945369669844)
,p_name=>'P512_TURNO_IDPERSONAL'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(311040542259669840)
,p_prompt=>unistr('C\00E9dula')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(311041253356669847)
,p_name=>'P512_TURNO_CONDUCTOR'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(311040542259669840)
,p_prompt=>'Conductor'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(313660986290288501)
,p_name=>'P512_CAB_ESTADO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(537676868046736901)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260714185848Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(313661076873288502)
,p_name=>'P512_CAB_USUARIO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(537676868046736901)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260714185848Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(318296328662653201)
,p_name=>'P512_AISV_LINK'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(537676868046736901)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260714185848Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(318296490533653202)
,p_name=>'P512_DAE_LINK'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(537676868046736901)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260714185848Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(318296567031653203)
,p_name=>'P512_AISV_ARCHIVO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(537676868046736901)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260714185848Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(318296665481653204)
,p_name=>'P512_DAE_ARCHIVO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(537676868046736901)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260714185848Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(318296705102653205)
,p_name=>'P512_AISV_NO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(313665801315288550)
,p_prompt=>'AISV No'
,p_source=>'Archivo AISV no cargado'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>0
,p_display_when=>'P512_AISV_ARCHIVO'
,p_display_when_type=>'ITEM_IS_NULL'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(318296941697653207)
,p_name=>'P512_DAE_NO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(313665801315288550)
,p_prompt=>'DAE No'
,p_source=>'Archivo DAE no cargado'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>0
,p_display_when=>'P512_DAE_ARCHIVO'
,p_display_when_type=>'ITEM_IS_NULL'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(318297261942653210)
,p_name=>'P512_DAE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(313665801315288550)
,p_prompt=>'DAE'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P512_DAE_ARCHIVO'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(318297316979653211)
,p_name=>'P512_CARGUE_OBSERVACION'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(313665801315288550)
,p_prompt=>unistr('Observaci\00F3n')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(318297600333653214)
,p_name=>'P512_EDITAR_CARGUE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(537676868046736901)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_item_comment=>'OJO ESTE VALOR VIENE DE LA 511'
,p_updated_on=>wwv_flow_imp.dz('20260714185848Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(318297779393653215)
,p_name=>'P512_EDITAR_DOCUMENTAL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(537676868046736901)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_item_comment=>'OJO ESTE VALOR VIENE DE LA 511'
,p_updated_on=>wwv_flow_imp.dz('20260714185849Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(318297874593653216)
,p_name=>'P512_EDITAR_REVISADO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(537676868046736901)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_item_comment=>'OJO ESTE VALOR VIENE DE LA 511'
,p_updated_on=>wwv_flow_imp.dz('20260714185849Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(318300187399653239)
,p_name=>'P512_DOCUMENTO_ELIMINAR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(537676868046736901)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260714185848Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(344897964937246613)
,p_name=>'P512_CAB_NUMERO_BK'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(537676868046736901)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260714185848Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(683903283313132226)
,p_name=>'P512_FECHAREALCARGUE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(306663162745898750)
,p_item_default=>'to_char(sysdate,''dd/mm/yyyy'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Real Cargue'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250430205242Z')
,p_updated_on=>wwv_flow_imp.dz('20250430205548Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(332268434085974032)
,p_validation_name=>'GRABAR'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P512_CONTENEDOR_NUMERO IS NOT NULL THEN',
'    IF :P512_CAB_NUMERO_BK IS NOT NULL AND PK_CMEX_DATOS_GESTION.F_CONTENEDOR_NRO_VALIDO(UPPER(:P512_CONTENEDOR_NUMERO)) = 0 THEN',
unistr('        RETURN ''N\00FAmero de contenedor NO V\00C1LIDO'';'),
'    END IF;',
'',
'    IF PK_CMEX_DATOS_GESTION.F_CONTENEDOR_NRO_EN_OTRO_DETALLE(:P512_CONTENEDOR_NUMERO, :P512_DATOS_GESTION_DETALLE_ID) >= 1 THEN',
unistr('        RETURN ''N\00FAmero de contenedor YA USADO en el mismo PROCESO'';'),
'    END IF;',
'',
'    IF PK_CMEX_DATOS_GESTION.F_CONTENEDOR_NRO_EN_OTRO_PROCESO(:P512_CONTENEDOR_NUMERO, :P512_DATOS_GESTION_ID) >= 1 THEN',
unistr('        RETURN ''N\00FAmero de contenedor YA USADO en un proceso reciente'';'),
'    END IF;',
'',
'END IF;',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(308252339076332041)
,p_name=>'ESTIBAJE_AGREGAR'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(308252295311332040)
,p_condition_element=>'P512_PERSONA_ESTIBAJE_AGREGAR'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(308252409135332042)
,p_event_id=>wwv_flow_imp.id(308252339076332041)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_DATOS_GESTION.SP_DATOS_GESTION_DET_ETIB_AGRE(',
'    :P512_DATOS_GESTION_DETALLE_ID,',
'    :P512_PERSONA_ESTIBAJE_AGREGAR',
');',
''))
,p_attribute_02=>'P512_PERSONA_ESTIBAJE_AGREGAR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(308252527544332043)
,p_event_id=>wwv_flow_imp.id(308252339076332041)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Debe seleccionar una persona'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(308252652189332044)
,p_event_id=>wwv_flow_imp.id(308252339076332041)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P512_PERSONA_ESTIBAJE_AGREGAR'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(308252784386332045)
,p_event_id=>wwv_flow_imp.id(308252339076332041)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(308251631700332034)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(308252846483332046)
,p_event_id=>wwv_flow_imp.id(308252339076332041)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P512_PERSONA_ESTIBAJE_AGREGAR'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(308253154297332049)
,p_name=>'ESTIBAJE_ELIMINAR'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P512_PERSONA_ESTIBAJE_ELIMINAR'
,p_condition_element=>'P512_PERSONA_ESTIBAJE_ELIMINAR'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(308253262751332050)
,p_event_id=>wwv_flow_imp.id(308253154297332049)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_DATOS_GESTION.SP_DATOS_GESTION_DET_ETIB_ELIM(',
'    :P512_DATOS_GESTION_DETALLE_ID,   ',
'    :P512_PERSONA_ESTIBAJE_ELIMINAR',
');',
''))
,p_attribute_02=>'P512_PERSONA_ESTIBAJE_ELIMINAR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(308951007564579001)
,p_event_id=>wwv_flow_imp.id(308253154297332049)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P512_PERSONA_ESTIBAJE_ELIMINAR'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(308951183199579002)
,p_event_id=>wwv_flow_imp.id(308253154297332049)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(308251631700332034)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(311039395656669828)
,p_name=>'SELLO_NAVIERA_ELIMINAR'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P512_SELLO_NAVIERA_ELIMINAR'
,p_condition_element=>'P512_SELLO_NAVIERA_ELIMINAR'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(311039435154669829)
,p_event_id=>wwv_flow_imp.id(311039395656669828)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_DATOS_GESTION.SP_REMOVE_SELLO_NAVIERA(',
'    :P512_SELLO_NAVIERA_ELIMINAR,',
'    :P512_DATOS_GESTION_DETALLE_ID',
');',
''))
,p_attribute_02=>'P512_SELLO_NAVIERA_ELIMINAR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(311039577544669830)
,p_event_id=>wwv_flow_imp.id(311039395656669828)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P512_SELLO_NAVIERA_ELIMINAR'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(311039648337669831)
,p_event_id=>wwv_flow_imp.id(311039395656669828)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(311037303130669808)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(318300248166653240)
,p_name=>'DOCUMENTO_ELIMINAR'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P512_DOCUMENTO_ELIMINAR'
,p_condition_element=>'P512_DOCUMENTO_ELIMINAR'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(318300393505653241)
,p_event_id=>wwv_flow_imp.id(318300248166653240)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_DATOS_GESTION.SP_REMOVE_DOCUMENTO (',
'    :P512_DOCUMENTO_ELIMINAR,',
'    :P512_DATOS_GESTION_DETALLE_ID',
');'))
,p_attribute_02=>'P512_DOCUMENTO_ELIMINAR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(318300492748653242)
,p_event_id=>wwv_flow_imp.id(318300248166653240)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P512_DOCUMENTO_ELIMINAR'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(318300506716653243)
,p_event_id=>wwv_flow_imp.id(318300248166653240)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(318297491771653212)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(308251262133332030)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GRABAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_DATOS_GESTION.SP_DATOS_GESTION_DETALLE_GRABA(',
'	:P512_DATOS_GESTION_DETALLE_ID,',
'',
'	:P512_CONTROL_ZAIMELLA,',
'	:P512_INSPECTOR_BIVAC,',
'	:P512_INSPECTOR_CAMPAMENTO,',
'',
'	:P512_CONTENEDOR_TIPO,',
'	UPPER(:P512_CONTENEDOR_NUMERO),',
'	replace(:P512_CONTENEDOR_ANCHO,''.'','',''),',
'	replace(:P512_CONTENEDOR_LARGO,''.'','',''),',
'	replace(:P512_CONTENEDOR_ALTO,''.'','',''),',
'',
'	:P512_SELLO_ZAIMELLA,',
'	:P512_SELLO_VERIFICADORA,',
'	:P512_PROFORMA,',
'	:P512_PEDIDOS,',
'	:P512_CHECK_DE_SEGURIDAD',
');',
'',
'update t_cmex_datos_gestion_detalle x set x.fecharealcargue = :p512_fecharealcargue where x.id = :p512_datos_gestion_detalle_id;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>308251262133332030
,p_updated_on=>wwv_flow_imp.dz('20250430205242Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(308249353587332011)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga Detalle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    DATOS_GESTION_ID,',
'    CONTROL_ZAIMELLA,',
'    INSPECTOR_BIVAC,',
'    INSPECTOR_CAMPAMENTO,',
'',
'    TURNO_ID,',
'',
'    CONTENEDOR_TIPO,',
'    CONTENEDOR_NUMERO,',
'    CONTENEDOR_LARGO,    ',
'    CONTENEDOR_ANCHO,',
'    CONTENEDOR_ALTO,',
'    ROUND(CONTENEDOR_LARGO*CONTENEDOR_ANCHO*CONTENEDOR_ALTO,2),',
'',
'    SELLO_ZAIMELLA,',
'    SELLO_VERIFICADORA,',
'    ',
'    PROFORMA,',
'    PEDIDOS,',
'    CHECK_DE_SEGURIDAD,',
'',
'    ---------  CARGUE',
'    AISV_ARCHIVO,',
'    DAE_ARCHIVO,',
'    DAE,',
'    CARGUE_OBSERVACION,',
'',
'    -------------------------',
'    FECHA_REGISTRO,',
'	fecharealcargue',
'INTO',
'    :P512_DATOS_GESTION_ID,',
'    :P512_CONTROL_ZAIMELLA,',
'    :P512_INSPECTOR_BIVAC,',
'    :P512_INSPECTOR_CAMPAMENTO,',
'',
'    :P512_TURNO_ID,',
'',
'    :P512_CONTENEDOR_TIPO,',
'    :P512_CONTENEDOR_NUMERO,',
'    :P512_CONTENEDOR_LARGO,    ',
'    :P512_CONTENEDOR_ANCHO,',
'    :P512_CONTENEDOR_ALTO,',
'    :P512_M3,',
'',
'    :P512_SELLO_ZAIMELLA,',
'    :P512_SELLO_VERIFICADORA,',
'    ',
'    :P512_PROFORMA,',
'    :P512_PEDIDOS,',
'    :P512_CHECK_DE_SEGURIDAD,',
'',
'    ---------  CARGUE',
'    :P512_AISV_ARCHIVO,',
'    :P512_DAE_ARCHIVO,',
'    :P512_DAE,',
'    :P512_CARGUE_OBSERVACION,',
'',
'    -------------------------',
'    :P512_FECHA_REGISTRO,',
'	:P512_FECHAREALCARGUE',
'FROM',
'    T_CMEX_DATOS_GESTION_DETALLE',
'WHERE',
'    ID=:P512_DATOS_GESTION_DETALLE_ID;',
'',
':P512_AISV_LINK := PK_CMEX_GESTIONBOOKING.F_RECUPERA_PARAMETRO(''URL_FILES'', ''none'')||:P512_AISV_ARCHIVO;',
':P512_DAE_LINK  := PK_CMEX_GESTIONBOOKING.F_RECUPERA_PARAMETRO(''URL_FILES'', ''none'')||:P512_DAE_ARCHIVO;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>308249353587332011
,p_updated_on=>wwv_flow_imp.dz('20250430205548Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(308249604173332014)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga Cabecera'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P512_DATOS_GESTION_ID IS NOT NULL THEN',
'    SELECT',
'        TIPO_CARGA,',
'        BOOKING_ID,',
'        NUMERO_BK,',
'        ESTADO,',
'        USUARIO',
'    INTO',
'        :P512_CAB_TIPO_CARGA,',
'        :P512_CAB_BOOKING_ID,',
'        :P512_CAB_NUMERO_BK,',
'        :P512_CAB_ESTADO,',
'        :P512_CAB_USUARIO',
'    FROM ',
'        VT_CMEX_DATOS_GESTION_MESA_TRB',
'    WHERE ',
'        ID = :P512_DATOS_GESTION_ID;',
'END IF;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>308249604173332014
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(311041127970669846)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga Turno'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P512_TURNO_ID IS NOT NULL THEN ',
'    SELECT ',
'        IDPERSONAL, ',
'        FECHADESDE_HORA, ',
'        IDVEHICULO, ',
'        NOMBRES',
'    INTO ',
'        :P512_TURNO_IDPERSONAL,',
'        :P512_TURNO_FECHADESDE,',
'        :P512_TURNO_IDVEHICULO,',
'        :P512_TURNO_CONDUCTOR',
'    FROM ',
'        VT_CMEX_TURNOS_ACPE',
'    WHERE ',
'        ID = :P512_TURNO_ID;',
'END IF;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>311041127970669846
);
wwv_flow_imp.component_end;
end;
/
