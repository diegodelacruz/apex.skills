prompt --application/pages/page_00158
begin
--   Manifest
--     PAGE: 00158
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>158
,p_name=>'COMEX - Aranceles SKU'
,p_step_title=>'COMEX - Aranceles SKU'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230708132655Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260409204110Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(75898914901799014)
,p_plug_name=>'Aranceles por SKU'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_imp.id(296122226350169167)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(75899095951799015)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(75987046519682623)
,p_plug_name=>'Aranceles SKU'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "ID", ',
'CODIGOPRODUCTO AS COD,',
'"CODIGOPRODUCTO",',
'--trim(imdsc1) producto',
'"PARTIDAARANCELARIA",',
'--"PAISORIOGEN",',
'(SELECT DESCRIPCION',
'from DATA.T_CORP_UDC ',
'WHERE ID_CABECERA = ''663'' AND ACTIVO = ''S''  and valor2=''1'' AND ID_TABLA = PAISORIOGEN) AS PASORIGEN, ',
'--pais',
'"PORCENTAJEVIGENTE_ESTANDAR",',
'"ARANCELZAIMELLA",',
'"PORCENTAJE_ISD",',
'"CREDITOTRIBUTARIO_ISD",',
'"FECHAVIGENCIADESDE",',
'"FECHAVIGENCIAHASTA",',
'"COMENTARIO"',
'from "#OWNER#"."T_CMEX_ARANCELESPRODUCTO"  ',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(75987477462682623)
,p_name=>'Report 1'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No se encontraron datos'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:159:&SESSION.::&DEBUG.:RP,159:P159_ID:#ID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-page.png" class="apex-edit-page" alt="">'
,p_owner=>'NETBY3'
,p_internal_uid=>75987477462682623
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(75987569930682634)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(75987969093682637)
,p_db_column_name=>'CODIGOPRODUCTO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(76010393910491646)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(75989503197682639)
,p_db_column_name=>'PARTIDAARANCELARIA'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'P. Arancelaria'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(77404613369214706)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(80461458062347006)
,p_db_column_name=>'PASORIGEN'
,p_display_order=>16
,p_column_identifier=>'O'
,p_column_label=>unistr('Pa\00EDs Origen')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(75990349241682640)
,p_db_column_name=>'PORCENTAJEVIGENTE_ESTANDAR'
,p_display_order=>26
,p_column_identifier=>'H'
,p_column_label=>'% vig. Est.'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(75990784462682640)
,p_db_column_name=>'ARANCELZAIMELLA'
,p_display_order=>36
,p_column_identifier=>'I'
,p_column_label=>'Arancel ZM'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(75991186948682640)
,p_db_column_name=>'PORCENTAJE_ISD'
,p_display_order=>46
,p_column_identifier=>'J'
,p_column_label=>'% ISD'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(75991502773682642)
,p_db_column_name=>'CREDITOTRIBUTARIO_ISD'
,p_display_order=>56
,p_column_identifier=>'K'
,p_column_label=>unistr('Cr\00E9dito T.')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(75991986531682642)
,p_db_column_name=>'FECHAVIGENCIADESDE'
,p_display_order=>66
,p_column_identifier=>'L'
,p_column_label=>'Fecha Desde'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(75992382248682642)
,p_db_column_name=>'FECHAVIGENCIAHASTA'
,p_display_order=>76
,p_column_identifier=>'M'
,p_column_label=>'Fecha Hasta'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(75992709485682643)
,p_db_column_name=>'COMENTARIO'
,p_display_order=>86
,p_column_identifier=>'N'
,p_column_label=>'Comentario'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(80462950905347021)
,p_db_column_name=>'COD'
,p_display_order=>96
,p_column_identifier=>'P'
,p_column_label=>unistr('C\00F3d. Producto')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(75997335943781599)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'759974'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'COD:CODIGOPRODUCTO:PARTIDAARANCELARIA:PASORIGEN:PORCENTAJEVIGENTE_ESTANDAR:ARANCELZAIMELLA:PORCENTAJE_ISD:CREDITOTRIBUTARIO_ISD:FECHAVIGENCIADESDE:FECHAVIGENCIAHASTA:'
,p_created_on=>wwv_flow_imp.dz('20230708132655Z')
,p_updated_on=>wwv_flow_imp.dz('20230708132655Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(75993161774682643)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(75899095951799015)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:159:&SESSION.::&DEBUG.:159'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp.component_end;
end;
/
