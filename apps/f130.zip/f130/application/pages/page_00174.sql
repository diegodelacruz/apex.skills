prompt --application/pages/page_00174
begin
--   Manifest
--     PAGE: 00174
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>174
,p_name=>'Form Contenedores Documentos'
,p_page_mode=>'MODAL'
,p_step_title=>'Form Contenedores Documentos'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_created_on=>wwv_flow_imp.dz('20230708132657Z')
,p_last_updated_on=>wwv_flow_imp.dz('20221121234422Z')
,p_last_updated_by=>'NETBY3'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(82104403885187207)
,p_plug_name=>'Form Contenedores Documentos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(82105137484187207)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295609822801037671)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(82105559514187207)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(82105137484187207)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Regresar'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(82105062986187207)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(82105137484187207)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P174_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(82104915964187207)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(82105137484187207)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P174_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(82104879260187207)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(82105137484187207)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P174_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(82123938189611201)
,p_branch_name=>'Go to 171'
,p_branch_action=>'f?p=&APP_ID.:171:&SESSION.::&DEBUG.:RP,171:P171_ID:&P174_ID_CMEX_MESATRABAJO.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82107933011187212)
,p_name=>'P174_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(82104403885187207)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82108238718187218)
,p_name=>'P174_NRO_CONTENEDOR'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(82104403885187207)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Nro Contenedor'
,p_source=>'NRO_CONTENEDOR'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NRO_CONTENEDOR || '' - '' || (SELECT CODIGO_BL FROM T_CMEX_DETALLEDATOSEXP WHERE ID = contenedor.ID_DETALLEDATOSEXP ) AS D ,',
'            NRO_CONTENEDOR AS R ',
'            FROM DATA.T_CMEX_DETALLECONTENEDOR contenedor',
'WHERE ID_CMEX_MESATRABAJO = :P174_ID_CMEX_MESATRABAJO;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82108626178187221)
,p_name=>'P174_ID_CMEX_MESATRABAJO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(82104403885187207)
,p_use_cache_before_default=>'NO'
,p_source=>'ID_CMEX_MESATRABAJO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82109092147187221)
,p_name=>'P174_NUMEROFACTURA'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(82104403885187207)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Pedido'
,p_source=>'NUMEROFACTURA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ORDENPEDIDO || '' / '' || FACTURA AS D, ID AS R FROM T_CMEX_PEDIDOSEXPORTACIONES WHERE ID_CMEX_MESATRABAJO = :P174_ID_CMEX_MESATRABAJO',
'AND ID NOT IN (SELECT NUMEROFACTURA FROM T_CMEX_CONTENEDORESDOCUMENTOS WHERE ID_CMEX_MESATRABAJO = :P174_ID_CMEX_MESATRABAJO)',
'AND :P174_ID IS NULL',
'UNION  ',
'SELECT ORDENPEDIDO || '' / '' || FACTURA AS D, ID AS R  FROM T_CMEX_PEDIDOSEXPORTACIONES WHERE ID_CMEX_MESATRABAJO = :P174_ID_CMEX_MESATRABAJO',
'AND  :P174_ID IS NOT NULL;	',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82109406888187221)
,p_name=>'P174_CERTIFICADOORIGEN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(82104403885187207)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Certificado Origen'
,p_source=>'CERTIFICADOORIGEN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>5
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(82105654155187207)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(82105559514187207)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(82106410347187209)
,p_event_id=>wwv_flow_imp.id(82105654155187207)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(82126133670611223)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'APEX_DEBUG_MESSAGE.ENABLE_DEBUG_MESSAGES(p_level => 3);',
'',
'APEX_DEBUG_MESSAGE.LOG_MESSAGE(',
'    p_message => '' :P174_ID = '' ||   :P174_ID ,',
'    p_level => 1 );    '))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>82126133670611223
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(82110276143187223)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from T_CMEX_CONTENEDORESDOCUMENTOS'
,p_attribute_02=>'T_CMEX_CONTENEDORESDOCUMENTOS'
,p_attribute_03=>'P174_ID'
,p_attribute_04=>'ID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>82110276143187223
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(82110610335187223)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of T_CMEX_CONTENEDORESDOCUMENTOS'
,p_attribute_02=>'T_CMEX_CONTENEDORESDOCUMENTOS'
,p_attribute_03=>'P174_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>82110610335187223
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(82126222031611224)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ActualizaContenedorPeso'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'sumaPesoNeto NUMBER;',
'sumaPesoBruto NUMBER;',
'BEGIN',
'SELECT SUM(PESONETO) PESONETO, SUM(PESOBRUTO)  INTO sumaPesoNeto, sumaPesoBruto',
'FROM T_CMEX_PEDIDOSEXPORTACIONES  WHERE ID IN (SELECT NUMEROFACTURA FROM T_CMEX_CONTENEDORESDOCUMENTOS ',
'                                        WHERE NRO_CONTENEDOR = :P174_NRO_CONTENEDOR );',
'',
'UPDATE T_CMEX_DETALLECONTENEDOR',
'SET PESONETO = sumaPesoNeto, PESOBRUTO = sumaPesoBruto',
'WHERE NRO_CONTENEDOR = :P174_NRO_CONTENEDOR;',
'                   ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>82126222031611224
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(82111063515187223)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(82105062986187207)
,p_internal_uid=>82111063515187223
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(82111400027187223)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>82111400027187223
);
wwv_flow_imp.component_end;
end;
/
