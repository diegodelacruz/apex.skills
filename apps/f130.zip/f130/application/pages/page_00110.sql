prompt --application/pages/page_00110
begin
--   Manifest
--     PAGE: 00110
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>110
,p_name=>unistr('Seguimiento Aprobaci\00F3n')
,p_alias=>unistr('SEGUIMIENTO-APROBACI\00D3N')
,p_step_title=>unistr('Seguimiento Aprobaci\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230719210430Z')
,p_last_updated_on=>wwv_flow_imp.dz('20230728164039Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(54007039689324915)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(54007158569324916)
,p_plug_name=>unistr('Seguimiento_Aprobaci\00F3n')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.phdoco, a.phdcto, a.phan8, pk_commons.f_jde2g(a.phtrdj) phtrdj',
'	, b.usuarioiniciador',
'	, fecha_inicio',
'	, b.estado',
'	, b.usuarioactual',
'	, fecha_fin',
'	, b.id',
'	, ''<span title="Ver ruta" class="fa fa-road"></span>'' ruta',
'	-- , decode(nvl(b.estado,''0''),''0'',''<span class="fa fa-paper-plane-o"></span>'',null) enrutar',
'	, case',
'		when a.phdcto in (''CN'') and nvl(b.estado,''0'') = ''0'' then ''<span class="fa fa-paper-plane-o"></span>''',
'		else null',
'		end enrutar',
'from f4301@jdedtadl a',
'left join t_flujo_aprobacion_cab b on a.phan8 = a.phan8 and a.phdcto = b.entidad_clase and a.phdoco = to_char(b.entidad_id) and b.codmodulo = ''COMP''',
'where a.phan8 = a.phan8 ',
'	and a.phdcto = a.phdcto ',
'	and a.phdcto in (''CN'',''CM'',''BM'',''BN'',''CE'',''OI'')',
'	and phtrdj between pk_commons.f_g2jde(:p110_fecha_desde) and pk_commons.f_g2jde(:p110_fecha_hasta)',
'	and (a.phdoco = :p110_ordencompra or :p110_ordencompra is null)',
'    -- and (a.phdoco,a.phdcto) not in (select x.pddoco, x.pddcto from f4311@jdedtadl x where a.phdoco = x.pddoco and a.phdcto = x.pddcto and x.pdnxtr != ''999'')',
'	and :p110_bandera = 1'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P110_FECHA_DESDE,P110_FECHA_HASTA,P110_BANDERA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Seguimiento_Aprobaci\00F3n')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20230728164039Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(54007513766324920)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>54007513766324920
,p_updated_on=>wwv_flow_imp.dz('20230728164039Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(54007634867324921)
,p_db_column_name=>'PHDOCO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Orden Compra'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(54007714671324922)
,p_db_column_name=>'PHDCTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(54007894357324923)
,p_db_column_name=>'PHAN8'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(137471420988975419)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(54007907098324924)
,p_db_column_name=>'USUARIOINICIADOR'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Iniciador'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(54008091621324925)
,p_db_column_name=>'FECHA_INICIO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fecha Inicio'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy hh24:mi'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(54008127730324926)
,p_db_column_name=>'ESTADO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(54008228236324927)
,p_db_column_name=>'USUARIOACTUAL'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Usuario Actual'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20230728144845Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(54008388779324928)
,p_db_column_name=>'FECHA_FIN'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Fecha Fin'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy hh24:mi'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(54008488496324929)
,p_db_column_name=>'ID'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(24023068135092927)
,p_db_column_name=>'PHTRDJ'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Fecha OC'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55026833503667111)
,p_db_column_name=>'RUTA'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Ruta'
,p_column_link=>'f?p=100:104:&SESSION.::&DEBUG.::G_OBJETO,G_OBJETO_ID,G_TODO:#PHDCTO#,#PHDOCO#,True'
,p_column_linktext=>'#RUTA#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20230728144351Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(37860196542753928)
,p_db_column_name=>'ENRUTAR'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Enrutar'
,p_column_link=>'JavaScript:$s("P110_AP_TIPO",'''');$s("P110_AP_TIPO",''#PHDCTO#'');$s("P110_AP_ORDEN",'''');$s("P110_AP_ORDEN",#PHDOCO#);'
,p_column_linktext=>'#ENRUTAR#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'APP_USER'
,p_display_condition2=>'DDELACRUZ'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20230728144351Z')
,p_updated_on=>wwv_flow_imp.dz('20230728151027Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(54309800734844098)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'543099'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PHDOCO:PHDCTO:PHTRDJ:PHAN8:ESTADO:FECHA_INICIO:FECHA_FIN:USUARIOINICIADOR:USUARIOACTUAL:RUTA:'
,p_sort_column_1=>'FECHA_INICIO'
,p_sort_direction_1=>'DESC NULLS LAST'
,p_sort_column_2=>'PHDCTO'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'PHDOCO'
,p_sort_direction_3=>'DESC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20230719210430Z')
,p_updated_on=>wwv_flow_imp.dz('20230719210500Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(35167823938063057)
,p_report_id=>wwv_flow_imp.id(54309800734844098)
,p_name=>'Sin Ruta'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ESTADO'
,p_operator=>'is null'
,p_condition_sql=>' (case when ("ESTADO" is null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#ffd6d6'
,p_created_on=>wwv_flow_imp.dz('20230719210500Z')
,p_updated_on=>wwv_flow_imp.dz('20230719210500Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(54008543459324930)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(54008645981324931)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(54008543459324930)
,p_button_name=>'Buscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Buscar'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(25726573765605532)
,p_name=>'P110_BANDERA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(54007039689324915)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(25726751666605534)
,p_name=>'P110_ORDENCOMPRA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(54007039689324915)
,p_prompt=>'Orden Compra'
,p_placeholder=>'99999999'
,p_format_mask=>'99999999'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'0'
,p_attribute_02=>'99999999'
,p_attribute_03=>'left'
,p_attribute_04=>'numeric'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(25726831104605535)
,p_name=>'P110_EMPTY'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(54007039689324915)
,p_prompt=>'Empty'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681811193037723)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37860264872753929)
,p_name=>'P110_AP_ORDEN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(54007158569324916)
,p_prompt=>'Orden'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when=>'APP_USER'
,p_display_when2=>'DDELACRUZ'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20230728150106Z')
,p_updated_on=>wwv_flow_imp.dz('20230728150134Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37860391977753930)
,p_name=>'P110_AP_TIPO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(54007158569324916)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when=>'APP_USER'
,p_display_when2=>'DDELACRUZ'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20230728150106Z')
,p_updated_on=>wwv_flow_imp.dz('20230728150134Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54007231496324917)
,p_name=>'P110_FECHA_DESDE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(54007039689324915)
,p_item_default=>'trunc(add_months(sysdate,-1),''month'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Desde'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'STATIC'
,p_attribute_07=>'+0d'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54007368164324918)
,p_name=>'P110_FECHA_HASTA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(54007039689324915)
,p_item_default=>'trunc(sysdate)'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Hasta'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'STATIC'
,p_attribute_07=>'+0d'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(37860437190753931)
,p_name=>'Enrutar'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P110_AP_ORDEN'
,p_condition_element=>'P110_AP_ORDEN'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20230728151441Z')
,p_updated_on=>wwv_flow_imp.dz('20230728152340Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37860510506753932)
,p_event_id=>wwv_flow_imp.id(37860437190753931)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEst\00E1 seguro de env\00EDar a ruta de aprobaci\00F3n?')
,p_created_on=>wwv_flow_imp.dz('20230728151441Z')
,p_updated_on=>wwv_flow_imp.dz('20230728151441Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37860600609753933)
,p_event_id=>wwv_flow_imp.id(37860437190753931)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'ENRUTAR'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20230728151441Z')
,p_updated_on=>wwv_flow_imp.dz('20230728152340Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(25726686809605533)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Buscar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    :P110_BANDERA := 1;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(54008645981324931)
,p_internal_uid=>25726686809605533
,p_updated_on=>wwv_flow_imp.dz('20230728152340Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(37860796434753934)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Enrutar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_estado_sig	varchar2(3);',
'v_estado_ant	varchar2(3);',
'v_area			char(12);',
'v_orden			number;',
'v_tipo			varchar2(2);',
'v_log_app		varchar2(100);',
'v_log_dsc		varchar2(100);',
'begin',
'	v_log_app	:= ''apex.130.110.enrutar'';',
'	v_orden		:= :p110_ap_orden;',
'	v_tipo		:= :p110_ap_tipo;',
'	begin',
'		select data.pk_corp_flujoaprobacion.f_buscarrutajde(phmcu) into v_area',
'		from f4301@jdedtadl where phdoco = v_orden and phdcto = v_tipo;',
'',
'		exception when others then v_area := null;',
'	end;',
'',
'	if trim(v_area) is null then',
'		v_log_dsc := ''Variables: v_orden: ''||v_orden||'', v_tipo: ''||v_tipo;',
'		data.pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,null,null,null); commit;',
unistr('		-- raise_application_error(-20000,''No se pudo enviar a ruta de aprobaci\00F3n.'');'),
'		apex_error.add_error (',
unistr('			p_message 			=> ''No existe ruta de aprobaci\00F3n configurada.'','),
'			p_display_location	=> apex_error.c_inline_in_notification);',
'		',
'		return;',
'	end if;',
'',
'	pk_comp_ordenescompra.sp_enviarorden (v_orden,v_tipo,:g_compania,v_area);',
'end;',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'ENRUTAR'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>37860796434753934
,p_created_on=>wwv_flow_imp.dz('20230728152340Z')
,p_updated_on=>wwv_flow_imp.dz('20230728163027Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
