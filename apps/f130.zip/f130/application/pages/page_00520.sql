prompt --application/pages/page_00520
begin
--   Manifest
--     PAGE: 00520
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>520
,p_name=>unistr('COMEX - Mesa de Trabajo Exportaci\00F3n')
,p_alias=>unistr('COMEX-EXPORTACI\00D3N-MESA-DE-TRABAJO')
,p_step_title=>unistr('Mesa de Trabajo Exportaci\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'div.formulario {',
'    padding: 3px;',
'}',
'.a-IRR-headerLabel, .a-IRR-headerLink {',
'    padding: 4px;',
'}',
'.a-IRR-table td {',
'    padding: 4px;',
'}',
'.t-Body-contentInner {',
'    padding: 5px;',
'}',
'.boton-grupo {',
'    padding: 2px;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20241113165842Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260409210518Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(598535393640977927)
,p_plug_name=>unistr('EXPORTACI\00D3N : Mesa de Trabajo')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296122226350169167)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(598537552833001565)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(614294046499248464)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(614298752159248511)
,p_plug_name=>'Mesa de trabajo'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    REGISTRO, ',
'',
'    PK_CMEX_EXPORTACION.F_ETAPA_VISUAL(ESTADO)  ',
'                            AS ESTADO, ',
'',
'    SUBSTR(MODALIDAD, 1, 3) AS MODALIDAD, ',
'',
'    FECHA_REGISTRO_DIA, ',
'    NUMERO_BK,',
'    CLIENTE_NOMBRES,',
'',
'',
'    USUARIO',
'FROM ',
'    VT_CMEX_EXPORTACION_MESA_TRABJ  MT',
'WHERE ',
'    MT.COMPANIA = :G_COMPANIA',
'    AND',
'    MT.ESTADO NOT IN (''ELIMINADO'')',
'    AND',
'    TRUNC(MT.FECHA_REGISTRO) BETWEEN :P520_FECHA_DESDE AND :P520_FECHA_HASTA',
';'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Mesa de trabajo'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(614298873137248512)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>614298873137248512
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(326290457423333101)
,p_db_column_name=>'REGISTRO'
,p_display_order=>10
,p_column_identifier=>'L'
,p_column_label=>'Registro'
,p_column_link=>'f?p=&APP_ID.:521:&SESSION.::&DEBUG.:521:P521_EXPORTACION_REGISTRO:#REGISTRO#'
,p_column_linktext=>'#REGISTRO#'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(327479104620678437)
,p_db_column_name=>'MODALIDAD'
,p_display_order=>20
,p_column_identifier=>'M'
,p_column_label=>'Mod.'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(326285090495228819)
,p_db_column_name=>'ESTADO'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Etapa'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(326286270101228820)
,p_db_column_name=>'CLIENTE_NOMBRES'
,p_display_order=>40
,p_column_identifier=>'G'
,p_column_label=>'Cliente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(327479209457678438)
,p_db_column_name=>'NUMERO_BK'
,p_display_order=>50
,p_column_identifier=>'N'
,p_column_label=>'Booking'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(326286657982228820)
,p_db_column_name=>'FECHA_REGISTRO_DIA'
,p_display_order=>60
,p_column_identifier=>'H'
,p_column_label=>'Fecha'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(326287897605228821)
,p_db_column_name=>'USUARIO'
,p_display_order=>70
,p_column_identifier=>'K'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(615530585403085711)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2892483'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'REGISTRO:ESTADO:MODALIDAD:NUMERO_BK:FECHA_REGISTRO_DIA:CLIENTE_NOMBRES:USUARIO:'
,p_sort_column_1=>'REGISTRO'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'ID'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'0:0:0:0:0'
,p_break_enabled_on=>'0:0:0:0:0'
,p_created_on=>wwv_flow_imp.dz('20241113165842Z')
,p_updated_on=>wwv_flow_imp.dz('20241113165842Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(326288863296228825)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(614294046499248464)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Buscar'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(326289245615228827)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(614294046499248464)
,p_button_name=>'NUEVO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Nuevo'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:521:&SESSION.::&DEBUG.:521::'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(326282813057228806)
,p_name=>'P520_EXPORTACION_ID_ELIMINAR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(598535393640977927)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(326283567198228810)
,p_name=>'P520_FECHA_DESDE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(598537552833001565)
,p_prompt=>'Desde'
,p_source=>'SELECT to_char(sysdate-31, ''dd/mm/yyyy'') FROM DUAL;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(326283947359228811)
,p_name=>'P520_FECHA_HASTA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(598537552833001565)
,p_prompt=>'Hasta'
,p_source=>'SELECT to_char(sysdate, ''dd/mm/yyyy'') FROM DUAL;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp.component_end;
end;
/
