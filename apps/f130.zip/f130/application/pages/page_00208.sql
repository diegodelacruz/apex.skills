prompt --application/pages/page_00208
begin
--   Manifest
--     PAGE: 00208
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>208
,p_name=>'dlgInsertaFecha'
,p_alias=>'DLGINSERTAFECHA'
,p_page_mode=>'MODAL'
,p_step_title=>'Nueva Fecha'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_created_on=>wwv_flow_imp.dz('20231206170811Z')
,p_last_updated_on=>wwv_flow_imp.dz('20231109165641Z')
,p_last_updated_by=>'DCUEVA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(249395287622698139)
,p_plug_name=>'Formulario'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(125125934312747638)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(249395287622698139)
,p_button_name=>'GRABAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Grabar'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-save'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(125126332893747643)
,p_name=>'P208_MINIMUM_DATE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(249395287622698139)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(125127164208747646)
,p_name=>'P208_DOCUMENTOTIPO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(249395287622698139)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(125127549538747646)
,p_name=>'P208_DOCUMENTO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(249395287622698139)
,p_prompt=>'Documento'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(125127823206747647)
,p_name=>'P208_UDC'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(249395287622698139)
,p_prompt=>'Nombre'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DRDL01 AS NOMBRE, DRKY AS UDC',
'FROM ',
'    VT_JDE_UDCJDE ',
'WHERE ',
'    DRSY=''00'' ',
'        AND ',
'    DRRT=''LG'' ',
'        AND ',
'    DRKY NOT IN (',
'        SELECT ',
'            PLLGTY',
'        FROM F4305@jdedtadl ',
'        WHERE',
'            PLDCTO = :P208_DOCUMENTOTIPO',
'                AND ',
'            PLDOCO = :P208_DOCUMENTO',
'                AND ',
'            PLKCOO = :G_COMPANIA',
'    )',
'ORDER BY 2'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(125128278916747647)
,p_name=>'P208_FECHA'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(249395287622698139)
,p_prompt=>'Fecha'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'ITEM'
,p_attribute_05=>'P208_MINIMUM_DATE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(125129452008747669)
,p_name=>'Grabar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(125125934312747638)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(125129926847747672)
,p_event_id=>wwv_flow_imp.id(125129452008747669)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'SP_FECHA_INSERTA'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_COMP_GESTIONCOMPRAS.SP_FECHA_INSERTA(',
'    :P208_DOCUMENTOTIPO,',
'    :P208_DOCUMENTO,',
'    :P208_UDC,',
'    PK_COMMONS.F_G2JDE( :P208_FECHA ),',
'    :G_COMPANIA',
');'))
,p_attribute_02=>'P208_FECHA,P208_UDC'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(125130411717747672)
,p_event_id=>wwv_flow_imp.id(125129452008747669)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(125128664566747667)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Minimum Date'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P208_MINIMUM_DATE := TO_CHAR(TRUNC(SYSDATE+1), ''DD-MM-RRRR'');',
'',
':P208_FECHA := :P208_MINIMUM_DATE;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>125128664566747667
);
wwv_flow_imp.component_end;
end;
/
