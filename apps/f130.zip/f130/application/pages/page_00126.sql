prompt --application/pages/page_00126
begin
--   Manifest
--     PAGE: 00126
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>126
,p_name=>'Carga de Precios-Proveedor-DescuentoCantidad'
,p_step_title=>'Carga de Precios-Proveedor-DescuentoCantidad'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20230708132653Z')
,p_last_updated_on=>wwv_flow_imp.dz('20220224204217Z')
,p_last_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43996821615911223)
,p_plug_name=>unistr('Informaci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(43997745802911232)
,p_name=>'Precios'
,p_parent_plug_id=>wwv_flow_imp.id(43996821615911223)
,p_template=>wwv_flow_imp.id(296121421643169165)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'TABLE'
,p_query_table=>'T_COMP_PRECIOPROVDESCANT'
,p_query_where=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ESTADO = 0',
'AND USUARIO = :APP_USER',
'and idproceso= :p126_proceso'))
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'CODIGOPROVEEDOR, CODIGOITEM, DESDE_CANTIDAD'
,p_include_rowid_column=>false
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P126_PROCESO'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(43997820875911233)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(43997991298911234)
,p_query_column_id=>2
,p_column_alias=>'CODIGOPROVEEDOR'
,p_column_display_sequence=>2
,p_column_heading=>'Codigoproveedor'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(43998025910911235)
,p_query_column_id=>3
,p_column_alias=>'CODIGOITEM'
,p_column_display_sequence=>3
,p_column_heading=>'Codigoitem'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(43998178322911236)
,p_query_column_id=>4
,p_column_alias=>'DESDE_CANTIDAD'
,p_column_display_sequence=>4
,p_column_heading=>'Desde Cantidad'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(43998270221911237)
,p_query_column_id=>5
,p_column_alias=>'DESCUENTO'
,p_column_display_sequence=>5
,p_column_heading=>'Descuento'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(43998361979911238)
,p_query_column_id=>6
,p_column_alias=>'VIGENCIADESDE'
,p_column_display_sequence=>6
,p_column_heading=>'Vigenciadesde'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(43998406008911239)
,p_query_column_id=>7
,p_column_alias=>'VIGENCIAHASTA'
,p_column_display_sequence=>7
,p_column_heading=>'Vigenciahasta'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(43998555309911240)
,p_query_column_id=>8
,p_column_alias=>'ESTADO'
,p_column_display_sequence=>8
,p_column_heading=>'Estado'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(43998647723911241)
,p_query_column_id=>9
,p_column_alias=>'USUARIO'
,p_column_display_sequence=>9
,p_column_heading=>'Usuario'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(43998796280911242)
,p_query_column_id=>10
,p_column_alias=>'FECHAREGISTRO'
,p_column_display_sequence=>10
,p_column_heading=>'Fecharegistro'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(43998830305911243)
,p_query_column_id=>11
,p_column_alias=>'IDPROCESO'
,p_column_display_sequence=>11
,p_column_heading=>'Idproceso'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(92755962828159010)
,p_plug_name=>'Carga de Precio-Proveedor-Descuento Cantidad'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295639738305037692)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(97468481898128394)
,p_plug_name=>'Barra de accion'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(43996560369911220)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(97468481898128394)
,p_button_name=>'BTN_SUBIR_PRECIO'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Cargar Plantilla [.xlsx]'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:300:&SESSION.::&DEBUG.:RP::'
,p_icon_css_classes=>'fa-upload'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(43999336599911248)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(97468481898128394)
,p_button_name=>'ENVIAR_APROBACION'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Enviar Aprobacion'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:101:&SESSION.::&DEBUG.:RP:G_OBJETO,G_OBJETO_ID,G_USUARIO,G_TIPO1,G_MODULO:PRECIO_PROVEEDOR_DESCUENTO_CANTIDAD,&P126_PROCESO.,&APP_USER.,PRECIO_PROVEEDOR,&APP_MODULO.'
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43996998768911224)
,p_name=>'P126_USUARIO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(43996821615911223)
,p_prompt=>'Usuario'
,p_source=>'SELECT NOMBRES || '' '' ||APELLIDOS FROM VT_CORP_USUARIO WHERE NOMBREUSUARIO = ''CVACA'''
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43997027700911225)
,p_name=>'P126_FECHA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(43996821615911223)
,p_prompt=>'Fecha'
,p_source=>'SELECT TO_DATE(SYSDATE, ''DD/MM/YYYY'') FROM DUAL;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43997154810911226)
,p_name=>'P126_PROCESO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(43996821615911223)
,p_prompt=>'Proceso'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43997286184911227)
,p_name=>'P126_MENSAJESALIDA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(43996821615911223)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43999454368911249)
,p_name=>'P126_ENVIO_EXITO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(43996821615911223)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43999578707911250)
,p_name=>'P126_TERMINA_FLUJO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(43996821615911223)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(43996643302911221)
,p_name=>'Cerrar dialogo tabla'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(43996560369911220)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43996712383911222)
,p_event_id=>wwv_flow_imp.id(43996643302911221)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  P_COMPANIA VARCHAR2(200);',
'  P_PROCESO NUMBER;',
'  P_USUARIO VARCHAR2(50);',
'  P_MENSAJE VARCHAR2(200);',
'BEGIN',
'  P_COMPANIA := ''00001'';',
'  P_PROCESO := :P126_PROCESO ;',
'  P_USUARIO := :APP_USER;',
'--borro lo ingresado y que no este enviado a aprobacion (estado 1)',
'  DELETE T_COMP_PRECIOPROVDESCANT where ESTADO = 0 AND USUARIO = :APP_USER;',
unistr('--Cargo informaci\00F3n a tabla temporal para enviar a aprobacion'),
'  PK_COMP_PRECIOPROVEEDOR.SP_CARGAPLANTILLA(',
'    P_COMPANIA => P_COMPANIA,',
'    P_PROCESO => P_PROCESO,',
'    P_USUARIO => P_USUARIO,',
'    P_MENSAJE => P_MENSAJE',
'  );  ',
'  :P126_MENSAJESALIDA := P_MENSAJE;',
'END;'))
,p_attribute_02=>'P126_PROCESO'
,p_attribute_03=>'P126_MENSAJESALIDA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43997608738911231)
,p_event_id=>wwv_flow_imp.id(43996643302911221)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.message.clearErrors();',
'',
'apex.message.showPageSuccess( apex.item( "P126_MENSAJESALIDA" ).getValue() );'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43997375557911228)
,p_event_id=>wwv_flow_imp.id(43996643302911221)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(43996821615911223)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43999189399911246)
,p_event_id=>wwv_flow_imp.id(43996643302911221)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(43997745802911232)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43999295143911247)
,p_event_id=>wwv_flow_imp.id(43996643302911221)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(97468481898128394)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(44249852489390502)
,p_name=>'Cierre dialogo: evio flujo'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(43999336599911248)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44249989280390503)
,p_event_id=>wwv_flow_imp.id(44249852489390502)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'apex.item( "P126_TERMINA_FLUJO" ).setValue(0);',
'apex.item( "P126_ENVIO_EXITO" ).setValue(0);',
'mostrarBarra();',
'if(this.data.G_EXITO==''true''){',
'     mensaje(''exito'', this.data.G_MENSAJE);',
'     apex.item( "P126_ENVIO_EXITO" ).setValue(1);',
'    if(isTerminoFlujo){',
'        apex.item( "P126_TERMINA_FLUJO" ).setValue(1);',
'    }',
'}',
'else{ ',
'     mensaje(''error'', this.data.G_MENSAJE);',
'}',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(44250095051390504)
,p_name=>unistr('Cierre di\00E1logo: envio flujo \00E9xito')
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(97468481898128394)
,p_condition_element=>'P126_ENVIO_EXITO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44250152017390505)
,p_event_id=>wwv_flow_imp.id(44250095051390504)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    UPDATE T_COMP_PRECIOPROVDESCANT SET ESTADO = 1',
'    WHERE ESTADO = 0',
'    AND USUARIO = :APP_USER;',
unistr('    :P126_MENSAJESALIDA := ''Enviado a aprobaci\00F3n'';'),
'    COMMIT;',
'    ',
'IF(:P126_TERMINA_FLUJO =2) THEN -- TERMINO FLUJO',
'',
'    PK_COMP_PRECIOPROVEEDOR.SP_APROBARDESCUENTOPROVEEDOR(',
'    p_numero=>:P126_PROCESO,',
'    P_COMPANIA=>:G_COMPANIA );',
'',
'END IF;',
''))
,p_attribute_02=>'P126_PROCESO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44250208499390506)
,p_event_id=>wwv_flow_imp.id(44250095051390504)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ocultarBarra();',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44250368964390507)
,p_event_id=>wwv_flow_imp.id(44250095051390504)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(43997745802911232)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(43999089089911245)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga Secuencial'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P126_PROCESO is null then',
'select DATA.SQ_COMP_PROCESOPRECIOPROV.nextval INTO :P126_PROCESO from dual;',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>43999089089911245
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(43997593377911230)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'MensajeProceso'
,p_process_sql_clob=>'apex_application.g_print_success_message := :P126_MENSAJESALIDA || '' ''|| SYSDATE;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>43997593377911230
);
wwv_flow_imp.component_end;
end;
/
