prompt --application/pages/page_00194
begin
--   Manifest
--     PAGE: 00194
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>194
,p_name=>unistr('Negociaci\00F3n - Detalle de \00CDndice')
,p_alias=>'NEGOCIACION-DETALLE-DE-INDICE'
,p_step_title=>unistr('Negociaci\00F3n - Detalle de \00CDndice')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(secItems).hide();'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-button.a-IRR-sortWidget-button[data-option="hide"], .a-IRR-button.a-IRR-sortWidget-button[data-option="freeze"]{',
'    display:none;',
'}',
'.a-IG-controls-item--aggregate, .a-IG-controls-item--controlBreak, .a-IG-controls-item--groupBy, .a-IG-reportSummary-item--aggregate, .a-IG-reportSummary-item--controlBreak, .a-IG-reportSummary-item--groupBy, .a-IRR-controls-item--aggregate, .a-IRR-c'
||'ontrols-item--controlBreak, .a-IRR-controls-item--groupBy, .a-IRR-reportSummary-item--aggregate, .a-IRR-reportSummary-item--controlBreak, .a-IRR-reportSummary-item--groupBy {',
'    --a-report-controls-cell-label-icon-background-color: #3b83bd;',
'    --a-report-controls-cell-label-hover-background-color: #e6f0f7;',
'    display: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'02'
,p_created_on=>wwv_flow_imp.dz('20240829153114Z')
,p_last_updated_on=>wwv_flow_imp.dz('20251021165958Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(158201790301429208)
,p_plug_name=>'Alert'
,p_icon_css_classes=>'fa-hand-stop-o'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--customIcons:t-Alert--danger:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(295605160997037667)
,p_plug_display_sequence=>20
,p_plug_source=>'Fechas de Vigencia se cruzan con valores de indices Aprobados'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pk_comp_negociacion.f_neg_validavigencia_valorindice (:P194_ID)>0',
'and :P194_ES_APROBADOR>=0'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(158201874391429209)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(295619229174037679)
,p_plug_display_sequence=>70
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(194811041198733944)
,p_plug_name=>'Archivos Soporte'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>50
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P194_ID is not null and :P194_ES_APROBADOR>=0'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(198208232361087942)
,p_plug_name=>'ArchivosSoporte'
,p_parent_plug_id=>wwv_flow_imp.id(194811041198733944)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select numeroarchivo ID',
'	, numeroarchivo',
'	, FILENAME',
'	, data.pk_commons.f_googledocview(numeroarchivo,MIMETYPE) enlacearchivo',
'	, NOMBREUSUARIO USUARIO',
'	, case TIPO ',
'		when ''ARCH_AUT'' then ''XML AUTORIZADO'' ',
'		when ''ARCH_HTM'' then ''HTML FORMATO RIDE'' ',
'		when ''ARCH_PDF'' then ''PDF FORMATO RIDE'' ',
'		when ''ARCH_XML'' then ''XML ZAIMELLA'' ',
'		END TIPO ',
'	, :APP_USER usr',
'FROM FILES.T_APEX_ARCHIVOS ',
'WHERE TABLA = ''T_COMP_NEGOCIACIONIDXVLR'' ',
'	AND ID_TABLA = (''IDXS''||LPAD(:P194_IDIDX,4,''0'')||LPAD(:P194_ID,4,''0''))',
'	AND (TIPO=''ANEXOSIDX'')'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'ArchivosSoporte'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20251021165958Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(198208310762087943)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>198208310762087943
,p_updated_on=>wwv_flow_imp.dz('20251021165958Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(198208502590087945)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>unistr('N\00FAmero Archivo')
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(198208638118087946)
,p_db_column_name=>'FILENAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Nombre Archivo'
,p_column_link=>'#ENLACEARCHIVO#'
,p_column_linktext=>'#FILENAME#'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251021165958Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(198209073916087950)
,p_db_column_name=>'USUARIO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200493273983509001)
,p_db_column_name=>'TIPO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200493382140509002)
,p_db_column_name=>'USR'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Usr'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(198208460208087944)
,p_db_column_name=>'ID'
,p_display_order=>100
,p_column_identifier=>'A'
,p_column_label=>'-'
,p_column_link=>'javascript:$s(''P194_NUMEROARCHIVO'',''''); $s(''P194_NUMEROARCHIVO'',''#NUMEROARCHIVO#'');'
,p_column_linktext=>'<span title="Eliminar" title="" class="fa fa-trash"/>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>unistr('nvl(:P194_ESTADOFLUJO,''CREACI\00D3N'') = ''CREACI\00D3N'' and :P194_ID is not null')
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(224409827071993401)
,p_db_column_name=>'ENLACEARCHIVO'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Enlacearchivo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251021165958Z')
,p_updated_on=>wwv_flow_imp.dz('20251021165958Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(200504888799544468)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2005049'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMEROARCHIVO:FILENAME:USUARIO:ID'
,p_created_on=>wwv_flow_imp.dz('20240829153114Z')
,p_updated_on=>wwv_flow_imp.dz('20251021165958Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(200022424441614085)
,p_plug_name=>unistr('Informaci\00F3n General')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>40
,p_query_type=>'TABLE'
,p_query_table=>'T_COMP_NEGOCIACIONIDXVLR'
,p_include_rowid_column=>false
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P194_ES_APROBADOR>=0'
,p_plug_display_when_cond2=>'PLSQL'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>':P194_ESTADOFLUJO IN(''EN RUTA'',''APROBADO'',''CADUCADO'')'
,p_plug_read_only_when2=>'PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(200029730836614096)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'1=1 and :P194_ES_APROBADOR>=0'
,p_plug_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(295275935381039405)
,p_plug_name=>'Botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121809343169165)
,p_plug_display_sequence=>60
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P194_ES_APROBADOR'
,p_plug_display_when_cond2=>'1'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(297255940180612131)
,p_plug_name=>'Alert'
,p_icon_css_classes=>'fa-hand-stop-o'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--customIcons:t-Alert--danger:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(295605160997037667)
,p_plug_display_sequence=>10
,p_plug_source=>'Proceso ya fue aprobado/rechazado'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P194_ES_APROBADOR<0'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(100046883127919612)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(200029730836614096)
,p_button_name=>'Atras'
,p_button_static_id=>'btnAtras'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Atras'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:141:&SESSION.::&DEBUG.::P141_ID:&P194_IDIDX.'
,p_button_condition=>':G_DETALLE_ID IS NULL AND :G_TOKEN IS NULL'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(100047293085919612)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(200029730836614096)
,p_button_name=>'Borrar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Borrar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>unistr('(:P194_ESTADOFLUJO is null or :P194_ESTADOFLUJO in(''RECHAZADO'',''CREACI\00D3N'') )and :P194_ID is not null')
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-trash-o'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(100048070256919613)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(200029730836614096)
,p_button_name=>'Crear'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Crear'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_button_condition=>unistr('(NVL(:P194_ESTADOFLUJO ,''CREACI\00D3N'')=''CREACI\00D3N'' ) and :P194_ID is null')
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-save-as'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(100047660023919612)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(200029730836614096)
,p_button_name=>'Grabar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Grabar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>unistr('(NVL(:P194_ESTADOFLUJO ,''CREACI\00D3N'') in(''RECHAZADO'',''CREACI\00D3N'')) and :P194_ID is not null')
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(158201047262429201)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(200029730836614096)
,p_button_name=>'Enviar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Enviar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>unistr('pk_comp_negociacion.f_neg_validavigencia_valorindice (:P194_ID)=0 AND :P194_ESTADOFLUJO in(''RECHAZADO'',''CREACI\00D3N'') and :P194_ID is not null')
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-send-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(295688750677087941)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_imp.id(200029730836614096)
,p_button_name=>'Caducar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Caducar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_confirm_message=>unistr('\00BFesta seguro de caducar el valor del \00EDndice?')
,p_confirm_style=>'warning'
,p_button_condition=>'(:P194_ESTADOFLUJO = ''APROBADO'' and TRUNC(SYSDATE) BETWEEN TRUNC(TO_DATE(:P194_VIGENCIADESDE)) AND TRUNC(TO_DATE(:P194_VIGENCIAHASTA)))'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-pause-circle'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(295276029022039406)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(295275935381039405)
,p_button_name=>'Aprobar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Aprobar'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:102:&SESSION.::&DEBUG.::G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO,G_TIPO2:&G_COMPANIA.,&APP_MODULO.,&APP_USER.,&P194_OBJETO.,&P194_ID.,&P194_USUARIOFLUJO.,&P194_RUTA_APROBACION.'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(295276154411039407)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(295275935381039405)
,p_button_name=>'Rechazar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Rechazar'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:103:&SESSION.::&DEBUG.::G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO,G_TIPO2:&G_COMPANIA.,&APP_MODULO.,&P194_USERMODI.,&P194_OBJETO.,&P194_ID.,&P194_USUARIOFLUJO.,&P194_RUTA_APROBACION.'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(295277719358039423)
,p_branch_name=>'Goto 141'
,p_branch_action=>'f?p=&APP_ID.:141:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(100047293085919612)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(295277667444039422)
,p_branch_name=>'Goto 141'
,p_branch_action=>'f?p=&APP_ID.:141:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(100048070256919613)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(295688557478087939)
,p_branch_name=>'Goto 141'
,p_branch_action=>'f?p=&APP_ID.:141:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(158201047262429201)
,p_branch_sequence=>30
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194811179161733945)
,p_name=>'P194_ARCHIVO_ANEXOS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(194811041198733944)
,p_prompt=>'Archivo Anexos'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_display_when=>unistr(':P194_ESTADOFLUJO = ''CREACI\00D3N'' and :P194_ID is not null')
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200493447303509003)
,p_name=>'P194_NUMEROARCHIVO'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(158201874391429209)
,p_prompt=>'NUMEROARCHIVO'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295276281917039408)
,p_name=>'P194_ES_APROBADOR'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(158201874391429209)
,p_prompt=>'Es Aprobador'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295276300419039409)
,p_name=>'P194_USUARIO'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(158201874391429209)
,p_prompt=>'Usuario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295276476602039410)
,p_name=>'P194_APROBADOR'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(158201874391429209)
,p_prompt=>'Aprobador'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295277584159039421)
,p_name=>'P194_EXITO'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(158201874391429209)
,p_prompt=>'Exito'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295278395598039429)
,p_name=>'P194_OBJETO'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(158201874391429209)
,p_prompt=>'Objeto'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295685170262087905)
,p_name=>'P194_ID'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(158201874391429209)
,p_item_source_plug_id=>wwv_flow_imp.id(200022424441614085)
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295685298906087906)
,p_name=>'P194_IDIDX'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(158201874391429209)
,p_item_source_plug_id=>wwv_flow_imp.id(200022424441614085)
,p_prompt=>'Ididx'
,p_source=>'IDIDX'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295685326452087907)
,p_name=>'P194_USERCREA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(158201874391429209)
,p_item_source_plug_id=>wwv_flow_imp.id(200022424441614085)
,p_prompt=>'Usercrea'
,p_source=>'USERCREA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>25
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295685472964087908)
,p_name=>'P194_FECHCREA'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(158201874391429209)
,p_item_source_plug_id=>wwv_flow_imp.id(200022424441614085)
,p_prompt=>'Fechcrea'
,p_source=>'FECHCREA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295685560600087909)
,p_name=>'P194_USERMODI'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(158201874391429209)
,p_item_source_plug_id=>wwv_flow_imp.id(200022424441614085)
,p_prompt=>'Usermodi'
,p_source=>'USERMODI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>25
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295685679160087910)
,p_name=>'P194_FECHMODI'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(158201874391429209)
,p_item_source_plug_id=>wwv_flow_imp.id(200022424441614085)
,p_prompt=>'Fechmodi'
,p_source=>'FECHMODI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295685701745087911)
,p_name=>'P194_VALINDICE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(200022424441614085)
,p_item_source_plug_id=>wwv_flow_imp.id(200022424441614085)
,p_prompt=>unistr('Valor \00CDndice')
,p_source=>'VALINDICE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295685852629087912)
,p_name=>'P194_VIGENCIADESDE'
,p_source_data_type=>'DATE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(200022424441614085)
,p_item_source_plug_id=>wwv_flow_imp.id(200022424441614085)
,p_prompt=>'Desde'
,p_source=>'VIGENCIADESDE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'STATIC'
,p_attribute_04=>'-0d'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:NUMBER-OF-MONTH:CLEAR-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295685925605087913)
,p_name=>'P194_VIGENCIAHASTA'
,p_source_data_type=>'DATE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(200022424441614085)
,p_item_source_plug_id=>wwv_flow_imp.id(200022424441614085)
,p_prompt=>'Hasta'
,p_source=>'VIGENCIAHASTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'STATIC'
,p_attribute_04=>'-0d'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:NUMBER-OF-MONTH:CLEAR-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295686003400087914)
,p_name=>'P194_OBSERVACION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(200022424441614085)
,p_item_source_plug_id=>wwv_flow_imp.id(200022424441614085)
,p_prompt=>unistr('Observaci\00F3n')
,p_source=>'OBSERVACION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>1000
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295686125107087915)
,p_name=>'P194_ESTADOFLUJO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(200022424441614085)
,p_item_source_plug_id=>wwv_flow_imp.id(200022424441614085)
,p_prompt=>'Estado Flujo'
,p_source=>'ESTADOFLUJO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="color:red"'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295686232261087916)
,p_name=>'P194_USUARIOFLUJO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(158201874391429209)
,p_item_source_plug_id=>wwv_flow_imp.id(200022424441614085)
,p_prompt=>'Usuarioflujo'
,p_source=>'USUARIOFLUJO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>25
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295686697357087920)
,p_name=>'P194_RUTA_APROBACION'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(200022424441614085)
,p_prompt=>unistr('Ruta Aprobaci\00F3n')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select   NOMBRE, TIPO2',
'from t_admi_ruta where codigomodulo = ''COMP'' and categoria1 = ''NEGOCIACIONIDX'';'))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295686795055087921)
,p_name=>'P194_FECHAMINIMA'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(158201874391429209)
,p_prompt=>'Fechaminima'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295689039706087944)
,p_name=>'P194_EMPTY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(200022424441614085)
,p_prompt=>'New'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681811193037723)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(297253011361612102)
,p_validation_name=>'Valor no vacio'
,p_validation_sequence=>10
,p_validation=>'P194_VALINDICE'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>'#LABEL# debe tener un valor'
,p_when_button_pressed=>wwv_flow_imp.id(100048070256919613)
,p_associated_item=>wwv_flow_imp.id(295685701745087911)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(297253155319612103)
,p_validation_name=>'Vigencia Desde no vacio'
,p_validation_sequence=>30
,p_validation=>'P194_VIGENCIADESDE'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#LABEL# debe tener un valor',
''))
,p_when_button_pressed=>wwv_flow_imp.id(100048070256919613)
,p_associated_item=>wwv_flow_imp.id(295685852629087912)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(297253210552612104)
,p_validation_name=>'Vigencia Hasta no vacio'
,p_validation_sequence=>60
,p_validation=>'P194_VIGENCIAHASTA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#LABEL# debe tener un valor',
''))
,p_when_button_pressed=>wwv_flow_imp.id(100048070256919613)
,p_associated_item=>wwv_flow_imp.id(295685925605087913)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(297253392128612105)
,p_validation_name=>'Observacion no vacio'
,p_validation_sequence=>80
,p_validation=>'P194_OBSERVACION'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#LABEL# debe tener un valor',
''))
,p_when_button_pressed=>wwv_flow_imp.id(100048070256919613)
,p_associated_item=>wwv_flow_imp.id(295686003400087914)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(297253444068612106)
,p_validation_name=>'Vigencia Desde  no puede ser mayor a Vigencia Hasta'
,p_validation_sequence=>100
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if(TO_DATE(:P194_VIGENCIADESDE)>TO_DATE(:P194_VIGENCIAHASTA))then',
'    return ''Inicio de Vigencia no puede ser mayor a Fin de Vigencia '';',
'end if;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(100048070256919613)
,p_associated_item=>wwv_flow_imp.id(295685852629087912)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(297253515227612107)
,p_validation_name=>'Valor no vacio_edita'
,p_validation_sequence=>110
,p_validation=>'P194_VALINDICE'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>'#LABEL# debe tener un valor'
,p_when_button_pressed=>wwv_flow_imp.id(100047660023919612)
,p_associated_item=>wwv_flow_imp.id(295685701745087911)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(297253636475612108)
,p_validation_name=>'Vigencia Desde no vacio_edita'
,p_validation_sequence=>120
,p_validation=>'P194_VIGENCIADESDE'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#LABEL# debe tener un valor',
''))
,p_when_button_pressed=>wwv_flow_imp.id(100047660023919612)
,p_associated_item=>wwv_flow_imp.id(295685852629087912)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(297253709940612109)
,p_validation_name=>'Vigencia Hasta no vacio_edita'
,p_validation_sequence=>130
,p_validation=>'P194_VIGENCIAHASTA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#LABEL# debe tener un valor',
''))
,p_when_button_pressed=>wwv_flow_imp.id(100047660023919612)
,p_associated_item=>wwv_flow_imp.id(295685925605087913)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(297253815546612110)
,p_validation_name=>'Observacion no vacio_edita'
,p_validation_sequence=>140
,p_validation=>'P194_OBSERVACION'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#LABEL# debe tener un valor',
''))
,p_when_button_pressed=>wwv_flow_imp.id(100047660023919612)
,p_associated_item=>wwv_flow_imp.id(295686003400087914)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(297253989062612111)
,p_validation_name=>'Vigencia Desde  no puede ser mayor a Vigencia Hasta_edita'
,p_validation_sequence=>150
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if(TO_DATE(:P194_VIGENCIADESDE)>TO_DATE(:P194_VIGENCIAHASTA))then',
'    return ''Inicio de Vigencia no puede ser mayor a Fin de Vigencia '';',
'end if;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(100047660023919612)
,p_associated_item=>wwv_flow_imp.id(295685852629087912)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(200493533449509004)
,p_name=>'Eliminar'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P194_NUMEROARCHIVO'
,p_condition_element=>'P194_NUMEROARCHIVO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(200493682838509005)
,p_event_id=>wwv_flow_imp.id(200493533449509004)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEsta seguro de eliminar?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(200493764803509006)
,p_event_id=>wwv_flow_imp.id(200493533449509004)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'DELETE FILES.t_apex_archivos WHERE NUMEROARCHIVO=:P194_NUMEROARCHIVO;'
,p_attribute_02=>'P194_NUMEROARCHIVO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(200493812129509007)
,p_event_id=>wwv_flow_imp.id(200493533449509004)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(200493969996509008)
,p_name=>'Cargar Archivo'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P194_ARCHIVO_ANEXOS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(200494012421509009)
,p_event_id=>wwv_flow_imp.id(200493969996509008)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'SUBIRARCHIVO'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(295276596924039411)
,p_name=>'Close Dialog Aprueba'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(295276029022039406)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(295276680717039412)
,p_event_id=>wwv_flow_imp.id(295276596924039411)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'mostrarBarra();',
'// P194_EXITO = 0 ERROR , 1 SE APROBO CON EXITO, 2 TERMINO FLUJO',
'apex.item("P194_EXITO").setValue(0);',
'',
'if(this.data.G_EXITO==''true''){',
'    apex.item("P194_EXITO").setValue(1);',
'    mensaje(''exito'', this.data.G_MENSAJE);',
'    if(isTerminoFlujo){',
'        apex.item("P194_EXITO").setValue(2);',
'    }',
'}',
'else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(295276732843039413)
,p_event_id=>wwv_flow_imp.id(295276596924039411)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE P_USUARIOAPROBADOR VARCHAR2(250);',
'BEGIN',
'    SELECT USUARIOACTUAL INTO  P_USUARIOAPROBADOR FROM t_flujo_aprobacion_cab WHERE codmodulo=:APP_MODULO and ENTIDAD_CLASE =''NEGOCIACIONIDX'' and ENTIDAD_ID=:P194_ID;',
'    IF(:P194_EXITO =1) THEN',
'        UPDATE t_comp_negociacionidxvlr SET ESTADOFLUJO=''EN_PROCESO'',USUARIOFLUJO=P_USUARIOAPROBADOR WHERE ID= :P194_ID;',
'    ELSIF(:P194_EXITO =2) THEN ',
'        UPDATE t_comp_negociacionidxvlr SET ESTADOFLUJO=''APROBADO'',USUARIOFLUJO=P_USUARIOAPROBADOR WHERE ID= :P194_ID;',
'    END IF;',
'END;',
'',
''))
,p_attribute_02=>'APP_MODULO,P194_EXITO,P194_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(295276867634039414)
,p_event_id=>wwv_flow_imp.id(295276596924039411)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if($v("P194_ID")>0){',
'    $(''#btnAtras'').trigger("click");',
'}'))
,p_server_condition_type=>'EXPRESSION'
,p_server_condition_expr1=>':G_DETALLE_ID IS NULL AND :G_TOKEN IS NULL'
,p_server_condition_expr2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(295687762203087931)
,p_event_id=>wwv_flow_imp.id(295276596924039411)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'Cerrar Ventana cuando es por llink'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'window.close();'
,p_server_condition_type=>'EXPRESSION'
,p_server_condition_expr1=>':G_DETALLE_ID IS not NULL AND :G_TOKEN IS not NULL'
,p_server_condition_expr2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(295276923532039415)
,p_event_id=>wwv_flow_imp.id(295276596924039411)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(295277001970039416)
,p_name=>'Close Dialog Rechazo'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(295276154411039407)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(295277120746039417)
,p_event_id=>wwv_flow_imp.id(295277001970039416)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'mostrarBarra();',
'// P194_EXITO = 0 ERROR , 1 SE APROBO CON EXITO, 2 TERMINO FLUJO',
'apex.item("P194_EXITO").setValue(0);',
'if(this.data.G_EXITO==''true''){',
'    apex.item("P194_EXITO").setValue(1);',
'    mensaje(''exito'', this.data.G_MENSAJE);',
'    if(isTerminoFlujo){',
'        apex.item("P194_EXITO").setValue(2);',
'    }',
'}',
'else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(295277251272039418)
,p_event_id=>wwv_flow_imp.id(295277001970039416)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE P_USUARIOAPROBADOR VARCHAR2(250);',
'BEGIN',
'    P_USUARIOAPROBADOR:=:APP_USER;',
'    IF(:P194_EXITO =1) THEN',
'       UPDATE t_comp_negociacionidxvlr SET ESTADOFLUJO=''RECHAZADO'',USUARIOFLUJO=P_USUARIOAPROBADOR WHERE ID= :P194_ID;',
'    END IF;',
'END;'))
,p_attribute_02=>'APP_MODULO,P194_ID,P194_EXITO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(295277345149039419)
,p_event_id=>wwv_flow_imp.id(295277001970039416)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if($v("P194_ID")>0){',
'    $(''#btnAtras'').trigger("click");',
'}'))
,p_server_condition_type=>'EXPRESSION'
,p_server_condition_expr1=>':G_DETALLE_ID IS NULL AND :G_TOKEN IS NULL'
,p_server_condition_expr2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(295687881474087932)
,p_event_id=>wwv_flow_imp.id(295277001970039416)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'Cerrar Ventana cuando es por llink'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'window.close();'
,p_server_condition_type=>'EXPRESSION'
,p_server_condition_expr1=>':G_DETALLE_ID IS not NULL AND :G_TOKEN IS not NULL'
,p_server_condition_expr2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(295277429811039420)
,p_event_id=>wwv_flow_imp.id(295277001970039416)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(295689120045087945)
,p_name=>'Caducar'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(295688750677087941)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_updated_on=>wwv_flow_imp.dz('20240909032312Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(295689250802087946)
,p_event_id=>wwv_flow_imp.id(295689120045087945)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    pk_comp_negociacion.sp_caducarIndice(p_compania => :g_compania, p_usuario => :app_user, p_idvlr => :p194_id);',
'end;'))
,p_attribute_02=>'P194_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240909032312Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(297254180735612113)
,p_event_id=>wwv_flow_imp.id(295689120045087945)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mensajeExito("Registro caducado de forma manual correctamente");',
'$(''#btnAtras'').trigger("click");'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(295687457529087928)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(200022424441614085)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Negociacion - indices calculo de precios detalle crea'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(100048070256919613)
,p_process_success_message=>'Datos almacenados correctamente'
,p_internal_uid=>295687457529087928
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(295687568536087929)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(200022424441614085)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Negociacion - indices calculo de precios detalle edita'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(100047660023919612)
,p_process_success_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Regstro Almacenado',
''))
,p_internal_uid=>295687568536087929
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(295687607669087930)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(200022424441614085)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Negociacion - indices calculo de precios detalle Borrar'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(100047293085919612)
,p_process_success_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Regstro Eliminado',
''))
,p_internal_uid=>295687607669087930
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(158202934273429220)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process form Negociacion - indices calculo de precios detalle enviar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    P_ID VARCHAR2(200);',
'    P_OBJETO VARCHAR2(200);',
'    P_OBJETODESCRIPCION VARCHAR2(200);',
'    P_ORDENMONTO NUMBER;',
'    P_ETAPA VARCHAR2(200);',
'    P_USUARIO VARCHAR2(200);',
'    P_COMENTARIO VARCHAR2(200);',
'    P_TIPO1 VARCHAR2(200);',
'    P_TIPO2 VARCHAR2(200);',
'    P_TIPO3 VARCHAR2(200);',
'    P_TIPO4 VARCHAR2(200);',
'    P_TIPO5 VARCHAR2(200);',
'    P_TIPO6 VARCHAR2(200);',
'    P_TIPO7 VARCHAR2(200);',
'    P_TIPO8 VARCHAR2(200);',
'    P_TIPO9 VARCHAR2(200);',
'    P_TIPO10 VARCHAR2(200);',
'    P_CODIGOPAGINA VARCHAR2(200);',
'    P_MODULO VARCHAR2(200);',
'    P_COMPANIA VARCHAR2(200);',
'    P_EXITO NUMBER;',
'    P_TERMINOFLUJO NUMBER;',
'    P_USUARIOAPROBADOR VARCHAR2(200);',
'    V_FLUJOID NUMBER;',
'BEGIN',
unistr('    P_ID := :P194_ID;P_OBJETO := ''NEGOCIACIONIDX'';P_OBJETODESCRIPCION := ''A\00F1adir Valores de indices '';P_ORDENMONTO := NULL;P_ETAPA := NULL;P_USUARIO := :APP_USER;'),
'    P_COMENTARIO := :P194_OBSERVACION;P_TIPO1 := ''NEGOCIACIONIDX'';',
'    P_TIPO2 := :P194_RUTA_APROBACION;P_TIPO3 := NULL;P_TIPO4 := NULL;P_TIPO5 := NULL;P_TIPO6 := NULL;P_TIPO7 := NULL;P_TIPO8 := NULL;P_TIPO9 := NULL;  P_TIPO10 := NULL;',
'    P_CODIGOPAGINA :=''COMPP194'';P_MODULO :=:APP_MODULO;P_COMPANIA := ''00001'';',
'    PK_CORP_FLUJOAPROBACION.SP_FLUJOENVIAR(',
'        P_ID => P_ID,P_OBJETO => P_OBJETO,P_OBJETODESCRIPCION => P_OBJETODESCRIPCION,P_ORDENMONTO => P_ORDENMONTO,P_ETAPA => P_ETAPA,',
'        P_USUARIO => P_USUARIO,P_COMENTARIO => P_COMENTARIO,P_TIPO1 => P_TIPO1,P_TIPO2 => P_TIPO2,P_TIPO3 => P_TIPO3,P_TIPO4 => P_TIPO4,',
'        P_TIPO5 => P_TIPO5,P_TIPO6 => P_TIPO6,P_TIPO7 => P_TIPO7,P_TIPO8 => P_TIPO8,P_TIPO9 => P_TIPO9,',
'        P_TIPO10 => P_TIPO10,P_CODIGOPAGINA => P_CODIGOPAGINA,P_MODULO => P_MODULO,P_COMPANIA => P_COMPANIA,P_EXITO => P_EXITO',
'    );',
'    ',
'    BEGIN',
'        SELECT USUARIOACTUAL ',
'        INTO P_USUARIOAPROBADOR ',
'        FROM t_flujo_aprobacion_cab WHERE codmodulo=P_MODULO and ENTIDAD_CLASE =P_OBJETO and ENTIDAD_ID=P_ID AND ESTADO in (''EN_PROCESO'');',
'    EXCEPTION WHEN OTHERS THEN ',
'        P_USUARIOAPROBADOR :=:APP_USER;',
'    END ;',
'    DBMS_OUTPUT.PUT_LINE(''P_USUARIOAPROBADOR :''||P_USUARIOAPROBADOR );',
'    DBMS_OUTPUT.PUT_LINE(''P_EXITO :''||P_EXITO );',
'    :P194_ESTADOFLUJO:=CASE P_EXITO WHEN 1 THEN ''EN RUTA'' WHEN 2 THEN ''APROBADO'' END;',
'    IF (P_EXITO= 1)THEN ',
'        UPDATE t_comp_negociacionIDXVLR    SET usuarioflujo=P_USUARIOAPROBADOR, estadoflujo=''EN_PROCESO'' WHERE ID =P_ID;',
'        apex_application.g_print_success_message :=''Enviado a flujo con exito.'';',
'    ELSIF (P_EXITO= 2)THEN ',
'        UPDATE t_comp_negociacionIDXVLR    SET usuarioflujo=P_USUARIOAPROBADOR, estadoflujo=''APROBADO'' WHERE ID =P_ID;',
'        apex_application.g_print_success_message :=''Aprobado flujo con exito.'';',
'    ELSIF (P_EXITO= 0)THEN ',
'        DBMS_OUTPUT.PUT_LINE('' PK_CORP_FLUJOAPROBACION.G_MENSAJE :''|| PK_CORP_FLUJOAPROBACION.G_MENSAJE );',
'        apex_application.g_print_success_message :=''this.data.G_RESULTADO.''||PK_CORP_FLUJOAPROBACION.G_MENSAJE;',
'        apex_error.add_error (',
'            p_message          => PK_CORP_FLUJOAPROBACION.G_MENSAJE,',
'            p_display_location =>apex_error.c_inline_in_notification ',
'        );',
'    END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(158201047262429201)
,p_internal_uid=>158202934273429220
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(200494122845509010)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Process form Negociacion - indices calculo de precios detalle cargar archivos soporte'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE V_NUMEROARCHIVO NUMBER;',
' V_ID_TABLA VARCHAR2(25);',
'',
'BEGIN',
'    V_ID_TABLA :=''IDXS''||LPAD(:P194_IDIDX,4,''0'')||LPAD(:P194_ID,4,''0'') ;',
'    if (:P194_ARCHIVO_ANEXOS IS NULL)then',
'        :P194_ARCHIVO_ANEXOS :=null;',
'        apex_error.add_error (p_message          => ''Debe seleccionar al menos un archivo:'',',
'        p_display_location =>apex_error.c_inline_in_notification ,',
'        p_page_item_name   => ''P194_ARCHIVO_ANEXOS''); ',
'    ELSIF(:P194_ARCHIVO_ANEXOS IS NOT NULL) THEN',
'        PK_APEX_ARCHIVOS.SP_CREARARCHIVO(:P194_ARCHIVO_ANEXOS,''T_COMP_NEGOCIACIONIDXVLR'',V_ID_TABLA ,''ANEXOSIDX'',NULL,:APP_USER, V_NUMEROARCHIVO);',
'        :P194_ARCHIVO_ANEXOS :=null;',
'        apex_application.g_print_success_message :=''Archivo anexado correctamente.'';',
'    END IF; ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SUBIRARCHIVO'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>200494122845509010
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(295686893292087922)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPageA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'	:P194_USUARIO:= :APP_USER;',
'    :P194_OBJETO:=''NEGOCIACIONIDX'';',
'    DBMS_OUTPUT.PUT_LINE('':P194_USUARIO=>''||:P194_USUARIO||'':P194_OBJETO=>''||:P194_OBJETO);',
'    DBMS_OUTPUT.PUT_LINE('':G_DETALLE_ID=>''||:G_DETALLE_ID||'':G_TOKEN=>''||:G_TOKEN);',
'	IF :G_DETALLE_ID IS NOT NULL AND :G_TOKEN IS NOT NULL THEN -- Aprobacion con token (desde link del correo)',
'		DATA.PK_CORP_FLUJOAPROBACION.SP_BUSCARAPROBACION(',
'			:G_DETALLE_ID',
'			, :G_TOKEN',
'			, :G_COMPANIA',
'			, :P194_APROBADOR',
'			, :P194_OBJETO',
'			, :P194_ID',
'		);',
'		:P194_USUARIO := :P194_APROBADOR;',
'	END IF;',
'    DBMS_OUTPUT.PUT_LINE('':P194_APROBADOR=>''||:P194_APROBADOR||'':P194_OBJETO=>''||:P194_OBJETO||'':P194_ID=>''||:P194_ID||:P194_OBJETO||'':P194_USUARIO=>''||:P194_USUARIO);',
'    begin',
'        SELECT PK_CORP_FLUJOAPROBACION.F_APROBADORFLUJO(:P194_USUARIO,USUARIOFLUJO,:APP_MODULO,:G_COMPANIA)',
'        INTO :P194_ES_APROBADOR',
'        FROM T_COMP_NEGOCIACIONIDXVLR',
'        WHERE PK_CORP_FLUJOAPROBACION.F_APROBADORFLUJO(:P194_USUARIO,USUARIOFLUJO,:APP_MODULO,:G_COMPANIA) = 1 ',
'        AND ESTADOFLUJO = ''EN_PROCESO'' ',
'        AND ID = :P194_ID;',
'        DBMS_OUTPUT.PUT_LINE('':P194_ES_APROBADOR=>''||:P194_ES_APROBADOR);',
'    exception when others then',
'        :P194_ES_APROBADOR:=0;',
'        IF :G_DETALLE_ID IS NOT NULL AND :G_TOKEN IS NOT NULL THEN -- Aprobacion con token (desde link del correo)',
'            :P194_ES_APROBADOR:=-1;',
'        END IF;',
'        DBMS_OUTPUT.PUT_LINE('':P194_ES_APROBADOR=>''||:P194_ES_APROBADOR);',
'    END;',
'    IF (:P194_ES_APROBADOR>=0)THEN',
'        begin',
'            if (:P194_IDIDX is null)then',
'                SELECT IDIDX ',
'                INTO :P194_IDIDX',
'                FROM T_COMP_NEGOCIACIONIDXVLR',
'                WHERE ID = :P194_ID',
'                group by IDIDX;',
'            end if;',
'            DBMS_OUTPUT.PUT_LINE('':P194_IDIDX=>''||:P194_IDIDX);',
'        exception when others then',
'            DBMS_OUTPUT.PUT_LINE('':P194_IDIDX=>''||:P194_IDIDX);',
'        END;',
'        begin',
unistr('            SELECT CASE WHEN B.ID IS NULL THEN ''CREACI\00D3N'' ELSE CASE WHEN B.ESTADO = ''EN_PROCESO'' THEN ''EN RUTA'' ELSE B.ESTADO END END ESTADOFLUJO'),
'            INTO :P194_ESTADOFLUJO',
'            FROM T_COMP_NEGOCIACIONIDXVLR a left join T_FLUJO_APROBACION_CAB b on  to_char(a.id) = b.ENTIDAD_ID AND b.ENTIDAD_CLASE = ''NEGOCIACIONIDX''',
'            where  A.ID=:P194_ID;',
'            DBMS_OUTPUT.PUT_LINE('':P194_ESTADOFLUJO=>''||:P194_ESTADOFLUJO);',
'        EXCEPTION WHEN OTHERS THEN ',
unistr('            :P194_ESTADOFLUJO:=''CREACI\00D3N'';'),
'            DBMS_OUTPUT.PUT_LINE('':P194_ESTADOFLUJO=>''||:P194_ESTADOFLUJO);',
'        END;',
'',
'        BEGIN',
'            SELECT RUTAAPROBACION INTO :P194_RUTA_APROBACION FROM T_COMP_NEGOCIACIONIDX WHERE ID = :P194_IDIDX;',
'                DBMS_OUTPUT.PUT_LINE('':P194_RUTA_APROBACION=>''||:P194_RUTA_APROBACION);',
'        EXCEPTION WHEN OTHERS THEN',
'            :P194_RUTA_APROBACION:='''';',
'        END;',
'        :P194_FECHAMINIMA:=TRUNC(SYSDATE);',
'        :P194_USERMODI:=:P194_USUARIO;',
'    END IF;',
'EXCEPTION WHEN OTHERS THEN ',
'    :P194_ESTADOFLUJO:=''EN RUTA'';',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>295686893292087922
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(295278426853039430)
,p_process_sequence=>40
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(200022424441614085)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form Negociaci\00F3n - Detalle de \00CDndice')
,p_internal_uid=>295278426853039430
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(200494295182509011)
,p_process_sequence=>50
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPageB'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    begin',
'        SELECT PK_CORP_FLUJOAPROBACION.F_APROBADORFLUJO(:P194_USUARIO,USUARIOFLUJO,:APP_MODULO,:G_COMPANIA)',
'        INTO :P194_ES_APROBADOR',
'        FROM T_COMP_NEGOCIACIONIDXVLR',
'        WHERE PK_CORP_FLUJOAPROBACION.F_APROBADORFLUJO(:P194_USUARIO,USUARIOFLUJO,:APP_MODULO,:G_COMPANIA) = 1 ',
'        AND ESTADOFLUJO = ''EN_PROCESO'' ',
'        AND ID = :P194_ID;',
'        DBMS_OUTPUT.PUT_LINE('':P194_ES_APROBADOR=>''||:P194_ES_APROBADOR);',
'    exception when others then',
'        :P194_ES_APROBADOR:=0;',
'        IF :G_DETALLE_ID IS NOT NULL AND :G_TOKEN IS NOT NULL THEN -- Aprobacion con token (desde link del correo)',
'            :P194_ES_APROBADOR:=-2;',
'        END IF;',
'        DBMS_OUTPUT.PUT_LINE('':P194_ES_APROBADOR=>''||:P194_ES_APROBADOR);',
'    END;',
'    IF (:P194_ES_APROBADOR>=0)THEN',
'        begin',
'            if (:P194_IDIDX is null)then',
'                SELECT IDIDX ',
'                INTO :P194_IDIDX',
'                FROM T_COMP_NEGOCIACIONIDXVLR',
'                WHERE ID = :P194_ID',
'                group by IDIDX;',
'            end if;',
'            DBMS_OUTPUT.PUT_LINE('':P194_IDIDX=>''||:P194_IDIDX);',
'        exception when others then',
'            DBMS_OUTPUT.PUT_LINE('':P194_IDIDX=>''||:P194_IDIDX);',
'        END;',
'        begin',
unistr('            SELECT CASE WHEN B.ID IS NULL THEN ''CREACI\00D3N'' ELSE CASE WHEN B.ESTADO = ''EN_PROCESO'' THEN ''EN RUTA'' ELSE B.ESTADO END END ESTADOFLUJO'),
'            INTO :P194_ESTADOFLUJO',
'            FROM T_COMP_NEGOCIACIONIDXVLR a left join T_FLUJO_APROBACION_CAB b on  to_char(a.id) = b.ENTIDAD_ID AND b.ENTIDAD_CLASE = ''NEGOCIACIONIDX''',
'            where  A.ID=:P194_ID;',
'            DBMS_OUTPUT.PUT_LINE('':P194_ESTADOFLUJO=>''||:P194_ESTADOFLUJO);',
'        EXCEPTION WHEN OTHERS THEN ',
unistr('            :P194_ESTADOFLUJO:=''CREACI\00D3N'';'),
'            DBMS_OUTPUT.PUT_LINE('':P194_ESTADOFLUJO=>''||:P194_ESTADOFLUJO);',
'        END;',
'',
'        BEGIN',
'            SELECT RUTAAPROBACION INTO :P194_RUTA_APROBACION FROM T_COMP_NEGOCIACIONIDX WHERE ID = :P194_IDIDX;',
'            DBMS_OUTPUT.PUT_LINE('':P194_RUTA_APROBACION=>''||:P194_RUTA_APROBACION);',
'        EXCEPTION WHEN OTHERS THEN',
'            :P194_RUTA_APROBACION:='''';',
'        END;',
'        :P194_FECHAMINIMA:=TRUNC(SYSDATE);',
'        :P194_USERMODI:=:P194_USUARIO;',
'    END IF;',
'EXCEPTION WHEN OTHERS THEN ',
'    :P194_ESTADOFLUJO:=''EN RUTA'';',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>200494295182509011
);
wwv_flow_imp.component_end;
end;
/
