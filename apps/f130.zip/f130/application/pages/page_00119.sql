prompt --application/pages/page_00119
begin
--   Manifest
--     PAGE: 00119
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>119
,p_name=>unistr('Fechas Importaci\00F3n')
,p_step_title=>unistr('Fechas Importaci\00F3n')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20230708132653Z')
,p_last_updated_on=>wwv_flow_imp.dz('20230703153718Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(293280316461548149)
,p_plug_name=>unistr('B\00FAsqueda')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(303948741769147503)
,p_name=>'Reporte'
,p_template=>wwv_flow_imp.id(295629242996037685)
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select control01,control02,control03,control04,num01,txt01,txt02,txt03,txt04,num02,data.pk_commons.f_jde2g(num02) fecha',
'from data.t_apex_temporal',
'where control01 = :g_compania and control02 = :app_modulo and control03 = :app_user and control04 = ''apex.130.119''; '))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(303950545741147521)
,p_query_column_id=>1
,p_column_alias=>'CONTROL01'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(303950671099147522)
,p_query_column_id=>2
,p_column_alias=>'CONTROL02'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(303950711668147523)
,p_query_column_id=>3
,p_column_alias=>'CONTROL03'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(303950832056147524)
,p_query_column_id=>4
,p_column_alias=>'CONTROL04'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(303950949026147525)
,p_query_column_id=>5
,p_column_alias=>'NUM01'
,p_column_display_sequence=>5
,p_column_heading=>'Documento'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(303951003501147526)
,p_query_column_id=>6
,p_column_alias=>'TXT01'
,p_column_display_sequence=>6
,p_column_heading=>'Tipo Doc.'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(303951125005147527)
,p_query_column_id=>7
,p_column_alias=>'TXT02'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(303951294293147528)
,p_query_column_id=>8
,p_column_alias=>'TXT03'
,p_column_display_sequence=>8
,p_column_heading=>'Registro'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_default_sort_column_sequence=>1
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(303951315567147529)
,p_query_column_id=>9
,p_column_alias=>'TXT04'
,p_column_display_sequence=>9
,p_column_heading=>unistr('Descripci\00F3n')
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(303951413179147530)
,p_query_column_id=>10
,p_column_alias=>'NUM02'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(303951553547147531)
,p_query_column_id=>11
,p_column_alias=>'FECHA'
,p_column_display_sequence=>11
,p_column_heading=>'Fecha'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(303951929991147535)
,p_plug_name=>'Agregar'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(316795136073387579)
,p_plug_name=>unistr('Barra de acci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(303976135360214548)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(316795136073387579)
,p_button_name=>'BUSCAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(303952512301147541)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(303951929991147535)
,p_button_name=>'AGREGAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Agregar'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-table-plus'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(293280422982548150)
,p_name=>'P119_DOCUMENTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(293280316461548149)
,p_prompt=>'Documento'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>10
,p_grid_label_column_span=>1
,p_grid_column_css_classes=>'col-doc'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303948676266147502)
,p_name=>'P119_TIPO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(293280316461548149)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303949141090147507)
,p_name=>'P119_MENSAJE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(293280316461548149)
,p_prompt=>'Mensaje'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681811193037723)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303951741903147533)
,p_name=>'P119_AGREGAR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(293280316461548149)
,p_item_default=>'N'
,p_prompt=>'Agregar'
,p_display_as=>'NATIVE_YES_NO'
,p_colspan=>3
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'S'
,p_attribute_03=>unistr('S\00CD')
,p_attribute_04=>'N'
,p_attribute_05=>'NO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303951837856147534)
,p_name=>'P119_BANDERA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(293280316461548149)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303952021699147536)
,p_name=>'P119_REGISTRO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(303951929991147535)
,p_prompt=>'Registro'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select drky||'' - ''||drdl01 d, drky from vt_jde_udcjde where drsy = ''00'' and drrt = ''LG'' order by 1'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(303952475378147540)
,p_name=>'P119_FECHA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(303951929991147535)
,p_item_default=>'sysdate'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_02=>'-0d'
,p_attribute_04=>'both'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(303948828606147504)
,p_name=>'Carga Datos'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(303976135360214548)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(303948990025147505)
,p_event_id=>wwv_flow_imp.id(303948828606147504)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra()'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(303949089965147506)
,p_event_id=>wwv_flow_imp.id(303948828606147504)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_documento number;',
'v_tipo		varchar2(2);',
'v_cantidad	number;',
'v_log_cia	varchar2(99);',
'v_log_mod	varchar2(99);',
'v_log_usr	varchar2(99);',
'v_log_app	varchar2(99);',
'begin',
'	v_documento := :p119_documento; v_tipo := :p119_tipo;',
'',
'	v_log_cia := :g_compania;',
'	v_log_mod := :app_modulo;',
'	v_log_usr := :app_user;',
'	v_log_app := ''apex.130.119'';',
'',
'	:p119_mensaje := null;',
'	:p119_bandera := 0;',
'	if v_documento is not null and v_tipo is not null then',
'		begin',
'			delete from data.t_apex_temporal',
'			where control01 = v_log_cia and control02 = v_log_mod and control03 = v_log_usr and control04 = v_log_app;',
'',
'			insert into data.t_apex_temporal (control01,control02,control03,control04,num01,txt01,txt02,txt03,txt04,num02)',
'			select v_log_cia,v_log_mod,v_log_usr,v_log_app,pldoco,pldcto,plkcoo,pllgty,pldl01,plissu from f4305@jdedtadl',
'			where pldoco = v_documento and pldcto = v_tipo and plkcoo = v_log_cia;',
'			v_cantidad := sql%rowcount;',
'',
'			if v_cantidad = 0 then',
'				:p119_mensaje := ''No hay registros para el documento ingresado.'';',
'			end if;',
'		end;',
'	else',
unistr('		:p119_mensaje := ''Debe ingresar el n\00FAmero y tipo de documento.'';'),
'	end if;',
'	:p119_bandera := v_cantidad;',
'	:p119_agregar := ''N'';',
'	commit;',
'end;'))
,p_attribute_02=>'P119_DOCUMENTO,P119_TIPO'
,p_attribute_03=>'P119_MENSAJE,P119_BANDERA,P119_AGREGAR'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(303951686048147532)
,p_event_id=>wwv_flow_imp.id(303948828606147504)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(303948741769147503)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(303949290312147508)
,p_event_id=>wwv_flow_imp.id(303948828606147504)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra()'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(303952160066147537)
,p_name=>'Agregar'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P119_AGREGAR'
,p_condition_element=>'P119_AGREGAR'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(303952245801147538)
,p_event_id=>wwv_flow_imp.id(303952160066147537)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(303951929991147535)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(303952393668147539)
,p_event_id=>wwv_flow_imp.id(303952160066147537)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(303951929991147535)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(303952619397147542)
,p_name=>'Agregar Registro'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(303952512301147541)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(303952748496147543)
,p_event_id=>wwv_flow_imp.id(303952619397147542)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra()'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(303952857086147544)
,p_event_id=>wwv_flow_imp.id(303952619397147542)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_documento 	number;',
'v_tipo			varchar2(2);',
'v_registro		varchar2(2);',
'v_descripcion	varchar2(30);',
'v_fecha			number;',
'v_cantidad		number;',
'v_log_cia		varchar2(99);',
'v_log_mod		varchar2(99);',
'v_log_usr		varchar2(99);',
'v_log_app		varchar2(99);',
'v_log_dsc		varchar2(99);',
'v_secuencia		number;',
'v_jde_hoy		number;',
'begin',
'	v_registro := :p119_registro; v_fecha := data.pk_commons.f_g2jde(:p119_fecha); v_jde_hoy := data.pk_commons.f_g2jde(sysdate);',
'',
'	v_log_cia := :g_compania;',
'	v_log_mod := :app_modulo;',
'	v_log_usr := :app_user;',
'	v_log_app := ''apex.130.119'';',
'',
'	begin',
unistr('		-- Verifico que haya registros establecidos para la sesi\00F3n.'),
unistr('		-- No podr\00E1 registrar fechas para otro documento que no sea el que busc\00F3.'),
'		select distinct num01,txt01 into v_documento,v_tipo from data.t_apex_temporal',
'		where control01 = v_log_cia and control02 = v_log_mod and control03 = v_log_usr and control04 = v_log_app;',
'',
'		exception',
'			when no_data_found then',
'				:p119_mensaje	:= ''Solo puede agregar fechas a un documento que tiene otras fechas.'';',
'				return;',
'			when others then',
unistr('				:p119_mensaje	:= ''No se pudo completar el proceso. Verifique los par\00E1metros.'';'),
'				return;',
'	end;',
'',
'	begin',
'		select count(1) into v_cantidad from f4305@jdedtadl',
'		where pldoco = v_documento and pldcto = v_tipo and trim(pllgty) = v_registro;',
'',
'		if v_cantidad = 1 then',
'			:p119_mensaje	:= ''Ya existe el tipo de registro que intenta guardar. No puede cambiarlo.'';',
'			return;',
'		elsif v_cantidad = 0 then',
'			-- Busco un ID',
'			pk_comp_ordenescompra.sp_seqf4305(v_secuencia);',
'			v_log_dsc := ''v_secuencia: ''||v_secuencia;',
'			data.pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,null,null,null); commit;',
'',
'			select rpad(drdl01,30,'' '') into v_descripcion from vt_jde_udcjde',
'			where drsy = ''00'' and drrt = ''LG'' and drky = v_registro and rownum = 1;',
'',
'			insert into f4305@jdedtadl (',
'				--',
'				plukid,pldoco,pldcto,plkcoo,pllgty,pldl01,plissu,',
'				--',
'				pllogh,plsfxo,plan8,plmcu,plomcu,pllgno,plstsc,plexr,plpaye,plexpr,plreqr,pldej,plancr,',
'				plcono,plrpt1,plrpt2,plrpt3,plsbcd,plu,plum,plusd1,plco,pluser,plpid,pljobn,plupmj,plupmt)',
'			select',
'				v_secuencia plukid,v_documento pldoco,v_tipo pldcto,v_log_cia plkcoo,v_registro pllgty,v_descripcion pldl01,v_fecha plissu,',
'				''01'' pllogh,''000'' plsfxo,0 plan8,''            '' plmcu,''            '' plomcu,0 pllgno,'' ''plstsc,''                              '' plexr,',
'				''N'' plpaye,0 plexpr,0 plreqr,0 pldej,0 plancr,',
'				0 plcono,''   '' plrpt1,''   '' plrpt2,''   '' plrpt3,'' '' plsbcd,0 plu,''  '' plum,0 plusd1,''     ''plco,''JDEDEV    ''pluser,''EP4305    '' plpid,',
'				''WEBSERVERJ'' pljobn,v_jde_hoy plupmj,to_number(to_char(sysdate,''hh24miss'')) plupmt',
'			from dual;',
'			v_cantidad := sql%rowcount;',
'',
'			if v_cantidad = 1 then',
'				delete from data.t_comp_generaocfecha where requisicion = v_documento and tiporequisicion = v_tipo;',
unistr('				:p119_mensaje	:= ''Se agreg\00F3 un registro en JDE y se elimin\00F3 los registros de Apex.'';'),
'			else',
unistr('				:p119_mensaje	:= ''No se agreg\00F3 registros. Verifique los par\00E1metros.'';'),
'			end if;',
'		else',
unistr('			:p119_mensaje	:= ''Hay m\00E1s de un registro del mismo tipo.'';'),
'			return;',
'		end if;',
'	end;',
'	commit;',
'end;'))
,p_attribute_02=>'P119_REGISTRO,P119_FECHA'
,p_attribute_03=>'P119_MENSAJE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(303952954897147545)
,p_event_id=>wwv_flow_imp.id(303952619397147542)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(303953028005147546)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Borrar Datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_log_cia		varchar2(99);',
'v_log_mod		varchar2(99);',
'v_log_usr		varchar2(99);',
'v_log_app		varchar2(99);',
'begin',
'	v_log_cia := :g_compania;',
'	v_log_mod := :app_modulo;',
'	v_log_usr := :app_user;',
'	v_log_app := ''apex.130.119'';',
'',
'	delete from data.t_apex_temporal',
'	where control01 = v_log_cia and control02 = v_log_mod and control03 = v_log_usr and control04 = v_log_app;',
'	:p119_mensaje := null;',
'	commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>303953028005147546
);
wwv_flow_imp.component_end;
end;
/
