prompt --application/pages/page_00125
begin
--   Manifest
--     PAGE: 00125
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>125
,p_name=>'Fechas OC'
,p_page_mode=>'MODAL'
,p_step_title=>'Fechas OC'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'21'
,p_created_on=>wwv_flow_imp.dz('20230708132653Z')
,p_last_updated_on=>wwv_flow_imp.dz('20230424180034Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43833121900620441)
,p_plug_name=>'Fechas'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select keyid,',
'REQUISICION, TIPOREQUISICION, PROVEEDOR, TIPOFECHA TIPO,',
'DESCRIPCION, FECHA',
'from T_COMP_GENERAOCFECHA',
'where ',
'REQUISICION = :p125_codigodocumento',
'and TIPOREQUISICION = :p125_tipo',
'and PROVEEDOR = :p125_proveedor;',
''))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P125_CODIGODOCUMENTO,P125_TIPO,P125_PROVEEDOR'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43833318093620443)
,p_name=>'KEYID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'KEYID'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43833453009620444)
,p_name=>'REQUISICION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'REQUISICION'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43833595914620445)
,p_name=>'TIPOREQUISICION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIPOREQUISICION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>50
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43833603822620446)
,p_name=>'PROVEEDOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROVEEDOR'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>60
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43833722783620447)
,p_name=>'TIPO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIPO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>70
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43833866522620448)
,p_name=>'DESCRIPCION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESCRIPCION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Descripcion'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>50
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43834059263620450)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_enable_hide=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43994691176911201)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_03=>'Y'
,p_enable_hide=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(45348621628234150)
,p_name=>'FECHA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHA'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DATE_PICKER'
,p_heading=>'Fecha'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>90
,p_value_alignment=>'CENTER'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(43833225763620442)
,p_internal_uid=>43833225763620442
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_max_row_count=>100000
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>false
,p_toolbar_buttons=>null
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>false
,p_download_formats=>null
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(44000539014911804)
,p_interactive_grid_id=>wwv_flow_imp.id(43833225763620442)
,p_static_id=>'193719'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(44000621005911804)
,p_report_id=>wwv_flow_imp.id(44000539014911804)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(44001104332911806)
,p_view_id=>wwv_flow_imp.id(44000621005911804)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(43833318093620443)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(44001659954911808)
,p_view_id=>wwv_flow_imp.id(44000621005911804)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(43833453009620444)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(44002140932911809)
,p_view_id=>wwv_flow_imp.id(44000621005911804)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(43833595914620445)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(44002650720911811)
,p_view_id=>wwv_flow_imp.id(44000621005911804)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(43833603822620446)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(44003173479911811)
,p_view_id=>wwv_flow_imp.id(44000621005911804)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(43833722783620447)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(44003661130911812)
,p_view_id=>wwv_flow_imp.id(44000621005911804)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(43833866522620448)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(44004670647911815)
,p_view_id=>wwv_flow_imp.id(44000621005911804)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(43834059263620450)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(46578339897813415)
,p_view_id=>wwv_flow_imp.id(44000621005911804)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(45348621628234150)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(129346705359446441)
,p_plug_name=>'Items'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(43994952382911204)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(43833121900620441)
,p_button_name=>'GUARDAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43832472148620434)
,p_name=>'P125_PROVEEDORNOMBRE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(129346705359446441)
,p_use_cache_before_default=>'NO'
,p_prompt=>'New'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION FROM VT_JDE_MAESTROPROVEEDOR',
'WHERE CODIGOPROVEEDOR = :P125_PROVEEDOR'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681811193037723)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43941884192283482)
,p_name=>'P125_CODIGODOCUMENTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(129346705359446441)
,p_prompt=>'New'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681811193037723)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43942204410283484)
,p_name=>'P125_TIPO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(129346705359446441)
,p_prompt=>'New'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681811193037723)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43942617095283484)
,p_name=>'P125_PROVEEDOR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(129346705359446441)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(43994794370911202)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(43833121900620441)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Fechas - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_only_for_changed_rows=>'N'
,p_internal_uid=>43994794370911202
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(43832241693620432)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'InsertaFechasPrimero'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_valida number;',
'begin',
'	v_valida := 0;',
'	select count(*) into v_valida from t_comp_generaocfecha where requisicion = :p125_codigodocumento and tiporequisicion = :p125_tipo and proveedor = :p125_proveedor;',
'',
'	if v_valida = 0 then',
'		if :p125_tipo = ''H3'' then',
'			insert into t_comp_generaocfecha (keyid,requisicion,tiporequisicion,tipofecha,fecha,proveedor,descripcion)',
'			select :p125_codigodocumento||:p125_tipo||trim(:p125_proveedor)||trim(pllgty)',
'				, :p125_codigodocumento requisicion',
'				, :p125_tipo tiporequisicion',
'				, pllgty tipo',
'				, data.pk_commons.f_jde2g(plissu) fecha',
'				, :p125_proveedor proveedor',
'				, case',
'					when pllgty = 1 then ''FECHA EMBARQUE''',
'					when pllgty = 2 then ''FECHA PUERTO''',
'					when pllgty = 3 then ''FECHA ZAIMELLA''',
'					when pllgty = 5 then ''FECHA PLANTA PROVEED.''',
'					end descripcion',
'			from f4305@jdedtadl',
'			where pldoco = :p125_codigodocumento',
'				and pldcto = :p125_tipo;',
'		end if;',
'',
'		if :p125_tipo = ''H1'' then',
'			insert into t_comp_generaocfecha (keyid,requisicion,tiporequisicion,tipofecha,fecha,proveedor,descripcion)',
'			select :p125_codigodocumento||:p125_tipo||trim(:p125_proveedor)||''3''',
'				, :p125_codigodocumento REQUISICION',
'				, :p125_tipo TIPOREQUISICION',
'				, 3 TIPO',
'				, to_date(sysdate,''dd/mm/yyyy'') fecha',
'				, :p125_proveedor proveedor',
'				, ''FECHA ZAIMELLA''',
'			from dual;',
'		end if;',
'	end if;',
'	commit;',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>43832241693620432
);
wwv_flow_imp.component_end;
end;
/
