prompt --application/pages/page_00128
begin
--   Manifest
--     PAGE: 00128
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>128
,p_name=>unistr('Informaci\00F3n adicional de OC')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Informaci\00F3n adicional de OC')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230708132654Z')
,p_last_updated_on=>wwv_flow_imp.dz('20230626145703Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(174457428311287120)
,p_plug_name=>'Items'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(45252132132724019)
,p_plug_name=>'Historial'
,p_parent_plug_id=>wwv_flow_imp.id(174457428311287120)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from t_comp_ocfechanueva where numerooc = :p128_codigodocumento',
'and tipooc = :p128_tipo and proveedor = :p128_proveedor and tiporegistro = :p128_tiporegistro;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P128_TIPOREGISTRO'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from t_comp_ocfechanueva where numerooc = :p128_codigodocumento',
'and tipooc = :p128_tipo and proveedor = :p128_proveedor and tiporegistro = :p128_tiporegistro;'))
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(45252203376724020)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'N'
,p_owner=>'CVACA'
,p_internal_uid=>45252203376724020
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45252311522724021)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45252400835724022)
,p_db_column_name=>'NUMEROOC'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Numerooc'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45252567378724023)
,p_db_column_name=>'TIPOOC'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tipooc'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45252641546724024)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45252740547724025)
,p_db_column_name=>'TIPOFECHA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Tipofecha'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P128_TIPOREGISTRO'
,p_display_condition2=>'FEC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45252890042724026)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Descripcion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45252975403724027)
,p_db_column_name=>'FECHA'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P128_TIPOREGISTRO'
,p_display_condition2=>'FEC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45253185660724029)
,p_db_column_name=>'FECHAMODIFICA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45253223574724030)
,p_db_column_name=>'ESTADO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Estado'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(97447256136002150)
,p_db_column_name=>'TIPOREGISTRO'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Tiporegistro'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(165580033754451203)
,p_db_column_name=>'USUARIOMODIFICA'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Usuariomodifica'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(45287610085832096)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'452877'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:NUMEROOC:TIPOOC:PROVEEDOR:TIPOFECHA:DESCRIPCION:FECHA:FECHAMODIFICA:ESTADO:TIPOREGISTRO'
,p_created_on=>wwv_flow_imp.dz('20230708132654Z')
,p_updated_on=>wwv_flow_imp.dz('20230708132654Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(45253374846724031)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(174457428311287120)
,p_button_name=>'Guardar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(158731226311706402)
,p_name=>'P128_TIPOREGISTRO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(174457428311287120)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(165579886904451201)
,p_name=>'P128_COMENTARIO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(174457428311287120)
,p_prompt=>'Comentario'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>1000
,p_cHeight=>3
,p_display_when=>'P128_TIPOREGISTRO'
,p_display_when2=>'COM'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295682014701037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(309875885249927801)
,p_name=>'P128_ORDENCOMPRA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(174457428311287120)
,p_prompt=>'Orden Compra'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(309875903573927802)
,p_name=>'P128_TIPOOC'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(174457428311287120)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(309876068020927803)
,p_name=>'P128_LINEA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(174457428311287120)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(309876173817927804)
,p_name=>'P128_PROVEEDOR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(174457428311287120)
,p_prompt=>'Proveedor'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_JDE_LIBRODIRECCIONES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct nombres as r, codigo as d from vt_jde_librodirecciones order by 1',
''))
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(309876266322927805)
,p_name=>'P128_TIPOCOMENTARIO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(174457428311287120)
,p_item_default=>'O'
,p_prompt=>'Comentario en'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>unistr('STATIC2:Orden de Compra;O,L\00EDnea;L')
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(309876309249927806)
,p_name=>'P128_NOTIFICAR'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(174457428311287120)
,p_item_default=>'N'
,p_prompt=>'Notificar'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'S'
,p_attribute_03=>unistr('S\00CD')
,p_attribute_04=>'N'
,p_attribute_05=>'NO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(309876403704927807)
,p_name=>'P128_PERSONA'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(174457428311287120)
,p_prompt=>'Persona'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select apellidos||'' ''||nombres nombre, coderp from vt_corp_usuario where estado = 1 and coderp is not null order by 1'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(165579928869451202)
,p_validation_name=>unistr('Validaci\00F3n')
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :p128_tiporegistro = ''COM'' and (trim(:p128_comentario) is null or length(:p128_comentario) = 0) then',
'	return false;',
'else',
'	return true;',
'end if;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'Debe ingresar el comentario.'
,p_when_button_pressed=>wwv_flow_imp.id(45253374846724031)
,p_associated_item=>wwv_flow_imp.id(165579886904451201)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(45253465726724032)
,p_name=>'Actualiza Fecha'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(45253374846724031)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(309876940045927812)
,p_event_id=>wwv_flow_imp.id(45253465726724032)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra()'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45253569553724033)
,p_event_id=>wwv_flow_imp.id(45253465726724032)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_aux		number;',
'v_fecha		varchar2(25);',
'v_linea		number;',
'v_tipcom	varchar2(1);',
'v_log_dsc	varchar2(100);',
'v_notificar	varchar2(1);',
'v_persona	number;',
'v_mensaje	clob;',
'v_cor_rem	varchar2(100);',
'v_cor_des	varchar2(100);',
'v_cor_ccp	varchar2(100);',
'v_cor_sub	varchar2(100);',
'v_log_app	varchar2(100);',
'v_txt_aux	varchar2(100);',
'begin',
'	v_aux		:= 0;',
'	v_tipcom	:= :p128_tipocomentario;',
'	v_log_app	:= ''apex.130.128'';',
'	v_cor_rem	:= ''notificacion@zaimella.com'';',
'',
'	if v_tipcom = ''O'' then',
'		v_linea := 0;',
'	elsif v_tipcom = ''L'' then',
'		v_linea := :p128_linea*1000;',
'	end if;',
'',
'	v_notificar	:= :p128_notificar;',
'	v_persona	:= :p128_persona;',
'',
'	v_log_dsc := ''p128_tiporegistro: ''||:p128_tiporegistro;',
'	v_log_dsc := v_log_dsc ||'', p128_tipocomentario: ''||:p128_tipocomentario;',
'	v_log_dsc := v_log_dsc ||'', p128_linea: ''||:p128_linea;',
'',
'	pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,null,null,null); commit;',
'',
'	if :p128_tiporegistro = ''FEC'' then',
unistr('		null; -- Ya no se har\00E1 registros de fechas'),
'	elsif :p128_tiporegistro = ''COM'' then',
'		insert into t_comp_infoadicionaloc (registro,tiporeg,ordencompra,tipooc,linea,informacion,estado) ',
'		select',
'			:p128_tiporegistro			registro',
'			, v_tipcom					tiporeg',
'			, :p128_ordencompra			ordencompra',
'			, :p303_tipoorden			tipooc',
'			, v_linea					linea',
'			, :p128_comentario			informacion',
'			, ''1''						estado',
'		from dual;',
'		commit;',
'',
'		if v_notificar = ''S'' then',
'			v_mensaje := ''<html><head><style type="text/css">',
'							body{font-family: Arial, Helvetica, sans-serif;font-size:10pt;margin:30px;background-color:#ffffff;}',
'							span.sig{font-style:italic;font-weight:bold;color:#811919;}}',
'							</style></head><meta charset="UTF-8"><body text="#000000">''||utl_tcp.crlf;',
'			v_mensaje := v_mensaje ||''<p>Estimado usuario, </p>''||utl_tcp.crlf;',
'',
'			begin',
'				select nombres||'' ''||apellidos, email into v_txt_aux, v_cor_ccp from vt_corp_usuario where nombreusuario = :app_user;',
'',
'				exception when others then',
'					v_txt_aux := ''-'';',
'					v_cor_ccp := v_cor_rem;',
'			end;',
'',
'			if v_txt_aux != ''-'' then',
'				v_mensaje := v_mensaje ||''<p><strong>''||v_txt_aux||''</strong> ha colocado un comentario ''||utl_tcp.crlf;',
'			else',
'				v_mensaje := v_mensaje ||''<p>Se ha colocado un comentario ''||utl_tcp.crlf;',
'			end if;',
'',
'			if v_linea = 0 then',
'				v_mensaje := v_mensaje ||''en la ''||utl_tcp.crlf;',
'			else',
'				select trim(imlitm)||'' - ''||trim(imdsc1) into v_txt_aux from f4311@jdedtadl inner join f4101@jdedtadl on pditm = imitm',
'				where pddoco = :p128_ordencompra and pddcto = :p303_tipoorden and pdlnid = v_linea and rownum = 1;',
'',
'				v_mensaje := v_mensaje ||''en el producto <strong>''||v_txt_aux||''</strong> de la ''||utl_tcp.crlf;',
'			end if;',
'',
'			v_mensaje := v_mensaje ||'' Orden de Compra <strong>''||:p128_ordencompra||'' - ''||:p303_tipoorden||''</strong>.</p>''||utl_tcp.crlf;',
'',
'			v_mensaje := v_mensaje ||''<p><i>''||upper(trim(:p128_comentario))||''</i></p>''||utl_tcp.crlf;',
'',
'			v_mensaje := v_mensaje || ''</body>'' || utl_tcp.crlf;',
'			v_mensaje := v_mensaje || ''</html>'' || utl_tcp.crlf;',
'',
'			begin',
'				select email into v_cor_des from vt_corp_usuario where coderp = v_persona and rownum = 1;',
'',
'				exception when others then',
'					v_cor_des := v_cor_ccp;',
'			end;',
'',
'			pk_commons.sp_apex_correohtml(v_mensaje,v_mensaje);',
'',
'			v_cor_sub := ''COMP - Comentario en Orden de Compra: ''||:p128_ordencompra||'' - ''||:p303_tipoorden;',
'',
'			-- v_cor_des := ''ddelacruz@zaimella.com''; v_cor_ccp := v_cor_des;',
'',
'			pk_commons.sp_apex_correo(',
'				p_aplicacion		=> v_log_app',
'				, p_remitente		=> v_cor_rem',
'				, p_para			=> v_cor_des',
'				, p_concopia		=> v_cor_ccp',
'				, p_concopiaoculta	=> null',
'				, p_asunto			=> v_cor_sub',
'				, p_contenido		=> v_mensaje',
'			);',
'		end if;',
'	end if;',
'	commit;',
'end;'))
,p_attribute_02=>'P128_TIPOREGISTRO,P128_PROVEEDOR,P128_ORDENCOMPRA,P128_TIPOOC,P128_LINEA,P128_TIPOCOMENTARIO,P128_COMENTARIO,P128_NOTIFICAR,P128_PERSONA'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45253693138724034)
,p_event_id=>wwv_flow_imp.id(45253465726724032)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(45252132132724019)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(309877026904927813)
,p_event_id=>wwv_flow_imp.id(45253465726724032)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra()'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(70674485382488429)
,p_event_id=>wwv_flow_imp.id(45253465726724032)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(309876533491927808)
,p_name=>'Notificar'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P128_NOTIFICAR'
,p_condition_element=>'P128_NOTIFICAR'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(309876611625927809)
,p_event_id=>wwv_flow_imp.id(309876533491927808)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P128_PERSONA'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(309876729298927810)
,p_event_id=>wwv_flow_imp.id(309876533491927808)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P128_PERSONA'
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
