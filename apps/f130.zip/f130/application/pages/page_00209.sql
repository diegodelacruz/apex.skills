prompt --application/pages/page_00209
begin
--   Manifest
--     PAGE: 00209
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>209
,p_name=>'dlgeditarh2'
,p_alias=>'DLGEDITARH2'
,p_page_mode=>'MODAL'
,p_step_title=>'Editar H2'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_created_on=>wwv_flow_imp.dz('20240423205901Z')
,p_last_updated_on=>wwv_flow_imp.dz('20250529173634Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(190516972437868249)
,p_plug_name=>'Comentarios para orden de compra'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(277044174289218368)
,p_plug_name=>'Formulario'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(185673212153245357)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(190516972437868249)
,p_button_name=>'GRABAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--success'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Grabar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(184019898455703742)
,p_name=>'P209_PROVEEDOR'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(277044174289218368)
,p_prompt=>'Proveedor'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_JDE_PROVEEDORES_HAB'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'	TRIM(ABALPH) AS DESCRIPCION,',
'	TRIM(ABTAX) AS IDENTIFICACION,',
'	ABAN8  AS CODIGO',
'FROM f0101@jdedtadl inner join f0401@jdedtadl on aban8 = a6an8',
'where 1 = 1',
'	and decode(a6ato,'' '',''Y'',''N'') = ''Y''',
'ORDER BY ABALPH'))
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250529173633Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(184019901510703743)
,p_name=>'P209_PRECIO_UNITARIO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(277044174289218368)
,p_prompt=>'Precio Unitario'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(184020066884703744)
,p_name=>'P209_DESCRIPCION_1'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(277044174289218368)
,p_prompt=>'Desc. 1'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(184020152072703745)
,p_name=>'P209_DESCRIPCION_2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(277044174289218368)
,p_prompt=>'Desc. 2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(185673564489245361)
,p_name=>'P209_PPGESTION_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(277044174289218368)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(185673999060245364)
,p_name=>'P209_CANTIDAD_ORGINAL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(277044174289218368)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(185674328100245364)
,p_name=>'P209_FECHA_COMPROMISO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(277044174289218368)
,p_prompt=>'Fecha Compromiso'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'ITEM'
,p_attribute_05=>'P209_MINIMUN_DATE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(185674708747245364)
,p_name=>'P209_CANTIDAD_MANUAL'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(277044174289218368)
,p_prompt=>'Cantidad'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'1'
,p_attribute_03=>'left'
,p_attribute_04=>'numeric'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(185675153206245365)
,p_name=>'P209_MINIMUN_DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(277044174289218368)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(185675539718245365)
,p_name=>'P209_CANTIDAD_REQUERIDA'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(277044174289218368)
,p_prompt=>'Cantidad Original'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(185675970197245365)
,p_name=>'P209_JUSTIFICACION'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(277044174289218368)
,p_prompt=>unistr('Justificaci\00F3n')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_inline_help_text=>unistr('Coloque una justificaci\00F3n en caso de cambiar la cantidad.')
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(185676372941245365)
,p_name=>'P209_EMAILS'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(277044174289218368)
,p_prompt=>'Emails'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>1
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_inline_help_text=>unistr('Ingrese las direcci\00F3nes de email separadas por coma.')
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(190516541020868245)
,p_name=>'P209_COMENTARIO_PROVEEDOR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(190516972437868249)
,p_prompt=>'Prov.'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>1500
,p_cHeight=>2
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'Y'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(190516698301868246)
,p_name=>'P209_COMENTARIO_APROBADOR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(190516972437868249)
,p_prompt=>'Apr.'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>2
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'Y'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(185676879290245369)
,p_validation_name=>unistr('Poner Justificaci\00F3n')
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P209_CANTIDAD_ORGINAL <> :P209_CANTIDAD_MANUAL AND (:P209_JUSTIFICACION IS NULL OR LENGTH(:P209_JUSTIFICACION) <5 ) ',
'    THEN RETURN FALSE;',
'    ELSE RETURN TRUE;',
'END IF;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>unistr('Debe poner una justificaci\00F3n.')
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(187268448121064719)
,p_validation_name=>'Proveedor tipo'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    V_PROVEEDOR_TIPO  VARCHAR2(100);',
'BEGIN        ',
'    -- Tipo de proveedor',
'    SELECT TIPO ',
'    INTO   V_PROVEEDOR_TIPO',
'    FROM   vt_jde_maestroproveedor ',
'    WHERE  codigoproveedor=:P209_PROVEEDOR;',
'    return true;',
'EXCEPTION WHEN OTHERS THEN ',
'    return false;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'Este proveedor no tiene un tipo en vt_jde_maestroproveedor .'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(185677918151245371)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Grabar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_COMP_GESTIONCOMPRAS.SP_SET_PPGESTION_DETALLES (',
'    P_PPGESTIONID      => :P209_PPGESTION_ID, ',
'    P_CODPROVEEDOR     => :P209_PROVEEDOR, ',
'    P_CANTIDAD_MANUAL  => :P209_CANTIDAD_MANUAL, ',
'    P_JUSTIFICACION    => :P209_JUSTIFICACION, ',
'    P_FECHA_COMPROMISO => :P209_FECHA_COMPROMISO,',
'    P_PRECIO_UNITARIO  => :P209_PRECIO_UNITARIO, ',
'    P_DESCRIPCION1     => :P209_DESCRIPCION_1, ',
'    P_DESCRIPCION2     => :P209_DESCRIPCION_2',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>185677918151245371
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(190516753231868247)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Grabar Comentarios'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_COMP_GESTIONCOMPRAS.SP_SET_PPGESTION_COMENTARIOS(',
'    :P209_PPGESTION_ID,',
'    :P209_COMENTARIO_PROVEEDOR,',
'    :P209_COMENTARIO_APROBADOR',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>190516753231868247
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(185677596551245371)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(185673212153245357)
,p_internal_uid=>185677596551245371
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(185678382936245371)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Minimum Date'
,p_process_sql_clob=>':P209_MINIMUN_DATE := TO_CHAR(TRUNC(SYSDATE+1), ''DD-MM-RRRR'');'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>185678382936245371
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(185677136217245370)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga Datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    CODPROVEEDOR,',
'    PRECIOUNITARIO,',
'',
'    CANTIDAD,',
'    NVL(CANTIDAD_MANUAL, CANTIDAD),',
'    EMAILS,',
'    FECHA_COMPROMISO,',
'    JUSTIFICACION,',
'',
'    NVL(CANTIDAD_MANUAL, CANTIDAD),',
'',
'    COMENTARIO_PROVEEDOR,',
'    COMENTARIO_APROBADOR,',
'',
'    DESCRIPCION1,',
'    DESCRIPCION2',
'INTO ',
'    :P209_PROVEEDOR,',
'    :P209_PRECIO_UNITARIO,',
'',
'    :P209_CANTIDAD_REQUERIDA,',
'    :P209_CANTIDAD_MANUAL,',
'    :P209_EMAILS,',
'    :P209_FECHA_COMPROMISO,',
'    :P209_JUSTIFICACION,',
'',
'    :P209_CANTIDAD_ORGINAL,',
'',
'    :P209_COMENTARIO_PROVEEDOR,',
'    :P209_COMENTARIO_APROBADOR,',
'',
'    :P209_DESCRIPCION_1,',
'    :P209_DESCRIPCION_2',
'FROM',
'    T_COMP_PRODTO_PROVEEDR_GESTION  ',
'WHERE ',
'    ID = :P209_PPGESTION_ID',
';',
'',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>185677136217245370
);
wwv_flow_imp.component_end;
end;
/
