prompt --application/pages/page_00516
begin
--   Manifest
--     PAGE: 00516
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>516
,p_name=>'COMEX - dlg AISV DAE'
,p_alias=>'COMEX-DLG-AISV-DAE'
,p_page_mode=>'MODAL'
,p_step_title=>'COMEX - AISV DAE'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_created_on=>wwv_flow_imp.dz('20241008145217Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240926163044Z')
,p_last_updated_by=>'DCUEVA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(313662107995288513)
,p_plug_name=>'Body'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(313661481742288506)
,p_plug_name=>'AISV'
,p_parent_plug_id=>wwv_flow_imp.id(313662107995288513)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>70
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>':P516_EDITAR_CARGUE = 0'
,p_plug_read_only_when2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(313661719901288509)
,p_plug_name=>'DAE'
,p_parent_plug_id=>wwv_flow_imp.id(313662107995288513)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>80
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>':P516_EDITAR_CARGUE = 0'
,p_plug_read_only_when2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(313662574064288517)
,p_plug_name=>unistr('Observaci\00F3n')
,p_parent_plug_id=>wwv_flow_imp.id(313662107995288513)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>90
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>':P516_EDITAR_CARGUE = 0'
,p_plug_read_only_when2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(313661979769288511)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(313662107995288513)
,p_button_name=>'GRABAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Grabar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>':P516_EDITAR_CARGUE = 1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(313665098138288542)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(313661719901288509)
,p_button_name=>'DESCARGA_DAE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(295682704716037726)
,p_button_image_alt=>'Descargar Archivo DAE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'&P516_DAE_LINK.'
,p_button_condition=>':P516_DAE_ARCHIVO IS NOT NULL'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-download'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(313664884068288540)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(313661481742288506)
,p_button_name=>'DESCARGA_AISV'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(295682704716037726)
,p_button_image_alt=>'Descargar Archivo AISV'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'&P516_AISV_LINK.'
,p_button_execute_validations=>'N'
,p_button_condition=>':P516_AISV_ARCHIVO IS NOT NULL'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-download'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(313663581789288527)
,p_branch_name=>'Go to 511 GRABAR'
,p_branch_action=>'f?p=&APP_ID.:511:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(313661979769288511)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(313661550784288507)
,p_name=>'P516_ARCHIVO_AISV_BROWSE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(313661481742288506)
,p_prompt=>'Subir Archivo AISV'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_display_when=>':P516_EDITAR_CARGUE = 1'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(313661828518288510)
,p_name=>'P516_ARCHIVO_DAE_BROWSE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(313661719901288509)
,p_prompt=>'Subir Archivo DAE'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_display_when=>':P516_EDITAR_CARGUE = 1'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(313662256426288514)
,p_name=>'P516_DAE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(313661719901288509)
,p_prompt=>'DAE'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(313662318967288515)
,p_name=>'P516_DATOS_GESTION_DETALLE_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(313662107995288513)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(313662417635288516)
,p_name=>'P516_CARGUE_OBSERVACION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(313662574064288517)
,p_prompt=>unistr('Cargue Observaci\00F3n')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(313662667212288518)
,p_name=>'P516_AISV_ARCHIVO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(313662107995288513)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(313662765296288519)
,p_name=>'P516_DAE_ARCHIVO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(313662107995288513)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(313663738764288529)
,p_name=>'P516_EDITAR_CARGUE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(313662107995288513)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(313664709006288539)
,p_name=>'P516_AISV_LINK'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(313662107995288513)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(313664940609288541)
,p_name=>'P516_DAE_LINK'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(313662107995288513)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(332268583386974033)
,p_validation_name=>'GRABAR'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P516_ARCHIVO_DAE_BROWSE IS NOT NULL AND :P516_DAE IS NULL THEN',
'    RETURN ''Debe ingresar un DAE'';',
'END IF;',
'',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(313661979769288511)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(313663160642288523)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga Detalle'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    CARGUE_OBSERVACION,',
'    AISV_ARCHIVO,',
'    DAE_ARCHIVO,',
'    DAE',
'INTO',
'    :P516_CARGUE_OBSERVACION,',
'    :P516_AISV_ARCHIVO,',
'    :P516_DAE_ARCHIVO,',
'    :P516_DAE',
'FROM',
'    VT_CMEX_DATOS_GESTION_DETALLE DET',
'WHERE',
'    DET.ID = :P516_DATOS_GESTION_DETALLE_ID',
';',
'',
':P516_AISV_LINK := PK_CMEX_GESTIONBOOKING.F_RECUPERA_PARAMETRO(''URL_FILES'', ''none'')||:P516_AISV_ARCHIVO;',
':P516_DAE_LINK  := PK_CMEX_GESTIONBOOKING.F_RECUPERA_PARAMETRO(''URL_FILES'', ''none'')||:P516_DAE_ARCHIVO;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>313663160642288523
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(313663651812288528)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GRABAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_DATOS_GESTION.SP_GRABA_CARGUE(',
'    :P516_DATOS_GESTION_DETALLE_ID,',
'    :APP_USER,',
'    :P516_CARGUE_OBSERVACION,',
'    :P516_ARCHIVO_AISV_BROWSE,',
'    :P516_ARCHIVO_DAE_BROWSE,',
'    :P516_DAE',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(313661979769288511)
,p_internal_uid=>313663651812288528
);
wwv_flow_imp.component_end;
end;
/
