prompt --application/pages/page_00501
begin
--   Manifest
--     PAGE: 00501
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>501
,p_name=>'COMEX - Booking'
,p_alias=>'COMEX-BOOKING'
,p_step_title=>'COMEX - Booking'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_created_on=>wwv_flow_imp.dz('20241224201233Z')
,p_last_updated_on=>wwv_flow_imp.dz('20251002211435Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(288012312362019707)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(288012775551019711)
,p_plug_name=>'Ingreso Seleccionar Tipo'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'P501_BOOKING_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(288012978363019713)
,p_plug_name=>'Ingreso de BOOKING'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P501_TIPO'
,p_plug_display_when_cond2=>'BOOKING'
,p_plug_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_read_only_when=>'P501_EDITAR_SOLICITUD'
,p_plug_read_only_when2=>'0'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(288013057783019714)
,p_plug_name=>'Ingreso de Reserva de Transporte'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P501_TIPO'
,p_plug_display_when_cond2=>'RESERVA'
,p_plug_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_read_only_when=>'P501_EDITAR_SOLICITUD'
,p_plug_read_only_when2=>'0'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(288013105055019715)
,p_plug_name=>'Ingreso Bloque comun'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P501_TIPO'
,p_plug_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_read_only_when=>'P501_EDITAR_SOLICITUD'
,p_plug_read_only_when2=>'0'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(288018326616035545)
,p_plug_name=>'&P501_TITULO.'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296122226350169167)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(289242312438856318)
,p_plug_name=>'Solicitado (administrador)'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P501_FECHA_SOLICITADO'
,p_plug_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_read_only_when=>'P501_EDITAR_INFORMACION'
,p_plug_read_only_when2=>'0'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(292840131502942304)
,p_plug_name=>'Footer info'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'EDITAR_SOLICITUD=&P501_EDITAR_SOLICITUD.  EDITAR_INFORMACION=&P501_EDITAR_INFORMACION.',
'',
''))
,p_plug_column_width=>'style="font-size: xx-small; color: lightgray;"'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(293430395644737109)
,p_plug_name=>'Pendiente (usuario)'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P501_ESTADO in (''PENDIENTE'', ''COMPLETADO'')'
,p_plug_display_when_cond2=>'PLSQL'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P501_ESTADO <> ''PENDIENTE'' ',
'    OR',
':P501_USUARIO <> :APP_USER'))
,p_plug_read_only_when2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(288012442318019708)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(288012312362019707)
,p_button_name=>'REGRESAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:500:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
,p_updated_on=>wwv_flow_imp.dz('20241227152459Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(293429556980737101)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(289242312438856318)
,p_button_name=>'ABRIR_ROLEAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Rolear'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P501_EDITAR_INFORMACION'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(293429695898737102)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(289242312438856318)
,p_button_name=>'ABRIR_ANULAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Anular'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P501_EDITAR_INFORMACION'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(295653013885943116)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(288012312362019707)
,p_button_name=>'HISTORIA'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Historia'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:503:&SESSION.::&DEBUG.:503:P503_P_ID:&P501_BOOKING_ID.'
,p_button_condition=>'P501_FECHA_SOLICITADO'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-h-square'
,p_updated_on=>wwv_flow_imp.dz('20241227152459Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(292839852723942301)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(288012312362019707)
,p_button_name=>'ENVIAR_SOLICITUD'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Enviar Solicitud'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P501_BOOKING_ID IS NOT NULL AND :P501_EDITAR_SOLICITUD = 1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-check-circle-o'
,p_updated_on=>wwv_flow_imp.dz('20241227152459Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(295045897708102703)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(288012312362019707)
,p_button_name=>'ENVIAR_PENDIENTE_PEDIDOS'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Enviar Pendiente Pedidos'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P501_EDITAR_INFORMACION=1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-check-circle-o'
,p_updated_on=>wwv_flow_imp.dz('20241227152459Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(297236209166438605)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(288012312362019707)
,p_button_name=>'ENVIAR_COMPLETADO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Enviar Completado'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P501_ESTADO = ''PENDIENTE'' AND :P501_USUARIO = :APP_USER'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-check-circle-o'
,p_updated_on=>wwv_flow_imp.dz('20241227152459Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(288015305416019737)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(288012312362019707)
,p_button_name=>'GRABAR_INGRESADO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Grabar Ingresado'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>':P501_BOOKING_ID IS NOT NULL AND :P501_EDITAR_SOLICITUD = 1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-save'
,p_updated_on=>wwv_flow_imp.dz('20241227152459Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(292842315755942326)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(288012312362019707)
,p_button_name=>'GRABAR_SOLICITADO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Grabar Solicitado'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>':P501_EDITAR_INFORMACION = 1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-save'
,p_updated_on=>wwv_flow_imp.dz('20241227152459Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(297236042749438603)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(288012312362019707)
,p_button_name=>'GRABAR_PEDIDOS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Grabar Pedidos'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>':P501_ESTADO = ''PENDIENTE'' AND :P501_USUARIO = :APP_USER'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-save'
,p_updated_on=>wwv_flow_imp.dz('20241227152459Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(683902995692132223)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(288012312362019707)
,p_button_name=>'ELIMINAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Eliminar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>':P501_ESTADO = ''INGRESADO'''
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-trash-o'
,p_created_on=>wwv_flow_imp.dz('20250430203904Z')
,p_updated_on=>wwv_flow_imp.dz('20250430204350Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(288015218351019736)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(288012775551019711)
,p_button_name=>'CREAR_NUEVO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--success'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Crear NUEVO'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P501_BOOKING_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_icon_css_classes=>'fa-save'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(292839946313942302)
,p_branch_name=>'Go To Page 500 ENVIAR_SOLICITUD'
,p_branch_action=>'f?p=&APP_ID.:500:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(292839852723942301)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(683903199064132225)
,p_branch_name=>'Go To Page 500 ELIMINAR REGISTRO'
,p_branch_action=>'f?p=&APP_ID.:500:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(683902995692132223)
,p_branch_sequence=>20
,p_created_on=>wwv_flow_imp.dz('20250430204254Z')
,p_updated_on=>wwv_flow_imp.dz('20250430204254Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(295046395931102708)
,p_branch_name=>'Go To Page 502 ABRIR ANULAR'
,p_branch_action=>'f?p=&APP_ID.:502:&SESSION.::&DEBUG.:502:P502_ACCION,P502_BOOKING_ID:ANULAR,&P501_BOOKING_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(293429695898737102)
,p_branch_sequence=>30
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(295651889739943104)
,p_branch_name=>'Go To Page 502 ABRIR ROLEAR'
,p_branch_action=>'f?p=&APP_ID.:502:&SESSION.::&DEBUG.:502:P502_ACCION,P502_BOOKING_ID:ROLEAR,&P501_BOOKING_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(293429556980737101)
,p_branch_sequence=>40
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(297235969098438602)
,p_branch_name=>'Go To Page 500 ENVIAR_PENDIENTE_PEDIDOS'
,p_branch_action=>'f?p=&APP_ID.:500:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(295045897708102703)
,p_branch_sequence=>50
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(297236535757438608)
,p_branch_name=>'Go To Page 500 ENVIAR_COMPLETADO'
,p_branch_action=>'f?p=&APP_ID.:500:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(297236209166438605)
,p_branch_sequence=>60
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(288012268578019706)
,p_name=>'P501_BOOKING_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(288018326616035545)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(288012502374019709)
,p_name=>'P501_TIPO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(288012775551019711)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Solicitud de BOOKING;BOOKING,Solicitud de Reserva de Transporte;RESERVA'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20251002210428Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(288013276461019716)
,p_name=>'P501_FECHA_PLAN_CARGUE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(288013105055019715)
,p_prompt=>'Fecha Plan Cargue'
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_read_only_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20250430210635Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(288013309832019717)
,p_name=>'P501_CLIENTE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(288013105055019715)
,p_prompt=>'Cliente'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'SELECT CODIGO||'' ''||NOMBRES, CODIGO FROM VT_JDE_CLIENTE where codigopais != ''EC'''
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251002210319Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(288013409306019718)
,p_name=>'P501_PUERTO_DESTINO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(288013105055019715)
,p_prompt=>'Puerto Destino'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>'select DISTINCT PUERTODESTINO_EXP from t_cmex_mesatrabajo WHERE PUERTODESTINO_EXP IS NOT NULL;'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'Y'
,p_attribute_05=>'7'
,p_attribute_09=>'1'
,p_attribute_10=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(288013581339019719)
,p_name=>'P501_INCOTERM'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(288013105055019715)
,p_prompt=>'Incoterm'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_INCOTERMS'
,p_lov=>'select DRKY ||'' - ''||upper(DRDL01) d,DRKY r from vt_jde_udcjde where drsy=''42'' and drrt=''FR'' and drky is not null order by upper(DRKY)'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20251002211435Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(288013633680019720)
,p_name=>'P501_CONTENEDORES_40'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(288012978363019713)
,p_prompt=>'Contenedores 40'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(288013778490019721)
,p_name=>'P501_CONTENEDORES_20'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(288012978363019713)
,p_prompt=>'Contenedores 20'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(288013893520019722)
,p_name=>'P501_CANTIDAD_VEHICULOS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(288013057783019714)
,p_prompt=>'Cantidad Vehiculos'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'1'
,p_attribute_02=>'999'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(288013941684019723)
,p_name=>'P501_TITULO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(288018326616035545)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(288014865802019732)
,p_name=>'P501_USUARIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(288013105055019715)
,p_prompt=>'Solicita'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P501_BOOKING_ID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(288014914508019733)
,p_name=>'P501_COMPANIA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(288018326616035545)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(288015024828019734)
,p_name=>'P501_ESTADO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(288013105055019715)
,p_prompt=>'Estado'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P501_BOOKING_ID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(288015159553019735)
,p_name=>'P501_FECHA_REGISTRO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(288013105055019715)
,p_prompt=>'Fecha'
,p_format_mask=>'DD-MON-YYYY HH24:MI'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P501_BOOKING_ID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(289241328562856308)
,p_name=>'P501_FECHA_MINIMA_CARGUE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(288018326616035545)
,p_source=>'SELECT TO_CHAR(SYSDATE-2, ''DD-MON-YYYY'') FROM DUAL;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250115151632Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(289241586948856310)
,p_name=>'P501_PEDIDOS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(293430395644737109)
,p_prompt=>'Pedidos'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct nombre, codigo from (',
'	select',
'		sddcto||''-''||sddoco  as nombre,',
'		sddcto||''-''||sddoco  as codigo',
'	from f4211@jdedtadl',
'	where 1 = 1',
'		and sddcto in (''VE'',''VJ'')',
'		and sdan8 = :p501_cliente',
'		and sdtrdj > pk_commons.f_g2jde(sysdate-180)',
'	union',
'	select',
'		sddcto||''-''||sddoco  as nombre,',
'		sddcto||''-''||sddoco  as codigo',
'	from f42119@jdedtadl',
'	where 1 = 1',
'		and sddcto in (''VE'',''VJ'')',
'		and sdan8 = :p501_cliente',
'		and sdtrdj > pk_commons.f_g2jde(sysdate-465)',
')',
'order by nombre desc'))
,p_lov_cascade_parent_items=>'P501_CLIENTE'
,p_ajax_items_to_submit=>'P501_CLIENTE'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>', '
,p_updated_on=>wwv_flow_imp.dz('20251002163234Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(289241606838856311)
,p_name=>'P501_FECHA_PEDIDO_REAL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(293430395644737109)
,p_prompt=>'Fecha Pedido Real'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_inline_help_text=>'Para obtener la Fecha Pedido Real debe previamente grabar los pedidos.'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(289242024556856315)
,p_name=>'P501_EDITAR_SOLICITUD'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(288018326616035545)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(289242167967856316)
,p_name=>'P501_EDITAR_INFORMACION'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(288018326616035545)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(289242445105856319)
,p_name=>'P501_FECHA_SOLICITADO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(289242312438856318)
,p_prompt=>'Solicitado'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(292841078098942313)
,p_name=>'P501_NAVIERA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(289242312438856318)
,p_prompt=>'Naviera'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>'select distinct naviera from t_cmex_mesatrabajo order by 1;'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'Y'
,p_attribute_05=>'7'
,p_attribute_09=>'1'
,p_attribute_10=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(292841275179942315)
,p_name=>'P501_FORWARDER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(289242312438856318)
,p_prompt=>'Forwarder'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>'select distinct forwarder from t_cmex_mesatrabajo ORDER BY 1;'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'Y'
,p_attribute_05=>'7'
,p_attribute_09=>'1'
,p_attribute_10=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(292841396652942316)
,p_name=>'P501_PALLETS'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(289242312438856318)
,p_prompt=>'Pallets'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_display_when=>'1 = 0'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'0'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_updated_on=>wwv_flow_imp.dz('20251002162535Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(292841443490942317)
,p_name=>'P501_TERMINAL_PORTUARIO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(289242312438856318)
,p_prompt=>'Terminal Portuario'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'',
'    DESCRIPCION AS NOMBRE,',
'    ID_TABLA    AS ID',
'',
'FROM T_CORP_UDC',
'WHERE ID_CABECERA=''RCDP_TERMI''',
'ORDER BY DESCRIPCION',
';'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(292841536976942318)
,p_name=>'P501_PATIO_RETIRO'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(289242312438856318)
,p_prompt=>'Patio Retiro'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    DESCRIPCION AS NOMBRE,',
'    ID_TABLA    AS ID    ',
'FROM T_CORP_UDC',
'WHERE ID_CABECERA=''CMEX_BDGS''',
'ORDER BY DESCRIPCION',
';'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(292841648629942319)
,p_name=>'P501_CUT_OFF_FISICO'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(289242312438856318)
,p_prompt=>'Cut Off Fisico'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20250115154521Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(292841775449942320)
,p_name=>'P501_FECHA_ZARPE_ESTIMADA'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(289242312438856318)
,p_prompt=>'Fecha Zarpe'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20250115154521Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(292841893462942321)
,p_name=>'P501_CUT_OFF_DOCUMENTAL'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(289242312438856318)
,p_prompt=>'Cut off Doc.'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20250115154444Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(292841949300942322)
,p_name=>'P501_FECHA_MINIMA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(288018326616035545)
,p_source=>'SELECT TO_CHAR(SYSDATE-2, ''YYYY-MM-DD'') FROM DUAL;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250115152714Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(292842073162942323)
,p_name=>'P501_FECHA_MAX_CANCELACION'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(289242312438856318)
,p_prompt=>unistr('Fecha m\00E1xima de cancelaci\00F3n')
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20250115154521Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(292842152416942324)
,p_name=>'P501_COSTO_CANCELACION'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(289242312438856318)
,p_prompt=>unistr('Costo por cancelaci\00F3n')
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'0'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(292842204525942325)
,p_name=>'P501_COSTO_ROLEO'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(289242312438856318)
,p_prompt=>'Costo por roleo'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'0'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(293430594990737111)
,p_name=>'P501_NUMERO_BK'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(289242312438856318)
,p_prompt=>unistr('N\00FAmero BK')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(293430652778737112)
,p_name=>'P501_SOLICITUD_ESTADO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(289242312438856318)
,p_prompt=>'Solicitud Estado'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:Reservado;RESERVADO,No Disponible;NO_DISPONIBLE'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'1 = 0'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20251002162449Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(293430708801737113)
,p_name=>'P501_DESTINO'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(289242312438856318)
,p_prompt=>'Destino'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ID_TABLA||'' - ''||DESCRIPCION AS NOMBRE,',
'    ID_TABLA    AS ID',
'FROM T_CORP_UDC',
'WHERE ID_CABECERA=''1228''',
'ORDER BY DESCRIPCION;',
'    '))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(293430841369737114)
,p_name=>'P501_PUERTO_ORIGEN'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(289242312438856318)
,p_prompt=>'Puerto Origen'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select distinct VALOR AS NAME, VALOR  AS CODE  from t_corp_udc where id_cabecera = ''CMEX_BDGS'' and valor is not null'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295045637048102701)
,p_name=>'P501_CENTRO_COSTO'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(289242312438856318)
,p_prompt=>'Centro de costo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    DESCRIPCION,',
'    TRIM(UNIDADNEGOCIO) AS UNIDADNEGOCIO',
'FROM VT_JDE_UNIDADESNEGOCIO',
'ORDER BY DESCRIPCION;'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(288015494273019738)
,p_validation_name=>'CREAR_NUEVO'
,p_validation_sequence=>10
,p_validation=>'P501_TIPO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'Debe seleccionar un tipo'
,p_when_button_pressed=>wwv_flow_imp.id(288015218351019736)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(293430413454737110)
,p_validation_name=>'ENVIAR_SOLICITUD'
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P501_FECHA_PLAN_CARGUE IS NULL THEN',
'    RETURN ''Debe ingresar la fecha plan cargue'';',
'END IF;',
'',
'IF :P501_CLIENTE IS NULL THEN',
'    RETURN ''Debe seleccionar un cliente'';',
'END IF;',
'',
'IF :P501_PUERTO_DESTINO IS NULL THEN',
'    RETURN ''Debe seleccionar un puerto destino'';',
'END IF;',
'',
'IF :P501_TIPO = ''BOOKING'' AND NVL(:P501_CONTENEDORES_40, 0) = 0 AND NVL(:P501_CONTENEDORES_20, 0) = 0 THEN',
'    RETURN ''Debe detallar la cantidad de contenedores'';',
'END IF;',
'',
'IF :P501_TIPO = ''RESERVA'' AND NVL(:P501_CANTIDAD_VEHICULOS, 0) = 0 THEN',
unistr('    RETURN ''Debe detallar la cantidad de veh\00EDculos'';'),
'END IF;',
'',
'IF :P501_INCOTERM IS NULL THEN',
'    RETURN ''Debe seleccionar un INCOTERM'';',
'END IF;',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(292839852723942301)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(293431008380737116)
,p_validation_name=>'ENVIAR_PENDIENTE'
,p_validation_sequence=>40
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P501_TIPO = ''BOOKING'' THEN',
'    IF :P501_NUMERO_BK IS NULL THEN',
'        RETURN ''Debe ingresar el NUMERO BK'';',
'    END IF;',
'    IF :P501_NAVIERA IS NULL THEN',
'        RETURN ''Debe detallar la NAVIERA'';',
'    END IF;',
'    IF :P501_FORWARDER IS NULL THEN',
'        RETURN ''Debe detallar el FORWARDER'';',
'    END IF;',
'',
'    IF :P501_TERMINAL_PORTUARIO IS NULL THEN',
'        RETURN ''Debe detallar el TERMINAL PORTUARIO'';',
'    END IF;',
'    IF :P501_PATIO_RETIRO IS NULL THEN',
'        RETURN ''Debe detallar el PATIO RETIRO'';',
'    END IF;    ',
'END IF;',
'',
'IF :P501_DESTINO IS NULL THEN',
'    RETURN ''Debe detallar el DESTINO'';',
'END IF;',
'',
'IF :P501_PUERTO_ORIGEN IS NULL THEN',
'    RETURN ''Debe detallar el PUERTO ORIGEN'';',
'END IF;',
'',
'',
'',
'IF :P501_CUT_OFF_DOCUMENTAL IS NULL THEN',
'    RETURN ''Debe detallar el CUT OFF DOCUMENTAL'';',
'END IF;',
'',
'IF :P501_CUT_OFF_FISICO IS NULL THEN',
'    RETURN ''Debe detallar el CUT OFF FISICO'';',
'END IF;',
'',
'IF :P501_FECHA_ZARPE_ESTIMADA IS NULL THEN',
'    RETURN ''Debe detallar la FECHA ZARPE ESTIMADA'';',
'END IF;',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(295045897708102703)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(295046711797102712)
,p_validation_name=>'ABRIR_ANULAR'
,p_validation_sequence=>50
,p_validation=>'P501_COSTO_CANCELACION'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>unistr('Debe ingresar el costo por cancelaci\00F3n.')
,p_when_button_pressed=>wwv_flow_imp.id(293429695898737102)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(295651517291943101)
,p_validation_name=>'ABRIR_ROLEAR'
,p_validation_sequence=>60
,p_validation=>'P501_COSTO_ROLEO'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>'Debe ingresar el costo por roleo.'
,p_when_button_pressed=>wwv_flow_imp.id(293429556980737101)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(297236379989438606)
,p_validation_name=>'ENVIAR_COMPLETADO'
,p_validation_sequence=>70
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P501_PEDIDOS IS NULL THEN',
'    RETURN ''Debe ingresar los pedidos'';',
'END IF;',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(297236209166438605)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(292840738215942310)
,p_name=>'ENVIAR_SOLICITUD'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(292839852723942301)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(292840884859942311)
,p_event_id=>wwv_flow_imp.id(292840738215942310)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Enviar Solicitud ?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(292840928842942312)
,p_event_id=>wwv_flow_imp.id(292840738215942310)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'ENVIAR_SOLICITUD'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(297236697893438609)
,p_name=>'ENVIAR_PENDIENTE_PEDIDOS'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(295045897708102703)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(297236715143438610)
,p_event_id=>wwv_flow_imp.id(297236697893438609)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Desea enviar a solicitar los PEDIDOS ?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(297236832750438611)
,p_event_id=>wwv_flow_imp.id(297236697893438609)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'ENVIAR_PENDIENTE_PEDIDOS'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(297236910412438612)
,p_name=>'ENVIAR_COMPLETADO'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(297236209166438605)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(297237085234438613)
,p_event_id=>wwv_flow_imp.id(297236910412438612)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Dar por completado el BOOKING ?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(297237156251438614)
,p_event_id=>wwv_flow_imp.id(297236910412438612)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'ENVIAR_COMPLETADO'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(288015832750019742)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CREAR_NUEVO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_GESTIONBOOKING.SP_NUEVO_BOOKING(',
'    :G_COMPANIA,',
'    :APP_USER,',
'    :P501_TIPO,',
'    ----------',
'    :P501_BOOKING_ID',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(288015218351019736)
,p_internal_uid=>288015832750019742
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(288016316844019747)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GRABAR_INGRESADO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_GESTIONBOOKING.SP_GRABA_BOOKING(',
'    :P501_BOOKING_ID,',
'    ----------------------------',
'    :P501_CLIENTE,',
'    :P501_FECHA_PLAN_CARGUE,',
'    :P501_PUERTO_DESTINO,',
'    :P501_INCOTERM,',
'    ------------------',
'    :P501_CONTENEDORES_40,',
'    :P501_CONTENEDORES_20,',
'    ------------------',
'    :P501_CANTIDAD_VEHICULOS',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(288015305416019737)
,p_internal_uid=>288016316844019747
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(292840073084942303)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ENVIAR_SOLICITUD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_GESTIONBOOKING.SP_GRABA_BOOKING(',
'    :P501_BOOKING_ID,',
'    ----------------------------',
'    :P501_CLIENTE,',
'    :P501_FECHA_PLAN_CARGUE,',
'    :P501_PUERTO_DESTINO,',
'    :P501_INCOTERM,',
'    ------------------',
'    :P501_CONTENEDORES_40,',
'    :P501_CONTENEDORES_20,',
'    ------------------',
'    :P501_CANTIDAD_VEHICULOS',
');',
'------------------------------',
'PK_CMEX_GESTIONBOOKING.SP_ENVIAR_SOLICITUD(:P501_BOOKING_ID, :APP_USER);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(292839852723942301)
,p_internal_uid=>292840073084942303
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(292842453303942327)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GRABAR_SOLICITADO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_GESTIONBOOKING.SP_GRABA_BOOKING_INF(',
'    :P501_BOOKING_ID,',
'    ----------------------------',
'    :P501_NUMERO_BK,',
'    :P501_SOLICITUD_ESTADO,',
'',
'    :P501_NAVIERA,',
'    :P501_FORWARDER,',
'    :P501_TERMINAL_PORTUARIO,',
'',
'    :P501_DESTINO,',
'    :P501_PUERTO_ORIGEN,',
'    :P501_PATIO_RETIRO,',
'',
'    :P501_PALLETS,',
'',
'    :P501_CUT_OFF_DOCUMENTAL,',
'    :P501_CUT_OFF_FISICO,',
'    :P501_FECHA_ZARPE_ESTIMADA,',
'    ',
'    :P501_FECHA_MAX_CANCELACION,',
'    :P501_COSTO_CANCELACION,',
'    :P501_COSTO_ROLEO',
');',
'update T_CMEX_BOOKING x set x.FECHA_PLAN_CARGUE = :P501_FECHA_PLAN_CARGUE where x.id = :P501_BOOKING_ID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(292842315755942326)
,p_internal_uid=>292842453303942327
,p_updated_on=>wwv_flow_imp.dz('20250430211029Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(295046233979102707)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ABRIR_ANULAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_GESTIONBOOKING.SP_GRABA_BOOKING_INF(',
'    :P501_BOOKING_ID,',
'    ----------------------------',
'    :P501_NUMERO_BK,',
'    :P501_SOLICITUD_ESTADO,',
'',
'    :P501_NAVIERA,',
'    :P501_FORWARDER,',
'    :P501_TERMINAL_PORTUARIO,',
'',
'    :P501_DESTINO,',
'    :P501_PUERTO_ORIGEN,',
'    :P501_PATIO_RETIRO,',
'',
'    :P501_PALLETS,',
'',
'    :P501_CUT_OFF_DOCUMENTAL,',
'    :P501_CUT_OFF_FISICO,',
'    :P501_FECHA_ZARPE_ESTIMADA,',
'    ',
'    :P501_FECHA_MAX_CANCELACION,',
'    :P501_COSTO_CANCELACION,',
'    :P501_COSTO_ROLEO',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(293429695898737102)
,p_internal_uid=>295046233979102707
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(295651632809943102)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ABRIR_ROLEAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_GESTIONBOOKING.SP_GRABA_BOOKING_INF(',
'    :P501_BOOKING_ID,',
'    ----------------------------',
'    :P501_NUMERO_BK,',
'    :P501_SOLICITUD_ESTADO,',
'',
'    :P501_NAVIERA,',
'    :P501_FORWARDER,',
'    :P501_TERMINAL_PORTUARIO,',
'',
'    :P501_DESTINO,',
'    :P501_PUERTO_ORIGEN,',
'    :P501_PATIO_RETIRO,',
'',
'    :P501_PALLETS,',
'',
'    :P501_CUT_OFF_DOCUMENTAL,',
'    :P501_CUT_OFF_FISICO,',
'    :P501_FECHA_ZARPE_ESTIMADA,',
'    ',
'    :P501_FECHA_MAX_CANCELACION,',
'    :P501_COSTO_CANCELACION,',
'    :P501_COSTO_ROLEO',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(293429556980737101)
,p_internal_uid=>295651632809943102
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(297235853622438601)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ENVIAR_PENDIENTE_PEDIDOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_GESTIONBOOKING.SP_GRABA_BOOKING_INF(',
'    :P501_BOOKING_ID,',
'    ----------------------------',
'    :P501_NUMERO_BK,',
'    :P501_SOLICITUD_ESTADO,',
'',
'    :P501_NAVIERA,',
'    :P501_FORWARDER,',
'    :P501_TERMINAL_PORTUARIO,',
'',
'    :P501_DESTINO,',
'    :P501_PUERTO_ORIGEN,',
'    :P501_PATIO_RETIRO,',
'',
'    :P501_PALLETS,',
'',
'    :P501_CUT_OFF_DOCUMENTAL,',
'    :P501_CUT_OFF_FISICO,',
'    :P501_FECHA_ZARPE_ESTIMADA,',
'    ',
'    :P501_FECHA_MAX_CANCELACION,',
'    :P501_COSTO_CANCELACION,',
'    :P501_COSTO_ROLEO',
');',
'------------------------------',
'PK_CMEX_GESTIONBOOKING.SP_ENVIAR_PENDIENTE_PEDIDOS(:P501_BOOKING_ID, :APP_USER);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(295045897708102703)
,p_internal_uid=>297235853622438601
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(297236173476438604)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GRABAR_PEDIDOS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_GESTIONBOOKING.SP_GRABA_BOOKING_PEDIDOS(',
'    :P501_BOOKING_ID,',
'    :P501_PEDIDOS',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(297236042749438603)
,p_internal_uid=>297236173476438604
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(297236420615438607)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ENVIAR_COMPLETADO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_GESTIONBOOKING.SP_GRABA_BOOKING_PEDIDOS(',
'    :P501_BOOKING_ID,',
'    :P501_PEDIDOS',
');',
'--------------------------',
'',
'PK_CMEX_GESTIONBOOKING.SP_ENVIAR_COMPLETADO(',
'    :P501_BOOKING_ID,',
'    :APP_USER',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(297236209166438605)
,p_internal_uid=>297236420615438607
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(683903003398132224)
,p_process_sequence=>110
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Eliminar Registro'
,p_process_sql_clob=>'update data.t_cmex_booking x set x.estado = ''ELIMINADO'' where id = :p501_booking_id;'
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'No se pudo eliminar el registro.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(683902995692132223)
,p_process_when=>':P501_ESTADO = ''INGRESADO'''
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_process_success_message=>'Registro Eliminado.'
,p_internal_uid=>683903003398132224
,p_created_on=>wwv_flow_imp.dz('20250430203904Z')
,p_updated_on=>wwv_flow_imp.dz('20250430204446Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(288014731684019731)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga BOOKING'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P501_BOOKING_ID IS NOT NULL THEN',
'    SELECT',
'        COMPANIA, USUARIO, ESTADO,',
'        TIPO,',
'        CLIENTE, PUERTO_DESTINO, INCOTERM,',
'        CONTENEDORES_40, CONTENEDORES_20, CANTIDAD_VEHICULOS,',
'',
'        PEDIDOS, FECHA_PEDIDO_REAL,',
'        ',
'        TO_CHAR(FECHA_REGISTRO, ''DD/MM/YYYY HH24:MI''),',
'        TO_CHAR(FECHA_PLAN_CARGUE, ''DD-MM-YYYY''),',
'		',
'		------------------------------',
'',
'        TO_CHAR(FECHA_SOLICITADO, ''DD/MM/YYYY HH24:MI''),',
'',
'		NAVIERA, FORWARDER, TERMINAL_PORTUARIO, ',
'		DESTINO, PUERTO_ORIGEN, PATIO_RETIRO,',
'		',
'        PALLETS, 		',
'        CUT_OFF_DOCUMENTAL, CUT_OFF_FISICO, FECHA_ZARPE_ESTIMADA,',
'',
'        FECHA_MAX_CANCELACION, COSTO_CANCELACION, COSTO_ROLEO,',
'        CENTRO_COSTO',
'    INTO',
'        :P501_COMPANIA, :P501_USUARIO, :P501_ESTADO,',
'        :P501_TIPO,',
'        :P501_CLIENTE, :P501_PUERTO_DESTINO, :P501_INCOTERM,',
'        :P501_CONTENEDORES_40, :P501_CONTENEDORES_20, :P501_CANTIDAD_VEHICULOS,',
'',
'        :P501_PEDIDOS, :P501_FECHA_PEDIDO_REAL,',
'',
'        :P501_FECHA_REGISTRO,',
'        :P501_FECHA_PLAN_CARGUE,',
'',
'		------------------------------',
'		',
'        :P501_FECHA_SOLICITADO,',
'',
'		:P501_NAVIERA, :P501_FORWARDER, :P501_TERMINAL_PORTUARIO,',
'		:P501_DESTINO, :P501_PUERTO_ORIGEN, :P501_PATIO_RETIRO,',
'		',
'		:P501_PALLETS, ',
'        :P501_CUT_OFF_DOCUMENTAL, :P501_CUT_OFF_FISICO, :P501_FECHA_ZARPE_ESTIMADA,',
'',
'        :P501_FECHA_MAX_CANCELACION, :P501_COSTO_CANCELACION, :P501_COSTO_ROLEO,',
'        :P501_CENTRO_COSTO',
'    FROM',
'        T_CMEX_BOOKING',
'    WHERE',
'        ID = :P501_BOOKING_ID;',
'    ',
'END IF;',
'',
':P501_EDITAR_SOLICITUD   := 0;',
':P501_EDITAR_INFORMACION := 0;',
'',
'IF :P501_ESTADO = ''INGRESADO'' AND :P501_USUARIO = :APP_USER THEN ',
'    :P501_EDITAR_SOLICITUD   := 1;',
'END IF;',
'',
'IF :P501_ESTADO = ''SOLICITADO'' AND PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES(''CMEX'', :APP_USER, :APP_PAGE_ID, ''INFORMACION'')=1 THEN ',
'    :P501_EDITAR_INFORMACION  := 1;',
'END IF;',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>288014731684019731
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(288012690969019710)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga Titulo'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    IF :P501_BOOKING_ID IS NULL THEN',
'        :P501_TITULO := ''Nueva solicitud de BOOKING'';',
'    END IF;',
'',
'    IF :P501_BOOKING_ID IS NOT NULL THEN',
'        :P501_TITULO := ''Solicitud de ''||:P501_TIPO||'' Nro. ''||:P501_BOOKING_ID;',
'    END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>288012690969019710
);
wwv_flow_imp.component_end;
end;
/
