prompt --application/pages/page_00137
begin
--   Manifest
--     PAGE: 00137
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>137
,p_name=>unistr('Negociaci\00F3n - Mesa de Trabajo')
,p_step_title=>unistr('Negociaci\00F3n - Mesa de Trabajo')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();',
'$(secItems).hide();'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-button.a-IRR-sortWidget-button[data-option="hide"], .a-IRR-button.a-IRR-sortWidget-button[data-option="freeze"]{',
'    display:none;',
'}',
'.a-IG-controls-item--aggregate, .a-IG-controls-item--controlBreak, .a-IG-controls-item--groupBy, .a-IG-reportSummary-item--aggregate, .a-IG-reportSummary-item--controlBreak, .a-IG-reportSummary-item--groupBy, .a-IRR-controls-item--aggregate, .a-IRR-c'
||'ontrols-item--controlBreak, .a-IRR-controls-item--groupBy, .a-IRR-reportSummary-item--aggregate, .a-IRR-reportSummary-item--controlBreak, .a-IRR-reportSummary-item--groupBy {',
'    --a-report-controls-cell-label-icon-background-color: #3b83bd;',
'    --a-report-controls-cell-label-hover-background-color: #e6f0f7;',
'    display: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240119194139Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260721142437Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(134656173088615749)
,p_plug_name=>'Negociaciones'
,p_region_name=>'rptRutaAprobacion'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    case',
'        when estadoflujo = ''CREACION''  then 0',
'        when estadoflujo = ''EN RUTA''   then 1',
'        when estadoflujo = ''VIGENTE''   then 2',
'        when estadoflujo = ''APROBADO''  then 3',
'        when estadoflujo = ''CADUCADO''  then 4',
'        when estadoflujo = ''CANCELADO'' then 5',
'        else 9',
'    end orden',
'    , estadoflujo',
'	, case',
'		when estadoflujo = ''CREACION''  then 1',
'		when estadoflujo in (''APROBADO'',''VIGENTE'',''CADUCADO'',''CANCELADO'',''EN RUTA'') then 0',
'		end edicion',
'	, APEX_PAGE.GET_URL(',
'		P_APPLICATION	=> 130',
'		, P_PAGE		=> CASE WHEN ESTADOFLUJO = ''CREACION'' THEN 139 ELSE 138 END',
'		, P_ITEMS		=> ''G_IDNEGOCIACION,G_EDITNEGOCIACION,G_PAGNEGOCIACION''||case when ESTADOFLUJO != ''CREACION'' then '',P138_ESTADO_FLUJO'' end',
'		, P_VALUES		=> IDNEGOCIACION||'',''||DECODE(ESTADOFLUJO,''CREACION'',1, 0)||'',''||:APP_PAGE_ID||case when ESTADOFLUJO != ''CREACION'' then '',''||ESTADOFLUJO end',
'	) enlace',
'    , seleccion',
'    , idnegociacion negociacion',
'    , fechaflujo fecha',
'    , solicitante',
'    , aprobador',
'    , volumen',
'    , esquema tipo_esquema',
'    , case esquema',
'        WHEN ''PD'' THEN  (SELECT   CODIGOPRODUCTO || '' - '' ||  NOMBREPRODUCTO || '' '' || CODIGOALTERNO || '' - ['' || UNIDADCOMPRA || '']''',
'                         FROM VT_JDE_PRODUCTOS',
'                         WHERE CODIGOCORTO=CODESQUEMA',
'                           AND CODESTADO<>''O'' )',
'        WHEN ''PV'' THEN  (SELECT   CODIGOPROVEEDOR || '' - '' ||  DESCRIPCION',
'                         FROM  VT_JDE_MAESTROPROVEEDOR',
'                         WHERE CODIGOPROVEEDOR=CODESQUEMA)',
'        END ESQUEMA',
'    , VIGENCIADESDE VIGENCIA_DESDE',
'    , VIGENCIAHASTA VIGENCIA_HASTA',
'    , NEG_PAS "NEG. PASADAS"',
'    , NEG_SIM "NEG. SIMILARES"',
'    , RUTA',
'    , PK_CORP_FLUJOAPROBACION.F_GESTIONCOLOR(:APP_USER, APROBADOR, ESTADOFLUJO, :G_COMPANIA, :G_MODULO) CSS',
'    , APEX_PAGE.GET_URL(',
'          P_APPLICATION=>130,',
'          P_PAGE=>CASE WHEN ESTADOFLUJO IN (''CREACION'',''RECHAZADO'') THEN 139 ELSE 138 END,',
'          P_ITEMS=>''G_IDNEGOCIACION,G_EDITNEGOCIACION,G_PAGNEGOCIACION'',',
'          P_VALUES=>IDNEGOCIACION|| '',''|| DECODE(ESTADOFLUJO,''CREACION'',1,0)|| '',''|| :APP_PAGE_ID',
'      ) URL',
'    , APEX_PAGE.GET_URL(',
'          P_APPLICATION=>130,',
'          P_PAGE=>143,',
'          P_ITEMS=>''P143_NEG_ID_ACTUAL,P143_TIPO,G_PAGNEGOCIACION'',',
'          P_VALUES=>IDNEGOCIACION|| '',1,''|| :APP_PAGE_ID',
'      ) URLPAS',
'    , APEX_PAGE.GET_URL(',
'          P_APPLICATION=>130,',
'          P_PAGE=>143,',
'          P_ITEMS=>''P143_NEG_ID_ACTUAL,P143_TIPO,G_PAGNEGOCIACION'',',
'          P_VALUES=>IDNEGOCIACION|| '',2,''|| :APP_PAGE_ID',
'      ) URLSIM',
'    , objeto',
'    , objetoid',
'    , todo',
'    , observacion',
'    , tiponegociacion',
'    , recurrente',
'	, case when solicitante = :app_user then 0 else 1 end ordenusr',
'from data.vt_comp_mesatrabajoneg',
'where 1 = 1',
'    and estadoflujo in (''CREACION'',''EN RUTA'',''VIGENTE'',''APROBADO'',''CADUCADO'',''CANCELADO'')',
'    and (',
'        ( :p137_estado = 1',
'			and (',
'				(aprobador is not null and pk_corp_flujoaprobacion.f_aprobadorflujo(:app_user, aprobador, :g_modulo, :g_compania) = 1)',
'                or estadoflujo = ''CREACION''',
'			)',
'			or solicitante = :app_user',
'        )',
'        or',
'        ( :p137_estado = 2',
'          and (',
'                vigenciadesde <= :p137_fecha_fin',
'                and nvl(vigenciahasta, date ''9999-12-31'') >= :p137_fecha_inicio',
'          )',
'        )',
'    )',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P137_ESTADO,P137_USUARIO,P137_FECHA_INICIO,P137_FECHA_FIN'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P137_ESTADO in (1,2)'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_updated_on=>wwv_flow_imp.dz('20260721142437Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(134656254848615750)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>134656254848615750
,p_updated_on=>wwv_flow_imp.dz('20260721142437Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134788186490704801)
,p_db_column_name=>'SELECCION'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'<input type="checkbox" id="selectallocs">'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P137_ESGESTIONLOTE'
,p_display_condition2=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(135558533060707425)
,p_db_column_name=>'ESTADOFLUJO'
,p_display_order=>20
,p_column_identifier=>'V'
,p_column_label=>'Estado'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251230220225Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134788223883704802)
,p_db_column_name=>'NEGOCIACION'
,p_display_order=>40
,p_column_identifier=>'B'
,p_column_label=>unistr('Negociaci\00F3n')
,p_column_link=>'#ENLACE#'
,p_column_linktext=>'#NEGOCIACION#'
,p_column_link_attr=>'class="#CSS#" alert="#ESTADOFLUJO#"'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'00000'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251230211642Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153685853608519648)
,p_db_column_name=>'VOLUMEN'
,p_display_order=>50
,p_column_identifier=>'AP'
,p_column_label=>'Volumen'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(93622776312381838)
,p_db_column_name=>'TIPO_ESQUEMA'
,p_display_order=>60
,p_column_identifier=>'AH'
,p_column_label=>'Tipo Esquema'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(134249283510088347)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132103880209164519)
,p_db_column_name=>'ESQUEMA'
,p_display_order=>70
,p_column_identifier=>'AN'
,p_column_label=>'Esquema'
,p_allow_sorting=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122172600Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(93622948571381840)
,p_db_column_name=>'VIGENCIA_DESDE'
,p_display_order=>80
,p_column_identifier=>'AJ'
,p_column_label=>'Vig. Desde'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122173020Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(93623094527381841)
,p_db_column_name=>'VIGENCIA_HASTA'
,p_display_order=>90
,p_column_identifier=>'AK'
,p_column_label=>'Vig. Hasta'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122173020Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(93622678541381837)
,p_db_column_name=>'FECHA'
,p_display_order=>110
,p_column_identifier=>'AG'
,p_column_label=>'Fecha'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122193416Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(135558319215707423)
,p_db_column_name=>'SOLICITANTE'
,p_display_order=>120
,p_column_identifier=>'T'
,p_column_label=>'Solicitante'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122193459Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(135558484743707424)
,p_db_column_name=>'APROBADOR'
,p_display_order=>130
,p_column_identifier=>'U'
,p_column_label=>'Aprobador'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122193459Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153685913512519649)
,p_db_column_name=>'NEG. PASADAS'
,p_display_order=>140
,p_column_identifier=>'AQ'
,p_column_label=>'Neg. Pasadas'
,p_column_link=>'#URLPAS#'
,p_column_linktext=>'#NEG. PASADAS#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251229180313Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(153686099713519650)
,p_db_column_name=>'NEG. SIMILARES'
,p_display_order=>150
,p_column_identifier=>'AR'
,p_column_label=>'Neg. Similares'
,p_column_link=>'#URLSIM#'
,p_column_linktext=>'#NEG. SIMILARES#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251229180313Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134789474381704814)
,p_db_column_name=>'RUTA'
,p_display_order=>160
,p_column_identifier=>'N'
,p_column_label=>'<span class="fa fa-road" title="Ruta" ></span>'
,p_column_link=>'f?p=100:104:&SESSION.::&DEBUG.:RP,:G_OBJETO,G_OBJETO_ID,G_TODO:#OBJETO#,#OBJETOID#,#TODO##OBJETO_ID#,#TODO#'
,p_column_linktext=>'#RUTA#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(141912039511248146)
,p_db_column_name=>'ORDEN'
,p_display_order=>170
,p_column_identifier=>'AO'
,p_column_label=>'Orden'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122193321Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137374274181651948)
,p_db_column_name=>'CSS'
,p_display_order=>180
,p_column_identifier=>'Y'
,p_column_label=>'Css'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(134790458388704824)
,p_db_column_name=>'URL'
,p_display_order=>190
,p_column_identifier=>'Q'
,p_column_label=>'Url'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(140641792691536239)
,p_db_column_name=>'OBJETO'
,p_display_order=>200
,p_column_identifier=>'AB'
,p_column_label=>'Objeto'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154541446896234511)
,p_db_column_name=>'OBJETOID'
,p_display_order=>210
,p_column_identifier=>'AT'
,p_column_label=>'Objetoid'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154541391133234510)
,p_db_column_name=>'TODO'
,p_display_order=>230
,p_column_identifier=>'AS'
,p_column_label=>'Todo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(131997237330393724)
,p_db_column_name=>'URLPAS'
,p_display_order=>240
,p_column_identifier=>'AE'
,p_column_label=>'Urlpas'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(131997308898393725)
,p_db_column_name=>'URLSIM'
,p_display_order=>250
,p_column_identifier=>'AF'
,p_column_label=>'Urlsim'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183799722726709144)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>260
,p_column_identifier=>'AU'
,p_column_label=>unistr('Observaci\00F3n')
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240123210937Z')
,p_updated_on=>wwv_flow_imp.dz('20240123210937Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183799809961709145)
,p_db_column_name=>'TIPONEGOCIACION'
,p_display_order=>270
,p_column_identifier=>'AV'
,p_column_label=>unistr('Tipo Negociaci\00F3n')
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240123210937Z')
,p_updated_on=>wwv_flow_imp.dz('20240123211001Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(300483202297773206)
,p_db_column_name=>'RECURRENTE'
,p_display_order=>280
,p_column_identifier=>'AW'
,p_column_label=>'Recurrente'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240508220737Z')
,p_updated_on=>wwv_flow_imp.dz('20240508220737Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298881257107448549)
,p_db_column_name=>'EDICION'
,p_display_order=>290
,p_column_identifier=>'AX'
,p_column_label=>'Edicion'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251230210808Z')
,p_updated_on=>wwv_flow_imp.dz('20251230210808Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(298881304728448550)
,p_db_column_name=>'ENLACE'
,p_display_order=>300
,p_column_identifier=>'AY'
,p_column_label=>'Enlace'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251230211642Z')
,p_updated_on=>wwv_flow_imp.dz('20251230211642Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(371139735354976403)
,p_db_column_name=>'ORDENUSR'
,p_display_order=>310
,p_column_identifier=>'AZ'
,p_column_label=>'OU'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260302053637Z')
,p_updated_on=>wwv_flow_imp.dz('20260302053809Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(134798170409705230)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1347982'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ESTADOFLUJO:SELECCION:NEGOCIACION:RECURRENTE:VOLUMEN:TIPO_ESQUEMA:ESQUEMA:VIGENCIA_DESDE:VIGENCIA_HASTA:SOLICITANTE:APROBADOR:RUTA:'
,p_sort_column_1=>'ORDEN'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'ORDENUSR'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'NEGOCIACION'
,p_sort_direction_3=>'DESC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'0:0:0:0:0'
,p_break_enabled_on=>'0:0:0:0:0'
,p_created_on=>wwv_flow_imp.dz('20240119194140Z')
,p_updated_on=>wwv_flow_imp.dz('20260302054103Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(373582987866161786)
,p_report_id=>wwv_flow_imp.id(134798170409705230)
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ORDENUSR'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("ORDENUSR" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#fff9e1'
,p_created_on=>wwv_flow_imp.dz('20260302054103Z')
,p_updated_on=>wwv_flow_imp.dz('20260302054103Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(134790295102704822)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning'
,p_plug_template=>wwv_flow_imp.id(295605160997037667)
,p_plug_display_sequence=>50
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(139588400722163998)
,p_plug_name=>'Barra de accion'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(139588519658163999)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(140641673072536238)
,p_plug_name=>'Negociaciones'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(295630388916037685)
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'N',
  'rds_mode', 'STANDARD',
  'remember_selection', 'SESSION')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20251229180537Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(154544541602234542)
,p_plug_name=>'Aprobadas/Vigentes'
,p_region_name=>'rptNegociacionAprobada'
,p_parent_plug_id=>wwv_flow_imp.id(140641673072536238)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'	 CASE',
'	 	WHEN ESTADOFLUJO IN (''EN RUTA'')   THEN 0',
'	 	WHEN ESTADOFLUJO IN (''VIGENTE'')   THEN 1',
'	 	WHEN ESTADOFLUJO IN (''APROBADO'')  THEN 2',
'	 	WHEN ESTADOFLUJO IN (''CADUCADO'')  THEN 4',
'	 	WHEN ESTADOFLUJO IN (''CANCELADO'') THEN 5',
'             ELSE 9',
'          END ORDEN',
'	, ESTADOFLUJO',
'	, IDNEGOCIACION NEGOCIACION',
'	, FECHAFLUJO FECHA',
'	, SOLICITANTE',
'	, APROBADOR',
'	, VOLUMEN',
'	, ESQUEMA TIPO_ESQUEMA',
'	, CASE ESQUEMA  ',
'		WHEN ''PD'' THEN  (SELECT   CODIGOPRODUCTO || '' - '' ||  NOMBREPRODUCTO || '' ''|| CODIGOALTERNO  || '' - ['' ||  UNIDADCOMPRA || '']'' D   FROM VT_JDE_PRODUCTOS WHERE CODIGOCORTO=CODESQUEMA AND CODESTADO<>''O'' )',
'		WHEN ''PV'' THEN  (SELECT   CODIGOPROVEEDOR || '' - '' ||  DESCRIPCION D FROM  VT_JDE_MAESTROPROVEEDOR WHERE CODIGOPROVEEDOR=CODESQUEMA)',
'		END ESQUEMA',
'	, VIGENCIADESDE VIGENCIA_DESDE',
'	, VIGENCIAHASTA VIGENCIA_HASTA',
'	, NEG_PAS "NEG. PASADAS"',
'	, NEG_SIM "NEG. SIMILARES"',
'	, PK_CORP_FLUJOAPROBACION.F_GESTIONCOLOR(:APP_USER, APROBADOR, ESTADOFLUJO, :G_COMPANIA, :G_MODULO) CSS',
'	, APEX_PAGE.GET_URL(P_APPLICATION=>130,P_PAGE=>CASE WHEN ESTADOFLUJO IN (''CREACION'',''RECHAZADO'') THEN 139 ELSE 138 END,P_ITEMS=>''G_IDNEGOCIACION,G_EDITNEGOCIACION,G_PAGNEGOCIACION'',P_VALUES=>IDNEGOCIACION|| '',''|| DECODE(ESTADOFLUJO,''CREACION'',1, 0)|'
||'| '',''|| :APP_PAGE_ID)URL',
'	, APEX_PAGE.GET_URL(P_APPLICATION=>130,P_PAGE=>143 ,P_ITEMS=>''P143_NEG_ID_ACTUAL,P143_TIPO,G_PAGNEGOCIACION'',P_VALUES=>IDNEGOCIACION|| '',1,''|| :APP_PAGE_ID)URLPAS',
'	, APEX_PAGE.GET_URL(P_APPLICATION=>130,P_PAGE=>143 ,P_ITEMS=>''P143_NEG_ID_ACTUAL,P143_TIPO,G_PAGNEGOCIACION'',P_VALUES=>IDNEGOCIACION|| '',2,''|| :APP_PAGE_ID)URLSIM',
'	, OBSERVACION',
'	, TIPONEGOCIACION, recurrente',
'FROM DATA.VT_COMP_MESATRABAJONEG',
'WHERE 1 = 1',
'	AND ( (:P137_ESTADO = 1 AND APROBADOR IS NOT NULL AND  PK_CORP_FLUJOAPROBACION.F_APROBADORFLUJO(:APP_USER, APROBADOR, :G_MODULO, :G_COMPANIA) = 1)',
'		OR (:P137_ESTADO = 2 AND (TRUNC(FECHAFLUJO) BETWEEN (:P137_FECHA_INICIO) AND (:P137_FECHA_FIN)))',
'		)',
'	AND ESTADOFLUJO IN ( ''APROBADO'' ,''VIGENTE'')',
'    AND :P137_TIPO=''#rptNegociacionAprobada'' '))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P137_ESTADO,P137_USUARIO,P137_FECHA_INICIO,P137_FECHA_FIN,P137_TIPO'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P137_ESTADO =2'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20240522151708Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(154544638268234543)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>154544638268234543
,p_updated_on=>wwv_flow_imp.dz('20240522151708Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154544719438234544)
,p_db_column_name=>'ESTADOFLUJO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Estado'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154544970440234546)
,p_db_column_name=>'NEGOCIACION'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>unistr('Negociaci\00F3n')
,p_column_link=>'f?p=&APP_ID.:138:&SESSION.::&DEBUG.:RP,138:G_IDNEGOCIACION,G_EDITNEGOCIACION,G_PAGNEGOCIACION,P138_ESTADO_FLUJO,P138_OBJETO:#NEGOCIACION#,0,&APP_PAGE_ID.,#ESTADOFLUJO#,'
,p_column_linktext=>'#NEGOCIACION#'
,p_column_link_attr=>'class="#CSS#" alert="#ESTADOFLUJO#"'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'00000'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240221190805Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154633469000115410)
,p_db_column_name=>'VOLUMEN'
,p_display_order=>40
,p_column_identifier=>'N'
,p_column_label=>'Volumen'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154545183852234548)
,p_db_column_name=>'TIPO_ESQUEMA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Tipo Esquema'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(134249283510088347)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154633259076115408)
,p_db_column_name=>'ESQUEMA'
,p_display_order=>60
,p_column_identifier=>'L'
,p_column_label=>'Esquema'
,p_allow_sorting=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122172601Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154632624527115402)
,p_db_column_name=>'VIGENCIA_DESDE'
,p_display_order=>70
,p_column_identifier=>'H'
,p_column_label=>'Vig. Desde'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122173020Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154632741118115403)
,p_db_column_name=>'VIGENCIA_HASTA'
,p_display_order=>80
,p_column_identifier=>'I'
,p_column_label=>'Vig. Hasta'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122173020Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154545035032234547)
,p_db_column_name=>'FECHA'
,p_display_order=>90
,p_column_identifier=>'D'
,p_column_label=>'Fecha'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122193416Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154545238126234549)
,p_db_column_name=>'SOLICITANTE'
,p_display_order=>100
,p_column_identifier=>'F'
,p_column_label=>'Solicitante'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122193459Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154545317637234550)
,p_db_column_name=>'APROBADOR'
,p_display_order=>110
,p_column_identifier=>'G'
,p_column_label=>'Aprobador'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122193459Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154633585278115411)
,p_db_column_name=>'NEG. PASADAS'
,p_display_order=>120
,p_column_identifier=>'O'
,p_column_label=>'Neg. Pasadas'
,p_column_link=>'#URLPAS#'
,p_column_linktext=>'#NEG. PASADAS#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154633619910115412)
,p_db_column_name=>'NEG. SIMILARES'
,p_display_order=>130
,p_column_identifier=>'P'
,p_column_label=>'Neg. Similares'
,p_column_link=>'#URLSIM#'
,p_column_linktext=>'#NEG. SIMILARES#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154633345752115409)
,p_db_column_name=>'ORDEN'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>'Orden'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122193321Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154632851906115404)
,p_db_column_name=>'CSS'
,p_display_order=>150
,p_column_identifier=>'J'
,p_column_label=>'Css'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154632904570115405)
,p_db_column_name=>'URL'
,p_display_order=>160
,p_column_identifier=>'K'
,p_column_label=>'Url'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154633820199115414)
,p_db_column_name=>'URLPAS'
,p_display_order=>180
,p_column_identifier=>'Q'
,p_column_label=>'Urlpas'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154633940129115415)
,p_db_column_name=>'URLSIM'
,p_display_order=>190
,p_column_identifier=>'R'
,p_column_label=>'Urlsim'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183799919895709146)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>200
,p_column_identifier=>'S'
,p_column_label=>unistr('Observaci\00F3n')
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240123210937Z')
,p_updated_on=>wwv_flow_imp.dz('20240123210937Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183800044232709147)
,p_db_column_name=>'TIPONEGOCIACION'
,p_display_order=>210
,p_column_identifier=>'T'
,p_column_label=>unistr('Tipo Negociaci\00F3n')
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240123210937Z')
,p_updated_on=>wwv_flow_imp.dz('20240123211001Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(300483154668773205)
,p_db_column_name=>'RECURRENTE'
,p_display_order=>220
,p_column_identifier=>'U'
,p_column_label=>'Recurrente'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240508220737Z')
,p_updated_on=>wwv_flow_imp.dz('20240508220737Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(154643608783122453)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1546437'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ESTADOFLUJO:NEGOCIACION:RECURRENTE:VOLUMEN:TIPO_ESQUEMA:ESQUEMA:VIGENCIA_DESDE:VIGENCIA_HASTA:SOLICITANTE:NEG. PASADAS:NEG. SIMILARES:'
,p_sort_column_1=>'NEGOCIACION'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20240119194140Z')
,p_updated_on=>wwv_flow_imp.dz('20240522151708Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(154634045154115416)
,p_plug_name=>'Caducadas/Anuladas'
,p_region_name=>'rptNegociacionCaduca'
,p_parent_plug_id=>wwv_flow_imp.id(140641673072536238)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'	 CASE',
'	 	WHEN ESTADOFLUJO IN (''EN RUTA'')   THEN 0',
'	 	WHEN ESTADOFLUJO IN (''VIGENTE'')   THEN 1',
'	 	WHEN ESTADOFLUJO IN (''APROBADO'')  THEN 2',
'	 	WHEN ESTADOFLUJO IN (''CADUCADO'')  THEN 4',
'	 	WHEN ESTADOFLUJO IN (''CANCELADO'') THEN 5',
'             ELSE 9',
'          END ORDEN',
'	, ESTADOFLUJO',
'	, IDNEGOCIACION NEGOCIACION',
'	, FECHAFLUJO FECHA',
'	, SOLICITANTE',
'	, APROBADOR',
'	, VOLUMEN',
'	, ESQUEMA TIPO_ESQUEMA',
'	, CASE ESQUEMA  ',
'		WHEN ''PD'' THEN  (SELECT   CODIGOPRODUCTO || '' - '' ||  NOMBREPRODUCTO || '' ''|| CODIGOALTERNO  || '' - ['' ||  UNIDADCOMPRA || '']'' D   FROM VT_JDE_PRODUCTOS WHERE CODIGOCORTO=CODESQUEMA AND CODESTADO<>''O'' )',
'		WHEN ''PV'' THEN  (SELECT   CODIGOPROVEEDOR || '' - '' ||  DESCRIPCION D FROM  VT_JDE_MAESTROPROVEEDOR WHERE CODIGOPROVEEDOR=CODESQUEMA)',
'		END ESQUEMA',
'	, VIGENCIADESDE VIGENCIA_DESDE',
'	, VIGENCIAHASTA VIGENCIA_HASTA',
'	, NEG_PAS "NEG. PASADAS"',
'	, NEG_SIM "NEG. SIMILARES"',
'	, PK_CORP_FLUJOAPROBACION.F_GESTIONCOLOR(:APP_USER, APROBADOR, ESTADOFLUJO, :G_COMPANIA, :G_MODULO) CSS',
'	, APEX_PAGE.GET_URL(P_APPLICATION=>130,P_PAGE=>CASE WHEN ESTADOFLUJO IN (''CREACION'',''RECHAZADO'') THEN 139 ELSE 138 END,P_ITEMS=>''G_IDNEGOCIACION,G_EDITNEGOCIACION,G_PAGNEGOCIACION'',P_VALUES=>IDNEGOCIACION|| '',''|| DECODE(ESTADOFLUJO,''CREACION'',1, 0)|'
||'| '',''|| :APP_PAGE_ID)URL',
'	, APEX_PAGE.GET_URL(P_APPLICATION=>130,P_PAGE=>143 ,P_ITEMS=>''P143_NEG_ID_ACTUAL,P143_TIPO,G_PAGNEGOCIACION'',P_VALUES=>IDNEGOCIACION|| '',1,''|| :APP_PAGE_ID)URLPAS',
'	, APEX_PAGE.GET_URL(P_APPLICATION=>130,P_PAGE=>143 ,P_ITEMS=>''P143_NEG_ID_ACTUAL,P143_TIPO,G_PAGNEGOCIACION'',P_VALUES=>IDNEGOCIACION|| '',2,''|| :APP_PAGE_ID)URLSIM',
'	, OBSERVACION',
'	, TIPONEGOCIACION, recurrente',
'FROM DATA.VT_COMP_MESATRABAJONEG',
'WHERE 1 = 1',
'	AND ( (:P137_ESTADO = 1 AND APROBADOR IS NOT NULL AND  PK_CORP_FLUJOAPROBACION.F_APROBADORFLUJO(:APP_USER, APROBADOR, :G_MODULO, :G_COMPANIA) = 1)',
'		OR (:P137_ESTADO = 2 AND (TRUNC(FECHAFLUJO) BETWEEN (:P137_FECHA_INICIO) AND (:P137_FECHA_FIN)))',
'		)',
'    AND ESTADOFLUJO IN ( ''CADUCADO'',''CANCELADO'' )',
'    AND :P137_TIPO=''#rptNegociacionCaduca'''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P137_ESTADO,P137_USUARIO,P137_FECHA_INICIO,P137_FECHA_FIN,P137_TIPO'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P137_ESTADO =2'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20240522151731Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(154634155210115417)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>154634155210115417
,p_updated_on=>wwv_flow_imp.dz('20240522151731Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154634251050115418)
,p_db_column_name=>'ESTADOFLUJO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Estado'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154634471594115420)
,p_db_column_name=>'NEGOCIACION'
,p_display_order=>20
,p_column_identifier=>'C'
,p_column_label=>unistr('Negociaci\00F3n')
,p_column_link=>'f?p=&APP_ID.:138:&SESSION.::&DEBUG.:RP,138:G_IDNEGOCIACION,G_EDITNEGOCIACION,G_PAGNEGOCIACION,P138_ESTADO_FLUJO,P138_OBJETO:#NEGOCIACION#,0,&APP_PAGE_ID.,#ESTADOFLUJO#,'
,p_column_linktext=>'#NEGOCIACION#'
,p_column_link_attr=>'class="#CSS#" alert="#ESTADOFLUJO#"'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'00000'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240221190805Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154635550664115431)
,p_db_column_name=>'VOLUMEN'
,p_display_order=>40
,p_column_identifier=>'N'
,p_column_label=>'Volumen'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154634637781115422)
,p_db_column_name=>'TIPO_ESQUEMA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Tipo Esquema'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(134249283510088347)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154635385582115429)
,p_db_column_name=>'ESQUEMA'
,p_display_order=>60
,p_column_identifier=>'L'
,p_column_label=>'Esquema'
,p_allow_sorting=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122172601Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154634940289115425)
,p_db_column_name=>'VIGENCIA_DESDE'
,p_display_order=>70
,p_column_identifier=>'H'
,p_column_label=>'Vig. Desde'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122173020Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154635085843115426)
,p_db_column_name=>'VIGENCIA_HASTA'
,p_display_order=>80
,p_column_identifier=>'I'
,p_column_label=>'Vig. Hasta'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122173020Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154634555198115421)
,p_db_column_name=>'FECHA'
,p_display_order=>90
,p_column_identifier=>'D'
,p_column_label=>'Fecha'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122193416Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154634790701115423)
,p_db_column_name=>'SOLICITANTE'
,p_display_order=>100
,p_column_identifier=>'F'
,p_column_label=>'Solicitante'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122193459Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154634862622115424)
,p_db_column_name=>'APROBADOR'
,p_display_order=>110
,p_column_identifier=>'G'
,p_column_label=>'Aprobador'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122193459Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154635635153115432)
,p_db_column_name=>'NEG. PASADAS'
,p_display_order=>120
,p_column_identifier=>'O'
,p_column_label=>'Neg. Pasadas'
,p_column_link=>'#URLPAS#'
,p_column_linktext=>'#NEG. PASADAS#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154635703678115433)
,p_db_column_name=>'NEG. SIMILARES'
,p_display_order=>130
,p_column_identifier=>'P'
,p_column_label=>'Neg. Similares'
,p_column_link=>'#URLSIM#'
,p_column_linktext=>'#NEG. SIMILARES#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154635409604115430)
,p_db_column_name=>'ORDEN'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>'Orden'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122193321Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154635118231115427)
,p_db_column_name=>'CSS'
,p_display_order=>150
,p_column_identifier=>'J'
,p_column_label=>'Css'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154635240237115428)
,p_db_column_name=>'URL'
,p_display_order=>160
,p_column_identifier=>'K'
,p_column_label=>'Url'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154635822923115434)
,p_db_column_name=>'URLPAS'
,p_display_order=>180
,p_column_identifier=>'Q'
,p_column_label=>'Urlpas'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154635974509115435)
,p_db_column_name=>'URLSIM'
,p_display_order=>190
,p_column_identifier=>'R'
,p_column_label=>'Urlsim'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183800127480709148)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>200
,p_column_identifier=>'S'
,p_column_label=>unistr('Observaci\00F3n')
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240123210937Z')
,p_updated_on=>wwv_flow_imp.dz('20240123210937Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183800293061709149)
,p_db_column_name=>'TIPONEGOCIACION'
,p_display_order=>210
,p_column_identifier=>'T'
,p_column_label=>unistr('Tipo Negociaci\00F3n')
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240123210937Z')
,p_updated_on=>wwv_flow_imp.dz('20240123211001Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(300483046011773204)
,p_db_column_name=>'RECURRENTE'
,p_display_order=>220
,p_column_identifier=>'U'
,p_column_label=>'Recurrente'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240508220737Z')
,p_updated_on=>wwv_flow_imp.dz('20240508220737Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(154650818161143886)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1546509'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ESTADOFLUJO:NEGOCIACION:RECURRENTE:VOLUMEN:TIPO_ESQUEMA:ESQUEMA:VIGENCIA_DESDE:VIGENCIA_HASTA:SOLICITANTE:NEG. PASADAS:NEG. SIMILARES:'
,p_sort_column_1=>'NEGOCIACION'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20240119194140Z')
,p_updated_on=>wwv_flow_imp.dz('20240522151731Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(154636039115115436)
,p_plug_name=>unistr('Gesti\00F3n')
,p_region_name=>'rptNegociacionCrea'
,p_parent_plug_id=>wwv_flow_imp.id(140641673072536238)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'	 CASE',
'	 	WHEN ESTADOFLUJO IN (''EN RUTA'')   THEN 0',
'	 	WHEN ESTADOFLUJO IN (''VIGENTE'')   THEN 1',
'	 	WHEN ESTADOFLUJO IN (''APROBADO'')  THEN 2',
'	 	WHEN ESTADOFLUJO IN (''CADUCADO'')  THEN 4',
'	 	WHEN ESTADOFLUJO IN (''CANCELADO'') THEN 5',
'             ELSE 9',
'          END ORDEN',
'	, ESTADOFLUJO',
'	, IDNEGOCIACION NEGOCIACION',
'	, FECHAFLUJO FECHA',
'	, SOLICITANTE',
'	, APROBADOR',
'	, VOLUMEN',
'	, ESQUEMA TIPO_ESQUEMA',
'	, CASE ESQUEMA  ',
'		WHEN ''PD'' THEN  (SELECT   CODIGOPRODUCTO || '' - '' ||  NOMBREPRODUCTO || '' ''|| CODIGOALTERNO  || '' - ['' ||  UNIDADCOMPRA || '']'' D   FROM VT_JDE_PRODUCTOS WHERE CODIGOCORTO=CODESQUEMA AND CODESTADO<>''O'' )',
'		WHEN ''PV'' THEN  (SELECT   CODIGOPROVEEDOR || '' - '' ||  DESCRIPCION D FROM  VT_JDE_MAESTROPROVEEDOR WHERE CODIGOPROVEEDOR=CODESQUEMA)',
'		END ESQUEMA',
'	, VIGENCIADESDE VIGENCIA_DESDE',
'	, VIGENCIAHASTA VIGENCIA_HASTA',
'	, NEG_PAS "NEG. PASADAS"',
'	, NEG_SIM "NEG. SIMILARES"',
'	, PK_CORP_FLUJOAPROBACION.F_GESTIONCOLOR(:APP_USER, APROBADOR, ESTADOFLUJO, :G_COMPANIA, :G_MODULO) CSS',
'	, APEX_PAGE.GET_URL(P_APPLICATION=>130,P_PAGE=>139,P_ITEMS=>''G_IDNEGOCIACION,G_EDITNEGOCIACION,G_PAGNEGOCIACION'',P_VALUES=>IDNEGOCIACION|| '',''|| DECODE(ESTADOFLUJO,''CREACION'',1, 0)|| '',''|| :APP_PAGE_ID)URL',
'	, APEX_PAGE.GET_URL(P_APPLICATION=>130,P_PAGE=>143 ,P_ITEMS=>''P143_NEG_ID_ACTUAL,P143_TIPO,G_PAGNEGOCIACION'',P_VALUES=>IDNEGOCIACION|| '',1,''|| :APP_PAGE_ID)URLPAS',
'	, APEX_PAGE.GET_URL(P_APPLICATION=>130,P_PAGE=>143 ,P_ITEMS=>''P143_NEG_ID_ACTUAL,P143_TIPO,G_PAGNEGOCIACION'',P_VALUES=>IDNEGOCIACION|| '',2,''|| :APP_PAGE_ID)URLSIM',
'	, OBSERVACION',
'	, TIPONEGOCIACION, recurrente',
'FROM DATA.VT_COMP_MESATRABAJONEG',
'WHERE 1 = 1',
'	AND ( (:P137_ESTADO = 1 AND APROBADOR IS NOT NULL AND  PK_CORP_FLUJOAPROBACION.F_APROBADORFLUJO(:APP_USER, APROBADOR, :G_MODULO, :G_COMPANIA) = 1)',
'		OR (:P137_ESTADO = 2 AND (TRUNC(FECHAFLUJO) BETWEEN (:P137_FECHA_INICIO) AND (:P137_FECHA_FIN)))',
'		)',
'        AND  ESTADOFLUJO IN (''CREACION'')',
'    AND :P137_TIPO=''#rptNegociacionCrea'''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P137_ESTADO,P137_USUARIO,P137_FECHA_INICIO,P137_FECHA_FIN,P137_TIPO'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P137_ES_CREADOR= 1'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20240522151832Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(154636102427115437)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>154636102427115437
,p_updated_on=>wwv_flow_imp.dz('20240522151832Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154636222992115438)
,p_db_column_name=>'ESTADOFLUJO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Estado'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154636338320115439)
,p_db_column_name=>'NEGOCIACION'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>unistr('Negociaci\00F3n')
,p_column_link=>'f?p=&APP_ID.:139:&SESSION.::&DEBUG.:RP,139:G_IDNEGOCIACION,G_EDITNEGOCIACION,G_PAGNEGOCIACION:#NEGOCIACION#,1,&APP_PAGE_ID.'
,p_column_linktext=>'#NEGOCIACION#'
,p_column_link_attr=>'class="#CSS#" alert="#ESTADOFLUJO#"'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'00000'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122193236Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154636504297115441)
,p_db_column_name=>'VOLUMEN'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Volumen'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154636648722115442)
,p_db_column_name=>'TIPO_ESQUEMA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Tipo Esquema'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(134249283510088347)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154636717109115443)
,p_db_column_name=>'ESQUEMA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Esquema'
,p_allow_sorting=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122172601Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154636877919115444)
,p_db_column_name=>'VIGENCIA_DESDE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Vig. Desde'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122173020Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154636948556115445)
,p_db_column_name=>'VIGENCIA_HASTA'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Vig. Hasta'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122173020Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154637009198115446)
,p_db_column_name=>'FECHA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fecha'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122193416Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154637190784115447)
,p_db_column_name=>'SOLICITANTE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Solicitante'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122193459Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154637277001115448)
,p_db_column_name=>'APROBADOR'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Aprobador'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122193459Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154637334772115449)
,p_db_column_name=>'NEG. PASADAS'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Neg. Pasadas'
,p_column_link=>'#URLPAS#'
,p_column_linktext=>'#NEG. PASADAS#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154637495435115450)
,p_db_column_name=>'NEG. SIMILARES'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Neg. Similares'
,p_column_link=>'#URLSIM#'
,p_column_linktext=>'#NEG. SIMILARES#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154656853232159001)
,p_db_column_name=>'ORDEN'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Orden'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240122193301Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154656957063159002)
,p_db_column_name=>'CSS'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Css'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154657065218159003)
,p_db_column_name=>'URL'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Url'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154657109903159004)
,p_db_column_name=>'URLPAS'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Urlpas'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154657219128159005)
,p_db_column_name=>'URLSIM'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Urlsim'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183800323755709150)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>unistr('Observaci\00F3n')
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240123210937Z')
,p_updated_on=>wwv_flow_imp.dz('20240123210937Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(206426330844010901)
,p_db_column_name=>'TIPONEGOCIACION'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>unistr('Tipo Negociaci\00F3n')
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240123210937Z')
,p_updated_on=>wwv_flow_imp.dz('20240123211001Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(300482921856773203)
,p_db_column_name=>'RECURRENTE'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Recurrente'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240508220619Z')
,p_updated_on=>wwv_flow_imp.dz('20240508220619Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(154667814092164247)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1546679'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ESTADOFLUJO:NEGOCIACION:RECURRENTE:VOLUMEN:TIPO_ESQUEMA:ESQUEMA:VIGENCIA_DESDE:VIGENCIA_HASTA:SOLICITANTE:NEG. PASADAS:NEG. SIMILARES:'
,p_sort_column_1=>'NEGOCIACION'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20240119194140Z')
,p_updated_on=>wwv_flow_imp.dz('20240522151832Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(139255748893882846)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(139588400722163998)
,p_button_name=>'INDICES'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Indices'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:141:&SESSION.::&DEBUG.:RP,141::'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-list-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133761853691103760)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(139588400722163998)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133761050895103758)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(139588400722163998)
,p_button_name=>'APROBAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Aprobar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P137_ESGESTIONLOTE'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-thumbs-up'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133761448567103760)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(139588400722163998)
,p_button_name=>'RECHAZAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Rechazar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P137_ESGESTIONLOTE'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-thumbs-down'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133924407807985530)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(139588400722163998)
,p_button_name=>'AGREGAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'AGREGAR'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:139:&SESSION.::&DEBUG.:RP,139:G_IDNEGOCIACION,G_EDITNEGOCIACION:0,0'
,p_button_condition=>'P137_ES_CREADOR'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-plus'
,p_updated_on=>wwv_flow_imp.dz('20240314190741Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43435215713543031)
,p_name=>'P137_ES_CREADOR'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(134790295102704822)
,p_prompt=>'Es Creador'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(133762974778103764)
,p_name=>'P137_COMENTARIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(134790295102704822)
,p_prompt=>'Comentario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(133763387507103764)
,p_name=>'P137_APROBADOR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(134790295102704822)
,p_prompt=>'Aprobador'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(133763721527103764)
,p_name=>'P137_GESTIONLOTE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(134790295102704822)
,p_prompt=>'Gestionlote'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(133764532618103764)
,p_name=>'P137_ESGESTIONLOTE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(134790295102704822)
,p_prompt=>'Esgestionlote'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(133764945365103764)
,p_name=>'P137_USUARIO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(134790295102704822)
,p_prompt=>'Usuario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(133765302204103764)
,p_name=>'P137_TIPO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(134790295102704822)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(133766188218103764)
,p_name=>'P137_ESTADO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(139588519658163999)
,p_item_default=>'1'
,p_prompt=>'Estado'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_UDC_ESTADOMESA'
,p_lov=>'SELECT DESCRIPCION, ID_TABLA FROM T_CORP_UDC WHERE id_cabecera=''ESTADOMESA'' ORDER BY id_tabla;'
,p_cHeight=>1
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(133766577886103766)
,p_name=>'P137_FECHA_INICIO'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(139588519658163999)
,p_item_default=>'TRUNC(ADD_MONTHS(SYSDATE,-1),''MONTH'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Inicio'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'STATIC'
,p_attribute_07=>'+0d'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON'
,p_attribute_13=>'HIDDEN'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(133766977880103766)
,p_name=>'P137_FECHA_FIN'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(139588519658163999)
,p_item_default=>'trunc(SYSDATE)'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha fin'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'STATIC'
,p_attribute_07=>'+0d'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON'
,p_attribute_13=>'HIDDEN'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135558143365707421)
,p_name=>'P137_CONTADOR'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(134790295102704822)
,p_prompt=>'Contador'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(133806658699103825)
,p_name=>'Cambia Estado Motrar filtros'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P137_ESTADO'
,p_condition_element=>'P137_ESTADO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(133807124881103827)
,p_event_id=>wwv_flow_imp.id(133806658699103825)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P137_FECHA_INICIO,P137_FECHA_FIN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(133808089451103828)
,p_event_id=>wwv_flow_imp.id(133806658699103825)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P137_FECHA_INICIO,P137_FECHA_FIN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(137372467127651930)
,p_event_id=>wwv_flow_imp.id(133806658699103825)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(137372510439651931)
,p_event_id=>wwv_flow_imp.id(133806658699103825)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(133808432505103828)
,p_name=>'Negociaciones Select All'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectallocs'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#rptNegociacion'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(133808936461103828)
,p_event_id=>wwv_flow_imp.id(133808432505103828)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#rptNegociacion #selectallocs'' ).is('':checked'')) {',
'    $(''#rptNegociacion input[type=checkbox][name=f01]'').prop(''checked'',true);',
'} else {',
'    $(''#rptNegociacion input[type=checkbox][name=f01]'').prop(''checked'',false);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(133809398504103828)
,p_name=>'Selecciona Costos'
,p_event_sequence=>40
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectallcosto'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#rptCosto'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(133809886755103828)
,p_event_id=>wwv_flow_imp.id(133809398504103828)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#rptCosto #selectallcosto'' ).is('':checked'')) {',
'    $(''#rptCosto input[type=checkbox][name=f01]'').prop(''checked'',true);',
'} else {',
'    $(''#rptCosto input[type=checkbox][name=f01]'').prop(''checked'',false);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(133810278797103828)
,p_name=>'Selecciona Descuentos'
,p_event_sequence=>50
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectalldsc'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#rptDescuentoCantidad'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(133810706628103828)
,p_event_id=>wwv_flow_imp.id(133810278797103828)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#rptDescuentoCantidad #selectalldsc'' ).is('':checked'')) {',
'    $(''#rptDescuentoCantidad input[type=checkbox][name=f01]'').prop(''checked'',true);',
'} else {',
'    $(''#rptDescuentoCantidad input[type=checkbox][name=f01]'').prop(''checked'',false);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(133811109292103828)
,p_name=>'Selecciona NCs'
,p_event_sequence=>60
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectallncs'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#rptNotasCredito'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(133811606470103828)
,p_event_id=>wwv_flow_imp.id(133811109292103828)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#rptNotasCredito #selectallncs'' ).is('':checked'')) {',
'    $(''#rptNotasCredito input[type=checkbox][name=f01]'').prop(''checked'',true);',
'} else {',
'    $(''#rptNotasCredito input[type=checkbox][name=f01]'').prop(''checked'',false);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(133812001469103828)
,p_name=>'LIQUIDACIONORDEN: Validacion aprobacion'
,p_event_sequence=>73
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(133761050895103758)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'document.querySelectorAll(''.chkF01'').length == [].filter.call( document.querySelectorAll(''.chkF01''), function( el ) {return !el.checked}).length ',
''))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(133812582527103830)
,p_event_id=>wwv_flow_imp.id(133812001469103828)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mensaje(''error'',''Debe selecionar al menos una negociacion, revise y vuelva a intentarlo.''); '
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(133813052036103830)
,p_event_id=>wwv_flow_imp.id(133812001469103828)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(133813546058103830)
,p_event_id=>wwv_flow_imp.id(133812001469103828)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'APROBAR'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(133813958301103830)
,p_name=>'LIQUIDACIONORDEN: Validacion rechazar'
,p_event_sequence=>83
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(133761448567103760)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'document.querySelectorAll(''.chkF01'').length == [].filter.call( document.querySelectorAll(''.chkF01''), function( el ) {return !el.checked}).length ',
''))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(133814476647103830)
,p_event_id=>wwv_flow_imp.id(133813958301103830)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'RECHAZAR'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(133814910964103831)
,p_event_id=>wwv_flow_imp.id(133813958301103830)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mensaje(''error'', ''Por favor, debe seleccionar un numero de documento para ser procesado, valide y vuelva a intentar''); '
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(133815486572103831)
,p_event_id=>wwv_flow_imp.id(133813958301103830)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(133805029638103822)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Aprobaci\00F3n en Lote')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'v_aprobador 		varchar(2500);',
'v_compania			varchar2(5);',
'v_exito 			number;',
'v_id 				varchar2(2500);',
'v_modulo 			varchar(250);',
'v_nego_error 		varchar2(2500);',
'v_nego_exito 		varchar2(2500);',
'v_numero 			varchar(20);',
'v_objeto 			varchar(250);',
'v_recurrente		varchar2(5);',
'v_termino 			number;',
'v_tipo 				varchar2(2500);',
'v_usuario 			varchar(250);',
'begin',
'	v_compania	:= :g_compania;',
'	for i in 1..apex_application.g_f01.count loop  --Recorre las filas seleccionadas',
'		v_id := apex_application.g_f01(i);',
'',
'		select item into v_numero	from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 1;',
'		select item into v_tipo		from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 2;',
'',
'		v_modulo	:= ''COMP'';',
'		v_aprobador	:= :app_user;',
'		v_usuario	:= :app_user;',
'',
'		select nvl(a.recurrente,''NO''),b.unidadnegocio into v_recurrente,v_objeto',
'		from t_comp_negociacion a inner join t_comp_negociacioncab b on a.id = b.idneg',
'		where a.id = v_numero and rownum = 1;',
'',
'		if v_recurrente = ''NO'' then',
'			v_objeto	:= ''NEGOCIACION'';',
'		end if;',
'',
'		pk_corp_flujoaprobacion.sp_flujoaprobar(',
'			p_id 					=> v_numero',
'			, p_objeto				=> v_objeto',
'			, p_ordenmonto			=> null',
'			, p_usuarioflujo		=> v_aprobador',
'			, p_usuario				=> v_usuario',
'			, p_comentario			=> ''''',
'			, p_comentario_usuarios	=> ''''',
'			, p_modulo				=> v_modulo',
'			, p_compania			=> v_compania',
'			, p_exito				=> v_exito',
'			, p_terminoflujo		=> v_termino',
'		);',
'',
'		if v_exito = 1 then',
'			if v_termino = 1 then',
'				data.pk_comp_negociacion.sp_aprobarnegociacion(p_compania => v_compania, p_usuario => v_usuario, p_idneg => v_numero);',
'			end if;		',
'',
'			if length(v_nego_exito) > 0 then',
'				v_nego_exito := v_nego_exito||''; ''||pk_comp_negociacion.f_neg_esquema(v_numero);',
'			else',
'				v_nego_exito := pk_comp_negociacion.f_neg_esquema(v_numero);',
'			end if; ',
'        else',
'    		if length(v_nego_error) > 0 then',
'    			v_nego_error := v_nego_error||''; ''||pk_comp_negociacion.f_neg_esquema(v_numero);',
'    		else',
'    			v_nego_error := pk_comp_negociacion.f_neg_esquema(v_numero);',
'    		end if;',
'        end if;',
'	end loop;',
'	--Mensaje de exito',
'	if length(v_nego_exito) > 0 then		',
unistr('    	apex_application.g_print_success_message := ''Negociaciones aprobadas con \00E9xito.'';'),
'	end if;',
'	--Mensaje de error',
'	if length(v_nego_error) > 0 then',
'		apex_error.add_error (',
'			p_message 				=> ''Error en procesar : ''||v_nego_error',
'			, p_display_location	=> apex_error.c_inline_in_notification',
'		);',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(133761050895103758)
,p_internal_uid=>133805029638103822
,p_updated_on=>wwv_flow_imp.dz('20240223212547Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(133805493296103824)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Rechazo en lote'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'v_aprobador		varchar(2500);',
'v_compania		varchar2(5);',
'v_exito			number;',
'v_id			varchar2(2500);',
'v_id_error_neg	varchar2(2500);',
'v_id_exito_neg	varchar2(2500);',
'v_modulo		varchar(250) ;',
'v_numero		varchar(20);',
'v_objeto		varchar(250);',
'v_recurrente	varchar2(5);',
'v_tipo			varchar2(2500);',
'v_usuario		varchar(250);',
'begin',
'	v_compania	:= :g_compania;',
'',
'	for i in 1..apex_application.g_f01.count loop --Recorre las filas seleccionadas',
'		v_id := apex_application.g_f01(i);',
'',
'		select item into v_numero	from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 1;',
'		select item into v_tipo		from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 2;',
'',
'		v_modulo	:= :app_modulo;',
'		v_aprobador	:= :p137_usuario;',
'		v_usuario	:= :p137_usuario;',
'',
'		select nvl(a.recurrente,''NO''),b.unidadnegocio into v_recurrente,v_objeto',
'		from t_comp_negociacion a inner join t_comp_negociacioncab b on a.id = b.idneg',
'		where a.id = v_numero and rownum = 1;',
'',
'		if v_recurrente = ''NO'' then',
'			v_objeto	:= ''NEGOCIACION'';',
'		end if;',
'',
'		pk_corp_flujoaprobacion.sp_flujorechazar(',
'			p_id					=> v_numero',
'			, p_objeto				=> v_objeto',
'			, p_usuarioflujo		=> v_aprobador',
'			, p_usuario				=> v_usuario',
'			, p_comentario			=> ''''',
'			, p_comentario_usuarios	=> ''''',
'			, p_modulo				=> ''COMP''',
'			, p_compania			=> ''00001''',
'			, p_exito				=> v_exito',
'		);',
'',
'		if v_exito = 1 then',
'			data.pk_comp_negociacion.sp_rechazarnegociacion(p_compania => v_compania, p_usuario => v_usuario, p_idneg => v_numero);',
'',
'			if length(v_id_exito_neg) > 0 then',
'				v_id_exito_neg := v_id_exito_neg||'' ,''||v_tipo||''-''||v_numero;',
'			else',
'				v_id_exito_neg := v_tipo||''-''||v_numero;',
'			end if;',
'		else',
'			if length(v_id_error_neg) > 0 then',
'				v_id_error_neg := v_id_error_neg||'' ,''||v_tipo||''-''||v_numero;',
'			else',
'				v_id_error_neg := v_tipo||''-''||v_numero;',
'			end if;',
'		end if;',
'	end loop;',
'',
'	--Mensaje de exito',
'	if length(v_id_exito_neg) > 0 then',
unistr('		apex_application.g_print_success_message := ''Negociaciones rechazadas con \00E9xito.'';'),
'	end if;',
'',
'	--Mensaje de error',
'	if length(v_id_error_neg) > 0 then',
'		apex_error.add_error (',
'			p_message				=> ''Error en rechazar las negociaciones: ''||v_id_error_neg',
'			, p_display_location	=> apex_error.c_inline_in_notification',
'		);',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(133761448567103760)
,p_internal_uid=>133805493296103824
,p_updated_on=>wwv_flow_imp.dz('20240223211716Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(133803453494103819)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Setup'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	:p137_aprobador		:= 0;',
'	:p137_esgestionlote	:= 0;',
'	:p137_usuario		:= :app_user;',
'	:p137_gestionlote	:= pk_admi_gestionparametros.f_admi_accesoacciones(:app_modulo,:app_user,:app_page_id,''GESTION_LOTE_NEG'');',
'	:p137_es_creador	:= pk_admi_gestionparametros.f_admi_accesoacciones(:app_modulo,:app_user,:app_page_id,''GESTION_CREA_NEG'');',
'',
'	begin',
'		select 1 into :p137_aprobador',
'		from vt_comp_mesatrabajoneg',
'		where rownum = 1',
'			and aprobador is not null',
'			and aprobador=:app_user',
'			and pk_corp_flujoaprobacion.f_aprobadorflujo(:app_user,aprobador,:g_modulo,:g_compania) = 1;',
'',
'		exception when others then :p137_aprobador := 0;',
'	end;',
'',
'	if (:p137_gestionlote + :p137_aprobador) > 1 then',
'		:p137_esgestionlote := 1;',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>133803453494103819
,p_updated_on=>wwv_flow_imp.dz('20240314190607Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(133803809933103820)
,p_process_sequence=>40
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Borrar Datos'
,p_attribute_01=>'CLEAR_CACHE_FOR_ITEMS'
,p_attribute_03=>'P137_COMENTARIO'
,p_internal_uid=>133803809933103820
,p_updated_on=>wwv_flow_imp.dz('20240314190201Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
