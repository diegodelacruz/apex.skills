prompt --application/pages/page_00526
begin
--   Manifest
--     PAGE: 00526
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>526
,p_name=>'COMEX - dlgDetallesVerificadora'
,p_alias=>'COMEX-DLGDETALLESVERIFICADORA'
,p_page_mode=>'MODAL'
,p_step_title=>'Detalles Verificadora'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20241113165843Z')
,p_last_updated_on=>wwv_flow_imp.dz('20241023172406Z')
,p_last_updated_by=>'DCUEVA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(352512928972436512)
,p_plug_name=>'CABECERA'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(352514019215436523)
,p_plug_name=>'ARCHIVOS'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    NUMEROARCHIVO, ',
'    FILENAME, ',
'    TO_CHAR(FECHA, ''DD/MM/YYYY HH24:MI'') AS FECHA,',
'    NUMEROARCHIVO AS BLOB',
'FROM ',
'    FILES.T_APEX_ARCHIVOS',
'WHERE',
'    TABLA=''T_CMEX_DATOS_GESTION_DETALLE''',
'        AND',
'    ID_TABLA=:P526_DATOS_GESTION_DET_ID',
'        AND',
'    TIPO = ''VERIFICADORA''',
'    ;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'ARCHIVOS'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(352514164182436524)
,p_max_row_count=>'1000000'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>352514164182436524
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(352514337543436526)
,p_db_column_name=>'FILENAME'
,p_display_order=>10
,p_column_identifier=>'B'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(352514208519436525)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Nr.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(352514435270436527)
,p_db_column_name=>'FECHA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fecha'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(352514575057436528)
,p_db_column_name=>'BLOB'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Archivo'
,p_column_type=>'NUMBER'
,p_format_mask=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment:#FILENAME#:FILES'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(352706326206995981)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3527064'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMEROARCHIVO:BLOB:FECHA:'
,p_created_on=>wwv_flow_imp.dz('20241113165843Z')
,p_updated_on=>wwv_flow_imp.dz('20241113165843Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(352515521045436538)
,p_plug_name=>'RECHAZAR'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(295619229174037679)
,p_plug_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P526_EDITAR_COORDINACION=1 AND :P526_FECHA_UPLOAD_VERIFICADORA IS NOT NULL'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(371908677312428002)
,p_plug_name=>'REPORTE INSPECCION'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    NUMEROARCHIVO, ',
'    FILENAME, ',
'    TO_CHAR(FECHA, ''DD/MM/YYYY HH24:MI'') AS FECHA,',
'    NUMEROARCHIVO AS BLOB',
'FROM ',
'    FILES.T_APEX_ARCHIVOS',
'WHERE',
'    NUMEROARCHIVO = :P526_REPORTE_INSPECCION_ARCHV',
'    ;'))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(371908741686428003)
,p_max_row_count=>'1000000'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>371908741686428003
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(371908883501428004)
,p_db_column_name=>'FILENAME'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(371908946722428005)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Nr.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(371909014578428006)
,p_db_column_name=>'FECHA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fecha'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(371909186871428007)
,p_db_column_name=>'BLOB'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>unistr('Reporte de Inspecci\00F3n')
,p_column_type=>'NUMBER'
,p_format_mask=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment:#FILENAME#:FILES'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(371918948519438924)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3719190'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BLOB:FECHA:'
,p_created_on=>wwv_flow_imp.dz('20241113165843Z')
,p_updated_on=>wwv_flow_imp.dz('20241113165843Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(352514683691436529)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(352512928972436512)
,p_button_name=>'NOTIFICAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Notificar'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P526_FECHA_NOTIF_VERIFICADORA IS NULL ',
'    AND ',
'(    ',
'    :P526_EDITAR_COORDINACION = 1',
'        OR',
'    :P526_EDITAR_TRANSITO = 1',
')'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(352515475561436537)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(352515521045436538)
,p_button_name=>'RECHAZAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Rechazar'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(352514810121436531)
,p_branch_name=>'GO TO 521'
,p_branch_action=>'f?p=&APP_ID.:521:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(352513380843436516)
,p_name=>'P526_EXPORTACION_REGISTRO'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(352513477318436517)
,p_name=>'P526_DATOS_GESTION_DET_ID'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(352513621079436519)
,p_name=>'P526_FECHA_NOTIF_VERIFICADORA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(352512928972436512)
,p_prompt=>'Notificado'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(352513792563436520)
,p_name=>'P526_REPORTE_INSPECCION_NUMERO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(352512928972436512)
,p_prompt=>'Nr. Rep. Insp.'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(352513827385436521)
,p_name=>'P526_FECHA_UPLOAD_VERIFICADORA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(352512928972436512)
,p_prompt=>'Upload'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(352514733780436530)
,p_name=>'P526_EDITAR_COORDINACION'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(352515689905436539)
,p_name=>'P526_MOTIVO_RECHAZO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(352515521045436538)
,p_prompt=>'Motivo Rechazo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>80
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(364782589062500919)
,p_name=>'P526_EDITAR_TRANSITO'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(371908543263428001)
,p_name=>'P526_REPORTE_INSPECCION_ARCHV'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(352515821839436541)
,p_validation_name=>'RECHAZAR'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P526_MOTIVO_RECHAZO IS NULL THEN',
'    RETURN ''Debe indicar un motivo de rechazo'';',
'END IF;',
'',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(352515475561436537)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(352515158593436534)
,p_name=>'NOTIFICAR'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(352514683691436529)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(352515238056436535)
,p_event_id=>wwv_flow_imp.id(352515158593436534)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.util.showSpinner();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(352515371073436536)
,p_event_id=>wwv_flow_imp.id(352515158593436534)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'NOTIFICAR'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(352514980615436532)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'NOTIFICAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_EXPORTACION.SP_NOTIFICA_VERIFICADORA(',
'    :P526_EXPORTACION_REGISTRO, ',
'    :P526_DATOS_GESTION_DET_ID, ',
'    NULL',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(352514683691436529)
,p_internal_uid=>352514980615436532
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(352515723865436540)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RECHAZAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_EXPORTACION.SP_RECHAZA_ARCHIVOS_VERIFICADORA(',
'    :P526_EXPORTACION_REGISTRO,',
'    :P526_DATOS_GESTION_DET_ID,',
'    :P526_MOTIVO_RECHAZO',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(352515475561436537)
,p_internal_uid=>352515723865436540
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(352513992144436522)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Carga Datos Gesti\00F3n Detalle')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    TO_CHAR(FECHA_NOTIF_VERIFICADORA, ''DD/MM/YYYY HH24:MI''),',
'    REPORTE_INSPECCION_NUMERO,',
'    REPORTE_INSPECCION_ARCHIVO,',
'    TO_CHAR(FECHA_UPLOAD_VERIFICADORA, ''DD/MM/YYYY HH24:MI'')',
'INTO',
'    :P526_FECHA_NOTIF_VERIFICADORA,',
'    :P526_REPORTE_INSPECCION_NUMERO,',
'    :P526_REPORTE_INSPECCION_ARCHV,',
'    :P526_FECHA_UPLOAD_VERIFICADORA',
'FROM',
'    T_CMEX_DATOS_GESTION_DETALLE',
'WHERE',
'    ID=:P526_DATOS_GESTION_DET_ID',
';'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>352513992144436522
);
wwv_flow_imp.component_end;
end;
/
