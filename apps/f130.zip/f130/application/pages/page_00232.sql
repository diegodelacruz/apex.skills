prompt --application/pages/page_00232
begin
--   Manifest
--     PAGE: 00232
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>232
,p_name=>unistr('Importaci\00F3n Muestras')
,p_alias=>unistr('IMPORTACI\00D3N-MUESTRAS')
,p_step_title=>unistr('Importaci\00F3n Muestras')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240830212054Z')
,p_last_updated_on=>wwv_flow_imp.dz('20241216202644Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(164162795984432092)
,p_plug_name=>unistr('Importaci\00F3n Muestras')
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with w_flj as (',
'    select max(id) idflujo, to_number(entidad_id) idmst ',
'    from t_flujo_aprobacion_cab where codmodulo = ''CMEX'' and entidad_clase = ''IMPORTACION_MUESTRAS'' and etapa = ''BORRADOR''',
'    group by to_number(entidad_id)',
')select id',
'	, usercrea',
'	, fechacrea',
'	, usermodifica',
'	, fechamodifica',
'	, tipo',
'	, regimen',
'	, idproceso',
'	, decode(estado,0,''Ingresado'',1,''En Ruta'',''Aprobado'') estado',
'	, codigoproveedor',
'	, centrodecosto',
'	, numerofactura',
'	, paisorigen',
'	, forwarder',
'	, icoterm',
'	, nuevoproveedor',
'	, pk_corp_flujoaprobacion.f_mesaiconoruta(:app_user) ruta',
'	, b.idflujo',
'from t_cmex_muestras a',
'left join w_flj b on a.id = b. idmst'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>unistr('Importaci\00F3n Muestras')
,p_updated_on=>wwv_flow_imp.dz('20241216202643Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(164162888885432092)
,p_name=>unistr('Importaci\00F3n Muestras')
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_detail_link=>'f?p=&APP_ID.:233:&SESSION.::&DEBUG.:RP,:P233_ID:\#ID#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'MALBAN'
,p_internal_uid=>164162888885432092
,p_updated_on=>wwv_flow_imp.dz('20241216202643Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(164163206845432106)
,p_db_column_name=>'ID'
,p_display_order=>0
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(164163644597432107)
,p_db_column_name=>'USERCREA'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Solicitante'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(164164076239432107)
,p_db_column_name=>'FECHACREA'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Fecha Solicita'
,p_column_type=>'DATE'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(164164489593432107)
,p_db_column_name=>'USERMODIFICA'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Usermodifica'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(164164824912432108)
,p_db_column_name=>'FECHAMODIFICA'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Fechamodifica'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(164165231159432108)
,p_db_column_name=>'TIPO'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Tipo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(165396252152546724)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(164165629149432108)
,p_db_column_name=>'REGIMEN'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>unistr('R\00E9gimen')
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(165397324327558205)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(164166863952432108)
,p_db_column_name=>'CODIGOPROVEEDOR'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(165398581949586903)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(164167218826432109)
,p_db_column_name=>'CENTRODECOSTO'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Centro de <BR>Costo'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(179827823702629097)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(164167676549432109)
,p_db_column_name=>'NUMEROFACTURA'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>unistr('N\00FAmero <br>Factura')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(164168886317432110)
,p_db_column_name=>'FORWARDER'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Forwarder'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(164169250101432110)
,p_db_column_name=>'ICOTERM'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'incoterm'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(164051891003097037)
,p_db_column_name=>'PAISORIGEN'
,p_display_order=>26
,p_column_identifier=>'Q'
,p_column_label=>unistr('Pa\00EDs Or\00EDgen')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(171064509687714421)
,p_db_column_name=>'IDPROCESO'
,p_display_order=>36
,p_column_identifier=>'R'
,p_column_label=>'Idproceso'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(171064663654714422)
,p_db_column_name=>'ESTADO'
,p_display_order=>46
,p_column_identifier=>'S'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316594540613598829)
,p_db_column_name=>'NUEVOPROVEEDOR'
,p_display_order=>56
,p_column_identifier=>'T'
,p_column_label=>'Nuevo Proveedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(371022462532652433)
,p_db_column_name=>'RUTA'
,p_display_order=>66
,p_column_identifier=>'U'
,p_column_label=>'<span title="Ver Ruta"class="fa fa-road"/>'
,p_column_link=>'f?p=100:104:&SESSION.::&DEBUG.:RR,104:G_OBJETO,G_OBJETO_ID,G_TODO:IMPORTACION_MUESTRAS,#ID#,TRUE'
,p_column_linktext=>'#RUTA#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(371022546472652434)
,p_db_column_name=>'IDFLUJO'
,p_display_order=>76
,p_column_identifier=>'V'
,p_column_label=>'Idflujo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(164196404304434700)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1641965'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'USERCREA:FECHACREA:TIPO:REGIMEN:CODIGOPROVEEDOR:NUEVOPROVEEDOR:CENTRODECOSTO:NUMEROFACTURA:FORWARDER:ICOTERM:ESTADO:RUTA:'
,p_sort_column_1=>'ID'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20240830212054Z')
,p_updated_on=>wwv_flow_imp.dz('20240830212054Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(164169769141432110)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(164162795984432092)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:233:&SESSION.::&DEBUG.:13::'
,p_icon_css_classes=>'fa-plus-circle-o'
);
wwv_flow_imp.component_end;
end;
/
