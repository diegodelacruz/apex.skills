prompt --application/pages/page_00511
begin
--   Manifest
--     PAGE: 00511
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>511
,p_name=>unistr('COMEX - Datos Gesti\00F3n')
,p_alias=>unistr('COMEX-DATOS-GESTI\00D3N')
,p_step_title=>unistr('COMEX - Datos Gesti\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.conBorde {',
'    border: solid 2px darkgray;',
'    padding: 6px ! IMPORTANT;',
'}',
'',
'.c80 {',
'display: block; width: 80px; ',
'}',
'.c100 {',
'display: block; width: 100px; ',
'}',
'.c120 {',
'display: block; width: 120px; ',
'}',
'.c140 {',
'display: block; width: 140px; ',
'}',
'.c160 {',
'display: block; width: 160px; ',
'}',
'.c180 {',
'display: block; width: 180px; ',
'}',
'.c200 {',
'display: block; width: 200px; ',
'}',
'',
'.c250 {',
'display: block; width: 250px; ',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20241024191447Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260714192958Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(305638644671051507)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(305638910773051510)
,p_plug_name=>'Primero Elegir Booking'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'P511_DATOS_GESTION_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(306658209340898701)
,p_plug_name=>'NUEVO ATADO A BOOKING'
,p_parent_plug_id=>wwv_flow_imp.id(305638910773051510)
,p_region_css_classes=>'conBorde'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'1=0'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20251006194229Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(306658624530898705)
,p_plug_name=>'NUEVO no atado a booking'
,p_parent_plug_id=>wwv_flow_imp.id(305638910773051510)
,p_region_css_classes=>'conBorde'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(305647551518091721)
,p_plug_name=>'&P511_TITULO.'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296122226350169167)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(306659473531898713)
,p_plug_name=>'Cabecera'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P511_DATOS_GESTION_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(306660429893898723)
,p_plug_name=>'Booking'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P511_DATOS_GESTION_ID'
,p_plug_read_only_when_type=>'EXPRESSION'
,p_plug_read_only_when=>'NOT(:P511_BOOKING_ID IS NULL AND :P511_ESTADO=''REGISTRADO'' AND :P511_USUARIO = :APP_USER)'
,p_plug_read_only_when2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(306662199155898740)
,p_plug_name=>'Detalles'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    DET.ID                 AS ID,',
'    ''<span title="Ir al detalle" class="fa fa-pencil" id="''||DET.ID||''_DET"></span>''',
'                           AS ICONO_LINK,    ',
'',
'    CONTROL_ZAIMELLA       AS CONTROL_ZAIMELLA,',
'    INSPECTOR_BIVAC        AS INSPECTOR_BIVAC,',
'    INSPECTOR_CAMPAMENTO   AS INSPECTOR_CAMPAMENTO,',
'',
'    DET.CONTENEDOR_TIPO    AS CONTENEDOR_TIPO,',
'    DET.CONTENEDOR_NUMERO  AS CONTENEDOR_NUMERO,',
'    DET.CONTENEDOR_DIMENSIONES  AS CONTENEDOR_DIMENSIONES,',
'    ROUND(DET.CONTENEDOR_M3, 2) AS CONTENEDOR_M3,',
'',
'',
'    DET.SELLO_ZAIMELLA     AS SELLO_ZAIMELLA,',
'    DET.CHECK_DE_SEGURIDAD AS CHECK_DE_SEGURIDAD,',
'',
'    ''<span title="Subir Sello Naviera" class="fa fa-id-badge"></span>''   ',
'                           AS ICONO_SELLOS_NAVIERA,',
'    DET.SELLOS_NAVIERA     AS SELLOS_NAVIERA,',
'',
'    ''<span title="Atar TURNO" class="fa fa-calendar"></span>''   ',
'                           AS ICONO_TURNO,',
'    TURNO_ID||'' ''||TURNO_IDVEHICULO||'' ''||TURNO_NOMBRES||'' ''||TURNO_FECHADESDE_HORA ',
'                           AS TURNO_DETALLE,',
'',
'    ''<span title="Cargar ASIV/DAE" class="fa fa-file-wrench"></span>''   ',
'                           AS ICONO_AISV_DAE,',
'    DET.AISV_DAE_RESUMEN   AS AISV_DAE_RESUMEN,',
'    DET.PEDIDOS            AS PEDIDOS,',
'',
'    DET.FECHA_REGISTRO     AS FECHA',
'FROM ',
'    VT_CMEX_DATOS_GESTION_DETALLE DET',
'WHERE',
'    DET.DATOS_GESTION_ID = :P511_DATOS_GESTION_ID',
';',
'',
'',
'            '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P511_DATOS_GESTION_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Detalles'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20260402161838Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(306662288221898741)
,p_max_row_count=>'1000000'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>306662288221898741
,p_updated_on=>wwv_flow_imp.dz('20260402161838Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(306662315490898742)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'#'
,p_column_link=>'f?p=&APP_ID.:512:&SESSION.::&DEBUG.:512:P512_DATOS_GESTION_DETALLE_ID,P512_EDITAR_CARGUE,P512_EDITAR_DOCUMENTAL,P512_EDITAR_REVISADO:#ID#,&P511_EDITAR_CARGUE.,&P511_EDITAR_DOCUMENTAL.,&P511_EDITAR_REVISADO.'
,p_column_linktext=>'#ID#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(332268028489974028)
,p_db_column_name=>'ICONO_LINK'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'.'
,p_column_link=>'f?p=&APP_ID.:512:&SESSION.::&DEBUG.:512:P512_DATOS_GESTION_DETALLE_ID,P512_EDITAR_CARGUE,P512_EDITAR_DOCUMENTAL:#ID#,&P511_EDITAR_CARGUE.,&P511_EDITAR_DOCUMENTAL.'
,p_column_linktext=>'#ICONO_LINK#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(306662568571898744)
,p_db_column_name=>'CONTENEDOR_TIPO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Cont. Tip.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(306662629587898745)
,p_db_column_name=>'CONTENEDOR_NUMERO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Cont. Numero'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(306662715030898746)
,p_db_column_name=>'CONTENEDOR_DIMENSIONES'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Dim.'
,p_column_html_expression=>'<span class="c80">#CONTENEDOR_DIMENSIONES#</span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(306662890206898747)
,p_db_column_name=>'CONTENEDOR_M3'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'M3'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(306662968872898748)
,p_db_column_name=>'FECHA'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(308251327596332031)
,p_db_column_name=>'CONTROL_ZAIMELLA'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Control Zaimella'
,p_column_html_expression=>'<span class="c250">#CONTROL_ZAIMELLA#</span>'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(9325769164189234)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260402161837Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(308251417211332032)
,p_db_column_name=>'INSPECTOR_BIVAC'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Inspector BIVAC'
,p_column_html_expression=>'<span class="c250">#INSPECTOR_BIVAC#</span>'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(9313907878155313)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260402161838Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(308251549970332033)
,p_db_column_name=>'INSPECTOR_CAMPAMENTO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Inspector Campamento'
,p_column_html_expression=>'<span class="c250">#INSPECTOR_CAMPAMENTO#</span>'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(9315598798158513)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260402161838Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(311037962390669814)
,p_db_column_name=>'ICONO_SELLOS_NAVIERA'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'@'
,p_column_link=>'f?p=&APP_ID.:513:&SESSION.::&DEBUG.:513:P513_DATOS_GESTION_DETALLE_ID:#ID#'
,p_column_linktext=>'#ICONO_SELLOS_NAVIERA#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P511_ESTADO=''REGISTRADO'' AND :P511_USUARIO = :APP_USER'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(311039014471669825)
,p_db_column_name=>'SELLOS_NAVIERA'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Sellos Naviera'
,p_column_html_expression=>'<span class="c250">#SELLOS_NAVIERA#</span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(312480540996335107)
,p_db_column_name=>'ICONO_TURNO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'@'
,p_column_link=>'f?p=&APP_ID.:515:&SESSION.::&DEBUG.:515:P515_DATOS_GESTION_DETALLE_ID:#ID#'
,p_column_linktext=>'#ICONO_TURNO#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P511_ESTADO=''REGISTRADO'' AND :P511_USUARIO = :APP_USER'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(312480641424335108)
,p_db_column_name=>'TURNO_DETALLE'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Turno'
,p_column_html_expression=>'<span class="c250">#TURNO_DETALLE#</span>'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(312930377383670401)
,p_db_column_name=>'SELLO_ZAIMELLA'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Sello Zaimella'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(312930480763670402)
,p_db_column_name=>'CHECK_DE_SEGURIDAD'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Check De Seguridad'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(313663276289288524)
,p_db_column_name=>'ICONO_AISV_DAE'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'@'
,p_column_link=>'f?p=&APP_ID.:516:&SESSION.::&DEBUG.:516:P516_DATOS_GESTION_DETALLE_ID,P516_EDITAR_CARGUE:#ID#,&P511_EDITAR_CARGUE.'
,p_column_linktext=>'#ICONO_AISV_DAE#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P511_ESTADO NOT IN (''REGISTRADO'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(313663412154288526)
,p_db_column_name=>'AISV_DAE_RESUMEN'
,p_display_order=>180
,p_column_identifier=>'S'
,p_column_label=>'ASIV / DAE'
,p_column_html_expression=>'<span class="c120">#AISV_DAE_RESUMEN#</span>'
,p_column_type=>'STRING'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P511_ESTADO NOT IN (''REGISTRADO'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(332268698655974034)
,p_db_column_name=>'PEDIDOS'
,p_display_order=>190
,p_column_identifier=>'U'
,p_column_label=>'Pedidos'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(308245071536293186)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3082451'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:ICONO_LINK:CONTENEDOR_TIPO:CONTROL_ZAIMELLA:INSPECTOR_BIVAC:INSPECTOR_CAMPAMENTO:CONTENEDOR_NUMERO:CONTENEDOR_DIMENSIONES:CONTENEDOR_M3:SELLO_ZAIMELLA:CHECK_DE_SEGURIDAD:PEDIDOS:SELLOS_NAVIERA:TURNO_DETALLE:ICONO_AISV_DAE:AISV_DAE_RESUMEN:'
,p_sort_column_1=>'ID'
,p_sort_direction_1=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20241024191447Z')
,p_updated_on=>wwv_flow_imp.dz('20241024191447Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(305638794257051508)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(305638644671051507)
,p_button_name=>'REGRESAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:510:&SESSION.::&DEBUG.:::'
,p_button_condition=>'UPPER(:APP_USER) <> ''NOBODY'''
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-arrow-left'
,p_updated_on=>wwv_flow_imp.dz('20260714192958Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(312930663482670404)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(305638644671051507)
,p_button_name=>'ENVIAR_REGISTRADO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Enviar Registrado'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P511_ESTADO=''REGISTRADO'' AND :P511_USUARIO = :APP_USER'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-check-circle-o'
,p_updated_on=>wwv_flow_imp.dz('20241227154623Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(313665264754288544)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(305638644671051507)
,p_button_name=>'ENVIAR_CARGUE'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Enviar Cargue'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P511_ESTADO=''CARGUE'' AND :P511_EDITAR_CARGUE = 1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-check-circle-o'
,p_updated_on=>wwv_flow_imp.dz('20241227154623Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(318300733385653245)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(305638644671051507)
,p_button_name=>'ENVIAR_DOCUMENTAL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Enviar Documental'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P511_EDITAR_DOCUMENTAL = 1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-check-circle-o'
,p_updated_on=>wwv_flow_imp.dz('20241227154623Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(322277707513759108)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(305638644671051507)
,p_button_name=>'RECHAZAR_REVISADO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Rechazar Revisado'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P511_EDITAR_REVISADO = 1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-times-circle-o'
,p_updated_on=>wwv_flow_imp.dz('20241227154623Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(322277170631759102)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(305638644671051507)
,p_button_name=>'ENVIAR_REVISADO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Enviar Documental'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P511_EDITAR_REVISADO = 1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-check-circle-o'
,p_updated_on=>wwv_flow_imp.dz('20241227154623Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(311039765979669832)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(305638644671051507)
,p_button_name=>'ABRE_AGREGAR_CONTENEDOR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Agregar Contenedor'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:514:&SESSION.::&DEBUG.:514:P514_DATOS_GESTION_ID:&P511_DATOS_GESTION_ID.'
,p_button_condition=>':P511_ESTADO=''REGISTRADO'' AND :P511_USUARIO = :APP_USER AND :P511_DATOS_GESTION_ID IS NOT NULL AND :P511_BOOKING_ID IS NULL'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-plus'
,p_updated_on=>wwv_flow_imp.dz('20241227154623Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(306661928337898738)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(305638644671051507)
,p_button_name=>'GRABAR_CABECERA'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Grabar Cabecera'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_button_condition=>':P511_ESTADO=''REGISTRADO'' AND :P511_USUARIO = :APP_USER'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-save'
,p_updated_on=>wwv_flow_imp.dz('20241227154623Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(306658407501898703)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(306658209340898701)
,p_button_name=>'CREAR_CON_BOOKING'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Crear Con Booking'
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(306658828723898707)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(306658624530898705)
,p_button_name=>'CREAR_SIN_BOOKING'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Crear Sin Booking'
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(312930794067670405)
,p_branch_name=>'Go To Page 510 ENVIAR_REGISTRADO'
,p_branch_action=>'f?p=&APP_ID.:510:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(312930663482670404)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(313665609589288548)
,p_branch_name=>'Go To Page 510 ENVIAR_CARGUE'
,p_branch_action=>'f?p=&APP_ID.:510:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(313665264754288544)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(318301192342653249)
,p_branch_name=>'Go To Page 510 ENVIAR_DOCUMENTAL'
,p_branch_action=>'f?p=&APP_ID.:510:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(318300733385653245)
,p_branch_sequence=>30
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(322277546944759106)
,p_branch_name=>'Go To Page 510 ENVIAR_REVISADO'
,p_branch_action=>'f?p=&APP_ID.:510:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(322277170631759102)
,p_branch_sequence=>40
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(322278255799759113)
,p_branch_name=>'Go To Page 510 RECHAZAR_REVISADO'
,p_branch_action=>'f?p=&APP_ID.:510:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(322277707513759108)
,p_branch_sequence=>50
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(305638464416051505)
,p_name=>'P511_TITULO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(305647551518091721)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(305638805779051509)
,p_name=>'P511_DATOS_GESTION_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(305647551518091721)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(306658333605898702)
,p_name=>'P511_BOOKING_SELECCIONADO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(306658209340898701)
,p_prompt=>'Booking'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_CMEX_BOOKING'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ID,',
'    NUMERO_BK,',
'    CLIENTE_NOMBRES,',
'    TRUNC(FECHA_PLAN_CARGUE) FECHA_PLAN_CARGUE',
'FROM VT_CMEX_BOOKING_MESA_TRABAJO',
'WHERE 1=1',
'-- AND ESTADO=''COMPLETADO''',
'-- AND NUMERO_BK IS NOT NULL',
';',
''))
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(306658794027898706)
,p_name=>'P511_BOOKING_INGRESADO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(306658624530898705)
,p_prompt=>'Digitar Booking'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(306659282301898711)
,p_name=>'P511_BOOKING_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(306660429893898723)
,p_prompt=>'BKG ID'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(306659344981898712)
,p_name=>'P511_NUMERO_BK'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(306659473531898713)
,p_prompt=>unistr('N\00FAmero BK')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(306659501409898714)
,p_name=>'P511_ESTADO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(306659473531898713)
,p_prompt=>'Estado'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(306659683397898715)
,p_name=>'P511_USUARIO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(306659473531898713)
,p_prompt=>'Solicita'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(306659778808898716)
,p_name=>'P511_FECHA_REGISTRO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(306659473531898713)
,p_prompt=>'Fecha'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(306659971973898718)
,p_name=>'P511_CLIENTE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(306660429893898723)
,p_prompt=>'Cliente'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'SELECT CODIGO||'' ''||NOMBRES, CODIGO FROM VT_JDE_CLIENTE;'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(306660009250898719)
,p_name=>'P511_FECHA_PLAN_CARGUE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(306660429893898723)
,p_prompt=>'Fecha Est. Carga'
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20250128202103Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(306660170140898720)
,p_name=>'P511_DESTINO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(306660429893898723)
,p_prompt=>'Destino'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ID_TABLA||'' - ''||DESCRIPCION AS NOMBRE,',
'    ID_TABLA    AS ID',
'FROM T_CORP_UDC',
'WHERE ID_CABECERA=''1228''',
'ORDER BY DESCRIPCION;',
'    '))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(306660545819898724)
,p_name=>'P511_FECHA_MINIMA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(305647551518091721)
,p_source=>'SELECT TO_CHAR(SYSDATE+4, ''YYYY-MM-DD'') FROM DUAL;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(313661194370288503)
,p_name=>'P511_EDITAR_CARGUE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(305647551518091721)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P511_ESTADO = ''CARGUE'' ',
'		AND ',
'	PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES(''CMEX'', :APP_USER, :APP_PAGE_ID, ''CARGUE'')=1 ',
'THEN ',
'    RETURN 1;',
'ELSE ',
'    RETURN 0;    ',
'END IF;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(313661238476288504)
,p_name=>'P511_EDITAR_DOCUMENTAL'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(305647551518091721)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P511_ESTADO = ''DOCUMENTAL''',
'THEN ',
'    RETURN 1;',
'ELSE ',
'    RETURN 0;    ',
'END IF;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260714192859Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(313661374509288505)
,p_name=>'P511_EDITAR_REVISADO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(305647551518091721)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P511_ESTADO = ''REVISADO'' ',
'		AND ',
'	PK_ADMI_GESTIONPARAMETROS.F_ADMI_ACCESOACCIONES(''CMEX'', :APP_USER, :APP_PAGE_ID, ''REVISADO'')=1 ',
'THEN ',
'    RETURN 1;',
'ELSE ',
'    RETURN 0;    ',
'END IF;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(306658988873898708)
,p_validation_name=>'CREAR_CON_BOOKING'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P511_BOOKING_SELECCIONADO IS NULL THEN',
'    RETURN ''Debe seleccionar un BOOKING de la lista'';',
'END IF;',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(306658407501898703)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(306663051705898749)
,p_validation_name=>'CREAR_SIN_BOOKING'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P511_BOOKING_INGRESADO IS NULL THEN',
unistr('    RETURN ''Debe digitar el n\00FAmero de booking'';'),
'END IF;',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(306658828723898707)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(312930557241670403)
,p_validation_name=>'ENVIAR_REGISTRADO'
,p_validation_sequence=>30
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    V_COUNT  NUMBER;',
'    V_ID     NUMBER;',
'BEGIN',
'    -- VALIDACIONES DE CABECERA',
'    IF :P511_CLIENTE IS NULL THEN',
'        RETURN ''Debe seleccionar un cliente'';',
'    END IF;',
'',
'    IF :P511_FECHA_PLAN_CARGUE IS NULL THEN',
'        RETURN ''Debe especificar una FECHA CARGUE'';',
'    END IF;',
'',
'    -- VALIDACIONES DE DETALLE',
'    SELECT COUNT(1) INTO V_COUNT FROM T_CMEX_DATOS_GESTION_DETALLE WHERE DATOS_GESTION_ID=:P511_DATOS_GESTION_ID;',
'    IF V_COUNT = 0 THEN',
'        RETURN ''Debe agregar al menos un contenedor'';',
'    END IF;',
'',
'    -- SELLO_ZAIMELLA',
'    SELECT NVL((SELECT ID FROM T_CMEX_DATOS_GESTION_DETALLE WHERE DATOS_GESTION_ID=:P511_DATOS_GESTION_ID AND ROWNUM <=1 AND SELLO_ZAIMELLA IS NULL), NULL) ',
'    INTO   V_ID',
'    FROM DUAL;',
'    IF V_ID IS NOT NULL THEN',
'        RETURN ''Debe especificar un SELLO ZAIMELLA al #''||V_ID;',
'    END IF;',
'',
'    -- CHECK_DE_SEGURIDAD',
'    SELECT NVL((SELECT ID FROM T_CMEX_DATOS_GESTION_DETALLE WHERE DATOS_GESTION_ID=:P511_DATOS_GESTION_ID AND ROWNUM <=1 AND CHECK_DE_SEGURIDAD IS NULL), NULL) ',
'    INTO   V_ID',
'    FROM DUAL;',
'    IF V_ID IS NOT NULL THEN',
'        RETURN ''Debe especificar un CHECK DE SEGURIDAD al #''||V_ID;',
'    END IF;',
'',
'    RETURN NULL;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(312930663482670404)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(313665151864288543)
,p_validation_name=>'ENVIAR_CARGUE'
,p_validation_sequence=>40
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    V_COUNT  NUMBER;',
'    V_ID     NUMBER;',
'BEGIN',
'',
'    -- AISV OBLIGATORIO solo con booking.',
'    IF :P511_NUMERO_BK IS NOT NULL THEN',
'        SELECT NVL((SELECT ID FROM T_CMEX_DATOS_GESTION_DETALLE WHERE DATOS_GESTION_ID=:P511_DATOS_GESTION_ID AND ROWNUM <=1 AND AISV_ARCHIVO IS NULL), NULL) ',
'        INTO   V_ID',
'        FROM   DUAL;',
'        IF V_ID IS NOT NULL THEN',
'            RETURN ''Debe subir el archivo AISV al #''||V_ID;',
'        END IF;',
'    END IF;',
'',
'    -- SI SUBIO ARCHIVO DAE DEBE DETALLAR EL DAE',
'    SELECT NVL((SELECT ID FROM T_CMEX_DATOS_GESTION_DETALLE WHERE DATOS_GESTION_ID=:P511_DATOS_GESTION_ID AND ROWNUM <=1 AND DAE_ARCHIVO IS NOT NULL AND DAE IS NULL), NULL) ',
'    INTO   V_ID',
'    FROM   DUAL;',
'    IF V_ID IS NOT NULL THEN',
'        RETURN ''Debe detallar el DAE al #''||V_ID;',
'    END IF;',
'',
'',
'    RETURN NULL;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(313665264754288544)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(318300660758653244)
,p_validation_name=>'ENVIAR_DOCUMENTAL'
,p_validation_sequence=>50
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    V_ID  NUMBER;',
'BEGIN',
'    -- FACTURA OBLIGATORIO',
'    BEGIN',
'        SELECT DET.ID INTO V_ID',
'        FROM ',
'            T_CMEX_DATOS_GESTION_DETALLE  DET LEFT JOIN ',
'            VT_CMEX_DATOS_GESTION_DOCMTOS DOCS',
'                ON DET.DATOS_GESTION_ID = DOCS.DATOS_GESTION_ID AND DET.ID = DOCS.ID AND DOCS.TIPO=''FACTURA''',
'        WHERE',
'            DET.DATOS_GESTION_ID = :P511_DATOS_GESTION_ID',
'            AND DOCS.TIPO IS NULL',
'            AND ROWNUM <= 1;',
'    EXCEPTION WHEN NO_DATA_FOUND THEN NULL;',
'    END;',
'',
'    IF V_ID IS NOT NULL THEN',
'        RETURN ''Debe cargar la FACTURA en el #''||V_ID;',
'    END IF;',
'',
'    -- LISTA DE EMPAQUE OBLIGATORIO',
'    BEGIN',
'        SELECT DET.ID INTO V_ID',
'        FROM ',
'            T_CMEX_DATOS_GESTION_DETALLE  DET LEFT JOIN ',
'            VT_CMEX_DATOS_GESTION_DOCMTOS DOCS',
'                ON DET.DATOS_GESTION_ID = DOCS.DATOS_GESTION_ID AND DET.ID = DOCS.ID AND DOCS.TIPO=''LISTA_EMPAQUE''',
'        WHERE',
'            DET.DATOS_GESTION_ID = :P511_DATOS_GESTION_ID',
'            AND DOCS.TIPO IS NULL',
'            AND ROWNUM <= 1;',
'    EXCEPTION WHEN NO_DATA_FOUND THEN NULL;',
'    END;',
'',
'    IF V_ID IS NOT NULL THEN',
'        RETURN ''Debe cargar la LISTA DE EMPAQUE en el #''||V_ID;',
'    END IF;    ',
'',
'    RETURN NULL;',
'END;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(318300733385653245)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(311038094376669815)
,p_name=>'Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(306662199155898740)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(311038160202669816)
,p_event_id=>wwv_flow_imp.id(311038094376669815)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(312930939366670407)
,p_name=>'ENVIAR_REGISTRADO'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(312930663482670404)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(312931060838670408)
,p_event_id=>wwv_flow_imp.id(312930939366670407)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Enviar REGISTRADO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(312931180237670409)
,p_event_id=>wwv_flow_imp.id(312930939366670407)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'ENVIAR_REGISTRADO'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(313665314098288545)
,p_name=>'ENVIAR_CARGUE'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(313665264754288544)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(313665419032288546)
,p_event_id=>wwv_flow_imp.id(313665314098288545)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Enviar CARGUE ?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(313665526877288547)
,p_event_id=>wwv_flow_imp.id(313665314098288545)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'ENVIAR_CARGUE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(318300896399653246)
,p_name=>'ENVIAR_DOCUMENTAL'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(318300733385653245)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(318300918340653247)
,p_event_id=>wwv_flow_imp.id(318300896399653246)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Enviar DOCUMENTAL ?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(318301005496653248)
,p_event_id=>wwv_flow_imp.id(318300896399653246)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'ENVIAR_DOCUMENTAL'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(322277280045759103)
,p_name=>'ENVIAR_REVISADO'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(322277170631759102)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(322277324925759104)
,p_event_id=>wwv_flow_imp.id(322277280045759103)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Enviar REVISADO ?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(322277464144759105)
,p_event_id=>wwv_flow_imp.id(322277280045759103)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'ENVIAR_REVISADO'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(322277851462759109)
,p_name=>'RECHAZAR_REVISADO'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(322277707513759108)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(322277933560759110)
,p_event_id=>wwv_flow_imp.id(322277851462759109)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'RECHAZAR REVISADO ? Se regresa a DOCUMENTAL.'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(322278082670759111)
,p_event_id=>wwv_flow_imp.id(322277851462759109)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'RECHAZAR_REVISADO'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(306659044393898709)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CREAR_CON_BOOKING'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_DATOS_GESTION.SP_DATOS_GESTION_NUEVO(',
'    :G_COMPANIA,',
'    :APP_USER,',
'    :P511_BOOKING_SELECCIONADO,',
'    NULL,',
'    ------------------',
'    :P511_DATOS_GESTION_ID',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(306658407501898703)
,p_internal_uid=>306659044393898709
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(306660642194898725)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CREAR_SIN_BOOKING'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_DATOS_GESTION.SP_DATOS_GESTION_NUEVO(',
'    :G_COMPANIA,',
'    :APP_USER,',
'    NULL,',
'    :P511_BOOKING_INGRESADO,',
'    ------------------',
'    :P511_DATOS_GESTION_ID',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(306658828723898707)
,p_internal_uid=>306660642194898725
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(306662030239898739)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GRABAR_CABECERA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_DATOS_GESTION.SP_DATOS_GESTION_CABECERA_GRABA(',
'    :P511_DATOS_GESTION_ID,',
'    :P511_CLIENTE,',
'    :P511_FECHA_PLAN_CARGUE,',
'    :P511_DESTINO',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(306661928337898738)
,p_internal_uid=>306662030239898739
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(312931211882670410)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ENVIAR_REGISTRADO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_DATOS_GESTION.SP_ENVIAR_REGISTRADO(',
'    :P511_DATOS_GESTION_ID,',
'    :APP_USER',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(312930663482670404)
,p_internal_uid=>312931211882670410
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(313665779382288549)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ENVIAR_CARGUE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_DATOS_GESTION.SP_ENVIAR_CARGUE(',
'    :P511_DATOS_GESTION_ID,',
'    :APP_USER',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(313665264754288544)
,p_internal_uid=>313665779382288549
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(318301231439653250)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ENVIAR_DOCUMENTAL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_DATOS_GESTION.SP_ENVIAR_DOCUMENTAL(',
'    :P511_DATOS_GESTION_ID,',
'    :APP_USER',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(318300733385653245)
,p_internal_uid=>318301231439653250
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(322277686322759107)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ENVIAR_REVISADO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_DATOS_GESTION.SP_ENVIAR_REVISADO(',
'    :P511_DATOS_GESTION_ID,',
'    :APP_USER',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(322277170631759102)
,p_internal_uid=>322277686322759107
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(322278179734759112)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RECHAZAR_REVISADO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_DATOS_GESTION.SP_RECHAZAR_REVISADO(',
'    :P511_DATOS_GESTION_ID,',
'    :APP_USER',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(322277707513759108)
,p_internal_uid=>322278179734759112
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(306659154663898710)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Carga DATOS GESTI\00D3N')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P511_DATOS_GESTION_ID IS NOT NULL THEN',
'    SELECT',
'        USUARIO,',
'        ESTADO,',
'		CASE WHEN ESTADO = ''DOCUMENTAL'' then 1 else -1 end estado_511,',
'        BOOKING_ID,',
'        NUMERO_BK,',
'        CLIENTE,',
'        TO_CHAR(FECHA_PLAN_CARGUE, ''DD-MM-YYYY''),',
'        DESTINO,',
'        TO_CHAR(FECHA_REGISTRO, ''DD/MM/YYYY HH24:MI'')',
'    INTO',
'        :P511_USUARIO,',
'        :P511_ESTADO,',
'		:P511_EDITAR_DOCUMENTAL,',
'        :P511_BOOKING_ID,',
'        :P511_NUMERO_BK,',
'        :P511_CLIENTE,',
'        :P511_FECHA_PLAN_CARGUE,',
'        :P511_DESTINO,',
'        :P511_FECHA_REGISTRO',
'    FROM',
'        T_CMEX_DATOS_GESTION',
'    WHERE ID = :P511_DATOS_GESTION_ID;',
'END IF;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>306659154663898710
,p_updated_on=>wwv_flow_imp.dz('20260714192859Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(305638579830051506)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Carga T\00EDtulo')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'	IF :P511_DATOS_GESTION_ID IS NULL THEN',
unistr('		:P511_TITULO := ''Nuevo Datos de Gesti\00F3n'';'),
'	END IF;',
'/*',
'	IF :P511_DATOS_GESTION_ID IS NOT NULL THEN',
unistr('		:P511_TITULO := ''Datos de Gesti\00F3n Nro. ''||:P511_DATOS_GESTION_ID;'),
'	END IF;',
'*/',
'END;',
'',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>305638579830051506
,p_updated_on=>wwv_flow_imp.dz('20260714192859Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
