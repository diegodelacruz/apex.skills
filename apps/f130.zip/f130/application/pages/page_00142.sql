prompt --application/pages/page_00142
begin
--   Manifest
--     PAGE: 00142
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>142
,p_name=>unistr('Negociaci\00F3n - Hist\00F3rico de Compras Proveedores')
,p_alias=>'NEGOCIACION-REPORTE-DE-PRODUCTO-PROVEEDORES'
,p_page_mode=>'NON_MODAL'
,p_step_title=>unistr('Negociaci\00F3n - Hist\00F3rico de Compras Proveedores')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(secItems).hide();',
'$s(''P142_TABS'','''');',
'',
'$(''.apex-rds'').data(''onRegionChange'', function(mode, activeTab) {',
'    $(''#btnPrint'').hide();',
'    $s(''P142_TABS'',activeTab.href);',
'    switch($v(''P142_TABS'') ) { ',
'        case ''#rptEvolucion'':$(''#btnPrint'').show();break;',
'    }',
'});'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-button.a-IRR-sortWidget-button[data-option="hide"], .a-IRR-button.a-IRR-sortWidget-button[data-option="freeze"]{',
'    display:none;',
'}',
'.a-IG-controls-item--aggregate, .a-IG-controls-item--controlBreak, .a-IG-controls-item--groupBy, .a-IG-reportSummary-item--aggregate, .a-IG-reportSummary-item--controlBreak, .a-IG-reportSummary-item--groupBy, .a-IRR-controls-item--aggregate, .a-IRR-c'
||'ontrols-item--controlBreak, .a-IRR-controls-item--groupBy, .a-IRR-reportSummary-item--aggregate, .a-IRR-reportSummary-item--controlBreak, .a-IRR-reportSummary-item--groupBy {',
'    --a-report-controls-cell-label-icon-background-color: #3b83bd;',
'    --a-report-controls-cell-label-hover-background-color: #e6f0f7;',
'    display: none;',
'}',
'.a-IRR-chartView, .a-IRR-controlsContainer, .a-IRR-detailView, .a-IRR-groupByView, .a-IRR-iconViewTable, .a-IRR-pivotView {',
'    border-top-color: #E6E6E6;',
'    display: none;',
'}',
'.TextoEditable',
'{',
'    width: 60px;',
'    background-color: #d0f5fd87;',
'    border:none;',
'    text-align: right;',
'    border-radius: 5px;',
'    border-style: groove;',
'    border-width: thin;',
'}',
'.TextoNoEditable',
'{',
'    width: 60px;',
'    background-color: transparent;',
'    border:none;',
'    text-align: right;',
'    border-radius: 5px;',
'    border-style: none;',
'    border-width: none;',
'}',
'',
'',
' ',
'',
'#SERIE1 { font-size: xx-small;}',
'#SERIE2 { font-size: xx-small;}',
'#SERIE3 { font-size: xx-small;}',
'#SERIE4 { font-size: xx-small;}',
''))
,p_step_template=>wwv_flow_imp.id(295596898750037659)
,p_page_template_options=>'#DEFAULT#'
,p_dialog_width=>'900'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240219201539Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240221190227Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43433471694543013)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>70
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43433511683543014)
,p_plug_name=>'BOTONES'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121809343169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(45201923276008008)
,p_plug_name=>'Parametros'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--hiddenOverflow'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295630388916037685)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(143507912172026718)
,p_plug_name=>'Reporte Historicos'
,p_region_name=>'historicoCompras'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(295630388916037685)
,p_plug_display_sequence=>20
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P142_TIPO'
,p_plug_display_when_cond2=>'1'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42651384579578849)
,p_plug_name=>'historico compras'
,p_region_name=>'histCabCompras'
,p_parent_plug_id=>wwv_flow_imp.id(143507912172026718)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NEG_ID, CAB_ID, DET_ID, PDAN8 ||'' - ''|| DESCRIPCION DESCRIPCION, trim(PDLITM) ||'' - ''|| PDDSC1 PDDSC1,  PDFRTH,NEG_VIGENCIADESDE ||'' - ''|| NEG_VIGENCIAHASTA NEG_VIGENCIA, NEG_VIGENCIADESDE, NEG_VIGENCIAHASTA, PDPRRC/10000 PDPRRC , CONTAR_OC, P'
||'DUORG/10000 PDUORG, PDAEXP/100 PDAEXP',
',PDAN8 PDAN81,PDPRRC PDPRRC1,PDFRTH PDFRTH1',
'FROM data.vt_comp_negociacionhoc',
'WHERE(( NVL(:P142_ID_DETALLE,0) =0 AND (NEG_ID = :P142_ID_NEG AND PDITM =:P142_PRODUCTOGRF)) OR ( NVL(:P142_ID_DETALLE,0) !=0 AND DET_ID=:P142_ID_DETALLE))',
'order by PDAN8,  PDPRRC',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P142_ID_DETALLE'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'historico compras'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(42651442700578850)
,p_max_row_count=>'1000000'
,p_allow_report_saving=>'N'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_textbox=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_select_columns=>'N'
,p_show_rows_per_page=>'N'
,p_show_filter=>'N'
,p_show_sort=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>42651442700578850
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43434579391543024)
,p_db_column_name=>'NEG_ID'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Neg Id'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'00000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43434648183543025)
,p_db_column_name=>'CAB_ID'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Cab Id'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43434704719543026)
,p_db_column_name=>'DET_ID'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Det Id'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45080140188050229)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>160
,p_column_identifier=>'Y'
,p_column_label=>'Proveedor'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45078760494050215)
,p_db_column_name=>'PDDSC1'
,p_display_order=>180
,p_column_identifier=>'Q'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45078872648050216)
,p_db_column_name=>'PDFRTH'
,p_display_order=>190
,p_column_identifier=>'R'
,p_column_label=>'Incoterm'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(74803172029355163)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45080204594050230)
,p_db_column_name=>'NEG_VIGENCIA'
,p_display_order=>200
,p_column_identifier=>'Z'
,p_column_label=>'Neg Vigencia'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45078930188050217)
,p_db_column_name=>'NEG_VIGENCIADESDE'
,p_display_order=>210
,p_column_identifier=>'S'
,p_column_label=>'Neg. Inicio Vigencia'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45079041609050218)
,p_db_column_name=>'NEG_VIGENCIAHASTA'
,p_display_order=>220
,p_column_identifier=>'T'
,p_column_label=>'Neg. Fin Vigencia'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45079203963050220)
,p_db_column_name=>'CONTAR_OC'
,p_display_order=>230
,p_column_identifier=>'U'
,p_column_label=>unistr('\00D3rdenes de Compra')
,p_column_link=>'f?p=&APP_ID.:142:&SESSION.::&DEBUG.::P142_PDAN8,P142_PDFRTH,P142_PDPRRC:#PDAN81#,#PDFRTH1#,#PDPRRC1#'
,p_column_linktext=>'Ver #CONTAR_OC# ordenes'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45080003416050228)
,p_db_column_name=>'PDPRRC'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Precio Prom.'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45079802266050226)
,p_db_column_name=>'PDUORG'
,p_display_order=>250
,p_column_identifier=>'V'
,p_column_label=>'Cantidad'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45079901717050227)
,p_db_column_name=>'PDAEXP'
,p_display_order=>260
,p_column_identifier=>'W'
,p_column_label=>'Total'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45201547879008004)
,p_db_column_name=>'PDPRRC1'
,p_display_order=>280
,p_column_identifier=>'AA'
,p_column_label=>'Pdprrc1'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45201666017008005)
,p_db_column_name=>'PDFRTH1'
,p_display_order=>290
,p_column_identifier=>'AB'
,p_column_label=>'Pdfrth1'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45201796365008006)
,p_db_column_name=>'PDAN81'
,p_display_order=>300
,p_column_identifier=>'AC'
,p_column_label=>'Pdan81'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(43441421086544999)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'434415'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NEG_ID:DESCRIPCION:PDFRTH:CONTAR_OC:PDUORG:PDPRRC:PDAEXP:'
,p_sort_column_1=>'PDAN81'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'PDDSC1:NEG_VIGENCIA:NEG_VIGENCIAHASTA:NEG_VIGENCIADESDE:0:0'
,p_break_enabled_on=>'PDDSC1:NEG_VIGENCIA:NEG_VIGENCIAHASTA:NEG_VIGENCIADESDE:0:0'
,p_created_on=>wwv_flow_imp.dz('20240219201539Z')
,p_updated_on=>wwv_flow_imp.dz('20240219201539Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(45080301104050231)
,p_plug_name=>unistr('Detalle OC\00B4s')
,p_region_name=>'histDetCompras'
,p_parent_plug_id=>wwv_flow_imp.id(143507912172026718)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NEG_ID,',
'       CAB_ID,',
'       DET_ID,',
'       pdan8,',
'       PDDOCO,',
'       PDDCTO,',
'       PDDOCO ||'' - ''||PDDCTO PDDOCO1,',
'       PDLITM ||'' - ''||PDDSC1 PDDSC1,',
'       PDFRTH,',
'       PK_COMMONS.F_JDE2G(PDTRDJ) PDTRDJ,',
'       PDPRRC/10000 PDPRRC,',
'       PDUORG/10000 PDUORG,',
'       PDAEXP/100 PDAEXP,',
'       CONTAR_OC',
'  from data.VT_COMP_NEGOCIACIONOC',
' where 1 = 1',
'and PDAN8=:P142_PDAN8',
'and nvl(trim(PDFRTH),''   '') = nvl(trim(:P142_PDFRTH),''   '')',
'-- and DET_ID=:P142_ID_DETALLE',
'AND (( NVL(:P142_ID_DETALLE,0) =0 AND (NEG_ID = :P142_ID_NEG AND PDITM =:P142_PRODUCTOGRF)) OR ( NVL(:P142_ID_DETALLE,0) !=0 AND DET_ID=:P142_ID_DETALLE))'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P142_PDAN8,P142_PDFRTH,P142_PDPRRC'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P142_PDAN8'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Detalle OC\00B4s')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(45080413863050232)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_textbox=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_select_columns=>'N'
,p_show_rows_per_page=>'N'
,p_show_filter=>'N'
,p_show_sort=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>45080413863050232
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45080514557050233)
,p_db_column_name=>'NEG_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Neg Id'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45080600595050234)
,p_db_column_name=>'CAB_ID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Cab Id'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45080716797050235)
,p_db_column_name=>'DET_ID'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Det Id'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45080806045050236)
,p_db_column_name=>'PDDOCO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Pddoco'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45080967344050237)
,p_db_column_name=>'PDDCTO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Pddcto'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45082037883050248)
,p_db_column_name=>'PDDOCO1'
,p_display_order=>60
,p_column_identifier=>'P'
,p_column_label=>'Orden de Compra'
,p_column_link=>'http://jasper.zaimella.com:8090/jasperserver/flow.html?_flowId=viewReportFlow&standAlone=true&_repFormat=pdf&output=pdf&_flowId=viewReportFlow&ParentFolderUri=/PRODUCCION/COMPRAS&reportUnit=/PRODUCCION/COMPRAS/rptOrdenCompras&j_username=desarrollo&j_'
||'password=desarrollo&_repLocale=en_US&_repEncoding=UTF-8&p_numero=#PDDOCO#&p_tipo=#PDDCTO#'
,p_column_linktext=>'#PDDOCO1#'
,p_column_link_attr=>'target="_blank"'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45081215307050240)
,p_db_column_name=>'PDDSC1'
,p_display_order=>70
,p_column_identifier=>'H'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45082142199050249)
,p_db_column_name=>'PDTRDJ'
,p_display_order=>80
,p_column_identifier=>'Q'
,p_column_label=>'Fecha OC'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45081354764050241)
,p_db_column_name=>'PDFRTH'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Incoterm'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(74803172029355163)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45081535406050243)
,p_db_column_name=>'PDPRRC'
,p_display_order=>100
,p_column_identifier=>'K'
,p_column_label=>'Precio Unit.'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45081688719050244)
,p_db_column_name=>'PDUORG'
,p_display_order=>110
,p_column_identifier=>'L'
,p_column_label=>'Cantidad'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45081799060050245)
,p_db_column_name=>'PDAEXP'
,p_display_order=>120
,p_column_identifier=>'M'
,p_column_label=>'Monto'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45081825974050246)
,p_db_column_name=>'CONTAR_OC'
,p_display_order=>130
,p_column_identifier=>'N'
,p_column_label=>'Contar Oc'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183797549110709122)
,p_db_column_name=>'PDAN8'
,p_display_order=>140
,p_column_identifier=>'R'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(135034190509484151)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(45192359084948962)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'451924'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PDAN8:PDDOCO1:PDTRDJ:PDFRTH:PDPRRC:PDUORG:PDAEXP:'
,p_sort_column_1=>'PDTRDJ'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'PDAN8:0:0:0:0:0'
,p_break_enabled_on=>'PDAN8:0:0:0:0:0'
,p_created_on=>wwv_flow_imp.dz('20240219201539Z')
,p_updated_on=>wwv_flow_imp.dz('20240219201539Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(145673743703365227)
,p_plug_name=>unistr('Reporte Evoluci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(295630388916037685)
,p_plug_display_sequence=>30
,p_plug_item_display_point=>'BELOW'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'N',
  'rds_mode', 'STANDARD',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(143508738498026726)
,p_plug_name=>unistr('Evoluci\00F3n de Precio de Compra')
,p_region_name=>'rptEvolucion'
,p_parent_plug_id=>wwv_flow_imp.id(145673743703365227)
,p_icon_css_classes=>'fa-line-chart'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM01||'' - ''||TXT01 Proveedor',
'    , to_number(num03||TXT05) ||''(''||TXT06||'')'' periodo2',
'    , TXT06 Periodo',
'    , NUM05 Precio',
'    , NUM06 Cantidad',
'    , NUM07 Monto',
'from T_APEX_TEMPORAL ',
'where   FLAG=''NEGOCIACION_GRAFICO_ORDENES_COMPRA'' ',
'and     CONTROL01=''00001'' ',
'and     CONTROL02=''COMP'' ',
'and     CONTROL03=UPPER(:P142_USUARIO)',
'and     CONTROL04= ''negociacion_sp_grafico_ordenes''',
'and     CONTROL05= to_number(:P142_ID_NEG)',
'order by Num03,Num04'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_ajax_items_to_submit=>'P142_ID_NEGOCIACION,P142_USUARIO'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P142_TIPO'
,p_plug_display_when_cond2=>'2'
,p_updated_on=>wwv_flow_imp.dz('20240221190227Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(143508839951026727)
,p_region_id=>wwv_flow_imp.id(143508738498026726)
,p_chart_type=>'line'
,p_title=>'Evolucion de Precio de Compra'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'on'
,p_data_cursor_behavior=>'smooth'
,p_hide_and_show_behavior=>'withoutRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_title=>'Proveedor:'
,p_legend_position=>'bottom'
,p_legend_font_size=>'10'
,p_overview_rendered=>'off'
,p_no_data_found_message=>unistr('No Existen datos para el grafico de evoluci\00F3n')
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ){ ',
'    options.dataFilter = function( data ) { ',
'        console.log(data);',
'        var s ;',
'        var c ;',
'        var colors = ["#33b2df","#546E7A","#d4526e","#13d8aa","#A5978B","#2b908f","#f9a3a4","#90ee7e","#f48024","#69d2e7"];',
'        for (s=0;s<data.series.length;s++) {',
'            c= colors[s];',
'            if (data.series[s].name==" - "){',
'                data.series[s].color = "#00000000";',
'                data.series[s].shortDesc = "";',
'            }else{',
'                data.series[s].color = c;',
'            }',
'        }',
'        return data;',
'    };',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(143508976198026728)
,p_chart_id=>wwv_flow_imp.id(143508839951026727)
,p_seq=>10
,p_name=>'Precio'
,p_location=>'REGION_SOURCE'
,p_series_name_column_name=>'PROVEEDOR'
,p_items_value_column_name=>'PRECIO'
,p_group_name_column_name=>'PROVEEDOR'
,p_group_short_desc_column_name=>'PROVEEDOR'
,p_items_label_column_name=>'PERIODO2'
,p_items_short_desc_column_name=>'PERIODO2'
,p_custom_column_name=>'PROVEEDOR'
,p_line_style=>'solid'
,p_line_width=>1
,p_line_type=>'curved'
,p_marker_rendered=>'auto'
,p_marker_shape=>'human'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'afterMarker'
,p_items_label_display_as=>'PERCENT'
,p_items_label_font_color=>'#0724c9'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(145671833746365208)
,p_chart_id=>wwv_flow_imp.id(143508839951026727)
,p_axis=>'y2'
,p_is_rendered=>'off'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'start'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_split_dual_y=>'auto'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(143509192127026730)
,p_chart_id=>wwv_flow_imp.id(143508839951026727)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'currency'
,p_decimal_places=>4
,p_currency=>'$'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'top'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'on'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(143509067419026729)
,p_chart_id=>wwv_flow_imp.id(143508839951026727)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'none'
,p_scaling=>'log'
,p_baseline_scaling=>'min'
,p_major_tick_rendered=>'on'
,p_min_step=>1
,p_minor_tick_rendered=>'on'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(145671270478365202)
,p_plug_name=>'Datos Series'
,p_region_name=>'secDetalle'
,p_parent_plug_id=>wwv_flow_imp.id(145673743703365227)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM01||'' - ''||TXT01 Proveedor',
'    , to_number(num03||TXT05) ||''(''||TXT06||'')'' periodo',
'    , NUM05 Precio',
'    , NUM06 Cantidad',
'    , NUM07 Monto',
'from T_APEX_TEMPORAL ',
'where   FLAG=''NEGOCIACION_GRAFICO_ORDENES_COMPRA'' ',
'and     CONTROL01=''00001'' ',
'and     CONTROL02=''COMP'' ',
'and     CONTROL03=UPPER(:P142_USUARIO)',
'and     CONTROL04= ''negociacion_sp_grafico_ordenes''',
'and     CONTROL05= to_number(:P142_ID_NEG)'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P142_ID_NEGOCIACION,P142_USUARIO'
,p_plug_column_width=>'style="font-size: smaller;"'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>' (:P142_TIPO IN (2,3,4))'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Datos Series'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20240221190227Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(149733531162703438)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_textbox=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_filter=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_notify=>'Y'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>149733531162703438
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(149733656228703439)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Proveedor'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(149733746109703440)
,p_db_column_name=>'PERIODO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Periodo'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(149733807509703441)
,p_db_column_name=>'PRECIO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Precio'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(149733974900703442)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Cantidad'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(149734089964703443)
,p_db_column_name=>'MONTO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Monto'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(150449093421543172)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1504491'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_view_mode=>'REPORT'
,p_report_columns=>'PROVEEDOR:PERIODO:PRECIO:CANTIDAD:MONTO'
,p_sort_column_1=>'PERIODO'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'PROVEEDOR'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20240219201539Z')
,p_updated_on=>wwv_flow_imp.dz('20240219201539Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(146083194430492832)
,p_plug_name=>unistr('Evoluci\00F3n de Cantidad de Compra')
,p_region_name=>'rptEvolucion'
,p_parent_plug_id=>wwv_flow_imp.id(145673743703365227)
,p_icon_css_classes=>'fa-line-chart'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM01||'' - ''||TXT01 Proveedor',
'    , to_number(num03||TXT05) ||''(''||TXT06||'')'' periodo2',
'    , TXT06 Periodo',
'    , NUM05 Precio',
'    , NUM06 Cantidad',
'    , NUM07 Monto',
'from T_APEX_TEMPORAL ',
'where   FLAG=''NEGOCIACION_GRAFICO_ORDENES_COMPRA'' ',
'and     CONTROL01=''00001'' ',
'and     CONTROL02=''COMP'' ',
'and     CONTROL03=UPPER(:P142_USUARIO)',
'and     CONTROL04= ''negociacion_sp_grafico_ordenes''',
'and     CONTROL05= to_number(:P142_ID_NEG)',
'order by Num03,Num04'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_ajax_items_to_submit=>'P142_ID_NEGOCIACION,P142_USUARIO'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P142_TIPO'
,p_plug_display_when_cond2=>'3'
,p_updated_on=>wwv_flow_imp.dz('20240221190227Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(146083223986492833)
,p_region_id=>wwv_flow_imp.id(146083194430492832)
,p_chart_type=>'line'
,p_title=>unistr('Evoluci\00F3n de Cantidad de Compra')
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'on'
,p_data_cursor_behavior=>'smooth'
,p_hide_and_show_behavior=>'withoutRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_title=>'Proveedor:'
,p_legend_position=>'bottom'
,p_legend_font_size=>'10'
,p_overview_rendered=>'off'
,p_no_data_found_message=>unistr('No Existen datos para el grafico de evoluci\00F3n')
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ){ ',
'    options.dataFilter = function( data ) { ',
'        console.log(data);',
'        var s ;',
'        var c ;',
'        var colors = ["#33b2df","#546E7A","#d4526e","#13d8aa","#A5978B","#2b908f","#f9a3a4","#90ee7e","#f48024","#69d2e7"];',
'        for (s=0;s<data.series.length;s++) {',
'            c= colors[s];',
'            if (data.series[s].name==" - "){',
'                data.series[s].color = "#00000000";',
'                data.series[s].shortDesc = "";',
'            }else{',
'                data.series[s].color = c;',
'            }',
'        }',
'        return data;',
'    };',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(146083389361492834)
,p_chart_id=>wwv_flow_imp.id(146083223986492833)
,p_seq=>10
,p_name=>'Cantidad'
,p_location=>'REGION_SOURCE'
,p_series_name_column_name=>'PROVEEDOR'
,p_items_value_column_name=>'CANTIDAD'
,p_group_name_column_name=>'PROVEEDOR'
,p_group_short_desc_column_name=>'PROVEEDOR'
,p_items_label_column_name=>'PERIODO2'
,p_items_short_desc_column_name=>'PERIODO2'
,p_custom_column_name=>'PROVEEDOR'
,p_line_style=>'solid'
,p_line_width=>1
,p_line_type=>'curved'
,p_marker_rendered=>'on'
,p_marker_shape=>'human'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'afterMarker'
,p_items_label_display_as=>'PERCENT'
,p_items_label_font_color=>'#0724c9'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(146083476522492835)
,p_chart_id=>wwv_flow_imp.id(146083223986492833)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'none'
,p_scaling=>'log'
,p_baseline_scaling=>'min'
,p_major_tick_rendered=>'on'
,p_min_step=>1
,p_minor_tick_rendered=>'on'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(146083647557492837)
,p_chart_id=>wwv_flow_imp.id(146083223986492833)
,p_axis=>'y2'
,p_is_rendered=>'off'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'start'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_split_dual_y=>'auto'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(146083504610492836)
,p_chart_id=>wwv_flow_imp.id(146083223986492833)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>2
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'top'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'on'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(146083763823492838)
,p_plug_name=>unistr('Evoluci\00F3n de Monto de Compra')
,p_region_name=>'rptEvolucion'
,p_parent_plug_id=>wwv_flow_imp.id(145673743703365227)
,p_icon_css_classes=>'fa-line-chart'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM01||'' - ''||TXT01 Proveedor',
'    , to_number(num03||TXT05) ||''(''||TXT06||'')'' periodo2',
'    , TXT06 Periodo',
'    , NUM05 Precio',
'    , NUM06 Cantidad',
'    , NUM07 Monto',
'from T_APEX_TEMPORAL ',
'where   FLAG=''NEGOCIACION_GRAFICO_ORDENES_COMPRA'' ',
'and     CONTROL01=''00001'' ',
'and     CONTROL02=''COMP'' ',
'and     CONTROL03=UPPER(:P142_USUARIO)',
'and     CONTROL04= ''negociacion_sp_grafico_ordenes''',
'and     CONTROL05= to_number(:P142_ID_NEG)',
'order by Num03,Num04'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_ajax_items_to_submit=>'P142_ID_NEGOCIACION,P142_USUARIO'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P142_TIPO'
,p_plug_display_when_cond2=>'4'
,p_updated_on=>wwv_flow_imp.dz('20240221190227Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(146083822491492839)
,p_region_id=>wwv_flow_imp.id(146083763823492838)
,p_chart_type=>'line'
,p_title=>'Evolucion de Monto de Compra'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'on'
,p_data_cursor_behavior=>'smooth'
,p_hide_and_show_behavior=>'withoutRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_title=>'Proveedor:'
,p_legend_position=>'bottom'
,p_legend_font_size=>'10'
,p_overview_rendered=>'off'
,p_no_data_found_message=>unistr('No Existen datos para el grafico de evoluci\00F3n')
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ){ ',
'    options.dataFilter = function( data ) { ',
'        console.log(data);',
'        var s ;',
'        var c ;',
'        var colors = ["#33b2df","#546E7A","#d4526e","#13d8aa","#A5978B","#2b908f","#f9a3a4","#90ee7e","#f48024","#69d2e7"];',
'        for (s=0;s<data.series.length;s++) {',
'            c= colors[s];',
'            if (data.series[s].name==" - "){',
'                data.series[s].color = "#00000000";',
'                data.series[s].shortDesc = "";',
'            }else{',
'                data.series[s].color = c;',
'            }',
'        }',
'        return data;',
'    };',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(146083908219492840)
,p_chart_id=>wwv_flow_imp.id(146083822491492839)
,p_seq=>10
,p_name=>'Monto'
,p_location=>'REGION_SOURCE'
,p_series_name_column_name=>'PROVEEDOR'
,p_items_value_column_name=>'MONTO'
,p_group_name_column_name=>'PROVEEDOR'
,p_group_short_desc_column_name=>'PROVEEDOR'
,p_items_label_column_name=>'PERIODO2'
,p_items_short_desc_column_name=>'PERIODO2'
,p_custom_column_name=>'PROVEEDOR'
,p_line_style=>'solid'
,p_line_width=>1
,p_line_type=>'curved'
,p_marker_rendered=>'on'
,p_marker_shape=>'human'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'afterMarker'
,p_items_label_display_as=>'PERCENT'
,p_items_label_font_color=>'#0724c9'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(146084183306492842)
,p_chart_id=>wwv_flow_imp.id(146083822491492839)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'currency'
,p_decimal_places=>0
,p_currency=>'$'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'top'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'on'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(146084294087492843)
,p_chart_id=>wwv_flow_imp.id(146083822491492839)
,p_axis=>'y2'
,p_is_rendered=>'off'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'start'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_split_dual_y=>'auto'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(146084060491492841)
,p_chart_id=>wwv_flow_imp.id(146083822491492839)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_major_tick_rendered=>'on'
,p_min_step=>1
,p_minor_tick_rendered=>'on'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'inside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(146082919911492830)
,p_plug_name=>'Barra de Acciones'
,p_region_name=>'secBarra'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(146082639089492827)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(146082919911492830)
,p_button_name=>'Print'
,p_button_static_id=>'btnPrint'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Print'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-download-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(43433638311543015)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(43433511683543014)
,p_button_name=>'Cerrar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Cerrar'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(143509433899026733)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(43433471694543013)
,p_button_name=>'Evolucion'
,p_button_static_id=>'btnBuscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>unistr('Evoluci\00F3n')
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-line-area-chart'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(43433706662543016)
,p_branch_name=>'gotoNegociacion'
,p_branch_action=>'&P142_URL.'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(43433638311543015)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43433317692543012)
,p_name=>'P142_ID_DETALLE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(43433471694543013)
,p_item_default=>'212'
,p_prompt=>'Id Detalle'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43433932209543018)
,p_name=>'P142_URL'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(43433471694543013)
,p_prompt=>'Url'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43434013190543019)
,p_name=>'P142_PAGINA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(43433471694543013)
,p_prompt=>'Pagina'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43435662342543035)
,p_name=>'P142_USUARIO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(43433471694543013)
,p_prompt=>'Usuario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45082286757050250)
,p_name=>'P142_PDAN8'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(43433471694543013)
,p_prompt=>'Pdan8'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45201216426008001)
,p_name=>'P142_PDFRTH'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(43433471694543013)
,p_prompt=>'Pdfrth'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45201396878008002)
,p_name=>'P142_PDPRRC'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(43433471694543013)
,p_prompt=>'Pdprrc'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45201857331008007)
,p_name=>'P142_PRODUCTO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(43433471694543013)
,p_prompt=>'Producto:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45202096657008009)
,p_name=>'P142_VIGENCIA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(45201923276008008)
,p_prompt=>'Vigencia:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(142582749309240641)
,p_name=>'P142_ID_NEGOCIACION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(43433471694543013)
,p_prompt=>'Id Negociacion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20240221190227Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(142582946753240643)
,p_name=>'P142_PRODUCTOGRF'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(45201923276008008)
,p_prompt=>'Producto'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   ',
'    CODIGOPRODUCTO || '' - '' ||  NOMBREPRODUCTO || '' ''|| CODIGOALTERNO  || '' - ['' ||  UNIDADCOMPRA || '']'' d  ,CODIGOCORTO r',
'FROM vt_jde_productos INNER JOIN vt_comp_negociaciondet ON CODIGOCORTO= DET_CODPRODUCTO ',
'WHERE  CODESTADO<>''O'' ',
'AND NEG_ID = :P142_ID_NEG',
'AND (DET_CODPRODUCTO =:P142_PRODUCTO OR :P142_PRODUCTO IS NULL)',
'GROUP BY  CODIGOPRODUCTO || '' - '' ||  NOMBREPRODUCTO || '' ''|| CODIGOALTERNO     || '' - ['' ||  UNIDADCOMPRA || '']''  ,CODIGOCORTO ,NOMBREPRODUCTO ',
'order by NOMBREPRODUCTO '))
,p_lov_cascade_parent_items=>'P142_ID_NEGOCIACION,P142_PRODUCTO'
,p_ajax_items_to_submit=>'P142_ID_NEGOCIACION,P142_PRODUCTO'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_read_only_when=>'P142_PORNEGOCIACION'
,p_read_only_when2=>'0'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20240221190227Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(142583083317240644)
,p_name=>'P142_MESES'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(43433471694543013)
,p_prompt=>'Meses Atras'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select level || decode(level,1,'' Mes'','' Meses'') DESCRIPCION, level RETORNO  from dual connect by level <= 24 order by RETORNO'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(143507826048026717)
,p_name=>'P142_TIPO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(45201923276008008)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('select ''Hist\00F3rico Ordenes de Compra'',1 from dual union all'),
unistr('select ''Evoluci\00F3n de Precio'',2 from dual union all'),
unistr('select ''Evoluci\00F3n de Cantidad'',3 from dual union all'),
unistr('select ''Evoluci\00F3n de Monto'',4 from dual')))
,p_lov_cascade_parent_items=>'P142_PORNEGOCIACION'
,p_ajax_items_to_submit=>'P142_PORNEGOCIACION'
,p_ajax_optimize_refresh=>'Y'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'4'
,p_attribute_02=>'SUBMIT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(143510069679026739)
,p_name=>'P142_PORNEGOCIACION'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(43433471694543013)
,p_prompt=>'Pornegociacion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(146083075067492831)
,p_name=>'P142_TABS'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(43433471694543013)
,p_prompt=>'Tabs'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(107608419967134324)
,p_name=>'Cancelar Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(43433638311543015)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(107608573822134325)
,p_event_id=>wwv_flow_imp.id(107608419967134324)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(143509615737026735)
,p_name=>'CambioEvolucion'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P142_MESES,P142_PRODUCTOGRF'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(143509717886026736)
,p_event_id=>wwv_flow_imp.id(143509615737026735)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(143509433899026733)
,p_attribute_01=>' $(''#btnBuscar'').trigger("click");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(146082788090492828)
,p_name=>'Print chart'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(146082639089492827)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(146082817827492829)
,p_event_id=>wwv_flow_imp.id(146082788090492828)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(secBarra).hide();',
'window.print()',
'$(secBarra).show();'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(43433858114543017)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    :P142_USUARIO:= :app_user;',
'    select apex_page.get_url(p_application=>130,p_page=>:P142_PAGINA)url into :P142_URL from dual;',
'end;',
'',
' if(:P142_TIPO is null) then :P142_TIPO:=2;end if;',
'IF (NVL(:P142_ID_DETALLE,0) != 0)THEN',
'    select neg_id,det_codproducto into :P142_ID_NEG,:P142_PRODUCTO from vt_comp_negociaciondet where det_id= :P142_ID_DETALLE and rownum=1;',
'END IF;',
'',
'SELECT VIGENCIADESDE ||'' - ''|| VIGENCIAHASTA NEG_VIGENCIA',
'INTO :P142_VIGENCIA',
'FROM t_comp_negociacion',
'WHERE ID=:P142_ID_NEG;',
'',
'if(:P142_PRODUCTOGRF is null )  then',
':P142_PRODUCTOGRF:=:P142_PRODUCTO;',
'end if;',
':P142_MESES:=12;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>43433858114543017
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(142583379428240647)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GRAFICO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pk_comp_negociacion.grafico_evolucion(:P142_ID_NEG,:P142_PRODUCTOGRF,:P142_USUARIO,:P142_MESES);',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>142583379428240647
);
wwv_flow_imp.component_end;
end;
/
