prompt --application/pages/page_00141
begin
--   Manifest
--     PAGE: 00141
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>141
,p_name=>unistr('Negociaci\00F3n - \00CDndices')
,p_alias=>'NEGOCIACION-INDICES'
,p_step_title=>unistr('Negociaci\00F3n - \00CDndices')
,p_allow_duplicate_submissions=>'N'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_javascript_code_onload=>'$(secItems).hide();'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Scroll Results Only in Side Column */',
'.t-Body-side {',
'    display: flex;',
'    flex-direction: column;',
'    overflow: hidden;',
'}',
'.search-results {',
'    flex: 1;',
'    overflow: auto;',
'}',
'/* Format Search Region */',
'.search-region {',
'    border-bottom: 1px solid rgba(0,0,0,.1);',
'    flex-shrink: 0;',
'}',
'.t-MediaList-badge, .t-MediaList-desc {',
'    color: #999ea7;',
'    font-size: 1.00rem;',
'}'))
,p_step_template=>wwv_flow_imp.id(295584560547037640)
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240829153114Z')
,p_last_updated_on=>wwv_flow_imp.dz('20251021164312Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(99955437864694402)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(99956631826694403)
,p_plug_name=>'Search'
,p_region_css_classes=>'search-region padding-md'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(295608822663037671)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(99957456716694405)
,p_name=>'Master Records'
,p_template=>wwv_flow_imp.id(295609041229037671)
,p_display_sequence=>20
,p_region_css_classes=>'search-results'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'t-MediaList--showDesc:t-MediaList--showBadges:u-colors:t-MediaList--horizontal'
,p_display_point=>'REGION_POSITION_02'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with t_todosidxs as (',
'	select distinct id ididx',
'		, apex_page.get_url(p_items => ''P141_ID'', p_values => id) link',
'		, decode(coalesce(:p141_id,''0''), id,''is-active'','''') class',
'		, upper(codindice) codindice',
'		, ''<span style="color:#000000c9">''||substr(observacion,1,50)||''</span>'' observacion',
'		, upper(rutaaprobacion) rutaaprobacion',
'	from data.t_comp_negociacionidx',
'	where 1 = 1',
'		and (:p141_search is null or (upper(codindice) like ''%''||upper(:p141_search)||''%'' or upper(observacion) like ''%''||upper(:p141_search)||''%''))',
'), flujo as (',
'	select estado',
'		, usuarioactual',
'		, usuarioiniciador',
'		, to_number(entidad_id)entidad_id',
'	from data.t_flujo_aprobacion_cab',
'	where 1 = 1',
'		and entidad_clase = ''NEGOCIACIONIDX''',
'		and estado in (''EN_PROCESO'')',
') , estados as (',
'	select distinct val.ididx',
'		, ''<span style="COLOR: ''||decode(estado,''EN_PROCESO'',''RED'',''ORANGE'')||'';">''||decode(estado,''EN_PROCESO'',''EN RUTA'',estado)||''</span>'' estadoflujo',
'		, data.pk_corp_flujoaprobacion.f_gestioncolor(:app_user,usuarioactual,estado,:g_compania,:app_modulo) gestioncolor',
'	from data.t_comp_negociacionidxvlr val',
'	inner join flujo cab on val.id = cab.entidad_id',
'	where 1 = 1',
'		and (upper(estado) like ''%''||upper(:p141_search)||''%'' or :p141_search is null)',
') select idx.ididx id',
'	, idx.class link_class',
'	, link',
'	, null icon_class',
'	, null link_attr',
'	, ''RED'' icon_color_class',
'	, null list_class',
'	, codindice list_title',
'	, decode(estadoflujo,null,null,estadoflujo ||''<br/>'')||observacion list_text',
'	, estadoflujo',
'	, case when estadoflujo like ''%EN RUTA%'' then 0 else 1 end orden',
'	, observacion',
'	, rutaaprobacion list_badge',
'from t_todosidxs idx',
'left join estados std on idx.ididx = std.ididx',
'order by link_class,orden,id desc;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P141_SEARCH'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295651889311037703)
,p_query_headings_type=>'QUERY_COLUMNS'
,p_query_num_rows=>1000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_break_cols=>'1'
,p_query_no_data_found=>'<div class="u-tC">No data found.</div>'
,p_query_row_count_max=>500
,p_break_type_flag=>'DEFAULT_BREAK_FORMATTING'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251002144451Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(99958164501694410)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(99958534978694412)
,p_query_column_id=>2
,p_column_alias=>'LINK_CLASS'
,p_column_display_sequence=>2
,p_column_heading=>'LINK_CLASS'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(99958951660694412)
,p_query_column_id=>3
,p_column_alias=>'LINK'
,p_column_display_sequence=>3
,p_column_heading=>'LINK'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(99959307538694412)
,p_query_column_id=>4
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>4
,p_column_heading=>'ICON_CLASS'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(99959704117694412)
,p_query_column_id=>5
,p_column_alias=>'LINK_ATTR'
,p_column_display_sequence=>5
,p_column_heading=>'LINK_ATTR'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(99960167209694413)
,p_query_column_id=>6
,p_column_alias=>'ICON_COLOR_CLASS'
,p_column_display_sequence=>6
,p_column_heading=>'ICON_COLOR_CLASS'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(99960552719694413)
,p_query_column_id=>7
,p_column_alias=>'LIST_CLASS'
,p_column_display_sequence=>7
,p_column_heading=>'LIST_CLASS'
,p_use_as_row_header=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(99960967675694413)
,p_query_column_id=>8
,p_column_alias=>'LIST_TITLE'
,p_column_display_sequence=>8
,p_column_heading=>'LIST_TITLE'
,p_use_as_row_header=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(158586933303419928)
,p_query_column_id=>9
,p_column_alias=>'LIST_TEXT'
,p_column_display_sequence=>60
,p_column_heading=>'List Text'
,p_use_as_row_header=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(157403942037618341)
,p_query_column_id=>10
,p_column_alias=>'ESTADOFLUJO'
,p_column_display_sequence=>40
,p_column_heading=>'Estadoflujo'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(157403892601618340)
,p_query_column_id=>11
,p_column_alias=>'ORDEN'
,p_column_display_sequence=>30
,p_column_heading=>'Orden'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(158203053546429221)
,p_query_column_id=>12
,p_column_alias=>'OBSERVACION'
,p_column_display_sequence=>50
,p_column_heading=>'Observacion'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(99961764183694413)
,p_query_column_id=>13
,p_column_alias=>'LIST_BADGE'
,p_column_display_sequence=>10
,p_column_heading=>'LIST_BADGE'
,p_use_as_row_header=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(99962136533694422)
,p_name=>'Negociacion - Indices Calculo de precios '
,p_region_name=>'rptIndiceCab'
,p_template=>wwv_flow_imp.id(296121421643169165)
,p_display_sequence=>10
,p_region_css_classes=>'js-master-region'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'TABLE'
,p_query_table=>'T_COMP_NEGOCIACIONIDX'
,p_query_where=>'ID=:P141_ID'
,p_include_rowid_column=>false
,p_display_when_condition=>'P141_ID'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P141_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295657610309037706)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(99962890021694423)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "T_COMP_NEGOCIACIONIDX"',
'where "ID" is not null',
'and "ID" = :P141_ID'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(156440628362962749)
,p_query_column_id=>2
,p_column_alias=>'USERCREA'
,p_column_display_sequence=>41
,p_column_heading=>'Iniciador'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(156440736074962750)
,p_query_column_id=>3
,p_column_alias=>'FECHCREA'
,p_column_display_sequence=>51
,p_column_heading=>'Fecha'
,p_use_as_row_header=>'N'
,p_column_format=>'dd/mm/yyyy'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(157399900420618301)
,p_query_column_id=>4
,p_column_alias=>'USERMODI'
,p_column_display_sequence=>71
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(157400043640618302)
,p_query_column_id=>5
,p_column_alias=>'FECHMODI'
,p_column_display_sequence=>81
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(156439865245962741)
,p_query_column_id=>6
,p_column_alias=>'CODINDICE'
,p_column_display_sequence=>11
,p_column_heading=>unistr('Cod. \00CDndice')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>'select 1 from "T_COMP_NEGOCIACIONIDX" where "CODINDICE" is not null and "ID" = :P141_ID'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(99965617907694425)
,p_query_column_id=>7
,p_column_alias=>'OBSERVACION'
,p_column_display_sequence=>21
,p_column_heading=>unistr('Observaci\00F3n')
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>'select 1 from "T_COMP_NEGOCIACIONIDX" where "OBSERVACION" is not null and "ID" = :P141_ID'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(295278163209039427)
,p_query_column_id=>8
,p_column_alias=>'RUTAAPROBACION'
,p_column_display_sequence=>61
,p_column_heading=>unistr('Ruta Aprobaci\00F3n')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NOMBRE, TIPO2',
'from t_admi_ruta where codigomodulo = ''COMP'' and tipo1 = ''NEGOCIACIONIDX'' '))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(99973541952694437)
,p_plug_name=>'Region Display Selector'
,p_region_css_classes=>'js-detail-rds'
,p_region_template_options=>'#DEFAULT#:margin-bottom-md'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(295608822663037671)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_num_rows=>15
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P141_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(99994820855694503)
,p_plug_name=>' .'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295608822663037671)
,p_plug_display_sequence=>50
,p_plug_source=>unistr('Ning\00FAn registro seleccionado')
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'P141_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(158204760860429238)
,p_plug_name=>unistr('Valores de \00CDndices C\00E1lculo')
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with enruta as (',
'	select to_number(entidad_id) id, a.estado, a.usuarioactual usuario',
'	from t_flujo_aprobacion_cab a inner join (select max(id) idflujo--, to_number(entidad_id) id',
'	from t_flujo_aprobacion_cab',
'	where codmodulo = ''COMP''',
'		and entidad_clase = ''NEGOCIACIONIDX''',
'		and entidad_id = entidad_id',
'		and usuarioactual = usuarioactual',
'	group by to_number(entidad_id)) b on a.id = b.idflujo',
'), datos as (',
'	select a.id',
'		, ididx',
'		, usercrea',
'		, fechcrea',
'		, usermodi',
'		, fechmodi',
'		, valindice',
'		, vigenciadesde',
'		, vigenciahasta',
'		, observacion',
'        , case',
'			when b.estado in (''EN_PROCESO'',''APROBADO'',''CADUCADO'') then ''<span aria-label="Ver"><span class="fa fa-eye" aria-hidden="true" title="Ver"></span></span>''',
'			else ''<span aria-label="Editar"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'' end faicono',
unistr('		, case when b.id is null then ''CREACI\00D3N'' else case when b.estado = ''EN_PROCESO'' then ''EN RUTA'' else b.estado end end estadoflujo'),
'		, case when b.id is null then a.usercrea else b.usuario end usuarioflujo',
'	from t_comp_negociacionidxvlr a',
'	left join enruta b on a.id = b.id',
'	where a.ididx = :p141_id',
') select qry.id id',
'	, qry.id id2',
'	, fechcrea',
'	, valindice',
'	, vigenciadesde',
'	, vigenciahasta',
'	, estadoflujo',
'	, usuarioflujo',
'	, observacion',
'    , faicono',
'from datos qry',
'order by qry.id desc'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P141_ID'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Valores de \00CDndices C\00E1lculo2')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20251021164312Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(158204813867429239)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_textbox=>'N'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>158204813867429239
,p_updated_on=>wwv_flow_imp.dz('20251021164312Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(158205037607429241)
,p_db_column_name=>'FECHCREA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'F. Registro'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251021163514Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(158205151466429242)
,p_db_column_name=>'VALINDICE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>unistr('Valor \00CDndice')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(158205282675429243)
,p_db_column_name=>'VIGENCIADESDE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Inicio Vigencia'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(158205323403429244)
,p_db_column_name=>'VIGENCIAHASTA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Fin Vigencia'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(158205456232429245)
,p_db_column_name=>'ESTADOFLUJO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Estado'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(158205556094429246)
,p_db_column_name=>'USUARIOFLUJO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Usuario'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(158205659266429247)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>unistr('Observaci\00F3n')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(158204954811429240)
,p_db_column_name=>'ID'
,p_display_order=>90
,p_column_identifier=>'A'
,p_column_label=>'-'
,p_column_link=>'f?p=&APP_ID.:194:&SESSION.::&DEBUG.:RP,194:P194_ID,P194_IDIDX,P194_USUARIOFLUJO:#ID#,&P141_ID.,#USUARIOFLUJO#'
,p_column_linktext=>'#FAICONO#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(289678555654140126)
,p_db_column_name=>'FAICONO'
,p_display_order=>120
,p_column_identifier=>'O'
,p_column_label=>'Faicono'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(289678658992140127)
,p_db_column_name=>'ID2'
,p_display_order=>130
,p_column_identifier=>'P'
,p_column_label=>'Id2'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(158597178547434083)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1585972'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:FECHCREA:VALINDICE:VIGENCIADESDE:VIGENCIAHASTA:ESTADOFLUJO:USUARIOFLUJO:OBSERVACION'
,p_created_on=>wwv_flow_imp.dz('20240829153114Z')
,p_updated_on=>wwv_flow_imp.dz('20240829153114Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(158584860906419907)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>70
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(99955956157694403)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(99955437864694402)
,p_button_name=>'Reestablecer'
,p_button_static_id=>'btnReset'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Reestablecer'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:141:&APP_SESSION.:RESET:&DEBUG.:RP,141::'
,p_button_condition=>'P141_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-undo-arrow'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(99995334946694504)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(99955437864694402)
,p_button_name=>'Editar'
,p_button_static_id=>'edit_master_btn'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Editar'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:147:&APP_SESSION.::&DEBUG.:RP,147:P147_ID:&P141_ID.'
,p_button_condition=>'P141_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-pencil-square-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(99956309878694403)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(99955437864694402)
,p_button_name=>'Agregar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Agregar'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:147:&APP_SESSION.::&DEBUG.:RP,147::'
,p_button_condition=>'P141_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(99980905572694482)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(158204760860429238)
,p_button_name=>'AgregarVal'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Agregar valores'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:194:&SESSION.::&DEBUG.:RP,194:P194_IDIDX:&P141_ID.'
,p_button_condition=>'P141_ID'
,p_button_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(99957087426694404)
,p_name=>'P141_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(99956631826694403)
,p_prompt=>'Search'
,p_placeholder=>'Search...'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681811193037723)
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large:t-Form-fieldContainer--postTextBlock'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(99973135488694437)
,p_name=>'P141_ID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(158584860906419907)
,p_prompt=>'Id'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(158585099946419909)
,p_name=>'P141_USUARIO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(158584860906419907)
,p_prompt=>'Usuario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(99995675381694504)
,p_name=>'Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(99962136533694422)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99996247638694504)
,p_event_id=>wwv_flow_imp.id(99995675381694504)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(99962136533694422)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99996746460694504)
,p_event_id=>wwv_flow_imp.id(99995675381694504)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess(''Negociacion - Indices Calculo de precios row(s) updated.'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(99974041157694440)
,p_name=>'Dialog Closed'
,p_event_sequence=>40
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'jBtnAprobar'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99981628924694483)
,p_event_id=>wwv_flow_imp.id(99974041157694440)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(99995700754694504)
,p_name=>'Perform Search'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P141_SEARCH'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'this.browserEvent.which === apex.jQuery.ui.keyCode.ENTER',
''))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keypress'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99997506985694505)
,p_event_id=>wwv_flow_imp.id(99995700754694504)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(99957456716694405)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(100009465193818906)
,p_event_id=>wwv_flow_imp.id(99995700754694504)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(99962136533694422)
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$s("P141_ID",0);',
'apex.region("rptIndiceCab").refresh();',
'apex.region("rptIndiceDet").refresh();'))
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(99998063461694505)
,p_event_id=>wwv_flow_imp.id(99995700754694504)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(157401356028618315)
,p_name=>'CloseDialogEdit147'
,p_event_sequence=>160
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(99995334946694504)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(157401453227618316)
,p_event_id=>wwv_flow_imp.id(157401356028618315)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(99962136533694422)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(157402025275618322)
,p_event_id=>wwv_flow_imp.id(157401356028618315)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(99957456716694405)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(157401763861618319)
,p_name=>'CloseDialog1Add47'
,p_event_sequence=>170
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(99956309878694403)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(157401836485618320)
,p_event_id=>wwv_flow_imp.id(157401763861618319)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(99962136533694422)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(157402169208618323)
,p_event_id=>wwv_flow_imp.id(157401763861618319)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(99957456716694405)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(200494679900509015)
,p_name=>'Refrescar'
,p_event_sequence=>220
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(99980905572694482)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(200494767650509016)
,p_event_id=>wwv_flow_imp.id(200494679900509015)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(158204760860429238)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(289680615689140147)
,p_name=>'Close Dialog'
,p_event_sequence=>230
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(158204760860429238)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(289680753556140148)
,p_event_id=>wwv_flow_imp.id(289680615689140147)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(295275576596039401)
,p_name=>'CambioAccion'
,p_event_sequence=>240
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P141_TIPOACCION'
,p_condition_element=>'P141_TIPOACCION'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(295275686577039402)
,p_event_id=>wwv_flow_imp.id(295275576596039401)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let v_objetoid =$v("P141_OBJETO_ID");',
'let v_aprobador =$v("P141_APROBADOR");',
'let v_accion =$v("P141_TIPOACCION");',
'alert("|"+v_objetoid +"|"+v_aprobador+"|"+v_accion+"|");',
'if (v_accion=="APROBAR"){',
'    $(''#btnAprobar'').trigger("click"); ',
'}',
'else if (v_accion=="RECHAZAR"){',
'    $(''#btnRechazar'').trigger("click");',
'}'))
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P141_TIPOACCION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(158586242734419921)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	:p141_usuario	:= :app_user;',
' ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>158586242734419921
);
wwv_flow_imp.component_end;
end;
/
