prompt --application/pages/page_00222
begin
--   Manifest
--     PAGE: 00222
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>222
,p_name=>'Negociacion - Vista completa'
,p_alias=>'NEGOCIACION-VISTA-COMPLETA'
,p_step_title=>'Negociacion - Vista completa'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(secItems).hide();',
'$(''.apex-rds'').data(''onRegionChange'', function(mode, activeTab) {',
'    var nomreg =activeTab.href; ',
'    console.log(nomreg);  ',
'    nomreg=  nomreg.replace("#","")',
'    console.log(nomreg);  ',
'    apex.region(nomreg ).refresh();',
'});',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-button.a-IRR-sortWidget-button[data-option="hide"], .a-IRR-button.a-IRR-sortWidget-button[data-option="freeze"]{',
'    display:none;',
'}',
'.a-IG-controls-item--aggregate, .a-IG-controls-item--controlBreak, .a-IG-controls-item--groupBy, .a-IG-reportSummary-item--aggregate, .a-IG-reportSummary-item--controlBreak, .a-IG-reportSummary-item--groupBy, .a-IRR-controls-item--aggregate, .a-IRR-c'
||'ontrols-item--controlBreak, .a-IRR-controls-item--groupBy, .a-IRR-reportSummary-item--aggregate, .a-IRR-reportSummary-item--controlBreak, .a-IRR-reportSummary-item--groupBy {',
'    --a-report-controls-cell-label-icon-background-color: #3b83bd;',
'    --a-report-controls-cell-label-hover-background-color: #e6f0f7;',
'    display: none;',
'}',
'.a-IRR-chartView, .a-IRR-controlsContainer, .a-IRR-detailView, .a-IRR-groupByView, .a-IRR-iconViewTable, .a-IRR-pivotView {',
'    border-top-color: #E6E6E6;',
'    display: none;',
'}',
'.TextoEditable',
'{',
'    width: 60px;',
'    background-color: #d0f5fd87;',
'    border:none;',
'    text-align: right;',
'    border-radius: 5px;',
'    border-style: groove;',
'    border-width: thin;',
'}',
'.TextoNoEditable',
'{',
'    width: 60px;',
'    background-color: transparent;',
'    border:none;',
'    text-align: right;',
'    border-radius: 5px;',
'    border-style: none;',
'    border-width: none;',
'}',
'',
'',
' ',
'',
'#SERIE1 { font-size: xx-small;}',
'#SERIE2 { font-size: xx-small;}',
'#SERIE3 { font-size: xx-small;}',
'#SERIE4 { font-size: xx-small;}',
'',
'',
'',
'.a-IRR-table tr td[headers*="PRECIO1"]',
'{',
'    background-color:#c1d6fb;',
'}',
'.a-IRR-table tr td[headers*="PRECIO2"]',
'{',
'    background-color:#d6d7fd;',
'}',
'.a-IRR-table tr td[headers*="PRECIO3"]',
'{',
'    background-color:#fef8a2;',
'}',
'.a-IRR-table tr td[headers*="ACTUAL"]',
'{',
'    background-color:#bef5c0;',
'}',
'.a-IRR-table {',
'    border-collapse: separate;',
'}',
'#PRECIO1 { background-color:#c1d6fb;}',
'#PRECIO2 { background-color:#d6d7fd;}',
'#PRECIO3 { background-color:#fef8a2;}',
'#ACTUAL { background-color:#bef5c0;}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240103143648Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240103165001Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(146084485160492845)
,p_plug_name=>'Barra de Acciones'
,p_region_name=>'secBarra'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>80
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(146084592795492846)
,p_plug_name=>'Parametros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>110
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(146084801764492849)
,p_plug_name=>'DetalleOC'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>70
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ng.neg_id,ng.cab_id,ng.det_id,neg_vigenciadesde,neg_vigenciahasta,',
'    f4.pddcto,f4.pddoco,',
'    f4.pddcto||'' - ''||f4.pddoco Orden_Compra,',
'    f4.pdan8||'' - ''||trim(mp.descripcion) Proveedor,pdan8,',
'    f4.pdlitm||'' - ''||pr.nombreproducto||'' [''||f4.pditm||''] (''||unidadcompra||'')''Producto,f4.pdlitm,f4.pditm,',
'    f4.pdprrc/10000 pdprrc,f4.pduorg/10000 pduorg,f4.pdaexp/10000 pdaexp,f4.pdurec/10000 pdurec',
'    ,''<span class="fa fa-database-check"></span>'' ver  ',
'from f4311@jdedtadl f4',
'    inner join t_comp_prodto_proveedr_gestion gs on documentotipo_oc = pddcto and  documento_oc= pddoco and compania=pdkcoo and gs.det_id is not null',
'    inner join vt_comp_negociacion ng on ng.det_codproducto= f4.pditm and CODIGOCORTOPRODUCTO= ng.det_codproducto AND ng.det_id = gs.det_id',
'    inner join vt_jde_maestroproveedor mp on f4.pdan8 = codigoproveedor',
'    inner join vt_jde_productos pr on pr.codigocorto=f4.pditm',
'where 1=1',
'    and (f4.pddcto=:P222_PDDCTO and f4.pddoco=:P222_PDDOCO)',
'--    and sysdate betwen neg_vigenciadesde and neg_vigenciahasta',
'    and ((to_char(f4.pdlttr)||''-''||to_char(f4.pdnxtr))<> (''980-999'') or  (to_char(f4.pdlttr)||''-''||to_char(f4.pdnxtr)=''980-999'' and pdurec > 0))',
'order by 3,2,1'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P222_PDDOCO,P222_PDDCTO'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P222_PDDOCO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'DetalleOC'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20240103162735Z')
,p_updated_by=>'WAIMINGNG'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(146084997540492850)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>146084997540492850
,p_updated_on=>wwv_flow_imp.dz('20240103162735Z')
,p_updated_by=>'WAIMINGNG'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148141404853932301)
,p_db_column_name=>'NEG_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>unistr('Negociaci\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'00000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148141525598932302)
,p_db_column_name=>'CAB_ID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Cab Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148141611093932303)
,p_db_column_name=>'DET_ID'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Det Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148141728233932304)
,p_db_column_name=>'NEG_VIGENCIADESDE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Vig. Desde'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148141833243932305)
,p_db_column_name=>'NEG_VIGENCIAHASTA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Vig. Hasta'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148142841840932315)
,p_db_column_name=>'PDUORG'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Qty Ordenada'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148143050680932317)
,p_db_column_name=>'PDUREC'
,p_display_order=>160
,p_column_identifier=>'Q'
,p_column_label=>'Qty Recibida'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148142732371932314)
,p_db_column_name=>'PDPRRC'
,p_display_order=>170
,p_column_identifier=>'N'
,p_column_label=>'Prec. Unitario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148142907129932316)
,p_db_column_name=>'PDAEXP'
,p_display_order=>180
,p_column_identifier=>'P'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148143306116932320)
,p_db_column_name=>'VER'
,p_display_order=>200
,p_column_identifier=>'R'
,p_column_label=>'<span class="fa fa-database-check"></span>'
,p_column_link=>'f?p=&APP_ID.:222:&SESSION.::&DEBUG.:RP,222:P222_PRODUCTO,P222_ID_NEG,P222_ID_DETALLE,P222_PDDCTO,P222_PDDOCO:#PDITM#,#NEG_ID#,#DET_ID#,#PDDCTO#,#PDDOCO#'
,p_column_linktext=>'#VER#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148143424034932321)
,p_db_column_name=>'ORDEN_COMPRA'
,p_display_order=>210
,p_column_identifier=>'S'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148143503824932322)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>220
,p_column_identifier=>'T'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148143638518932323)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>230
,p_column_identifier=>'U'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148143753219932324)
,p_db_column_name=>'PDAN8'
,p_display_order=>240
,p_column_identifier=>'V'
,p_column_label=>'Pdan8'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148143821169932325)
,p_db_column_name=>'PDLITM'
,p_display_order=>250
,p_column_identifier=>'W'
,p_column_label=>'Pdlitm'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148143951983932326)
,p_db_column_name=>'PDITM'
,p_display_order=>260
,p_column_identifier=>'X'
,p_column_label=>'Pditm'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148144762082932334)
,p_db_column_name=>'PDDCTO'
,p_display_order=>270
,p_column_identifier=>'Y'
,p_column_label=>'Pddcto'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148144880023932335)
,p_db_column_name=>'PDDOCO'
,p_display_order=>280
,p_column_identifier=>'Z'
,p_column_label=>'Pddoco'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(148152001259933524)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1481521'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NEG_ID:NEG_VIGENCIADESDE:NEG_VIGENCIAHASTA:ORDEN_COMPRA:PROVEEDOR:PRODUCTO:PDPRRC:PDUORG:PDAEXP:VER:'
,p_created_on=>wwv_flow_imp.dz('20240103143648Z')
,p_updated_on=>wwv_flow_imp.dz('20240103162735Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'WAIMINGNG'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(148144306686932330)
,p_plug_name=>'Negociaciones Proveedores'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>90
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P222_PDDOCO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(290799381544341709)
,p_plug_name=>'NEGOCIACIONES OTROS PROVEEDORES'
,p_parent_plug_id=>wwv_flow_imp.id(148144306686932330)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with ',
'  prd as (SELECT   CODIGOPRODUCTO || '' - '' ||  NOMBREPRODUCTO || '' ''|| CODIGOALTERNO  || '' - ['' ||  UNIDADCOMPRA || '']'' NOMBREPRODUCTO  ,CODIGOCORTO  FROM vt_jde_productos WHERE  CODESTADO<>''O'' GROUP BY  CODIGOPRODUCTO || '' - '' ||  NOMBREPRODUCTO || '
||''' ''|| CODIGOALTERNO     || '' - ['' ||  UNIDADCOMPRA || '']''  ,CODIGOCORTO ,NOMBREPRODUCTO order by NOMBREPRODUCTO)',
' ,prv as (SELECT   CODIGOPROVEEDOR || '' - '' ||  DESCRIPCION DESCRIPCION, CODIGOPROVEEDOR  FROM  VT_JDE_MAESTROPROVEEDOR GROUP BY CODIGOPROVEEDOR || '' - '' ||  DESCRIPCION , CODIGOPROVEEDOR , DESCRIPCION ORDER BY DESCRIPCION) ',
' ,itr as (select DRKY ||'' - ''||upper(DRDL01) DRDL01,DRKY  from vt_jde_udcjde where drsy=''42'' and drrt=''FR'' and drky is not null order by upper(DRKY))',
' ,fmp as (select PNPTC ||'' - ''||upper(PNPTD) PNPTD ,PNPTC from f0014@jdedtadl where trim(PNPTC) is not null  order by PNPTD)',
' SELECT',
'    (select DESCRIPCION from prv where codigoproveedor = NG_CODESQUEMA) NEG_CODESQUEMA_ACT,NG_NEG_ID,NG_VIGENCIA,(select NOMBREPRODUCTO from prd where CODIGOCORTO = ng_CODPRODUCTO)DET_CODPRODUCTO_ACT,ng_PRECIO, ',
'    (select DESCRIPCION from prv where codigoproveedor = P1_CODESQUEMA) P1_CODESQUEMA     ,P1_NEG_ID,P1_VIGENCIA,                                                                                      P1_PRECIO, P1_VARIACION,(case when P1_VARIACION<0 t'
||'hen ''<span style="color:red; font-size:small" class="fa fa-arrow-circle-up"></span>'' when P1_VARIACION>0 then ''<span style="color:orange; font-size:small" class="fa fa-arrow-circle-down"></span>'' else ''<span style="color:green; font-size:small" class'
||'="fa fa-dot-circle-o"></span>'' end) p1_semaforo,',
'    (select DESCRIPCION from prv where codigoproveedor = P2_CODESQUEMA) P2_CODESQUEMA     ,P2_NEG_ID,P2_VIGENCIA,                                                                                      P2_PRECIO, P2_VARIACION,(case when P2_VARIACION<0 t'
||'hen ''<span style="color:red; font-size:small" class="fa fa-arrow-circle-up"></span>'' when P2_VARIACION>0 then ''<span style="color:orange; font-size:small" class="fa fa-arrow-circle-down"></span>'' else ''<span style="color:green; font-size:small" class'
||'="fa fa-dot-circle-o"></span>'' end) p2_semaforo,',
'    (select DESCRIPCION from prv where codigoproveedor = P3_CODESQUEMA) P3_CODESQUEMA     ,P3_NEG_ID,P3_VIGENCIA,                                                                                      P3_PRECIO, P3_VARIACION,(case when P3_VARIACION<0 t'
||'hen ''<span style="color:red; font-size:small" class="fa fa-arrow-circle-up"></span>'' when P3_VARIACION>0 then ''<span style="color:orange; font-size:small" class="fa fa-arrow-circle-down"></span>'' else ''<span style="color:green; font-size:small" class'
||'="fa fa-dot-circle-o"></span>'' end) p3_semaforo',
'FROM',
'    vt_comp_negociacionprv',
'WHERE 1=1',
'    and NG_NEG_ID = :P222_ID_NEG',
'    and NG_CODPRODUCTO= :P222_PRODUCTOGRF',
'    '))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P222_NEG_ID_ACTUAL,P222_TIPO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'NEGOCIACIONES OTROS PROVEEDORES'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(290799393883341710)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_textbox=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_filter=>'N'
,p_show_sort=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>290799393883341710
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148245849326128691)
,p_db_column_name=>'NEG_CODESQUEMA_ACT'
,p_display_order=>10
,p_column_identifier=>'AN'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_static_id=>'ACTUAL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148247004217128692)
,p_db_column_name=>'DET_CODPRODUCTO_ACT'
,p_display_order=>20
,p_column_identifier=>'AQ'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_static_id=>'ACTUAL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148246244407128692)
,p_db_column_name=>'NG_NEG_ID'
,p_display_order=>30
,p_column_identifier=>'AO'
,p_column_label=>unistr('Negociaci\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'00000'
,p_static_id=>'ACTUAL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148246672716128692)
,p_db_column_name=>'NG_VIGENCIA'
,p_display_order=>40
,p_column_identifier=>'AP'
,p_column_label=>'Vigencia'
,p_column_type=>'STRING'
,p_static_id=>'ACTUAL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148248091464128693)
,p_db_column_name=>'NG_PRECIO'
,p_display_order=>100
,p_column_identifier=>'AS'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'ACTUAL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148248472510128694)
,p_db_column_name=>'P1_CODESQUEMA'
,p_display_order=>120
,p_column_identifier=>'AT'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_static_id=>'PRECIO1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148236222103128685)
,p_db_column_name=>'P1_NEG_ID'
,p_display_order=>130
,p_column_identifier=>'K'
,p_column_label=>unistr('Negociaci\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'00000'
,p_static_id=>'PRECIO1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148236656972128685)
,p_db_column_name=>'P1_VIGENCIA'
,p_display_order=>140
,p_column_identifier=>'L'
,p_column_label=>'Vigencia'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_static_id=>'PRECIO1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148238611228128686)
,p_db_column_name=>'P1_PRECIO'
,p_display_order=>190
,p_column_identifier=>'R'
,p_column_label=>'Precio Uni.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_static_id=>'PRECIO1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148239030104128687)
,p_db_column_name=>'P1_VARIACION'
,p_display_order=>200
,p_column_identifier=>'S'
,p_column_label=>'% Var.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'PRECIO1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148144423385932331)
,p_db_column_name=>'P1_SEMAFORO'
,p_display_order=>210
,p_column_identifier=>'AW'
,p_column_label=>unistr('<span title="% Variaci\00F3n" style="color:blue" class="fa fa-dot-circle-o"></span>')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_static_id=>'PRECIO1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148248886620128694)
,p_db_column_name=>'P2_CODESQUEMA'
,p_display_order=>220
,p_column_identifier=>'AU'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_static_id=>'PRECIO2'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148239417519128687)
,p_db_column_name=>'P2_NEG_ID'
,p_display_order=>230
,p_column_identifier=>'U'
,p_column_label=>unistr('Negociaci\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'00000'
,p_static_id=>'PRECIO2'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148239885777128687)
,p_db_column_name=>'P2_VIGENCIA'
,p_display_order=>240
,p_column_identifier=>'V'
,p_column_label=>'Vigencia'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_static_id=>'PRECIO2'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148241832705128689)
,p_db_column_name=>'P2_PRECIO'
,p_display_order=>250
,p_column_identifier=>'AB'
,p_column_label=>'Precio Uni.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_static_id=>'PRECIO2'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148242255071128689)
,p_db_column_name=>'P2_VARIACION'
,p_display_order=>260
,p_column_identifier=>'AC'
,p_column_label=>'% Var.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'PRECIO2'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148144566058932332)
,p_db_column_name=>'P2_SEMAFORO'
,p_display_order=>270
,p_column_identifier=>'AX'
,p_column_label=>unistr('<span title="% Variaci\00F3n" style="color:blue" class="fa fa-dot-circle-o"></span>')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_static_id=>'PRECIO2'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148249244738128694)
,p_db_column_name=>'P3_CODESQUEMA'
,p_display_order=>280
,p_column_identifier=>'AV'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_static_id=>'PRECIO3'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148242673854128689)
,p_db_column_name=>'P3_NEG_ID'
,p_display_order=>290
,p_column_identifier=>'AE'
,p_column_label=>unistr('Negociaci\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'00000'
,p_static_id=>'PRECIO3'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148243069925128690)
,p_db_column_name=>'P3_VIGENCIA'
,p_display_order=>300
,p_column_identifier=>'AF'
,p_column_label=>'Vigencia'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_static_id=>'PRECIO3'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148245050597128691)
,p_db_column_name=>'P3_PRECIO'
,p_display_order=>310
,p_column_identifier=>'AL'
,p_column_label=>'Precio Uni.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_static_id=>'PRECIO3'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148245499518128691)
,p_db_column_name=>'P3_VARIACION'
,p_display_order=>320
,p_column_identifier=>'AM'
,p_column_label=>'% Var.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'PRECIO3'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148144655364932333)
,p_db_column_name=>'P3_SEMAFORO'
,p_display_order=>340
,p_column_identifier=>'AY'
,p_column_label=>unistr('<span title="% Variaci\00F3n" style="color:blue" class="fa fa-dot-circle-o"></span>')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_static_id=>'PRECIO3'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(290844072433379076)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1426092'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NEG_CODESQUEMA_ACT:DET_CODPRODUCTO_ACT:NG_NEG_ID:NG_VIGENCIA:NG_PRECIO:P1_CODESQUEMA:P1_NEG_ID:P1_VIGENCIA:P1_PRECIO:P1_VARIACION:P2_CODESQUEMA:P2_NEG_ID:P2_VIGENCIA:P2_PRECIO:P2_VARIACION:P3_CODESQUEMA:P3_NEG_ID:P3_VIGENCIA:P3_PRECIO:P3_VARIACION'
,p_break_on=>'NEG_CODESQUEMA_ACT:DET_CODPRODUCTO_ACT:NG_NEG_ID:NG_VIGENCIA:0:0'
,p_break_enabled_on=>'NEG_CODESQUEMA_ACT:DET_CODPRODUCTO_ACT:NG_NEG_ID:NG_VIGENCIA:0:0'
,p_created_on=>wwv_flow_imp.dz('20240103143648Z')
,p_updated_on=>wwv_flow_imp.dz('20240103143648Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(290846790134370967)
,p_plug_name=>'colores'
,p_parent_plug_id=>wwv_flow_imp.id(148144306686932330)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div>',
unistr('    <span style="margin-left : 15px;">Negociaci\00F3n Actual<span        class="fa fa-square" style="color: #bef5c0; margin-left: 5px;"> <span class="visuallyhidden"></span> </span>'),
unistr('    <span style="margin-left : 15px;">1er. Negociaci\00F3n Anterior<span class="fa fa-square" style="color: #c1d6fb; margin-left: 5px;"> <span class="visuallyhidden"></span> </span></span>'),
unistr('    <span style="margin-left : 15px;">2da. Negociaci\00F3n Anterior<span class="fa fa-square" style="color: #d6d7fd; margin-left: 5px;"> <span class="visuallyhidden"></span> </span></span>'),
unistr('    <span style="margin-left : 15px;">3er. Negociaci\00F3n Anterior<span class="fa fa-square" style="color: #fef8a2; margin-left: 5px;"> <span class="visuallyhidden"></span> </span></span>'),
'    </span>',
'</div>',
' '))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(191512088011764498)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>100
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(191512128000764499)
,p_plug_name=>'BOTONES'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121809343169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(293752360020586712)
,p_plug_name=>unistr('Reporte Evoluci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(295630388916037685)
,p_plug_display_sequence=>80
,p_plug_item_display_point=>'BELOW'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P222_PDDOCO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'N',
  'rds_mode', 'STANDARD',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(291587354815248211)
,p_plug_name=>unistr('Evoluci\00F3n de Precio de Compra')
,p_region_name=>'rptEvolucionPrecio'
,p_parent_plug_id=>wwv_flow_imp.id(293752360020586712)
,p_icon_css_classes=>'fa-line-chart'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM01||'' - ''||TXT01 Proveedor',
'    , to_number(num03||TXT05) ||''(''||TXT06||'')'' periodo2',
'    , TXT06 Periodo',
'    , NUM05 Precio',
'    , NUM06 Cantidad',
'    , NUM07 Monto',
'from T_APEX_TEMPORAL ',
'where   FLAG=''NEGOCIACION_GRAFICO_ORDENES_COMPRA'' ',
'and     CONTROL01=''00001'' ',
'and     CONTROL02=''COMP'' ',
'and     CONTROL03=:APP_USER',
'and     CONTROL04= ''negociacion_sp_grafico_ordenes''',
'and     CONTROL05= to_number(:P222_ID_NEG)',
'order by Num03,Num04'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_ajax_items_to_submit=>'P222_ID_NEG'
,p_updated_on=>wwv_flow_imp.dz('20240103165001Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(148104057781221554)
,p_region_id=>wwv_flow_imp.id(291587354815248211)
,p_chart_type=>'bar'
,p_title=>'Evolucion de Precio de Compra'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'on'
,p_data_cursor_behavior=>'smooth'
,p_hide_and_show_behavior=>'withoutRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_title=>'Proveedor:'
,p_legend_position=>'bottom'
,p_legend_font_size=>'10'
,p_no_data_found_message=>unistr('No Existen datos para el grafico de evoluci\00F3n')
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ){ ',
'    options.dataFilter = function( data ) { ',
'        console.log(data);',
'        var s ;',
'        var c ;',
'        var colors = ["#33b2df","#546E7A","#d4526e","#13d8aa","#A5978B","#2b908f","#f9a3a4","#90ee7e","#f48024","#69d2e7"];',
'        for (s=0;s<data.series.length;s++) {',
'            c= colors[s];',
'            if (data.series[s].name==" - "){',
'                data.series[s].color = "#00000000";',
'                data.series[s].shortDesc = "";',
'            }else{',
'                data.series[s].color = c;',
'            }',
'        }',
'        return data;',
'    };',
'    return options;',
'}'))
,p_updated_on=>wwv_flow_imp.dz('20240103165001Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(148106372762221557)
,p_chart_id=>wwv_flow_imp.id(148104057781221554)
,p_seq=>10
,p_name=>'Precio'
,p_location=>'REGION_SOURCE'
,p_series_name_column_name=>'PROVEEDOR'
,p_items_value_column_name=>'PRECIO'
,p_items_label_column_name=>'PERIODO2'
,p_items_short_desc_column_name=>'PERIODO2'
,p_custom_column_name=>'PROVEEDOR'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'center'
,p_updated_on=>wwv_flow_imp.dz('20240103165001Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(148105141916221556)
,p_chart_id=>wwv_flow_imp.id(148104057781221554)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'currency'
,p_decimal_places=>4
,p_currency=>'$'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'top'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'on'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(148104534284221555)
,p_chart_id=>wwv_flow_imp.id(148104057781221554)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'none'
,p_scaling=>'log'
,p_baseline_scaling=>'min'
,p_major_tick_rendered=>'on'
,p_min_step=>1
,p_minor_tick_rendered=>'on'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(148105780908221556)
,p_chart_id=>wwv_flow_imp.id(148104057781221554)
,p_axis=>'y2'
,p_is_rendered=>'off'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'start'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_split_dual_y=>'auto'
,p_updated_on=>wwv_flow_imp.dz('20240103165001Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(293749886795586687)
,p_plug_name=>'Datos Series'
,p_region_name=>'secDetalle'
,p_parent_plug_id=>wwv_flow_imp.id(293752360020586712)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM01||'' - ''||TXT01 Proveedor',
'    , to_number(num03||TXT05) ||''(''||TXT06||'')'' periodo',
'    , NUM05 Precio',
'    , NUM06 Cantidad',
'    , NUM07 Monto',
'from T_APEX_TEMPORAL ',
'where   FLAG=''NEGOCIACION_GRAFICO_ORDENES_COMPRA'' ',
'and     CONTROL01=''00001'' ',
'and     CONTROL02=''COMP'' ',
'and     CONTROL03=:APP_USER',
'and     CONTROL04= ''negociacion_sp_grafico_ordenes''',
'and     CONTROL05= to_number(:P222_ID_NEG)'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P222_ID_NEG,APP_USER'
,p_plug_column_width=>'style="font-size: smaller;"'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Datos Series'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(293754490761586733)
,p_name=>'PROVEEDOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROVEEDOR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Series'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>10
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>false
,p_filter_is_required=>false
,p_static_id=>'SERIE1'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(293754564379586734)
,p_name=>'PERIODO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PERIODO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Periodo'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>20
,p_value_alignment=>'CENTER'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>false
,p_filter_is_required=>false
,p_static_id=>'SERIE2'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(293754714074586735)
,p_name=>'PRECIO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PRECIO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Precio'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>30
,p_value_alignment=>'RIGHT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_format_mask=>'999G999G999G999G990D0000'
,p_enable_filter=>false
,p_filter_is_required=>false
,p_static_id=>'SERIE3'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(294158710087714286)
,p_name=>'CANTIDAD'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CANTIDAD'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Cantidad'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>40
,p_value_alignment=>'RIGHT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_format_mask=>'999G999G999G999G990D00'
,p_enable_filter=>false
,p_filter_is_required=>false
,p_static_id=>'SERIE4'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(294162919937714329)
,p_name=>'MONTO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MONTO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Monto'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>50
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'999G999G999G999G990D0000'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(293754374806586732)
,p_internal_uid=>293754374806586732
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_show_nulls_as=>'-'
,p_select_first_row=>false
,p_fixed_row_height=>false
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'ACTIONS_MENU'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>true
,p_download_formats=>'XLSX'
,p_enable_mail_download=>false
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(294164544830719275)
,p_interactive_grid_id=>wwv_flow_imp.id(293754374806586732)
,p_static_id=>'1460860'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(294164740045719275)
,p_report_id=>wwv_flow_imp.id(294164544830719275)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(294165291791719278)
,p_view_id=>wwv_flow_imp.id(294164740045719275)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(293754490761586733)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(294166196441719285)
,p_view_id=>wwv_flow_imp.id(294164740045719275)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(293754564379586734)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(294167059918719288)
,p_view_id=>wwv_flow_imp.id(294164740045719275)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(293754714074586735)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(294167980804719292)
,p_view_id=>wwv_flow_imp.id(294164740045719275)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(294158710087714286)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(295941489547217631)
,p_view_id=>wwv_flow_imp.id(294164740045719275)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(294162919937714329)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(294161810747714317)
,p_plug_name=>unistr('Evoluci\00F3n de Cantidad de Compra')
,p_region_name=>'rptEvolucionCantidad'
,p_parent_plug_id=>wwv_flow_imp.id(293752360020586712)
,p_icon_css_classes=>'fa-line-chart'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM01||'' - ''||TXT01 Proveedor',
'    , to_number(num03||TXT05) ||''(''||TXT06||'')'' periodo2',
'    , TXT06 Periodo',
'    , NUM05 Precio',
'    , NUM06 Cantidad',
'    , NUM07 Monto',
'from T_APEX_TEMPORAL ',
'where   FLAG=''NEGOCIACION_GRAFICO_ORDENES_COMPRA'' ',
'and     CONTROL01=''00001'' ',
'and     CONTROL02=''COMP'' ',
'and     CONTROL03=:APP_USER',
'and     CONTROL04= ''negociacion_sp_grafico_ordenes''',
'and     CONTROL05= to_number(:P222_ID_NEG)',
'order by Num03,Num04'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_ajax_items_to_submit=>'P222_ID_NEG'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(148107258638221558)
,p_region_id=>wwv_flow_imp.id(294161810747714317)
,p_chart_type=>'lineWithArea'
,p_title=>unistr('Evoluci\00F3n de Cantidad de Compra')
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'on'
,p_data_cursor_behavior=>'smooth'
,p_hide_and_show_behavior=>'withoutRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_title=>'Proveedor:'
,p_legend_position=>'bottom'
,p_legend_font_size=>'10'
,p_overview_rendered=>'off'
,p_no_data_found_message=>unistr('No Existen datos para el grafico de evoluci\00F3n')
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ){ ',
'    options.dataFilter = function( data ) { ',
'        console.log(data);',
'        var s ;',
'        var c ;',
'        var colors = ["#33b2df","#546E7A","#d4526e","#13d8aa","#A5978B","#2b908f","#f9a3a4","#90ee7e","#f48024","#69d2e7"];',
'        for (s=0;s<data.series.length;s++) {',
'            c= colors[s];',
'            if (data.series[s].name==" - "){',
'                data.series[s].color = "#00000000";',
'                data.series[s].shortDesc = "";',
'            }else{',
'                data.series[s].color = c;',
'            }',
'        }',
'        return data;',
'    };',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(148109589408221559)
,p_chart_id=>wwv_flow_imp.id(148107258638221558)
,p_seq=>10
,p_name=>'Cantidad'
,p_location=>'REGION_SOURCE'
,p_series_name_column_name=>'PROVEEDOR'
,p_items_value_column_name=>'CANTIDAD'
,p_group_name_column_name=>'PROVEEDOR'
,p_group_short_desc_column_name=>'PROVEEDOR'
,p_items_label_column_name=>'PERIODO2'
,p_items_short_desc_column_name=>'PERIODO2'
,p_custom_column_name=>'PROVEEDOR'
,p_line_style=>'dotted'
,p_line_width=>1
,p_line_type=>'curved'
,p_marker_rendered=>'on'
,p_marker_shape=>'human'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'center'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(148108983222221559)
,p_chart_id=>wwv_flow_imp.id(148107258638221558)
,p_axis=>'y2'
,p_is_rendered=>'off'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'start'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_split_dual_y=>'auto'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(148107701432221558)
,p_chart_id=>wwv_flow_imp.id(148107258638221558)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'none'
,p_scaling=>'log'
,p_baseline_scaling=>'min'
,p_major_tick_rendered=>'on'
,p_min_step=>1
,p_minor_tick_rendered=>'on'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(148108396612221558)
,p_chart_id=>wwv_flow_imp.id(148107258638221558)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'top'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'on'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(294162380140714323)
,p_plug_name=>unistr('Evoluci\00F3n de Monto de Compra')
,p_region_name=>'rptEvolucionMonto'
,p_parent_plug_id=>wwv_flow_imp.id(293752360020586712)
,p_icon_css_classes=>'fa-line-chart'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM01||'' - ''||TXT01 Proveedor',
'    , to_number(num03||TXT05) ||''(''||TXT06||'')'' periodo2',
'    , TXT06 Periodo',
'    , NUM05 Precio',
'    , NUM06 Cantidad',
'    , NUM07 Monto',
'from T_APEX_TEMPORAL ',
'where   FLAG=''NEGOCIACION_GRAFICO_ORDENES_COMPRA'' ',
'and     CONTROL01=''00001'' ',
'and     CONTROL02=''COMP'' ',
'and     CONTROL03=:APP_USER',
'and     CONTROL04= ''negociacion_sp_grafico_ordenes''',
'and     CONTROL05= to_number(:P222_ID_NEG)',
'order by Num03,Num04'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_ajax_items_to_submit=>'P222_ID_NEG'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(148110431710221560)
,p_region_id=>wwv_flow_imp.id(294162380140714323)
,p_chart_type=>'lineWithArea'
,p_title=>'Evolucion de Monto de Compra'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'on'
,p_data_cursor_behavior=>'smooth'
,p_hide_and_show_behavior=>'withoutRescale'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'on'
,p_legend_title=>'Proveedor:'
,p_legend_position=>'bottom'
,p_legend_font_size=>'10'
,p_overview_rendered=>'off'
,p_no_data_found_message=>unistr('No Existen datos para el grafico de evoluci\00F3n')
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function( options ){ ',
'    options.dataFilter = function( data ) { ',
'        console.log(data);',
'        var s ;',
'        var c ;',
'        var colors = ["#33b2df","#546E7A","#d4526e","#13d8aa","#A5978B","#2b908f","#f9a3a4","#90ee7e","#f48024","#69d2e7"];',
'        for (s=0;s<data.series.length;s++) {',
'            c= colors[s];',
'            if (data.series[s].name==" - "){',
'                data.series[s].color = "#00000000";',
'                data.series[s].shortDesc = "";',
'            }else{',
'                data.series[s].color = c;',
'            }',
'        }',
'        return data;',
'    };',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(148112793212221561)
,p_chart_id=>wwv_flow_imp.id(148110431710221560)
,p_seq=>10
,p_name=>'Monto'
,p_location=>'REGION_SOURCE'
,p_series_name_column_name=>'PROVEEDOR'
,p_items_value_column_name=>'MONTO'
,p_group_name_column_name=>'PROVEEDOR'
,p_group_short_desc_column_name=>'PROVEEDOR'
,p_items_label_column_name=>'PERIODO2'
,p_items_short_desc_column_name=>'PERIODO2'
,p_custom_column_name=>'PROVEEDOR'
,p_line_style=>'dotted'
,p_line_width=>1
,p_line_type=>'curved'
,p_marker_rendered=>'on'
,p_marker_shape=>'human'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'center'
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(148112151009221561)
,p_chart_id=>wwv_flow_imp.id(148110431710221560)
,p_axis=>'y2'
,p_is_rendered=>'off'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'start'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_split_dual_y=>'auto'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(148111509352221560)
,p_chart_id=>wwv_flow_imp.id(148110431710221560)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'currency'
,p_decimal_places=>4
,p_currency=>'$'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_position=>'top'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'on'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(148110997242221560)
,p_chart_id=>wwv_flow_imp.id(148110431710221560)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'none'
,p_scaling=>'log'
,p_baseline_scaling=>'min'
,p_major_tick_rendered=>'on'
,p_min_step=>1
,p_minor_tick_rendered=>'on'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(148098518600221542)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(146084485160492845)
,p_button_name=>'Cerrar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Cerrar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(148093067017221536)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(146084485160492845)
,p_button_name=>'Evolucion'
,p_button_static_id=>'btnBuscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>unistr('Evoluci\00F3n')
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-dot-circle-o'
,p_button_cattributes=>'style="display:none"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(148092317950221534)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(146084485160492845)
,p_button_name=>'Print'
,p_button_static_id=>'btnPrint'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Print'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-download-alt'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(146084644430492847)
,p_name=>'P222_PDDCTO'
,p_item_sequence=>10
,p_prompt=>'Pddcto'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(146084746654492848)
,p_name=>'P222_PDDOCO'
,p_item_sequence=>20
,p_prompt=>'Pddoco'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(148093417398221537)
,p_name=>'P222_ID_NEG'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(191512088011764498)
,p_prompt=>'Id Neg'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(148093844299221539)
,p_name=>'P222_ID_DETALLE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(191512088011764498)
,p_item_default=>'212'
,p_prompt=>'Id Detalle'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(148094226226221539)
,p_name=>'P222_PRODUCTO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(191512088011764498)
,p_prompt=>'Producto:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(148095495282221540)
,p_name=>'P222_MESES'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(191512088011764498)
,p_item_default=>'12'
,p_prompt=>'Meses Atras'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select level || decode(level,1,'' Mes'','' Meses'') DESCRIPCION, level RETORNO  from dual connect by level <= 24 order by RETORNO'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(148099601445221543)
,p_name=>'P222_PRODUCTOGRF'
,p_item_sequence=>50
,p_prompt=>'Producto'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT   ',
'    CODIGOPRODUCTO || '' - '' ||  NOMBREPRODUCTO || '' ''|| CODIGOALTERNO  || '' - ['' ||  UNIDADCOMPRA || '']'' d  ,CODIGOCORTO r',
'FROM vt_jde_productos INNER JOIN vt_comp_negociaciondet ON CODIGOCORTO= DET_CODPRODUCTO ',
'WHERE  CODESTADO<>''O'' ',
'AND (DET_CODPRODUCTO =:P222_PRODUCTO OR :P222_PRODUCTO IS NULL)',
'GROUP BY  CODIGOPRODUCTO || '' - '' ||  NOMBREPRODUCTO || '' ''|| CODIGOALTERNO     || '' - ['' ||  UNIDADCOMPRA || '']''  ,CODIGOCORTO ,NOMBREPRODUCTO ',
'order by NOMBREPRODUCTO '))
,p_lov_cascade_parent_items=>'P222_PRODUCTO'
,p_ajax_items_to_submit=>'P222_PRODUCTO'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(148115959509221570)
,p_name=>'Cancelar Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(148098518600221542)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(148116473501221572)
,p_event_id=>wwv_flow_imp.id(148115959509221570)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(148117724306221573)
,p_name=>'CambioEvolucion'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P222_MESES,P222_PRODUCTOGRF'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(148118212897221574)
,p_event_id=>wwv_flow_imp.id(148117724306221573)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(148093067017221536)
,p_attribute_01=>' $(''#btnBuscar'').trigger("click");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(148116845519221573)
,p_name=>'Print chart'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(148092317950221534)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(148117314211221573)
,p_event_id=>wwv_flow_imp.id(148116845519221573)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(secBarra).hide();',
'window.print()',
'$(secBarra).show();'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(148144040853932327)
,p_process_sequence=>20
,p_process_point=>'AFTER_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'cargarDatos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'P_NEG_ID NUMBER;',
'P_PRD_ID NUMBER;',
'P_MES_ID NUMBER;',
'BEGIN',
'    :P222_MESES:=12;',
'    P_NEG_ID :=:P222_ID_NEG;',
'    P_PRD_ID :=:P222_PRODUCTOGRF;',
'    P_MES_ID :=:P222_MESES;',
'    pk_comp_negociacion.grafico_evolucion(P_NEG_ID,P_PRD_ID,:app_user,P_MES_ID);',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>148144040853932327
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(148115149398221568)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF (:P222_PDDOCO IS NOT NULL AND :P222_PDDCTO IS NOT NULL)THEN',
'    if(:P222_PRODUCTOGRF is null )  then',
'    :P222_PRODUCTOGRF:=:P222_PRODUCTO;',
'    end if;',
'    :P222_MESES:=12;',
'    DECLARE ',
'    P_NEG_ID NUMBER;',
'    P_PRD_ID NUMBER;',
'    P_MES_ID NUMBER;',
'    BEGIN',
'        P_NEG_ID :=:P222_ID_NEG;',
'        P_PRD_ID :=:P222_PRODUCTOGRF;',
'        P_MES_ID :=:P222_MESES;',
'        pk_comp_negociacion.grafico_evolucion(P_NEG_ID,P_PRD_ID,:app_user,P_MES_ID);',
'    END;',
'END IF;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>148115149398221568
);
wwv_flow_imp.component_end;
end;
/
