prompt --application/pages/page_00527
begin
--   Manifest
--     PAGE: 00527
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>527
,p_name=>'COMEX - Transportista'
,p_alias=>'COMEX-TRANSPORTISTA'
,p_step_title=>'COMEX - Transportista'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_rejoin_existing_sessions=>'Y'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20241024191448Z')
,p_last_updated_on=>wwv_flow_imp.dz('20241017160915Z')
,p_last_updated_by=>'DCUEVA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(352516037088436543)
,p_plug_name=>'Transportista'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295639738305037692)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(697595776830622084)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(697597402733622100)
,p_plug_name=>'CABECERA'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(697598863371622115)
,p_plug_name=>'UPLOAD'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(697599111330622117)
,p_plug_name=>'ARCHIVOS'
,p_parent_plug_id=>wwv_flow_imp.id(697598863371622115)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    NUMEROARCHIVO,',
'    FILENAME,',
'    NUMEROARCHIVO AS ICONO_BORRAR,',
'',
'    TO_CHAR(FECHA, ''DD/MM/YYYY HH24:MI'') AS FECHA',
'FROM   ',
'    FILES.T_APEX_ARCHIVOS ',
'WHERE ',
'    TABLA    = ''T_CMEX_DATOS_GESTION_DETALLE'' ',
'        AND',
'    ID_TABLA = TO_CHAR(:P527_DATOS_GESTION_DET_ID)',
'        AND',
'    TIPO     = ''TRANSPORTISTA''',
'ORDER BY ',
'    FECHA DESC',
'FETCH FIRST 1 ROWS ONLY;',
'            '))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'ARCHIVOS'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(697599230853622118)
,p_max_row_count=>'1000000'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>697599230853622118
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(354500330814565639)
,p_db_column_name=>'FILENAME'
,p_display_order=>10
,p_column_identifier=>'B'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(354500002672565637)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'ARCHIVO'
,p_column_type=>'NUMBER'
,p_format_mask=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment:#FILENAME#:FILES'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(354500711160565639)
,p_db_column_name=>'ICONO_BORRAR'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'-'
,p_column_link=>'javascript:apex.item("P525_NUMEROARCHIVO_BORRAR").setValue("#ICONO_BORRAR#");'
,p_column_linktext=>'<span class="fa fa-trash"></span>'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(352516328514436546)
,p_db_column_name=>'FECHA'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Fecha'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(699044844242156061)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3445461'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMEROARCHIVO:FECHA:'
,p_created_on=>wwv_flow_imp.dz('20241024191448Z')
,p_updated_on=>wwv_flow_imp.dz('20241024191448Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(354502447821565646)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(697595776830622084)
,p_button_name=>'GRABAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Grabar'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P527_EDITAR_TRANSPORTISTA'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(354499331748565627)
,p_name=>'P527_UPLOAD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(697598863371622115)
,p_prompt=>'Subir Archivos'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_display_when=>'P527_EDITAR_TRANSPORTISTA'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
,p_attribute_15=>'50000'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(354503194939565647)
,p_name=>'P527_EXPORTACION_REGISTRO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(697597402733622100)
,p_prompt=>'Registro'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(354503542624565648)
,p_name=>'P527_ESTADO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(697597402733622100)
,p_prompt=>'Estado'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(354503914630565648)
,p_name=>'P527_DATOS_GESTION_DET_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(697597402733622100)
,p_prompt=>'Cont. ID'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(354504393876565648)
,p_name=>'P527_CONTENEDOR_NUMERO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(697597402733622100)
,p_prompt=>'Contenedor'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(354504728937565648)
,p_name=>'P527_IDVEHICULO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(697597402733622100)
,p_prompt=>'Placa'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(354505106778565648)
,p_name=>'P527_FECHA_CARGUE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(697597402733622100)
,p_prompt=>'Fecha Cargue'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(354505515842565649)
,p_name=>'P527_PEDIDOS'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(697597402733622100)
,p_prompt=>'Pedidos'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(354505937902565649)
,p_name=>'P527_TRANSPORTISTA'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(697597402733622100)
,p_prompt=>'Transportista'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(354506304784565649)
,p_name=>'P527_TURNO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(697597402733622100)
,p_prompt=>'Turno'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(354509260858565651)
,p_name=>'P527_NUMEROARCHIVO_BORRAR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(352516037088436543)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(354509611186565652)
,p_name=>'P527_EDITAR_TRANSPORTISTA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(352516037088436543)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF ',
'    UPPER(:APP_USER) = ''TRANSPORTISTA'' ',
'        AND ',
'    :P527_ESTADO IN (''COORDINACION'', ''TRANSITO'')',
'THEN ',
'    RETURN 1;',
'ELSE ',
'    RETURN 0;    ',
'END IF;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(352516246273436545)
,p_validation_name=>'UPLOAD'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P527_UPLOAD IS NULL THEN',
'    RETURN ''Debe seleccionar el archivo a subir'';',
'END IF;',
'',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(354511392524565669)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'UPLOAD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P527_UPLOAD IS NOT NULL THEN',
'',
'    PK_CMEX_EXPORTACION.SP_CARGA_ARCHIVOS_TRANSPORTISTA(',
'        :P527_EXPORTACION_REGISTRO,',
'        :P527_DATOS_GESTION_DET_ID,',
'        :APP_USER',
'    );',
'',
'END IF;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>354511392524565669
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(354510960195565668)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga Contenedor'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    CONTENEDOR_NUMERO,',
'    PEDIDOS,',
'    TRUNC(FECHA_PLAN_CARGUE) AS FECHA_CARGUE,',
'    ',
'    TURNO_ID       AS TURNO,',
'    TURNO_EMPRESA  AS TRANSPORTISTA,',
'    TURNO_IDVEHICULO',
'',
'INTO',
'',
'    :P527_CONTENEDOR_NUMERO,',
'    :P527_PEDIDOS,',
'    :P527_FECHA_CARGUE,',
'',
'    :P527_TURNO,',
'    :P527_TRANSPORTISTA,',
'    :P527_IDVEHICULO',
'',
'FROM',
'    VT_CMEX_DATOS_GESTION_DETALLE',
'WHERE ',
'    ID = :P527_DATOS_GESTION_DET_ID;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>354510960195565668
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(354511757274565669)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga Registro'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ESTADO',
'INTO',
'      :P527_ESTADO',
'FROM  T_CMEX_EXPORTACION',
'WHERE REGISTRO = :P527_EXPORTACION_REGISTRO;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>354511757274565669
);
wwv_flow_imp.component_end;
end;
/
