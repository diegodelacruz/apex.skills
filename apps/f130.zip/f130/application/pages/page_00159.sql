prompt --application/pages/page_00159
begin
--   Manifest
--     PAGE: 00159
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>159
,p_name=>'COMEX - Aranceles SKU'
,p_step_title=>'COMEX - Aranceles SKU'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_created_on=>wwv_flow_imp.dz('20230708132656Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260409204243Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(75899169129799016)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(75976948402682565)
,p_plug_name=>'Formulario'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(75977671087682568)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(75899169129799016)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Cancel'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:158:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(75977558598682568)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(75899169129799016)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Delete'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P159_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-trash'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(75977434061682568)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(75899169129799016)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P159_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(75977323943682568)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(75899169129799016)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P159_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(75979293719682573)
,p_branch_action=>'f?p=&APP_ID.:158:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(75979648804682579)
,p_name=>'P159_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(75976948402682565)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(75980090847682592)
,p_name=>'P159_CODIGOPRODUCTO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(75976948402682565)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('C\00F3digo Producto')
,p_source=>'CODIGOPRODUCTO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_PRODUCTOS_JDE'
,p_lov=>'SELECT trim(imdsc1)||'' (''||trim(imlitm)||'')'' AS DESCRIPCION, trim(imlitm) AS CODIGO FROM F4101@jdedtadl where substr(imglpt,1,2) = ''IN'''
,p_cSize=>32
,p_cMaxlength=>10
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(75980439385682596)
,p_name=>'P159_DESCRIPCION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(75976948402682565)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Descripcion'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_PRODUCTOS_JDE'
,p_lov=>'SELECT trim(imdsc1)||'' (''||trim(imlitm)||'')'' AS DESCRIPCION, trim(imlitm) AS CODIGO FROM F4101@jdedtadl where substr(imglpt,1,2) = ''IN'''
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(75980896937682596)
,p_name=>'P159_TIPO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(75976948402682565)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_TIPOSMATERIALES_JDE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT upper(DRDL01)||'' (''||DRKY||'')'' AS D, DRKY AS R FROM DATA.VT_JDE_UDCJDE',
'WHERE DRSY = ''41'' AND DRRT= ''9'' AND SUBSTR(DRKY, 1,2) = ''IN''',
'ORDER BY 1'))
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(75981213639682596)
,p_name=>'P159_CATEGORIA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(75976948402682565)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Categoria'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(75981627256682598)
,p_name=>'P159_PARTIDAARANCELARIA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(75976948402682565)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Partida Arancelaria'
,p_source=>'PARTIDAARANCELARIA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_CMEX_PARTIDAARANCELARIA_IMP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PARTIDA || '' - '' || DESCRIPCION as d,',
'       ID as r',
'  from T_CMEX_PARTIDAARANCELARIA'))
,p_cSize=>32
,p_cMaxlength=>30
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(75982017680682598)
,p_name=>'P159_PAISORIOGEN'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(75976948402682565)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Pais Origen'
,p_source=>'PAISORIOGEN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_PAISES_JDE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select drdl01 d, drky r',
'from vt_jde_udcjde ',
'where drsy = ''00'' and drrt = ''CN'' and drky != ''*'' order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20240410195746Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(75982496340682598)
,p_name=>'P159_PORCENTAJEVIGENTE_ESTANDA'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(75976948402682565)
,p_use_cache_before_default=>'NO'
,p_prompt=>'% Vigente Estandar'
,p_source=>'PORCENTAJEVIGENTE_ESTANDAR'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(75982874905682598)
,p_name=>'P159_ARANCELZAIMELLA'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(75976948402682565)
,p_use_cache_before_default=>'NO'
,p_prompt=>'% Arancel Zaimella'
,p_source=>'ARANCELZAIMELLA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(75983214597682598)
,p_name=>'P159_PORCENTAJE_ISD'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(75976948402682565)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Porcentaje ISD'
,p_source=>'PORCENTAJE_ISD'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(75983556715682601)
,p_name=>'P159_CREDITOTRIBUTARIO_ISD'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(75976948402682565)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Credito Tributario ISD'
,p_source=>'CREDITOTRIBUTARIO_ISD'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LOV_CREDITOTRIBUTARIO'
,p_lov=>'.'||wwv_flow_imp.id(76048126086578034)||'.'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(75983909350682603)
,p_name=>'P159_FECHAVIGENCIADESDE'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(75976948402682565)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fecha Vigencia Desde'
,p_source=>'FECHAVIGENCIADESDE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(75984389852682603)
,p_name=>'P159_FECHAVIGENCIAHASTA'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(75976948402682565)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fecha Vigencia Hasta'
,p_source=>'FECHAVIGENCIAHASTA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(75984725854682604)
,p_name=>'P159_COMENTARIO'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(75976948402682565)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Comentario'
,p_source=>'COMENTARIO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>500
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(75899517909799020)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P159_CODIGOPRODUCTO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75899684596799021)
,p_event_id=>wwv_flow_imp.id(75899517909799020)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_tipo VARCHAR2(5);',
'v_categoria VARCHAR2(5);',
'BEGIN ',
'    SELECT imdsc1, imglpt, imprp4  INTO  :P159_DESCRIPCION, v_tipo, v_categoria   FROM F4101@jdedtadl WHERE  imlitm = RPAD(:P159_CODIGOPRODUCTO,25,'' '');',
'    ',
'    APEX_DEBUG_MESSAGE.ENABLE_DEBUG_MESSAGES(p_level => 3);',
'',
'APEX_DEBUG_MESSAGE.LOG_MESSAGE(',
'    p_message => '' :v_categoria = '' ||   REPLACE(v_categoria, '' '', ''*'') ,',
'    p_level => 1 );    ',
'    ',
'    BEGIN',
'    ',
'    SELECT DRDL01 INTO :P159_TIPO      FROM VT_JDE_UDCJDE WHERE DRSY = ''41'' AND DRRT= ''9'' AND DRKY = v_tipo;',
'    ',
'    SELECT DRDL01 INTO :P159_CATEGORIA FROM VT_JDE_UDCJDE WHERE DRSY = ''41'' AND DRRT= ''P4'' AND DRKY = v_categoria;  ',
'    EXCEPTION WHEN NO_DATA_FOUND THEN',
'        :P159_TIPO  := NULL;',
'        :P159_CATEGORIA  := NULL;',
'    END;',
'    ',
'END;'))
,p_attribute_02=>'P159_CODIGOPRODUCTO'
,p_attribute_03=>'P159_DESCRIPCION,P159_TIPO,P159_CATEGORIA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(80461233994347004)
,p_name=>'Cargardatos'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_display_when_cond=>'P159_ID'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(80461357181347005)
,p_event_id=>wwv_flow_imp.id(80461233994347004)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_tipo VARCHAR2(5);',
'v_categoria VARCHAR2(5);',
'BEGIN ',
'    SELECT imdsc1, imglpt, imprp4  INTO  :P159_DESCRIPCION, v_tipo, v_categoria   FROM F4101@jdedtadl WHERE  imlitm = RPAD(:P159_CODIGOPRODUCTO,25,'' ''); ',
'    ',
'    BEGIN',
'    ',
'    SELECT DRDL01 INTO :P159_TIPO      FROM VT_JDE_UDCJDE WHERE DRSY = ''41'' AND DRRT= ''9'' AND DRKY = v_tipo;',
'    ',
'    SELECT DRDL01 INTO :P159_CATEGORIA FROM VT_JDE_UDCJDE WHERE DRSY = ''41'' AND DRRT= ''P4'' AND DRKY = v_categoria;  ',
'    EXCEPTION WHEN NO_DATA_FOUND THEN',
'        :P159_TIPO  := NULL;',
'        :P159_CATEGORIA  := NULL;',
'    END;',
'    ',
'END;'))
,p_attribute_02=>'P159_CODIGOPRODUCTO'
,p_attribute_03=>'P159_DESCRIPCION,P159_TIPO,P159_CATEGORIA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(75985508785682612)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from T_CMEX_ARANCELESPRODUCTO'
,p_attribute_02=>'T_CMEX_ARANCELESPRODUCTO'
,p_attribute_03=>'P159_ID'
,p_attribute_04=>'ID'
,p_internal_uid=>75985508785682612
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(75985911487682612)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of T_CMEX_ARANCELESPRODUCTO'
,p_attribute_02=>'T_CMEX_ARANCELESPRODUCTO'
,p_attribute_03=>'P159_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>75985911487682612
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(75986337750682612)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(75977558598682568)
,p_internal_uid=>75986337750682612
);
wwv_flow_imp.component_end;
end;
/
