prompt --application/pages/page_00101
begin
--   Manifest
--     PAGE: 00101
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>101
,p_name=>'Orden de Compra'
,p_step_title=>'Orden de Compra'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(secItems).hide();',
'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();',
''))
,p_inline_css=>'.cancelado {text-decoration:line-through;}'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20241105185722Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260402164948Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5831123562060286)
,p_plug_name=>'&P101_TITULO.'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296122226350169167)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5831181062060287)
,p_plug_name=>'Datos Principales'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5831853350060294)
,p_plug_name=>'Detalle'
,p_region_name=>'tblDetalle'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120613521169165)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select documento',
'	, documentotipo',
'	, linea',
'	, case',
'		when :p101_es_aprobador = 1 and  estado_ant||''-''||estado_sig != ''980-999'' then apex_item.checkbox(1,linea,''CHECKED class="chkF01"'') else '''' end seleccion',
'/*',
'	, ''<span ''||decode((select count(1) from f574310@jdedtadl where calitm = x.codigoproducto and caexdj < (to_char(sysdate,''yyyyddd'')-1900000)),0,'''',''class="bgAmarillo"'')||''>''||trim(x.codigoproducto)||'' - ''||decode(v.tipoinventario,''IN13'',descripcion,d'
||'ecode(tipolinea,''S '',producto ||'' | ''||codigoalterno,descripcion))||''</span>'' producto',
'*/',
'	, ''<span''||case when estado_ant||''-''||estado_sig = ''980-999'' then '' class="cancelado">'' else ''>'' end||trim(x.codigoproducto)||'' - ''||decode(v.tipoinventario,''IN13'',descripcion,decode(tipolinea,''S '',DESCRIPCIONCOMPLETA,DESCRIPCIONCOMPLETA))||''</span>'
||''' producto',
'	, unidadmedida unidad',
'	, cantidad',
'	, precio',
'	, total',
'	, pk_comp_ordenescompra.f_comentario@jdedtadl(p_compania=>:g_compania,p_tipooc=>documentotipo,p_ordencompra=>documento,p_tipo=>''A'',p_linea=>linea) informacion',
'	, case when documentotipo = ''H3'' then (select to_date(to_char(plissu+1900000),''yyyyddd'') from f4305@jdedtadl where pldoco = documento and pldcto = documentotipo and pllgty = 3) else to_date(fechaentregajde+ 1900000,''yyyyddd'') end fecha',
'	, 0 agotamiento',
'	, ''<span title="Actividad Comercial"class="fa fa-sitemap-vertical"></span>'' actividad',
'	, decode(tipolinea,''S '',''<span title="Producto"class="fa fa-eye"></span>'','''') verproducto',
'	, unenvio',
'	, cantsolicitada',
'	, nvl(cantcomprada,cantidad) cantcomprada',
'	, justdetcomprador',
'	, idgenordencompra',
'from vt_jde_ordencompradetalle x,vt_jde_productos v',
'where documento = :p101_numero',
'	and documentotipo = :p101_tipo',
'	and x.codigocortoproducto = v.codigocorto',
unistr('	-- and (:p101_estado = ''RECHAZADO'' or estado_ant <> 980)    -- Caso 27774 WMNG Solicita mostrar las l\00EDneas de los productos rechazados'),
'ORDER BY linea;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_updated_on=>wwv_flow_imp.dz('20260223204459Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(5832777184060303)
,p_max_row_count=>'10000000'
,p_no_data_found_message=>unistr('Todas las l\00EDneas est\00E1n canceladas. Si est\00E1 en su aprobaci\00F3n debe rechazar la Orden  ')
,p_show_nulls_as=>'-'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>302077646963569046
,p_updated_on=>wwv_flow_imp.dz('20260223204459Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(5871189549509777)
,p_db_column_name=>'SELECCION'
,p_display_order=>10
,p_column_identifier=>'E'
,p_column_label=>'<input type="checkbox" id="selectalloc">'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6106668621249070)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>20
,p_column_identifier=>'H'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6308848337673176)
,p_db_column_name=>'DOCUMENTOTIPO'
,p_display_order=>30
,p_column_identifier=>'K'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6308951886673177)
,p_db_column_name=>'LINEA'
,p_display_order=>40
,p_column_identifier=>'L'
,p_column_label=>unistr('L\00EDnea')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250505035643Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(5832903282060304)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>50
,p_column_identifier=>'A'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(98583493519101310)
,p_db_column_name=>'UNIDAD'
,p_display_order=>60
,p_column_identifier=>'N'
,p_column_label=>'UM'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(5832996853060305)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>70
,p_column_identifier=>'B'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(5833097690060306)
,p_db_column_name=>'PRECIO'
,p_display_order=>80
,p_column_identifier=>'C'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P101_CONTRATO=0 OR (:P101_CONTRATO=1 AND TRIM(:P101_TIPO_CONTRATO)=''F'')'
,p_display_condition2=>'SQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(5833182359060307)
,p_db_column_name=>'TOTAL'
,p_display_order=>90
,p_column_identifier=>'D'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P101_CONTRATO=0 OR (:P101_CONTRATO=1 AND TRIM(:P101_TIPO_CONTRATO)=''F'')'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(307638670963020616)
,p_db_column_name=>'INFORMACION'
,p_display_order=>100
,p_column_identifier=>'M'
,p_column_label=>unistr('Informaci\00F3n')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_display_condition=>'P101_BANDERA_INFDET'
,p_display_condition2=>'0'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6106574283249069)
,p_db_column_name=>'ACTIVIDAD'
,p_display_order=>110
,p_column_identifier=>'G'
,p_column_label=>'-'
,p_column_link=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.:RP:P102_LINEA,P102_NUMERO,P102_TIPO,P102_PRODUCTO:#LINEA#,#DOCUMENTO#,#DOCUMENTOTIPO#,#PRODUCTO#'
,p_column_linktext=>'#ACTIVIDAD#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_display_condition=>'P101_BANDERA_ACTCOM'
,p_display_condition2=>'0'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(6308821988673175)
,p_db_column_name=>'VERPRODUCTO'
,p_display_order=>120
,p_column_identifier=>'J'
,p_column_label=>'-'
,p_column_link=>'f?p=&APP_ID.:103:&SESSION.::&DEBUG.:RP,103:P103_IDGENORDENCOMPRA:#IDGENORDENCOMPRA#'
,p_column_linktext=>'#VERPRODUCTO#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_display_condition=>'P101_BANDERA_INFPRD'
,p_display_condition2=>'0'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260223204459Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(98583625660101312)
,p_db_column_name=>'FECHA'
,p_display_order=>130
,p_column_identifier=>'O'
,p_column_label=>'F. Compromiso'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(98583767119101313)
,p_db_column_name=>'AGOTAMIENTO'
,p_display_order=>140
,p_column_identifier=>'P'
,p_column_label=>'Agotamiento'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85322405235939450)
,p_db_column_name=>'UNENVIO'
,p_display_order=>150
,p_column_identifier=>'Q'
,p_column_label=>unistr('UN Env\00EDo')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(137471420988975419)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250505035643Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183797249460709119)
,p_db_column_name=>'JUSTDETCOMPRADOR'
,p_display_order=>170
,p_column_identifier=>'S'
,p_column_label=>'Just. Mod. Cantidad'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_display_condition=>'P101_BANDERA_A'
,p_display_condition2=>'0'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183797312075709120)
,p_db_column_name=>'CANTSOLICITADA'
,p_display_order=>180
,p_column_identifier=>'T'
,p_column_label=>'Cant. Sol.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_display_condition=>'P101_BANDERA_A'
,p_display_condition2=>'0'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183797451253709121)
,p_db_column_name=>'CANTCOMPRADA'
,p_display_order=>190
,p_column_identifier=>'U'
,p_column_label=>'Cant.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(355333954649124206)
,p_db_column_name=>'IDGENORDENCOMPRA'
,p_display_order=>200
,p_column_identifier=>'V'
,p_column_label=>'ID GODC'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260223203108Z')
,p_updated_on=>wwv_flow_imp.dz('20260223203108Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(5867926262497142)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3021128'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_view_mode=>'REPORT'
,p_report_columns=>'SELECCION:LINEA:PRODUCTO:UNIDAD:UNENVIO:FECHA:CANTCOMPRADA:PRECIO:TOTAL:VERPRODUCTO:INFORMACION:'
,p_sort_column_1=>'LINEA'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_sum_columns_on_break=>'TOTAL'
,p_created_on=>wwv_flow_imp.dz('20241105185722Z')
,p_updated_on=>wwv_flow_imp.dz('20250505035850Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'GDIMELLA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5869254232509758)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5869580307509761)
,p_plug_name=>'Botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121809343169165)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P101_ES_APROBADOR'
,p_plug_display_when_cond2=>'1'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(145801150728202944)
,p_plug_name=>'Adjuntos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296120613521169165)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select numeroarchivo id',
'	, numeroarchivo',
'	, filename',
'	, tipo',
'	, fecha',
'	, nombreusuario usuario',
'	, pk_commons.f_googledocview(numeroarchivo,mimetype) enlace',
'from files.t_apex_archivos',
'where tabla = ''T_COMP_ORDENES''',
'and ((id_tabla = :p101_numero and tipo = :p101_tipo) or (id_tabla = :p101_numero_a and tipo = :p101_tipo_a))',
'order by filename'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_updated_on=>wwv_flow_imp.dz('20250505035358Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(145801225157202945)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>145801225157202945
,p_updated_on=>wwv_flow_imp.dz('20250505035358Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145801396725202946)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145801449569202947)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Numeroarchivo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145801516233202948)
,p_db_column_name=>'FILENAME'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Archivo'
,p_column_link=>'#ENLACE#'
,p_column_linktext=>'#FILENAME#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250505035358Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148053881308235401)
,p_db_column_name=>'TIPO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Tipo Orden'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148053968777235402)
,p_db_column_name=>'FECHA'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(148054050773235403)
,p_db_column_name=>'USUARIO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(12508212884116104)
,p_db_column_name=>'ENLACE'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Enlace'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250505034602Z')
,p_updated_on=>wwv_flow_imp.dz('20250505034602Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(148068854179243171)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1480689'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:NUMEROARCHIVO:FILENAME:TIPO:FECHA:USUARIO'
,p_created_on=>wwv_flow_imp.dz('20241105185722Z')
,p_updated_on=>wwv_flow_imp.dz('20250505034722Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(340099997446298917)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(340846642606805035)
,p_plug_name=>'Variables'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_region_attributes=>'style="display:none;"'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(340846825595805037)
,p_plug_name=>'Condiciones de acuerdo'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'NEVER'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(340847591342805044)
,p_name=>unistr('Terminos de negociaci\00F3n')
,p_template=>wwv_flow_imp.id(296120613521169165)
,p_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select descripcion producto',
'	, cantidad',
'	, precio',
'	, costo',
'	, descripcionadicional descripcion',
'from vt_jde_ordencompracontrato',
'where compania = :g_compania and documentonumero = :p101_numero and documentotipo = :p101_tipo;'))
,p_display_condition_type=>'NEVER'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(340847606134805045)
,p_query_column_id=>1
,p_column_alias=>'PRODUCTO'
,p_column_display_sequence=>1
,p_column_heading=>'Producto'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(340847771012805046)
,p_query_column_id=>2
,p_column_alias=>'CANTIDAD'
,p_column_display_sequence=>2
,p_column_heading=>'Cantidad'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(340847879016805047)
,p_query_column_id=>3
,p_column_alias=>'PRECIO'
,p_column_display_sequence=>3
,p_column_heading=>'Precio'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(340847961847805048)
,p_query_column_id=>4
,p_column_alias=>'COSTO'
,p_column_display_sequence=>4
,p_column_heading=>'Costo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(340848086295805049)
,p_query_column_id=>5
,p_column_alias=>'DESCRIPCION'
,p_column_display_sequence=>5
,p_column_heading=>'Descripcion'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5869380793509759)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(5869254232509758)
,p_button_name=>'ATRAS'
,p_button_static_id=>'btnAtras'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Atras'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:RP::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6309522245673182)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(5869254232509758)
,p_button_name=>'CONTRATO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Contrato'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:104:&SESSION.::&DEBUG.:RP:P104_COMPANIA,P104_NUMERO,P104_TIPO:&G_COMPANIA.,&P101_NUMERO.,&P101_TIPO.'
,p_button_condition=>'P101_CONTRATO'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-file-bookmark'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5870083192509766)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(5869254232509758)
,p_button_name=>'COMENTARIO'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Comentario'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:105:&SESSION.::&DEBUG.:RP:G_OBJETO,G_OBJETO_ID,G_MODULO,G_COMPANIA,G_USUARIO:&P101_TIPO.,&P101_NUMERO.,&APP_MODULO.,&G_COMPANIA.,&P101_USUARIO.'
,p_icon_css_classes=>'fa-comment'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5870020018509765)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(5869254232509758)
,p_button_name=>'VER_RUTA'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Ver Ruta'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:104:&SESSION.::&DEBUG.:RR,104:G_OBJETO,G_OBJETO_ID,G_TODO:&P101_TIPO.,&P101_NUMERO.,false'
,p_icon_css_classes=>'fa-road'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(147756950235749201)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(5869254232509758)
,p_button_name=>'ADJUNTO'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Adjunto'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:401:&SESSION.::&DEBUG.:RP:P401_TABLA,P401_ID,P401_TIPO,P401_ESTADO:T_COMP_ORDENES,&P101_NUMERO_A.,&P101_TIPO_A.,0'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-paperclip'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5869712418509762)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(5869580307509761)
,p_button_name=>'APROBAR'
,p_button_static_id=>'APROBAR'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Aprobar'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:102:&SESSION.::&DEBUG.:RP,:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO,G_MONTO:&G_COMPANIA.,&APP_MODULO.,&P101_USUARIO.,&P101_TIPO.,&P101_NUMERO.,&P101_APROBADOR.,&P101_MONTO.'
,p_button_cattributes=>'style="display:none;"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(322267208502678702)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(5869580307509761)
,p_button_name=>'btnAprobar'
,p_button_static_id=>'btnAprobar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Aprobar'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P101_ES_APROBADOR = 1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5870592097509771)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(5869580307509761)
,p_button_name=>'RECHAZAR'
,p_button_static_id=>'RECHAZAR'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Rechazar'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:103:&SESSION.::&DEBUG.:RP:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO:&G_COMPANIA.,&APP_MODULO.,&P101_USUARIO.,&P101_TIPO.,&P101_NUMERO.,&P101_APROBADOR.'
,p_button_cattributes=>'style="display:none;"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(322269327806684438)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(5869580307509761)
,p_button_name=>'btnRechazar'
,p_button_static_id=>'btnRechazar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Rechazar'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P101_ES_APROBADOR = 1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5831275661060288)
,p_name=>'P101_NUMERO'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(5831181062060287)
,p_prompt=>unistr('N\00FAmero:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5831373830060289)
,p_name=>'P101_TIPO'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(5831181062060287)
,p_prompt=>'Tipo:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5831491385060290)
,p_name=>'P101_PROVEEDOR'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(5831181062060287)
,p_prompt=>'Proveedor:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5831564408060291)
,p_name=>'P101_UNIDAD_NEGOCIO'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(5831181062060287)
,p_prompt=>'Unidad Negocio:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5831676522060292)
,p_name=>'P101_FECHA_ENTREGA'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(5831181062060287)
,p_prompt=>'Fecha Entrega:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_display_when=>'P101_ORDENOORIGINAL'
,p_display_when2=>'0'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5869474316509760)
,p_name=>'P101_APROBADOR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(340846642606805035)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5870386829509769)
,p_name=>'P101_FLUJO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(340846642606805035)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5872909001509794)
,p_name=>'P101_SINSELECCION'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(340846642606805035)
,p_prompt=>'Sin Seleccion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5873885799509804)
,p_name=>'P101_DESCRIPCION'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(5831181062060287)
,p_prompt=>unistr('Descripci\00F3n:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6107150952249075)
,p_name=>'P101_ES_APROBADOR'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(340846642606805035)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6107311871249076)
,p_name=>'P101_ESTADO'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(340846642606805035)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6308392649673171)
,p_name=>'P101_USUARIO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(340846642606805035)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6308557682673173)
,p_name=>'P101_TOKEN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(340846642606805035)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6309303435673180)
,p_name=>'P101_FECHA_ORDEN'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(5831181062060287)
,p_prompt=>'Fecha Orden:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6309335997673181)
,p_name=>'P101_CONTRATO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(340846642606805035)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12508332941116105)
,p_name=>'P101_INCOTERM'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(5831181062060287)
,p_prompt=>'Incoterm'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P101_INCOTERM'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20250505050936Z')
,p_updated_on=>wwv_flow_imp.dz('20250505050936Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(98583508322101311)
,p_name=>'P101_ORDENOORIGINAL'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(340846642606805035)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(147757071737749202)
,p_name=>'P101_NUMERO_A'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(5831181062060287)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(147757158156749203)
,p_name=>'P101_TIPO_A'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(5831181062060287)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(183797030328709117)
,p_name=>'P101_BANDERA_A'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(340846642606805035)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(257268411828638529)
,p_name=>'P101_SOLICITANTE'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(5831181062060287)
,p_prompt=>'Solicitante:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(257268500153638530)
,p_name=>'P101_COMPRADOR'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(5831181062060287)
,p_prompt=>'Comprador:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(307638849870020618)
,p_name=>'P101_MONTO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(340846642606805035)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(314312566117891920)
,p_name=>'P101_SELECCION'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(340846642606805035)
,p_prompt=>'Seleccion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(314313278127891927)
,p_name=>'P101_MENSAJE'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(340099997446298917)
,p_prompt=>'Mensaje'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(340846708834805036)
,p_name=>'P101_TITULO'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(340846642606805035)
,p_prompt=>'Titulo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(340846935650805038)
,p_name=>'P101_FRECUENCIA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(340846825595805037)
,p_prompt=>'Frecuencia Pago:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(340847094064805039)
,p_name=>'P101_FECHA_PAGO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(340846825595805037)
,p_prompt=>'Fecha Inicio Pago:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(340847148777805040)
,p_name=>'P101_ANTICIPO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(340846825595805037)
,p_prompt=>'Anticipo:'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(340847280014805041)
,p_name=>'P101_FECHA_ANTICIPO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(340846825595805037)
,p_prompt=>'Fecha Anticipo:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(340847367759805042)
,p_name=>'P101_TIPO_MONTO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(340846825595805037)
,p_prompt=>'Tipo Monto:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(340847465793805043)
,p_name=>'P101_NUMERO_PAGOS'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(340846825595805037)
,p_prompt=>'Numero Pagos'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(340848146903805050)
,p_name=>'P101_TIPO_CONTRATO'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(340846642606805035)
,p_prompt=>'Tipo Contrato'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(341887337923405401)
,p_name=>'P101_FECHA_CONTRATO_INCIO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(340846825595805037)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(341887444899405402)
,p_name=>'P101_FECHA_CONTRATO_FIN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(340846825595805037)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(411015901327960542)
,p_name=>'P101_BANDERA_INFDET'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(340846642606805035)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(411016066361960543)
,p_name=>'P101_BANDERA_ACTCOM'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(340846642606805035)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(411016115635960544)
,p_name=>'P101_BANDERA_INFPRD'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(340846642606805035)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(5870208089509767)
,p_name=>unistr('Cierre di\00E1logo: aprobar')
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(5869712418509762)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5870277035509768)
,p_event_id=>wwv_flow_imp.id(5870208089509767)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'mostrarBarra();',
'// P101_FLUJO = 0 ERROR , 1 SE APROBO CON EXITO, 2 TERMINO FLUJO',
'apex.item("P101_FLUJO").setValue(0);',
'',
'if(this.data.G_EXITO==''true''){',
'    apex.item("P101_FLUJO").setValue(1);',
'    mensaje(''exito'', this.data.G_MENSAJE);',
'    if(isTerminoFlujo){',
'        apex.item("P101_FLUJO").setValue(2);',
'    }',
'}',
'else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5870480895509770)
,p_event_id=>wwv_flow_imp.id(5870208089509767)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_log_app varchar2(100);',
'v_log_dsc varchar2(1000);',
'v_NUMEROORDEN NUMBER;',
'v_TIPOORDEN VARCHAR2(200);',
'v_MENSAJE VARCHAR2(200);',
'begin',
'	v_log_app := ''apex.130.101.aprobar'';',
unistr('	--v_log_dsc := ''Par\00E1metros: P101_TIPO: ''||:p101_tipo||'', P101_NUMERO: ''||:p101_numero||'', P101_FLUJO: ''||:p101_flujo;'),
'    v_log_dsc := substr(''APROBAR: P101_TIPO: ''||:p101_tipo||'', P101_NUMERO: ''||:p101_numero||'', P101_FLUJO: ''||:p101_flujo||'', P101_SELECCION: ''||:P101_SELECCION, 1,1000);',
'	data.pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,null,null,null);',
'',
'	if :p101_flujo = 2 then',
'		pk_comp_ordenescompra.sp_aprobarorden(p_numero=>:p101_numero,p_tipo=>:p101_tipo,p_compania=>:g_compania);',
'	end if;',
'end;'))
,p_attribute_02=>'P101_FLUJO,P101_SINSELECCION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5870948015509775)
,p_event_id=>wwv_flow_imp.id(5870208089509767)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var token = apex.item("P101_TOKEN").getValue();',
'ocultarBarra();',
'if(this.data.G_EXITO==''true''){',
'    if(token==''0''){',
'        $(''#btnAtras'').trigger("click");',
'    }else{',
'        $(''#btnAprobar'').hide();',
'        $(''#btnRechazar'').hide();',
'    }',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(5870725459509772)
,p_name=>unistr('Cierre di\00E1logo: rechazar')
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(5870592097509771)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5870777396509773)
,p_event_id=>wwv_flow_imp.id(5870725459509772)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mostrarBarra();',
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'console.log(trama);',
'// P101_FLUJO = 0 ERROR , 1 EXITO',
'apex.item( "P101_FLUJO" ).setValue(0);',
'',
'if(this.data.G_EXITO==''true''){',
'    apex.item( "P101_FLUJO" ).setValue(1);',
'}',
'else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}',
'',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5870921680509774)
,p_event_id=>wwv_flow_imp.id(5870725459509772)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_log_app		varchar2(100);',
'v_log_dsc		varchar2(3999);',
'v_numeroorden	number;',
'v_tipoorden		varchar2(200);',
'v_mensaje		varchar2(3999);',
'v_compania      varchar2(5):=''00001'';--:g_compania;',
'begin',
'	v_log_app := ''apex.130.101.rechazar'';',
'',
'	if :p101_flujo = 1 then',
'        PK_COMP_ORDENESCOMPRA.SP_CANCELAROCLINEA(',
'            P_NUMERO		=> :p101_numero ,',
'            P_TIPO		    => :p101_tipo,',
'            P_COMPANIA		=> v_compania,',
'            P_LINEAS		=> :p101_seleccion, -- si linea es null cancela a toda las lineas de la orden que esten pendientes',
'            P_NUMEROORDEN	=> V_NUMEROORDEN, --si es exitoso te devuelve el mismo numero de orden anulada',
'            P_TIPOORDEN		=> V_TIPOORDEN, -- si es exitoso te devuelve el mismo tipo orden anulada',
'            P_MENSAJE		=> V_MENSAJE',
'        );',
'        DBMS_OUTPUT.PUT_LINE(v_mensaje);',
'		:P101_MENSAJE := v_mensaje;',
'    	v_log_dsc := ''RECHAZAR: P101_TIPO: ''||:p101_tipo||'', P101_NUMERO: ''||:p101_numero||'', P101_FLUJO: ''||:p101_flujo||'', P101_SELECCION: ''||:p101_seleccion;',
'    	data.pk_commons.sp_apex_log(v_log_app,0,NULL,null,null,v_mensaje||'' -   ''||v_log_dsc);',
'',
'        if (UPPER(v_mensaje) not like ''%ERROR%'')THEN',
'			pk_comp_ordenescompra.sp_notificaruta(v_compania,v_numeroorden,v_tipoorden,-1);',
'        END IF;',
'		/*pk_comp_ordenescompra.sp_rechazarlinea(p_numero=>:p101_numero, p_tipo=>:p101_tipo,p_compania=>:g_compania, p_lineas =>:P101_SELECCION);*/',
'	end if;',
'end;'))
,p_attribute_02=>'P101_FLUJO,P101_SELECCION,P101_SINSELECCION,P101_MENSAJE'
,p_attribute_03=>'P101_MENSAJE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(340099641953298914)
,p_event_id=>wwv_flow_imp.id(5870725459509772)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let v_mensaje=$v("P101_MENSAJE");',
'',
'if (!v_mensaje.toUpperCase().includes("ERROR")){',
'            mensajeExito (v_mensaje);',
'}else{',
'    mensajeError (v_mensaje);',
'}'))
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P101_MENSAJE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5871045864509776)
,p_event_id=>wwv_flow_imp.id(5870725459509772)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var token = apex.item("P101_TOKEN").getValue();',
'ocultarBarra();',
'if(this.data.G_EXITO==''true''){',
'    if(token==''0''){',
'        $(''#btnAtras'').trigger("click");',
'    }else{',
'        $(''#btnAprobar'').hide();',
'        $(''#btnRechazar'').hide();',
'    }',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(5871922100509784)
,p_name=>'Seleccion'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.chkF01'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5871987866509785)
,p_event_id=>wwv_flow_imp.id(5871922100509784)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if(document.querySelectorAll(''.chkF01'').length == [].filter.call( document.querySelectorAll(''.chkF01''), function( el ) {return !el.checked}).length){',
'    //NO SELECCION NADA',
'     $(''#btnAprobar'').hide();',
'     $(''#btnRechazar'').hide();',
'}else{',
'    //SELECCIONO ALGO',
'     $(''#btnAprobar'').show();',
'     $(''#btnRechazar'').show();',
'}',
'',
'var lineas =""; ',
'document.querySelectorAll(''.chkF01'').forEach(function(seleccion) {',
'    if(!seleccion.checked){',
'        var linea = seleccion.value',
'        if(lineas==""){',
'            lineas = linea;',
'        }else{',
'            lineas = lineas+'',''+linea;',
'        }      ',
'    }',
'    ',
'});',
'apex.item("P101_SINSELECCION").setValue(lineas);',
'',
'var lineas =""; ',
'document.querySelectorAll(''.chkF01'').forEach(function(seleccion) {',
'    if(seleccion.checked){',
'        var linea = seleccion.value',
'        if(lineas==""){',
'            lineas = linea;',
'        }else{',
'            lineas = lineas+'',''+linea;',
'        }      ',
'    }',
'    ',
'});',
'apex.item("P101_SELECCION").setValue(lineas);',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(314313098424891925)
,p_name=>'Inicio'
,p_event_sequence=>40
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(314313154127891926)
,p_event_id=>wwv_flow_imp.id(314313098424891925)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var lineas =""; ',
'document.querySelectorAll(''.chkF01'').forEach(function(seleccion) {',
'    if(seleccion.checked){',
'        var linea = seleccion.value',
'        if(lineas==""){',
'            lineas = linea;',
'        }else{',
'            lineas = lineas+'',''+linea;',
'        }      ',
'    }',
'    ',
'});',
'apex.item("P101_SELECCION").setValue(lineas);',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(322267494014682369)
,p_name=>'Validacion aprobacion Vacio'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(322267208502678702)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(document.querySelectorAll(''.chkF01'').length == [].filter.call( ',
'    document.querySelectorAll(''.chkF01''), function( el ) {return !el.checked}).length )'))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(322267851227682386)
,p_event_id=>wwv_flow_imp.id(322267494014682369)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mensaje(''error'',''Debe seleccionar al menos una linea para aprobar, valide y vuelva a intentar.''); ',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(322268326587682387)
,p_event_id=>wwv_flow_imp.id(322267494014682369)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(320099842251569707)
,p_name=>'Validacion aprobacion Todo'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(322267208502678702)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(document.querySelectorAll(''.chkF01'').length == [].filter.call( ',
'    document.querySelectorAll(''.chkF01''), function( el ) {return el.checked}).length )'))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(320100174331569710)
,p_event_id=>wwv_flow_imp.id(320099842251569707)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#APROBAR'').trigger("click");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(320100262103569711)
,p_name=>'Validacion aprobacion algunos'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(322267208502678702)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'([].filter.call(document.querySelectorAll(''.chkF01''), function( el ) {return !el.checked}).length > 0 ) &&',
'(document.querySelectorAll(''.chkF01'').length > [].filter.call(document.querySelectorAll(''.chkF01''), function( el ) {return !el.checked}).length )'))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(320101226017569721)
,p_event_id=>wwv_flow_imp.id(320100262103569711)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(320100406181569713)
,p_event_id=>wwv_flow_imp.id(320100262103569711)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_log_app varchar2(100);',
'v_log_dsc varchar2(100);',
'v_NUMEROORDEN NUMBER;',
'    v_TIPOORDEN VARCHAR2(200);',
'    v_MENSAJE VARCHAR2(200);',
'begin',
'	v_log_app := ''apex.130.101.aprobar'';',
unistr('	v_log_dsc := ''Par\00E1metros: P101_TIPO: ''||:p101_tipo||'', P101_NUMERO: ''||:p101_numero;'),
'	data.pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,null,null,null);',
'',
'	if trim(:p101_sinseleccion) is not null then',
'        PK_COMP_ORDENESCOMPRA.SP_CANCELAROCLINEA(',
'            P_NUMERO => :p101_numero ,',
'            P_TIPO => :p101_tipo,',
'            P_COMPANIA => :G_COMPANIA,',
'            P_LINEAS => :p101_sinseleccion, -- si linea es null cancela a toda las lineas de la orden que esten pendientes',
'            P_NUMEROORDEN => v_NUMEROORDEN, --SI ES EXITOSO TE DEVUELVE EL MISMO NUMERO DE ORDEN ANULADA',
'            P_TIPOORDEN => v_TIPOORDEN, -- SI ES EXITOSO TE DEVUELVE EL MISMO TIPO ORDEN ANULADA',
'            P_MENSAJE => v_MENSAJE',
'          );	',
'		/*pk_comp_ordenescompra.sp_rechazarlinea(p_numero=>:p101_numero,p_tipo=>:p101_tipo,',
'            p_lineas=>:p101_sinseleccion,p_compania=>:g_compania);*/',
'        :P101_MENSAJE := v_mensaje ;',
'            ',
'	end if;',
'',
'end;'))
,p_attribute_02=>'P101_FLUJO,P101_SINSELECCION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(320101756449569726)
,p_event_id=>wwv_flow_imp.id(320100262103569711)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(5831853350060294)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(320101350168569722)
,p_event_id=>wwv_flow_imp.id(320100262103569711)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(322269537831686975)
,p_name=>'Validacion rechazar vacio'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(322269327806684438)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'(document.querySelectorAll(''.chkF01'').length == [].filter.call( document.querySelectorAll(''.chkF01''), function( el ) {return !el.checked}).length )'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(322270427346686976)
,p_event_id=>wwv_flow_imp.id(322269537831686975)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mensaje(''error'',''Debe seleccionar al menos una linea, valide y vuelva a intentar.''); ',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(322270915450686977)
,p_event_id=>wwv_flow_imp.id(322269537831686975)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(320100587519569714)
,p_name=>'Validacion rechazar todo'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(322269327806684438)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'(document.querySelectorAll(''.chkF01'').length == [].filter.call( document.querySelectorAll(''.chkF01''), function( el ) {return el.checked}).length )'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(320100649775569715)
,p_event_id=>wwv_flow_imp.id(320100587519569714)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#RECHAZAR'').trigger("click");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(320100944509569718)
,p_name=>'Validacion rechazar algunos'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(322269327806684438)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'(document.querySelectorAll(''.chkF01'').length > [].filter.call( document.querySelectorAll(''.chkF01''), function( el ) {return el.checked}).length )'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(320101496305569723)
,p_event_id=>wwv_flow_imp.id(320100944509569718)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(320101178760569720)
,p_event_id=>wwv_flow_imp.id(320100944509569718)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_log_app varchar2(100);',
'v_log_dsc varchar2(3999);',
'v_NUMEROORDEN NUMBER;',
'    v_TIPOORDEN VARCHAR2(200);',
'    v_MENSAJE VARCHAR2(3999);',
'v_compania      varchar2(5):=''00001'';--:g_compania;',
'begin',
'	v_log_app := ''apex.130.101.rechazar'';',
'    ',
'    PK_COMP_ORDENESCOMPRA.SP_CANCELAROCLINEA(',
'            P_NUMERO => :p101_numero ,',
'            P_TIPO => :p101_tipo,',
'            P_COMPANIA => v_compania,',
'            P_LINEAS => :P101_SELECCION, -- si linea es null cancela a toda las lineas de la orden que esten pendientes',
'            P_NUMEROORDEN => v_NUMEROORDEN, --SI ES EXITOSO TE DEVUELVE EL MISMO NUMERO DE ORDEN ANULADA',
'            P_TIPOORDEN => v_TIPOORDEN, -- SI ES EXITOSO TE DEVUELVE EL MISMO TIPO ORDEN ANULADA',
'            P_MENSAJE => v_MENSAJE',
'          );	',
'        DBMS_OUTPUT.PUT_LINE(v_mensaje);',
'        :P101_MENSAJE := v_mensaje ;',
'    	v_log_dsc := ''RECHAZAR: P101_TIPO: ''||:p101_tipo||'', P101_NUMERO: ''||:p101_numero||'', P101_FLUJO: ''||:p101_flujo||'', P101_SELECCION: ''||:p101_seleccion;',
'    	data.pk_commons.sp_apex_log(v_log_app,1,NULL,null,null,v_mensaje||'' -   ''||v_log_dsc);',
'        /*pk_comp_ordenescompra.sp_rechazarlinea(p_numero=>:p101_numero, p_tipo=>:p101_tipo,p_compania=>:g_compania, p_lineas =>:P101_SELECCION);*/',
'        :P101_SELECCION:=NULL;',
'        :P101_SINSELECCION:=NULL;',
'end;'))
,p_attribute_02=>'P101_FLUJO,P101_SELECCION,P101_SINSELECCION'
,p_attribute_03=>'P101_MENSAJE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(320101671805569725)
,p_event_id=>wwv_flow_imp.id(320100944509569718)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let v_mensaje=$v("P101_MENSAJE");',
'ocultarBarra();',
'if (!v_mensaje.toUpperCase().includes("ERROR")){',
'            mensajeExito (v_mensaje);',
'}else{',
'    mensajeError (v_mensaje);',
'}'))
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P101_MENSAJE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(340099793447298915)
,p_event_id=>wwv_flow_imp.id(320100944509569718)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(371952021166872105)
,p_name=>'Selecciona Todo Det OC'
,p_event_sequence=>110
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectalloc'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#tblDetalle'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(371952170658872106)
,p_event_id=>wwv_flow_imp.id(371952021166872105)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#tblDetalle #selectalloc'' ).is('':checked'')) {',
'		$(''#tblDetalle input[type=checkbox][name=f01]'').prop(''checked'',true);',
'		} else {',
'		$(''#tblDetalle input[type=checkbox][name=f01]'').prop(''checked'',false);',
'		}'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(5831764004060293)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga de Datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_contador		number;',
'v_ordencompra 	number;',
'v_tipooc		varchar2(2);',
'begin',
'	:p101_usuario	:= :app_user;',
'	:p101_token		:= 0;',
'',
'	if :g_detalle_id is not null and :g_token is not null then -- Aprobacion con token (desde link del correo)',
'		data.pk_corp_flujoaprobacion.sp_buscaraprobacion(',
'			:g_detalle_id',
'			, :g_token',
'			, :g_compania',
'			, :p101_aprobador',
'			, :p101_tipo',
'			, :p101_numero',
'		);',
'',
'		:p101_usuario := :p101_aprobador;',
'		:p101_token :=1;',
'	end if;',
'',
'	v_ordencompra 	:= :p101_numero;',
'	v_tipooc		:= :p101_tipo;',
'',
'	:p101_es_aprobador := pk_corp_flujoaprobacion.f_aprobadorflujo(:p101_usuario,:p101_aprobador,:app_modulo,:g_compania);',
'',
'	:p101_estado := null;',
'',
'	select count(1) into v_contador from vt_jde_ordencompra_cab where documento = v_ordencompra and documentotipo = v_tipooc;',
'',
'	if v_contador = 0 then',
'		return;',
'	end if;',
'',
'	-- Cabecera',
'	select unidadnegocio_des',
'		, proveedor',
'		, to_date(fechaentregajde+ 1900000,''yyyyddd'') ',
'		, fecha',
'		, decode(trim(tipocontrato),null,0,1)',
'		, nvl(trim(documentooriginal),0)',
'		, frecuenciapago',
'		, frecuencia',
'		, numeropago',
'		, to_char(nvl(trim(montoanticipo),0),''FML999G999G999G999G990D00'')',
'		, decode(fechapagojde,0,'''',to_date(fechapagojde + 1900000,''yyyyddd''))',
'		, decode(fechapagoanticipojde,0,'''',to_date(fechapagoanticipojde + 1900000,''yyyyddd''))',
'		, tipocontrato',
'		, decode(fechapagojde,0,'''',to_char( to_date(fechapagojde + 1900000,''yyyyddd''),''yyyy - MONTH''))',
'		, decode(fechaentregajde,0,'''',to_char( to_date(fechaentregajde + 1900000,''yyyyddd''), ''yyyy - MONTH''))',
'		, trim(incoterm)',
'	into',
'		:p101_unidad_negocio',
'		, :p101_proveedor',
'		, :p101_fecha_entrega',
'		, :p101_fecha_orden',
'		, :p101_contrato',
'		, :p101_ordenooriginal',
'		, :p101_frecuencia',
'		, :p101_tipo_monto',
'		, :p101_numero_pagos',
'		, :p101_anticipo',
'		, :p101_fecha_pago',
'		, :p101_fecha_anticipo',
'		, :p101_tipo_contrato',
'		, :p101_fecha_contrato_incio',
'		, :p101_fecha_contrato_fin',
'		, :p101_incoterm',
'	from vt_jde_ordencompra_cab where documento = v_ordencompra and documentotipo = v_tipooc;',
'',
unistr('	-- Descripci\00F3n de la Cabecera'),
'	select pk_comp_ordenescompra.f_descripcionlinea(v_ordencompra,v_tipooc,0) into :p101_descripcion from dual;',
'',
'	-- Monto',
'	select trunc(sum(total)) into :p101_monto from vt_jde_ordencompradetalle ',
'	where documento = v_ordencompra and documentotipo = v_tipooc and estado_ant != 980;',
'',
'	:p101_titulo := ''Orden de Compra'';',
'',
'	if :p101_contrato = 1 then',
'		:p101_titulo := ''Orden de Compra con Pago Recurrente'';',
'	end if;',
'',
'	select nvl(trim(pdoorn), pddoco) into :p101_numero_a from f4311@jdedtadl where pddoco = v_ordencompra and pddcto = v_tipooc and rownum = 1;',
'	select nvl(trim(pdocto), pddcto) into :p101_tipo_a from f4311@jdedtadl where pddoco = v_ordencompra and pddcto = v_tipooc and rownum = 1;',
'',
unistr('	-- [03/01/2024] Valido si hay diferencia de cantidades entre la requisici\00F3n y la OC'),
'	select count(1) into :p101_bandera_a',
'	from t_comp_prodto_proveedr_gestion where documentotipo_oc = v_tipooc and documento_oc = v_ordencompra and cantidad != nvl(cantidad_manual,cantidad);',
'',
'	:p101_mensaje := null;',
'',
'	-- Banderas de columnas opcionales',
'	begin',
'		:p101_bandera_infdet	:= 0;',
'		:p101_bandera_infprd	:= 0;',
'		:p101_bandera_actcom	:= 0;',
'',
unistr('		-- Informaci\00F3n para el Aprobador'),
'		select count(1) into :p101_bandera_infdet',
'		from vt_jde_ordencompradetalle',
'		where 1 = 1',
'			and documento = :p101_numero',
'			and documentotipo = :p101_tipo',
'			and pk_comp_ordenescompra.f_comentario@jdedtadl(p_compania=>:g_compania,p_tipooc=>documentotipo,p_ordencompra=>documento,p_tipo=>''A'',p_linea=>linea) is not null;',
'',
unistr('		-- Informaci\00F3n del Producto'),
'		select count(1) into :p101_bandera_infprd',
'		from vt_jde_ordencompradetalle',
'		where 1 = 1',
'			and documento = :p101_numero',
'			and documentotipo = :p101_tipo',
'			and tipolinea = ''S '';',
'',
'		-- Actividades Comerciales',
'		select count(1) into :p101_bandera_actcom',
'		from vt_jde_ordenes_act_com',
'		where 1 = 1',
'			and documento = :p101_numero',
'			and documentipo = :p101_tipo',
'			and trim(descripcion) is not null;',
'',
'		exception when others then',
'			:p101_bandera_infdet	:= 0;',
'			:p101_bandera_infprd	:= 0;',
'			:p101_bandera_actcom	:= 0;',
'	end;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>5831764004060293
,p_updated_on=>wwv_flow_imp.dz('20250505051655Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(5873825249509803)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Borrar datos'
,p_attribute_01=>'CLEAR_CACHE_FOR_ITEMS'
,p_attribute_03=>'P101_SINSELECCION,P101_FLUJO,G_TOKEN,G_DETALLE_ID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>5873825249509803
);
wwv_flow_imp.component_end;
end;
/
