prompt --application/pages/page_00121
begin
--   Manifest
--     PAGE: 00121
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>121
,p_name=>'Detalle Generacion de OC'
,p_step_title=>'Detalle Generacion de OC'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230708132653Z')
,p_last_updated_on=>wwv_flow_imp.dz('20230711143807Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(41727229677779514)
,p_plug_name=>'ResumenOCxProveedor'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>60
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.documento',
'	, a.documentotipo',
'	, a.PROVEEDOR',
'	, round(sum((a.totalcompra)/(select sum(x.totalcompra) from t_comp_generaoc x where x.documentotipo = a.documentotipo and x.documento = a.documento)),2)*100 porcentaje',
'	, sum(a.TOTALCOMPRA)/10000 valor',
'	, ''<span title="Ingresar Fecha"class="fa fa-calendar-o"/>'' fechas',
'	, ''<span title="Tipo Negociacion"class="fa fa-briefcase"/>'' negociacion',
'	, a.proveedor codigoproveedor',
'from t_comp_generaoc a',
'where a.documentotipo = :p121_tipo_req',
'and a.documento = :p121_num_req',
'and estado = 0',
'and a.proveedor is not null',
'group by a. documento, a. documentotipo, a.proveedor'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P121_NUM_REQ,P121_TIPO_REQ'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from t_comp_generaoc a',
'where a.DOCUMENTOTIPO = :p121_tipo_req',
'and a.DOCUMENTO = :p121_num_req',
'AND ESTADO = 0'))
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(41727365986779515)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'N'
,p_owner=>'CVACA'
,p_internal_uid=>41727365986779515
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(41931768497094002)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>10
,p_column_identifier=>'E'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(41931988281094004)
,p_db_column_name=>'VALOR'
,p_display_order=>30
,p_column_identifier=>'G'
,p_column_label=>'Valor'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(41933201917094017)
,p_db_column_name=>'PORCENTAJE'
,p_display_order=>40
,p_column_identifier=>'R'
,p_column_label=>'Porcentaje'
,p_column_html_expression=>'#PORCENTAJE#%'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43830549113620415)
,p_db_column_name=>'FECHAS'
,p_display_order=>50
,p_column_identifier=>'S'
,p_column_label=>'Fechas'
,p_column_link=>'f?p=&APP_ID.:125:&SESSION.::&DEBUG.:RP:P125_CODIGODOCUMENTO,P125_PROVEEDOR,P125_TIPO:#DOCUMENTO#,#CODIGOPROVEEDOR#,#DOCUMENTOTIPO#'
,p_column_linktext=>'#FECHAS#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43831277122620422)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>60
,p_column_identifier=>'T'
,p_column_label=>'Documento'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43831366915620423)
,p_db_column_name=>'DOCUMENTOTIPO'
,p_display_order=>70
,p_column_identifier=>'U'
,p_column_label=>'Documentotipo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43832391676620433)
,p_db_column_name=>'CODIGOPROVEEDOR'
,p_display_order=>80
,p_column_identifier=>'V'
,p_column_label=>'Codigoproveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(70672887671488413)
,p_db_column_name=>'NEGOCIACION'
,p_display_order=>90
,p_column_identifier=>'W'
,p_column_label=>'Negociacion'
,p_column_link=>'f?p=&APP_ID.:129:&SESSION.::&DEBUG.:RP:P129_CODIGODOCUMENTO,P129_PROVEEDOR,P129_TIPO:#DOCUMENTO#,#CODIGOPROVEEDOR#,#DOCUMENTOTIPO#'
,p_column_linktext=>'#NEGOCIACION#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(41744758761947614)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'417448'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PROVEEDOR:VALOR:PORCENTAJE::FECHAS:DOCUMENTO:DOCUMENTOTIPO:CODIGOPROVEEDOR:NEGOCIACION'
,p_sum_columns_on_break=>'VALOR:PORCENTAJE'
,p_created_on=>wwv_flow_imp.dz('20230708132653Z')
,p_updated_on=>wwv_flow_imp.dz('20230708132653Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43383572817124410)
,p_plug_name=>'Generacion OC Grid'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id',
'	, keyid',
'	, documento',
'	, documentotipo',
'	, codsolicitante',
'	, fecharequerimiento',
'	, nombrecomprador',
'	, codigoproducto',
'	, nombreproducto',
'	, unidadcompra',
'	, bodega',
'	, cantidadsolictada/10000 cantidadsolictada',
'	, cantidadsugeridacompra/10000 cantidadsugeridacompra',
'	, linea',
'	, '''' seleccionproveedor',
'	, proveedor',
'	, preciounitario/10000 preciounitario',
'	, moneda',
'	, totalcompra/10000 totalcompra',
'	, estado',
'	, usuario',
'	, auditoriafecha',
'	, '''' justificacionlinea',
'from t_comp_generaoc',
'where documentotipo = :p121_tipo_req',
'and documento = :p121_num_req',
'and estado = 0'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P121_TIPO_REQ,P121_NUM_REQ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43386008266124435)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>true
,p_default_type=>'SEQUENCE'
,p_default_expression=>'SQ_COMP_GENERAOC'
,p_duplicate_value=>false
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43386115140124436)
,p_name=>'KEYID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'KEYID'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Keyid'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>100
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43386209963124437)
,p_name=>'DOCUMENTO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DOCUMENTO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Documento'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>50
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43386399946124438)
,p_name=>'DOCUMENTOTIPO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DOCUMENTOTIPO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Documentotipo'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>2
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43386452533124439)
,p_name=>'CODSOLICITANTE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODSOLICITANTE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Codsolicitante'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>70
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43386581369124440)
,p_name=>'FECHAREQUERIMIENTO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHAREQUERIMIENTO'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DATE_PICKER'
,p_heading=>'Fecharequerimiento'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>80
,p_value_alignment=>'CENTER'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43386640892124441)
,p_name=>'NOMBRECOMPRADOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NOMBRECOMPRADOR'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Nombrecomprador'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_is_required=>false
,p_max_length=>100
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_control_break=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43386733338124442)
,p_name=>'CODIGOPRODUCTO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODIGOPRODUCTO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>unistr('C\00F3digo')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>100
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>25
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43386865545124443)
,p_name=>'NOMBREPRODUCTO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NOMBREPRODUCTO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Producto'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>110
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>50
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43386927438124444)
,p_name=>'UNIDADCOMPRA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UNIDADCOMPRA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'UM'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>2
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43387042452124445)
,p_name=>'BODEGA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BODEGA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Bodega'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>130
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>12
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43387110684124446)
,p_name=>'CANTIDADSOLICTADA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CANTIDADSOLICTADA'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Cant. Soli'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>140
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43387242041124447)
,p_name=>'CANTIDADSUGERIDACOMPRA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CANTIDADSUGERIDACOMPRA'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Cant. Compra'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>150
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43387350669124448)
,p_name=>'LINEA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'LINEA'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Linea'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>160
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43387479295124449)
,p_name=>'SELECCIONPROVEEDOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SELECCIONPROVEEDOR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_LINK'
,p_heading=>'_'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>170
,p_value_alignment=>'CENTER'
,p_link_target=>'f?p=&APP_ID.:122:&SESSION.::&DEBUG.:RP:P122_BODEGA,P122_CODIGOPRODUCTO,P122_KEYID:&BODEGA.,&CODIGOPRODUCTO.,&KEYID.'
,p_link_text=>'Costo-Proveeedor'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_escape_on_http_output=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43387595457124450)
,p_name=>'PROVEEDOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROVEEDOR'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Proveedor'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>180
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(41703476241628470)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43399559656364901)
,p_name=>'PRECIOUNITARIO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PRECIOUNITARIO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Precio'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>190
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43399604092364902)
,p_name=>'MONEDA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MONEDA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'$'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>200
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>3
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43399791392364903)
,p_name=>'TOTALCOMPRA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOTALCOMPRA'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Total'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>210
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43399827121364904)
,p_name=>'ESTADO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ESTADO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Estado'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>220
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43399900229364905)
,p_name=>'USUARIO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'USUARIO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Usuario'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>230
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>20
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43400096901364906)
,p_name=>'AUDITORIAFECHA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'AUDITORIAFECHA'
,p_data_type=>'DATE'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DATE_PICKER'
,p_heading=>'Auditoriafecha'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>240
,p_value_alignment=>'CENTER'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43400259683364908)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'N'
,p_attribute_03=>'Y'
,p_enable_hide=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43891916725246105)
,p_name=>'AccionesFila'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_enable_hide=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43995297444911207)
,p_name=>'JUSTIFICACIONLINEA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'JUSTIFICACIONLINEA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_LINK'
,p_heading=>'Justificacion'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>250
,p_value_alignment=>'CENTER'
,p_link_target=>'f?p=&APP_ID.:123:&SESSION.::&DEBUG.:RP:P123_CODIGODOCUMENTO,P123_TIPO,P123_LINEA:&DOCUMENTO.,&DOCUMENTOTIPO.,&LINEA.'
,p_link_text=>'Ver'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(43385986822124434)
,p_internal_uid=>43385986822124434
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>false
,p_toolbar_buttons=>null
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>false
,p_download_formats=>null
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_oracle_text_index_column=>'ID'
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(43405774458364953)
,p_interactive_grid_id=>wwv_flow_imp.id(43385986822124434)
,p_static_id=>'193714'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(43405878275364953)
,p_report_id=>wwv_flow_imp.id(43405774458364953)
,p_view_type=>'GRID'
,p_stretch_columns=>false
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(43406300098364954)
,p_view_id=>wwv_flow_imp.id(43405878275364953)
,p_display_seq=>22
,p_column_id=>wwv_flow_imp.id(43386008266124435)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(43406845259364956)
,p_view_id=>wwv_flow_imp.id(43405878275364953)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(43386115140124436)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(43407342551364957)
,p_view_id=>wwv_flow_imp.id(43405878275364953)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(43386209963124437)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(43407846758364959)
,p_view_id=>wwv_flow_imp.id(43405878275364953)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(43386399946124438)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(43408367893364960)
,p_view_id=>wwv_flow_imp.id(43405878275364953)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(43386452533124439)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(43408862641364962)
,p_view_id=>wwv_flow_imp.id(43405878275364953)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(43386581369124440)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(43409378966364964)
,p_view_id=>wwv_flow_imp.id(43405878275364953)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(43386640892124441)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(43409891285364965)
,p_view_id=>wwv_flow_imp.id(43405878275364953)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(43386733338124442)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>82
,p_sort_order=>1
,p_sort_direction=>'DESC'
,p_sort_nulls=>'FIRST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(43410313332364967)
,p_view_id=>wwv_flow_imp.id(43405878275364953)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(43386865545124443)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>144
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(43410865707364967)
,p_view_id=>wwv_flow_imp.id(43405878275364953)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(43386927438124444)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>54
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(43411331595364968)
,p_view_id=>wwv_flow_imp.id(43405878275364953)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(43387042452124445)
,p_is_visible=>false
,p_is_frozen=>false
,p_width=>60
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(43411882084364971)
,p_view_id=>wwv_flow_imp.id(43405878275364953)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(43387110684124446)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>79
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(43412327422364973)
,p_view_id=>wwv_flow_imp.id(43405878275364953)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(43387242041124447)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>104
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(43412890447364974)
,p_view_id=>wwv_flow_imp.id(43405878275364953)
,p_display_seq=>21
,p_column_id=>wwv_flow_imp.id(43387350669124448)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(43413345954364976)
,p_view_id=>wwv_flow_imp.id(43405878275364953)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(43387479295124449)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>118
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(43413847997364978)
,p_view_id=>wwv_flow_imp.id(43405878275364953)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(43387595457124450)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>169
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(43414397113364979)
,p_view_id=>wwv_flow_imp.id(43405878275364953)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(43399559656364901)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>73
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(43414818871364981)
,p_view_id=>wwv_flow_imp.id(43405878275364953)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(43399604092364902)
,p_is_visible=>false
,p_is_frozen=>false
,p_width=>48
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(43415312450364982)
,p_view_id=>wwv_flow_imp.id(43405878275364953)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(43399791392364903)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>78
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(43415868235364984)
,p_view_id=>wwv_flow_imp.id(43405878275364953)
,p_display_seq=>18
,p_column_id=>wwv_flow_imp.id(43399827121364904)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(43416338545364985)
,p_view_id=>wwv_flow_imp.id(43405878275364953)
,p_display_seq=>19
,p_column_id=>wwv_flow_imp.id(43399900229364905)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(43416821920364987)
,p_view_id=>wwv_flow_imp.id(43405878275364953)
,p_display_seq=>20
,p_column_id=>wwv_flow_imp.id(43400096901364906)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(43909804080760045)
,p_view_id=>wwv_flow_imp.id(43405878275364953)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(43891916725246105)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(44025299118268353)
,p_view_id=>wwv_flow_imp.id(43405878275364953)
,p_display_seq=>23
,p_column_id=>wwv_flow_imp.id(43995297444911207)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_aggregate(
 p_id=>wwv_flow_imp.id(89142000000)
,p_view_id=>wwv_flow_imp.id(43405878275364953)
,p_function=>'SUM'
,p_column_id=>wwv_flow_imp.id(43399791392364903)
,p_show_grand_total=>false
,p_is_enabled=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(43892083165246106)
,p_plug_name=>'Barra de accion Resumen'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>50
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(48658764381942177)
,p_plug_name=>unistr('Detalle Generaci\00F3n OC')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295639738305037692)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(53371042106910729)
,p_plug_name=>'Barra de accion'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(53373497758912694)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6961453820024047)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(53371042106910729)
,p_button_name=>'SALIR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Salir'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(41565259602887146)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(53371042106910729)
,p_button_name=>'CAMBIAPROVEEDOR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Cambiar de Proveedor'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:124:&SESSION.::&DEBUG.:RP:P124_DOCUMENTO,P124_DOCUMENTOTIPO:&P121_NUM_REQ.,&P121_TIPO_REQ.'
,p_icon_css_classes=>'fa-user-magnifying-glass'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(41565044953887144)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(53371042106910729)
,p_button_name=>'GUARDAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(43892498126246110)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(43892083165246106)
,p_button_name=>'APROBAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Enviar Aprobar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(43995444661911209)
,p_branch_name=>'Regresar'
,p_branch_action=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(43892498126246110)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3543397058486114)
,p_name=>'P121_NOMBRECOMPRADOR_1'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(53373497758912694)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Comprador:'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select APELLIDOS || '' '' || NOMBRES  FROM VT_CORP_USUARIO',
'WHERE CODERP = :P121_NOMBRECOMPRADOR'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6961147205024044)
,p_name=>'P121_NUM_REQ'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(53373497758912694)
,p_prompt=>unistr('# Requisici\00F3n: ')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>'STATIC:H1;H1,H3;H3'
,p_colspan=>5
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6961379213024046)
,p_name=>'P121_SOLICITANTE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(53373497758912694)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40556147288737746)
,p_name=>'P121_NOMBRECOMPRADOR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(53373497758912694)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select APELLIDOS || '' '' || NOMBRES  FROM VT_CORP_USUARIO',
'WHERE NOMBREUSUARIO = :APP_USER'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40556537258737746)
,p_name=>'P121_TIPO_REQ'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(53373497758912694)
,p_prompt=>'Tipo: '
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>'STATIC:H1;H1,H3;H3'
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(40556976035737746)
,p_name=>'P121_FECHA_REQ'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(53373497758912694)
,p_prompt=>'Fecha Requerimiento:'
,p_source=>'SELECT  ADD_MONTHS(SYSDATE,-12) FROM DUAL;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>5
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41562663045887120)
,p_name=>'P121_JUSTIFICACIONCABECERA'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(53373497758912694)
,p_prompt=>unistr('Justificaci\00F3n: ')
,p_source=>'CAMPO DESAHABILITADO TEMPORALMENTE.'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20230711143603Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(41564959078887143)
,p_name=>'P121_SOLICITANTENOMBRE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(53373497758912694)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Solicitante:'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nombres as r',
'from VT_JDE_LIBRODIRECCIONES',
'where codigo = :p121_solicitante'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(542214411830004746)
,p_name=>'P121_BODEGA'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(53373497758912694)
,p_prompt=>'Bodega:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(43996336789911218)
,p_tabular_form_region_id=>wwv_flow_imp.id(43383572817124410)
,p_validation_name=>'Valida Precio'
,p_validation_sequence=>10
,p_validation=>'PRECIOUNITARIO'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>'Ingrese Precio Unitario'
,p_when_button_pressed=>wwv_flow_imp.id(43892498126246110)
,p_only_for_changed_rows=>'N'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(43996411829911219)
,p_validation_name=>'Valida Ingreso de Fechas'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'v_aux number;',
'BEGIN',
'select nvl(COUNT(*),0) into v_aux',
'from t_comp_generaocfecha',
'where REQUISICION = :P121_NUM_REQ',
'AND TIPOREQUISICION = :P121_NUM_REQ',
'and fecha is not null;',
'',
'if v_aux != 0 then',
'return false;',
'else',
'return true;',
'end if;',
'',
'end;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_BOOLEAN'
,p_error_message=>'Ingrese Fecha '
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(43892498126246110)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(41565323236887147)
,p_name=>'ConfirmaSalir'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(6961453820024047)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41565429071887148)
,p_event_id=>wwv_flow_imp.id(41565323236887147)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Desea Salir sin guardar la OC'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41725998352779501)
,p_event_id=>wwv_flow_imp.id(41565323236887147)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var numsesion = document.getElementById(''pInstance'').value;',
'var href = ''f?p=130:120:''+numsesion+'':::::''; ',
'',
'window.location = href; '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(41726101638779503)
,p_name=>unistr('ConfirmaEnvioAprobaci\00F3n')
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(43892498126246110)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41726384806779505)
,p_event_id=>wwv_flow_imp.id(41726101638779503)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>unistr('\00BFDesea enviar a flujo de aprobaci\00F3n la OC generada?')
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(41728219275779524)
,p_name=>'CalculaTotalOC'
,p_event_sequence=>50
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41728428884779526)
,p_event_id=>wwv_flow_imp.id(41728219275779524)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  ',
'to_number(sum(nvl(TOTALCOMPRA,0)), ''999999999D9999999999'', ''NLS_NUMERIC_CHARACTERS='''',.'''''')',
'INTO :P121_TOTALOCVALOR',
'from t_comp_generaoc ',
'where DOCUMENTOTIPO = :p121_tipo_req',
'and DOCUMENTO = :p121_num_req ;'))
,p_attribute_02=>'P121_TIPO_REQ,P121_NUM_REQ'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(41729092449779532)
,p_name=>'GuardaCambiosOCPreliminar'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(41565044953887144)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(41726582796779507)
,p_event_id=>wwv_flow_imp.id(41729092449779532)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Desea guardar los cambios en la OC?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43403751195364943)
,p_event_id=>wwv_flow_imp.id(41729092449779532)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(43382924525124404)
,p_name=>'Refresca Proveedor'
,p_event_sequence=>100
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(43383572817124410)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43383038971124405)
,p_event_id=>wwv_flow_imp.id(43382924525124404)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(43383572817124410)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43400535238364911)
,p_event_id=>wwv_flow_imp.id(43382924525124404)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(41727229677779514)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(43400411703364910)
,p_name=>'Refresca Proveedor_1'
,p_event_sequence=>110
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(53371042106910729)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43830393271620413)
,p_event_id=>wwv_flow_imp.id(43400411703364910)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(43383572817124410)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43830218308620412)
,p_event_id=>wwv_flow_imp.id(43400411703364910)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(41727229677779514)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(43995674938911211)
,p_name=>'Refresca Fechas'
,p_event_sequence=>120
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(41727229677779514)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43995782701911212)
,p_event_id=>wwv_flow_imp.id(43995674938911211)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(41727229677779514)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43995824803911213)
,p_event_id=>wwv_flow_imp.id(43995674938911211)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(43383572817124410)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43996206110911217)
,p_event_id=>wwv_flow_imp.id(43995674938911211)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(43892083165246106)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(70673916413488424)
,p_name=>'Refresca Negociacion'
,p_event_sequence=>130
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(41727229677779514)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(70674259640488427)
,p_event_id=>wwv_flow_imp.id(70673916413488424)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(43892083165246106)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(70674113548488426)
,p_event_id=>wwv_flow_imp.id(70673916413488424)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(43383572817124410)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(70674079013488425)
,p_event_id=>wwv_flow_imp.id(70673916413488424)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(41727229677779514)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(70674518226488430)
,p_event_id=>wwv_flow_imp.id(70673916413488424)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_FOCUS'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(43892498126246110)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(43400629235364912)
,p_name=>'RecalculaTotalLinea'
,p_event_sequence=>140
,p_triggering_element_type=>'COLUMN'
,p_triggering_region_id=>wwv_flow_imp.id(43383572817124410)
,p_triggering_element=>'CANTIDADSUGERIDACOMPRA,PRECIOUNITARIO,PROVEEDOR'
,p_condition_element_type=>'COLUMN'
,p_condition_element=>'PRECIOUNITARIO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43400786738364913)
,p_event_id=>wwv_flow_imp.id(43400629235364912)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'COLUMN'
,p_affected_elements=>'TOTALCOMPRA'
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>':PRECIOUNITARIO * :CANTIDADSUGERIDACOMPRA'
,p_attribute_07=>'CANTIDADSUGERIDACOMPRA,PRECIOUNITARIO'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43401390730364919)
,p_event_id=>wwv_flow_imp.id(43400629235364912)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update t_comp_generaoc set totalcompra = (:preciounitario*:cantidadsugeridacompra)*10000',
'	, cantidadsugeridacompra = :cantidadsugeridacompra *10000',
'	, preciounitario = :preciounitario *10000',
'	, proveedor = :proveedor',
'where keyid = :keyid;',
'commit;'))
,p_attribute_02=>'KEYID,CANTIDADSUGERIDACOMPRA,PRECIOUNITARIO,PROVEEDOR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43401114466364917)
,p_event_id=>wwv_flow_imp.id(43400629235364912)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(41727229677779514)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(46414613636667022)
,p_name=>'ACTUALIZA JUSTIFICACION'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P121_JUSTIFICACIONCABECERA'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_updated_on=>wwv_flow_imp.dz('20230711143807Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(46414798181667023)
,p_event_id=>wwv_flow_imp.id(46414613636667022)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    null;',
'    --update f564310@jdedtadl set ialongmsg = (select :p121_justificacioncabecera from dual) where iadcto = :p121_tipo_req and iadoco = :p121_num_req and ialnid = 0;',
'end;'))
,p_attribute_02=>'P121_JUSTIFICACIONCABECERA,P121_NUM_REQ,P121_TIPO_REQ'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20230711143807Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(43891899098246104)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(43383572817124410)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Acciones IG'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'v_documento varchar2(8);',
'v_linea_max number;',
'begin',
'	case :apex$row_status',
'	when ''C'' then',
'		select max(linea) + 1000 into v_linea_max from t_comp_generaoc where documento = :p121_num_req and documentotipo = :p121_tipo_req;',
'',
'		insert into t_comp_generaoc',
'		(keyid,documento,documentotipo,codsolicitante,fecharequerimiento,nombrecomprador,bodega,cantidadsolictada,cantidadsugeridacompra,linea,totalcompra,estado,usuario,auditoriafecha)',
'		select DOCUMENTO||DOCUMENTOTIPO||v_linea_max,DOCUMENTO,DOCUMENTOTIPO,CODSOLICITANTE,FECHAREQUERIMIENTO,NOMBRECOMPRADOR,BODEGA,0,0,v_linea_max,0,0,:APP_USER,SYSDATE',
'		from T_COMP_GENERAOC',
'		where documento = :p121_num_req and documentotipo = :P121_TIPO_REQ and linea = v_linea_max and rownum = 1;',
'	when ''U'' then',
'		update t_comp_generaoc set documento  = :documento,documentotipo = :documentotipo where id = :id;',
'	when ''D'' then',
'		update  t_comp_generaoc set estado = 10 where id = :id;',
'	end case;',
'	commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>43891899098246104
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(43892567987246111)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Actualiza Justificaciones'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    null;',
'    -- update f564310@jdedtadl set ialongmsg = (select :p121_justificacioncabecera from dual) where iadcto = :p121_tipo_req and iadoco = :p121_num_req and ialnid = 0;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(41565044953887144)
,p_internal_uid=>43892567987246111
,p_updated_on=>wwv_flow_imp.dz('20230711143807Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(46414553627667021)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Actualiza Justificaciones_1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    null;',
'    -- update f564310@jdedtadl set ialongmsg = (select :p121_justificacioncabecera from dual) where iadcto = :p121_tipo_req and iadoco = :p121_num_req and ialnid = 0;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(43892498126246110)
,p_internal_uid=>46414553627667021
,p_updated_on=>wwv_flow_imp.dz('20230711143807Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(43995329718911208)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Genera OC en JDE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'p_compania			varchar2(200);',
'p_requisicion		number;',
'p_requisiciontipo	varchar2(200);',
'p_version			varchar2(200);',
'p_numeroorden		number;',
'p_tipoorden			varchar2(200);',
'p_mensaje			varchar2(200);',
'v_proveedor			number;',
'begin',
'	p_compania			:= ''00001'';',
'	p_requisicion		:= :p121_num_req ;',
'	p_requisiciontipo	:= :p121_tipo_req;',
'	p_version			:= null;',
'',
'	pk_comp_ordenescompra.sp_insertaorden(',
'		p_compania			=> p_compania',
'		, p_requisicion		=> p_requisicion',
'		, p_requisiciontipo	=> p_requisiciontipo',
'		, p_version			=> p_version',
'		, p_numeroorden		=> p_numeroorden',
'		, p_tipoorden		=> p_tipoorden',
'		, p_mensaje			=> p_mensaje',
'	);',
'	apex_application.g_print_success_message := p_mensaje || '' ''|| sysdate;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(43892498126246110)
,p_internal_uid=>43995329718911208
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(41787679591120746)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'InsertaPreliminarOC'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_contador number;',
'v_cantidadreq number;',
'v_cantidadpantalla number;',
'v_log_app    varchar2(50);',
'v_comprador   varchar2(100);',
'v_cod_comp    number;',
'begin',
'	v_log_app := ''apex.130.121.prerendering'';',
'	pk_commons.sp_apex_log(v_log_app,0,null,null,null,null);',
'',
'	select coderp into v_cod_comp from vt_corp_usuario where nombreusuario = :app_user and rownum = 1;',
'',
'	/*',
'	update f4311@jdedtadl a set  pdlttr = 980, pdnxtr = 999, pduopn = 0',
'	where pddoco||pddcto||pdlnid in (select keyid from t_comp_generaoc where estado = 10);',
'	*/',
'	update f4311@jdedtadl a set  pdlttr = 980, pdnxtr = 999, pduopn = 0',
'	where (pddoco,pddcto,pdlnid) in (select documento,documentotipo,linea from t_comp_generaoc where estado = 10);',
'	/*',
'	update f4311@jdedtadl x set (x.pdlttr,x.pdnxtr,x.pduopn) =',
'		(select 980,999,0 from t_comp_generaoc y where y.documento = x.pddoco and y.documentotipo = x.pddcto and y.linea = x.pdlnid and y.estado = 10)',
'	where exists',
'		(select 980,999,0 from t_comp_generaoc y where y.documento = x.pddoco and y.documentotipo = x.pddcto and y.linea = x.pdlnid and y.estado = 10);',
'	*/',
'',
'	pk_commons.sp_apex_log(v_log_app,1,null,null,null,null);',
'	delete t_comp_generaoc where keyid in (',
'		select pddoco||pddcto||pdlnid',
'		from f4311@jdedtadl a',
'		where (',
'			(pddcto = :p121_tipo_req and :p121_tipo_req = ''H3'' and pdlttr != 110 and pdnxtr != 120)',
'			or',
'			(pddcto = :p121_tipo_req and :p121_tipo_req = ''H1'' and pdlttr != 100 and pdnxtr != 130)',
'			)',
'			and pddoco = :p121_num_req);',
'',
'	pk_commons.sp_apex_log(v_log_app,2,null,null,null,null);',
'	select nvl(sum(a.pduorg),0) into v_cantidadreq',
'	from f4311@jdedtadl a',
'	where (',
'		(pddcto = :p121_tipo_req and :p121_tipo_req = ''H3'' and pdlttr = 110 and pdnxtr = 120)',
'		or',
'		(pddcto = :p121_tipo_req and :p121_tipo_req = ''H1'' and pdlttr = 100 and pdnxtr = 130)',
'		)',
'		and pddoco = :p121_num_req;',
'',
'	pk_commons.sp_apex_log(v_log_app,3,null,null,null,null);',
'	select nvl(sum(cantidadsolictada),0) into v_cantidadpantalla',
'	from t_comp_generaoc ',
'	where trim(documentotipo) = trim(:p121_tipo_req)',
'		and documento = :p121_num_req',
'		and estado = 0;',
'',
'	if v_cantidadreq > v_cantidadpantalla then',
'		pk_commons.sp_apex_log(v_log_app,4,null,null,null,null);',
'		insert into t_comp_generaoc (',
'			keyid,documento,documentotipo,codsolicitante,fecharequerimiento,nombrecomprador,codigoproducto,nombreproducto,',
'			unidadcompra,bodega,cantidadsolictada,cantidadsugeridacompra,linea,proveedor,preciounitario,moneda,totalcompra,estado,usuario,auditoriafecha',
'		) select pddoco||pddcto||pdlnid keyid',
'			, pddoco documento',
'			, pddcto documentotipo',
'			, pdan8 codsolicitante',
'			, pk_commons.f_jde2g(pdtrdj) fecharequerimiento',
'			, v_cod_comp nombrecomprador',
'			, codigoproducto',
'			, nombreproducto||'' ''||codigoalterno',
'			, unidadcompra',
'			, trim(pdmcu) bodega',
'			, pduorg cantidadsolictada',
'			, pduorg cantidadsugeridacompra',
'			, pdlnid linea',
'			, '''' proveedor',
'			, '''' preciounitario',
'			, '''' moneda',
'			, 0 totalcompra',
'			, 0 estado',
'			, :app_user usuario',
'			, sysdate auditoriafecha',
'		from f4311@jdedtadl a',
'		left join vt_jde_productos b on pditm = codigocorto',
'		where (',
'			(pddcto = :p121_tipo_req and :p121_tipo_req = ''H3'' and pdlttr = 110 and pdnxtr = 120)',
'			or',
'			(pddcto = :p121_tipo_req and :p121_tipo_req = ''H1'' and pdlttr = 100 and pdnxtr = 130)',
'			)',
'			and pddoco = :p121_num_req',
'			and pddoco||pddcto||pdlnid not in (select keyid from t_comp_generaoc where trim(documentotipo) = trim(:p121_tipo_req) and documento = :p121_num_req and estado = 0);',
'	end if;',
'',
'	select nvl(count(*),0) into v_contador from t_comp_generaoc where trim(documentotipo) = trim(:p121_tipo_req) and documento = :p121_num_req and estado = 0;',
'',
'	if v_contador = 0 then',
'		pk_commons.sp_apex_log(v_log_app,5,null,null,null,null);',
'		insert into t_comp_generaoc (',
'			keyid,documento,documentotipo,codsolicitante,fecharequerimiento,nombrecomprador,codigoproducto,nombreproducto,',
'			unidadcompra,bodega,cantidadsolictada,cantidadsugeridacompra,linea,proveedor,preciounitario,moneda,totalcompra,estado,usuario,auditoriafecha',
'		) select pddoco||pddcto||pdlnid keyid',
'			, pddoco documento',
'			, pddcto documentotipo',
'			, pdan8 codsolicitante',
'			, pk_commons.f_jde2g(pdtrdj) fecharequerimiento',
'			, to_number(comprador) nombrecomprador',
'			, codigoproducto',
'			, nombreproducto',
'			, unidadcompra',
'			, trim(pdmcu) bodega',
'			, pduorg cantidadsolictada',
'			, pduorg cantidadsugeridacompra',
'			, pdlnid linea',
'			, '''' proveedor',
'			, '''' preciounitario',
'			, '''' moneda',
'			, 0 totalcompra',
'			, 0 estado',
'			, :app_user usuario',
'			, sysdate auditoriafecha',
'		from f4311@jdedtadl a',
'		left join vt_jde_productos b on pditm = codigocorto',
'		where (',
'			(pddcto = :p121_tipo_req and :p121_tipo_req = ''H3'' and pdlttr = 110 and pdnxtr = 120)',
'			or',
'			(pddcto = :p121_tipo_req and :p121_tipo_req = ''H1'' and pdlttr = 100 and pdnxtr = 130)',
'			)',
'			and pddoco = :p121_num_req;',
'	end if;',
'	pk_commons.sp_apex_log(v_log_app,6,null,null,null,null);',
'	commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>41787679591120746
);
wwv_flow_imp.component_end;
end;
/
