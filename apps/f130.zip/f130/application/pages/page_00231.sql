prompt --application/pages/page_00231
begin
--   Manifest
--     PAGE: 00231
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>231
,p_name=>'Devoluciones MO NC Revisar'
,p_alias=>'DEVOLUCIONES-MO-NC-REVISAR'
,p_page_mode=>'MODAL'
,p_step_title=>'Devoluciones MO NC Revisar'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'div.formulario {',
'    padding: 0px;',
'}',
'',
'.t-Form-inputContainer, .t-Form-labelContainer {',
'    padding-top: 0px;',
'    padding-bottom: 1px;',
'}',
'',
'.t-Form--large .t-Form-label, .t-Form-fieldContainer--large .t-Form-label {',
'    padding-top: 0px;',
'    padding-bottom: 1px;',
'}',
'',
'.a-IRR-table td {',
'    padding: 1px;',
'}',
'.a-IRR-header {',
'    height: 25px;',
'}',
'.a-IRR-headerLink {',
'    min-height: 25px;',
'    padding-top: 0px;',
'    padding-bottom: 0px;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20250221161023Z')
,p_last_updated_on=>wwv_flow_imp.dz('20250227205518Z')
,p_last_updated_by=>'FGUEVARA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(965738328453557313)
,p_plug_name=>'Cabecera'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(983788263151410177)
,p_plug_name=>'Aprobar'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>120
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(983788458853410179)
,p_plug_name=>'RECHAZAR'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>130
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1023199500561718872)
,p_plug_name=>'Detalle'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>110
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    CANTIDAD, ',
'    UNIDAD, ',
'    COSTOUNID, ',
'    COSTOTOT ',
'FROM ',
'    DP.t_valorrechazo ',
'WHERE ',
'    NROINFORME=:P231_INFORME_NUMERO;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Detalle'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1023199592435718873)
,p_max_row_count=>'1000000'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>1023199592435718873
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(522245918411732196)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(522246323817732196)
,p_db_column_name=>'UNIDAD'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Und.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(522246719748732196)
,p_db_column_name=>'COSTOUNID'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Cost. Unit.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(522247142020732197)
,p_db_column_name=>'COSTOTOT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1023214800225885104)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5009740'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CANTIDAD:UNIDAD:COSTOUNID:COSTOTOT'
,p_created_on=>wwv_flow_imp.dz('20250221161023Z')
,p_updated_on=>wwv_flow_imp.dz('20250221161023Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(522244167202732192)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(983788263151410177)
,p_button_name=>'APROBAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--success'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Aprobar'
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(522244805999732193)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(983788458853410179)
,p_button_name=>'RECHAZAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--success'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Rechazar'
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(522251134814732205)
,p_branch_name=>'APROBAR'
,p_branch_action=>'f?p=&APP_ID.:230:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(522244167202732192)
,p_branch_sequence=>10
,p_updated_on=>wwv_flow_imp.dz('20250227205457Z')
,p_updated_by=>'FGUEVARA'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(522251572038732205)
,p_branch_name=>'RECHAZAR'
,p_branch_action=>'f?p=&APP_ID.:230:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(522244805999732193)
,p_branch_sequence=>20
,p_updated_on=>wwv_flow_imp.dz('20250227205517Z')
,p_updated_by=>'FGUEVARA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(522241483827732188)
,p_name=>'P231_O4_NUMERO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(965738328453557313)
,p_prompt=>'O4'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(522241868164732189)
,p_name=>'P231_INFORME_NUMERO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(965738328453557313)
,p_prompt=>unistr('N\00FAm. Informe')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(522242211791732189)
,p_name=>'P231_PROVEEDOR_NOMBRE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(965738328453557313)
,p_prompt=>'Proveedor Nombre'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NOMBRE',
'FROM DP.USRPEDIDOS',
'WHERE CODIGOCLIENTE = :P231_PROVEEDOR_CODIGO',
';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(522242650738732190)
,p_name=>'P231_PRODUCTO_NOMBRE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(965738328453557313)
,p_prompt=>'Materia Prima'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(522243046555732190)
,p_name=>'P231_NOTA_CREDITO_MP_LINK'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(965738328453557313)
,p_prompt=>'N.C. Mat. Prima'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'HTML_UNSAFE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(522243437264732191)
,p_name=>'P231_NOTA_CREDITO_FEE_LINK'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(965738328453557313)
,p_prompt=>'N.C. Fee'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'HTML_UNSAFE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(522245246703732193)
,p_name=>'P231_OBSERVACIONES'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(983788458853410179)
,p_prompt=>'Observaciones'
,p_placeholder=>'Motivo del rechazo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(522247810533732201)
,p_name=>'P231_PROVEEDOR_CODIGO'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(522248282877732201)
,p_name=>'P231_CODIGOCORTOPRODUCTO'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(522248604057732202)
,p_name=>'P231_NOTA_CREDITO_MP'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(522249078444732202)
,p_name=>'P231_NOTA_CREDITO_FEE'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(522249519482732203)
,p_validation_name=>'RECHAZAR'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P231_OBSERVACIONES IS NULL OR LENGTH(:P231_OBSERVACIONES) < 5 THEN',
'    RETURN ''Debe detallar el motivo del rechazo'';',
'END IF;',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(522244805999732193)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(522250296542732204)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'APROBAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_EXTE_GESTION_DEVOLUCION.SP_COMPRAS_APRUEBA_NCS(',
'    :P231_O4_NUMERO,',
'    :P231_CODIGOCORTOPRODUCTO',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(522244167202732192)
,p_internal_uid=>522250296542732204
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(522250674105732204)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'RECHAZAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_EXTE_GESTION_DEVOLUCION.SP_COMPRAS_RECHAZA_NCS(',
'    :P231_O4_NUMERO,',
'    :P231_CODIGOCORTOPRODUCTO,',
'    :P231_OBSERVACIONES',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(522244805999732193)
,p_internal_uid=>522250674105732204
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(522249819857732203)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga O4'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    V_URL_RIDE  VARCHAR2(500);',
'BEGIN',
'    SELECT ',
'        PK_EXTE_GESTION_DESPACHO.F_RECUPERA_PARAMETRO(''URL_RIDE'', ''/descargaDocumentos/descargarride'') ',
'    INTO',
'        V_URL_RIDE',
'    FROM DUAL;',
'',
'    SELECT',
'        INFORME_NUMERO,',
'        PRODUCTO_NOMBRE,',
'        PROVEEDOR_CODIGO,',
'',
'        SUBSTR(NOTA_CREDITO_MP,  25,3)||''-''||SUBSTR(NOTA_CREDITO_MP,  28,3)||''-''||SUBSTR(NOTA_CREDITO_MP,  31,9),',
'        SUBSTR(NOTA_CREDITO_FEE, 25,3)||''-''||SUBSTR(NOTA_CREDITO_FEE, 28,3)||''-''||SUBSTR(NOTA_CREDITO_FEE, 31,9),',
'',
'        ''<a href="''||V_URL_RIDE||''?claveAcceso=''||NOTA_CREDITO_MP ||''">''||SUBSTR(NOTA_CREDITO_MP,  25,3)||''-''||SUBSTR(NOTA_CREDITO_MP,  28,3)||''-''||SUBSTR(NOTA_CREDITO_MP,  31,9)||''</a>'',',
'        ''<a href="''||V_URL_RIDE||''?claveAcceso=''||NOTA_CREDITO_FEE||''">''||SUBSTR(NOTA_CREDITO_FEE, 25,3)||''-''||SUBSTR(NOTA_CREDITO_FEE, 28,3)||''-''||SUBSTR(NOTA_CREDITO_FEE, 31,9)||''</a>'',',
'        ',
'        OBSERVACION',
'',
'    INTO',
'        :P231_INFORME_NUMERO,',
'        :P231_PRODUCTO_NOMBRE,',
'        :P231_PROVEEDOR_CODIGO,',
'',
'        :P231_NOTA_CREDITO_MP,',
'        :P231_NOTA_CREDITO_FEE,',
'',
'        :P231_NOTA_CREDITO_MP_LINK,',
'        :P231_NOTA_CREDITO_FEE_LINK,',
'',
'        :P231_OBSERVACIONES',
'    FROM',
'        VT_EXTE_DEVOLUCION_MESA_PROVDR',
'    WHERE',
'        O4_NUMERO = :P231_O4_NUMERO',
'            AND',
'             INFORME_ESTADO not in (''0'', ''6'', ''7'') and ',
'        CODIGOCORTOPRODUCTO = :P231_CODIGOCORTOPRODUCTO',
'    ;',
'END;',
'',
'',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>522249819857732203
,p_updated_on=>wwv_flow_imp.dz('20250227181418Z')
,p_updated_by=>'FGUEVARA'
);
wwv_flow_imp.component_end;
end;
/
