prompt --application/pages/page_00235
begin
--   Manifest
--     PAGE: 00235
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>235
,p_name=>'Etapas Importacion Muestras'
,p_alias=>'ETAPAS-IMPORTACION-MUESTRAS'
,p_step_title=>'Etapas Importacion Muestras'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'16'
,p_created_on=>wwv_flow_imp.dz('20240410163238Z')
,p_last_updated_on=>wwv_flow_imp.dz('20250320204301Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(171065954489714435)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(171066019046714436)
,p_plug_name=>unistr('Importaci\00F3n ET1')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       IDPROCESO,       ',
'       CODIGOPROVEEDOR,',
'       MONTOMUESTRA,',
'       PAGOEXTERIOR,',
'       CENTRODECOSTO,      ',
'       PAISORIGEN,',
'       ICOTERM,',
'       NUMEROFACTURA,',
'       MODALIDAD,',
'       FORWARDER,',
'       REGIMEN',
'  from T_CMEX_MUESTRAS'))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P235_ETAPA=''ET1'''
,p_plug_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(172361996847475595)
,p_plug_name=>unistr('Etapa 1 Importaci\00F3n de Muestras')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296122226350169167)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(172368193824537144)
,p_plug_name=>unistr('Importaci\00F3n ET2')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       IDPROCESO,       ',
'       CODIGOPROVEEDOR,',
'       MONTOMUESTRA,',
'       PAGOEXTERIOR,',
'       CENTRODECOSTO,      ',
'       PAISORIGEN,',
'       ICOTERM,',
'       NUMEROFACTURA,',
'       MODALIDAD,',
'       FORWARDER,',
'       REGIMEN',
'  from T_CMEX_MUESTRAS'))
,p_is_editable=>false
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P235_ETAPA=''ET2'''
,p_plug_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(172364754112537110)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(171065954489714435)
,p_button_name=>'Retornar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Retornar'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:176:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
,p_updated_on=>wwv_flow_imp.dz('20240830211605Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(172365211476537115)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(171065954489714435)
,p_button_name=>'Ruta_CC'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Ruta CC'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:104:&SESSION.::&DEBUG.::G_OBJETO,G_OBJETO_ID,G_TODO:IMPORTACION_MUESTRAS,&P235_ID.,true'
,p_icon_css_classes=>'fa-road'
,p_updated_on=>wwv_flow_imp.dz('20240830211605Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(172365050826537113)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(171065954489714435)
,p_button_name=>'Adjuntos'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Adjuntos'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:401:&SESSION.::&DEBUG.::P401_TABLA,P401_ID,P401_ESTADO,P401_REGIMEN:T_CMEX_MUESTRAS,&P235_ID.,0,&P235_REGIMEN.'
,p_icon_css_classes=>'fa-paperclip'
,p_updated_on=>wwv_flow_imp.dz('20240830211605Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(172367575049537138)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(171065954489714435)
,p_button_name=>'Grabar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Grabar ETD'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-save'
,p_updated_on=>wwv_flow_imp.dz('20240830211605Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(172365329888537116)
,p_button_sequence=>140
,p_button_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_button_name=>'Tipo_Muestra'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Tipo Muestra'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:236:&SESSION.::&DEBUG.::P236_ID:&P235_ID.'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171066233112714438)
,p_name=>'P235_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_item_source_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171067166852714447)
,p_name=>'P235_CODIGOPROVEEDOR'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_item_source_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_prompt=>'Proveedor: '
,p_source=>'CODIGOPROVEEDOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_CMEX_PROVEEDORES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CODIGOJDE ||'' - ''||RAZONSOCIAL D, CODIGOJDE R',
'FROM VT_COMP_JDEPROVEEDOR',
'UNION',
'SELECT CAST(''99999 - OTROS'' AS NCHAR(40)) D, 99999 R',
'FROM DUAL;      '))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20240611150718Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171067250762714448)
,p_name=>'P235_CENTRODECOSTO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_item_source_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_prompt=>'Centro de Costos: '
,p_source=>'CENTRODECOSTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171067356452714449)
,p_name=>'P235_NUMEROFACTURA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_item_source_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_prompt=>unistr('N\00FAmero Factura: ')
,p_source=>'NUMEROFACTURA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(171067415857714450)
,p_name=>'P235_PAISORIGEN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_item_source_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_prompt=>unistr('Pa\00EDs de Origen: ')
,p_source=>'PAISORIGEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_PAISES_JDE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select drdl01 d, drky r',
'from vt_jde_udcjde ',
'where drsy = ''00'' and drrt = ''CN'' and drky != ''*'' order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20240410195746Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(172363877634537101)
,p_name=>'P235_FORWARDER'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_item_source_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_prompt=>'Forwarder: '
,p_source=>'FORWARDER'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(172363984489537102)
,p_name=>'P235_ICOTERM'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_item_source_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_prompt=>'Icoterm: '
,p_source=>'ICOTERM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(172364036401537103)
,p_name=>'P235_MONTOMUESTRA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_item_source_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_prompt=>'Monto de la muestra:'
,p_pre_element_text=>'$'
,p_source=>'MONTOMUESTRA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(172364156917537104)
,p_name=>'P235_MODALIDAD'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_item_source_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_prompt=>'Modalidad: '
,p_source=>'MODALIDAD'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(172364259687537105)
,p_name=>'P235_PAGOEXTERIOR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_item_source_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_prompt=>'Genera Pago al Exterior:'
,p_source=>'PAGOEXTERIOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_SINO'
,p_lov=>'.'||wwv_flow_imp.id(78141453854944977)||'.'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(172364657315537109)
,p_name=>'P235_IDMUESTRA'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(172364970207537112)
,p_name=>'P235_IDPROCESO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_item_source_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_prompt=>'Registro: '
,p_source=>'IDPROCESO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(172365113096537114)
,p_name=>'P235_REGIMEN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_item_source_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_source=>'REGIMEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(172367476090537137)
,p_name=>'P235_ETD'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(171066019046714436)
,p_prompt=>'ETD: '
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(172367796699537140)
,p_name=>'P235_ETAPA'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(172367685705537139)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Actualizaq_ETD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_fechazarpe	date;',
'v_regimen		varchar2(5);',
'v_idmst			number;',
'begin',
'	v_idmst := :p235_id;',
'	-- Obtengo el TIPO DE REGIMEN',
'	-- begin',
'	-- 	select regimen into v_regimen from t_cmex_muestras where id = v_idmst;',
'',
'	-- 	exception when no_data_found then v_regimen := ''0'';',
'	-- end;',
'',
'	-- obtengo la fecha de ZARPE',
'	begin',
'		select max(fechazarpe) into v_fechazarpe from t_cmex_muestrasdet where idcabecera = v_idmst;',
'',
'		exception when no_data_found then v_fechazarpe := null;',
'	end;',
'',
'	-- si la fecha ETD es mayor o igua a la fecha actual, el proceso pasa a etapa 2',
'	if :p235_etd >= v_fechazarpe or v_fechazarpe is null then',
'		-- si la fecha ETD es mayor o igua a la fecha actual, actualizo la fecha de ZARPE ',
'		update t_cmex_muestrasdet set fechazarpe = :p235_etd where idcabecera = v_idmst;',
'',
'		--proceso pasa a etapa 2',
'		update t_cmex_muestras set etapa = ''ET2''--DECODE(REGIMEN,''10'',''ET2'',''91'',''ET5'')',
'		where id = v_idmst;',
'',
'		update t_cmex_mesatrabajo',
'		set codigoetapa = ''ET2'',--DECODE(V_REGIMEN,''10'',''ET2'',''91'',''ET5''),',
'			fechaetd = :p235_etd',
'		where id_muestra = v_idmst;',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>172367685705537139
,p_updated_on=>wwv_flow_imp.dz('20250320204301Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(171066178499714437)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(171066019046714436)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Etapas Importacion Muestras'
,p_internal_uid=>171066178499714437
);
wwv_flow_imp.component_end;
end;
/
