prompt --application/pages/page_00401
begin
--   Manifest
--     PAGE: 00401
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>401
,p_name=>unistr('Reporte - Tiempo de Requisici\00F3n')
,p_alias=>unistr('REPORTE-TIEMPO-DE-REQUISICI\00D3N')
,p_step_title=>unistr('Tiempo de Requisici\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(316585522945694029)
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(regOcultos).hide();',
'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_last_updated_on=>wwv_flow_imp.dz('20260803185057Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(316580507623678604)
,p_plug_name=>unistr('Par\00E1metros')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(316580674978678605)
,p_plug_name=>'Reporte'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with rq as (',
'	select phkcoo rqkcoo',
'		, phdoco rqdoco',
'		, phdcto rqdcto',
'		, phan8 rqan8',
'		, abalph rqalph',
'		, phshan rqshan',
'		, phdrqj rqdrqj',
'		, phtrdj rqtrdj',
'	from data.vt_jde_f4301',
'	inner join data.vt_jde_f0101 on phan8 = aban8',
'	where phdcto in (''H1'',''H2'',''H3'')',
'), oc as (',
'	select phkcoo ockcoo',
'		, phdoco ocdoco',
'		, phdcto ocdcto',
'		, phan8 ocan8',
'		, abalph ocalph',
'		, phshan ocshan',
'		, phdrqj ocdrqj',
'		, phtrdj octrdj',
'	from data.vt_jde_f4301',
'	inner join data.vt_jde_f0101 on phan8 = aban8',
'	where phdcto in (''CN'',''CM'',''BM'',''BN'')',
') select v11.pdkcoo',
'	, v11.pdoorn rqdoco',
'	, v11.pdocto rqdcto',
'	, rq.rqdrqj fecharq',
'	, rq.rqalph requisitor',
'	, v11.pddoco ocdoco',
'	, v11.pddcto ocdcto',
'	, oc.ocdrqj fechaoc',
'	, oc.ocan8 codproveedor',
'	, oc.ocalph proveedor',
'	, decode(rq.rqdrqj, null, null, oc.ocdrqj - rq.rqdrqj) diasrqoc',
'	, v11.pdlitm codproducto',
'	, v11.pddsc1 descoc1',
'	, v11.pddsc2 descoc2',
'	, im.imdsc1 descprd1',
'	, im.imdsc2 descprd2',
'	, v11.pduorg cantordoc',
'	, v11.pdurec cantrecoc',
'	, v11.pdprrc precunitoc',
'	, v11.pdaexp totaloc',
'from data.vt_jde_f4311 v11',
'inner join data.vt_jde_f4101 im on v11.pdlitm = im.imlitm',
'inner join oc on v11.pdkcoo = oc.ockcoo and v11.pddoco = oc.ocdoco and v11.pddcto = oc.ocdcto',
'left join rq on v11.pdkcoo = rq.rqkcoo and v11.pdoorn = rq.rqdoco and v11.pdocto = rq.rqdcto',
'where 1 = 1',
'	and :p401_bandera = 1',
'	and oc.ocdrqj between :p401_fechadesde and :p401_fechahasta'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(316580701086678606)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>316580701086678606
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316580876873678607)
,p_db_column_name=>'PDKCOO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>unistr('Compa\00F1ia')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316580963810678608)
,p_db_column_name=>'RQDOCO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>unistr('N\00FAm. RQ')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316581085992678609)
,p_db_column_name=>'RQDCTO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Tipo RQ'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316581136543678610)
,p_db_column_name=>'FECHARQ'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fecha RQ'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316581273290678611)
,p_db_column_name=>'REQUISITOR'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Requisitor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316581304888678612)
,p_db_column_name=>'OCDOCO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>unistr('N\00FAm. OC')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316581451311678613)
,p_db_column_name=>'OCDCTO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Tipo OC'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316581594405678614)
,p_db_column_name=>'FECHAOC'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Fecha OC'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316581688838678615)
,p_db_column_name=>'CODPROVEEDOR'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>unistr('C\00F3d. Proveedor')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316581785444678616)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316581834740678617)
,p_db_column_name=>'DIASRQOC'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>unistr('D\00EDas RQ/OC')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316581918877678618)
,p_db_column_name=>'CODPRODUCTO'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>unistr('C\00F3d. Producto')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316582094911678619)
,p_db_column_name=>'DESCOC1'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Desc. Prd. OC 1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316582161580678620)
,p_db_column_name=>'DESCOC2'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Desc. Prd. OC 2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316582263839678621)
,p_db_column_name=>'DESCPRD1'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Desc. Prd. 1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316582389596678622)
,p_db_column_name=>'DESCPRD2'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Desc. Prd. 2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316582454189678623)
,p_db_column_name=>'CANTORDOC'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Cant. Ord.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316582573304678624)
,p_db_column_name=>'CANTRECOC'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Cant. Rec'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316582601041678625)
,p_db_column_name=>'PRECUNITOC'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Prec. UN'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316582728112678626)
,p_db_column_name=>'TOTALOC'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(316604403129959708)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3166045'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PDKCOO:RQDOCO:RQDCTO:FECHARQ:REQUISITOR:OCDOCO:OCDCTO:FECHAOC:CODPROVEEDOR:PROVEEDOR:DIASRQOC:CODPRODUCTO:DESCOC1:DESCOC2:DESCPRD1:DESCPRD2:CANTORDOC:CANTRECOC:PRECUNITOC:TOTALOC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(316582850967678627)
,p_plug_name=>'Ocultos'
,p_region_name=>'regOcultos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(322419437291881677)
,p_plug_name=>unistr('Barra de Acci\00F3n')
,p_region_name=>'rptBarraAccion'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(316583215008678631)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(322419437291881677)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Buscar'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(316582995577678628)
,p_name=>'P401_FECHADESDE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(316580507623678604)
,p_item_default=>'trunc(add_months(sysdate,-1),''MONTH'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Desde'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'TODAY-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(316583056566678629)
,p_name=>'P401_FECHAHASTA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(316580507623678604)
,p_item_default=>'sysdate'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Hasta'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'TODAY-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(316583301840678632)
,p_name=>'P401_BANDERA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(316582850967678627)
,p_prompt=>'Bandera'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(316583450889678633)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Bandera'
,p_process_sql_clob=>':p401_bandera := 1;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(316583215008678631)
,p_internal_uid=>316583450889678633
);
wwv_flow_imp.component_end;
end;
/
