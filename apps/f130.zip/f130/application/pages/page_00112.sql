prompt --application/pages/page_00112
begin
--   Manifest
--     PAGE: 00112
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>112
,p_name=>unistr('Aprobaci\00F3n Pago Recurrente')
,p_alias=>unistr('APROBACI\00D3N-PAGO-RECURRENTE')
,p_step_title=>unistr('Aprobaci\00F3n Pago Recurrente')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(regItems).hide();',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240522202903Z')
,p_last_updated_on=>wwv_flow_imp.dz('20250224190455Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(203625069320739502)
,p_plug_name=>'Alerta'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(295605160997037667)
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_source=>unistr('<span style="color: #ff0000a3;font-size: xx-large;font-family: fantasy;">No existe informaci\00F3n para aprobaci\00F3n</span>')
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P112_IDNEG'
,p_plug_display_when_cond2=>'0'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20240522211527Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(209074337231233372)
,p_plug_name=>'Pago Recurrente'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296122226350169167)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_plug_display_when_condition=>'P112_IDNEG'
,p_plug_display_when_cond2=>'0'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(209425935859645868)
,p_plug_name=>'Botones'
,p_region_name=>'regBotones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121809343169165)
,p_plug_display_sequence=>70
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P112_ES_APROBADOR'
,p_plug_display_when_cond2=>'1'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20240522212031Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(300487056840773244)
,p_plug_name=>unistr('Detalle de la Negociaci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>50
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_plug_display_when_condition=>'P112_IDNEG'
,p_plug_display_when_cond2=>'0'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'N',
  'rds_mode', 'STANDARD',
  'remember_selection', 'NO')).to_clob
,p_created_on=>wwv_flow_imp.dz('20240522211527Z')
,p_updated_on=>wwv_flow_imp.dz('20240522212328Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(333001607213522355)
,p_plug_name=>unistr('\00CDtems')
,p_region_name=>'rptDetalle'
,p_parent_plug_id=>wwv_flow_imp.id(300487056840773244)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct det_id id',
'	, cab_id idcab',
'	, (select codigoproducto||'' - ''||nombreproducto||'' ''||codigoalterno||'' - [''||unidadcompra||'']'' d from vt_jde_productos where codigocorto = det_codproducto and codestado <> ''O'') codigoproducto',
'	, det_codproducto codproducto',
'	, det_codproductoprv codproductoprv',
'	, det_desproductoprv desproductoprv',
'	, det_umproductoprv umproductoprv',
unistr('	, decode(det_tiempoentrega,0,''Inmediato'',det_tiempoentrega ||'' d\00EDas'') tiempoentrega'),
'	, (select upper(trim(pnptd)) d from f0014@jdedtadl where pnptc = det_formapago and trim(pnptc) is not null) formapago',
'	, (select drky ||'' - ''||upper(drdl01) d from vt_jde_udcjde where drky = det_incoterm and drsy = ''42'' and drrt = ''FR'' and drky is not null ) incoterm',
'	, det_cantdesde cantdesde',
'	, det_canthasta canthasta',
'	, decode(cab_tipoprecio,''FM'',det_preciocal,det_precio) precio',
'	, det_preciocal preciocalculado',
'	, det_comentario comentario',
'	-- , decode(det_estadoflujo,''CREACION'',''PENDIENTE APROBACION'',det_estadoflujo) estadoflujo',
'from vt_comp_negociaciondet d',
'left join vt_comp_negociacionpas p on neg_id = neg_id_act',
'	and det_codproducto = det_codproducto_act',
'	and det_codproveedor = det_codproveedor_act',
'	and det_cantdesde = det_cantdesde_act',
'	and det_canthasta = det_canthasta_act',
'	and nvl(det_tiempoentrega,0) = nvl(det_tiempoentrega_act,0)',
'	and nvl(det_formapago,'' '') = nvl(det_formapago_act,'' '')',
'	and nvl(det_incoterm,'' '') = nvl(det_incoterm_act,'' '')',
'where neg_id = :p112_idneg'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P112_ID_CABECERA,P112_ID_NEGOCIACION'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Detalle'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20250224190455Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(333001706081522356)
,p_max_row_count=>'1000000'
,p_show_search_bar=>'N'
,p_fixed_header=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>333001706081522356
,p_updated_on=>wwv_flow_imp.dz('20250224190455Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(203489058722751117)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(203489440399751118)
,p_db_column_name=>'IDCAB'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Idcab'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(203489832472751118)
,p_db_column_name=>'CODPRODUCTOPRV'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>unistr('C\00F3d. Producto Prov.')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(203490219543751118)
,p_db_column_name=>'DESPRODUCTOPRV'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Des. Producto Prov.'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(203490668637751118)
,p_db_column_name=>'UMPRODUCTOPRV'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'UM'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(203491066550751119)
,p_db_column_name=>'TIEMPOENTREGA'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Tiempo de Entrega'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(203491428645751119)
,p_db_column_name=>'FORMAPAGO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Forma Pago'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(203491891449751119)
,p_db_column_name=>'INCOTERM'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Incoterm'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(203492209523751119)
,p_db_column_name=>'CANTDESDE'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Cant. Desde'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(203492690442751120)
,p_db_column_name=>'CANTHASTA'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Cant. Hasta'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(203493041653751120)
,p_db_column_name=>'PRECIO'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Precio'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(203493481345751120)
,p_db_column_name=>'COMENTARIO'
,p_display_order=>220
,p_column_identifier=>'T'
,p_column_label=>'Comentario'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(203495098059751121)
,p_db_column_name=>'CODIGOPRODUCTO'
,p_display_order=>260
,p_column_identifier=>'Y'
,p_column_label=>'Producto'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(203497448099751123)
,p_db_column_name=>'PRECIOCALCULADO'
,p_display_order=>280
,p_column_identifier=>'AE'
,p_column_label=>'Precio'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(203497884900751123)
,p_db_column_name=>'CODPRODUCTO'
,p_display_order=>290
,p_column_identifier=>'AF'
,p_column_label=>unistr('C\00F3d. Corto')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(335603676131922604)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1321150'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODPRODUCTO:CODIGOPRODUCTO:CODPRODUCTOPRV:DESPRODUCTOPRV:UMPRODUCTOPRV:PRECIOCALCULADO'
,p_sort_column_1=>'CODIGOPRODUCTO'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'CODPROVEEDOR'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'CANTDESDE'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'CANTDESDE'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'P1_ORDEN'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20240522202903Z')
,p_updated_on=>wwv_flow_imp.dz('20250224190455Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(519540792684222804)
,p_plug_name=>'Archivos'
,p_region_name=>'rptSoporte'
,p_parent_plug_id=>wwv_flow_imp.id(300487056840773244)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(295630388916037685)
,p_plug_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select numeroarchivo',
'	, filename',
'	, blobcontent',
'	, mimetype',
'	, ride',
'	, fecha',
'	, nombreusuario',
'	, tabla',
'	, id_tabla',
'	, tipo',
'	, observacion',
'	, estado',
'	, ''<span class="fa fa-trash"/>'' borra     ',
'from files.vt_apex_archivos',
'where tabla = ''T_COMP_NEGOCIACION'' ',
'	and to_number(substr(id_tabla,2,5)) = :p112_idneg',
'	and tipo = ''ARCHIVO_CABECERA'''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Archivos Adjuntos'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_created_on=>wwv_flow_imp.dz('20240522211405Z')
,p_updated_on=>wwv_flow_imp.dz('20240522212403Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(519541018876222806)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'No hay archivos adjuntos.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>519541018876222806
,p_created_on=>wwv_flow_imp.dz('20240522211405Z')
,p_updated_on=>wwv_flow_imp.dz('20240522212403Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(324261898039121438)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Numeroarchivo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240522211405Z')
,p_updated_on=>wwv_flow_imp.dz('20240522211405Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(324262674975121440)
,p_db_column_name=>'BLOBCONTENT'
,p_display_order=>20
,p_column_identifier=>'C'
,p_column_label=>'Archivo'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_format_mask=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment:#FILENAME#:FILES'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240522211405Z')
,p_updated_on=>wwv_flow_imp.dz('20240522211405Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(324263083619121440)
,p_db_column_name=>'MIMETYPE'
,p_display_order=>30
,p_column_identifier=>'D'
,p_column_label=>'Tipo'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240522211405Z')
,p_updated_on=>wwv_flow_imp.dz('20240522211405Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(324263862658121441)
,p_db_column_name=>'FECHA'
,p_display_order=>40
,p_column_identifier=>'F'
,p_column_label=>'Fecha'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy hh24:mi'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240522211405Z')
,p_updated_on=>wwv_flow_imp.dz('20240522211405Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(324264234026121441)
,p_db_column_name=>'NOMBREUSUARIO'
,p_display_order=>50
,p_column_identifier=>'G'
,p_column_label=>'Usuario'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240522211405Z')
,p_updated_on=>wwv_flow_imp.dz('20240522211405Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(324262237298121440)
,p_db_column_name=>'FILENAME'
,p_display_order=>60
,p_column_identifier=>'B'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240522211405Z')
,p_updated_on=>wwv_flow_imp.dz('20240522211405Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(324264622190121441)
,p_db_column_name=>'TABLA'
,p_display_order=>70
,p_column_identifier=>'H'
,p_column_label=>'Tabla'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240522211405Z')
,p_updated_on=>wwv_flow_imp.dz('20240522211405Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(324265025250121441)
,p_db_column_name=>'ID_TABLA'
,p_display_order=>80
,p_column_identifier=>'I'
,p_column_label=>'Id Tabla'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240522211405Z')
,p_updated_on=>wwv_flow_imp.dz('20240522211405Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(324265464392121442)
,p_db_column_name=>'TIPO'
,p_display_order=>90
,p_column_identifier=>'J'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240522211405Z')
,p_updated_on=>wwv_flow_imp.dz('20240522211405Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(324266286487121442)
,p_db_column_name=>'ESTADO'
,p_display_order=>100
,p_column_identifier=>'L'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240522211405Z')
,p_updated_on=>wwv_flow_imp.dz('20240522211405Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(324265837118121442)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'Observacion'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240522211405Z')
,p_updated_on=>wwv_flow_imp.dz('20240522211405Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(324263460013121441)
,p_db_column_name=>'RIDE'
,p_display_order=>130
,p_column_identifier=>'E'
,p_column_label=>'Ride'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240522211405Z')
,p_updated_on=>wwv_flow_imp.dz('20240522211405Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(324266655777121443)
,p_db_column_name=>'BORRA'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>'-'
,p_column_link=>'javascript: $s("P140_ID_NUMEROARCHIVO","");$s("P140_ID_NUMEROARCHIVO",#NUMEROARCHIVO#);'
,p_column_linktext=>'#BORRA#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P112_ES_EDICION = 1'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240522211405Z')
,p_updated_on=>wwv_flow_imp.dz('20240522211405Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(519843368887010849)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'450533'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BLOBCONTENT:FECHA:NOMBREUSUARIO:BORRA:'
,p_created_on=>wwv_flow_imp.dz('20240522211405Z')
,p_updated_on=>wwv_flow_imp.dz('20240522211405Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(409915675110757967)
,p_plug_name=>'Pago Recurrente'
,p_region_name=>'regInformacion'
,p_region_template_options=>'#DEFAULT#:t-Form--noPadding:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>40
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_plug_display_when_condition=>'P112_IDNEG'
,p_plug_display_when_cond2=>'0'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(456571153850640318)
,p_plug_name=>'Barra de Acciones'
,p_region_name=>'regBarra'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_plug_display_when_condition=>'P112_IDNEG'
,p_plug_display_when_cond2=>'0'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(456576818361643008)
,p_plug_name=>'Items'
,p_region_name=>'regItems'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info'
,p_plug_template=>wwv_flow_imp.id(295605160997037667)
,p_plug_display_sequence=>80
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20240918185126Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(203556605196136109)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(209425935859645868)
,p_button_name=>'APROBAR'
,p_button_static_id=>'btnAprobar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Aprobar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:102:&SESSION.::&DEBUG.:RP,:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID:&G_COMPANIA.,&APP_MODULO.,&P112_USUARIO.,&P112_OBJETO.,&P112_IDNEG.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(203557050849136110)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(209425935859645868)
,p_button_name=>'RECHAZAR'
,p_button_static_id=>'btnRechazar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Rechazar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:103:&SESSION.::&DEBUG.:RP,:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID:&G_COMPANIA.,&APP_MODULO.,&P112_USUARIO.,&P112_OBJETO.,&P112_IDNEG.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(322649748674654820)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(456571153850640318)
,p_button_name=>'Atras'
,p_button_static_id=>'btnAtras'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Atras'
,p_button_position=>'TOP'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::'
,p_button_condition=>'P112_ORIGEN'
,p_button_condition2=>'MESA'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(203241113338171002)
,p_name=>'P112_ORIGEN'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(456576818361643008)
,p_prompt=>'Origen'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(203241387485171004)
,p_name=>'P112_PROVEEDOR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(409915675110757967)
,p_prompt=>'Proveedor:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(203241433495171005)
,p_name=>'P112_COMPRADOR'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(409915675110757967)
,p_prompt=>'Comprador:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(203241665961171007)
,p_name=>'P112_DIRECCIONENVIO'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(409915675110757967)
,p_prompt=>unistr('Dir. Env\00EDo')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(203241776140171008)
,p_name=>'P112_UNIDADNEGOCIOGASTO'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(409915675110757967)
,p_prompt=>'UN Gasto'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(203242075029171011)
,p_name=>'P112_EXITO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(456576818361643008)
,p_prompt=>unistr('\00C9xito')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(203242140515171012)
,p_name=>'P112_TERMINA'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(456576818361643008)
,p_prompt=>'Termina'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(203242332014171014)
,p_name=>'P112_USUARIO'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(456576818361643008)
,p_prompt=>'Origen'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(203485529602747025)
,p_name=>'P112_TIPOMONTO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(409915675110757967)
,p_prompt=>'Tipo Monto:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(203485964060747026)
,p_name=>'P112_NUMEROPAGOS'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(409915675110757967)
,p_prompt=>unistr('N\00FAm. Pagos:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(203486379555747026)
,p_name=>'P112_FECHAPRIMERPAGO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(409915675110757967)
,p_prompt=>'Fecha Primer Pago:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20240522211304Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(203486757710747026)
,p_name=>'P112_TIPOPAGO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(409915675110757967)
,p_prompt=>'Tipo Pago:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(203487162090747027)
,p_name=>'P112_TIPORECEPCION'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(409915675110757967)
,p_prompt=>unistr('Tipo Recepci\00F3n:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(203487538854747027)
,p_name=>'P112_COSTO'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(409915675110757967)
,p_prompt=>'Costo Total:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when=>'P112_TIPOMONTO'
,p_display_when2=>'FIJO'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(203487979652747028)
,p_name=>'P112_FRECUENCIA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(409915675110757967)
,p_prompt=>'Frecuencia:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(203488352847747028)
,p_name=>'P112_REQUISITOR'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(409915675110757967)
,p_prompt=>'Requisitor:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(203624951125739501)
,p_name=>'P112_OBJETO'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(456576818361643008)
,p_prompt=>'Objeto'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(300485471626773228)
,p_name=>'P112_FLJTOKEN'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(456576818361643008)
,p_prompt=>'Token'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(300485559342773229)
,p_name=>'P112_FLJDETALLE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(456576818361643008)
,p_prompt=>'Detalle'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(322655155958657509)
,p_name=>'P112_IDNEG'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(456576818361643008)
,p_prompt=>'ID Neg'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(322659589751657514)
,p_name=>'P112_ES_APROBADOR'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(456576818361643008)
,p_prompt=>'Es Aprobador'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(322660744241657515)
,p_name=>'P112_APROBADOR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(456576818361643008)
,p_prompt=>'Aprobador'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(322665964191657518)
,p_name=>'P112_ESTADO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(456576818361643008)
,p_prompt=>'Estado'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(330855145273165838)
,p_name=>'P112_OBSERVACION'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(409915675110757967)
,p_prompt=>unistr('Observaci\00F3n')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20240628191300Z')
,p_updated_on=>wwv_flow_imp.dz('20240628191443Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(330855246131165839)
,p_name=>'P112_COMENTARIO'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(409915675110757967)
,p_prompt=>'Comentario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20240628191300Z')
,p_updated_on=>wwv_flow_imp.dz('20240628191444Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(203241840607171009)
,p_name=>unistr('Cierre di\00E1logo: Aprobar')
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(203556605196136109)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_updated_on=>wwv_flow_imp.dz('20240918201114Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(203241954027171010)
,p_event_id=>wwv_flow_imp.id(203241840607171009)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'console.log(trama);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'',
'mostrarBarra();',
'',
'apex.item("P112_EXITO").setValue(0);',
'',
'if(this.data.G_EXITO==''true''){',
'	apex.item("P112_EXITO").setValue(1);',
'',
'	if(isTerminoFlujo){',
'		mensaje(''exito'', this.data.G_MENSAJE+''. '' + ''<br />Termina el flujo.'' );',
'		apex.item("P112_TERMINA").setValue(1);',
'	}else{',
'		mensaje(''exito'', this.data.G_MENSAJE);',
'	}',
'}else{',
'	mensaje(''error'',this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(203242240544171013)
,p_event_id=>wwv_flow_imp.id(203241840607171009)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_exito		number;',
'v_idneg		number;',
'v_termina	number;',
'v_usuario	varchar(250);',
'v_respuesta	varchar(999);',
'v_log_app	varchar(100);',
'v_log_dsc	varchar(999);',
'begin',
'    v_log_app	:= ''apex.130.112.aprobar'';',
'	v_usuario	:= :p112_usuario;',
'	v_exito		:= :p112_exito;',
'	v_termina	:= nvl(:p112_termina,0);',
'	v_idneg		:= :p112_idneg;',
'',
'	v_log_dsc	:= ''Valores: v_usuario: ''||v_usuario||'', v_idneg: ''||v_idneg||'', v_exito: ''||v_exito||'', v_termina: ''||v_termina;',
'',
'	pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,null,null,null);',
'',
'	if v_exito = 1 and v_termina = 1 then',
'		pk_comp_negociacion.sp_aprobacionpagorecurrente(:g_compania,v_usuario,v_idneg,''APROBAR'',v_respuesta);',
'		pk_commons.sp_apex_log(v_log_app,1,v_log_dsc,v_respuesta,null,null);',
'	end if;',
'end;'))
,p_attribute_02=>'P112_IDNEG,P112_USUARIO,P112_EXITO,P112_TERMINA'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240918201114Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(203242416121171015)
,p_event_id=>wwv_flow_imp.id(203241840607171009)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if(this.data.G_EXITO==''true''){',
'	$(''#btnAprobar'').hide();',
'	$(''#btnRechazar'').hide();',
'	$(''#btnAtras'').trigger("click");',
'}',
'ocultarBarra();'))
,p_updated_on=>wwv_flow_imp.dz('20240918185436Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(203242522218171016)
,p_name=>unistr('Cierre di\00E1logo: Rechazar')
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(203557050849136110)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
,p_updated_on=>wwv_flow_imp.dz('20240711160251Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(203242677965171017)
,p_event_id=>wwv_flow_imp.id(203242522218171016)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'mostrarBarra();',
'apex.item("P112_EXITO").setValue(0);',
'if(this.data.G_EXITO==''true''){',
'	apex.item("P112_EXITO").setValue(1);',
'	mensaje(''exito'', this.data.G_MENSAJE);',
'	if(isTerminoFlujo){',
'		apex.item("P112_TERMINA").setValue(1);',
'	}',
'}else{',
'	mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(203242773530171018)
,p_event_id=>wwv_flow_imp.id(203242522218171016)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_exito		number;',
'v_idneg		number;',
'v_termina	number;',
'v_usuario	varchar(250);',
'v_respuesta	varchar(999);',
'v_log_app	varchar(100);',
'v_log_dsc	varchar(999);',
'begin',
'    v_log_app	:= ''apex.130.112.rechazar'';',
'	v_usuario	:= :p112_usuario;',
'	v_exito		:= :p112_exito;',
'	v_termina	:= nvl(:p112_termina,0);',
'	v_idneg		:= :p112_idneg;',
'',
'	v_log_dsc	:= ''Valores: v_usuario: ''||v_usuario||'', v_idneg: ''||v_idneg||'', v_exito: ''||v_exito||'', v_termina: ''||v_termina;',
'',
'	pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,null,null,null);',
'',
'	if v_exito = 1 then',
'		pk_comp_negociacion.sp_aprobacionpagorecurrente(:g_compania,v_usuario,v_idneg,''RECHAZAR'',v_respuesta);',
'		pk_commons.sp_apex_log(v_log_app,1,v_log_dsc,v_respuesta,null,null);',
'	end if;',
'end;'))
,p_attribute_02=>'P112_IDNEG,P112_USUARIO,P112_EXITO,P112_TERMINA'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240711160251Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(203242837776171019)
,p_event_id=>wwv_flow_imp.id(203242522218171016)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if(this.data.G_EXITO==''true''){',
'	$(''#btnAprobar'').hide();',
'	$(''#btnRechazar'').hide();',
'	$(''#btnAtras'').trigger("click");',
'}',
'ocultarBarra();'))
,p_updated_on=>wwv_flow_imp.dz('20240522213639Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(203241205712171003)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetUp'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_origen 		varchar2(10);',
'v_idneg			number;',
'v_detalle		number;',
'v_token			number;',
'v_esaprobador	number;',
'v_estado		varchar2(99);',
'v_aprobador		varchar2(99);',
'v_usuario		varchar2(99);',
'v_objeto		varchar2(99);',
'v_mensaje		varchar2(3999);',
'v_compania		varchar2(5);',
'v_modulo		varchar2(9);',
'begin',
'	v_origen		:= nvl(:p112_origen,''API'');',
'	v_esaprobador	:= 0;',
'	v_modulo		:= :app_modulo;',
'',
'	if v_origen = ''MESA'' then',
'		v_idneg		:= :p112_idneg;',
'		v_usuario	:= :app_user;',
'		v_objeto	:= ''PAGORECURRENTE'';',
'		v_compania	:= :g_compania;',
'',
'		select aprobador into v_aprobador from vt_comp_mesatrabajopgr where idneg = v_idneg;',
'	else',
'		v_detalle	:= :g_detalle_id;',
'		v_token		:= :g_token;',
'',
'		pk_corp_flujoaprobacion.sp_buscaraprobacion(v_detalle,v_token,v_compania,v_aprobador,v_objeto,v_idneg);',
'		v_usuario := v_aprobador;',
'	end if;',
'',
'	if v_usuario = v_aprobador then',
'		v_esaprobador := 1;',
'	end if;',
'',
'	begin',
'		:p112_usuario		:= v_usuario;',
'		:p112_aprobador		:= v_aprobador;',
'		:p112_es_aprobador	:= v_esaprobador;',
'		:p112_fljtoken		:= v_token;',
'		:p112_fljdetalle	:= v_detalle;',
'		:p112_idneg			:= v_idneg;',
'		:p112_objeto		:= v_objeto;',
'		:p112_origen		:= v_origen;',
'		:g_compania			:= v_compania;',
'	end;',
'',
'	begin',
'		select codproveedor||'' - ''||proveedor proveedor',
'			, tipomonto',
'			, frecuencia',
'			, numeropagos',
'			, fechaprimerpago',
'			, tipopago',
'			, tiporecepcion',
'			, to_char(costotal,''FML999G999G999G999G990D00'')',
'			, unidadnegociogasto',
'			, direccionenvio',
'			, requisitor',
'			, comprador',
'			, observacion',
'			, comentario',
'		into :p112_proveedor',
'			, :p112_tipomonto',
'			, :p112_frecuencia',
'			, :p112_numeropagos',
'			, :p112_fechaprimerpago',
'			, :p112_tipopago',
'			, :p112_tiporecepcion',
'			, :p112_costo',
'			, :p112_unidadnegociogasto',
'			, :p112_direccionenvio',
'			, :p112_requisitor',
'			, :p112_comprador',
'			, :p112_observacion',
'			, :p112_comentario',
'		from vt_comp_mesatrabajopgr where idneg = v_idneg;',
'',
'		exception when others then :p112_idneg := 0;',
'	end;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>203241205712171003
,p_updated_on=>wwv_flow_imp.dz('20240628191405Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
