prompt --application/pages/page_00207
begin
--   Manifest
--     PAGE: 00207
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>207
,p_name=>'dlgCambiaFecha'
,p_alias=>'DLGCAMBIAFECHA'
,p_page_mode=>'MODAL'
,p_step_title=>'Cambia Fecha'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_created_on=>wwv_flow_imp.dz('20231206170811Z')
,p_last_updated_on=>wwv_flow_imp.dz('20231109160047Z')
,p_last_updated_by=>'DCUEVA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(124269948778950529)
,p_plug_name=>'Formulario'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(124269451016950524)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(124269948778950529)
,p_button_name=>'GRABAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Grabar'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-save'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(124268565896950515)
,p_name=>'P207_FECHA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(124269948778950529)
,p_prompt=>'Fecha'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'ITEM'
,p_attribute_05=>'P207_MINIMUM_DATE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(124268607395950516)
,p_name=>'P207_MINIMUM_DATE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(124269948778950529)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(124268970591950519)
,p_name=>'P207_DOCUMENTOTIPO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(124269948778950529)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(124269011450950520)
,p_name=>'P207_DOCUMENTO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(124269948778950529)
,p_prompt=>'Documento'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(124269143289950521)
,p_name=>'P207_UDC'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(124269948778950529)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(124269272559950522)
,p_name=>'P207_LABEL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(124269948778950529)
,p_prompt=>'Nombre'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(124269684793950526)
,p_name=>'Grabar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(124269451016950524)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(124269788436950527)
,p_event_id=>wwv_flow_imp.id(124269684793950526)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'SP_FECHA_CAMBIA'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_COMP_GESTIONCOMPRAS.SP_FECHA_CAMBIA(',
'    :P207_DOCUMENTOTIPO,',
'    :P207_DOCUMENTO,',
'    :P207_UDC,',
'    PK_COMMONS.F_G2JDE( :P207_FECHA ),',
'    :G_COMPANIA',
');'))
,p_attribute_02=>'P207_FECHA'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(124269893264950528)
,p_event_id=>wwv_flow_imp.id(124269684793950526)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(124525271797607633)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Minimum Date'
,p_process_sql_clob=>':P207_MINIMUM_DATE := TO_CHAR(TRUNC(SYSDATE+1), ''DD-MM-RRRR'');'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>124525271797607633
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(125101092776353303)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    PK_COMMONS.F_JDE2G(PLISSU), PLDL01 ',
'INTO ',
'    :P207_FECHA, :P207_LABEL',
'FROM F4305@jdedtadl ',
'WHERE',
'    PLDCTO = :P207_DOCUMENTOTIPO',
'        AND ',
'    PLDOCO = :P207_DOCUMENTO',
'        AND ',
'    PLLGTY = :P207_UDC',
'        AND ',
'    PLKCOO = :G_COMPANIA;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>125101092776353303
);
wwv_flow_imp.component_end;
end;
/
