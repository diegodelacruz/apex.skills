prompt --application/pages/page_00203
begin
--   Manifest
--     PAGE: 00203
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>203
,p_name=>'dlgSeleccionaProveedor'
,p_alias=>'DLGSELECCIONAPROVEEDOR'
,p_page_mode=>'MODAL'
,p_step_title=>'Seleccionar Proveedor'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-table {',
'     min-width: 1500px;',
'}',
'.a-IRR-table td {',
'    padding: 0px;',
'    padding-right: 2px;',
'    padding-left: 2px;    ',
'}',
'.t-Form-inputContainer, .t-Form-labelContainer {',
'    padding: 0px;',
'    padding-left: 10px;',
'}'))
,p_page_template_options=>'ui-dialog--stretch'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240227194122Z')
,p_last_updated_on=>wwv_flow_imp.dz('20251114200456Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(87921322736756306)
,p_plug_name=>'Negociaciones'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>130
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'	neg_id',
'	, cab_id',
'	, det_id',
'	, neg_tipo',
'	, neg_esquema',
'	, neg_codesquema',
'	, neg_recurrente',
'	, neg_periodicidad',
'	, det_vigente vigente',
'	, neg_estadoflujo',
'	, cab_escala',
'	, cab_acumula',
'	, cab_tipoprecio',
'	, cab_formula',
'	, det_codproducto',
'	, det_codproveedor',
'	, det_codproveedor det_codproveedor_select',
'	, det_tiempoentrega',
'	, det_formapago',
'	, det_incoterm',
'	, det_cantdesde',
'	, det_canthasta',
'	, det_precio',
'	, det_codproductoprv || '' - '' || det_desproductoprv || '' - '' || det_umproductoprv as prod_proveedor',
'	, case',
'		when det_precio = 0 then',
unistr('			''<span title="Precio no v\00E1lido" class="fa fa-times-circle" style="color: #D9534F;"></span>'''),
'		when neg_tipo = ''FJ'' then',
'			''<span title="Seleccionar Proveedor (Fijo)" class="fa fa-check-circle" style="color: #00a65a;"></span>''',
'		when neg_tipo = ''ES'' then',
'			case',
'				when :p203_cantidad between det_cantdesde and det_canthasta then',
'					''<span title="Seleccionar Proveedor (Escala)" class="fa fa-check-circle" style="color: #27a2d4;"></span>''',
'			else',
'				''<span title="Fuera de escala" class="fa fa-times-circle" style="color: #D9534F;"></span>''',
'			end',
'		else '''' end as icono_seleccionar',
'/*',
'	, case',
'		when det_precio		= 0		then ''<span title="Seleccionar ESTE Proveedor" class="fa fa-times-circle" style="color: red;"/>''',
'		when neg_tipo		= ''FJ''	then ''<span title="Seleccionar ESTE Proveedor" class="fa fa-hand-o-right" style="color: darkgreen;"/>''',
'			when neg_tipo	= ''ES''	then',
'				case',
'					when :p203_cantidad between det_cantdesde and det_canthasta then ''<span title="Seleccionar ESTE Proveedor" class="fa fa-hand-o-right" style="color: darkblue;"/>''',
'					else ''<span title="Fuera de escala" class="fa fa-times-circle" style="color: red;"/>''',
'				end',
'		else '''' end as icono_seleccionar',
'*/',
'	, case',
'		when det_precio = 0 then ''style="color: #D9534F;"'' -- Error',
unistr('		when neg_tipo = ''FJ'' then ''style="color: #00a65a;"'' -- \00C9xito/Fijo'),
'		when neg_tipo = ''ES'' then',
'		case ',
'			when :p203_cantidad between det_cantdesde and det_canthasta then ''style="color: #27a2d4;"'' -- Info/Escala',
'			else ''style="color: #F0AD4E;"'' -- Advertencia (Fuera de escala)',
'			end',
'		else '''' end as color_precio',
'/*',
'	, case',
'		when det_precio	= 0		then ''style="color: red;"''',
'		when neg_tipo	= ''FJ''	then ''style="color: green;"''',
'		when neg_tipo	= ''ES'' 	then',
'			case ',
'				when :p203_cantidad between det_cantdesde and det_canthasta then ''style="color: blue;"''',
'				else ''style="color: orange;"''',
'			end',
'		else '''' end as color_precio',
'*/',
'	, case',
'		when det_precio = 0 then '''' -- No hacer nada (Error)',
'		when neg_tipo = ''FJ'' then ''JavaScript:$s("P203_DET_ID_SELECCIONADO", "");$s("P203_DET_ID_SELECCIONADO",''||det_id||'');''',
'		when neg_tipo = ''FM'' then ''JavaScript:$s("P203_DET_ID_SELECCIONADO", "");$s("P203_DET_ID_SELECCIONADO",''||det_id||'');''',
'		when neg_tipo = ''ES'' then',
'		case',
'			when :p203_cantidad between det_cantdesde and det_canthasta then ''JavaScript:$s("P203_DET_ID_SELECCIONADO","");$s("P203_DET_ID_SELECCIONADO",''||det_id||'');''',
'			else '''' -- No hacer nada (Fuera de escala)',
'			end',
'		else '''' end as accion_javascript',
'/*',
'	, case',
unistr('		when det_precio		= 0   	then ''JavaScript:alert("Revisar los \00EDndices o f\00F3rmulas de las negociacaciones.");'''),
'		when neg_tipo		= ''FJ''	then ''JavaScript:$s("P203_DET_ID_SELECCIONADO", "");$s("P203_DET_ID_SELECCIONADO",''||det_id||'');''',
'		when neg_tipo		= ''FM''	then ''JavaScript:$s("P203_DET_ID_SELECCIONADO", "");$s("P203_DET_ID_SELECCIONADO",''||det_id||'');''',
'		when neg_tipo		= ''ES''	then',
'			case',
'				when :p203_cantidad between det_cantdesde and det_canthasta then ''JavaScript:$s("P203_DET_ID_SELECCIONADO","");$s("P203_DET_ID_SELECCIONADO",''||det_id||'');''',
'				else ''JavaScript:alert("Fuera de escala.");''',
'			end',
'		else '''' end as accion_javascript',
'*/',
'from ',
'	data.vt_comp_negociacionsel',
'where 1 = 1',
'	and det_codproducto = :p203_codigocortoproducto',
'	and det_vigente = ''SI''',
'	and neg_esquemahab = ''SI''',
'	and neg_estadoflujo = ''APROBADO''',
'	and ((:p203_reserva = 1 and det_puedereservar = 1) or :p203_reserva = 0)'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Negociaciones'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SI algunos precios tienen valor ',
unistr('<span style="color: red; font-weight: 900;">CERO ($0.0000) </span>. Entonces revisar los \00EDndices o f\00F3rmulas de las negociacaciones.')))
,p_updated_on=>wwv_flow_imp.dz('20251114200456Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(87921438772756307)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>87921438772756307
,p_updated_on=>wwv_flow_imp.dz('20251114200456Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87925592692756348)
,p_db_column_name=>'ICONO_SELECCIONAR'
,p_display_order=>10
,p_column_identifier=>'AA'
,p_column_label=>'.'
,p_column_link=>'#ACCION_JAVASCRIPT#'
,p_column_linktext=>'#ICONO_SELECCIONAR#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250529180633Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87921575272756308)
,p_db_column_name=>'NEG_ID'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Neg Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87921636056756309)
,p_db_column_name=>'CAB_ID'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Cab Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87921721743756310)
,p_db_column_name=>'DET_ID'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Det Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87921888954756311)
,p_db_column_name=>'NEG_TIPO'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(134249042425086839)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87921966337756312)
,p_db_column_name=>'NEG_ESQUEMA'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Esquema'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(134249283510088347)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87922080410756313)
,p_db_column_name=>'NEG_CODESQUEMA'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'Neg Codesquema'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87922121739756314)
,p_db_column_name=>'NEG_RECURRENTE'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Recurr.'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(134249933350095820)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250529180649Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87922255483756315)
,p_db_column_name=>'NEG_PERIODICIDAD'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'Period.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250529180649Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87922311205756316)
,p_db_column_name=>'VIGENTE'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Vigente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87922423760756317)
,p_db_column_name=>'NEG_ESTADOFLUJO'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87922559585756318)
,p_db_column_name=>'CAB_ESCALA'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'Cab Escala'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87922617857756319)
,p_db_column_name=>'CAB_ACUMULA'
,p_display_order=>130
,p_column_identifier=>'L'
,p_column_label=>'Acum.'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87922775941756320)
,p_db_column_name=>'CAB_TIPOPRECIO'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>'Tipo Precio'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(134248652638070866)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87922882164756321)
,p_db_column_name=>'CAB_FORMULA'
,p_display_order=>150
,p_column_identifier=>'N'
,p_column_label=>'Cab Formula'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87922969960756322)
,p_db_column_name=>'DET_CODPRODUCTO'
,p_display_order=>160
,p_column_identifier=>'O'
,p_column_label=>'Det Codproducto'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87923098973756323)
,p_db_column_name=>'DET_CODPROVEEDOR'
,p_display_order=>170
,p_column_identifier=>'P'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87924082608756333)
,p_db_column_name=>'PROD_PROVEEDOR'
,p_display_order=>180
,p_column_identifier=>'Z'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87923469098756327)
,p_db_column_name=>'DET_TIEMPOENTREGA'
,p_display_order=>190
,p_column_identifier=>'T'
,p_column_label=>'Tiempo Ent.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87923574236756328)
,p_db_column_name=>'DET_FORMAPAGO'
,p_display_order=>200
,p_column_identifier=>'U'
,p_column_label=>'Forma Pago'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(134250431110099274)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87923623856756329)
,p_db_column_name=>'DET_INCOTERM'
,p_display_order=>210
,p_column_identifier=>'V'
,p_column_label=>'INCOTERM'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87923723831756330)
,p_db_column_name=>'DET_CANTDESDE'
,p_display_order=>220
,p_column_identifier=>'W'
,p_column_label=>'Cant. Desde'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87923809389756331)
,p_db_column_name=>'DET_CANTHASTA'
,p_display_order=>230
,p_column_identifier=>'X'
,p_column_label=>'Cant. Hasta'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(87923926061756332)
,p_db_column_name=>'DET_PRECIO'
,p_display_order=>240
,p_column_identifier=>'Y'
,p_column_label=>'Precio'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span #COLOR_PRECIO#>',
'    #DET_PRECIO#',
'</span>'))
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(88453774332246511)
,p_db_column_name=>'DET_CODPROVEEDOR_SELECT'
,p_display_order=>250
,p_column_identifier=>'AB'
,p_column_label=>'Det Codproveedor Select'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91370862414973010)
,p_db_column_name=>'COLOR_PRECIO'
,p_display_order=>260
,p_column_identifier=>'AC'
,p_column_label=>'Color Precio'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(157376363631647201)
,p_db_column_name=>'ACCION_JAVASCRIPT'
,p_display_order=>270
,p_column_identifier=>'AD'
,p_column_label=>'Accion Javascript'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(88368632716058801)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'883687'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ICONO_SELECCIONAR:DET_CODPROVEEDOR:NEG_TIPO:NEG_ESQUEMA:NEG_RECURRENTE:NEG_PERIODICIDAD:CAB_ACUMULA:CAB_TIPOPRECIO:DET_TIEMPOENTREGA:DET_FORMAPAGO:DET_INCOTERM:DET_CANTDESDE:DET_CANTHASTA:DET_PRECIO:PROD_PROVEEDOR:'
,p_sort_column_1=>'DET_PRECIO'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20240227194122Z')
,p_updated_on=>wwv_flow_imp.dz('20250529180742Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(88453214481246506)
,p_plug_name=>'Proveedor Actual'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>120
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P203_PROVEEDOR_ID_PRE_SEL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(173241322996721302)
,p_plug_name=>'Mensaje Reserva'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>140
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span style="color:green;">',
'*Solo se listan negociaciones adecuadas para una compra tipo RESERVA.',
'</span>'))
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P203_RESERVA'
,p_plug_display_when_cond2=>'1'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(88452950030246503)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(88453214481246506)
,p_button_name=>'ELIMINAR_PROVEEDOR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Dejar sin Proveedor'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(141896312423069213)
,p_branch_name=>'SET SALTO'
,p_branch_action=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.::P201_SALTAR_SELECT_PROVEEDOR:1#idSeccionSeguimientos&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(88452950030246503)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(87924246628756335)
,p_name=>'P203_CODIGOCORTOPRODUCTO'
,p_item_sequence=>60
,p_prompt=>unistr('C\00F3d. Prod.')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(87924390331756336)
,p_name=>'P203_CANTIDAD'
,p_item_sequence=>70
,p_prompt=>'Cantidad'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(87925068839756343)
,p_name=>'P203_PRODUCTO'
,p_item_sequence=>90
,p_prompt=>'Producto'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(87925191679756344)
,p_name=>'P203_DESCRIPCION'
,p_item_sequence=>110
,p_prompt=>unistr('Descripci\00F3n')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(87925234637756345)
,p_name=>'P203_UNIDADMEDIDA'
,p_item_sequence=>80
,p_prompt=>'UM'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(88452862621246502)
,p_name=>'P203_PROVEEDOR_ID_PRE_SEL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(88453214481246506)
,p_prompt=>'Proveedor Actual'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_JDE_LIBRODIRECCIONES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DISTINCT nombres as r,',
'       codigo as d',
'  from VT_JDE_LIBRODIRECCIONES',
' order by 1'))
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20250529174934Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(88453634021246510)
,p_name=>'P203_DET_ID_SELECCIONADO'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91370268737973004)
,p_name=>'P203_DET_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91370317555973005)
,p_name=>'P203_PPGESTION_ID'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(173241204000721301)
,p_name=>'P203_RESERVA'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(88453094523246504)
,p_name=>'Eliminar proveedor'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(88452950030246503)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(88453144383246505)
,p_event_id=>wwv_flow_imp.id(88453094523246504)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_COMP_GESTIONCOMPRAS.SP_DEL_PPGESTION_NEGOCIACION(:P203_PPGESTION_ID);',
''))
,p_attribute_02=>'P203_PROVEEDOR_ID_PRE_SEL'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(88453384535246507)
,p_event_id=>wwv_flow_imp.id(88453094523246504)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(88453898761246512)
,p_name=>'ON PROVEEDOR SELECCIONADO'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P203_DET_ID_SELECCIONADO'
,p_condition_element=>'P203_DET_ID_SELECCIONADO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(88454088917246514)
,p_event_id=>wwv_flow_imp.id(88453898761246512)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_COMP_GESTIONCOMPRAS.SP_SET_PPGESTION_NEGOCIACION (',
'    :P203_PPGESTION_ID, ',
'    :P203_DET_ID_SELECCIONADO',
');'))
,p_attribute_02=>'P203_DET_ID_SELECCIONADO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(88453920907246513)
,p_event_id=>wwv_flow_imp.id(88453898761246512)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(87925384795756346)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- DETALLES DE LA PPGESTION',
'SELECT ',
'    PPGESTION.DET_ID,',
'    PPGESTION.CODIGOCORTOPRODUCTO,',
'    NVL(PPGESTION.CANTIDAD_MANUAL, PPGESTION.CANTIDAD),',
'    RESERVA',
'INTO    ',
'    :P203_DET_ID,',
'    :P203_CODIGOCORTOPRODUCTO,',
'    :P203_CANTIDAD,',
'    :P203_RESERVA',
'FROM ',
'    T_COMP_PRODTO_PROVEEDR_GESTION PPGESTION',
'WHERE',
'    PPGESTION.ID = :P203_PPGESTION_ID',
';',
'',
'',
unistr('-- INFORMACI\00D3N DEL PRODUCTO'),
'SELECT',
'    IMDSC1, ',
'    IMLITM||'' - ''||IMDSC1||'' - ''||IMUOM3, ',
'    IMUOM3',
'INTO',
'    :P203_PRODUCTO,',
'    :P203_DESCRIPCION,',
'    :P203_UNIDADMEDIDA    ',
'FROM ',
'    F4101@JDEDTADL           PRODUCTO',
'WHERE ',
'    IMITM=:P203_CODIGOCORTOPRODUCTO',
';    ',
'',
unistr('-- PARA SABER SI ESTA L\00CDNEA TIENE UN PROVEEDOR PRE-SELECCIONADO'),
':P203_PROVEEDOR_ID_PRE_SEL := NULL;',
'IF :P203_DET_ID IS NOT NULL THEN',
'    SELECT ',
'        DET_CODPROVEEDOR',
'    INTO ',
'        :P203_PROVEEDOR_ID_PRE_SEL     ',
'    FROM VT_COMP_NEGOCIACIONsel',
'    WHERE DET_ID = :P203_DET_ID;',
'END IF',
';    ',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>87925384795756346
,p_updated_on=>wwv_flow_imp.dz('20250529192226Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
