prompt --application/pages/page_00127
begin
--   Manifest
--     PAGE: 00127
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>127
,p_name=>'Ver Precio Proveedor Descuento Cantidad'
,p_step_title=>'Ver Precio Proveedor Descuento Cantidad'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230708132654Z')
,p_last_updated_on=>wwv_flow_imp.dz('20220224205234Z')
,p_last_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(137193979091858759)
,p_plug_name=>'Detalle Descuento x Cantidad'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295639738305037692)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(391470875723063134)
,p_plug_name=>'Datos principales'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(391471548011063141)
,p_plug_name=>'Detalle'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120613521169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>'SELECT * FROM T_COMP_PRECIOPROVDESCANT WHERE IDPROCESO=:P127_NUMERO;'
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P127_NUMERO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(391472471845063150)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'No existe detalle'
,p_show_nulls_as=>'-'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'JBALCAZAR'
,p_internal_uid=>391472471845063150
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44288559847784531)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'AI'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44288606548784532)
,p_db_column_name=>'CODIGOPROVEEDOR'
,p_display_order=>20
,p_column_identifier=>'AJ'
,p_column_label=>'Codigoproveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44288764828784533)
,p_db_column_name=>'CODIGOITEM'
,p_display_order=>30
,p_column_identifier=>'AK'
,p_column_label=>'Codigoitem'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44288800704784534)
,p_db_column_name=>'DESDE_CANTIDAD'
,p_display_order=>40
,p_column_identifier=>'AL'
,p_column_label=>'Desde Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44288964882784535)
,p_db_column_name=>'DESCUENTO'
,p_display_order=>50
,p_column_identifier=>'AM'
,p_column_label=>'Descuento'
,p_column_html_expression=>'#DESCUENTO#%'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44289077526784536)
,p_db_column_name=>'VIGENCIADESDE'
,p_display_order=>60
,p_column_identifier=>'AN'
,p_column_label=>'Vigenciadesde'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44289126108784537)
,p_db_column_name=>'VIGENCIAHASTA'
,p_display_order=>70
,p_column_identifier=>'AO'
,p_column_label=>'Vigenciahasta'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44289228796784538)
,p_db_column_name=>'ESTADO'
,p_display_order=>80
,p_column_identifier=>'AP'
,p_column_label=>'Estado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44289330372784539)
,p_db_column_name=>'USUARIO'
,p_display_order=>90
,p_column_identifier=>'AQ'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44289448757784540)
,p_db_column_name=>'FECHAREGISTRO'
,p_display_order=>100
,p_column_identifier=>'AR'
,p_column_label=>'Fecharegistro'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(44289566995784541)
,p_db_column_name=>'IDPROCESO'
,p_display_order=>110
,p_column_identifier=>'AS'
,p_column_label=>'Idproceso'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(391507620923499989)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'443242'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>':APROBADORULTIMO:ID:CODIGOPROVEEDOR:CODIGOITEM:DESDE_CANTIDAD:DESCUENTO:VIGENCIADESDE:VIGENCIAHASTA:USUARIO:FECHAREGISTRO:IDPROCESO'
,p_sum_columns_on_break=>'TOTAL'
,p_created_on=>wwv_flow_imp.dz('20230708132654Z')
,p_updated_on=>wwv_flow_imp.dz('20230708132654Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(391508948893512605)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(391509274968512608)
,p_plug_name=>'Botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121809343169165)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P127_ES_APROBADOR'
,p_plug_display_when_cond2=>'1'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(44324956912947501)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(391508948893512605)
,p_button_name=>'ATRAS'
,p_button_static_id=>'btnAtras'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Atras'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:RP::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(44326478068947504)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(391509274968512608)
,p_button_name=>'APROBAR'
,p_button_static_id=>'btnAprobar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Aprobar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:102:&SESSION.::&DEBUG.:RP:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO,G_MONTO:&G_COMPANIA.,&APP_MODULO.,&P127_USUARIO.,&P127_TIPO.,&P127_NUMERO.,&P127_APROBADOR.,&P127_MONTO.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(44326809087947504)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(391509274968512608)
,p_button_name=>'RECHAZAR'
,p_button_static_id=>'btnRechazar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Rechazar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:103:&SESSION.::&DEBUG.:RP:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO:&G_COMPANIA.,&APP_MODULO.,&P127_USUARIO.,&P127_TIPO.,&P127_NUMERO.,&P127_APROBADOR.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(44325368133947502)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(391508948893512605)
,p_button_name=>'COMENTARIO'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Comentario'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:105:&SESSION.::&DEBUG.:RP:G_OBJETO,G_OBJETO_ID,G_MODULO,G_COMPANIA,G_USUARIO:&P127_TIPO.,&P127_NUMERO.,&APP_MODULO.,&G_COMPANIA.,&P127_USUARIO.'
,p_icon_css_classes=>'fa-comment'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(44325727935947502)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(391508948893512605)
,p_button_name=>'VER_RUTA'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Ver Ruta'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:104:&SESSION.::&DEBUG.:RP:G_OBJETO,G_OBJETO_ID,G_TODO:&P127_TIPO.,&P127_NUMERO.,true'
,p_icon_css_classes=>'fa-road'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44314733827947487)
,p_name=>'P127_CONTRATO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(391470875723063134)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44315166166947493)
,p_name=>'P127_TOKEN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(391470875723063134)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44315595671947493)
,p_name=>'P127_USUARIO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(391470875723063134)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44315939400947493)
,p_name=>'P127_APROBADOR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(391470875723063134)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44316387849947493)
,p_name=>'P127_FLUJO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(391470875723063134)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44316786345947494)
,p_name=>'P127_ES_APROBADOR'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(391470875723063134)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44317176129947494)
,p_name=>'P127_MONTO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(391470875723063134)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44317533944947494)
,p_name=>'P127_TIPO'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(391470875723063134)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44317930256947494)
,p_name=>'P127_NUMERO'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(391470875723063134)
,p_prompt=>'Proceso:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44318387090947494)
,p_name=>'P127_ESTADO'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(391470875723063134)
,p_prompt=>'Estado:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44318766500947494)
,p_name=>'P127_FECHA_ORDEN'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(391470875723063134)
,p_prompt=>'Fecha :'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44319147595947494)
,p_name=>'P127_DESCRIPCION'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(391470875723063134)
,p_prompt=>unistr('Descripci\00F3n:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(44328303140947513)
,p_name=>unistr('Cierre di\00E1logo: aprobar')
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(44326478068947504)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44328809821947513)
,p_event_id=>wwv_flow_imp.id(44328303140947513)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'mostrarBarra();',
'// P127_FLUJO = 0 ERROR , 1 SE APROBO CON EXITO, 2 TERMINO FLUJO',
'apex.item("P127_FLUJO").setValue(0);',
'',
'if(this.data.G_EXITO==''true''){',
'    apex.item("P127_FLUJO").setValue(1);',
'    mensaje(''exito'', this.data.G_MENSAJE);',
'    if(isTerminoFlujo){',
'        apex.item("P127_FLUJO").setValue(2);',
'    }',
'}',
'else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44329367009947515)
,p_event_id=>wwv_flow_imp.id(44328303140947513)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    ',
'IF(:P127_FLUJO =2) THEN -- TERMINO FLUJO',
'',
'    PK_COMP_PRECIOPROVEEDOR.SP_APROBARDESCUENTOPROVEEDOR(',
'    p_numero=>:P127_NUMERO,',
'    P_COMPANIA=>:G_COMPANIA );',
'',
'END IF;'))
,p_attribute_02=>'P127_FLUJO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44329851476947515)
,p_event_id=>wwv_flow_imp.id(44328303140947513)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var token = apex.item("P127_TOKEN").getValue();',
'ocultarBarra();',
'if(this.data.G_EXITO==''true''){',
'    if(token==''0''){',
'        $(''#btnAtras'').trigger("click");',
'    }else{',
'        $(''#btnAprobar'').hide();',
'        $(''#btnRechazar'').hide();',
'    }',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(44330217363947515)
,p_name=>unistr('Cierre di\00E1logo: rechazar')
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(44326809087947504)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44330736917947515)
,p_event_id=>wwv_flow_imp.id(44330217363947515)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'// P127_FLUJO = 0 ERROR , 1 EXITO',
'apex.item( "P127_FLUJO" ).setValue(0);',
'',
'',
'if(this.data.G_EXITO==''true''){',
'    apex.item( "P127_FLUJO" ).setValue(1);',
'}',
'else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44331254662947515)
,p_event_id=>wwv_flow_imp.id(44330217363947515)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF(:P127_FLUJO =1) THEN -- RECHAZO CON EXITO',
'    PK_COMP_PRECIOPROVEEDOR.SP_RECHAZODESCUENTOPROVEEDOR(',
'    p_numero=>:P127_NUMERO,',
'    P_COMPANIA=>:G_COMPANIA );',
'END IF;'))
,p_attribute_02=>'P127_FLUJO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44331737382947515)
,p_event_id=>wwv_flow_imp.id(44330217363947515)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var token = apex.item("P127_TOKEN").getValue();',
'',
'if(this.data.G_EXITO==''true''){',
'    if(token==''0''){',
'        $(''#btnAtras'').trigger("click");',
'    }else{',
'        $(''#btnAprobar'').hide();',
'        $(''#btnRechazar'').hide();',
'    }',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(44332105438947515)
,p_name=>'Seleccion'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.chkF01'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44332607234947516)
,p_event_id=>wwv_flow_imp.id(44332105438947515)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if(document.querySelectorAll(''.chkF01'').length == [].filter.call( document.querySelectorAll(''.chkF01''), function( el ) {return !el.checked}).length){',
'    //NO SELECCION NADA',
'     $(''#btnAprobar'').hide();',
'}else{',
'    //SELECCIONO ALGO',
'     $(''#btnAprobar'').show();',
'}',
'',
'var lineas =""; ',
'document.querySelectorAll(''.chkF01'').forEach(function(seleccion) {',
'    if(!seleccion.checked){',
'        var linea = seleccion.value',
'        if(lineas==""){',
'            lineas = linea;',
'        }else{',
'            lineas = lineas+'',''+linea;',
'        }      ',
'    }',
'    ',
'});',
'apex.item("P127_SINSELECCION").setValue(lineas);',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(44327555161947512)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga de Datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'V_CONTADOR  NUMBER;',
'BEGIN',
'',
'    :P127_USUARIO := :APP_USER;',
'    :P127_TOKEN :=0;',
'    IF(:G_DETALLE_ID IS NOT NULL AND :G_TOKEN IS NOT NULL) THEN --APROBACION CON TOKEN (DESDE LINK DEL CORREO)',
'            PK_CORP_FLUJOAPROBACION.SP_BUSCARAPROBACION(:G_DETALLE_ID, :G_TOKEN, :G_COMPANIA, :P127_APROBADOR, :P127_TIPO, :P127_NUMERO);',
'            :P127_USUARIO := :P127_APROBADOR;',
'            :P127_TOKEN :=1;',
'    END IF;',
'    ',
'    :P127_ES_APROBADOR := PK_CORP_FLUJOAPROBACION.F_APROBADORFLUJO(:P127_USUARIO, :P127_APROBADOR, :APP_MODULO ,:G_COMPANIA);',
'',
'    SELECT  COUNT(1) INTO V_CONTADOR',
'    FROM VT_COMP_MESATRABAJO_PRECIODESC WHERE PROCESO = :P127_NUMERO;',
'    ',
'    IF(V_CONTADOR=0) THEN',
'        RETURN;',
'    END IF;',
'    ',
'    -- CABECERA',
'    SELECT   FECHA_INICIO, ESTADO',
'    INTO   :P127_FECHA_ORDEN, :P127_ESTADO',
'    FROM VT_COMP_MESATRABAJO_PRECIODESC WHERE PROCESO = :P127_NUMERO AND ROWNUM=1;',
'    ',
'    ',
'',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>44327555161947512
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(44327974272947512)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Borrar datos'
,p_attribute_01=>'CLEAR_CACHE_FOR_ITEMS'
,p_attribute_03=>'P127_FLUJO,G_TOKEN,G_DETALLE_ID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>44327974272947512
);
wwv_flow_imp.component_end;
end;
/
