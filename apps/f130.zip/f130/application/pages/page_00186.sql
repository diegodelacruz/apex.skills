prompt --application/pages/page_00186
begin
--   Manifest
--     PAGE: 00186
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>186
,p_name=>'Control Diario Importaciones'
,p_step_title=>'Control Diario Importaciones'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230825163644Z')
,p_last_updated_on=>wwv_flow_imp.dz('20221129164851Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(100242448298731990)
,p_plug_name=>'Control Diario Importaciones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with cnt as(',
'	select id_cmex_mesatrabajo idcab',
'		, listagg(nro_contenedor,'','') within group (order by id_cmex_mesatrabajo) contenedores',
'		, sum(pesobruto) pesobruto',
'		, sum(pesoneto) pesoneto',
'	from data.t_cmex_detallecontenedor group by id_cmex_mesatrabajo',
') select a.id',
'	, upper(a.ordenagente) ordenagente',
'	, a.codigoetapa||'' - ''||c.descripcion etapa',
'	, a.tipooc||'' - ''||a.ordencompra ordencompra',
'	, a.ordencompra numordern',
'	, a.codigoproveedor codproveedor',
'	, b.descripcion proveedor',
'	, nvl(a.cnt20pies,0) cnt20pies',
'	, nvl(a.cnt40pies,0) cnt40pies',
'	, d.pesobruto',
'	, d.pesoneto',
'	, d.contenedores',
'	, a.cargaliberada',
'	, a.fechacas',
'	, a.fechadav',
'	, a.fechaeta',
'	, a.fechaetd',
'	, a.fechacargaliberada fechalib',
'	, decode(a.codigoetapa,''ET9'',null,extract(day from(sysdate - a.fechmodi))) diasetapa',
'	, upper(a.aduana) aduana',
'	, upper(a.distrito) distrito',
'	, upper(a.bodega) bodega',
'from data.t_cmex_mesatrabajo a',
'inner join vt_jde_maestroproveedor b on a.codigoproveedor = b.codigoproveedor',
'inner join t_corp_udc c on a.codigoetapa = c.valor and c.id_cabecera = ''CMEX_ET_IM''',
'left join cnt d on a.id = d.idcab',
'left join t_rcdp_solicitudimportaciones e on a.ordencompra = to_number(e.documentooi)',
'where a.codigomodulo = ''IMP'' and a.ordencompra is not null;'))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(100242516119731990)
,p_name=>'Control Diario Importaciones'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>100242516119731990
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100242965471732006)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100243312395732015)
,p_db_column_name=>'ORDENAGENTE'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Orden Agente'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100243758082732015)
,p_db_column_name=>'ETAPA'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Etapa'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100244236616732015)
,p_db_column_name=>'ORDENCOMPRA'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Orden Compra'
,p_column_link=>'f?p=&APP_ID.:187:&SESSION.::&DEBUG.:RP,187:P187_ORDENCOMPRA:#NUMORDERN#'
,p_column_linktext=>'#ORDENCOMPRA#'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100244611679732015)
,p_db_column_name=>'CODPROVEEDOR'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>unistr('C\00F3d. Proveedor')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100245088698732015)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100245451620732015)
,p_db_column_name=>'CNT20PIES'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'CNT 20'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100245812122732015)
,p_db_column_name=>'CNT40PIES'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'CNT 40'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100246282807732015)
,p_db_column_name=>'PESOBRUTO'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Peso bruto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100246640604732017)
,p_db_column_name=>'PESONETO'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Peso neto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100247079308732017)
,p_db_column_name=>'CONTENEDORES'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Contenedores'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100247444907732017)
,p_db_column_name=>'CARGALIBERADA'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Carga Liberada'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100247864470732018)
,p_db_column_name=>'FECHACAS'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Fecha CAS'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100248281617732018)
,p_db_column_name=>'FECHADAV'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Fecha DAV'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100248632170732018)
,p_db_column_name=>'FECHAETA'
,p_display_order=>15
,p_column_identifier=>'O'
,p_column_label=>'Fecha ETA'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100249053169732018)
,p_db_column_name=>'FECHAETD'
,p_display_order=>16
,p_column_identifier=>'P'
,p_column_label=>'Fecha ETD'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100249448990732020)
,p_db_column_name=>'FECHALIB'
,p_display_order=>17
,p_column_identifier=>'Q'
,p_column_label=>'Fecha Lib.'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100249884216732020)
,p_db_column_name=>'DIASETAPA'
,p_display_order=>18
,p_column_identifier=>'R'
,p_column_label=>unistr('D\00EDas etapa')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100250290291732020)
,p_db_column_name=>'ADUANA'
,p_display_order=>19
,p_column_identifier=>'S'
,p_column_label=>'Aduana'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100250665073732020)
,p_db_column_name=>'DISTRITO'
,p_display_order=>20
,p_column_identifier=>'T'
,p_column_label=>'Distrito'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100251043025732021)
,p_db_column_name=>'BODEGA'
,p_display_order=>21
,p_column_identifier=>'U'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(100266888152812304)
,p_db_column_name=>'NUMORDERN'
,p_display_order=>31
,p_column_identifier=>'V'
,p_column_label=>unistr('N\00FAm. Orden')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(100251419758739826)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1002515'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ORDENAGENTE:ORDENCOMPRA:CODPROVEEDOR:PROVEEDOR:CNT20PIES:CNT40PIES:PESOBRUTO:PESONETO:CARGALIBERADA:FECHACAS:FECHAETA:ADUANA:DISTRITO:BODEGA:CONTENEDORES::NUMORDERN'
,p_sort_column_1=>'ID'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20230825163644Z')
,p_updated_on=>wwv_flow_imp.dz('20230825163644Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
