prompt --application/pages/page_00152
begin
--   Manifest
--     PAGE: 00152
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>152
,p_name=>'COMEX - Contenedor'
,p_page_mode=>'MODAL'
,p_step_title=>'COMEX - Contenedor'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20230708132655Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260812171739Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74060134734884718)
,p_plug_name=>'Parametros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_region_attributes=>'style = "display : none;"'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20230918220357Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74060680892884723)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(74177783857327839)
,p_name=>'Contenedores'
,p_template=>wwv_flow_imp.id(296120613521169165)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       USERCREA,',
'       FECHCREA,',
'       USERMODI,',
'       FECHMODI,',
'       ID_CMEX_MESATRABAJO,',
'       NRO_CONTENEDOR,',
'       TAMANOCONTENEDOR,',
'       PESONETO,',
'       PESOBRUTO,',
'       PRIORITARIO,',
'       ID_DETALLEDATOSEXP,',
'       PREEMBARQUE,',
'       ANTINARCOTICOS,',
'       TRANSPORTISTA,',
'       REPORTEVERIFICADORA,',
'       nvl(PESOTARA,0) PESOTARA,',
'	   nvl(PESOBRUTO,0) + nvl(PESOTARA,0) pesocargable',
'  from T_CMEX_DETALLECONTENEDOR',
' where ID_CMEX_MESATRABAJO = :P152_ID_MESATRABAJO'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P152_ID_MESATRABAJO'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No se encontraron datos.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_report_total_text_format=>'Peso Total'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'descargar'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260812171739Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(64134075009537827)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>71
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260812171552Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(64134108267537828)
,p_query_column_id=>2
,p_column_alias=>'USERCREA'
,p_column_display_sequence=>81
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260812171552Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(64134229896537829)
,p_query_column_id=>3
,p_column_alias=>'FECHCREA'
,p_column_display_sequence=>91
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260812171552Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(64134358804537830)
,p_query_column_id=>4
,p_column_alias=>'USERMODI'
,p_column_display_sequence=>101
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260812171552Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(64134401374537831)
,p_query_column_id=>5
,p_column_alias=>'FECHMODI'
,p_column_display_sequence=>111
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260812171552Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74178576618327864)
,p_query_column_id=>6
,p_column_alias=>'ID_CMEX_MESATRABAJO'
,p_column_display_sequence=>171
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260812171552Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74178173538327862)
,p_query_column_id=>7
,p_column_alias=>'NRO_CONTENEDOR'
,p_column_display_sequence=>1
,p_column_heading=>'Contenedor'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:153:&SESSION.::&DEBUG.:RP,153:P153_ID,P153_MODULO:#ID#,IMP'
,p_column_linktext=>'#NRO_CONTENEDOR#'
,p_column_alignment=>'CENTER'
,p_default_sort_column_sequence=>1
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20230918221126Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74180152364327864)
,p_query_column_id=>8
,p_column_alias=>'TAMANOCONTENEDOR'
,p_column_display_sequence=>11
,p_column_heading=>unistr('Tama\00F1o')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260812171552Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74178932079327864)
,p_query_column_id=>9
,p_column_alias=>'PESONETO'
,p_column_display_sequence=>21
,p_column_heading=>'P. Neto (kg)'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260812171552Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74179345181327864)
,p_query_column_id=>10
,p_column_alias=>'PESOBRUTO'
,p_column_display_sequence=>31
,p_column_heading=>'P. Bruto (kg)'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260812171552Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74179789050327864)
,p_query_column_id=>11
,p_column_alias=>'PRIORITARIO'
,p_column_display_sequence=>61
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260812171552Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(64134565057537832)
,p_query_column_id=>12
,p_column_alias=>'ID_DETALLEDATOSEXP'
,p_column_display_sequence=>121
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260812171552Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(64134648239537833)
,p_query_column_id=>13
,p_column_alias=>'PREEMBARQUE'
,p_column_display_sequence=>131
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260812171552Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(64134700628537834)
,p_query_column_id=>14
,p_column_alias=>'ANTINARCOTICOS'
,p_column_display_sequence=>141
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260812171552Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(64134800092537835)
,p_query_column_id=>15
,p_column_alias=>'TRANSPORTISTA'
,p_column_display_sequence=>151
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260812171552Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(64134941633537836)
,p_query_column_id=>16
,p_column_alias=>'REPORTEVERIFICADORA'
,p_column_display_sequence=>161
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260812171552Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(572622795715644702)
,p_query_column_id=>17
,p_column_alias=>'PESOTARA'
,p_column_display_sequence=>41
,p_column_heading=>'P. Tara (kg)'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260812171704Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(572622823967644703)
,p_query_column_id=>18
,p_column_alias=>'PESOCARGABLE'
,p_column_display_sequence=>51
,p_column_heading=>'P. Cargable (kg)'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260812171704Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74060783489884724)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(74060680892884723)
,p_button_name=>'AGREGAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Agregar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:153:&SESSION.::&DEBUG.:RP,153:P153_ID_CMEX_MESATRABAJO,P153_MODULO:&P152_ID_MESATRABAJO.,IMP'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'res NUMBER;',
'total NUMBER;',
'BEGIN',
'',
'    SELECT COUNT(ID_CMEX_MESATRABAJO) INTO res ',
'    FROM t_cmex_detallecontenedor',
'    WHERE ID_CMEX_MESATRABAJO = :P152_ID_MESATRABAJO;',
'',
'    SELECT NVL(CNT20PIES,0)+ NVL(CNT40PIES, 0) INTO total ',
'    FROM T_CMEX_MESATRABAJO ',
'    WHERE ID = :P152_ID_MESATRABAJO;',
'',
'IF res < total THEN',
'    RETURN TRUE;',
'END IF ;',
'',
'',
'RETURN FALSE;',
'END;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74060823892884725)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(74060680892884723)
,p_button_name=>'REGRESAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:151:&SESSION.::&DEBUG.:RP,151:P151_ID:&P152_ID_MESATRABAJO.'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74060266036884719)
,p_name=>'P152_ID_MESATRABAJO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(74060134734884718)
,p_prompt=>'Id Mesatrabajo'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp.component_end;
end;
/
