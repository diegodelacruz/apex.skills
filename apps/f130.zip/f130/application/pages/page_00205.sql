prompt --application/pages/page_00205
begin
--   Manifest
--     PAGE: 00205
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>205
,p_name=>'dlgSeleccionaProductoSinReq'
,p_alias=>'DLGSELECCIONAPRODUCTOSINREQ'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Comprar sin Requisici\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_created_on=>wwv_flow_imp.dz('20240910212017Z')
,p_last_updated_on=>wwv_flow_imp.dz('20241111194142Z')
,p_last_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(91373097456973032)
,p_plug_name=>'Formulario'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20241105212613Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(91373349185973035)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(91373097456973032)
,p_button_name=>'GRABAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Grabar'
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91373119635973033)
,p_name=>'P205_PRODUCTO'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(91373097456973032)
,p_prompt=>'Producto'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''''||TRIM(CODIGOPRODUCTO)||'' - '' ||TRIM(nombreproducto)||'' - '' ||TRIM(CODIGOALTERNO)  d, codigocorto r ',
'from vt_jde_productos',
'where  trim(nombreproducto) is not null AND CODIGOPRODUCTO <>''?''',
'order by nombreproducto'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91373212718973034)
,p_name=>'P205_CANTIDAD'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(91373097456973032)
,p_prompt=>'Cantidad'
,p_source=>'select (1/10000) from dual'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'0'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_updated_on=>wwv_flow_imp.dz('20241111194142Z')
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(113730901776020313)
,p_name=>'P205_TIPO_REQ'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(91373097456973032)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    TRIM(DRKY)||'' ''||TRIM(DRDL01) AS LABEL,',
'    TRIM(DRKY)   AS VALUE',
'FROM vt_jde_udcjde where DRSY=''00'' AND DRRT =''DT'' AND DRKY IN(''H1'',''H2'',''H3'')',
'ORDER BY DRKY;'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(113731242798020316)
,p_name=>'P205_BODEGA'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(91373097456973032)
,p_prompt=>'Bodega'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'    mcdc  descripcion,',
'	mcmcu codunidad',
'from f0006@jdedtadl where mcstyl = ''BP''',
'order by descripcion',
' ;',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(91373510139973037)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Grabar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    V_ID   NUMBER;',
'BEGIN',
'    PK_COMP_GESTIONCOMPRAS.SP_AGREGAR_SIN_REQUISICION(',
'        :P205_TIPO_REQ,',
'        :P205_PRODUCTO,',
'        :P205_BODEGA,',
'        :P205_CANTIDAD,',
'        0,',
'        :APP_USER,',
'        :G_COMPANIA,',
'',
'        V_ID',
'    );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(91373349185973035)
,p_internal_uid=>91373510139973037
,p_process_comment=>unistr('Debe previamente haber seleccionar un tipo de requisici\00F3n en la b\00FAsqueda de requisiciones.')
,p_updated_on=>wwv_flow_imp.dz('20241111193927Z')
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(91373468294973036)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(91373349185973035)
,p_process_when=>'P205_PRODUCTO'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>91373468294973036
);
wwv_flow_imp.component_end;
end;
/
