prompt --application/pages/page_00167
begin
--   Manifest
--     PAGE: 00167
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>167
,p_name=>unistr('COMEX - C\00E1lculo y Pago ISD')
,p_step_title=>unistr('COMEX - C\00E1lculo y Pago ISD')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230708132657Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260409205456Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79245170598195236)
,p_plug_name=>unistr('Listado de Ordenes Importaci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120613521169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT mesa.ORDENCOMPRA, mesa.TIPOOC, mesa.TIPOOC || ''-'' || mesa.ORDENCOMPRA as ORDEN,  mesa.CODIGOPROVEEDOR, mesa.ID ',
'from DATA.T_CMEX_MESATRABAJO mesa',
'LEFT JOIN DATA.T_CMEX_CALCULOYPAGOISD isd',
'on mesa.ID = isd.ID_CMEX_MESATRABAJO',
'WHERE mesa.CODIGOETAPA = ''ET6''',
'--and mesa.ID IN (SELECT ID_CMEX_MESATRABAJO FROM DATA.T_CMEX_PROVISION WHERE ESTADO = ''PROCESADO'' AND ID_BATCH IS NOT NULL AND TIPOREGISTRO = ''PROVISION'')'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(79245237304195237)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:168:&SESSION.::&DEBUG.:RP,168:P168_ID_CMEX_MESATRABAJO,P168_ORDENCOMPRA:#ID#,#ORDENCOMPRA#'
,p_detail_link_text=>'<span aria-hidden="true" class="fa fa-layers" ></span>'
,p_detail_link_attr=>'title="Abrir"'
,p_owner=>'NETBY3'
,p_internal_uid=>79245237304195237
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79245366352195238)
,p_db_column_name=>'ORDENCOMPRA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Orden Compra'
,p_column_link=>'f?p=&APP_ID.:168:&SESSION.::&DEBUG.:RP,168:P168_ID_CMEX_MESATRABAJO,P168_ORDENCOMPRA:#ID#,#ORDENCOMPRA#'
,p_column_linktext=>'#ORDENCOMPRA#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79245400944195239)
,p_db_column_name=>'TIPOOC'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo OC'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79245586954195240)
,p_db_column_name=>'CODIGOPROVEEDOR'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79245696465195241)
,p_db_column_name=>'ID'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(80462794467347019)
,p_db_column_name=>'ORDEN'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Orden'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(79413853752077254)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'794139'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ORDEN:CODIGOPROVEEDOR:'
,p_created_on=>wwv_flow_imp.dz('20230708132657Z')
,p_updated_on=>wwv_flow_imp.dz('20230708132657Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79245847331195243)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
