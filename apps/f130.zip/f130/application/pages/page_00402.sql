prompt --application/pages/page_00402
begin
--   Manifest
--     PAGE: 00402
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>402
,p_name=>'Reporte - Detalle OCs GZML'
,p_alias=>'REPORTE-DETALLE-OCS-GZML'
,p_step_title=>'Detalle OCs GZML'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(316585522945694029)
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(regOcultos).hide();',
'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_last_updated_on=>wwv_flow_imp.dz('20260803185048Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(316631765603112924)
,p_plug_name=>'Reporte'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with sts as (',
'	select idcab, estado, min(fechcrea) ini, max(fechcrea) fin from data.t_comp_ordencompraextlog group by idcab, estado',
')',
'select a.idcab',
'	, a.estado',
'	, a.usercrea',
'	, a.fechcrea',
'	, a.companiades',
'	, c.descripcion companiadestino',
'	, a.codcatcompra',
'	, a.catcompra',
'	, a.codsctgcompra',
'	, a.sctgcompra',
'	, a.codproveedor',
'	, a.descproveedor',
'	, a.moneda',
'	, a.fechaplan',
'	, a.estadopago',
'	, a.observacion',
'	, a.cantitems',
'	, a.totaloc',
'	, a.usuarioiniciador',
'	, a.recurrente',
unistr('	, data.pk_comp_gestionocgrupozm.f_tiempoestado(a.idcab,''GESTI\00D3N'') tmp_gestion'),
'	, data.pk_comp_gestionocgrupozm.f_tiempoestado(a.idcab,''EN RUTA'') tmp_ruta',
'	, ing.ini ini_ing',
'	, ing.fin fin_ing',
'	, ges.ini ini_ges',
'	, ges.fin fin_ges',
'	, rta.ini ini_rta',
'	, rta.fin fin_rta',
'	, apr.ini ini_apr',
'	, apr.fin fin_apr',
'	, b.codproducto',
'	, b.descproducto',
'	, b.unidadmedida',
'	, b.cantordenada',
'	, b.precio',
'	, b.obsproveedor',
'	, b.obsaprobador',
'	, b.obsrecepcion',
'	, b.obscomprador',
'	, b.codproveedor codproveedor_det',
'	, b.descproveedor descproveedor_det',
'from data.vt_comp_ordencompraext a',
'inner join data.t_comp_ordencompraextdet b on a.idcab = b.idcab',
'inner join data.t_corp_udc c on c.id_cabecera = ''COMP_CGZCM'' and a.companiades = c.id_tabla',
'left join sts ing on ing.estado = ''INGRESADO'' and ing.idcab = a.idcab',
'left join sts apr on apr.estado = ''APROBADO'' and apr.idcab = a.idcab',
unistr('left join sts ges on ges.estado = ''GESTI\00D3N'' and ges.idcab = a.idcab'),
'left join sts rta on ing.estado = ''EN RUTA'' and rta.idcab = a.idcab',
'where 1 = 1',
'	and :p402_bandera = 1',
'	and a.fechcrea between :p402_fechadesde and :p402_fechahasta'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(316631820679112925)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>316631820679112925
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316631947476112926)
,p_db_column_name=>'IDCAB'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'ID OC'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316632069565112927)
,p_db_column_name=>'ESTADO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316632122752112928)
,p_db_column_name=>'USERCREA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Usr. Crea'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316632241125112929)
,p_db_column_name=>'FECHCREA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fecha Crea'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316632337556112930)
,p_db_column_name=>'COMPANIADES'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>unistr('C\00F3d. C\00EDa. Des')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316632437567112931)
,p_db_column_name=>'COMPANIADESTINO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>unistr('C\00EDa. Destino')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316632553883112932)
,p_db_column_name=>'CODCATCOMPRA'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>unistr('C\00F3d. Cat. Compra')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316632693423112933)
,p_db_column_name=>'CATCOMPRA'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Cat. Compra'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316632714603112934)
,p_db_column_name=>'CODSCTGCOMPRA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Cod. Subcat. Compra'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316632831316112935)
,p_db_column_name=>'SCTGCOMPRA'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Subcat. Compra'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316632931324112936)
,p_db_column_name=>'CODPROVEEDOR'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>unistr('C\00F3d. Proveedor')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316633066168112937)
,p_db_column_name=>'DESCPROVEEDOR'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316633133697112938)
,p_db_column_name=>'MONEDA'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316633272862112939)
,p_db_column_name=>'FECHAPLAN'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Fecha ETA'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316633303208112940)
,p_db_column_name=>'ESTADOPAGO'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Est. Pago'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316633482017112941)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>unistr('Observaci\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316633520387112942)
,p_db_column_name=>'CANTITEMS'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>unistr('Cant. \00CDtems')
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316633682703112943)
,p_db_column_name=>'TOTALOC'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Total OC'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316633746260112944)
,p_db_column_name=>'USUARIOINICIADOR'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Usr. Inicia'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316633886515112945)
,p_db_column_name=>'RECURRENTE'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Recurrente'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316633981477112946)
,p_db_column_name=>'TMP_GESTION'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Tiempo Gst.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316634085666112947)
,p_db_column_name=>'TMP_RUTA'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Tiempo Ruta'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316634144644112948)
,p_db_column_name=>'INI_ING'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Ini Ing'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316634271988112949)
,p_db_column_name=>'FIN_ING'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Fin Ing'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316634396843112950)
,p_db_column_name=>'INI_GES'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Ini Ges'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316658957597121601)
,p_db_column_name=>'FIN_GES'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Fin Ges'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316659087304121602)
,p_db_column_name=>'INI_RTA'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Ini Rta'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316659108779121603)
,p_db_column_name=>'FIN_RTA'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Fin Rta'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316659268914121604)
,p_db_column_name=>'INI_APR'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Ini Apr'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316659325380121605)
,p_db_column_name=>'FIN_APR'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Fin Apr'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316659457595121606)
,p_db_column_name=>'CODPRODUCTO'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>unistr('C\00F3d. Producto')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316659571392121607)
,p_db_column_name=>'DESCPRODUCTO'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316659641101121608)
,p_db_column_name=>'UNIDADMEDIDA'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'UM'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316659775547121609)
,p_db_column_name=>'CANTORDENADA'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Cant. Ord.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316659830000121610)
,p_db_column_name=>'PRECIO'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Precio UN'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316659935507121611)
,p_db_column_name=>'OBSPROVEEDOR'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Obs. Proveedor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316660073662121612)
,p_db_column_name=>'OBSAPROBADOR'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Obs. Aprobador'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316660126746121613)
,p_db_column_name=>'OBSRECEPCION'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Obs. Recepcion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316660237229121614)
,p_db_column_name=>'OBSCOMPRADOR'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Obs. Comprador'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316660324442121615)
,p_db_column_name=>'CODPROVEEDOR_DET'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>unistr('C\00F3d. Proveedor*')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(316660442524121616)
,p_db_column_name=>'DESCPROVEEDOR_DET'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Proveedor*'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(316689880617122629)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3166899'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'IDCAB:ESTADO:USERCREA:FECHCREA:COMPANIADESTINO:CATCOMPRA:SCTGCOMPRA:DESCPROVEEDOR:MONEDA:FECHAPLAN:ESTADOPAGO:OBSERVACION:CANTITEMS:TOTALOC:USUARIOINICIADOR:RECURRENTE:TMP_GESTION:TMP_RUTA:INI_ING:FIN_ING:INI_GES:FIN_GES:INI_RTA:FIN_RTA:INI_APR:FIN_A'
||'PR:CODPRODUCTO:DESCPRODUCTO:UNIDADMEDIDA:CANTORDENADA:PRECIO:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(633198884320771134)
,p_plug_name=>unistr('Par\00E1metros')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(633201227664771157)
,p_plug_name=>'Ocultos'
,p_region_name=>'regOcultos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_location=>null
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(639037813988974207)
,p_plug_name=>unistr('Barra de Acci\00F3n')
,p_region_name=>'rptBarraAccion'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(316627507038092588)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(639037813988974207)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Buscar'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(633208837086771207)
,p_name=>'P402_FECHADESDE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(633198884320771134)
,p_item_default=>'trunc(add_months(sysdate,-1),''MONTH'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Desde'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'TODAY-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(633208898075771208)
,p_name=>'P402_FECHAHASTA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(633198884320771134)
,p_item_default=>'sysdate'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Hasta'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'TODAY-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(633210165930771216)
,p_name=>'P402_BANDERA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(633201227664771157)
,p_prompt=>'Bandera'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(316628148026092620)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Bandera'
,p_process_sql_clob=>':p402_bandera := 1;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(316627507038092588)
,p_internal_uid=>316628148026092620
);
wwv_flow_imp.component_end;
end;
/
