prompt --application/pages/page_00165
begin
--   Manifest
--     PAGE: 00165
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>165
,p_name=>unistr('COMEX - Costos de Importaci\00F3n')
,p_step_title=>unistr('COMEX - Costos de Importaci\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_last_updated_on=>wwv_flow_imp.dz('20260409205742Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79243157468195216)
,p_plug_name=>'Costos de Importacion'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('select ''Importaci\00F3n'' modulo'),
'	, costo.id',
'	, mesa.id id_mesa',
'	, provision.id id_provision',
'	, mesa.ordencompra',
'	, mesa.tipooc',
'	, mesa.paisorigen',
'	, datos.incoterm',
'	, mesa.naviera',
'	, costo.valortotalfacturas',
'	, provision.puertodes',
'	, provision.ordenagtadn',
'	, provision.codigoproveedor',
'	, costo.valorprovision',
'	, costo.valorreal',
'from data.t_cmex_mesatrabajo mesa',
'inner join data.t_cmex_datoscomplementarios datos on mesa.id = datos.id_cmex_mesatrabajo',
'inner join data.t_cmex_provision provision',
'	on mesa.id = provision.id_cmex_mesatrabajo and provision.tiporegistro = ''PROVISION''',
'left join data.t_cmex_costoimportacion costo on mesa.id = costo.id_cmex_mesatrabajo',
'where mesa.codigoetapa = ''ET6'''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(79243200361195217)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:166:&SESSION.::&DEBUG.:RP,166:P166_ID,P166_ID_CMEX_MESATRABAJO,P166_ID_CMEX_LIQUIDACIONIMP:#ID#,#ID_MESA#,#ID_PROVISION#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'NETBY3'
,p_internal_uid=>79243200361195217
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79243371551195218)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79243453905195219)
,p_db_column_name=>'ORDENCOMPRA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Orden de Compra'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79243521686195220)
,p_db_column_name=>'TIPOOC'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'TOC'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79243622814195221)
,p_db_column_name=>'PAISORIGEN'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>unistr('Pa\00EDs')
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(74285031630072794)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79243717835195222)
,p_db_column_name=>'INCOTERM'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Incoterm'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79243864563195223)
,p_db_column_name=>'NAVIERA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Naviera'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79243982207195224)
,p_db_column_name=>'VALORTOTALFACTURAS'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Valor Total Facturas'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79244012937195225)
,p_db_column_name=>'PUERTODES'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Puerto Destino'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79244186567195226)
,p_db_column_name=>'ORDENAGTADN'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Orden Agente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79244224793195227)
,p_db_column_name=>'CODIGOPROVEEDOR'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79244309024195228)
,p_db_column_name=>'VALORPROVISION'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Valor Provision'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79244430236195229)
,p_db_column_name=>'VALORREAL'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Valor Real'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(84276181859476147)
,p_db_column_name=>'ID_MESA'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Id Mesa'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(84276209488476148)
,p_db_column_name=>'ID_PROVISION'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Id Provision'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(411016203764960545)
,p_db_column_name=>'MODULO'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>unistr('M\00F3dulo')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(79321100748924306)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'793212'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ORDENCOMPRA:TIPOOC:PAISORIGEN:INCOTERM:NAVIERA:VALORTOTALFACTURAS:PUERTODES:ORDENAGTADN:CODIGOPROVEEDOR:VALORPROVISION:VALORREAL:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79244632780195231)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp.component_end;
end;
/
