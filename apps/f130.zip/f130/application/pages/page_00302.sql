prompt --application/pages/page_00302
begin
--   Manifest
--     PAGE: 00302
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>302
,p_name=>unistr('Gesti\00F3n de Compradores')
,p_step_title=>unistr('Gesti\00F3n de Compradores')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230708132659Z')
,p_last_updated_on=>wwv_flow_imp.dz('20250513172441Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(44580439407114505)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(212074692288340826)
,p_plug_name=>unistr('Gesti\00F3n Compradores')
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select num03 noi',
'	, txt03 toi',
'	, num02 noc',
'	, txt02 toc',
'	, num01 nrq',
'	, txt01 trq',
'	, num13 proveedor',
'	, num14 comprador',
'	, num11 requisitor',
'	, fecha03 fechareq',
'	, fecha05 fechainicioruta',
'	, fecha06 fechafinruta',
'	, fecha06 - nvl(fecha03,fecha05) dias',
'	, txt10 observacion',
'/*',
'	, num01 noi',
'	, txt01 toi',
'	, num02 noc',
'	, txt02 toc',
'	, num03 nrq',
'	, txt03 trq',
'	, num10 proveedor',
'	, num11 comprador',
'	, num12 requisitor',
'	, fecha01 fechareq',
'	, fecha02 fechainicioruta',
'	, fecha03 fechafinruta',
'	, fecha03 - nvl(fecha01,fecha02) dias',
'*/',
'from data.t_apex_temporal',
'where 1 = 1',
'	and flag = ''C''',
'	and control01 = :g_compania',
'	and control02 = :app_modulo',
'	and control03 = :app_user',
'	and control04 = ''data.pk_comp_reportes.sp_gestioncompradores'''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_updated_on=>wwv_flow_imp.dz('20250513172441Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(212074735931340827)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'CSV'
,p_enable_mail_download=>'N'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>212074735931340827
,p_updated_on=>wwv_flow_imp.dz('20250513172441Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(212074875738340828)
,p_db_column_name=>'COMPRADOR'
,p_display_order=>60
,p_column_identifier=>'A'
,p_column_label=>'Comprador'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(212074961164340829)
,p_db_column_name=>'REQUISITOR'
,p_display_order=>70
,p_column_identifier=>'B'
,p_column_label=>'Requisitor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(212076450926340844)
,p_db_column_name=>'FECHAREQ'
,p_display_order=>120
,p_column_identifier=>'P'
,p_column_label=>'Fin Req.'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(212075581217340835)
,p_db_column_name=>'FECHAINICIORUTA'
,p_display_order=>130
,p_column_identifier=>'H'
,p_column_label=>'Inicio OC'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(212075605031340836)
,p_db_column_name=>'FECHAFINRUTA'
,p_display_order=>140
,p_column_identifier=>'I'
,p_column_label=>'Fin OC'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(212076695768340846)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>170
,p_column_identifier=>'R'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92884089369350949)
,p_db_column_name=>'NOI'
,p_display_order=>180
,p_column_identifier=>'T'
,p_column_label=>'Orden Embarque'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92884182517350950)
,p_db_column_name=>'TOI'
,p_display_order=>190
,p_column_identifier=>'U'
,p_column_label=>'TOE'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250533097930615201)
,p_db_column_name=>'NOC'
,p_display_order=>200
,p_column_identifier=>'V'
,p_column_label=>'Orden Compra'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250533183865615202)
,p_db_column_name=>'TOC'
,p_display_order=>210
,p_column_identifier=>'W'
,p_column_label=>'TOC'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250533270162615203)
,p_db_column_name=>'NRQ'
,p_display_order=>220
,p_column_identifier=>'X'
,p_column_label=>unistr('Requisici\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250533372583615204)
,p_db_column_name=>'TRQ'
,p_display_order=>230
,p_column_identifier=>'Y'
,p_column_label=>'TRQ'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250533401819615205)
,p_db_column_name=>'DIAS'
,p_display_order=>240
,p_column_identifier=>'Z'
,p_column_label=>unistr('D\00EDas')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(683903390248132227)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>250
,p_column_identifier=>'AA'
,p_column_label=>unistr('Observaci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250513163335Z')
,p_updated_on=>wwv_flow_imp.dz('20250513163347Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(238835908213653150)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2388360'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NOI:TOI:NOC:TOC:NRQ:TRQ:PROVEEDOR:COMPRADOR:REQUISITOR:FECHAREQ:FECHAINICIORUTA:FECHAFINRUTA:DIAS:OBSERVACION:'
,p_sort_column_1=>'COMPRADOR'
,p_sort_direction_1=>'ASC NULLS LAST'
,p_sort_column_2=>'NOI'
,p_sort_direction_2=>'DESC NULLS LAST'
,p_sort_column_3=>'NOC'
,p_sort_direction_3=>'DESC NULLS LAST'
,p_sort_column_4=>'NRQ'
,p_sort_direction_4=>'DESC NULLS LAST'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20230708132659Z')
,p_updated_on=>wwv_flow_imp.dz('20250513172441Z')
,p_created_by=>'CVACA'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(21810289158226299)
,p_report_id=>wwv_flow_imp.id(238835908213653150)
,p_name=>'RQ'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIAS'
,p_operator=>'is null'
,p_condition_sql=>' (case when ("DIAS" is null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FFEBC9'
,p_created_on=>wwv_flow_imp.dz('20250513172441Z')
,p_updated_on=>wwv_flow_imp.dz('20250513172441Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1080963231180695207)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(44588976505121121)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1080963231180695207)
,p_button_name=>'BUSCAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44580665809114507)
,p_name=>'P302_FECHADESDE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(44580439407114505)
,p_item_default=>'trunc(add_months(sysdate,-1),''month'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Desde:'
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44580752287114508)
,p_name=>'P302_TIPOORDEN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(44580439407114505)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44580893463114509)
,p_name=>'P302_FECHAHASTA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(44580439407114505)
,p_item_default=>'sysdate'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Hasta:'
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(44580958065114510)
,p_name=>'P302_COMPRADOR'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(44580439407114505)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_coderp number;',
'begin',
'	begin',
'		select pdanby into v_coderp',
'		from f4311@jdedtadl, vt_corp_usuario',
'		where pdanby = coderp and nombreusuario = :app_user and pddcto in (''CM'',''BM'',''CE'',''CN'', ''BN'',''OI'')',
'        and pdtrdj between data.pk_commons.f_g2jde(:p302_fechadesde) and data.pk_commons.f_g2jde(:p302_fechahasta)',
'        and rownum = 1;',
'',
'		exception when no_data_found then v_coderp := null;',
'	end;',
'',
'	return v_coderp;',
'end;'))
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Comprador: '
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct apellidos||'' ''||nombres a',
'	, pdanby b',
'from f4311@jdedtadl, vt_corp_usuario',
'where pdanby = coderp',
'	and pddcto in (''CM'',''BM'',''CE'',''CN'', ''BN'',''OI'')',
'    and pdtrdj between data.pk_commons.f_g2jde(:p302_fechadesde) and data.pk_commons.f_g2jde(:p302_fechahasta)',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_cascade_parent_items=>'P302_FECHADESDE,P302_FECHAHASTA'
,p_ajax_items_to_submit=>'P302_FECHADESDE,P302_FECHAHASTA'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(92883240737350941)
,p_name=>'P302_BANDERA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(44580439407114505)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(542214596106004747)
,p_name=>'P302_TIPOREQUISICION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(44580439407114505)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(92883574325350944)
,p_name=>'Buscar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(44588976505121121)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(92883686372350945)
,p_event_id=>wwv_flow_imp.id(92883574325350944)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(92883730612350946)
,p_event_id=>wwv_flow_imp.id(92883574325350944)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	pk_comp_reportes.sp_gestioncompradores(:g_compania,:app_user,:p302_comprador,null,null,:p302_fechadesde,:p302_fechahasta);',
'end;'))
,p_attribute_02=>'P302_FECHADESDE,P302_FECHAHASTA,P302_COMPRADOR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(212075824893340838)
,p_event_id=>wwv_flow_imp.id(92883574325350944)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(212074692288340826)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(92883905421350948)
,p_event_id=>wwv_flow_imp.id(92883574325350944)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp.component_end;
end;
/
