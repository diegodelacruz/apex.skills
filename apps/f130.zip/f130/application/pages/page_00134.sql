prompt --application/pages/page_00134
begin
--   Manifest
--     PAGE: 00134
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>134
,p_name=>'Imprimir OC'
,p_step_title=>'Imprimir OC'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20241002191301Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260506153115Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(128921618100055348)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(129031564645454403)
,p_plug_name=>'Ordenes de Compra'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select phdcto',
'	, phdoco',
'	, data.pk_commons.f_jde2g(phtrdj) fechaoc',
'	, sum((pduorg/10000)*(pdprrc/10000)) photot',
'	, phan8',
'	, trim(abalph) abalph',
'	, :p134_url||''&p_numero=''||PHDOCO||''&p_tipo=''||phdcto url',
'	, ''<span class="fa fa-file-pdf-o" aria-hidden="true" style="color: #FA0F00;"></span>'' pdf',
'from f4301@jdedtadl a',
'inner join f4311@jdedtadl b on a.phkcoo = b.pdkcoo and a.phdoco = b.pddoco and a.phdcto = b.pddcto',
'inner join f0101@jdedtadl c on c.aban8 = a.phan8',
'where :p134_bandera = 1',
'	and phdcto = :p134_tipo',
'	and ((phtrdj between data.pk_commons.f_g2jde(:p134_fecdesde) and data.pk_commons.f_g2jde(:p134_fechasta)) )',
'	and (phdoco = :P134_ORDENCOMPRA or :P134_ORDENCOMPRA is null)',
'group by',
'phdcto',
', phdoco',
', data.pk_commons.f_jde2g(phtrdj) ',
', phan8',
', trim(abalph)'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Ordenes de Compra'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20250319140053Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(129031605843454404)
,p_max_row_count=>'1000000'
,p_max_row_count_message=>unistr('Esta consulta devuelve m\00E1s de #MAX_ROW_COUNT# filas, filtre los datos para asegurar resultados completos.')
,p_no_data_found_message=>unistr('No se ha encontrado ning\00FAn dato.')
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>129031605843454404
,p_updated_on=>wwv_flow_imp.dz('20250319140053Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129031709631454405)
,p_db_column_name=>'PHDCTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129031802409454406)
,p_db_column_name=>'PHDOCO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Orden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129031951262454407)
,p_db_column_name=>'FECHAOC'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129032055950454408)
,p_db_column_name=>'PHOTOT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Total OC'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129032115571454409)
,p_db_column_name=>'PHAN8'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>unistr('C\00F3d. Proveedor')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(129032211084454410)
,p_db_column_name=>'ABALPH'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(340098810368298906)
,p_db_column_name=>'URL'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Url'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_updated_on=>wwv_flow_imp.dz('20250319140053Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(340099129838298909)
,p_db_column_name=>'PDF'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'-'
,p_column_link=>'#URL#'
,p_column_linktext=>'#PDF#'
,p_column_link_attr=>'target="_blank"'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250319140038Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(129054817543518773)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1290549'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PDF:PHDCTO:PHDOCO:FECHAOC:PHAN8:ABALPH:PHOTOT:'
,p_sort_column_1=>'FECHAOC'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'PHDCTO'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'PHDOCO'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_sum_columns_on_break=>'PHOTOT'
,p_created_on=>wwv_flow_imp.dz('20241002191301Z')
,p_updated_on=>wwv_flow_imp.dz('20241002191301Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(129032686959454414)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(129032761988454415)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(129032686959454414)
,p_button_name=>'Buscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(55026131712667104)
,p_name=>'P134_ORDENCOMPRA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(128921618100055348)
,p_prompt=>'Orden Compra'
,p_placeholder=>'99999999'
,p_format_mask=>'99999999'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'0'
,p_attribute_02=>'99999999'
,p_attribute_03=>'left'
,p_attribute_04=>'numeric'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(111974209547981947)
,p_name=>'P134_BANDERA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(128921618100055348)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(128921801405055350)
,p_name=>'P134_FECDESDE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(128921618100055348)
,p_item_default=>'trunc(ADD_MONTHS(SYSDATE,-1),''MONTH'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha desde: '
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'+0d'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129031300993454401)
,p_name=>'P134_FECHASTA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(128921618100055348)
,p_item_default=>'trunc(SYSDATE)'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha hasta: '
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'+0d'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(129031453425454402)
,p_name=>'P134_TIPO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(128921618100055348)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  item D,item R from table(pk_commons.f_dividirtexto(''BN|CM|CN|CE|CT|CP|BM'',''|'')) ',
'ORDER BY 1',
';'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(340098929795298907)
,p_name=>'P134_URL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(128921618100055348)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(340099037461298908)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- if pk_corp_commons.f_isproduccion then',
'--     :p134_url:=''http://jasper.zaimella.com:8090/jasperserver/flow.html?_flowId=viewReportFlow&standAlone=true&_repFormat=pdf&output=pdf&_flowId=viewReportFlow&ParentFolderUri=/PRODUCCION/COMPRAS&reportUnit=/PRODUCCION/COMPRAS/rptOrdenCompras&j_use'
||'rname=desarrollo&j_password=desarrollo&_repLocale=en_US&_repEncoding=UTF-8'';',
'-- else',
'--     :p134_url:=''http://jasper.zaimella.com:8090/jasperserver/flow.html?_flowId=viewReportFlow&standAlone=true&_repFormat=pdf&output=pdf&_flowId=viewReportFlow&ParentFolderUri=/TEST/COMPRAS&reportUnit=/TEST/COMPRAS/rptOrdenCompras&j_username=desarr'
||'ollo&j_password=desarrollo&_repLocale=en_US&_repEncoding=UTF-8'';',
'-- end if;',
'',
'if pk_corp_commons.f_isproduccion then',
'	:p134_url:=''http://jasper.zaimella.com:8090/jasperserver/rest_v2/reports/PRODUCCION/COMPRAS/rptOrdenCompras.pdf?&j_username=jasperadmin&j_password=jasperadmin&_repLocale=en_US&_repEncoding=UTF-8'';',
'else',
'	:p134_url:=''http://jasper.zaimella.com:8090/jasperserver/rest_v2/reports/TEST/COMPRAS/rptOrdenCompras.pdf?&j_username=jasperadmin&j_password=jasperadmin&_repLocale=en_US&_repEncoding=UTF-8'';',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>340099037461298908
,p_updated_on=>wwv_flow_imp.dz('20260506153115Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(111974326476981948)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Bandera'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    :P134_BANDERA := 1;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(129032761988454415)
,p_internal_uid=>111974326476981948
);
wwv_flow_imp.component_end;
end;
/
