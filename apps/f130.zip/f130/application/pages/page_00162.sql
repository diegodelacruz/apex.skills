prompt --application/pages/page_00162
begin
--   Manifest
--     PAGE: 00162
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>162
,p_name=>'COMEX - Provisiones'
,p_step_title=>'COMEX - Provisiones'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_created_on=>wwv_flow_imp.dz('20240414044950Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260409204341Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(76150578185799227)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(76166753351894109)
,p_plug_name=>'Provisiones'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_read_only_when_type=>'FUNCTION_BODY'
,p_plug_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_conta NUMBER;',
'BEGIN',
'',
'IF :P162_ESTADO = ''EN RUTA''  THEN RETURN TRUE; END IF;',
'',
'RETURN FALSE;',
'',
'',
'',
'END;'))
,p_plug_read_only_when2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20241108160119Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(497404518976544405)
,p_plug_name=>'Datos Exportaciones'
,p_parent_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P162_CODIGOMODULO'
,p_plug_display_when_cond2=>'EXP'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20241108160119Z')
,p_updated_on=>wwv_flow_imp.dz('20241108160119Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(92023068437888202)
,p_plug_name=>'Detalle Montos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P162_ESTADO IN (''INGRESADO'',''RECHAZADO'') AND :P162_ID IS NOT NULL'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20241108160025Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(92023171441888203)
,p_plug_name=>'Form Tabular Detalle'
,p_parent_plug_id=>wwv_flow_imp.id(92023068437888202)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.id',
'	, a.id_cabecera',
'	, a.concepto',
'	, a.montoprovision',
'	, a.montoreal',
'	, nvl(a.montoestandar,0) montoestandar',
'	, a.proveedor',
'	, a.numerofactura',
'	, ''<span title="Adjuntar Factura" class="fa fa-paperclip"></span>'' Adjuntar',
'	, a.idordvnc',
'from data.t_cmex_provision_detalle a-- left join t_cmex_ordenesvinculadas b on a.idordvnc = b.id',
'where a.id_cabecera = :p162_id'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P162_ID'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Form Tabular Detalle'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20250220173458Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(188778052704282708)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(188778156066282709)
,p_name=>'ID_CABECERA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID_CABECERA'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P162_ID'
,p_duplicate_value=>true
,p_include_in_export=>false
,p_updated_on=>wwv_flow_imp.dz('20250205202136Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(188778207976282710)
,p_name=>'CONCEPTO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CONCEPTO'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>'Concepto'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_is_required=>false
,p_max_length=>3
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(93018914532751121)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20241107201209Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(188778309636282711)
,p_name=>'MONTOPROVISION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MONTOPROVISION'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Monto'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>80
,p_value_alignment=>'RIGHT'
,p_attribute_01=>'0'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P162_CODIGOMODULO'
,p_display_condition2=>'IMP'
,p_column_comment=>unistr('En las Importaciones s\00ED se provisiona')
,p_updated_on=>wwv_flow_imp.dz('20250128155035Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(188778499704282712)
,p_name=>'PROVEEDOR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PROVEEDOR'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>'Proveedor'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(165398581949586903)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':p162_codigomodulo = ''EXP'' or :p162_ordencompra like ''IMP%'''
,p_display_condition2=>'PLSQL'
,p_updated_on=>wwv_flow_imp.dz('20241107201112Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(188778502424282713)
,p_name=>'NUMEROFACTURA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUMEROFACTURA'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>unistr('N\00FAmero Factura')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>15
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':p162_codigomodulo = ''EXP'' or :p162_ordencompra like ''IMP%'''
,p_display_condition2=>'PLSQL'
,p_updated_on=>wwv_flow_imp.dz('20241107201112Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(188778696246282714)
,p_name=>'ADJUNTAR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ADJUNTAR'
,p_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_LINK'
,p_heading=>'Factura'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>120
,p_value_alignment=>'CENTER'
,p_link_target=>'f?p=100:401:&SESSION.::&DEBUG.::P401_TABLA,P401_ID,P401_ESTADO,P401_TIPO:T_CMEX_PROVISION_DETALLE,&P162_ID.,1,&NUMEROFACTURA.'
,p_link_text=>'&ADJUNTAR.'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>false
,p_is_primary_key=>false
,p_include_in_export=>true
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P162_ORDENCOMPRA like ''IMP%'''
,p_display_condition2=>'PLSQL'
,p_escape_on_http_output=>false
,p_updated_on=>wwv_flow_imp.dz('20250220173458Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(188778946244282717)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(188779062210282718)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(497404243294544402)
,p_name=>'MONTOREAL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MONTOREAL'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Monto'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>100
,p_value_alignment=>'RIGHT'
,p_attribute_01=>'0'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P162_CODIGOMODULO'
,p_display_condition2=>'EXP'
,p_column_comment=>'Las exportaciones no se provisionan.'
,p_updated_on=>wwv_flow_imp.dz('20250128155035Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(497404380183544403)
,p_name=>'MONTOESTANDAR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MONTOESTANDAR'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>unistr('Monto Est\00E1ndar')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>110
,p_value_alignment=>'RIGHT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P162_CODIGOMODULO'
,p_display_condition2=>'EXP'
,p_updated_on=>wwv_flow_imp.dz('20241107201112Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(591850754419691409)
,p_name=>'IDORDVNC'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IDORDVNC'
,p_data_type=>'NUMBER'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'OI'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>150
,p_value_alignment=>'CENTER'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>'select ordenimp, id from t_cmex_ordenesvinculadas where idmesa = :p162_id_cmex_mesatrabajo'
,p_lov_display_extra=>false
,p_lov_display_null=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_updated_on=>wwv_flow_imp.dz('20250205211211Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(188777985217282707)
,p_internal_uid=>188777985217282707
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'ACTIONS_MENU:RESET:SAVE'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>true
,p_download_formats=>'XLSX'
,p_enable_mail_download=>false
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_updated_on=>wwv_flow_imp.dz('20250205211417Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(188800492231503469)
,p_interactive_grid_id=>wwv_flow_imp.id(188777985217282707)
,p_static_id=>'1888005'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
,p_updated_on=>wwv_flow_imp.dz('20250205211417Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(188800601343503470)
,p_report_id=>wwv_flow_imp.id(188800492231503469)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(188801144594503474)
,p_view_id=>wwv_flow_imp.id(188800601343503470)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(188778052704282708)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(188802060495503480)
,p_view_id=>wwv_flow_imp.id(188800601343503470)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(188778156066282709)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(188802951279503483)
,p_view_id=>wwv_flow_imp.id(188800601343503470)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(188778207976282710)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(188803803713503486)
,p_view_id=>wwv_flow_imp.id(188800601343503470)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(188778309636282711)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>150
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(188804773294503488)
,p_view_id=>wwv_flow_imp.id(188800601343503470)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(188778499704282712)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(188805640370503490)
,p_view_id=>wwv_flow_imp.id(188800601343503470)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(188778502424282713)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(188806532688503493)
,p_view_id=>wwv_flow_imp.id(188800601343503470)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(188778696246282714)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>60
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(189651269886888078)
,p_view_id=>wwv_flow_imp.id(188800601343503470)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(188778946244282717)
,p_is_visible=>true
,p_is_frozen=>true
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(498437688092527109)
,p_view_id=>wwv_flow_imp.id(188800601343503470)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(497404243294544402)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>125
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(498438559649527114)
,p_view_id=>wwv_flow_imp.id(188800601343503470)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(497404380183544403)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>125
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(592409276460181092)
,p_view_id=>wwv_flow_imp.id(188800601343503470)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(591850754419691409)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>150
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(93112145708453117)
,p_plug_name=>'BotonesTabular'
,p_parent_plug_id=>wwv_flow_imp.id(92023068437888202)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295609041229037671)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'1=2'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20241108160025Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(93112230324453118)
,p_plug_name=>unistr('Reporte Aprobaci\00F3n')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select b.concepto',
'	, b.montoreal',
'	, b.montoprovision',
'	, b.montoestandar',
'	, b.proveedor',
'	, b.numerofactura',
'    , c.ordenimp',
'	, case',
'		when a.codigomodulo = ''IMP'' then case when b.montoprovision > b.montoestandar then 1 else 0 end',
'		when a.codigomodulo = ''EXP'' then case when b.montoreal > b.montoestandar then 1 else 0 end',
'		end as bandera',
'from t_cmex_provision a',
'inner join t_cmex_provision_detalle b on a.id = b.id_cabecera',
'left join t_cmex_ordenesvinculadas c on b.idordvnc = c.id',
'where a.id = :p162_id'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P162_ID'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P162_ESTADO IN (''PROCESADO'',''EN RUTA'')'
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_updated_on=>wwv_flow_imp.dz('20250109172756Z')
,p_updated_by=>'TPALACIOS'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(93112487077453120)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'NETBY3'
,p_internal_uid=>93112487077453120
,p_updated_on=>wwv_flow_imp.dz('20250109172756Z')
,p_updated_by=>'TPALACIOS'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250536485525615235)
,p_db_column_name=>'CONCEPTO'
,p_display_order=>10
,p_column_identifier=>'E'
,p_column_label=>'Concepto'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(93018914532751121)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(93112677638453122)
,p_db_column_name=>'MONTOPROVISION'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Monto'
,p_allow_ctrl_breaks=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P162_CODIGOMODULO'
,p_display_condition2=>'IMP'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20241108161001Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(93112745793453123)
,p_db_column_name=>'MONTOESTANDAR'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>unistr('Monto Est\00E1ndar')
,p_allow_ctrl_breaks=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20241108161001Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(93113431975453130)
,p_db_column_name=>'BANDERA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Bandera'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(188778763428282715)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>50
,p_column_identifier=>'F'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P162_ORDENCOMPRA like ''IMP%'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(188778809929282716)
,p_db_column_name=>'NUMEROFACTURA'
,p_display_order=>60
,p_column_identifier=>'G'
,p_column_label=>unistr('N\00FAmero Factura')
,p_column_type=>'STRING'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P162_ORDENCOMPRA like ''IMP%'''
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(497404693924544406)
,p_db_column_name=>'MONTOREAL'
,p_display_order=>70
,p_column_identifier=>'H'
,p_column_label=>'Monto'
,p_allow_ctrl_breaks=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P162_CODIGOMODULO'
,p_display_condition2=>'EXP'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20241108161000Z')
,p_updated_on=>wwv_flow_imp.dz('20241108161000Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560166217334877037)
,p_db_column_name=>'ORDENIMP'
,p_display_order=>80
,p_column_identifier=>'I'
,p_column_label=>unistr('Orden Importaci\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250109172710Z')
,p_updated_on=>wwv_flow_imp.dz('20250109172710Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(93162705013354829)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'931628'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ORDENIMP:CONCEPTO:MONTOESTANDAR:MONTOPROVISION:'
,p_sort_column_1=>'ORDENIMP'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'CONCEPTO'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20240414044950Z')
,p_updated_on=>wwv_flow_imp.dz('20250109172756Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'TPALACIOS'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(561408977014929489)
,p_report_id=>wwv_flow_imp.id(93162705013354829)
,p_name=>'Mayores'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'BANDERA'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("BANDERA" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#ffc3c3'
,p_row_font_color=>'#000000'
,p_created_on=>wwv_flow_imp.dz('20250109172756Z')
,p_updated_on=>wwv_flow_imp.dz('20250109172756Z')
,p_created_by=>'TPALACIOS'
,p_updated_by=>'TPALACIOS'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(92024432316888216)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(93112145708453117)
,p_button_name=>'ADD'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>unistr('A\00F1adir Fila')
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.widget.tabular.addRow();'
,p_icon_css_classes=>'fa-plus'
,p_updated_on=>wwv_flow_imp.dz('20241108160025Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(76167446773894111)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(76150578185799227)
,p_button_name=>'CANCELCMEX'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:155:&SESSION.::&DEBUG.:::'
,p_button_condition=>'P162_MODULO_EXT'
,p_button_condition2=>'CMEX'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-arrow-left'
,p_updated_on=>wwv_flow_imp.dz('20241128153918Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(92024226688888214)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(93112145708453117)
,p_button_name=>'MUTI_ROW_DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Eliminar Seleccionados'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-trash'
,p_updated_on=>wwv_flow_imp.dz('20241108160025Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(92024337321888215)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(93112145708453117)
,p_button_name=>'SAVE_TABULAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Guardar Rubros'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-save'
,p_updated_on=>wwv_flow_imp.dz('20241108160025Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(210982387307024548)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(76150578185799227)
,p_button_name=>'CANCELFINZ'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=109:2002:&SESSION.::&DEBUG.:2002::'
,p_button_condition=>'P162_MODULO_EXT'
,p_button_condition2=>'FINZ'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-arrow-left'
,p_updated_on=>wwv_flow_imp.dz('20241128153918Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(76167370077894111)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(76150578185799227)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Eliminar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    IF :P162_ID IS NULL THEN ',
'        RETURN FALSE;',
'    END IF;',
'',
'    IF :P162_ESTADO IN (''PROCESADO'',''EN RUTA'') THEN ',
'        RETURN FALSE;',
'    END IF;',
'    RETURN TRUE;',
'END;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-trash'
,p_database_action=>'DELETE'
,p_updated_on=>wwv_flow_imp.dz('20241128153918Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(92024049372888212)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(93112145708453117)
,p_button_name=>'CANCELAR_TABULAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Cancelar Cambios'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:162:&SESSION.::&DEBUG.:RP,162:P162_ID:&P162_ID.'
,p_icon_css_classes=>'fa-times-circle-o'
,p_updated_on=>wwv_flow_imp.dz('20241108160025Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(76167265003894111)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(76150578185799227)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Aplicar Cambios'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_conta NUMBER;',
'BEGIN',
'    IF :P162_ID IS NULL THEN RETURN FALSE; END IF;',
'    IF :P162_ESTADO IN (''PROCESADO'',''EN RUTA'') THEN RETURN FALSE; END IF;',
'    RETURN TRUE;',
'END;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'UPDATE'
,p_updated_on=>wwv_flow_imp.dz('20241128153918Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37859479961753921)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(76150578185799227)
,p_button_name=>'ATAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Atar OC Original'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''x''',
'from t_cmex_mesatrabajo a',
'inner join t_cmex_provision b on a.id = b.id_cmex_mesatrabajo',
'where 1 = 1',
'and b.id = :p162_id',
'and :p162_estado != ''PENDIENTE''',
'and :p162_codigomodulo = ''IMP'''))
,p_button_condition_type=>'NOT_EXISTS'
,p_icon_css_classes=>'fa-server-check'
,p_updated_on=>wwv_flow_imp.dz('20241105034942Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(61446436468698525)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(76150578185799227)
,p_button_name=>'ARCHIVO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Archivos'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:190:&SESSION.::&DEBUG.:190:P190_IDMESA,P190_IDPROV:&P162_ID_CMEX_MESATRABAJO.,&P162_ID.'
,p_icon_css_classes=>'fa-file-pdf-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(64131716147537804)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(76150578185799227)
,p_button_name=>'CARGARGASTOS'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Cargar Gastos'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P162_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-badge-dollar'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(79242395099195208)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(76150578185799227)
,p_button_name=>'PROCESAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Procesar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_conta number;',
'v_resultado boolean;',
'BEGIN',
'    IF :P162_ID IS NULL THEN RETURN FALSE; END IF;',
'',
'    IF :P162_ESTADO IN (''PROCESADO'',''EN RUTA'') THEN RETURN FALSE; END IF;',
'',
'    SELECT COUNT(1) INTO v_conta FROM DATA.T_CMEX_PROVISION_DETALLE WHERE ID_CABECERA = :P162_ID AND MONTOPROVISION >= 0;',
'',
'    IF v_conta < 1 THEN RETURN FALSE; END IF;',
'',
'    RETURN TRUE;',
'END;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-gears'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(93112821291453124)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(76150578185799227)
,p_button_name=>'APROBAR_FLUJO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Aprobar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P162_ESTADO = ''EN RUTA'' AND ',
'pk_cmex_mesatrabajo.F_ESTANDAR_APROBACION_FLUJO(P_ID_CAB => :P162_ID, P_MODULO => ''CMEX'', P_TIPOMODULO => :P162_CODIGOMODULO, P_ENTIDAD => ''CMEX_PROVISION'', P_ETAPA => NULL, P_USUARIO => :APP_USER ,  P_ESTADO_BUSCAR => ''EN_PROCESO'' )  = 1'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-check-circle-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(93112993374453125)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_imp.id(76150578185799227)
,p_button_name=>'RECHAZAR_FLUJO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Rechazar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P162_ESTADO = ''EN RUTA'' AND ',
'pk_cmex_mesatrabajo.F_ESTANDAR_APROBACION_FLUJO(P_ID_CAB => :P162_ID, P_MODULO => ''CMEX'', P_TIPOMODULO => :P162_CODIGOMODULO, P_ENTIDAD => ''CMEX_PROVISION'', P_ETAPA => NULL, P_USUARIO => :APP_USER ,  P_ESTADO_BUSCAR => ''EN_PROCESO'' )  = 1'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-times-circle-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(201054841307262401)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_imp.id(76150578185799227)
,p_button_name=>'HABILITAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Habilitar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>':P162_ESTADO IN (''PROCESADO'') and :P162_MODULO_EXT in (''CMEX'')'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-undo-arrow'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(187249505774684744)
,p_button_sequence=>130
,p_button_plug_id=>wwv_flow_imp.id(76150578185799227)
,p_button_name=>'Requisicion'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>unistr('Generar Requisici\00F3n')
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P162_ORDENCOMPRA like ''IMP%'''
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-flag-checkered'
,p_updated_on=>wwv_flow_imp.dz('20240414050830Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(76167118552894111)
,p_button_sequence=>150
,p_button_plug_id=>wwv_flow_imp.id(76150578185799227)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Crear'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P162_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'INSERT'
,p_updated_on=>wwv_flow_imp.dz('20241128153918Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(76169030658894112)
,p_branch_name=>'Go To Page 162 - Form Provisiones'
,p_branch_action=>'f?p=&APP_ID.:162:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
,p_branch_condition_type=>'REQUEST_NOT_IN_CONDITION'
,p_branch_condition=>'DELETE,APROBAR_FLUJO,RECHAZAR_FLUJO,PROCESAR'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(80461111308347003)
,p_branch_name=>'Go to 155 - Liquidacion Importaciones'
,p_branch_action=>'f?p=&APP_ID.:155:&SESSION.::&DEBUG.:RP,155::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>11
,p_branch_condition_type=>'REQUEST_IN_CONDITION'
,p_branch_condition=>'DELETE,RECHAZAR_FLUJO'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(93114139315453137)
,p_branch_name=>'Go to 155 - Mesa de trabajo'
,p_branch_action=>'f?p=&APP_ID.:155:&SESSION.::&DEBUG.:RP,::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(93112821291453124)
,p_branch_sequence=>21
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(93114281097453138)
,p_branch_name=>'Go To Procesamiento Result - 155 Liquidacion'
,p_branch_action=>'f?p=&APP_ID.:155:&SESSION.::&DEBUG.:RP,155::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(79242395099195208)
,p_branch_sequence=>31
,p_branch_condition_type=>'EXPRESSION'
,p_branch_condition=>':P162_ESTADO = ''EN RUTA'''
,p_branch_condition_text=>'PLSQL'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(93114336542453139)
,p_branch_name=>'Go To Procesamiento Result - Aprobado'
,p_branch_action=>'f?p=&APP_ID.:155:&SESSION.::&DEBUG.:RP,::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(79242395099195208)
,p_branch_sequence=>41
,p_branch_condition_type=>'EXPRESSION'
,p_branch_condition=>':P162_ESTADO = ''PROCESADO'''
,p_branch_condition_text=>'PLSQL'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76169441275894116)
,p_name=>'P162_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76169805258894125)
,p_name=>'P162_ESTADO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_use_cache_before_default=>'NO'
,p_item_default=>'INGRESADO'
,p_prompt=>'Estado'
,p_source=>'ESTADO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76170297949894126)
,p_name=>'P162_ID_BATCH'
,p_item_sequence=>400
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_use_cache_before_default=>'NO'
,p_source=>'ID_BATCH'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76170656928894126)
,p_name=>'P162_CODIGOMODULO'
,p_item_sequence=>450
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_use_cache_before_default=>'NO'
,p_item_default=>'IMP'
,p_source=>'CODIGOMODULO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76171033520894128)
,p_name=>'P162_ORDENCOMPRA'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Orden Compra'
,p_source=>'ORDENCOMPRA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(decode(nvl(id_muestra,0),0,oc,idproceso)) display, to_char(decode(nvl(id_muestra,0),0,oc,idproceso)) retorn',
'from vt_cmex_mesatrabajo',
'where 1 = 1',
'	and :p162_codigomodulo = ''IMP''',
'	and codigoetapa = ''ET6''',
'	and to_char(decode(nvl(id_muestra,0),0,oc,idproceso)) not in (select ordencompra from data.t_cmex_provision)',
'union',
'select to_char(''EXP-''||registro) display, to_char(''EXP-''||registro) retorn',
'from data.t_cmex_exportacion',
'where 1 = 1',
'	and :p162_codigomodulo = ''EXP''',
'	and estado = estado',
'	and ''EXP-''||registro not in (select ordencompra from data.t_cmex_provision)',
'union',
'select ordencompra display, ordencompra retorn',
'from data.t_cmex_provision',
'where :p162_estado != ''PENDIENTE'' and ordencompra = :p162_ordencompra',
'order by 1;'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when=>':P162_ID IS NOT NULL'
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20241127194141Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76177487639894134)
,p_name=>'P162_CODIGOPROVEEDOR'
,p_item_sequence=>410
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_use_cache_before_default=>'NO'
,p_source=>'CODIGOPROVEEDOR'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76177850877894134)
,p_name=>'P162_TIPOMERCA'
,p_item_sequence=>420
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_use_cache_before_default=>'NO'
,p_source=>'TIPOMERCA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76178259785894134)
,p_name=>'P162_REFERENDO'
,p_item_sequence=>440
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_use_cache_before_default=>'NO'
,p_source=>'REFERENDO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76178646704894134)
,p_name=>'P162_FECHALIQADN'
,p_item_sequence=>330
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fecha Liq Aduana'
,p_source=>'FECHALIQADN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'readonly = "readonly"'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76179003590894134)
,p_name=>'P162_FECHACIECST'
,p_item_sequence=>340
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fecha Cierre de Costo'
,p_source=>'FECHACIECST'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76179473801894134)
,p_name=>'P162_ORDENAGTADN'
,p_item_sequence=>430
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_use_cache_before_default=>'NO'
,p_source=>'ORDENAGTADN'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76179807107894134)
,p_name=>'P162_PUERTOORI'
,p_item_sequence=>350
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_use_cache_before_default=>'NO'
,p_item_default=>'select upper(puertoorigen) from t_cmex_mesatrabajo where id = :p162_id_cmex_mesatrabajo and rownum = 1'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Puerto Origen'
,p_source=>'PUERTOORI'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>'SELECT DISTINCT PUERTOORI FROM DATA.T_CMEX_PROVISION'
,p_cSize=>32
,p_cMaxlength=>25
,p_display_when=>'P162_CODIGOMODULO'
,p_display_when2=>'EXP'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'N'
,p_attribute_09=>'2'
,p_updated_on=>wwv_flow_imp.dz('20241105031105Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76180275250894136)
,p_name=>'P162_PUERTODES'
,p_item_sequence=>360
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_use_cache_before_default=>'NO'
,p_item_default=>'select distrito from t_cmex_mesatrabajo where id = :p162_id_cmex_mesatrabajo'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Puerto Destino'
,p_source=>'PUERTODES'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select distinct valor dis, valor ret from t_corp_udc where id_cabecera = ''CMEX_BDGS'' and trim(valor) is not null order by 1'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_display_when=>'P162_CODIGOMODULO'
,p_display_when2=>'EXP'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20241105031105Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76180694751894136)
,p_name=>'P162_USERCREA'
,p_item_sequence=>460
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_use_cache_before_default=>'NO'
,p_source=>'USERCREA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76181081722894137)
,p_name=>'P162_FECHACREA'
,p_item_sequence=>470
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_use_cache_before_default=>'NO'
,p_source=>'FECHACREA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76181805572894137)
,p_name=>'P162_USERMODI'
,p_item_sequence=>480
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_use_cache_before_default=>'NO'
,p_source=>'USERMODI'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76182294057894137)
,p_name=>'P162_FECHAMODI'
,p_item_sequence=>490
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_use_cache_before_default=>'NO'
,p_source=>'FECHAMODI'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76183065074894139)
,p_name=>'P162_ID_CMEX_MESATRABAJO'
,p_item_sequence=>390
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_use_cache_before_default=>'NO'
,p_source=>'ID_CMEX_MESATRABAJO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(78325734994948345)
,p_name=>'P162_PROVEEDOR_DISPLAY'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Proveedor'
,p_source=>'P162_CODIGOPROVEEDOR'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_JDE_LIBRODIRECCIONES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DISTINCT nombres as r,',
'       codigo as d',
'  from VT_JDE_LIBRODIRECCIONES',
' order by 1'))
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(78326221681948350)
,p_name=>'P162_TIPOMERCA_DISPLAY'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_prompt=>'Tipo Mercaderia'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P162_CODIGOMODULO'
,p_display_when2=>'EXP'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20241105031105Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79241794802195202)
,p_name=>'P162_TIPOREGISTRO'
,p_item_sequence=>500
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_use_cache_before_default=>'NO'
,p_item_default=>'PROVISION'
,p_source=>'TIPOREGISTRO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79242168482195206)
,p_name=>'P162_ID_GRUPO'
,p_item_sequence=>510
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_use_cache_before_default=>'NO'
,p_source=>'ID_GRUPO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79242533495195210)
,p_name=>'P162_ORDENAGENTE_DISPLAY'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Orden Agente'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79242606048195211)
,p_name=>'P162_REFERENDO_DISPLAY'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Referendo'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93113119176453127)
,p_name=>'P162_ACCION'
,p_item_sequence=>520
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93113310230453129)
,p_name=>'P162_MTOOI'
,p_item_sequence=>370
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_use_cache_before_default=>'NO'
,p_item_default=>'select montooc from t_cmex_mesatrabajo where id = :p162_id_cmex_mesatrabajo'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>unistr('Monto Tr\00E1mite')
,p_source=>'MTOOI'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_display_when=>':P162_ORDENCOMPRA LIKE ''OI%'''
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'decimal'
,p_updated_on=>wwv_flow_imp.dz('20241105033256Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(188777454297282702)
,p_name=>'P162_MENSAJE'
,p_item_sequence=>540
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_prompt=>unistr('Requisici\00F3n: ')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>':P162_ORDENCOMPRA LIKE ''IMP%'''
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(188777520080282703)
,p_name=>'P162_CONTADOR'
,p_item_sequence=>550
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(210982241714024547)
,p_name=>'P162_MODULO_EXT'
,p_item_sequence=>530
,p_item_plug_id=>wwv_flow_imp.id(76166753351894109)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(497404774596544407)
,p_name=>'P162_EXP_DESTINO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(497404518976544405)
,p_prompt=>'Destino:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20241108161541Z')
,p_updated_on=>wwv_flow_imp.dz('20241108161541Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(497404803395544408)
,p_name=>'P162_EXP_INCOTERM'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(497404518976544405)
,p_prompt=>'Incoterm:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20241108161541Z')
,p_updated_on=>wwv_flow_imp.dz('20241108162111Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(497404933479544409)
,p_name=>'P162_EXP_NAVIERA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(497404518976544405)
,p_prompt=>'Naviera:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20241108161541Z')
,p_updated_on=>wwv_flow_imp.dz('20241108161541Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(497405120928544411)
,p_name=>'P162_EXP_TRANSPORTISTA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(497404518976544405)
,p_prompt=>unistr('C\00EDa. Transp.:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20241108161541Z')
,p_updated_on=>wwv_flow_imp.dz('20241108161642Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(497405213560544412)
,p_name=>'P162_EXP_CONTENEDORES'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(497404518976544405)
,p_prompt=>'Cant. Contenedores:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20241108161541Z')
,p_updated_on=>wwv_flow_imp.dz('20241108161541Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(497405330065544413)
,p_name=>'P162_EXP_FACTURAS'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(497404518976544405)
,p_prompt=>'Facturas:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20241108161541Z')
,p_updated_on=>wwv_flow_imp.dz('20241108161642Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(497405471354544414)
,p_name=>'P162_EXP_FECZARPE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(497404518976544405)
,p_prompt=>'Fecha Zarpe:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20241108161541Z')
,p_updated_on=>wwv_flow_imp.dz('20241108161541Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(497405543298544415)
,p_name=>'P162_EXP_FECETA'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(497404518976544405)
,p_prompt=>'Fecha ETA:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20241108161541Z')
,p_updated_on=>wwv_flow_imp.dz('20241108161642Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(497405637027544416)
,p_name=>'P162_EXP_FECINGRESO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(497404518976544405)
,p_prompt=>'Fecha Ingreso:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20241108161541Z')
,p_updated_on=>wwv_flow_imp.dz('20241108161642Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(76181570462894137)
,p_validation_name=>'P162_FECHACREA must be timestamp'
,p_validation_sequence=>300
,p_validation=>'P162_FECHACREA'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>'#LABEL# must be a valid timestamp.'
,p_associated_item=>wwv_flow_imp.id(76181081722894137)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(76182735803894139)
,p_validation_name=>'P162_FECHAMODI must be timestamp'
,p_validation_sequence=>320
,p_validation=>'P162_FECHAMODI'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>'#LABEL# must be a valid timestamp.'
,p_associated_item=>wwv_flow_imp.id(76182294057894137)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(78325878091948346)
,p_name=>'CargarDatos'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P162_ORDENCOMPRA'
,p_condition_element=>'P162_ORDENCOMPRA'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_updated_on=>wwv_flow_imp.dz('20241127194141Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(78325927863948347)
,p_event_id=>wwv_flow_imp.id(78325878091948346)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	if :p162_ordencompra is not null then',
'		if :p162_codigomodulo = ''IMP'' then',
'			select codigoproveedor,ordenagente,ordenagente,id',
'			into :p162_codigoproveedor,:p162_ordenagtadn,:p162_ordenagente_display,:p162_id_cmex_mesatrabajo',
'			from data.vt_cmex_mesatrabajo where tipooc ||''-''||ordencompra = :p162_ordencompra or trim(idproceso) = :p162_ordencompra;',
'',
'			select distinct nombres into :p162_proveedor_display',
'			from vt_jde_librodirecciones ',
'			where codigo = :p162_codigoproveedor;',
'',
'			select tipomercaderia into :p162_tipomerca',
'			from data.t_cmex_datoscomplementarios',
'			where id_cmex_mesatrabajo = :p162_id_cmex_mesatrabajo;',
'',
'			select upper(drdl01)||'' (''||drky||'')'' into :p162_tipomerca_display',
'			from data.vt_jde_udcjde',
'			where drsy = ''41'' and drrt = ''9'' and drky = :p162_tipomerca;',
'',
'			select refrendo,refrendo,fechapago_liq into :p162_referendo,:p162_referendo_display,:p162_fechaliqadn',
'			from data.t_cmex_tramitesaduana',
'			where id_cmex_mesatrabajo = :p162_id_cmex_mesatrabajo;',
'		else',
'			select cliente,refrendo,refrendo',
'			into :p162_codigoproveedor,:p162_referendo,:p162_referendo_display',
'			from data.t_cmex_exportacion where 1 = 1 and to_char(''EXP-''||registro) = :p162_ordencompra;',
'/*',
'			select codigoproveedor, ordenagente, ordenagente, id',
'			into :p162_codigoproveedor,:p162_ordenagtadn,:p162_ordenagente_display,:p162_id_cmex_mesatrabajo',
'			from data.t_cmex_mesatrabajo ',
'			where csconvert(codigomodulo||''-''|| lpad(id,5,''0''),''NCHAR_CS'') = :p162_ordencompra;',
'*/',
'			select distinct nombres into :p162_proveedor_display',
'			from vt_jde_librodirecciones ',
'			where codigo = :p162_codigoproveedor;',
'/*',
'			select refrendo, refrendo',
'			into :p162_referendo,:p162_referendo_display',
'			from data.t_cmex_tramitesaduana',
'			where id_cmex_mesatrabajo = :p162_id_cmex_mesatrabajo;',
'*/',
'		end if;',
'	else',
'		:p162_codigoproveedor:= null;',
'		:p162_ordenagtadn:= null;',
'		:p162_id_cmex_mesatrabajo:= null;',
'		:p162_proveedor_display:= null;',
'		:p162_tipomerca:= null;',
'		:p162_tipomerca_display:= null;',
'		:p162_referendo:= null;',
'	end if;',
'end;'))
,p_attribute_02=>'P162_ORDENCOMPRA'
,p_attribute_03=>'P162_CODIGOPROVEEDOR,P162_ORDENAGTADN,P162_ID_CMEX_MESATRABAJO,P162_TIPOMERCA,P162_REFERENDO,P162_PROVEEDOR_DISPLAY,P162_TIPOMERCA_DISPLAY,P162_ORDENAGENTE_DISPLAY,P162_REFERENDO_DISPLAY,P162_FECHALIQADN'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20241127194141Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(79242752456195212)
,p_name=>'Ejecutar'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(79242395099195208)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_updated_on=>wwv_flow_imp.dz('20241105015254Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79242840434195213)
,p_event_id=>wwv_flow_imp.id(79242752456195212)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEst\00E1 seguro de enviar la liquidaci\00F3n?')
,p_attribute_03=>'information'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(187249426653684743)
,p_event_id=>wwv_flow_imp.id(79242752456195212)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_contador	number := 0;',
'v_idprov	number;',
'begin',
'	if :p162_ordencompra like ''IMP%'' and :p162_fechaciecst is not null then',
'		v_idprov := :p162_id;',
'',
'		select count(*) into v_contador',
'		from t_cmex_provision_detalle',
'		where id_cabecera=v_idprov',
'		and montoprovision > 0 and proveedor is not null and requisicion is not null;',
'',
'		if v_contador > 0 then',
'			update t_cmex_provision set estado = ''PROCESADO'' where id = v_idprov;',
'',
'			update t_cmex_mesatrabajo set codigoetapa = ''ET7''',
'			where id = (select id_cmex_mesatrabajo from t_cmex_provision where id = v_idprov);',
'		end if;',
'	end if;',
'end;'))
,p_attribute_02=>'P162_ID,P162_ORDENCOMPRA,P162_FECHACIECST'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20241105015254Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79242926945195214)
,p_event_id=>wwv_flow_imp.id(79242752456195212)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'PROCESAR'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(93113524435453131)
,p_name=>'APRUEBA'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(93112821291453124)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(93113642219453132)
,p_event_id=>wwv_flow_imp.id(93113524435453131)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P162_ACCION'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(93113741340453133)
,p_event_id=>wwv_flow_imp.id(93113524435453131)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'APROBAR_FLUJO'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(93113846309453134)
,p_name=>'RECHAZAR'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(93112993374453125)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(93113932667453135)
,p_event_id=>wwv_flow_imp.id(93113846309453134)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P162_ACCION'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(93114044925453136)
,p_event_id=>wwv_flow_imp.id(93113846309453134)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'RECHAZAR_FLUJO'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(94274072134663842)
,p_name=>'Etiquetas'
,p_event_sequence=>50
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>':P162_CODIGOMODULO = ''EXP'''
,p_display_when_cond2=>'PLSQL'
,p_updated_on=>wwv_flow_imp.dz('20241105033112Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94274131972663843)
,p_event_id=>wwv_flow_imp.id(94274072134663842)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#P162_PROVEEDOR_DISPLAY_LABEL").text("Cliente");',
'',
'',
''))
,p_updated_on=>wwv_flow_imp.dz('20241105033112Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(94274289232663844)
,p_name=>'OcultarCampos'
,p_event_sequence=>60
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>':P162_CODIGOMODULO = ''EXP'''
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94274382528663845)
,p_event_id=>wwv_flow_imp.id(94274289232663844)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P162_FECHALIQADN,P162_TIPOMERCA_DISPLAY,P162_ORDENAGENTE_DISPLAY,P162_FECHACIECST'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(37859518382753922)
,p_name=>'Atar'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(37859479961753921)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_updated_on=>wwv_flow_imp.dz('20241127182505Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37859635411753923)
,p_event_id=>wwv_flow_imp.id(37859518382753922)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37859799649753924)
,p_event_id=>wwv_flow_imp.id(37859518382753922)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_idmesa        number;',
'v_ordencompra   number;',
'v_idprov        number;',
'v_log_app		varchar2(100);',
'v_log_dsc		varchar2(999);',
'begin',
'	v_idprov    := :p162_id;',
'	v_log_app	:= ''apex.130.162.atar'';',
'	v_log_dsc	:= ''Variables: v_idprov: ''||v_idprov;',
'	data.pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,null,null,null); commit;',
'',
'	select a.id,a.ordencompra into v_idmesa,v_ordencompra',
'	from t_cmex_mesatrabajo a inner join t_cmex_provision b on a.id = b.id_cmex_mesatrabajo where b.id = v_idprov and rownum = 1;',
'',
'	v_log_dsc	:= ''Variables: v_idmesa: ''||v_idmesa||'', v_ordencompra: ''||v_ordencompra;',
'	data.pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,null,null,null); commit;',
'',
'	pk_cmex_mesatrabajo.sp_vincularordenimportacion(:g_compania,v_idmesa,v_ordencompra);',
'	commit;',
'end;'))
,p_attribute_02=>'P162_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20241127182504Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37859811438753925)
,p_event_id=>wwv_flow_imp.id(37859518382753922)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(64131815442537805)
,p_name=>'Cargar Gastos Adicionales'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(64131716147537804)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(64131984318537806)
,p_event_id=>wwv_flow_imp.id(64131815442537805)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(64132054301537807)
,p_event_id=>wwv_flow_imp.id(64131815442537805)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_idmesa number;',
'begin',
'	v_idmesa := :p162_id_cmex_mesatrabajo;',
'	pk_cmex_mesatrabajo.sp_gastosadicionales(:g_compania,:app_user,v_idmesa);',
'end;'))
,p_attribute_02=>'P162_ID_CMEX_MESATRABAJO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(64132111437537808)
,p_event_id=>wwv_flow_imp.id(64131815442537805)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(92023171441888203)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(64132206190537809)
,p_event_id=>wwv_flow_imp.id(64131815442537805)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(187249694628684745)
,p_name=>'Validar'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(187249505774684744)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(187249721557684746)
,p_event_id=>wwv_flow_imp.id(187249694628684745)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'   V_CONTADOR   NUMBER :=0;   ',
'BEGIN',
unistr('    -- Verifico que existan datos para generar la requisici\00F3n'),
'    SELECT COUNT(*) INTO V_CONTADOR',
'    FROM T_CMEX_PROVISION_DETALLE',
'    WHERE ID_CABECERA=:P162_ID',
'    AND MONTOPROVISION>0 AND PROVEEDOR IS NOT NULL AND REQUISICION IS NULL;',
'',
'    :P162_CONTADOR:=V_CONTADOR;',
'',
'    IF V_CONTADOR=0 THEN',
'       :P162_MENSAJE:=''No exsiten datos para generar requisiciones.'';',
'     --  raise_application_error (-20001,''No exsiten datos para generar requisiciones.'');',
'    END IF;',
' ',
'END;'))
,p_attribute_02=>'P162_ID'
,p_attribute_03=>'P162_CONTADOR,P162_MENSAJE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(187249859528684747)
,p_name=>'Confimar'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(187249505774684744)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(187249971671684748)
,p_event_id=>wwv_flow_imp.id(187249859528684747)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Est\00E1 seguro de iniciar el proceso de generaci\00F3n?')
,p_attribute_02=>unistr('Genera Requisici\00F3n')
,p_attribute_03=>'danger'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(187250097793684749)
,p_event_id=>wwv_flow_imp.id(187249859528684747)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(187250165323684750)
,p_event_id=>wwv_flow_imp.id(187249859528684747)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'Ejecutar'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'   V_RESPUESTA  VARCHAR2(200);',
'   V_CONTADOR   NUMBER :=0;   ',
'BEGIN',
unistr('-- Verifico que existan datos para generar la requisici\00F3n'),
'--BEGIN',
'    SELECT COUNT(*) INTO V_CONTADOR',
'    FROM T_CMEX_PROVISION_DETALLE',
'    WHERE ID_CABECERA=:P162_ID',
'    AND MONTOPROVISION>0 AND PROVEEDOR IS NOT NULL AND REQUISICION IS NULL;',
'',
'  --EXCEPTION WHEN NO_DATA_FOUND THEN ',
'    -- raise_application_error (-20001,''No exsiten datos para generar requisiciones.'');',
'',
'--END;',
'',
'IF V_CONTADOR>0 THEN',
unistr('    -- se env\00EDa a generar la requisici\00F3n'),
'    pk_cmex_mesatrabajo.sp_generarequisicion(:G_COMPANIA,:APP_USER,:P162_ID,V_RESPUESTA);',
'',
'    :P162_MENSAJE:=V_RESPUESTA;',
'  ELSE',
'    :P162_MENSAJE:=''No exsiten datos para generar requisiciones.'';',
'END IF;',
' ',
'END;'))
,p_attribute_02=>'P162_ID'
,p_attribute_03=>'P162_MENSAJE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(188777379364282701)
,p_event_id=>wwv_flow_imp.id(187249859528684747)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(76183832614894140)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from T_CMEX_PROVISION'
,p_attribute_02=>'T_CMEX_PROVISION'
,p_attribute_03=>'P162_ID'
,p_attribute_04=>'ID'
,p_internal_uid=>76183832614894140
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(37860077282753927)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Ata OC Original'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_idmesa		number;',
'v_ordencompra	number;',
'v_idprov		number;',
'v_log_app		varchar2(100);',
'v_log_dsc		varchar2(999);',
'begin',
'	if :p162_estado != ''PENDIENTE'' then',
'		v_idprov	:= :p162_id;',
'		v_log_app	:= ''apex.130.162.atar'';',
'		v_log_dsc	:= ''Variables: v_idprov: ''||v_idprov;',
'		data.pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,null,null,null);',
'',
'		if :p162_codigomodulo = ''IMP'' then',
'			select a.id,a.ordencompra',
'			into v_idmesa,v_ordencompra',
'			from t_cmex_mesatrabajo a',
'			inner join t_cmex_provision b on a.id = b.id_cmex_mesatrabajo',
'			where 1 = 1',
'				and b.id = v_idprov',
'				and rownum = 1;',
'		elsif :p162_codigomodulo = ''EXP'' then',
'			select a.registro,a.registro orden',
'			into v_idmesa,v_ordencompra',
'			from data.t_cmex_exportacion a',
'			inner join t_cmex_provision b on a.registro = b.id_cmex_mesatrabajo',
'			where 1 = 1',
'				and b.id = v_idprov',
'				and rownum = 1;',
'',
'			-- Lleno los datos complementarios:',
'			begin',
'				select case',
'					when nvl(a.contenedores_20,0) = 0 and nvl(a.contenedores_40,0) = 0 then ''Carga Suelta''',
'					when nvl(a.contenedores_20,0) > 0 and nvl(a.contenedores_40,0) > 0 then ''CNT 20ft: ''||a.contenedores_20||'', CNT 40ft: ''||a.contenedores_40',
'					when nvl(a.contenedores_20,0) > 0 and nvl(a.contenedores_40,0) = 0 then ''CNT 20ft: ''||a.contenedores_20',
'					when nvl(a.contenedores_20,0) = 0 and nvl(a.contenedores_40,0) > 0 then ''CNT 40ft: ''||a.contenedores_40',
'					else ''~(o.0)~'' end contenedores',
'					, a.puerto_destino destino',
'					, a.pedidos facturas',
'					, b.eta_aprox feceta',
'					, to_char(b.fecha_registro,''dd/mm/yyyy'') fecingreso',
'					, b.fecha_zarpe_estimada feczarpe',
'					, b.incoterm',
'					, b.naviera',
'				into',
'				:p162_exp_contenedores',
'				, :p162_exp_destino',
'				, :p162_exp_facturas',
'				, :p162_exp_feceta',
'				, :p162_exp_fecingreso',
'				, :p162_exp_feczarpe',
'				, :p162_exp_incoterm',
'				, :p162_exp_naviera',
'				-- , :p162_exp_transportista',
'				from data.t_cmex_booking a',
'				inner join data.t_cmex_exportacion b on a.id = b.booking_id',
'				where 1 = 1',
'					and b.registro = to_char(v_idmesa);',
'',
'				exception when others then',
'					:p162_exp_contenedores := null;',
'					:p162_exp_destino := null;',
'					:p162_exp_facturas := null;',
'					:p162_exp_feceta := null;',
'					:p162_exp_fecingreso := null;',
'					:p162_exp_feczarpe := null;',
'					:p162_exp_incoterm := null;',
'					:p162_exp_naviera := null;',
'					:p162_exp_transportista := null;',
'			end;',
'		end if;',
'',
'		v_log_dsc	:= ''Variables: v_idmesa: ''||v_idmesa||'', v_ordencompra: ''||v_ordencompra;',
'		data.pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,null,null,null);',
'',
unistr('		-- la importaci\00F3n de muestras no se vinculan'),
'		if :p162_ordencompra like ''OI%'' then',
'			pk_cmex_mesatrabajo.sp_vincularordenimportacion(:g_compania,v_idmesa,v_ordencompra);',
'		end if;',
'	end if;',
'	commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>37860077282753927
,p_updated_on=>wwv_flow_imp.dz('20241127194235Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(79243015954195215)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Valida Interoperabilidad'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_contadorrubros	number; ',
'v_aprobado			number;',
'v_ejecutainteroperabilidad number;',
'v_log_dsc			varchar2(999);',
'v_idprovision		number;',
'v_modulo			varchar2(5);',
'v_idmesa			number;',
'v_flag				number;',
'v_log_app			varchar2(100);',
'begin',
'	v_log_app		:= ''apex.130.162.aprobacion'';',
'	v_idprovision	:= :p162_id;',
'	v_modulo		:= :p162_codigomodulo;',
'',
'	begin',
'		select id_cmex_mesatrabajo into v_idmesa from t_cmex_provision where id = v_idprovision;',
'',
'		exception when others then',
'			raise_application_error(-20001,''No hay registro asociado en la mesa de trabajo.'');',
'	end;',
'',
'	begin',
'		delete from t_cmex_provision_detalle',
'		where 1 = 1',
'			and id_cabecera = v_idprovision',
'			and ((v_modulo = ''IMP'' and nvl(montoprovision,0) = 0) or (v_modulo = ''EXP'' and nvl(montoreal,0) = 0));',
'',
'		with prv as (',
'			select concepto,count(1) cuenta from t_cmex_provision_detalle',
'			where id_cabecera = v_idprovision having count(1) > 1',
'		) select count(*) into v_flag from prv;',
'',
'		if v_flag != 0 then',
unistr('			raise_application_error(-20001,''Hay m\00E1s de un concepto/rubro que se repite.'');'),
'		end if;',
'',
'		exception when others then',
'			v_flag := -1;',
'	end;',
'',
'	/*-- Comprueba valores necesarios --*/',
'	if v_modulo = ''EXP'' then',
'		v_log_dsc := ''p162_codigomodulo = "EXP"'';',
'		pk_commons.sp_apex_log(v_log_app,1,v_log_dsc,null,null,null);',
'',
'		:p162_estado := ''PROCESADO'';',
'	elsif v_modulo = ''IMP'' then',
'		if 1 = 1',
'			and :p162_puertoori is not null',
'			and :p162_puertodes is not null',
'			and :p162_mtooi is not null',
'			and :p162_ordencompra is not null',
'			and :p162_fechaliqadn is not null',
'			and :p162_fechaciecst is not null then',
'			v_log_dsc := ''Ingresa al proceso'';',
'			pk_commons.sp_apex_log(v_log_app,1,v_log_dsc,null,null,null);',
'',
'			/*-- Contar errores en los datos --*/',
'			select count(1) into v_contadorrubros',
'			from data.t_cmex_provision_detalle where id_cabecera = v_idprovision and montoprovision >= 0;',
'',
'			/*-- Valida que existan rubros para la provision --*/',
'			if  v_contadorrubros < 1 then',
'				v_log_dsc := ''v_contadorrubros < 1'';',
'				pk_commons.sp_apex_log(v_log_app,2,v_log_dsc,null,null,null);',
'',
unistr('				raise_application_error(-20001,''No hay datos registrados para la provisi\00F3n.'');'),
'			end if;',
'',
'			-- Copia los valores estandar vigente en base al modulo interno de CMEX',
'			pk_cmex_mesatrabajo.sp_estandarprovisiones(p_idprovision => v_idprovision,p_codigomodulo => v_modulo);',
'',
'			data.pk_cmex_mesatrabajo.sp_provisionimp(:g_compania,:app_user,v_idprovision,:p162_id_batch);',
'',
'			-- Verifica resultado de la interoperabilidad y cambia estados',
'			v_log_dsc := '':p162_id_batch: ''||:p162_id_batch;',
'			pk_commons.sp_apex_log(v_log_app,3,v_log_dsc,null,null,null);',
'',
'			if :p162_id_batch is not null then',
'				:p162_estado := ''PROCESADO'';',
'			else',
'				raise_application_error(-20001,''Error en interoperabilidad'');',
'			end if;',
'		else',
unistr('			raise_application_error(-20001,''Debe completar toda la informaci\00F3n necesaria.'');'),
'		end if;',
'	end if;',
'',
'	v_log_dsc := ''Termina'';',
'	pk_commons.sp_apex_log(v_log_app,4,v_log_dsc,null,null,null);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(79242395099195208)
,p_internal_uid=>79243015954195215
,p_updated_on=>wwv_flow_imp.dz('20241230215838Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(79241994182195204)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Establece Valores'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    IF :P162_ORDENCOMPRA IS NULL THEN',
'        :P162_USERCREA := :APP_USER;',
'    END IF;',
'',
'    IF :P162_ID IS NULL THEN',
'        :P162_USERCREA := :APP_USER;',
'        :P162_FECHACREA := SYSDATE;',
'',
'        SELECT NVL(MAX(ID_GRUPO),0) + 1 INTO :P162_ID_GRUPO FROM DATA.T_CMEX_PROVISION;',
'    ELSE',
'       :P162_USERMODI := :APP_USER;',
'       :P162_FECHAMODI := SYSDATE;',
'    END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>79241994182195204
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(76184271692894140)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of T_CMEX_PROVISION'
,p_attribute_02=>'T_CMEX_PROVISION'
,p_attribute_03=>'P162_ID'
,p_attribute_04=>'ID'
,p_attribute_09=>'P162_ID'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'SAVE,CREATE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_process_success_message=>'Guardado Correcto'
,p_internal_uid=>76184271692894140
,p_updated_on=>wwv_flow_imp.dz('20241127195659Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(93113077989453126)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Aprobaci\00F3n/Rechazo')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_estado VARCHAR2(100);',
'BEGIN ',
'    IF :P162_ACCION = 1 THEN',
'        pk_cmex_mesatrabajo.SP_APROB_RECH_VARIACIONPROV(P_ID_PROV => :P162_ID, P_USUARIO => :APP_USER, P_MODULO => ''CMEX'', P_COMPANIA => :G_COMPANIA, P_ACCION => :P162_ACCION);',
'',
'        SELECT ESTADO INTO v_estado FROM T_CMEX_PROVISION WHERE ID = :P162_ID;',
'',
'        IF v_estado = ''APROBADO'' THEN ',
'            DATA.pk_cmex_mesatrabajo.SP_PROVISIONIMP (:G_COMPANIA, :APP_USER, :P162_ID, :P162_ID_BATCH);',
'',
'            IF :P162_ID_BATCH IS NOT NULL THEN :P162_ESTADO := ''PROCESADO''; ELSE  RAISE_APPLICATION_ERROR(-20001, ''Error en Interoperabilidad''); END IF;',
'        END IF;',
'    ELSE',
'        pk_cmex_mesatrabajo.SP_APROB_RECH_VARIACIONPROV(P_ID_PROV => :P162_ID, P_USUARIO => :APP_USER, P_MODULO => ''CMEX'', P_COMPANIA => :G_COMPANIA, P_ACCION => :P162_ACCION);',
'    END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'APROBAR_FLUJO,RECHAZAR_FLUJO'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>93113077989453126
,p_updated_on=>wwv_flow_imp.dz('20241230215913Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(79242291380195207)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Aprobado'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_mensaje		clob;',
'v_asunto		varchar2(150);',
'v_desti			varchar2(200);',
'v_remitente		varchar2(100);',
'v_estado		varchar2(100);',
'v_idprov		number;',
'v_idmesa		number;',
'v_incoterm		varchar2(50);',
'v_ordenori		varchar2(99);',
'v_batch			varchar2(99);',
'v_ordencmp		varchar2(25);',
'v_modulo		varchar2(10);',
'v_proveedor		varchar2(99);',
'v_urladj		varchar2(99);',
'v_log_app		varchar2(99);',
'v_log_dsc		varchar2(999);',
'v_fechaliq 		varchar2(50);',
'v_numliqui 		varchar2(50);',
'v_refrendo 		varchar2(50);',
'v_facturas 		varchar2(99);',
'v_pedidos 		varchar2(99);',
'v_fecharfr		date;',
'v_log_qty		number;',
'v_booking		number;',
'v_aux_tx1		varchar(100);',
'begin',
'	v_idprov	:= :p162_id;',
'	v_batch		:= :p162_id_batch;',
'	v_ordencmp	:= :p162_ordencompra;',
'	v_modulo	:= :p162_codigomodulo;',
'	v_estado	:= :p162_estado;',
'	v_log_app	:= ''apex.130.162.notificacion'';',
unistr('	v_log_dsc	:= ''Par\00E1metros: v_idprov: ''||v_idprov||'', v_batch: ''||v_batch||'', v_ordencmp: ''||v_ordencmp||'', v_modulo: ''||v_modulo;'),
'',
'	pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,null,null,null);',
'',
'	if v_estado in (''PROCESADO'',''EN RUTA'') then',
'		update t_cmex_provision set estado = v_estado,id_batch = v_batch where id = v_idprov;',
'		v_log_qty := sql%rowcount;',
'	end if;',
'',
'	if v_estado = ''PROCESADO'' then',
'		v_mensaje := null;',
'		v_mensaje := ''<html><head>',
'							<style type="text/css">body{font-family: Arial, Helvetica, sans-serif;',
'							font-size:10pt; margin:30px; background-color:#ffffff;}',
'							span.sig{font-style:italic;font-weight:bold;color:#811919;}}',
'							</style>',
'							</head><meta charset="UTF-8"><body>''||utl_tcp.crlf;',
'		if v_modulo = ''IMP'' then',
'			select a.id idmesa',
'				, trim(d.abalph) proveedor',
'				, phfrth incoterm',
'				, listagg(c.tipoorig||''-''||c.ordenori, ''; '') within group (order by c.ordenori,c.tipoorig) ocos',
'			into v_idmesa,v_proveedor,v_incoterm,v_ordenori',
'			from t_cmex_mesatrabajo a',
'			inner join t_cmex_provision b on a.id = b.id_cmex_mesatrabajo',
'			inner join t_cmex_ordenesvinculadas c on a.id = c.idmesa',
'			inner join f0101@jdedtadl d on a.codigoproveedor = d.aban8',
'			left join f4301@jdedtadl e on a.ordencompra = e.phdoco and a.tipooc = e.phdcto',
'			where b.id = v_idprov',
'			group by a.id,trim(d.abalph),phfrth;',
'',
'			begin',
'				select to_char(fechapago_liq,''dd/mm/yyyy''),numeroliquidacion,refrendo into v_fechaliq,v_numliqui,v_refrendo from data.t_cmex_tramitesaduana where id_cmex_mesatrabajo = v_idmesa and rownum = 1;',
'',
'				exception when others then v_fechaliq := null; v_numliqui := null; v_refrendo := null;',
'			end;',
'',
'			select dominio||''/apex/f?p=130:188:::YES::P188_ID_TABLA:''||v_idmesa into v_urladj from data.t_admi_modulo where codigo = ''CMEX'';',
'',
unistr('			v_mensaje := ''<p>Estimado Usuario,</p><p>se ha registrado la Provisi\00F3n de Gastos de la Orden de Importaci\00F3n <strong>''||v_ordencmp||''</strong>.</p>''||utl_tcp.crlf;'),
'			v_mensaje := v_mensaje || ''<p><strong>Batch</strong>: ''||v_batch||''</p>''||utl_tcp.crlf;',
'			v_mensaje := v_mensaje || ''<p><strong>Orden Original</strong>: ''||v_ordenori||''</p>''||utl_tcp.crlf;',
'',
'			if pk_cmex_mesatrabajo.f_ordenesvinculadas(v_idmesa) = 1 then',
'				select listagg(distinct ordenimp, '', '') into v_aux_tx1 from t_cmex_ordenesvinculadas where idmesa = v_idmesa;',
unistr('				v_mensaje := v_mensaje || ''<p><strong>\00D3rdenes Vinculadas</strong>: ''||v_aux_tx1||''</p>''||utl_tcp.crlf;'),
'			end if;',
'',
unistr('			v_mensaje := v_mensaje || ''<p><strong>T\00E9rminos de Negociaci\00F3n</strong>: ''||v_incoterm||''</p>''||utl_tcp.crlf;'),
unistr('			v_mensaje := v_mensaje || ''<p><strong>Fecha Liquidaci\00F3n</strong>: ''||nvl(v_fechaliq,''Sin Registro'')||''</p>''||utl_tcp.crlf;'),
unistr('			v_mensaje := v_mensaje || ''<p><strong>N\00FAmero Liquidaci\00F3n</strong>: ''||nvl(v_numliqui,''Sin Registro'')||''</p>''||utl_tcp.crlf;'),
'			v_mensaje := v_mensaje || ''<p><strong>Refrendo</strong>: ''||nvl(v_refrendo,''Sin Registro'')||''</p>''||utl_tcp.crlf;',
'			v_mensaje := v_mensaje || ''<p></p>''||utl_tcp.crlf;',
'			v_mensaje := v_mensaje || ''<p><a href="''||v_urladj||''">Ver Archivos</a></p>''||utl_tcp.crlf;',
'',
'			v_mensaje := v_mensaje || ''<p><small><strong>IDM</strong>: ''||lpad(v_idmesa,5,''0'')||''</small></p>''||utl_tcp.crlf;',
'			v_mensaje := v_mensaje || ''<p><small><strong>PRV</strong>: ''||lpad(v_idprov,5,''0'')||''</small></p>''||utl_tcp.crlf;',
'',
'			v_mensaje := v_mensaje||''</body>''||utl_tcp.crlf;',
'			v_mensaje := v_mensaje||''</html>''||utl_tcp.crlf;',
'',
'			update t_cmex_mesatrabajo set codigoetapa = ''ET7'' where id = :p162_id_cmex_mesatrabajo;',
'			v_log_qty := sql%rowcount;',
'		else',
'			v_idmesa := substr(v_ordencmp,5);',
'			begin',
'				begin',
'					with fac as (',
'						select distinct factura_tipo||''-''||factura_numero facturas, booking_id booking',
'						from data.vt_cmex_exportacion_facturas where exportacion_registro = v_idmesa',
'					) select listagg(facturas, ''; '') within group (order by facturas) facturas',
'						, max(booking)',
'					into v_facturas,v_booking',
'					from fac;',
'',
unistr('					v_pedidos := ''No se registr\00F3 pedidos.'';'),
'',
'					if nvl(v_booking,0) > 0 then',
'						select pedidos into v_pedidos from data.t_cmex_booking where id = v_booking;',
'					end if;',
'',
unistr('					exception when others then v_facturas := ''No se registr\00F3 facturas.'';'),
'				end;',
'',
'				select cliente||'' - ''||cliente_nombres cliente',
'					, incoterm_nombre',
'					, refrendo',
'					, refrendo_fecha',
'				into v_proveedor, v_incoterm, v_refrendo, v_fecharfr',
'				from data.vt_cmex_exportacion_mesa_trabj where registro = v_idmesa;',
'			end;',
'',
unistr('			v_mensaje := ''<p>Estimado Usuario,</p><p>se ha registrado Costos de Exportaci\00F3n: <strong>''||v_ordencmp||''</strong>.</p>''||utl_tcp.crlf;'),
'			v_mensaje := v_mensaje || ''<p><strong>Proceso</strong>: ''			||v_idmesa		||''</p>''||utl_tcp.crlf;',
'			v_mensaje := v_mensaje || ''<p><strong>Cliente</strong>: ''			||v_proveedor	||''</p>''||utl_tcp.crlf;',
'			v_mensaje := v_mensaje || ''<p><strong>Pedido</strong>: ''			||v_pedidos		||''</p>''||utl_tcp.crlf;',
'			v_mensaje := v_mensaje || ''<p><strong>Factura</strong>: ''			||v_facturas	||''</p>''||utl_tcp.crlf;',
'			v_mensaje := v_mensaje || ''<p><strong>Incoterm</strong>: ''			||v_incoterm	||''</p>''||utl_tcp.crlf;',
'			v_mensaje := v_mensaje || ''<p><strong>Refrendo</strong>: ''			||v_refrendo	||''</p>''||utl_tcp.crlf;',
'			v_mensaje := v_mensaje || ''<p><strong>Fecha Refrendo</strong>: ''	||v_fecharfr	||''</p>''||utl_tcp.crlf;',
'			v_mensaje := v_mensaje || ''<p></p>''||utl_tcp.crlf;',
'',
'			v_mensaje := v_mensaje || ''<p><small><strong>IDM</strong>: ''||v_idmesa||''</small></p>''||utl_tcp.crlf;',
'			v_mensaje := v_mensaje || ''<p><small><strong>PRV</strong>: ''||lpad(v_idprov,5,''0'')||''</small></p>''||utl_tcp.crlf;',
'',
'			v_mensaje := v_mensaje||''</body>''||utl_tcp.crlf;',
'			v_mensaje := v_mensaje||''</html>''||utl_tcp.crlf;',
'',
'			update data.t_cmex_exportacion set estado = ''ARRIBADO'' where registro = v_idmesa;',
'		end if;',
'',
'		v_log_dsc := ''v_log_qty: ''||v_log_qty;',
'		pk_commons.sp_apex_log(v_log_app,1,v_log_dsc,null,null,null);',
'',
'		select pk_cmex_mesatrabajo.f_obtenerremitente_correo(''CMEX_NOTIF'',''R'') into v_remitente from dual;',
'',
'		if v_modulo = ''IMP'' and v_log_qty > 0 then',
unistr('			v_asunto := v_modulo||'' - Provisi\00F3n Registrada: ''||v_ordencmp||'' ''||v_proveedor;'),
'',
unistr('			pk_commons.sp_apex_log(v_log_app,2,''Provisi\00F3n: ''||v_idprov,v_asunto,null,null);'),
'',
'			select listagg(valor,'','') within group (order by id_tabla) correos into v_desti from data.t_corp_udc where id_cabecera = ''CMEX_NOT_D'' and valor2 = ''CMEX.PROVISION.ALIAS.130.162'';',
'		elsif v_modulo = ''EXP'' then',
unistr('			v_asunto := v_modulo||'' - Costos de Exportaci\00F3n: ''||v_idmesa||'' ''||v_proveedor;'),
'',
unistr('			pk_commons.sp_apex_log(v_log_app,2,''Costos de Exportaci\00F3n: ''||v_idprov,v_asunto,null,null);'),
'',
'			v_desti := ''ddelacruz@zaimella.com'';',
'		end if;',
'',
'		data.pk_commons.sp_apex_correohtml(v_mensaje,v_mensaje);',
'',
'		data.pk_commons.sp_apex_correo(',
'			p_aplicacion		=> v_log_app',
'			, p_remitente		=> v_remitente',
'			, p_para			=> v_desti',
'			, p_concopia		=> null',
'			, p_concopiaoculta	=> null',
'			, p_asunto			=> v_asunto',
'			, p_contenido		=> v_mensaje',
'		);',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'PROCESAR,APROBAR_FLUJO'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>79242291380195207
,p_updated_on=>wwv_flow_imp.dz('20250109172155Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(76184632990894140)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(76167370077894111)
,p_internal_uid=>76184632990894140
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(201054939788262402)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Habilitar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	-- Habilita el ingreso de provisiones cuando el usuario comete errores',
'	update t_cmex_provision set estado = ''INGRESADO'', id_batch = null where id = :p162_id;',
'',
'	update t_cmex_mesatrabajo set codigoetapa = ''ET6'' where id = :p162_id_cmex_mesatrabajo;',
'	commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(201054841307262401)
,p_internal_uid=>201054939788262402
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(188779144331282719)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(92023171441888203)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Form Tabular Detalle - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>188779144331282719
);
wwv_flow_imp.component_end;
end;
/
