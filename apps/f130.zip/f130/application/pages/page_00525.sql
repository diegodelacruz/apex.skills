prompt --application/pages/page_00525
begin
--   Manifest
--     PAGE: 00525
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>525
,p_name=>'COMEX - Verificadora'
,p_alias=>'COMEX-VERIFICADORA'
,p_step_title=>'COMEX - Verificadora'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_rejoin_existing_sessions=>'Y'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20241024191448Z')
,p_last_updated_on=>wwv_flow_imp.dz('20241017160711Z')
,p_last_updated_by=>'DCUEVA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(343096077093052180)
,p_plug_name=>'Verificadora'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295639738305037692)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(343097026825056502)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(343098652728056518)
,p_plug_name=>'CABECERA'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(343098799665056519)
,p_plug_name=>'DOCUMENTOS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    TIPO_DESCRIPCION,',
'    NUMEROARCHIVO,',
'    TO_CHAR(FECHA, ''DD/MM/YYYY HH24:MI'') AS FECHA,',
'    FILENAME',
'    ',
'FROM VT_CMEX_DATOS_GESTION_DOCMTOS ',
'WHERE ',
'    TIPO IN (''FACTURA'',''LISTA_EMPAQUE'',''DESPACHO_EXPORT'')',
'        AND',
'    ID=:P525_DATOS_GESTION_DET_ID',
'ORDER BY TIPO;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'DOCUMENTOS'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(343098829084056520)
,p_max_row_count=>'1000000'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>343098829084056520
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(343099261982056524)
,p_db_column_name=>'FECHA'
,p_display_order=>10
,p_column_identifier=>'C'
,p_column_label=>'Fecha'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(343099070191056522)
,p_db_column_name=>'TIPO_DESCRIPCION'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Documento'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(343099120279056523)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Archivo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment:#FILENAME#:FILES'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(343099492202056526)
,p_db_column_name=>'FILENAME'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(344506298824302946)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3445063'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'TIPO_DESCRIPCION:NUMEROARCHIVO:'
,p_created_on=>wwv_flow_imp.dz('20241024191448Z')
,p_updated_on=>wwv_flow_imp.dz('20241024191448Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(343100113366056533)
,p_plug_name=>'OTROS ARCHIVOS'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(343100361325056535)
,p_plug_name=>'ARCHIVOS'
,p_parent_plug_id=>wwv_flow_imp.id(343100113366056533)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    NUMEROARCHIVO,',
'    FILENAME,',
'    NUMEROARCHIVO AS ICONO_BORRAR',
'FROM   ',
'    FILES.T_APEX_ARCHIVOS ',
'WHERE ',
'    TABLA    = ''T_CMEX_DATOS_GESTION_DETALLE'' ',
'        AND',
'    ID_TABLA = TO_CHAR(:P525_DATOS_GESTION_DET_ID)',
'        AND',
'    TIPO     = ''VERIFICADORA''',
'        AND     ',
'    NUMEROARCHIVO <> NVL(:P525_REPORTE_INSPECCION_ARCHVO, 0)',
';',
'            '))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'ARCHIVOS'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(343100480848056536)
,p_max_row_count=>'1000000'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>343100480848056536
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(343100721813056539)
,p_db_column_name=>'FILENAME'
,p_display_order=>10
,p_column_identifier=>'B'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(343100655854056538)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'OTROS ARCHIVOS'
,p_column_type=>'NUMBER'
,p_format_mask=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment:#FILENAME#:FILES'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(343100824090056540)
,p_db_column_name=>'ICONO_BORRAR'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'-'
,p_column_link=>'javascript:apex.item("P525_NUMEROARCHIVO_BORRAR").setValue("#ICONO_BORRAR#");'
,p_column_linktext=>'<span class="fa fa-trash"></span>'
,p_column_type=>'NUMBER'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(344546094236590479)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3445461'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMEROARCHIVO:ICONO_BORRAR:'
,p_created_on=>wwv_flow_imp.dz('20241024191448Z')
,p_updated_on=>wwv_flow_imp.dz('20241024191448Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(343101450581056546)
,p_plug_name=>unistr('REPORTE DE INSPECCI\00D3N')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_read_only_when=>'P525_EDITAR_VERIFICADORA'
,p_plug_read_only_when2=>'0'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(364781576276500909)
,p_plug_name=>unistr('REPORTE INSPECCI\00D3N')
,p_parent_plug_id=>wwv_flow_imp.id(343101450581056546)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    NUMEROARCHIVO,',
'    FILENAME',
'FROM   ',
'    FILES.T_APEX_ARCHIVOS ',
'WHERE ',
'    NUMEROARCHIVO = :P525_REPORTE_INSPECCION_ARCHVO',
';',
'            '))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('REPORTE INSPECCI\00D3N')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(364781646890500910)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>364781646890500910
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(364781744643500911)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>unistr('REPORTE DE INSPECCI\00D3N')
,p_column_type=>'NUMBER'
,p_format_mask=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment:#FILENAME#:FILES'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(364781807049500912)
,p_db_column_name=>'FILENAME'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(364930293717312145)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3649303'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMEROARCHIVO:'
,p_created_on=>wwv_flow_imp.dz('20241024191448Z')
,p_updated_on=>wwv_flow_imp.dz('20241024191448Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(343101641734056548)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(343101450581056546)
,p_button_name=>'GRABAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--success'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Grabar'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P525_EDITAR_VERIFICADORA'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-save'
,p_grid_column_attributes=>'style="text-align: right"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(364781228993500906)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(343100113366056533)
,p_button_name=>'SUBIR_OTROS_ARCHIVOS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--success'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Subir Otros Archivos'
,p_button_alignment=>'RIGHT'
,p_grid_column_attributes=>'style="text-align: right"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(343096943939056501)
,p_name=>'P525_EXPORTACION_REGISTRO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(343098652728056518)
,p_prompt=>'Registro'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(343097109343056503)
,p_name=>'P525_DATOS_GESTION_DET_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(343098652728056518)
,p_prompt=>'Cont. ID'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(343099544607056527)
,p_name=>'P525_CONTENEDOR_NUMERO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(343098652728056518)
,p_prompt=>'Contenedor'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(343099634721056528)
,p_name=>'P525_PEDIDOS'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(343098652728056518)
,p_prompt=>'Pedidos'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(343099772778056529)
,p_name=>'P525_FECHA_CARGUE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(343098652728056518)
,p_prompt=>'Fecha Cargue'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(343099846934056530)
,p_name=>'P525_TURNO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(343098652728056518)
,p_prompt=>'Turno'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(343099903491056531)
,p_name=>'P525_TRANSPORTISTA'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(343098652728056518)
,p_prompt=>'Transportista'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(343100206845056534)
,p_name=>'P525_UPLOAD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(343100113366056533)
,p_prompt=>'Otros Archivos'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_display_when=>'P525_EDITAR_VERIFICADORA'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'Y'
,p_attribute_12=>'INLINE'
,p_attribute_13=>'Seleccione otros archivos'
,p_attribute_15=>'50000'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(343100503530056537)
,p_name=>'P525_NUMEROARCHIVO_BORRAR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(343096077093052180)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(343101070459056542)
,p_name=>'P525_IDVEHICULO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(343098652728056518)
,p_prompt=>'Placa'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(343101130572056543)
,p_name=>'P525_ESTADO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(343098652728056518)
,p_prompt=>'Estado'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(343101350797056545)
,p_name=>'P525_EDITAR_VERIFICADORA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(343096077093052180)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF ',
'    UPPER(:APP_USER) = ''VERIFICADORA'' ',
'        AND ',
'    :P525_ESTADO IN (''COORDINACION'', ''TRANSITO'')',
'THEN ',
'    RETURN 1;',
'ELSE ',
'    RETURN 0;    ',
'END IF;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(343101548514056547)
,p_name=>'P525_REPORTE_INSPECCION_NUMERO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(343101450581056546)
,p_prompt=>unistr('Nr. Reporte Inspecci\00F3n')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>3
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(364781309907500907)
,p_name=>'P525_ARCHIVO_INSPECCION_UPLOAD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(343101450581056546)
,p_prompt=>'Archivo'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_display_when=>'P525_EDITAR_VERIFICADORA'
,p_display_when2=>'1'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
,p_attribute_13=>unistr('Seleccione el Reporte de Inspecci\00F3n')
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(364781453101500908)
,p_name=>'P525_REPORTE_INSPECCION_ARCHVO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(343096077093052180)
,p_prompt=>'New'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(364781999845500913)
,p_validation_name=>'UPLOAD'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P525_UPLOAD IS NULL THEN',
'    RETURN ''Debe seleccionar el o los archivos a subir'';',
'END IF;',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(364781228993500906)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(364782026296500914)
,p_validation_name=>'GRABAR'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P525_REPORTE_INSPECCION_NUMERO IS NULL THEN',
unistr('    RETURN ''Debe ingresar el N\00FAmero de Reporte de Inspecci\00F3n'';'),
'END IF;',
'',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(343101641734056548)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(344897241315246606)
,p_name=>'Eliminar Archivo'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P525_NUMEROARCHIVO_BORRAR'
,p_condition_element=>'P525_NUMEROARCHIVO_BORRAR'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(344897328097246607)
,p_event_id=>wwv_flow_imp.id(344897241315246606)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_EXPORTACION.SP_BORRA_ARCHIVO_VERIFICADORA(',
'    :P525_EXPORTACION_REGISTRO,',
'    :P525_DATOS_GESTION_DET_ID,',
'    :P525_NUMEROARCHIVO_BORRAR',
');'))
,p_attribute_02=>'P525_NUMEROARCHIVO_BORRAR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(344897432987246608)
,p_event_id=>wwv_flow_imp.id(344897241315246606)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P525_NUMEROARCHIVO_BORRAR'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(344897544779246609)
,p_event_id=>wwv_flow_imp.id(344897241315246606)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(343100361325056535)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(343100919045056541)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'UPLOAD'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P525_UPLOAD IS NOT NULL THEN',
'',
'    PK_CMEX_EXPORTACION.SP_CARGA_ARCHIVOS_VERIFICADORA(',
'        :P525_EXPORTACION_REGISTRO,',
'        :P525_DATOS_GESTION_DET_ID,',
'        :APP_USER',
'    );',
'',
'END IF;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(364781228993500906)
,p_internal_uid=>343100919045056541
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(343101799180056549)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GRABAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_EXPORTACION.SP_GRABA_INSUMO_VERIFICADORA(',
'    :P525_EXPORTACION_REGISTRO,',
'    :P525_DATOS_GESTION_DET_ID,',
'    :P525_REPORTE_INSPECCION_NUMERO,',
'    :APP_USER',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(343101641734056548)
,p_internal_uid=>343101799180056549
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(343100000334056532)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga Contenedor'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    CONTENEDOR_NUMERO,',
'    PEDIDOS,',
'    TRUNC(FECHA_PLAN_CARGUE) AS FECHA_CARGUE,',
'    ',
'    TURNO_ID       AS TURNO,',
'    TURNO_EMPRESA  AS TRANSPORTISTA,',
'    TURNO_IDVEHICULO,',
'',
'    REPORTE_INSPECCION_NUMERO,',
'    REPORTE_INSPECCION_ARCHIVO',
'    ',
'INTO',
'',
'    :P525_CONTENEDOR_NUMERO,',
'    :P525_PEDIDOS,',
'    :P525_FECHA_CARGUE,',
'',
'    :P525_TURNO,',
'    :P525_TRANSPORTISTA,',
'    :P525_IDVEHICULO,',
'',
'    :P525_REPORTE_INSPECCION_NUMERO,',
'    :P525_REPORTE_INSPECCION_ARCHVO',
'',
'FROM',
'    VT_CMEX_DATOS_GESTION_DETALLE',
'WHERE ',
'    ID = :P525_DATOS_GESTION_DET_ID;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>343100000334056532
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(343101235893056544)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga Registro'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ESTADO',
'INTO',
'      :P525_ESTADO',
'FROM  T_CMEX_EXPORTACION',
'WHERE REGISTRO = :P525_EXPORTACION_REGISTRO;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>343101235893056544
);
wwv_flow_imp.component_end;
end;
/
