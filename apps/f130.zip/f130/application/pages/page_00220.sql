prompt --application/pages/page_00220
begin
--   Manifest
--     PAGE: 00220
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>220
,p_name=>'Negociacion - Detalle extras'
,p_alias=>'NEGOCIACION-DATOS-EXTRA-DIALOGO'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Modificaci\00F3n Negociaci\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>' $(secItems).hide();'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.ui-dialog.t-Dialog-page--standard .ui-dialog-titlebar, .ui-dialog.t-Dialog-page--wizard .ui-dialog-titlebar {',
'    flex-shrink: 0;',
'    display: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'16'
,p_created_on=>wwv_flow_imp.dz('20240109210238Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260624155722Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(138962462732199241)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(138962530519199242)
,p_plug_name=>unistr('Cancelaci\00F3n de Negociaci\00F3n &P220_ID_NEGOCIACION.')
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(295630388916037685)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P220_TIPO'
,p_plug_display_when_cond2=>'1'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(138962726464199244)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning'
,p_plug_template=>wwv_flow_imp.id(295605160997037667)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(140161593386320827)
,p_plug_name=>unistr('Extensi\00F3n de Vigencia en Negociaci\00F3n &P220_ID_NEGOCIACION.')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P220_TIPO'
,p_plug_display_when_cond2=>'2'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20260624144700Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(138963267759199249)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(138962462732199241)
,p_button_name=>'Atras'
,p_button_static_id=>'btnAtras'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Atras'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(138963152335199248)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(138962462732199241)
,p_button_name=>'Continuar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Continuar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_confirm_message=>unistr('\00BFEsta seguro de continuar con la cancelaci\00F3n?')
,p_button_condition=>'P220_TIPO'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(140161763312320829)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(138962462732199241)
,p_button_name=>'Enviar'
,p_button_static_id=>'btnEnviar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Enviar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_confirm_message=>unistr('\00BFEsta seguro de continuar con el envio a flujo de aprobaci\00F3n?')
,p_button_condition=>'P220_TIPO'
,p_button_condition2=>'2'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-send-o'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(141064965668133025)
,p_branch_name=>'Go To Page 138'
,p_branch_action=>'f?p=&APP_ID.:138:&SESSION.::&DEBUG.::P138_ESTADO_FLUJO,P138_IRMESA:&P220_ESTADO_FLUJO.,1&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(138962829282199245)
,p_name=>'P220_ID_NEGOCIACION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(138962726464199244)
,p_prompt=>'Id Negociacion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(138962936297199246)
,p_name=>'P220_JUST_CANCELA'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(138962530519199242)
,p_prompt=>'Motivo:'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>120
,p_cMaxlength=>200
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(295682382356037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'Y'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140159016170320802)
,p_name=>'P220_TIPO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(138962726464199244)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140159356877320805)
,p_name=>'P220_ANULADO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(138962726464199244)
,p_prompt=>'Anulado'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140159768638320809)
,p_name=>'P220_VIGDESDE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(140161593386320827)
,p_prompt=>'Desde'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140159990455320811)
,p_name=>'P220_VIGHASTA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(140161593386320827)
,p_prompt=>'Hasta'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140160017668320812)
,p_name=>'P220_VIGNUEVA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(140161593386320827)
,p_prompt=>'Nuevo termino de vigencia'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'STATIC'
,p_attribute_04=>'&P220_VIGHASTAMIN.'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER'
,p_attribute_13=>'HIDDEN'
,p_attribute_14=>'1'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140161019439320822)
,p_name=>'P220_VIGHASTAMIN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(138962726464199244)
,p_prompt=>'Vighastamin'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140161456491320826)
,p_name=>'P220_OBJETO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(138962726464199244)
,p_prompt=>'Objeto'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140161652546320828)
,p_name=>'P220_JUST_VIGENCIA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(140161593386320827)
,p_prompt=>'Motivo:'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>3
,p_field_template=>wwv_flow_imp.id(295682382356037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260624144701Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140162040958320832)
,p_name=>'P220_ENVIO_EXITO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(138962726464199244)
,p_prompt=>'Envio Exito'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140162388738320835)
,p_name=>'P220_TERMINA_FLUJO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(138962726464199244)
,p_prompt=>'Termina Flujo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(141064762222133023)
,p_name=>'P220_TITULO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(138962726464199244)
,p_prompt=>'Titulo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(141065211947133028)
,p_name=>'P220_ESTADO_FLUJO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(138962726464199244)
,p_prompt=>'Estado Flujo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(138963029771199247)
,p_validation_name=>unistr('Justficaci\00F3n Cancela no vacio')
,p_validation_sequence=>10
,p_validation=>'P220_JUST_CANCELA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#LABEL# debe tener un valor',
''))
,p_always_execute=>'Y'
,p_validation_condition=>'P220_JUST_CANCELA'
,p_validation_condition_type=>'ITEM_IS_NULL'
,p_when_button_pressed=>wwv_flow_imp.id(138963152335199248)
,p_associated_item=>wwv_flow_imp.id(138962936297199246)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(140160274866320814)
,p_validation_name=>'Vigencia nueva no vacio'
,p_validation_sequence=>20
,p_validation=>'P220_VIGNUEVA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor'
,p_always_execute=>'Y'
,p_validation_condition=>'P220_TIPO'
,p_validation_condition2=>'2'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_when_button_pressed=>wwv_flow_imp.id(140161763312320829)
,p_associated_item=>wwv_flow_imp.id(140160017668320812)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(141065194190133027)
,p_validation_name=>unistr('Justficaci\00F3n Extencion no vacio')
,p_validation_sequence=>30
,p_validation=>'P220_JUST_VIGENCIA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(140161763312320829)
,p_associated_item=>wwv_flow_imp.id(140161652546320828)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(138963310030199250)
,p_name=>'Cierra Dialogo'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(138963267759199249)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140158983951320801)
,p_event_id=>wwv_flow_imp.id(138963310030199250)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(145672937463365219)
,p_name=>'Cerrar'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(138963152335199248)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(145673078847365220)
,p_event_id=>wwv_flow_imp.id(145672937463365219)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#btnAtras'').trigger("click");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(145673123918365221)
,p_name=>'Cerrar_1'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(140161763312320829)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_display_when_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(145673207591365222)
,p_event_id=>wwv_flow_imp.id(145673123918365221)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#btnAtras'').trigger("click");'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(140159124106320803)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Proceder Cambios'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'P_ID VARCHAR2(200);',
'P_OBJETO VARCHAR2(200);',
'P_OBJETODESCRIPCION VARCHAR2(500);',
'P_ORDENMONTO NUMBER;',
'P_ETAPA VARCHAR2(200);',
'P_USUARIO VARCHAR2(200);',
'P_TIPO1 VARCHAR2(200);',
'P_TIPO2 VARCHAR2(200);',
'P_TIPO3 VARCHAR2(200);',
'P_TIPO4 VARCHAR2(200);',
'P_TIPO5 VARCHAR2(200);',
'P_TIPO6 VARCHAR2(200);',
'P_TIPO7 VARCHAR2(200);',
'P_TIPO8 VARCHAR2(200);',
'P_TIPO9 VARCHAR2(200);',
'P_TIPO10 VARCHAR2(200);',
'P_CODIGOPAGINA VARCHAR2(200);',
'P_MODULO VARCHAR2(200);',
'P_COMPANIA VARCHAR2(200);',
'P_EXITO NUMBER;',
'P_TERMINOFLUJO NUMBER;',
'P_USUARIOAPROBADOR VARCHAR2(200);',
'V_FLUJOID NUMBER;',
'v_usuario		varchar2(50);',
'v_comentario	varchar2(4000);',
'v_tipo			number;',
'BEGIN',
'	p_id := :p220_id_negociacion;',
'	v_usuario := :app_user;',
'	v_tipo := :p220_tipo;',
'',
'	if v_tipo = 1 then',
'		v_comentario := substr(trim(:p220_just_cancela),1,3999);',
'	elsif v_tipo = 2 then',
'		v_comentario := substr(trim(:p220_just_vigencia),1,3999);',
'	end if;',
'',
'	P_COMPANIA := ''00001'';',
'	P_MODULO :=''COMP'';',
'	P_OBJETO := ''NEGOCIACIONEXP'';',
'	P_TIPO1 := ''NEGOCIACIONEXP'';',
'	P_CODIGOPAGINA :=''COMPP138'';',
'	P_USUARIO := v_usuario;',
'	P_TIPO2 := data.pk_comp_negociacion.f_rutaaprobacion(P_ID);',
unistr('	P_OBJETODESCRIPCION := ''Extensi\00F3n de vigencia de Negociaci\00F3n ''||to_char(p_id,''00000'');'),
'	P_ORDENMONTO := NULL;',
'	P_ETAPA := NULL;',
'	P_TIPO3 := NULL;',
'	P_TIPO4 := NULL;',
'	P_TIPO5 := NULL;',
'	P_TIPO6 := NULL;',
'	P_TIPO7 := NULL;',
'	P_TIPO8 := NULL;',
'	P_TIPO9 := NULL;',
'	P_TIPO10 := NULL;',
'',
'	if :p220_tipo = 1 then',
'		data.pk_comp_negociacion.sp_negocicacionanular(P_ID,v_usuario,v_comentario);',
unistr('		apex_application.g_print_success_message :=''Se ha cancelado la negociaci\00F3n:''||to_char(P_ID,''00000'');'),
'',
'		:p220_estado_flujo := ''CANCELADO'';',
'	elsif :p220_tipo = 2 then',
'		data.pk_corp_flujoaprobacion.sp_flujoenviar(',
'			P_ID => P_ID',
'			, P_OBJETO => P_OBJETO',
'			, P_OBJETODESCRIPCION => P_OBJETODESCRIPCION',
'			, P_ORDENMONTO => P_ORDENMONTO',
'			, P_ETAPA => P_ETAPA',
'			, P_USUARIO => P_USUARIO',
'			, P_COMENTARIO => v_comentario',
'			, P_TIPO1 => P_TIPO1',
'			, P_TIPO2 => P_TIPO2',
'			, P_TIPO3 => P_TIPO3',
'			, P_TIPO4 => P_TIPO4',
'			, P_TIPO5 => P_TIPO5',
'			, P_TIPO6 => P_TIPO6',
'			, P_TIPO7 => P_TIPO7',
'			, P_TIPO8 => P_TIPO8',
'			, P_TIPO9 => P_TIPO9',
'			, P_TIPO10 => P_TIPO10',
'			, P_CODIGOPAGINA => P_CODIGOPAGINA',
'			, P_MODULO => P_MODULO',
'			, P_COMPANIA => P_COMPANIA',
'			, P_EXITO => P_EXITO',
'		);',
'',
'		if p_exito in (1,2) then',
'			update data.t_comp_negociacion set vigenciahastaant = vigenciahasta where id = p_id;',
unistr('			update data.t_comp_negociacion set vigenciahasta = :p220_vignueva, observacion = substr(trim(observacion)||''<br/>Extensi\00F3n de Vigencia: ''||v_comentario,1,3999) where id = p_id;'),
'',
'			:p220_estado_flujo := ''EN RUTA'';',
'		end if;',
'',
'		if p_exito = 1 then ',
'			update data.t_comp_negociacion set usuarioflujo = p_usuarioaprobador, estadoflujo = ''EN_PROCESO'' where id = p_id;',
unistr('			apex_application.g_print_success_message := ''Enviado a flujo con \00E9xito.'';'),
'		elsif p_exito = 2 then',
'			update data.t_comp_negociacion set usuarioflujo = p_usuarioaprobador, estadoflujo = ''APROBADO'' where id = p_id;',
unistr('			apex_application.g_print_success_message := ''Aprobado flujo con \00E9xito.'';'),
'		elsif p_exito = 0 then',
'			apex_application.g_print_success_message := ''this.data.g_resultado.''||data.pk_corp_flujoaprobacion.g_mensaje;',
'			apex_error.add_error (p_message => data.pk_corp_flujoaprobacion.g_mensaje, p_display_location => apex_error.c_inline_in_notification);',
'		end if;',
'	end  if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>':P220_TIPO IN (1,2)'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>140159124106320803
,p_updated_on=>wwv_flow_imp.dz('20260624155722Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(140160328332320815)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (:P220_TIPO=1)then',
unistr('    :P220_TITULO:=''Cancelaci\00F3n Negociaci\00F3n No.''||:P220_ID_NEGOCIACION;'),
'end if;',
'if (:P220_TIPO=2)then',
'    select vigenciadesde,vigenciahasta ,vigenciahasta +1,vigenciahasta +1',
'    into :P220_VIGDESDE,:P220_VIGHASTA ,:P220_VIGNUEVA,:P220_VIGHASTAMIN',
'    from t_comp_negociacion ',
'    where id = :P220_ID_NEGOCIACION;',
unistr('    :P220_TITULO:=''Extencion de Vigencia Negociaci\00F3n No.''||:P220_ID_NEGOCIACION;'),
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>140160328332320815
);
wwv_flow_imp.component_end;
end;
/
