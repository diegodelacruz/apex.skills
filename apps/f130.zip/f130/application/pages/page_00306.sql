prompt --application/pages/page_00306
begin
--   Manifest
--     PAGE: 00306
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>306
,p_name=>unistr('Prom. d\00EDas Puerto')
,p_alias=>'PROM-DIAS-PUERTO'
,p_step_title=>'Prom. dias Puerto'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'	$(secItems).hide();'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Report-report thead {',
'  display: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'25'
,p_created_on=>wwv_flow_imp.dz('20240913133621Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240913170156Z')
,p_last_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(312508827411892574)
,p_plug_name=>'Reporte'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>60
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  CONTACONTENEDOR total_contenedor, OC, PROVEEDOR, CNT20PIES, CNT40PIES, CARGASUELTA, FECHAETA, FECHADESCARGUE, CONDUCTOR, FECHATURNO, DIAS_ESTADIA,motivoincplan,fechaduc , bodega',
'from vt_comp_cmex_promdiaspuerto',
'where trunc(fechaturno) between TRUNC(TO_DATE(:P306_DESDE)) AND LAST_DAY(TO_DATE(:P306_HASTA));   '))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P306_ANIO_MES'
,p_plug_column_width=>'style="text-wrap: nowrap;"'
,p_plug_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_plug_display_when_condition=>'P306_NUMEROREGISTROS'
,p_prn_page_header=>unistr('Tiempo Nacionalizaci\00F3n Importaciones')
,p_updated_on=>wwv_flow_imp.dz('20240913170156Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(312508966989892574)
,p_name=>unistr('Tiempo Nacionalizaci\00F3n Importaciones')
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>312508966989892574
,p_updated_on=>wwv_flow_imp.dz('20240913170156Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(312510533648892581)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Nombre de proveedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(312511774497892581)
,p_db_column_name=>'CARGASUELTA'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Carga Suelta'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(312512145353892582)
,p_db_column_name=>'FECHAETA'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Fecha Eta'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY HH24:MI:SS'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(312512925691892582)
,p_db_column_name=>'CONDUCTOR'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Conductor'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(312658837013131268)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(312513320482892582)
,p_db_column_name=>'FECHATURNO'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Fecha Turno'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY HH24:MI:SS'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(312513704707892583)
,p_db_column_name=>'DIAS_ESTADIA'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>unistr('Dias Estad\00EDa')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240913164614Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(312517985377894129)
,p_db_column_name=>'CNT20PIES'
,p_display_order=>32
,p_column_identifier=>'O'
,p_column_label=>'Cont. 20pies'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(312518054276894130)
,p_db_column_name=>'CNT40PIES'
,p_display_order=>42
,p_column_identifier=>'P'
,p_column_label=>'Cont. 40pies'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(312518170298894131)
,p_db_column_name=>'OC'
,p_display_order=>52
,p_column_identifier=>'Q'
,p_column_label=>unistr('N\00FAmero de OI')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(312518244941894132)
,p_db_column_name=>'MOTIVOINCPLAN'
,p_display_order=>62
,p_column_identifier=>'R'
,p_column_label=>'Motivo Inc. Plan'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(312518315862894133)
,p_db_column_name=>'FECHADUC'
,p_display_order=>72
,p_column_identifier=>'S'
,p_column_label=>'Fecha Ult. Cnt.'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(404092074641906643)
,p_db_column_name=>'TOTAL_CONTENEDOR'
,p_display_order=>82
,p_column_identifier=>'W'
,p_column_label=>'Total Contenedor'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240913165125Z')
,p_updated_on=>wwv_flow_imp.dz('20240913165125Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(404092137203906644)
,p_db_column_name=>'FECHADESCARGUE'
,p_display_order=>92
,p_column_identifier=>'X'
,p_column_label=>'Fechadescargue'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240913165125Z')
,p_updated_on=>wwv_flow_imp.dz('20240913165125Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(404092267942906645)
,p_db_column_name=>'BODEGA'
,p_display_order=>102
,p_column_identifier=>'Y'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240913170026Z')
,p_updated_on=>wwv_flow_imp.dz('20240913170026Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(312514507714893205)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3125146'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_view_mode=>'REPORT'
,p_report_columns=>'OC:PROVEEDOR:CNT20PIES:CNT40PIES:BODEGA:CARGASUELTA:FECHAETA:FECHADESCARGUE:FECHATURNO:DIAS_ESTADIA:MOTIVOINCPLAN:FECHADUC:'
,p_sort_column_1=>'PROVEEDOR'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'OC'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'FECHATURNO'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'0:0:0:0:0'
,p_break_enabled_on=>'0:0:0:0:0'
,p_avg_columns_on_break=>'DIAS_ESTADIA'
,p_created_on=>wwv_flow_imp.dz('20240913133621Z')
,p_updated_on=>wwv_flow_imp.dz('20240913170156Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(312515155074894101)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(319905051258200724)
,p_plug_name=>unistr('Promedio d\00EDas en puerto por Terminal Portuario ')
,p_parent_plug_id=>wwv_flow_imp.id(312515155074894101)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>40
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'htp.p(''<table border="0" cellpadding="5" cellspacing="0">',
unistr('<tr><th><p><label>Promedio d\00EDas en puerto: </label></p></th>'),
'<th colspan="2"><p><span style="color:red;">''||:P306_PROMEDIO||''</span></p></th>',
'</tr>'');',
'FOR promedios IN (',
'    select ROW_NUMBER() OVER (  ORDER BY bodega  )  rn,',
'codbodega,',
'bodega,',
'to_char(SUM(CONTACONTENEDOR),''999G999G999G999G990D00'')TOTAL_CONTENEDOR,',
'to_char(AVG( CASE WHEN (FECHADESCARGUE -FECHAETA) <0 THEN 0 ELSE (FECHADESCARGUE -FECHAETA) END ),''999G999G999G999G990D00'')PROM_DIAS_ESTADIA',
'from vt_comp_cmex_promdiaspuerto',
'where  trunc(fechaturno) between TRUNC(TO_DATE(:P306_DESDE)) AND LAST_DAY(TO_DATE(:P306_HASTA))',
'GROUP BY codbodega, bodega',
'ORDER BY codbodega, bodega',
')',
'LOOP',
'    IF (promedios.RN=1)THEN',
unistr('    --<th><p><label>Promedio d\00EDas en puerto: </label></p></th>'),
unistr('        htp.p(''<tr><th style="text-align:center" rowspan="''||:P306_NUMEROREGISTROS||''">Promedio d\00EDas en puerto <br/>por Terminal Portuario</th><td style="text-align:left">''||promedios.bodega||''</td><td style="text-align:right">''||promedios.PROM_DIAS_')
||'ESTADIA||''</td></tr>'');',
'    ELSE',
'        htp.p(''<tr><td style="text-align:left">''||promedios.bodega||''</td><td style="text-align:right">''||promedios.PROM_DIAS_ESTADIA||''</td></tr>'');',
'    END IF;',
'',
'END LOOP;',
'htp.p(''</tbody>',
'</table>'');'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_plug_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_plug_display_when_condition=>'P306_NUMEROREGISTROS'
,p_updated_on=>wwv_flow_imp.dz('20240913165416Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(319905632780200730)
,p_plug_name=>'Total contenedores por terminal portuario'
,p_parent_plug_id=>wwv_flow_imp.id(312515155074894101)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'htp.p(''<table border="0" cellpadding="5" cellspacing="0">',
'<tr><th><p><label>Total contenedores: </label></p></th>',
'<th colspan="2"><p><span style="color:red;">''||:P306_CONTARCONTENEDOR||''</span></p></th>',
'</tr>'');',
'FOR promedios IN (    ',
'select ROW_NUMBER() OVER (  ORDER BY bodega  )  rn,',
'codbodega,',
'bodega,',
'SUM(CONTACONTENEDOR)TOTAL_CONTENEDOR,',
'AVG( CASE WHEN (FECHADESCARGUE -FECHAETA) <0 THEN 0 ELSE (FECHADESCARGUE -FECHAETA) END )PROM_DIAS_ESTADIA',
'from vt_comp_cmex_promdiaspuerto',
'where  trunc(fechaturno) between TRUNC(TO_DATE(:P306_DESDE)) AND LAST_DAY(TO_DATE(:P306_HASTA))',
'GROUP BY codbodega, bodega',
'ORDER BY codbodega, bodega )',
'LOOP',
'    IF (promedios.RN=1)THEN',
'        htp.p(''<tr><th style="text-align:center" rowspan="''||:P306_NUMEROREGISTROS||''">Total contenedores <br/>por Terminal Portuario</th><td style="text-align:left">''||promedios.bodega||''</td><td style="text-align:right">''||promedios.Total_Contenedo'
||'r||''</td></tr>'');',
'    ELSE',
'        htp.p(''<tr><td style="text-align:left">''||promedios.bodega||''</td><td style="text-align:right">''||promedios.Total_Contenedor||''</td></tr>'');',
'    END IF;',
'',
'END LOOP;',
'htp.p(''</tbody>',
'</table>'');'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_plug_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_plug_display_when_condition=>'P306_NUMEROREGISTROS'
,p_updated_on=>wwv_flow_imp.dz('20240913165416Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(312517598932894125)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(318472835801183330)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(312517661941894126)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(312517598932894125)
,p_button_name=>'Buscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Buscar'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(312515277191894102)
,p_name=>'P306_ANIO_MES'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(312515155074894101)
,p_prompt=>'Periodo'
,p_placeholder=>'Seleecione Periodo'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(add_months(trunc(sysdate, ''MM''), level - 12), ''YYYY / Month'') AS display_value,',
'    to_char(add_months(trunc(sysdate, ''MM''), level - 12), ''MMYYYY'')    AS return_value',
'FROM',
'    dual',
'CONNECT BY',
'    level <= 12',
'ORDER BY',
'    level desc'))
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(312517803557894128)
,p_name=>'P306_PROMEDIO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(318472835801183330)
,p_prompt=>unistr('Promedio d\00EDas en puerto')
,p_format_mask=>'999G999G999G999G990D00'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="color:red;"'
,p_grid_label_column_span=>4
,p_display_when=>'P306_PROMEDIO'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(318472932694183331)
,p_name=>'P306_HASTA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(318472835801183330)
,p_prompt=>'Hasta'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(318473091781183332)
,p_name=>'P306_DESDE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(318472835801183330)
,p_prompt=>'Desde'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(319903886522200712)
,p_name=>'P306_CONTARCONTENEDOR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(318472835801183330)
,p_prompt=>'Total Contenedores '
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_cattributes_element=>'style="color:red;"'
,p_grid_label_column_span=>4
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(319905550978200729)
,p_name=>'P306_NUMEROREGISTROS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(318472835801183330)
,p_prompt=>'Numeroregistros'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(318472686434183328)
,p_name=>'cambio mes'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P306_ANIO_MES'
,p_condition_element=>'P306_ANIO_MES'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(318473251914183334)
,p_event_id=>wwv_flow_imp.id(318472686434183328)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra()'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(318472743648183329)
,p_event_id=>wwv_flow_imp.id(318472686434183328)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select TRUNC(TO_DATE(''01/''||SUBSTR(:P306_ANIO_MES,1,2)||''/''||SUBSTR(:P306_ANIO_MES,3)),''MM'') ',
',LAST_DAY(TO_DATE(''01/''||SUBSTR(:P306_ANIO_MES,1,2)||''/''||SUBSTR(:P306_ANIO_MES,3)))',
'into :P306_DESDE,:P306_HASTA',
'from dual;'))
,p_attribute_02=>'P306_ANIO_MES'
,p_attribute_03=>'P306_DESDE,P306_HASTA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(318473393710183335)
,p_event_id=>wwv_flow_imp.id(318472686434183328)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra()'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(318473190034183333)
,p_event_id=>wwv_flow_imp.id(318472686434183328)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(312518458919894134)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'select ',
'COUNT(DISTINCT codbodega) CONTAR,',
'to_char(SUM(CONTACONTENEDOR),''999G999G999G999G990D00'')CONTACONTENEDOR,',
'to_char(round(AVG(dias_estadia),2),''999G999G999G999G990D00'')dias_estadia',
'INTO :P306_NUMEROREGISTROS,:P306_CONTARCONTENEDOR,:P306_PROMEDIO',
'from VT_COMP_CMEX_PROMDIASPUERTO',
'',
'where trunc(fechaturno) between TRUNC(TO_DATE(:P306_DESDE)) AND LAST_DAY(TO_DATE(:P306_HASTA));',
'  ',
' ',
unistr(':P306_PROMEDIO:=ROUND(:P306_PROMEDIO,2)||'' d\00EDas.'';'),
':P306_CONTARCONTENEDOR:=ROUND(:P306_CONTARCONTENEDOR,2)||'' Cnts.'';',
'EXCEPTION WHEN OTHERS THEN',
'    :P306_PROMEDIO:=NULL;',
'    :P306_CONTARCONTENEDOR:=NULL;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>312518458919894134
,p_updated_on=>wwv_flow_imp.dz('20240913165645Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp.component_end;
end;
/
