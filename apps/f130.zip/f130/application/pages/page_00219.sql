prompt --application/pages/page_00219
begin
--   Manifest
--     PAGE: 00219
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>219
,p_name=>'PAGOS RECURRENTES - INFO EXTRA'
,p_alias=>'PAGOS-RECURRENTES-INFO-EXTRA1'
,p_page_mode=>'MODAL'
,p_step_title=>'&P219_TITLE.'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(secItems).hide();'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-button.a-IRR-sortWidget-button[data-option="hide"], .a-IRR-button.a-IRR-sortWidget-button[data-option="freeze"]{',
'    display:none;',
'}',
'.a-IG-controls-item--aggregate, .a-IG-controls-item--controlBreak, .a-IG-controls-item--groupBy, .a-IG-reportSummary-item--aggregate, .a-IG-reportSummary-item--controlBreak, .a-IG-reportSummary-item--groupBy, .a-IRR-controls-item--aggregate, .a-IRR-c'
||'ontrols-item--controlBreak, .a-IRR-controls-item--groupBy, .a-IRR-reportSummary-item--aggregate, .a-IRR-reportSummary-item--controlBreak, .a-IRR-reportSummary-item--groupBy {',
'    --a-report-controls-cell-label-icon-background-color: #3b83bd;',
'    --a-report-controls-cell-label-hover-background-color: #e6f0f7;',
'    display: none;',
'}',
'.a-IRR-chartView, .a-IRR-controlsContainer, .a-IRR-detailView, .a-IRR-groupByView, .a-IRR-iconViewTable, .a-IRR-pivotView {',
'    border-top-color: #E6E6E6;',
'    display: none;',
'}'))
,p_step_template=>wwv_flow_imp.id(295596898750037659)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240226220112Z')
,p_last_updated_on=>wwv_flow_imp.dz('20231120142601Z')
,p_last_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(127414498455639930)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(236182221414807559)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning'
,p_plug_template=>wwv_flow_imp.id(295605160997037667)
,p_plug_display_sequence=>50
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(246952101341733551)
,p_plug_name=>unistr('Negociaci\00F3n &P219_NEGID.')
,p_region_name=>'rptNegociacion'
,p_region_template_options=>'#DEFAULT#:t-Form--noPadding:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>30
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P219_PROCESO'
,p_plug_display_when_cond2=>'1'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(253722003273475959)
,p_plug_name=>'Negociacion'
,p_parent_plug_id=>wwv_flow_imp.id(246952101341733551)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'htp.p(''<div id="coloresLista">'');',
'        FOR NEG IN (select distinct ',
'    NEG_ID,',
' ',
'    case when NEG_TIPO =''FJ'' THEN ''FJ - FIJO'' ELSE ''ES - ESCALA'' END NEG_TIPO,',
'    case when NEG_ESQUEMA =''PV'' THEN ''PV - PROVEEDOR'' ELSE ''PD - PRODUCTO'' END NEG_ESQUEMA,',
'    CASE WHEN NEG_ESQUEMA =''PV'' THEN ',
'        (SELECT TRIM(CODIGOPROVEEDOR)||'' - ''|| TRIM(DESCRIPCION) ||'' (''||TRIM(TIPO)||'')''FROM VT_JDE_MAESTROPROVEEDOR WHERE CODIGOPROVEEDOR = NEG_CODESQUEMA AND ROWNUM=1)',
'        ELSE ',
'        (SELECT CODIGOPRODUCTO||'' - ''|| NOMBREPRODUCTO FROM VT_JDE_PRODUCTOS WHERE CODIGOCORTO = NEG_CODESQUEMA AND ROWNUM=1)',
'        END NEG_CODESQUEMA ,',
'    NEG_RECURRENTE,',
unistr('    NEG_PERIODICIDAD ||'' D\00EDas'' NEG_PERIODICIDAD,'),
'    NEG_VIGENCIADESDE  || '' - ''||NEG_VIGENCIAHASTA NEG_VIGENCIA',
'from VT_COMP_NEGOCIACION',
'where neg_id=:P219_NEGID)',
'        LOOP',
'         htp.p(''<table border="0" cellspacing="0px" width="100%" >',
unistr('				<tr><td ><strong>Id Negociaci\00F3n:</strong></td><td>''||to_char(NEG.NEG_Id,''00000'')||''</td><td > </td><td >Tipo:</td><td>''||NEG.NEG_TIPO||''</td></tr>'),
unistr('				<tr><td ><strong>Esquema:</strong></td><td>''||NEG.NEG_ESQUEMA||''</td><td > </td><td >C\00F3d. Esquema:</td><td>''||NEG.NEG_CODESQUEMA||''</td></tr>'),
'				<tr><td ><strong>Recurrente:</strong></td><td>''||NEG.NEG_RECURRENTE||''</td><td > </td><td >Periodicidad:</td><td>''||NEG.NEG_PERIODICIDAD||''</td></tr>',
unistr('				<tr><td ><strong>Vig\00E9	ncia:</strong></td><td>''||NEG.NEG_VIGENCIA||''</td><td > </td><td > </td></tr>		'),
'			</table>'');',
'        END LOOP;',
'   htp.p(''</div>'');'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(253773128266561282)
,p_plug_name=>'Detalle'
,p_parent_plug_id=>wwv_flow_imp.id(246952101341733551)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CAB_ID,',
'        ''<span>''',
'            ||decode(d.neg_tipo,''ES'','' Escala      :''||d.CAB_ESCALA ||''<br/>'','''')',
'            ||decode(d.neg_tipo,''ES'','',Acumula     :''||d.CAB_ACUMULA||''<br/>'','''')',
'                                   ||'',Tipo Precio :''||d.CAB_TIPOPRECIO||''<br/>''',
'                                   ||'',Tipo Fornula:''||decode(d.CAB_TIPOPRECIO,''FJ'','''',( select FORMULA from t_comp_negociacionform where id = d.CAB_FORMULA and  activo=1))||''<br/>'' ',
unistr('            ||'',Justifiaci\00F3n:''||CAB_JUSTIFICACION ||''<span style="color:#f2f4f7">''||d.CAB_ID||''</span><br/>'''),
'        ||''</span>'' cabecera,',
'       CAB_ESCALA ESCALA,',
'       CAB_ACUMULA ACUMULA,',
'       CAB_TIPOPRECIO TIPO_PRECIO,',
'       CAB_FORMULA FORMULA,',
'       CAB_JUSTIFICACION JUSTIFICACION ,',
'       DET_CODPRODUCTO COD_PRODUCTO,',
'       DET_CODPROVEEDOR COD_PROVEEDOR,',
'       DET_CODPRODUCTOPRV COD_PRODUCTOPRV,',
'       DET_DESPRODUCTOPRV DES_PRODUCTOPRV,',
'       DET_UMPRODUCTOPRV UM_PRODUCTOPRV,',
unistr('       case DET_TIEMPOENTREGA when 0 then ''Inmediato'' else to_char(DET_TIEMPOENTREGA)||'' d\00EDas'' end TIEMPO_ENTREGA,'),
'       DET_FORMAPAGO FORMA_PAGO,',
'       DET_INCOTERM INCOTERM,',
'       DET_CANTDESDE CANT_DESDE,',
'       DET_CANTHASTA CANT_HASTA,',
'       DET_PRECIO PRECIO,',
'       DET_COMENTARIO COMENTARIO',
'  from VT_COMP_NEGOCIACION d',
' where neg_id=:P219_NEGID'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Detalle'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(253773178367561283)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>253773178367561283
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(128566445310671759)
,p_db_column_name=>'COD_PRODUCTO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Producto'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(135034190509484151)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(128566898656671759)
,p_db_column_name=>'COD_PROVEEDOR'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(135034190509484151)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(128567282878671759)
,p_db_column_name=>'COD_PRODUCTOPRV'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>unistr('C\00F3d. Producto Prv')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(128567682055671759)
,p_db_column_name=>'DES_PRODUCTOPRV'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Desc. Producto Prv'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(128568008832671759)
,p_db_column_name=>'UM_PRODUCTOPRV'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Um Producto Prv'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(128568420701671760)
,p_db_column_name=>'FORMA_PAGO'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Forma Pago'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(134250431110099274)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(128568888959671760)
,p_db_column_name=>'INCOTERM'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Incoterm'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(74803172029355163)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(128569229488671760)
,p_db_column_name=>'CANT_DESDE'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Cant Desde'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(128569639544671760)
,p_db_column_name=>'CANT_HASTA'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Cant Hasta'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(128570061558671761)
,p_db_column_name=>'PRECIO'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(128570441936671761)
,p_db_column_name=>'COMENTARIO'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Comentario'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(128570883468671761)
,p_db_column_name=>'TIEMPO_ENTREGA'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Tiempo Entrega'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(127415434499639940)
,p_db_column_name=>'CAB_ID'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Cab Id'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(127415509734639941)
,p_db_column_name=>'ESCALA'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Escala'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(127415659404639942)
,p_db_column_name=>'ACUMULA'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Acumula'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(127415701841639943)
,p_db_column_name=>'TIPO_PRECIO'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Tipo Precio'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(127415858965639944)
,p_db_column_name=>'FORMULA'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Formula'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(127415992348639945)
,p_db_column_name=>'JUSTIFICACION'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Justificacion'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(127416077529639946)
,p_db_column_name=>'CABECERA'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(253840694909573455)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1252784'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'COD_PROVEEDOR:COD_PRODUCTO:COD_PRODUCTOPRV:DES_PRODUCTOPRV:UM_PRODUCTOPRV:FORMA_PAGO:INCOTERM:TIEMPO_ENTREGA:CANT_DESDE:CANT_HASTA:PRECIO:CABECERA:'
,p_break_on=>'COD_PROVEEDOR:COD_PRODUCTO:0:0:0:0'
,p_break_enabled_on=>'COD_PROVEEDOR:COD_PRODUCTO:0:0:0:0'
,p_created_on=>wwv_flow_imp.dz('20240226220112Z')
,p_updated_on=>wwv_flow_imp.dz('20240226220112Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(127414573056639931)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(127414498455639930)
,p_button_name=>'Imprimir'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Imprimir'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P219_PROCESO'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-print'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127416204310639948)
,p_name=>'P219_NEGID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(236182221414807559)
,p_prompt=>'Negid'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127416355583639949)
,p_name=>'P219_TITLE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(236182221414807559)
,p_prompt=>'Title'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127416443429639950)
,p_name=>'P219_PROCESO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(236182221414807559)
,p_prompt=>'Proceso'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(127414693515639932)
,p_name=>'PrintRegion'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(127414573056639931)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(127414756492639933)
,p_event_id=>wwv_flow_imp.id(127414693515639932)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_PRINT.REGION.TO.PDF.V.2.0'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(246952101341733551)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(127414853510639934)
,p_event_id=>wwv_flow_imp.id(127414693515639932)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(128660158380446201)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P219_TITLE:=   case',
unistr('                    when :P219_PROCESO= 1 then ''Visualizaci\00F3n de Negociaci\00F3n'''),
unistr('                    when :P219_PROCESO= 2 then ''Informaci\00F3n Extra de Orden Compra'''),
'                end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>128660158380446201
);
wwv_flow_imp.component_end;
end;
/
