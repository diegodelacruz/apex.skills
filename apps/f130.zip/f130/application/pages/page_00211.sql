prompt --application/pages/page_00211
begin
--   Manifest
--     PAGE: 00211
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>211
,p_name=>'Generar OC'
,p_alias=>'GENERAROC'
,p_step_title=>'Generar OC'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(regParametros).hide();'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240611163553Z')
,p_last_updated_on=>wwv_flow_imp.dz('20250227155433Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(190512169448868201)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(190512362009868203)
,p_plug_name=>'Editar Cabecera'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(190512437317868204)
,p_plug_name=>unistr('Configuraci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(211843037801642302)
,p_plug_name=>'Lineas'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ID,',
'    PRODUCTO,',
'    NVL(CANTIDAD_MANUAL, CANTIDAD) AS CANTIDAD,',
'    UNIDADMEDIDA,',
'    NVL(PRECIOUNITARIOEXTERNO, PRECIOUNITARIO)  AS PRECIOUNITARIO,',
'    PRECIOTOTAL',
'FROM ',
'    VT_COMP_PENDIENTE_GENERAR_OC',
'WHERE            ',
'    COMPANIA         = :G_COMPANIA',
'        AND                                ',
'    TIPO_REQUISICION = :P211_GOC_TIPO_REQUISICION',
'        AND',
'    TRIM(CODBODEGA)  = TRIM(:P211_GOC_CODBODEGA)',
'        AND     ',
'    CODPROVEEDOR     = :P211_GOC_DET_CODPROVEEDOR',
'        AND',
'    RESERVA          = :P211_GOC_RESERVA',
'        AND',
'    USUARIO          = :APP_USER',
'        AND',
unistr('    CODPROVEEDOR     IS NOT NULL   -- Tiene negociaci\00F3n'),
'        AND',
'    FECHA_COMPROMISO IS NOT NULL   -- Tiene fecha compromiso',
'        AND',
'    FECHA_PROCESADO  IS NULL       -- Pendiente de generar OC',
'        AND',
'    (:P211_MODO_AGRUPADO IS NULL OR MODO_AGRUPADO = :P211_MODO_AGRUPADO)',
'ORDER BY ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Lineas'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20250226181424Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(211843179826642303)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>211843179826642303
,p_updated_on=>wwv_flow_imp.dz('20250226180954Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(211843285552642304)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250226180954Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(211844134561642313)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>20
,p_column_identifier=>'F'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(211843584262642307)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(211843604531642308)
,p_db_column_name=>'UNIDADMEDIDA'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'UM'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250226180954Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(211843881582642310)
,p_db_column_name=>'PRECIOUNITARIO'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Precio Uni.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250226180954Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(211843905877642311)
,p_db_column_name=>'PRECIOTOTAL'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(212426747443960578)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2124268'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:PRODUCTO:CANTIDAD:UNIDADMEDIDA:PRECIOUNITARIO:PRECIOTOTAL:'
,p_sum_columns_on_break=>'PRECIOTOTAL'
,p_created_on=>wwv_flow_imp.dz('20240611163553Z')
,p_updated_on=>wwv_flow_imp.dz('20240611163553Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'ATOPON'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(615426430839473502)
,p_plug_name=>unistr('Par\00E1metros')
,p_region_name=>'regParametros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250226175231Z')
,p_updated_on=>wwv_flow_imp.dz('20250226181424Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(615426617771473504)
,p_plug_name=>unistr('Configuraci\00F3n Tipo OC')
,p_icon_css_classes=>'fa-exclamation'
,p_region_template_options=>'#DEFAULT#:t-Alert--colorBG:t-Alert--horizontal:t-Alert--customIcons:t-Alert--warning:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(295605160997037667)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':p211_flag_servicios = 1'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250226181424Z')
,p_updated_on=>wwv_flow_imp.dz('20250226200829Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(190512287466868202)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(190512169448868201)
,p_button_name=>'REGRESAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
,p_updated_on=>wwv_flow_imp.dz('20250226171504Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(191037715799783718)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(190512362009868203)
,p_button_name=>'GOTO_200'
,p_button_static_id=>'GOTO_200'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Goto 200'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:200:&SESSION.::&DEBUG.:::'
,p_button_cattributes=>'style="display:none;"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(190512634371868206)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(190512169448868201)
,p_button_name=>'GENERAR_OC'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Generar OC'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-gear'
,p_updated_on=>wwv_flow_imp.dz('20250226203424Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(190512751274868207)
,p_name=>'P211_GOC_TIPO_REQUISICION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(190512437317868204)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(190512862841868208)
,p_name=>'P211_GOC_CODBODEGA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(190512437317868204)
,p_prompt=>'Bodega'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_JDE_BODEGAS'
,p_lov=>'SELECT CODUNIDAD||'' - ''||DESCRIPCION BODEGA, CODUNIDAD AS CODBODEGA from VT_JDE_BODEGAS;'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(190512923960868209)
,p_name=>'P211_GOC_DET_CODPROVEEDOR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(190512437317868204)
,p_prompt=>'Proveedor'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_JDE_PROVEEDORES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    TRIM(ABALPH) AS DESCRIPCION,',
'    TRIM(ABTAX) AS IDENTIFICACION,',
'    ABAN8  AS CODIGO',
'FROM f0101@jdedtadl',
'ORDER BY ABALPH;'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(190513098281868210)
,p_name=>'P211_GOC_RESERVA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(190512437317868204)
,p_prompt=>'Reserva'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P211_GOC_RESERVA'
,p_display_when_type=>'ITEM_IS_NOT_ZERO'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(190513145855868211)
,p_name=>'P211_CABECERA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(190512362009868203)
,p_prompt=>'Cabecera OC'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_grid_label_column_span=>2
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(190515975741868239)
,p_name=>'P211_MONTO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(190512437317868204)
,p_prompt=>'Monto'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(190516055352868240)
,p_name=>'P211_FECHA_COMPROMISO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(190512437317868204)
,p_prompt=>'Compromiso'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200197734180652328)
,p_name=>'P211_MODO_AGRUPADO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(190512437317868204)
,p_prompt=>'Modo Agrupado'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P211_MODO_AGRUPADO'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200197984261652330)
,p_name=>'P211_GOTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(615426430839473502)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20250226175715Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200199986161652350)
,p_name=>'P211_CANTIDAD'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(190512437317868204)
,p_prompt=>'Cantidad'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P211_MODO_AGRUPADO'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(615426566407473503)
,p_name=>'P211_FLAG_SERVICIOS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(615426430839473502)
,p_prompt=>'Flag Servicios'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250226175624Z')
,p_updated_on=>wwv_flow_imp.dz('20250226175715Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(615426717373473505)
,p_name=>'P211_VERSIONORG'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(615426617771473504)
,p_prompt=>unistr('Versi\00F3n*')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when=>'APP_USER'
,p_display_when2=>'DDELACRUZ'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250226181650Z')
,p_updated_on=>wwv_flow_imp.dz('20250226195504Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(615426849468473506)
,p_name=>'P211_TIPOOCORG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(615426617771473504)
,p_prompt=>'Tipo OC*'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when=>'APP_USER'
,p_display_when2=>'DDELACRUZ'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250226181650Z')
,p_updated_on=>wwv_flow_imp.dz('20250226195504Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(615426924519473507)
,p_name=>'P211_TIPO_OC'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(615426617771473504)
,p_prompt=>'Tipo OC'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:BN;BN,CN;CN'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20250226181809Z')
,p_updated_on=>wwv_flow_imp.dz('20250226195504Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(615427070195473508)
,p_name=>'P211_VERSION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(615426617771473504)
,p_prompt=>unistr('Versi\00F3n')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250226181809Z')
,p_updated_on=>wwv_flow_imp.dz('20250226195504Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(190515249130868232)
,p_name=>'GENERAR OC'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(190512634371868206)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_updated_on=>wwv_flow_imp.dz('20250226203250Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(190515635151868236)
,p_event_id=>wwv_flow_imp.id(190515249130868232)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Confirma'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Generar la nueva orden de compra &P211_GOC_TIPO_REQUISICION. &P211_GOC_CODBODEGA. &P211_GOC_DET_CODPROVEEDOR.'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(190515720623868237)
,p_event_id=>wwv_flow_imp.id(190515249130868232)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'Wait Popup'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.widget.waitPopup();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(190515347636868233)
,p_event_id=>wwv_flow_imp.id(190515249130868232)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_name=>'SP_GENERA_OC'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    V_DOCUMENTOTIPO  VARCHAR(2);',
'    V_DOCUMENTO      NUMBER;',
'BEGIN',
'    PK_COMP_GESTIONCOMPRAS.SP_LOG(''SP_GENERA_OC APEX'', ''Inicio TIPO=''||:P211_GOC_TIPO_REQUISICION||'' CODBODEGA=''||:P211_GOC_CODBODEGA||'' CODPROVEEDOR=''||:P211_GOC_DET_CODPROVEEDOR||'' RESERVA=''||:P211_GOC_RESERVA);',
'',
'    PK_COMP_GESTIONCOMPRAS.SP_GENERA_OC(',
'        :P211_GOC_TIPO_REQUISICION, ',
'        :P211_GOC_CODBODEGA, ',
'        :P211_GOC_CODBODEGA, ',
'        :P211_GOC_DET_CODPROVEEDOR, ',
'        :P211_GOC_RESERVA,',
'        :P211_MODO_AGRUPADO,',
'        :APP_USER, ',
'        :G_COMPANIA,',
'        ',
'        V_DOCUMENTOTIPO, ',
'        V_DOCUMENTO',
'    );',
'',
'    PK_COMP_GESTIONCOMPRAS.SP_LOG(''SP_GENERA_OC APEX'', ''Resultado luego de invocar TIPO=''||V_DOCUMENTOTIPO||'' DOC=''||V_DOCUMENTO);',
'',
'    PK_COMP_GESTIONCOMPRAS.SP_ESTABLECE_COMENTARIOS(',
'        :G_COMPANIA, ',
'        V_DOCUMENTOTIPO,',
'        V_DOCUMENTO,',
'        :P211_CABECERA',
'    );    ',
'END;'))
,p_attribute_02=>'P211_CABECERA'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(190515856072868238)
,p_event_id=>wwv_flow_imp.id(190515249130868232)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_name=>'GOTO'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'document.getElementById(''GOTO_200'').click();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(615427144717473509)
,p_name=>unistr('Actualizar Versi\00F3n')
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P211_TIPO_OC'
,p_condition_element=>'P211_TIPO_OC'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20250226193736Z')
,p_updated_on=>wwv_flow_imp.dz('20250226195345Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(615427229090473510)
,p_event_id=>wwv_flow_imp.id(615427144717473509)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
,p_created_on=>wwv_flow_imp.dz('20250226193736Z')
,p_updated_on=>wwv_flow_imp.dz('20250226195345Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(615427348376473511)
,p_event_id=>wwv_flow_imp.id(615427144717473509)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_versionorg	varchar2(20);',
'v_tipoocorg		varchar2(10);',
'v_version		varchar2(20);',
'v_tipo_oc		varchar2(10);',
'v_versionalt	varchar2(20);',
'v_tipoocalt		varchar2(10);',
'begin',
'	v_versionorg	:= :p211_versionorg;',
'	v_tipoocorg		:= :p211_tipoocorg;',
'	v_version		:= :p211_version;',
'	v_tipo_oc		:= :p211_tipo_oc;',
'',
'	if v_tipo_oc != v_tipoocorg then',
'		begin',
'			select valor2, v_tipo_oc into v_versionalt, v_tipoocalt',
'			from t_corp_udc',
'			where id_tabla = ''SVXX-PEXT'' and valor = v_tipo_oc and activo = ''1'' and rownum = 1;',
'',
'			exception when others then',
'				if v_tipo_oc = ''CN'' then',
'					v_versionalt := ''ERP0012'';',
'				else',
'					v_versionalt := ''ERP0024'';',
'				end if;',
'				v_tipoocalt := v_tipo_oc;',
'		end;',
'	else',
'		v_versionalt	:= v_versionorg;',
'		v_tipoocalt		:= v_tipoocorg;',
'	end if;',
'',
'	:p211_version := v_versionalt;',
'	-- :p211_tipo_oc := v_tipoocalt;',
'',
'	update t_comp_prodto_proveedr_gestion x set x.version = v_versionalt, x.tipo_oc = v_tipoocalt',
'	where 1 = 1',
'		and compania			= :g_compania',
'		and tipo_requisicion	= :p211_goc_tipo_requisicion',
'		and trim(bodega)		= trim(:p211_goc_codbodega)',
'		and codproveedor		= :p211_goc_det_codproveedor',
'		and reserva				= :p211_goc_reserva',
'		and usuario				= :app_user',
'		and codproveedor		is not null',
'		and fecha_compromiso	is not null',
'		and fecha_procesado		is null',
'		and (:p211_modo_agrupado is null or modo_agrupado = :p211_modo_agrupado);',
'end;'))
,p_attribute_02=>'P211_TIPOOCORG,P211_VERSIONORG,P211_TIPO_OC,P211_VERSION,P211_GOC_TIPO_REQUISICION,P211_GOC_CODBODEGA,P211_GOC_DET_CODPROVEEDOR,P211_GOC_RESERVA,P211_MODO_AGRUPADO'
,p_attribute_03=>'P211_VERSION'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250226193736Z')
,p_updated_on=>wwv_flow_imp.dz('20250226195233Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(615427595549473513)
,p_event_id=>wwv_flow_imp.id(615427144717473509)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
,p_created_on=>wwv_flow_imp.dz('20250226193736Z')
,p_updated_on=>wwv_flow_imp.dz('20250226195345Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(190513230986868212)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Acumula Cabeceras'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    V_COMENTARIOS_APROBADOR CLOB := '''';',
'BEGIN',
'    -- Recupero las cabeceras de las requisiciones',
'    FOR REQ IN (',
'        WITH ',
'            W_CODPRODS AS (',
'                SELECT ',
'                    DISTINCT CODIGOCORTOPRODUCTO, CODBODEGA',
'                FROM VT_COMP_PENDIENTE_GENERAR_OC',
'                WHERE ',
'                    TIPO_REQUISICION = :P211_GOC_TIPO_REQUISICION',
'                        AND ',
'                    TRIM(CODBODEGA)  = :P211_GOC_CODBODEGA -- ''17001''',
'                        AND',
'                    CODPROVEEDOR     = :P211_GOC_DET_CODPROVEEDOR -- 4724    ',
'                        AND',
'                    RESERVA          = :P211_GOC_RESERVA',
'                        AND',
'                    USUARIO          = :APP_USER',
'                        AND',
'                    COMPANIA         = :G_COMPANIA    ',
'                        AND ',
unistr('                    CODPROVEEDOR     IS NOT NULL   -- Tiene negociaci\00F3n'),
'                        AND',
'                    FECHA_COMPROMISO IS NOT NULL   -- Tiene fecha compromiso',
'                        AND',
'                    FECHA_PROCESADO  IS NULL       -- Pendiente de generar OC',
'            )',
'            SELECT ',
'                DISTINCT DOCUMENTOTIPO, DOCUMENTO',
'            FROM ',
'                T_COMP_F4311_GESTION GST,',
'                W_CODPRODS           PRODS',
'            WHERE',
'                GST.CODIGOCORTOPRODUCTO = PRODS.CODIGOCORTOPRODUCTO',
'                    AND',
'                GST.BODEGA              = PRODS.CODBODEGA',
'                    AND',
'                USUARIO                 = :APP_USER',
'                    AND',
'                COMPANIA                = :G_COMPANIA ',
'                    AND ',
'                FECHA_PROCESADO  IS NULL       -- Pendiente de generar OC',
'    )',
'    LOOP',
'        V_COMENTARIOS_APROBADOR := V_COMENTARIOS_APROBADOR||REQ.DOCUMENTOTIPO||''-''||REQ.DOCUMENTO||'': ''||PK_COMP_ORDENESCOMPRA.F_COMENTARIO@JDEDTADL(',
'            p_compania    => :G_COMPANIA,',
'            p_tipooc      => REQ.DOCUMENTOTIPO,',
'            p_ordencompra => REQ.DOCUMENTO',
'        )||CHR(13);',
'    END LOOP;',
'',
'    :P211_CABECERA := DBMS_LOB.SUBSTR(V_COMENTARIOS_APROBADOR, 4000, 1);',
'',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>190513230986868212
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(615426399423473501)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Respaldo'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_qty_ord	number;',
'v_qty_srv	number;',
'v_log_qty	number;',
'begin',
'	:p211_flag_servicios := 0;',
'',
unistr('	-- Respaldo la Versi\00F3n y Tipo OC'),
'	update t_comp_prodto_proveedr_gestion x set x.versionorg = x.version, x.tipoocorg = x.tipo_oc',
'	where 1 = 1',
'		and compania			= :g_compania',
'		and tipo_requisicion	= :p211_goc_tipo_requisicion',
'		and trim(bodega)		= trim(:p211_goc_codbodega)',
'		and codproveedor		= :p211_goc_det_codproveedor',
'		and reserva				= :p211_goc_reserva',
'		and usuario				= :app_user',
'		and codproveedor		is not null',
'		and fecha_compromiso	is not null',
'		and fecha_procesado		is null',
'		and (:p211_modo_agrupado is null or modo_agrupado = :p211_modo_agrupado)',
'		and versionorg is null',
'		and tipoocorg is null;',
'',
'	v_log_qty := sql%rowcount;',
'',
'	begin',
'		select versionorg,tipoocorg,version,tipo_oc into :p211_versionorg, :p211_tipoocorg,:p211_version, :p211_tipo_oc',
'		from t_comp_prodto_proveedr_gestion',
'		where 1 = 1',
'			and compania			= :g_compania',
'			and tipo_requisicion	= :p211_goc_tipo_requisicion',
'			and trim(bodega)		= trim(:p211_goc_codbodega)',
'			and codproveedor		= :p211_goc_det_codproveedor',
'			and reserva				= :p211_goc_reserva',
'			and usuario				= :app_user',
'			and codproveedor		is not null',
'			and fecha_compromiso	is not null',
'			and fecha_procesado		is null',
'			and (:p211_modo_agrupado is null or modo_agrupado = :p211_modo_agrupado)',
'			and rownum = 1;',
'',
'		exception when others then :p211_flag_servicios := 0;',
'	end;',
'',
unistr('	-- Valido la cantidad de \00EDtems'),
'	select count(1) into v_qty_ord from t_comp_prodto_proveedr_gestion',
'	where 1 = 1',
'		and compania			= :g_compania',
'		and tipo_requisicion	= :p211_goc_tipo_requisicion',
'		and trim(bodega)		= trim(:p211_goc_codbodega)',
'		and codproveedor		= :p211_goc_det_codproveedor',
'		and reserva				= :p211_goc_reserva',
'		and usuario				= :app_user',
'		and codproveedor		is not null',
'		and fecha_compromiso	is not null',
'		and fecha_procesado		is null',
'		and (:p211_modo_agrupado is null or modo_agrupado = :p211_modo_agrupado);',
'',
'	-- Valido la cantidad de servicios',
'	select count(1) into v_qty_srv from t_comp_prodto_proveedr_gestion',
'	where 1 = 1',
'		and compania			= :g_compania',
'		and tipo_requisicion	= :p211_goc_tipo_requisicion',
'		and trim(bodega)		= trim(:p211_goc_codbodega)',
'		and codproveedor		= :p211_goc_det_codproveedor',
'		and reserva				= :p211_goc_reserva',
'		and usuario				= :app_user',
'		and codproveedor		is not null',
'		and fecha_compromiso	is not null',
'		and fecha_procesado		is null',
'		and (:p211_modo_agrupado is null or modo_agrupado = :p211_modo_agrupado)',
'		and substr(productotipo,1,2) = ''SV'';',
'',
'	if v_qty_ord > 0 and v_qty_ord = v_qty_srv then',
'		:p211_flag_servicios := 1;',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>615426399423473501
,p_created_on=>wwv_flow_imp.dz('20250226174931Z')
,p_updated_on=>wwv_flow_imp.dz('20250227155433Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
