prompt --application/pages/page_00615
begin
--   Manifest
--     PAGE: 00615
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>615
,p_name=>'Dividir orden'
,p_alias=>'DIVIDIR-ORDEN'
,p_page_mode=>'MODAL'
,p_step_title=>'Dividir orden'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20250106175801Z')
,p_last_updated_on=>wwv_flow_imp.dz('20241224144945Z')
,p_last_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(405193417927791340)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(405194353360791349)
,p_name=>'Deatlle'
,p_region_name=>'tblDetalle'
,p_template=>wwv_flow_imp.id(295629242996037685)
,p_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT APEX_ITEM.CHECKBOX(1,ID,CASE WHEN :P615_TODO=1 THEN ''CHECKED'' ELSE ''UNCHECKED'' END || '' class="chkF01"'') seleccion,',
'codproducto ,descproducto ,ctgproducto ,unidadmedida ,cantordenada ',
'FROM T_COMP_ORDENCOMPRAEXTDET',
'WHERE IDCAB=:P615_IDORDEN',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(411393914833050301)
,p_query_column_id=>1
,p_column_alias=>'SELECCION'
,p_column_display_sequence=>10
,p_column_heading=>'<input type="checkbox" id="selectalloc">'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(411394023928050302)
,p_query_column_id=>2
,p_column_alias=>'CODPRODUCTO'
,p_column_display_sequence=>20
,p_column_heading=>unistr('C\00F3d. Producto')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(411394125765050303)
,p_query_column_id=>3
,p_column_alias=>'DESCPRODUCTO'
,p_column_display_sequence=>30
,p_column_heading=>'Producto'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(411394225002050304)
,p_query_column_id=>4
,p_column_alias=>'CTGPRODUCTO'
,p_column_display_sequence=>40
,p_column_heading=>unistr('Categor\00EDa')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(411394330328050305)
,p_query_column_id=>5
,p_column_alias=>'UNIDADMEDIDA'
,p_column_display_sequence=>50
,p_column_heading=>'U.M.'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(411394449887050306)
,p_query_column_id=>6
,p_column_alias=>'CANTORDENADA'
,p_column_display_sequence=>60
,p_column_heading=>'Cant. Ordenada'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D0000'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(405193559553791341)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(405193417927791340)
,p_button_name=>'Salir'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Salir'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:620:&SESSION.::&DEBUG.::P620_ID:&P615_IDORDEN.'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(405193826078791344)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(405193417927791340)
,p_button_name=>'Dividir'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Dividir OC'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P615_BANDERA>1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-pie-chart'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(411395234890050314)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(405193417927791340)
,p_button_name=>'Seleccionar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Seleccionar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'1=2'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-check-square-o'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(405193787930791343)
,p_name=>'P615_IDORDEN'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(405194113490791347)
,p_name=>'P615_TODO'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(411395064299050312)
,p_name=>'P615_NUEVOID'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(411395149783050313)
,p_name=>'P615_SELECCIONADOS'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(411395535078050317)
,p_name=>'P615_MENSAJE'
,p_item_sequence=>70
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(411395826555050320)
,p_name=>'P615_BANDERA'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(411395936691050321)
,p_name=>'P615_CONTADOR'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(411398320060050345)
,p_name=>'P615_BANDERA_1'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(411394549447050307)
,p_name=>'Division'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(405193826078791344)
,p_condition_element=>'P615_BANDERA_1'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(411394665256050308)
,p_event_id=>wwv_flow_imp.id(411394549447050307)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEst\00E1 seguro de realizar la separaci\00F3n? Se crear\00E1 una nueva solicitud.')
,p_attribute_03=>'danger'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(411394949669050311)
,p_event_id=>wwv_flow_imp.id(411394549447050307)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'',
'   V_NUEVOID   NUMBER:=0;',
'',
'BEGIN',
'   pk_comp_gestionocgrupozm.sp_dividirsolicitud(:G_COMPANIA,:APP_USER,:P615_IDORDEN,:P615_SELECCIONADOS,V_NUEVOID);',
'',
'   :P615_NUEVOID:=V_NUEVOID;',
'',
unistr('   :P615_MENSAJE:=''Se cre\00F3 la solicitud:''||'' ''||:P615_NUEVOID;'),
'',
'END;'))
,p_attribute_02=>'P615_SELECCIONADOS'
,p_attribute_03=>'P615_NUEVOID,P615_MENSAJE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(411395749876050319)
,p_event_id=>wwv_flow_imp.id(411394549447050307)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(405194353360791349)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(411395375522050315)
,p_name=>'Seleccion'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.chkF01'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(411395443950050316)
,p_event_id=>wwv_flow_imp.id(411395375522050315)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var lineas =""; ',
'var contador = 0;',
'document.querySelectorAll(''.chkF01'').forEach(function(seleccion) {',
'    if(seleccion.checked){',
'         contador++;',
'        ',
'        var linea = seleccion.value',
'        if(lineas==""){',
'            lineas = linea;',
'        }else{',
'            lineas = lineas+'',''+linea;',
'        }          ',
'    }',
'});',
'apex.item("P615_SELECCIONADOS").setValue(lineas);',
'apex.item("P615_CONTADOR").setValue(contador);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(411398456406050346)
,p_event_id=>wwv_flow_imp.id(411395375522050315)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P615_CONTADOR>0  THEN',
'   IF :P615_CONTADOR<:P615_BANDERA THEN',
'     :P615_BANDERA_1:=0;',
'    ELSE',
'      :P615_BANDERA_1:=1;',
'   END IF;',
'  ELSE',
'    :P615_CONTADOR:=null;',
'    :P615_BANDERA_1:=null;',
'END IF;'))
,p_attribute_02=>'P615_CONTADOR,P615_BANDERA'
,p_attribute_03=>'P615_BANDERA_1'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(411398687653050348)
,p_name=>'SELECCIONAR'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(405193826078791344)
,p_condition_element=>'P615_CONTADOR'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(411398765173050349)
,p_event_id=>wwv_flow_imp.id(411398687653050348)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>unistr('Seleccione uno o varios \00EDtems.')
,p_attribute_03=>'success'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(411398826495050350)
,p_name=>'SELECCIONAR_1'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(405193826078791344)
,p_condition_element=>'P615_CONTADOR'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(415951716618075101)
,p_event_id=>wwv_flow_imp.id(411398826495050350)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>unistr('Seleccione uno o varios \00EDtems.')
,p_attribute_03=>'success'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(415951880817075102)
,p_name=>'SELECCIONAR_2'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(405193826078791344)
,p_condition_element=>'P615_BANDERA_1'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(415951909235075103)
,p_event_id=>wwv_flow_imp.id(415951880817075102)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>unistr('No se puede crear una nueva solicitud con los \00EDtems seleccionados.')
,p_attribute_03=>'warning'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(415956033734075144)
,p_name=>'Selecciona todo'
,p_event_sequence=>60
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectalloc'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#tblDetalle'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(415956126558075145)
,p_event_id=>wwv_flow_imp.id(415956033734075144)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#tblDetalle #selectalloc'' ).is('':checked'')) {',
'		$(''#tblDetalle input[type=checkbox][name=f01]'').prop(''checked'',true);',
'		} else {',
'		$(''#tblDetalle input[type=checkbox][name=f01]'').prop(''checked'',false);',
'		}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(415956369360075147)
,p_event_id=>wwv_flow_imp.id(415956033734075144)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var lineas =""; ',
'var contador = 0;',
'document.querySelectorAll(''.chkF01'').forEach(function(seleccion) {',
'    if(seleccion.checked){',
'         contador++;',
'        ',
'        var linea = seleccion.value',
'        if(lineas==""){',
'            lineas = linea;',
'        }else{',
'            lineas = lineas+'',''+linea;',
'        }          ',
'    }',
'});',
'apex.item("P615_SELECCIONADOS").setValue(lineas);',
'apex.item("P615_CONTADOR").setValue(contador);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(415956491528075148)
,p_event_id=>wwv_flow_imp.id(415956033734075144)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P615_CONTADOR>0  THEN',
'   IF :P615_CONTADOR<:P615_BANDERA THEN',
'     :P615_BANDERA_1:=0;',
'    ELSE',
'      :P615_BANDERA_1:=1;',
'   END IF;',
'  ELSE',
'    :P615_CONTADOR:=null;',
'    :P615_BANDERA_1:=null;',
'END IF;'))
,p_attribute_02=>'P615_CONTADOR,P615_BANDERA'
,p_attribute_03=>'P615_BANDERA_1'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(405194261466791348)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Asignar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P615_TODO:=0;',
'',
'BEGIN',
'    SELECT COUNT(*) INTO :P615_BANDERA  FROM T_COMP_ORDENCOMPRAEXTDET',
'    WHERE IDCAB=:P615_IDORDEN;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>405194261466791348
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(411395644587050318)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Borrar'
,p_attribute_01=>'CLEAR_CACHE_FOR_ITEMS'
,p_attribute_03=>'P615_MENSAJE,P615_SELECCIONADOS,P615_NUEVOID,P615_BANDERA,P615_BANDERA_1,P615_CONTADOR'
,p_internal_uid=>411395644587050318
);
wwv_flow_imp.component_end;
end;
/
