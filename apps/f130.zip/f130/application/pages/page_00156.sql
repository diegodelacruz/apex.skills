prompt --application/pages/page_00156
begin
--   Manifest
--     PAGE: 00156
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>156
,p_name=>'COMEX - Bodega Importaciones'
,p_step_title=>'COMEX - Bodega Importaciones'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230708132655Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260409203901Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(75668438008913622)
,p_plug_name=>'Ingreso Bodega Importaciones'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>wwv_flow_imp.id(296122226350169167)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(75668592965913623)
,p_plug_name=>'barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(75794981283701708)
,p_plug_name=>'Ingreso Bodega Importaciones'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'ID, ',
'CODIGOPROVEEDOR AS PROVEEDOR,',
'ORDENCOMPRA DOC_ORDEN_COMPRA,  TIPOOC  AS TIPO, ',
' TIPOOC || ''-'' || ORDENCOMPRA AS ORDEN_COMPRA,  ',
'    (select listagg(tipoorig || ''-'' ||ordenori,'' / '') ',
'         within group (order by ordenimp) correos from data.t_cmex_ordenesvinculadas ',
'     WHERE idmesa = mesa.ID ',
'     AND ordenimp = mesa.ORDENCOMPRA) AS ORDENES_ORIGINALES,',
'      CNT20PIES, ',
'      CNT40PIES',
'FROM DATA.T_CMEX_MESATRABAJO mesa',
' LEFT JOIN DATA.VT_CMEX_ORDENCOMPRA_ACT vt_ordenes',
' on mesa.ORDENCOMPRA = vt_ordenes.NUMERO_OI',
' ',
'-- where mesa.CODIGOETAPA = ''ET5''',
' WHERE mesa.CODIGOETAPA IN  (SELECT VALOR FROM T_CORP_UDC WHERE ID_CABECERA = ''CMEX_ET_IM'' AND ID_TABLA >= (SELECT ID_TABLA FROM T_CORP_UDC WHERE VALOR = ''ET5'' AND ID_CABECERA = ''CMEX_ET_IM''))',
' AND mesa.CODIGOMODULO = ''IMP'''))
,p_plug_source_type=>'NATIVE_IR'
,p_updated_on=>wwv_flow_imp.dz('20241127192825Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(75795078669701708)
,p_name=>'Mesa Trabajo Ingreso Bodega Importaciones'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:163:&SESSION.::&DEBUG.:RP,163:P163_ID_CMEX_MESATRABAJO,P163_OI,P163_PROVEEDOR:#ID#,#DOC_ORDEN_COMPRA#,#PROVEEDOR#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_detail_link_attr=>'title = "Abrir"'
,p_owner=>'NETBY3'
,p_internal_uid=>75795078669701708
,p_updated_on=>wwv_flow_imp.dz('20241127192825Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(75795401466701714)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(75797410882701719)
,p_db_column_name=>'CNT40PIES'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'CNT 40 pies'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(75797821267701719)
,p_db_column_name=>'CNT20PIES'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'CNT 20 pies'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(76151200563799234)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>17
,p_column_identifier=>'W'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(76151387097799235)
,p_db_column_name=>'DOC_ORDEN_COMPRA'
,p_display_order=>27
,p_column_identifier=>'X'
,p_column_label=>'Num Orden Compra '
,p_column_link=>'f?p=&APP_ID.:163:&SESSION.::&DEBUG.:RP,163:P163_ID_CMEX_MESATRABAJO,P163_OI,P163_PROVEEDOR:#ID#,#DOC_ORDEN_COMPRA#,#PROVEEDOR#'
,p_column_linktext=>'#DOC_ORDEN_COMPRA#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(76151440464799236)
,p_db_column_name=>'TIPO'
,p_display_order=>37
,p_column_identifier=>'Y'
,p_column_label=>'Tipo OC'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(80462525405347017)
,p_db_column_name=>'ORDEN_COMPRA'
,p_display_order=>67
,p_column_identifier=>'AB'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(80463092400347022)
,p_db_column_name=>'ORDENES_ORIGINALES'
,p_display_order=>77
,p_column_identifier=>'AD'
,p_column_label=>'Ordenes Originales'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(75806830008712684)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'758069'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ORDEN_COMPRA:PROVEEDOR:ORDENES_ORIGINALES:CNT40PIES:CNT20PIES:'
,p_created_on=>wwv_flow_imp.dz('20230708132655Z')
,p_updated_on=>wwv_flow_imp.dz('20230708132655Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp.component_end;
end;
/
