prompt --application/pages/page_00114
begin
--   Manifest
--     PAGE: 00114
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>114
,p_name=>'Mesa de Trabajo Grupo'
,p_alias=>'MESA-DE-TRABAJO-GRUPO'
,p_step_title=>'Mesa de Trabajo Grupo'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(regOcultos).hide();'
,p_inline_css=>'.cancelado {text-decoration:line-through;}'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_on=>wwv_flow_imp.dz('20260702213724Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(76537218441016721)
,p_plug_name=>'Ocultos'
,p_region_name=>'regOcultos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(76537327362016722)
,p_plug_name=>unistr('Par\00E1metros')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(76538693898016735)
,p_plug_name=>'Orden Compra'
,p_region_name=>'rptOrdenCompra'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with w_base as (',
'	select pdkcoo||''|''||codmodulo||''|''||idgrupo||''|''||aprobador||''|''||pdan8 apex_item_clave',
'		, pddoco',
'		, pddcto',
'		, pddoco||''-''||pddcto pddcco',
'		, pdlnid',
'		, pdan8',
'		, abalph',
'		, pdtrdj',
'		, pditm',
'		, pdlitm',
'		, pddsc2',
'		, imdsc1',
'		, imdsc2',
'		, pduorg',
'		, pdprrc',
'		, pdaexp',
'	from data.vt_comp_ordencompradet',
'	inner join data.t_corp_grupoaprobacion on pdkcoo = compania and pddoco = to_number(idobjeto) and pddcto = tipoobjeto',
'	where idgrupo = :p114_idgrupo and estado = ''AGRUPADO''',
') select apex_item.checkbox(1,apex_item_clave,''checked class="chkF01"'') seleccion',
'	, ''<span class="fa fa-eye" aria-hidden="true"></span>'' detalle',
'	, pdan8',
'	, abalph',
'	, count(distinct pddcco) pddcco',
'	, sum(pdprrc) pdprrc',
'	, sum(pdaexp) pdaexp',
'from w_base',
'group by apex_item_clave,pdan8,abalph;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P114_GRUPOOBJETO'
,p_plug_display_when_cond2=>'ORDENCOMPRA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20260702213724Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(76538752242016736)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>76538752242016736
,p_updated_on=>wwv_flow_imp.dz('20260702213724Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146172891216254509)
,p_db_column_name=>'SELECCION'
,p_display_order=>10
,p_column_identifier=>'P'
,p_column_label=>'<input type="checkbox" id="selectallodc">'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250825144245Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152009493122268206)
,p_db_column_name=>'DETALLE'
,p_display_order=>20
,p_column_identifier=>'R'
,p_column_label=>'-'
,p_column_link=>'f?p=&APP_ID.:115:&SESSION.::&DEBUG.:115:P115_IDGRUPO,P115_APROBADOR,P115_CODCRITERIO,P115_GRUPOOBJETO,P114_CODAGRUPADOR,P115_PARAMETRO_1:&P114_IDGRUPO.,&P114_APROBADOR.,&P114_CODCRITERIO.,&P114_GRUPOOBJETO.,&P114_CODAGRUPADOR.,#PDAN8#'
,p_column_linktext=>'#DETALLE#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250825144245Z')
,p_updated_on=>wwv_flow_imp.dz('20250825144944Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(76539156375016740)
,p_db_column_name=>'PDAN8'
,p_display_order=>30
,p_column_identifier=>'D'
,p_column_label=>unistr('C\00F3d. Proveedor')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250825144245Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(76539274183016741)
,p_db_column_name=>'ABALPH'
,p_display_order=>40
,p_column_identifier=>'E'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250825144245Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(76540187072016750)
,p_db_column_name=>'PDPRRC'
,p_display_order=>50
,p_column_identifier=>'N'
,p_column_label=>'P. Unitario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250825144245Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(77165263141330001)
,p_db_column_name=>'PDAEXP'
,p_display_order=>60
,p_column_identifier=>'O'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250825144245Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(152009316286268205)
,p_db_column_name=>'PDDCCO'
,p_display_order=>70
,p_column_identifier=>'Q'
,p_column_label=>'Cant. OCs'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250825143514Z')
,p_updated_on=>wwv_flow_imp.dz('20250825144245Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(77175913827345099)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_report_alias=>'771760'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_view_mode=>'REPORT'
,p_report_columns=>'SELECCION:DETALLE:ABALPH:PDDCCO:PDAEXP:'
,p_sort_column_1=>'PDDCCO'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'PDAEXP'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'DESC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_sum_columns_on_break=>'PDAEXP'
,p_updated_on=>wwv_flow_imp.dz('20250825145156Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(137038195487932515)
,p_plug_name=>'Liquidaciones'
,p_region_name=>'rptLiquidaciones'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with w_base as (',
'	select b.compania||''|''||b.codmodulo||''|''||b.idgrupo||''|''||b.aprobador||''|''||b.coddireccion apex_item_clave, a.*',
'	from data.vt_gliq_liquidacion a',
'	inner join data.t_corp_grupoaprobacion b on b.grupoobjeto = ''LIQUIDACION'' and a.idliq = b.idobjeto',
'	where b.idgrupo = :p114_idgrupo and b.estado = ''AGRUPADO''',
') select apex_item.checkbox(1,apex_item_clave,''checked class="chkF01"'') seleccion, x.* from w_base x'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P114_GRUPOOBJETO'
,p_plug_display_when_cond2=>'LIQUIDACION'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20250828060355Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(137038279848932516)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>137038279848932516
,p_updated_on=>wwv_flow_imp.dz('20250828060355Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146172912509254510)
,p_db_column_name=>'COMPANIA'
,p_display_order=>10
,p_column_identifier=>'P'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146173003562254511)
,p_db_column_name=>'IDLIQ'
,p_display_order=>20
,p_column_identifier=>'Q'
,p_column_label=>'ID Liq.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'00000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146173151282254512)
,p_db_column_name=>'USUARIO'
,p_display_order=>30
,p_column_identifier=>'R'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146173254519254513)
,p_db_column_name=>'NOMBRES'
,p_display_order=>40
,p_column_identifier=>'S'
,p_column_label=>'Nombres'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146173381417254514)
,p_db_column_name=>'CODUNIDADNEGOCIO'
,p_display_order=>50
,p_column_identifier=>'T'
,p_column_label=>unistr('C\00F3d. UN')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146173400223254515)
,p_db_column_name=>'UNIDADNEGOCIO'
,p_display_order=>60
,p_column_identifier=>'U'
,p_column_label=>'Unidad Negocio'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146173576209254516)
,p_db_column_name=>'FECHACREACION'
,p_display_order=>70
,p_column_identifier=>'V'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146173639050254517)
,p_db_column_name=>'TIPO'
,p_display_order=>80
,p_column_identifier=>'W'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146173745108254518)
,p_db_column_name=>'MONTO'
,p_display_order=>90
,p_column_identifier=>'X'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146173855562254519)
,p_db_column_name=>'SUBTOTALCERO'
,p_display_order=>100
,p_column_identifier=>'Y'
,p_column_label=>'Sub Total 0%'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146173954142254520)
,p_db_column_name=>'SUBTOTALDIVA'
,p_display_order=>110
,p_column_identifier=>'Z'
,p_column_label=>'Sub Total IVA'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146174070727254521)
,p_db_column_name=>'IVA'
,p_display_order=>120
,p_column_identifier=>'AA'
,p_column_label=>'IVA'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146174183681254522)
,p_db_column_name=>'VALORTOTAL'
,p_display_order=>130
,p_column_identifier=>'AB'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146174296413254523)
,p_db_column_name=>'FACTURA'
,p_display_order=>140
,p_column_identifier=>'AC'
,p_column_label=>'Factura'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146174345130254524)
,p_db_column_name=>'CODPROVEEDOR'
,p_display_order=>150
,p_column_identifier=>'AD'
,p_column_label=>'Cod. Proveedor'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'000000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146174492717254525)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>160
,p_column_identifier=>'AE'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146174595055254526)
,p_db_column_name=>'TIPOLIQUIDACION'
,p_display_order=>170
,p_column_identifier=>'AF'
,p_column_label=>'Tipo Liq.'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146174689871254527)
,p_db_column_name=>'NUMEROLIQUIDACION'
,p_display_order=>180
,p_column_identifier=>'AG'
,p_column_label=>'Numeroliquidacion'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146174749969254528)
,p_db_column_name=>'ESTADO'
,p_display_order=>190
,p_column_identifier=>'AH'
,p_column_label=>'Estado'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146174805493254529)
,p_db_column_name=>'DETALLEESTADO'
,p_display_order=>200
,p_column_identifier=>'AI'
,p_column_label=>'Detalleestado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146174945222254530)
,p_db_column_name=>'ESTADOAPROBACION'
,p_display_order=>210
,p_column_identifier=>'AJ'
,p_column_label=>'Estadoaprobacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146175057842254531)
,p_db_column_name=>'RUTAAPROBACION'
,p_display_order=>220
,p_column_identifier=>'AK'
,p_column_label=>'Rutaaprobacion'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146175153674254532)
,p_db_column_name=>'IDFLUJO'
,p_display_order=>230
,p_column_identifier=>'AL'
,p_column_label=>'Idflujo'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146175257603254533)
,p_db_column_name=>'USUARIOFLUJO'
,p_display_order=>240
,p_column_identifier=>'AM'
,p_column_label=>'Usuarioflujo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146175399416254534)
,p_db_column_name=>'OBJETIVO'
,p_display_order=>250
,p_column_identifier=>'AN'
,p_column_label=>'Objetivo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(146175452361254535)
,p_db_column_name=>'DETALLE'
,p_display_order=>260
,p_column_identifier=>'AO'
,p_column_label=>'Detalle'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(155929398182227101)
,p_db_column_name=>'APEX_ITEM_CLAVE'
,p_display_order=>270
,p_column_identifier=>'AP'
,p_column_label=>'Apex Item Clave'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250828055222Z')
,p_updated_on=>wwv_flow_imp.dz('20250828055222Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(155929445315227102)
,p_db_column_name=>'SELECCION'
,p_display_order=>280
,p_column_identifier=>'AQ'
,p_column_label=>'<input type="checkbox" id="selectallliq">'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250828055222Z')
,p_updated_on=>wwv_flow_imp.dz('20250828060247Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(146210081915775844)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1462101'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SELECCION:PROVEEDOR:IDLIQ:TIPO:FECHACREACION:UNIDADNEGOCIO:OBJETIVO:DETALLE:MONTO:'
,p_break_on=>'PROVEEDOR'
,p_break_enabled_on=>'PROVEEDOR'
,p_updated_on=>wwv_flow_imp.dz('20250828055347Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(137039843624932532)
,p_plug_name=>'Pagos Recurrentes'
,p_region_name=>'rptPagosRecurrentes'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pddoco',
'	, pddcto',
'	, pdlnid',
'	, pdan8',
'	, abalph',
'	, pdtrdj',
'	, pditm',
'	, pdlitm',
'	, ''<span''||case when pdlttr||''-''||pdnxtr = ''980-999'' then '' class="cancelado">'' else ''>'' end||trim(pdlitm)||'' - ''||decode(pdglc,''IN13'',pddsc1||'' ''||pddsc2,decode(pdlnty,''S '',imdsc1||'' ''||imdsc2 ||'' | ''||pditm,pddsc1||'' ''||pddsc2))||''</span>'' pddsc1',
'	, pddsc2',
'	, imdsc1',
'	, imdsc2',
'	, pduorg',
'	, pdprrc',
'	, pdaexp',
'from data.vt_comp_ordencompradet',
'inner join data.t_corp_grupoaprobacion on pdkcoo = compania and pddoco = to_number(idobjeto) and pddcto = tipoobjeto',
'where data.pk_commons.f_encrypt(agrupador) = :p114_codagrupador;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P114_GRUPOOBJETO'
,p_plug_display_when_cond2=>'PAGORECURRENTE'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20260702213724Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(137039978876932533)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>137039978876932533
,p_updated_on=>wwv_flow_imp.dz('20260702213724Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137040061848932534)
,p_db_column_name=>'PDDOCO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Orden Compra'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137040155439932535)
,p_db_column_name=>'PDDCTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo Orden'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137040299197932536)
,p_db_column_name=>'PDLNID'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>unistr('L\00EDnea')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137040365791932537)
,p_db_column_name=>'PDAN8'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>unistr('C\00F3d. Proveedor')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137040451783932538)
,p_db_column_name=>'ABALPH'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137040516722932539)
,p_db_column_name=>'PDTRDJ'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Solicitud'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137040694788932540)
,p_db_column_name=>'PDITM'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>unistr('C\00F3d. Corto')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137040718493932541)
,p_db_column_name=>'PDLITM'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>unistr('C\00F3d. Producto')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137040893214932542)
,p_db_column_name=>'PDDSC1'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137040941052932543)
,p_db_column_name=>'PDDSC2'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Pddsc2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137041030770932544)
,p_db_column_name=>'IMDSC1'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Imdsc1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137041147857932545)
,p_db_column_name=>'IMDSC2'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Imdsc2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137041285694932546)
,p_db_column_name=>'PDUORG'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Cant.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137041318436932547)
,p_db_column_name=>'PDPRRC'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'P. Unitario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137041446198932548)
,p_db_column_name=>'PDAEXP'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(137041568613932549)
,p_plug_name=>'Negociaciones'
,p_region_name=>'rptNegociaciones'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>60
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pddoco',
'	, pddcto',
'	, pdlnid',
'	, pdan8',
'	, abalph',
'	, pdtrdj',
'	, pditm',
'	, pdlitm',
'	, ''<span''||case when pdlttr||''-''||pdnxtr = ''980-999'' then '' class="cancelado">'' else ''>'' end||trim(pdlitm)||'' - ''||decode(pdglc,''IN13'',pddsc1||'' ''||pddsc2,decode(pdlnty,''S '',imdsc1||'' ''||imdsc2 ||'' | ''||pditm,pddsc1||'' ''||pddsc2))||''</span>'' pddsc1',
'	, pddsc2',
'	, imdsc1',
'	, imdsc2',
'	, pduorg',
'	, pdprrc',
'	, pdaexp',
'from data.vt_comp_ordencompradet',
'inner join data.t_corp_grupoaprobacion on pdkcoo = compania and pddoco = to_number(idobjeto) and pddcto = tipoobjeto',
'where data.pk_commons.f_encrypt(agrupador) = :p114_codagrupador;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P114_GRUPOOBJETO'
,p_plug_display_when_cond2=>'NEGOCIACION'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20260702213724Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(137041649136932550)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>137041649136932550
,p_updated_on=>wwv_flow_imp.dz('20260702213724Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145800628871570201)
,p_db_column_name=>'PDDOCO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Orden Compra'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145800756236570202)
,p_db_column_name=>'PDDCTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo Orden'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145800848067570203)
,p_db_column_name=>'PDLNID'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>unistr('L\00EDnea')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145800919097570204)
,p_db_column_name=>'PDAN8'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>unistr('C\00F3d. Proveedor')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145801096787570205)
,p_db_column_name=>'ABALPH'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145801157020570206)
,p_db_column_name=>'PDTRDJ'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Solicitud'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145801234762570207)
,p_db_column_name=>'PDITM'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>unistr('C\00F3d. Corto')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145801388238570208)
,p_db_column_name=>'PDLITM'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>unistr('C\00F3d. Producto')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145801466537570209)
,p_db_column_name=>'PDDSC1'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145801584736570210)
,p_db_column_name=>'PDDSC2'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Pddsc2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145801692452570211)
,p_db_column_name=>'IMDSC1'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Imdsc1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145801790126570212)
,p_db_column_name=>'IMDSC2'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Imdsc2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145801817300570213)
,p_db_column_name=>'PDUORG'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Cant.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145801986598570214)
,p_db_column_name=>'PDPRRC'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'P. Unitario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145802001658570215)
,p_db_column_name=>'PDAEXP'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(145802126593570216)
,p_plug_name=>unistr('Notas de Cr\00E9dito')
,p_region_name=>'rptNotasCredito'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>70
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pddoco',
'	, pddcto',
'	, pdlnid',
'	, pdan8',
'	, abalph',
'	, pdtrdj',
'	, pditm',
'	, pdlitm',
'	, ''<span''||case when pdlttr||''-''||pdnxtr = ''980-999'' then '' class="cancelado">'' else ''>'' end||trim(pdlitm)||'' - ''||decode(pdglc,''IN13'',pddsc1||'' ''||pddsc2,decode(pdlnty,''S '',imdsc1||'' ''||imdsc2 ||'' | ''||pditm,pddsc1||'' ''||pddsc2))||''</span>'' pddsc1',
'	, pddsc2',
'	, imdsc1',
'	, imdsc2',
'	, pduorg',
'	, pdprrc',
'	, pdaexp',
'from data.vt_comp_ordencompradet',
'inner join data.t_corp_grupoaprobacion on pdkcoo = compania and pddoco = to_number(idobjeto) and pddcto = tipoobjeto',
'where data.pk_commons.f_encrypt(agrupador) = :p114_codagrupador;'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P114_GRUPOOBJETO'
,p_plug_display_when_cond2=>'NOTACREDITO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20260702213643Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(145802206140570217)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>145802206140570217
,p_updated_on=>wwv_flow_imp.dz('20260702213643Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145802344889570218)
,p_db_column_name=>'PDDOCO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Orden Compra'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145802492566570219)
,p_db_column_name=>'PDDCTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo Orden'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145802591882570220)
,p_db_column_name=>'PDLNID'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>unistr('L\00EDnea')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145802643138570221)
,p_db_column_name=>'PDAN8'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>unistr('C\00F3d. Proveedor')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145802745812570222)
,p_db_column_name=>'ABALPH'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145802848169570223)
,p_db_column_name=>'PDTRDJ'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Solicitud'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145802952318570224)
,p_db_column_name=>'PDITM'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>unistr('C\00F3d. Corto')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145803079713570225)
,p_db_column_name=>'PDLITM'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>unistr('C\00F3d. Producto')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145803175134570226)
,p_db_column_name=>'PDDSC1'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145803241876570227)
,p_db_column_name=>'PDDSC2'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Pddsc2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145803311235570228)
,p_db_column_name=>'IMDSC1'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Imdsc1'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145803496406570229)
,p_db_column_name=>'IMDSC2'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Imdsc2'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145803591361570230)
,p_db_column_name=>'PDUORG'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Cant.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145803655254570231)
,p_db_column_name=>'PDPRRC'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'P. Unitario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145803749862570232)
,p_db_column_name=>'PDAEXP'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(160189706082976424)
,p_plug_name=>'Barra de accion'
,p_region_name=>'rptBarraAcciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>40
,p_plug_display_point=>'REGION_POSITION_01'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(77165312263330002)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(160189706082976424)
,p_button_name=>'BACK'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.:113::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(77183115451462661)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(160189706082976424)
,p_button_name=>'Aprobar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Aprobar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-thumbs-up'
,p_updated_on=>wwv_flow_imp.dz('20250827213128Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(77183598842462662)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(160189706082976424)
,p_button_name=>'Rechazar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Rechazar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_icon_css_classes=>'fa-thumbs-down'
,p_updated_on=>wwv_flow_imp.dz('20250827213128Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76537819592016727)
,p_name=>'P114_IDGRUPO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(76537218441016721)
,p_prompt=>'Idgrupo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76537952713016728)
,p_name=>'P114_APROBADOR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(76537218441016721)
,p_prompt=>'Aprobador'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76538069853016729)
,p_name=>'P114_CODCRITERIO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(76537218441016721)
,p_prompt=>'Codcriterio'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76538109158016730)
,p_name=>'P114_CODAGRUPADOR'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(76537218441016721)
,p_prompt=>'Codagrupador'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(137038002163932514)
,p_name=>'P114_GRUPOOBJETO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(76537218441016721)
,p_prompt=>'Grupoobjeto'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(152012620326268238)
,p_name=>'P114_USUARIO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(76537218441016721)
,p_prompt=>'Usuario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250827212328Z')
,p_updated_on=>wwv_flow_imp.dz('20250827212328Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(146512795896734614)
,p_name=>'Selecciona Todo OCs'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectallodc'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#rptOrdenCompra'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(146513104545734614)
,p_event_id=>wwv_flow_imp.id(146512795896734614)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#rptOrdenCompra #selectallodc'' ).is('':checked'')) {',
'    $(''#rptOrdenCompra input[type=checkbox][name=f01]'').prop(''checked'',true);',
'} else {',
'    $(''#rptOrdenCompra input[type=checkbox][name=f01]'').prop(''checked'',false);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(155929513396227103)
,p_name=>'Selecciona Todo LQ'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectallliq'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#rptLiquidaciones'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20250828055605Z')
,p_updated_on=>wwv_flow_imp.dz('20250828060346Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(155929604958227104)
,p_event_id=>wwv_flow_imp.id(155929513396227103)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#rptLiquidaciones #selectallliq'' ).is('':checked'')) {',
'    $(''#rptLiquidaciones input[type=checkbox][name=f01]'').prop(''checked'',true);',
'} else {',
'    $(''#rptLiquidaciones input[type=checkbox][name=f01]'').prop(''checked'',false);',
'}'))
,p_created_on=>wwv_flow_imp.dz('20250828055605Z')
,p_updated_on=>wwv_flow_imp.dz('20250828060346Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(155929732019227105)
,p_name=>'Selecciona Todo PgR'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectallpgr'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#rptPagosRecurrentes'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20250828060658Z')
,p_updated_on=>wwv_flow_imp.dz('20250828060658Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(155929804771227106)
,p_event_id=>wwv_flow_imp.id(155929732019227105)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#rptPagosRecurrentes #selectallpgr'' ).is('':checked'')) {',
'    $(''#rptPagosRecurrentes input[type=checkbox][name=f01]'').prop(''checked'',true);',
'} else {',
'    $(''#rptPagosRecurrentes input[type=checkbox][name=f01]'').prop(''checked'',false);',
'}'))
,p_created_on=>wwv_flow_imp.dz('20250828060658Z')
,p_updated_on=>wwv_flow_imp.dz('20250828060658Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(155929967075227107)
,p_name=>'Selecciona Todo Neg'
,p_event_sequence=>40
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectallneg'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#rptNegociaciones'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20250828061028Z')
,p_updated_on=>wwv_flow_imp.dz('20250828061028Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(155930089139227108)
,p_event_id=>wwv_flow_imp.id(155929967075227107)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#rptNegociaciones #selectallneg'' ).is('':checked'')) {',
'    $(''#rptNegociaciones input[type=checkbox][name=f01]'').prop(''checked'',true);',
'} else {',
'    $(''#rptNegociaciones input[type=checkbox][name=f01]'').prop(''checked'',false);',
'}'))
,p_created_on=>wwv_flow_imp.dz('20250828061028Z')
,p_updated_on=>wwv_flow_imp.dz('20250828061028Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(155930161071227109)
,p_name=>'Selecciona Todo NDC'
,p_event_sequence=>50
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectallndc'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#rptNotasCredito'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20250828061028Z')
,p_updated_on=>wwv_flow_imp.dz('20250828061028Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(155930201370227110)
,p_event_id=>wwv_flow_imp.id(155930161071227109)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#rptNotasCredito #selectallndc'' ).is('':checked'')) {',
'    $(''#rptNotasCredito input[type=checkbox][name=f01]'').prop(''checked'',true);',
'} else {',
'    $(''#rptNotasCredito input[type=checkbox][name=f01]'').prop(''checked'',false);',
'}'))
,p_created_on=>wwv_flow_imp.dz('20250828061028Z')
,p_updated_on=>wwv_flow_imp.dz('20250828061028Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(155646908716174605)
,p_process_sequence=>30
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetUp'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	begin	-- Usuarios',
'		:p114_usuario := ''JMALDONADO'';',
'		-- :p114_usuario := :app_user;',
'	end;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>155646908716174605
,p_created_on=>wwv_flow_imp.dz('20250827212247Z')
,p_updated_on=>wwv_flow_imp.dz('20250827212352Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(155644223954163810)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Aprobar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_opcion	varchar2(25);',
'v_dato		varchar2(4000);',
'v_log_app	varchar2(100);',
'v_log_dsc	varchar2(999);',
'v_log_msg	varchar2(999);',
'begin',
'	v_log_app	:= ''apex.130.114.Aprobar'';',
'	v_opcion	:= ''APROBAR'';',
'	for i in 1..apex_application.g_f01.count loop',
'		declare',
'			v_compania	varchar2(5);',
'			v_modulo	varchar2(4);',
'			v_idgrupo	number;',
'			v_aprobador	varchar2(25);',
'			v_criterio	varchar2(25);',
'			v_agrupador	varchar2(1000);',
'			v_an8		number;',
'		begin',
'			v_dato := apex_application.g_f01(i);',
'',
'			v_compania	:= regexp_substr(v_dato, ''[^|]+'', 1, 1);',
'			v_modulo	:= regexp_substr(v_dato, ''[^|]+'', 1, 2);',
'			v_idgrupo	:= regexp_substr(v_dato, ''[^|]+'', 1, 3);',
'			v_aprobador	:= regexp_substr(v_dato, ''[^|]+'', 1, 4);',
'			v_an8		:= regexp_substr(v_dato, ''[^|]+'', 1, 5);',
'',
'			v_log_dsc := ''v_compania: ''||v_compania||'', v_modulo: ''||v_modulo||'', v_idgrupo: ''||v_idgrupo;',
'			v_log_dsc := v_log_dsc||'', v_aprobador: ''||v_aprobador||'', v_an8: ''||v_an8;',
'',
'			data.pk_comp_reportes.sp_gestionaprobaciongrupo(',
'				  p_compania		=> v_compania',
'				, p_modulo			=> v_modulo',
'				, p_aplicacion		=> :app_id',
'				, p_pagina			=> :app_page_id',
'				, p_usuario			=> :p114_usuario',
'				, p_aprobador		=> v_aprobador',
'				, p_idgrupo			=> v_idgrupo',
'				, p_grupoobjeto		=> v_an8',
'				, p_objetos			=> null',
'				, p_opcion			=> v_opcion',
'				, p_respuesta		=> v_log_msg',
'			);',
'			data.pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,v_log_msg,null,null);',
'		end;',
'	end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>unistr('Ocurri\00F3 un error. Por favor comun\00EDquese con el Administrador.')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(77183115451462661)
,p_process_success_message=>unistr('Todos los \00EDtems seleccionados fueron aprobados.')
,p_internal_uid=>155644223954163810
,p_created_on=>wwv_flow_imp.dz('20250827212059Z')
,p_updated_on=>wwv_flow_imp.dz('20250828051655Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(155644739667165133)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Rechazar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_opcion	varchar2(25);',
'v_dato		varchar2(4000);',
'v_log_app	varchar2(100);',
'v_log_dsc	varchar2(999);',
'v_log_msg	varchar2(999);',
'begin',
'	v_log_app	:= ''apex.130.114.Rechazar'';',
'	v_opcion	:= ''RECHAZAR'';',
'	for i in 1..apex_application.g_f01.count loop',
'		declare',
'			v_compania	varchar2(5);',
'			v_modulo	varchar2(4);',
'			v_idgrupo	number;',
'			v_aprobador	varchar2(25);',
'			v_criterio	varchar2(25);',
'			v_agrupador	varchar2(1000);',
'			v_an8		number;',
'		begin',
'			v_dato := apex_application.g_f01(i);',
'',
'			v_compania	:= regexp_substr(v_dato, ''[^|]+'', 1, 1);',
'			v_modulo	:= regexp_substr(v_dato, ''[^|]+'', 1, 2);',
'			v_idgrupo	:= regexp_substr(v_dato, ''[^|]+'', 1, 3);',
'			v_aprobador	:= regexp_substr(v_dato, ''[^|]+'', 1, 4);',
'			v_an8		:= regexp_substr(v_dato, ''[^|]+'', 1, 5);',
'',
'			v_log_dsc := ''v_compania: ''||v_compania||'', v_modulo: ''||v_modulo||'', v_idgrupo: ''||v_idgrupo;',
'			v_log_dsc := v_log_dsc||'', v_aprobador: ''||v_aprobador||'', v_an8: ''||v_an8;',
'',
'			data.pk_comp_reportes.sp_gestionaprobaciongrupo(',
'				  p_compania		=> v_compania',
'				, p_modulo			=> v_modulo',
'				, p_aplicacion		=> :app_id',
'				, p_pagina			=> :app_page_id',
'				, p_usuario			=> :p114_usuario',
'				, p_aprobador		=> v_aprobador',
'				, p_idgrupo			=> v_idgrupo',
'				, p_grupoobjeto		=> v_an8',
'				, p_objetos			=> null',
'				, p_opcion			=> v_opcion',
'				, p_respuesta		=> v_log_msg',
'			);',
'			data.pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,v_log_msg,null,null);',
'		end;',
'	end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>unistr('Ocurri\00F3 un error. Por favor comun\00EDquese con el Administrador.')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(77183598842462662)
,p_process_success_message=>unistr('Todos los \00EDtems seleccionados fueron rechazados.')
,p_internal_uid=>155644739667165133
,p_created_on=>wwv_flow_imp.dz('20250827212112Z')
,p_updated_on=>wwv_flow_imp.dz('20250828051655Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
