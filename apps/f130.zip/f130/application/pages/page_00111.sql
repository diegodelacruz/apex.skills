prompt --application/pages/page_00111
begin
--   Manifest
--     PAGE: 00111
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>111
,p_name=>'IMP - Fecha Estimada ZM'
,p_alias=>'IMP-FECHA-ESTIMADA-ZM'
,p_step_title=>'IMP - Fecha Estimada ZM'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20231219195655Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240802205626Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(124608675550127038)
,p_plug_name=>'Reporte'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id',
'	, codigoetapa',
'	, tipooc || ''-'' || ordencompra oc',
'	, codigoproveedor',
'	, proveedor',
'	, forwarder',
'	, cnt20pies',
'	, cnt40pies',
'	, fechaetd',
'	, case',
'		when trim(bit_fechaeta) is null then to_char(fechaeta,''dd/mm/yyyy'')',
'		else ''<span style="font-weight: 700; color:#9763f6" title="''||bit_fechaeta||''">''||fechaeta||''</span>'' end fechaeta',
'	, case',
'		when (cnt20pies + cnt40pies) > 1 then data.pk_commons.f_add_wdays(fechaeta,4)',
'		else case ',
'			when instr(forwarder,''FEDEX'') > 0 or instr(forwarder,''DHL EXPRESS'') > 0 or instr(forwarder,''UPS'') > 0 then data.pk_commons.f_add_wdays(fechaeta,4)',
'			else data.pk_commons.f_add_wdays(fechaeta,6) end',
'		end fechazai',
'	, fechcrea',
'from vt_cmex_mesatrabajo where to_number(substr(codigoetapa,3,1)) < 7 and nvl(codigoproveedor,0) > 0'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Reporte'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20240802205626Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(124608783975127039)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>124608783975127039
,p_updated_on=>wwv_flow_imp.dz('20240802205626Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124608890298127040)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124608970861127041)
,p_db_column_name=>'CODIGOETAPA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Etapa'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(74279793258956227)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124609012182127042)
,p_db_column_name=>'OC'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124609186190127043)
,p_db_column_name=>'CODIGOPROVEEDOR'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>unistr('C\00F3d. Proveedor')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124609201563127044)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124609346195127045)
,p_db_column_name=>'FORWARDER'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Forwarder'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124609412061127046)
,p_db_column_name=>'CNT20PIES'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'CNT 20P'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124609592199127047)
,p_db_column_name=>'CNT40PIES'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'CNT 40P'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124609671753127048)
,p_db_column_name=>'FECHAETD'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fecha ETD'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(141992784207401404)
,p_db_column_name=>'FECHAETA'
,p_display_order=>100
,p_column_identifier=>'O'
,p_column_label=>'Fecha ETA'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(124609849597127050)
,p_db_column_name=>'FECHAZAI'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'Fecha ZAI'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(371022302261652432)
,p_db_column_name=>'FECHCREA'
,p_display_order=>130
,p_column_identifier=>'P'
,p_column_label=>'Fecha. Reg.'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240802205516Z')
,p_updated_on=>wwv_flow_imp.dz('20240802205516Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(141970508244718442)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1419706'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODIGOETAPA:OC:CODIGOPROVEEDOR:PROVEEDOR:FORWARDER:FECHAETA:FECHAZAI:FECHCREA:'
,p_sort_column_1=>'CODIGOETAPA'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'OC'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20231219195656Z')
,p_updated_on=>wwv_flow_imp.dz('20240802205626Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
