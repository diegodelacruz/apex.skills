prompt --application/pages/page_00245
begin
--   Manifest
--     PAGE: 00245
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>245
,p_name=>'Comentarios'
,p_alias=>'COMENTARIOS'
,p_page_mode=>'MODAL'
,p_step_title=>'Comentarios'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20240410163932Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240401161402Z')
,p_last_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(187246550491684714)
,p_name=>'Detalle'
,p_template=>wwv_flow_imp.id(296121421643169165)
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT X.ID,',
'       X.FLUJO_ID,       ',
'       X.FECHA_HASTA,',
'       X.ESTADO,',
'       X.USERID,',
'       X.ZCOMENTARIO',
'  FROM T_FLUJO_APROBACION_DET X, T_FLUJO_APROBACION_CAB Y',
'  WHERE Y.ENTIDAD_ID=:P245_ID AND Y.ENTIDAD_CLASE=''IMPORTACION_MUESTRAS'' AND Y.CODMODULO=''CMEX''',
'  AND Y.ID=X.FLUJO_ID',
''))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P245_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(187246692498684715)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(187246797304684716)
,p_query_column_id=>2
,p_column_alias=>'FLUJO_ID'
,p_column_display_sequence=>20
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(187246918717684718)
,p_query_column_id=>3
,p_column_alias=>'FECHA_HASTA'
,p_column_display_sequence=>40
,p_column_heading=>'Fecha '
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(187247072580684719)
,p_query_column_id=>4
,p_column_alias=>'ESTADO'
,p_column_display_sequence=>50
,p_column_heading=>'Estado'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(187247182928684720)
,p_query_column_id=>5
,p_column_alias=>'USERID'
,p_column_display_sequence=>60
,p_column_heading=>'Usuario'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(187247317752684722)
,p_query_column_id=>6
,p_column_alias=>'ZCOMENTARIO'
,p_column_display_sequence=>80
,p_column_heading=>'Comentario'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(187247781991684726)
,p_name=>'P245_ID'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
