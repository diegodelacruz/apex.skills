prompt --application/pages/page_00224
begin
--   Manifest
--     PAGE: 00224
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>224
,p_name=>unistr('Informaci\00F3n de Pago Recurrente')
,p_alias=>unistr('INFORMACI\00D3N-DE-PAGO-RECURRENTE')
,p_page_mode=>'NON_MODAL'
,p_step_title=>unistr('Informaci\00F3n de Pago Recurrente')
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(295596898750037659)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_created_on=>wwv_flow_imp.dz('20240522153553Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240531211655Z')
,p_created_by=>'DDELACRUZ'
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(300485796489773231)
,p_plug_name=>unistr('Par\00E1metros')
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info'
,p_plug_template=>wwv_flow_imp.id(295605160997037667)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'APP_USER'
,p_plug_display_when_cond2=>'DDELACRUZ'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20240522153728Z')
,p_updated_on=>wwv_flow_imp.dz('20240522153728Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(530275386621137712)
,p_plug_name=>'Datos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20240522154138Z')
,p_updated_on=>wwv_flow_imp.dz('20240522160232Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(300486403793773238)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(530275386621137712)
,p_button_name=>'GUARDAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P224_ESTADOPGR'
,p_button_condition2=>'RECHAZADO'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_created_on=>wwv_flow_imp.dz('20240522160232Z')
,p_updated_on=>wwv_flow_imp.dz('20240522165034Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(300486546481773239)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(530275386621137712)
,p_button_name=>'ENVIAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P224_ESTADOPGR'
,p_button_condition2=>'RECHAZADO'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_created_on=>wwv_flow_imp.dz('20240522160233Z')
,p_updated_on=>wwv_flow_imp.dz('20240522165034Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(300485861734773232)
,p_name=>'P224_IDNEG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(300485796489773231)
,p_prompt=>'ID Neg:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20240522153743Z')
,p_updated_on=>wwv_flow_imp.dz('20240522155739Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(300486284673773236)
,p_name=>'P224_ESTADONEG'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(300485796489773231)
,p_prompt=>'Estado Neg:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20240522155739Z')
,p_updated_on=>wwv_flow_imp.dz('20240522155739Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(300486309241773237)
,p_name=>'P224_ESTADOPGR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(300485796489773231)
,p_prompt=>'Estado PGR:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20240522155739Z')
,p_updated_on=>wwv_flow_imp.dz('20240522155739Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(300486694178773240)
,p_name=>'P224_VIGDESDE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(300485796489773231)
,p_prompt=>'Vigdesde'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240522161013Z')
,p_updated_on=>wwv_flow_imp.dz('20240522161013Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(300486775008773241)
,p_name=>'P224_VIGHASTA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(300485796489773231)
,p_prompt=>'Vigdesde'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240522161013Z')
,p_updated_on=>wwv_flow_imp.dz('20240522161013Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(323845233773126783)
,p_name=>'P224_TIPOMONTO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(530275386621137712)
,p_prompt=>'Tipo Monto:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_NEG_TIPOMONTO'
,p_lov=>'.'||wwv_flow_imp.id(240341499876606572)||'.'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20240522154138Z')
,p_updated_on=>wwv_flow_imp.dz('20240522160828Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(323845668731126784)
,p_name=>'P224_NUMEROPAGOS'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(530275386621137712)
,p_prompt=>unistr('N\00FAm. Pagos:')
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_created_on=>wwv_flow_imp.dz('20240522154138Z')
,p_updated_on=>wwv_flow_imp.dz('20240522160706Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(323846023623126785)
,p_name=>'P224_FECHAPRIMERPAGO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(530275386621137712)
,p_prompt=>'Primer Pago:'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'ITEM'
,p_attribute_05=>'P224_VIGDESDE'
,p_attribute_06=>'ITEM'
,p_attribute_08=>'P224_VIGHASTA'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'YEAR-PICKER'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
,p_created_on=>wwv_flow_imp.dz('20240522154138Z')
,p_updated_on=>wwv_flow_imp.dz('20240522161503Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(323846402800126785)
,p_name=>'P224_TIPOPAGO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(530275386621137712)
,p_prompt=>'Tipo Pago:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_NEG_TIPOPAGO'
,p_lov=>'.'||wwv_flow_imp.id(231130202278619882)||'.'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20240522154138Z')
,p_updated_on=>wwv_flow_imp.dz('20240522160828Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(323846889803126785)
,p_name=>'P224_TIPORECEPCION'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(530275386621137712)
,p_prompt=>unistr('Tipo Recepci\00F3n:')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_NEG_TIPORECEPCION'
,p_lov=>'.'||wwv_flow_imp.id(257467648715249911)||'.'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20240522154138Z')
,p_updated_on=>wwv_flow_imp.dz('20240522160828Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(323847218822126785)
,p_name=>'P224_COSTO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(530275386621137712)
,p_prompt=>'Costo Total:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240522154138Z')
,p_updated_on=>wwv_flow_imp.dz('20240522165442Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(323847616835126786)
,p_name=>'P224_FRECUENCIA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(530275386621137712)
,p_prompt=>'Frecuencia:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_NEG_FRECUENCIA'
,p_lov=>'.'||wwv_flow_imp.id(230185465636915585)||'.'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20240522154138Z')
,p_updated_on=>wwv_flow_imp.dz('20240531211655Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(323848005024126786)
,p_name=>'P224_REQUISITOR'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(530275386621137712)
,p_prompt=>'Requisitor'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P224_REQUISITOR'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240522154138Z')
,p_updated_on=>wwv_flow_imp.dz('20240522160613Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(300486175873773235)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetUp'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_idneg number;',
'begin',
'	v_idneg := :p224_idneg;',
'',
'	select frecuencia',
'		, numeropagos',
'		, tipopago',
'		, fechaprimerpago',
'		, tipomonto',
'		, tiporecepcion',
'		, estadoflujo',
'		, estadopagos',
'		, vigenciadesde',
'		, vigenciahasta',
'	into',
'		:p224_frecuencia',
'		, :p224_numeropagos',
'		, :p224_tipopago',
'		, :p224_fechaprimerpago',
'		, :p224_tipomonto',
'		, :p224_tiporecepcion',
'		, :p224_estadoneg',
'		, :p224_estadopgr',
'		, :p224_vigdesde',
'		, :p224_vighasta',
'	from t_comp_negociacion where recurrente = ''SI'' and id = v_idneg;',
'',
'	select to_char(costotal,''FML999G999G999G999G990D00'') into :p224_costo from vt_comp_mesatrabajopgr where idneg = v_idneg;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>300486175873773235
,p_created_on=>wwv_flow_imp.dz('20240522155037Z')
,p_updated_on=>wwv_flow_imp.dz('20240522165442Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(300486810355773242)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Guardar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_idneg number;',
'begin',
'	v_idneg := :p224_idneg;',
'',
'	update t_comp_negociacion x set',
'		x.frecuencia		= :p224_frecuencia',
'		, x.numeropagos		= :p224_numeropagos',
'		, x.tipopago		= :p224_tipopago',
'		, x.fechaprimerpago	= :p224_fechaprimerpago',
'		, x.tipomonto		= :p224_tipomonto',
'		, x.tiporecepcion	= :p224_tiporecepcion',
'	where recurrente = ''SI'' and id = v_idneg;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>unistr('Ocurri\00F3 un problema. P\00F3ngase en contacto con el administrador.')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(300486403793773238)
,p_process_success_message=>'Cambios Guardados.'
,p_internal_uid=>300486810355773242
,p_created_on=>wwv_flow_imp.dz('20240522164242Z')
,p_updated_on=>wwv_flow_imp.dz('20240522164807Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(300486929652773243)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Enviar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_compania	varchar2(5);',
'v_usuario	varchar2(25);',
'v_idneg		number;',
'v_respuesta	varchar2(500);',
'begin',
'	v_compania	:= :g_compania;',
'	v_usuario	:= :app_user;',
'	v_idneg		:= :p224_idneg;',
'',
'	pk_comp_negociacion.sp_enrutarpagorecurrente(v_compania,v_usuario,v_idneg,v_respuesta);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>unistr('Ocurri\00F3 un problema. P\00F3ngase en contacto con el administrador.')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(300486403793773238)
,p_process_success_message=>unistr('Pago Recurrente enviado a aprobaci\00F3n.')
,p_internal_uid=>300486929652773243
,p_created_on=>wwv_flow_imp.dz('20240522164807Z')
,p_updated_on=>wwv_flow_imp.dz('20240522164807Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
