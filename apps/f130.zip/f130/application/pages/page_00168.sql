prompt --application/pages/page_00168
begin
--   Manifest
--     PAGE: 00168
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>168
,p_name=>unistr('COMEX - Form. C\00E1lculo y Pago ISD')
,p_step_title=>unistr('COMEX - Form. C\00E1lculo y Pago ISD')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'',
'function calcularCT_ISD(event){',
'    ',
'    if (apex.item("P168_ISD").getValue() == "" || apex.item("P168_ISD").getValue() == null){ //comprueba la seleccion de la partida',
'             alert("Debe seleccionar la partida");',
'            console.log(event);       ',
'            event.preventDefault();',
'       ',
'    } else {',
'        ',
'    var fobUnitario = apex.item("P168_VALORFOBUNITARIO").getValue() + "";',
'    var fleteExterior = apex.item("P168_FLETEEXTERIOR").getValue() + "";',
'    var seguroexterior = apex.item("P168_SEGUROEXTERIOR").getValue()+ "";',
'',
'            const  r = /^[0-9]{1,12}(\,{0,1}[0-9]{1,2}){0,1}/; //',
'',
'        if (r.test(fobUnitario) == false){',
'            alert("Formato Incorrecto");',
'                apex.item("P168_VALORFOBUNITARIO" ).setStyle( "color", "red" );',
unistr('                apex.item("P168_VALORCIF").setValue("\00A1ERROR!");'),
'                apex.item("P168_VALORCIF").setStyle( "color", "red" ); ',
'         }',
'        if (r.test(fleteExterior) == false){',
'            alert("Formato Incorrecto");',
'                apex.item( "P168_FLETEEXTERIOR" ).setStyle( "color", "red" );',
unistr('                apex.item("P168_VALORCIF").setValue("\00A1ERROR!");'),
'                apex.item("P168_VALORCIF").setStyle( "color", "red" );',
'         }',
'        if (r.test(seguroexterior) == false){',
'                alert("Formato Incorrecto");',
'                apex.item( "P168_SEGUROEXTERIOR" ).setStyle( "color", "red" );',
unistr('                apex.item("P168_VALORCIF").setValue("\00A1ERROR!");'),
'                apex.item("P168_VALORCIF").setStyle( "color", "red" );',
'         }',
'            if (r.test(fobUnitario) == true &&  r.test(fleteExterior) == true && r.test(seguroexterior) == true ){',
'                apex.item( "P168_VALORFOBUNITARIO" ).setStyle( "color", "black" );',
'                apex.item( "P168_FLETEEXTERIOR" ).setStyle( "color", "black" );',
'                apex.item( "P168_SEGUROEXTERIOR" ).setStyle( "color", "black" );',
'             ',
'                apex.server.process("CalculoValor",',
'                   {pageItems: "#P168_VALORFOBUNITARIO,#P168_FLETEEXTERIOR,#P168_SEGUROEXTERIOR,#P168_PORCENTAJE_ISD,#P168_ISD"},',
'                    {dataType: "json",',
'                        success: function(pData){',
'                                console.log(pData);',
'                            apex.item("P168_VALORCIF").setValue(pData.cif);',
'                            apex.item("P168_VALORCIF").setStyle( "color", "blue" );',
'                            apex.item("P168_VALORISD").setValue(pData.isd);',
'                            apex.item("P168_VALORISD").setStyle( "color", "blue" );',
'                            ',
'                            apex.item("P168_CTISD").setValue(pData.ct_isd);',
'                            apex.item("P168_CTISD").setStyle( "color", "blue" );',
'                            apex.item("P168_GASTOISD").setValue(pData.gt_isd);',
'                            apex.item("P168_GASTOISD").setStyle( "color", "blue" );',
'                            ',
'                            apex.item("P168_BASECOMPROBANTE_RETENCION").setValue(pData.baseImponibleRet);',
'                            apex.item("P168_BASECOMPROBANTE_RETENCION").setStyle( "color", "blue" );',
'                            ',
'                      }',
'                     }',
'                );//Fin apex.server.process',
'             } ',
'        }',
'   }    ',
'',
'',
'function validateNumber(event) {',
'  var keyCode = event.keyCode;',
unistr('  var excludedKeys = [8, 37, 39, 46, 188];//Teclas extra que queremos que el campo acepte aparte de los n\00FAmeros, como el backspace'),
unistr('//Realizamos la validaci\00F3n de la tecla ingresada'),
'  if (!((keyCode >= 48 && keyCode <= 57) || (keyCode >= 96 && keyCode <= 105) || (excludedKeys.includes(keyCode)))) {',
'        event.preventDefault();',
'  }    ',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_created_on=>wwv_flow_imp.dz('20230708132657Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260409205546Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79245940343195244)
,p_plug_name=>'Listado Productos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296120613521169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'calculo.ID,',
'calculo.PAISPROVEEDOR,',
'(SELECT DESCRIPCION from DATA.T_CORP_UDC ',
'WHERE ID_CABECERA = ''663'' AND ACTIVO = ''S'' and valor2=''1'' AND ID_TABLA = calculo.PAISPROVEEDOR) as PAIS_DESCRIPCION,',
'calculo.CODIGOPRODUCTO,',
'(SELECT NOMBREPRODUCTO FROM DATA.VT_JDE_PRODUCTOS WHERE CODIGOCORTO = calculo.CODIGOPRODUCTO) AS NOMBRE_PRODUCTO, ',
'calculo.ID_PARTIDAARANCELARIA,',
'(SELECT DESCRIPCION FROM T_CMEX_PARTIDAARANCELARIA WHERE ID = calculo.ID_PARTIDAARANCELARIA) AS PARTIDA_DISPLAY,',
'calculo.VALORFOBUNITARIO,',
'calculo.FLETEEXTERIOR,',
'calculo.SEGUROEXTERIOR,',
'calculo.VALORISD,',
'calculo.CTISD,',
'calculo.GASTOISD,',
'calculo.BASECOMPROBANTE_RETENCION,',
'calculo.FECHA_PAGO,',
'calculo.CONFIRMACION_CONTABLE,',
'calculo.ID_CMEX_MESATRABAJO,',
'calculo.FECHALIQUIDACION',
'FROM DATA.T_CMEX_CALCULOYPAGOISD calculo',
'WHERE ID_CMEX_MESATRABAJO = :P168_ID_CMEX_MESATRABAJO'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P168_ID_CMEX_MESATRABAJO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(79246038430195245)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:168:&SESSION.::&DEBUG.:RP,168:P168_ID,P168_ID_CMEX_MESATRABAJO:#ID#,#ID_CMEX_MESATRABAJO#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-pencil.png" class="apex-edit-pencil" alt="">'
,p_owner=>'NETBY3'
,p_internal_uid=>79246038430195245
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79246564575195250)
,p_db_column_name=>'ID_PARTIDAARANCELARIA'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Id Partidaarancelaria'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79527085703966401)
,p_db_column_name=>'VALORFOBUNITARIO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Valor FOB Unitario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79527121478966402)
,p_db_column_name=>'FLETEEXTERIOR'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Flete Exterior'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79527202942966403)
,p_db_column_name=>'SEGUROEXTERIOR'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Seguro Exterior'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79527343028966404)
,p_db_column_name=>'VALORISD'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Valor ISD'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79527428259966405)
,p_db_column_name=>'CTISD'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'CT ISD'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79527599190966406)
,p_db_column_name=>'GASTOISD'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Gasto ISD'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79527697464966407)
,p_db_column_name=>'BASECOMPROBANTE_RETENCION'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>unistr('Base Comprobante Retenci\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79527750795966408)
,p_db_column_name=>'FECHA_PAGO'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Fecha Pago'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79527842927966409)
,p_db_column_name=>'CONFIRMACION_CONTABLE'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>unistr('Confirmaci\00F3n Contable')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79527952380966410)
,p_db_column_name=>'FECHALIQUIDACION'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>unistr('Fecha Liquidaci\00F3n')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79528508006966416)
,p_db_column_name=>'ID'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>' Editar'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79528692699966417)
,p_db_column_name=>'PAISPROVEEDOR'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>unistr('Pa\00EDs Proveedor')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79528767107966418)
,p_db_column_name=>'CODIGOPRODUCTO'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Codigo producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79528859241966419)
,p_db_column_name=>'ID_CMEX_MESATRABAJO'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Id Cmex Mesatrabajo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79529064484966421)
,p_db_column_name=>'PAIS_DESCRIPCION'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Pais Proveedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79529171260966422)
,p_db_column_name=>'NOMBRE_PRODUCTO'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79529221347966423)
,p_db_column_name=>'PARTIDA_DISPLAY'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Partida Arancelaria'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(79537346553967357)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'795374'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:NOMBRE_PRODUCTO:PAISPROVEEDOR:VALORFOBUNITARIO:FLETEEXTERIOR:SEGUROEXTERIOR:VALORISD:CTISD:GASTOISD:BASECOMPROBANTE_RETENCION:FECHA_PAGO:CONFIRMACION_CONTABLE:FECHALIQUIDACION:PAIS_DESCRIPCION:'
,p_created_on=>wwv_flow_imp.dz('20230708132657Z')
,p_updated_on=>wwv_flow_imp.dz('20230708132657Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79528070213966411)
,p_plug_name=>'PARAMETROS'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_region_attributes=>'style = "display: none;"'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79528276717966413)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79783758048097219)
,p_plug_name=>'Formulario'
,p_region_name=>'dlgForm'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size720x480'
,p_region_attributes=>'style="width : 1024;"'
,p_plug_template=>wwv_flow_imp.id(295627185797037684)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79516825186962151)
,p_plug_name=>'Formulario Calculo y Pago ISD'
,p_parent_plug_id=>wwv_flow_imp.id(79783758048097219)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79784539650097227)
,p_plug_name=>'GrupoBotones'
,p_parent_plug_id=>wwv_flow_imp.id(79783758048097219)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(79517466529962153)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(79784539650097227)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Delete'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition_type=>'NEVER'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(79517510919962153)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(79528276717966413)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Cancel'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:167:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(79517322653962153)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(79784539650097227)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P168_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(79517218057962153)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(79784539650097227)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P168_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(79519181066962160)
,p_branch_action=>'f?p=&APP_ID.:168:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79519513493962163)
,p_name=>'P168_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(79516825186962151)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79519971204962176)
,p_name=>'P168_PAISPROVEEDOR'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(79516825186962151)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Pais Proveedor'
,p_source=>'PAISPROVEEDOR'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_PAISES_JDE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select drdl01 d, drky r',
'from vt_jde_udcjde ',
'where drsy = ''00'' and drrt = ''CN'' and drky != ''*'' order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20240410195746Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79520334353962181)
,p_name=>'P168_CODIGOPRODUCTO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(79516825186962151)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Codigo Producto'
,p_source=>'CODIGOPRODUCTO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79520779756962181)
,p_name=>'P168_ID_PARTIDAARANCELARIA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(79516825186962151)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Partida Arancelaria'
,p_post_element_text=>'<br><p id="mensajeValores" style =" font-size:10px;color: red;">.</p>'
,p_source=>'ID_PARTIDAARANCELARIA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'SELECT DESCRIPCION, ID FROM T_CMEX_PARTIDAARANCELARIA'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_inline_help_text=>'Para poder cargar los valores solicitados debe seleccionar los datos de la partida arancelaria'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79521149364962182)
,p_name=>'P168_VALORFOBUNITARIO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(79516825186962151)
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_prompt=>'Valor FOB Unitario'
,p_source=>'VALORFOBUNITARIO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_icon_css_classes=>'fa-dollar'
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79521516779962182)
,p_name=>'P168_FLETEEXTERIOR'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(79516825186962151)
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_prompt=>'Flete Exterior'
,p_source=>'FLETEEXTERIOR'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_icon_css_classes=>'fa-dollar'
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79521947377962182)
,p_name=>'P168_SEGUROEXTERIOR'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(79516825186962151)
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_prompt=>'Seguro Exterior'
,p_source=>'SEGUROEXTERIOR'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_icon_css_classes=>'fa-dollar'
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79522390846962182)
,p_name=>'P168_VALORISD'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(79516825186962151)
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_prompt=>'ISD'
,p_source=>'VALORISD'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_tag_attributes=>'readonly = "readonly"'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_icon_css_classes=>'fa-dollar'
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79522755745962184)
,p_name=>'P168_CTISD'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(79516825186962151)
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_prompt=>'Considerado CT ISD'
,p_source=>'CTISD'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_tag_attributes=>'readonly = "readonly"'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_icon_css_classes=>'fa-dollar'
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79523132749962184)
,p_name=>'P168_GASTOISD'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(79516825186962151)
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_prompt=>'Considerado GASTO ISD'
,p_source=>'GASTOISD'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_tag_attributes=>'readonly = "readonly"'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_icon_css_classes=>'fa-dollar'
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79523593943962184)
,p_name=>'P168_BASECOMPROBANTE_RETENCION'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(79516825186962151)
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_prompt=>unistr('Base Imponible Comprobante Retenci\00F3n')
,p_source=>'BASECOMPROBANTE_RETENCION'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_attributes=>'readonly = "readonly"'
,p_grid_label_column_span=>4
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79523918083962184)
,p_name=>'P168_FECHA_PAGO'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(79516825186962151)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fecha Pago'
,p_source=>'FECHA_PAGO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79524376756962185)
,p_name=>'P168_CONFIRMACION_CONTABLE'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(79516825186962151)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Confirmacion Contable'
,p_source=>'CONFIRMACION_CONTABLE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>2
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79524747238962185)
,p_name=>'P168_ID_CMEX_MESATRABAJO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(79528070213966411)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id Cmex Mesatrabajo'
,p_source=>'ID_CMEX_MESATRABAJO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79525127002962185)
,p_name=>'P168_FECHALIQUIDACION'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(79516825186962151)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Fecha Liquidaci\00F3n')
,p_source=>'FECHALIQUIDACION'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79528919937966420)
,p_name=>'P168_ORDENCOMPRA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(79528070213966411)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Ordencompra'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79783888659097220)
,p_name=>'P168_DISPLAY_PRODUCTO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(79516825186962151)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Producto'
,p_source=>'P168_CODIGOPRODUCTO'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_PRODUCTOS_JDE'
,p_lov=>'SELECT trim(imdsc1)||'' (''||trim(imlitm)||'')'' AS DESCRIPCION, trim(imlitm) AS CODIGO FROM F4101@jdedtadl where substr(imglpt,1,2) = ''IN'''
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79783925100097221)
,p_name=>'P168_ISD'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(79516825186962151)
,p_prompt=>'ISD Partida Arancelaria'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79784069222097222)
,p_name=>'P168_REFRENDO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(79516825186962151)
,p_prompt=>'Refrendo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79784123906097223)
,p_name=>'P168_VALORCIF'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(79516825186962151)
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_prompt=>'Valor CIF'
,p_source=>'VALORCIF'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_tag_attributes=>'readonly = "readonly"'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_icon_css_classes=>'fa-dollar'
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79785785091097239)
,p_name=>'P168_PORCENTAJE_ISD'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(79516825186962151)
,p_use_cache_before_default=>'NO'
,p_prompt=>'%'
,p_post_element_text=>'%'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681811193037723)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(79783592973097217)
,p_name=>'AbrirFormulario'
,p_event_sequence=>10
,p_condition_element=>'P168_ID'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79783655219097218)
,p_event_id=>wwv_flow_imp.id(79783592973097217)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(79516825186962151)
,p_attribute_01=>'openModal(''dlgForm'');'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79784787952097229)
,p_event_id=>wwv_flow_imp.id(79783592973097217)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT NOMBREPRODUCTO INTO :P168_DISPLAY_PRODUCTO FROM VT_JDE_PRODUCTOS WHERE CODIGOCORTO = :P168_CODIGOPRODUCTO;',
' '))
,p_attribute_02=>'P168_CODIGOPRODUCTO'
,p_attribute_03=>'P168_DISPLAY_PRODUCTO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(79784853500097230)
,p_name=>'CargaPartidaArancelaria'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P168_ID_PARTIDAARANCELARIA'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79784989988097231)
,p_event_id=>wwv_flow_imp.id(79784853500097230)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P168_ISD,P168_PORCENTAJE_ISD'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'SELECT CREDITOTRIBUTARIO, PORCENTAJEISD FROM T_CMEX_PARTIDAARANCELARIA WHERE ID = :P168_ID_PARTIDAARANCELARIA'
,p_attribute_07=>'P168_ID_PARTIDAARANCELARIA'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(79785003279097232)
,p_name=>'Calcular'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P168_VALORFOBUNITARIO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79785183113097233)
,p_event_id=>wwv_flow_imp.id(79785003279097232)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P168_VALORCIF'
,p_attribute_01=>'calcularCT_ISD(event);'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(79785280607097234)
,p_name=>'CalcularISD2'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P168_FLETEEXTERIOR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79785317265097235)
,p_event_id=>wwv_flow_imp.id(79785280607097234)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P168_VALORCIF'
,p_attribute_01=>'calcularCT_ISD(event);'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(79785406215097236)
,p_name=>'CalcularISD3'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P168_SEGUROEXTERIOR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79785533336097237)
,p_event_id=>wwv_flow_imp.id(79785406215097236)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P168_VALORCIF'
,p_attribute_01=>'calcularCT_ISD(event);'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(79785882187097240)
,p_name=>'ValidarCampo'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P168_VALORFOBUNITARIO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79785988792097241)
,p_event_id=>wwv_flow_imp.id(79785882187097240)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P168_VALORFOBUNITARIO'
,p_attribute_01=>'validateNumber(event);'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(79786191017097243)
,p_name=>'ValidarCampo2'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P168_FLETEEXTERIOR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79786206949097244)
,p_event_id=>wwv_flow_imp.id(79786191017097243)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P168_FLETEEXTERIOR'
,p_attribute_01=>'validateNumber(event);'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(79786345404097245)
,p_name=>'Validar3'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P168_SEGUROEXTERIOR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keydown'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79786496113097246)
,p_event_id=>wwv_flow_imp.id(79786345404097245)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P168_SEGUROEXTERIOR'
,p_attribute_01=>'validateNumber(event);'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(79786522635097247)
,p_name=>'HabilitarCampos'
,p_event_sequence=>90
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P168_ISD'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79786614545097248)
,p_event_id=>wwv_flow_imp.id(79786522635097247)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P168_VALORFOBUNITARIO,P168_FLETEEXTERIOR,P168_SEGUROEXTERIOR'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$x(''P168_VALORFOBUNITARIO'').readOnly = false;',
'$x(''P168_FLETEEXTERIOR'').readOnly = false;',
'$x(''P168_SEGUROEXTERIOR'').readOnly = false;'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(79786752563097249)
,p_name=>'BloqueaCampos'
,p_event_sequence=>100
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79786890613097250)
,p_event_id=>wwv_flow_imp.id(79786752563097249)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P168_VALORFOBUNITARIO,P168_FLETEEXTERIOR,P168_SEGUROEXTERIOR'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (apex.item("P168_ISD").getValue() == null || apex.item("P168_ISD").getValue() == "" ){',
'$x(''P168_VALORFOBUNITARIO'').readOnly = true;',
'$x(''P168_FLETEEXTERIOR'').readOnly = true;',
'$x(''P168_SEGUROEXTERIOR'').readOnly = true;',
'}'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(79528487965966415)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CopiarProductos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_var VARCHAR2(2);',
'CURSOR productosOrden IS',
'SELECT CODIGO_PRODUCTO FROM                ',
' (SELECT detalleOrdenes.PDITM AS CODIGO_PRODUCTO, detalleOrdenes.PDAN8 AS CODIGO_PROVEEDOR, detalleOrdenes.PDDOCO AS ORDEN_COMPRA, ',
' productos.CODIGOCORTO, productos.NOMBREPRODUCTO',
' FROM F4311@jdedtadl detalleOrdenes , DATA.vt_jde_productos productos ',
' WHERE detalleOrdenes.PDDOCO = :P168_ORDENCOMPRA',
' and detalleOrdenes.PDITM = productos.CODIGOCORTO) productosOrden,',
' data.T_CMEX_MESATRABAJO mesa',
' WHERE productosOrden.codigo_proveedor = mesa.codigoproveedor',
' and productosorden.orden_compra = mesa.ordencompra',
' and (CODIGO_PRODUCTO, mesa.id) NOT IN (SELECT CODIGOPRODUCTO, ID_CMEX_MESATRABAJO FROM DATA.T_CMEX_CALCULOYPAGOISD calculo ',
'                WHERE ID_CMEX_MESATRABAJO = :P168_ID_CMEX_MESATRABAJO);',
'BEGIN ',
'FOR producto IN productosOrden ',
'LOOP',
'INSERT INTO DATA.T_CMEX_CALCULOYPAGOISD(ID, CODIGOPRODUCTO, ID_CMEX_MESATRABAJO )',
'VALUES(NULL, producto.CODIGO_PRODUCTO, :P168_ID_CMEX_MESATRABAJO);',
'v_var := ''A'';',
'',
'END LOOP;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE ',
'v_contadorIngresados NUMBER;',
'v_contadorOriginal NUMBER;',
'BEGIN ',
'SELECT COUNT(calculo.CODIGOPRODUCTO) INTO v_contadorIngresados',
'FROM DATA.T_CMEX_CALCULOYPAGOISD calculo',
'WHERE ID_CMEX_MESATRABAJO = :P168_ID_CMEX_MESATRABAJO;',
'',
'',
'SELECT count(CODIGO_PRODUCTO) INTO v_contadorOriginal FROM                ',
' (SELECT detalleOrdenes.PDITM AS CODIGO_PRODUCTO, detalleOrdenes.PDAN8 AS CODIGO_PROVEEDOR, detalleOrdenes.PDDOCO AS ORDEN_COMPRA, ',
' productos.CODIGOCORTO, productos.NOMBREPRODUCTO',
' FROM F4311@jdedtadl detalleOrdenes , DATA.vt_jde_productos productos ',
' WHERE detalleOrdenes.PDDOCO = :P168_ORDENCOMPRA',
' and detalleOrdenes.PDITM = productos.CODIGOCORTO) productosOrden;',
' ',
' IF v_contadorIngresados = v_contadorOriginal THEN ',
'     RETURN FALSE;',
' END IF;',
'',
'END;',
''))
,p_process_when_type=>'FUNCTION_BODY'
,p_process_when2=>'PLSQL'
,p_internal_uid=>79528487965966415
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(79525988966962188)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from T_CMEX_CALCULOYPAGOISD'
,p_attribute_02=>'T_CMEX_CALCULOYPAGOISD'
,p_attribute_03=>'P168_ID'
,p_attribute_04=>'ID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>79525988966962188
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(79526394904962188)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of T_CMEX_CALCULOYPAGOISD'
,p_attribute_02=>'T_CMEX_CALCULOYPAGOISD'
,p_attribute_03=>'P168_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>79526394904962188
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(79526708679962188)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(79517466529962153)
,p_internal_uid=>79526708679962188
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(79785674820097238)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'CalculoValor'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_cif NUMBER;',
'    v_isd NUMBER;',
'    c_porcentajeISD NUMBER := 5;',
'    c_porcentajeArancel NUMBER;',
'    v_ct_isd NUMBER;',
'    v_gt_isd NUMBER;',
'    v_aplicaISD NUMBER;',
'    v_baseImpRetencion NUMBER;',
'    ',
'BEGIN ',
'',
'APEX_DEBUG_MESSAGE.ENABLE_DEBUG_MESSAGES(p_level => 3);',
'',
'APEX_DEBUG_MESSAGE.LOG_MESSAGE(',
'    p_message => '' ::P168_PORCENTAJE_ISD = '' ||   :P168_PORCENTAJE_ISD ,',
'    p_level => 1 );    ',
'',
'APEX_DEBUG_MESSAGE.LOG_MESSAGE(',
'    p_message => '' ::P168_ISD = '' ||   :P168_ISD ,',
'    p_level => 1 ); ',
'',
'        IF :P168_ISD IN (''SI'',''Si'',''si'') THEN v_aplicaISD := 1; ELSE v_aplicaISD := -1; END IF;',
'',
'       IF :P168_VALORFOBUNITARIO IS NULL THEN',
'           :P168_VALORFOBUNITARIO := 0;',
'       END IF;',
'        IF :P168_FLETEEXTERIOR IS NULL THEN',
'           :P168_FLETEEXTERIOR := 0;',
'       END IF;',
'        IF :P168_SEGUROEXTERIOR IS NULL THEN',
'           :P168_SEGUROEXTERIOR := 0;',
'       END IF;',
'       ',
'    v_cif := :P168_VALORFOBUNITARIO + :P168_FLETEEXTERIOR + :P168_SEGUROEXTERIOR;',
'    v_isd := v_cif * (c_porcentajeISD / 100);',
'    IF v_aplicaISD > 0 THEN ',
'        v_ct_isd := :P168_VALORFOBUNITARIO * (:P168_PORCENTAJE_ISD / 100);',
'        v_gt_isd := (:P168_FLETEEXTERIOR + :P168_SEGUROEXTERIOR) * (:P168_PORCENTAJE_ISD / 100);',
'    ELSE',
'        v_gt_isd := (:P168_VALORFOBUNITARIO + :P168_FLETEEXTERIOR + :P168_SEGUROEXTERIOR) * (:P168_PORCENTAJE_ISD / 100); ',
'        v_ct_isd := 0;',
'    END IF;',
'    ',
'    v_baseImpRetencion := v_cif;',
'',
'apex_json.open_object;',
'apex_json.write(''cif'', ROUND(v_cif, 2 ));',
'apex_json.write(''isd'', ROUND(v_isd, 2 ));',
'apex_json.write(''ct_isd'', ROUND(v_ct_isd, 2 ));',
'apex_json.write(''gt_isd'', ROUND(v_gt_isd, 2 ));',
'apex_json.write(''baseImponibleRet'', ROUND(v_baseImpRetencion, 2 ));',
'',
'apex_json.close_object;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>79785674820097238
);
wwv_flow_imp.component_end;
end;
/
