prompt --application/pages/page_00164
begin
--   Manifest
--     PAGE: 00164
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>164
,p_name=>'Muestras - Registro'
,p_step_title=>'Muestras - Registro'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'',
'function borrarArchivo ( numArchivo ){',
'    ',
'    apex.item("P164_NUMARCHIVO").setValue(numArchivo);',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_created_on=>wwv_flow_imp.dz('20230708132656Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260409204700Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77306516670494823)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77307517678494833)
,p_plug_name=>'ParametrosEtapa'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_region_attributes=>'style = "display : none;"'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77322536649568135)
,p_plug_name=>'Formulario Mesa Trabajo Muestras y Courier'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77306855220494826)
,p_plug_name=>'ET1 - &P164_ETAPA1.'
,p_region_name=>'ET1'
,p_parent_plug_id=>wwv_flow_imp.id(77322536649568135)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(295619229174037679)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77306909983494827)
,p_plug_name=>'ET2 - &P164_ETAPA2.'
,p_region_name=>'ET2'
,p_parent_plug_id=>wwv_flow_imp.id(77322536649568135)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(295619229174037679)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77453085253149623)
,p_plug_name=>'barraAccionEtapa2'
,p_parent_plug_id=>wwv_flow_imp.id(77306909983494827)
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77453159700149624)
,p_plug_name=>'Formulario ET2'
,p_parent_plug_id=>wwv_flow_imp.id(77306909983494827)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77307041040494828)
,p_plug_name=>'ET3 - &P164_ETAPA3.'
,p_region_name=>'ET3'
,p_parent_plug_id=>wwv_flow_imp.id(77322536649568135)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(295619229174037679)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77307123981494829)
,p_plug_name=>'ET4 - &P164_ETAPA4.'
,p_region_name=>'ET4'
,p_parent_plug_id=>wwv_flow_imp.id(77322536649568135)
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(295619229174037679)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77452623956149619)
,p_plug_name=>'Archivos'
,p_region_name=>'DlgsubirArchivos'
,p_region_template_options=>'js-modal:js-draggable:js-resizable:js-dialog-size720x480'
,p_plug_template=>wwv_flow_imp.id(295627185797037684)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77453494104149627)
,p_plug_name=>'Form'
,p_parent_plug_id=>wwv_flow_imp.id(77452623956149619)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(77453584991149628)
,p_name=>'Listado'
,p_parent_plug_id=>wwv_flow_imp.id(77452623956149619)
,p_template=>wwv_flow_imp.id(296121421643169165)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUMEROARCHIVO,',
'      dbms_lob.getlength(blobcontent) blobcontent,',
'       FILENAME,',
'       ID_TABLA,',
'       TIPO,',
'       OBSERVACION,',
'       FECHA,',
'       NOMBREUSUARIO,',
'       NUMEROARCHIVO AS BORRAR',
'  from FILES.T_APEX_ARCHIVOS',
'  WHERE ESTADO = ''1'' ',
'  AND TABLA = ''T_CMEX_MUESTRASCOURIER''',
'  AND TIPO  IN (SELECT VALOR FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''CMEX_ET2FI'' UNION SELECT VALOR FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''CMEX_ET4FI'')  ',
'  AND ID_TABLA = :P164_ID;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(77453657128149629)
,p_query_column_id=>1
,p_column_alias=>'NUMEROARCHIVO'
,p_column_display_sequence=>1
,p_column_heading=>'Archivo'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:164:&SESSION.:APPLICATION_PROCESS=G_PROC_DESCARGARARCHIVO:&DEBUG.:RP:G_NUMEROARCHIVO:#NUMEROARCHIVO#'
,p_column_linktext=>'<span class="fa fa-download" aria-hidden="true"></span>'
,p_column_link_attr=>'target="_blank" download'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(77453720122149630)
,p_query_column_id=>2
,p_column_alias=>'BLOBCONTENT'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(77453811078149631)
,p_query_column_id=>3
,p_column_alias=>'FILENAME'
,p_column_display_sequence=>3
,p_column_heading=>'Filename'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(77453999105149632)
,p_query_column_id=>4
,p_column_alias=>'ID_TABLA'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(77454099769149633)
,p_query_column_id=>5
,p_column_alias=>'TIPO'
,p_column_display_sequence=>5
,p_column_heading=>'Tipo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION, VALOR FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''CMEX_ET2FI''',
'UNION',
'SELECT DESCRIPCION, VALOR FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''CMEX_ET4FI'''))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(77454100534149634)
,p_query_column_id=>6
,p_column_alias=>'OBSERVACION'
,p_column_display_sequence=>6
,p_column_heading=>'Observacion'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(77454213250149635)
,p_query_column_id=>7
,p_column_alias=>'FECHA'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(77454332484149636)
,p_query_column_id=>8
,p_column_alias=>'NOMBREUSUARIO'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(77454442543149637)
,p_query_column_id=>9
,p_column_alias=>'BORRAR'
,p_column_display_sequence=>9
,p_column_heading=>'Borrar'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript: borrarArchivo ( #NUMEROARCHIVO# );'
,p_column_linktext=>'<span aria-hidden="true" class="fa fa-trash-o"></span>'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77454754129149640)
,p_plug_name=>'Barradeaccionesmodal'
,p_parent_plug_id=>wwv_flow_imp.id(77452623956149619)
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(77323240927568136)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(77306516670494823)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:157:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(77452900663149622)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(77453085253149623)
,p_button_name=>'SUBIR_ARCHIVOS'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Subir Archivos'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-file-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(77454877506149641)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(77454754129149640)
,p_button_name=>'Subir'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Subir'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(77323104785568136)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(77306516670494823)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Eliminar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P164_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-trash'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(77323035053568136)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(77306516670494823)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P164_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(77322926650568136)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(77306516670494823)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P164_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(77324825187568140)
,p_branch_name=>'Go To Page 164'
,p_branch_action=>'f?p=&APP_ID.:164:&SESSION.::&DEBUG.:164:P164_ID:&P164_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
,p_branch_condition_type=>'REQUEST_NOT_EQUAL_CONDITION'
,p_branch_condition=>'DELETE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(80462366232347015)
,p_branch_name=>'Go to '
,p_branch_action=>'f?p=&APP_ID.:157:&SESSION.::&DEBUG.:RP,157::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>11
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77306735158494825)
,p_name=>'P164_NUMEROORDEN_OI'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(77453159700149624)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Numero OI'
,p_source=>'NUMEROORDEN_OI'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77307320044494831)
,p_name=>'P164_ID_PARTIDAARANCELARIA'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(77306855220494826)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Partida Arancelaria'
,p_source=>'ID_PARTIDAARANCELARIA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>'SELECT PARTIDA FROM T_CMEX_PARTIDAARANCELARIA'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'N'
,p_attribute_09=>'4'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77307452472494832)
,p_name=>'P164_ENVIOCONNUMEROOI'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(77306855220494826)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Envi\00F3 Con N\00FAmero OI')
,p_source=>'ENVIOCONNUMEROOI'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:Si;SI,No;NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'6'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77307608868494834)
,p_name=>'P164_ETAPA1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(77307517678494833)
,p_prompt=>'Etapa1'
,p_source=>'SELECT DESCRIPCION FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''CMEX_ET_MC'' AND VALOR = ''ET1'';'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77307772416494835)
,p_name=>'P164_ETAPA2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(77307517678494833)
,p_prompt=>'Etapa2'
,p_source=>'SELECT DESCRIPCION FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''CMEX_ET_MC'' AND VALOR = ''ET2'';'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77307890720494836)
,p_name=>'P164_ETAPA3'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(77307517678494833)
,p_prompt=>'Etapa3'
,p_source=>'SELECT DESCRIPCION FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''CMEX_ET_MC'' AND VALOR = ''ET3'';'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77307941653494837)
,p_name=>'P164_ETAPA4'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(77307517678494833)
,p_prompt=>'Etapa4'
,p_source=>'SELECT DESCRIPCION FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''CMEX_ET_MC'' AND VALOR = ''ET4'';'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77325247843568143)
,p_name=>'P164_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(77322536649568135)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77325685224568149)
,p_name=>'P164_ESTADO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(77322536649568135)
,p_use_cache_before_default=>'NO'
,p_item_default=>'ET1'
,p_source=>'ESTADO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77326066432568152)
,p_name=>'P164_EMPRESATRANSPORTISTA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(77306855220494826)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Empresa Transportista'
,p_source=>'EMPRESATRANSPORTISTA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_CMEX_EMPRESATRANSPORTE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DESCRIPCION as d,',
'       VALOR as r',
'  from DATA.T_CORP_UDC',
'  WHERE ID_CABECERA = ''CMEX_TRANS''',
' order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77326452251568152)
,p_name=>'P164_NUMEROGUIA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(77306855220494826)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('N\00FAmero Gu\00EDa')
,p_source=>'NUMEROGUIA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77326820710568152)
,p_name=>'P164_REMITENTE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(77306855220494826)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Remitente'
,p_source=>'REMITENTE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>'select  trim(ABALPH) AS DESCRIPCION from f0101@jdedtadl inner join f0401@jdedtadl on aban8 = a6an8;'
,p_cSize=>32
,p_cMaxlength=>30
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77327606330568152)
,p_name=>'P164_FECHANOTIFICACION'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(77306855220494826)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Fecha Notificaci\00F3n')
,p_source=>'FECHANOTIFICACION'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77328053262568154)
,p_name=>'P164_NUMEROLIQUIDACION'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(77453159700149624)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('N\00FAmero Liquidaci\00F3n')
,p_source=>'NUMEROLIQUIDACION'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>30
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77328456677568154)
,p_name=>'P164_REFERENDO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(77453159700149624)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Referendo'
,p_source=>'REFERENDO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77328836811568154)
,p_name=>'P164_UNIDADNEGOCIO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(77453159700149624)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Unidad Negocio'
,p_source=>'UNIDADNEGOCIO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_UNIDADNEGOCIO'
,p_lov=>'select trim(mcmcu)||'' - ''||trim(mcdc) as d, trim(mcmcu) as r from f0006@jdedtadl order by trim(mcdc)'
,p_cSize=>30
,p_cMaxlength=>15
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240416145335Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77329251297568154)
,p_name=>'P164_FACTURA'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(77307041040494828)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Factura'
,p_source=>'FACTURA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>25
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77329604657568154)
,p_name=>'P164_VALOR'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(77307041040494828)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Valor'
,p_source=>'VALOR'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77332029019568158)
,p_name=>'P164_OBSERVACIONES'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(77306855220494826)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Observaciones'
,p_source=>'OBSERVACIONES'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>500
,p_cHeight=>4
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77452730119149620)
,p_name=>'P164_DOCUMENTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(77453494104149627)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Documento'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'NATIVE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77452875052149621)
,p_name=>'P164_TIPO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(77453494104149627)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION, VALOR FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''CMEX_ET2FI''',
'UNION',
'SELECT DESCRIPCION, VALOR FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''CMEX_ET4FI''',
'AND VALOR NOT IN ''ET4_6'';'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(77454654483149639)
,p_name=>'P164_OBS_ARCHIVO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(77453494104149627)
,p_prompt=>unistr('Observaci\00F3n Archivo')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80461646827347008)
,p_name=>'P164_NUMARCHIVO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(77453494104149627)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(77309292134494850)
,p_name=>unistr('Habilitaci\00F3nItem')
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P164_ENVIOCONNUMEROOI'
,p_condition_element=>'P164_ENVIOCONNUMEROOI'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'SI'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77451874357149611)
,p_event_id=>wwv_flow_imp.id(77309292134494850)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P164_UNIDADNEGOCIO'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77451996923149612)
,p_event_id=>wwv_flow_imp.id(77309292134494850)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P164_NUMEROORDEN_OI'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77452143709149614)
,p_event_id=>wwv_flow_imp.id(77309292134494850)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P164_UNIDADNEGOCIO'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
':P164_UNIDADNEGOCIO := NULL;',
'END;'))
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77452248902149615)
,p_event_id=>wwv_flow_imp.id(77309292134494850)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P164_NUMEROORDEN_OI'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
':P164_NUMEROORDEN_OI := NULL;',
'END;'))
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77450837389149601)
,p_event_id=>wwv_flow_imp.id(77309292134494850)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P164_NUMEROORDEN_OI'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77450961219149602)
,p_event_id=>wwv_flow_imp.id(77309292134494850)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P164_UNIDADNEGOCIO'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(77451081618149603)
,p_name=>'OI_SI'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P164_ENVIOCONNUMEROOI'
,p_display_when_cond2=>'SI'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77451190412149604)
,p_event_id=>wwv_flow_imp.id(77451081618149603)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P164_NUMEROORDEN_OI'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77451294835149605)
,p_event_id=>wwv_flow_imp.id(77451081618149603)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P164_UNIDADNEGOCIO'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(77451389818149606)
,p_name=>'OI_NO'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P164_ENVIOCONNUMEROOI'
,p_display_when_cond2=>'NO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77451463627149607)
,p_event_id=>wwv_flow_imp.id(77451389818149606)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P164_UNIDADNEGOCIO'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77451527519149608)
,p_event_id=>wwv_flow_imp.id(77451389818149606)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P164_NUMEROORDEN_OI'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(77452474301149617)
,p_name=>'ExpandeRegion'
,p_event_sequence=>40
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77452507624149618)
,p_event_id=>wwv_flow_imp.id(77452474301149617)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var etapa = apex.item("P164_ESTADO").getValue();',
'$("#"+etapa).find("button.t-Button--hideShow").eq(0).click();',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(77453223500149625)
,p_name=>'abrirModal'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(77452900663149622)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(77453386269149626)
,p_event_id=>wwv_flow_imp.id(77453223500149625)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(77452623956149619)
,p_attribute_01=>'javascript:openModal(''DlgsubirArchivos'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(80461750178347009)
,p_name=>'Borrar'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P164_NUMARCHIVO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(80462256654347014)
,p_event_id=>wwv_flow_imp.id(80461750178347009)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'BORRAR'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(77332887523568160)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from T_CMEX_MUESTRASCOURIER'
,p_attribute_02=>'T_CMEX_MUESTRASCOURIER'
,p_attribute_03=>'P164_ID'
,p_attribute_04=>'ID'
,p_internal_uid=>77332887523568160
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(80462158017347013)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Elimina Archivo'
,p_process_sql_clob=>'delete from files.t_apex_archivos where numeroarchivo = :p164_numarchivo;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P164_NUMARCHIVO'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>80462158017347013
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(77452390483149616)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Validaci\00F3n Etapas')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_totalArchivos	number;',
'v_arch1			number;',
'v_arch2			number;',
'v_mensaje		clob;',
'v_cor_rem		varchar2(100);',
'v_cor_des		varchar2(100);',
'v_empresa		varchar2(200);',
'begin',
'	-- ETAPA 1',
'	if :p164_empresatransportista is not null and :p164_numeroguia is not null and :p164_remitente is not null and :p164_fechanotificacion is not null and :p164_id_partidaarancelaria is not null and :p164_envioconnumerooi is not null then',
'		:P164_ESTADO := ''ET2'';',
'',
'		select pk_cmex_mesatrabajo.f_validaarchivos_et2imp(p_cabeceraudc => ''CMEX_ET2FI'', p_tabla => ''T_CMEX_MUESTRASCOURIER'', p_idmesa => :p164_id, p_numerorequerido => 0) into v_arch1 from dual;',
'',
'		select pk_cmex_mesatrabajo.f_validaarchivos_et2imp(p_cabeceraudc => ''CMEX_ET4FI'', p_tabla => ''T_CMEX_MUESTRASCOURIER'', p_idmesa => :p164_id, p_numerorequerido => 0) into v_arch2 from dual;',
'		',
'		if v_arch1 = 1 and v_arch2 = 1 then v_totalarchivos := 1; else v_totalarchivos := 0; end if;',
'		',
'		if :p164_numeroliquidacion is not null and :p164_referendo is not null and ((:p164_unidadnegocio is not null and :p164_envioconnumerooi = ''NO'') or (:p164_envioconnumerooi = ''SI'' and :p164_numeroorden_oi is not null)) and v_totalarchivos > 0 then',
'			:p164_estado := ''ET3'';',
'',
'			if :p164_factura is not null and :p164_valor is not null then ',
'				:p164_estado := ''ET4'';',
'',
'				for listado in (select valor, descripcion from data.t_corp_udc where id_cabecera = ''CMEX_NOTMC'' and activo = 1)	loop',
'					v_cor_des := listado.valor || '','' || v_cor_des;',
'				end loop;			',
'',
'				apex_debug_message.enable_debug_messages(p_level => 3);',
'',
'				apex_debug_message.log_message(p_message => '' v_cor_des1 = '' ||v_cor_des,p_level => 1);',
'',
'				select descripcion into v_empresa from data.t_corp_udc where id_cabecera = ''CMEX_TRANS'' and valor = :p164_empresatransportista;',
'',
'				v_cor_rem := ''notificaciones@zaimella.com'';',
'				v_cor_des := substr(v_cor_des,1,length(v_cor_des)-1);',
'',
'				apex_debug_message.log_message(p_message => ''v_cor_des2 = '' ||v_cor_des,p_level => 1);',
'',
'				v_mensaje := ''<h2>Entrega de muestras y courier</h2><br><p>Estimado se le notifica que la empresa ''||v_empresa||'' se encuentra proxima a entregar un paquete con el numero de guia ''||:p164_numeroguia|| ''.</p> <br> <p>Saludos.</p>'';',
'',
'				data.pk_commons.sp_apex_correohtml(v_mensaje,v_mensaje);',
'',
'				data.pk_commons.sp_apex_correo(',
unistr('					p_aplicacion		=>''apex.130.164.notificaci\00F3n'''),
'					, p_remitente		=> v_cor_rem',
'					, p_para			=> v_cor_des',
'					, p_concopia		=> null',
'					, p_concopiaoculta	=> null',
'					, p_asunto			=> ''Correo de Prueba''',
'					, p_contenido		=> v_mensaje);',
'			end if;',
'		end if;',
'	else',
'		:p164_estado := ''ET1'';',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'DELETE'
,p_process_when_type=>'REQUEST_NOT_EQUAL_CONDITION'
,p_internal_uid=>77452390483149616
,p_updated_on=>wwv_flow_imp.dz('20230825163839Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(77333263210568161)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of T_CMEX_MUESTRASCOURIER'
,p_attribute_02=>'T_CMEX_MUESTRASCOURIER'
,p_attribute_03=>'P164_ID'
,p_attribute_04=>'ID'
,p_attribute_09=>'P164_ID'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>77333263210568161
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(77454555515149638)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar Archivos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_valor number;',
'begin',
'	data.pk_apex_archivos.sp_creararchivo(:p164_documento,''T_CMEX_MUESTRASCOURIER'',:p164_id,:p164_tipo,:p164_obs_archivo,:app_user,v_valor);',
'',
'	update files.t_apex_archivos set estado = 1 where numeroarchivo = v_valor;',
'',
'	:p164_documento := null;',
'	:p164_obs_archivo := null;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(77454877506149641)
,p_internal_uid=>77454555515149638
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(77333655395568163)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(77323104785568136)
,p_internal_uid=>77333655395568163
);
wwv_flow_imp.component_end;
end;
/
