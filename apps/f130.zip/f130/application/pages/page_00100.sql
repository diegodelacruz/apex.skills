prompt --application/pages/page_00100
begin
--   Manifest
--     PAGE: 00100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>100
,p_name=>'Mesa de Trabajo'
,p_step_title=>'Mesa de Trabajo'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();',
'',
'$(''.apex-rds'').data(''onRegionChange'', function(mode, activeTab) {',
'	apex.item( "P100_TIPO" ).setValue(activeTab.href);',
'',
'	$(''#btnAgregarNeg'').hide();',
'',
'	switch($v(''P100_TIPO'')) { ',
'		case ''#rptLiquidacion'': 			apex.region("rptLiquidacion").refresh();break;',
'		case ''#rptCosto'': 					apex.region("rptCosto").refresh();break;',
'		case ''#rptNotasCredito'': 			apex.region("rptNotasCredito").refresh();break;',
'		case ''#rptDescuentoCantidad'': 		apex.region("rptDescuentoCantidad").refresh();break;',
'		case ''#rptNegociacion'': 			apex.region("rptNegociacion").refresh();$(''#btnAgregarNeg'').show();break;',
'		case ''#rptPagosRecurrentes'': 		apex.region("rptPagosRecurrentes").refresh();$(''#btnAgregarNeg'').show();break;',
'		case ''#rptCEGrupoZML'': 			    apex.region("rptCEGrupoZML").refresh();break;',
'	}',
'});',
'$(secItems).hide();'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-button.a-IRR-sortWidget-button[data-option="hide"], .a-IRR-button.a-IRR-sortWidget-button[data-option="freeze"]{',
'	display:none;',
'}',
'.a-IG-controls-item--aggregate, .a-IG-controls-item--controlBreak, .a-IG-controls-item--groupBy, .a-IG-reportSummary-item--aggregate, .a-IG-reportSummary-item--controlBreak, .a-IG-reportSummary-item--groupBy, .a-IRR-controls-item--aggregate, .a-IRR-c'
||'ontrols-item--controlBreak, .a-IRR-controls-item--groupBy, .a-IRR-reportSummary-item--aggregate, .a-IRR-reportSummary-item--controlBreak, .a-IRR-reportSummary-item--groupBy {',
'	--a-report-controls-cell-label-icon-background-color: #3b83bd;',
'	--a-report-controls-cell-label-hover-background-color: #e6f0f7;',
'	display: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'13'
,p_last_updated_on=>wwv_flow_imp.dz('20260624193504Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5828353747060259)
,p_plug_name=>'Barra de accion'
,p_region_name=>'rptBarraAcciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(5828472683060260)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(92124188920074031)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(295630388916037685)
,p_plug_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(340844196558805010)
,p_plug_name=>'Mesa'
,p_region_name=>'tblMesa'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:t-TabsRegion-mod--fillLabels:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_imp.id(295637154502037690)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(60860131750781201)
,p_plug_name=>'&P100_LC_MRK.'
,p_region_name=>'rptLiquidacion'
,p_parent_plug_id=>wwv_flow_imp.id(340844196558805010)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with mo as (',
'	select mesa.*',
'		, (',
'			select estado from (',
'				select estado',
'					, entidad_id',
'					, entidad_clase',
'				from t_flujo_aprobacion_cab a',
'				where codmodulo = ''COMP''',
'			) aproba',
'			where cast(entidad_id as numeric) = mesa.numero',
'				and entidad_clase = mesa.tipo',
'				and rownum = 1',
'		) estadoflujo1',
'		, pk_corp_flujoaprobacion.f_gestioncolor(:app_user,aprobador,estado,:g_compania,''COMP'') css',
'		, pk_corp_flujoaprobacion.f_aprobadorflujo(:app_user,aprobador,:app_modulo,:g_compania) aprobadorflujo',
'		, pk_corp_flujoaprobacion.f_mesaiconoruta(aprobador) ruta',
'	from vt_comp_mesatrabajo mesa',
'	where 1 = 1',
'		-- and :p100_tipo = ''#rptLiquidacion''',
'		and compania = :g_compania',
'		and (',
'				(:p100_estado = 2 and fechaorden between :p100_fecha_inicio and :p100_fecha_fin)',
'				or',
'				(:p100_estado = 1 and aprobador is not null and pk_corp_flujoaprobacion.f_aprobadorflujo(:app_user,aprobador,:app_modulo,:g_compania) = 1)',
'			)',
'		and (',
'			unidadnegocio = ''RUTA CONFIDENCIAL             ''',
'			and pk_admi_gestionparametros.f_admi_accesoacciones(:app_modulo,:app_user,:app_page_id,''CONFIDENCIAL'') = 1 or unidadnegocio != ''RUTA CONFIDENCIAL             ''',
'			)',
'), lstor as (',
'	select apex_page.get_url(',
'			p_application	=> 100,',
'			p_page			=> 401,',
'			p_items			=> ''P401_TABLA,P401_ID,P401_TIPO,P401_ESTADO'',',
'			p_values		=> (select ''T_COMP_ORDENES,''||pdoorn||'',''||pdocto||'',0'' from f4311@jdedtadl where pddoco = ord.numero and pddcto = ord.tipo and rownum = 1)',
'			) url_adjunto',
'		, case when pk_apex_archivos.f_cantidadarchivos(',
'			p_tabla			=> ''T_COMP_ORDENES'',',
'			p_idtabla		=> (select pdoorn from f4311@jdedtadl where pddoco = ord.numero and pddcto = ord.tipo and rownum = 1),',
'			p_tipo			=> (select pdocto from f4311@jdedtadl where pddoco = ord.numero and pddcto = ord.tipo and rownum = 1)) > 0',
'			then ''<span class="fa fa-paperclip" aria-hidden="true"></span>'' else '''' end adjunto',
'		, apex_page.get_url (',
'			p_application	=> 100,',
'			p_page			=> 401,',
'			p_items			=> ''P401_TABLA,P401_ID,P401_TIPO,P401_ESTADO'',',
'			p_values		=> ''T_COMP_ORDENES,''||ord.numero||'',''||ord.tipo||'',0'') url_adjunto_c',
'		, case when pk_apex_archivos.f_cantidadarchivos (',
'			p_tabla			=> ''T_COMP_ORDENES'',',
'			p_idtabla		=> ord.numero,',
'			p_tipo			=> ord.tipo) > 0',
'			then ''<span class="fa fa-paperclip" aria-hidden="true"></span>'' else '''' end adjunto_c',
'		-- , decode(aprobadorflujo,1,apex_item.checkbox(1,tipo||''-''||numero,''checked class="chkF01"''),'''') seleccion',
'		, ''COM'' tipodata',
'		, :p100_gestionlotecom gestion',
'		, aprobadorflujo',
'		, apex_page.get_url (',
'			p_application	=> 130,',
'			p_page			=> 101,',
'			p_items			=> ''P101_NUMERO,P101_TIPO,P101_APROBADOR,P101_SOLICITANTE,P101_COMPRADOR'',',
'			p_values		=> cast(numero as varchar(20))||'',''||cast(tipo as varchar(150))||'',''||cast(aprobador as varchar(150))||'',''||cast(solicitante as varchar2(150))||'',''||cast(compradorerp as varchar2(150))',
'			) url',
'		, ord.numero numero',
'		, ord.numero id',
'		, cast(ord.tipo as varchar(150)) tipo',
'		, ord.solicitante',
'		, ord.unidadnegocio',
'		, ord.proveedor',
'		, ord.aprobador',
'		, cast(ord.comprador as varchar(150)) comprador',
'		, ord.compradorerp',
'		, ord.valor valor',
'		, ord.valor valorliquidado',
'		, 0 valorpagar',
'		, estadoflujo1 estado',
'		, ord.fechaflujo',
'		, ord.fechaorden fechaorden',
'		, ord.fechaentrega fechaentrega',
'		, cast(ord.compania as varchar(10)) compania',
'		, null detalleid',
'		, null token',
'		, ord.estado estadoaprobacion',
'		, pk_comp_ordenescompra.f_descripcionlinea(numero,tipo,0) descripcion',
'		, ruta',
'		, cast(ord.tipo as varchar(150)) objeto',
'		, numero objeto_id',
'		,''True'' todo  ',
'		, pk_corp_flujoaprobacion.f_mesaorden(css) orden',
'		, css',
'		, null nivelalerta',
'	from mo ord',
'), ml as (',
'	select mesa.*',
'		, (',
'			select estado from (',
'				select estado,entidad_id from t_flujo_aprobacion_cab a where codmodulo = ''GLIQ'' order by id desc)',
'			where rownum = 1 and cast(entidad_id as numeric) = mesa.id) estadoflujo1',
'		, pk_corp_flujoaprobacion.f_gestioncolor(:app_user,aprobador,estado,:g_compania,''GLIQ'') css',
'	from vt_gliq_mesatrabajo mesa',
'	where 1 = 1',
'		-- and :p100_tipo = ''#rptLiquidacion''',
'		and compania = :g_compania',
'		and (',
'				(:p100_estado = 2 and trunc(fechacreacion) between :p100_fecha_inicio and :p100_fecha_fin)',
'				or',
'				(:p100_estado = 1 and aprobador is not null and pk_corp_flujoaprobacion.f_aprobadorflujo(:app_user,aprobador,:app_modulo,:g_compania) = 1)',
'			)',
'), lstli as (',
'	select '''' url_adjunto',
'		, '''' adjunto',
'		, '''' url_adjunto_c',
'		, '''' adjunto_c',
'		-- , case',
'		-- 	when pk_corp_flujoaprobacion.f_aprobadorflujo(:app_user,aprobador,:app_modulo,:g_compania) = 1 and estadoaprobacion = ''P''',
'		-- 		then apex_item.checkbox(2,ID,''class="chkF02"'') else '''' end seleccion',
'		, ''LIQ'' tipodata',
'		, :p100_gestionloteliq gestion',
'		, pk_corp_flujoaprobacion.f_aprobadorflujo(:app_user,aprobador,:app_modulo,:g_compania) aprobadorflujo',
'		, case',
'			when pk_corp_flujoaprobacion.f_aprobadorflujo(:app_user,aprobador,:app_modulo,:g_compania) = 1',
'				then :p100_liq_aprobacion||''?detalleId=''||detalleid||''&token=''||token else :p100_liq_aprobacion||''?liquidacionId=''||id end url',
'		, liquid.id numero',
'		, liquid.id id',
'		, cast(liquid.tipo as varchar(150)) tipo',
'		, liquid.solicitante',
'		, liquid.unidadnegocio',
'		, liquid.proveedor',
'		, liquid.aprobador',
'		, null comprador',
'		, null compradorerp',
'		-- , cast(liquid.solicitante as varchar(150)) comprador1',
'		, nvl(liquid.monto,0) valor',
'		, nvl(liquid.valorliquidado,0) valorliquidado',
'		, liquid.valorpagar valorpagar',
'		, estadoflujo1 estado',
'		, liquid.fechaflujo',
'		, liquid.fechacreacion fechaorden',
'		, liquid.fechacreacion fechaentrega',
'		, cast(liquid.compania as varchar(10))compania',
'		, liquid.detalleid detalleid',
'		, liquid.token token',
'		, liquid.estadoaprobacion estadoaprobacion',
'		, liquid.detalle descripcion',
'		, pk_corp_flujoaprobacion.f_mesaiconoruta(aprobador) ruta',
'		, ''Liquidacion'' objeto',
'		, id objeto_id',
'		, ''True'' todo',
'		, pk_corp_flujoaprobacion.f_mesaorden(css) orden',
'		, css',
'		, case when substr(lower(liquid.tipo),1,4) in (''liqu'',''caja'') then',
'			case',
'				when nvl(liquid.valorliquidado,0) >= 50 and nvl(liquid.valorliquidado,0) < 100 then 1',
'				when nvl(liquid.valorliquidado,0) >= 100 then 3',
'				else 0 end end nivelalerta',
'	from ml liquid',
'), pr as (',
'	select p.idneg',
'		, p.codproveedor',
'		, p.proveedor',
'		, p.estado',
'		, p.estadopagos',
'		, p.usrcomprador',
'		, p.usrrequisitor',
'		, p.usrvalidador',
'		, p.aprobador',
'		, cast(p.unidadnegociogasto as nchar(30)) unidadnegocio',
'		, p.flujodesde',
'		, p.fechaneg',
'		, p.costotal',
'		, p.observacion',
'		, ''PAGORECURRENTE'' objeto',
'		, ''Pago Recurrente FIJO-''||p.tipomonto tipo',
'		, :p100_gestionloteliq gestion',
'		, :g_compania compania',
'		, pk_corp_flujoaprobacion.f_gestioncolor(:app_user,p.aprobador,p.estadopagos,:g_compania,:app_modulo) css',
'		, pk_corp_flujoaprobacion.f_aprobadorflujo(:app_user,p.aprobador,:app_modulo,:g_compania) aprobadorflujo',
'		, pk_corp_flujoaprobacion.f_mesaiconoruta(p.aprobador) ruta',
'	from vt_comp_mesatrabajopgr p',
'	where 1 = 1',
'		and (',
'			(:p100_estado = 1 and estadopagos = ''EN_PROCESO'' and aprobador is not null and data.pk_corp_flujoaprobacion.f_aprobadorflujo(:app_user,aprobador,:app_modulo,:g_compania) = 1)',
'			or',
'			(:p100_estado = 2 and trunc(fechaneg) between :p100_fecha_inicio and :p100_fecha_fin)',
'			)',
'		and (',
'			unidadnegocio != ''CONFIDENCIAL'' or pk_admi_gestionparametros.f_admi_accesoacciones(:app_modulo,:app_user,:app_page_id,''CONFIDENCIAL'') = 1',
'			)',
'), lstpr as (',
'	select '''' url_adjunto',
'		, '''' adjunto',
'		, '''' url_adjunto_c',
'		, '''' adjunto_c',
'		-- , '''' seleccion',
'		, ''PGR'' tipodata',
'		, pr.gestion',
'		, pr.aprobadorflujo',
'		, apex_page.get_url (',
'			p_application	=> 130,',
'			p_page			=> 112,',
'			p_items			=> ''P112_IDNEG,P112_ESTADO,P112_APROBADOR,P112_ORIGEN'',',
'			p_values		=> cast(IDNEG as varchar(20))||'',''||cast(estadopagos as varchar(150))||'',''||cast(aprobador as varchar(150))||'',''||cast(''MESA'' as varchar(150))',
'			) url',
'		, pr.idneg numero',
'		, pr.idneg id',
'		, cast(pr.tipo as varchar(150)) tipo',
'		, pr.usrrequisitor solicitante',
'		, pr.unidadnegocio unidadnegocio',
'		, pr.proveedor',
'		, pr.aprobador',
'		, cast(pr.usrcomprador as varchar(150)) comprador',
'		, usrcomprador compradorerp',
'		, null valor',
'		, null valorliquidado',
'		, pr.costotal valorpagar',
'		, pr.estadopagos estado',
'		, pr.flujodesde fechaflujo',
'		, pr.fechaneg fechaorden',
'		, null fechaentrega',
'		, cast(pr.compania as varchar(10)) compania',
'		, null detalleid',
'		, null token',
'		, pr.estadopagos estadoaprobacion',
'		, cast(pr.observacion as varchar(500)) descripcion',
'		, pr.ruta',
'		, cast(pr.objeto as varchar(150)) objeto',
'		, pr.idneg objeto_id',
'		, ''True'' todo',
'		, pk_corp_flujoaprobacion.f_mesaorden(css) orden',
'		, css',
'		, 0 nivelalerta',
'	from pr',
'), res as (',
'	select * from lstor',
'		union all',
'	select * from lstli',
'		union all',
'	select * from lstpr',
') select url_adjunto',
'	, adjunto',
'	, url_adjunto_c',
'	, adjunto_c',
'	, tipodata as tipodata',
'	, apex_item.checkbox(3,tipodata||''|''||numero||''|''||decode(aprobador,null,'' '',aprobador)||''|''||tipo,''CHECKED class="chkF03"'') seleccion',
'	, aprobadorflujo',
'	, cast(gestion as number) gestion',
'	, case',
'		when cast(gestion as number) = 0 then 11',
'		else case',
'			when aprobador is null then 10',
'			else case',
'				when aprobadorflujo = 1 then case estado',
'					when ''PENDIENTE'' then 0',
'					when ''PENDIENTE LIQUIDAR'' then 1',
'					when ''EN PROCESO'' then 2',
'					when ''EN_PROCESO'' then 2',
'					when ''RUTA DE APROBACION'' then 3',
'					else 4 end',
'				else 5 end end end ordenseleccion',
'	, case estado',
'		when ''PENDIENTE'' then 0',
'		when ''PENDIENTE LIQUIDAR'' then 1',
'		when ''EN_PROCESO'' then 2',
'		when ''EN PROCESO'' then 2',
'		when ''RUTA DE APROBACION'' then 3',
'		else 4 end ordenseleccion1',
'	, numero',
'	-- , ''<span class="''||css||''" title="''||estado||''">'' ||case tipodata when ''COM'' then ''Orden: '' when ''LIQ'' then ''Liquidacion: '' when ''PGR'' then ''Pago Recurrente: '' end||numero ||''</span>'' textoenlace',
'	, ''<span class="''||css||''" title="''||estado||''">'' ||numero||''</span>'' textoenlace',
'	, case when tipodata in (''COM'',''PGR'') then '' '' else ''target="_blank"'' end atributoenlace',
'	, tipo',
'	, solicitante',
'	, aprobador',
'	, compradorerp comprador',
'	, unidadnegocio',
'	, proveedor',
'	, url',
'	, token',
'	, valor',
'	, valorliquidado',
'	, valorpagar',
'	, fechaorden',
'	, fechaentrega',
'	, replace(estado,''_'', '' '')  estado',
'	, nvl(descripcion,'' '') descripcion',
'	, ruta',
'	, objeto',
'	, objeto_id',
'	, todo',
'	, css',
'	, orden',
'	, nivelalerta',
'from res'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P100_ESTADO,P100_FECHA_INICIO,P100_FECHA_FIN,P100_TIPO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(60860337923781203)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>60860337923781203
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60862116026781221)
,p_db_column_name=>'SELECCION'
,p_display_order=>30
,p_column_identifier=>'K'
,p_column_label=>'<input type="checkbox" id="selectallocs">'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_rpt_show_filter_lov=>'N'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P100_APROBADOR > 0'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60862989695781229)
,p_db_column_name=>'NUMERO'
,p_display_order=>40
,p_column_identifier=>'P'
,p_column_label=>unistr('N\00FAmero')
,p_column_link=>'#URL#'
,p_column_linktext=>'#TEXTOENLACE#'
,p_column_link_attr=>'#ATRIBUTOENLACE#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60861149626781211)
,p_db_column_name=>'TIPO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60861253431781212)
,p_db_column_name=>'SOLICITANTE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Solicitante'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60861320957781213)
,p_db_column_name=>'UNIDADNEGOCIO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Unidad de Negocio'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60861484768781214)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60860595604781205)
,p_db_column_name=>'APROBADOR'
,p_display_order=>90
,p_column_identifier=>'B'
,p_column_label=>'Aprobador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60863343160781233)
,p_db_column_name=>'FECHAORDEN'
,p_display_order=>100
,p_column_identifier=>'T'
,p_column_label=>'Fec. Documento'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60863475638781234)
,p_db_column_name=>'FECHAENTREGA'
,p_display_order=>110
,p_column_identifier=>'U'
,p_column_label=>'Fec. Entrega'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60863284519781232)
,p_db_column_name=>'VALOR'
,p_display_order=>120
,p_column_identifier=>'S'
,p_column_label=>'Valor'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60861640806781216)
,p_db_column_name=>'VALORLIQUIDADO'
,p_display_order=>130
,p_column_identifier=>'I'
,p_column_label=>'Valor liquidado'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60861721560781217)
,p_db_column_name=>'VALORPAGAR'
,p_display_order=>140
,p_column_identifier=>'J'
,p_column_label=>'Valor a Pagar'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60860441879781204)
,p_db_column_name=>'ESTADO'
,p_display_order=>150
,p_column_identifier=>'A'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60863564654781235)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>160
,p_column_identifier=>'V'
,p_column_label=>unistr('Descripci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60860889033781208)
,p_db_column_name=>'RUTA'
,p_display_order=>170
,p_column_identifier=>'D'
,p_column_label=>'Ruta'
,p_column_link=>'f?p=100:104:&SESSION.::&DEBUG.:RP:G_OBJETO,G_OBJETO_ID,G_TODO:#OBJETO#,#OBJETO_ID#,#TODO#'
,p_column_linktext=>'#RUTA#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60860727345781207)
,p_db_column_name=>'CSS'
,p_display_order=>180
,p_column_identifier=>'C'
,p_column_label=>'Css'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60862224242781222)
,p_db_column_name=>'URL'
,p_display_order=>190
,p_column_identifier=>'L'
,p_column_label=>'Url'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60862454592781224)
,p_db_column_name=>'TOKEN'
,p_display_order=>200
,p_column_identifier=>'M'
,p_column_label=>'Token'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60863195616781231)
,p_db_column_name=>'ATRIBUTOENLACE'
,p_display_order=>210
,p_column_identifier=>'R'
,p_column_label=>'Atributoenlace'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60862756921781227)
,p_db_column_name=>'TIPODATA'
,p_display_order=>220
,p_column_identifier=>'N'
,p_column_label=>'Tipodata'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60863057643781230)
,p_db_column_name=>'TEXTOENLACE'
,p_display_order=>240
,p_column_identifier=>'Q'
,p_column_label=>'Textoenlace'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60863655146781236)
,p_db_column_name=>'OBJETO'
,p_display_order=>250
,p_column_identifier=>'W'
,p_column_label=>'Objeto'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60863775967781237)
,p_db_column_name=>'OBJETO_ID'
,p_display_order=>260
,p_column_identifier=>'X'
,p_column_label=>'Objeto Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60863883256781238)
,p_db_column_name=>'TODO'
,p_display_order=>270
,p_column_identifier=>'Y'
,p_column_label=>'Todo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60864125961781241)
,p_db_column_name=>'APROBADORFLUJO'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Aprobadorflujo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60985032319265025)
,p_db_column_name=>'GESTION'
,p_display_order=>290
,p_column_identifier=>'AI'
,p_column_label=>'Gestion'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60985193085265026)
,p_db_column_name=>'ORDENSELECCION'
,p_display_order=>300
,p_column_identifier=>'AJ'
,p_column_label=>'Ordenseleccion'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(60985245709265027)
,p_db_column_name=>'ORDENSELECCION1'
,p_display_order=>310
,p_column_identifier=>'AK'
,p_column_label=>'Ordenseleccion1'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(97446747633002145)
,p_db_column_name=>'COMPRADOR'
,p_display_order=>320
,p_column_identifier=>'AL'
,p_column_label=>'Comprador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145800733225202940)
,p_db_column_name=>'URL_ADJUNTO'
,p_display_order=>330
,p_column_identifier=>'AM'
,p_column_label=>'Url Adjunto'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145800839945202941)
,p_db_column_name=>'ADJUNTO'
,p_display_order=>340
,p_column_identifier=>'AN'
,p_column_label=>'Adjunto S.'
,p_column_link=>'#URL_ADJUNTO#'
,p_column_linktext=>'#ADJUNTO#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145800930398202942)
,p_db_column_name=>'URL_ADJUNTO_C'
,p_display_order=>350
,p_column_identifier=>'AO'
,p_column_label=>'Url Adjunto C'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(145801060036202943)
,p_db_column_name=>'ADJUNTO_C'
,p_display_order=>360
,p_column_identifier=>'AP'
,p_column_label=>'Adjunto C.'
,p_column_link=>'#URL_ADJUNTO_C#'
,p_column_linktext=>'#ADJUNTO_C#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183798974670709136)
,p_db_column_name=>'ORDEN'
,p_display_order=>370
,p_column_identifier=>'AQ'
,p_column_label=>'Orden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(621500270320994401)
,p_db_column_name=>'NIVELALERTA'
,p_display_order=>380
,p_column_identifier=>'AR'
,p_column_label=>'NivelAlerta'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(60875880099840674)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'608759'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SELECCION:NUMERO:TIPO:SOLICITANTE:ADJUNTO:COMPRADOR:ADJUNTO_C:UNIDADNEGOCIO:PROVEEDOR:APROBADOR:FECHAORDEN:FECHAENTREGA:VALOR:VALORLIQUIDADO:VALORPAGAR:ESTADO:DESCRIPCION:RUTA:URL_ADJUNTO_C:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(77210267594934843)
,p_plug_name=>'&P100_NC_MRK.'
,p_region_name=>'rptNotasCredito'
,p_parent_plug_id=>wwv_flow_imp.id(340844196558805010)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  mesafinal.*',
'	, apex_item.checkbox(1,lote||''|''||decode(aprobador,null,'' '',aprobador),''checked class = "chkf01"'') seleccion',
'	, pk_corp_flujoaprobacion.f_mesaiconoruta(aprobador) ruta',
'	, pk_corp_flujoaprobacion.f_mesaorden(css) orden',
'from (',
'	select mesa.* ',
'		, pk_corp_flujoaprobacion.f_gestioncolor(:app_user,aprobador,null,:g_compania,''BACK'') css',
'	from vt_back_mesatrabajo mesa ',
'	where 1 = 1 and /*:p100_tipo = ''#rptNotasCredito'' and*/ compania = :g_compania',
'		and (',
'			(:p100_estado = 2 and trunc(fechadesde) between to_date(:p100_fecha_inicio,''dd/mm/yyyy'') and to_date(:p100_fecha_fin,''dd/mm/yyyy''))',
'				or',
'			(:p100_estado = 1 and aprobador is not null and estado = ''EN_PROCESO'' and pk_corp_flujoaprobacion.f_aprobadorflujo(:app_user,aprobador,''BACK'',:g_compania) = 1)',
'			)',
'	) mesafinal;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P100_ESTADO,P100_FECHA_INICIO,P100_FECHA_FIN,P100_TIPO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(77210375375934844)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>77210375375934844
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79919759515602814)
,p_db_column_name=>'SELECCION'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'<input type="checkbox" id="selectallncs">'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P100_APROBADOR > 0'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(77210568973934846)
,p_db_column_name=>'COMPANIA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79918833917602805)
,p_db_column_name=>'LOTE'
,p_display_order=>30
,p_column_identifier=>'I'
,p_column_label=>'Proceso'
,p_column_link=>'f?p=&APP_ID.:106:&SESSION.::&DEBUG.:RP,106:P106_LOTE:#LOTE#'
,p_column_linktext=>'#LOTE#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(77210853531934849)
,p_db_column_name=>'SOLICITANTE'
,p_display_order=>40
,p_column_identifier=>'E'
,p_column_label=>'Solicitante'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(77210661428934847)
,p_db_column_name=>'APROBADOR'
,p_display_order=>50
,p_column_identifier=>'C'
,p_column_label=>'Aprobador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(77210709660934848)
,p_db_column_name=>'FECHADESDE'
,p_display_order=>60
,p_column_identifier=>'D'
,p_column_label=>'Fecha Solicitud'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy hh24:mi'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(77210903577934850)
,p_db_column_name=>'CSS'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'Css'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79918444677602801)
,p_db_column_name=>'RUTA'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Ruta'
,p_column_link=>'f?p=100:104:&SESSION.::&DEBUG.:RP:G_OBJETO,G_OBJETO_ID,G_TODO:GENERACION_NOTA_CREDITO,#LOTE#,true'
,p_column_linktext=>'#RUTA#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79918529524602802)
,p_db_column_name=>'ORDEN'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'Orden'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(193206307958644501)
,p_db_column_name=>'ESTADO'
,p_display_order=>100
,p_column_identifier=>'K'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P100_ESTADO'
,p_display_condition2=>'2'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(193206523038644503)
,p_db_column_name=>'MOTIVO'
,p_display_order=>120
,p_column_identifier=>'M'
,p_column_label=>'Motivo'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(193206632621644504)
,p_db_column_name=>'MONTO'
,p_display_order=>130
,p_column_identifier=>'N'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(193206779438644505)
,p_db_column_name=>'CLIENTE'
,p_display_order=>140
,p_column_identifier=>'O'
,p_column_label=>'Cliente'
,p_column_html_expression=>'<div style="max-width:300px;">#CLIENTE#</div>'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_static_id=>'rptColCliente'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(79930047542676293)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'799301'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SELECCION:LOTE:SOLICITANTE:FECHADESDE:CLIENTE:MOTIVO:MONTO:RUTA:'
,p_sort_column_1=>'LOTE'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(92124801705074038)
,p_plug_name=>'&P100_NG_MRK.'
,p_region_name=>'rptNegociacion'
,p_parent_plug_id=>wwv_flow_imp.id(340844196558805010)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'	case',
'		when estadoflujo in (''EN RUTA'')   then 0',
'		when estadoflujo in (''VIGENTE'')   then 1',
'		when estadoflujo in (''APROBADO'')  then 2',
'		when estadoflujo in (''CADUCADO'')  then 4',
'		when estadoflujo in (''CANCELADO'') then 5',
'		else 9 end orden',
'	, estadoflujo',
'	, case',
'		when estadoflujo in (''EN RUTA'')',
'			then apex_item.checkbox(4,idnegociacion||''|''||codtiponegociacion,decode(codestado,null,''DISABLED'',''CHECKED'')||'' class="chkF04"'')',
'		else '''' end seleccion',
'	, idnegociacion negociacion',
'	, recurrente',
'	, volumen',
'	, escala',
'	, precio',
'	, moneda',
'	, incoterm',
'	, tiempoentrega',
'	, formapago',
'	, fechaflujo fecha',
'	, solicitante',
'	, aprobador',
'	, esquema tipo_esquema',
'	, case esquema',
'		when ''PD'' then (select codigoproducto	||'' - ''|| nombreproducto || '' ''|| codigoalterno || '' - ['' || unidadcompra || '']'' d from vt_jde_productos where codigocorto = codesquema and codestado != ''O'')',
'		when ''PV'' then (select codigoproveedor	||'' - ''|| descripcion d from vt_jde_maestroproveedor where codigoproveedor = codesquema)',
'		end esquema',
'	, vigenciadesde vigencia_desde',
'	, vigenciahasta vigencia_hasta',
'	, neg_pas "NEG. PASADAS"',
'	, neg_sim "NEG. SIMILARES"',
'	, ruta',
'	, pk_corp_flujoaprobacion.f_gestioncolor(:app_user,aprobador,estadoflujo,:g_compania,:g_modulo) css',
'	, apex_page.get_url(p_application=>130,p_page => case when estadoflujo in (''CREACION'',''RECHAZADO'') then 139 else 138 end,p_items => ''G_IDNEGOCIACION,G_EDITNEGOCIACION,G_PAGNEGOCIACION'',p_values=>idnegociacion||'',''||decode(estadoflujo,''CREACION'',1,0)'
||'||'',''||:app_page_id) url',
'	, apex_page.get_url(p_application=>130,p_page=>143,p_items=>''P143_NEG_ID_ACTUAL,P143_TIPO,G_PAGNEGOCIACION'',p_values=>idnegociacion||'',1,''|| :app_page_id) urlpas',
'	, apex_page.get_url(p_application=>130,p_page=>143,p_items=>''P143_NEG_ID_ACTUAL,P143_TIPO,G_PAGNEGOCIACION'',p_values=>idnegociacion||'',2,''|| :app_page_id) urlsim',
'	, objeto',
'	, objetoid',
'	, todo',
'	, observacion',
'	, tiponegociacion',
'	, case when recurrente = ''SI'' then pk_commons.f_coloralerta(2) else '''' end coloralerta',
'from data.vt_comp_mesatrabajoneg',
'where 1 = 1',
'	and (',
'			(:p100_estado = 1 and aprobador is not null and  pk_corp_flujoaprobacion.f_aprobadorflujo(:app_user, aprobador, :g_modulo, :g_compania) = 1)',
'			or',
'			(:p100_estado = 2 and (trunc(fechaflujo) between (:p100_fecha_inicio) and (:p100_fecha_fin)))',
'		)',
'	and estadoflujo in (''EN RUTA'',''VIGENTE'',''APROBADO'',''CADUCADO'',''CANCELADO'')'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P100_ESTADO,P100_FECHA_INICIO,P100_FECHA_FIN,P100_TIPO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'&P100_NG_MRK.'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(132104465057164525)
,p_max_row_count=>'1000000'
,p_search_button_label=>'Buscar'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_finder_drop_down=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_notify=>'Y'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>132104465057164525
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132104527196164526)
,p_db_column_name=>'ESTADOFLUJO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Estado'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132104627384164527)
,p_db_column_name=>'SELECCION'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'<input type="checkbox" id="selectallneg">'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':p100_gestionloteneg=1'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132104760548164528)
,p_db_column_name=>'NEGOCIACION'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'ID'
,p_column_link=>'f?p=&APP_ID.:138:&SESSION.::&DEBUG.:RP,138:G_IDNEGOCIACION,G_EDITNEGOCIACION,G_PAGNEGOCIACION,P138_ESTADO_FLUJO,P138_OBJETO:#NEGOCIACION#,0,&APP_PAGE_ID.,#ESTADOFLUJO#,#OBJETO#'
,p_column_linktext=>'#NEGOCIACION#'
,p_column_link_attr=>'C'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'00000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132104892031164529)
,p_db_column_name=>'FECHA'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132104902662164530)
,p_db_column_name=>'SOLICITANTE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Solicitante'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132105062183164531)
,p_db_column_name=>'APROBADOR'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Aprobador'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132105232628164533)
,p_db_column_name=>'TIPO_ESQUEMA'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Tipo Esquema'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(134249283510088347)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132105314892164534)
,p_db_column_name=>'ESQUEMA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132105537914164536)
,p_db_column_name=>'VIGENCIA_DESDE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Vig. Desde'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132105669700164537)
,p_db_column_name=>'VIGENCIA_HASTA'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Vig. Hasta'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132105905099164540)
,p_db_column_name=>'RUTA'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'<span title="Ver Ruta"class="fa fa-road"/>'
,p_column_link=>'f?p=100:104:&SESSION.::&DEBUG.::G_OBJETO,G_OBJETO_ID,G_TODO:#OBJETO#,#OBJETOID#,TRUE#OBJETO_ID#,#TODO#'
,p_column_linktext=>'#RUTA#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132106014119164541)
,p_db_column_name=>'CSS'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Css'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132106178669164542)
,p_db_column_name=>'URL'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Url'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132106233114164543)
,p_db_column_name=>'URLPAS'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Urlpas'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132106367643164544)
,p_db_column_name=>'URLSIM'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Urlsim'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132106598236164546)
,p_db_column_name=>'OBJETO'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Objeto'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(132106777673164548)
,p_db_column_name=>'TODO'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Todo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(138961195917199228)
,p_db_column_name=>'ORDEN'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(138961215695199229)
,p_db_column_name=>'NEG. PASADAS'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'<span class="fa fa-file-archive-o" title="Negociaciones Pasadas" aria-hidden="true"></span>'
,p_column_link=>'#URLPAS#'
,p_column_linktext=>'#NEG. PASADAS#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(138961352583199230)
,p_db_column_name=>'NEG. SIMILARES'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'<span class="fa fa-table-file"     title="Negociaciones Similares" aria-hidden="true"></span>'
,p_column_link=>'#URLSIM#'
,p_column_linktext=>'#NEG. SIMILARES#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(202196484253491001)
,p_db_column_name=>'VOLUMEN'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Volumen'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(202196595768491002)
,p_db_column_name=>'OBJETOID'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Objetoid'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(202196619473491003)
,p_db_column_name=>'ESCALA'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Escala'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(202196788293491004)
,p_db_column_name=>'PRECIO'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Precio'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(202196850555491005)
,p_db_column_name=>'MONEDA'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Moneda'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(202196974699491006)
,p_db_column_name=>'INCOTERM'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Incoterm'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(202197064994491007)
,p_db_column_name=>'TIEMPOENTREGA'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'T. Entrega'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(202197171770491008)
,p_db_column_name=>'FORMAPAGO'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'F. Pago'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183799558065709142)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>unistr('Observaci\00F3n')
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183799649597709143)
,p_db_column_name=>'TIPONEGOCIACION'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>unistr('Tipo Negociaci\00F3n')
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(206431062914010948)
,p_db_column_name=>'RECURRENTE'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Gen. Pago Rec.'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(615427889735473516)
,p_db_column_name=>'COLORALERTA'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Color Alerta'
,p_column_type=>'STRING'
,p_static_id=>'colNegColorAlerta'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(132249946023303911)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1322500'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ORDEN:ESTADOFLUJO:SELECCION:NEGOCIACION:TIPONEGOCIACION:RECURRENTE:ESQUEMA:INCOTERM:SOLICITANTE:OBSERVACION:RUTA:NEG. PASADAS:NEG. SIMILARES:'
,p_sort_column_1=>'NEGOCIACION'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'ORDEN:ESTADOFLUJO:0:0:0:0'
,p_break_enabled_on=>'ORDEN:ESTADOFLUJO:0:0:0:0'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(621463674405898720)
,p_report_id=>wwv_flow_imp.id(132249946023303911)
,p_name=>'Gen. Pago'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'RECURRENTE'
,p_operator=>'='
,p_expr=>'SI'
,p_condition_sql=>' (case when ("RECURRENTE" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''SI''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#ffe8cc'
,p_row_font_color=>'#000000'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(560099565760828721)
,p_plug_name=>'&P100_CE_MRK.'
,p_region_name=>'rptCEGrupoZML'
,p_parent_plug_id=>wwv_flow_imp.id(340844196558805010)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  mesafinal.*',
'	, case',
'		when mesafinal.estado = ''EN RUTA''',
'			then apex_item.checkbox(6,idcab||''|''||decode(usuarioactual,null,'' '',usuarioactual)||''|''||nvl(ordencompraerp,idcab),''checked class = "chkF06"'')',
'		else null end seleccion',
'	, data.pk_corp_flujoaprobacion.f_mesaorden(css) orden',
'from (',
'	select mesa.* ',
'		, data.pk_corp_flujoaprobacion.f_gestioncolor(:app_user,usuarioactual,null,:g_compania,''COMP'') css',
'	from data.vt_comp_ordencompraext mesa',
'	where 2 = 2',
'		and mesatrabajo = 1',
'		and (',
'			(:p100_estado = 1 and usuarioactual is not null and estado = ''EN RUTA'' and data.pk_corp_flujoaprobacion.f_aprobadorflujo(:app_user,usuarioactual,''COMP'',:g_compania) = 1)',
'				or',
'			(:p100_estado = 2 and trunc(fechcrea) between to_date(:p100_fecha_inicio,''dd/mm/yyyy'') and to_date(:p100_fecha_fin,''dd/mm/yyyy''))',
'		)',
'	) mesafinal'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P100_ESTADO,P100_FECHA_INICIO,P100_FECHA_FIN'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20260121134813Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(560099628012828722)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'No hay registros pendientes.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>560099628012828722
,p_updated_on=>wwv_flow_imp.dz('20260121134813Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560162866968877003)
,p_db_column_name=>'IDCAB'
,p_display_order=>10
,p_column_identifier=>'AC'
,p_column_label=>unistr('N\00FAmero')
,p_column_link=>'f?p=&APP_ID.:620:&SESSION.::&DEBUG.:620:P620_ID,P620_COMPANIADES,P620_USUARIOFLUJO,P620_PAGRETORNO,P620_ENTIDADCLASE,P620_RECURRENTE:#IDCAB#,#COMPANIADES#,#USUARIOACTUAL#,100,#ENTIDADCLASE#,#RECURRENTE#'
,p_column_linktext=>'#IDCAB#'
,p_column_link_attr=>'class="#CSS#"'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560162938971877004)
,p_db_column_name=>'TIPODOC'
,p_display_order=>20
,p_column_identifier=>'AD'
,p_column_label=>'Tipodoc'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560163093014877005)
,p_db_column_name=>'ESTADO'
,p_display_order=>30
,p_column_identifier=>'AE'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560163194197877006)
,p_db_column_name=>'USERCREA'
,p_display_order=>40
,p_column_identifier=>'AF'
,p_column_label=>'Usercrea'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560163262707877007)
,p_db_column_name=>'FECHCREA'
,p_display_order=>50
,p_column_identifier=>'AG'
,p_column_label=>'Fechcrea'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560163333490877008)
,p_db_column_name=>'USERRQST'
,p_display_order=>60
,p_column_identifier=>'AH'
,p_column_label=>'Solicitante'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560163402507877009)
,p_db_column_name=>'USERCOMP'
,p_display_order=>70
,p_column_identifier=>'AI'
,p_column_label=>'Comprador'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560163514954877010)
,p_db_column_name=>'COMPANIAORI'
,p_display_order=>80
,p_column_identifier=>'AJ'
,p_column_label=>'Companiaori'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560163610127877011)
,p_db_column_name=>'COMPANIADES'
,p_display_order=>90
,p_column_identifier=>'AK'
,p_column_label=>unistr('C\00EDa. Destino')
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(559033228932758134)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260105015544Z')
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560163788806877012)
,p_db_column_name=>'CATCOMPRA'
,p_display_order=>100
,p_column_identifier=>'AL'
,p_column_label=>'Cat. Compra'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(557527731706369421)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260105015624Z')
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560163822596877013)
,p_db_column_name=>'CODPROVEEDOR'
,p_display_order=>110
,p_column_identifier=>'AM'
,p_column_label=>unistr('C\00F3d. Proveedor')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560163991453877014)
,p_db_column_name=>'DESCPROVEEDOR'
,p_display_order=>120
,p_column_identifier=>'AN'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560164022673877015)
,p_db_column_name=>'MONEDA'
,p_display_order=>130
,p_column_identifier=>'AO'
,p_column_label=>'Moneda'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560164153094877016)
,p_db_column_name=>'FECHAPLAN'
,p_display_order=>140
,p_column_identifier=>'AP'
,p_column_label=>'Fecha ETA'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560164222888877017)
,p_db_column_name=>'CANTITEMS'
,p_display_order=>150
,p_column_identifier=>'AQ'
,p_column_label=>unistr('\00CDtems')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560164360023877018)
,p_db_column_name=>'TOTALOC'
,p_display_order=>160
,p_column_identifier=>'AR'
,p_column_label=>'Total OC.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560164438019877019)
,p_db_column_name=>'IDFLUJO'
,p_display_order=>170
,p_column_identifier=>'AS'
,p_column_label=>'Idflujo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560164556427877020)
,p_db_column_name=>'CODRUTA'
,p_display_order=>180
,p_column_identifier=>'AT'
,p_column_label=>'Codruta'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560164640612877021)
,p_db_column_name=>'DESCRUTA'
,p_display_order=>190
,p_column_identifier=>'AU'
,p_column_label=>'Descruta'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560164710409877022)
,p_db_column_name=>'IDDETFLUJO'
,p_display_order=>200
,p_column_identifier=>'AV'
,p_column_label=>'Iddetflujo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560164800039877023)
,p_db_column_name=>'TOKENFLUJO'
,p_display_order=>210
,p_column_identifier=>'AW'
,p_column_label=>'Tokenflujo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560164941061877024)
,p_db_column_name=>'USUARIOINICIADOR'
,p_display_order=>220
,p_column_identifier=>'AX'
,p_column_label=>'Usuarioiniciador'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560165039365877025)
,p_db_column_name=>'USUARIOACTUAL'
,p_display_order=>230
,p_column_identifier=>'AY'
,p_column_label=>'Aprobador'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560165175856877026)
,p_db_column_name=>'FLUJODESDE'
,p_display_order=>240
,p_column_identifier=>'AZ'
,p_column_label=>'Flujodesde'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560165260001877027)
,p_db_column_name=>'MESATRABAJO'
,p_display_order=>250
,p_column_identifier=>'BA'
,p_column_label=>'Mesatrabajo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560165341830877028)
,p_db_column_name=>'RUTA'
,p_display_order=>260
,p_column_identifier=>'BB'
,p_column_label=>'Ruta'
,p_column_link=>'f?p=100:104:&SESSION.::&DEBUG.::G_OBJETO,G_OBJETO_ID,G_TODO:#ENTIDADCLASE#,#IDCAB#,TRUE'
,p_column_linktext=>'#RUTA#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560165406127877029)
,p_db_column_name=>'CSS'
,p_display_order=>270
,p_column_identifier=>'BC'
,p_column_label=>'Css'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560165503856877030)
,p_db_column_name=>'SELECCION'
,p_display_order=>280
,p_column_identifier=>'BD'
,p_column_label=>'<input type="checkbox" id="selectallcgz">'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>':P100_APROBADOR > 0'
,p_display_condition2=>'PLSQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(560165660565877031)
,p_db_column_name=>'ORDEN'
,p_display_order=>290
,p_column_identifier=>'BE'
,p_column_label=>'Orden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(585056534167907201)
,p_db_column_name=>'CODCATCOMPRA'
,p_display_order=>300
,p_column_identifier=>'BF'
,p_column_label=>'Codcatcompra'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(585056609687907202)
,p_db_column_name=>'ESTADOPAGO'
,p_display_order=>310
,p_column_identifier=>'BG'
,p_column_label=>'Estadopago'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(585056727270907203)
,p_db_column_name=>'OBSERVACION'
,p_display_order=>320
,p_column_identifier=>'BH'
,p_column_label=>unistr('Observaci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(585056826886907204)
,p_db_column_name=>'COMENTARIO'
,p_display_order=>330
,p_column_identifier=>'BI'
,p_column_label=>'Comentario'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(599462246599255633)
,p_db_column_name=>'ORDENCOMPRAERP'
,p_display_order=>340
,p_column_identifier=>'BJ'
,p_column_label=>'OC ERP'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(57425159233960601)
,p_db_column_name=>'RQCOMPRAERP'
,p_display_order=>350
,p_column_identifier=>'BO'
,p_column_label=>'Rqcompraerp'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(57425689024960606)
,p_db_column_name=>'ENTIDADCLASE'
,p_display_order=>360
,p_column_identifier=>'BQ'
,p_column_label=>'Entidadclase'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(137036719441932501)
,p_db_column_name=>'RECURRENTE'
,p_display_order=>370
,p_column_identifier=>'BR'
,p_column_label=>'Rec.'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(138466680301723728)
,p_db_column_name=>'CODSCTGCOMPRA'
,p_display_order=>380
,p_column_identifier=>'BS'
,p_column_label=>'Codsctgcompra'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(138466704175723729)
,p_db_column_name=>'SCTGCOMPRA'
,p_display_order=>390
,p_column_identifier=>'BT'
,p_column_label=>'Sctgcompra'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(560161004121874354)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5601611'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'COMPANIADES:SELECCION:IDCAB:CATCOMPRA:USERRQST:USERCOMP:DESCPROVEEDOR:OBSERVACION:TOTALOC:MONEDA:FECHAPLAN:ORDENCOMPRAERP:ESTADO:USUARIOACTUAL:RUTA'
,p_break_on=>'COMPANIADES:0:0:0:0:0'
,p_break_enabled_on=>'COMPANIADES:0:0:0:0:0'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(138075259458657881)
,p_report_id=>wwv_flow_imp.id(560161004121874354)
,p_name=>'Recurrentes'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'RECURRENTE'
,p_operator=>'='
,p_expr=>'SI'
,p_condition_sql=>' (case when ("RECURRENTE" = #APXWS_EXPR#) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = ''SI''  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#a7d7e2'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6107667907249080)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(5828353747060259)
,p_button_name=>'Aprobar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Aprobar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P100_APROBADOR=1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-thumbs-up'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(6108721222249090)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(5828353747060259)
,p_button_name=>'Rechazar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Rechazar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P100_APROBADOR=1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-thumbs-down'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(94384916308893614)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(5828353747060259)
,p_button_name=>'btnAprobar'
,p_button_static_id=>'btnAprobar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'btnAprobar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-thumbs-up'
,p_button_cattributes=>'style="display:none"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(94385080759893615)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(5828353747060259)
,p_button_name=>'btnRechazar'
,p_button_static_id=>'btnRechazar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Rechazar_comp'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-thumbs-down'
,p_button_cattributes=>'style="display:none"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(5830957300060285)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(5828353747060259)
,p_button_name=>'Buscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(132266755545622503)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(5828353747060259)
,p_button_name=>'Agregar'
,p_button_static_id=>'btnAgregarNeg'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Agregar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:139:&SESSION.::&DEBUG.:RP,139:G_EDITNEGOCIACION,G_IDNEGOCIACION,G_PAGNEGOCIACION:0,0,100'
,p_button_condition=>'P100_ES_CREADORNEG'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(152012277396268234)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(5828353747060259)
,p_button_name=>'MESATRABAJO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Mesa de Trabajo*'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.:113::'
,p_button_condition=>'P100_REDIRECCIONA'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-home'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5828543291060261)
,p_name=>'P100_ESTADO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(5828472683060260)
,p_item_default=>'1'
,p_prompt=>'Estado'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_UDC_ESTADOMESA'
,p_lov=>'SELECT DESCRIPCION, ID_TABLA FROM T_CORP_UDC WHERE id_cabecera=''ESTADOMESA'' ORDER BY id_tabla;'
,p_cHeight=>1
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5828718383060262)
,p_name=>'P100_FECHA_INICIO'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(5828472683060260)
,p_item_default=>'sysdate - 6'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Inicio'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'STATIC'
,p_attribute_07=>'+0d'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON'
,p_attribute_13=>'HIDDEN'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(5828780474060263)
,p_name=>'P100_FECHA_FIN'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(5828472683060260)
,p_item_default=>'trunc(sysdate)'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha fin'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'STATIC'
,p_attribute_07=>'+0d'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON'
,p_attribute_13=>'HIDDEN'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6107396453249077)
,p_name=>'P100_GESTIONLOTECOM'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(92124188920074031)
,p_prompt=>'Gestionlotecom'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6107787878249081)
,p_name=>'P100_APROBADOR'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(92124188920074031)
,p_prompt=>'Aprobador'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6108342017249087)
,p_name=>'P100_COMENTARIO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(92124188920074031)
,p_prompt=>'Comentario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6108469548249088)
,p_name=>'P100_APROBAR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(92124188920074031)
,p_prompt=>'Aprobar'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60860215671781202)
,p_name=>'P100_LIQ_APROBACION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(92124188920074031)
,p_prompt=>'Liq Aprobacion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60864600460781246)
,p_name=>'P100_VALORES'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(92124188920074031)
,p_prompt=>'Valores'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60984281547265017)
,p_name=>'P100_GESTIONLOTELIQ'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(92124188920074031)
,p_prompt=>'Gestioloteliq'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60984591688265020)
,p_name=>'P100_ESGESTIONLOTE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(92124188920074031)
,p_prompt=>'Esgestionlote'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(79922360082602840)
,p_name=>'P100_NOTASCREDITO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(92124188920074031)
,p_prompt=>'Notascredito'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93622326747381834)
,p_name=>'P100_GESTIONLOTENEG'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(92124188920074031)
,p_prompt=>'Gestionloteneg'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(94385317526893618)
,p_name=>'P100_USUARIO'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(92124188920074031)
,p_prompt=>'Usuario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(100422122254316602)
,p_name=>'P100_COSTOPROVEEDOR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(92124188920074031)
,p_prompt=>'Costoproveedor'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(100422687559316607)
,p_name=>'P100_DESCUENTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(92124188920074031)
,p_prompt=>'Descuento'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(132104286647164523)
,p_name=>'P100_BANDERA'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(92124188920074031)
,p_prompt=>'Bandera'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(132266840150622504)
,p_name=>'P100_ES_CREADORNEG'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(92124188920074031)
,p_prompt=>'Es Creadorneg'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(145804155811570236)
,p_name=>'P100_REDIRECCIONA'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(92124188920074031)
,p_prompt=>'Redirecciona'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(183798341699709130)
,p_name=>'P100_NG_MRK'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(92124188920074031)
,p_prompt=>'Ng Mrk'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(183798418604709131)
,p_name=>'P100_NC_MRK'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(92124188920074031)
,p_prompt=>'Ng Mrk'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(183798522432709132)
,p_name=>'P100_CP_MRK'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(92124188920074031)
,p_prompt=>'Ng Mrk'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(183798681798709133)
,p_name=>'P100_LC_MRK'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(92124188920074031)
,p_prompt=>'Ng Mrk'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(183799055932709137)
,p_name=>'P100_NAVEGADORTABS'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(92124188920074031)
,p_prompt=>'Navegadortabs'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(260170964539355617)
,p_name=>'P100_PR_MRK'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(92124188920074031)
,p_prompt=>'Pr Mrk'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(339346870506759705)
,p_name=>'P100_USUARIO_SELECCION'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(92124188920074031)
,p_prompt=>'Usuario Seleccion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(340845689364805025)
,p_name=>'P100_TIPO'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(92124188920074031)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(401963749228798720)
,p_name=>'P100_CE_MRK'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(92124188920074031)
,p_prompt=>'Ce Mrk'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(5828883811060264)
,p_name=>'Motrar filtros'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P100_ESTADO'
,p_condition_element=>'P100_ESTADO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5828932901060265)
,p_event_id=>wwv_flow_imp.id(5828883811060264)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P100_FECHA_INICIO,P100_FECHA_FIN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(132267298810622508)
,p_event_id=>wwv_flow_imp.id(5828883811060264)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(5829060464060266)
,p_name=>'Ocultar filtros'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P100_ESTADO'
,p_condition_element=>'P100_ESTADO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(5829155501060267)
,p_event_id=>wwv_flow_imp.id(5829060464060266)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P100_FECHA_INICIO,P100_FECHA_FIN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(132267353086622509)
,p_event_id=>wwv_flow_imp.id(5829060464060266)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(60983837371265013)
,p_name=>'Selecciona Todo OCs/Liq'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectallocs'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#rptLiquidacion'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(60983959436265014)
,p_event_id=>wwv_flow_imp.id(60983837371265013)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#rptLiquidacion #selectallocs'' ).is('':checked'')) {',
'    $(''#rptLiquidacion input[type=checkbox][name=f03]'').prop(''checked'',true);',
'} else {',
'    $(''#rptLiquidacion input[type=checkbox][name=f03]'').prop(''checked'',false);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(93622480162381835)
,p_name=>'Selecciona Todo Neg'
,p_event_sequence=>40
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectallneg'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#rptNegociacion'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(93622596663381836)
,p_event_id=>wwv_flow_imp.id(93622480162381835)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#rptNegociacion #selectallneg'' ).is('':checked'')) {',
'    $(''#rptNegociacion input[type=checkbox][name=f04]'').prop(''checked'',true);',
'} else {',
'    $(''#rptNegociacion input[type=checkbox][name=f04]'').prop(''checked'',false);',
'}',
' '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(300482724051773201)
,p_name=>'Selecciona Todo Pagos'
,p_event_sequence=>50
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectallpgr'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#rptPagosRecurrentes'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(300482823835773202)
,p_event_id=>wwv_flow_imp.id(300482724051773201)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#rptPagosRecurrentes #selectallpgr'' ).is('':checked'')) {',
'    $(''#rptPagosRecurrentes input[type=checkbox][name=f05]'').prop(''checked'',true);',
'} else {',
'    $(''#rptPagosRecurrentes input[type=checkbox][name=f05]'').prop(''checked'',false);',
'}',
' '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(100422348319316604)
,p_name=>'Selecciona Todo Costos'
,p_event_sequence=>60
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectallcosto'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#rptCosto'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(100422460196316605)
,p_event_id=>wwv_flow_imp.id(100422348319316604)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#rptCosto #selectallcosto'' ).is('':checked'')) {',
'    $(''#rptCosto input[type=checkbox][name=f01]'').prop(''checked'',true);',
'} else {',
'    $(''#rptCosto input[type=checkbox][name=f01]'').prop(''checked'',false);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(100422760697316608)
,p_name=>'Selecciona Todo Descuentos'
,p_event_sequence=>70
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectalldsc'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#rptDescuentoCantidad'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(100422874290316609)
,p_event_id=>wwv_flow_imp.id(100422760697316608)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#rptDescuentoCantidad #selectalldsc'' ).is('':checked'')) {',
'    $(''#rptDescuentoCantidad input[type=checkbox][name=f01]'').prop(''checked'',true);',
'} else {',
'    $(''#rptDescuentoCantidad input[type=checkbox][name=f01]'').prop(''checked'',false);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(79922109695602838)
,p_name=>'Selecciona Todo NCs'
,p_event_sequence=>80
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectallncs'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#rptNotasCredito'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79922238056602839)
,p_event_id=>wwv_flow_imp.id(79922109695602838)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#rptNotasCredito #selectallncs'' ).is('':checked'')) {',
'    $(''#rptNotasCredito input[type=checkbox][name=f01]'').prop(''checked'',true);',
'} else {',
'    $(''#rptNotasCredito input[type=checkbox][name=f01]'').prop(''checked'',false);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(405193067746791336)
,p_name=>'Selecciona Todo  CGZ'
,p_event_sequence=>90
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'#selectallcgz'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'#rptCEGrupoZML'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(405193118228791337)
,p_event_id=>wwv_flow_imp.id(405193067746791336)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($(''#rptCEGrupoZML #selectallcgz'' ).is('':checked'')) {',
'    $(''#rptCEGrupoZML input[type=checkbox][name=f06]'').prop(''checked'',true);',
'} else {',
'    $(''#rptCEGrupoZML input[type=checkbox][name=f06]'').prop(''checked'',false);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(60864285796781242)
,p_name=>'MESATRABAJO: Validacion aprobacion'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(6107667907249080)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(document.querySelectorAll(''.chkF03'').length == [].filter.call( document.querySelectorAll(''.chkF03''), function( el ) {return !el.checked}).length && $v("P100_TIPO")==''#rptLiquidacion'')',
'||',
'(document.querySelectorAll(''.chkF04'').length == [].filter.call( document.querySelectorAll(''.chkF04''), function( el ) {return !el.checked}).length && $v("P100_TIPO")==''#rptNegociacion'')',
'||',
'(document.querySelectorAll(''.chkF05'').length == [].filter.call( document.querySelectorAll(''.chkF05''), function( el ) {return !el.checked}).length && $v("P100_TIPO")==''#rptPagosRecurrentes'')',
'||',
'(document.querySelectorAll(''.chkF06'').length == [].filter.call( document.querySelectorAll(''.chkF06''), function( el ) {return !el.checked}).length && $v("P100_TIPO")==''#rptCEGrupoZML'')'))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(60864374931781243)
,p_event_id=>wwv_flow_imp.id(60864285796781242)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let v_tipo ='''';',
'if ($v(''P100_TIPO'') == ''#rptLiquidacion'' ){',
unistr('    v_tipo ='' un documento (orden / liquidaci\00F3n) para ser procesado'';'),
'}',
'if ($v(''P100_TIPO'') == ''#rptNegociacion'' ){',
unistr('    v_tipo ='' una negociaci\00F3n para ser procesada'';'),
'}',
'if ($v(''P100_TIPO'') == ''#rptPagosRecurrentes'' ){',
unistr('    v_tipo ='' una negociaci\00F3n de Pago Recurrente para ser procesada'';'),
'}',
'if ($v(''P100_TIPO'') == ''#rptCEGrupoZML'' ){',
'    v_tipo ='' una Orden de Compra para ser procesada'';',
'}',
'mensaje(''error'',''Debe seleccionar al menos''+v_tipo+'', valide y vuelva a intentar.''); ',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(60864425503781244)
,p_event_id=>wwv_flow_imp.id(60864285796781242)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(60982817211265003)
,p_event_id=>wwv_flow_imp.id(60864285796781242)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#btnAprobar'').trigger("click");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(60983351822265008)
,p_name=>'MESATRABAJO: Validacion rechazar'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(6108721222249090)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'(document.querySelectorAll(''.chkF03'').length == [].filter.call( document.querySelectorAll(''.chkF03''), function( el ) {return !el.checked}).length && $v("P100_TIPO")==''#rptLiquidacion'')',
'||',
'(document.querySelectorAll(''.chkF04'').length == [].filter.call( document.querySelectorAll(''.chkF04''), function( el ) {return !el.checked}).length && $v("P100_TIPO")==''#rptNegociacion'')',
'||',
'(document.querySelectorAll(''.chkF05'').length == [].filter.call( document.querySelectorAll(''.chkF05''), function( el ) {return !el.checked}).length && $v("P100_TIPO")==''#rptPagosRecurrentes'')',
'||',
'(document.querySelectorAll(''.chkF06'').length == [].filter.call( document.querySelectorAll(''.chkF06''), function( el ) {return !el.checked}).length && $v("P100_TIPO")==''#rptCEGrupoZML'')'))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(60983486003265009)
,p_event_id=>wwv_flow_imp.id(60983351822265008)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#btnRechazar'').trigger("click");'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(60983557181265010)
,p_event_id=>wwv_flow_imp.id(60983351822265008)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let v_tipo ='''';',
'if ($v(''P100_TIPO'') == ''#rptLiquidacion'' ){',
unistr('    v_tipo ='' un documento (orden / liquidaci\00F3n) para ser rechazado'';'),
'}',
'if ($v(''P100_TIPO'') == ''#rptNegociacion'' ){',
unistr('    v_tipo ='' una negociaci\00F3n para ser rechazado'';'),
'}',
'if ($v(''P100_TIPO'') == ''#rptPagosRecurrentes'' ){',
unistr('    v_tipo ='' una negociaci\00F3n de Pago Recurrente para ser rechazado'';'),
'}',
'if ($v(''P100_TIPO'') == ''#rptCEGrupoZML'' ){',
'    v_tipo ='' una Orde de Compra para ser rechazada'';',
'}',
'mensaje(''error'',''Debe seleccionar al menos''+v_tipo+'', valide y vuelva a intentar.''); ',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(60983670109265011)
,p_event_id=>wwv_flow_imp.id(60983351822265008)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(183798786457709134)
,p_name=>'Activar Tab'
,p_event_sequence=>120
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(340844196558805010)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'atabsactivate'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(183798888656709135)
,p_event_id=>wwv_flow_imp.id(183798786457709134)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var atab = apex.region("tblMesa").widget().aTabs("getActive").href;',
'var ttab = atab.replace("SR_","") ;',
'$s("P100_TIPO",ttab);',
'$s("P100_NAVEGADORTABS",atab);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(183799155177709138)
,p_event_id=>wwv_flow_imp.id(183798786457709134)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    :g_navegadortabs := :P100_NAVEGADORTABS;',
'end;'))
,p_attribute_02=>'P100_NAVEGADORTABS'
,p_attribute_03=>'G_NAVEGADORTABS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(183799202237709139)
,p_name=>'Navegador Tabs'
,p_event_sequence=>130
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(183799301894709140)
,p_event_id=>wwv_flow_imp.id(183799202237709139)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    :P100_NAVEGADORTABS := :g_navegadortabs;',
'end;'))
,p_attribute_02=>'G_NAVEGADORTABS'
,p_attribute_03=>'P100_NAVEGADORTABS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_server_condition_type=>'ITEM_IS_NOT_NULL'
,p_server_condition_expr1=>'G_NAVEGADORTABS'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(183799481833709141)
,p_event_id=>wwv_flow_imp.id(183799202237709139)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'switch ($v("P100_NAVEGADORTABS"))',
'{',
'	case "#SR_rptLiquidacion"		:apex.region("tblMesa").widget().aTabs("getTabs")["#SR_rptLiquidacion"].makeActive();break;',
'	case "#SR_rptCosto"				:apex.region("tblMesa").widget().aTabs("getTabs")["#SR_rptCosto"].makeActive();break;',
'	case "#SR_rptNotasCredito"		:apex.region("tblMesa").widget().aTabs("getTabs")["#SR_rptNotasCredito"].makeActive();break;',
'	case "#SR_rptNegociacion"		:apex.region("tblMesa").widget().aTabs("getTabs")["#SR_rptNegociacion"].makeActive();break;',
'	case "#SR_rptPagosRecurrentes"	:apex.region("tblMesa").widget().aTabs("getTabs")["#SR_rptPagosRecurrentes"].makeActive();break;',
'    case "#SR_rptCEGrupoZML"	:apex.region("tblMesa").widget().aTabs("getTabs")["#SR_rptrptCEGrupoZML"].makeActive();break;',
'}'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(60864856801781248)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Aprobaci\00F3n en Lote')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'v_aprobador 			varchar(2500);',
'v_compania				varchar2(5);',
'v_estado 				varchar(250);',
'v_estadoaprobacion 		varchar(20);',
'v_exito 				number;',
'v_id 					varchar2(2500);',
'v_flag_exito			varchar2(2500);',
'v_flag_error			varchar2(2500);',
'v_id_error_com 			varchar2(2500);',
'v_id_error_liq 			varchar2(2500);',
'v_id_error_pgr 			varchar2(2500);',
'v_id_error_cgz 			varchar2(2500); -- Compras Grupo ZML',
'v_id_exito_com 			varchar2(2500);',
'v_id_exito_liq 			varchar2(2500);',
'v_id_exito_pgr 			varchar2(2500);',
'v_id_exito_cgz 			varchar2(2500); -- Compras Grupo ZML',
'v_id_flujo 				varchar2(500):=null;',
'v_log_app				varchar2(99);',
'v_log_dsc				varchar2(3999);',
'v_log_msg				varchar2(3999);',
'v_log_obs				varchar2(3999);',
'v_cor_rem				varchar2(100);',
'v_cor_sub				varchar2(999);',
'v_mensaje				varchar2(3999);',
'v_modulo 				varchar(250);',
'v_monto 				number;',
'v_nego_error 			varchar2(2500);',
'v_nego_exito 			varchar2(2500);',
'v_numero 				varchar(20);',
'v_numero_aux 	    	varchar(20);',
'v_objeto 				varchar(250);',
'v_recurrente			varchar2(5);',
'v_termino 				number;',
'v_tipo 					varchar2(2500);',
'v_tipodata 				varchar(10);',
'v_usuario 				varchar(250);',
'v_usuariosolicita		varchar(250); -- Compras Grupo ZML',
'v_comprador				varchar(250); -- Compras Grupo ZML',
'v_usuario_flujo 		varchar(250):=null;',
'v_reporte				varchar(250);',
'v_respuesta				varchar(3999);',
'v_aux_num				number;',
'v_aux_cia				varchar2(5);',
'v_aux_cls				varchar2(50);',
'v_flag					number;',
'v_sesionid				varchar2(100);',
'v_route_id				varchar2(100);',
'v_response				clob;',
'v_compania_sap			varchar2(5)   :='''';',
'v_code					number;',
'v_status				varchar2(10);',
'v_borrador				number;',
'v_sapfinal				number;',
'v_docnumfinal			number;',
'v_docentryfinal			number;',
'v_fechadocfinal			date;',
'v_entidadclase			varchar2(5);',
'v_idRutaAprobacionSAP	VARCHAR2(50);',
'v_trama					varchar2(3999);',
'begin',
'	v_compania		:= :g_compania;',
'	v_log_app		:= ''apex.130.100.aprobacionlote'';',
'	v_cor_rem		:= ''apex@zaimella.com'';',
'	:p100_aprobar	:= null;',
'	v_reporte		:= :p100_tipo;',
'',
unistr('	v_log_dsc := ''Aprobaci\00F3n en Lote: Opci\00F3n: ''||:p100_tipo||'', Compa\00F1ia: ''||:g_compania||'', Usuario: ''||:app_user;'),
'',
'	if v_reporte = ''#rptLiquidacion'' then',
'		pk_commons.sp_apex_log(v_log_app,1,v_log_dsc,v_log_msg,v_log_obs,null);',
'		v_id_exito_com := null; v_id_error_com := null;',
'		v_id_exito_pgr := null; v_id_error_pgr := null;',
'		v_id_exito_liq := null; v_id_error_liq := null;',
'',
'		for i in 1..apex_application.g_f03.count loop  --Recorre las filas seleccionadas',
'			v_id := apex_application.g_f03(i);',
'			--Se recupera los datos d cada registro seleccionado',
'			--v_tipodata	(LIQ>>Liquidaciones de compra  || COM>>Ordenes)',
'			select item into v_tipodata		from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 1;',
'			--v_numero		(IDENTIFADOR DE LA ORDEN Y/O LIQUIDACION DE COMPRA)',
'			select item into v_numero		from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 2;',
'			--v_aprobador	(IDENTIFICADOR DE APROBADOR)',
'			select item into v_aprobador	from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 3;',
'			--v_tipo		(TIPO DE ORDEN Y/O LIQUIDACION DE COMPRA)',
'			select item into v_tipo			from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 4;',
'',
'			v_log_msg := ''v_tipodata: ''||v_tipodata||'', v_numero: ''||v_numero|| '', v_aprobador: ''||v_aprobador|| '', v_tipo: ''||v_tipo;',
'',
'			if v_tipodata = ''COM'' then',
'				v_objeto  := ''DOCUMENTO'';',
'				v_modulo  := :app_modulo;',
'',
'				pk_corp_flujoaprobacion.sp_flujoaprobar(',
'					p_id 					=> v_numero',
'					, p_objeto				=> v_tipo',
'					, p_ordenmonto			=> null',
'					, p_usuarioflujo		=> v_aprobador',
'					, p_usuario				=> :app_user',
'					, p_comentario			=> :p100_comentario',
'					, p_comentario_usuarios	=> :p100_usuario_seleccion',
'					, p_modulo				=> :app_modulo',
'					, p_compania			=> v_compania',
'					, p_exito				=> v_exito',
'					, p_terminoflujo		=> v_termino',
'				);',
'',
'				v_trama := null;',
'				if :app_user not in (''GDIMELLA'',''DJACOME'',''CRUBINA'',''RGARCIA'') then',
'					v_trama := ''Trama: ''||data.pk_corp_flujoaprobacion.g_trama;',
'					v_trama := v_trama||'', Mensaje: ''||data.pk_corp_flujoaprobacion.g_mensaje;',
'					v_trama := substr(v_trama,1,3999);',
'				end if;',
'',
'				if v_exito = 1 then -- Continuacion de proceso cuando se aprueba con exito',
'					if v_termino = 1 then -- Continuacion de proceso cuando termina el flujo',
'						pk_comp_ordenescompra.sp_aprobarorden(',
'							p_numero	=> v_numero',
'							,p_tipo 	=> v_tipo',
'							,p_compania	=> v_compania',
'						);',
'					end if;',
'',
'					-- Guarda los Id que se aprobaron con exito',
'					if length(v_id_exito_com) > 0 then',
'						v_id_exito_com := v_id_exito_com||'', ''||v_tipo||''-''||v_numero;',
'					else ',
'						v_id_exito_com :=v_tipo||''-''||v_numero;',
'					end if; ',
'				else -- Continuacion de proceso cuando da un error al aprobar el flujo',
'					if length(v_id_error_com) > 0 then',
'						v_id_error_com := v_id_error_com||'', ''||v_tipo||''-''||v_numero;',
'					else',
'						v_id_error_com := v_tipo||''-''||v_numero;',
'					end if;',
'				end if;',
'				v_log_obs := ''v_exito: ''||v_exito||'', v_termino: ''||v_termino||'', v_id_exito_com: ''||v_id_exito_com||'', v_id_error_com: ''||v_id_error_com;',
'				pk_commons.sp_apex_log(v_log_app,2,v_log_dsc,v_log_msg,v_log_obs,v_trama);',
'			elsif v_tipodata = ''PGR'' then',
'				v_objeto := ''PAGORECURRENTE'';',
'				v_modulo  := :app_modulo;',
'',
'				pk_corp_flujoaprobacion.sp_flujoaprobar(',
'					p_id 					=> v_numero',
'					, p_objeto				=> v_objeto',
'					, p_ordenmonto			=> null',
'					, p_usuarioflujo		=> v_aprobador',
'					, p_usuario				=> :app_user',
'					, p_comentario			=> :p100_comentario',
'					, p_comentario_usuarios	=> :p100_usuario_seleccion',
'					, p_modulo				=> v_modulo',
'					, p_compania			=> v_compania',
'					, p_exito				=> v_exito',
'					, p_terminoflujo		=> v_termino',
'				);',
'',
'				v_trama := null;',
'				if :app_user not in (''GDIMELLA'',''DJACOME'',''CRUBINA'',''RGARCIA'') then',
'					v_trama := ''Trama: ''||data.pk_corp_flujoaprobacion.g_trama;',
'					v_trama := v_trama||'', Mensaje: ''||data.pk_corp_flujoaprobacion.g_mensaje;',
'					v_trama := substr(v_trama,1,3999);',
'				end if;',
'',
'				if v_exito = 1 then',
'					if v_termino = 1 then',
'						pk_comp_negociacion.sp_aprobacionpagorecurrente(v_compania,:app_user,v_numero,''APROBAR'',v_respuesta);',
'					end if;',
'',
'					if length(v_id_exito_pgr) > 0 then',
'						v_id_exito_pgr := v_id_exito_pgr||'', ''||v_tipo||''-''||v_numero;',
'					else ',
'						v_id_exito_pgr := v_tipo||''-''||v_numero;',
'					end if; ',
'				else',
'					if length(v_id_error_pgr) > 0 then',
'						v_id_error_pgr := v_id_error_pgr||'', ''||v_tipo||''-''||v_numero;',
'					else',
'						v_id_error_pgr := v_tipo||''-''||v_numero;',
'					end if;',
'				end if;',
'				v_log_obs := ''v_exito: ''||v_exito||'', v_termino: ''||v_termino||'', v_id_exito_pgr: ''||v_id_exito_pgr||'', v_id_error_pgr: ''||v_id_error_pgr;',
'				pk_commons.sp_apex_log(v_log_app,2,v_log_dsc,v_log_msg,v_log_obs,v_trama);',
'			elsif v_tipodata = ''LIQ'' then',
'				v_objeto := ''Liquidacion'';',
'				v_modulo := ''GLIQ'';',
'',
'				select monto,solicitante,estadoaprobacion into v_monto,v_usuario,v_estadoaprobacion from vt_gliq_mesatrabajo where id = v_numero;',
'',
'				pk_corp_flujoaprobacion.sp_flujoaprobar(',
'					p_id 					=> v_numero',
'					, p_objeto				=> v_objeto',
'					, p_ordenmonto			=> v_monto',
'					, p_usuarioflujo		=> v_aprobador',
'					, p_usuario				=> :APP_USER',
'					, p_comentario			=> :P100_COMENTARIO',
'					, P_COMENTARIO_USUARIOS	=> :P100_USUARIO_SELECCION',
'					, p_modulo				=> v_modulo',
'					, p_compania			=> v_compania',
'					, p_exito				=> v_exito',
'					, P_TERMINOFLUJO		=> v_termino',
'				);',
'',
'				v_trama := null;',
'				if :app_user not in (''GDIMELLA'',''DJACOME'',''CRUBINA'',''RGARCIA'') then',
'					v_trama := ''Trama: ''||data.pk_corp_flujoaprobacion.g_trama;',
'					v_trama := v_trama||'', Mensaje: ''||data.pk_corp_flujoaprobacion.g_mensaje;',
'					v_trama := substr(v_trama,1,3999);',
'				end if;',
'					',
'				if v_exito = 1 then -- Continuacion de proceso cuando se aprueba con exito',
'					if v_termino = 1 then -- Continuacion de proceso cuando termina el flujo',
'						v_estado := CASE',
'									WHEN v_estadoaprobacion = ''S''								then ''GA''	--fLUJO DE APROBACION',
'									WHEN v_estadoaprobacion = ''GA''								then ''A''',
'									WHEN v_estadoaprobacion = ''P'' AND v_tipo	 LIKE ''%B/S%''	then ''GR''	--fLUJO DE APROBACION',
'									WHEN v_estadoaprobacion = ''P'' AND v_tipo NOT LIKE ''%B/S%''	then ''GP''	--fLUJO DE APROBACION',
'									WHEN v_estadoaprobacion IN (''GP'',''GR'')						then ''F''',
'								end;',
'						if v_estadoaprobacion IN (''S'',''P'') then ',
'							pk_corp_flujoaprobacion.sp_flujoenviar(',
'								p_id					=> v_numero',
'								, p_objeto				=> v_objeto',
'								, p_objetodescripcion	=> v_tipo ||'' Nro. ''||  v_numero',
'								, p_usuario				=> v_usuario',
'								, p_modulo				=> v_modulo',
'								, p_compania			=> v_compania',
'								, P_CODIGOPAGINA		=> ''GLIQMOD05''',
'								, P_TIPO1				=> ''FINANZAS''',
'								, P_TIPO2				=> v_estado',
'								, p_exito				=> v_exito',
'							);',
'',
'							select id,usuarioactual	into v_id_flujo,v_usuario_flujo from t_flujo_aprobacion_cab where codmodulo = ''GLIQ'' and estado = ''EN_PROCESO'' and entidad_id = v_numero;',
'						end if;',
'',
'						update t_gliq_liquidacion set usuarioflujo = v_usuario_flujo, idflujo = v_id_flujo, estadoaprobacion = v_estado where id = v_numero;',
'					end if;',
'',
'					-- Guarda los Id que se aprobaron con exito',
'					if length(v_id_exito_liq) > 0 then',
'						v_id_exito_liq := v_id_exito_liq||'', ''||v_numero;',
'					else',
'						v_id_exito_liq := v_numero;',
'					end if;',
'				else	-- Continuacion de proceso cuando da un error al aprobar el flujo',
'					if length(v_id_error_liq) > 0 then',
'						v_id_error_liq := v_id_error_liq||'', ''||v_numero;',
'					else ',
'						v_id_error_liq := v_numero;',
'					end if; ',
'				end if;',
'				v_log_obs := ''v_exito: ''||v_exito||'', v_termino: ''||v_termino||'', v_id_exito_liq: ''||v_id_exito_liq||'', v_id_error_liq: ''||v_id_error_liq;',
'				pk_commons.sp_apex_log(v_log_app,2,v_log_dsc,v_log_msg,v_log_obs,v_trama);',
'			end if;',
'		end loop;',
'',
unistr('		-- Mensaje de \00C9xito'),
'		if length(v_id_exito_com) > 0 then',
unistr('			v_log_msg := ''Se aprob\00F3 con \00E9xito las \00F3rdenes: ''||v_id_exito_com;'),
'			pk_commons.sp_apex_log(v_log_app,3,v_log_dsc,v_log_msg,null,null);',
'			apex_application.g_print_success_message := v_log_msg;',
'		end if;',
'',
'		if length(v_id_exito_pgr) > 0 then',
unistr('			v_log_msg := ''Se aprob\00F3 con \00E9xito los pagos recurrentes: ''||v_id_exito_pgr;'),
'			pk_commons.sp_apex_log(v_log_app,3,v_log_dsc,v_log_msg,null,null);',
'			apex_application.g_print_success_message := v_log_msg;',
'		end if;',
'',
'		if length(v_id_exito_liq) > 0 then',
unistr('			v_log_msg := ''Se aprob\00F3 con \00E9xito las liquidaciones: ''||v_id_exito_liq;'),
'			pk_commons.sp_apex_log(v_log_app,3,v_log_dsc,v_log_msg,null,null);',
'			apex_application.g_print_success_message := v_log_msg;',
'		end if;',
'',
'		-- Mensaje de error',
'		if length(v_id_error_com) > 0 then',
unistr('			v_log_msg := ''Error en aprobar las \00F3rdenes: ''||v_id_error_com;'),
'			pk_commons.sp_apex_log(v_log_app,-1,v_log_dsc,v_log_msg,null,null);',
'			apex_error.add_error(p_message => v_log_msg, p_display_location => apex_error.c_inline_in_notification);',
'		end if;',
'',
'		if length(v_id_error_pgr) > 0 then',
'			v_log_msg := ''Error en aprobar los pagos recurrentes: ''||v_id_error_pgr;',
'			pk_commons.sp_apex_log(v_log_app,-1,v_log_dsc,v_log_msg,null,null);',
'			apex_error.add_error(p_message => v_log_msg, p_display_location => apex_error.c_inline_in_notification);',
'		end if;',
'',
'		if length(v_id_error_liq) > 0 then',
'			v_log_msg := ''Error en aprobar las liquidaciones: ''||v_id_error_liq;',
'			pk_commons.sp_apex_log(v_log_app,-1,v_log_dsc,v_log_msg,null,null);',
'			apex_error.add_error(p_message => v_log_msg, p_display_location => apex_error.c_inline_in_notification);',
'		end if;',
'	elsif v_reporte = ''#rptNotasCredito'' then',
'		pk_commons.sp_apex_log(v_log_app,1,v_log_dsc,v_log_msg,v_log_obs,null);',
'		v_id_error_com := null;',
'',
'		for i in 1..apex_application.g_f01.count loop  --Recorre las filas seleccionadas',
'			v_id := apex_application.g_f01(i);',
'			-- Lote',
'			select item into v_numero		from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 1;',
'			-- Aprobador',
'			select item into v_aprobador	from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 2;',
'',
'			v_log_msg := ''v_numero: ''||v_numero||'', v_aprobador: ''||v_aprobador;',
'',
'			pk_corp_flujoaprobacion.sp_flujoaprobar(',
'				p_id 					=> v_numero',
'				, p_objeto				=> ''GENERACION_NOTA_CREDITO''',
'				, p_ordenmonto			=> null',
'				, p_usuarioflujo		=> v_aprobador',
'				, p_usuario				=> :APP_USER',
'				, p_comentario			=> null',
'				, p_comentario_usuarios	=> null',
'				, p_modulo				=> ''BACK''',
'				, p_compania			=> v_compania',
'				, p_exito				=> v_exito',
'				, p_terminoflujo		=> v_termino',
'			);	-- llama el proceso estandar de aprobar flujo',
'',
'			if v_exito = 1 then -- Continuacion de proceso cuando se aprueba con exito',
'				if v_termino = 1 then -- Continuacion de proceso cuando termina el flujo',
'					pk_back_notadecredito.sp_apruebanc(v_numero,''0'');',
'				end if;',
'			else',
'				if length(v_id_error_com) > 0 then',
'					v_id_error_com := v_id_error_com||'', ''||v_numero;',
'				else',
'					v_id_error_com := v_numero;',
'				end if;',
'			end if;',
'			v_log_obs := ''v_exito: ''||v_exito||'', v_termino: ''||v_termino||'', v_id_error_com: ''||v_id_error_com;',
'			pk_commons.sp_apex_log(v_log_app,2,v_log_dsc,v_log_msg,v_log_obs,null);',
'		end loop;',
'',
'		-- Mensaje de exito',
'		if v_id_error_com is null or length(v_id_error_com) = 0 then',
unistr('			v_log_msg := ''Todas las Notas de Cr\00E9dito Marcadas fueron aprobadas con \00E9xito.'';'),
'			pk_commons.sp_apex_log(v_log_app,3,v_log_dsc,v_log_msg,null,null);',
'			apex_application.g_print_success_message := v_log_msg;',
'		else',
'			if instr(v_id_error_com,'','') > 0 then',
'				v_mensaje := ''Error al aprobar las NCs: ''||v_id_error_com;',
'			else',
'				v_mensaje := ''Error al aprobar la NC: ''||v_id_error_com;',
'			end if;',
'			v_log_msg := v_mensaje;',
'			pk_commons.sp_apex_log(v_log_app,-1,v_log_dsc,v_log_msg,null,null);',
'			apex_error.add_error(p_message => v_log_dsc, p_display_location	=> apex_error.c_inline_in_notification);',
'		end if;',
'	elsif v_reporte = ''#rptCEGrupoZML'' then',
'		pk_commons.sp_apex_log(v_log_app,1,v_log_dsc,null,null,null);',
'		v_id_error_cgz := null;',
'',
'		for i in 1..apex_application.g_f06.count loop  --Recorre las filas seleccionadas',
'			v_id := apex_application.g_f06(i);',
'',
'			begin',
'				-- ID orden de compra',
'				select item into v_numero		from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 1;',
'				-- Aprobador',
'				select item into v_aprobador	from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 2;',
'				-- Numero documento SAP ',
'				select item into v_numero_aux   from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 3;',
'',
'				exception when others then',
unistr('					v_log_msg := ''Error en obtenci\00F3n de datos de pk_commons.f_dividirtexto'';'),
'					v_log_obs := ''v_id: ''||v_id;',
'					pk_commons.sp_apex_log(v_log_app,-1,v_log_dsc,v_log_msg,v_log_obs,null);',
'					return;',
'			end;',
'',
'			v_log_msg := ''v_aprobador: ''||v_aprobador||'', v_numero: ''||v_numero||'', v_numero_aux: ''||v_numero_aux;',
'',
'			begin',
'				select companiades,entidadclase into v_aux_cia,v_aux_cls',
'				from data.vt_comp_ordencompraext where entidadclase is not null and idcab = v_numero and rownum = 1;',
'',
'				exception when others then',
unistr('					v_log_msg := ''Error en obtenci\00F3n de datos de data.vt_comp_ordencompraext'';'),
'					v_log_obs := ''v_numero: ''||v_numero;',
'					pk_commons.sp_apex_log(v_log_app,-2,v_log_dsc,v_log_msg,v_log_obs,null);',
'					return;',
'			end;',
'',
'			v_log_msg := v_log_msg||'', v_aux_cia: ''||v_aux_cia||'', v_aux_cls: ''||v_aux_cls;',
'			pk_commons.sp_apex_log(v_log_app,2,v_log_dsc,v_log_msg,null,null);',
'',
'			begin',
'				data.pk_corp_flujoaprobacion.sp_flujoaprobar (',
'					p_id 					=> v_numero',
'					, p_objeto				=> v_aux_cls',
'					, p_ordenmonto			=> null',
'					, p_usuarioflujo		=> v_aprobador',
'					, p_usuario				=> :app_user',
'					, p_comentario			=> null',
'					, p_comentario_usuarios	=> null',
'					, p_modulo				=> ''COMP''',
'					, p_compania			=> v_compania',
'					, p_exito				=> v_exito',
'					, p_terminoflujo		=> v_termino',
'				);',
'',
'				v_trama := null;',
'				if :app_user not in (''GDIMELLA'',''DJACOME'',''CRUBINA'',''RGARCIA'') then',
'					v_trama := ''Trama: ''||data.pk_corp_flujoaprobacion.g_trama;',
'					v_trama := v_trama||'', Mensaje: ''||data.pk_corp_flujoaprobacion.g_mensaje;',
'					v_trama := substr(v_trama,1,3999);',
'				end if;',
'',
'				exception when others then',
unistr('					v_log_msg := ''Error en flujo de aprobaci\00F3n'';'),
'					pk_commons.sp_apex_log(v_log_app,-3,v_log_dsc,v_log_msg,null,v_trama);',
'					v_exito := 0;',
'			end;',
'			v_log_msg := ''v_exito: ''||v_exito||'', v_termino: ''||v_termino;',
'			pk_commons.sp_apex_log(v_log_app,3,v_log_dsc,v_log_msg,null,v_trama);',
'',
'			if v_exito = 1 then',
'				if v_termino = 1 then',
'					data.pk_comp_gestionocgrupozm.sp_gestionaprobacion(v_compania,:app_user,v_numero,''APROBAR'');',
'				end if;',
'			else',
'				v_log_msg := ''Elementos con problemas.'';',
'				v_log_obs := ''v_exito: ''||nvl(v_exito,0)||'', v_termino: ''||nvl(v_termino,0);',
'				pk_commons.sp_apex_log(v_log_app,4,v_log_dsc,v_log_msg,null,null);',
'',
'				if length(v_id_error_cgz) > 0 then',
'					v_id_error_cgz := v_id_error_cgz||'', ''||v_numero;',
'				else',
'					v_id_error_cgz := v_numero;',
'				end if;',
'			end if;',
'			v_log_obs := ''v_id_error_cgz: ''||v_id_error_cgz;',
'			pk_commons.sp_apex_log(v_log_app,5,v_log_dsc,v_log_msg,v_log_obs,null);',
'		end loop;',
'',
'		-- Mensaje de exito',
'		if v_id_error_cgz is null or length(v_id_error_cgz) = 0 then',
unistr('			v_log_msg := ''Todas las OCs del Grupo Zaimella marcadas fueron aprobadas con \00E9xito.'';'),
'			pk_commons.sp_apex_log(v_log_app,6,v_log_dsc,v_log_msg,null,null);',
'			apex_application.g_print_success_message := v_log_dsc;',
'		else',
'			if instr(v_id_error_cgz,'','') > 0 then',
'				v_mensaje := ''Error al aprobar las OCGZMLs: ''||v_id_error_cgz;',
'			else',
'				v_mensaje := ''Error al aprobar la OCGZML: ''||v_id_error_cgz;',
'			end if;',
'			v_log_msg := v_mensaje;',
'			pk_commons.sp_apex_log(v_log_app,-4,v_log_dsc,v_log_msg,null,null);',
'			-- apex_error.add_error(p_message => v_log_dsc, p_display_location	=> apex_error.c_inline_in_notification);',
'			v_cor_sub := ''Apex: ''||''Error a ''||:app_user||'' al aprobar en ''||v_log_app;',
'			data.pk_commons.sp_apex_correo(v_log_app,v_cor_rem,''ddelacruz@zaimella.com'',null,null,v_cor_sub,v_log_msg);',
'		end if;',
'	elsif v_reporte = ''#rptCosto'' then',
'		pk_commons.sp_apex_log(v_log_app,1,v_log_dsc,null,null,null);',
'		v_id_error_com := null;',
'',
'		for i in 1..apex_application.g_f01.count loop  --Recorre las filas seleccionadas',
'			v_id := apex_application.g_f01(i);',
'',
'			--Se recupera los datos d cada registro seleccionado:',
'			-- Proceso',
'			select item into v_numero		from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 1;',
'			-- Aprobador',
'			select item into v_aprobador	from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 2;',
'',
'			v_log_dsc := ''v_id = ''||v_id||'', v_numero = ''||v_numero||'', v_aprobador = ''||v_aprobador;',
'',
'			pk_corp_flujoaprobacion.sp_flujoaprobar(',
'				p_id 					=> v_numero',
'				, p_objeto				=> ''COSTO_PROVEEDOR''',
'				, p_ordenmonto			=> null',
'				, p_usuarioflujo		=> v_aprobador',
'				, p_usuario				=> :app_user',
'				, p_comentario			=> null',
'				, p_comentario_usuarios	=> null',
'				, p_modulo				=> :app_modulo',
'				, p_compania			=> v_compania',
'				, p_exito				=> v_exito',
'				, p_terminoflujo		=> v_termino',
'			);',
'',
'			if v_exito = 1 then',
'				if v_termino = 1 then',
'					pk_comp_ordenescompra.sp_aprobarcostoproveedor(p_numero=>v_numero,p_compania=>v_compania);',
'				end if;',
'			else',
'				if length(v_id_error_com) > 0 then',
'					v_id_error_com := v_id_error_com||'', ''||v_numero;',
'				else',
'					v_id_error_com := v_numero;',
'				end if;',
'			end if;',
'			v_log_obs := ''v_exito: ''||v_exito||'', v_termino: ''||v_termino||'', v_id_error_com: ''||v_id_error_com;',
'			pk_commons.sp_apex_log(v_log_app,2,v_log_dsc,v_log_msg,v_log_obs,null);',
'		end loop;',
'',
'		-- Mensaje de exito',
'		if v_id_error_com is null or length(v_id_error_com) = 0 then',
'			v_log_msg := ''Todos los registros marcadas fueron aprobados.'';',
'			pk_commons.sp_apex_log(v_log_app,3,v_log_dsc,v_log_msg,null,null);',
'			apex_application.g_print_success_message := v_log_dsc;',
'		else',
'			v_log_msg := ''Error al aprobar Costo/Proveedor: ''||v_id_error_com;',
'			pk_commons.sp_apex_log(v_log_app,-1,v_log_dsc,v_log_msg,null,null);',
'			apex_error.add_error (p_message => v_log_msg, p_display_location => apex_error.c_inline_in_notification);',
'		end if;',
'	elsif v_reporte = ''#rptDescuentoCantidad'' then',
'		pk_commons.sp_apex_log(v_log_app,1,v_log_dsc,null,null,null);',
'		v_id_error_com := null;',
'		return;',
'	elsif v_reporte = ''#rptNegociacion'' then',
'		pk_commons.sp_apex_log(v_log_app,1,v_log_dsc,null,null,null);',
'		for i in 1..apex_application.g_f04.count loop',
'			v_id := apex_application.g_f04(i);',
'',
'			select item into v_numero	from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 1;',
'			select item into v_tipo		from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 2;',
'',
'			v_modulo	:= ''COMP'';',
'			v_aprobador	:= :app_user;',
'			v_usuario	:= :app_user;',
'',
'			select nvl(a.recurrente,''NO''),trim(b.unidadnegocio) into v_recurrente,v_objeto',
'			from t_comp_negociacion a inner join t_comp_negociacioncab b on a.id = b.idneg',
'			where a.id = v_numero and rownum = 1;',
'',
'			if v_recurrente = ''NO'' then',
'				v_objeto	:= ''NEGOCIACION'';',
'			end if;',
'',
'			v_log_msg := ''v_numero: ''||v_numero||'', v_tipo: ''||v_tipo||'', v_recurrente: ''||v_recurrente||'', v_objeto: ''||v_objeto;',
'',
'			pk_corp_flujoaprobacion.sp_flujoaprobar(',
'				p_id 					=> v_numero',
'				, p_objeto				=> v_objeto',
'				, p_ordenmonto			=> null',
'				, p_usuarioflujo		=> v_aprobador',
'				, p_usuario				=> v_usuario',
'				, p_comentario			=> ''''',
'				, p_comentario_usuarios	=> ''''',
'				, p_modulo				=> v_modulo',
'				, p_compania			=> v_compania',
'				, p_exito				=> v_exito',
'				, p_terminoflujo		=> v_termino',
'			);',
'',
'			v_trama := null;',
'			if :app_user not in (''GDIMELLA'',''DJACOME'',''CRUBINA'',''RGARCIA'') then',
'				v_trama := ''Trama: ''||data.pk_corp_flujoaprobacion.g_trama;',
'				v_trama := v_trama||'', Mensaje: ''||data.pk_corp_flujoaprobacion.g_mensaje;',
'				v_trama := substr(v_trama,1,3999);',
'			end if;',
'',
'			if v_exito = 1 then',
'				if v_termino = 1 then',
'					data.pk_comp_negociacion.sp_aprobarnegociacion(p_compania => v_compania, p_usuario => v_usuario, p_idneg => v_numero);',
'				end if;',
'',
'				if length(v_nego_exito) > 0 then',
'					v_nego_exito := v_nego_exito||''; ''||pk_comp_negociacion.f_neg_esquema(v_numero);',
'				else',
'					v_nego_exito := pk_comp_negociacion.f_neg_esquema(v_numero);',
'				end if; ',
'			else',
'				if length(v_nego_error) > 0 then',
'					v_nego_error := v_nego_error||''; ''||pk_comp_negociacion.f_neg_esquema(v_numero);',
'				else',
'					v_nego_error := pk_comp_negociacion.f_neg_esquema(v_numero);',
'				end if;				',
'			end if;',
'			v_log_obs := ''v_exito: ''||v_exito||'', v_termino: ''||v_termino||'', v_nego_exito: ''||v_nego_exito||'', v_nego_error; ''||v_nego_error;',
'			pk_commons.sp_apex_log(v_log_app,2,v_log_dsc,v_log_msg,v_log_obs,v_trama);',
'		end loop;',
'',
'		-- Mensaje de exito',
'		if length(v_nego_exito) > 0 then',
unistr('			v_log_msg := ''Negociaciones aprobadas con \00E9xito.'';'),
'			pk_commons.sp_apex_log(v_log_app,3,v_log_dsc,v_log_msg,null,null);',
'			apex_application.g_print_success_message := v_log_msg;',
'		end if;',
'',
'		-- Mensaje de error',
'		if length(v_nego_error) > 0 then',
'			v_log_msg := ''Error en procesar: ''||v_nego_error;',
'			pk_commons.sp_apex_log(v_log_app,-1,v_log_dsc,v_log_msg,null,null);',
'			apex_error.add_error (p_message => v_log_msg, p_display_location => apex_error.c_inline_in_notification);',
'		end if;',
'	elsif v_reporte = ''#rptPagosRecurrentes'' then',
'		pk_commons.sp_apex_log(v_log_app,1,v_log_dsc,null,null,null);',
'',
'		for i in 1..apex_application.g_f05.count loop  --Recorre las filas seleccionadas',
'			v_id := apex_application.g_f05(i);',
'',
'			select item into v_numero	from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 1;',
'			select item into v_tipo		from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 2;',
'',
'			v_modulo	:= ''COMP'';',
'			v_aprobador	:= :app_user;',
'			v_usuario	:= :app_user;',
'',
'			select nvl(a.recurrente,''NO''),trim(b.unidadnegocio) into v_recurrente,v_objeto',
'			from t_comp_negociacion a inner join t_comp_negociacioncab b on a.id = b.idneg',
'			where a.id = v_numero and rownum = 1;',
'',
'			if v_recurrente = ''NO'' then',
'				v_objeto	:= ''NEGOCIACION'';',
'			end if;',
'',
'			v_log_msg := ''v_numero: ''||v_numero||'', v_tipo: ''||v_tipo||'', v_recurrente: ''||v_recurrente||'', v_objeto: ''||v_objeto;',
'',
'			pk_corp_flujoaprobacion.sp_flujoaprobar(',
'				p_id 					=> v_numero',
'				, p_objeto				=> v_objeto',
'				, p_ordenmonto			=> null',
'				, p_usuarioflujo		=> v_aprobador',
'				, p_usuario				=> v_usuario',
'				, p_comentario			=> ''''',
'				, p_comentario_usuarios	=> ''''',
'				, p_modulo				=> v_modulo',
'				, p_compania			=> v_compania',
'				, p_exito				=> v_exito',
'				, p_terminoflujo		=> v_termino',
'			);',
'',
'			if v_exito = 1 then',
'				if v_termino = 1 then',
'					data.pk_comp_negociacion.sp_aprobarnegociacion(p_compania => v_compania, p_usuario => v_usuario, p_idneg => v_numero);',
'				end if;',
'',
'				if length(v_nego_exito) > 0 then',
'					v_nego_exito := v_nego_exito||''; ''||pk_comp_negociacion.f_neg_esquema(v_numero);',
'				else',
'					v_nego_exito := pk_comp_negociacion.f_neg_esquema(v_numero);',
'				end if; ',
'			else',
'				if length(v_nego_error) > 0 then',
'					v_nego_error := v_nego_error||''; ''||pk_comp_negociacion.f_neg_esquema(v_numero);',
'				else',
'					v_nego_error := pk_comp_negociacion.f_neg_esquema(v_numero);',
'				end if;				',
'			end if;',
'			v_log_obs := ''v_exito: ''||v_exito||'', v_termino: ''||v_termino||'', v_nego_exito: ''||v_nego_exito||'', v_nego_error; ''||v_nego_error;',
'			pk_commons.sp_apex_log(v_log_app,2,v_log_dsc,v_log_msg,v_log_obs,null);',
'		end loop;',
'',
'		-- Mensaje de exito',
'		if length(v_nego_exito) > 0 then',
unistr('			v_log_msg := ''Negociaciones de Pagos Recurrentes aprobadas con \00E9xito.'';'),
'			pk_commons.sp_apex_log(v_log_app,3,v_log_dsc,v_log_msg,null,null);',
'			apex_application.g_print_success_message := v_log_msg;',
'		end if;',
'',
'		-- Mensaje de error',
'		if length(v_nego_error) > 0 then',
'			v_log_msg := ''Error en procesar: ''||v_nego_error;',
'			pk_commons.sp_apex_log(v_log_app,3,v_log_dsc,v_log_msg,null,null);',
'			 apex_error.add_error (p_message => v_log_msg, p_display_location => apex_error.c_inline_in_notification);',
'		end if;',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>unistr('ERROR Aprobaci\00F3n en Lote')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(94384916308893614)
,p_process_success_message=>unistr('Aprobaci\00F3n en Lote')
,p_internal_uid=>60864856801781248
,p_updated_on=>wwv_flow_imp.dz('20260624193504Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(60983053409265005)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Rechazo en lote'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'v_aprobador				varchar(2500);',
'v_compania				varchar2(5);',
'v_estado				varchar(250);',
'v_exito					number;',
'v_id					varchar2(2500);',
'v_id_error_com			varchar2(2500);',
'v_id_error_liq			varchar2(2500);',
'v_id_error_neg			varchar2(2500);',
'v_id_error_pgr			varchar2(2500);',
'v_id_error_cgz			varchar2(2500); --Compras Grupo ZML',
'v_id_exito_com			varchar2(2500);',
'v_id_exito_liq			varchar2(2500);',
'v_id_exito_neg			varchar2(2500);',
'v_id_exito_pgr			varchar2(2500);',
'v_id_exito_cgz			varchar2(2500); --Compras Grupo ZML',
'v_log_app				varchar2(99);',
'v_log_dsc				varchar2(3999);',
'v_log_msg				varchar2(3999);',
'v_log_obs				varchar2(3999);',
'v_cor_rem				varchar2(100);',
'v_cor_sub				varchar2(999);',
'v_mensaje				varchar2(2500);',
'v_modulo				varchar(250);',
'v_monto					number;',
'v_numero				varchar(20);',
'v_numero_aux 			varchar(20);',
'v_objeto				varchar(250);',
'v_recurrente			varchar2(5);',
'v_tipo					varchar2(2500);',
'v_tipodata				varchar(10);',
'v_usuario				varchar(250);',
'v_usuariosolicita 		varchar(250); --Compras Grupo ZML',
'v_comprador				varchar2(250);--Compras Grupo ZML',
'v_reporte				varchar(250);',
'v_respuesta				varchar(3999);',
'v_aux_num				number;',
'v_aux_cia				varchar2(5);',
'v_aux_cls				varchar2(50);',
'v_flag					number;',
'',
'v_sesionid				varchar2(100);',
'v_route_id				varchar2(100);',
'v_response				clob;',
'v_compania_sap			varchar2(5) ;',
'v_entidadclase			varchar2(5);',
'',
'v_code					number;',
'v_status				varchar2(10);',
'v_idRutaAprobacionSAP	varchar2(50);',
'',
'begin',
'	v_compania		:= :g_compania;',
'	v_log_app		:= ''apex.130.100.rechazolote'';',
'	v_cor_rem		:= ''apex@zaimella.com'';',
'	:p100_aprobar	:= null;',
'	v_reporte		:= :p100_tipo;',
'',
unistr('	v_log_dsc := ''Rechazo en Lote: Opci\00F3n: ''||:p100_tipo||'', Compa\00F1ia: ''||:g_compania||'', Usuario: ''||:app_user;'),
'',
'	if v_reporte = ''#rptLiquidacion'' then',
'		pk_commons.sp_apex_log(v_log_app,1,v_reporte,null,null,null);',
'',
'		for i in 1..apex_application.g_f03.count loop --Recorre las filas seleccionadas',
'			v_id := apex_application.g_f03(i);',
'			--Se recupera los datos d cada registro seleccionado',
'			--v_tipodata	(LIQ>>Liquidaciones de compra || COM>>Ordenes)',
'			select data into v_tipodata		from (select level as id, regexp_substr(v_id,''[^|]+'',1,level) as data from dual connect by regexp_substr(v_id,''[^|]+'',1,level) is not null) a where id = 1;',
'			--v_numero	 (IDENTIFADOR DE LA ORDEN Y/O LIQUIDACION DE COMPRA)',
'			select data into v_numero		from (select level as id, regexp_substr(v_id,''[^|]+'',1,level) as data from dual connect by regexp_substr(v_id,''[^|]+'',1,level) is not null) b where id = 2;',
'			--v_aprobador (IDENTIFICADOR DE APROBADOR)',
'			select data into v_aprobador	from (select level as id, regexp_substr(v_id,''[^|]+'',1,level) as data from dual connect by regexp_substr(v_id,''[^|]+'',1,level) is not null) c where id = 3;',
'			--v_tipo		(TIPO DE ORDEN Y/O LIQUIDACION DE COMPRA)',
'			select data into v_tipo			from (select level as id, regexp_substr(v_id,''[^|]+'',1,level) as data from dual connect by regexp_substr(v_id,''[^|]+'',1,level) is not null) c where id = 4;',
'			--CAMPO DE VALIDACION DE EXTRACION DE DATOS(SIEMPRE OCULTO)',
'			:p100_valores := v_tipodata ||''-''||v_numero||''-''||v_aprobador||''-''||v_tipo;',
'',
'			if v_tipodata = ''COM'' then',
'				v_objeto :=''DOCUMENTO'';',
'				v_modulo :=:app_modulo;',
'				pk_corp_flujoaprobacion.sp_flujorechazar(',
'					p_id					=> v_numero',
'					,p_objeto				=> v_tipo',
'					,p_usuarioflujo			=> v_aprobador',
'					,p_usuario				=> :app_user',
'					,p_comentario			=> :p100_comentario',
'					,p_comentario_usuarios	=> :p100_usuario_seleccion',
'					,p_modulo				=> :app_modulo',
'					,p_compania				=> :g_compania',
'					,p_exito				=> v_exito',
'				); -- llama el proceso estandar de aprobar flujo',
'',
'				if v_exito = 1 then -- Continuacion de proceso cuando se aprueba con exito',
'					pk_comp_ordenescompra.sp_rechazarlinea(',
'						p_numero	=> v_numero',
'						, p_tipo		=> v_tipo',
'						, p_compania	=> :g_compania',
'					);',
'',
'					-- Guarda los Id que se rechazaron con exito',
'					if length(v_id_exito_com) > 0 then',
'						v_id_exito_com := v_id_exito_com||'' ,''||v_tipo||''-''||v_numero;',
'					else',
'						v_id_exito_com := v_tipo||''-''||v_numero;',
'					end if; ',
'				else -- Continuacion de proceso cuando da un error al rechazar el flujo',
'					-- Guarda los Id que dieron error al rechazar',
'					if length(v_id_error_com) > 0 then',
'						v_id_error_com := v_id_error_com||'' ,''||v_tipo||''-''||v_numero;',
'					else',
'						v_id_error_com := v_tipo||''-''||v_numero;',
'					end if;',
'				end if;',
'			elsif v_tipodata = ''PGR'' then',
'				v_objeto	:= ''PAGORECURRENTE'';',
'				v_modulo	:= :app_modulo;',
'',
'				pk_corp_flujoaprobacion.sp_flujorechazar(',
'					p_id					=> v_numero',
'					, p_objeto				=> v_objeto',
'					, p_usuarioflujo		=> v_aprobador',
'					, p_usuario				=> :app_user',
'					, p_comentario			=> :p100_comentario',
'					, p_comentario_usuarios	=> :p100_usuario_seleccion',
'					, p_modulo				=> v_modulo',
'					, p_compania			=> :g_compania',
'					, p_exito				=> v_exito',
'				);',
'',
'				if v_exito = 1 then',
'					pk_comp_negociacion.sp_aprobacionpagorecurrente(v_compania,:app_user,v_numero,''RECHAZAR'',v_respuesta);',
'',
'					if length(v_id_exito_pgr) > 0 then',
'						v_id_exito_pgr := v_id_exito_pgr||'', ''||v_numero;',
'					else',
'						v_id_exito_pgr := v_numero;',
'					end if;',
'				else',
'					if length(v_id_error_pgr) > 0 then',
'						v_id_error_pgr := v_id_error_pgr||'', ''||v_numero;',
'					else',
'						v_id_error_pgr := v_numero;',
'					end if;',
'				end if;',
'			elsif v_tipodata = ''LIQ'' then',
'				v_objeto := ''Liquidacion'';',
'				v_modulo := ''GLIQ'';',
'				select 	monto,solicitante into v_monto,v_usuario from vt_gliq_mesatrabajo where id = v_numero; -- selecciona informacion del documento que se esta gestionando',
'',
'				pk_corp_flujoaprobacion.sp_flujorechazar(',
'					p_id					=> v_numero',
'					,p_objeto				=> v_objeto',
'					,p_usuarioflujo			=> v_aprobador',
'					,p_usuario				=> :app_user',
'					,p_comentario			=> :p100_comentario',
'					,p_comentario_usuarios	=> :p100_usuario_seleccion',
'					,p_modulo				=> v_modulo',
'					,p_compania				=> :g_compania',
'					,p_exito				=> v_exito',
'				); -- llama el proceso estandar de aprobar flujo',
'',
'				if v_exito = 1 then -- Continuacion de proceso cuando se aprueba con exito',
'					if v_tipo LIKE ''%B/S%'' then',
'						update t_gliq_liquidacion set estadoaprobacion = ''G'', usuarioflujo = null, idflujo = null where id = v_numero;',
'						v_estado := ''G'';',
'					else ',
'						update t_gliq_liquidacion set estadoaprobacion = ''A'', usuarioflujo = null, idflujo = null where id = v_numero;',
'						v_estado := ''A'';',
'					end if;',
'',
'					-- Guarda los Id que se rechazaron con exito',
'					if length(v_id_exito_liq) > 0 then',
'						v_id_exito_liq := v_id_exito_liq||'' ,''||v_numero;',
'					else',
'						v_id_exito_liq := v_numero;',
'					end if;',
'				else -- Continuacion de proceso cuando da un error al rechazaron el flujo',
'					-- Guarda los Id que dieron error al rechazaron',
'					if length(v_id_error_liq) > 0 then',
'						v_id_error_liq := v_id_error_liq||'' ,''||v_numero;',
'					else',
'						v_id_error_liq := v_numero;',
'					end if;',
'				end if;',
'			end if;',
'	 	end loop;',
'',
'		--Mensaje de exito',
'		if length(v_id_exito_com) > 0 then',
unistr('			apex_application.g_print_success_message := ''Se rechaz\00F3 con \00E9xito las ordenes: ''||v_id_exito_com;'),
'		end if;',
'		--Mensaje de error',
'		if length(v_id_error_com) > 0 then',
'			apex_error.add_error (',
'				p_message				=> ''Error en rechazar las ordenes: ''||v_id_error_com',
'				, p_display_location	=> apex_error.c_inline_in_notification',
'			);',
'		end if;',
'',
'		--Mensaje de exito',
'		if length(v_id_exito_liq) > 0 then',
unistr('			apex_application.g_print_success_message := ''Se rechaz\00F3 con \00E9xito las liquidaciones: ''||v_id_exito_liq;'),
'		end if;',
'',
'		--Mensaje de error',
'		if length(v_id_error_liq) > 0 then',
'			apex_error.add_error (',
'				p_message				=> ''Error en rechazar las liquidaciones: ''||v_id_error_liq',
'				, p_display_location	=> apex_error.c_inline_in_notification',
'			);',
'		end if;',
'',
'		--Mensaje de exito',
'		if length(v_id_exito_pgr) > 0 then',
unistr('			apex_application.g_print_success_message := ''Se rechaz\00F3 con \00E9xito los pagos recurrentes: ''||v_id_exito_pgr;'),
'		end if;',
'',
'		--Mensaje de error',
'		if length(v_id_error_pgr) > 0 then',
'			apex_error.add_error (',
'				p_message				=> ''Error en rechazar los pagos recurrentes: ''||v_id_error_pgr',
'				, p_display_location	=> apex_error.c_inline_in_notification',
'			);',
'		end if;',
'	elsif v_reporte = ''#rptNotasCredito'' then',
'		pk_commons.sp_apex_log(v_log_app,1,v_reporte,null,null,null);',
'		v_id_error_com := null;',
'',
'		for i in 1..apex_application.g_f01.count loop  --Recorre las filas seleccionadas',
'			v_id := apex_application.g_f01(i);',
'			-- Lote',
'			select item into v_numero		from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 1;',
'			-- Aprobador',
'			select item into v_aprobador	from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 2;',
'',
'			pk_commons.sp_apex_log(v_log_app,2,i,''v_numero: ''||v_numero||'', v_aprobador: ''||v_aprobador,null,null);',
'			',
'			pk_corp_flujoaprobacion.sp_flujorechazar(',
'				p_id					=> v_numero',
'				,p_objeto				=> ''GENERACION_NOTA_CREDITO''',
'				,p_usuarioflujo			=> v_aprobador',
'				,p_usuario				=> :app_user',
'				,p_comentario			=> null',
'				,p_comentario_usuarios	=> null',
'				,p_modulo				=> ''BACK''',
'				,p_compania				=> :g_compania',
'				,p_exito				=> v_exito',
'			); -- llama el proceso estandar de aprobar flujo',
'',
'			if v_exito = 1 then -- Continuacion de proceso cuando se aprueba con exito',
'				pk_back_notadecredito.sp_rechazanc(v_numero,''0'');',
'			else',
'				if length(v_id_error_com) > 0 then',
'					v_id_error_com := v_id_error_com||'', ''||v_numero;',
'				else',
'					v_id_error_com := v_numero;',
'				end if;',
'			end if;',
'		end loop;',
'',
'		--Mensaje de exito',
'		if v_id_error_com is null or length(v_id_error_com) = 0 then',
unistr('			apex_application.g_print_success_message := ''Todas las Notas de Cr\00E9dito Marcadas fueron rechazadas.'';'),
'		else',
'			if instr(v_id_error_com,'','') > 0 then',
'				v_mensaje := ''Error al rechazar las NCs: ''||v_id_error_com;',
'			else',
'				v_mensaje := ''Error al rechazar la NC: ''||v_id_error_com;',
'			end if;',
'',
'			apex_error.add_error (',
'				p_message 				=> v_mensaje',
'				,  p_display_location	=> apex_error.c_inline_in_notification',
'			);',
'		end if;',
'    elsif v_reporte = ''#rptCEGrupoZML'' then',
'		pk_commons.sp_apex_log(v_log_app,1,v_log_dsc,null,null,null);',
'		v_id_error_cgz := null;',
'',
'		for i in 1..apex_application.g_f06.count loop  --Recorre las filas seleccionadas',
'			v_id := apex_application.g_f06(i);',
'',
'			begin',
'				-- ID orden de compra',
'				select item into v_numero		from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 1;',
'				-- Aprobador',
'				select item into v_aprobador	from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 2;',
'				-- Numero documento SAP ',
'				select item into v_numero_aux   from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 3;',
'',
'				exception when others then',
unistr('					v_log_msg := ''Error en obtenci\00F3n de datos de pk_commons.f_dividirtexto'';'),
'					v_log_obs := ''v_id: ''||v_id;',
'					pk_commons.sp_apex_log(v_log_app,-1,v_log_dsc,v_log_msg,v_log_obs,null);',
'					return;',
'			end;',
'',
'			v_log_msg := ''v_aprobador: ''||v_aprobador||'', v_numero: ''||v_numero||'', v_numero_aux: ''||v_numero_aux;',
'',
'			begin',
'				select companiades,entidadclase into v_aux_cia,v_aux_cls',
'				from data.vt_comp_ordencompraext where entidadclase is not null and idcab = v_numero and rownum = 1;',
'',
'				exception when others then',
unistr('					v_log_msg := ''Error en obtenci\00F3n de datos de data.vt_comp_ordencompraext'';'),
'					v_log_obs := ''v_numero: ''||v_numero;',
'					pk_commons.sp_apex_log(v_log_app,-1,v_log_dsc,v_log_msg,v_log_obs,null);',
'					return;',
'			end;',
'',
'			v_log_msg := v_log_msg||'', v_aux_cia: ''||v_aux_cia||'', v_aux_cls: ''||v_aux_cls;',
'			pk_commons.sp_apex_log(v_log_app,2,v_log_dsc,v_log_msg,null,null);',
'',
'			begin',
'				pk_corp_flujoaprobacion.sp_flujorechazar(',
'					p_id					=> v_numero',
'					,p_objeto				=> v_aux_cls',
'					,p_usuarioflujo			=> v_aprobador',
'					,p_usuario				=> :app_user',
'					,p_comentario			=> null',
'					,p_comentario_usuarios	=> null',
'					,p_modulo				=> ''COMP''',
'					,p_compania				=> :g_compania',
'					,p_exito				=> v_exito',
'				);',
'',
'				exception when others then',
unistr('					v_log_msg := ''Error en flujo de aprobaci\00F3n'';'),
'					pk_commons.sp_apex_log(v_log_app,-1,v_log_dsc,v_log_msg,null,null);',
'					v_exito := 0;',
'			end;',
'			v_log_obs := ''v_exito: ''||v_exito;',
'			pk_commons.sp_apex_log(v_log_app,3,v_log_dsc,v_log_msg,null,null);',
'',
'			if v_exito = 1 then -- Continuacion de proceso cuando se aprueba con exito',
'				data.pk_comp_gestionocgrupozm.sp_gestionaprobacion(v_compania,:app_user,v_numero,''RECHAZAR'');',
'			else',
'				v_log_msg := ''Elementos con problemas.'';',
'				v_log_obs := ''v_exito: ''||nvl(v_exito,''nulo'');',
'				pk_commons.sp_apex_log(v_log_app,4,v_log_dsc,v_log_msg,null,null);',
'',
'				if length(v_id_error_cgz) > 0 then',
'					v_id_error_cgz := v_id_error_cgz||'', ''||v_numero_aux;',
'				else',
'					v_id_error_cgz := v_numero_aux;',
'				end if;',
'			end if;',
'		end loop;',
'',
'		--Mensaje de exito',
'		if v_id_error_cgz is null or length(v_id_error_cgz) = 0 then',
'			apex_application.g_print_success_message := ''Todas las OCs marcadas fueron rechazadas.'';',
'		else',
'			if instr(v_id_error_cgz,'','') > 0 then',
'				v_mensaje := ''Error al rechazar las OCs: ''||v_id_error_cgz;',
'			else',
'				v_mensaje := ''Error al rechazar la OC: ''||v_id_error_cgz;',
'			end if;',
'			v_log_msg := v_mensaje;',
'			pk_commons.sp_apex_log(v_log_app,-4,v_log_dsc,v_log_msg,null,null);',
'			-- apex_error.add_error (p_message => v_mensaje, p_display_location => apex_error.c_inline_in_notification);',
'			v_cor_sub := ''Apex: ''||''Error a ''||:app_user||'' al rechazar en ''||v_log_app;',
'			data.pk_commons.sp_apex_correo(v_log_app,v_cor_rem,''ddelacruz@zaimella.com'',null,null,v_cor_sub,v_log_msg);			',
'		end if;',
'	elsif v_reporte = ''#rptCosto'' then',
'		pk_commons.sp_apex_log(v_log_app,1,v_reporte,null,null,null); commit;',
'',
'		for i in 1..apex_application.g_f01.count loop  --Recorre las filas seleccionadas',
'			v_id := apex_application.g_f01(i);',
'',
'			--Se recupera los datos d cada registro seleccionado:',
'			-- Proceso',
'			select item into v_numero		from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 1;',
'			-- Aprobador',
'			select item into v_aprobador	from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 2;',
'',
'			v_log_dsc := ''Valores: v_id = ''||v_id||'', v_numero = ''||v_numero||'', v_aprobador = ''||v_aprobador;',
'			pk_commons.sp_apex_log(v_log_app,3,v_log_dsc,null,null,null); commit;',
'',
'			pk_corp_flujoaprobacion.sp_flujorechazar(',
'				p_id 					=> v_numero',
'				, p_objeto				=> ''COSTO_PROVEEDOR''',
'				, p_usuarioflujo		=> v_aprobador',
'				, p_usuario				=> :app_user',
'				, p_comentario			=> null',
'				, p_comentario_usuarios	=> null',
'				, p_modulo				=> :app_modulo',
'				, p_compania			=> :g_compania',
'				, p_exito				=> v_exito',
'			);	-- llama el proceso estandar de aprobar flujo',
'',
'			if v_exito = 1 then -- Continuacion de proceso cuando se aprueba con exito',
'				pk_comp_ordenescompra.sp_rechazarcostoproveedor(p_numero=>v_numero,p_compania=>:g_compania);',
'			else',
'				if length(v_id_error_com) > 0 then',
'					v_id_error_com := v_id_error_com||'', ''||v_numero;',
'				else',
'					v_id_error_com := v_numero;',
'				end if;',
'			end if;',
'		end loop;',
'',
'		--Mensaje de exito',
'		if v_id_error_com is null or length(v_id_error_com) = 0 then',
'			apex_application.g_print_success_message := ''Todas las Registros Marcadas fueron rechazados.'';',
'		else',
'			if instr(v_id_error_com,'','') > 0 then',
'				v_mensaje := ''Error al rechazar Costo/Proveedor: ''||v_id_error_com;',
'			else',
'				v_mensaje := ''Error al rechazar Costo/Proveedor: ''||v_id_error_com;',
'			end if;',
'',
'			apex_error.add_error (',
'				p_message 				=> v_mensaje',
'				,  p_display_location	=> apex_error.c_inline_in_notification',
'			);',
'		end if;',
'	elsif v_reporte = ''#rptDescuentoCantidad'' then',
'		pk_commons.sp_apex_log(v_log_app,1,v_reporte,null,null,null); commit;',
'		return;',
'	elsif v_reporte = ''#rptNegociacion'' then',
'		pk_commons.sp_apex_log(v_log_app,1,v_reporte,null,null,null);',
'		for i in 1..apex_application.g_f04.count loop --Recorre las filas seleccionadas',
'			v_id := apex_application.g_f04(i);',
'',
'			select item into v_numero	from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 1;',
'			select item into v_tipo		from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 2;',
'',
'			v_modulo	:= :app_modulo;',
'			v_aprobador	:= :p100_usuario;',
'			v_usuario	:= :p100_usuario;',
'',
'			select nvl(a.recurrente,''NO''),b.unidadnegocio into v_recurrente,v_objeto',
'			from t_comp_negociacion a inner join t_comp_negociacioncab b on a.id = b.idneg',
'			where a.id = v_numero and rownum = 1;',
'',
'			if v_recurrente = ''NO'' then',
'				v_objeto	:= ''NEGOCIACION'';',
'			end if;',
'',
'			v_log_dsc := ''v_id: ''||v_id||'', v_modulo: ''||v_modulo||'', v_aprobador: ''||v_aprobador||'', v_usuario: ''||v_usuario;',
'			v_log_dsc := v_log_dsc||'', v_recurrente: ''||v_recurrente||'', v_objeto: ''||v_objeto;',
'			pk_commons.sp_apex_log(v_log_app,2,v_reporte,v_log_dsc,null,null);',
'',
'			pk_corp_flujoaprobacion.sp_flujorechazar(',
'				p_id					=> v_numero',
'				,p_objeto				=> v_objeto',
'				,p_usuarioflujo			=> v_aprobador',
'				,p_usuario				=> v_usuario',
'				,p_comentario			=> ''''',
'				,p_comentario_usuarios	=> ''''',
'				,p_modulo				=> ''COMP''',
'				,p_compania				=> ''00001''',
'				,p_exito				=> v_exito',
'			);',
'			v_log_dsc := ''v_exito: ''||v_exito;',
'			pk_commons.sp_apex_log(v_log_app,3,v_reporte,v_log_dsc,null,null);',
'',
'			if v_exito = 1 then',
'				data.pk_comp_negociacion.sp_rechazarnegociacion(p_compania => v_compania, p_usuario => v_usuario, p_idneg => v_numero);',
'',
'				if length(v_id_exito_neg) > 0 then',
'					v_id_exito_neg := v_id_exito_neg||'' ,''||v_tipo||''-''||v_numero;',
'				else',
'					v_id_exito_neg := v_tipo||''-''||v_numero;',
'				end if; ',
'			else',
'				if length(v_id_error_neg) > 0 then',
'					v_id_error_neg := v_id_error_neg||'' ,''||v_tipo||''-''||v_numero;',
'				else',
'					v_id_error_neg := v_tipo||''-''||v_numero;',
'				end if;',
'			end if;',
'			v_log_dsc := ''v_id_exito_neg: ''||v_id_exito_neg||'', v_id_error_neg: ''||v_id_error_neg;',
'			pk_commons.sp_apex_log(v_log_app,4,v_reporte,v_log_dsc,null,null);',
'	 	end loop;',
'',
'		--Mensaje de exito',
'		if length(v_id_exito_neg) > 0 then',
unistr('			apex_application.g_print_success_message := ''Negociaciones rechazadas con \00E9xito.'';'),
'		end if;',
'',
'		--Mensaje de error',
'		if length(v_id_error_neg) > 0 then',
'			apex_error.add_error (',
'				p_message				=> ''Error en procesar: ''||v_id_error_neg',
'				, p_display_location	=> apex_error.c_inline_in_notification',
'			);',
'		end if;',
'	elsif v_reporte = ''#rptPagosRecurrentes'' then',
'		pk_commons.sp_apex_log(v_log_app,1,v_reporte,null,null,null);',
'		for i in 1..apex_application.g_f05.count loop --Recorre las filas seleccionadas',
'			v_id := apex_application.g_f05(i);',
'',
'			select item into v_numero	from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 1;',
'			select item into v_tipo		from table(pk_commons.f_dividirtexto(v_id,''|'')) where id = 2;',
'',
'			v_modulo	:= :app_modulo;',
'			v_aprobador	:= :p100_usuario;',
'			v_usuario	:= :p100_usuario;',
'',
'			select nvl(a.recurrente,''NO''),b.unidadnegocio into v_recurrente,v_objeto',
'			from t_comp_negociacion a inner join t_comp_negociacioncab b on a.id = b.idneg',
'			where a.id = v_numero and rownum = 1;',
'',
'			if v_recurrente = ''NO'' then',
'				v_objeto	:= ''NEGOCIACION'';',
'			end if;',
'',
'			v_log_dsc := ''v_id: ''||v_id||'', v_modulo: ''||v_modulo||'', v_aprobador: ''||v_aprobador||'', v_usuario: ''||v_usuario;',
'			v_log_dsc := v_log_dsc||'', v_recurrente: ''||v_recurrente||'', v_objeto: ''||v_objeto;',
'			pk_commons.sp_apex_log(v_log_app,2,v_reporte,v_log_dsc,null,null);',
'',
'			pk_corp_flujoaprobacion.sp_flujorechazar(',
'				p_id					=> v_numero',
'				,p_objeto				=> v_objeto',
'				,p_usuarioflujo			=> v_aprobador',
'				,p_usuario				=> v_usuario',
'				,p_comentario			=> ''''',
'				,p_comentario_usuarios	=> ''''',
'				,p_modulo				=> ''COMP''',
'				,p_compania				=> ''00001''',
'				,p_exito				=> v_exito',
'			);',
'			v_log_dsc := ''v_exito: ''||v_exito;',
'			pk_commons.sp_apex_log(v_log_app,3,v_reporte,v_log_dsc,null,null);',
'',
'			if v_exito = 1 then',
'				data.pk_comp_negociacion.sp_rechazarnegociacion(p_compania => v_compania, p_usuario => v_usuario, p_idneg => v_numero);',
'',
'				if length(v_id_exito_neg) > 0 then',
'					v_id_exito_neg := v_id_exito_neg||'' ,''||v_tipo||''-''||v_numero;',
'				else',
'					v_id_exito_neg := v_tipo||''-''||v_numero;',
'				end if; ',
'			else',
'				if length(v_id_error_neg) > 0 then',
'					v_id_error_neg := v_id_error_neg||'' ,''||v_tipo||''-''||v_numero;',
'				else',
'					v_id_error_neg := v_tipo||''-''||v_numero;',
'				end if;',
'			end if;',
'			v_log_dsc := ''v_id_exito_neg: ''||v_id_exito_neg||'', v_id_error_neg: ''||v_id_error_neg;',
'			pk_commons.sp_apex_log(v_log_app,4,v_reporte,v_log_dsc,null,null);',
'	 	end loop;',
'',
'		--Mensaje de exito',
'		if length(v_id_exito_neg) > 0 then',
unistr('			apex_application.g_print_success_message := ''Negociaciones de Pago Recurrente rechazadas con \00E9xito.'';'),
'		end if;',
'',
'		--Mensaje de error',
'		if length(v_id_error_neg) > 0 then',
'			apex_error.add_error (',
'				p_message				=> ''Error en procesar: ''||v_id_error_neg',
'				, p_display_location	=> apex_error.c_inline_in_notification',
'			);',
'		end if;',
'	end if;',
'	commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'ERROR Rechazo en lote'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(94385080759893615)
,p_process_success_message=>'Rechazo en lote'
,p_internal_uid=>60983053409265005
,p_updated_on=>wwv_flow_imp.dz('20260413173331Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(145804056603570235)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Redirecciona'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'v_usuario varchar2(100);',
'begin',
'	begin',
'		select id_tabla into v_usuario',
'		from data.t_corp_udc',
'		where 1 = 1',
'			and ID_CABECERA = ''COMP_USVIP''',
'			and upper(trim(ID_TABLA)) = :app_user',
'			and activo = ''1''',
'			and rownum = 1;',
'',
'		exception when others then v_usuario := null;',
'	end;',
'',
'	if v_usuario is not null and nvl(:g_referenciamt,0) = 0 then',
'		apex_util.redirect_url(apex_page.get_url(p_page => 113));',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>145804056603570235
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6107471577249078)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga de Datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'v_gestionloteres	number;',
'v_gestionlotecom	number;',
'v_gestionloteliq	number;',
'v_gestionloteneg	number;',
'v_log_app			varchar2(100);',
'v_log_usr			varchar2(100);',
'v_log_dsc			varchar2(500);',
'v_log_msg			varchar2(500);',
'v_log_obs			varchar2(500);',
'v_sesionid           varchar2(100);',
'v_route_id           varchar2(100);',
'v_response           clob;',
'--v_compania_sap           varchar2(5)   :=''00015'';',
'',
'begin',
'	v_log_usr	:= :app_user;',
'	v_log_app	:= ''apex.130.100.cargardatos'';',
'	v_log_dsc	:= ''g_compania: ''||:g_compania||'', app_modulo: ''||:app_modulo||'', v_log_usr: ''||v_log_usr||'', app_page_id: ''||:app_page_id;',
'	pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,v_log_msg,v_log_obs,null);',
'	----------------------------------------------------------------',
'	:p100_aprobador		:= 0;',
'	:p100_usuario		:= v_log_usr;',
'	:p100_navegadortabs	:= :g_navegadortabs;',
'',
'	select dominio||rutamodulo||''/aprobaciones/aprobacionLiquidarSolicitud.xhtml'' ruta into :p100_liq_aprobacion from t_admi_modulo where codigo = ''GLIQ'';',
'',
'	v_gestionlotecom	:= pk_admi_gestionparametros.f_admi_accesoacciones(:app_modulo,v_log_usr,:app_page_id,''GESTION_LOTE'');',
'	v_gestionloteliq	:= pk_admi_gestionparametros.f_admi_accesoacciones(:app_modulo,v_log_usr,:app_page_id,''GESTION_LOTE_LIQ'');',
'	v_gestionloteneg	:= pk_admi_gestionparametros.f_admi_accesoacciones(:app_modulo,v_log_usr,:app_page_id,''GESTION_LOTE_NEG'');',
'',
'	v_gestionloteres	:= v_gestionlotecom + v_gestionloteliq + v_gestionloteneg;',
'',
'	:p100_gestionlotecom	:= v_gestionlotecom;',
'	:p100_gestionloteliq	:= v_gestionloteliq;',
'	:p100_gestionloteneg	:= v_gestionloteneg;',
'	:p100_esgestionlote		:= v_gestionloteres;',
'',
'	if v_gestionloteres > 0 then ',
'		:p100_aprobador := 1;',
'	end if;',
'',
'	v_log_msg	:= ''v_gestionloteres: ''||v_gestionloteres||'', v_gestionlotecom: ''||v_gestionlotecom||'', v_gestionloteliq: ''||v_gestionloteliq||'', v_gestionloteneg: ''||v_gestionloteneg;',
'	pk_commons.sp_apex_log(v_log_app,1,v_log_dsc,v_log_msg,v_log_obs,null);',
'/*',
'    -- me conecto a SAP ',
'    PK_SAP_COMPRAS_WS.SP_LOGIN(v_compania_sap,v_sesionid,v_route_id,v_response);',
'',
unistr('    -- si v_sesionid no es nulo continu\00F3 con el proceso'),
'    IF v_sesionid IS NOT NULL THEN',
'       -- inserto en las tablas de compras del grupo Zaimella todas las compras pendientes de SAP',
'       PK_SAP_COMPRAS_WS.SP_INSERTA_OC_BORRADOR_OPTIMIZADO(v_compania_sap,v_sesionid);',
'',
'       -- me desconecto de SAP',
'',
'       PK_SAP_COMPRAS_WS.SP_LOGOUT(v_sesionid,v_route_id,v_response);',
'    END IF;',
'    */',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>6107471577249078
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(183798226480709129)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Notificaci\00F3n')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_contador  number;',
unistr('v_lc_mrk	varchar2(255)	:= ''Orden de Compra/Liquidaci\00F3n - EC'';'),
'v_cp_mrk	varchar2(255)	:= ''Costo Proveedor'';',
unistr('v_nc_mrk	varchar2(255)	:= ''Notas de Cr\00E9dito'';'),
'v_ng_mrk	varchar2(255)	:= ''Negociaciones'';',
'v_pr_mrk	varchar2(255)	:= ''Pagos Recurrentes'';',
'v_ce_mrk	varchar2(255)	:= ''Grupo Zaimella'';',
'v_icono 	varchar2(999);',
'v_log_app	varchar2(100);',
'v_log_usr	varchar2(100);',
'v_log_dsc	varchar2(500);',
'v_log_msg	varchar2(500);',
'v_log_obs	varchar2(500);',
'begin',
'	v_log_usr	:= :app_user;',
'	v_log_app	:= ''apex.130.100.notificacion'';',
'	v_log_dsc	:= ''g_compania: ''||:g_compania||'', app_modulo: ''||:app_modulo||'', v_log_usr: ''||v_log_usr||'', app_page_id: ''||:app_page_id;',
'	pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,v_log_msg,v_log_obs,null);',
'	----------------------------------------------------------------',
unistr('	-- T\00EDtulo de las regiones'),
'	:p100_lc_mrk := v_lc_mrk;',
'	:p100_cp_mrk := v_cp_mrk;',
'	:p100_nc_mrk := v_nc_mrk;',
'	:p100_ng_mrk := v_ng_mrk;',
'	:p100_pr_mrk := v_pr_mrk;',
'	:p100_ce_mrk := v_ce_mrk;',
'',
'	v_icono := '' <span style="color:red; font-size:small" class="fa fa-dot-circle-o"></span>'';',
'',
unistr('	v_log_obs := ''Pendientes: OCs/Liq/Vi\00E1ticos'';'),
'	with mo as (',
'		select count(1) contador',
'		from vt_comp_mesatrabajo mesa',
'		where compania = :g_compania',
'		and (aprobador is not null and pk_corp_flujoaprobacion.f_aprobadorflujo(:app_user,aprobador,:g_modulo,:g_compania) = 1)',
'		and (unidadnegocio = ''RUTA CONFIDENCIAL             '' and pk_admi_gestionparametros.f_admi_accesoacciones(:g_modulo,:app_user,:app_page_id,''CONFIDENCIAL'') = 1 or unidadnegocio != ''RUTA CONFIDENCIAL             '')',
'	), ml as (',
'		select count(1) contador',
'		from vt_gliq_mesatrabajo mesa',
'		where compania = :g_compania',
'		and (aprobador is not null and pk_corp_flujoaprobacion.f_aprobadorflujo(:app_user,aprobador,:g_modulo,:g_compania) = 1)',
'	), pr as (',
'		select count(1) contador',
'		from vt_comp_mesatrabajopgr p',
'		where 1 = 1',
'			and (aprobador is not null and pk_corp_flujoaprobacion.f_aprobadorflujo(:app_user,aprobador,:app_modulo,:g_compania) = 1)',
'			and (unidadnegocio != ''CONFIDENCIAL'' or pk_admi_gestionparametros.f_admi_accesoacciones(:app_modulo,:app_user,:app_page_id,''CONFIDENCIAL'') = 1)',
'	), lstor as (select sum(contador) contador from mo',
'	), lstli as (select sum(contador) contador from ml',
'	), lstpr as (select sum(contador) contador from pr)',
'	select sum(contador) into v_contador',
'	from (select contador from lstor oc union all select contador from lstli lq union all select contador from lstpr pr) res;',
'',
'	v_lc_mrk :=v_lc_mrk ||case v_contador when 0 then '''' else v_icono end;',
'',
'	:p100_lc_mrk := v_lc_mrk;',
'	pk_commons.sp_apex_log(v_log_app,1,v_log_dsc,v_log_msg,v_log_obs,null);',
'',
unistr('	v_log_obs := ''Pendientes: Notas de Cr\00E9dito'';'),
'	select  count(1) into v_contador',
'	from (',
'		select *',
'		from vt_back_mesatrabajo mesa',
'		where compania = :g_compania',
'			and (aprobador is not null and estado = ''EN_PROCESO'' and pk_corp_flujoaprobacion.f_aprobadorflujo(:app_user,aprobador,''BACK'',:g_compania) = 1)',
'	) mesafinal;',
'',
'	v_nc_mrk :=v_nc_mrk  ||case v_contador when 0 then '''' else v_icono end;',
'',
'	:p100_nc_mrk := v_nc_mrk;',
'	pk_commons.sp_apex_log(v_log_app,2,v_log_dsc,v_log_msg,v_log_obs,null);',
'',
'	v_log_obs := ''Pendientes: Negociaciones'';',
'	select',
'	count(1) into v_contador',
'	from data.vt_comp_mesatrabajoneg',
'	where 1 = 1',
'		and nvl(recurrente,''NO'') = ''NO''',
'		and (aprobador is not null and  pk_corp_flujoaprobacion.f_aprobadorflujo(:app_user,aprobador,:g_modulo,:g_compania) = 1)',
'		and estadoflujo in (''EN RUTA'',''VIGENTE'',''APROBADO'',''CADUCADO'',''CANCELADO'');',
'',
'	v_ng_mrk := v_ng_mrk||case v_contador when 0 then '''' else v_icono end;',
'',
'	:p100_ng_mrk := v_ng_mrk;',
'	pk_commons.sp_apex_log(v_log_app,3,v_log_dsc,v_log_msg,v_log_obs,null);',
'',
'	v_log_obs := ''Pendientes: Pagos Recurrentes'';',
'	select',
'	count(1) into v_contador',
'	from data.vt_comp_mesatrabajoneg',
'	where 1 = 1',
'		and nvl(recurrente,''NO'') = ''SI''',
'		and (aprobador is not null and pk_corp_flujoaprobacion.f_aprobadorflujo(:app_user,aprobador,:g_modulo,:g_compania) = 1)',
'		and estadoflujo in (''EN RUTA'',''VIGENTE'',''APROBADO'',''CADUCADO'',''CANCELADO'');',
'',
'	v_pr_mrk := v_pr_mrk||case v_contador when 0 then '''' else v_icono end;',
'',
'	:p100_pr_mrk := v_pr_mrk;',
'	pk_commons.sp_apex_log(v_log_app,4,v_log_dsc,v_log_msg,v_log_obs,null);',
'',
'	v_log_obs := ''Pendientes: Compras Grupo Zaimella'';',
'	select',
'	count(1) into v_contador',
'	from data.vt_comp_ordencompraext',
'	where 1 = 1',
'		and (usuarioactual is not null and pk_corp_flujoaprobacion.f_aprobadorflujo(:app_user,usuarioactual,''COMP'',:g_compania) = 1)',
'		and estado in (''EN RUTA'');',
'',
'	v_ce_mrk := v_ce_mrk||case v_contador when 0 then '''' else v_icono end;',
'',
'	:p100_ce_mrk := v_ce_mrk;',
'	pk_commons.sp_apex_log(v_log_app,5,v_log_dsc,v_log_msg,v_log_obs,null);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>183798226480709129
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6108571966249089)
,p_process_sequence=>40
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Borrar Datos'
,p_attribute_01=>'CLEAR_CACHE_FOR_ITEMS'
,p_attribute_03=>'P100_APROBAR,P100_COMENTARIO'
,p_internal_uid=>6108571966249089
);
wwv_flow_imp.component_end;
end;
/
