prompt --application/pages/page_00200
begin
--   Manifest
--     PAGE: 00200
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>200
,p_name=>'GOC - Mesa de Trabajo'
,p_alias=>'MESA-DE-TRABAJO-OCS'
,p_step_title=>'GOC - Mesa de Trabajo'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-table td {',
'    padding: 0px;',
'    padding-right: 2px;',
'    padding-left: 2px;    ',
'}',
'',
'.a-IRR-toolbar{',
'    background: transparent;',
'}',
'',
'.selectNeg div{',
'    background: bisque;',
'}',
'',
'.generaOC div{',
'    background: darkseagreen;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20241018210559Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260409210640Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(117085618157036739)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(117086036462036743)
,p_plug_name=>'FIltros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(117086459319036747)
,p_plug_name=>'Ordenes de Compra'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH',
'	W_GESTION AS (',
'		SELECT',
'			COMPANIA,',
'			USUARIO,',
'			DOCUMENTOTIPO_OC,',
'			DOCUMENTO_OC,',
'			MODULOEXTERNO,',
'			COUNT(1)				AS LINEAS,',
'			MAX(FECHA_PROCESADO)	AS FECHA_PROCESADO,',
'			MAX(RESERVA)			AS RESERVA,',
'			MAX(FECHA_REACTIVA_RESERVA) AS FECHA_REACTIVA_RESERVA',
'		FROM',
'			T_COMP_PRODTO_PROVEEDR_GESTION',
'		GROUP BY COMPANIA, USUARIO, MODULOEXTERNO, DOCUMENTOTIPO_OC, DOCUMENTO_OC',
') SELECT F4301.DOCUMENTOTIPO 	AS DOCUMENTOTIPO,',
'	F4301.DOCUMENTO				AS DOCUMENTO,',
'	F4301.UNIDADNEGOCIO_DES,',
'	F4301.CODIGOPROVEEDOR,',
'	F4301.CODIGOPROVEEDOR||'' - ''||F4301.PROVEEDOR AS PROVEEDOR,',
'	F4301.CODIGOCOMPRADOR,',
'	F4301.FECHA,',
'	CASE ',
'		WHEN GESTION.RESERVA = 1 AND GESTION.FECHA_REACTIVA_RESERVA IS NULL THEN NULL',
'		ELSE F4301.VALOR END AS VALOR,',
'	GESTION.COMPANIA      AS COMPANIA,',
'	GESTION.USUARIO       AS USUARIO,',
'	GESTION.MODULOEXTERNO AS MODULOEXTERNO,',
'	GESTION.FECHA_PROCESADO,',
'	GESTION.RESERVA       AS RESERVA,',
'	CASE',
'		WHEN GESTION.RESERVA = 1 AND FECHA_REACTIVA_RESERVA IS NULL THEN ''<span title="Compra RESERVA" class="fa fa-check-square" style="color: red;font-weight: bolder;"/>''',
'		WHEN GESTION.RESERVA = 1 AND FECHA_REACTIVA_RESERVA IS NOT NULL THEN ''<span title="Compra RESERVA" class="fa fa-check-square" style="color: green;font-weight: bolder;"/>''',
'		ELSE '' ''',
'	END AS ICONO_RESERVAR,',
'',
'	pk_apex_archivos.f_cantidadarchivos(',
'		p_tabla 		=> ''T_COMP_ORDENES'',',
'		p_idtabla		=> F4301.DOCUMENTO,',
'		p_tipo 			=> F4301.DOCUMENTOTIPO) AS CANTIDAD_ADJUNTOS,',
'	CASE',
'		WHEN',
'			EXTRACT(DAY FROM (SYSDATE - FECHA_PROCESADO))*24*60+EXTRACT(HOUR FROM (SYSDATE - FECHA_PROCESADO))*60+EXTRACT(MINUTE FROM (SYSDATE - FECHA_PROCESADO)) <=4 THEN ''color: red;font-weight: bolder;''',
'		ELSE '''' END AS ESTILO_RECIENTE,',
'	''<span class="fa fa-paperclip" aria-hidden="true"></span>'' AS adjunto,',
'	(SELECT MAX(ESTADO_ANT||''-''||ESTADO_SIG) FROM VT_COMP_F4311 WHERE documentotipo = F4301.DOCUMENTOTIPO AND documento = F4301.DOCUMENTO) ESTADO,',
unistr('	case when data.pk_comp_gestioncompras.f_tieneanticipo(GESTION.COMPANIA,F4301.DOCUMENTOTIPO,F4301.DOCUMENTO) > 0 then ''S\00CD'' else null end anticipo'),
'FROM ',
'	VT_COMP_F4301 F4301 LEFT JOIN W_GESTION GESTION',
'	ON F4301.DOCUMENTOTIPO = GESTION.DOCUMENTOTIPO_OC AND F4301.DOCUMENTO = GESTION.DOCUMENTO_OC',
'WHERE 1 = 1',
'	and data.pk_comp_gestioncompras.f_gestionporun(:g_compania,f4301.bodegacodigo,:app_user) = 1',
'	and (:P200_TIPO_OC IS NULL OR F4301.DOCUMENTOTIPO = :P200_TIPO_OC)',
'	and F4301.FECHA BETWEEN :P200_DESDE AND :P200_HASTA'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Ordenes de compra'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20250917151659Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(117086580456036748)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>117086580456036748
,p_updated_on=>wwv_flow_imp.dz('20250917151659Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(117086637241036749)
,p_db_column_name=>'DOCUMENTOTIPO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'TOC'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(117086747716036750)
,p_db_column_name=>'DOCUMENTO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Orden Compra'
,p_column_link=>'f?p=&APP_ID.:206:&SESSION.::&DEBUG.::P206_DOCUMENTOTIPO_OC,P206_DOCUMENTO_OC:#DOCUMENTOTIPO#,#DOCUMENTO#'
,p_column_linktext=>'#DOCUMENTO#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119158489254955301)
,p_db_column_name=>'UNIDADNEGOCIO_DES'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Unidad Negocio'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119158523120955302)
,p_db_column_name=>'CODIGOPROVEEDOR'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'CODPROVEEDOR'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119158702798955304)
,p_db_column_name=>'CODIGOCOMPRADOR'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'CODCOMPRADOR'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119158817981955305)
,p_db_column_name=>'FECHA'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(171544188886797801)
,p_db_column_name=>'VALOR'
,p_display_order=>80
,p_column_identifier=>'R'
,p_column_label=>'Valor'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119158920005955306)
,p_db_column_name=>'COMPANIA'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119159025664955307)
,p_db_column_name=>'USUARIO'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Usuario'
,p_column_html_expression=>'<span style="#ESTILO_RECIENTE#">#USUARIO#</span>'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(190517001019868250)
,p_db_column_name=>'FECHA_PROCESADO'
,p_display_order=>110
,p_column_identifier=>'S'
,p_column_label=>'Generada'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy hh24:mi'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250625165255Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119159177204955308)
,p_db_column_name=>'MODULOEXTERNO'
,p_display_order=>120
,p_column_identifier=>'J'
,p_column_label=>'MEXT'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119159367613955310)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>130
,p_column_identifier=>'L'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120781033803806002)
,p_db_column_name=>'CANTIDAD_ADJUNTOS'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Cantidad Adjuntos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(120780977868806001)
,p_db_column_name=>'ADJUNTO'
,p_display_order=>150
,p_column_identifier=>'M'
,p_column_label=>'-'
,p_column_link=>'f?p=100:401:&SESSION.::&DEBUG.::P401_TIPO,P401_ID,P401_TABLA,P401_ESTADO:#DOCUMENTOTIPO#,#DOCUMENTO#,T_COMP_ORDENES,0'
,p_column_linktext=>'#ADJUNTO#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250625165344Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(163556370465845807)
,p_db_column_name=>'RESERVA'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Reserva'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(163556466216845808)
,p_db_column_name=>'ICONO_RESERVAR'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Rsrv.'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(191806408054883401)
,p_db_column_name=>'ESTILO_RECIENTE'
,p_display_order=>180
,p_column_identifier=>'T'
,p_column_label=>'Estilo Reciente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(292856240478051548)
,p_db_column_name=>'ESTADO'
,p_display_order=>190
,p_column_identifier=>'U'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(97153501416731620)
,p_db_column_name=>'ANTICIPO'
,p_display_order=>200
,p_column_identifier=>'V'
,p_column_label=>'Anticipo'
,p_allow_sorting=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250709202043Z')
,p_updated_on=>wwv_flow_imp.dz('20250717211447Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(119166943103955887)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1191670'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOCUMENTOTIPO:DOCUMENTO:UNIDADNEGOCIO_DES:PROVEEDOR:VALOR:USUARIO:FECHA_PROCESADO:MODULOEXTERNO:ADJUNTO:ICONO_RESERVAR:ANTICIPO:'
,p_sort_column_1=>'FECHA_PROCESADO'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'DOCUMENTOTIPO'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'DOCUMENTO'
,p_sort_direction_3=>'DESC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20241018210559Z')
,p_updated_on=>wwv_flow_imp.dz('20250709202520Z')
,p_created_by=>'ATOPON'
,p_updated_by=>'KMORAN'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(119134189729871902)
,p_plug_name=>'Mesa de Trabajo OCs &G_NAVEGACION_AGRUPADO.'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296122226350169167)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(200198852444652339)
,p_plug_name=>unistr('Navegaci\00F3n Modo Agrupado')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_column_width=>'style="display: none;"'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(119159595817955312)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(117085618157036739)
,p_button_name=>'NUEVA_OC'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Nueva OC'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(117085714606036740)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(117085618157036739)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Buscar'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(200199045057652341)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(200198852444652339)
,p_button_name=>'SALTO_NAVEGACION_AGRUPADO'
,p_button_static_id=>'SALTO_NAVEGACION_AGRUPADO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Salto Navegacion Agrupado'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:211:&SESSION.::&DEBUG.:211:P211_GOC_TIPO_REQUISICION,P211_GOC_CODBODEGA,P211_GOC_DET_CODPROVEEDOR,P211_GOC_RESERVA,P211_MONTO,P211_FECHA_COMPROMISO,P211_MODO_AGRUPADO,P211_CANTIDAD:&P200_GRP_TIPO_REQUISICION.,&P200_GRP_CODBODEGA.,&P200_GRP_DET_CODPROVEEDOR.,&P200_GRP_RESERVA.,&P200_GRP_MONTO.,&P200_GRP_FECHA_COMPROMISO.,&P200_GRP_MODO_AGRUPADO.,&P200_GRP_CANTIDAD.'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(117086199916036744)
,p_name=>'P200_DESDE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(117086036462036743)
,p_prompt=>'Desde'
,p_source=>'SELECT SYSDATE-7 FROM DUAL;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(117086257718036745)
,p_name=>'P200_HASTA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(117086036462036743)
,p_prompt=>'Hasta'
,p_source=>'SELECT SYSDATE FROM DUAL;'
,p_source_type=>'QUERY_COLON'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(117086389291036746)
,p_name=>'P200_TIPO_OC'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(117086036462036743)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    TRIM(DRKY)||'' ''||TRIM(DRDL01) AS LABEL,',
'    TRIM(DRKY)   AS VALUE',
'FROM vt_jde_udcjde where DRSY=''00'' AND DRRT =''DT'' AND DRKY IN(''CN'',''CM'',''BN'',''BM'',''CT'',''CE'')',
'ORDER BY DRKY;'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200199181211652342)
,p_name=>'P200_GRP_TIPO_REQUISICION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(200198852444652339)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200199266981652343)
,p_name=>'P200_GRP_CODBODEGA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(200198852444652339)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200199360589652344)
,p_name=>'P200_GRP_DET_CODPROVEEDOR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(200198852444652339)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200199473364652345)
,p_name=>'P200_GRP_RESERVA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(200198852444652339)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200199572018652346)
,p_name=>'P200_GRP_MONTO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(200198852444652339)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200199672490652347)
,p_name=>'P200_GRP_FECHA_COMPROMISO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(200198852444652339)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200199710353652348)
,p_name=>'P200_GRP_MODO_AGRUPADO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(200198852444652339)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(200199888170652349)
,p_name=>'P200_GRP_CANTIDAD'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(200198852444652339)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(200198606300652337)
,p_name=>'MODO_AGRUPADO_NAVEGACION'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>':P200_GRP_MODO_AGRUPADO IS NOT NULL AND :G_NAVEGACION_AGRUPADO=1'
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(200198734831652338)
,p_event_id=>wwv_flow_imp.id(200198606300652337)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'document.getElementById(''SALTO_NAVEGACION_AGRUPADO'').click();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(200198915299652340)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Navegacion Modo Agrupado'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P200_GRP_MODO_AGRUPADO := NULL;',
'BEGIN    ',
'    SELECT ',
'        MIN(MODO_AGRUPADO)',
'    INTO ',
'        :P200_GRP_MODO_AGRUPADO',
'    FROM ',
'        VT_COMP_PENDIENTE_GENERAR_OC',
'    WHERE',
'        COMPANIA      = :G_COMPANIA    ',
'            AND',
'        USUARIO       = :APP_USER',
'            AND',
'        CODPROVEEDOR IS NOT NULL',
'            AND',
'        FECHA_PROCESADO IS NULL        ',
'            AND',
'        MODO_AGRUPADO IS NOT NULL',
'    ;',
'    SELECT ',
'        MAX(TIPO_REQUISICION),',
'        MAX(TRIM(CODBODEGA)),',
'        MAX(CODPROVEEDOR),',
'        MAX(RESERVA),',
'        TO_CHAR(',
'            ROUND(SUM(NVL(PRECIOTOTAL,0)),4)  ',
'            , ''9999999990.00''',
'         )AS MONTO,',
'        MAX(FECHA_COMPROMISO),',
'        SUM(NVL(CANTIDAD_MANUAL, CANTIDAD)) AS CANTIDAD',
'    INTO',
'        :P200_GRP_TIPO_REQUISICION,',
'        :P200_GRP_CODBODEGA,',
'        :P200_GRP_DET_CODPROVEEDOR,',
'        :P200_GRP_RESERVA,',
'        :P200_GRP_MONTO,',
'        :P200_GRP_FECHA_COMPROMISO,',
'        :P200_GRP_CANTIDAD',
'    FROM ',
'        VT_COMP_PENDIENTE_GENERAR_OC',
'    WHERE',
'        CODPROVEEDOR IS NOT NULL',
'            AND',
'        MODO_AGRUPADO=:P200_GRP_MODO_AGRUPADO',
'            AND',
'        FECHA_PROCESADO IS NULL        ',
'    GROUP BY ',
'        MODO_AGRUPADO;',
'EXCEPTION WHEN OTHERS THEN',
'    :P200_GRP_MODO_AGRUPADO := NULL;',
'    :G_NAVEGACION_AGRUPADO  := 0;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>200198915299652340
);
wwv_flow_imp.component_end;
end;
/
