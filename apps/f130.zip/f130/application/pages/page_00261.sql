prompt --application/pages/page_00261
begin
--   Manifest
--     PAGE: 00261
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>261
,p_name=>unistr('Proveedor - Configuraci\00F3n')
,p_alias=>unistr('PROVEEDOR-CONFIGURACI\00D3N')
,p_page_mode=>'NON_MODAL'
,p_step_title=>unistr('Proveedor - Configuraci\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(regOculta).hide();'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_created_on=>wwv_flow_imp.dz('20250417160141Z')
,p_last_updated_on=>wwv_flow_imp.dz('20250529205527Z')
,p_created_by=>'DDELACRUZ'
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(675435931547489605)
,p_plug_name=>'Oculta'
,p_region_name=>'regOculta'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250417160325Z')
,p_updated_on=>wwv_flow_imp.dz('20250417180502Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(677635588124886694)
,p_plug_name=>unistr('Proveedor - Configuraci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>30
,p_query_type=>'TABLE'
,p_query_table=>'T_COMP_PROVEEDORCTG'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_created_on=>wwv_flow_imp.dz('20250417160141Z')
,p_updated_on=>wwv_flow_imp.dz('20250417180502Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(683719311040683402)
,p_plug_name=>'Barra de Acciones'
,p_region_name=>'regBarraAcciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250417180426Z')
,p_updated_on=>wwv_flow_imp.dz('20250417180502Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(677642224135886706)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(683719311040683402)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Cerrar'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:213:&APP_SESSION.::&DEBUG.:::'
,p_button_condition_type=>'NEVER'
,p_created_on=>wwv_flow_imp.dz('20250417160141Z')
,p_updated_on=>wwv_flow_imp.dz('20250417180619Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(677642823014886707)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(683719311040683402)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Delete'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition_type=>'NEVER'
,p_database_action=>'DELETE'
,p_created_on=>wwv_flow_imp.dz('20250417160141Z')
,p_updated_on=>wwv_flow_imp.dz('20250417180543Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(677643160888886708)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(683719311040683402)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar Cambios'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P261_COMPANIA'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'UPDATE'
,p_created_on=>wwv_flow_imp.dz('20250417160142Z')
,p_updated_on=>wwv_flow_imp.dz('20250417180619Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(677643504695886708)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(683719311040683402)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'RIGHT'
,p_button_condition_type=>'NEVER'
,p_database_action=>'INSERT'
,p_created_on=>wwv_flow_imp.dz('20250417160142Z')
,p_updated_on=>wwv_flow_imp.dz('20250417180543Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(677643858359886708)
,p_branch_action=>'f?p=&APP_ID.:213:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
,p_created_on=>wwv_flow_imp.dz('20250417160142Z')
,p_updated_on=>wwv_flow_imp.dz('20250417160142Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(675436024869489606)
,p_name=>'P261_CONTRATO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(677635588124886694)
,p_item_source_plug_id=>wwv_flow_imp.id(677635588124886694)
,p_prompt=>'Contrato'
,p_source=>'CONTRATO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'S'
,p_attribute_03=>unistr('S\00CD')
,p_attribute_04=>'N'
,p_attribute_05=>'NO'
,p_created_on=>wwv_flow_imp.dz('20250417164414Z')
,p_updated_on=>wwv_flow_imp.dz('20250417180759Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(675436118028489607)
,p_name=>'P261_TIPOCANTOCS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(677635588124886694)
,p_item_source_plug_id=>wwv_flow_imp.id(677635588124886694)
,p_prompt=>'Tipo Cant. Gen. OCs'
,p_source=>'TIPOCANTOCS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_PRV_TIPOCANTOCS'
,p_lov=>'select id_tabla, descripcion from data.t_corp_udc  where id_cabecera = ''COMP_PRV04'' and activo = ''1'' order by id_tabla'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20250417171046Z')
,p_updated_on=>wwv_flow_imp.dz('20250417180759Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(675436226470489608)
,p_name=>'P261_VALORPRDCOMPRA'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(677635588124886694)
,p_item_source_plug_id=>wwv_flow_imp.id(677635588124886694)
,p_prompt=>'Valor'
,p_source=>'VALORPRDCOMPRA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'0'
,p_attribute_03=>'right'
,p_attribute_04=>'numeric'
,p_created_on=>wwv_flow_imp.dz('20250417171205Z')
,p_updated_on=>wwv_flow_imp.dz('20250417180759Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(675436632987489612)
,p_name=>'P261_TMP_DESDE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(675435931547489605)
,p_prompt=>'TMP Desde'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250417173331Z')
,p_updated_on=>wwv_flow_imp.dz('20250417173331Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(675436752746489613)
,p_name=>'P261_TMP_HASTA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(675435931547489605)
,p_prompt=>'TMP Hasta'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250417173332Z')
,p_updated_on=>wwv_flow_imp.dz('20250417173344Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(675437666595489622)
,p_name=>'P261_PROVEEDOR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(677635588124886694)
,p_prompt=>'Proveedor'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_JDE_LIBRODIRECCIONESCODIGO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    codigo',
'    || '' - ''',
'    || nombres AS d,',
'    codigo     AS r',
'FROM',
'    (',
'        SELECT',
'            codigo,',
'            nombres',
'        FROM',
'            vt_jde_librodirecciones',
'        GROUP BY',
'            codigo,',
'            nombres',
'    ) a',
'ORDER BY',
'    nombres'))
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'N'
,p_attribute_02=>'LOV'
,p_attribute_04=>'N'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20250417180759Z')
,p_updated_on=>wwv_flow_imp.dz('20250417181045Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(677635971479886694)
,p_name=>'P261_COMPANIA'
,p_source_data_type=>'VARCHAR2'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(675435931547489605)
,p_item_source_plug_id=>wwv_flow_imp.id(677635588124886694)
,p_source=>'COMPANIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250417160141Z')
,p_updated_on=>wwv_flow_imp.dz('20250417160438Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(677636382630886699)
,p_name=>'P261_CODPROVEEDOR'
,p_source_data_type=>'VARCHAR2'
,p_is_primary_key=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(675435931547489605)
,p_item_source_plug_id=>wwv_flow_imp.id(677635588124886694)
,p_source=>'CODPROVEEDOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250417160141Z')
,p_updated_on=>wwv_flow_imp.dz('20250417160439Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(677636756030886700)
,p_name=>'P261_HABILITADO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(677635588124886694)
,p_item_source_plug_id=>wwv_flow_imp.id(677635588124886694)
,p_prompt=>'Habilitado'
,p_source=>'HABILITADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'S'
,p_attribute_03=>unistr('S\00CD')
,p_attribute_04=>'N'
,p_attribute_05=>'NO'
,p_created_on=>wwv_flow_imp.dz('20250417160141Z')
,p_updated_on=>wwv_flow_imp.dz('20250417180759Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(677637124186886703)
,p_name=>'P261_EVALUACION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(677635588124886694)
,p_item_source_plug_id=>wwv_flow_imp.id(677635588124886694)
,p_prompt=>unistr('Evaluaci\00F3n')
,p_source=>'EVALUACION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'S'
,p_attribute_03=>unistr('S\00CD')
,p_attribute_04=>'N'
,p_attribute_05=>'NO'
,p_created_on=>wwv_flow_imp.dz('20250417160141Z')
,p_updated_on=>wwv_flow_imp.dz('20250417180759Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(677637542870886703)
,p_name=>'P261_PERIODOCOMPRA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(677635588124886694)
,p_item_source_plug_id=>wwv_flow_imp.id(677635588124886694)
,p_prompt=>'Perd. de Compra'
,p_source=>'PERIODOCOMPRA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_PRV_PERIODOCOMPRA'
,p_lov=>'select id_tabla, descripcion from data.t_corp_udc  where id_cabecera = ''COMP_PRV01'' and activo = ''1'' order by id_tabla'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20250417160141Z')
,p_updated_on=>wwv_flow_imp.dz('20250417180759Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(677637923135886703)
,p_name=>'P261_NIVELCOMPRA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(677635588124886694)
,p_item_source_plug_id=>wwv_flow_imp.id(677635588124886694)
,p_prompt=>'Nivel Compra'
,p_source=>'NIVELCOMPRA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_PRV_NIVELCOMPRA'
,p_lov=>'select id_tabla, descripcion from data.t_corp_udc  where id_cabecera = ''COMP_PRV02'' and activo = ''1'' order by id_tabla'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20250417160141Z')
,p_updated_on=>wwv_flow_imp.dz('20250417180759Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(677638332794886703)
,p_name=>'P261_CTGRAZONSOCIAL'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(677635588124886694)
,p_item_source_plug_id=>wwv_flow_imp.id(677635588124886694)
,p_prompt=>unistr('Cat. Raz\00F3n Social')
,p_source=>'CTGRAZONSOCIAL'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_PRV_CTGRAZONSOCIAL'
,p_lov=>'select id_tabla, descripcion from data.t_corp_udc  where id_cabecera = ''COMP_PRV03'' and activo = ''1'' order by descripcion'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20250417160141Z')
,p_updated_on=>wwv_flow_imp.dz('20250417180759Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(677638766253886703)
,p_name=>'P261_COMPRADESDE'
,p_source_data_type=>'DATE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(677635588124886694)
,p_item_source_plug_id=>wwv_flow_imp.id(677635588124886694)
,p_prompt=>'Aut. Desde'
,p_source=>'COMPRADESDE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250417160141Z')
,p_updated_on=>wwv_flow_imp.dz('20250417180759Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(677639133524886704)
,p_name=>'P261_COMPRAHASTA'
,p_source_data_type=>'DATE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(677635588124886694)
,p_item_source_plug_id=>wwv_flow_imp.id(677635588124886694)
,p_prompt=>'Aut. Hasta'
,p_source=>'COMPRAHASTA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250417160141Z')
,p_updated_on=>wwv_flow_imp.dz('20250417180759Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(675436320916489609)
,p_name=>'Tipo Seleccionado'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P261_TIPOCANTOCS'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'$v("P261_TIPOCANTOCS") == ''001'' || $v("P261_TIPOCANTOCS") == ''002'' || $v("P261_TIPOCANTOCS") == ''003'''
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20250417172543Z')
,p_updated_on=>wwv_flow_imp.dz('20250417174400Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(675436460236489610)
,p_event_id=>wwv_flow_imp.id(675436320916489609)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P261_VALORPRDCOMPRA'
,p_created_on=>wwv_flow_imp.dz('20250417172543Z')
,p_updated_on=>wwv_flow_imp.dz('20250417172543Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(675436500909489611)
,p_event_id=>wwv_flow_imp.id(675436320916489609)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P261_VALORPRDCOMPRA'
,p_created_on=>wwv_flow_imp.dz('20250417172543Z')
,p_updated_on=>wwv_flow_imp.dz('20250417172543Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(675437135142489617)
,p_name=>'Tipo NO Seleccionado'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P261_TIPOCANTOCS'
,p_condition_element=>'P261_TIPOCANTOCS'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20250417174400Z')
,p_updated_on=>wwv_flow_imp.dz('20250417175526Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(675437275093489618)
,p_event_id=>wwv_flow_imp.id(675437135142489617)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P261_COMPRADESDE,P261_COMPRAHASTA'
,p_created_on=>wwv_flow_imp.dz('20250417174400Z')
,p_updated_on=>wwv_flow_imp.dz('20250417175526Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(675437524252489621)
,p_event_id=>wwv_flow_imp.id(675437135142489617)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P261_COMPRADESDE,P261_COMPRAHASTA'
,p_created_on=>wwv_flow_imp.dz('20250417175526Z')
,p_updated_on=>wwv_flow_imp.dz('20250417175526Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(675436821654489614)
,p_name=>'Set Desde'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P261_VALORPRDCOMPRA'
,p_condition_element=>'P261_VALORPRDCOMPRA'
,p_triggering_condition_type=>'GREATER_THAN'
,p_triggering_expression=>'0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20250417173644Z')
,p_updated_on=>wwv_flow_imp.dz('20250417180056Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(675436977747489615)
,p_event_id=>wwv_flow_imp.id(675436821654489614)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_valor number;',
'v_desde date;',
'v_hasta date;',
'begin',
'	v_valor := to_number(:p261_valorprdcompra);',
'	v_desde := sysdate;',
'	if :p261_tipocantocs = ''001'' then',
'		v_hasta := v_desde + v_valor;',
'	elsif :p261_tipocantocs = ''002'' then',
'		v_hasta := add_months(v_desde,v_valor);',
'	else',
'		v_hasta := null;',
'	end if;',
'	v_desde := :p261_compradesde;',
'	v_hasta := :p261_comprahasta;',
'end;'))
,p_attribute_02=>'P261_COMPRADESDE,P261_VALORPRDCOMPRA,P261_TIPOCANTOCS'
,p_attribute_03=>'P261_COMPRADESDE,P261_COMPRAHASTA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250417173644Z')
,p_updated_on=>wwv_flow_imp.dz('20250417180056Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(675437706911489623)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetUp'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_codproveedor	varchar2(25);',
'v_proveedor varchar2(25);',
'begin',
'	v_codproveedor := :p261_codproveedor;',
'	begin',
'		v_proveedor := v_codproveedor;',
'	end;',
'',
'	begin',
'		v_proveedor := v_codproveedor;',
'		:p261_proveedor := v_proveedor;',
'	end;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>675437706911489623
,p_created_on=>wwv_flow_imp.dz('20250417180947Z')
,p_updated_on=>wwv_flow_imp.dz('20250417181238Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(677644779548886710)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(677635588124886694)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('Process form Proveedor - Configuraci\00F3n')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>677644779548886710
,p_created_on=>wwv_flow_imp.dz('20250417160142Z')
,p_updated_on=>wwv_flow_imp.dz('20250417160142Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(683903537819132229)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Actualizaci\00F3n')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_proveedor varchar2(50);',
'v_compania varchar2(5);',
'begin',
'	v_compania := :p261_compania;',
'	v_proveedor := :p261_codproveedor;',
'	if v_compania = ''00001'' then',
'		update f0401@jdedtadl set a6ato = decode(:p261_habilitado,''S'',''Y'',''N'') where a6an8 = to_number(v_proveedor);',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>683903537819132229
,p_created_on=>wwv_flow_imp.dz('20250529205527Z')
,p_updated_on=>wwv_flow_imp.dz('20250529205527Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(677644329830886710)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(677635588124886694)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form Proveedor - Configuraci\00F3n')
,p_internal_uid=>677644329830886710
,p_created_on=>wwv_flow_imp.dz('20250417160142Z')
,p_updated_on=>wwv_flow_imp.dz('20250417160142Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
