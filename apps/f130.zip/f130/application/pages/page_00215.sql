prompt --application/pages/page_00215
begin
--   Manifest
--     PAGE: 00215
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>215
,p_name=>'Detalle del Pago'
,p_alias=>'DETALLE-DEL-PAGO'
,p_step_title=>'Detalle del Pago'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(regItems).hide();'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-button.a-IRR-sortWidget-button[data-option="hide"], .a-IRR-button.a-IRR-sortWidget-button[data-option="freeze"]{',
'    display:none;',
'}',
'.a-IG-controls-item--aggregate, .a-IG-controls-item--controlBreak, .a-IG-controls-item--groupBy, .a-IG-reportSummary-item--aggregate, .a-IG-reportSummary-item--controlBreak, .a-IG-reportSummary-item--groupBy, .a-IRR-controls-item--aggregate, .a-IRR-c'
||'ontrols-item--controlBreak, .a-IRR-controls-item--groupBy, .a-IRR-reportSummary-item--aggregate, .a-IRR-reportSummary-item--controlBreak, .a-IRR-reportSummary-item--groupBy {',
'    --a-report-controls-cell-label-icon-background-color: #3b83bd;',
'    --a-report-controls-cell-label-hover-background-color: #e6f0f7;',
'    display: none;',
'}',
'.a-IRR-chartView, .a-IRR-controlsContainer, .a-IRR-detailView, .a-IRR-groupByView, .a-IRR-iconViewTable, .a-IRR-pivotView {',
'    border-top-color: #E6E6E6;',
'    display: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240226220107Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260429203449Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(70578155801986404)
,p_plug_name=>'Detalle Factura'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>50
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select txt03 codproductoprv',
'	, txt04 desproductoprv',
'	, txt06 umproductoprv',
'	, txt07 codproducto',
'	, txt08 descproducto',
'	, txt09 enlace',
'	, num03 cantidad',
'	, num04 precio',
'	, num05 total',
'	, num06 codcortoproducto',
'	, num07 negiddet',
'	, num08 precioneg',
'	, num09 coincodproducto',
'	, num12 validamonto',
'	, ''<-@->'' separador',
'from data.t_apex_temporal',
'where control01 = :g_compania',
'	and control02 = :app_modulo',
'	and control03 = ''pk_comp_negociacion.sp_buscarfacturas''',
'	and control04 = to_char(to_number(:p215_idnegociacion))',
'	and txt01 = :p215_claveacceso'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P215_IDNEGOCIACION,P215_CLAVEACCESO'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'(:p215_claveacceso is not null and :p215_estado = ''ACTIVO'') or :p215_origenproveedor = ''PE'''
,p_plug_display_when_cond2=>'PLSQL'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Detalle Factura'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_created_on=>wwv_flow_imp.dz('20240305045717Z')
,p_updated_on=>wwv_flow_imp.dz('20250421204623Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(70578283598986405)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>70578283598986405
,p_created_on=>wwv_flow_imp.dz('20240305045717Z')
,p_updated_on=>wwv_flow_imp.dz('20240515205651Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(70579191239986414)
,p_db_column_name=>'CODPRODUCTOPRV'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Cod. Prod. Neg.'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240305045717Z')
,p_updated_on=>wwv_flow_imp.dz('20240305143944Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(70579247424986415)
,p_db_column_name=>'DESPRODUCTOPRV'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'Producto Neg.'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240305045717Z')
,p_updated_on=>wwv_flow_imp.dz('20240305143944Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(70579302436986416)
,p_db_column_name=>'UMPRODUCTOPRV'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'UM Neg.'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240305045717Z')
,p_updated_on=>wwv_flow_imp.dz('20240305143944Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(70579454948986417)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Cantidad'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240305045717Z')
,p_updated_on=>wwv_flow_imp.dz('20240305143944Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(70579517157986418)
,p_db_column_name=>'PRECIO'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'Precio Fact.'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240305045717Z')
,p_updated_on=>wwv_flow_imp.dz('20240411211038Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(70579717492986420)
,p_db_column_name=>'NEGIDDET'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>'ID det. Neg.'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240305045717Z')
,p_updated_on=>wwv_flow_imp.dz('20240305143944Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(70579875559986421)
,p_db_column_name=>'PRECIONEG'
,p_display_order=>150
,p_column_identifier=>'N'
,p_column_label=>'Precio*'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240305045717Z')
,p_updated_on=>wwv_flow_imp.dz('20240305144623Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(70579903080986422)
,p_db_column_name=>'COINCODPRODUCTO'
,p_display_order=>160
,p_column_identifier=>'O'
,p_column_label=>'Coinc. Producto'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240305045717Z')
,p_updated_on=>wwv_flow_imp.dz('20240305143944Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(244874091340010336)
,p_db_column_name=>'CODPRODUCTO'
,p_display_order=>170
,p_column_identifier=>'P'
,p_column_label=>unistr('C\00F3d. Producto*')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240305141938Z')
,p_updated_on=>wwv_flow_imp.dz('20240305143944Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(244874148639010337)
,p_db_column_name=>'DESCPRODUCTO'
,p_display_order=>180
,p_column_identifier=>'Q'
,p_column_label=>'Producto*'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240305141938Z')
,p_updated_on=>wwv_flow_imp.dz('20240305143944Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(244874335917010339)
,p_db_column_name=>'CODCORTOPRODUCTO'
,p_display_order=>200
,p_column_identifier=>'S'
,p_column_label=>unistr('C\00F3d. Corto Prod.*')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240305141938Z')
,p_updated_on=>wwv_flow_imp.dz('20240305143944Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(70578753178986410)
,p_db_column_name=>'TOTAL'
,p_display_order=>210
,p_column_identifier=>'D'
,p_column_label=>'Total'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240305045717Z')
,p_updated_on=>wwv_flow_imp.dz('20240305143944Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(244874439578010340)
,p_db_column_name=>'SEPARADOR'
,p_display_order=>220
,p_column_identifier=>'T'
,p_column_label=>'.'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240305143256Z')
,p_updated_on=>wwv_flow_imp.dz('20240305143944Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(244874209042010338)
,p_db_column_name=>'ENLACE'
,p_display_order=>230
,p_column_identifier=>'R'
,p_column_label=>'Enlace'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20240305141938Z')
,p_updated_on=>wwv_flow_imp.dz('20240305143944Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(300485044957773224)
,p_db_column_name=>'VALIDAMONTO'
,p_display_order=>240
,p_column_identifier=>'U'
,p_column_label=>'Val. Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240515171504Z')
,p_updated_on=>wwv_flow_imp.dz('20240515171504Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(246400127630403914)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2464002'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODPRODUCTO:DESCPRODUCTO:PRECIONEG:SEPARADOR:CODPRODUCTOPRV:DESPRODUCTOPRV:CANTIDAD:PRECIO:TOTAL:'
,p_created_on=>wwv_flow_imp.dz('20240305045742Z')
,p_updated_on=>wwv_flow_imp.dz('20240515173738Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(316742948695342703)
,p_report_id=>wwv_flow_imp.id(246400127630403914)
,p_name=>'Val. Monto'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'VALIDAMONTO'
,p_operator=>'='
,p_expr=>'0'
,p_condition_sql=>' (case when ("VALIDAMONTO" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_font_color=>'#f50707'
,p_created_on=>wwv_flow_imp.dz('20240515173738Z')
,p_updated_on=>wwv_flow_imp.dz('20240515173738Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(107608885480134328)
,p_plug_name=>unistr('Informaci\00F3n del Pago')
,p_region_template_options=>'#DEFAULT#:t-Form--noPadding:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20240315042504Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(107610039294134340)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(125710243114747734)
,p_plug_name=>'Items'
,p_region_name=>'regItems'
,p_region_template_options=>'t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(295605160997037667)
,p_plug_display_sequence=>70
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20240315050913Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(244779922830761702)
,p_plug_name=>unistr('Par\00E1metros')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>30
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P215_ESTADO'
,p_plug_display_when_cond2=>'ACTIVO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20240304160439Z')
,p_updated_on=>wwv_flow_imp.dz('20240417141037Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(244781491252761717)
,p_plug_name=>'Facturas'
,p_region_name=>'rptFacturas'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with fac as (',
'	select txt01 claveacceso',
'		-- , txt02 secuencial',
'		, substr(txt02,1,17) secuencial',
'		, txt09 ride',
'		, fecha01 fechafactura',
'		, sum(num05) total',
'		, num10 cantfact',
'		, num11 cantnego',
'	from data.t_apex_temporal',
'	where control01 = :g_compania',
'		and control02 = :app_modulo',
'		and control03 = ''pk_comp_negociacion.sp_buscarfacturas''',
'		and control04 = to_char(to_number(:p215_idnegociacion))',
unistr('		and nvl(num10,0) <= num11	-- La factura debe tener la cantidad de items menor o igual a la cantidad de \00EDtems negociados'),
'		and nvl(num10,0) > 0',
'	-- group by txt01, txt02, txt09, fecha01, num10, num11',
'	group by txt01, substr(txt02,1,17), txt09, fecha01, num10, num11',
') select fac.*',
'	, apex_item.radiogroup(',
'		p_idx => 1',
'		, p_value => fac.claveacceso',
'		, p_attributes => ''class = "RB01" ''||case when fac.claveacceso = :p215_claveacceso then ''checked'' end||'' onchange = $s(P215_CLAVEACCESO,this.value)''',
'			) seleccion',
'from fac'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P215_IDNEGOCIACION'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P215_ESTADO'
,p_plug_display_when_cond2=>'ACTIVO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Facturas'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_created_on=>wwv_flow_imp.dz('20240304164435Z')
,p_updated_on=>wwv_flow_imp.dz('20260429203449Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(244781532057761718)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>wwv_flow_string.join(wwv_flow_t_varchar2(
'No hay facturas del proveedor en el periodo ingresado. Defina un nuevo rango y de clic en ''Buscar Facturas''.',
'Puede contactarse con Finanzas para validar si la factura ha llegado o para que la registren.'))
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>244781532057761718
,p_created_on=>wwv_flow_imp.dz('20240304165131Z')
,p_updated_on=>wwv_flow_imp.dz('20260429203449Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(244873555301010331)
,p_db_column_name=>'SELECCION'
,p_display_order=>10
,p_column_identifier=>'BT'
,p_column_label=>'.'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240304215907Z')
,p_updated_on=>wwv_flow_imp.dz('20240305035447Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(244872581204010321)
,p_db_column_name=>'CLAVEACCESO'
,p_display_order=>20
,p_column_identifier=>'BL'
,p_column_label=>'Clave Acceso'
,p_column_link=>'#RIDE#'
,p_column_linktext=>'#CLAVEACCESO#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240304195856Z')
,p_updated_on=>wwv_flow_imp.dz('20240304215907Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(244872669652010322)
,p_db_column_name=>'SECUENCIAL'
,p_display_order=>30
,p_column_identifier=>'BM'
,p_column_label=>'Secuencial'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240304195856Z')
,p_updated_on=>wwv_flow_imp.dz('20240304215907Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(244872745832010323)
,p_db_column_name=>'FECHAFACTURA'
,p_display_order=>40
,p_column_identifier=>'BN'
,p_column_label=>'Fecha Factura'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240304195856Z')
,p_updated_on=>wwv_flow_imp.dz('20240304215907Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(244873154707010327)
,p_db_column_name=>'TOTAL'
,p_display_order=>50
,p_column_identifier=>'BR'
,p_column_label=>'Total'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240304195856Z')
,p_updated_on=>wwv_flow_imp.dz('20240304215907Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(244873257149010328)
,p_db_column_name=>'RIDE'
,p_display_order=>60
,p_column_identifier=>'BS'
,p_column_label=>'Ride'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240304214414Z')
,p_updated_on=>wwv_flow_imp.dz('20240304215907Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(244874587208010341)
,p_db_column_name=>'CANTFACT'
,p_display_order=>70
,p_column_identifier=>'BU'
,p_column_label=>'Cantfact'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20240306172740Z')
,p_updated_on=>wwv_flow_imp.dz('20240306172740Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(244874648928010342)
,p_db_column_name=>'CANTNEGO'
,p_display_order=>80
,p_column_identifier=>'BV'
,p_column_label=>'Cantnego'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20240306172740Z')
,p_updated_on=>wwv_flow_imp.dz('20240306172740Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(244917630322047686)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2449177'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SELECCION:FECHAFACTURA:CLAVEACCESO:SECUENCIAL:TOTAL:'
,p_sort_column_1=>'FECHAFACTURA'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20240304165140Z')
,p_updated_on=>wwv_flow_imp.dz('20240305035235Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(330851451535165801)
,p_plug_name=>unistr('Informaci\00F3n del Pago Realizado')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P215_ESTADO'
,p_plug_display_when_cond2=>'APROBADO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20240529160334Z')
,p_updated_on=>wwv_flow_imp.dz('20250627174501Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(330851548956165802)
,p_plug_name=>unistr('Informaci\00F3n')
,p_parent_plug_id=>wwv_flow_imp.id(330851451535165801)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20240529160709Z')
,p_updated_on=>wwv_flow_imp.dz('20240529160709Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(330851847293165805)
,p_name=>'Detalle OC'
,p_parent_plug_id=>wwv_flow_imp.id(330851451535165801)
,p_template=>wwv_flow_imp.id(296121421643169165)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select jt.*',
'from t_comp_pagosrecurrentes a, json_table(a.detfactura,''$[*]''',
'	columns codproductoprv varchar2(100) path ''$.codproductoprv'',',
'		desproductoprv varchar2(100) path ''$.desproductoprv'',',
'		codcortoproducto number path ''$.codcortoproducto'',',
'		codproducto varchar2(100) path ''$.codproducto'',',
'		descproducto varchar2(100) path ''$.descproducto'',',
'		cantidad number path ''$.cantidad'',',
'		preciofac number path ''$.preciofac'',',
'		totalfac number path ''$.totalfac'',',
'		precioneg number path ''$.precioneg'',',
'		totalneg number path ''$.totalneg'',',
'		iddetneg number path ''$.iddetneg''',
'	) jt',
'where a.idneg = :p215_idnegociacion and a.idpago = :p215_idpago'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P215_IDNEGOCIACION,P215_IDPAGO'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Descargar'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_created_on=>wwv_flow_imp.dz('20240529161401Z')
,p_updated_on=>wwv_flow_imp.dz('20240529162806Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(330851933642165806)
,p_query_column_id=>1
,p_column_alias=>'CODPRODUCTOPRV'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240529161754Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(330852025331165807)
,p_query_column_id=>2
,p_column_alias=>'DESPRODUCTOPRV'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240529161754Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(330852103391165808)
,p_query_column_id=>3
,p_column_alias=>'CODCORTOPRODUCTO'
,p_column_display_sequence=>30
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240529161754Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(330852281693165809)
,p_query_column_id=>4
,p_column_alias=>'CODPRODUCTO'
,p_column_display_sequence=>40
,p_column_heading=>unistr('C\00F3d. Producto')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240529162806Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(330852358670165810)
,p_query_column_id=>5
,p_column_alias=>'DESCPRODUCTO'
,p_column_display_sequence=>50
,p_column_heading=>'Producto'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240529162806Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(330852416107165811)
,p_query_column_id=>6
,p_column_alias=>'CANTIDAD'
,p_column_display_sequence=>60
,p_column_heading=>'Cantidad'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D0000'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240529162806Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(330852518069165812)
,p_query_column_id=>7
,p_column_alias=>'PRECIOFAC'
,p_column_display_sequence=>70
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240529161839Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(330852622167165813)
,p_query_column_id=>8
,p_column_alias=>'TOTALFAC'
,p_column_display_sequence=>80
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240529161839Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(330852705846165814)
,p_query_column_id=>9
,p_column_alias=>'PRECIONEG'
,p_column_display_sequence=>90
,p_column_heading=>'Precio Un.'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D0000'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240529162806Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(330852876735165815)
,p_query_column_id=>10
,p_column_alias=>'TOTALNEG'
,p_column_display_sequence=>100
,p_column_heading=>'Total'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240529162806Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(330852968622165816)
,p_query_column_id=>11
,p_column_alias=>'IDDETNEG'
,p_column_display_sequence=>110
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240529161754Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(734700954259438255)
,p_plug_name=>'Archivos'
,p_parent_plug_id=>wwv_flow_imp.id(330851451535165801)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>80
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select filename archivo',
'	, fecha fecha_carga',
'	, dbms_lob.getlength(blobcontent) blobcontent',
'	, numeroarchivo',
'	, tipo tipoarchivo',
'	, ''<span aria-hidden="true" class="fa fa-trash-o"></span>'' eliminar',
'	, pk_commons.f_googledocview(numeroarchivo,mimetype) enlace',
'from files.t_apex_archivos',
'where 1 = 1',
'	and tabla = ''VT_COMP_PAGOSRECURRENTES''',
'	and id_tabla = :p215_identidad',
'	and nvl(tipo,''X'') = nvl(tipo,''X'')',
'order by numeroarchivo desc'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Archivos'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_ai_enabled=>false
,p_created_on=>wwv_flow_imp.dz('20250627174237Z')
,p_updated_on=>wwv_flow_imp.dz('20250627174911Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(734701008677438256)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'No hay archivos asociados.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>734701008677438256
,p_created_on=>wwv_flow_imp.dz('20250627174237Z')
,p_updated_on=>wwv_flow_imp.dz('20250627174911Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(734701133820438257)
,p_db_column_name=>'ARCHIVO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Archivo'
,p_column_link=>'#ENLACE#'
,p_column_linktext=>'#ARCHIVO#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250627174237Z')
,p_updated_on=>wwv_flow_imp.dz('20250627174237Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(734701192533438258)
,p_db_column_name=>'FECHA_CARGA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fecha Carga'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250627174237Z')
,p_updated_on=>wwv_flow_imp.dz('20250627174237Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(734701561295438262)
,p_db_column_name=>'ELIMINAR'
,p_display_order=>30
,p_column_identifier=>'F'
,p_column_label=>'Eliminar'
,p_column_link=>'javascript: $s(''P216_IDBORRAR'','''');$s(''P216_IDBORRAR'',''#NUMEROARCHIVO#'');'
,p_column_linktext=>'#ELIMINAR#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'NEVER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250627174237Z')
,p_updated_on=>wwv_flow_imp.dz('20250627174911Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(734701329683438259)
,p_db_column_name=>'BLOBCONTENT'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Blobcontent'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250627174237Z')
,p_updated_on=>wwv_flow_imp.dz('20250627174237Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(734701436870438260)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Numeroarchivo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250627174237Z')
,p_updated_on=>wwv_flow_imp.dz('20250627174237Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(734701524911438261)
,p_db_column_name=>'TIPOARCHIVO'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Tipoarchivo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250627174237Z')
,p_updated_on=>wwv_flow_imp.dz('20250627174237Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(734701724543438263)
,p_db_column_name=>'ENLACE'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Enlace'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250627174237Z')
,p_updated_on=>wwv_flow_imp.dz('20250627174237Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(766212408990899797)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'6805362'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ARCHIVO:FECHA_CARGA:ELIMINAR:BLOBCONTENT:NUMEROARCHIVO:TIPOARCHIVO:ENLACE'
,p_created_on=>wwv_flow_imp.dz('20250627174237Z')
,p_updated_on=>wwv_flow_imp.dz('20250627174237Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(232463123498576541)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(107610039294134340)
,p_button_name=>'REGRESAR'
,p_button_static_id=>'btnRegresar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:214:&SESSION.::&DEBUG.:214::'
,p_icon_css_classes=>'fa-arrow-left'
,p_created_on=>wwv_flow_imp.dz('20240227190819Z')
,p_updated_on=>wwv_flow_imp.dz('20240315041528Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(114080190895632729)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(107610039294134340)
,p_button_name=>'ENCARGADO'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Designar Encargado'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:217:&SESSION.::&DEBUG.:RP,217:P217_IDNEGOCIACION:&P215_IDNEGOCIACION.'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-window-user'
,p_updated_on=>wwv_flow_imp.dz('20240315041438Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(107610149411134341)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(107610039294134340)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-search'
,p_updated_on=>wwv_flow_imp.dz('20240315041438Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(244780756328761710)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(244779922830761702)
,p_button_name=>'FACTURAS'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Buscar Facturas'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-search'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240304163918Z')
,p_updated_on=>wwv_flow_imp.dz('20240417141037Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(244874991854010345)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(70578155801986404)
,p_button_name=>'COTEJO_AUT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>unistr('Cotego Autom\00E1tico')
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':p215_estado = ''ACTIVO'' and :p215_tipomonto = ''FIJO'' and :p215_validamonto = 1'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-check fam-circle fam-is-success'
,p_created_on=>wwv_flow_imp.dz('20240307164942Z')
,p_updated_on=>wwv_flow_imp.dz('20250627174127Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(249937131671133007)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(70578155801986404)
,p_button_name=>'COTEJO_MAN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Cotejo Manual'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:216:&SESSION.::&DEBUG.:216:P216_CLAVEACCESO,P216_IDNEGOCIACION,P216_IDPAGO,P216_CODPROVEEDOR,P216_TIPOMONTO,P216_ORIGENPROVEEDOR,P216_IDENTIDAD,P216_BANDERA:&P215_CLAVEACCESO.,&P215_IDNEGOCIACION.,&P215_IDPAGO.,&P215_CODPROVEEDOR.,&P215_TIPOMONTO.,&P215_ORIGENPROVEEDOR.,&P215_IDENTIDAD.,&P215_BANDERA.'
,p_button_condition=>':p215_estado = ''ACTIVO'' and (:p215_tipomonto = ''VARIABLE'' or :p215_origenproveedor = ''PE'')'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-check fam-stop fam-is-danger'
,p_created_on=>wwv_flow_imp.dz('20240311174505Z')
,p_updated_on=>wwv_flow_imp.dz('20250627174127Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(70577945218986402)
,p_name=>'P215_TABLAVALOR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(244781491252761717)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240305040942Z')
,p_updated_on=>wwv_flow_imp.dz('20240305044742Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(70578054839986403)
,p_name=>'P215_TABLAID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(244781491252761717)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240305040942Z')
,p_updated_on=>wwv_flow_imp.dz('20240305044742Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(70580125764986424)
,p_name=>'P215_FRECUENCIA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(107608885480134328)
,p_prompt=>'Frecuencia:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_NEG_FRECUENCIA'
,p_lov=>'.'||wwv_flow_imp.id(230185465636915585)||'.'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20240315042151Z')
,p_updated_on=>wwv_flow_imp.dz('20240531211655Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(70580218454986425)
,p_name=>'P215_TIPORECEPCION'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(107608885480134328)
,p_prompt=>unistr('Tipo Recepci\00F3n:')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_NEG_TIPORECEPCION'
,p_lov=>'.'||wwv_flow_imp.id(257467648715249911)||'.'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20240315042151Z')
,p_updated_on=>wwv_flow_imp.dz('20240315042234Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(107609408872134334)
,p_name=>'P215_FECHAINI'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(244779922830761702)
,p_item_default=>'sysdate - 6'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Inicio'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
,p_updated_on=>wwv_flow_imp.dz('20241002145737Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(107609579530134335)
,p_name=>'P215_FECHAFIN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(244779922830761702)
,p_item_default=>'sysdate'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Fin'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
,p_updated_on=>wwv_flow_imp.dz('20240304163510Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(125710314318747735)
,p_name=>'P215_APROBADOR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(125710243114747734)
,p_prompt=>'Aprobador:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20240313141804Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(232462815473576538)
,p_name=>'P215_CODPROVEEDOR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(125710243114747734)
,p_prompt=>unistr('C\00F3d. Proveedor')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240227185602Z')
,p_updated_on=>wwv_flow_imp.dz('20240313141804Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(232462961345576539)
,p_name=>'P215_IDNEGOCIACION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(125710243114747734)
,p_prompt=>unistr('ID Negociaci\00F3n:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240227185602Z')
,p_updated_on=>wwv_flow_imp.dz('20240313141804Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(232463087863576540)
,p_name=>'P215_IDPAGO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(107608885480134328)
,p_prompt=>unistr('N\00FAm. Pago:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20240227185602Z')
,p_updated_on=>wwv_flow_imp.dz('20240315042151Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(232463238428576542)
,p_name=>'P215_ESTADO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(125710243114747734)
,p_prompt=>'Estado:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240227191210Z')
,p_updated_on=>wwv_flow_imp.dz('20240313141804Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(232464037840576550)
,p_name=>'P215_APROBACION'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(125710243114747734)
,p_prompt=>unistr('Aprobaci\00F3n:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240304154705Z')
,p_updated_on=>wwv_flow_imp.dz('20240313141804Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(244780091536761703)
,p_name=>'P215_PROVEEDOR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(107608885480134328)
,p_prompt=>'Proveedor:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20240304161309Z')
,p_updated_on=>wwv_flow_imp.dz('20240304161506Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(244780101034761704)
,p_name=>'P215_NUMEROPAGOS'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(107608885480134328)
,p_prompt=>'Cant. Pagos:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20240304161310Z')
,p_updated_on=>wwv_flow_imp.dz('20240315042151Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(244780218210761705)
,p_name=>'P215_TIPOPAGO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(107608885480134328)
,p_prompt=>'Tipo Pago:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_NEG_TIPOPAGO'
,p_lov=>'.'||wwv_flow_imp.id(231130202278619882)||'.'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20240304161310Z')
,p_updated_on=>wwv_flow_imp.dz('20240315042151Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(244780393947761706)
,p_name=>'P215_FECHAPRIMERPAGO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(107608885480134328)
,p_prompt=>'Fecha prim. Pago:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20240304161310Z')
,p_updated_on=>wwv_flow_imp.dz('20240315042151Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(244780449764761707)
,p_name=>'P215_TIPOMONTO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(107608885480134328)
,p_prompt=>'Tipo Monto:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_NEG_TIPOMONTO'
,p_lov=>'.'||wwv_flow_imp.id(240341499876606572)||'.'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_created_on=>wwv_flow_imp.dz('20240304161310Z')
,p_updated_on=>wwv_flow_imp.dz('20240315042151Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(244780513543761708)
,p_name=>'P215_FLJDETALLE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(125710243114747734)
,p_prompt=>'ID det. Flujo:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240304161310Z')
,p_updated_on=>wwv_flow_imp.dz('20240313141804Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(244780631280761709)
,p_name=>'P215_FLJTOKEN'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(125710243114747734)
,p_prompt=>'Token:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240304161310Z')
,p_updated_on=>wwv_flow_imp.dz('20240313141804Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(244873632709010332)
,p_name=>'P215_CLAVEACCESO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(125710243114747734)
,p_prompt=>'Clave Acceso:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240304220401Z')
,p_updated_on=>wwv_flow_imp.dz('20240313170403Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(249936700474133003)
,p_name=>'P215_ESAPROBADOR'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(125710243114747734)
,p_prompt=>unistr('Aprobaci\00F3n:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240307185235Z')
,p_updated_on=>wwv_flow_imp.dz('20240313141804Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(249936884403133004)
,p_name=>'P215_FECHAPAGO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(107608885480134328)
,p_prompt=>'Fecha Pago:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20240307194706Z')
,p_updated_on=>wwv_flow_imp.dz('20240315042151Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(260170833103355616)
,p_name=>'P215_RESPUESTA'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(125710243114747734)
,p_prompt=>'Respuesta:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240424170726Z')
,p_updated_on=>wwv_flow_imp.dz('20240424170726Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(300484910520773223)
,p_name=>'P215_VALIDAMONTO'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(125710243114747734)
,p_prompt=>'Valida Monto:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20240515162927Z')
,p_updated_on=>wwv_flow_imp.dz('20250324220417Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(330851677649165803)
,p_name=>'P215_ORDENCOMPRA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(330851548956165802)
,p_prompt=>'Orden Compra'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20240529160709Z')
,p_updated_on=>wwv_flow_imp.dz('20240529162506Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(330851710758165804)
,p_name=>'P215_CLAVEACCESOPAGO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(330851548956165802)
,p_prompt=>'Clave Acceso'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20240529160709Z')
,p_updated_on=>wwv_flow_imp.dz('20240529162506Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(649023004053697401)
,p_name=>'P215_ORIGENPROVEEDOR'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(125710243114747734)
,p_prompt=>'Origen Proveedor:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250324220417Z')
,p_updated_on=>wwv_flow_imp.dz('20250324220417Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(649023369393697404)
,p_name=>'P215_IDENTIDAD'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(125710243114747734)
,p_prompt=>'Identidad'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250325220623Z')
,p_updated_on=>wwv_flow_imp.dz('20250325220623Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(649023673948697407)
,p_name=>'P215_BANDERA'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(125710243114747734)
,p_prompt=>'Bandera'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_item_comment=>unistr('Me permitir\00E1 controlar el estado del Pago.')
,p_created_on=>wwv_flow_imp.dz('20250326170612Z')
,p_updated_on=>wwv_flow_imp.dz('20250326170612Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(244780889505761711)
,p_name=>'Buscar Facturas'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(244780756328761710)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20240304164239Z')
,p_updated_on=>wwv_flow_imp.dz('20240304174141Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(244780990710761712)
,p_event_id=>wwv_flow_imp.id(244780889505761711)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
,p_created_on=>wwv_flow_imp.dz('20240304164240Z')
,p_updated_on=>wwv_flow_imp.dz('20240304164240Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(244781083904761713)
,p_event_id=>wwv_flow_imp.id(244780889505761711)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_idneg		number;',
'v_idpago	number;',
'begin',
'	v_idneg		:= to_number(:p215_idnegociacion);',
'	v_idpago	:= to_number(:p215_idpago);',
'',
'	data.pk_comp_negociacion.sp_buscarfacturas (',
'		p_compania		=> :g_compania',
'		, p_usuario		=> :app_user',
'		, p_idneg		=> v_idneg',
'		, p_proveedor	=> :p215_codproveedor',
'		, p_desde		=> :p215_fechaini',
'		, p_hasta		=> :p215_fechafin',
'	);',
'end;'))
,p_attribute_02=>'P215_CODPROVEEDOR,P215_FECHAINI,P215_FECHAFIN'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240304164240Z')
,p_updated_on=>wwv_flow_imp.dz('20240304165131Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(244871952928010315)
,p_event_id=>wwv_flow_imp.id(244780889505761711)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(244781491252761717)
,p_created_on=>wwv_flow_imp.dz('20240304165130Z')
,p_updated_on=>wwv_flow_imp.dz('20240304174141Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(244781161357761714)
,p_event_id=>wwv_flow_imp.id(244780889505761711)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
,p_created_on=>wwv_flow_imp.dz('20240304164240Z')
,p_updated_on=>wwv_flow_imp.dz('20240304165131Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(244873769522010333)
,p_name=>unistr('Selecci\00F3n RB')
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.RB01'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20240304221158Z')
,p_updated_on=>wwv_flow_imp.dz('20240313165520Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(244873907121010335)
,p_event_id=>wwv_flow_imp.id(244873769522010333)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_idneg	number;',
'v_idpago		number;',
'v_claveacceso	varchar2(100);',
'begin',
'	v_idneg			:= :p215_idnegociacion;',
'	v_idpago		:= :p215_idpago;',
'	v_claveacceso	:= :p215_claveacceso;',
'end;'))
,p_attribute_02=>'P215_IDNEGOCIACION,P215_IDPAGO,P215_CLAVEACCESO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240304221158Z')
,p_updated_on=>wwv_flow_imp.dz('20240313142031Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(249936915307133005)
,p_event_id=>wwv_flow_imp.id(244873769522010333)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(70578155801986404)
,p_created_on=>wwv_flow_imp.dz('20240307195909Z')
,p_updated_on=>wwv_flow_imp.dz('20240307195909Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(70580047481986423)
,p_event_id=>wwv_flow_imp.id(244873769522010333)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240305045717Z')
,p_updated_on=>wwv_flow_imp.dz('20240313165520Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(244875006036010346)
,p_name=>'Asociar Factura'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(244874991854010345)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20240307171856Z')
,p_updated_on=>wwv_flow_imp.dz('20240523200119Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(244875328161010349)
,p_event_id=>wwv_flow_imp.id(244875006036010346)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEst\00E1 seguro de asociar la Factura al Pago de la Negociaci\00F3n? Esta acci\00F3n generar\00E1 una Orden de Compra.')
,p_attribute_02=>'Asociar Factura'
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-exclamation-triangle-o'
,p_attribute_06=>unistr('S\00ED')
,p_attribute_07=>'Cancelar'
,p_created_on=>wwv_flow_imp.dz('20240307171856Z')
,p_updated_on=>wwv_flow_imp.dz('20240307171856Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(244875107050010347)
,p_event_id=>wwv_flow_imp.id(244875006036010346)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
,p_created_on=>wwv_flow_imp.dz('20240307171856Z')
,p_updated_on=>wwv_flow_imp.dz('20240307171856Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(244875250338010348)
,p_event_id=>wwv_flow_imp.id(244875006036010346)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_idneg	number;',
'v_idpago		number;',
'v_claveacceso	varchar2(100);',
'v_respuesta		varchar2(3000);',
'v_proveedor		number;',
'begin',
'	v_idneg			:= :p215_idnegociacion;',
'	v_idpago		:= :p215_idpago;',
'	v_claveacceso	:= :p215_claveacceso;',
'	v_proveedor		:= :p215_codproveedor;',
'',
'	data.pk_comp_negociacion.sp_asociarpago(',
'		p_compania		=> :g_compania',
'		, p_usuario		=> :app_user',
'		, p_idneg		=> v_idneg',
'		, p_proveedor	=> v_proveedor',
'		, p_idpago		=> v_idpago',
'		, p_claveacceso	=> v_claveacceso',
'		, p_respuesta	=> v_respuesta',
'	);',
'',
'	:p215_respuesta := v_respuesta;',
'end;'))
,p_attribute_02=>'P215_IDNEGOCIACION,P215_IDPAGO,P215_CLAVEACCESO,P215_CODPROVEEDOR'
,p_attribute_03=>'P215_RESPUESTA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240307171856Z')
,p_updated_on=>wwv_flow_imp.dz('20240424171134Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(249936532820133001)
,p_event_id=>wwv_flow_imp.id(244875006036010346)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#btnRegresar'').trigger("click");',
'ocultarBarra();'))
,p_created_on=>wwv_flow_imp.dz('20240307171929Z')
,p_updated_on=>wwv_flow_imp.dz('20240523200119Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(125710599343747737)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Setup'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_idneg		number;',
'v_idpago	number;',
'v_usuario	varchar2(25);',
'v_aprobador	varchar2(25);',
'v_log_app	varchar2(99);',
'v_log_dsc	varchar2(999);',
'v_log_msg	varchar2(999);',
'v_log_obs	varchar2(999);',
'begin',
'	v_log_app := ''apex.130.215.setup'';',
unistr('	-- Desde la p\00E1gina 214 se env\00EDa:'),
'	--- p215_idnegociacion, p215_idpago, p215_codproveedor, p215_aprobador, p215_estado',
'',
'	--Verifico si ingresa desde la Mesa de Trabajo o por enlace.',
'	if :g_detalle_id is not null and :g_token is not null then -- Aprobacion con token (desde link del correo)',
'		pk_corp_flujoaprobacion.sp_buscaraprobacion(:g_detalle_id,:g_token,:g_compania,v_aprobador,v_idneg,v_idpago);',
'',
'		v_usuario := v_aprobador;',
'	else',
'		v_usuario	:= :app_user;',
'		v_aprobador	:= :p215_aprobador;',
'		v_idneg		:= to_number(:p215_idnegociacion);',
'		v_idpago	:= to_number(:p215_idpago);',
'	end if;',
'	v_log_dsc := ''v_usuario: ''||v_usuario||'', v_aprobador: ''||v_aprobador||'', v_idneg: ''||v_idneg||'', v_idpago: ''||v_idpago;',
'',
'	-- Valido si es aprobador',
'	if v_aprobador = v_usuario then :p215_esaprobador := 1; else :p215_esaprobador := 0; end if;',
'',
unistr('	-- Cargo informaci\00F3n del pago:'),
'	begin',
'		select codproveedor',
'			, proveedor',
'			, tipomonto',
'			, idpago',
'			, fechapago',
'			, numeropagos',
'			, fechaprimerpago',
'			, frecuencia',
'			, tiporecepcion',
'			, tipopago',
'			, estado',
'			, aprobacion',
'			, fljdetalle',
'			, fljtoken',
'			, tipoorden||''-''||numorden',
'			, claveacceso',
'			, identidad',
'		into :p215_codproveedor',
'			, :p215_proveedor',
'			, :p215_tipomonto',
'			, :p215_idpago',
'			, :p215_fechapago',
'			, :p215_numeropagos',
'			, :p215_fechaprimerpago',
'			, :p215_frecuencia',
'			, :p215_tiporecepcion',
'			, :p215_tipopago',
'			, :p215_estado',
'			, :p215_aprobacion',
'			, :p215_fljdetalle',
'			, :p215_fljtoken',
'			, :p215_ordencompra',
'			, :p215_claveaccesopago',
'			, :p215_identidad',
'		from data.vt_comp_pagosrecurrentes',
'		where idneg = v_idneg and idpago = v_idpago;',
'',
'		exception when others then',
'			v_log_msg := ''No hay datos en data.vt_comp_pagosrecurrentes'';',
'			data.pk_commons.sp_apex_log(v_log_app,-1,v_log_dsc,v_log_msg,v_log_obs,null);',
'			:p215_aprobacion := 0;',
'	end;',
'',
'	begin',
'		select num12 into :p215_validamonto',
'		from data.t_apex_temporal',
'		where control01 = :g_compania',
'			and control02 = :app_modulo',
'			and control03 = ''pk_comp_negociacion.sp_buscarfacturas''',
'			and control04 = to_char(to_number(:p215_idnegociacion))',
'			and txt01 = :p215_claveacceso',
'			and rownum = 1;',
'',
'		exception when others then ',
'			v_log_msg := ''No hay datos en data.t_apex_temporal'';',
'			data.pk_commons.sp_apex_log(v_log_app,-2,v_log_dsc,v_log_msg,v_log_obs,null);',
'			:p215_validamonto := 0;',
'	end;',
'',
'	begin',
'		select substr(tipo,1,2) into :p215_origenproveedor',
'		from data.vt_jde_maestroproveedor',
'		where codigoproveedor = :p215_codproveedor and rownum = 1;',
'',
'		exception when others then',
'			v_log_msg := ''No hay datos en data.vt_jde_maestroproveedor'';',
'			data.pk_commons.sp_apex_log(v_log_app,-3,v_log_dsc,v_log_msg,v_log_obs,null);',
'			:p215_origenproveedor := ''XY'';',
'	end;',
'',
'	-- if :p215_origenproveedor = ''PL'' or (:p215_origenproveedor = ''PE'' and :p215_tipomonto = ''FIJO'') then',
'	if :p215_origenproveedor = ''PL'' then',
'		:p215_bandera := ''LIBRE'';',
'	elsif :p215_origenproveedor = ''PE'' and :p215_tipomonto in (''VARIABLE'',''FIJO'') then',
'		:p215_bandera := ''APROBACION'';',
'	else',
unistr('		v_log_msg := ''Condici\00F3n no controlada'';'),
'		v_log_obs := ''p215_origenproveedor: ''||:p215_origenproveedor||'', p215_tipomonto: ''||:p215_tipomonto;',
'		data.pk_commons.sp_apex_log(v_log_app,-4,v_log_dsc,v_log_msg,v_log_obs,null);',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>125710599343747737
,p_updated_on=>wwv_flow_imp.dz('20251030210402Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
