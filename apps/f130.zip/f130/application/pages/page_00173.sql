prompt --application/pages/page_00173
begin
--   Manifest
--     PAGE: 00173
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>173
,p_name=>'Conocimiento Embarque'
,p_page_mode=>'MODAL'
,p_step_title=>'Conocimiento Embarque'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'02'
,p_created_on=>wwv_flow_imp.dz('20230708132657Z')
,p_last_updated_on=>wwv_flow_imp.dz('20221122002352Z')
,p_last_updated_by=>'NETBY3'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(81377609099053726)
,p_plug_name=>'Conocimiento Embarque'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(82124231006611204)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(82124380014611205)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(82124231006611204)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>':P173_ID IS NULL'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(98605953123944718)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(82124231006611204)
,p_button_name=>'ELIMINAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Eliminar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':P173_ID IS NOT NULL'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-trash'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(94271655509663818)
,p_branch_action=>'f?p=&APP_ID.:171:&SESSION.::&DEBUG.:RP,171:P171_ID:&P173_ID_CMEX_MESATRABAJO.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81377759882053727)
,p_name=>'P173_CODIGO_BL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(81377609099053726)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Conocimiento de Embarque'
,p_source=>'CODIGO_BL'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>25
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82124173099611203)
,p_name=>'P173_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(81377609099053726)
,p_use_cache_before_default=>'NO'
,p_source=>'ID'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82124503643611207)
,p_name=>'P173_ID_CMEX_MESATRABAJO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(81377609099053726)
,p_use_cache_before_default=>'NO'
,p_source=>'ID_CMEX_MESATRABAJO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(98606026931944719)
,p_name=>'Confirmacion'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(98605953123944718)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(98606179727944720)
,p_event_id=>wwv_flow_imp.id(98606026931944719)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Esta seguro de eliminar el dato, la informaci\00F3n dependiente al dato ser\00E1 eliminada tambi\00E9n?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(98606218589944721)
,p_event_id=>wwv_flow_imp.id(98606026931944719)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(82124460378611206)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'PROCESS ROW'
,p_attribute_02=>'T_CMEX_DETALLEDATOSEXP'
,p_attribute_03=>'P173_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(82124380014611205)
,p_internal_uid=>82124460378611206
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(98606312285944722)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Eliminar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN ',
'DELETE FROM DATA.T_CMEX_CONTENEDORESDOCUMENTOS',
'WHERE NRO_CONTENEDOR = (SELECT NRO_CONTENEDOR FROM T_CMEX_DETALLECONTENEDOR WHERE ID_DETALLEDATOSEXP = :P173_ID );',
'',
'DELETE FROM DATA.T_CMEX_DETALLECONTENEDOR',
'WHERE ID_DETALLEDATOSEXP = :P173_ID;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(98605953123944718)
,p_internal_uid=>98606312285944722
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(82124021986611202)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'FETCH ROW '
,p_attribute_02=>'T_CMEX_DETALLEDATOSEXP'
,p_attribute_03=>'P173_ID'
,p_attribute_04=>'ID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>82124021986611202
);
wwv_flow_imp.component_end;
end;
/
