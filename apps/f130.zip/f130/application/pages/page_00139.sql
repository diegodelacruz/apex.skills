prompt --application/pages/page_00139
begin
--   Manifest
--     PAGE: 00139
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>139
,p_name=>unistr('Negociaci\00F3n - Registro')
,p_step_title=>unistr('Registro - Negociaci\00F3n')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(secItems).hide();',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-button.a-IRR-sortWidget-button[data-option="hide"], .a-IRR-button.a-IRR-sortWidget-button[data-option="freeze"]{',
'    display:none;',
'}',
'.a-IG-controls-item--aggregate, .a-IG-controls-item--controlBreak, .a-IG-controls-item--groupBy, .a-IG-reportSummary-item--aggregate, .a-IG-reportSummary-item--controlBreak, .a-IG-reportSummary-item--groupBy, .a-IRR-controls-item--aggregate, .a-IRR-c'
||'ontrols-item--controlBreak, .a-IRR-controls-item--groupBy, .a-IRR-reportSummary-item--aggregate, .a-IRR-reportSummary-item--controlBreak, .a-IRR-reportSummary-item--groupBy {',
'    --a-report-controls-cell-label-icon-background-color: #3b83bd;',
'    --a-report-controls-cell-label-hover-background-color: #e6f0f7;',
'    display: none;',
'}',
'.t-Wizard-body {',
'    background-repeat: no-repeat!important;',
'    background-size: 100% 16px,100% 16px,100% 8px,100% 8px!important;',
'    background-attachment: local,local,scroll,scroll!important;',
'    display: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240829153113Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260714220457Z')
,p_last_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(133924695414985532)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(134070789946252905)
,p_plug_name=>'Detalle'
,p_region_name=>'Detalle'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(295630388916037685)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select det_id id',
'	, cab_id idcab',
'	, (select codigoproducto||'' - ''||nombreproducto||'' ''||codigoalterno||'' - [''||unidadcompra||'']'' d from vt_jde_productos where codigocorto = det_codproducto and codestado != ''O'') codigoproducto',
'	, det_codproducto codproducto',
'	, det_codproductoprv codproductoprv',
'	, det_desproductoprv desproductoprv',
'	, det_umproductoprv umproductoprv',
'	, (select codigoproveedor||'' - ''||descripcion d from vt_jde_maestroproveedor where codigoproveedor = det_codproveedor) codproveedor',
unistr('	, decode(det_tiempoentrega,0,''Inmediato'',det_tiempoentrega ||'' d\00EDas'')tiempoentrega'),
'	, (select pnptc||'' - ''||upper(pnptd) d from f0014@jdedtadl where pnptc = det_formapago and trim(pnptc) is not null) formapago',
'	, (select drky ||'' - ''||upper(drdl01) d from vt_jde_udcjde where drky = det_incoterm   and  drsy = ''42'' and drrt = ''FR'' and drky is not null ) incoterm',
'	, det_cantdesde cantdesde',
'	, det_canthasta canthasta',
'	, decode(cab_tipoprecio,''FM'',det_preciocal,det_precio) precio',
'	, det_preciocal preciocalculado',
'	, det_comentario comentario',
'	, null ver--, case when exists (select 1 from vt_comp_negociacionhoc h where h.pditm = d.det_codproducto ) then ''<span class="fa fa-combo-chart"></span>'' else null end ver',
'	, det_precio_p1',
'	, variacion_p1',
'	, data.pk_comp_negociacion.f_neg_semaforo(decode(cab_tipoprecio,''FM'',det_preciocal,det_precio),det_precio_p1) p1_semaforo',
'	, case when variacion_p1 < 0 then 1 when variacion_p1 > 0 then -1 else 0 end p1_orden',
'	, d.ultimacompra',
'from data.vt_comp_negociaciondet d left join data.vt_comp_negociacionpas p on neg_id = neg_id_act',
'	and det_id = det_id_act',
'	and det_codproveedor = det_codproveedor_act',
'	and det_cantdesde = det_cantdesde_act',
'	and det_canthasta = det_canthasta_act',
'	and nvl(det_tiempoentrega,0) = nvl(det_tiempoentrega_act,0)',
'	and nvl(det_formapago,''x'') = nvl(det_formapago_act,''x'')',
'	and nvl(det_incoterm,''y'') = nvl(det_incoterm_act,''y'')',
'where neg_id = :p139_id_negociacion',
'	and cab_id=:p139_id_cabecera'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P139_ID_CABECERA'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P139_ID_NEGOCIACION'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Detalle'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20260302155537Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(135397155327648824)
,p_max_row_count=>'1000000'
,p_allow_report_saving=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_finder_drop_down=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_filter=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>135397155327648824
,p_updated_on=>wwv_flow_imp.dz('20260302155537Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(135397269189648825)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(135397369984648826)
,p_db_column_name=>'IDCAB'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Idcab'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43436019112543039)
,p_db_column_name=>'CODPRODUCTOPRV'
,p_display_order=>50
,p_column_identifier=>'T'
,p_column_label=>unistr('C\00F3d. Producto Prov')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P139_ESQUEMA'
,p_display_condition2=>'PV'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(62378583390452808)
,p_db_column_name=>'DESPRODUCTOPRV'
,p_display_order=>70
,p_column_identifier=>'W'
,p_column_label=>'Desc. Producto Prov'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P139_ESQUEMA'
,p_display_condition2=>'PV'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79931056265477324)
,p_db_column_name=>'UMPRODUCTOPRV'
,p_display_order=>80
,p_column_identifier=>'Z'
,p_column_label=>'UM Producto Proveedor'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P139_ESQUEMA'
,p_display_condition2=>'PV'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(135398114826648834)
,p_db_column_name=>'FORMAPAGO'
,p_display_order=>90
,p_column_identifier=>'J'
,p_column_label=>'Forma de Pago'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(134250431110099274)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(135398216748648835)
,p_db_column_name=>'INCOTERM'
,p_display_order=>100
,p_column_identifier=>'K'
,p_column_label=>'Incoterm'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(74803172029355163)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(135398335876648836)
,p_db_column_name=>'CANTDESDE'
,p_display_order=>110
,p_column_identifier=>'L'
,p_column_label=>'Cant. Desde'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>'(:P139_TIPO_NEGOCIACION=''ES'')'
,p_display_condition2=>'SQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(135398451183648837)
,p_db_column_name=>'CANTHASTA'
,p_display_order=>120
,p_column_identifier=>'M'
,p_column_label=>'Cant. Hasta'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_display_condition_type=>'EXPRESSION'
,p_display_condition=>'(:P139_TIPO_NEGOCIACION=''ES'')'
,p_display_condition2=>'SQL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(135398574491648838)
,p_db_column_name=>'PRECIO'
,p_display_order=>130
,p_column_identifier=>'N'
,p_column_label=>'Precio '
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(135398815927648841)
,p_db_column_name=>'COMENTARIO'
,p_display_order=>160
,p_column_identifier=>'Q'
,p_column_label=>'Comentario'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43436266367543041)
,p_db_column_name=>'VER'
,p_display_order=>230
,p_column_identifier=>'V'
,p_column_label=>'<span class="fa fa-combo-chart"></span>'
,p_column_link=>'f?p=&APP_ID.:142:&SESSION.::&DEBUG.:142:P142_ID_NEGOCIACION,P142_PAGINA,P142_ID_DETALLE,P142_PRODUCTO,P142_VIGENCIA:&P139_ID_NEGOCIACION.,&APP_PAGE_ID.,#ID#,#CODPRODUCTO#,&P139_VIGENCIA_DESDE. - &P139_VIGENCIA_HASTA.'
,p_column_linktext=>'#VER#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P139_ESQUEMA'
,p_display_condition2=>'xPV'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260302043505Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(62378960172452812)
,p_db_column_name=>'TIEMPOENTREGA'
,p_display_order=>240
,p_column_identifier=>'Y'
,p_column_label=>'Tiempo de Entrega'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154657312288159006)
,p_db_column_name=>'CODIGOPRODUCTO'
,p_display_order=>250
,p_column_identifier=>'AA'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P139_ESQUEMA'
,p_display_condition2=>'PV'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154657404472159007)
,p_db_column_name=>'CODPROVEEDOR'
,p_display_order=>260
,p_column_identifier=>'AB'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P139_ESQUEMA'
,p_display_condition2=>'PD'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154657780665159010)
,p_db_column_name=>'DET_PRECIO_P1'
,p_display_order=>290
,p_column_identifier=>'AE'
,p_column_label=>unistr('\00DAltimo Precio')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154657834959159011)
,p_db_column_name=>'VARIACION_P1'
,p_display_order=>300
,p_column_identifier=>'AF'
,p_column_label=>'% Var.'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154657997196159012)
,p_db_column_name=>'P1_SEMAFORO'
,p_display_order=>310
,p_column_identifier=>'AG'
,p_column_label=>'<span style="color:white; font-size:small" class="fa fa-dot-circle-o">'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(154658086687159013)
,p_db_column_name=>'P1_ORDEN'
,p_display_order=>320
,p_column_identifier=>'AH'
,p_column_label=>'P1 Orden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(206426495471010902)
,p_db_column_name=>'PRECIOCALCULADO'
,p_display_order=>330
,p_column_identifier=>'AI'
,p_column_label=>unistr('Precio. C\00E1lc. F\00F3rm.')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(232459722182576507)
,p_db_column_name=>'CODPRODUCTO'
,p_display_order=>340
,p_column_identifier=>'AJ'
,p_column_label=>'Codproducto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(411012354745960506)
,p_db_column_name=>'ULTIMACOMPRA'
,p_display_order=>350
,p_column_identifier=>'AK'
,p_column_label=>unistr('\00DAlt. Compra')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240909033933Z')
,p_updated_on=>wwv_flow_imp.dz('20240909033933Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(135453550378825739)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1354536'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>20
,p_report_columns=>'CODIGOPRODUCTO:CODPROVEEDOR:CODPRODUCTOPRV:DESPRODUCTOPRV:CANTDESDE:CANTHASTA:UMPRODUCTOPRV:TIEMPOENTREGA:FORMAPAGO:INCOTERM:PRECIO:COMENTARIO:DET_PRECIO_P1:VARIACION_P1:P1_SEMAFORO:VER'
,p_created_on=>wwv_flow_imp.dz('20240829153113Z')
,p_updated_on=>wwv_flow_imp.dz('20250219144120Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(134073239089252930)
,p_plug_name=>'Cabecera'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(295630388916037685)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id',
'	, idneg',
'	, usercrea',
'	, fechcrea',
'	, usermodi',
'	, fechmodi',
'	, escala',
'	, acumula',
'	, tipoprecio',
'	, formula',
'	, unidadnegocio',
'	, unidadnegociogasto',
'	, moneda',
'	, toleranciatip',
'	, toleranciaamp',
'	, toleranciadsd',
'	, toleranciahst',
'	, justificacion',
'	, direccionenvio',
'	, ''<span title="Ver Detalles" class="fa fa-layout-list-right"/>'' detalle',
'from t_comp_negociacioncab',
'where idneg = :p139_id_negociacion'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P139_ID_NEGOCIACION'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P139_ID_NEGOCIACION'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Cabecera'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43436627426543045)
,p_name=>'UNIDADNEGOCIO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UNIDADNEGOCIO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>unistr('(UN) Ruta de Aprobaci\00F3n')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>150
,p_value_alignment=>'LEFT'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_attribute_08=>'500'
,p_is_required=>false
,p_max_length=>20
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(44764979228098231)
,p_lov_display_extra=>false
,p_lov_display_null=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P139_RECURRENTE'
,p_display_condition2=>'SI'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43436783900543046)
,p_name=>'MONEDA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'MONEDA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Moneda'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>180
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(44765112142102561)
,p_lov_display_extra=>false
,p_lov_display_null=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'USD'
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43436827954543047)
,p_name=>'TOLERANCIATIP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOLERANCIATIP'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Tipo Tolerancia'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>190
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(50696667460910822)
,p_lov_display_extra=>false
,p_lov_display_null=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'PCN'
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43436901675543048)
,p_name=>'TOLERANCIAAMP'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOLERANCIAAMP'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>200
,p_attribute_01=>'Y'
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43437085844543049)
,p_name=>'TOLERANCIADSD'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOLERANCIADSD'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'% Tol. Desde'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>210
,p_value_alignment=>'RIGHT'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43437169072543050)
,p_name=>'TOLERANCIAHST'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOLERANCIAHST'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'% Tol. Hasta'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>220
,p_value_alignment=>'RIGHT'
,p_attribute_03=>'right'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(134150333457570805)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Id'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>30
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(134150490913570806)
,p_name=>'IDNEG'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'IDNEG'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Idneg'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P139_ID_NEGOCIACION'
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(134150512565570807)
,p_name=>'USERCREA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'USERCREA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Usercrea'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P139_USUARIO'
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(134150662152570808)
,p_name=>'FECHCREA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHCREA'
,p_data_type=>'TIMESTAMP'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Fechcrea'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(134150784663570809)
,p_name=>'USERMODI'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'USERMODI'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Usermodi'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'ITEM'
,p_default_expression=>'P139_USUARIO'
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(134150826305570810)
,p_name=>'FECHMODI'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FECHMODI'
,p_data_type=>'TIMESTAMP'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Fechmodi'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>80
,p_value_alignment=>'LEFT'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_date_ranges=>'ALL'
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(134150994521570811)
,p_name=>'ESCALA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ESCALA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Escala'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>90
,p_value_alignment=>'CENTER'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(134249429228090814)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_lov_null_text=>'Seleccione'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P139_TIPO_NEGOCIACION'
,p_display_condition2=>'ES'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(134151082980570812)
,p_name=>'ACUMULA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ACUMULA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_YES_NO'
,p_heading=>'Acumula'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>100
,p_value_alignment=>'CENTER'
,p_attribute_01=>'N'
,p_attribute_02=>'SI'
,p_attribute_03=>'SI'
,p_attribute_04=>'NO'
,p_attribute_05=>'NO'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P139_TIPO_NEGOCIACION'
,p_display_condition2=>'ES'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(134151171154570813)
,p_name=>'TIPOPRECIO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TIPOPRECIO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Tipo Precio'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>110
,p_value_alignment=>'CENTER'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(134248652638070866)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_lov_null_text=>'Seleccione'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(134151271293570814)
,p_name=>'FORMULA'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'FORMULA'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>unistr('F\00F3rmula')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>120
,p_value_alignment=>'LEFT'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_attribute_08=>'900'
,p_attribute_10=>'DESCRIPCION'
,p_is_required=>false
,p_max_length=>100
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(66566332119154689)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(134151339884570815)
,p_name=>'JUSTIFICACION'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'JUSTIFICACION'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Justificacion'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>230
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>500
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(134153814987570840)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(134153974812570841)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(134267474559289107)
,p_name=>'DETALLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DETALLE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_LINK'
,p_heading=>'-'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>240
,p_value_alignment=>'CENTER'
,p_link_target=>'f?p=&APP_ID.:140:&SESSION.::&DEBUG.:RP:P140_ID_CABECERA,P140_ID_NEGOCIACION:&ID.,&IDNEG.'
,p_link_text=>'&DETALLE.'
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>true
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>false
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_display_condition=>'P139_ES_EDICION'
,p_display_condition2=>'-1'
,p_escape_on_http_output=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(260170055162355608)
,p_name=>'UNIDADNEGOCIOGASTO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UNIDADNEGOCIOGASTO'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>'UN Gasto'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>160
,p_value_alignment=>'LEFT'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_attribute_08=>'500'
,p_is_required=>false
,p_max_length=>25
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(314367888586033042)
,p_lov_display_extra=>false
,p_lov_display_null=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P139_RECURRENTE'
,p_display_condition2=>'SI'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(300484327023773217)
,p_name=>'DIRECCIONENVIO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DIRECCIONENVIO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>unistr('Dir. Env\00EDo')
,p_heading_alignment=>'LEFT'
,p_display_sequence=>170
,p_value_alignment=>'LEFT'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_attribute_08=>'500'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(314400268386167334)
,p_lov_display_extra=>false
,p_lov_display_null=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P139_RECURRENTE'
,p_display_condition2=>'SI'
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(134150244544570804)
,p_internal_uid=>134150244544570804
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>false
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>false
,p_show_toolbar=>true
,p_toolbar_buttons=>'ACTIONS_MENU:RESET:SAVE'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>false
,p_download_formats=>null
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (config) {',
'    return cargarToolbar(config);',
'}'))
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(134160575781572837)
,p_interactive_grid_id=>wwv_flow_imp.id(134150244544570804)
,p_static_id=>'378706'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(134160644934572837)
,p_report_id=>wwv_flow_imp.id(134160575781572837)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(44730590963522732)
,p_view_id=>wwv_flow_imp.id(134160644934572837)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(43436627426543045)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>100
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(44731457117522737)
,p_view_id=>wwv_flow_imp.id(134160644934572837)
,p_display_seq=>15
,p_column_id=>wwv_flow_imp.id(43436783900543046)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>70
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(44732337420522739)
,p_view_id=>wwv_flow_imp.id(134160644934572837)
,p_display_seq=>16
,p_column_id=>wwv_flow_imp.id(43436827954543047)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>100
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(44733283878522741)
,p_view_id=>wwv_flow_imp.id(134160644934572837)
,p_display_seq=>19
,p_column_id=>wwv_flow_imp.id(43436901675543048)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>93
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(44734189815522742)
,p_view_id=>wwv_flow_imp.id(134160644934572837)
,p_display_seq=>17
,p_column_id=>wwv_flow_imp.id(43437085844543049)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>70
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(44735060000522744)
,p_view_id=>wwv_flow_imp.id(134160644934572837)
,p_display_seq=>18
,p_column_id=>wwv_flow_imp.id(43437169072543050)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>70
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(134161183612572838)
,p_view_id=>wwv_flow_imp.id(134160644934572837)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(134150333457570805)
,p_is_visible=>false
,p_is_frozen=>false
,p_width=>40
,p_sort_order=>1
,p_sort_direction=>'ASC'
,p_sort_nulls=>'LAST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(134161629939572840)
,p_view_id=>wwv_flow_imp.id(134160644934572837)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(134150490913570806)
,p_is_visible=>false
,p_is_frozen=>false
,p_width=>65
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(134162165494572840)
,p_view_id=>wwv_flow_imp.id(134160644934572837)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(134150512565570807)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(134162665220572841)
,p_view_id=>wwv_flow_imp.id(134160644934572837)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(134150662152570808)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(134163134318572843)
,p_view_id=>wwv_flow_imp.id(134160644934572837)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(134150784663570809)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(134163617096572844)
,p_view_id=>wwv_flow_imp.id(134160644934572837)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(134150826305570810)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(134164192632572844)
,p_view_id=>wwv_flow_imp.id(134160644934572837)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(134150994521570811)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>100
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(134164634297572846)
,p_view_id=>wwv_flow_imp.id(134160644934572837)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(134151082980570812)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>100
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(134165131056572848)
,p_view_id=>wwv_flow_imp.id(134160644934572837)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(134151171154570813)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>70
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(134165654245572848)
,p_view_id=>wwv_flow_imp.id(134160644934572837)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(134151271293570814)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>100
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(134166140018572849)
,p_view_id=>wwv_flow_imp.id(134160644934572837)
,p_display_seq=>20
,p_column_id=>wwv_flow_imp.id(134151339884570815)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>100
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(134240428888018008)
,p_view_id=>wwv_flow_imp.id(134160644934572837)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(134153814987570840)
,p_is_visible=>true
,p_is_frozen=>true
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(134285204150470531)
,p_view_id=>wwv_flow_imp.id(134160644934572837)
,p_display_seq=>21
,p_column_id=>wwv_flow_imp.id(134267474559289107)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>10
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(285731433564022157)
,p_view_id=>wwv_flow_imp.id(134160644934572837)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(260170055162355608)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>100
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(314376304248052558)
,p_view_id=>wwv_flow_imp.id(134160644934572837)
,p_display_seq=>14
,p_column_id=>wwv_flow_imp.id(300484327023773217)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>100
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(134073737708252935)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Wizard--hideStepsXSmall:t-Form--noPadding'
,p_plug_template=>wwv_flow_imp.id(295640760127037692)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(134074297308252940)
,p_plug_name=>'&P139_TITULO.'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(257267687194638521)
,p_plug_name=>unistr('Informaci\00F3n de Pagos Recurrentes')
,p_parent_plug_id=>wwv_flow_imp.id(134074297308252940)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>80
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P139_RECURRENTE'
,p_plug_display_when_cond2=>'SI'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133924725861985533)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(133924695414985532)
,p_button_name=>'Atras'
,p_button_static_id=>'btnAtras'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Atras'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:137:&SESSION.::&DEBUG.:RP,::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(257267587797638520)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(133924695414985532)
,p_button_name=>'Responsable'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Responsable PR'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:217:&SESSION.::&DEBUG.:RP,217:P217_IDNEGOCIACION:&P139_ID_NEGOCIACION.'
,p_button_condition=>'P139_RECURRENTE'
,p_button_condition2=>'SI'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-user-arrow-up'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(94388199847893646)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(133924695414985532)
,p_button_name=>'NegPasadas'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Neg. Pasadas'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:143:&SESSION.::&DEBUG.:143:P143_NEG_ID_ACTUAL,P143_TIPO:&P139_ID_NEGOCIACION.,1'
,p_button_condition=>'P139_ID_NEGOCIACION'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa fa-file-archive-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(94388292611893647)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(133924695414985532)
,p_button_name=>'NegOtrosProveedores'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Neg. Otros Proveedores'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:143:&SESSION.::&DEBUG.:143:P143_NEG_ID_ACTUAL,P143_TIPO:&P139_ID_NEGOCIACION.,2'
,p_button_condition=>'P139_ID_NEGOCIACION'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-table-file'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(132269512054622531)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(133924695414985532)
,p_button_name=>'Formulas'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Formulas'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:148:&SESSION.::&DEBUG.:RP,148::'
,p_warn_on_unsaved_changes=>null
,p_confirm_message=>unistr('\00BFEst\00E1 seguro de cargar formulas?')
,p_confirm_style=>'warning'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-forms'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(59254042516950225)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(133924695414985532)
,p_button_name=>'Cargar_Indices'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Cargar Indices'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-list-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(133924864696985534)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(133924695414985532)
,p_button_name=>'Grabar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Grabar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P139_ES_EDICION'
,p_button_condition_type=>'ITEM_IS_NULL_OR_ZERO'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(134791088075704830)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(133924695414985532)
,p_button_name=>'Editar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Grabar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P139_ES_EDICION'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(139898859018798824)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_imp.id(133924695414985532)
,p_button_name=>'Eliminar'
,p_button_static_id=>'btnEliminar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Eliminar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_confirm_message=>unistr('\00BFEsta seguro de eliminar la negociaci\00F3n?')
,p_confirm_style=>'warning'
,p_button_condition=>'P139_ID_NEGOCIACION'
,p_button_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_icon_css_classes=>'fa-trash-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(143510621462026745)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_imp.id(133924695414985532)
,p_button_name=>'Evolucion'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>unistr('Evoluci\00F3n')
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:142:&SESSION.::&DEBUG.:RP,142:P142_ID_NEG,P142_PAGINA,P142_ID_DETALLE,P142_ID_NEG:&P139_ID_NEGOCIACION.,&APP_ID_PAGE.,0,&P139_ID_NEGOCIACION.'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-analytics'
,p_button_comment=>'SSC: P139_ID_NEGOCIACION is not null'
,p_updated_on=>wwv_flow_imp.dz('20260302044602Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(137372626435651932)
,p_button_sequence=>130
,p_button_plug_id=>wwv_flow_imp.id(133924695414985532)
,p_button_name=>'EnviarFlujo'
,p_button_static_id=>'btnValidar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar Flujo'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from data.vt_comp_negociaciondet ',
'where 1 = 1',
'	and neg_id = :p139_id_negociacion',
'	and neg_estadoflujo in (''CREACION'', ''RECHAZADO'') and det_id is not null'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-send'
,p_updated_on=>wwv_flow_imp.dz('20250827165212Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(135558904697707429)
,p_button_sequence=>140
,p_button_plug_id=>wwv_flow_imp.id(133924695414985532)
,p_button_name=>'Enviar'
,p_button_static_id=>'btnEnviar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enviar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:101:&SESSION.::&DEBUG.:RP,:G_MODULO,G_OBJETO,G_OBJETO_ID,G_USUARIO,G_TIPO1,G_COMENTARIO,G_PAGINA,G_OBJETO_DESCRIPCION,G_TIPO2:&APP_MODULO.,&P139_OBJETO.,&P139_IDOBJETO.,&P139_USUARIOFLUJO.,&P139_OBJETO.,&P139_OBJETO_DESCRIPCION.,COMPP138,&P139_OBJETO_DESCRIPCION.,&P139_TIPO2.'
,p_confirm_message=>unistr('\00BFEst\00E1 seguro de enviar a aprobaci\00F3n?')
,p_confirm_style=>'warning'
,p_icon_css_classes=>'fa-send'
,p_button_cattributes=>'style="display:none"'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(139898483693798820)
,p_branch_name=>'Goto 137'
,p_branch_action=>'f?p=&APP_ID.:137:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(139898859018798824)
,p_branch_sequence=>20
,p_branch_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_branch_condition=>'P139_BORRADO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43435362150543032)
,p_name=>'P139_USUARIO'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_prompt=>'Usuario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93623354058381844)
,p_name=>'P139_USUARIOFLUJO'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_prompt=>'Usuarioflujo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(132269803313622534)
,p_name=>'P139_PAGFORMULAS'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_prompt=>'Pagformulas'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(133925389958985539)
,p_name=>'P139_TIPO_NEGOCIACION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(134074297308252940)
,p_item_default=>'FJ'
,p_prompt=>unistr('Tipo Negociaci\00F3n:')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_NEG_TIPO'
,p_lov=>'SELECT VALOR D, ID_TABLA R FROM "DATA"."T_CORP_UDC" WHERE ACTIVO = 1 AND ID_CABECERA = ''COMP_NGTIP'';'
,p_cHeight=>1
,p_read_only_when=>'P139_ES_EDICION'
,p_read_only_when2=>'-1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(133925446271985540)
,p_name=>'P139_ESQUEMA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(134074297308252940)
,p_prompt=>'Tipo Esquema:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_NEG_ESQUEMA'
,p_lov=>'SELECT VALOR D, ID_TABLA R FROM "DATA"."T_CORP_UDC" WHERE ACTIVO = 1 AND ID_CABECERA = ''COMP_NGESQ'';'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_read_only_when=>'P139_ES_EDICION'
,p_read_only_when2=>'-1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(133925554363985541)
,p_name=>'P139_COD_ESQUEMA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(134074297308252940)
,p_prompt=>'Esquema:'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select D descripcion,R codigo from (',
'WITH',
'prd as (SELECT CODIGOPRODUCTO  || '' - '' ||  NOMBREPRODUCTO || '' ''|| CODIGOALTERNO  || '' - ['' ||  UNIDADCOMPRA || '']'' d  ,CODIGOCORTO r,  ''PD'' tipo FROM vt_jde_productos WHERE  :P139_ESQUEMA=''PD'' AND CODESTADO<>''O'' GROUP BY  CODIGOPRODUCTO || '' - '' ||'
||'  NOMBREPRODUCTO || '' ''|| CODIGOALTERNO     || '' - ['' ||  UNIDADCOMPRA || '']''  ,CODIGOCORTO ,NOMBREPRODUCTO order by NOMBREPRODUCTO ),',
'prv as (SELECT CODIGOPROVEEDOR || '' - '' ||  DESCRIPCION d, CODIGOPROVEEDOR r,  ''PV'' FROM  VT_JDE_MAESTROPROVEEDOR WHERE :P139_ESQUEMA=''PV'' and HABILITADO = ''SI'' GROUP BY CODIGOPROVEEDOR || '' - '' ||  DESCRIPCION , CODIGOPROVEEDOR , DESCRIPCION ORDER B'
||'Y DESCRIPCION)',
'select * from prd union all',
'select * from prv ',
')',
''))
,p_lov_cascade_parent_items=>'P139_ESQUEMA'
,p_ajax_items_to_submit=>'P139_ESQUEMA'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when=>'P139_ES_EDICION'
,p_read_only_when2=>'-1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_updated_on=>wwv_flow_imp.dz('20250529171122Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(133925607871985542)
,p_name=>'P139_VIGENCIA_DESDE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(134074297308252940)
,p_item_default=>'TRUNC(SYSDATE)'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Inicio de Vigencia:'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_read_only_when=>'P139_ES_EDICION'
,p_read_only_when2=>'-1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'STATIC'
,p_attribute_04=>'&P139_RANGOFECHA.'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON'
,p_attribute_13=>'HIDDEN'
,p_attribute_15=>'IMAGE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(133925743933985543)
,p_name=>'P139_VIGENCIA_HASTA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(134074297308252940)
,p_item_default=>'TRUNC(SYSDATE+1)'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fin de Hasta:'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_read_only_when=>'P139_ES_EDICION'
,p_read_only_when2=>'-1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'STATIC'
,p_attribute_04=>'+1d'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON'
,p_attribute_13=>'HIDDEN'
,p_attribute_15=>'IMAGE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134073623437252934)
,p_name=>'P139_PERIODICIDAD'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(257267687194638521)
,p_prompt=>'Periodicidad:'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_cattributes_element=>'width="15px"'
,p_tag_css_classes=>'PERIODICIDAD'
,p_display_when_type=>'NEVER'
,p_read_only_when=>'P139_ES_EDICION'
,p_read_only_when2=>'-1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'0'
,p_attribute_02=>'365'
,p_attribute_03=>'left'
,p_attribute_04=>'text'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134074351493252941)
,p_name=>'P139_ID_NEGOCIACION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_prompt=>'Id Negociacion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134151580182570817)
,p_name=>'P139_TITULO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_prompt=>'Titulo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134152487564570826)
,p_name=>'P139_FECHA_ACTUAL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_item_default=>'TRUNC(SYSDATE)'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Actual'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134655257295615740)
,p_name=>'P139_EDIT_NEGOCIACION'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_prompt=>'Edit Negociacion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134790753068704827)
,p_name=>'P139_ES_EDICION'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_prompt=>'Es Edicion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134791701401704837)
,p_name=>'P139_MENSAJE_ERROR'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_prompt=>'Mensaje Error'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134792142495704841)
,p_name=>'P139_ESQUEMA_ACT'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_prompt=>'Esquema Act'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134792252652704842)
,p_name=>'P139_COD_ESQUEMA_ACT'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_prompt=>'Cod Esquema Act'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(134792387551704843)
,p_name=>'P139_ELIMINA_DETALLE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_prompt=>'Elimina Detalle'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135397030394648823)
,p_name=>'P139_ID_CABECERA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_prompt=>'Id Cabecera'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135557812317707418)
,p_name=>'P139_GRABAR_CABECERA'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_prompt=>'Grabar Cabecera'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135559496463707434)
,p_name=>'P139_TERMINA_FLUJO'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_item_default=>'0'
,p_prompt=>'Termina Flujo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(135559592139707435)
,p_name=>'P139_ENVIO_EXITO'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_item_default=>'0'
,p_prompt=>'Envio Exito'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(137370897725651914)
,p_name=>'P139_RANGOFECHA'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_prompt=>'Rangofecha'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(137373091766651936)
,p_name=>'P139_VALIDAR'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_item_default=>'0'
,p_prompt=>'Validar'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(139255391599882842)
,p_name=>'P139_RECURRENTE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(134074297308252940)
,p_item_default=>'NO'
,p_prompt=>'Pago Recurrente:'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'SI'
,p_attribute_03=>'SI'
,p_attribute_04=>'NO'
,p_attribute_05=>'NO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(139898562452798821)
,p_name=>'P139_BORRADO'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_prompt=>'Borrado'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140079878198614943)
,p_name=>'P139_VACIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(134074297308252940)
,p_prompt=>'Vacio'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681811193037723)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140738265480225131)
,p_name=>'P139_OBSERVACION'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(134074297308252940)
,p_prompt=>unistr('Observaci\00F3n:')
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>3999
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'Y'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(145673629998365226)
,p_name=>'P139_MINDATE'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_prompt=>'Mindate'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(149734154056703444)
,p_name=>'P139_IDOBJETO'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_prompt=>'Idobjeto'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(149734218487703445)
,p_name=>'P139_OBJETO'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_prompt=>'Objeto'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(206430375629010941)
,p_name=>'P139_FRECUENCIA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(257267687194638521)
,p_prompt=>'Frecuencia:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_NEG_FRECUENCIA'
,p_lov=>'.'||wwv_flow_imp.id(230185465636915585)||'.'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(206430420555010942)
,p_name=>'P139_NUMEROPAGOS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(257267687194638521)
,p_prompt=>unistr('N\00FAm. Pagos:')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(231096597470534301)
,p_name=>'P139_TIPOPAGO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(257267687194638521)
,p_prompt=>'Tipo Pago:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_NEG_TIPOPAGO'
,p_lov=>'.'||wwv_flow_imp.id(231130202278619882)||'.'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(231096669813534302)
,p_name=>'P139_FECHAPRIMERPAGO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(257267687194638521)
,p_prompt=>'Primer Pago:'
,p_format_mask=>'dd/mm/yyyy'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'STATIC'
,p_attribute_04=>'&P139_LIMFECHAPRIMPAGO.'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(231097581439534311)
,p_name=>'P139_LIMFECHAPRIMPAGO'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_prompt=>'Limfechaprimpago'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(231098326563534319)
,p_name=>'P139_OBJETO_DESCRIPCION'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_prompt=>'Objeto Descripcion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(231098568783534321)
,p_name=>'P139_TIPO2'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_prompt=>'Tipo2'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(232463304458576543)
,p_name=>'P139_TIPOMONTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(257267687194638521)
,p_prompt=>'Tipo Monto:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_NEG_TIPOMONTO'
,p_lov=>'.'||wwv_flow_imp.id(240341499876606572)||'.'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(257267994493638524)
,p_name=>'P139_TIPORECEPCION'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(257267687194638521)
,p_prompt=>unistr('Tipo Recepci\00F3n:')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LOV_NEG_TIPORECEPCION'
,p_lov=>'.'||wwv_flow_imp.id(257467648715249911)||'.'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(260170428612355612)
,p_name=>'P139_COSTO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(257267687194638521)
,p_prompt=>'Costo'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P139_TIPOMONTO'
,p_display_when2=>'FJ'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(260170530419355613)
,p_name=>'P139_REQUISITOR'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(257267687194638521)
,p_prompt=>'Requisitor:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'select ''*'' from t_corp_udc a where :p139_recurrente = ''SI'' and a.id_cabecera = ''COMP_PRRSP'' and id_tabla = lpad(:p139_id_negociacion,5,''0'')'
,p_display_when_type=>'EXISTS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(301847251069681628)
,p_name=>'P139_EXISTE_CABECERA_RECURRENTE'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(134073737708252935)
,p_prompt=>'Existe Cabecera Recurrente'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(134152686536570828)
,p_validation_name=>'NO VACIO Esquema'
,p_validation_sequence=>10
,p_validation=>'P139_COD_ESQUEMA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(133924864696985534)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(134792490657704844)
,p_validation_name=>'NO VACIO Esquema_Edit'
,p_validation_sequence=>20
,p_validation=>'P139_COD_ESQUEMA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(134791088075704830)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(138497235799026943)
,p_validation_name=>'NO VACIO Tipo Esquema'
,p_validation_sequence=>30
,p_validation=>'P139_ESQUEMA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_when_button_pressed=>wwv_flow_imp.id(133924864696985534)
,p_associated_item=>wwv_flow_imp.id(133925446271985540)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(138497354922026944)
,p_validation_name=>'NO VACIO Tipo Esquema_Edit'
,p_validation_sequence=>40
,p_validation=>'P139_ESQUEMA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_when_button_pressed=>wwv_flow_imp.id(134791088075704830)
,p_associated_item=>wwv_flow_imp.id(133925446271985540)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(134152748168570829)
,p_validation_name=>'NO VACIO Periodicidad'
,p_validation_sequence=>50
,p_validation=>'P139_PERIODICIDAD'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_always_execute=>'Y'
,p_validation_condition=>'2 = 1 and :P139_RECURRENTE = ''SI'' AND :P139_ESQUEMA = ''PV'''
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(133924864696985534)
,p_associated_item=>wwv_flow_imp.id(134073623437252934)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(134792575994704845)
,p_validation_name=>'NO VACIO Periodicidad_Edit'
,p_validation_sequence=>60
,p_validation=>'P139_PERIODICIDAD'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_always_execute=>'Y'
,p_validation_condition=>'2 = 1 and :P139_RECURRENTE = ''SI'' AND :P139_ESQUEMA = ''PV'''
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(134791088075704830)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(206430618146010944)
,p_validation_name=>'NO VACIO Frecuencia'
,p_validation_sequence=>70
,p_validation=>'P139_FRECUENCIA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_always_execute=>'Y'
,p_validation_condition=>':P139_RECURRENTE = ''SI'' AND :P139_ESQUEMA = ''PV'''
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(133924864696985534)
,p_associated_item=>wwv_flow_imp.id(206430375629010941)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(206430789361010945)
,p_validation_name=>'NO VACIO Frecuencia Edit'
,p_validation_sequence=>80
,p_validation=>'P139_FRECUENCIA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_always_execute=>'Y'
,p_validation_condition=>':P139_RECURRENTE = ''SI'' AND :P139_ESQUEMA = ''PV'''
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(134791088075704830)
,p_associated_item=>wwv_flow_imp.id(206430375629010941)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(206430866913010946)
,p_validation_name=>unistr('NO VACIO N\00FAm. Pagos')
,p_validation_sequence=>90
,p_validation=>'P139_NUMEROPAGOS'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_always_execute=>'Y'
,p_validation_condition=>':P139_RECURRENTE = ''SI'' AND :P139_ESQUEMA = ''PV'''
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(133924864696985534)
,p_associated_item=>wwv_flow_imp.id(206430420555010942)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(206430973856010947)
,p_validation_name=>unistr('NO VACIO N\00FAm. Pagos Edit')
,p_validation_sequence=>100
,p_validation=>'P139_NUMEROPAGOS'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_always_execute=>'Y'
,p_validation_condition=>':P139_RECURRENTE = ''SI'' AND :P139_ESQUEMA = ''PV'''
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(134791088075704830)
,p_associated_item=>wwv_flow_imp.id(206430420555010942)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(231097132956534307)
,p_validation_name=>'NO VACIO Tipo Pago'
,p_validation_sequence=>120
,p_validation=>'P139_NUMEROPAGOS'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_always_execute=>'Y'
,p_validation_condition=>':P139_RECURRENTE = ''SI'' AND :P139_ESQUEMA = ''PV'''
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(133924864696985534)
,p_associated_item=>wwv_flow_imp.id(231096597470534301)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(231097220176534308)
,p_validation_name=>'NO VACIO Tipo Pago Edit'
,p_validation_sequence=>130
,p_validation=>'P139_NUMEROPAGOS'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_always_execute=>'Y'
,p_validation_condition=>':P139_RECURRENTE = ''SI'' AND :P139_ESQUEMA = ''PV'''
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(134791088075704830)
,p_associated_item=>wwv_flow_imp.id(231096597470534301)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(231097329468534309)
,p_validation_name=>'NO VACIO Primer Pago'
,p_validation_sequence=>140
,p_validation=>'P139_NUMEROPAGOS'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_always_execute=>'Y'
,p_validation_condition=>':P139_RECURRENTE = ''SI'' AND :P139_ESQUEMA = ''PV'''
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(133924864696985534)
,p_associated_item=>wwv_flow_imp.id(231096669813534302)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(231097454126534310)
,p_validation_name=>'NO VACIO Primer Pago Edit'
,p_validation_sequence=>160
,p_validation=>'P139_NUMEROPAGOS'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_always_execute=>'Y'
,p_validation_condition=>':P139_RECURRENTE = ''SI'' AND :P139_ESQUEMA = ''PV'''
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(134791088075704830)
,p_associated_item=>wwv_flow_imp.id(231096669813534302)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(244874765900010343)
,p_validation_name=>'NO VACIO Tipo Monto'
,p_validation_sequence=>170
,p_validation=>'P139_TIPOMONTO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_always_execute=>'Y'
,p_validation_condition=>':P139_RECURRENTE = ''SI'' AND :P139_ESQUEMA = ''PV'''
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(133924864696985534)
,p_associated_item=>wwv_flow_imp.id(232463304458576543)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(244874819288010344)
,p_validation_name=>'NO VACIO Tipo Monto Edit'
,p_validation_sequence=>180
,p_validation=>'P139_TIPOMONTO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_always_execute=>'Y'
,p_validation_condition=>':P139_RECURRENTE = ''SI'' AND :P139_ESQUEMA = ''PV'''
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(134791088075704830)
,p_associated_item=>wwv_flow_imp.id(232463304458576543)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(134152850912570830)
,p_validation_name=>'NO VACIO Vigencia Desde'
,p_validation_sequence=>200
,p_validation=>'P139_VIGENCIA_DESDE'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(133924864696985534)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(134792677236704846)
,p_validation_name=>'NO VACIO Vigencia Desde_Edit'
,p_validation_sequence=>210
,p_validation=>'P139_VIGENCIA_DESDE'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(134791088075704830)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(134152900698570831)
,p_validation_name=>'NO VACIO Vigencia Hasta'
,p_validation_sequence=>220
,p_validation=>'P139_VIGENCIA_HASTA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(133924864696985534)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(134792787448704847)
,p_validation_name=>'NO VACIO Vigencia Hasta_Edit'
,p_validation_sequence=>230
,p_validation=>'P139_VIGENCIA_HASTA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(134791088075704830)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(134510464372237227)
,p_validation_name=>'NO MAYOR Vigencia Hasta'
,p_validation_sequence=>240
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (trunc(to_date(:P139_VIGENCIA_DESDE))>trunc(to_date(:P139_VIGENCIA_HASTA))) then',
'    return ''Fechas de Vigencia incorrectas, Inicio de Vigencia no puede ser mayor a Fin de Vigencia '';   ',
'   end if;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(133924864696985534)
,p_associated_item=>wwv_flow_imp.id(133925607871985542)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(134792833420704848)
,p_validation_name=>'NO MAYOR Vigencia Hasta_Edit'
,p_validation_sequence=>250
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (trunc(to_date(:P139_VIGENCIA_DESDE))>trunc(to_date(:P139_VIGENCIA_HASTA))) then',
'    return ''Fechas de Vigencia incorrectas, Inicio de Vigencia  no puede ser mayor a Fin de Vigencia '';   ',
'   end if;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(134791088075704830)
,p_associated_item=>wwv_flow_imp.id(133925607871985542)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(137370942328651915)
,p_validation_name=>'NO MENOR Fecha Actual'
,p_validation_sequence=>260
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (trunc(to_date(:P139_VIGENCIA_DESDE))<trunc(SYSDATE)) then',
'    return ''Fechas de Vigencia incorrectas, Inicio de Vigencia no puede ser menor a Fecha Actual'';   ',
'   end if;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(133924864696985534)
,p_associated_item=>wwv_flow_imp.id(133925607871985542)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(137371072032651916)
,p_validation_name=>'NO MENOR Fecha Actual Edit'
,p_validation_sequence=>270
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (trunc(to_date(:P139_VIGENCIA_DESDE))<trunc(SYSDATE)) then',
'    return ''Fechas de Vigencia incorrectas, Inicio de Vigencia no puede ser menor a Fecha Actual'';   ',
'   end if;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(134791088075704830)
,p_associated_item=>wwv_flow_imp.id(133925607871985542)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(43436473753543043)
,p_validation_name=>'NO MENOR Fecha Inicio'
,p_validation_sequence=>280
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (trunc(to_date(:P139_VIGENCIA_HASTA))<=trunc(to_date(:P139_VIGENCIA_DESDE))) then',
'    return ''Fechas de Vigencia incorrectas,  Fin de Vigencia no puede ser menor/igual a Inicio de Vigencia'';   ',
'   end if;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(133924864696985534)
,p_associated_item=>wwv_flow_imp.id(133925607871985542)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(43436586669543044)
,p_validation_name=>'NO MENOR Fecha Inicio Edit'
,p_validation_sequence=>290
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (trunc(to_date(:P139_VIGENCIA_HASTA))<trunc(to_date(:P139_VIGENCIA_DESDE))) then',
'    return (''Fechas de Vigencia incorrectas,  Fin de Vigencia no puede ser menor a Inicio de Vigencia'');   ',
'end if;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(134791088075704830)
,p_associated_item=>wwv_flow_imp.id(133925607871985542)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(134154469066570846)
,p_tabular_form_region_id=>wwv_flow_imp.id(134073239089252930)
,p_validation_name=>'NO VACIO Col Escala'
,p_validation_sequence=>300
,p_validation=>'ESCALA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#COLUMN_HEADER# debe tener un valor.'
,p_validation_condition=>'P139_TIPO_NEGOCIACION'
,p_validation_condition2=>'ES'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_exec_cond_for_each_row=>'Y'
,p_associated_column=>'ESCALA'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(134154524091570847)
,p_tabular_form_region_id=>wwv_flow_imp.id(134073239089252930)
,p_validation_name=>'NO VACIO Col Tipo Precio'
,p_validation_sequence=>310
,p_validation=>'TIPOPRECIO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#COLUMN_HEADER# debe tener un valor.'
,p_associated_column=>'TIPOPRECIO'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(134154677342570848)
,p_tabular_form_region_id=>wwv_flow_imp.id(134073239089252930)
,p_validation_name=>'NO VACIO Col Formula'
,p_validation_sequence=>320
,p_validation=>'FORMULA'
,p_validation_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_error_message=>'#COLUMN_HEADER# debe tener un valor.'
,p_validation_condition=>'TIPOPRECIO'
,p_validation_condition2=>'FM'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_exec_cond_for_each_row=>'Y'
,p_associated_column=>'FORMULA'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(134266849412289101)
,p_tabular_form_region_id=>wwv_flow_imp.id(134073239089252930)
,p_validation_name=>'NO VACIO Col Acumula'
,p_validation_sequence=>330
,p_validation=>'ACUMULA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#COLUMN_HEADER# debe tener un valor.'
,p_validation_condition=>'P139_TIPO_NEGOCIACION'
,p_validation_condition2=>'ES'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_exec_cond_for_each_row=>'Y'
,p_associated_column=>'ACUMULA'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(231097686381534312)
,p_tabular_form_region_id=>wwv_flow_imp.id(134073239089252930)
,p_validation_name=>'NO VACIO Col Unidad Negocio'
,p_validation_sequence=>340
,p_validation=>'UNIDADNEGOCIO'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#COLUMN_HEADER# debe tener un valor.'
,p_validation_condition=>'P139_RECURRENTE'
,p_validation_condition2=>'SI'
,p_validation_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_exec_cond_for_each_row=>'Y'
,p_associated_column=>'UNIDADNEGOCIO'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(257268010287638525)
,p_validation_name=>unistr('NO VACIO Tipo Recepci\00F3n')
,p_validation_sequence=>350
,p_validation=>'P139_TIPORECEPCION'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_validation_condition=>':P139_RECURRENTE = ''SI'' AND :P139_ESQUEMA = ''PV'''
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(133924864696985534)
,p_associated_item=>wwv_flow_imp.id(257267994493638524)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(257268134073638526)
,p_validation_name=>unistr('NO VACIO Tipo Recepci\00F3n Edit')
,p_validation_sequence=>360
,p_validation=>'P139_TIPORECEPCION'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor.'
,p_validation_condition=>':P139_RECURRENTE = ''SI'' AND :P139_ESQUEMA = ''PV'''
,p_validation_condition2=>'PLSQL'
,p_validation_condition_type=>'EXPRESSION'
,p_when_button_pressed=>wwv_flow_imp.id(134791088075704830)
,p_associated_item=>wwv_flow_imp.id(257267994493638524)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(134153243069570834)
,p_name=>'Cambia Valor Recurrente'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P139_RECURRENCIA'
,p_condition_element=>'P139_RECURRENCIA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'SI'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(139255087346882839)
,p_event_id=>wwv_flow_imp.id(134153243069570834)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P139_PERIODICIDAD'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(139255275216882841)
,p_event_id=>wwv_flow_imp.id(134153243069570834)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P139_PERIODICIDAD'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(134154105565570843)
,p_name=>'Cambia Tipo Precio'
,p_event_sequence=>50
,p_triggering_element_type=>'COLUMN'
,p_triggering_region_id=>wwv_flow_imp.id(134073239089252930)
,p_triggering_element=>'TIPOPRECIO'
,p_condition_element_type=>'COLUMN'
,p_condition_element=>'TIPOPRECIO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'FM'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(134267298586289105)
,p_event_id=>wwv_flow_imp.id(134154105565570843)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'COLUMN'
,p_affected_elements=>'FORMULA'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(134154282528570844)
,p_event_id=>wwv_flow_imp.id(134154105565570843)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'COLUMN'
,p_affected_elements=>'FORMULA'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(134154390314570845)
,p_event_id=>wwv_flow_imp.id(134154105565570843)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'COLUMN'
,p_affected_elements=>'FORMULA'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(134791553160704835)
,p_name=>'Cambia_Esquema'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P139_ESQUEMA'
,p_condition_element=>'P139_ESQUEMA'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(134791918749704839)
,p_event_id=>wwv_flow_imp.id(134791553160704835)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    v_esquema_act varchar2(20);',
'    v_mensaje varchar2(200);',
'    v_contador number;',
'begin',
'    v_mensaje:='''';',
'    v_esquema_act:= :P139_ESQUEMA_ACT;',
'    select count(1) into v_contador',
'    from vt_comp_negociacionDET',
'    where 1=1',
'    and NEG_ID=:P139_ID_NEGOCIACION',
'    and NEG_ESTADOFLUJO in (''CREACION'', ''RECHAZADO'') AND DET_ID IS NOT NULL ;  ',
'    if (v_esquema_act <> :P139_ESQUEMA and  v_contador>0)then',
unistr('        v_mensaje:=''Con esta accion se borrar\00E1 todos los registros del detalle.\005Cn\00BFEst\00E1 seguro de cambiar el esquema de la negociaci\00F3n?'';'),
'    end if;    ',
'    :P139_MENSAJE_ERROR:=v_mensaje;    ',
'exception when others then ',
'     v_mensaje:='''';',
'     :P139_MENSAJE_ERROR:=v_mensaje;',
'end;',
''))
,p_attribute_02=>'P139_ID_NEGOCIACION,P139_MENSAJE_ERROR,P139_ESQUEMA'
,p_attribute_03=>'P139_MENSAJE_ERROR'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(134791815777704838)
,p_event_id=>wwv_flow_imp.id(134791553160704835)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'let msj= $v("P139_MENSAJE_ERROR");',
'if ( msj!=""){',
'    apex.message.confirm(msj, function( okPressed ) {',
'        if( okPressed ) {',
'            $s("P139_ELIMINA_DETALLE",''1'');',
'            $s("P139_COD_ESQUEMA","");',
'        } else {',
'            $s("P139_ELIMINA_DETALLE",''0'');',
'            $s("P139_ESQUEMA",$v("P139_ESQUEMA_ACT"));    ',
'            $s("P139_COD_ESQUEMA",$v("P139_COD_ESQUEMA_ACT"));',
'           ',
'        }',
'    });    ',
'}',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45204961777008038)
,p_event_id=>wwv_flow_imp.id(134791553160704835)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(134074297308252940)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(135396769984648820)
,p_name=>'CambioSeleccionCabecera'
,p_event_sequence=>70
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(134073239089252930)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.data.selectedRecords[0] != undefined'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(135396830307648821)
,p_event_id=>wwv_flow_imp.id(135396769984648820)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var value = this.data.selectedRecords[0][0];',
'//$s("P139_ID_CABECERA",value);',
'if(isNaN(value)){',
'	$s("P139_ID_CABECERA",0);',
' }else{',
'	$s("P139_ID_CABECERA",value);',
' }',
'apex.region("Detalle").refresh();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(135559031845707430)
,p_name=>unistr('Cierre di\00E1logo: env\00EDo flujo')
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(135558904697707429)
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'Number($v("P139_VALIDAR"))==0;'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(135559134559707431)
,p_event_id=>wwv_flow_imp.id(135559031845707430)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'console.log(trama);',
'console.log(isTerminoFlujo);',
'apex.item( "P139_TERMINA_FLUJO" ).setValue(0);',
'apex.item( "P139_ENVIO_EXITO" ).setValue(0);',
'console.log(this.data.G_EXITO);',
'if(this.data.G_EXITO==''true''){',
'     mensaje(''exito'', this.data.G_MENSAJE);',
'     apex.item("P139_ENVIO_EXITO" ).setValue(1);',
'    if(isTerminoFlujo){',
'        apex.item( "P139_TERMINA_FLUJO" ).setValue(1);',
'    }',
'}',
'else{ ',
'     mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(135559708103707437)
,p_event_id=>wwv_flow_imp.id(135559031845707430)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_valida	number;',
'v_estado	varchar2(20);',
'v_idneg		number;',
'begin',
'	v_idneg := :p139_id_negociacion;',
'	if :p139_envio_exito = 1 then ',
'		v_estado:=  case when :p139_termina_flujo = 1 then ''APROBADO'' else ''EN_PROCESO'' end;',
'		:p139_es_edicion := -1;',
'',
'		update t_comp_negociacion		set estadoflujo = v_estado, usuarioflujo = :p139_usuario where id = v_idneg;',
'',
'		update t_comp_negociacioncab	set estadoflujo = v_estado, usuarioflujo = :p139_usuario where idneg = v_idneg;',
'',
'		update t_comp_negociaciondet	set estadoflujo = v_estado, usuarioflujo = :p139_usuario where idcab in',
'			(select id from t_comp_negociacioncab where idneg = v_idneg);',
'	end if;',
'	commit;',
'end;'))
,p_attribute_02=>'P139_TERMINA_FLUJO,P139_ID_NEGOCIACION,P139_USUARIO,P139_ENVIO_EXITO'
,p_attribute_03=>'P139_ES_EDICION'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(137371218496651918)
,p_event_id=>wwv_flow_imp.id(135559031845707430)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v("P139_ENVIO_EXITO")==1){',
'    $(''#btnValidar'').hide();',
'    $(''#btnEnviar'').hide();',
'    $(''#btnAtras'').trigger("click");',
'} ',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(137372736073651933)
,p_name=>'Valida Envio Flujo'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(137372626435651932)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(149733408753703437)
,p_event_id=>wwv_flow_imp.id(137372736073651933)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra()'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(137373575707651941)
,p_event_id=>wwv_flow_imp.id(137372736073651933)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_valida varchar2(3999);',
'begin',
'	v_valida		:= '''';',
'	:p139_validar	:= v_valida;',
'',
'	select ''<ul>''||listagg(''<li>''||item||''</li>'') within group(order by id)||''</ul>''',
'	into v_valida',
'	from table (pk_commons.f_dividirtexto(pk_comp_negociacion.f_neg_validacioncompleta(:p139_id_negociacion),''|''));',
'',
'	v_valida:=REPLACE(v_valida,''<ul><li></li></ul>'','''');',
'',
'	if v_valida is not null then',
'		:p139_validar := v_valida;',
'	end if;',
'',
'	dbms_output.put_line(:p139_validar);',
'end;'))
,p_attribute_02=>'P139_ID_NEGOCIACION'
,p_attribute_03=>'P139_VALIDAR'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_stop_execution_on_error=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(137372961733651935)
,p_event_id=>wwv_flow_imp.id(137372736073651933)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P139_VALIDAR,P139_ENVIO_EXITO,P139_TERMINA_FLUJO'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'valida = $v("P139_VALIDAR");',
'if (valida==''''){',
'    $("#btnEnviar").trigger("click");',
'}',
'else {',
'    mensaje(''error'',valida);',
'}',
' $s("P139_VALIDAR","");',
'ocultarBarra();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(140638168766536203)
,p_name=>'Mostrar Periodicidad'
,p_event_sequence=>130
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P139_RECURRENTE'
,p_condition_element=>'P139_RECURRENTE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'SI'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_display_when_cond=>'P139_ID_NEGOCIACION'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(257267804076638523)
,p_event_id=>wwv_flow_imp.id(140638168766536203)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(257267687194638521)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140638248119536204)
,p_event_id=>wwv_flow_imp.id(140638168766536203)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(257267687194638521)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(139255495208882843)
,p_name=>'Cambia Recurrente'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P139_RECURRENTE'
,p_condition_element=>'P139_RECURRENTE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'SI'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140330815446969850)
,p_event_id=>wwv_flow_imp.id(139255495208882843)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update t_comp_negociacion set',
'	recurrente		= :p139_recurrente,',
'	frecuencia		= :p139_frecuencia,',
'	numeropagos		= :p139_numeropagos,',
'	fechaprimerpago	= :p139_fechaprimerpago,',
'	tipomonto		= :p139_tipomonto,',
'	tiporecepcion	= :p139_tiporecepcion',
'where id = :p139_id_negociacion;'))
,p_attribute_02=>'P139_RECURRENTE,P139_FRECUENCIA,P139_NUMEROPAGOS,P139_FECHAPRIMERPAGO,P139_TIPOMONTO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(260170273186355610)
,p_event_id=>wwv_flow_imp.id(139255495208882843)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update t_comp_negociacion set',
'	recurrente		= :p139_recurrente,',
'	frecuencia		= null,',
'	numeropagos		= null,',
'	fechaprimerpago	= null,',
'	tipomonto		= null,',
'	tiporecepcion	= null',
'where id = :p139_id_negociacion;'))
,p_attribute_02=>'P139_RECURRENTE,P139_FRECUENCIA,P139_NUMEROPAGOS,P139_FECHAPRIMERPAGO,P139_TIPOMONTO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(301846838317681624)
,p_event_id=>wwv_flow_imp.id(139255495208882843)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v("P139_EXISTE_CABECERA_RECURRENTE")!=0){',
'    var button = document.querySelector(".a-Button[data-action=''row-add-row'']");',
'    button.style.display = "none"; // To hide',
'}',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(301847071572681626)
,p_event_id=>wwv_flow_imp.id(139255495208882843)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var button = document.querySelector(".a-Button[data-action=''row-add-row'']");',
'button.style.display = "inline-block"; // To show',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140638039849536202)
,p_event_id=>wwv_flow_imp.id(139255495208882843)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(260170109831355609)
,p_event_id=>wwv_flow_imp.id(139255495208882843)
,p_event_result=>'FALSE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(139492576713021413)
,p_name=>'Cargar'
,p_event_sequence=>160
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_updated_on=>wwv_flow_imp.dz('20260714220457Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(139492635919021414)
,p_event_id=>wwv_flow_imp.id(139492576713021413)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P139_ENVIO_EXITO,P139_TERMINA_FLUJO'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(139492767726021415)
,p_event_id=>wwv_flow_imp.id(139492576713021413)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P139_VALIDAR'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'-1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(301847160373681627)
,p_event_id=>wwv_flow_imp.id(139492576713021413)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ($v("P139_EXISTE_CABECERA_RECURRENTE")!=0){',
'    var button = document.querySelector(".a-Button[data-action=''row-add-row'']");',
'    button.style.display = "none"; // To hide',
'}',
''))
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P139_RECURRENTE'
,p_client_condition_expression=>'SI'
,p_updated_on=>wwv_flow_imp.dz('20260714220457Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(140079990874614944)
,p_name=>'Cambiar_Esquema'
,p_event_sequence=>170
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P139_ESQUEMA'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'$v("P139_ID_NEGOCIACION")!="" && $v("P139_ESQUEMA")=="PV"'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140080049314614945)
,p_event_id=>wwv_flow_imp.id(140079990874614944)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P139_RECURRENTE,P139_PERIODICIDAD'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140080163065614946)
,p_event_id=>wwv_flow_imp.id(140079990874614944)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P139_RECURRENTE,P139_PERIODICIDAD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(140330560501969847)
,p_name=>'CambiaTipoNegociacion'
,p_event_sequence=>180
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P139_TIPO_NEGOCIACION'
,p_condition_element=>'P139_ID_NEGOCIACION'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140330732884969849)
,p_event_id=>wwv_flow_imp.id(140330560501969847)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'UPDATE t_comp_negociacion ',
'set TIPO=:P139_TIPO_NEGOCIACION',
'WHERE ID=:P139_ID_NEGOCIACION;',
'IF (:P139_TIPO_NEGOCIACION=''FJ'') THEN',
'    UPDATE t_comp_negociacioncab ',
'    set ESCALA=NULL, ACUMULA=NULL',
'    WHERE IDNEG=:P139_ID_NEGOCIACION;',
'end if;',
'UPDATE t_comp_negociaciondet',
'set   CANTDESDE=1, CANTHASTA=1',
'WHERE ID IN (SELECT DET_ID FROM VT_COMP_NEGOCIACION WHERE NEG_ID=:P139_ID_NEGOCIACION);',
''))
,p_attribute_02=>'P139_TIPO_NEGOCIACION,P139_ID_NEGOCIACION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(140330665382969848)
,p_event_id=>wwv_flow_imp.id(140330560501969847)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(45202406330008013)
,p_name=>'Cambia Tipo Tolerancia'
,p_event_sequence=>190
,p_triggering_element_type=>'COLUMN'
,p_triggering_region_id=>wwv_flow_imp.id(134073239089252930)
,p_triggering_element=>'TOLERANCIATIP'
,p_condition_element_type=>'COLUMN'
,p_condition_element=>'TOLERANCIATIP'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45202551521008014)
,p_event_id=>wwv_flow_imp.id(45202406330008013)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'COLUMN'
,p_affected_elements=>'TOLERANCIADSD,TOLERANCIAHST'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(45202659076008015)
,p_event_id=>wwv_flow_imp.id(45202406330008013)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'COLUMN'
,p_affected_elements=>'TOLERANCIADSD,TOLERANCIAHST'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(132268724262622523)
,p_name=>'RedireccionPagina'
,p_event_sequence=>200
,p_triggering_element_type=>'COLUMN'
,p_triggering_region_id=>wwv_flow_imp.id(134073239089252930)
,p_triggering_element=>'FORMULA'
,p_condition_element_type=>'COLUMN'
,p_condition_element=>'FORMULA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(132268861917622524)
,p_event_id=>wwv_flow_imp.id(132268724262622523)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var res = confirm("esta seguro de crear una formula");',
'console.log(res);',
'if(res){',
'    //mostrarBarra();',
'    var url;',
'    url = $v("P139_PAGFORMULAS");',
'    w = open(url,"winLov","Scrollbars=1,resizable=1,width=800,height=600");',
'    if (w.opener == null)',
'    w.opener = self;',
'    w.focus();',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(231096975079534305)
,p_name=>'Primer Pago'
,p_event_sequence=>210
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P139_FRECUENCIA'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_when_cond=>'P139_RECURRENTE'
,p_display_when_cond2=>'SI'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(231097035279534306)
,p_event_id=>wwv_flow_imp.id(231096975079534305)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_recurrente varchar2(5);',
'v_frecuencia varchar2(5);',
'v_desde date;',
'v_fecha date;',
'begin',
'	v_recurrente	:= nvl(:p139_recurrente,''NO'');',
'	v_desde			:= :p139_vigencia_desde;',
'	if v_recurrente = ''SI'' then',
'		v_frecuencia := nvl(:p139_frecuencia,''MN'');',
'',
'		case',
'			when v_frecuencia = ''SM'' then v_fecha := v_desde + 7;',
'			when v_frecuencia = ''QN'' then v_fecha := v_desde + 14;',
'			when v_frecuencia = ''MN'' then v_fecha := add_months(v_desde,1);',
'			when v_frecuencia = ''TR'' then v_fecha := add_months(v_desde,3);',
'			when v_frecuencia = ''ST'' then v_fecha := add_months(v_desde,6);',
'			when v_frecuencia = ''AN'' then v_fecha := add_months(v_desde,12);',
'			else v_fecha := v_desde;',
'		end case;',
'	else',
'		v_fecha := v_desde;',
'	end if;',
'	:p139_fechaprimerpago	:= v_fecha;',
'end;'))
,p_attribute_02=>'P139_VIGENCIA_DESDE,P139_RECURRENTE,P139_FRECUENCIA'
,p_attribute_03=>'P139_FECHAPRIMERPAGO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(301847405310681630)
,p_name=>'GrabarCabecera'
,p_event_sequence=>220
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(134073239089252930)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridsave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(301847532774681631)
,p_event_id=>wwv_flow_imp.id(301847405310681630)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(134793033941704850)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_idneg			number;',
'v_objeto_descripcion	varchar2(500);',
'begin',
'	:p139_es_edicion		:= 0;',
'	:p139_grabar_cabecera	:= 0;',
'	:p139_mensaje_error		:= null;',
'	:p139_validar			:= null;',
'	:p139_tipo2				:= null;',
'	:p139_usuario			:= :app_user;',
'	:p139_usuarioflujo		:= :app_user;',
'	:p139_edit_negociacion	:= :g_editnegociacion;',
'',
'	select apex_page.get_url(p_application=>130,p_page=>148) url into :p139_pagformulas from dual;',
'',
'	select decode(:g_idnegociacion,0,null,:g_idnegociacion) into :p139_id_negociacion from dual;',
'',
'	v_idneg			:= :p139_id_negociacion;',
'	:p139_idobjeto	:= to_number(v_idneg);',
'',
'	if v_idneg is not null and :p139_edit_negociacion = 1 then',
'		select tipo,esquema,codesquema',
'			, recurrente',
'			, periodicidad,frecuencia,numeropagos,tipopago,fechaprimerpago,tipomonto,tiporecepcion',
'			, vigenciadesde,vigenciahasta',
'			, esquema,codesquema,observacion',
'			, ''-''||to_number(to_char(sysdate,''dd'')-to_char(vigenciadesde,''dd''))||''d''',
'			, usercrea',
'		into :p139_tipo_negociacion,:p139_esquema,:p139_cod_esquema',
'			, :p139_recurrente',
'			, :p139_periodicidad,:p139_frecuencia,:p139_numeropagos,:p139_tipopago,:p139_fechaprimerpago,:p139_tipomonto,:p139_tiporecepcion',
'			, :p139_vigencia_desde,:p139_vigencia_hasta',
'			, :p139_esquema_act,:p139_cod_esquema_act,:p139_observacion',
'			, :p139_rangofecha',
'			, :p139_usuarioflujo',
'		from t_comp_negociacion n',
'		where id = v_idneg;',
'',
'		:p139_es_edicion := 1;',
'		:p139_limfechaprimpago	:= trunc(add_months(:p139_vigencia_desde,-1),''month'');',
'	else',
unistr('		:p139_titulo				:= ''Registro - Negociaci\00F3n'';    '),
'		:p139_id_negociacion		:= null;',
'		:p139_tipo_negociacion		:= null;',
'		:p139_esquema				:= null;',
'		:p139_cod_esquema			:= null;',
'		:p139_recurrente			:= null;',
'		:p139_periodicidad			:= null;',
'		:p139_vigencia_desde		:= null;',
'		:p139_vigencia_hasta		:= null;',
'		:p139_id_cabecera			:= null;',
'		:p139_edit_negociacion		:= null;',
'		:p139_es_edicion			:= null;',
'		:p139_mensaje_error			:= null;',
'		:p139_esquema_act			:= null;',
'		:p139_cod_esquema_act		:= null;',
'		:p139_elimina_detalle		:= null;',
'		:p139_observacion			:= null;',
'		:p139_rangofecha			:=''-0d'';',
'	end if;',
'',
'	select decode(nvl(:p139_recurrente,''NO''),''SI'',pk_comp_negociacion.f_neg_validarutaaprobacion(v_idneg),''NEGOCIACION'') into :p139_objeto from dual;',
'',
unistr('	v_objeto_descripcion := ''Negociaci\00F3n'';'),
'',
'	if nvl(:p139_recurrente,''NO'') = ''SI'' then',
'		v_objeto_descripcion	:= v_objeto_descripcion||'' de Pago Recurrente'';',
'		:p139_tipo2				:= ''CN'';',
'',
'		select to_char(sum(nvl(det_preciocal,0)),''FML999G999G999G999G990D00'') into :p139_costo',
'		from vt_comp_negociaciondet where neg_recurrente = ''SI'' and neg_tipomonto = ''FJ'' and neg_id = v_idneg;',
'        BEGIN',
'    		select trim(apellidos)||'' ''||trim(nombres) into :p139_requisitor',
'    		from t_corp_udc a inner join vt_corp_usuario b on a.valor = b.nombreusuario and a.id_cabecera = ''COMP_PRRSP''',
'    		where a.id_tabla = lpad(v_idneg,5,''0'') and rownum = 1;',
'        EXCEPTION WHEN OTHERS THEN ',
'            :p139_requisitor:=NULL;',
'        END;',
'	else',
'		:p139_tipo2 := data.pk_comp_negociacion.f_rutaaprobacion(:p139_id_negociacion);',
'	end if;',
'',
'	v_objeto_descripcion := v_objeto_descripcion||'' con vigencia entre ''||:p139_vigencia_desde||'' - ''||:p139_vigencia_hasta;',
'',
'	:p139_objeto_descripcion := v_objeto_descripcion;',
'',
'	if nvl(v_idneg,0) =0 then',
unistr('		:p139_titulo := ''Registro - Negociaci\00F3n'';'),
'	else',
'		if nvl(:p139_es_edicion,0) = 1 then',
unistr('			:p139_titulo := ''Registro - Negociaci\00F3n No. ''||v_idneg;'),
'		else',
unistr('			:p139_titulo := ''Registro - Negociaci\00F3n No. ''||v_idneg;'),
'		end if;',
'	end if;',
'',
'	:p139_mindate := sysdate;',
'    ',
'    :P139_EXISTE_CABECERA_RECURRENTE:=0;',
'',
'    IF (:P139_RECURRENTE=''SI'')THEN',
'        BEGIN',
'            select COUNT(DISTINCT 1)',
'            INTO :P139_EXISTE_CABECERA_RECURRENTE',
'            from t_comp_negociacioncab',
'            where idneg = :p139_id_negociacion;',
'        EXCEPTION WHEN OTHERS THEN',
'            :P139_EXISTE_CABECERA_RECURRENTE:=0;',
'        END;',
'    END IF;',
'--exception when others then null;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>134793033941704850
,p_updated_on=>wwv_flow_imp.dz('20250827165046Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(134151494848570816)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'InsertaNegociacion'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'v_usercrea			varchar2(20);',
'v_usermodi			varchar2(20);',
'v_tipo				varchar2(10);',
'v_esquema			varchar2(100);',
'v_codesquema		number;',
'v_recurrente		varchar2(50);',
'v_periodicidad		number;',
'v_vigenciadesde		date;',
'v_vigenciahasta		date;',
'v_observacion		varchar(3998);',
'v_mensaje			varchar2(250);',
'begin',
'	v_usercrea			:= :p139_usuario;',
'	v_usermodi			:= :p139_usuario;',
'	v_tipo				:= :p139_tipo_negociacion;',
'	v_esquema			:= :p139_esquema;',
'	v_codesquema		:= :p139_cod_esquema;',
'	v_recurrente		:= :p139_recurrente;',
'	v_periodicidad		:= case v_recurrente when ''NO'' then null else :p139_periodicidad end;',
'	v_vigenciadesde		:= :p139_vigencia_desde;',
'	v_vigenciahasta		:= :p139_vigencia_hasta;',
'	v_observacion		:= trim(:p139_observacion);',
'',
'	insert into t_comp_negociacion (id,usercrea,tipo,esquema,codesquema,recurrente,periodicidad,vigenciadesde,vigenciahasta,estadoflujo,observacion)',
'	values(null,v_usercrea,v_tipo,v_esquema,v_codesquema,v_recurrente,v_periodicidad,v_vigenciadesde,v_vigenciahasta,''CREACION'',v_observacion) returning id into :g_idnegociacion;',
'',
unistr('	apex_application.g_print_success_message :=''Se cre\00F3 la negociacion No. ''||:g_idnegociacion;'),
'',
unistr('	v_mensaje := ''Registro - Negociaci\00F3n No. ''||:g_idnegociacion;'),
'',
'	:p139_titulo := v_mensaje;',
'',
'	:g_editnegociacion		:= 1;',
'',
'	:p139_elimina_detalle	:= 0;',
'',
'	apex_application.g_print_success_message := v_mensaje;',
'',
'	exception when others then',
unistr('		v_mensaje := ''Ha ocurrido un error al registrar la negocociaci\00F3n.'';'),
'		apex_error.add_error (',
'			p_message			=> v_mensaje,',
'			p_display_location	=> apex_error.c_inline_in_notification',
'		);',
'end;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(133924864696985534)
,p_internal_uid=>134151494848570816
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(134791188736704831)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'EditarNegociacion'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'v_usercrea			varchar2(20);',
'v_usermodi			varchar2(20);',
'v_tipo				varchar2(10);',
'v_esquema			varchar2(100);',
'v_codesquema		number;',
'v_recurrente		varchar2(50);',
'v_periodicidad		number;',
'v_vigenciadesde		date;',
'v_vigenciahasta		date;',
'v_observacion		varchar(3998);',
'v_mensaje			varchar2(250);',
'v_idneg				number;',
'begin',
'	v_idneg				:= :p139_id_negociacion;',
'	v_usercrea			:= :p139_usuario;',
'	v_usermodi			:= :p139_usuario;',
'	v_tipo				:= :p139_tipo_negociacion;',
'	v_esquema			:= :p139_esquema;',
'	v_codesquema		:= :p139_cod_esquema;',
'	v_recurrente		:= :p139_recurrente;',
'	v_periodicidad		:= case v_recurrente when ''NO'' then null else :p139_periodicidad end;',
'	v_vigenciadesde		:= :p139_vigencia_desde;',
'	v_vigenciahasta		:= :p139_vigencia_hasta;',
'	v_observacion		:= trim(:p139_observacion);',
'',
'	update t_comp_negociacion',
'	set usermodi			= v_usermodi',
'		, tipo				= v_tipo',
'		, esquema			= v_esquema',
'		, codesquema		= v_codesquema',
'		, vigenciadesde		= v_vigenciadesde',
'		, vigenciahasta		= v_vigenciahasta',
'		, estadoflujo		= ''CREACION''',
'		, observacion		= v_observacion',
'		, recurrente		= v_recurrente',
'		, periodicidad		= v_periodicidad',
'		, tipomonto			= :p139_tipomonto',
'		, frecuencia		= :p139_frecuencia',
'		, numeropagos		= :p139_numeropagos',
'		, fechaprimerpago	= :p139_fechaprimerpago',
'		, tipopago			= :p139_tipopago',
'		, tiporecepcion		= :p139_tiporecepcion',
'	where id = v_idneg;',
'',
'	v_mensaje := ''Registro correcto.'';',
'',
'	if v_idneg is not null and :p139_elimina_detalle = 1 then',
'		delete from t_comp_negociaciondet where id in (',
'			select c.id  from t_comp_negociacion a ',
'			inner join t_comp_negociacioncab b  on a.id = b.idneg',
'			inner join t_comp_negociaciondet c  on b.id = c.idcab',
'			where a.id= :p139_id_negociacion',
'			);',
'',
unistr('		v_mensaje := v_mensaje||''\005CnSe elimin\00F3 los datos de los detalles.'';'),
'	end if;',
'',
'	apex_application.g_print_success_message := v_mensaje;',
'',
'	exception when others then',
unistr('	v_mensaje :=''Ha ocurrido un error al registrar la negociaci\00F3n.'';'),
'	apex_error.add_error(',
'	p_message			=> v_mensaje,',
'		p_display_location	=> apex_error.c_inline_in_notification);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(134791088075704830)
,p_internal_uid=>134791188736704831
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(139898320778798819)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'BorrarNegociacion'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	pk_comp_negociacion. sp_borrarnegociacion(',
'		:p139_id_negociacion',
'		, :p139_borrado',
'	);',
'',
'	if :p139_borrado > 0 then',
unistr('		apex_application.g_print_success_message := ''Se elimin\00F3 correctamente la negociaci\00F3n No. ''||:p139_id_negociacion;'),
'	else',
'		apex_error.add_error(',
unistr('			p_message			=> ''Error en eliminar la negociaci\00F3n. Comun\00EDquese con el administrador.'','),
'			p_display_location	=> apex_error.c_inline_in_notification ',
'		);',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(139898859018798824)
,p_internal_uid=>139898320778798819
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(134154092602570842)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(134073239089252930)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Cabecera - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_process_error_message=>'Error al almacenar datos'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P139_GRABAR_CABECERA'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'1'
,p_exec_cond_for_each_row=>'Y'
,p_process_success_message=>'Datos almacenados correctamente'
,p_internal_uid=>134154092602570842
);
wwv_flow_imp.component_end;
end;
/
