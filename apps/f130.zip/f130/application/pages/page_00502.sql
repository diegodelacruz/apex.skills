prompt --application/pages/page_00502
begin
--   Manifest
--     PAGE: 00502
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>502
,p_name=>'COMEX - dlg Anular/Rolear'
,p_alias=>'CMEX-DLG-ANULAR-ROLEAR'
,p_page_mode=>'MODAL'
,p_step_title=>'CMEX - Anular/Rolear'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_created_on=>wwv_flow_imp.dz('20240926171942Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240920163451Z')
,p_last_updated_by=>'DCUEVA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(295046862503102713)
,p_plug_name=>'ANULAR'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P502_ACCION'
,p_plug_display_when_cond2=>'ANULAR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(295046942262102714)
,p_plug_name=>'ROLEAR'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P502_ACCION'
,p_plug_display_when_cond2=>'ROLEAR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(295047118329102716)
,p_plug_name=>'Centro de costo'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P502_TIPO'
,p_plug_display_when_cond2=>'BOOKING'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(295236476621199603)
,p_plug_name=>'&P502_ACCION.  &P502_TIPO. Nro. &P502_BOOKING_ID.'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295639738305037692)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(295047614038102721)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(295046862503102713)
,p_button_name=>'ANULAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Anular'
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(295652231186943108)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(295046942262102714)
,p_button_name=>'ROLEAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Rolear'
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(295048502222102730)
,p_branch_name=>'Go To Page 500 ANULAR'
,p_branch_action=>'f?p=&APP_ID.:500:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(295047614038102721)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(295652105998943107)
,p_branch_name=>'Go To Page 500 ROLEAR'
,p_branch_action=>'f?p=&APP_ID.:500:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(295652231186943108)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295045931879102704)
,p_name=>'P502_ACCION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(295236476621199603)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295046081736102705)
,p_name=>'P502_BOOKING_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(295236476621199603)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295047031324102715)
,p_name=>'P502_MOTIVO_ANULADO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(295046862503102713)
,p_prompt=>'Motivo '
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    VALOR,',
'    ID_TABLA',
'FROM T_CORP_UDC',
'WHERE ID_CABECERA = ''CMEX_AR_MT'';'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295047348635102718)
,p_name=>'P502_CENTRO_COSTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(295047118329102716)
,p_prompt=>'Centro Costo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    DESCRIPCION,',
'    TRIM(UNIDADNEGOCIO) AS UNIDADNEGOCIO',
'FROM VT_JDE_UNIDADESNEGOCIO',
'ORDER BY DESCRIPCION;'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295047484752102719)
,p_name=>'P502_TIPO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(295236476621199603)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295047579168102720)
,p_name=>'P502_MOTIVO_ROLEADO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(295046942262102714)
,p_prompt=>'Motivo Roleo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    VALOR,',
'    ID_TABLA',
'FROM T_CORP_UDC',
'WHERE ID_CABECERA = ''CMEX_AR_MT'';'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(295652093638943106)
,p_name=>'P502_FECHA_PLAN_CARGUE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(295046942262102714)
,p_prompt=>'Fecha Plan Cargue'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(295048680295102731)
,p_validation_name=>'VALIDA_ANULAR'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P502_MOTIVO_ANULADO IS NULL THEN',
'    RETURN ''Debe selecionar un MOTIVO'';',
'END IF;',
'',
'IF :P502_TIPO = ''BOOKING'' AND :P502_CENTRO_COSTO IS NULL THEN',
'    RETURN ''Debe selecionar un CENTRO DE COSTO'';',
'END IF;',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(295047614038102721)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(295651990018943105)
,p_validation_name=>'VALIDA_ROLEAR'
,p_validation_sequence=>20
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P502_MOTIVO_ROLEADO IS NULL THEN',
'    RETURN ''Debe selecionar un MOTIVO'';',
'END IF;',
'',
'IF :P502_TIPO = ''BOOKING'' AND :P502_CENTRO_COSTO IS NULL THEN',
'    RETURN ''Debe selecionar un CENTRO DE COSTO'';',
'END IF;',
'',
'IF :P502_FECHA_PLAN_CARGUE IS NULL OR :P502_FECHA_PLAN_CARGUE < SYSDATE THEN',
'    RETURN ''Debe selecionar una FECHA PLAN CARGUE correcta'';',
'END IF;',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(295652231186943108)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(295047890106102723)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ANULAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_GESTIONBOOKING.SP_ANULAR(',
'    :P502_BOOKING_ID,',
'    :P502_MOTIVO_ANULADO,',
'    :P502_CENTRO_COSTO,',
'    :APP_USER',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(295047614038102721)
,p_internal_uid=>295047890106102723
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(295652394769943109)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ROLEAR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_GESTIONBOOKING.SP_ROLEAR(',
'    :P502_BOOKING_ID,',
'    :P502_MOTIVO_ROLEADO,',
'    :P502_CENTRO_COSTO,',
'    :P502_FECHA_PLAN_CARGUE,',
'    :APP_USER',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(295652231186943108)
,p_internal_uid=>295652394769943109
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(295047244118102717)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargar BOOKING'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    CENTRO_COSTO,',
'    MOTIVO_ANULADO,',
'    TIPO,',
'',
'    TO_CHAR(FECHA_PLAN_CARGUE, ''DD-MM-YYYY'')',
'INTO',
'    :P502_CENTRO_COSTO,',
'    :P502_MOTIVO_ANULADO,',
'    :P502_TIPO,',
'    ',
'    :P502_FECHA_PLAN_CARGUE',
'FROM',
'    T_CMEX_BOOKING',
'WHERE ID = :P502_BOOKING_ID;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>295047244118102717
);
wwv_flow_imp.component_end;
end;
/
