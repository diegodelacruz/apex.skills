prompt --application/pages/page_00109
begin
--   Manifest
--     PAGE: 00109
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>109
,p_name=>'SKUs Recibidos'
,p_step_title=>'SKUs Recibidos'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''.apex-rds'').data(''onRegionChange'', function(mode, activeTab) {',
'     apex.item( "P109_TIPO" ).setValue(activeTab.href);',
'    console.log(activeTab.href);',
'});',
'',
'$(secItems).hide();'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230719203312Z')
,p_last_updated_on=>wwv_flow_imp.dz('20230801154640Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(42138786056956540)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>50
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(136566994975245409)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(137336917521235506)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(138999907079347703)
,p_plug_name=>'SKUs Recibidos'
,p_region_name=>'rptImportaciones'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'flag,',
'txt01 TIP_TRNS,',
'pk_commons.f_jde2g(num01) FEC_TRNS,',
'txt04 ARTICULO_TRNS,',
'num02/10000 CANTIDAD_TRNS,',
'txt02 UM_TRNS,',
'num03/10000 COSTO_UNIT_TRNS,',
'num04/100 COSTO_TOTAL_TRNS,',
'',
'',
'',
'',
'num08 NUM_ORDEN_OI,',
'txt05 TIP_ORDEN_OI,',
'pk_commons.f_jde2g(num09) FEC_ORDEN_OI,',
'pk_commons.f_jde2g(num10) FEC_APROBACION_OI,',
'num11 COD_PROVEEDOR_OI,',
'num11 PROVEEDOR_OI,',
'num12/10000 CANT_POR_RECIBIR_OI,',
'num13/10000 COST_UNITARIO_OI,',
'num14/100 IMP_ORIG_SOLICITADO_OI,',
'pk_commons.f_jde2g(num15) FEC_ENTG_PROMETIDA_OI,',
'',
'',
'',
'',
'',
'',
'num20 NUM_ORDEN,',
'txt08 TIP_ORDEN,',
'pk_commons.f_jde2g(num22) FEC_ORDEN,',
'pk_commons.f_jde2g(num23) FEC_APROBACION,',
'num24 PROVEEDOR,',
'num24 NOMBRE_PROVEEDOR,',
'txt09 DESC_LINEA,',
'num25/10000 CANT_ORDENADA,',
'txt10 UM,',
'num26/10000 CANT_RECIBIDA,',
'num27/10000 CANT_POR_RECIBIR,',
'num28/10000 COST_UNITARIO,',
'num29/100 IMP_ORG_SOLICITADO,',
'txt11 INICIADOR_TRANSACCION,',
'num33 REQUISITOR,',
'num33 NOMBRE_REQUISITOR,',
'pk_commons.f_jde2g(num23) FEC_ING_REQUISICION,',
'pk_commons.f_jde2g(num31) FEC_ENT_PROMETIDA,',
'pk_commons.f_jde2g(num32) FEC_RECEPCION',
'',
'',
'from data.t_apex_temporal',
'where 1=1',
'AND control01= ''00001''',
'and control02=''COMP''',
'and control03=:APP_USER',
'and control04=''data.pk_comp_reportes.sp_skurecibidos''',
'AND :P109_BANDERA=1'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P109_FECHA_DESDE,P109_FECHA_HASTA,P109_TIPO,P109_BANDERA'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(139000005745347704)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>139000005745347704
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42608472638567815)
,p_db_column_name=>'TIP_TRNS'
,p_display_order=>10
,p_column_identifier=>'EV'
,p_column_label=>'Tip Trns'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42608580060567816)
,p_db_column_name=>'FEC_TRNS'
,p_display_order=>20
,p_column_identifier=>'EW'
,p_column_label=>'Fec. Trans.'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42608688592567817)
,p_db_column_name=>'ARTICULO_TRNS'
,p_display_order=>30
,p_column_identifier=>'EX'
,p_column_label=>unistr('C\00F3d. Producto')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42608785081567818)
,p_db_column_name=>'CANTIDAD_TRNS'
,p_display_order=>40
,p_column_identifier=>'EY'
,p_column_label=>'Cant. Trans.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42608847597567819)
,p_db_column_name=>'UM_TRNS'
,p_display_order=>50
,p_column_identifier=>'EZ'
,p_column_label=>'UM'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42608946060567820)
,p_db_column_name=>'COSTO_UNIT_TRNS'
,p_display_order=>60
,p_column_identifier=>'FA'
,p_column_label=>'Costo Unitario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42609002521567821)
,p_db_column_name=>'COSTO_TOTAL_TRNS'
,p_display_order=>70
,p_column_identifier=>'FB'
,p_column_label=>'Costo Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42609133378567822)
,p_db_column_name=>'NUM_ORDEN_OI'
,p_display_order=>80
,p_column_identifier=>'FC'
,p_column_label=>'Orden Compra'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42609254026567823)
,p_db_column_name=>'TIP_ORDEN_OI'
,p_display_order=>90
,p_column_identifier=>'FD'
,p_column_label=>'TOC'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42609347764567824)
,p_db_column_name=>'FEC_ORDEN_OI'
,p_display_order=>100
,p_column_identifier=>'FE'
,p_column_label=>'Fecha OC'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42609436018567825)
,p_db_column_name=>'FEC_APROBACION_OI'
,p_display_order=>110
,p_column_identifier=>'FF'
,p_column_label=>'Aprob. OC'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42609571653567826)
,p_db_column_name=>'PROVEEDOR_OI'
,p_display_order=>120
,p_column_identifier=>'FG'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42609728788567828)
,p_db_column_name=>'CANT_POR_RECIBIR_OI'
,p_display_order=>140
,p_column_identifier=>'FI'
,p_column_label=>'Cant. Pend.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42609820868567829)
,p_db_column_name=>'COST_UNITARIO_OI'
,p_display_order=>150
,p_column_identifier=>'FJ'
,p_column_label=>'Costo Unitario OC'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42609993682567830)
,p_db_column_name=>'IMP_ORIG_SOLICITADO_OI'
,p_display_order=>160
,p_column_identifier=>'FK'
,p_column_label=>'Imp .Sol. OC'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42610054392567831)
,p_db_column_name=>'FEC_ENTG_PROMETIDA_OI'
,p_display_order=>170
,p_column_identifier=>'FL'
,p_column_label=>'Ent. Prom.'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42610112354567832)
,p_db_column_name=>'NUM_ORDEN'
,p_display_order=>180
,p_column_identifier=>'FM'
,p_column_label=>'OC Original'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42610202919567833)
,p_db_column_name=>'TIP_ORDEN'
,p_display_order=>190
,p_column_identifier=>'FN'
,p_column_label=>'TOO'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42610365973567834)
,p_db_column_name=>'FEC_ORDEN'
,p_display_order=>200
,p_column_identifier=>'FO'
,p_column_label=>'Fecha OCO'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42610407267567835)
,p_db_column_name=>'FEC_APROBACION'
,p_display_order=>210
,p_column_identifier=>'FP'
,p_column_label=>'Aprob. OCO'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42610517507567836)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>220
,p_column_identifier=>'FQ'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42610625345567837)
,p_db_column_name=>'NOMBRE_PROVEEDOR'
,p_display_order=>230
,p_column_identifier=>'FR'
,p_column_label=>'Nombre Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42610882526567839)
,p_db_column_name=>'DESC_LINEA'
,p_display_order=>250
,p_column_identifier=>'FT'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42610958194567840)
,p_db_column_name=>'CANT_ORDENADA'
,p_display_order=>260
,p_column_identifier=>'FU'
,p_column_label=>'Cant. Ord.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42611037015567841)
,p_db_column_name=>'UM'
,p_display_order=>270
,p_column_identifier=>'FV'
,p_column_label=>'UM OC'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42611135828567842)
,p_db_column_name=>'CANT_RECIBIDA'
,p_display_order=>280
,p_column_identifier=>'FW'
,p_column_label=>'Cant. Rec.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42611221511567843)
,p_db_column_name=>'CANT_POR_RECIBIR'
,p_display_order=>290
,p_column_identifier=>'FX'
,p_column_label=>'Cant. Pend. OCO'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42611314327567844)
,p_db_column_name=>'COST_UNITARIO'
,p_display_order=>300
,p_column_identifier=>'FY'
,p_column_label=>'Costo Unitario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42611480385567845)
,p_db_column_name=>'IMP_ORG_SOLICITADO'
,p_display_order=>310
,p_column_identifier=>'FZ'
,p_column_label=>'Imp. sol. OCO'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42611572930567846)
,p_db_column_name=>'INICIADOR_TRANSACCION'
,p_display_order=>320
,p_column_identifier=>'GA'
,p_column_label=>'Iniciador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42611690940567847)
,p_db_column_name=>'REQUISITOR'
,p_display_order=>330
,p_column_identifier=>'GB'
,p_column_label=>'Requisitor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42611727630567848)
,p_db_column_name=>'NOMBRE_REQUISITOR'
,p_display_order=>340
,p_column_identifier=>'GC'
,p_column_label=>'Requisitor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42611837222567849)
,p_db_column_name=>'FEC_ING_REQUISICION'
,p_display_order=>350
,p_column_identifier=>'GD'
,p_column_label=>'Fecha RQ'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42611968390567850)
,p_db_column_name=>'FEC_ENT_PROMETIDA'
,p_display_order=>360
,p_column_identifier=>'GE'
,p_column_label=>'Ent.Prom.'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42646506961578801)
,p_db_column_name=>'FEC_RECEPCION'
,p_display_order=>370
,p_column_identifier=>'GF'
,p_column_label=>'Fecha Rec.'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42646848091578804)
,p_db_column_name=>'FLAG'
,p_display_order=>380
,p_column_identifier=>'GG'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43434815170543027)
,p_db_column_name=>'COD_PROVEEDOR_OI'
,p_display_order=>390
,p_column_identifier=>'GH'
,p_column_label=>unistr('C\00F3d. Proveedor')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(139069612212164837)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1390697'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'FLAG:FEC_TRNS:ARTICULO_TRNS:DESC_LINEA:CANTIDAD_TRNS:UM_TRNS:COSTO_UNIT_TRNS:COSTO_TOTAL_TRNS:NUM_ORDEN_OI:TIP_ORDEN_OI:FEC_ORDEN_OI:FEC_APROBACION_OI:CANT_POR_RECIBIR_OI:COST_UNITARIO_OI:IMP_ORIG_SOLICITADO_OI:FEC_ENTG_PROMETIDA_OI:NUM_ORDEN:TIP_ORD'
||'EN:FEC_ORDEN:FEC_APROBACION:PROVEEDOR_OI:COD_PROVEEDOR_OI:CANT_ORDENADA:UM:CANT_RECIBIDA:CANT_POR_RECIBIR:COST_UNITARIO:IMP_ORG_SOLICITADO:INICIADOR_TRANSACCION:NOMBRE_REQUISITOR:FEC_ING_REQUISICION:FEC_ENT_PROMETIDA:FEC_RECEPCION:'
,p_created_on=>wwv_flow_imp.dz('20230719203312Z')
,p_updated_on=>wwv_flow_imp.dz('20230719203312Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(137337138808235508)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(137336917521235506)
,p_button_name=>'Buscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42138578938956538)
,p_name=>'P109_PROVEEDOR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(136566994975245409)
,p_prompt=>'Proveedor'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CODIGOPROVEEDOR || '' - '' ||  DESCRIPCION d, CODIGOPROVEEDOR r FROM  VT_JDE_MAESTROPROVEEDOR  ',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'seleccione'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42138696885956539)
,p_name=>'P109_PRODUCTO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(136566994975245409)
,p_prompt=>'Producto'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CODIGOPRODUCTO  || '' - '' ||  NOMBREPRODUCTO  d  ,CODIGOCORTO r',
'FROM vt_jde_productos order by NOMBREPRODUCTO ',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'seleccione'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(42646605300578802)
,p_name=>'P109_USUARIO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(42138786056956540)
,p_prompt=>'Usuario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54825795321705409)
,p_name=>'P109_TIPO_ORDEN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(136566994975245409)
,p_prompt=>'Tipo Orden'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select  item D,item R from table(pk_commons.f_dividirtexto(''OI|CM|CN'',''|'')) ORDER BY 1 ;'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54825895546705410)
,p_name=>'P109_TIPO_ORDENORI'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(136566994975245409)
,p_prompt=>'Tipo Orden Original'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select  item D,item R from table(pk_commons.f_dividirtexto(''BM|BN|CE'',''|'')) ORDER BY 1 ;'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20230801154640Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136567070074245410)
,p_name=>'P109_FECHA_DESDE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(136566994975245409)
,p_item_default=>'trunc(add_months(sysdate,-1),''month'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Desde'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'+0d'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(136567264824245412)
,p_name=>'P109_FECHA_HASTA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(136566994975245409)
,p_item_default=>'trunc(sysdate)'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Hasta'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'+0d'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(138399592360690538)
,p_name=>'P109_BANDERA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(42138786056956540)
,p_prompt=>'Bandera'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(138999858855347702)
,p_name=>'P109_TIPO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(42138786056956540)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(43434973273543028)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P109_PROVEEDOR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43435023400543029)
,p_event_id=>wwv_flow_imp.id(43434973273543028)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P109_PRODUCTO'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(42646711036578803)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>':P109_USUARIO:=:app_user;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>42646711036578803
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(138399483637690537)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Buscar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    pk_comp_reportes. sp_skurecibidos(',
'                  :G_COMPANIA',
'                , :APP_USER',
'                , :P109_FECHA_DESDE		',
'                , :P109_FECHA_HASTA		',
'                , :P109_PROVEEDOR	',
'                , :P109_PRODUCTO	',
'                , :P109_TIPO_ORDEN',
'                , :P109_TIPO_ORDENORI',
'            );',
'    :P109_BANDERA:=1;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>138399483637690537
);
wwv_flow_imp.component_end;
end;
/
