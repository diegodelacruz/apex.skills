prompt --application/pages/page_00151
begin
--   Manifest
--     PAGE: 00151
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>151
,p_name=>'COMEX - Detalle'
,p_step_title=>'COMEX - Detalle'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function borrarArchivo( numeroArchivo ){',
'    ',
'    apex.item("P151_NUMEROARCHIVO_BORRAR").setValue(numeroArchivo);',
'    ',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20240830212053Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260721135912Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(73869791244721904)
,p_plug_name=>'&P151_DISPLAY_ET1.'
,p_region_name=>'ET1'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_region_attributes=>'class = "reg_etapa"'
,p_plug_template=>wwv_flow_imp.id(295619229174037679)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_item_display_point=>'BELOW'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74242343287161038)
,p_plug_name=>'Datos ET1'
,p_parent_plug_id=>wwv_flow_imp.id(73869791244721904)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(73869889750721905)
,p_plug_name=>'&P151_DISPLAY_ET2.'
,p_region_name=>'ET2'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_region_attributes=>'class = "reg_etapa"'
,p_plug_template=>wwv_flow_imp.id(295619229174037679)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61445853970698519)
,p_plug_name=>unistr('Notificaci\00F3nET2')
,p_parent_plug_id=>wwv_flow_imp.id(73869889750721905)
,p_region_template_options=>'#DEFAULT#:t-Form--slimPadding:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<span id = "archivosEstado" style="float:right;"> </span><br><span id = "contenedoresEstado" style="float:right;"></span>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(73871455363721921)
,p_plug_name=>'Datos Naviera'
,p_parent_plug_id=>wwv_flow_imp.id(73869889750721905)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74059712143884714)
,p_plug_name=>'Botones_ETAPA2'
,p_parent_plug_id=>wwv_flow_imp.id(73869889750721905)
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(73869942920721906)
,p_plug_name=>'&P151_DISPLAY_ET3.'
,p_region_name=>'ET3'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_region_attributes=>'class = "reg_etapa"'
,p_plug_template=>wwv_flow_imp.id(295619229174037679)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74681275853609804)
,p_plug_name=>'FormularioETAPA3'
,p_parent_plug_id=>wwv_flow_imp.id(73869942920721906)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74681374395609805)
,p_plug_name=>'BOTONES_ETAPA3'
,p_parent_plug_id=>wwv_flow_imp.id(73869942920721906)
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_display_condition_type=>'FUNCTION_BODY'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'/*',
'IF :P151_CODIGOETAPA = ''ET3'' THEN',
'        RETURN TRUE;',
'END IF;',
'*/',
'RETURN FALSE;',
'END;'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(73870039609721907)
,p_plug_name=>'Datos Generales'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(520045337200817235)
,p_name=>unistr('\00D3rdenes Vinculadas')
,p_parent_plug_id=>wwv_flow_imp.id(73870039609721907)
,p_template=>wwv_flow_imp.id(296120252599169164)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.*',
'from t_cmex_ordenesvinculadas a',
'where idmesa = :p151_id and ordenimp != :p151_ordenimportacion',
'order by a.id'))
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''x''',
'from t_cmex_ordenesvinculadas',
'where idmesa = :p151_id and ordenimp != :p151_ordenimportacion'))
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_created_on=>wwv_flow_imp.dz('20241128144144Z')
,p_updated_on=>wwv_flow_imp.dz('20241216200821Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(520045482747817236)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20241128144414Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(520045541225817237)
,p_query_column_id=>2
,p_column_alias=>'COMPANIA'
,p_column_display_sequence=>20
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20241128144414Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(520045672471817238)
,p_query_column_id=>3
,p_column_alias=>'IDMESA'
,p_column_display_sequence=>30
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20241128144414Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(520045722014817239)
,p_query_column_id=>4
,p_column_alias=>'ORDENIMP'
,p_column_display_sequence=>40
,p_column_heading=>'Orden Imp.'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20241128144414Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(520045815367817240)
,p_query_column_id=>5
,p_column_alias=>'ORDENORI'
,p_column_display_sequence=>50
,p_column_heading=>'Orden Orig.'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20241128144414Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(520045942496817241)
,p_query_column_id=>6
,p_column_alias=>'TIPOORIG'
,p_column_display_sequence=>60
,p_column_heading=>'Tipo OC'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20241128144414Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(520046094058817242)
,p_query_column_id=>7
,p_column_alias=>'CODPROVEEDOR'
,p_column_display_sequence=>70
,p_column_heading=>'Proveedor'
,p_use_as_row_header=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(185688337882482745)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20241128144414Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(520046155678817243)
,p_query_column_id=>8
,p_column_alias=>'NOTIFICADO'
,p_column_display_sequence=>80
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20241128144414Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(73870303341721910)
,p_plug_name=>unistr('Detalle Orden de Importaci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296122226350169167)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(73870533137721912)
,p_plug_name=>'Barra de accion'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74631575100117222)
,p_plug_name=>'Subir Archivos'
,p_region_name=>'DlgArchivos'
,p_region_template_options=>'js-dialog-autoheight:js-modal:js-draggable:js-resizable:js-dialog-size720x480'
,p_plug_template=>wwv_flow_imp.id(295627185797037684)
,p_plug_display_sequence=>70
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74630057935117207)
,p_plug_name=>'CargarArchivos'
,p_parent_plug_id=>wwv_flow_imp.id(74631575100117222)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74631689327117223)
,p_plug_name=>'BOTONES_ARCHIVOS'
,p_parent_plug_id=>wwv_flow_imp.id(74631575100117222)
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(74684528081609837)
,p_name=>'Listado de Archivos'
,p_region_name=>'DlgArchivos'
,p_parent_plug_id=>wwv_flow_imp.id(74631575100117222)
,p_template=>wwv_flow_imp.id(296120613521169165)
,p_display_sequence=>30
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_item_display_point=>'BELOW'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUMEROARCHIVO,',
'      dbms_lob.getlength(blobcontent) blobcontent,',
'       FILENAME,',
'       ID_TABLA,',
'       TIPO,',
'       OBSERVACION,',
'       FECHA,',
'       NOMBREUSUARIO,',
'       NUMEROARCHIVO AS BORRAR',
'  from FILES.T_APEX_ARCHIVOS',
'  WHERE ESTADO = ''1'' ',
'  AND TABLA = ''T_CMEX_MESATRABAJO''',
'  AND TIPO  IN (SELECT VALOR FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''CMEX_''|| :P151_CODIGOETAPA|| ''FI'' )  ',
'  AND ID_TABLA = :P151_ID;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P151_ID,P151_CODIGOETAPA'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74684832481609840)
,p_query_column_id=>1
,p_column_alias=>'NUMEROARCHIVO'
,p_column_display_sequence=>1
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:151:&SESSION.:APPLICATION_PROCESS=G_PROC_DESCARGARARCHIVO:&DEBUG.:RP:G_NUMEROARCHIVO:#NUMEROARCHIVO#'
,p_column_linktext=>'<span class="fa fa-download" aria-hidden="true"></span>'
,p_column_link_attr=>'target="_blank" download'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74684985047609841)
,p_query_column_id=>2
,p_column_alias=>'BLOBCONTENT'
,p_column_display_sequence=>2
,p_column_heading=>'Descargar'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment:Descargar:FILES'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74685024078609842)
,p_query_column_id=>3
,p_column_alias=>'FILENAME'
,p_column_display_sequence=>3
,p_column_heading=>'Nombre'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74685195158609843)
,p_query_column_id=>4
,p_column_alias=>'ID_TABLA'
,p_column_display_sequence=>4
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74685290555609844)
,p_query_column_id=>5
,p_column_alias=>'TIPO'
,p_column_display_sequence=>5
,p_column_heading=>'Tipo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION, VALOR FROM DATA.T_CORP_UDC',
'WHERE ID_CABECERA = ''CMEX_''|| :P151_CODIGOETAPA ||''FI'''))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74685394213609845)
,p_query_column_id=>6
,p_column_alias=>'OBSERVACION'
,p_column_display_sequence=>6
,p_column_heading=>unistr('Observaci\00F3n')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74685421090609846)
,p_query_column_id=>7
,p_column_alias=>'FECHA'
,p_column_display_sequence=>7
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74685518057609847)
,p_query_column_id=>8
,p_column_alias=>'NOMBREUSUARIO'
,p_column_display_sequence=>8
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74685681121609848)
,p_query_column_id=>9
,p_column_alias=>'BORRAR'
,p_column_display_sequence=>9
,p_column_heading=>'Borrar'
,p_use_as_row_header=>'N'
,p_column_link=>'javascript:borrarArchivo(#BORRAR#)'
,p_column_linktext=>'<span title="Eliminar" class="fa fa-trash"/>'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74631716426117224)
,p_plug_name=>'Visualizar Archivos'
,p_region_name=>'DlgArchivosVer'
,p_region_template_options=>'js-dialog-autoheight:js-modal:js-draggable:js-resizable:js-dialog-size720x480'
,p_plug_template=>wwv_flow_imp.id(295627185797037684)
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(74631878441117225)
,p_name=>'Listado de Archivos'
,p_parent_plug_id=>wwv_flow_imp.id(74631716426117224)
,p_template=>wwv_flow_imp.id(296120613521169165)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_item_display_point=>'BELOW'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUMEROARCHIVO,',
'      dbms_lob.getlength(blobcontent) blobcontent,',
'       FILENAME,',
'       ID_TABLA,',
'       TIPO,',
'       OBSERVACION,',
'       FECHA,',
'       NOMBREUSUARIO,',
'       NUMEROARCHIVO AS BORRAR',
'  from FILES.T_APEX_ARCHIVOS',
'  WHERE ESTADO = ''1'' ',
'  AND TABLA = ''T_CMEX_MESATRABAJO''',
'  AND TIPO  IN (SELECT VALOR FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''CMEX_''|| :P151_ETAPA_ANTERIOR|| ''FI'' )  ',
'  AND ID_TABLA = :P151_ID;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P151_ID,P151_ETAPA_ANTERIOR'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'No se encontraron datos'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74632041597117227)
,p_query_column_id=>1
,p_column_alias=>'NUMEROARCHIVO'
,p_column_display_sequence=>1
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:151:&SESSION.:APPLICATION_PROCESS=G_PROC_DESCARGARARCHIVO:&DEBUG.:RP:G_NUMEROARCHIVO:#NUMEROARCHIVO#'
,p_column_linktext=>'<span class="fa fa-download" aria-hidden="true"></span>'
,p_column_link_attr=>'target="_blank" download'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74632138407117228)
,p_query_column_id=>2
,p_column_alias=>'BLOBCONTENT'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74632218267117229)
,p_query_column_id=>3
,p_column_alias=>'FILENAME'
,p_column_display_sequence=>3
,p_column_heading=>'Nombre'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74632382739117230)
,p_query_column_id=>4
,p_column_alias=>'ID_TABLA'
,p_column_display_sequence=>4
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74632455733117231)
,p_query_column_id=>5
,p_column_alias=>'TIPO'
,p_column_display_sequence=>5
,p_column_heading=>'Tipo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION, VALOR FROM DATA.T_CORP_UDC',
'WHERE ID_CABECERA = ''CMEX_''|| :P151_ETAPA_ANTERIOR ||''FI'''))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74632598167117232)
,p_query_column_id=>6
,p_column_alias=>'OBSERVACION'
,p_column_display_sequence=>6
,p_column_heading=>unistr('Observaci\00F3n')
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74632651858117233)
,p_query_column_id=>7
,p_column_alias=>'FECHA'
,p_column_display_sequence=>7
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74632755227117234)
,p_query_column_id=>8
,p_column_alias=>'NOMBREUSUARIO'
,p_column_display_sequence=>8
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(74632865027117235)
,p_query_column_id=>9
,p_column_alias=>'BORRAR'
,p_column_display_sequence=>9
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74632946475117236)
,p_plug_name=>'Parametros'
,p_parent_plug_id=>wwv_flow_imp.id(74631716426117224)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_region_attributes=>'style="display:none;"'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74683045182609822)
,p_plug_name=>'&P151_DISPLAY_ET4.'
,p_region_name=>'ET4'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_region_attributes=>'class = "reg_etapa"'
,p_plug_template=>wwv_flow_imp.id(295619229174037679)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61445919584698520)
,p_plug_name=>unistr('Notificaci\00F3nET4')
,p_parent_plug_id=>wwv_flow_imp.id(74683045182609822)
,p_region_template_options=>'#DEFAULT#:t-Form--slimPadding:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>'<span id = "archivosEstadoET4" style="float:right;"> </span>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74683145984609823)
,p_plug_name=>'Botones_etapa4'
,p_parent_plug_id=>wwv_flow_imp.id(74683045182609822)
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74683260578609824)
,p_plug_name=>'FormularioEtapa4'
,p_parent_plug_id=>wwv_flow_imp.id(74683045182609822)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(75666845427913606)
,p_plug_name=>'Contenedores'
,p_region_name=>'DlgContenedoresVer'
,p_region_template_options=>'js-dialog-autoheight:js-modal:js-draggable:js-resizable:js-dialog-size720x480'
,p_plug_template=>wwv_flow_imp.id(295627185797037684)
,p_plug_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(75666994017913607)
,p_name=>'Contenedores'
,p_parent_plug_id=>wwv_flow_imp.id(75666845427913606)
,p_template=>wwv_flow_imp.id(296121421643169165)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'TABLE'
,p_query_table=>'T_CMEX_DETALLECONTENEDOR'
,p_query_where=>'ID_CMEX_MESATRABAJO = :P151_ID'
,p_include_rowid_column=>false
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P151_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_report_total_text_format=>'Peso Total'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(75667015125913608)
,p_query_column_id=>1
,p_column_alias=>'NRO_CONTENEDOR'
,p_column_display_sequence=>1
,p_column_heading=>unistr('N\00FAm. Contenedor')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_default_sort_column_sequence=>1
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(75667102120913609)
,p_query_column_id=>2
,p_column_alias=>'ID_CMEX_MESATRABAJO'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(75667286007913610)
,p_query_column_id=>3
,p_column_alias=>'PESONETO'
,p_column_display_sequence=>3
,p_column_heading=>'Peso Neto kg'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(75667323702913611)
,p_query_column_id=>4
,p_column_alias=>'PESOBRUTO'
,p_column_display_sequence=>4
,p_column_heading=>'Peso Bruto kg'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(75667495121913612)
,p_query_column_id=>5
,p_column_alias=>'PRIORITARIO'
,p_column_display_sequence=>5
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(75667579042913613)
,p_query_column_id=>6
,p_column_alias=>'TAMANOCONTENEDOR'
,p_column_display_sequence=>6
,p_column_heading=>unistr('Tama\00F1o Contenedor')
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(75668376162913621)
,p_plug_name=>'&P151_DISPLAY_ET5.'
,p_region_name=>'ET5'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_region_attributes=>'class = "reg_etapa"'
,p_plug_template=>wwv_flow_imp.id(295619229174037679)
,p_plug_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_header=>'<div style ="color: red;">Este campo se actualiza al momento que se registran los contenedores en planta</div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(76571958877781323)
,p_plug_name=>'&P151_DISPLAY_ET6.'
,p_region_name=>'ET6'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_region_attributes=>'class = "reg_etapa"'
,p_plug_template=>wwv_flow_imp.id(295619229174037679)
,p_plug_display_sequence=>110
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(93115418934453150)
,p_name=>'Listado Costos'
,p_parent_plug_id=>wwv_flow_imp.id(76571958877781323)
,p_template=>wwv_flow_imp.id(296120613521169165)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'TABLE'
,p_query_table=>'T_CMEX_PROVISION_DETALLE'
,p_query_where=>'ID_CABECERA = (SELECT ID FROM T_CMEX_PROVISION WHERE ID_CMEX_MESATRABAJO = :P151_ID)'
,p_include_rowid_column=>false
,p_display_when_condition=>'select 1 from t_cmex_provision_detalle where id_cabecera = (select id from t_cmex_provision where id_cmex_mesatrabajo = :p151_id);'
,p_display_condition_type=>'EXISTS'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Descargar'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(94269963045663801)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(94270099203663802)
,p_query_column_id=>2
,p_column_alias=>'ID_CABECERA'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(94270166706663803)
,p_query_column_id=>3
,p_column_alias=>'CONCEPTO'
,p_column_display_sequence=>3
,p_column_heading=>'Concepto'
,p_use_as_row_header=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(93018914532751121)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(94270278086663804)
,p_query_column_id=>4
,p_column_alias=>'MONTOPROVISION'
,p_column_display_sequence=>4
,p_column_heading=>'Monto'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(94270387119663805)
,p_query_column_id=>5
,p_column_alias=>'MONTOREAL'
,p_column_display_sequence=>5
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(94270410245663806)
,p_query_column_id=>6
,p_column_alias=>'MONTOESTANDAR'
,p_column_display_sequence=>6
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(76572010425781324)
,p_plug_name=>'&P151_DISPLAY_ET7.'
,p_region_name=>'ET7'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_region_attributes=>'class = "reg_etapa"'
,p_plug_template=>wwv_flow_imp.id(295619229174037679)
,p_plug_display_sequence=>120
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(76572110476781325)
,p_plug_name=>'&P151_DISPLAY_ET8.'
,p_region_name=>'ET8'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_region_attributes=>'class = "reg_etapa"'
,p_plug_template=>wwv_flow_imp.id(295619229174037679)
,p_plug_display_sequence=>130
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(93115033625453146)
,p_plug_name=>'AccionesFase8'
,p_parent_plug_id=>wwv_flow_imp.id(76572110476781325)
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(94270556400663807)
,p_plug_name=>'Mensaje'
,p_parent_plug_id=>wwv_flow_imp.id(76572110476781325)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>unistr('<div id = "mensajeET8" >Debe subir el archivo y presionar el bot\00F3n Guardar en la barra de acciones de la secci\00F3n para continuar con el proceso.</div>')
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(76572849141781332)
,p_plug_name=>'Parametros Etapas'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_region_attributes=>'style = "display : none;"'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(94271196688663813)
,p_plug_name=>'&P151_DISPLAY_ET9.'
,p_region_name=>'ET9'
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(295619229174037679)
,p_plug_display_sequence=>140
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(94272972723663831)
,p_plug_name=>'Bitacora'
,p_region_name=>'DlgBitacoras'
,p_region_template_options=>'#DEFAULT#:js-dialog-size480x320'
,p_plug_template=>wwv_flow_imp.id(295627185797037684)
,p_plug_display_sequence=>150
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'Y',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61446019037698521)
,p_plug_name=>unistr('Notificaci\00F3nBT')
,p_region_name=>'bitacorafecha'
,p_parent_plug_id=>wwv_flow_imp.id(94272972723663831)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295608822663037671)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(61445381061698514)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(74059712143884714)
,p_button_name=>'NOTIFICARAGENTE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Notificar Agente'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P151_CODIGOETAPA'
,p_button_condition2=>'ET2'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-users-chat'
,p_updated_on=>wwv_flow_imp.dz('20241127161224Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(73870768674721914)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(73870533137721912)
,p_button_name=>'REGRESAR'
,p_button_static_id=>'btnAtras'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:176:&SESSION.::&DEBUG.:RP::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74060379048884720)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(74059712143884714)
,p_button_name=>'AGREGAR_DATOS_CONTENEDORES'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Agregar Datos Contenedores'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:152:&SESSION.::&DEBUG.:RP,152:P152_ID_MESATRABAJO:&P151_ID.'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    IF :P151_CODIGOETAPA != ''ET9'' AND (:P151_CNT20PIES > 0 OR :P151_CNT40PIES > 0) THEN',
'        RETURN TRUE;',
'    END IF;',
'',
'    RETURN FALSE;',
'END;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-plus'
,p_updated_on=>wwv_flow_imp.dz('20241127161224Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74630857480117215)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(74631689327117223)
,p_button_name=>'SUBIR_ARCHIVO_GENERAL'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Subir Archivo'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74682870667609820)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(74681374395609805)
,p_button_name=>'GUARDAR_ETAPA3'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Guardar Etapa 3'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'/*',
'IF :P151_CODIGOETAPA = ''ET3'' THEN',
'        RETURN TRUE;',
'END IF;',
'*/',
'RETURN FALSE;',
'END;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(75666594933913603)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(74683145984609823)
,p_button_name=>'VER_ARCHIVOS_ETAPA_4'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Ver Archivos Etapa'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  V_CONTARCHVIOS NUMBER :=0;',
'BEGIN',
'    BEGIN',
'       SELECT COUNT(*) INTO V_CONTARCHVIOS',
'       FROM  FILES.T_APEX_ARCHIVOS',
'       WHERE ESTADO = ''1'' ',
'       AND TABLA = ''T_CMEX_MESATRABAJO''',
'       AND TIPO  IN (SELECT VALOR FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''CMEX_''|| :P151_CODIGOETAPA|| ''FI'' ',
'                     AND VALOR2=''U'')  ',
'       AND ID_TABLA = :P151_ID;      ',
'      EXCEPTION WHEN NO_DATA_FOUND THEN  V_CONTARCHVIOS:=0;',
'    END;',
'',
'    IF :P151_CODIGOETAPA = ''ET4'' AND :P151_ID_MUESTRA IS NOT NULL AND NVL(V_CONTARCHVIOS,0) =2 THEN',
'        RETURN TRUE;',
'      ELSE',
'        RETURN FALSE;',
'    END IF;',
'END;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-eye'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(93115199782453147)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(93115033625453146)
,p_button_name=>'AGREGAR_ARCHIVOS_F8'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Agregar Archivos F8'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:openModal(''DlgArchivos'');'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-file-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(187248509329684734)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(76571958877781323)
,p_button_name=>unistr('Requisici\00F3n')
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>unistr('Ver Requisici\00F3n')
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:237:&SESSION.::&DEBUG.::P237_ID_MESATRABAJO:&P151_ID.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74684287423609834)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(74683145984609823)
,p_button_name=>'GUARDAR_ETAPA4'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Guardar Etapa 4'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'/*',
'IF :P151_CODIGOETAPA = ''ET4'' THEN',
'        RETURN TRUE;',
'END IF;',
'*/',
'RETURN FALSE;',
'END;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(93115264057453148)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(93115033625453146)
,p_button_name=>'VER_ARCHIVOS_ET8'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Ver Archivos'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:$s(''P151_ETAPA_ANTERIOR'',"ET8");openModal(''DlgArchivosVer'');'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-eye'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(250537826784615249)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(73870533137721912)
,p_button_name=>'ARCHIVOS'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Cargar Archivos'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:190:&SESSION.::&DEBUG.:190:P190_FLAG1,P190_IDMESA,P190_IDETAPA,P190_IDMUESTRA:A,&P151_ID.,&P151_CODIGOETAPA.,&P151_ID_MUESTRA.'
,p_icon_css_classes=>'fa-file-pdf-o'
,p_updated_on=>wwv_flow_imp.dz('20240902212522Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74060987721884726)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(74059712143884714)
,p_button_name=>'Cargar_Archivos'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Cargar Archivos'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'',
'    IF :P151_CODIGOETAPA = ''ET2'' THEN',
'        RETURN TRUE;',
'      ELSE',
'        RETURN FALSE;',
'    END IF;    ',
'END;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-file-plus'
,p_updated_on=>wwv_flow_imp.dz('20241127161224Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74684426621609836)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(74683145984609823)
,p_button_name=>'Agregar_Archivos'
,p_button_static_id=>'agregarArchivosET4'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Agregar Archivos'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  V_CONTARCHVIOS NUMBER :=0;',
'BEGIN',
'    BEGIN',
'       SELECT COUNT(*) INTO V_CONTARCHVIOS',
'       FROM  FILES.T_APEX_ARCHIVOS',
'       WHERE ESTADO = ''1'' ',
'       AND TABLA = ''T_CMEX_MESATRABAJO''',
'       AND TIPO  IN (SELECT VALOR FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''CMEX_''|| :P151_CODIGOETAPA|| ''FI'' ',
'                     AND VALOR2=''U'')  ',
'       AND ID_TABLA = :P151_ID;      ',
'      EXCEPTION WHEN NO_DATA_FOUND THEN  V_CONTARCHVIOS:=0;',
'    END;',
'',
'    IF :P151_CODIGOETAPA = ''ET4'' AND :P151_ID_MUESTRA IS NOT NULL AND NVL(V_CONTARCHVIOS,0) <>2 THEN',
'        RETURN TRUE;',
'      ELSE',
'        RETURN FALSE;',
'    END IF;',
'END;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-file-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(79531274746966443)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(73870533137721912)
,p_button_name=>'VINCULAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Vincular OI'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:169:&SESSION.::&DEBUG.:RP,169:P169_IDMESA,P169_ORDENIMP:&P151_ID.,&P151_ORDENIMPORTACION.'
,p_button_condition=>':P151_CODIGOETAPA = ''ET2'''
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-server-plus'
,p_updated_on=>wwv_flow_imp.dz('20241216194928Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(94271091396663812)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(93115033625453146)
,p_button_name=>'FINALIZAR_ETAPA8'
,p_button_static_id=>'FINALIZAR_ETAPA8'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'select ''x'' from dual where pk_cmex_mesatrabajo.f_verificaarchivos(:p151_id,:p151_codigoetapa) = 1'
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74633109785117238)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(74059712143884714)
,p_button_name=>'VER_ARCHIVOS_ETAPA'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Ver Archivos Etapa'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'/*',
'IF :P151_CODIGOETAPA <> ''ET2'' THEN',
'    RETURN TRUE;',
'END IF;',
'*/',
'    RETURN FALSE;',
'END;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-eye'
,p_updated_on=>wwv_flow_imp.dz('20241127161224Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(84301747447155701)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(73870533137721912)
,p_button_name=>'RECHAZAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Rechazar Registro'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P151_CODIGOETAPA'
,p_button_condition2=>'ET222'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(94271939304663821)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(74683145984609823)
,p_button_name=>'ENVIARNOTIFICACIONET4'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>unistr('Enviar Notificaci\00F3n')
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_mostrar NUMBER;',
'v_numero NUMBER;',
'BEGIN ',
'	SELECT ID_TABLA into v_numero FROM T_CORP_UDC WHERE VALOR = :P151_CODIGOETAPA AND ID_CABECERA = ''CMEX_ET_IM'';',
'',
'	IF v_numero >= 4 AND :P151_FECHALIQ IS NOT NULL AND :P151_FECHAPAGO_LIQ IS NOT NULL AND  :P151_TIPOAFORO IS NOT NULL AND',
'		:P151_TIPODESPACHO IS NOT NULL AND :P151_REFRENDO IS NOT NULL AND :P151_NUMEROLIQUIDACION IS NOT NULL',
'		THEN ',
unistr('		RETURN FALSE;--RETURN TRUE; -- Cambio necesario para no cambiar la notificaci\00F3n'),
'	END IF;',
'	RETURN FALSE;',
'END;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-send'
,p_updated_on=>wwv_flow_imp.dz('20250203162702Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(75667639817913614)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(74059712143884714)
,p_button_name=>'Ver_Contenedores'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Ver Contenedores'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    IF :P151_CODIGOETAPA in (''ET2'',''ET9'') THEN',
'        RETURN TRUE;',
'    END IF;',
'',
'    RETURN FALSE;',
'END;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-columns'
,p_updated_on=>wwv_flow_imp.dz('20241127161224Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(94273066992663832)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(74683145984609823)
,p_button_name=>'BITACORA_CAS'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Bitacora Fecha CAS'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-info-circle-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(308906653991281441)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(73870533137721912)
,p_button_name=>'RECHAZAR_1'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Rechazar Registro'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:107:&SESSION.::&DEBUG.:107:G_VALOR1:1'
,p_confirm_message=>unistr('\00BFEst\00E1 seguro de rechazar el registro de la importaci\00F3n? Se cambiar\00E1 a Etapa 1.')
,p_confirm_style=>'warning'
,p_button_condition=>'P151_CODIGOETAPA'
,p_button_condition2=>'ET2'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-undo'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(64133827441537825)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(73870533137721912)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'select * from dual where :p151_codigoetapa not in (''ET9'')'
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(94273511804663837)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(74059712143884714)
,p_button_name=>'BITACORA_ETA'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Bitacora ETA'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-info-circle-o'
,p_updated_on=>wwv_flow_imp.dz('20241127161224Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74059868367884715)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(74059712143884714)
,p_button_name=>'GUARDAR_ETAPA2'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Guardar Etapa 2'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'/*',
'IF :P151_CODIGOETAPA = ''ET2'' THEN',
'        RETURN TRUE;',
'END IF;',
'*/',
'RETURN FALSE;',
'END;'))
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'FUNCTION_BODY'
,p_icon_css_classes=>'fa-save'
,p_updated_on=>wwv_flow_imp.dz('20241127161224Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85321373534939439)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(73870533137721912)
,p_button_name=>'SAVE_ORDAGE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'select * from dual where :p151_codigoetapa in (''ET9'')'
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(308906591603281440)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(73870533137721912)
,p_button_name=>'RUTA'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Ruta'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:104:&SESSION.::&DEBUG.:104:G_OBJETO,G_OBJETO_ID,G_TODO:IMPORTACION_MUESTRAS,&P151_ID_MUESTRA.,TRUE'
,p_button_condition=>'P151_ID_MUESTRA'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-road'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(187248877646684737)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(76572010425781324)
,p_button_name=>'NOTIFICA_INICIADOR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Notifica Arribo'
,p_button_alignment=>'RIGHT'
,p_button_condition=>':P151_ID_MUESTRA IS NOT NULL'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(74631438141117221)
,p_branch_action=>'f?p=&APP_ID.:151:&SESSION.::&DEBUG.:RP,151:P151_ID:&P151_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37859048742753917)
,p_name=>'P151_PUERTOORIGEN'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(73871455363721921)
,p_prompt=>'Puerto Origen'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P151_ID_MUESTRA IS NULL OR ',
'(:P151_ID_MUESTRA IS NOT NULL AND :P151_REGIMENMUESTRA=''10'')'))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37859100717753918)
,p_name=>'P151_AGENTEADUANA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(73871455363721921)
,p_prompt=>'Agente Aduana'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select descripcion, id_tabla from t_corp_udc where id_cabecera = ''CMEX_AGNT'' order by id'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P151_ID_MUESTRA IS NULL OR ',
'(:P151_ID_MUESTRA IS NOT NULL AND :P151_REGIMENMUESTRA=''10'')'))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37859912972753926)
,p_name=>'P151_FORWARDER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(73871455363721921)
,p_prompt=>'Forwarder'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>'select distinct upper(forwarder) from t_cmex_mesatrabajo where forwarder is not null'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when=>':P151_ID_MUESTRA IS NULL'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'Y'
,p_attribute_05=>'5'
,p_attribute_09=>'2'
,p_attribute_10=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(61445569041698516)
,p_name=>'P151_VALORADUANA'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(74683260578609824)
,p_prompt=>'Valor en Aduana'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'0'
,p_attribute_03=>'right'
,p_attribute_04=>'decimal'
,p_updated_on=>wwv_flow_imp.dz('20250203171014Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64132474700537811)
,p_name=>'P151_TRAMITEOBS'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(74683260578609824)
,p_prompt=>unistr('Tr\00E1mite Observado')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LOV_SINO'
,p_lov=>'.'||wwv_flow_imp.id(78141453854944977)||'.'
,p_begin_on_new_line=>'N'
,p_display_when=>':P151_ID_MUESTRA IS NULL'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20250203171014Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64132585735537812)
,p_name=>'P151_MOTIVOINCPLAN'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(74683260578609824)
,p_prompt=>'Motivo Inc. Plan'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select descripcion, id_tabla from t_corp_udc where id_cabecera = ''CMEX_MINCP'' order by 1'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_display_when=>':P151_ID_MUESTRA IS NULL'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20250203171014Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64133516288537822)
,p_name=>'P151_INCMUESTRA'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(74242343287161038)
,p_prompt=>'Incluye Muestra'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64133606424537823)
,p_name=>'P151_MONTOOC'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(74242343287161038)
,p_prompt=>'Monto OC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73870160296721908)
,p_name=>'P151_ORDENIMPORTACION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(73870039609721907)
,p_prompt=>unistr('Orden Importaci\00F3n')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73870263256721909)
,p_name=>'P151_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(73870039609721907)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73870409312721911)
,p_name=>'P151_TIPO_OI'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(73870039609721907)
,p_prompt=>'Tipo OC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73871017477721917)
,p_name=>'P151_CODIGOPROVEEDOR'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(73870039609721907)
,p_prompt=>'Proveedor'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_JDE_LIBRODIRECCIONES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DISTINCT nombres as r,',
'       codigo as d',
'  from VT_JDE_LIBRODIRECCIONES',
' order by 1'))
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73871168206721918)
,p_name=>'P151_FECHAREC'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(73871455363721921)
,p_prompt=>unistr('Fecha Recolecci\00F3n')
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>15
,p_display_when=>':P151_INCOTERM=''EXW'' AND :P151_ID_MUESTRA IS NULL'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73871261958721919)
,p_name=>'P151_FECHAETD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(73871455363721921)
,p_prompt=>'Fecha Zarpe'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>15
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73871572907721922)
,p_name=>'P151_CONOCIMIENTOEMBARQUE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(73871455363721921)
,p_prompt=>'Documento de Transporte'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when=>':P151_ID_MUESTRA IS NULL'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260720165131Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73871696186721923)
,p_name=>'P151_NAVIERA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(73871455363721921)
,p_prompt=>'Naviera'
,p_display_as=>'NATIVE_AUTO_COMPLETE'
,p_lov=>'select distinct upper(naviera) from t_cmex_mesatrabajo where naviera is not null'
,p_cSize=>30
,p_display_when=>':P151_ID_MUESTRA IS NULL'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'CONTAINS_IGNORE'
,p_attribute_04=>'Y'
,p_attribute_05=>'5'
,p_attribute_09=>'2'
,p_attribute_10=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73871764175721924)
,p_name=>'P151_ORDENAGENTE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(73871455363721921)
,p_prompt=>'Orden del Agente'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P151_ID_MUESTRA IS NULL OR ',
'(:P151_ID_MUESTRA IS NOT NULL AND :P151_REGIMENMUESTRA=''10'')'))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260721135912Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73871899400721925)
,p_name=>'P151_NUMFACTURA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(74242343287161038)
,p_prompt=>unistr('N\00FAm. Factura')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73871900932721926)
,p_name=>'P151_CNT20PIES'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(73871455363721921)
,p_item_default=>'0'
,p_prompt=>'Contenedor 20 ft'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P151_ID_MUESTRA IS NULL OR ',
'(:P151_ID_MUESTRA IS NOT NULL AND :P151_REGIMENMUESTRA=''10'')'))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_css_classes=>'mensaje'
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73872058938721927)
,p_name=>'P151_CNT40PIES'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(73871455363721921)
,p_item_default=>'0'
,p_prompt=>'Contenedor 40 ft'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P151_ID_MUESTRA IS NULL OR ',
'(:P151_ID_MUESTRA IS NOT NULL AND :P151_REGIMENMUESTRA=''10'')'))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_css_classes=>'mensaje'
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73872145691721928)
,p_name=>'P151_BULTOSPALLETS'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(73871455363721921)
,p_prompt=>'Bultos/Pallets'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73872246350721929)
,p_name=>'P151_PESONETO'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(73871455363721921)
,p_prompt=>'Peso Neto Total kg'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P151_ID_MUESTRA IS NULL OR ',
'(:P151_ID_MUESTRA IS NOT NULL AND :P151_REGIMENMUESTRA=''10'')'))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73872330293721930)
,p_name=>'P151_PESOBRUTO'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(73871455363721921)
,p_prompt=>'Peso Bruto Total kg'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_03=>'right'
,p_attribute_04=>'decimal'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73872437688721931)
,p_name=>'P151_CUBICAJE'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(73871455363721921)
,p_prompt=>'Cubicaje m3'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P151_ID_MUESTRA IS NULL OR ',
'(:P151_ID_MUESTRA IS NOT NULL AND :P151_REGIMENMUESTRA=''10'')'))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73872507376721932)
,p_name=>'P151_PAISORIGEN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(74242343287161038)
,p_prompt=>unistr('Pa\00EDs Origen')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_PAISES_JDE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select drdl01 d, drky r',
'from vt_jde_udcjde ',
'where drsy = ''00'' and drrt = ''CN'' and drky != ''*'' order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(73872830736721935)
,p_name=>'P151_CODIGOETAPA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(73870039609721907)
,p_prompt=>'Etapa'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_CMEX_ETAPAS_IMPORTACION'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select valor||'' - ''||descripcion AS D, valor AS R ',
'from data.t_corp_udc where id_cabecera = ''CMEX_ET_IM'''))
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74060029166884717)
,p_name=>'P151_APLICACIONSEGURO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(73871455363721921)
,p_prompt=>unistr('Aplicaci\00F3n Seguro')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_display_when=>':P151_ID_MUESTRA IS NULL'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74242458056161039)
,p_name=>'P151_INCOTERM'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(74242343287161038)
,p_prompt=>'Incoterm'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_INCOTERMS'
,p_lov=>'select DRKY ||'' - ''||upper(DRDL01) d,DRKY r from vt_jde_udcjde where drsy=''42'' and drrt=''FR'' and drky is not null order by upper(DRKY)'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_read_only_when=>'P151_CODIGOETAPA'
,p_read_only_when2=>'ET1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74242590561161040)
,p_name=>'P151_CARGAPRIORITARIA'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(74242343287161038)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74242699999161041)
,p_name=>'P151_TIPOMERCADERIA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(74242343287161038)
,p_prompt=>unistr('Tipo Mercader\00EDa')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TIPOSMATERIALES_JDE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT upper(DRDL01)||'' (''||DRKY||'')'' AS D, DRKY AS R FROM DATA.VT_JDE_UDCJDE',
'WHERE DRSY = ''41'' AND DRRT= ''9'' AND SUBSTR(DRKY, 1,2) = ''IN''',
'ORDER BY 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_read_only_when=>'P151_CODIGOETAPA'
,p_read_only_when2=>'ET1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74242719514161042)
,p_name=>'P151_OBSERVACIONES'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(74242343287161038)
,p_prompt=>'Observaciones'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74630253633117209)
,p_name=>'P151_ARCHIVO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(74630057935117207)
,p_prompt=>'Archivo'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'NATIVE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74630498990117211)
,p_name=>'P151_TIPOARCHIVO_SUBIR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(74630057935117207)
,p_prompt=>'Tip Archivo Subir'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DECODE(VALOR2,''U'',''*-''||DESCRIPCION,DESCRIPCION) AS D, VALOR AS R ',
'FROM DATA.T_CORP_UDC ',
'WHERE ID_CABECERA = ''CMEX_''|| :P151_CODIGOETAPA||''FI''',
'AND (:P151_CODIGOETAPA=''ET4''  ',
'     AND VALOR NOT IN ( SELECT TIPO ',
'                   FROM FILES.T_APEX_ARCHIVOS',
'                   WHERE ESTADO = ''1'' ',
'                   AND TABLA = ''T_CMEX_MESATRABAJO''',
'                   AND TIPO  IN (SELECT VALOR FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''CMEX_''|| :P151_CODIGOETAPA|| ''FI'' ',
'                                 AND VALOR2=''U'')  ',
'                    AND ID_TABLA = :P151_ID)  or :P151_CODIGOETAPA<>''ET4'' )'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74630527813117212)
,p_name=>'P151_OBSERVACION_ARCHIVO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(74630057935117207)
,p_prompt=>'Observaciones'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74633097618117237)
,p_name=>'P151_ETAPA_ANTERIOR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(74632946475117236)
,p_prompt=>'Etapa Anterior'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74680902524609801)
,p_name=>'P151_FECHADAV'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(74683260578609824)
,p_prompt=>'Fecha aprob. DAV'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74681071181609802)
,p_name=>'P151_BODEGA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(74681275853609804)
,p_prompt=>'Bodega'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select descripcion, id_tabla from t_corp_udc where id_cabecera = ''CMEX_BDGS'' and valor = :p151_distrito order by 1'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_cascade_parent_items=>'P151_DISTRITO'
,p_ajax_optimize_refresh=>'N'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74681172245609803)
,p_name=>'P151_MANIFIESTOCARGA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(74681275853609804)
,p_prompt=>'Manifiesto de Carga'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>23
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74682694864609818)
,p_name=>'P151_FECHAETA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(73871455363721921)
,p_prompt=>'Fecha ETA'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74683341219609825)
,p_name=>'P151_FECHALIQ'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(74683260578609824)
,p_prompt=>'Fecha Liq.'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74683456085609826)
,p_name=>'P151_FECHAPAGO_LIQ'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(74683260578609824)
,p_prompt=>'Fecha Pago Liq.'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74683571338609827)
,p_name=>'P151_TIPOAFORO'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(74683260578609824)
,p_prompt=>'Tipo Aforo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TIPOSAFORO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DESCRIPCION as d,',
'       VALOR as r',
'  from DATA.T_CORP_UDC',
'  WHERE ID_CABECERA = ''CMEX_IMAFO''',
'ORDER BY 2'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74683610836609828)
,p_name=>'P151_TIPODESPACHO'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(74683260578609824)
,p_prompt=>'Tipo Despacho'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_TIPOSDESPACHO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DESCRIPCION as d,',
'       VALOR as r',
'  from DATA.T_CORP_UDC',
'  WHERE ID_CABECERA = ''CMEX_T_DES''',
' order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20250203171014Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74683769775609829)
,p_name=>'P151_REFRENDO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(74683260578609824)
,p_prompt=>'Refrendo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74683849969609830)
,p_name=>'P151_NUMEROLIQUIDACION'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(74683260578609824)
,p_prompt=>unistr('N\00FAm. Liquidaci\00F3n')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74683957557609831)
,p_name=>'P151_FECHACAS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(74683260578609824)
,p_prompt=>'Fecha CAS '
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when=>':P151_ID_MUESTRA IS NULL OR (:P151_ID_MUESTRA IS NOT NULL AND :P151_REGIMENMUESTRA=10)'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74684074835609832)
,p_name=>'P151_CARGALIBERADA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(74683260578609824)
,p_prompt=>'Carga Liberada'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>'STATIC:Si;SI,No;NO'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74684197796609833)
,p_name=>'P151_AVISOPAGO_LIQUIDACION'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(74683260578609824)
,p_prompt=>'Aviso Pago Liq.'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:Si;SI,No;NO'
,p_begin_on_new_line=>'N'
,p_display_when=>':P151_ID_MUESTRA IS NULL'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74685804413609850)
,p_name=>'P151_NUMEROARCHIVO_BORRAR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(74684528081609837)
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(75899706407799022)
,p_name=>'P151_FECHAPLANIFICADAPLANTA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(75668376162913621)
,p_prompt=>'Fecha Planificada Planta'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76572233917781326)
,p_name=>'P151_FECHA_ULTIMO_CONTENEDOR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(76572010425781324)
,p_prompt=>unistr('Fecha \00DAltimo Contenedor')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>':P151_ID_MUESTRA is null'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76572303765781327)
,p_name=>'P151_CARGA_LIBRE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(73871455363721921)
,p_prompt=>'Carga Suelta'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_lov=>'STATIC:Si;SI,No;NO'
,p_begin_on_new_line=>'N'
,p_display_when=>':P151_ID_MUESTRA IS NULL'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76572973614781333)
,p_name=>'P151_DISPLAY_ET1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(76572849141781332)
,p_prompt=>'Display Et1'
,p_source=>'SELECT VALOR||'' - ''||DESCRIPCION FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''CMEX_ET_IM'' AND VALOR = ''ET1'';'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76573006923781334)
,p_name=>'P151_DISPLAY_ET2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(76572849141781332)
,p_prompt=>'Display Et1'
,p_source=>'SELECT VALOR||'' - ''||DESCRIPCION FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''CMEX_ET_IM'' AND VALOR = ''ET2'';'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76573103548781335)
,p_name=>'P151_DISPLAY_ET3'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(76572849141781332)
,p_prompt=>'Display Et1'
,p_source=>'SELECT VALOR||'' - ''||DESCRIPCION FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''CMEX_ET_IM'' AND VALOR = ''ET3'';'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76573246570781336)
,p_name=>'P151_DISPLAY_ET4'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(76572849141781332)
,p_prompt=>'Display Et4'
,p_source=>'SELECT VALOR||'' - ''||DESCRIPCION FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''CMEX_ET_IM'' AND VALOR = ''ET4'';'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76573358166781337)
,p_name=>'P151_DISPLAY_ET5'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(76572849141781332)
,p_prompt=>'Display Et5'
,p_source=>'SELECT VALOR||'' - ''||DESCRIPCION FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''CMEX_ET_IM'' AND VALOR = ''ET5'';'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76573496202781338)
,p_name=>'P151_DISPLAY_ET6'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(76572849141781332)
,p_prompt=>'Display Et6'
,p_source=>'SELECT VALOR||'' - ''||DESCRIPCION FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''CMEX_ET_IM'' AND VALOR = ''ET6'';'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76573524214781339)
,p_name=>'P151_DISPLAY_ET7'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(76572849141781332)
,p_prompt=>'Display Et7'
,p_source=>'SELECT VALOR||'' - ''||DESCRIPCION FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''CMEX_ET_IM'' AND VALOR = ''ET7'';'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76573658801781340)
,p_name=>'P151_DISPLAY_ET8'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(76572849141781332)
,p_prompt=>'Display Et8'
,p_source=>'SELECT VALOR||'' - ''||DESCRIPCION FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''CMEX_ET_IM'' AND VALOR = ''ET8'';'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80464033352347032)
,p_name=>'P151_ADUANA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(74681275853609804)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80464101495347033)
,p_name=>'P151_DISTRITO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(74681275853609804)
,p_prompt=>'Distrito'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT distinct valor dis, valor ret FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''CMEX_BDGS'' and trim(valor) is not null order by 1'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80464698871347038)
,p_name=>'P151_FECHACARGALIBERADA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(74683260578609824)
,p_prompt=>'Fecha Carga Liberada'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85318852161939414)
,p_name=>'P151_FECHADUC'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(74681275853609804)
,p_prompt=>unistr('Fecha \00DAlt. Cnt.')
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when=>':P151_ID_MUESTRA IS NULL OR (:P151_ID_MUESTRA IS NOT NULL AND :P151_REGIMENMUESTRA=10)'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85318996355939415)
,p_name=>'P151_TIPOPRODUCTO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(74242343287161038)
,p_prompt=>'Tipo Producto'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select descripcion dis, id_tabla ret from t_corp_udc where id_cabecera = ''CMEX_TPRD'' order by 1'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when=>'P151_CODIGOETAPA'
,p_read_only_when2=>'ET1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(93115375373453149)
,p_name=>'P151_ESTADO_PROV_ET6'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(76571958877781323)
,p_prompt=>'Estado'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_estado varchar2(20);',
'BEGIN ',
'',
'    BEGIN ',
'        SELECT ESTADO INTO v_estado FROM T_CMEX_PROVISION',
'        WHERE ID_CMEX_MESATRABAJO = :P151_ID;',
'    EXCEPTION WHEN NO_dATA_FOUND THEN ',
'        v_estado := ''EN ESPERA'';',
'    END ;',
'',
'RETURN v_estado;',
'',
'END;'))
,p_source_type=>'FUNCTION_BODY'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(94271296391663814)
,p_name=>'P151_DISPLAY_ET9'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(76572849141781332)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Display Et9'
,p_source=>'SELECT VALOR||'' - ''||DESCRIPCION FROM DATA.T_CORP_UDC WHERE ID_CABECERA = ''CMEX_ET_IM'' AND VALOR = ''ET9'';'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(94271329200663815)
,p_name=>'P151_FECHA_FINALIZACION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(94271196688663813)
,p_prompt=>unistr('Fecha Finalizaci\00F3n')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT FECHA_FINALIZA',
'FROM T_CMEX_MESATRABAJO',
'WHERE ID = :P151_ID;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(187247925172684728)
,p_name=>'P151_ID_MUESTRA'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(73871455363721921)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(187248027073684729)
,p_name=>'P151_DOCUMENTOEMBARQUE'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(73871455363721921)
,p_prompt=>'Documento Embarque: '
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>30
,p_colspan=>6
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--OR  --(:P151_ID_MUESTRA IS NOT NULL AND :P151_REGIMENMUESTRA=''10'')',
':P151_ID_MUESTRA IS NOT NULL '))
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(187248184948684730)
,p_name=>'P151_PAISORIGENMUESTRA'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(73871455363721921)
,p_prompt=>unistr('Pa\00EDs de Embarque: ')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_PAISES_JDE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select drdl01 d, drky r',
'from vt_jde_udcjde ',
'where drsy = ''00'' and drrt = ''CN'' and drky != ''*'' order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>6
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(187248243088684731)
,p_name=>'P151_REGIMENMUESTRA'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(73871455363721921)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(187248636205684735)
,p_name=>'P151_FECHATURNO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(76572010425781324)
,p_prompt=>'Fecha Turno: '
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_display_when=>':P151_ID_MUESTRA IS NOT NULL'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(187248764164684736)
,p_name=>'P151_INGRESOREALZM'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(76572010425781324)
,p_prompt=>'Fecha Ingreso <br>Real a ZM: '
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_display_when=>':P151_ID_MUESTRA IS NOT NULL'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(250536380832615234)
,p_name=>'P151_VIADESPACHO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(74242343287161038)
,p_prompt=>unistr('V\00EDa Despacho')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_VIADESPACHO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select descripcion d, id_tabla r',
'from t_corp_udc where id_cabecera = ''CMEX_VDESP'' order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when=>'P151_CODIGOETAPA'
,p_read_only_when2=>'ET1'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295682298750037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308907222883281447)
,p_name=>'P151_COMENTARIO_A'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(73870039609721907)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(308907371216281448)
,p_name=>'P151_COMENTARIOUSUARIO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(73870039609721907)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(585057112141907207)
,p_name=>'P151_VALORIVALIQ'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(74683260578609824)
,p_prompt=>'IVA Liq. Aduana'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250203171014Z')
,p_updated_on=>wwv_flow_imp.dz('20250203171014Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(187248394002684732)
,p_validation_name=>unistr('Num\00E9rico')
,p_validation_sequence=>10
,p_validation=>'P151_NUMEROLIQUIDACION'
,p_validation2=>'^([0-9]){8}$'
,p_validation_type=>'REGULAR_EXPRESSION'
,p_error_message=>unistr('N\00FAmero Liquidaci\00F3n debe ser de 8 caracteres num\00E9ricos')
,p_associated_item=>wwv_flow_imp.id(74683849969609830)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(187248458385684733)
,p_validation_name=>unistr('Num\00E9rico2')
,p_validation_sequence=>20
,p_validation=>'P151_REFRENDO'
,p_validation2=>'^([0-9]){17}$'
,p_validation_type=>'REGULAR_EXPRESSION'
,p_error_message=>unistr('Refrendo debe ser de 17 caracteres num\00E9ricos')
,p_associated_item=>wwv_flow_imp.id(74683769775609829)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(73872991748721936)
,p_name=>'VerificaEtapaExpandeRegion'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(73873029086721937)
,p_event_id=>wwv_flow_imp.id(73872991748721936)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'EVENT_SOURCE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var etapa = apex.item("P151_CODIGOETAPA").getValue();',
'console.log(etapa);',
'$(".reg_etapa").removeClass(''is-collapsed'');',
'$(".reg_etapa").removeClass(''is-expanded'');',
'$(".reg_etapa").addClass(''is-collapsed'');',
'',
'$("#"+etapa).find("button.t-Button--hideShow").eq(0).click();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(74629736908117204)
,p_name=>'ValidaET2'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>':P151_CODIGOETAPA = ''ET2'''
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(74629858816117205)
,p_event_id=>wwv_flow_imp.id(74629736908117204)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.server.process("VerificaET2",',
'   {pageItems: "#P151_ID,#P151_CNT20PIES,#P151_CNT40PIES"},',
'    {dataType: "json",',
'    success: function(pData){',
'                console.log(pData);',
'        if (pData.reload == ''S''){ location.reload();}',
'        if (pData.archivos == ''S'' ){',
'            $("#archivosEstado").text("Archivos Completos");     ',
'            $("#archivosEstado").css(''color'', ''green'');',
'            }else{',
'                ',
'                if (apex.item("P151_CNT20PIES").getValue() == null || apex.item("P151_CNT20PIES").getValue() == ""){}',
'                else{',
'                    $("#archivosEstado").text("Archivos Incompletos");',
'                    $("#archivosEstado").css(''color'', ''red'');;',
'                }',
'',
'        }',
'        if (pData.contenedores == ''S'' ){',
'            $("#contenedoresEstado").text("Contenedores Completos");  ',
'             $("#contenedoresEstado").css(''color'', ''green'');;',
'        }else{',
'            if (apex.item("P151_CNT20PIES").getValue() == null || apex.item("P151_CNT20PIES").getValue() == ""){',
'                ',
'            }else{',
'                $("#contenedoresEstado").text("Contenedores Incompletos");',
'                $("#contenedoresEstado").css(''color'', ''red'');    ',
'            }',
'        }',
'      }',
'   }',
');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(75667914575913617)
,p_name=>'ValidaET4'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>':P151_CODIGOETAPA = ''ET4'''
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75668083156913618)
,p_event_id=>wwv_flow_imp.id(75667914575913617)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.server.process("VerificaET4",',
'   {pageItems: "#P151_ID"},',
'    {dataType: "json",',
'    success: function(pData){',
'                 console.log(pData );',
'',
'        if (pData.reload == ''S''){ location.reload();}',
'        if (pData.archivos == ''S'' ){',
'                $("#archivosEstadoET4").text("Archivos Completos");     ',
'                $("#archivosEstadoET4").css(''color'', ''green'');',
'            }else{',
'                $("#archivosEstadoET4").text("Archivos Incompletos");',
'                $("#archivosEstadoET4").css(''color'', ''red'');',
'        }',
'      }',
'   }',
');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(74684604393609838)
,p_name=>'New'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(74684426621609836)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(74684766754609839)
,p_event_id=>wwv_flow_imp.id(74684604393609838)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'javascript:openModal(''DlgArchivos'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(75217306664518601)
,p_name=>'EjecutarBorradoArchivo'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P151_NUMEROARCHIVO_BORRAR'
,p_condition_element=>'P151_NUMEROARCHIVO_BORRAR'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75217493658518602)
,p_event_id=>wwv_flow_imp.id(75217306664518601)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEsta seguro de eliminar el arhivo?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75217529769518603)
,p_event_id=>wwv_flow_imp.id(75217306664518601)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DELETE FROM FILES.T_APEX_ARCHIVOS ',
'WHERE NUMEROARCHIVO = :P151_NUMEROARCHIVO_BORRAR;'))
,p_attribute_02=>'P151_NUMEROARCHIVO_BORRAR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75217799980518605)
,p_event_id=>wwv_flow_imp.id(75217306664518601)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(74684528081609837)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(74631110158117218)
,p_event_id=>wwv_flow_imp.id(75217306664518601)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P151_NUMEROARCHIVO_BORRAR'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    :P151_NUMEROARCHIVO_BORRAR := NULL;',
'END;'))
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(74630954092117216)
,p_name=>'MostrarDialogo'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(74060987721884726)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(74631094483117217)
,p_event_id=>wwv_flow_imp.id(74630954092117216)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'javascript:openModal(''DlgArchivos'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(74631238271117219)
,p_name=>'ActualizarDatosArchivos'
,p_event_sequence=>70
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(74684528081609837)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(74631375974117220)
,p_event_id=>wwv_flow_imp.id(74631238271117219)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'JQUERY_SELECTOR'
,p_affected_elements=>'.reg_etapa'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(74633294784117239)
,p_name=>'VisualizarArchivos'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(74633109785117238)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(74633386986117240)
,p_event_id=>wwv_flow_imp.id(74633294784117239)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'javascript:$s(''P151_ETAPA_ANTERIOR'',"ET2");openModal(''DlgArchivosVer'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(75666626981913604)
,p_name=>'VisualizarArchivos_1'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(75666594933913603)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75666759157913605)
,p_event_id=>wwv_flow_imp.id(75666626981913604)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'javascript:$s(''P151_ETAPA_ANTERIOR'',"ET4");openModal(''DlgArchivosVer'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(74633501415117242)
,p_name=>'REFRESCAR'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P151_ETAPA_ANTERIOR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(74633658135117243)
,p_event_id=>wwv_flow_imp.id(74633501415117242)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(74631878441117225)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(75666301579913601)
,p_name=>'New_1'
,p_event_sequence=>110
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'ui-button ui-corner-all ui-widget ui-button-icon-only ui-dialog-titlebar-close'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'ui-button ui-corner-all ui-widget ui-button-icon-only ui-dialog-titlebar-close'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75666472349913602)
,p_event_id=>wwv_flow_imp.id(75666301579913601)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(75667705961913615)
,p_name=>'MostrarModal'
,p_event_sequence=>120
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(75667639817913614)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75667829181913616)
,p_event_id=>wwv_flow_imp.id(75667705961913615)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'javascript:openModal(''DlgContenedoresVer'');',
''))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(75898202539799007)
,p_name=>'New_2'
,p_event_sequence=>130
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(74060379048884720)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(75898380798799008)
,p_event_id=>wwv_flow_imp.id(75898202539799007)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'JQUERY_SELECTOR'
,p_affected_elements=>'document'
,p_attribute_01=>'window.reload();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(76572439046781328)
,p_name=>'CargaLibre20'
,p_event_sequence=>140
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P151_CNT20PIES'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76572563526781329)
,p_event_id=>wwv_flow_imp.id(76572439046781328)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF (:P151_CNT20PIES IS NULL OR :P151_CNT20PIES = 0) AND (:P151_CNT40PIES IS NULL OR :P151_CNT40PIES = 0) THEN',
'    :P151_CARGA_LIBRE := ''SI'';',
'ELSE',
'    :P151_CARGA_LIBRE := ''NO'';',
'END IF;'))
,p_attribute_02=>'P151_CNT20PIES,P151_CNT40PIES'
,p_attribute_03=>'P151_CARGA_LIBRE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(76572630213781330)
,p_name=>'CargaLibre40'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P151_CNT40PIES'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76572799836781331)
,p_event_id=>wwv_flow_imp.id(76572630213781330)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF (:P151_CNT20PIES IS NULL OR :P151_CNT20PIES = 0) AND (:P151_CNT40PIES IS NULL OR :P151_CNT40PIES = 0) THEN',
'    :P151_CARGA_LIBRE := ''SI'';',
'ELSE',
'    :P151_CARGA_LIBRE := ''NO'';',
'END IF;'))
,p_attribute_02=>'P151_CNT20PIES,P151_CNT40PIES'
,p_attribute_03=>'P151_CARGA_LIBRE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(76573946943781343)
,p_name=>'New_3'
,p_event_sequence=>160
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P151_FECHACARGALIBERADA'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76574082651781344)
,p_event_id=>wwv_flow_imp.id(76573946943781343)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P151_FECHACARGALIBERADA IS NULL OR :P151_FECHACAS = ''''  THEN',
'     :P151_CARGALIBERADA := ''NO'';',
'ELSE ',
'    :P151_CARGALIBERADA := ''SI'';',
'END IF;'))
,p_attribute_02=>'P151_FECHACARGALIBERADA'
,p_attribute_03=>'P151_CARGALIBERADA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(79784285556097224)
,p_name=>'CargarFechaFasesSuperiores'
,p_event_sequence=>170
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'FUNCTION_BODY'
,p_display_when_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF (:P151_CNT20PIES + :P151_CNT40PIES) > 0 OR :P151_ID_MUESTRA IS NOT NULL',
'    THEN RETURN TRUE;',
'END IF;',
'',
'RETURN FALSE;',
''))
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79784325627097225)
,p_event_id=>wwv_flow_imp.id(79784285556097224)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	-- Fecha planificada de ingreso a planta',
'	select min(fechadescargue) into :p151_fechaplanificadaplanta',
'	from data.t_rcdp_solicitudimportaciones',
'	where documentooi = :p151_ordenimportacion;',
'',
'	-- Fecha de recepcion del ultimo contenedor',
'	select max(fechadescargue) into :p151_fecha_ultimo_contenedor',
'	from data.t_rcdp_solicitudimportaciones',
'	where documentooi = :p151_ordenimportacion',
'		and (select count(1) from t_rcdp_solicitudimportaciones where documentooi = :p151_ordenimportacion and estado = 4)',
'			= (select count(nro_contenedor) from t_cmex_detallecontenedor where id_cmex_mesatrabajo = :p151_id)',
'	and estado = 4;',
unistr('    -- fecha turno para importaci\00F3n de muestras s\00F3lo R\00C9GIMEN 10, para REGIMEN 91 se digita este dato'),
'    IF :P151_REGIMENMUESTRA=10 THEN',
'       SELECT MAX(TO_CHAR(FECHATURNO,''DD/MM/YYYY'')) INTO :P151_FECHATURNO',
'       FROM T_RCDP_SOLICITUDIMPORTACIONES',
'       WHERE ESTADO = 3 ',
'       AND TRIM(OBSERVACION)= (SELECT ID FROM T_CMEX_MESATRABAJO WHERE ID= :P151_ID);',
'    END IF;',
'end;'))
,p_attribute_02=>'P151_ORDENIMPORTACION'
,p_attribute_03=>'P151_FECHA_ULTIMO_CONTENEDOR,P151_FECHAPLANIFICADAPLANTA,P151_FECHATURNO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(79784488988097226)
,p_event_id=>wwv_flow_imp.id(79784285556097224)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P151_FECHA_ULTIMO_CONTENEDOR'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(93114461777453140)
,p_name=>'EjecutaCambioEtapaET5'
,p_event_sequence=>180
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P151_FECHAPLANIFICADAPLANTA'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'!apex.item("P151_FECHAPLANIFICADAPLANTA").isEmpty() && apex.item("P151_CODIGOETAPA").getValue() == "ET5"'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(93114656066453142)
,p_event_id=>wwv_flow_imp.id(93114461777453140)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'FINALIZARETAPA5'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(93114770719453143)
,p_name=>'EjecutaCambiarEtapa8'
,p_event_sequence=>190
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P151_FECHA_ULTIMO_CONTENEDOR'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'!apex.item("P151_FECHA_ULTIMO_CONTENEDOR").isEmpty() && apex.item("P151_CODIGOETAPA").getValue() == "ET7"'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(93114994650453145)
,p_event_id=>wwv_flow_imp.id(93114770719453143)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'FINALIZARETAPA7'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(94270781109663809)
,p_name=>'ValidaET8'
,p_event_sequence=>200
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94270817458663810)
,p_event_id=>wwv_flow_imp.id(94270781109663809)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.server.process("VerificaET8",',
'   {pageItems: "#P151_ID,#P151_CNT20PIES,#P151_CNT40PIES"},',
'    {dataType: "json",',
'    success: function(pData){',
'                console.log(pData);',
'        if (pData.archivos == ''S'' ){',
'            var cnt20pies = apex.item("P151_CNT20PIES").getValue();',
'            var cnt40pies = apex.item("P151_CNT40PIES").getValue();',
'            var cargaLibre = apex.item("P151_CARGA_LIBRE").getValue();',
'            ',
'            ',
'            if(cnt20pies == 0 && cnt40pies == 0  ){ ',
unistr('                $("#mensajeET8").text("No aplica validaci\00F3n de archivos");     '),
'                $("#mensajeET8").css(''color'', ''green''); ',
'                if (apex.item("P151_CODIGOETAPA").getValue() == "ET8"){',
'                     $("#FINALIZAR_ETAPA8").show();   ',
'                }',
'            }',
'            else {',
'                $("#mensajeET8").text("Archivos Completos");     ',
'                $("#mensajeET8").css(''color'', ''green'');',
'',
'                if (apex.item("P151_CODIGOETAPA").getValue() == "ET8"){',
'                     $("#FINALIZAR_ETAPA8").show();   ',
'                }                ',
'            }',
'         }',
'      }',
'   }',
');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(94272062216663822)
,p_name=>'EnviarCorreo'
,p_event_sequence=>210
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(94271939304663821)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94272188608663823)
,p_event_id=>wwv_flow_imp.id(94272062216663822)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.server.process("AvisoPagoLiquidacion",',
'   {pageItems: "#P151_ID"},',
'    {dataType: "json",',
'    success: function(pData){',
'                console.log(pData);',
'        if (pData.envio == 1 ){',
'            alert(''Correo enviado exitosamente.'')',
'         }',
'      }',
'   }',
');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(94272440933663826)
,p_name=>'ValidaFechaET5'
,p_event_sequence=>210
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--(:P151_CNT20PIES + :P151_CNT40PIES) < 1 AND :P151_CODIGOETAPA IN (''ET5'',''ET7'')',
'',
'((:P151_CNT20PIES + :P151_CNT40PIES) < 1 AND :P151_CODIGOETAPA IN (''ET5''))',
'OR ',
'(:P151_ID_MUESTRA IS NOT NULL AND :P151_CODIGOETAPA IN (''ET5''))'))
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94272509476663827)
,p_event_id=>wwv_flow_imp.id(94272440933663826)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :p151_codigoetapa = ''ET5'' then',
'	data.pk_cmex_mesatrabajo.sp_actualizaetapa(:p151_id,''ET6'');',
'--elsif :p151_codigoetapa = ''ET7'' THEN',
'--	data.pk_cmex_mesatrabajo.sp_actualizaetapa(:p151_id,''ET8'');',
'end if;'))
,p_attribute_02=>'P151_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94272614706663828)
,p_event_id=>wwv_flow_imp.id(94272440933663826)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_server_condition_type=>'EXPRESSION'
,p_server_condition_expr1=>'1=2'
,p_server_condition_expr2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(187248945813684738)
,p_name=>'ValidaFechaET7'
,p_event_sequence=>220
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'EXPRESSION'
,p_display_when_cond=>wwv_flow_string.join(wwv_flow_t_varchar2(
'((:P151_CNT20PIES + :P151_CNT40PIES) < 1 AND :P151_CODIGOETAPA IN (''ET7''))',
'OR ',
'(:P151_ID_MUESTRA IS NOT NULL AND :P151_CODIGOETAPA IN (''ET7''))'))
,p_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(187249091180684739)
,p_event_id=>wwv_flow_imp.id(187248945813684738)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF  (:p151_codigoetapa = ''ET7'' AND :P151_ID_MUESTRA IS NULL) OR ',
'--    (:p151_codigoetapa = ''ET7'' AND :P151_ID_MUESTRA IS NOT NULL AND :P151_REGIMENMUESTRA=''91'') OR',
'    (:p151_codigoetapa = ''ET7'' AND :P151_ID_MUESTRA IS NOT NULL AND :P151_FECHATURNO IS NOT NULL AND :P151_INGRESOREALZM IS NOT NULL)  THEN',
'    ',
'	data.pk_cmex_mesatrabajo.sp_actualizaetapa(:p151_id,''ET8'');',
'end if;'))
,p_attribute_02=>'P151_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(187249183426684740)
,p_event_id=>wwv_flow_imp.id(187248945813684738)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_server_condition_type=>'EXPRESSION'
,p_server_condition_expr1=>'1=2'
,p_server_condition_expr2=>'PLSQL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(94273105280663833)
,p_name=>'ObtenerBitacora'
,p_event_sequence=>230
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(94273066992663832)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94273210618663834)
,p_event_id=>wwv_flow_imp.id(94273105280663833)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.server.process("BitacoraFechaCAS",',
'   {pageItems: "#P151_ID"},',
'    {dataType: "json",',
'    success: function(pData){',
'            $("#bitacorafecha").text("") ;',
'             console.log(pData);',
'            if (pData.result == "S"){',
'        ',
'            const words = pData.bitacoraCAS.split(''$'');',
'            console.log(words);',
'            for (let i = 0; i < words.length; i++){',
'                $("#bitacorafecha").append(words[i]);',
'                $("#bitacorafecha").append(''<p></p>'');',
'            }',
'           }else ',
'               {',
'                    $("#bitacorafecha").text(pData.bitacoraCAS) ;',
'                   ',
'               }',
'            openModal(''DlgBitacoras'');',
'      }',
'   }',
');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(94273364252663835)
,p_name=>'ObtenerBitacora_1'
,p_event_sequence=>240
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(94273511804663837)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94273435713663836)
,p_event_id=>wwv_flow_imp.id(94273364252663835)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.server.process("BitacoraFechaETA",',
'   {pageItems: "#P151_ID"},',
'    {dataType: "json",',
'    success: function(pData){',
'            console.log(pData);',
'               $("#bitacorafecha").text("") ;',
'            if (pData.result == "S") {',
'        ',
'           //  $("#bitacorafecha").text(pData.bitacoraETA);',
'        ',
'            const words = pData.bitacoraETA.split(''$'');',
'            console.log(words);',
'            for (let i = 0; i < words.length; i++){',
'                $("#bitacorafecha").append(words[i]);',
'                $("#bitacorafecha").append(''<p></p>'');',
'            }',
'',
'           } else {',
'               $("#bitacorafecha").text(pData.bitacoraETA) ;',
'           }',
'            openModal(''DlgBitacoras'');',
'  ',
'      }',
'   }',
');'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(64132664374537813)
,p_name=>'Tramite Observado'
,p_event_sequence=>250
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P151_TIPOAFORO'
,p_condition_element=>'P151_TIPOAFORO'
,p_triggering_condition_type=>'IN_LIST'
,p_triggering_expression=>'AF_3,AF_4'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(64132711844537814)
,p_event_id=>wwv_flow_imp.id(64132664374537813)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P151_TRAMITEOBS'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(64132829067537815)
,p_event_id=>wwv_flow_imp.id(64132664374537813)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P151_TRAMITEOBS'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(84301877789155702)
,p_name=>'Rechaza Registro'
,p_event_sequence=>260
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(84301747447155701)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(84301942278155703)
,p_event_id=>wwv_flow_imp.id(84301877789155702)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEst\00E1 seguro de rechazar el registro de la importaci\00F3n? Se cambiar\00E1 a Etapa 1.')
,p_attribute_02=>'Rechazo de Registro'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(84302120734155705)
,p_event_id=>wwv_flow_imp.id(84301877789155702)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(84302021787155704)
,p_event_id=>wwv_flow_imp.id(84301877789155702)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_idmesa number;',
'begin',
'	v_idmesa := :p151_id;',
'',
'	data.pk_cmex_mesatrabajo.sp_notificaetapa(p_idmesa => v_idmesa, p_usuario => :app_user, p_opcion => ''R''); commit;',
'end;'))
,p_attribute_02=>'P151_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(84302213881155706)
,p_event_id=>wwv_flow_imp.id(84301877789155702)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ocultarBarra();',
'$(''#btnAtras'').trigger("click");'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(308906700314281442)
,p_name=>'Rechaza Registro_1'
,p_event_sequence=>270
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(308906653991281441)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(308906932178281444)
,p_event_id=>wwv_flow_imp.id(308906700314281442)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mostrarBarra();',
'$s(''P151_COMENTARIO_A'',this.data.G_COMENTARIO);',
'$s(''P151_COMENTARIOUSUARIO'',this.data.G_USUARIOS_LISTA);'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(308907082647281445)
,p_event_id=>wwv_flow_imp.id(308906700314281442)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_idmesa number;',
'begin',
'	v_idmesa := :p151_id;',
'',
'	data.pk_cmex_mesatrabajo.sp_notificaetapa(p_idmesa => v_idmesa, p_usuario => :app_user, p_opcion => ''R'',p_comentario=>:P151_COMENTARIO_A); commit;',
'end;'))
,p_attribute_02=>'P151_ID,P151_COMENTARIO_A'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(308907133238281446)
,p_event_id=>wwv_flow_imp.id(308906700314281442)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ocultarBarra();',
'$(''#btnAtras'').trigger("click");'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(520046417192817246)
,p_name=>'Cerrar Dialogo'
,p_event_sequence=>280
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(79531274746966443)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
,p_created_on=>wwv_flow_imp.dz('20241128145608Z')
,p_updated_on=>wwv_flow_imp.dz('20241128152635Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(520046598548817247)
,p_event_id=>wwv_flow_imp.id(520046417192817246)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(520045337200817235)
,p_created_on=>wwv_flow_imp.dz('20241128145608Z')
,p_updated_on=>wwv_flow_imp.dz('20241128150144Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(521164894944341801)
,p_event_id=>wwv_flow_imp.id(520046417192817246)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20241128152320Z')
,p_updated_on=>wwv_flow_imp.dz('20241128152635Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(94271711338663819)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Observaciones'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_fechacas date;',
'v_fechaeta date;',
'begin',
'	pk_cmex_mesatrabajo.sp_bitacora_fecha_cas_eta(',
'		p_idmesa => :p151_id',
'		, p_fechacas => :p151_fechacas',
'		, p_fechaeta => :p151_fechaeta',
'	);',
'',
'	pk_cmex_mesatrabajo.sp_observaciones_imp (',
'		p_idmesa => :p151_id',
'		, p_observacion => :p151_observaciones',
'	);',
'',
'	-- Actualizar las fechas',
'	data.pk_cmex_mesatrabajo.sp_fechasjde(:p151_id);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>':P151_ID_MUESTRA is null'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>94271711338663819
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(64133762650537824)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Guardar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_idmesa	number;',
'v_cnt20		number;',
'v_cnt40		number;',
'v_idetapa	varchar2(3);',
'v_log_app	varchar2(1000);',
'v_log_dsc	varchar2(1000);',
'begin',
'	v_log_app	:= ''apex.130.151.guardar'';',
'	v_idmesa	:= :p151_id;',
'	v_idetapa	:= :p151_codigoetapa;',
'	v_cnt20		:= nvl(:p151_cnt20pies,0);',
'	v_cnt40		:= nvl(:p151_cnt40pies,0);',
'',
unistr('	v_log_dsc	:= ''Par\00E1metros: v_idmesa: ''||nvl(:p151_id,''[null]'');'),
'	pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,null,null,null);',
'',
'	if v_cnt20 > 0 or v_cnt40 > 0 then',
'		begin',
'			select sum(y.pesobruto) into :p151_pesobruto from t_cmex_detallecontenedor y where y.id_cmex_mesatrabajo = v_idmesa;',
'',
'			exception when others then :p151_pesobruto := 0;',
'		end;',
'	end if;',
'',
unistr('	-- Actualizaci\00F3n de datos'),
'	begin',
'		update t_cmex_mesatrabajo x set',
'			-- Etapa 1',
'			x.observaciones = :p151_observaciones',
'			-- Etapa 2',
'			, x.agenteaduana = :p151_agenteaduana',
'			, x.aplicacionseguro = :p151_aplicacionseguro',
'			, x.bultospallets = :p151_bultospallets',
'			, x.cnt20pies = v_cnt20',
'			, x.cnt40pies = v_cnt40',
'			, x.conocimientoembarque = :p151_conocimientoembarque',
'			, x.cubicaje = :p151_cubicaje',
'			, x.fechaeta = :p151_fechaeta',
'			, x.fechaetd = :p151_fechaetd',
'			, x.fecharec = :p151_fecharec',
'			, x.forwarder = upper(trim(:p151_forwarder))',
'			, x.naviera = upper(trim(:p151_naviera))',
'			, x.numfactura = :p151_numfactura',
'			, x.ordenagente = :p151_ordenagente',
'			, x.paisorigen = :p151_paisorigen',
'			, x.pesobruto = :p151_pesobruto',
'			, x.pesoneto = :p151_pesoneto',
'			, x.puertoorigen = :p151_puertoorigen',
'			, X.DOCUMENTOEMBARQUE = :P151_DOCUMENTOEMBARQUE',
'			-- Etapa 3',
'			, x.bodega = :p151_bodega',
'			, x.distrito = :p151_distrito',
'			, x.manifiestocarga = :p151_manifiestocarga',
'			, x.fechaduc = :p151_fechaduc',
'			-- Etapa 4',
'			, x.cargaliberada = :p151_cargaliberada',
'			, x.fechacargaliberada = :p151_fechacargaliberada',
'			, x.fechacas = :p151_fechacas',
'			, x.fechadav = :p151_fechadav',
'			, x.fechaliq = :p151_fechaliq',
'			, x.motivoincplan = :p151_motivoincplan',
'			, x.tramiteobs = :p151_tramiteobs',
'			, x.valoraduana = :p151_valoraduana',
'			, x.valorivaliq = :p151_valorivaliq',
'			--Etapa 7 impotacion de muestras',
'			, x.fechaturno = :p151_fechaturno',
'			, x.fecharealzm = :p151_ingresorealzm',
'		where id = v_idmesa;',
'',
'		update data.t_cmex_tramitesaduana x set',
'			x.numeroliquidacion = :p151_numeroliquidacion',
'			, x.refrendo = :p151_refrendo',
'		where id_cmex_mesatrabajo = v_idmesa;',
'	end;',
'',
'	-- Acciones por etapa',
'	begin',
'		if v_idetapa = ''ET2'' then',
'			data.pk_cmex_mesatrabajo.sp_finalizaetapa2(',
'				v_idmesa',
'				, :p151_conocimientoembarque',
'				, :p151_naviera',
'				, :p151_ordenagente',
'				, :p151_numfactura',
'				, :p151_aplicacionseguro',
'				, :p151_cnt40pies',
'				, :p151_cnt20pies',
'				, :p151_bultospallets',
'				, :p151_pesoneto',
'				, :p151_pesobruto',
'				, :p151_cubicaje',
'				, :p151_paisorigen',
'				, :p151_fechaeta',
'			);',
'		elsif v_idetapa = ''ET3'' then',
'			data.pk_cmex_mesatrabajo.sp_finalizaetapa3(',
'				v_idmesa',
'				, null',
'				, :p151_bodega',
'				, :p151_manifiestocarga',
'				, null',
'				, :p151_distrito',
'			);',
'		elsif v_idetapa = ''ET4'' then',
'			data.pk_cmex_mesatrabajo.sp_finalizaetapa4(',
'				v_idmesa',
'				, :p151_fechaliq',
'				, :p151_fechapago_liq',
'				, :p151_tipoaforo',
'				, :p151_tipodespacho',
'				, :p151_refrendo',
'				, :p151_numeroliquidacion',
'				, :p151_fechacas',
'				, :p151_cargaliberada',
'				, :p151_fechacargaliberada',
'				, :p151_avisopago_liquidacion',
'			);',
'',
unistr('			-- \00DAltimo cambio con TPALACIOS [03/02/2024]'),
'			-- pk_cmex_mesatrabajo.sp_enviarcorreoavisopago(v_idmesa);',
'		end if;',
'	end;',
'',
'	data.pk_cmex_mesatrabajo.sp_fechasjde(v_idmesa);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(64133827441537825)
,p_internal_uid=>64133762650537824
,p_updated_on=>wwv_flow_imp.dz('20250218135620Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(74058670973884703)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Etapa 1'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    update data.t_cmex_datoscomplementarios x set x.observaciones = :p151_observaciones where id_cmex_mesatrabajo = :p151_id;',
'    commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error en el proceso: ET1'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>':P151_ID_MUESTRA is null'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_process_success_message=>'Guardado'
,p_internal_uid=>74058670973884703
,p_updated_on=>wwv_flow_imp.dz('20241128153115Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(74059930883884716)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Etapa 2'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_idmesa number;',
'begin',
'	v_idmesa := :p151_id;',
'	if :p151_codigoetapa = ''ET2'' then',
'		if :p151_cnt20pies is null then',
'			:p151_cnt20pies := 0;',
'		end if;',
'',
'		if :p151_cnt40pies is null then',
'			:p151_cnt40pies := 0;',
'		end if;',
'',
'		begin',
'			update t_cmex_mesatrabajo x set',
'				x.puertoorigen = :p151_puertoorigen',
'				, x.agenteaduana = :p151_agenteaduana',
'				, x.forwarder = upper(trim(:p151_forwarder))',
'				, x.conocimientoembarque = :p151_conocimientoembarque',
'				, x.cnt20pies = :p151_cnt20pies',
'				, x.cnt40pies = :p151_cnt40pies',
'				, x.naviera = upper(trim(:p151_naviera))',
'				, x.ordenagente = :p151_ordenagente',
'				, x.numfactura = :p151_numfactura',
'				, x.bultospallets = :p151_bultospallets',
'				, x.pesoneto = :p151_pesoneto',
'				, x.pesobruto = :p151_pesobruto',
'				, x.cubicaje = :p151_cubicaje',
'				, x.paisorigen = :p151_paisorigen',
'				, x.aplicacionseguro = :p151_aplicacionseguro',
'				, x.fechaeta = :p151_fechaeta',
'				, x.fechaetd = :p151_fechaetd',
'				, x.fecharec = :p151_fecharec',
'                , X.DOCUMENTOEMBARQUE = :P151_DOCUMENTOEMBARQUE',
'			where id = v_idmesa;',
'			commit;',
'		end;',
'',
'		data.pk_cmex_mesatrabajo.sp_finalizaetapa2(',
'			v_idmesa',
'			, :p151_conocimientoembarque',
'			, :p151_naviera',
'			, :p151_ordenagente',
'			, :p151_numfactura',
'			, :p151_aplicacionseguro',
'			, :p151_cnt40pies',
'			, :p151_cnt20pies',
'			, :p151_bultospallets',
'			, :p151_pesoneto',
'			, :p151_pesobruto',
'			, :p151_cubicaje',
'			, :p151_paisorigen',
'			, :p151_fechaeta',
'		);',
'',
'		-- Actualizar las fechas',
'		data.pk_cmex_mesatrabajo.sp_fechasjde(v_idmesa);',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error en el proceso: ET2'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(74059868367884715)
,p_process_success_message=>'Guardado'
,p_internal_uid=>74059930883884716
,p_updated_on=>wwv_flow_imp.dz('20241128153115Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(74682966834609821)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Etapa 3'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_idmesa number;',
'v_idetapa varchar2(10);',
'begin',
'	v_idmesa	:= :p151_id;',
'	v_idetapa	:= :p151_codigoetapa;',
'	if v_idetapa = ''ET3'' then',
'		update data.t_cmex_mesatrabajo ',
'			set bodega = :p151_bodega',
'			, manifiestocarga = :p151_manifiestocarga',
'			, distrito = :p151_distrito',
'		where id = v_idmesa;',
'',
'		data.pk_cmex_mesatrabajo.sp_finalizaetapa3(',
'			v_idmesa',
'			, null',
'			, :p151_bodega',
'			, :p151_manifiestocarga',
'			, null',
'			, :p151_distrito',
'		);',
'',
'		-- Actualizar las fechas',
'		data.pk_cmex_mesatrabajo.sp_fechasjde(v_idmesa);',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error en el proceso: ET3'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(74682870667609820)
,p_process_success_message=>'Guardado'
,p_internal_uid=>74682966834609821
,p_updated_on=>wwv_flow_imp.dz('20241128153115Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(74684375607609835)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Etapa 4'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_idmesa number;',
'v_idetapa varchar2(10);',
'begin',
'	v_idmesa	:= :p151_id;',
'	v_idetapa	:= :p151_codigoetapa;',
'	if v_idetapa = ''ET4'' then',
'		update data.t_cmex_mesatrabajo',
'			set fechadav = :p151_fechadav',
'				, fechaliq = :p151_fechaliq',
'				, fechacas = :p151_fechacas',
'				, cargaliberada = :p151_cargaliberada',
'				, fechacargaliberada = :p151_fechacargaliberada',
'				, valoraduana = :p151_valoraduana',
'				, valorivaliq = :p151_valorivaliq',
'				, tramiteobs = :p151_tramiteobs',
'				, motivoincplan = :p151_motivoincplan',
'		where id = v_idmesa;',
'',
'		data.pk_cmex_mesatrabajo.sp_finalizaetapa4(',
'			v_idmesa',
'			, :p151_fechaliq',
'			, :p151_fechapago_liq',
'			, :p151_tipoaforo',
'			, :p151_tipodespacho',
'			, :p151_refrendo',
'			, :p151_numeroliquidacion',
'			, :p151_fechacas',
'			, :p151_cargaliberada',
'			, :p151_fechacargaliberada',
'			, :p151_avisopago_liquidacion',
'		);',
'',
'		-- Actualizar las fechas',
'		data.pk_cmex_mesatrabajo.sp_fechasjde(v_idmesa);',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error en el proceso: ET4'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(74684287423609834)
,p_process_success_message=>'Guardado'
,p_internal_uid=>74684375607609835
,p_updated_on=>wwv_flow_imp.dz('20250218135452Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(94272221546663824)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Etapa 5'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    data.pk_cmex_mesatrabajo.sp_actualizaetapa(:p151_id,''ET6'');',
'',
'    -- Actualizar las Fechas',
'    data.pk_cmex_mesatrabajo.sp_fechasjde(:p151_id);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error en el proceso: ET5'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'FINALIZARETAPA5'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_process_success_message=>'Guardado'
,p_internal_uid=>94272221546663824
,p_updated_on=>wwv_flow_imp.dz('20241128153115Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(94272360529663825)
,p_process_sequence=>80
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Etapa 7'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	data.pk_cmex_mesatrabajo.sp_actualizaetapa(:p151_id,''ET8'');',
'',
'	-- Actualizar las Fechas',
'	data.pk_cmex_mesatrabajo.sp_fechasjde(:p151_id);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error en el proceso: ET7'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'FINALIZARETAPA7'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_process_success_message=>'Guardado'
,p_internal_uid=>94272360529663825
,p_updated_on=>wwv_flow_imp.dz('20241128153115Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(94270950270663811)
,p_process_sequence=>90
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Etapa 8'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	data.pk_cmex_mesatrabajo.sp_actualizaetapa(:p151_id,''ET9'');',
'	update data.t_cmex_mesatrabajo x set x.fecha_finaliza = sysdate where x.id = :p151_id;',
'',
'	-- Actualizar las fechas',
'	data.pk_cmex_mesatrabajo.sp_fechasjde(:p151_id);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Error en el proceso: ET8'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(94271091396663812)
,p_process_success_message=>'Guardado'
,p_internal_uid=>94270950270663811
,p_updated_on=>wwv_flow_imp.dz('20241128153115Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(74630789134117214)
,p_process_sequence=>100
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga Archivos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_valor number;',
'begin',
'	data.pk_apex_archivos.sp_creararchivo(',
'		:p151_archivo',
'		, ''T_CMEX_MESATRABAJO''',
'		, :p151_id',
'		, :p151_tipoarchivo_subir',
'		, :p151_observacion_archivo',
'		, :app_user',
'		, v_valor',
'	);',
'',
'	update files.t_apex_archivos set estado = 1 where numeroarchivo = v_valor;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(74630857480117215)
,p_internal_uid=>74630789134117214
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(85661509767724829)
,p_process_sequence=>110
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Auditor\00EDa')
,p_process_sql_clob=>'update data.t_cmex_mesatrabajo set usermodi = :app_user, fechmodi = sysdate where id = :p151_id;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>85661509767724829
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(61445435588698515)
,p_process_sequence=>120
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Notifica Agente'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_idmesa number;',
'begin',
'	v_idmesa := :p151_id;',
'	delete from data.t_cmex_infoagenteaduana where idmesa = v_idmesa;',
'	data.pk_cmex_mesatrabajo.sp_notificacomexagente(v_idmesa);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(61445381061698514)
,p_process_success_message=>unistr('Notificaci\00F3n Enviada.')
,p_internal_uid=>61445435588698515
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(85321406958939440)
,p_process_sequence=>130
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('N\00FAm. Tr\00E1mite')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_idmesa number;',
'begin',
'	v_idmesa := :p151_id;',
'	update t_cmex_mesatrabajo x set x.ordenagente = :p151_ordenagente, x.fechaliq = :p151_fechaliq where id = v_idmesa;',
'',
'	update data.t_cmex_tramitesaduana x set',
'		x.numeroliquidacion = :p151_numeroliquidacion',
'		, x.refrendo = :p151_refrendo',
'	where id_cmex_mesatrabajo = v_idmesa;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(85321373534939439)
,p_process_success_message=>unistr('Tr\00E1mite Actualizado')
,p_internal_uid=>85321406958939440
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(187249206197684741)
,p_process_sequence=>140
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Notifica_inicador'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('-- se notifica al iniciador del tramite de importaci\00F3n de la MUESTRA'),
'pk_cmex_mesatrabajo.sp_notificainiciador(:P151_ID,:P151_FECHATURNO,:P151_CODIGOPROVEEDOR);',
'--NULL;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(187248877646684737)
,p_internal_uid=>187249206197684741
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(73870963153721916)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Verificaci\00F3n ID')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :p151_id is null then',
'	data.pk_cmex_mesatrabajo.sp_generaridmesatrabajo(''IMP'');',
'',
'	:p151_id := pk_cmex_mesatrabajo.f_obteneridmesatrabajo();',
'',
'	update data.t_cmex_mesatrabajo set usercrea = :app_user, fechcrea = sysdate where id = :p151_id;',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'P151_ID'
,p_process_when_type=>'ITEM_IS_NULL'
,p_internal_uid=>73870963153721916
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(74058499943884701)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga Datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_idmesa number;',
'v_ordenagente1 varchar2(100);	-- Tabla t_cmex_mesatrabajo',
'v_ordenagente2 varchar2(100);	-- Tabla t_cmex_infoagenteaduana',
'v_qty	number;',
'begin',
'	v_idmesa := :p151_id;',
'',
'	if v_idmesa is not null then',
'		begin',
'			select count(*) into v_qty from t_cmex_mesatrabajo',
'			where id = v_idmesa and (nvl(cnt20pies,0) > 0 or nvl(cnt40pies,0) > 0);',
'',
'			if v_qty > 0 then',
'				update t_cmex_mesatrabajo x set x.pesobruto =',
'					(select sum(y.pesobruto) from t_cmex_detallecontenedor y where y.id_cmex_mesatrabajo = x.id)',
'				where x.id = v_idmesa and exists',
'					(select sum(y.pesobruto) from t_cmex_detallecontenedor y where y.id_cmex_mesatrabajo = x.id);',
'				commit;',
'			end if;',
'		end;',
'',
'		-- Datos de mesa de trabajo',
'		select codigoetapa',
'			, ordencompra',
'			, tipooc',
'			, codigoproveedor',
'			, fecharec',
'			, fechaetd',
'			, conocimientoembarque',
'			, naviera',
'			, fechaeta',
'			, ordenagente',
'			, numfactura',
'			, cnt20pies',
'			, cnt40pies',
'			, bultospallets',
'			, pesoneto',
'			, pesobruto',
'			, cubicaje',
'			, paisorigen',
'			, aplicacionseguro',
'			, bodega',
'			, manifiestocarga',
'			, fechadav',
'			, fechaliq',
'			, cargaliberada',
'			, fechacas',
'			, distrito',
'			, fechacargaliberada',
'			, viadespacho',
'			, puertoorigen',
'			, agenteaduana',
'			, forwarder',
'			, valoraduana',
'			, tramiteobs',
'			, motivoincplan',
'			, incmuestra',
'			, to_char(nvl(montooc,0),''FML999G999G999G999G990D00'')',
'			, incoterm',
'			, tipomaterial',
'			, tipoproducto',
'			, fechaduc',
'			, id_muestra',
'			, documentoembarque',
'			, regimenmuestra',
'			, fechaturno',
'			, fecharealzm',
'			, valorivaliq',
'		into :p151_codigoetapa',
'			, :p151_ordenimportacion',
'			, :p151_tipo_oi',
'			, :p151_codigoproveedor',
'			, :p151_fecharec',
'			, :p151_fechaetd',
'			, :p151_conocimientoembarque',
'			, :p151_naviera',
'			, :p151_fechaeta',
'			, v_ordenagente1 --:p151_ordenagente',
'			, :p151_numfactura',
'			, :p151_cnt20pies',
'			, :p151_cnt40pies',
'			, :p151_bultospallets',
'			, :p151_pesoneto',
'			, :p151_pesobruto',
'			, :p151_cubicaje',
'			, :p151_paisorigen',
'			, :p151_aplicacionseguro',
'			, :p151_bodega',
'			, :p151_manifiestocarga',
'			, :p151_fechadav',
'			, :p151_fechaliq',
'			, :p151_cargaliberada',
'			, :p151_fechacas',
'			, :p151_distrito',
'			, :p151_fechacargaliberada',
'			, :p151_viadespacho',
'			, :p151_puertoorigen',
'			, :p151_agenteaduana',
'			, :p151_forwarder',
'			, :p151_valoraduana',
'			, :p151_tramiteobs',
'			, :p151_motivoincplan',
'			, :p151_incmuestra',
'			, :p151_montooc',
'			, :p151_incoterm',
'			, :p151_tipomercaderia',
'			, :p151_tipoproducto',
'			, :p151_fechaduc',
'			, :p151_id_muestra',
'			, :p151_documentoembarque',
'			, :p151_regimenmuestra',
'			, :p151_fechaturno',
'			, :p151_ingresorealzm',
'			, :p151_valorivaliq',
'		from data.t_cmex_mesatrabajo where id = v_idmesa;',
'',
'		:p151_paisorigenmuestra := :p151_paisorigen;',
'',
'		select count(1) into v_qty from data.t_cmex_infoagenteaduana where idmesa = v_idmesa and ordenagente is not null and estado != ''INGRESADO'';',
'',
'		if v_qty > 0 then',
'			select ordenagente into v_ordenagente2 from data.t_cmex_infoagenteaduana where idmesa = v_idmesa and rownum = 1;',
'			:p151_ordenagente := v_ordenagente2;',
'		else',
'			:p151_ordenagente := v_ordenagente1;',
'		end if;',
'',
'		-- Carga datos complemetarios',
'		begin',
'			select cargaprioritara',
'				, observaciones',
'			into :p151_cargaprioritaria',
'				, :p151_observaciones',
'			from data.t_cmex_datoscomplementarios where id_cmex_mesatrabajo = v_idmesa;',
'',
'			exception when no_data_found then',
'				:p151_incoterm			:= null;',
'				:p151_cargaprioritaria	:= null;',
'				:p151_tipomercaderia	:= null;',
'				:p151_observaciones		:= null;',
'		end;',
'',
'		-- Carga datos de t_cmex_tramitesaduana tramites de aduana',
'		begin',
'			select fechapago_liq',
'				, aforo',
'				, tipodespacho',
'				, refrendo',
'				, numeroliquidacion',
'				, avisopago_liq',
'			into :p151_fechapago_liq',
'				, :p151_tipoaforo',
'				, :p151_tipodespacho',
'				, :p151_refrendo',
'				, :p151_numeroliquidacion',
'				, :p151_avisopago_liquidacion',
'			from data.t_cmex_tramitesaduana where id_cmex_mesatrabajo = v_idmesa;',
'',
'			exception when no_data_found then',
'				:p151_fechapago_liq		:= null;',
'				:p151_tipoaforo			:= null;',
'				:p151_tipodespacho		:= null; ',
'				:p151_refrendo			:= null;',
'				:p151_numeroliquidacion	:= null;',
'		end;',
'',
'		if :p151_codigoetapa = ''ET8'' and data.pk_cmex_mesatrabajo.f_verificaarchivos(v_idmesa,''ET8'') = 1 then',
'			data.pk_cmex_mesatrabajo.sp_actualizaetapa(v_idmesa,''ET9'');',
'			update data.t_cmex_mesatrabajo x set x.fecha_finaliza = sysdate where x.id = v_idmesa;			',
'		end if;',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'Erro en carga de datos'
,p_internal_uid=>74058499943884701
,p_updated_on=>wwv_flow_imp.dz('20250203171235Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(74629962694117206)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'VerificaET2'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_archivos char(1);',
'v_contenedores char(1);',
'v_parametros char(1);',
'v_idetapa varchar2(3);',
'v_reload char(1);',
'v_idmesa number;',
'begin',
'	v_reload	:= ''N'';',
'	v_idmesa	:= :p151_id;',
'',
'	v_idetapa   := data.pk_cmex_mesatrabajo.f_etapa(v_idmesa);',
'',
'	if v_idetapa <> ''ET1'' then',
'		if pk_cmex_mesatrabajo.f_verificaarchivos(p_idmesa => v_idmesa,p_etapa => v_idetapa) = 1 then',
'			v_archivos := ''S'';',
'		else',
'			v_archivos := ''N'';',
'		end if;',
'',
'		if pk_cmex_mesatrabajo.f_verificacontenedores(p_idmesa => v_idmesa) > 0 then',
'			v_contenedores := ''S'';',
'		else',
'			v_contenedores := ''N'';',
'		end if;',
'',
'		if pk_cmex_mesatrabajo.f_verificadatos(p_idmesa => v_idmesa,p_etapa => v_idetapa) = 1 then',
'			v_parametros := ''S'';',
'		else',
'			v_parametros := ''N'';',
'		end if;',
'',
'		data.pk_commons.sp_apex_log(''apex.130.151.ajax.verificaet2'',0,''v_archivos: ''||v_archivos||'', v_parametros: ''||v_parametros||'', v_contenedores: ''||v_contenedores||'', v_idetapa: ''||v_idetapa,null,null,null);',
'',
'		if v_archivos = ''S'' and v_parametros = ''S'' and v_contenedores = ''S'' and v_idetapa = ''ET2'' then',
'			data.pk_cmex_mesatrabajo.sp_actualizaetapa(p_idmesa => v_idmesa,p_etapa => ''ET3'');',
'			v_reload := ''S'';',
'		end if;',
'	end if;',
'    ',
'	apex_json.open_object;',
'	apex_json.write(''archivos'',v_archivos);',
'	apex_json.write(''contenedores'',v_contenedores);',
'	apex_json.write(''parametros'',v_parametros);',
'	apex_json.write(''reload'',v_reload);',
'	apex_json.close_object;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>74629962694117206
,p_updated_on=>wwv_flow_imp.dz('20250203165818Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(75668174655913619)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'VerificaET4'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_archivos char(1);',
'v_parametros char(1);',
'v_idetapa varchar2(3);',
'v_reload char(1);',
'v_idmesa number;',
'begin',
'	v_idmesa := :p151_id;',
'	v_reload := ''N'';',
'',
'	v_idetapa := pk_cmex_mesatrabajo.f_etapa(v_idmesa);',
'',
'	if pk_cmex_mesatrabajo.f_verificaarchivos(p_idmesa => v_idmesa,p_etapa => v_idetapa) > 0 then',
'		v_archivos := ''S'';',
'	else',
'		v_archivos := ''N'';',
'	end if;',
'',
'	if pk_cmex_mesatrabajo.f_verificadatos(p_idmesa => v_idmesa,p_etapa => v_idetapa) = 1 then',
'		v_parametros := ''S'';',
'	else',
'		v_parametros := ''N'';',
'	end if;',
'',
'	data.pk_commons.sp_apex_log(''apex.130.151.ajax.verificaet4'',0,''v_idmesa: ''||v_idmesa||'', v_archivos: ''||v_archivos||'', v_parametros: ''||v_parametros||'', v_idetapa: ''||v_idetapa,null,null,null); commit;',
'	if v_archivos = ''S'' and  v_parametros = ''S'' and v_idetapa = ''ET4'' then',
'		data.pk_cmex_mesatrabajo.sp_actualizaetapa(p_idmesa => v_idmesa,p_etapa => ''ET6'');',
'		v_reload := ''S'';',
'	end if;',
'',
'	apex_json.open_object;',
'	apex_json.write(''archivos'',v_archivos);',
'	apex_json.write(''parametros'',v_parametros);',
'	apex_json.write(''reload'',v_reload );',
'	apex_json.close_object;',
'    -- data.pk_commons.sp_apex_log(''apex.130.151.ajax.verificaet4'',0,''apex_json.open_object: ''||apex_json.get_clob_output,null,null,null); commit;    ',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>75668174655913619
,p_updated_on=>wwv_flow_imp.dz('20250203162702Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(94270655440663808)
,p_process_sequence=>30
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'VerificaET8'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_archivosactuales	number;',
'v_archivos char(1);',
'v_idetapa varchar2(3);',
'v_contenedores number;',
'v_idmesa	number;',
'v_cnt20		number;',
'v_cnt40		number;',
'begin',
'	v_idmesa	:= :p151_id;',
'	v_idetapa	:= pk_cmex_mesatrabajo.f_etapa(v_idmesa);',
'	v_cnt20		:= nvl(:p151_cnt20pies,0);',
'	v_cnt40		:= nvl(:p151_cnt40pies,0);',
'',
'	if v_cnt20 = 0 and v_cnt40 = 0 then',
'		v_archivosactuales := 1;',
'	else ',
'		v_contenedores := v_cnt20 + v_cnt40;',
'		v_archivosactuales := pk_cmex_mesatrabajo.f_verificaarchivos(p_idmesa => v_idmesa,p_etapa => ''ET8'');',
'	end if;',
'',
'	if v_archivosactuales >= 0 then v_archivos := ''S''; else v_archivos := ''N''; end if;',
'',
'	apex_json.open_object;',
'	apex_json.write(''archivos'',v_archivos);',
'	apex_json.close_object;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>94270655440663808
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(94271861386663820)
,p_process_sequence=>40
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'AvisoPagoLiquidacion'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'BEGIN',
'	pk_cmex_mesatrabajo.SP_ENVIARCORREOAVISOPAGO(:P151_ID);',
'	apex_json.open_object;',
'	apex_json.write(''envio'', 1);',
'	apex_json.close_object;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'1=2'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>94271861386663820
,p_updated_on=>wwv_flow_imp.dz('20250217220749Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(94272734703663829)
,p_process_sequence=>50
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'BitacoraFechaETA'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_bitacora VARCHAR2(1000);',
'BEGIN',
'',
'SELECT FECHAETA_BITACORA ',
'INTO v_bitacora',
'FROM T_CMEX_MESATRABAJO ',
'WHERE ID = :P151_ID;',
'',
'apex_json.open_object;',
'    IF v_bitacora IS NULL THEN ',
'    apex_json.write(''result'',''N'');',
'    apex_json.write(''bitacoraETA'',''No existen cambios actualmente'');',
'    ELSE ',
'    apex_json.write(''result'',''S'');',
'    apex_json.write(''bitacoraETA'',v_bitacora);',
'    END IF;',
'apex_json.close_object;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>94272734703663829
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(94272862938663830)
,p_process_sequence=>60
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'BitacoraFechaCAS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'v_bitacora VARCHAR2(1000);',
'BEGIN',
'',
'SELECT FECHACAS_BITACORA ',
'INTO v_bitacora',
'FROM T_CMEX_MESATRABAJO ',
'WHERE ID = :P151_ID;',
'',
'apex_json.open_object;',
'    IF v_bitacora IS NULL THEN ',
'    apex_json.write(''result'',''N'');',
'    apex_json.write(''bitacoraCAS'', ''No existen cambios actualmente'');',
'    ELSE ',
'    apex_json.write(''result'',''S'');',
'    apex_json.write(''bitacoraCAS'', v_bitacora);',
'    END IF;',
'apex_json.close_object;',
'',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>94272862938663830
);
wwv_flow_imp.component_end;
end;
/
