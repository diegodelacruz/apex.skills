prompt --application/pages/page_00103
begin
--   Manifest
--     PAGE: 00103
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>103
,p_name=>unistr('Informaci\00F3n de Producto')
,p_alias=>'INFORMACION-DEL-PRODUCTO'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Informaci\00F3n de Producto')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(regOcultos).hide();'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'17'
,p_created_on=>wwv_flow_imp.dz('20230708132652Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260226174648Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6109808191249101)
,p_plug_name=>'Datos'
,p_region_template_options=>'#DEFAULT#:t-Form--noPadding:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20260225050034Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(355334225402124209)
,p_plug_name=>'Ocultos'
,p_region_name=>'regOcultos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20260223204057Z')
,p_updated_on=>wwv_flow_imp.dz('20260223204057Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6109885012249102)
,p_name=>'P103_PRODUCTO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(6109808191249101)
,p_prompt=>'Producto:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20260225051544Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6110004341249103)
,p_name=>'P103_PRODUCTO_COD'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(6109808191249101)
,p_prompt=>unistr('C\00F3digo:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20260225051544Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6110043690249104)
,p_name=>'P103_STOCK_ACTUAL'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(6109808191249101)
,p_prompt=>'Stock Actual:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20260225051544Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6110187067249105)
,p_name=>'P103_STOCK_TRNASITO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(6109808191249101)
,p_prompt=>unistr('Stock Tr\00E1nsito:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20260225051544Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6110247276249106)
,p_name=>'P103_CONSUMO_PROMEDIO_M'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(6109808191249101)
,p_prompt=>'Cons. Prom. Mes:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20260225051544Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6110421882249107)
,p_name=>'P103_DIAS_INVENTARIO'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(6109808191249101)
,p_prompt=>unistr('D\00EDas Inv.:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20260225051544Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6307070102673158)
,p_name=>'P103_COSTO_COMPRA'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(6109808191249101)
,p_prompt=>unistr('\00DAlt. Costo:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20260225051544Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6307182976673159)
,p_name=>'P103_FECHA_COMPRA'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(6109808191249101)
,p_prompt=>unistr('\00DAlt. Compra:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20260225051544Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6307235619673160)
,p_name=>'P103_STOCK_SIMULADO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(6109808191249101)
,p_prompt=>'Stock Sim.:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20260225051544Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6307391756673161)
,p_name=>'P103_VARACION_PRECIO'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(6109808191249101)
,p_prompt=>'Var. Precio:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20260225051544Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6307520304673162)
,p_name=>'P103_DIAS_INVENTARIO_S'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(6109808191249101)
,p_prompt=>unistr('D\00EDas Inv. Sim.:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20260225051544Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6307580850673163)
,p_name=>'P103_ACOPIO_MAX'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(6109808191249101)
,p_prompt=>unistr('Acopio M\00E1x.:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20260225051544Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6307719615673164)
,p_name=>'P103_ACOPIO_MIN'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(6109808191249101)
,p_prompt=>unistr('Acopio M\00EDn.:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20260225051544Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6307744819673165)
,p_name=>'P103_ULTIMO_SALIDA'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(6109808191249101)
,p_prompt=>unistr('\00DAlt. Salida:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20260225050918Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6307886787673166)
,p_name=>'P103_ULTIMO_FECHA_SALIDA'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(6109808191249101)
,p_prompt=>'Fecha Consulta:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20260225050918Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6307932837673167)
,p_name=>'P103_NUMERO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(6109808191249101)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260225050034Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6308055422673168)
,p_name=>'P103_TIPO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(6109808191249101)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260225050034Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6308183360673169)
,p_name=>'P103_LINEA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(6109808191249101)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260225050034Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(355334342821124210)
,p_name=>'P103_IDGENORDENCOMPRA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(355334225402124209)
,p_prompt=>'Idgenordencompra'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260223204121Z')
,p_updated_on=>wwv_flow_imp.dz('20260223204121Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(367627386650309902)
,p_name=>'P103_CONSUMO_PROMEDIO_D'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(6109808191249101)
,p_prompt=>'Cons. Prom. Diario:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20260225050917Z')
,p_updated_on=>wwv_flow_imp.dz('20260225051544Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(367627227657309901)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Procedimiento'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- ============================================================',
'--  Proceso: Carga de infoproducto bajo demanda',
unistr('--  P\00E1gina  : 103'),
unistr('--  Punto   : BEFORE HEADER \2014 ejecutar ANTES del proceso'),
'--            "Carga de Datos" (SELECT INTO existente)',
'--  Fecha   : 2026-02-19',
'-- ------------------------------------------------------------',
unistr('--  Lee los par\00E1metros de data.t_comp_prodto_proveedr_gestion'),
'--  usando :p103_idgenordencompra, llama al procedimiento',
'--  sp_informacionproducto y persiste el resultado en el campo',
'--  infoproducto del mismo registro.',
'-- ============================================================',
'declare',
'	v_compania		data.t_comp_prodto_proveedr_gestion.compania%type;',
'	v_bodega		data.t_comp_prodto_proveedr_gestion.bodega%type;',
'	v_tipoorden		data.t_comp_prodto_proveedr_gestion.documentotipo_oc%type;',
'	v_numeroorden	data.t_comp_prodto_proveedr_gestion.documento_oc%type;',
'	v_producto		data.t_comp_prodto_proveedr_gestion.codigocortoproducto%type;',
'	v_respuesta		clob;',
'begin',
unistr('	-- 1. Leer par\00E1metros del registro identificado por el id'),
'	select trim(compania)',
'		, trim(bodega)',
'		, trim(documentotipo_oc)',
'		, documento_oc',
'		, codigocortoproducto',
'	into v_compania',
'		, v_bodega',
'		, v_tipoorden',
'		, v_numeroorden',
'		, v_producto',
'	from data.t_comp_prodto_proveedr_gestion',
'	where id = :p103_idgenordencompra;',
'',
unistr('	-- 2. Calcular la informaci\00F3n del producto'),
'	data.pk_comp_gestioncompras.sp_informacionproducto(',
'		p_compania		=> v_compania',
'		, p_bodega		=> v_bodega',
'		, p_tipoorden	=> v_tipoorden',
'		, p_numeroorden	=> v_numeroorden',
'		, p_producto	=> v_producto',
'		, p_respuesta	=> v_respuesta',
'	);',
'',
unistr('	-- 3. Persistir solo si se obtuvo respuesta v\00E1lida'),
'	if v_respuesta is not null then',
'		update data.t_comp_prodto_proveedr_gestion',
'		set infoproducto = v_respuesta',
'		where id = :p103_idgenordencompra;',
'	end if;',
'',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>367627227657309901
,p_created_on=>wwv_flow_imp.dz('20260225035418Z')
,p_updated_on=>wwv_flow_imp.dz('20260225035418Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(6308299783673170)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Carga de Datos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- ============================================================',
unistr('--  Query p\00E1gina 103 \2014 Informaci\00F3n de Producto'),
'--  Fuente: data.t_comp_prodto_proveedr_gestion.infoproducto',
'--  Fecha : 2026-02-25',
'-- ------------------------------------------------------------',
'--  Cambio: p103_consumo_promedio se divide en dos campos:',
'--    :p103_consumo_promedio_m  consumo promedio mensual',
'--    :p103_consumo_promedio_d  consumo promedio diario',
'-- ============================================================',
'select',
'	json_value(infoproducto, ''$.producto'')',
'	, json_value(infoproducto, ''$.codigoproducto'')',
'	, to_char(',
'		json_value(infoproducto, ''$.stock'' returning number)',
'		, ''999G999G999G999G990D00''',
'	)',
'	, to_char(',
'		json_value(infoproducto, ''$.stocktransito'' returning number)',
'		, ''999G999G999G999G990D00''',
'	)',
'	, to_char(',
'		json_value(infoproducto, ''$.consumopromedio_mensual'' returning number)',
'		, ''999G999G999G999G990D00''',
'	)',
'	, to_char(',
'		json_value(infoproducto, ''$.consumopromedio_diario'' returning number)',
'		, ''999G999G999G999G990D00''',
'	)',
'	, to_char(',
'		json_value(infoproducto, ''$.diasinventario'' returning number)',
'		, ''999G999G999G999G990D00''',
'	)',
'	, to_char(',
'		json_value(infoproducto, ''$.ultimoprecio'' returning number)',
'		, ''FML999G999G999G999G990D00''',
'	)',
'	, json_value(infoproducto, ''$.ultimafecha'')',
'	, to_char(',
'		json_value(infoproducto, ''$.stocksimulado'' returning number)',
'		, ''999G999G999G999G990D00''',
'	)',
'	, to_char(',
'		json_value(infoproducto, ''$.diasinventariosim'' returning number)',
'		, ''999G999G999G999G990D00''',
'	)',
'	, to_char(',
'		json_value(infoproducto, ''$.variacionprecio'' returning number)',
'		, ''FM990D00''',
'	) || '' %''',
'	, to_char(',
'		json_value(infoproducto, ''$.cantidadmaxima'' returning number)',
'		, ''999G999G999G999G990D00''',
'	)',
'	, to_char(',
'		json_value(infoproducto, ''$.cantidadminima'' returning number)',
'		, ''999G999G999G999G990D00''',
'	)',
'	, to_char(',
'		json_value(infoproducto, ''$.ultimasalida'' returning number)',
'		, ''999G999G999G999G990D00''',
'	)',
'	, json_value(infoproducto, ''$.ultimafechasalida'')',
'into :p103_producto',
'	, :p103_producto_cod',
'	, :p103_stock_actual',
'	, :p103_stock_trnasito',
'	, :p103_consumo_promedio_m',
'	, :p103_consumo_promedio_d',
'	, :p103_dias_inventario',
'	, :p103_costo_compra',
'	, :p103_fecha_compra',
'	, :p103_stock_simulado',
'	, :p103_dias_inventario_s',
'	, :p103_varacion_precio',
'	, :p103_acopio_max',
'	, :p103_acopio_min',
'	, :p103_ultimo_salida',
'	, :p103_ultimo_fecha_salida',
'from data.t_comp_prodto_proveedr_gestion',
'where id = :p103_idgenordencompra;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>6308299783673170
,p_updated_on=>wwv_flow_imp.dz('20260226174648Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
