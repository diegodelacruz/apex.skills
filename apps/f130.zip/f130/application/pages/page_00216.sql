prompt --application/pages/page_00216
begin
--   Manifest
--     PAGE: 00216
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>216
,p_name=>'Asociar Pago'
,p_alias=>'ASOCIAR-PAGO'
,p_step_title=>'Asociar Pago'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(regOcultos).hide();'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240312172802Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260422150225Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(249937231179133008)
,p_plug_name=>'Ocultos'
,p_region_name=>'regOcultos'
,p_region_template_options=>'t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(295605160997037667)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20260422145040Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(255046632887448346)
,p_plug_name=>unistr('\00CDtems Factura')
,p_parent_plug_id=>wwv_flow_imp.id(249937231179133008)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20240313211859Z')
,p_updated_on=>wwv_flow_imp.dz('20240313211859Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(255046706792448347)
,p_plug_name=>unistr('\00CDtems Negociaci\00F3n')
,p_parent_plug_id=>wwv_flow_imp.id(249937231179133008)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20240313211859Z')
,p_updated_on=>wwv_flow_imp.dz('20240313211859Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(249937494858133010)
,p_plug_name=>unistr('Negociaci\00F3n')
,p_region_name=>'rptNegociacion'
,p_region_template_options=>'t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case when control05 = ''S'' then null',
'		else apex_item.radiogroup(p_idx => 2,p_value => rowid,p_attributes => ''class = "RB02" onchange = $s(P216_TABLANEG,this.value)'') end selneg',
'	, rowid rid',
'	, num01 neg_id',
'	, num02 det_id',
'	, num03 det_codproveedor',
'	, num04 det_codproducto',
'	, txt01 codproducto',
'	, txt02 producto',
'	, txt03 det_codproductoprv',
'	, case when length(txt04) > 20 then substr(txt04,1,20)||''...'' else txt04 end det_desproductoprv',
'	, txt05 det_umproductoprv',
'	, num05 det_preciocal',
'	, num06 det_cantdesde',
'	, num07 det_canthasta',
'	, num08 det_cantmaxima',
'	, case when control05 = ''S'' then to_char(num09)',
'		else apex_item.text(p_idx => 3,p_value => num09,p_item_id => rowid,p_attributes => ''class = "TX01" style="width: 50px; text-align: right;" disabled onchange = $s(P216_VALORNEG,this.value)'') end cantusuario',
'from data.t_apex_temporal',
'where control01 = :g_compania',
'	and control02 = :app_modulo',
'	and control03 = ''apex.130.216.negociacion''',
'	and control04 = :p216_claveacceso',
'	and num01 = :p216_idnegociacion',
'order by control05,txt01,txt03'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P216_IDNEGOCIACION,P216_CLAVEACCESO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('Negociaci\00F3n')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20250421215215Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(249937756519133013)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>249937756519133013
,p_updated_on=>wwv_flow_imp.dz('20250421215215Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(254836689693388409)
,p_db_column_name=>'SELNEG'
,p_display_order=>10
,p_column_identifier=>'BB'
,p_column_label=>'.'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240312173049Z')
,p_updated_on=>wwv_flow_imp.dz('20240313214034Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253660790767572222)
,p_db_column_name=>'RID'
,p_display_order=>20
,p_column_identifier=>'AZ'
,p_column_label=>'RID'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'OTHER'
,p_column_alignment=>'CENTER'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240313214034Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(249937808290133014)
,p_db_column_name=>'NEG_ID'
,p_display_order=>30
,p_column_identifier=>'A'
,p_column_label=>'Neg Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_updated_on=>wwv_flow_imp.dz('20240312173228Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(249938057149133016)
,p_db_column_name=>'DET_ID'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Det Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_updated_on=>wwv_flow_imp.dz('20240312173228Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(249940893892133044)
,p_db_column_name=>'DET_CODPRODUCTO'
,p_display_order=>50
,p_column_identifier=>'AE'
,p_column_label=>unistr('C\00F3d. Producto')
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_updated_on=>wwv_flow_imp.dz('20240312173228Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(249940998574133045)
,p_db_column_name=>'DET_CODPROVEEDOR'
,p_display_order=>60
,p_column_identifier=>'AF'
,p_column_label=>unistr('C\00F3d. Proveedor')
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_updated_on=>wwv_flow_imp.dz('20240312173228Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(249941068089133046)
,p_db_column_name=>'DET_CODPRODUCTOPRV'
,p_display_order=>70
,p_column_identifier=>'AG'
,p_column_label=>unistr('C\00F3d. Prod.*')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240313214034Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(249941194322133047)
,p_db_column_name=>'DET_DESPRODUCTOPRV'
,p_display_order=>80
,p_column_identifier=>'AH'
,p_column_label=>'Producto*'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240313214034Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(249941285149133048)
,p_db_column_name=>'DET_UMPRODUCTOPRV'
,p_display_order=>90
,p_column_identifier=>'AI'
,p_column_label=>'UM Prv.'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_updated_on=>wwv_flow_imp.dz('20240312173228Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253658703917572202)
,p_db_column_name=>'DET_CANTDESDE'
,p_display_order=>100
,p_column_identifier=>'AM'
,p_column_label=>'Cant.'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_updated_on=>wwv_flow_imp.dz('20240312173228Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253658843921572203)
,p_db_column_name=>'DET_CANTHASTA'
,p_display_order=>110
,p_column_identifier=>'AN'
,p_column_label=>'Det Canthasta'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_updated_on=>wwv_flow_imp.dz('20240312173228Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253658999852572204)
,p_db_column_name=>'DET_CANTMAXIMA'
,p_display_order=>120
,p_column_identifier=>'AO'
,p_column_label=>unistr('Cant. M\00E1x.')
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_updated_on=>wwv_flow_imp.dz('20240312173228Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253659286526572207)
,p_db_column_name=>'DET_PRECIOCAL'
,p_display_order=>130
,p_column_identifier=>'AR'
,p_column_label=>'Precio'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240313214034Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253659721568572212)
,p_db_column_name=>'CODPRODUCTO'
,p_display_order=>140
,p_column_identifier=>'AW'
,p_column_label=>unistr('C\00F3d. Producto')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240313214034Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253659821901572213)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>150
,p_column_identifier=>'AX'
,p_column_label=>'Producto'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20240313214034Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(253662902597572244)
,p_db_column_name=>'CANTUSUARIO'
,p_display_order=>160
,p_column_identifier=>'BC'
,p_column_label=>'Cantidad'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240312185658Z')
,p_updated_on=>wwv_flow_imp.dz('20240313214034Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(253693363540581263)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2536934'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SELNEG:CODPRODUCTO:PRODUCTO:DET_CODPRODUCTOPRV:DET_DESPRODUCTOPRV:DET_PRECIOCAL:CANTUSUARIO:'
,p_created_on=>wwv_flow_imp.dz('20240312172802Z')
,p_updated_on=>wwv_flow_imp.dz('20240313144534Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(255043524686448315)
,p_plug_name=>'Pre Orden de Compra'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select rowid rid',
'	, num01 neg_id',
'	, num02 pago_id',
'	, num03 det_codproveedor',
'	, num04 det_codproducto',
'	, txt01 codproducto',
'	, txt02 producto',
'	, txt03 det_codproductoprv',
'	, txt04 det_desproductoprv',
'	, txt05 det_umproductoprv',
'	, num05 det_preciocal',
'	, num06 det_cantdesde',
'	, num07 det_canthasta',
'	, num08 det_cantmaxima',
'	, num09 det_cantidad',
'	, num05*num09 det_total',
'from data.t_apex_temporal',
'where control01 = :g_compania',
'	and control02 = :app_modulo',
'	and control03 = ''apex.130.216.preorden''',
'	and num01 = :p216_idnegociacion',
'	and num02 = :p216_idpago'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''x''',
'from data.t_apex_temporal',
'where control01 = :g_compania',
'	and control02 = :app_modulo',
'	and control03 = ''apex.130.216.preorden''',
'	and num01 = :p216_idnegociacion',
'	and num02 = :p216_idpago'))
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Pre Orden de Compra'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_created_on=>wwv_flow_imp.dz('20240313144419Z')
,p_updated_on=>wwv_flow_imp.dz('20240313214034Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(255043618112448316)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>255043618112448316
,p_created_on=>wwv_flow_imp.dz('20240313144419Z')
,p_updated_on=>wwv_flow_imp.dz('20240313214034Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255043777527448317)
,p_db_column_name=>'RID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'RID'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'OTHER'
,p_column_alignment=>'CENTER'
,p_rpt_show_filter_lov=>'N'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240313144419Z')
,p_updated_on=>wwv_flow_imp.dz('20240313213942Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255043866166448318)
,p_db_column_name=>'NEG_ID'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Neg ID'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240313144419Z')
,p_updated_on=>wwv_flow_imp.dz('20240313213942Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255044037511448320)
,p_db_column_name=>'DET_CODPROVEEDOR'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>unistr('C\00F3d. Proveedor')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240313144419Z')
,p_updated_on=>wwv_flow_imp.dz('20240313213942Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255044176816448321)
,p_db_column_name=>'DET_CODPRODUCTO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>unistr('C\00F3d. Corto Producto')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240313144419Z')
,p_updated_on=>wwv_flow_imp.dz('20240313213942Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255044276929448322)
,p_db_column_name=>'CODPRODUCTO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>unistr('C\00F3d. Producto')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240313144419Z')
,p_updated_on=>wwv_flow_imp.dz('20240313213942Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255044355522448323)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Producto'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240313144420Z')
,p_updated_on=>wwv_flow_imp.dz('20240313213942Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255044485907448324)
,p_db_column_name=>'DET_CODPRODUCTOPRV'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>unistr('C\00F3d. Prod. Prov')
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20240313144420Z')
,p_updated_on=>wwv_flow_imp.dz('20240313164619Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255044579590448325)
,p_db_column_name=>'DET_DESPRODUCTOPRV'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Desc. Prod. Prov.'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240313144420Z')
,p_updated_on=>wwv_flow_imp.dz('20240313213942Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255044693979448326)
,p_db_column_name=>'DET_UMPRODUCTOPRV'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'UM Prov.'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20240313144420Z')
,p_updated_on=>wwv_flow_imp.dz('20240313164619Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255044797019448327)
,p_db_column_name=>'DET_PRECIOCAL'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Precio'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240313144420Z')
,p_updated_on=>wwv_flow_imp.dz('20240313213942Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255044857619448328)
,p_db_column_name=>'DET_CANTDESDE'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Det Cantdesde'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20240313144420Z')
,p_updated_on=>wwv_flow_imp.dz('20240313144420Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255044934754448329)
,p_db_column_name=>'DET_CANTHASTA'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Det Canthasta'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20240313144420Z')
,p_updated_on=>wwv_flow_imp.dz('20240313144420Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255045045147448330)
,p_db_column_name=>'DET_CANTMAXIMA'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Det Cantmaxima'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20240313144420Z')
,p_updated_on=>wwv_flow_imp.dz('20240313144420Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255045125573448331)
,p_db_column_name=>'DET_CANTIDAD'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Cantidad'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240313144420Z')
,p_updated_on=>wwv_flow_imp.dz('20240313213942Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255045297888448332)
,p_db_column_name=>'DET_TOTAL'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Total'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240313144420Z')
,p_updated_on=>wwv_flow_imp.dz('20240313213942Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(255046024335448340)
,p_db_column_name=>'PAGO_ID'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'ID Pago'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240313161427Z')
,p_updated_on=>wwv_flow_imp.dz('20240313213942Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(255921459259047023)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2559215'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODPRODUCTO:PRODUCTO:DET_DESPRODUCTOPRV:DET_PRECIOCAL:DET_CANTIDAD:DET_TOTAL:'
,p_sum_columns_on_break=>'DET_TOTAL'
,p_created_on=>wwv_flow_imp.dz('20240313144453Z')
,p_updated_on=>wwv_flow_imp.dz('20240313213419Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(324225672530539020)
,p_plug_name=>'Detalle Factura'
,p_region_name=>'rptFactura'
,p_region_template_options=>'t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296120252599169164)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case when control05 = ''S'' then null',
'		else apex_item.radiogroup(p_idx => 1,p_value => txt03,p_attributes => ''class = "RB01" onchange = $s(P216_VALORFAC,this.value)'') end selfac',
'	, txt03 codproductoprv',
'	, txt04 desproductoprv',
'	, txt06 umproductoprv',
'	, txt08 enlace',
'	, num03 cantidad',
'	, num04 precio',
'	, num05 total',
'from data.t_apex_temporal',
'where 1 = 1',
'	and control01 = :g_compania',
'	and control02 = :app_modulo',
'	and control03 = ''pk_comp_negociacion.sp_buscarfacturas''',
'	and control04 = to_char(to_number(:p216_idnegociacion))',
'	and txt01 = :p216_claveacceso',
'order by control05,txt03'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P216_IDNEGOCIACION,P216_CLAVEACCESO'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_plug_display_when_condition=>'P216_ORIGENPROVEEDOR'
,p_plug_display_when_cond2=>'PE'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Detalle Factura'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20260422150225Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(324225800327539021)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>324225800327539021
,p_updated_on=>wwv_flow_imp.dz('20260422150225Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(254835875698388401)
,p_db_column_name=>'SELFAC'
,p_display_order=>10
,p_column_identifier=>'AJ'
,p_column_label=>'.'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240312173049Z')
,p_updated_on=>wwv_flow_imp.dz('20240313214034Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(254835912305388402)
,p_db_column_name=>'CODPRODUCTOPRV'
,p_display_order=>20
,p_column_identifier=>'AK'
,p_column_label=>'Cod. Prod.*'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240312173049Z')
,p_updated_on=>wwv_flow_imp.dz('20240313214034Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(254836045232388403)
,p_db_column_name=>'DESPRODUCTOPRV'
,p_display_order=>30
,p_column_identifier=>'AL'
,p_column_label=>'Producto*'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240312173049Z')
,p_updated_on=>wwv_flow_imp.dz('20240313214034Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(254836173370388404)
,p_db_column_name=>'UMPRODUCTOPRV'
,p_display_order=>40
,p_column_identifier=>'AM'
,p_column_label=>'UM*'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240312173049Z')
,p_updated_on=>wwv_flow_imp.dz('20240313214034Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(254836253171388405)
,p_db_column_name=>'ENLACE'
,p_display_order=>50
,p_column_identifier=>'AN'
,p_column_label=>'Enlace'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20240312173049Z')
,p_updated_on=>wwv_flow_imp.dz('20240312173049Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(254836387834388406)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>60
,p_column_identifier=>'AO'
,p_column_label=>'Cant. Fact.'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240312173049Z')
,p_updated_on=>wwv_flow_imp.dz('20240313214034Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(254836462160388407)
,p_db_column_name=>'PRECIO'
,p_display_order=>70
,p_column_identifier=>'AP'
,p_column_label=>'Precio Fact.'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240312173049Z')
,p_updated_on=>wwv_flow_imp.dz('20240313214034Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(254836536377388408)
,p_db_column_name=>'TOTAL'
,p_display_order=>80
,p_column_identifier=>'AQ'
,p_column_label=>'Total'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240312173049Z')
,p_updated_on=>wwv_flow_imp.dz('20240313214034Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(500047644358956530)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2464002'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SELFAC:CODPRODUCTOPRV:DESPRODUCTOPRV:UMPRODUCTOPRV:CANTIDAD:PRECIO:TOTAL:'
,p_sum_columns_on_break=>'TOTAL'
,p_created_on=>wwv_flow_imp.dz('20240312172802Z')
,p_updated_on=>wwv_flow_imp.dz('20240312173540Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(361109816412015701)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(382189980363912581)
,p_plug_name=>'Alerta'
,p_region_name=>'regItems'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(295605160997037667)
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<h4>Diferencia detectada entre el valor de la <strong>Factura</strong> y el <strong>Pago</strong>.</h4>',
unistr('<h5>El precio y/o la cantidad de los \00EDtems registrados en la factura.</h5>'),
'<h5>En caso de tratarse de un proveedor del exterior, <strong>debe adjuntar los archivos de soporte correspondientes</strong>.</h5>'))
,p_plug_display_condition_type=>'ITEM_IS_NOT_ZERO'
,p_plug_display_when_condition=>'P216_CONTADOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20240313203752Z')
,p_updated_on=>wwv_flow_imp.dz('20250422145702Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(649023998851697410)
,p_plug_name=>'Soporte'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P216_BANDERA'
,p_plug_display_when_cond2=>'APROBACION'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20250326174019Z')
,p_updated_on=>wwv_flow_imp.dz('20251030210542Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(649024695057697417)
,p_plug_name=>'Archivos'
,p_parent_plug_id=>wwv_flow_imp.id(649023998851697410)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select filename archivo',
'	, fecha fecha_carga',
'	, dbms_lob.getlength(blobcontent) blobcontent',
'	, numeroarchivo',
'	, tipo tipoarchivo',
'	, ''<span aria-hidden="true" class="fa fa-trash-o"></span>'' eliminar',
'	, pk_commons.f_googledocview(numeroarchivo,mimetype) enlace',
'from files.t_apex_archivos',
'where 1 = 1',
'	and tabla = ''VT_COMP_PAGOSRECURRENTES''',
'	and id_tabla = :p216_identidad',
'	and nvl(tipo,''X'') = nvl(tipo,''X'')',
'order by numeroarchivo desc'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Archivos'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_created_on=>wwv_flow_imp.dz('20250327151154Z')
,p_updated_on=>wwv_flow_imp.dz('20250422144016Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(649024749475697418)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>649024749475697418
,p_created_on=>wwv_flow_imp.dz('20250327151154Z')
,p_updated_on=>wwv_flow_imp.dz('20250422144016Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(649024874618697419)
,p_db_column_name=>'ARCHIVO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Archivo'
,p_column_link=>'#ENLACE#'
,p_column_linktext=>'#ARCHIVO#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250327151154Z')
,p_updated_on=>wwv_flow_imp.dz('20250327192954Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(649024933331697420)
,p_db_column_name=>'FECHA_CARGA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Fecha Carga'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250327151154Z')
,p_updated_on=>wwv_flow_imp.dz('20250327192954Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(649025302093697424)
,p_db_column_name=>'ELIMINAR'
,p_display_order=>30
,p_column_identifier=>'F'
,p_column_label=>'Eliminar'
,p_column_link=>'javascript: $s(''P216_IDBORRAR'','''');$s(''P216_IDBORRAR'',''#NUMEROARCHIVO#'');'
,p_column_linktext=>'#ELIMINAR#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250327151154Z')
,p_updated_on=>wwv_flow_imp.dz('20250327193015Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(649025070481697421)
,p_db_column_name=>'BLOBCONTENT'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Blobcontent'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250327151154Z')
,p_updated_on=>wwv_flow_imp.dz('20250327193015Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(649025177668697422)
,p_db_column_name=>'NUMEROARCHIVO'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Numeroarchivo'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250327151154Z')
,p_updated_on=>wwv_flow_imp.dz('20250327193015Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(649025265709697423)
,p_db_column_name=>'TIPOARCHIVO'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Tipoarchivo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250327151154Z')
,p_updated_on=>wwv_flow_imp.dz('20250327193015Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(649025465341697425)
,p_db_column_name=>'ENLACE'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Enlace'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20250327151154Z')
,p_updated_on=>wwv_flow_imp.dz('20250327193015Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(680536149789158959)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'6805362'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ARCHIVO:FECHA_CARGA:ELIMINAR:BLOBCONTENT:NUMEROARCHIVO:TIPOARCHIVO:ENLACE'
,p_created_on=>wwv_flow_imp.dz('20250421204704Z')
,p_updated_on=>wwv_flow_imp.dz('20250421204704Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(253500054033881364)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(361109816412015701)
,p_button_name=>'REGRESAR'
,p_button_static_id=>'btnRegresar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:215:&SESSION.::&DEBUG.:214::'
,p_icon_css_classes=>'fa-arrow-left'
,p_updated_on=>wwv_flow_imp.dz('20240313211658Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(253500467571881364)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(361109816412015701)
,p_button_name=>'GENERAR'
,p_button_static_id=>'btnGenerar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Generar Pago'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''x''',
'from data.t_apex_temporal',
'where control01 = :g_compania',
'	and control02 = :app_modulo',
'	and control03 = ''apex.130.216.preorden''',
'	and num01 = :p216_idnegociacion',
'	and num02 = :p216_idpago',
'	and :p216_contador = 0'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-cart-lock'
,p_updated_on=>wwv_flow_imp.dz('20250326172852Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(255045355215448333)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(255043524686448315)
,p_button_name=>'ELIMINAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Eliminar Detalle'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-trash-o'
,p_created_on=>wwv_flow_imp.dz('20240313150446Z')
,p_updated_on=>wwv_flow_imp.dz('20240313214244Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(253663427607572249)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(249937494858133010)
,p_button_name=>'ENVIAR'
,p_button_static_id=>'btnEnviar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Enviar a OC'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-cart-plus'
,p_created_on=>wwv_flow_imp.dz('20240312202220Z')
,p_updated_on=>wwv_flow_imp.dz('20240313214322Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(249937508038133011)
,p_name=>'P216_CLAVEACCESO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(249937231179133008)
,p_prompt=>'Clave de Acceso:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20240313210127Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(249937671232133012)
,p_name=>'P216_IDNEGOCIACION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(249937231179133008)
,p_prompt=>unistr('ID Negociaci\00F3n:')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_updated_on=>wwv_flow_imp.dz('20240313210127Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(253660356003572218)
,p_name=>'P216_VALORFAC'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(255046632887448346)
,p_prompt=>'Valor FAC:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20240313211859Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(253660498442572219)
,p_name=>'P216_TABLANEG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(255046706792448347)
,p_prompt=>'Tabla NEG:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20240313211859Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(253660592483572220)
,p_name=>'P216_VALORNEG'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(255046706792448347)
,p_prompt=>'Valor NEG:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20240313211859Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(255043111133448311)
,p_name=>'P216_TABLAFAC'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(255046632887448346)
,p_prompt=>'Tabla FAC:'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20240312214441Z')
,p_updated_on=>wwv_flow_imp.dz('20240313211859Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(255045841032448338)
,p_name=>'P216_IDPAGO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(249937231179133008)
,p_prompt=>'ID Pago:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240313150626Z')
,p_updated_on=>wwv_flow_imp.dz('20240313210127Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(255046435690448344)
,p_name=>'P216_BANDERA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(249937231179133008)
,p_prompt=>'Bandera:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240313205811Z')
,p_updated_on=>wwv_flow_imp.dz('20240313210128Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(255046524650448345)
,p_name=>'P216_MENSAJE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(249937231179133008)
,p_prompt=>'ID Pago:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240313210025Z')
,p_updated_on=>wwv_flow_imp.dz('20240313210128Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(300487625609773250)
,p_name=>'P216_CODPROVEEDOR'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(249937231179133008)
,p_prompt=>'Codproveedor'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20240527152852Z')
,p_updated_on=>wwv_flow_imp.dz('20240527153031Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(649023188390697402)
,p_name=>'P216_TIPOMONTO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(249937231179133008)
,p_prompt=>'Tipomonto'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250324221143Z')
,p_updated_on=>wwv_flow_imp.dz('20250324221143Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(649023219793697403)
,p_name=>'P216_ORIGENPROVEEDOR'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(249937231179133008)
,p_prompt=>'Origenproveedor'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250324221143Z')
,p_updated_on=>wwv_flow_imp.dz('20250324221143Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(649023482836697405)
,p_name=>'P216_IDENTIDAD'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(249937231179133008)
,p_prompt=>'Identidad'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250325220649Z')
,p_updated_on=>wwv_flow_imp.dz('20250325220649Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(649023708377697408)
,p_name=>'P216_CONTADOR'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(249937231179133008)
,p_prompt=>'Contador'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250326172852Z')
,p_updated_on=>wwv_flow_imp.dz('20250326172852Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(649024032368697411)
,p_name=>'P216_ARCHIVO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(649023998851697410)
,p_prompt=>'Archivo'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'SESSION'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
,p_created_on=>wwv_flow_imp.dz('20250326174651Z')
,p_updated_on=>wwv_flow_imp.dz('20250326174651Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(649025548679697426)
,p_name=>'P216_IDBORRAR'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(249937231179133008)
,p_prompt=>'Idborrar'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250327195605Z')
,p_updated_on=>wwv_flow_imp.dz('20250327195605Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(680428475568803008)
,p_name=>'P216_ARCHIVOS'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(249937231179133008)
,p_prompt=>'Archivos'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20250422144723Z')
,p_updated_on=>wwv_flow_imp.dz('20250422144723Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(253663071957572245)
,p_name=>'Guardar Cantidad'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.TX01'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20240312191601Z')
,p_updated_on=>wwv_flow_imp.dz('20250818134210Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(253663184437572246)
,p_event_id=>wwv_flow_imp.id(253663071957572245)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	-- update t_apex_temporal x set x.num09 = nvl(replace(:p216_valorneg,'','',''.''),0) where rowid = :p216_tablaneg;',
'	update t_apex_temporal x set x.num09 = data.pk_commons.safe_to_number(:p216_valorneg) where rowid = :p216_tablaneg;',
'end;'))
,p_attribute_02=>'P216_TABLANEG,P216_VALORNEG'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240312191601Z')
,p_updated_on=>wwv_flow_imp.dz('20250818134210Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(255042216208448302)
,p_name=>unistr('CH Bot\00F3n Enviar')
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P216_VALORFAC,P216_TABLANEG'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20240312203620Z')
,p_updated_on=>wwv_flow_imp.dz('20250421220503Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(255042335176448303)
,p_event_id=>wwv_flow_imp.id(255042216208448302)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (($v(''P216_VALORFAC'') != '''' || $v(''P216_ORIGENPROVEEDOR'') == ''PE'') && $v(''P216_TABLANEG'') != '''') {',
'	$(''#btnEnviar'').show();',
'} else {',
'	$(''#btnEnviar'').hide();',
'}'))
,p_created_on=>wwv_flow_imp.dz('20240312203620Z')
,p_updated_on=>wwv_flow_imp.dz('20250421220503Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(255042496474448304)
,p_name=>unistr('PL Bot\00F3n Enviar')
,p_event_sequence=>50
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
,p_created_on=>wwv_flow_imp.dz('20240312203818Z')
,p_updated_on=>wwv_flow_imp.dz('20240312203818Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(255042524927448305)
,p_event_id=>wwv_flow_imp.id(255042496474448304)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#btnEnviar'').hide();'
,p_created_on=>wwv_flow_imp.dz('20240312203818Z')
,p_updated_on=>wwv_flow_imp.dz('20240312203818Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(255042627879448306)
,p_name=>unistr('Selecci\00F3n Negociaci\00F3n')
,p_event_sequence=>60
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.RB02'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20240312211333Z')
,p_updated_on=>wwv_flow_imp.dz('20240312211542Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(255042711022448307)
,p_event_id=>wwv_flow_imp.id(255042627879448306)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''.TX01'').each(function(i,obj){',
'	if($(obj).attr(''id'') === $v(''P216_TABLANEG'')) {',
'		this.disabled = false;',
'	} else {',
'		this.disabled = true;',
'	}',
'});'))
,p_created_on=>wwv_flow_imp.dz('20240312211335Z')
,p_updated_on=>wwv_flow_imp.dz('20240312211335Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(255042850613448308)
,p_name=>'Enviar OC'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(253663427607572249)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20240312214442Z')
,p_updated_on=>wwv_flow_imp.dz('20240527163013Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(255042912141448309)
,p_event_id=>wwv_flow_imp.id(255042850613448308)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
,p_created_on=>wwv_flow_imp.dz('20240312214443Z')
,p_updated_on=>wwv_flow_imp.dz('20240312214443Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(255043007104448310)
,p_event_id=>wwv_flow_imp.id(255042850613448308)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_idneg			number;',
'v_idpago		number;',
'v_log_qty		number;',
'v_compania		varchar2(5);',
'v_modulo		varchar2(9);',
'v_log_app		varchar2(100);',
'v_claveacceso	varchar2(100);',
'v_valorfac		varchar2(100);',
'v_tablaneg		varchar2(100);',
'begin',
'	v_compania		:= :g_compania;',
'	v_modulo		:= :app_modulo;',
'	v_idneg			:= to_number(:p216_idnegociacion);',
'	v_idpago		:= to_number(:p216_idpago);',
'	v_claveacceso	:= :p216_claveacceso;',
'	v_valorfac		:= :p216_valorfac;',
'	v_tablaneg		:= :p216_tablaneg;',
'	v_log_app		:= ''apex.130.216.preorden'';',
'',
'	insert into data.t_apex_temporal (control01,control02,control03,control04,num01,num02,num03,num04,txt01,txt02,txt04,num05,num06,num07,num08,num09)',
'	select control01,control02,v_log_app,control04,num01,v_idpago,num03,num04,txt01,txt02,txt04,num05,num06,num07,num08,num09',
'	from data.t_apex_temporal',
'	where rowid = v_tablaneg;',
'	v_log_qty := sql%rowcount;',
'',
'	if v_log_qty = 1 then',
'		update data.t_apex_temporal x set control05 = ''S'' where rowid = v_tablaneg;',
'',
'		update data.t_apex_temporal x set control05 = ''S''',
'		where control01 = v_compania',
'			and control02 = v_modulo',
'			and control03 = ''pk_comp_negociacion.sp_buscarfacturas''',
'			and control04 = v_idneg',
'			and txt01 = v_claveacceso',
'			and txt03 = v_valorfac;',
'	end if;',
'',
'	:p216_valorfac := null;',
'	:p216_tablaneg := null;',
'end;'))
,p_attribute_02=>'P216_CLAVEACCESO,P216_IDNEGOCIACION,P216_IDPAGO,P216_TABLANEG,P216_VALORFAC'
,p_attribute_03=>'P216_VALORFAC,P216_TABLANEG'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240312214443Z')
,p_updated_on=>wwv_flow_imp.dz('20240527163013Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(255043471965448314)
,p_event_id=>wwv_flow_imp.id(255042850613448308)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240312214924Z')
,p_updated_on=>wwv_flow_imp.dz('20240312220032Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(255045482541448334)
,p_name=>'Eliminar Detalle'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(255045355215448333)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20240313150446Z')
,p_updated_on=>wwv_flow_imp.dz('20251107153959Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(255045517969448335)
,p_event_id=>wwv_flow_imp.id(255045482541448334)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('\00BFEst\00E1 seguro de eliminar el detalle?'),
unistr('Se borrar\00E1 los avances de este proceso.')))
,p_attribute_02=>'Eliminar el Detalle'
,p_attribute_04=>'fa-exclamation-triangle-o'
,p_attribute_06=>unistr('S\00ED')
,p_attribute_07=>'No'
,p_created_on=>wwv_flow_imp.dz('20240313150446Z')
,p_updated_on=>wwv_flow_imp.dz('20240313180234Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(255045649679448336)
,p_event_id=>wwv_flow_imp.id(255045482541448334)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
,p_created_on=>wwv_flow_imp.dz('20240313150446Z')
,p_updated_on=>wwv_flow_imp.dz('20240313150446Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(255045770299448337)
,p_event_id=>wwv_flow_imp.id(255045482541448334)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_idneg			number;',
'v_idpago		number;',
'v_compania		varchar2(5);',
'v_modulo		varchar2(9);',
'v_claveacceso	varchar2(100);',
'begin',
'	v_compania		:= :g_compania;',
'	v_modulo		:= :app_modulo;',
'	v_idneg			:= to_number(:p216_idnegociacion);',
'	v_idpago		:= to_number(:p216_idpago);',
'	v_claveacceso	:= :p216_claveacceso;',
'',
'	-- Borro los registros de la pre-orden:',
'	delete from data.t_apex_temporal',
'	where control01 = v_compania',
'		and control02 = v_modulo',
'		and control03 = ''apex.130.216.preorden''',
'		and num01 = v_idneg',
'		and num02 = v_idpago;',
'',
'	-- Actualizo las banderas del detalle de la factura',
'	update data.t_apex_temporal x set x.control05 = ''N''',
'	where control01 = v_compania',
'		and control02 = v_modulo',
'		and control03 = ''pk_comp_negociacion.sp_buscarfacturas''',
'		and control04 = to_char(to_number(v_idneg))',
'		and txt01 = v_claveacceso;',
'',
unistr('	-- Actualiado las banderas de la negociaci\00F3n'),
'	update data.t_apex_temporal x set x.control05 = ''N'', x.num09 = 1',
'	where control01 = v_compania',
'	and control02 = v_modulo',
'	and control03 = ''apex.130.216.negociacion''',
'	and control04 = v_claveacceso',
'	and num01 = v_idneg;',
'end;'))
,p_attribute_02=>'P216_IDNEGOCIACION,P216_IDPAGO,P216_CLAVEACCESO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240313150446Z')
,p_updated_on=>wwv_flow_imp.dz('20251107153959Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(255045924700448339)
,p_event_id=>wwv_flow_imp.id(255045482541448334)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240313161135Z')
,p_updated_on=>wwv_flow_imp.dz('20240313161135Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(255046109226448341)
,p_name=>'Generar Pago'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(253500467571881364)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20240313175942Z')
,p_updated_on=>wwv_flow_imp.dz('20240527163319Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(255046219738448342)
,p_event_id=>wwv_flow_imp.id(255046109226448341)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('\00BFEst\00E1 seguro de Generar el Pago?'),
unistr('Se enviar\00E1 a ruta de aprobaci\00F3n. Una vez aprobado el pago se generar\00E1 la Orden de Compra.')))
,p_attribute_02=>'Generar Pago'
,p_attribute_04=>'fa-exclamation-triangle-o'
,p_attribute_06=>unistr('S\00ED')
,p_attribute_07=>'No'
,p_created_on=>wwv_flow_imp.dz('20240313175942Z')
,p_updated_on=>wwv_flow_imp.dz('20240313175942Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(300485209906773226)
,p_event_id=>wwv_flow_imp.id(255046109226448341)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
,p_created_on=>wwv_flow_imp.dz('20240516061209Z')
,p_updated_on=>wwv_flow_imp.dz('20240516061209Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(255046371972448343)
,p_event_id=>wwv_flow_imp.id(255046109226448341)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_idneg			number;',
'v_idpago		number;',
'v_claveacceso	varchar2(100);',
'v_respuesta		varchar2(3000);',
'v_proveedor		number;',
'begin',
'	v_idneg			:= to_number(:p216_idnegociacion);',
'	v_idpago		:= to_number(:p216_idpago);',
'	v_claveacceso	:= :p216_claveacceso;',
'	v_proveedor		:= :p216_codproveedor;',
'/*',
'	pk_comp_negociacion.sp_enrutarpago(',
'		p_compania		=> :g_compania',
'		, p_usuario		=> :app_user',
'		, p_idneg		=> v_idneg',
'		, p_idpago		=> v_idpago',
'		, p_respuesta	=> v_respuesta',
'	);',
'*/',
'	data.pk_comp_negociacion.sp_asociarpago(',
'		p_compania		=> :g_compania',
'		, p_usuario		=> :app_user',
'		, p_idneg		=> v_idneg',
'		, p_proveedor	=> v_proveedor',
'		, p_idpago		=> v_idpago',
'		, p_claveacceso	=> v_claveacceso',
'		, p_respuesta	=> v_respuesta',
'	);',
'end;',
unistr('-- Validar la ruta de aprobaci\00F3n,'),
'-- Actualziar los campos de la tabla t_comp_pagosrecurrentes',
'-- borrar los datos de la tabla temporal',
unistr('-- Regresar a la p\00E1gina anterior')))
,p_attribute_02=>'P216_IDNEGOCIACION,P216_IDPAGO,P216_CLAVEACCESO,P216_CODPROVEEDOR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20240313180121Z')
,p_updated_on=>wwv_flow_imp.dz('20240527163319Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(300485312549773227)
,p_event_id=>wwv_flow_imp.id(255046109226448341)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(''#btnRegresar'').trigger("click");',
'ocultarBarra();'))
,p_created_on=>wwv_flow_imp.dz('20240516061209Z')
,p_updated_on=>wwv_flow_imp.dz('20240523200323Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(649024123885697412)
,p_name=>'Cargar Archivo'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P216_ARCHIVO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20250326174651Z')
,p_updated_on=>wwv_flow_imp.dz('20250326174651Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(649024237106697413)
,p_event_id=>wwv_flow_imp.id(649024123885697412)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250326174651Z')
,p_updated_on=>wwv_flow_imp.dz('20250326174651Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(680427801942803002)
,p_name=>'Borrar Archivo'
,p_event_sequence=>110
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P216_IDBORRAR'
,p_condition_element=>'P216_IDBORRAR'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_created_on=>wwv_flow_imp.dz('20250422144524Z')
,p_updated_on=>wwv_flow_imp.dz('20250422144524Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(680427969430803003)
,p_event_id=>wwv_flow_imp.id(680427801942803002)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
,p_created_on=>wwv_flow_imp.dz('20250422144524Z')
,p_updated_on=>wwv_flow_imp.dz('20250422144524Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(680428073916803004)
,p_event_id=>wwv_flow_imp.id(680427801942803002)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	pk_apex_archivos.sp_eliminaarchivo(:p216_idborrar);',
'end;'))
,p_attribute_02=>'P216_IDBORRAR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250422144524Z')
,p_updated_on=>wwv_flow_imp.dz('20250422144524Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(680428178856803005)
,p_event_id=>wwv_flow_imp.id(680427801942803002)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
,p_created_on=>wwv_flow_imp.dz('20250422144524Z')
,p_updated_on=>wwv_flow_imp.dz('20250422144524Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(680428292609803006)
,p_event_id=>wwv_flow_imp.id(680427801942803002)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(649024695057697417)
,p_created_on=>wwv_flow_imp.dz('20250422144524Z')
,p_updated_on=>wwv_flow_imp.dz('20250422144524Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(680428304451803007)
,p_event_id=>wwv_flow_imp.id(680427801942803002)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20250422144524Z')
,p_updated_on=>wwv_flow_imp.dz('20250422144524Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(253660672631572221)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetUp'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_idneg			number;',
'v_idpago		number;',
'v_compania		varchar2(5);',
'v_claveacceso	varchar2(100);',
'v_mensaje		varchar2(999);',
'v_modulo		varchar2(9);',
'v_origenprv		varchar2(25);',
'v_log_app		varchar2(100);',
'v_log_dsc		varchar2(999);',
'v_log_msg		varchar2(999);',
'v_log_obs		varchar2(999);',
'v_log_qty		number;',
'v_log_amt		number;',
'v_qty_neg		number;',
'v_qty_fac		number;',
'v_qty_poc		number;',
'v_identidad		varchar2(25);',
'begin',
'	v_idneg			:= to_number(:p216_idnegociacion);',
'	v_idpago		:= to_number(:p216_idpago);',
'	v_identidad		:= trim(:p216_identidad);',
'	v_compania		:= :g_compania;',
'	v_modulo		:= :app_modulo;',
'	v_origenprv		:= trim(:p216_origenproveedor);',
'	v_claveacceso	:= case when v_origenprv = ''PE'' and trim(:p216_claveacceso) is null then v_identidad else trim(:p216_claveacceso) end;',
'',
'	:p216_claveacceso := v_claveacceso;',
'',
'	v_log_app		:= ''apex.130.216.negociacion'';',
unistr('	v_log_dsc		:= ''Par\00E1metros: g_compania: ''||:g_compania||'', app_modulo: ''||:app_modulo||'', p216_idnegociacion: ''||:p216_idnegociacion||'', p216_idpago: ''||:p216_idpago||'', p216_claveacceso: ''||:p216_claveacceso;'),
'',
'	v_mensaje		:= ''<p>Hay diferencia en los valores de la <strong>Factura</strong> y el <strong>Pago</strong>.</p>'';',
unistr('	v_mensaje		:= v_mensaje || ''<p>Verifique el precio de los \00EDtems en la factura y/o la cantidad de ingresada.</p>'';'),
'',
'	-- Cantidad de registros en la preorden. Permite verificar si ya se ha cargado los datos.',
'	select count(*) into v_qty_poc from data.t_apex_temporal',
'	where 1 = 1',
'		and control01 = v_compania',
'		and control02 = v_modulo',
'		and control03 = ''apex.130.216.preorden''',
'		and control04 = v_claveacceso',
'		and num01 = v_idneg;',
'',
unistr('	-- Cantidad de registros de la negociaci\00F3n'),
'	select count(*) into v_qty_neg from data.t_apex_temporal',
'	where 1 = 1',
'		and control01 = v_compania',
'		and control02 = v_modulo',
'		and control03 = ''apex.130.216.negociacion''',
'		and control04 = v_claveacceso',
'		and num01 = v_idneg;',
'',
'	-- Cantidad de registros en la factura',
'	select count(*) into v_qty_fac from data.t_apex_temporal',
'	where 1 = 1',
'		and control01 = v_compania',
'		and control02 = v_modulo',
'		and control03 = ''pk_comp_negociacion.sp_buscarfacturas''',
'		and control04 = v_idneg',
'		and txt01 = v_claveacceso;',
'',
'	v_log_msg		:= ''Variables: v_claveacceso: ''||v_claveacceso||'', v_origenprv: ''||v_origenprv||'', v_qty_poc: ''||v_qty_poc||'', v_qty_neg: ''||v_qty_neg||'', v_qty_fac: ''||v_qty_fac;',
'',
'	if v_qty_poc = 0 then',
'		delete from data.t_apex_temporal',
'		where control01 = v_compania',
'			and control02 = v_modulo',
'			and control03 = ''apex.130.216.negociacion''',
'			and control04 = v_claveacceso',
'			and num01 = v_idneg;',
'',
'		v_qty_neg := 0;',
'	end if;',
'',
'	if v_qty_neg = 0 and nvl(v_idneg,0) > 0 and v_claveacceso is not null then',
'		v_log_obs := ''if v_qty_neg = 0 and nvl(v_idneg,0) > 0 and trim(v_claveacceso) is not null'';',
'		insert into data.t_apex_temporal (control01,control02,control03,control04,control05,num01,num02,num03,num04,txt01,txt02,txt03,txt04,txt05,num05,num06,num07,num08,num09)',
'		select v_compania, v_modulo, v_log_app, v_claveacceso, ''N'' procesado',
'			, neg_id',
'			, det_id',
'			, det_codproveedor',
'			, det_codproducto',
'			, trim(b.imlitm) codproducto',
'			, to_char(trim(b.imdsc1))||case when trim(b.imdsc2) is null then to_char('''') else to_char('' '')||to_char(trim(b.imdsc2)) end producto',
'			, det_codproductoprv',
'			, det_desproductoprv',
'			, det_umproductoprv',
'			, pk_comp_negociacion.f_formularecurrente(p_idneg=>neg_id,p_iddet=>det_id,p_idpago=>v_idpago) -- det_preciocal',
'			, det_cantdesde',
'			, det_canthasta',
'			, det_cantmaxima',
'			, 1 cantusuario',
'		from vt_comp_negociaciondet a',
'		inner join f4101@jdedtadl b on a.det_codproducto = b.imitm',
'		where neg_id = :p216_idnegociacion;',
'	end if;',
'',
unistr('	-- Validaci\00F3n'),
'	if v_origenprv != ''PE'' then',
'		with fac as (',
'			select round(sum(num05),2) t_fac from data.t_apex_temporal',
'			where control01 = v_compania',
'				and control02 = v_modulo',
'				and control03 = ''pk_comp_negociacion.sp_buscarfacturas''',
'				and control04 = to_char(to_number(v_idneg))',
'				and txt01 = v_claveacceso ',
'		), poc as (',
'			select count(*) c_poc, round(sum(num05*num09),2) t_poc from data.t_apex_temporal',
'			where control01 = v_compania',
'				and control02 = v_modulo',
'				and control03 = ''apex.130.216.preorden''',
'				and num01 = v_idneg',
'				and num02 = v_idpago',
'		) select case when c_poc = 0 then 0 else (t_poc - t_fac) end into v_log_qty from fac,poc;',
'	else',
'		with poc as (',
'			select count(*) c_poc, round(sum(num05*num09),2) t_poc from data.t_apex_temporal',
'			where control01 = v_compania',
'				and control02 = v_modulo',
'				and control03 = ''apex.130.216.preorden''',
'				and num01 = v_idneg',
'				and num02 = v_idpago',
'		) select case when c_poc > 0 then 0 else 1 end into v_log_qty from poc;',
'',
'		select count(1) into :p216_archivos',
'		from files.t_apex_archivos',
'		where 1 = 1',
'			and tabla = ''VT_COMP_PAGOSRECURRENTES''',
'			and id_tabla = v_identidad',
'			and nvl(tipo,''X'') = nvl(tipo,''X'');',
'',
'		if :p216_archivos = 0 then',
'			v_log_qty := 1;',
'		end if;',
'	end if;',
'',
'	v_log_obs := case when v_log_obs is not null then v_log_obs||'', v_log_qty: ''||v_log_qty else ''v_log_qty: ''||v_log_qty end;',
'	pk_commons.sp_apex_log(v_log_app,0,v_log_dsc,v_log_msg,v_log_obs,null);',
'',
'	:p216_contador := v_log_qty;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>253660672631572221
,p_updated_on=>wwv_flow_imp.dz('20251107173751Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(649024318013697414)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Archivo'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare v_numeroarchivo number;',
'begin',
'	pk_apex_archivos.sp_creararchivo(:p216_archivo,''VT_COMP_PAGOSRECURRENTES'',:p216_identidad,null,null,:app_user,v_numeroarchivo);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>649024318013697414
,p_created_on=>wwv_flow_imp.dz('20250326180331Z')
,p_updated_on=>wwv_flow_imp.dz('20250422143827Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
