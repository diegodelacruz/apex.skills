prompt --application/pages/page_00150
begin
--   Manifest
--     PAGE: 00150
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>150
,p_name=>'COMEX - Mesa de Trabajo'
,p_step_title=>'COMEX - Mesa de Trabajo'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function consultaOCdetalles (numeroOc, tipoOC, codProveedor, numeroOI, idmesa ){',
'',
'    //apex server process consulta detalles de la OC nueva o existente',
'    apex.server.process("VerificarOI",',
'       {x01:numeroOc, x02: tipoOC, x03: codProveedor, x04: numeroOI, x05: idmesa },',
'        {dataType: "json",',
'            success: function(pData){',
'                console.log(pData);',
'                ',
'               if (numeroOI != ""){  window.location.href = pData.url; }',
'               if (pData.existente > 0 && numeroOI == ""){',
'                   ',
'                     $("#mensajeConfirm").text("Esta OC contiene datos relacionados sin especificar su OI, desea observarlos o crear un nuevo registro?");',
'                       apex.item("P150_URL").setValue(pData.url);',
'                   openModal(''dlgConfirmar'');',
'               ',
'               }else{',
'                    window.location.href = pData.url; ',
'               }     ',
'            }',
'           }',
'    );',
'    ',
'    ',
'      ',
'    ',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230708132654Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260409203611Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(73860997223711302)
,p_plug_name=>'Mesa de Trabajo Comercio Exterior'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       ESTADO_TRAMITE,',
'       REFERENCIA,',
'       PROVEEDOR,',
'       PROVEEDOR AS NOMBRE_PROVEEDOR,',
'       DOC_ORDEN_COMPRA,',
'       TIPO,',
'       DOC_ORDEN_ORIGINAL,',
'       TIPO_OI,',
'       data.pk_commons.f_jde2g(FECHA_ORDEN) FECHA_ORDEN,',
'       CONOCIMIENTOEMBARQUE,',
'       CNT40PIES,',
'       CNT20PIES,',
'       FECHAREC,',
'       FECHAETD,',
'       FECHADAV,',
'       FECHALIQ,',
'       FECHACAS,',
'       CARGALIBERADA,',
'       OBSERVACIONES',
'  from DATA.VT_CMEX_MESATRABAJO vt_mesa',
' WHERE vt_mesa.FECHA_ORDEN BETWEEN  data.pk_commons.f_g2jde(TO_DATE(:P150_FECHA_INICIO))',
' --:P150_FINICIO_JDE ',
' AND data.pk_commons.f_g2jde(TO_DATE(:P150_FECHA_FIN))',
' UNION ',
' select ID,',
'       ESTADO_TRAMITE,',
'       REFERENCIA,',
'       PROVEEDOR,',
'       PROVEEDOR AS NOMBRE_PROVEEDOR,',
'       DOC_ORDEN_COMPRA,',
'       TIPO,',
'       DOC_ORDEN_ORIGINAL,',
'       TIPO_OI,',
'       data.pk_commons.f_jde2g(FECHA_ORDEN) FECHA_ORDEN,',
'       CONOCIMIENTOEMBARQUE,',
'       CNT40PIES,',
'       CNT20PIES,',
'       FECHAREC,',
'       FECHAETD,',
'       FECHADAV,',
'       FECHALIQ,',
'       FECHACAS,',
'       CARGALIBERADA,',
'       OBSERVACIONES',
'  from DATA.VT_CMEX_MESATRABAJO vt_mesa',
'  WHERE :P150_FECHA_INICIO IS NULL',
'  AND :P150_FECHA_FIN IS NULL',
' --WHERE vt_mesa.FECHA_ORDEN BETWEEN :P150_FINICIO_JDE AND :P150_FFIN_JDE',
'     '))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_display_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(73861091973711302)
,p_name=>'Mesa de Trabajo Comercio Exterior'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No se encontraron datos'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'NETBY3'
,p_internal_uid=>73861091973711302
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(73861410726711313)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(73861713098711313)
,p_db_column_name=>'ESTADO_TRAMITE'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Etapa'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(74279793258956227)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(73862157289711313)
,p_db_column_name=>'REFERENCIA'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Referencia'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(73862584425711313)
,p_db_column_name=>'PROVEEDOR'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(74682479517609816)
,p_db_column_name=>'NOMBRE_PROVEEDOR'
,p_display_order=>14
,p_column_identifier=>'U'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(73862947261711313)
,p_db_column_name=>'DOC_ORDEN_COMPRA'
,p_display_order=>24
,p_column_identifier=>'E'
,p_column_label=>'Numero Orden'
,p_column_link=>'f?p=&APP_ID.:151:&SESSION.::&DEBUG.:RP,151:P151_ORDENIMPORTACION,P151_ID,P151_TIPO_OI,P151_CODIGOPROVEEDOR,P151_CODIGOETAPA:#DOC_ORDEN_COMPRA#,#ID#,#TIPO#,#PROVEEDOR#,#ESTADO_TRAMITE#'
,p_column_linktext=>'#DOC_ORDEN_COMPRA#'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(73863344131711313)
,p_db_column_name=>'TIPO'
,p_display_order=>34
,p_column_identifier=>'F'
,p_column_label=>'Tipo OC'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(73863776190711315)
,p_db_column_name=>'DOC_ORDEN_ORIGINAL'
,p_display_order=>44
,p_column_identifier=>'G'
,p_column_label=>'OC Original'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(73864154624711315)
,p_db_column_name=>'TIPO_OI'
,p_display_order=>54
,p_column_identifier=>'H'
,p_column_label=>'Tipo OCO'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(73864588286711315)
,p_db_column_name=>'CONOCIMIENTOEMBARQUE'
,p_display_order=>64
,p_column_identifier=>'I'
,p_column_label=>'Conocimiento Embarque'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(73864971477711315)
,p_db_column_name=>'CNT40PIES'
,p_display_order=>74
,p_column_identifier=>'J'
,p_column_label=>'CNT40'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(73865312043711315)
,p_db_column_name=>'CNT20PIES'
,p_display_order=>84
,p_column_identifier=>'K'
,p_column_label=>'CNT20'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(73865703663711316)
,p_db_column_name=>'FECHAREC'
,p_display_order=>94
,p_column_identifier=>'L'
,p_column_label=>'Fecha REC'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(73866108490711316)
,p_db_column_name=>'FECHAETD'
,p_display_order=>104
,p_column_identifier=>'M'
,p_column_label=>'Fecha ETD'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(73866551183711316)
,p_db_column_name=>'FECHADAV'
,p_display_order=>114
,p_column_identifier=>'N'
,p_column_label=>'Fecha DAV'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(73866910504711316)
,p_db_column_name=>'FECHALIQ'
,p_display_order=>124
,p_column_identifier=>'O'
,p_column_label=>'Fecha LIQ'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(73867396204711316)
,p_db_column_name=>'FECHACAS'
,p_display_order=>134
,p_column_identifier=>'P'
,p_column_label=>'Fecha CAS'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(73867723212711316)
,p_db_column_name=>'CARGALIBERADA'
,p_display_order=>144
,p_column_identifier=>'Q'
,p_column_label=>'Carga Liberada'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(73868171978711316)
,p_db_column_name=>'OBSERVACIONES'
,p_display_order=>154
,p_column_identifier=>'R'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(74682358236609815)
,p_db_column_name=>'FECHA_ORDEN'
,p_display_order=>164
,p_column_identifier=>'T'
,p_column_label=>'Fecha Orden'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(73868887921715488)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'738689'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DOC_ORDEN_COMPRA:TIPO:DOC_ORDEN_ORIGINAL:TIPO_OI:FECHA_ORDEN:NOMBRE_PROVEEDOR:FECHAREC:FECHAETD:FECHADAV:FECHALIQ:FECHACAS:ESTADO_TRAMITE:'
,p_sort_column_1=>'DOC_ORDEN_COMPRA'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20230708132654Z')
,p_updated_on=>wwv_flow_imp.dz('20230708132654Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(75949390978382494)
,p_report_id=>wwv_flow_imp.id(73868887921715488)
,p_name=>unistr('Sin Gesti\00F3n')
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'ID'
,p_operator=>'is null'
,p_condition_sql=>' (case when ("ID" is null) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME#'
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_font_color=>'#E61515'
,p_created_on=>wwv_flow_imp.dz('20230708132654Z')
,p_updated_on=>wwv_flow_imp.dz('20230708132654Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(73869482987721901)
,p_plug_name=>'Mesa de trabajo'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296122226350169167)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(73869539038721902)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74059005083884707)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78322436301948312)
,p_plug_name=>'Mesa2'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ID, CODIGOETAPA, ORDENCOMPRA, ',
'   TIPOOC, TIPOOC || ''-'' || ORDENCOMPRA AS OC, ',
'   CODIGOPROVEEDOR, ',
'   CONOCIMIENTOEMBARQUE, ',
'   CNT20PIES, CNT40PIES, FECHAREC, ',
'   FECHAETD, FECHAETA, FECHADAV, ',
'   FECHALIQ, FECHACAS, CARGALIBERADA, ',
'   OBSERVACIONES, NAVIERA, ORDENAGENTE, ',
'   NUMFACTURA, BULTOSPALLETS, PESONETO, ',
'   PESOBRUTO, CUBICAJE, PAISORIGEN, ',
'   NUMCONTENEDOR, CNTPESON, CNTPESOB, ',
'   CNTPRIORITARIO, REFERENCIA, APLICACIONSEGURO, ',
'    BODEGA, MANIFIESTOCARGA, fechaOI , fechaOIConvertida',
'    FROM  VT_CMEX_MESATRABAJO ',
'    ',
'    WHERE fechaOI BETWEEN :P150_FECHA_INICIO_JDE',
' --:P150_FINICIO_JDE ',
' AND :P150_FECHA_FIN_JDE'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(78322533789948313)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:151:&SESSION.::&DEBUG.:RP,151:P151_ID:#ID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-page.png" class="apex-edit-page" alt="">'
,p_owner=>'NETBY3'
,p_internal_uid=>78322533789948313
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78323331543948321)
,p_db_column_name=>'ID'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Editar'
,p_column_link=>'f?p=&APP_ID.:151:&SESSION.::&DEBUG.:RP,151:P151_ID:#ID#'
,p_column_linktext=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-page.png" class="apex-edit-page" alt="">'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78323445122948322)
,p_db_column_name=>'CODIGOETAPA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Etapa'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(74279793258956227)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78323577057948323)
,p_db_column_name=>'CONOCIMIENTOEMBARQUE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Conocimiento Embarque'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78323616206948324)
,p_db_column_name=>'CNT20PIES'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'CNT 20 Pies'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78323747335948325)
,p_db_column_name=>'CNT40PIES'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'CNT 40 Pies'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78323816125948326)
,p_db_column_name=>'FECHAREC'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Fecha REC'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78323914231948327)
,p_db_column_name=>'FECHAETD'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Fecha ETD'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78324033875948328)
,p_db_column_name=>'FECHADAV'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Fecha DAV'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78324170570948329)
,p_db_column_name=>'FECHALIQ'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Fecha LIQ'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78324282914948330)
,p_db_column_name=>'FECHACAS'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Fecha CAS'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78324385168948331)
,p_db_column_name=>'CARGALIBERADA'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Carga Liberada'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78324455007948332)
,p_db_column_name=>'ORDENAGENTE'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Ordenagente'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78324524577948333)
,p_db_column_name=>'OBSERVACIONES'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(78325390652948341)
,p_db_column_name=>'ORDENCOMPRA'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Orden Compra OI'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79529345061966424)
,p_db_column_name=>'TIPOOC'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Tipo OC'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79529420204966425)
,p_db_column_name=>'CODIGOPROVEEDOR'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(41703476241628470)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79529561814966426)
,p_db_column_name=>'FECHAETA'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Fecha ETA'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79529663558966427)
,p_db_column_name=>'NAVIERA'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Naviera'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79529784236966428)
,p_db_column_name=>'NUMFACTURA'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Numfactura'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79529887335966429)
,p_db_column_name=>'BULTOSPALLETS'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Bultospallets'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79529960796966430)
,p_db_column_name=>'PESONETO'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Pesoneto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79530072888966431)
,p_db_column_name=>'PESOBRUTO'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>'Pesobruto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79530181855966432)
,p_db_column_name=>'CUBICAJE'
,p_display_order=>300
,p_column_identifier=>'AD'
,p_column_label=>'Cubicaje'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79530269682966433)
,p_db_column_name=>'PAISORIGEN'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>'Paisorigen'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79530338453966434)
,p_db_column_name=>'NUMCONTENEDOR'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Numcontenedor'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79530494796966435)
,p_db_column_name=>'CNTPESON'
,p_display_order=>330
,p_column_identifier=>'AG'
,p_column_label=>'Cntpeson'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79530535319966436)
,p_db_column_name=>'CNTPESOB'
,p_display_order=>340
,p_column_identifier=>'AH'
,p_column_label=>'Cntpesob'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79530683770966437)
,p_db_column_name=>'CNTPRIORITARIO'
,p_display_order=>350
,p_column_identifier=>'AI'
,p_column_label=>'Cntprioritario'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79530768478966438)
,p_db_column_name=>'REFERENCIA'
,p_display_order=>360
,p_column_identifier=>'AJ'
,p_column_label=>'Referencia'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79530811175966439)
,p_db_column_name=>'APLICACIONSEGURO'
,p_display_order=>370
,p_column_identifier=>'AK'
,p_column_label=>'Aplicacionseguro'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79530970729966440)
,p_db_column_name=>'BODEGA'
,p_display_order=>380
,p_column_identifier=>'AL'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(79531056180966441)
,p_db_column_name=>'MANIFIESTOCARGA'
,p_display_order=>390
,p_column_identifier=>'AM'
,p_column_label=>'Manifiestocarga'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(80462463566347016)
,p_db_column_name=>'OC'
,p_display_order=>400
,p_column_identifier=>'AN'
,p_column_label=>'Orden Compra'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(80462823335347020)
,p_db_column_name=>'FECHAOI'
,p_display_order=>410
,p_column_identifier=>'AO'
,p_column_label=>'Fecha Orden JDE'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(80463506665347027)
,p_db_column_name=>'FECHAOICONVERTIDA'
,p_display_order=>420
,p_column_identifier=>'AP'
,p_column_label=>'Fecha OI'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(78527105406796026)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'785272'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODIGOETAPA:REFERENCIA:OC:CODIGOPROVEEDOR:CNT40PIES:CNT20PIES:FECHAREC:FECHAETD:FECHAETA:FECHADAV:FECHALIQ:FECHACAS:CARGALIBERADA:FECHAOICONVERTIDA:'
,p_sort_column_1=>'ID'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20230708132654Z')
,p_updated_on=>wwv_flow_imp.dz('20230708132654Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(78324762023948335)
,p_plug_name=>'DlgConfirmar'
,p_region_name=>'dlgConfirmar'
,p_region_template_options=>'#DEFAULT#:js-dialog-autoheight:js-dialog-size600x400'
,p_plug_template=>wwv_flow_imp.id(295627185797037684)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'<h3 id= "mensajeConfirm"></h3>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74059560340884712)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(73869539038721902)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(78324933494948337)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(78324762023948335)
,p_button_name=>'ACEPTAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Abrir'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(78325044726948338)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(78324762023948335)
,p_button_name=>'NUEVO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Nuevo'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(79531103076966442)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(73869539038721902)
,p_button_name=>'NUEVA_ORDEN'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Nueva'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:151:&SESSION.::&DEBUG.:RP,151::'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74059138347884708)
,p_name=>'P150_FECHA_INICIO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(74059005083884707)
,p_prompt=>'Fecha Inicio'
,p_source=>'SELECT  TRUNC(ADD_MONTHS(SYSDATE,(:P150_MESES_PARAMETRO)*-1),''MM'') as fecha FROM DUAL'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74059282790884709)
,p_name=>'P150_FECHA_FIN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(74059005083884707)
,p_prompt=>'Fecha Fin'
,p_source=>'SELECT  SYSDATE FROM DUAL'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(78324880072948336)
,p_name=>'P150_URL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(78324762023948335)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80463348003347025)
,p_name=>'P150_FECHA_INICIO_JDE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(74059005083884707)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80463481055347026)
,p_name=>'P150_FECHA_FIN_JDE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(74059005083884707)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80464421200347036)
,p_name=>'P150_MESES_PARAMETRO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(74059005083884707)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(80464552213347037)
,p_computation_sequence=>10
,p_computation_item=>'P150_MESES_PARAMETRO'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation=>'1'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(80463611510347028)
,p_computation_sequence=>10
,p_computation_item=>'P150_FECHA_INICIO_JDE'
,p_computation_type=>'QUERY'
,p_computation=>'SELECT data.pk_commons.f_g2jde(TO_DATE(:P150_FECHA_INICIO,''DD/MM/YYYY'')) AS D FROM DUAL;'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(80463737549347029)
,p_computation_sequence=>20
,p_computation_item=>'P150_FECHA_FIN_JDE'
,p_computation_type=>'QUERY'
,p_computation=>'SELECT data.pk_commons.f_g2jde(TO_DATE(:P150_FECHA_FIN,''DD/MM/YYYY'')) AS D FROM DUAL;'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(80464259431347034)
,p_computation_sequence=>10
,p_computation_item=>'P150_FECHA_INICIO_JDE'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>'SELECT  data.pk_commons.f_g2jde(TRUNC(ADD_MONTHS(SYSDATE,(:P150_MESES_PARAMETRO)*-1),''MM'')) as fecha FROM DUAL'
,p_compute_when=>'P150_FECHA_INICIO'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(80464382062347035)
,p_computation_sequence=>20
,p_computation_item=>'P150_FECHA_FIN_JDE'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'QUERY'
,p_computation=>'SELECT  data.pk_commons.f_g2jde(sysdate) as fecha FROM DUAL'
,p_compute_when=>'P150_FECHA_FIN'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(74681717258609809)
,p_name=>'Refrer'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P150_FECHA_INICIO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(74681860350609810)
,p_event_id=>wwv_flow_imp.id(74681717258609809)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P150_FECHA_INICIO_JDE'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'SELECT data.pk_commons.f_g2jde(TO_DATE(:P150_FECHA_INICIO,''DD/MM/YYYY'')) AS D FROM DUAL;'
,p_attribute_07=>'P150_FECHA_INICIO'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(74682149687609813)
,p_event_id=>wwv_flow_imp.id(74681717258609809)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P150_FINICIO_JDE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(74681992100609811)
,p_name=>'refres'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P150_FECHA_FIN'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(74682090629609812)
,p_event_id=>wwv_flow_imp.id(74681992100609811)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P150_FECHA_FIN_JDE'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'SELECT data.pk_commons.f_g2jde(TO_DATE(:P150_FECHA_FIN,''DD/MM/YYYY'')) AS D FROM DUAL;'
,p_attribute_07=>'P150_FECHA_FIN'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(74682204657609814)
,p_event_id=>wwv_flow_imp.id(74681992100609811)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P150_FFIN_JDE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(78325126974948339)
,p_name=>'New'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(78324933494948337)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(78325297086948340)
,p_event_id=>wwv_flow_imp.id(78325126974948339)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'JAVASCRIPT_EXPRESSION'
,p_affected_elements=>'window'
,p_attribute_01=>'window.location.href = apex.item("P150_URL").getValue();'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(78324655361948334)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'VerificarOI'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_idmesa number;',
'v_url varchar2(500);',
'v_existe number;',
'begin ',
'	begin ',
'		select idmesa, 1 into v_idmesa, v_existe',
'		from data.t_cmex_ordenesvinculadas',
'		where 1 = 1',
'			and ordenori = apex_application.g_x01',
'			and tipoorig = apex_application.g_x02',
'			and codproveedor =  apex_application.g_x03',
'			and ordenimp = to_number(apex_application.g_x04);',
'',
'		exception when no_data_found then v_idmesa := 0; v_existe:= -1;',
'	end;',
'',
'	if v_idmesa = 0 then',
'	begin',
'		select idmesa, 1 into v_idmesa, v_existe',
'		from data.t_cmex_ordenesvinculadas',
'		where 1 = 1',
'			and ordenori = apex_application.g_x01',
'			and tipoorig = apex_application.g_x02',
'			and codproveedor =  apex_application.g_x03;',
'',
'		exception when no_data_found then v_idmesa := 0; v_existe:= -1;',
'	end;',
'	end if;',
'',
'	if v_idmesa = 0 then',
'	    if apex_application.g_x04 = '''' or apex_application.g_x04 is null then',
'	        insert into t_cmex_mesatrabajo (id,codigoproveedor,codigoetapa)',
'	        values (null, apex_application.g_x03,''ET1'') returning id into v_idmesa;',
'',
'	        insert into data.t_cmex_ordenesvinculadas(compania,idmesa,ordenimp,ordenori,tipoorig,codproveedor)',
'	        values (:g_compania,v_idmesa,null,apex_application.g_x01,apex_application.g_x02,apex_application.g_x03);',
'		else',
'			insert into t_cmex_mesatrabajo (codigoproveedor,codigoetapa,ordencompra,tipooc)',
'			values (apex_application.g_x03,''ET1'',to_number(apex_application.g_x04),''OI'') returning id into v_idmesa;',
'',
'			insert into data.t_cmex_ordenesvinculadas(compania,idmesa,ordenimp,ordenori,tipoorig,codproveedor)',
'			values (:g_compania,v_idmesa,to_number(apex_application.g_x04),apex_application.g_x01, apex_application.g_x02,apex_application.g_x03);	    ',
'		end if;',
'	end if;',
'	v_url := ''f?p=''||:APP_ID||'':151:''||:APP_SESSION||''::NO:REP,151:P151_ID:''||v_idmesa;',
'	apex_json.open_object;',
'	apex_json.write(''id_mesa'',v_idmesa);',
'	apex_json.write(''url'',v_url);',
'	apex_json.write(''existente'',v_existe);',
'	apex_json.close_object;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>78324655361948334
,p_updated_on=>wwv_flow_imp.dz('20241127193740Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
