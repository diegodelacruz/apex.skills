prompt --application/pages/page_00148
begin
--   Manifest
--     PAGE: 00148
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>148
,p_name=>unistr('Negociaci\00F3n - Formulaciones')
,p_alias=>'NEGOCIACION-FORMULACIONES1'
,p_step_title=>unistr('Negociaci\00F3n - Formulaciones')
,p_allow_duplicate_submissions=>'N'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-button.a-IRR-sortWidget-button[data-option="hide"], .a-IRR-button.a-IRR-sortWidget-button[data-option="freeze"]{',
'    display:none;',
'}',
'.a-IG-controls-item--aggregate, .a-IG-controls-item--controlBreak, .a-IG-controls-item--groupBy, .a-IG-reportSummary-item--aggregate, .a-IG-reportSummary-item--controlBreak, .a-IG-reportSummary-item--groupBy, .a-IRR-controls-item--aggregate, .a-IRR-c'
||'ontrols-item--controlBreak, .a-IRR-controls-item--groupBy, .a-IRR-reportSummary-item--aggregate, .a-IRR-reportSummary-item--controlBreak, .a-IRR-reportSummary-item--groupBy {',
'    --a-report-controls-cell-label-icon-background-color: #3b83bd;',
'    --a-report-controls-cell-label-hover-background-color: #e6f0f7;',
'    display: none;',
'}',
'/* Scroll Results Only in Side Column */',
'.t-Body-side {',
'    display: flex;',
'    flex-direction: column;',
'    overflow: hidden;',
'}',
'.search-results {',
'    flex: 1;',
'    overflow: auto;',
'}',
'/* Format Search Region */',
'.search-region {',
'    border-bottom: 1px solid rgba(0,0,0,.1);',
'    flex-shrink: 0;',
'}'))
,p_step_template=>wwv_flow_imp.id(295584560547037640)
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20240129134912Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260409203504Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(66411410413003316)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-Form--noPadding:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(295583779177037631)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(295683461023037726)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(66412801043003317)
,p_plug_name=>'Search'
,p_region_css_classes=>'search-region padding-md'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(295608822663037671)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(66413538290003318)
,p_name=>'Master Records'
,p_template=>wwv_flow_imp.id(295609041229037671)
,p_display_sequence=>20
,p_region_css_classes=>'search-results'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'t-MediaList--showDesc:t-MediaList--stack'
,p_display_point=>'REGION_POSITION_02'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id',
'	, null link_class',
'	, apex_page.get_url(p_items => ''P148_ID'', p_values => "ID") link',
'	, null icon_class',
'	, null link_attr',
'	, null icon_color_class',
'	, case when coalesce(:p148_id,''0'') = id then ''is-active'' else '' '' end list_class',
'	, substr(formula,1,50)||(case when length(FORMULA) > 50 then ''...'' else '''' end ) list_title',
'	, substr(descripcion,1,50)||( case when length(DESCRIPCION) > 50 then ''...'' else '''' end )||''<br/>''||''<span style="color:red">''||decode(activo,1,'''',''Inactivo'')||''<span/>'' list_text',
'	, null list_badge',
'from data.t_comp_negociacionform x',
'where (:p148_search is null',
'	or upper(x.formula) like ''%''||upper(:p148_search)||''%''',
'	or upper(x.descripcion) like ''%''||upper(:p148_search)||''%''',
')',
'order by activo desc,formula'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P148_SEARCH'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295651889311037703)
,p_query_num_rows=>1000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'<div class="u-tC">No data found.</div>'
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
,p_updated_on=>wwv_flow_imp.dz('20251002150446Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66414276953003323)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'ID'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66414640641003323)
,p_query_column_id=>2
,p_column_alias=>'LINK_CLASS'
,p_column_display_sequence=>2
,p_column_heading=>'LINK_CLASS'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66415089171003324)
,p_query_column_id=>3
,p_column_alias=>'LINK'
,p_column_display_sequence=>3
,p_column_heading=>'LINK'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66415439421003324)
,p_query_column_id=>4
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>4
,p_column_heading=>'ICON_CLASS'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66415859440003324)
,p_query_column_id=>5
,p_column_alias=>'LINK_ATTR'
,p_column_display_sequence=>5
,p_column_heading=>'LINK_ATTR'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66416200567003324)
,p_query_column_id=>6
,p_column_alias=>'ICON_COLOR_CLASS'
,p_column_display_sequence=>6
,p_column_heading=>'ICON_COLOR_CLASS'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66416619304003324)
,p_query_column_id=>7
,p_column_alias=>'LIST_CLASS'
,p_column_display_sequence=>7
,p_column_heading=>'LIST_CLASS'
,p_use_as_row_header=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66417044983003324)
,p_query_column_id=>8
,p_column_alias=>'LIST_TITLE'
,p_column_display_sequence=>8
,p_column_heading=>'LIST_TITLE'
,p_use_as_row_header=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66417497064003325)
,p_query_column_id=>9
,p_column_alias=>'LIST_TEXT'
,p_column_display_sequence=>9
,p_column_heading=>'LIST_TEXT'
,p_use_as_row_header=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66417852556003325)
,p_query_column_id=>10
,p_column_alias=>'LIST_BADGE'
,p_column_display_sequence=>10
,p_column_heading=>'LIST_BADGE'
,p_use_as_row_header=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(66418292588003335)
,p_name=>'Negociacion - Formulaciones'
,p_template=>wwv_flow_imp.id(296121421643169165)
,p_display_sequence=>10
,p_region_css_classes=>'js-master-region'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       USERCREA,',
'       FECHCREA,',
'       USERMODI,',
'       FECHMODI,',
'       FORMULA,',
'       DESCRIPCION,',
'       CASE WHEN ACTIVO = 1 THEN ''Activo'' ELSE ''Inactivo''END ACTIVO',
'  from T_COMP_NEGOCIACIONFORM',
' where "ID" = :P148_ID'))
,p_display_when_condition=>'P148_ID'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295657610309037706)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Debe seleccionar un registro en el panel izquierdo',
''))
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66418981592003336)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "T_COMP_NEGOCIACIONFORM"',
'where "ID" is not null',
'and "ID" = :P148_ID'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66419305215003336)
,p_query_column_id=>2
,p_column_alias=>'USERCREA'
,p_column_display_sequence=>2
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "T_COMP_NEGOCIACIONFORM"',
'where "USERCREA" is not null',
'and "ID" = :P148_ID'))
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66419701964003336)
,p_query_column_id=>3
,p_column_alias=>'FECHCREA'
,p_column_display_sequence=>3
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "T_COMP_NEGOCIACIONFORM"',
'where "FECHCREA" is not null',
'and "ID" = :P148_ID'))
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66420159960003337)
,p_query_column_id=>4
,p_column_alias=>'USERMODI'
,p_column_display_sequence=>4
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "T_COMP_NEGOCIACIONFORM"',
'where "USERMODI" is not null',
'and "ID" = :P148_ID'))
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66420510562003337)
,p_query_column_id=>5
,p_column_alias=>'FECHMODI'
,p_column_display_sequence=>5
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "T_COMP_NEGOCIACIONFORM"',
'where "FECHMODI" is not null',
'and "ID" = :P148_ID'))
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66420916406003337)
,p_query_column_id=>6
,p_column_alias=>'FORMULA'
,p_column_display_sequence=>6
,p_column_heading=>unistr('F\00F3rmula')
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "T_COMP_NEGOCIACIONFORM"',
'where "FORMULA" is not null',
'and "ID" = :P148_ID'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66421336530003337)
,p_query_column_id=>7
,p_column_alias=>'DESCRIPCION'
,p_column_display_sequence=>7
,p_column_heading=>unistr('Descripci\00F3n')
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "T_COMP_NEGOCIACIONFORM"',
'where "DESCRIPCION" is not null',
'and "ID" = :P148_ID'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66421796373003337)
,p_query_column_id=>8
,p_column_alias=>'ACTIVO'
,p_column_display_sequence=>8
,p_column_heading=>'Estado'
,p_use_as_row_header=>'N'
,p_column_hit_highlight=>'Inactivo'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "T_COMP_NEGOCIACIONFORM"',
'where "ACTIVO" is not null',
'and "ID" = :P148_ID'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(66427624448003348)
,p_plug_name=>'Region Display Selector'
,p_region_css_classes=>'js-detail-rds'
,p_region_template_options=>'#DEFAULT#:margin-bottom-md'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(295608822663037671)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_num_rows=>15
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P148_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(66428031223003348)
,p_name=>'Negociacion - Formulaciones detalle'
,p_template=>wwv_flow_imp.id(296120252599169164)
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_css_classes=>'js-detail-region'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'t-Report--stretch:#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id',
'	, idfrm',
'	, usercrea',
'	, fechcrea',
'	, usermodi',
'	, fechmodi',
'	, variable',
'	, tipovalor',
'	, ididx',
'	, case',
'		when tipovalor = 1',
'			then (select valindice from data.vt_comp_negociacionidx where id = ididx and sysdate between vigenciadesde and vigenciahasta and estadoflujo = ''APROBADO'') ',
'		else valor end valor',
'from t_comp_negociacionformdet',
'where idfrm = :p148_id',
'and pantalla = 1'))
,p_display_when_condition=>'P148_ID'
,p_display_condition_type=>'ITEM_NOT_NULL_OR_ZERO'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P148_ID'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>5000
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240528175550Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66428833748003349)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66429286931003349)
,p_query_column_id=>2
,p_column_alias=>'IDFRM'
,p_column_display_sequence=>2
,p_column_heading=>'Idfrm'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66429668639003350)
,p_query_column_id=>3
,p_column_alias=>'USERCREA'
,p_column_display_sequence=>3
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66430097889003350)
,p_query_column_id=>4
,p_column_alias=>'FECHCREA'
,p_column_display_sequence=>4
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66430446681003350)
,p_query_column_id=>5
,p_column_alias=>'USERMODI'
,p_column_display_sequence=>5
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66430857704003350)
,p_query_column_id=>6
,p_column_alias=>'FECHMODI'
,p_column_display_sequence=>6
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66431267601003350)
,p_query_column_id=>7
,p_column_alias=>'VARIABLE'
,p_column_display_sequence=>7
,p_column_heading=>'Variable'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:191:&SESSION.::&DEBUG.:RP,191:P191_ID:#ID#'
,p_column_linktext=>'#VARIABLE#'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66431695047003351)
,p_query_column_id=>8
,p_column_alias=>'TIPOVALOR'
,p_column_display_sequence=>8
,p_column_heading=>'Tipo Valor'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(66470570719199476)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66432005741003351)
,p_query_column_id=>9
,p_column_alias=>'IDIDX'
,p_column_display_sequence=>9
,p_column_heading=>'Indice'
,p_use_as_row_header=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(66472642723269258)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(66432437513003351)
,p_query_column_id=>10
,p_column_alias=>'VALOR'
,p_column_display_sequence=>10
,p_column_heading=>'Valor'
,p_use_as_row_header=>'N'
,p_column_format=>'999G999G999G999G990D0000'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(66451675286003372)
,p_plug_name=>'Debe seleccionar un registro en el panel izquierdo'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295608822663037671)
,p_plug_display_sequence=>70
,p_plug_source=>'Debe seleccionar un registro en el panel izquierdo'
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'P148_ID'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(66412155996003316)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(66411410413003316)
,p_button_name=>'Reestablecer'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Reestablecer'
,p_button_redirect_url=>'f?p=&APP_ID.:148:&APP_SESSION.:RESET:&DEBUG.:RP,148::'
,p_button_condition=>'P148_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-undo'
,p_updated_on=>wwv_flow_imp.dz('20251002150806Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(66436533977003354)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(66428031223003348)
,p_button_name=>'POP_T_COMP_NEGOCIACIONFORMDET'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Agregar Formulaciones detalle'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:191:&SESSION.::&DEBUG.:RP,191:P191_IDFRM,P191_ID:&P148_ID.,'
,p_button_condition_type=>'NEVER'
,p_icon_css_classes=>'fa-plus'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(66452148995003372)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(66411410413003316)
,p_button_name=>'Editar'
,p_button_static_id=>'edit_master_btn'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Editar'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:149:&APP_SESSION.::&DEBUG.:RP,149:P149_ID:&P148_ID.'
,p_button_condition=>'P148_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-pencil-square-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(193111578323648721)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(66411410413003316)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>unistr('Borrar F\00F3rmula')
,p_button_condition=>'select ''x'' from data.t_comp_negociacioncab where nvl(formula,0) in (select id from data.t_comp_negociacionform where id = :p148_id)'
,p_button_condition_type=>'NOT_EXISTS'
,p_icon_css_classes=>'fa-trash-o'
,p_created_on=>wwv_flow_imp.dz('20251002153715Z')
,p_updated_on=>wwv_flow_imp.dz('20251002155029Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(66412566084003316)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(66411410413003316)
,p_button_name=>'Agregar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Agregar'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:149:&APP_SESSION.::&DEBUG.:RP,149::'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(66413200353003317)
,p_name=>'P148_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(66412801043003317)
,p_prompt=>'Search'
,p_placeholder=>'Search...'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681811193037723)
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large:t-Form-fieldContainer--postTextBlock'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(66427252643003348)
,p_name=>'P148_ID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(66418292588003335)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'S'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(66452452637003372)
,p_name=>'Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(66418292588003335)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(66453087419003373)
,p_event_id=>wwv_flow_imp.id(66452452637003372)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(66428195078003349)
,p_name=>'Dialog Closed'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(66428031223003348)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(66437203699003354)
,p_event_id=>wwv_flow_imp.id(66428195078003349)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(66452581756003372)
,p_name=>'Perform Search'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P148_SEARCH'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which === apex.jQuery.ui.keyCode.ENTER'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keypress'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(66454398355003373)
,p_event_id=>wwv_flow_imp.id(66452581756003372)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(66413538290003318)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(66454871289003374)
,p_event_id=>wwv_flow_imp.id(66452581756003372)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(193111665116648722)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Borrar F\00F3rmula')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	delete from data.t_comp_negociacionformdet where idfrm = :p148_id;',
'	delete from data.t_comp_negociacionform where id = :p148_id;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_error_message=>'No se pudo borrar el registro.'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(193111578323648721)
,p_process_success_message=>unistr('F\00F3rmula borrada.')
,p_internal_uid=>193111665116648722
,p_created_on=>wwv_flow_imp.dz('20251002153837Z')
,p_updated_on=>wwv_flow_imp.dz('20251002154847Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
