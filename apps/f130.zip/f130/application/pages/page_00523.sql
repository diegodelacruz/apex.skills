prompt --application/pages/page_00523
begin
--   Manifest
--     PAGE: 00523
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>523
,p_name=>unistr('COMEX - dlg Cargar Archivo EXPORTACI\00D3N')
,p_alias=>unistr('COMEX-DLG-CARGAR-ARCHIVO-EXPORTACI\00D3N')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('COMEX - Cargar Archivo EXPORTACI\00D3N')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'16'
,p_created_on=>wwv_flow_imp.dz('20241024191448Z')
,p_last_updated_on=>wwv_flow_imp.dz('20241016193903Z')
,p_last_updated_by=>'DCUEVA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(641299233143693224)
,p_plug_name=>'Body'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(330258406253023401)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(641299233143693224)
,p_button_name=>'GRABAR_DOCUMENTO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Grabar Documento'
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(329868713489317109)
,p_branch_name=>'Go to 521 - GRABAR_DOCUMENTO'
,p_branch_action=>'f?p=&APP_ID.:521:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(330258406253023401)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(329868828243317110)
,p_name=>'P523_FACTURA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(641299233143693224)
,p_prompt=>'Factura'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    FACTURA_TIPO||''-''||FACTURA_NUMERO  AS NAME,',
'    FACTURA_TIPO||''-''||FACTURA_NUMERO  AS CODE',
'FROM ',
'    T_CMEX_EXPORTACION_FACTURA',
'WHERE ',
'    EXPORTACION_REGISTRO = :P523_EXPORTACION_REGISTRO',
';',
'',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(329868943512317111)
,p_name=>'P523_CONTENEDOR'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(641299233143693224)
,p_prompt=>'Contenedor'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DISTINCT',
'    FAC.CONTENEDOR_NUMERO||'' - ''||FAC.TURNO_IDVEHICULO ',
'                AS CONTENEDOR_NUMERO_DET,',
'    FAC.CONTENEDOR_NUMERO AS CONTENEDOR_NUMERO',
'FROM ',
'    VT_CMEX_DATOS_GESTION_FACTURAS  FAC',
'    JOIN',
'        T_CMEX_EXPORTACION_FACTURA  EXF',
'            ON FAC.FACTURA = EXF.FACTURA_TIPO||''-''||EXF.FACTURA_NUMERO',
'WHERE',
'    EXF.EXPORTACION_REGISTRO = :P523_EXPORTACION_REGISTRO',
'ORDER BY FAC.CONTENEDOR_NUMERO;',
'',
''))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(329869041480317112)
,p_name=>'P523_OBSERVACION'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(641299233143693224)
,p_prompt=>'Observacion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(330258839674023406)
,p_name=>'P523_TIPO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(641299233143693224)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_CMEX_EXPORT_TIPO_DOCUMENTO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ID_TABLA AS NAME,',
'    VALOR    AS CODE',
'FROM',
'    T_CORP_UDC ',
'WHERE',
'    ID_CABECERA = ''CMEX_TP_AR''',
';'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(330259665579023408)
,p_name=>'P523_DOCUMENTO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(641299233143693224)
,p_prompt=>'Documento'
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'N'
,p_attribute_12=>'INLINE'
,p_attribute_13=>'Seleccione el archivo'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(330260092049023422)
,p_name=>'P523_EXPORTACION_REGISTRO'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(364780838491500902)
,p_name=>'P523_CO_CODE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(641299233143693224)
,p_prompt=>unistr('C\00F3digo CO')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(330260567632023423)
,p_validation_name=>'GRABAR_DOCUMENTO'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P523_DOCUMENTO IS NULL THEN',
'    RETURN ''Debe seleccionar un ARCHIVO'';',
'END IF;',
'',
'IF :P523_TIPO IS NULL THEN',
'    RETURN ''Debe seleccionar un TIPO'';',
'END IF;',
'',
'IF :P523_TIPO IN (''CO'') AND :P523_FACTURA IS NULL THEN',
'    RETURN ''Debe seleccionar una FACTURA'';',
'END IF;',
'',
'IF :P523_TIPO IN (''CO'') AND :P523_CO_CODE IS NULL THEN',
unistr('    RETURN ''Debe ingresar el c\00F3digo CO'';'),
'END IF;',
'',
'IF :P523_TIPO IN (''CO'') AND LENGTH(:P523_CO_CODE) <> 8 THEN',
unistr('    RETURN ''el c\00F3digo CO de ser de tama\00F1o 8'';'),
'END IF;',
'',
'IF :P523_TIPO IN (''VGM'', ''EIR'') AND :P523_CONTENEDOR IS NULL THEN',
'    RETURN ''Debe ingresar seleccionar un CONTENEDOR'';',
'END IF;',
'',
'RETURN NULL;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(330258406253023401)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(364780983908500903)
,p_name=>'Change'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P523_TIPO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(364781042776500904)
,p_event_id=>wwv_flow_imp.id(364780983908500903)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(641299233143693224)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(330260862359023423)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GRABAR_DOCUMENTO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'PK_CMEX_EXPORTACION.SP_GRABA_DOCUMENTO(',
'    :P523_EXPORTACION_REGISTRO,',
'    :P523_TIPO,',
'    :P523_CO_CODE,',
'    :P523_FACTURA,',
'    :P523_CONTENEDOR,',
'    :APP_USER,',
'    :P523_OBSERVACION',
');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(330258406253023401)
,p_internal_uid=>330260862359023423
);
wwv_flow_imp.component_end;
end;
/
