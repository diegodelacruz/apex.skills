prompt --application/pages/page_00143
begin
--   Manifest
--     PAGE: 00143
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>143
,p_name=>unistr('Negociaci\00F3n - Reportes')
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Reportes'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(secItems).hide();'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-button.a-IRR-sortWidget-button[data-option="hide"], .a-IRR-button.a-IRR-sortWidget-button[data-option="freeze"]{',
'    display:none;',
'}',
'.a-IG-controls-item--aggregate, .a-IG-controls-item--controlBreak, .a-IG-controls-item--groupBy, .a-IG-reportSummary-item--aggregate, .a-IG-reportSummary-item--controlBreak, .a-IG-reportSummary-item--groupBy, .a-IRR-controls-item--aggregate, .a-IRR-c'
||'ontrols-item--controlBreak, .a-IRR-controls-item--groupBy, .a-IRR-reportSummary-item--aggregate, .a-IRR-reportSummary-item--controlBreak, .a-IRR-reportSummary-item--groupBy {',
'    --a-report-controls-cell-label-icon-background-color: #3b83bd;',
'    --a-report-controls-cell-label-hover-background-color: #e6f0f7;',
'    display: none;',
'}',
'.a-IRR-chartView, .a-IRR-controlsContainer, .a-IRR-detailView, .a-IRR-groupByView, .a-IRR-iconViewTable, .a-IRR-pivotView {',
'    border-top-color: #E6E6E6;',
'    display: none;',
'}',
'',
'.a-IRR-table tr td[headers*="PRECIO1"]',
'{',
'    background-color:#c1d6fb;',
'}',
'.a-IRR-table tr td[headers*="PRECIO2"]',
'{',
'    background-color:#d6d7fd;',
'}',
'.a-IRR-table tr td[headers*="PRECIO3"]',
'{',
'    background-color:#fef8a2;',
'}',
'.a-IRR-table tr td[headers*="ACTUAL"]',
'{',
'    background-color:#bef5c0;',
'}',
'.a-IRR-table {',
'    border-collapse: separate;',
'}',
'#PRECIO1 { background-color:#c1d6fb;}',
'#PRECIO2 { background-color:#d6d7fd;}',
'#PRECIO3 { background-color:#fef8a2;}',
'#ACTUAL { background-color:#bef5c0;}',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240219201600Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260409202707Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(139493263962021420)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(139698312639391441)
,p_plug_name=>'Negociaciones Pasadas'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select neg_id_p1 neg_id_ant',
'	, neg_id_act',
'	, det_codproveedor_act neg_codesquema_act',
'	, det_codproducto_act',
'	, det_incoterm_p1 det_incoterm_ant',
'	, det_precio_p1 det_precio_ant',
'	, det_precio_act',
'	, variacion_p1 variacion',
'from vt_comp_negociacionpas',
'where neg_id_act = :p143_neg_id_actual and :p143_tipo = 1',
'order by neg_id_p1 desc'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P143_NEG_ID_ACTUAL,P143_TIPO'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P143_TIPO'
,p_plug_display_when_cond2=>'1'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Negociaciones Pasadas'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20250218142851Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(141063425102133010)
,p_max_row_count=>'1000000'
,p_search_button_label=>'<span class="fa fa-search" aria-hidden="true"></span>'
,p_allow_report_saving=>'N'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_show_search_textbox=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_filter=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>141063425102133010
,p_updated_on=>wwv_flow_imp.dz('20250218142851Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142473579412744702)
,p_db_column_name=>'NEG_ID_ACT'
,p_display_order=>10
,p_column_identifier=>'L'
,p_column_label=>unistr('Negociaci\00F3n Act')
,p_allow_highlighting=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'00000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142473427850744701)
,p_db_column_name=>'NEG_ID_ANT'
,p_display_order=>40
,p_column_identifier=>'K'
,p_column_label=>unistr('Negociaci\00F3n Ant')
,p_allow_highlighting=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'00000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142473889540744705)
,p_db_column_name=>'NEG_CODESQUEMA_ACT'
,p_display_order=>60
,p_column_identifier=>'O'
,p_column_label=>'Proveedor'
,p_allow_highlighting=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(135034190509484151)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142473959704744706)
,p_db_column_name=>'DET_CODPRODUCTO_ACT'
,p_display_order=>70
,p_column_identifier=>'P'
,p_column_label=>'Producto'
,p_allow_highlighting=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(135034190509484151)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142474024663744707)
,p_db_column_name=>'DET_INCOTERM_ANT'
,p_display_order=>80
,p_column_identifier=>'Q'
,p_column_label=>'Incoterm Ant'
,p_allow_highlighting=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(74803172029355163)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250218142851Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142474196351744708)
,p_db_column_name=>'DET_PRECIO_ANT'
,p_display_order=>90
,p_column_identifier=>'R'
,p_column_label=>'Precio Ant'
,p_allow_highlighting=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250218142851Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142474276444744709)
,p_db_column_name=>'DET_PRECIO_ACT'
,p_display_order=>100
,p_column_identifier=>'S'
,p_column_label=>'Precio Act'
,p_allow_highlighting=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250218142851Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(599462866963255639)
,p_db_column_name=>'VARIACION'
,p_display_order=>110
,p_column_identifier=>'T'
,p_column_label=>unistr('Variaci\00F3n')
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250218141503Z')
,p_updated_on=>wwv_flow_imp.dz('20250218141503Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(141326788069712112)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1413268'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NEG_ID_ACT:NEG_CODESQUEMA_ACT:NEG_ID_ANT:DET_CODPRODUCTO_ACT:DET_INCOTERM_ANT:DET_PRECIO_ACT:DET_PRECIO_ANT:VARIACION:'
,p_sort_column_1=>'NEG_ID_ANT'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'NEG_VIGENCIA_ANT'
,p_sort_direction_2=>'DESC'
,p_break_on=>'NEG_ID_ACT:NEG_VIGENCIA_ACT:NEG_CODESQUEMA_ACT:0:0:0'
,p_break_enabled_on=>'NEG_ID_ACT:NEG_VIGENCIA_ACT:NEG_CODESQUEMA_ACT:0:0:0'
,p_created_on=>wwv_flow_imp.dz('20240219201600Z')
,p_updated_on=>wwv_flow_imp.dz('20250218142636Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(142564496060213040)
,p_plug_name=>'Negociaciones con otros Proveedores'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(295629242996037685)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with ',
'  prd as (SELECT   CODIGOPRODUCTO || '' - '' ||  NOMBREPRODUCTO || '' ''|| CODIGOALTERNO  || '' - ['' ||  UNIDADCOMPRA || '']'' NOMBREPRODUCTO  ,CODIGOCORTO  FROM vt_jde_productos WHERE  CODESTADO<>''O'' GROUP BY  CODIGOPRODUCTO || '' - '' ||  NOMBREPRODUCTO || '
||''' ''|| CODIGOALTERNO     || '' - ['' ||  UNIDADCOMPRA || '']''  ,CODIGOCORTO ,NOMBREPRODUCTO order by NOMBREPRODUCTO)',
' ,prv as (SELECT   CODIGOPROVEEDOR || '' - '' ||  DESCRIPCION DESCRIPCION, CODIGOPROVEEDOR  FROM  VT_JDE_MAESTROPROVEEDOR GROUP BY CODIGOPROVEEDOR || '' - '' ||  DESCRIPCION , CODIGOPROVEEDOR , DESCRIPCION ORDER BY DESCRIPCION) ',
' ,itr as (select DRKY ||'' - ''||upper(DRDL01) DRDL01,DRKY  from vt_jde_udcjde where drsy=''42'' and drrt=''FR'' and drky is not null order by upper(DRKY))',
' ,fmp as (select PNPTC ||'' - ''||upper(PNPTD) PNPTD ,PNPTC from f0014@jdedtadl where trim(PNPTC) is not null  order by PNPTD)',
' SELECT',
'    (select DESCRIPCION from prv where codigoproveedor = NG_CODESQUEMA) NEG_CODESQUEMA_ACT,NG_NEG_ID,NG_VIGENCIA,(select NOMBREPRODUCTO from prd where CODIGOCORTO = ng_CODPRODUCTO)DET_CODPRODUCTO_ACT,ng_TIEMPOENTREGA DET_TIEMPOENTREGA_ACT,(select DRD'
||'L01 from itr where DRKY = ng_INCOTERM)DET_INCOTERM_ACT ,(select PNPTD from fmp where PNPTC = ng_FORMAPAGO)DET_FORMAPAGO_ACT,ng_VOLUMEN,ng_PRECIO, ',
'    (select DESCRIPCION from prv where codigoproveedor = P1_CODESQUEMA) P1_CODESQUEMA     ,P1_NEG_ID,P1_VIGENCIA,                                                                                       P1_TIEMPOENTREGA                      ,(select DRD'
||'L01 from itr where DRKY = P1_INCOTERM)P1_INCOTERM      ,(select PNPTD from fmp where PNPTC = P1_FORMAPAGO)P1_FORMAPAGO     ,P1_VOLUMEN,P1_PRECIO, P1_VARIACION,',
'    (select DESCRIPCION from prv where codigoproveedor = P2_CODESQUEMA) P2_CODESQUEMA     ,P2_NEG_ID,P2_VIGENCIA,                                                                                       P2_TIEMPOENTREGA                      ,(select DRD'
||'L01 from itr where DRKY = P2_INCOTERM)P2_INCOTERM      ,(select PNPTD from fmp where PNPTC = P2_FORMAPAGO)P2_FORMAPAGO     ,P2_VOLUMEN,P2_PRECIO, P2_VARIACION,',
'    (select DESCRIPCION from prv where codigoproveedor = P3_CODESQUEMA) P3_CODESQUEMA     ,P3_NEG_ID,P3_VIGENCIA,                                                                                       P3_TIEMPOENTREGA                      ,(select DRD'
||'L01 from itr where DRKY = P3_INCOTERM)P3_INCOTERM      ,(select PNPTD from fmp where PNPTC = P3_FORMAPAGO)P3_FORMAPAGO     ,P3_VOLUMEN,P3_PRECIO, P3_VARIACION',
'FROM',
'    vt_comp_negociacionprv',
'WHERE 1=1',
'    and NG_NEG_ID = :p143_neg_id_actual',
'    AND :P143_TIPO=2'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P143_NEG_ID_ACTUAL,P143_TIPO'
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P143_TIPO'
,p_plug_display_when_cond2=>'2'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Negociaciones con otros Proveedores'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20250218145639Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(142564508399213041)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_textbox=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_select_columns=>'N'
,p_show_rows_per_page=>'N'
,p_show_filter=>'N'
,p_show_sort=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>142564508399213041
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142581850558240632)
,p_db_column_name=>'NEG_CODESQUEMA_ACT'
,p_display_order=>10
,p_column_identifier=>'AN'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_static_id=>'ACTUAL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142582169141240635)
,p_db_column_name=>'DET_CODPRODUCTO_ACT'
,p_display_order=>20
,p_column_identifier=>'AQ'
,p_column_label=>'Producto'
,p_column_type=>'STRING'
,p_static_id=>'ACTUAL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142581978651240633)
,p_db_column_name=>'NG_NEG_ID'
,p_display_order=>30
,p_column_identifier=>'AO'
,p_column_label=>unistr('Negociaci\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'00000'
,p_static_id=>'ACTUAL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142582003231240634)
,p_db_column_name=>'NG_VIGENCIA'
,p_display_order=>40
,p_column_identifier=>'AP'
,p_column_label=>'Vigencia'
,p_column_type=>'STRING'
,p_static_id=>'ACTUAL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142565081587213046)
,p_db_column_name=>'DET_TIEMPOENTREGA_ACT'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'T. Entrega'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_static_id=>'ACTUAL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142565106670213047)
,p_db_column_name=>'DET_INCOTERM_ACT'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'Incoterm'
,p_column_type=>'STRING'
,p_static_id=>'ACTUAL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142565202124213048)
,p_db_column_name=>'DET_FORMAPAGO_ACT'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'F. Pago'
,p_column_type=>'STRING'
,p_static_id=>'ACTUAL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142582200403240636)
,p_db_column_name=>'NG_VOLUMEN'
,p_display_order=>90
,p_column_identifier=>'AR'
,p_column_label=>unistr('Vol\00FAmen')
,p_column_type=>'STRING'
,p_static_id=>'ACTUAL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142582391119240637)
,p_db_column_name=>'NG_PRECIO'
,p_display_order=>100
,p_column_identifier=>'AS'
,p_column_label=>'Precio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_static_id=>'ACTUAL'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142582470930240638)
,p_db_column_name=>'P1_CODESQUEMA'
,p_display_order=>120
,p_column_identifier=>'AT'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_static_id=>'PRECIO1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142578899931240602)
,p_db_column_name=>'P1_NEG_ID'
,p_display_order=>130
,p_column_identifier=>'K'
,p_column_label=>unistr('Negociaci\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'00000'
,p_static_id=>'PRECIO1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142578973543240603)
,p_db_column_name=>'P1_VIGENCIA'
,p_display_order=>140
,p_column_identifier=>'L'
,p_column_label=>'Vigencia'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_static_id=>'PRECIO1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142579144093240605)
,p_db_column_name=>'P1_TIEMPOENTREGA'
,p_display_order=>150
,p_column_identifier=>'N'
,p_column_label=>'T. Entrega'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_static_id=>'PRECIO1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142579208337240606)
,p_db_column_name=>'P1_INCOTERM'
,p_display_order=>160
,p_column_identifier=>'O'
,p_column_label=>'Incoterm'
,p_column_type=>'STRING'
,p_static_id=>'PRECIO1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142579325405240607)
,p_db_column_name=>'P1_FORMAPAGO'
,p_display_order=>170
,p_column_identifier=>'P'
,p_column_label=>'F. Pago'
,p_column_type=>'STRING'
,p_static_id=>'PRECIO1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142579481223240608)
,p_db_column_name=>'P1_VOLUMEN'
,p_display_order=>180
,p_column_identifier=>'Q'
,p_column_label=>unistr('Vol\00FAmen')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_static_id=>'PRECIO1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142579589986240609)
,p_db_column_name=>'P1_PRECIO'
,p_display_order=>190
,p_column_identifier=>'R'
,p_column_label=>'Precio Uni.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_static_id=>'PRECIO1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142579615788240610)
,p_db_column_name=>'P1_VARIACION'
,p_display_order=>200
,p_column_identifier=>'S'
,p_column_label=>unistr('Variaci\00F3n')
,p_column_type=>'NUMBER'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'PRECIO1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142582516885240639)
,p_db_column_name=>'P2_CODESQUEMA'
,p_display_order=>210
,p_column_identifier=>'AU'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_static_id=>'PRECIO2'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142579871860240612)
,p_db_column_name=>'P2_NEG_ID'
,p_display_order=>220
,p_column_identifier=>'U'
,p_column_label=>unistr('Negociaci\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'00000'
,p_static_id=>'PRECIO2'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142579953162240613)
,p_db_column_name=>'P2_VIGENCIA'
,p_display_order=>230
,p_column_identifier=>'V'
,p_column_label=>'Vigencia'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_static_id=>'PRECIO2'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142580178488240615)
,p_db_column_name=>'P2_TIEMPOENTREGA'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'T. Entrega'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_static_id=>'PRECIO2'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142580238328240616)
,p_db_column_name=>'P2_INCOTERM'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Incoterm'
,p_column_type=>'STRING'
,p_static_id=>'PRECIO2'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142580396427240617)
,p_db_column_name=>'P2_FORMAPAGO'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'F. Pago'
,p_column_type=>'STRING'
,p_static_id=>'PRECIO2'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142580471675240618)
,p_db_column_name=>'P2_VOLUMEN'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>unistr('Vol\00FAmen')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_static_id=>'PRECIO2'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142580515297240619)
,p_db_column_name=>'P2_PRECIO'
,p_display_order=>280
,p_column_identifier=>'AB'
,p_column_label=>'Precio Uni.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_static_id=>'PRECIO2'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142580651909240620)
,p_db_column_name=>'P2_VARIACION'
,p_display_order=>290
,p_column_identifier=>'AC'
,p_column_label=>unistr('Variaci\00F3n')
,p_column_type=>'NUMBER'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'PRECIO2'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142582691350240640)
,p_db_column_name=>'P3_CODESQUEMA'
,p_display_order=>300
,p_column_identifier=>'AV'
,p_column_label=>'Proveedor'
,p_column_type=>'STRING'
,p_static_id=>'PRECIO3'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142580825774240622)
,p_db_column_name=>'P3_NEG_ID'
,p_display_order=>310
,p_column_identifier=>'AE'
,p_column_label=>unistr('Negociaci\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_format_mask=>'00000'
,p_static_id=>'PRECIO3'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142580962380240623)
,p_db_column_name=>'P3_VIGENCIA'
,p_display_order=>320
,p_column_identifier=>'AF'
,p_column_label=>'Vigencia'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_static_id=>'PRECIO3'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142581122514240625)
,p_db_column_name=>'P3_TIEMPOENTREGA'
,p_display_order=>330
,p_column_identifier=>'AH'
,p_column_label=>'T. Entrega'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_static_id=>'PRECIO3'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142581288166240626)
,p_db_column_name=>'P3_INCOTERM'
,p_display_order=>340
,p_column_identifier=>'AI'
,p_column_label=>'Incoterm'
,p_column_type=>'STRING'
,p_static_id=>'PRECIO3'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142581392020240627)
,p_db_column_name=>'P3_FORMAPAGO'
,p_display_order=>350
,p_column_identifier=>'AJ'
,p_column_label=>'F. Pago'
,p_column_type=>'STRING'
,p_static_id=>'PRECIO3'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142581414494240628)
,p_db_column_name=>'P3_VOLUMEN'
,p_display_order=>360
,p_column_identifier=>'AK'
,p_column_label=>unistr('Vol\00FAmen')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_static_id=>'PRECIO3'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142581554797240629)
,p_db_column_name=>'P3_PRECIO'
,p_display_order=>370
,p_column_identifier=>'AL'
,p_column_label=>'Precio Uni.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_static_id=>'PRECIO3'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(142581682810240630)
,p_db_column_name=>'P3_VARIACION'
,p_display_order=>380
,p_column_identifier=>'AM'
,p_column_label=>unistr('Variaci\00F3n')
,p_column_type=>'NUMBER'
,p_format_mask=>'999G999G999G999G990D00'
,p_static_id=>'PRECIO3'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(142609186949250407)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1426092'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NEG_CODESQUEMA_ACT:DET_CODPRODUCTO_ACT:NG_NEG_ID:NG_VIGENCIA:DET_TIEMPOENTREGA_ACT:DET_INCOTERM_ACT:DET_FORMAPAGO_ACT:NG_VOLUMEN:NG_PRECIO:P1_CODESQUEMA:P1_NEG_ID:P1_VIGENCIA:P1_TIEMPOENTREGA:P1_INCOTERM:P1_FORMAPAGO:P1_VOLUMEN:P1_PRECIO:P1_VARIACION'
||':P2_CODESQUEMA:P2_NEG_ID:P2_VIGENCIA:P2_TIEMPOENTREGA:P2_INCOTERM:P2_FORMAPAGO:P2_VOLUMEN:P2_PRECIO:P2_VARIACION:P3_CODESQUEMA:P3_NEG_ID:P3_VIGENCIA:P3_TIEMPOENTREGA:P3_INCOTERM:P3_FORMAPAGO:P3_VOLUMEN:P3_PRECIO:P3_VARIACION:'
,p_break_on=>'NEG_CODESQUEMA_ACT:DET_CODPRODUCTO_ACT:NG_NEG_ID:NG_VIGENCIA:0:0'
,p_break_enabled_on=>'NEG_CODESQUEMA_ACT:DET_CODPRODUCTO_ACT:NG_NEG_ID:NG_VIGENCIA:0:0'
,p_created_on=>wwv_flow_imp.dz('20240219201600Z')
,p_updated_on=>wwv_flow_imp.dz('20240219201600Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(142581787898240631)
,p_plug_name=>'colores'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>5
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div>',
unistr('    <span style="margin-left : 15px;">Negociaci\00F3n Actual<span        class="fa fa-square" style="color: #bef5c0; margin-left: 5px;"> <span class="visuallyhidden"></span> </span>'),
unistr('    <span style="margin-left : 15px;">1er. Negociaci\00F3n Anterior<span class="fa fa-square" style="color: #c1d6fb; margin-left: 5px;"> <span class="visuallyhidden"></span> </span></span>'),
unistr('    <span style="margin-left : 15px;">2da. Negociaci\00F3n Anterior<span class="fa fa-square" style="color: #d6d7fd; margin-left: 5px;"> <span class="visuallyhidden"></span> </span></span>'),
unistr('    <span style="margin-left : 15px;">3er. Negociaci\00F3n Anterior<span class="fa fa-square" style="color: #fef8a2; margin-left: 5px;"> <span class="visuallyhidden"></span> </span></span>'),
'    </span>',
'</div>',
' '))
,p_plug_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_display_when_condition=>'P143_TIPO'
,p_plug_display_when_cond2=>'2'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43435770351543036)
,p_name=>'P143_USUARIO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(139493263962021420)
,p_prompt=>'Usuario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(139493357427021421)
,p_name=>'P143_NEG_ID_ACTUAL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(139493263962021420)
,p_prompt=>'Neg Id Actual'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(139901058225798846)
,p_name=>'P143_TIPO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(139493263962021420)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(140078089498614925)
,p_name=>'P143_TITULO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(139493263962021420)
,p_prompt=>'Titulo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(140077938432614924)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Setup Interface'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P143_TITULO:=CASE WHEN :P143_TIPO=1 THEN ''PASADAS'' ELSE ''OTROS PROVEEDORES'' END;',
':P143_USUARIO:=:app_user;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>140077938432614924
);
wwv_flow_imp.component_end;
end;
/
