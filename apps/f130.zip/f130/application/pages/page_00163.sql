prompt --application/pages/page_00163
begin
--   Manifest
--     PAGE: 00163
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>163
,p_name=>'COMEX - Det. Transporte'
,p_page_mode=>'MODAL'
,p_step_title=>'COMEX - Det. Transporte'
,p_reload_on_submit=>'A'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20230708132656Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260409204404Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(76151945557799241)
,p_plug_name=>'Parametros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_region_attributes=>'style = "display : none;"'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(76152388295799245)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(76152439332799246)
,p_plug_name=>'Cabecera'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(76508292903804492)
,p_name=>'Detalle Transporte'
,p_template=>wwv_flow_imp.id(296121421643169165)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_TABFORM'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'"ID",',
'"ID" ID_DISPLAY,',
'"ID_CMEX_MESATRABAJO",',
'"ID_CONTENEDOR",',
'"FECHASOLICITADAPLANTA",',
'"FECHACONFIRMADAINGRESOPLANTA",',
'"TRANSPORTISTA",',
'"CONDUCTOR",',
'"PLACA",',
'"ESTADO",',
'"ADUANA",',
'"DISTRITO"',
'from "#OWNER#"."T_CMEX_DETALLESTRANSPORTE"',
'WHERE ID_CMEX_MESATRABAJO = :P163_ID_CMEX_MESATRABAJO',
''))
,p_display_condition_type=>'NEVER'
,p_ajax_items_to_submit=>'P163_ID_CMEX_MESATRABAJO'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>10
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'(null)'
,p_query_no_data_found=>'No data found.'
,p_query_num_rows_type=>'ROW_RANGES_IN_SELECT_LIST'
,p_query_row_count_max=>500
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76508949506804492)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>2
,p_disable_sort_column=>'N'
,p_hidden_column=>'Y'
,p_display_as=>'HIDDEN'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_ref_schema=>'DATA'
,p_ref_table_name=>'T_CMEX_DETALLESTRANSPORTE'
,p_ref_column_name=>'ID'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76509307532804493)
,p_query_column_id=>2
,p_column_alias=>'ID_DISPLAY'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_ref_schema=>'DATA'
,p_ref_table_name=>'T_CMEX_DETALLESTRANSPORTE'
,p_ref_column_name=>'ID_DISPLAY'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76509741597804493)
,p_query_column_id=>3
,p_column_alias=>'ID_CMEX_MESATRABAJO'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
,p_ref_schema=>'DATA'
,p_ref_table_name=>'T_CMEX_DETALLESTRANSPORTE'
,p_ref_column_name=>'ID_CMEX_MESATRABAJO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76510199935804493)
,p_query_column_id=>4
,p_column_alias=>'ID_CONTENEDOR'
,p_column_display_sequence=>5
,p_column_heading=>'Contenedor'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_ref_schema=>'DATA'
,p_ref_table_name=>'T_CMEX_DETALLESTRANSPORTE'
,p_ref_column_name=>'ID_CONTENEDOR'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76510530805804493)
,p_query_column_id=>5
,p_column_alias=>'FECHASOLICITADAPLANTA'
,p_column_display_sequence=>6
,p_column_heading=>'Fecha Solicitada Planta'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'DATE_PICKER'
,p_column_width=>12
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_ref_schema=>'DATA'
,p_ref_table_name=>'T_CMEX_DETALLESTRANSPORTE'
,p_ref_column_name=>'FECHASOLICITADAPLANTA'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76510968458804493)
,p_query_column_id=>6
,p_column_alias=>'FECHACONFIRMADAINGRESOPLANTA'
,p_column_display_sequence=>7
,p_column_heading=>'Fecha Confirmada Ingreso Planta'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'DATE_PICKER'
,p_column_width=>12
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_ref_schema=>'DATA'
,p_ref_table_name=>'T_CMEX_DETALLESTRANSPORTE'
,p_ref_column_name=>'FECHACONFIRMADAINGRESOPLANTA'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76511345348804493)
,p_query_column_id=>7
,p_column_alias=>'TRANSPORTISTA'
,p_column_display_sequence=>8
,p_column_heading=>'Transportista'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT'
,p_column_width=>16
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_ref_schema=>'DATA'
,p_ref_table_name=>'T_CMEX_DETALLESTRANSPORTE'
,p_ref_column_name=>'TRANSPORTISTA'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76511725516804493)
,p_query_column_id=>8
,p_column_alias=>'CONDUCTOR'
,p_column_display_sequence=>9
,p_column_heading=>'Conductor'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT'
,p_column_width=>16
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_ref_schema=>'DATA'
,p_ref_table_name=>'T_CMEX_DETALLESTRANSPORTE'
,p_ref_column_name=>'CONDUCTOR'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76512100036804495)
,p_query_column_id=>9
,p_column_alias=>'PLACA'
,p_column_display_sequence=>10
,p_column_heading=>'Placa'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT'
,p_column_width=>12
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_ref_schema=>'DATA'
,p_ref_table_name=>'T_CMEX_DETALLESTRANSPORTE'
,p_ref_column_name=>'PLACA'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76512562321804495)
,p_query_column_id=>10
,p_column_alias=>'ESTADO'
,p_column_display_sequence=>11
,p_column_heading=>'Estado'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT'
,p_column_width=>15
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_ref_schema=>'DATA'
,p_ref_table_name=>'T_CMEX_DETALLESTRANSPORTE'
,p_ref_column_name=>'ESTADO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76512983051804495)
,p_query_column_id=>11
,p_column_alias=>'ADUANA'
,p_column_display_sequence=>12
,p_column_heading=>'Aduana'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT'
,p_column_width=>16
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_ref_schema=>'DATA'
,p_ref_table_name=>'T_CMEX_DETALLESTRANSPORTE'
,p_ref_column_name=>'ADUANA'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76513380126804495)
,p_query_column_id=>12
,p_column_alias=>'DISTRITO'
,p_column_display_sequence=>13
,p_column_heading=>'Distrito'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT'
,p_column_width=>16
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_ref_schema=>'DATA'
,p_ref_table_name=>'T_CMEX_DETALLESTRANSPORTE'
,p_ref_column_name=>'DISTRITO'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76524743745804503)
,p_query_column_id=>13
,p_column_alias=>'CHECK$01'
,p_column_display_sequence=>1
,p_display_as=>'CHECKBOX'
,p_report_column_width=>1
,p_derived_column=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(76569735677781301)
,p_name=>'Archivo'
,p_template=>wwv_flow_imp.id(296120613521169165)
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_new_grid_row=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUMEROARCHIVO,',
'       dbms_lob.getlength(BLOBCONTENT) Archivo,',
'       FILENAME,',
'       MIMETYPE,',
'       TABLA,',
'       ID_TABLA,',
'       TIPO,',
'       OBSERVACION,',
'       ESTADO,',
'       FECHA,',
'       NOMBREUSUARIO,',
'       RIDE',
'  from FILES.T_APEX_ARCHIVOS',
'  WHERE TABLA = ''T_CMEX_MESATRABAJO''',
'AND ID_TABLA = :P163_ID_CMEX_MESATRABAJO',
'AND TIPO = ''ET4_3'''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295657610309037706)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76569897307781302)
,p_query_column_id=>1
,p_column_alias=>'NUMEROARCHIVO'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76571029721781314)
,p_query_column_id=>2
,p_column_alias=>'ARCHIVO'
,p_column_display_sequence=>12
,p_column_heading=>'Archivo CAS'
,p_use_as_row_header=>'N'
,p_column_format=>'DOWNLOAD:T_APEX_ARCHIVOS:BLOBCONTENT:NUMEROARCHIVO::MIMETYPE:FILENAME:::attachment:Descargar:FILES'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76570095379781304)
,p_query_column_id=>3
,p_column_alias=>'FILENAME'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76570194080781305)
,p_query_column_id=>4
,p_column_alias=>'MIMETYPE'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76570275639781306)
,p_query_column_id=>5
,p_column_alias=>'TABLA'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76570361647781307)
,p_query_column_id=>6
,p_column_alias=>'ID_TABLA'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76570403275781308)
,p_query_column_id=>7
,p_column_alias=>'TIPO'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76570569841781309)
,p_query_column_id=>8
,p_column_alias=>'OBSERVACION'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76570693579781310)
,p_query_column_id=>9
,p_column_alias=>'ESTADO'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76570763730781311)
,p_query_column_id=>10
,p_column_alias=>'FECHA'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76570860169781312)
,p_query_column_id=>11
,p_column_alias=>'NOMBREUSUARIO'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(76570959866781313)
,p_query_column_id=>12
,p_column_alias=>'RIDE'
,p_column_display_sequence=>11
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(80464799335347039)
,p_name=>'Detalles Transporte'
,p_template=>wwv_flow_imp.id(296120613521169165)
,p_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'         SELECT ID_CMEX_MESATRABAJO, ',
'         NRO_CONTENEDOR, CONT, CONDUCTOR, PLACA, IDEMPRESA, BODEGA, DISTRITO,',
'         ORDENCOMPRA',
'        FROM ',
'         (',
'         SELECT contenedores.ID_CMEX_MESATRABAJO,',
'         contenedores.NRO_CONTENEDOR,',
'         CASE WHEN importaciones.CONTENEDORESP IS NULL THEN',
'          --  ''<span aria-hidden="true" class="fa fa-remove"></span>''',
'         ''<span class="fa fa-remove" style="color: #ff3300;" title = "No Verificado">',
'                <spam class="visuallyhidden">No Verificado</spam>',
'         </span>'' ',
'             ',
'         ELSE ',
'            --''<span aria-hidden="true" class="fa fa-check"></span>''',
'             ''<span class="fa fa-check" style="color: #00cc66;" title = "Verificado">',
'                <spam class="visuallyhidden">Verificado</spam>',
'         </span>'' ',
'        END AS CONT,             ',
'        CONDUCTOR, PLACA, IDEMPRESA',
'         FROM DATA.T_CMEX_DETALLECONTENEDOR contenedores ',
'         LEFT JOIN DATA.T_RCDP_SOLICITUDIMPORTACIONES importaciones',
'         ON contenedores.NRO_CONTENEDOR = importaciones.CONTENEDORESP',
'         WHERE contenedores.ID_CMEX_MESATRABAJO = :P163_ID_CMEX_MESATRABAJO) conten',
'         INNER JOIN DATA.T_CMEX_MESATRABAJO mesa',
'         ON conten.ID_CMEX_MESATRABAJO = mesa.ID',
''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(295654681717037704)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(80464812128347040)
,p_query_column_id=>1
,p_column_alias=>'ID_CMEX_MESATRABAJO'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(80464994043347041)
,p_query_column_id=>2
,p_column_alias=>'NRO_CONTENEDOR'
,p_column_display_sequence=>2
,p_column_heading=>'Nro Contenedor'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(80465008891347042)
,p_query_column_id=>3
,p_column_alias=>'CONT'
,p_column_display_sequence=>3
,p_column_heading=>'Estado'
,p_column_format=>'PCT_GRAPH:::'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(80465132065347043)
,p_query_column_id=>4
,p_column_alias=>'CONDUCTOR'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(80465234050347044)
,p_query_column_id=>5
,p_column_alias=>'PLACA'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(80465332942347045)
,p_query_column_id=>6
,p_column_alias=>'IDEMPRESA'
,p_column_display_sequence=>6
,p_column_heading=>'Empresa'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(81147046466144896)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(80465752149347049)
,p_query_column_id=>7
,p_column_alias=>'BODEGA'
,p_column_display_sequence=>9
,p_column_heading=>'Bodega'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(80465559109347047)
,p_query_column_id=>8
,p_column_alias=>'DISTRITO'
,p_column_display_sequence=>7
,p_column_heading=>'Distrito Aduanero'
,p_use_as_row_header=>'N'
,p_column_alignment=>'CENTER'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(80465602460347048)
,p_query_column_id=>9
,p_column_alias=>'ORDENCOMPRA'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(76517478187804498)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(76508292903804492)
,p_button_name=>'SUBMIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(76517314852804498)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(76508292903804492)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:163:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(76517683895804498)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(76508292903804492)
,p_button_name=>'ADD'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Add'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.widget.tabular.addRow();'
,p_button_execute_validations=>'N'
,p_button_cattributes=>'style = "display : none;"'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(76517593549804498)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(76508292903804492)
,p_button_name=>'MULTI_ROW_DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682663716037726)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''MULTI_ROW_DELETE'');'
,p_button_execute_validations=>'N'
,p_button_cattributes=>'style = "display : none;"'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(76525587175804503)
,p_branch_name=>'Go To Page 163'
,p_branch_action=>'f?p=&APP_ID.:163:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(76517478187804498)
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76152037399799242)
,p_name=>'P163_ID_CMEX_MESATRABAJO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(76151945557799241)
,p_prompt=>'Id Cmex Mesatrabajo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76152726813799249)
,p_name=>'P163_OI'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(76152439332799246)
,p_prompt=>'Orden Compra'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(76571151335781315)
,p_name=>'P163_PROVEEDOR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(76152439332799246)
,p_prompt=>'Proveedor'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_JDE_LIBRODIRECCIONES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct nombres as r, codigo as d from vt_jde_librodirecciones order by 1',
''))
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'LOV'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(76519265395804498)
,p_tabular_form_region_id=>wwv_flow_imp.id(76508292903804492)
,p_validation_name=>'ID_CMEX_MESATRABAJO must be numeric'
,p_validation_sequence=>30
,p_validation=>'ID_CMEX_MESATRABAJO'
,p_validation_type=>'ITEM_IS_NUMERIC'
,p_error_message=>'#COLUMN_HEADER# must be numeric.'
,p_when_button_pressed=>wwv_flow_imp.id(76517478187804498)
,p_associated_column=>'ID_CMEX_MESATRABAJO'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(76519613526804499)
,p_tabular_form_region_id=>wwv_flow_imp.id(76508292903804492)
,p_validation_name=>'FECHASOLICITADAPLANTA must be a valid date'
,p_validation_sequence=>50
,p_validation=>'FECHASOLICITADAPLANTA'
,p_validation_type=>'ITEM_IS_DATE'
,p_error_message=>'#COLUMN_HEADER# must be a valid date.'
,p_when_button_pressed=>wwv_flow_imp.id(76517478187804498)
,p_associated_column=>'FECHASOLICITADAPLANTA'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(76520076606804499)
,p_tabular_form_region_id=>wwv_flow_imp.id(76508292903804492)
,p_validation_name=>'FECHACONFIRMADAINGRESOPLANTA must be a valid date'
,p_validation_sequence=>60
,p_validation=>'FECHACONFIRMADAINGRESOPLANTA'
,p_validation_type=>'ITEM_IS_DATE'
,p_error_message=>'#COLUMN_HEADER# must be a valid date.'
,p_when_button_pressed=>wwv_flow_imp.id(76517478187804498)
,p_associated_column=>'FECHACONFIRMADAINGRESOPLANTA'
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(76152575823799247)
,p_name=>'OcultarCheck'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76152641953799248)
,p_event_id=>wwv_flow_imp.id(76152575823799247)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$( "input[type=''checkbox'']" ).css(''display'',''none'');'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(76520364643804499)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(76508292903804492)
,p_process_type=>'NATIVE_TABFORM_UPDATE'
,p_process_name=>'ApplyMRU'
,p_attribute_02=>'T_CMEX_DETALLESTRANSPORTE'
,p_attribute_03=>'ID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(76517478187804498)
,p_process_success_message=>'#MRU_COUNT# filas actualizadas, #MRI_COUNT# filas insertadas.'
,p_internal_uid=>76520364643804499
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(76520723879804499)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(76508292903804492)
,p_process_type=>'NATIVE_TABFORM_DELETE'
,p_process_name=>'ApplyMRD'
,p_attribute_02=>'T_CMEX_DETALLESTRANSPORTE'
,p_attribute_03=>'ID'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'MULTI_ROW_DELETE'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_process_success_message=>'#MRD_COUNT# filas eliminadas'
,p_internal_uid=>76520723879804499
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(76525241535804503)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_type=>'NEVER'
,p_internal_uid=>76525241535804503
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(76152252198799244)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Contenedores'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'FOR contenedor IN (SELECT NRO_CONTENEDOR FROM T_CMEX_DETALLECONTENEDOR WHERE ID_CMEX_MESATRABAJO = :P163_ID_CMEX_MESATRABAJO ',
'                      AND NRO_CONTENEDOR NOT IN (SELECT ID_CONTENEDOR FROM T_CMEX_DETALLESTRANSPORTE WHERE ID_CMEX_MESATRABAJO = :P163_ID_CMEX_MESATRABAJO))',
'LOOP',
'    ',
'    INSERT INTO T_CMEX_DETALLESTRANSPORTE (ID, ID_CMEX_MESATRABAJO, ID_CONTENEDOR, ESTADO)',
'    VALUES (NULL, :P163_ID_CMEX_MESATRABAJO, contenedor.NRO_CONTENEDOR, '''' );',
'    ',
'END LOOP;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>76152252198799244
);
wwv_flow_imp.component_end;
end;
/
