prompt --application/pages/page_00153
begin
--   Manifest
--     PAGE: 00153
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>153
,p_name=>'COMEX - Det. Contenedor'
,p_page_mode=>'MODAL'
,p_step_title=>'COMEX - Det. Contenedor'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_created_on=>wwv_flow_imp.dz('20230708132655Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260812181414Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74060485869884721)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(296121055316169165)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(74189613057389381)
,p_plug_name=>'Detalle del Contenedor'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(296121421643169165)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20230906141013Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74190300805389381)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(74060485869884721)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Cancel'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:152:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74190211851389381)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(74060485869884721)
,p_button_name=>'DELETE'
,p_button_action=>'REDIRECT_URL'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_image_alt=>'Eliminar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'javascript:apex.confirm(htmldb_delete_message,''DELETE'');'
,p_button_execute_validations=>'N'
,p_button_condition=>'P153_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-trash'
,p_database_action=>'DELETE'
,p_updated_on=>wwv_flow_imp.dz('20230906140400Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74190113394389381)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(74060485869884721)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Aplicar Cambios'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P153_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'UPDATE'
,p_updated_on=>wwv_flow_imp.dz('20230906140400Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(74190072923389381)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(74060485869884721)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(295682559356037725)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Crear'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P153_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'INSERT'
,p_updated_on=>wwv_flow_imp.dz('20230906140400Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(74191935927389384)
,p_branch_name=>'Go To Page 152'
,p_branch_action=>'f?p=&APP_ID.:152:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'P153_MODULO'
,p_branch_condition_text=>'IMP'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(81379934741053749)
,p_branch_name=>'Go to 171'
,p_branch_action=>'f?p=&APP_ID.:171:&SESSION.::&DEBUG.:RP,171:P171_ID:&P153_ID_CMEX_MESATRABAJO.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>11
,p_branch_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_branch_condition=>'P153_MODULO'
,p_branch_condition_text=>'EXP'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(64133987848537826)
,p_name=>'P153_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(74189613057389381)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
,p_created_on=>wwv_flow_imp.dz('20230906140358Z')
,p_updated_on=>wwv_flow_imp.dz('20230906140358Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74192309943389392)
,p_name=>'P153_NRO_CONTENEDOR'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(74189613057389381)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('N\00FAmero')
,p_source=>'NRO_CONTENEDOR'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260812171009Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74192617143389427)
,p_name=>'P153_ID_CMEX_MESATRABAJO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(74189613057389381)
,p_use_cache_before_default=>'NO'
,p_source=>'ID_CMEX_MESATRABAJO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_updated_on=>wwv_flow_imp.dz('20230918151027Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74193084751389434)
,p_name=>'P153_PESONETO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(74189613057389381)
,p_use_cache_before_default=>'NO'
,p_prompt=>'P. Neto (kg)'
,p_source=>'PESONETO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_display_when=>':P153_MODULO <> ''EXP'''
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'0'
,p_attribute_03=>'right'
,p_attribute_04=>'decimal'
,p_updated_on=>wwv_flow_imp.dz('20260812172101Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74193478667389434)
,p_name=>'P153_PESOBRUTO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(74189613057389381)
,p_use_cache_before_default=>'NO'
,p_prompt=>'P. Bruto (kg)'
,p_source=>'PESOBRUTO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_display_when=>':P153_MODULO <> ''EXP'''
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'0'
,p_attribute_03=>'right'
,p_attribute_04=>'decimal'
,p_updated_on=>wwv_flow_imp.dz('20260812172101Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74193803976389436)
,p_name=>'P153_PRIORITARIO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(74189613057389381)
,p_use_cache_before_default=>'NO'
,p_item_default=>'IF :P153_MODULO = ''IMP'' THEN :P153_PRIORITARIO := ''N''; ELSE :P153_PRIORITARIO := null; END IF; '
,p_item_default_type=>'FUNCTION_BODY'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Prioritario'
,p_source=>'PRIORITARIO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LOV_SINO'
,p_lov=>'.'||wwv_flow_imp.id(78141453854944977)||'.'
,p_display_when=>'P153_MODULO'
,p_display_when2=>'EXP'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20230918151027Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(74194294270389436)
,p_name=>'P153_TAMANOCONTENEDOR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(74189613057389381)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Tama\00F1o')
,p_source=>'TAMANOCONTENEDOR'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT DESCRIPCION AS D, VALOR AS R FROM T_CORP_UDC WHERE ID_CABECERA = ''CMEX_T_CON'' AND ACTIVO = ''1'''
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20260812171009Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81379321119053743)
,p_name=>'P153_PREEMBARQUE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(74189613057389381)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Inspecci\00F3n Preembarque')
,p_source=>'PREEMBARQUE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LOV_SINO'
,p_lov=>'.'||wwv_flow_imp.id(78141453854944977)||'.'
,p_display_when=>'P153_MODULO'
,p_display_when2=>'EXP'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20230918151028Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81379496885053744)
,p_name=>'P153_MODULO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(74189613057389381)
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20230918221045Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81379512905053745)
,p_name=>'P153_ANTINARCOTICOS'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(74189613057389381)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Inspecci\00F3n Antinarc\00F3ticos')
,p_source=>'ANTINARCOTICOS'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LOV_SINO'
,p_lov=>'.'||wwv_flow_imp.id(78141453854944977)||'.'
,p_begin_on_new_line=>'N'
,p_display_when=>'P153_MODULO'
,p_display_when2=>'EXP'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20230918151028Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81379766750053747)
,p_name=>'P153_REPORTEVERIFICADORA'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(74189613057389381)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Reporte Verificadora'
,p_source=>'REPORTEVERIFICADORA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>25
,p_display_when=>'P153_MODULO'
,p_display_when2=>'EXP'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20230918151028Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81379853204053748)
,p_name=>'P153_TRANSPORTISTA'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(74189613057389381)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Transportista'
,p_source=>'TRANSPORTISTA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_EMPRESAS'
,p_lov=>'select nombre AS D, idempresa AS R  from t_acpe_empresa;'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when=>'P153_MODULO'
,p_display_when2=>'EXP'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_updated_on=>wwv_flow_imp.dz('20230918151028Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81380069600053750)
,p_name=>'P153_ID_DETALLEDATOSEXP'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(74189613057389381)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Conocimiento de Embarque'
,p_source=>'ID_DETALLEDATOSEXP'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'SELECT CODIGO_BL AS D, ID AS R FROM  T_CMEX_DETALLEDATOSEXP WHERE ID_CMEX_MESATRABAJO = :P153_ID_CMEX_MESATRABAJO'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_display_when=>'P153_MODULO'
,p_display_when2=>'EXP'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20230918151028Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(572622658750644701)
,p_name=>'P153_PESOTARA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(74189613057389381)
,p_use_cache_before_default=>'NO'
,p_prompt=>'P. Tara (kg)'
,p_source=>'PESOTARA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_display_when=>':P153_MODULO <> ''EXP'''
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(295681930575037725)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'0'
,p_attribute_03=>'right'
,p_attribute_04=>'decimal'
,p_created_on=>wwv_flow_imp.dz('20260812171009Z')
,p_updated_on=>wwv_flow_imp.dz('20260812181414Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(76573721563781341)
,p_name=>unistr('Validaci\00F3n')
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P153_NRO_CONTENEDOR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'focusout'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(76573855831781342)
,p_event_id=>wwv_flow_imp.id(76573721563781341)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const  r = /^[A-Z]{4}[0-9]{7}/;',
'var texto = apex.item("P153_NRO_CONTENEDOR").getValue();',
'',
'if (r.test(texto) == false){',
'    alert("Formato Incorrecto");',
'    apex.item( "P153_NRO_CONTENEDOR" ).setStyle( "color", "red" );',
'}else{',
'    apex.item( "P153_NRO_CONTENEDOR" ).setStyle( "color", "black" );',
'}'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(74195020463389437)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from T_CMEX_DETALLECONTENEDOR'
,p_attribute_02=>'T_CMEX_DETALLECONTENEDOR'
,p_attribute_03=>'P153_ID'
,p_attribute_04=>'ID'
,p_internal_uid=>74195020463389437
,p_updated_on=>wwv_flow_imp.dz('20230906140400Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(74243177748161046)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Verifica Contenedores'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_total			number;',
'v_registrados	number;',
'v_idmesa		number;',
'v_idmodulo		varchar2(3);',
'v_tamano		varchar2(9);',
'begin',
'	v_idmesa	:= :p153_id_cmex_mesatrabajo;',
'	v_idmodulo	:= :p153_modulo;',
'	v_tamano	:= :p153_tamanocontenedor;',
'',
'	if v_idmodulo = ''EXP'' then',
'		null;',
'	else',
'		if v_tamano = ''20PIES'' then',
'			begin',
'				select nvl(cnt20pies,0) into v_total',
'				from data.t_cmex_mesatrabajo',
'				where id = v_idmesa;',
'',
'				exception when no_data_found then v_total := 0;',
'			end;',
'',
'			select count(1) into v_registrados',
'			from data.t_cmex_detallecontenedor',
'			where tamanocontenedor = v_tamano and id_cmex_mesatrabajo = v_idmesa;',
'',
'			if v_registrados > v_total then',
unistr('				raise_application_error(-20001, ''N\00FAmero de contenedores incorrecto.'');'),
'			end if;',
'		else',
'			begin',
'				select nvl(cnt40pies,0) into v_total',
'				from data.t_cmex_mesatrabajo',
'				where id = v_idmesa;',
'',
'				exception when no_data_found then v_total := 0;',
'			end;',
'',
'			select count(1) into v_registrados',
'			from data.t_cmex_detallecontenedor',
'			where tamanocontenedor = ''40PIES'' and id_cmex_mesatrabajo = v_idmesa;',
'',
'			if v_registrados > v_total then',
unistr('				raise_application_error(-20001, ''N\00FAmero de contenedores incorrecto.'');'),
'			end if;',
'		end if;',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'DELETE'
,p_process_when_type=>'REQUEST_NOT_EQUAL_CONDITION'
,p_internal_uid=>74243177748161046
,p_updated_on=>wwv_flow_imp.dz('20260812181258Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(74195411879389439)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of T_CMEX_DETALLECONTENEDOR'
,p_attribute_02=>'T_CMEX_DETALLECONTENEDOR'
,p_attribute_03=>'P153_ID'
,p_attribute_04=>'ID'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>74195411879389439
,p_updated_on=>wwv_flow_imp.dz('20230906140403Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(85320447014939430)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Actualiza Peso Bruto'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update t_cmex_mesatrabajo x set x.pesobruto =',
'	(select sum(y.pesobruto) from t_cmex_detallecontenedor y where y.id_cmex_mesatrabajo = x.id)',
'where x.id = :p153_id_cmex_mesatrabajo and exists',
'	(select sum(y.pesobruto) from t_cmex_detallecontenedor y where y.id_cmex_mesatrabajo = x.id);'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>85320447014939430
,p_created_on=>wwv_flow_imp.dz('20230919145948Z')
,p_updated_on=>wwv_flow_imp.dz('20230919145948Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(82126462251611226)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cont. Exportaciones'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_cnt20 number;',
'v_cnt40 number;',
'v_idmesa number;',
'begin',
'	v_idmesa := :p153_id_cmex_mesatrabajo;',
'	select count(1) into v_cnt20 from t_cmex_detallecontenedor',
'	where tamanocontenedor = ''20PIES'' and id_cmex_mesatrabajo = v_idmesa;',
'',
'	select count(1) into v_cnt40 from t_cmex_detallecontenedor',
'	where tamanocontenedor = ''40PIES'' and id_cmex_mesatrabajo = v_idmesa;',
'',
'	update t_cmex_mesatrabajo set cnt20pies = v_cnt20, cnt40pies = v_cnt40',
'	where id = v_idmesa;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P153_MODULO'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'EXP'
,p_internal_uid=>82126462251611226
,p_updated_on=>wwv_flow_imp.dz('20230919145948Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(74195895984389439)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(74190211851389381)
,p_internal_uid=>74195895984389439
,p_updated_on=>wwv_flow_imp.dz('20230919145948Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
