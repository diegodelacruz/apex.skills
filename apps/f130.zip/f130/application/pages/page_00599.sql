prompt --application/pages/page_00599
begin
--   Manifest
--     PAGE: 00599
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>599
,p_name=>'COMEX - SSO'
,p_alias=>'COMEX-SSO'
,p_step_title=>'COMEX - SSO'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_deep_linking=>'Y'
,p_rejoin_existing_sessions=>'Y'
,p_page_component_map=>'17'
,p_created_on=>wwv_flow_imp.dz('20241113165843Z')
,p_last_updated_on=>wwv_flow_imp.dz('20241023200132Z')
,p_last_updated_by=>'DCUEVA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(457062467291269968)
,p_plug_name=>'VARIABLES'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(295630388916037685)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(344896945875246603)
,p_name=>'P599_EXPORTACION_REGISTRO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(457062467291269968)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(344897092652246604)
,p_name=>'P599_DATOS_GESTION_DET_ID'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(457062467291269968)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(344897132021246605)
,p_name=>'P599_REMEMBER'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(457062467291269968)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(344903819919264070)
,p_name=>'P599_USERNAME'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(457062467291269968)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(344904218897264070)
,p_name=>'P599_PASSWORD'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(457062467291269968)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(344904646368264070)
,p_name=>'P599_COMPANIA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(457062467291269968)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(344905003978264071)
,p_name=>'P599_PAGE_GOTO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(457062467291269968)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(344905486358264071)
,p_name=>'P599_URL_GOTO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(457062467291269968)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(352515980065436542)
,p_name=>'P599_ORIGEN'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(457062467291269968)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(344905809184264075)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get Username Cookie'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P599_USERNAME := apex_authentication.get_login_username_cookie;',
':P599_REMEMBER := case when :P9999_USERNAME is not null then ''Y'' end;',
'',
'-- LOG',
'PK_CMEX_GESTIONBOOKING.SP_LOG(''SSO'', NULL, ''Before Header''||:APP_SESSION||'' ''||:APP_USER);'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>344905809184264075
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(344906229644264076)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Datos para SSO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    COUNTER     NUMBER;',
'    REMOTE_USER VARCHAR2(100);',
'BEGIN',
'    :P599_PAGE_GOTO := 100;',
'    REMOTE_USER     := NULL;',
'    :P599_PASSWORD  := NULL;',
'',
'    IF :P599_ORIGEN      = ''V'' THEN',
'        REMOTE_USER     := ''VERIFICADORA'';',
'        :P599_PAGE_GOTO := 525;',
'    END IF;',
'    ',
'    IF :P599_ORIGEN      = ''T'' THEN',
'        REMOTE_USER     := ''TRANSPORTISTA'';',
'        :P599_PAGE_GOTO := 527;',
'    END IF;',
'',
'    IF UPPER(:APP_USER) = ''NOBODY'' THEN',
'',
'        IF REMOTE_USER IS NULL THEN',
'            RAISE_APPLICATION_ERROR(-20000,''Null remote user'');',
'            RETURN;',
'        END IF;',
'',
'        IF :P599_COMPANIA IS NULL THEN',
'            :P599_COMPANIA := ''00001'';',
'        END IF;',
'',
'        :P599_USERNAME := REMOTE_USER;',
'',
'        SELECT COUNT(1) INTO COUNTER FROM VT_CORP_USUARIO WHERE UPPER(NOMBREUSUARIO)=UPPER(REMOTE_USER);',
'        ',
'        IF COUNTER = 0 THEN',
'            RAISE_APPLICATION_ERROR(-20000,''NO existe ''||UPPER(REMOTE_USER));',
'            RETURN;    ',
'        END IF;',
'',
'        SELECT CONTRASENA ',
'        INTO   :P599_PASSWORD',
'        FROM   VT_CORP_USUARIO',
'        WHERE  UPPER(NOMBREUSUARIO)=UPPER(REMOTE_USER);',
'    END IF;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>344906229644264076
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(344906616763264077)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SSO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P599_PASSWORD IS NOT NULL THEN',
'',
'    apex_authentication.send_login_username_cookie (',
'        p_username => lower(:P599_USERNAME),',
'        p_consent  => :P599_REMEMBER = ''Y'' ',
'    );',
'',
'    apex_authentication.login(',
'        p_username => :P599_USERNAME,',
'        p_password => :P599_PASSWORD ',
'    );',
'',
'    APEX_UTIL.set_session_state(''G_COMPANIA'', :P599_COMPANIA);',
'END IF;',
'',
':P599_URL_GOTO := APEX_UTIL.PREPARE_URL(p_url => ''f?p=130:''',
'            ||',
'        :P599_PAGE_GOTO||'':''||:APP_SESSION',
'            ||',
'        ''::::P''||:P599_PAGE_GOTO||''_EXPORTACION_REGISTRO,P''||:P599_PAGE_GOTO||''_DATOS_GESTION_DET_ID:''',
'            ||',
'        :P599_EXPORTACION_REGISTRO||'',''||:P599_DATOS_GESTION_DET_ID);',
'',
'-- LOG',
'PK_CMEX_GESTIONBOOKING.SP_LOG(''SSO'', :P599_EXPORTACION_REGISTRO, :P599_URL_GOTO);',
'',
'apex_util.redirect_url (',
'    p_url => ''/apex/''||:P599_URL_GOTO ',
');',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>344906616763264077
);
wwv_flow_imp.component_end;
end;
/
