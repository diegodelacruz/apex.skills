prompt --application/shared_components/logic/application_processes/g_gestion_presidente
begin
--   Manifest
--     APPLICATION PROCESS: G_GESTION_PRESIDENTE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(201044743037676228)
,p_process_sequence=>2
,p_process_point=>'AFTER_LOGIN'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'G_GESTION_PRESIDENTE'
,p_process_sql_clob=>'select decode(:app_user,''GDIMELLA'',1,0) into :g_gestion_presidente from dual;'
,p_process_clob_language=>'PLSQL'
,p_version_scn=>1
,p_created_on=>wwv_flow_imp.dz('20240117194628Z')
,p_updated_on=>wwv_flow_imp.dz('20240117194628Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
