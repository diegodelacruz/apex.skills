prompt --application/shared_components/logic/application_processes/g_proc_descargararchivo
begin
--   Manifest
--     APPLICATION PROCESS: G_PROC_DESCARGARARCHIVO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(78301204741741433)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'G_PROC_DESCARGARARCHIVO'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	data.pk_cmex_mesatrabajo.sp_descargarblob (:g_numeroarchivo);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_process_when_type=>'USER_IS_NOT_PUBLIC_USER'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>1
,p_updated_on=>wwv_flow_imp.dz('20230825165050Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
