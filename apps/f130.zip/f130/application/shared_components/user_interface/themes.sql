prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 130
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(295684814041037735)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_version_identifier=>'1.2'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>42997337983432003
,p_is_locked=>false
,p_default_page_template=>wwv_flow_imp.id(295601127697037664)
,p_default_dialog_template=>wwv_flow_imp.id(295596898750037659)
,p_error_template=>wwv_flow_imp.id(295590414047037653)
,p_printer_friendly_template=>wwv_flow_imp.id(295601127697037664)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_imp.id(295590414047037653)
,p_default_button_template=>wwv_flow_imp.id(295682663716037726)
,p_default_region_template=>wwv_flow_imp.id(296121421643169165)
,p_default_chart_template=>wwv_flow_imp.id(295630388916037685)
,p_default_form_template=>wwv_flow_imp.id(295630388916037685)
,p_default_reportr_template=>wwv_flow_imp.id(295630388916037685)
,p_default_tabform_template=>wwv_flow_imp.id(295630388916037685)
,p_default_wizard_template=>wwv_flow_imp.id(295630388916037685)
,p_default_menur_template=>wwv_flow_imp.id(295639738305037692)
,p_default_listr_template=>wwv_flow_imp.id(295630388916037685)
,p_default_irr_template=>wwv_flow_imp.id(295629242996037685)
,p_default_report_template=>wwv_flow_imp.id(295654681717037704)
,p_default_label_template=>wwv_flow_imp.id(295681930575037725)
,p_default_menu_template=>wwv_flow_imp.id(295683461023037726)
,p_default_calendar_template=>wwv_flow_imp.id(295683528029037728)
,p_default_list_template=>wwv_flow_imp.id(295670477192037715)
,p_default_nav_list_template=>wwv_flow_imp.id(295678067734037721)
,p_default_top_nav_list_temp=>wwv_flow_imp.id(295678067734037721)
,p_default_side_nav_list_temp=>wwv_flow_imp.id(295676038882037720)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_imp.id(295609822801037671)
,p_default_dialogr_template=>wwv_flow_imp.id(295608822663037671)
,p_default_option_label=>wwv_flow_imp.id(295681930575037725)
,p_default_required_label=>wwv_flow_imp.id(295681930575037725)
,p_default_navbar_list_template=>wwv_flow_imp.id(295675881544037720)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#IMAGE_PREFIX#themes/theme_42/1.2/')
,p_files_version=>172
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#IMAGE_PREFIX#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_IMAGES#js/theme42#MIN#.js?v=#APEX_VERSION#',
'#THEME_DB_IMAGES#js/zaimella.js'))
,p_css_file_urls=>'#THEME_IMAGES#css/Core#MIN#.css?v=#APEX_VERSION#'
,p_updated_on=>wwv_flow_imp.dz('20250428145426Z')
,p_updated_by=>'CVACA'
);
wwv_flow_imp.component_end;
end;
/
