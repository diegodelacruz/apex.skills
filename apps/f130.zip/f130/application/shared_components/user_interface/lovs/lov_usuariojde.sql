prompt --application/shared_components/user_interface/lovs/lov_usuariojde
begin
--   Manifest
--     LOV_USUARIOJDE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(93828433234264361)
,p_lov_name=>'LOV_USUARIOJDE'
,p_lov_query=>'select nombres||'' ''||apellidos d, coderp r from vt_corp_usuario where nvl(coderp,0) != 0'
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
