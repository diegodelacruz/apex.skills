prompt --application/shared_components/user_interface/lovs/lov_neg_unidadnegocio
begin
--   Manifest
--     LOV_NEG_UNIDADNEGOCIO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(44764979228098231)
,p_lov_name=>'LOV_NEG_UNIDADNEGOCIO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select tipo1||'' - ''||nombre descripcion,trim(tipo1) codigo',
'from t_admi_ruta a',
'where codigomodulo = ''COMP'' and tipo2 = ''CN'' order by nombre'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'CODIGO'
,p_display_column_name=>'DESCRIPCION'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
,p_updated_on=>wwv_flow_imp.dz('20240416150039Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(284324532681962359)
,p_query_column_name=>'CODIGO'
,p_heading=>unistr('C\00F3digo')
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
,p_is_visible=>'N'
,p_is_searchable=>'N'
,p_created_on=>wwv_flow_imp.dz('20240411155414Z')
,p_updated_on=>wwv_flow_imp.dz('20240416150039Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(284324932917962360)
,p_query_column_name=>'DESCRIPCION'
,p_heading=>unistr('Descripci\00F3n')
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
,p_created_on=>wwv_flow_imp.dz('20240411155414Z')
,p_updated_on=>wwv_flow_imp.dz('20240416150039Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
