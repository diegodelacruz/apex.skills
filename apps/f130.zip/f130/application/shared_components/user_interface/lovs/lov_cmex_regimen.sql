prompt --application/shared_components/user_interface/lovs/lov_cmex_regimen
begin
--   Manifest
--     LOV_CMEX_REGIMEN
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(165397324327558205)
,p_lov_name=>'LOV_CMEX_REGIMEN'
,p_lov_query=>'.'||wwv_flow_imp.id(165397324327558205)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(165397608342558205)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('Muestra R\00E9gimen 10')
,p_lov_return_value=>'10'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(165398092971558206)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('Muestra R\00E9gimen 91')
,p_lov_return_value=>'91'
);
wwv_flow_imp.component_end;
end;
/
