prompt --application/shared_components/user_interface/lovs/lov_cmex_tipotramite
begin
--   Manifest
--     LOV_CMEX_TIPOTRAMITE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(165396252152546724)
,p_lov_name=>'LOV_CMEX_TIPOTRAMITE'
,p_lov_query=>'.'||wwv_flow_imp.id(165396252152546724)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(165396507409546740)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('Importaci\00F3n')
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(165396920189546741)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('Exportaci\00F3n')
,p_lov_return_value=>'2'
);
wwv_flow_imp.component_end;
end;
/
