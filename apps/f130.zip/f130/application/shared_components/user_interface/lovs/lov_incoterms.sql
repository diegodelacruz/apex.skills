prompt --application/shared_components/user_interface/lovs/lov_incoterms
begin
--   Manifest
--     LOV_INCOTERMS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(74803172029355163)
,p_lov_name=>'LOV_INCOTERMS'
,p_lov_query=>'select DRKY ||'' - ''||upper(DRDL01) d,DRKY r from vt_jde_udcjde where drsy=''42'' and drrt=''FR'' and drky is not null order by upper(DRKY)'
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
