prompt --application/shared_components/user_interface/lovs/lov_cmex_unidadmedida
begin
--   Manifest
--     LOV_CMEX_UNIDADMEDIDA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(166348189842737774)
,p_lov_name=>'LOV_CMEX_UNIDADMEDIDA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT upper(DRDL01)||'' (''||DRKY||'')'' AS D, DRKY AS R ',
'FROM DATA.VT_JDE_UDCJDE',
'WHERE DRSY = ''00'' AND DRRT= ''UM'' ',
'ORDER BY 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
