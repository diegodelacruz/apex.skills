prompt --application/shared_components/user_interface/lovs/lov_redessociales
begin
--   Manifest
--     LOV_REDESSOCIALES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(59045883375216499)
,p_lov_name=>'LOV_REDESSOCIALES'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CAMPO1 id,CAMPO2,CAMPO1',
'from table',
'(',
'PK_COMMONS.F_SPLIT2TABLE(''fa-twitter|twitter;fa-facebook|facebook;fa-instagram|instagram;'', ''|'','';'')',
');'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'ID'
,p_display_column_name=>'CAMPO2'
,p_icon_column_name=>'CAMPO1'
,p_group_column_name=>'CAMPO1'
,p_group_sort_direction=>'DESC'
,p_default_sort_column_name=>'CAMPO2'
,p_default_sort_direction=>'ASC'
,p_oracle_text_column_name=>'CAMPO1'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
