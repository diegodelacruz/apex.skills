prompt --application/shared_components/user_interface/lovs/lov_udc_41_9
begin
--   Manifest
--     LOV_UDC_41_9
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(129811530306971265)
,p_lov_name=>'LOV_UDC_41_9'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select upper(drdl01)||'' (''||drky||'')'' d, drky',
'from data.vt_jde_udcjde y',
'where y.drsy = ''41'' and y.drrt = ''9'' and drky is not null'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'DRKY'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>125445541851
,p_updated_on=>wwv_flow_imp.dz('20260602211752Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
