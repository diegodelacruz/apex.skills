prompt --application/shared_components/user_interface/lovs/lov_productos_jde
begin
--   Manifest
--     LOV_PRODUCTOS_JDE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(76010393910491646)
,p_lov_name=>'LOV_PRODUCTOS_JDE'
,p_lov_query=>'SELECT trim(imdsc1)||'' (''||trim(imlitm)||'')'' AS DESCRIPCION, trim(imlitm) AS CODIGO FROM F4101@jdedtadl where substr(imglpt,1,2) = ''IN'''
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
