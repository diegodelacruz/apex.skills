prompt --application/shared_components/user_interface/lovs/lov_jde_tipodocumento
begin
--   Manifest
--     LOV_JDE_TIPODOCUMENTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(115200108729326933)
,p_lov_name=>'LOV_JDE_TIPODOCUMENTO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT TRIM(drky)     || ''-'' || drdl01  d, TRIM(drky) r ',
'FROM vt_jde_udc ',
'WHERE   drsy = ''00'' AND drrt IN ( ''DT'' ) ',
'ORDER BY 1;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
