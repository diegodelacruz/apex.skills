prompt --application/shared_components/user_interface/lovs/lov_terminosdepago2
begin
--   Manifest
--     LOV_TERMINOSDEPAGO2
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(55151214738202566)
,p_lov_name=>'LOV_TERMINOSDEPAGO2'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  l_sql   CLOB := ''select d, r from ('';',
'  l_sep   VARCHAR2(20) := '''';',
'',
'  PROCEDURE add_src(p_sql IN CLOB, p_probe IN VARCHAR2) IS',
'  BEGIN',
'    -- Intentamos conectar al dblink. Si falla, no agregamos ese origen.',
'    BEGIN',
'      EXECUTE IMMEDIATE p_probe;       -- por ej. ''select 1 from dual@jdedtadl''',
'      l_sql := l_sql || l_sep || p_sql;',
'      l_sep := '' UNION ALL '';',
'    EXCEPTION',
'      WHEN OTHERS THEN',
'        NULL; -- ignoramos el error del dblink',
'    END;',
'  END;',
'BEGIN',
'  -- 1) JDE (siempre lo intentamos)',
'  add_src(',
'    q''[',
'      SELECT CAST(pnptc || '' - '' || TRIM(pnptd) AS VARCHAR2(70)) AS d,',
'             CAST(pnptc AS VARCHAR2(10)) AS r',
'      FROM f0014@jdedtadl',
'    ]'',',
'    ''select 1 from dual@jdedtadl''',
'  );',
'',
unistr('  -- 2) HANA GT (solo si aplica compa\00F1\00EDa)'),
'  IF NVL(:P620_COMPANIADES, ''X'') = ''00006'' THEN',
'    add_src(',
'      q''[',
'        SELECT CAST("GroupNum" || '' - '' || "PymntGroup" AS VARCHAR2(70)) AS d,',
'               CAST(TO_CHAR("GroupNum") AS VARCHAR2(10)) AS r',
'        FROM OCTG@HANAGT',
'      ]'',',
'      ''select 1 from dual@HANAGT''',
'    );',
'  END IF;',
'',
unistr('  -- 3) HANA ABX (solo si aplica compa\00F1\00EDa)'),
'  IF NVL(:P620_COMPANIADES, ''X'') = ''00015'' THEN',
'    add_src(',
'      q''[',
'        SELECT CAST("GroupNum" || '' - '' || "PymntGroup" AS VARCHAR2(70)) AS d,',
'               CAST(TO_CHAR("GroupNum") AS VARCHAR2(10)) AS r',
'        FROM OCTG@HANA_ABX',
'      ]'',',
'      ''select 1 from dual@HANA_ABX''',
'    );',
'  END IF;',
'',
unistr('  -- 3) HANA PE (solo si aplica compa\00F1\00EDa)'),
'  IF NVL(:P620_COMPANIADES, ''X'') = ''00003'' THEN',
'    add_src(',
'      q''[',
'        SELECT CAST("GroupNum" || '' - '' || "PymntGroup" AS VARCHAR2(70)) AS d,',
'               CAST(TO_CHAR("GroupNum") AS VARCHAR2(10)) AS r',
'        FROM OCTG@HANA_PE',
'      ]'',',
'      ''select 1 from dual@HANA_PE''',
'    );',
'  END IF;',
'',
unistr('  -- Si ning\00FAn origen qued\00F3 disponible, devolvemos 0 filas'),
'  IF l_sep IS NULL THEN',
'    RETURN ''select cast(null as varchar2(70)) d, cast(null as varchar2(10)) r from dual where 1=0'';',
'  END IF;',
'',
'  l_sql := l_sql || '')'';',
'  RETURN l_sql;',
'END;',
''))
,p_source_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>119928657631
,p_updated_on=>wwv_flow_imp.dz('20260109152357Z')
,p_updated_by=>'JBALCAZAR'
);
wwv_flow_imp.component_end;
end;
/
