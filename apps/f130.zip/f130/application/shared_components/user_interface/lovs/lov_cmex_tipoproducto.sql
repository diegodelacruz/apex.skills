prompt --application/shared_components/user_interface/lovs/lov_cmex_tipoproducto
begin
--   Manifest
--     LOV_CMEX_TIPOPRODUCTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(166961037936021229)
,p_lov_name=>'LOV_CMEX_TIPOPRODUCTO'
,p_lov_query=>'.'||wwv_flow_imp.id(166961037936021229)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(166961317609021230)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'TELA NO TEJIDA'
,p_lov_return_value=>'TNT'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(166961741138021230)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'ADHESIVOS'
,p_lov_return_value=>'ADH'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(166962183429021230)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'PP FILM'
,p_lov_return_value=>'PPF'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(166962525945021230)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>unistr('QU\00CDMICOS')
,p_lov_return_value=>'QUI'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(166962909794021230)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>'SPANDEX'
,p_lov_return_value=>'SPA'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(166963359498021230)
,p_lov_disp_sequence=>6
,p_lov_disp_value=>'PULPA'
,p_lov_return_value=>'PUL'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(166963756399021231)
,p_lov_disp_sequence=>7
,p_lov_disp_value=>'SAP'
,p_lov_return_value=>'SAP'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(166964154209021231)
,p_lov_disp_sequence=>8
,p_lov_disp_value=>'PRODUCTO TERMINADO'
,p_lov_return_value=>'PTE'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(166964581883021231)
,p_lov_disp_sequence=>9
,p_lov_disp_value=>'OTROS'
,p_lov_return_value=>'OTR'
);
wwv_flow_imp.component_end;
end;
/
