prompt --application/shared_components/user_interface/lovs/lov_neg_tipoformula
begin
--   Manifest
--     LOV_NEG_TIPOFORMULA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(66470570719199476)
,p_lov_name=>'LOV_NEG_TIPOFORMULA'
,p_lov_query=>'.'||wwv_flow_imp.id(66470570719199476)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(66470893296199477)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('Por \00CDndice')
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(66471259202199478)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Por Valor'
,p_lov_return_value=>'2'
);
wwv_flow_imp.component_end;
end;
/
