prompt --application/shared_components/user_interface/lovs/lov_neg_tipopago
begin
--   Manifest
--     LOV_NEG_TIPOPAGO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(231130202278619882)
,p_lov_name=>'LOV_NEG_TIPOPAGO'
,p_lov_query=>'.'||wwv_flow_imp.id(231130202278619882)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
,p_created_on=>wwv_flow_imp.dz('20240220155120Z')
,p_updated_on=>wwv_flow_imp.dz('20240220155120Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(231130591656619890)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Periodo Actual'
,p_lov_return_value=>'PA'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(231130906384619891)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Periodo Cerrado'
,p_lov_return_value=>'PC'
);
wwv_flow_imp.component_end;
end;
/
