prompt --application/shared_components/user_interface/lovs/lov_jde_octiposfechaentrega
begin
--   Manifest
--     LOV_JDE_OCTIPOSFECHAENTREGA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(45271574021808744)
,p_lov_name=>'LOV_JDE_OCTIPOSFECHAENTREGA'
,p_lov_query=>'.'||wwv_flow_imp.id(45271574021808744)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(45271803756808744)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'FECHA EMBARQUE'
,p_lov_return_value=>'1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(45272262710808745)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'FECHA PUERTO'
,p_lov_return_value=>'2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(45272660547808745)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'FECHA ZAIMELLA'
,p_lov_return_value=>'3'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(45273021969808745)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'FECHA PLANTA PROVEED.'
,p_lov_return_value=>'5'
);
wwv_flow_imp.component_end;
end;
/
