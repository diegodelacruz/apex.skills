prompt --application/shared_components/user_interface/lovs/lov_terminosdepago
begin
--   Manifest
--     LOV_TERMINOSDEPAGO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(291135880889049209)
,p_lov_name=>'LOV_TERMINOSDEPAGO'
,p_lov_query=>'select pnptc||'' - ''||trim(pnptd) d,pnptc r from f0014@jdedtadl'
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
