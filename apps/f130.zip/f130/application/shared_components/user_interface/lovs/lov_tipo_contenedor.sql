prompt --application/shared_components/user_interface/lovs/lov_tipo_contenedor
begin
--   Manifest
--     LOV_TIPO_CONTENEDOR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(312467351177195672)
,p_lov_name=>'LOV_TIPO_CONTENEDOR'
,p_lov_query=>'.'||wwv_flow_imp.id(312467351177195672)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(312467647717195675)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'40 pies'
,p_lov_return_value=>'40'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(312468012511195676)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'20 pies'
,p_lov_return_value=>'20'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(312468481520195676)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'SUELTA'
,p_lov_return_value=>'SUELTA'
);
wwv_flow_imp.component_end;
end;
/
