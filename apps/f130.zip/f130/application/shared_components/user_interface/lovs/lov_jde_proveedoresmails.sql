prompt --application/shared_components/user_interface/lovs/lov_jde_proveedoresmails
begin
--   Manifest
--     LOV_JDE_PROVEEDORESMAILS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(105150054551790711)
,p_lov_name=>'LOV_JDE_PROVEEDORESMAILS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
' ',
'select ',
'    CODIGOJDE ||'' - ''||RAZONSOCIAL USUARIO,',
'    NOMBRECOMERCIAL,',
'    CODIGOJDE,',
'    REPLACE(EMAILPEDIDO,''|'','','') EMAIL',
'from vt_comp_jdeproveedor',
'where 1= 1',
'AND ESTADO= ''A''',
'AND EMAILPEDIDO IS NOT NULL'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'CODIGOJDE'
,p_display_column_name=>'USUARIO'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'USUARIO'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(105150587315797203)
,p_query_column_name=>'USUARIO'
,p_heading=>'Usuario'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(105153262461808695)
,p_query_column_name=>'EMAIL'
,p_heading=>'Email'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(105321930866666115)
,p_query_column_name=>'CODIGOJDE'
,p_heading=>'Codigojde'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(105150909071797203)
,p_query_column_name=>'NOMBRECOMERCIAL'
,p_heading=>'Nombrecomercial'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
