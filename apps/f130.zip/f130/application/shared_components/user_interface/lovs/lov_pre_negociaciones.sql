prompt --application/shared_components/user_interface/lovs/lov_pre_negociaciones
begin
--   Manifest
--     LOV_PRE_NEGOCIACIONES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(112037224041564304)
,p_lov_name=>'LOV_PRE_NEGOCIACIONES'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT neg_id,cab_id,det_id,NEG_VIGENCIADESDE,NEG_VIGENCIAHASTA,nvl(NEG_PERIODICIDAD,0)NEG_PERIODICIDAD,trim(IMDSC1) ||'' ''|| trim(IMDSC2) DET_DESPRODUCTO,',
'DET_CODPRODUCTO,DET_CODPRODUCTOPRV,DET_DESPRODUCTOPRV',
',''[''||NEG_VIGENCIADESDE||'' - ''||NEG_VIGENCIAHASTA ||''] - ''||trim(IMDSC1) ||'' ''|| trim(IMDSC2) descripcion2',
'FROM  vt_comp_negociacion neg',
'inner  JOIN F4101@JDEDTADL on DET_CODPRODUCTO = IMITM',
'WHERE 1=1',
'and  neg_id=:P216_NEGID',
'ORDER BY neg_id,cab_id,det_id'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'NEG_ID'
,p_display_column_name=>'DESCRIPCION2'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(112038490459580317)
,p_query_column_name=>'NEG_ID'
,p_heading=>'Neg Id'
,p_display_sequence=>30
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(112038075000580317)
,p_query_column_name=>'CAB_ID'
,p_heading=>'Cab Id'
,p_display_sequence=>40
,p_data_type=>'NUMBER'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(112037618149580316)
,p_query_column_name=>'DET_ID'
,p_heading=>'Det iId'
,p_display_sequence=>50
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(112038828901580317)
,p_query_column_name=>'NEG_VIGENCIADESDE'
,p_heading=>'Inicio Vigencia'
,p_display_sequence=>60
,p_data_type=>'DATE'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(112039290575580317)
,p_query_column_name=>'NEG_VIGENCIAHASTA'
,p_heading=>'Fin Vigencia'
,p_display_sequence=>70
,p_data_type=>'DATE'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(112039680188580317)
,p_query_column_name=>'NEG_PERIODICIDAD'
,p_heading=>'Periodicidad'
,p_display_sequence=>80
,p_data_type=>'NUMBER'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(112040034059580317)
,p_query_column_name=>'DET_CODPRODUCTO'
,p_heading=>'Cod Producto JDE'
,p_display_sequence=>90
,p_data_type=>'NUMBER'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(112040432207580318)
,p_query_column_name=>'DET_DESPRODUCTO'
,p_heading=>'Producto JDE'
,p_display_sequence=>100
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(112040884285580318)
,p_query_column_name=>'DET_CODPRODUCTOPRV'
,p_heading=>'Cod Producto Proveedor'
,p_display_sequence=>110
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(112041299374580318)
,p_query_column_name=>'DET_DESPRODUCTOPRV'
,p_heading=>'Producto Proveedor'
,p_display_sequence=>120
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(112198587614090124)
,p_query_column_name=>'DESCRIPCION2'
,p_heading=>unistr('Descripci\00F3n')
,p_display_sequence=>130
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
