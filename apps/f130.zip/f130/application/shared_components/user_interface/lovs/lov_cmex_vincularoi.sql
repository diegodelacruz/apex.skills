prompt --application/shared_components/user_interface/lovs/lov_cmex_vincularoi
begin
--   Manifest
--     LOV_CMEX_VINCULAROI
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(519937098850320362)
,p_lov_name=>'LOV_CMEX_VINCULAROI'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select phdoco odc, pk_commons.f_jde2g(phtrdj) fecha, phdoco||'' - ''||lpad(aban8,6,''0'')||'' - ''||upper(trim(abalph)) proveedor',
'from f4301@jdedtadl inner join f0101@jdedtadl on phan8 = aban8 and phdcto = phdcto and phdoco = phdoco',
'where phan8 = phan8 and phdcto = ''OI'' and phdoco not in (select ordenimp from t_cmex_ordenesvinculadas where ordenimp is not null union select ordencompra from t_cmex_mesatrabajo where ordencompra is not null)',
'order by phdoco desc'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'ODC'
,p_display_column_name=>'PROVEEDOR'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
,p_created_on=>wwv_flow_imp.dz('20241127170614Z')
,p_updated_on=>wwv_flow_imp.dz('20241127192441Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
