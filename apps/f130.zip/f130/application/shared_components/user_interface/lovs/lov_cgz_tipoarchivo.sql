prompt --application/shared_components/user_interface/lovs/lov_cgz_tipoarchivo
begin
--   Manifest
--     LOV_CGZ_TIPOARCHIVO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(573004918697433826)
,p_lov_name=>'LOV_CGZ_TIPOARCHIVO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id_tabla, descripcion',
'from t_corp_udc',
'where id_cabecera = ''COMP_CGZ03'' and id_tabla != ''000''',
'order by descripcion'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID_TABLA'
,p_display_column_name=>'DESCRIPCION'
,p_version_scn=>1
,p_created_on=>wwv_flow_imp.dz('20250120133121Z')
,p_updated_on=>wwv_flow_imp.dz('20250120133121Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
