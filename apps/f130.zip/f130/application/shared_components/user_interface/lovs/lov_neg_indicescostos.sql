prompt --application/shared_components/user_interface/lovs/lov_neg_indicescostos
begin
--   Manifest
--     LOV_NEG_INDICESCOSTOS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(66472642723269258)
,p_lov_name=>'LOV_NEG_INDICESCOSTOS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  CODINDICE indice , ID  , ''[''||VIGENCIADESDE||'' - ''||VIGENCIAHASTA||'']'' VIGENCIA , substr(OBSERVACION,1,50)||'' - ''||substr(OBSERVACIONVLR,1,50) OBSERVACION from vt_comp_negociacionidx',
'order by VIGENCIAHASTA DESC, VIGENCIADESDE desc'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'ID'
,p_display_column_name=>'OBSERVACION'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(87914956423693703)
,p_query_column_name=>'ID'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(87915338528693704)
,p_query_column_name=>'INDICE'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(157466037148254828)
,p_query_column_name=>'OBSERVACION'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(87915717389693704)
,p_query_column_name=>'VIGENCIA'
,p_display_sequence=>40
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
