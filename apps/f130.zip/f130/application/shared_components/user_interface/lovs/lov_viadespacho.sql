prompt --application/shared_components/user_interface/lovs/lov_viadespacho
begin
--   Manifest
--     LOV_VIADESPACHO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(41639067365102374)
,p_lov_name=>'LOV_VIADESPACHO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select descripcion d, id_tabla r',
'from t_corp_udc where id_cabecera = ''CMEX_VDESP'' order by 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
,p_created_on=>wwv_flow_imp.dz('20230726055813Z')
,p_updated_on=>wwv_flow_imp.dz('20240410155847Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp.component_end;
end;
/
