prompt --application/shared_components/user_interface/lovs/lov_unidadnegocio
begin
--   Manifest
--     LOV_UNIDADNEGOCIO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(77363400278805753)
,p_lov_name=>'LOV_UNIDADNEGOCIO'
,p_lov_query=>'select trim(mcmcu)||'' - ''||trim(mcdc) as d, trim(mcmcu) as r from f0006@jdedtadl order by trim(mcdc)'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
,p_updated_on=>wwv_flow_imp.dz('20240412201404Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
