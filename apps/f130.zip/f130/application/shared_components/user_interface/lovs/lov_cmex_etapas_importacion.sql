prompt --application/shared_components/user_interface/lovs/lov_cmex_etapas_importacion
begin
--   Manifest
--     LOV_CMEX_ETAPAS_IMPORTACION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(74279793258956227)
,p_lov_name=>'LOV_CMEX_ETAPAS_IMPORTACION'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select valor||'' - ''||descripcion AS D, valor AS R ',
'from data.t_corp_udc where id_cabecera = ''CMEX_ET_IM'''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
