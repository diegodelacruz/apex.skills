prompt --application/shared_components/user_interface/lovs/lov_pre_tipo_codigo
begin
--   Manifest
--     LOV_PRE_TIPO_CODIGO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(113688874875081204)
,p_lov_name=>'LOV_PRE_TIPO_CODIGO'
,p_reference_id=>113685317443066485
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ID_TABLA, ID_TABLA ||'' '' ||DESCRIPCION DESCRIPCION',
'FROM "DATA"."T_CORP_UDC"  ',
'WHERE ID_CABECERA=''COMP_PRTIP'' AND ACTIVO=''1''; '))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'ID_TABLA'
,p_display_column_name=>'DESCRIPCION'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
