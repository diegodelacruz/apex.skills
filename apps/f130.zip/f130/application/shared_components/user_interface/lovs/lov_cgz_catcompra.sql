prompt --application/shared_components/user_interface/lovs/lov_cgz_catcompra
begin
--   Manifest
--     LOV_CGZ_CATCOMPRA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(557527731706369421)
,p_lov_name=>'LOV_CGZ_CATCOMPRA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select descripcion D, id_tabla R',
'from data.t_corp_udc ',
'where id_cabecera = ''COMP_CGZ01'' and activo = ''1'' and id_tabla != ''000'' ',
'order by descripcion;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>113718076879
,p_created_on=>wwv_flow_imp.dz('20250106182755Z')
,p_updated_on=>wwv_flow_imp.dz('20250806140359Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
