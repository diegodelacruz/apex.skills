prompt --application/shared_components/user_interface/lovs/lov_neg_tipotolerancia
begin
--   Manifest
--     LOV_NEG_TIPOTOLERANCIA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(50696667460910822)
,p_lov_name=>'LOV_NEG_TIPOTOLERANCIA'
,p_lov_query=>'.'||wwv_flow_imp.id(50696667460910822)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(50696996309910822)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'POR CONTRATO'
,p_lov_return_value=>'PCN'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(56037301555797564)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('POR COTIZACI\00D3N')
,p_lov_return_value=>'PCZ'
);
wwv_flow_imp.component_end;
end;
/
