prompt --application/shared_components/user_interface/lovs/lov_compania
begin
--   Manifest
--     LOV_COMPANIA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(557492462485214923)
,p_lov_name=>'LOV_COMPANIA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select *',
'from T_ADMI_COMPANIA',
'where 1 = 1',
'	and codigocorporacion = ''00001''',
'order by CODIGO'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'CODIGO'
,p_display_column_name=>'DESCRIPCION'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
,p_created_on=>wwv_flow_imp.dz('20250106180210Z')
,p_updated_on=>wwv_flow_imp.dz('20250106204353Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(557717219455153842)
,p_query_column_name=>'CODIGO'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
,p_is_visible=>'N'
,p_is_searchable=>'N'
,p_created_on=>wwv_flow_imp.dz('20250106203840Z')
,p_updated_on=>wwv_flow_imp.dz('20250106204353Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(557717633075153842)
,p_query_column_name=>'DESCRIPCION'
,p_heading=>unistr('Descripci\00F3n')
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
,p_created_on=>wwv_flow_imp.dz('20250106203840Z')
,p_updated_on=>wwv_flow_imp.dz('20250106204353Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(557718040959153842)
,p_query_column_name=>'DESC_CORTA'
,p_heading=>'Desc. Corta'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
,p_is_visible=>'N'
,p_created_on=>wwv_flow_imp.dz('20250106203840Z')
,p_updated_on=>wwv_flow_imp.dz('20250106204353Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(557718436048153842)
,p_query_column_name=>'CODIGOPAIS'
,p_heading=>unistr('Pa\00EDs')
,p_display_sequence=>40
,p_data_type=>'VARCHAR2'
,p_created_on=>wwv_flow_imp.dz('20250106203840Z')
,p_updated_on=>wwv_flow_imp.dz('20250106204353Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(557718847585153842)
,p_query_column_name=>'MONEDA'
,p_heading=>'Moneda'
,p_display_sequence=>50
,p_data_type=>'VARCHAR2'
,p_is_visible=>'N'
,p_created_on=>wwv_flow_imp.dz('20250106203840Z')
,p_updated_on=>wwv_flow_imp.dz('20250106204353Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
