prompt --application/shared_components/user_interface/lovs/lov_neg_codigoesq
begin
--   Manifest
--     LOV_NEG_CODIGOESQ
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(135034190509484151)
,p_lov_name=>'LOV_NEG_CODIGOESQ'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select D descripcion,R codigo from (',
'with prd as (',
'SELECT   CODIGOPRODUCTO || '' - '' ||  NOMBREPRODUCTO || '' ''|| CODIGOALTERNO  || '' - ['' ||  UNIDADCOMPRA || '']'' d  ,CODIGOCORTO r,  ''PD'' tipo FROM vt_jde_productos WHERE  CODESTADO<>''O'' GROUP BY  CODIGOPRODUCTO || '' - '' ||  NOMBREPRODUCTO || '' ''|| CODI'
||'GOALTERNO     || '' - ['' ||  UNIDADCOMPRA || '']''  ,CODIGOCORTO ,NOMBREPRODUCTO order by NOMBREPRODUCTO ',
'),',
'prv as (',
'SELECT   CODIGOPROVEEDOR || '' - '' ||  DESCRIPCION d, CODIGOPROVEEDOR r,  ''PV'' FROM  VT_JDE_MAESTROPROVEEDOR GROUP BY CODIGOPROVEEDOR || '' - '' ||  DESCRIPCION , CODIGOPROVEEDOR , DESCRIPCION ORDER BY DESCRIPCION',
')',
' select d,r from prd union all',
' select d,r from prv',
' )'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
