prompt --application/shared_components/user_interface/lovs/lov_jde_proveedores
begin
--   Manifest
--     LOV_JDE_PROVEEDORES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(185688337882482745)
,p_lov_name=>'LOV_JDE_PROVEEDORES'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'	TRIM(ABALPH) AS DESCRIPCION,',
'	TRIM(ABTAX) AS IDENTIFICACION,',
'	ABAN8  AS CODIGO',
'FROM f0101@jdedtadl',
'ORDER BY ABALPH'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'CODIGO'
,p_display_column_name=>'DESCRIPCION'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>111315654542
,p_updated_on=>wwv_flow_imp.dz('20250529173259Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(192081081016950591)
,p_query_column_name=>'CODIGO'
,p_heading=>unistr('C\00F3digo')
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_updated_on=>wwv_flow_imp.dz('20250529173259Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(192081406887950592)
,p_query_column_name=>'DESCRIPCION'
,p_heading=>unistr('Descripci\00F3n')
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
,p_updated_on=>wwv_flow_imp.dz('20250529173259Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(192081815656950592)
,p_query_column_name=>'IDENTIFICACION'
,p_heading=>unistr('Identificaci\00F3n')
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
,p_updated_on=>wwv_flow_imp.dz('20250529173259Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
