prompt --application/shared_components/user_interface/lovs/lov_pre_usuario_un
begin
--   Manifest
--     LOV_PRE_USUARIO_UN
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(114160610899915627)
,p_lov_name=>'LOV_PRE_USUARIO_UN'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CODERP,NOMBREUSUARIO,  APELLIDOS||''''||NOMBRES NOMBRES, EMAIL, CODCENTROCOSTO, CENTROCOSTO',
'from vt_corp_usuario',
'where lpad(CODCENTROCOSTO,12,'' '')=:P_UNIDADNEGOCIO',
'AND ESTADO= 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'NOMBREUSUARIO'
,p_display_column_name=>'NOMBREUSUARIO'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'NOMBREUSUARIO'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(114161264334922643)
,p_query_column_name=>'NOMBREUSUARIO'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(114161637320922644)
,p_query_column_name=>'CODERP'
,p_heading=>'Coderp'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(114162071792922644)
,p_query_column_name=>'NOMBRES'
,p_heading=>'Nombres'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(114162481455922644)
,p_query_column_name=>'EMAIL'
,p_heading=>'Email'
,p_display_sequence=>40
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
