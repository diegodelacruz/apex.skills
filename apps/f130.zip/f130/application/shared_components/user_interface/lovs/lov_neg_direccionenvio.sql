prompt --application/shared_components/user_interface/lovs/lov_neg_direccionenvio
begin
--   Manifest
--     LOV_NEG_DIRECCIONENVIO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(314400268386167334)
,p_lov_name=>'LOV_NEG_DIRECCIONENVIO'
,p_lov_query=>'select aban8 coddireccion, trim(abalph) nombre, trim(abmcu) unidadnegocio from f0101@jdedtadl where abat1 = ''UN '''
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'CODDIRECCION'
,p_display_column_name=>'NOMBRE'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'NOMBRE'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
,p_created_on=>wwv_flow_imp.dz('20240513175504Z')
,p_updated_on=>wwv_flow_imp.dz('20240513175608Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(314402792317173749)
,p_query_column_name=>'CODDIRECCION'
,p_heading=>unistr('C\00F3d. Direcci\00F3n')
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_created_on=>wwv_flow_imp.dz('20240513175608Z')
,p_updated_on=>wwv_flow_imp.dz('20240513175608Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(314403165553173750)
,p_query_column_name=>'NOMBRE'
,p_heading=>'Nombre'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
,p_created_on=>wwv_flow_imp.dz('20240513175608Z')
,p_updated_on=>wwv_flow_imp.dz('20240513175608Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(314403567851173750)
,p_query_column_name=>'UNIDADNEGOCIO'
,p_heading=>'Unidad Negocio'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
,p_created_on=>wwv_flow_imp.dz('20240513175608Z')
,p_updated_on=>wwv_flow_imp.dz('20240513175608Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
