prompt --application/shared_components/user_interface/lovs/lov_jde_bodegas
begin
--   Manifest
--     LOV_JDE_BODEGAS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(102052470684402594)
,p_lov_name=>'LOV_JDE_BODEGAS'
,p_lov_query=>'SELECT CODUNIDAD||'' - ''||DESCRIPCION BODEGA, CODUNIDAD AS CODBODEGA from VT_JDE_BODEGAS;'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'VT_JDE_BODEGAS'
,p_return_column_name=>'CODBODEGA'
,p_display_column_name=>'BODEGA'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'BODEGA'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
