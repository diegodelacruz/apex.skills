prompt --application/shared_components/user_interface/lovs/lov_udc_56_tp_rubros
begin
--   Manifest
--     LOV_UDC_56_TP_RUBROS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(93018914532751121)
,p_lov_name=>'LOV_UDC_56_TP_RUBROS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select TRIM(DRKY) || '' - ''  || DRDL01 as d,',
'       TRIM(DRKY) as r',
'  from VT_JDE_UDCJDE',
'      WHERE DRSY = ''56''',
'      AND DRRT = ''TP''',
'      ORDER  BY 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
