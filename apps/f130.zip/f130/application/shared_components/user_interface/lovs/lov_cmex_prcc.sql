prompt --application/shared_components/user_interface/lovs/lov_cmex_prcc
begin
--   Manifest
--     LOV_CMEX_PRCC
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(9315598798158513)
,p_lov_name=>'LOV_CMEX_PRCC'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ID_TABLA||'' - ''||VALOR AS VALOR, ',
'    ID_TABLA',
'FROM',
'T_CORP_UDC WHERE ID_CABECERA=''CMEX_PRCC'' ORDER BY VALOR'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID_TABLA'
,p_display_column_name=>'VALOR'
,p_version_scn=>110345816707
,p_created_on=>wwv_flow_imp.dz('20250430212700Z')
,p_updated_on=>wwv_flow_imp.dz('20250430212700Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
