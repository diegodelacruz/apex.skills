prompt --application/shared_components/user_interface/lovs/lov_cmex_export_tipo_documento
begin
--   Manifest
--     LOV_CMEX_EXPORT_TIPO_DOCUMENTO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(330268175056330773)
,p_lov_name=>'LOV_CMEX_EXPORT_TIPO_DOCUMENTO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    ID_TABLA AS NAME,',
'    VALOR    AS CODE',
'FROM',
'    T_CORP_UDC ',
'WHERE',
'    ID_CABECERA = ''CMEX_TP_AR''',
';'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'CODE'
,p_display_column_name=>'NAME'
,p_default_sort_column_name=>'NAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
