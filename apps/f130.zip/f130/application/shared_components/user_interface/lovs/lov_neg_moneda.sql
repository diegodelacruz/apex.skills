prompt --application/shared_components/user_interface/lovs/lov_neg_moneda
begin
--   Manifest
--     LOV_NEG_MONEDA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(44765112142102561)
,p_lov_name=>'LOV_NEG_MONEDA'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRKY||'' - ''||DRDL01 DESCRIPCION, DRKY VALOR',
'from vt_jde_udcjde',
'where drsy = ''74R''and drrt = ''CR'' and drky in (''EUR'',''USD'',''BOB'',''DOP'',''PEN'',''QTZ'')'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'VALOR'
,p_display_column_name=>'DESCRIPCION'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
,p_updated_on=>wwv_flow_imp.dz('20250212215622Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
