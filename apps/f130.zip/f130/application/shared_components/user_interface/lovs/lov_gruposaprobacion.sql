prompt --application/shared_components/user_interface/lovs/lov_gruposaprobacion
begin
--   Manifest
--     LOV_GRUPOSAPROBACION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(145543636457534087)
,p_lov_name=>'LOV_GRUPOSAPROBACION'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id_tabla, descripcion',
'from data.t_corp_udc',
'where id_cabecera = ''COMP_GRAPR'' and valor = ''COMP'' and activo = ''1'' order by id_tabla'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID_TABLA'
,p_display_column_name=>'DESCRIPCION'
,p_version_scn=>114168423068
,p_created_on=>wwv_flow_imp.dz('20250819170922Z')
,p_updated_on=>wwv_flow_imp.dz('20250819170922Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
