prompt --application/shared_components/user_interface/lovs/lov_neg_bodegarecepcion
begin
--   Manifest
--     LOV_NEG_BODEGARECEPCION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(314367888586033042)
,p_lov_name=>'LOV_NEG_BODEGARECEPCION'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trim(cimcu) cimcu,trim(ciartg) ciartg, cian8 from f41001@jdedtadl',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'CIMCU'
,p_display_column_name=>'CIMCU'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'CIMCU'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
,p_created_on=>wwv_flow_imp.dz('20240513173242Z')
,p_updated_on=>wwv_flow_imp.dz('20240513175633Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(314370587476039732)
,p_query_column_name=>'CIMCU'
,p_heading=>'Unidad Negocio'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
,p_created_on=>wwv_flow_imp.dz('20240513173348Z')
,p_updated_on=>wwv_flow_imp.dz('20240513175633Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(314370964872039735)
,p_query_column_name=>'CIARTG'
,p_heading=>unistr('Ruta de Aprobaci\00F3n')
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
,p_created_on=>wwv_flow_imp.dz('20240513173348Z')
,p_updated_on=>wwv_flow_imp.dz('20240513175633Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(314371331787039735)
,p_query_column_name=>'CIAN8'
,p_heading=>unistr('Dir. Env\00EDo')
,p_display_sequence=>30
,p_data_type=>'NUMBER'
,p_created_on=>wwv_flow_imp.dz('20240513173348Z')
,p_updated_on=>wwv_flow_imp.dz('20240513175633Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
