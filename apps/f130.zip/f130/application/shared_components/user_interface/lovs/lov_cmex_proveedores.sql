prompt --application/shared_components/user_interface/lovs/lov_cmex_proveedores
begin
--   Manifest
--     LOV_CMEX_PROVEEDORES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(165398581949586903)
,p_lov_name=>'LOV_CMEX_PROVEEDORES'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CODIGOJDE ||'' - ''||RAZONSOCIAL D, CODIGOJDE R',
'FROM VT_COMP_JDEPROVEEDOR',
'UNION',
'SELECT CAST(''99999 - OTROS'' AS NCHAR(40)) D, 99999 R',
'FROM DUAL;      '))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'D'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
,p_updated_on=>wwv_flow_imp.dz('20240611150706Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp.component_end;
end;
/
