prompt --application/shared_components/user_interface/lovs/lov_cmex_booking
begin
--   Manifest
--     LOV_CMEX_BOOKING
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(306664015441949785)
,p_lov_name=>'LOV_CMEX_BOOKING'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    ID,',
'    NUMERO_BK,',
'    cliente_nombres,',
'    trunc(fecha_plan_cargue) fecha_plan_cargue,',
'	pedidos',
'from data.vt_cmex_booking_mesa_trabajo',
'where 1 = 1',
'	and estado = ''COMPLETADO'''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'ID'
,p_display_column_name=>'NUMERO_BK'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'NUMERO_BK'
,p_default_sort_direction=>'DESC'
,p_version_scn=>110379786271
,p_updated_on=>wwv_flow_imp.dz('20250501205908Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(10853843282631350)
,p_query_column_name=>'PEDIDOS'
,p_heading=>'Pedidos'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
,p_created_on=>wwv_flow_imp.dz('20250501205908Z')
,p_updated_on=>wwv_flow_imp.dz('20250501205908Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(306664806596963165)
,p_query_column_name=>'ID'
,p_display_sequence=>10
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
,p_updated_on=>wwv_flow_imp.dz('20250501205908Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(306665211606963166)
,p_query_column_name=>'NUMERO_BK'
,p_heading=>'Booking'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
,p_updated_on=>wwv_flow_imp.dz('20250501205908Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(306665618613963166)
,p_query_column_name=>'CLIENTE_NOMBRES'
,p_heading=>'Cliente'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
,p_updated_on=>wwv_flow_imp.dz('20250501205908Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(306666023439963166)
,p_query_column_name=>'FECHA_PLAN_CARGUE'
,p_heading=>'Plan Cargue'
,p_display_sequence=>40
,p_data_type=>'DATE'
,p_updated_on=>wwv_flow_imp.dz('20250501205908Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
