prompt --application/shared_components/user_interface/lovs/lov_cmex_proveedores2
begin
--   Manifest
--     LOV_CMEX_PROVEEDORES2
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(345852374077232285)
,p_lov_name=>'LOV_CMEX_PROVEEDORES2'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DISTINCT codigo||'' - ''||nombres as r,',
'       codigo as d',
'  from VT_JDE_LIBRODIRECCIONES',
'  where codigo<>99999',
' ',
'UNION',
'SELECT CAST(''99999 - OTROS'' AS NCHAR(40)) D, 99999 R',
'FROM DUAL',
'ORDER BY 1'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'D'
,p_display_column_name=>'R'
,p_version_scn=>1
,p_created_on=>wwv_flow_imp.dz('20240612211307Z')
,p_updated_on=>wwv_flow_imp.dz('20240612211307Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp.component_end;
end;
/
