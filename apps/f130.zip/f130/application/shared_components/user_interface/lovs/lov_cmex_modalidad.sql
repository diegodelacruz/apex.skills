prompt --application/shared_components/user_interface/lovs/lov_cmex_modalidad
begin
--   Manifest
--     LOV_CMEX_MODALIDAD
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(166958819380978655)
,p_lov_name=>'LOV_CMEX_MODALIDAD'
,p_lov_query=>'.'||wwv_flow_imp.id(166958819380978655)||'.'
,p_location=>'STATIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(166959101417978667)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'MARITIMO'
,p_lov_return_value=>'MARITIMO'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(166959557505978668)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'TERRESTRE'
,p_lov_return_value=>'TERRESTRE'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(166959914338978669)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'AEREO'
,p_lov_return_value=>'AEREO'
);
wwv_flow_imp.component_end;
end;
/
