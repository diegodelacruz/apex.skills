prompt --application/shared_components/user_interface/lovs/lov_cmex_patio_retiro
begin
--   Manifest
--     LOV_CMEX_PATIO_RETIRO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(366748229517141612)
,p_lov_name=>'LOV_CMEX_PATIO_RETIRO'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    DESCRIPCION AS NOMBRE,',
'    ID_TABLA    AS ID    ',
'FROM T_CORP_UDC',
'WHERE ID_CABECERA=''CMEX_BDGS''',
'ORDER BY DESCRIPCION',
';'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'ID'
,p_display_column_name=>'NOMBRE'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
