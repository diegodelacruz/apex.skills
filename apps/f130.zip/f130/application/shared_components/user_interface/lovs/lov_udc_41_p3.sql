prompt --application/shared_components/user_interface/lovs/lov_udc_41_p3
begin
--   Manifest
--     LOV_UDC_41_P3
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(379055203221162693)
,p_lov_name=>'LOV_UDC_41_P3'
,p_lov_query=>'select drky, drdl01 from data.vt_jde_udcjde where drsy = ''41'' and drrt = ''P3'' order by drky'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'DRKY'
,p_display_column_name=>'DRDL01'
,p_version_scn=>121969039698
,p_created_on=>wwv_flow_imp.dz('20260305141432Z')
,p_updated_on=>wwv_flow_imp.dz('20260305141432Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
