prompt --application/shared_components/user_interface/lovs/lov_jde_librodirecciones
begin
--   Manifest
--     LOV_JDE_LIBRODIRECCIONES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(41703476241628470)
,p_lov_name=>'LOV_JDE_LIBRODIRECCIONES'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DISTINCT nombres as r,',
'       codigo as d',
'  from VT_JDE_LIBRODIRECCIONES',
' order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
