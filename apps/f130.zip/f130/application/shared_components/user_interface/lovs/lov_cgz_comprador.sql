prompt --application/shared_components/user_interface/lovs/lov_cgz_comprador
begin
--   Manifest
--     LOV_CGZ_COMPRADOR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(557531657046385304)
,p_lov_name=>'LOV_CGZ_COMPRADOR'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION2 D,VALOR R',
'FROM T_CORP_UDC',
'WHERE ID_CABECERA=''COMP_CGZ00''',
'AND ID_TABLA<>''*''',
'ORDER BY 1;'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>1
,p_created_on=>wwv_flow_imp.dz('20250106183034Z')
,p_updated_on=>wwv_flow_imp.dz('20250106183034Z')
,p_created_by=>'MALBAN'
,p_updated_by=>'MALBAN'
);
wwv_flow_imp.component_end;
end;
/
