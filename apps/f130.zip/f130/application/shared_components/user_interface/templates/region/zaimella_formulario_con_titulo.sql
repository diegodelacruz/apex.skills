prompt --application/shared_components/user_interface/templates/region/zaimella_formulario_con_titulo
begin
--   Manifest
--     REGION TEMPLATE: ZAIMELLA_FORMULARIO_CON_TITULO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_plug_template(
 p_id=>wwv_flow_imp.id(296120252599169164)
,p_layout=>'TABLE'
,p_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="#REGION_STATIC_ID#" #REGION_ATTRIBUTES# class="#REGION_CSS_CLASSES# formulario"> ',
'    <div class="t-Region-header">',
'      <div class="t-Region-headerItems t-Region-headerItems--title">',
'        <h2 class="t-Region-title" id="#REGION_STATIC_ID#_heading">#TITLE#</h2>',
'      </div>        ',
'    </div>    ',
'#PREVIOUS##BODY##SUB_REGIONS##NEXT#',
'</div>',
'',
''))
,p_page_plug_template_name=>'Zaimella Formulario con titulo'
,p_internal_name=>'ZAIMELLA_FORMULARIO_CON_TITULO'
,p_theme_id=>42
,p_theme_class_id=>7
,p_preset_template_options=>'t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_default_label_alignment=>'RIGHT'
,p_default_field_alignment=>'LEFT'
,p_reference_id=>92870912127290114
,p_translate_this_template=>'N'
);
wwv_flow_imp_shared.create_plug_tmpl_display_point(
 p_id=>wwv_flow_imp.id(19388664984929692)
,p_plug_template_id=>wwv_flow_imp.id(296120252599169164)
,p_name=>'Region Body'
,p_placeholder=>'BODY'
,p_has_grid_support=>true
,p_has_region_support=>true
,p_has_item_support=>true
,p_has_button_support=>true
,p_glv_new_row=>true
);
wwv_flow_imp_shared.create_plug_tmpl_display_point(
 p_id=>wwv_flow_imp.id(19388726601929692)
,p_plug_template_id=>wwv_flow_imp.id(296120252599169164)
,p_name=>'Sub Regions'
,p_placeholder=>'SUB_REGIONS'
,p_has_grid_support=>true
,p_has_region_support=>true
,p_has_item_support=>false
,p_has_button_support=>false
,p_glv_new_row=>true
);
wwv_flow_imp_shared.create_plug_tmpl_display_point(
 p_id=>wwv_flow_imp.id(19388820719929692)
,p_plug_template_id=>wwv_flow_imp.id(296120252599169164)
,p_name=>'Next'
,p_placeholder=>'NEXT'
,p_has_grid_support=>false
,p_has_region_support=>false
,p_has_item_support=>false
,p_has_button_support=>true
,p_glv_new_row=>true
);
wwv_flow_imp_shared.create_plug_tmpl_display_point(
 p_id=>wwv_flow_imp.id(19388927980929692)
,p_plug_template_id=>wwv_flow_imp.id(296120252599169164)
,p_name=>'Previous'
,p_placeholder=>'PREVIOUS'
,p_has_grid_support=>false
,p_has_region_support=>false
,p_has_item_support=>false
,p_has_button_support=>true
,p_glv_new_row=>true
);
wwv_flow_imp.component_end;
end;
/
