prompt --application/shared_components/navigation/lists/zaimella_menu
begin
--   Manifest
--     LIST: Zaimella Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(296238011144396279)
,p_name=>'Zaimella Menu'
,p_list_type=>'SQL_QUERY'
,p_list_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 NIVEL, (SELECT DESCRIPCION FROM T_ADMI_COMPANIA WHERE CODIGO=:G_COMPANIA) LABEL, ''#'' TARGET, '''' IS_CURRENT, ''-'' ICONOCSS from dual ',
'union all',
'select * from (SELECT NIVEL, OPCIONMENU label, ',
'      DECODE(RUTAPAGINA ,NULL,''#'',RUTA||'':''||:APP_SESSION||''::NO:RP,''||RUTAPAGINA) target,',
'       NULL is_current, ''fa''||'' ''||iconocss',
'FROM (SELECT DISTINCT NIVEL, OPCIONMENU , RUTAPAGINA ,RUTA, iconocss, CODIGOPAGINA,codigopadre, ORDEN',
'from DATA.VT_CORP_PAGINAS WHERE  CODIGOUSUARIO=:APP_USER AND GRUPO=''APEX'' AND OBJETO IS NULL AND ',
'CODIGO_TG IS NULL AND  CODIGOCOMPANIA=:G_COMPANIA)',
'  START WITH codigopadre is null',
'       CONNECT BY PRIOR CODIGOPAGINA=codigopadre  ',
'          -- and PRIOR CODIGOUSUARIO=:APP_USER AND ',
'-- PRIOR CODIGOCOMPANIA=:G_COMPANIA AND ',
'--PRIOR GRUPO=''APEX''',
'--AND PRIOR OBJETO IS NULL AND PRIOR  CODIGO_TG IS NULL',
'ORDER SIBLINGS BY ORDEN);'))
,p_list_status=>'PUBLIC'
,p_version_scn=>123485191141
,p_updated_on=>wwv_flow_imp.dz('20260409203109Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(54301695130821691)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('Seguimiento Aprobaci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:110:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'110'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(63581352898783728)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Negociaciones - Indices de calculo de precios'
,p_list_item_link_target=>'f?p=&APP_ID.:141:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-layout-header-sidebar-left'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'141,147'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(85915954181640554)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Generar OCs'
,p_list_item_link_target=>'f?p=&APP_ID.:201:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'201'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(85962226004460298)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'dlgDetalleRequision'
,p_list_item_link_target=>'f?p=&APP_ID.:202:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'202'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(88333249899760583)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'dlgSeleccionaProveedor'
,p_list_item_link_target=>'f?p=&APP_ID.:203:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'203'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(119133620142871889)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Mesa de Trabajo OCs'
,p_list_item_link_target=>'f?p=&APP_ID.:200:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'200'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(124522265540583994)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'dlgCambiaFecha'
,p_list_item_link_target=>'f?p=&APP_ID.:207:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'207'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(140175806596021488)
,p_list_item_display_sequence=>90
,p_list_item_link_text=>unistr('Correcci\00F3n Descripci\00F3n OC')
,p_list_item_link_target=>'f?p=&APP_ID.:111:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'111'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(164041140792579010)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>unistr('Importaci\00F3n de Muestras')
,p_list_item_link_target=>'f?p=&APP_ID.:231:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'231'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(164162333608432092)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>unistr('Importaci\00F3n Muestras')
,p_list_item_link_target=>'f?p=&APP_ID.:232:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-layout-header-sidebar-left'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'232,13'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(170970460765253573)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>unistr('Detalle Aprobaci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:234:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'234'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(172361461459475583)
,p_list_item_display_sequence=>130
,p_list_item_link_text=>'Etapas Importacion Muestras'
,p_list_item_link_target=>'f?p=&APP_ID.:235:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'235'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(173187217982366819)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Tipo de Muestra'
,p_list_item_link_target=>'f?p=&APP_ID.:236:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'236'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(177451983988191265)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Conceptos Liquidaci+on'
,p_list_item_link_target=>'f?p=&APP_ID.:400:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-table-pointer'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'400'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(181839693546723664)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>unistr('Estado Importaci\00F3n Muestras')
,p_list_item_link_target=>'f?p=&APP_ID.:240:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'240'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(182392149582477155)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>unistr('Liquidaci\00F3n Costos Muestras')
,p_list_item_link_target=>'f?p=&APP_ID.:241:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'241'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(182699998997165313)
,p_list_item_display_sequence=>180
,p_list_item_link_text=>unistr('Revisi\00F3n Flete')
,p_list_item_link_target=>'f?p=&APP_ID.:242:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'242'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(190509970226800115)
,p_list_item_display_sequence=>190
,p_list_item_link_text=>'GenerarOC'
,p_list_item_link_target=>'f?p=&APP_ID.:211:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'211'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(203227649427798178)
,p_list_item_display_sequence=>200
,p_list_item_link_text=>unistr('Aprobaci\00F3n Pago Recurrente')
,p_list_item_link_target=>'f?p=&APP_ID.:112:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'112'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(272252525096749153)
,p_list_item_display_sequence=>210
,p_list_item_link_text=>'Booking Mesa de trabajo'
,p_list_item_link_target=>'f?p=&APP_ID.:500:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'500'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(288017811762035533)
,p_list_item_display_sequence=>220
,p_list_item_link_text=>'COMEX - Booking'
,p_list_item_link_target=>'f?p=&APP_ID.:501:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'501'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(295235945850199580)
,p_list_item_display_sequence=>230
,p_list_item_link_text=>'CMEX - dlg Anular/Rolear'
,p_list_item_link_target=>'f?p=&APP_ID.:502:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'502'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(295743258850013853)
,p_list_item_display_sequence=>240
,p_list_item_link_text=>'CMEX - dlg Hisrtoria'
,p_list_item_link_target=>'f?p=&APP_ID.:503:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'503'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(305636312325032482)
,p_list_item_display_sequence=>250
,p_list_item_link_text=>'COMEX - Documentos mesa de trabajo'
,p_list_item_link_target=>'f?p=&APP_ID.:510:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'510'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(305647006914091717)
,p_list_item_display_sequence=>260
,p_list_item_link_text=>unistr('COMEX - Datos Gesti\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:511:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'511'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(308246288682320386)
,p_list_item_display_sequence=>270
,p_list_item_link_text=>unistr('CMEX - Datos Gesti\00F3n Detalle')
,p_list_item_link_target=>'f?p=&APP_ID.:512:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'512'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(312465880999187278)
,p_list_item_display_sequence=>280
,p_list_item_link_text=>'CMEX - dlg Nuevo Contenedor'
,p_list_item_link_target=>'f?p=&APP_ID.:514:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'514'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(326299890436385967)
,p_list_item_display_sequence=>290
,p_list_item_link_text=>unistr('COMEX - Exportaci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:521:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'521'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(343095582560052169)
,p_list_item_display_sequence=>300
,p_list_item_link_text=>'COMEX - Verificadora'
,p_list_item_link_target=>'f?p=&APP_ID.:525:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'525'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(352569247187844450)
,p_list_item_display_sequence=>310
,p_list_item_link_text=>'COMEX - dlgDetallesVerificadora'
,p_list_item_link_target=>'f?p=&APP_ID.:526:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'526'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(555325375592827071)
,p_list_item_display_sequence=>320
,p_list_item_link_text=>'Maestro de Proveedores'
,p_list_item_link_target=>'f?p=&APP_ID.:213:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-file-o'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'213'
,p_created_on=>wwv_flow_imp.dz('20250101033732Z')
,p_updated_on=>wwv_flow_imp.dz('20250101033732Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(657932930858964393)
,p_list_item_display_sequence=>330
,p_list_item_link_text=>unistr('Proveedor - Categor\00EDas')
,p_list_item_link_target=>'f?p=&APP_ID.:260:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-forms'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'260'
,p_created_on=>wwv_flow_imp.dz('20250331155438Z')
,p_updated_on=>wwv_flow_imp.dz('20250331155438Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(677634411041886653)
,p_list_item_display_sequence=>340
,p_list_item_link_text=>unistr('Proveedor - Configuraci\00F3n')
,p_list_item_link_target=>'f?p=&APP_ID.:261:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-forms'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'261'
,p_created_on=>wwv_flow_imp.dz('20250417160141Z')
,p_updated_on=>wwv_flow_imp.dz('20250417160141Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
