prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(295583779177037631)
,p_name=>'Breadcrumb'
,p_updated_on=>wwv_flow_imp.dz('20260409203109Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(54302541073821720)
,p_short_name=>unistr('Seguimiento Aprobaci\00F3n')
,p_link=>'f?p=&APP_ID.:110:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>110
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(66411857654003316)
,p_short_name=>'Negociacion - Formulaciones'
,p_link=>'f?p=&APP_ID.:148:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>148
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(74196679976389444)
,p_short_name=>'Formulario Detalles Contenedores IO'
,p_link=>'f?p=&APP_ID.:153:&SESSION.'
,p_page_id=>153
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(85916839580640555)
,p_short_name=>'Generar OCs'
,p_link=>'f?p=&APP_ID.:201:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>201
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(85963153667460306)
,p_short_name=>'dlgDetalleRequision'
,p_link=>'f?p=&APP_ID.:202:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>202
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(88334004787760638)
,p_short_name=>'dlgSeleccionaProveedor'
,p_link=>'f?p=&APP_ID.:203:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>203
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(119134528974871903)
,p_short_name=>'Mesa de Trabajo OCs'
,p_link=>'f?p=&APP_ID.:200:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>200
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(124523142930584006)
,p_short_name=>'dlgCambiaFecha'
,p_link=>'f?p=&APP_ID.:207:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>207
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(140176657830021503)
,p_short_name=>unistr('Correcci\00F3n Descripci\00F3n OC')
,p_link=>'f?p=&APP_ID.:111:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>111
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(164170374442432111)
,p_short_name=>unistr('Importaci\00F3n Muestras')
,p_link=>'f?p=&APP_ID.:232:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>232
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(170971343517253577)
,p_short_name=>unistr('Detalle Aprobaci\00F3n')
,p_link=>'f?p=&APP_ID.:234:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>234
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(172362303363475597)
,p_short_name=>'Etapas Importacion Muestras'
,p_link=>'f?p=&APP_ID.:235:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>235
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(173188177223366824)
,p_short_name=>'Tipo de Muestra'
,p_link=>'f?p=&APP_ID.:236:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>236
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(177452839287191265)
,p_short_name=>'Conceptos Liquidaci+on'
,p_link=>'f?p=&APP_ID.:400:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>400
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(181840538072723679)
,p_short_name=>unistr('Estado Importaci\00F3n Muestras')
,p_link=>'f?p=&APP_ID.:240:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>240
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(182393039915477171)
,p_short_name=>unistr('Liquidaci\00F3n Costos Muestras')
,p_link=>'f?p=&APP_ID.:241:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>241
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(182700728422165326)
,p_short_name=>unistr('Revisi\00F3n Flete')
,p_link=>'f?p=&APP_ID.:242:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>242
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(190510866489800126)
,p_short_name=>'GenerarOC'
,p_link=>'f?p=&APP_ID.:211:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>211
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(203228499038798193)
,p_short_name=>unistr('Aprobaci\00F3n Pago Recurrente')
,p_link=>'f?p=&APP_ID.:112:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>112
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(272253437507749166)
,p_short_name=>'Booking Mesa de trabajo'
,p_link=>'f?p=&APP_ID.:500:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>500
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(288018721954035546)
,p_short_name=>'COMEX - Booking'
,p_link=>'f?p=&APP_ID.:501:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>501
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(295236881974199604)
,p_short_name=>'CMEX - dlg Anular/Rolear'
,p_link=>'f?p=&APP_ID.:502:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>502
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(295583912064037632)
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.'
,p_page_id=>1
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(295744108828013893)
,p_short_name=>'CMEX - dlg Hisrtoria'
,p_link=>'f?p=&APP_ID.:503:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>503
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(305637218074032495)
,p_short_name=>'COMEX - Documentos mesa de trabajo'
,p_link=>'f?p=&APP_ID.:510:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>510
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(305647905469091721)
,p_short_name=>unistr('COMEX - Datos Gesti\00F3n')
,p_link=>'f?p=&APP_ID.:511:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>511
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(308247120548320397)
,p_short_name=>unistr('CMEX - Datos Gesti\00F3n Detalle')
,p_link=>'f?p=&APP_ID.:512:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>512
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(312466742381187298)
,p_short_name=>'CMEX - dlg Nuevo Contenedor'
,p_link=>'f?p=&APP_ID.:514:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>514
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(326289728207228833)
,p_short_name=>'COMEX - Exportaci&#xF3;n Mesa de trabajo'
,p_link=>'f?p=&APP_ID.:520:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>520
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(326300764661385980)
,p_short_name=>unistr('COMEX - Exportaci\00F3n')
,p_link=>'f?p=&APP_ID.:521:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>521
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(343096473393052182)
,p_short_name=>'COMEX - Verificadora'
,p_link=>'f?p=&APP_ID.:525:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>525
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(352570155127844473)
,p_short_name=>'COMEX - dlgDetallesVerificadora'
,p_link=>'f?p=&APP_ID.:526:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>526
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(400709513146215445)
,p_short_name=>'Mesa de trabajo GrupoZML'
,p_link=>'f?p=&APP_ID.:600:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>600
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(400792015365849228)
,p_short_name=>'Cabecera Compra'
,p_link=>'f?p=&APP_ID.:605:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>605
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(657933774078964417)
,p_short_name=>unistr('Proveedor - Categor\00EDas')
,p_link=>'f?p=&APP_ID.:260:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>260
,p_created_on=>wwv_flow_imp.dz('20250331155439Z')
,p_updated_on=>wwv_flow_imp.dz('20250331155439Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(677635349831886664)
,p_short_name=>unistr('Proveedor - Configuraci\00F3n')
,p_link=>'f?p=&APP_ID.:261:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>261
,p_created_on=>wwv_flow_imp.dz('20250417160141Z')
,p_updated_on=>wwv_flow_imp.dz('20250417160141Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
