prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 130
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>130
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(292239115698721921)
,p_created_on=>wwv_flow_imp.dz('20240422204050Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240422204050Z')
,p_created_by=>'MALBAN'
,p_last_updated_by=>'MALBAN'
);
wwv_flow_imp.component_end;
end;
/
