
function mensaje(Type,Msg){
    var findSpan = $('#APEX_SUCCESS_MESSAGE').length;
    if (findSpan == 1){
        $('#APEX_SUCCESS_MESSAGE').remove();

        // Re-Run
        mensaje(Type,Msg);
    } else{
            // Adding HTML code!
            $('body').prepend(
                '<span id="APEX_SUCCESS_MESSAGE" class="apex-page-success"><div class="t-Body-alert">'
                + '<div class="t-Alert t-Alert--defaultIcons t-Alert--success t-Alert--horizontal t-Alert--page t-Alert--colorBG" '
                + 'id="t_Alert_Success" role="alert" style="display: none;"><div class="t-Alert-wrap"><div class="t-Alert-icon">'
                + '<span style="color: white; font-size: 25px;" class="fa fa-check fa-xl fa-anim-flash"></span></div>'
                + '<div class="t-Alert-content"><div class="t-Alert-header"><h2 class="t-Alert-title">'
                + Msg
                + '</h2></div></div><div class="t-Alert-buttons"><button class="t-Button t-Button--noUI t-Button--icon t-Button--closeAlert" '
                + 'type="button" title="Close Notification"><span class="t-Icon icon-close"></span></button></div></div></div></div></span>');

                $('#t_Alert_Success > div > div.t-Alert-buttons > button[title="Close Notification"]')
                    .on('click',function(){
                    $('#APEX_SUCCESS_MESSAGE').remove();
                });

            if(Type=='exito'){
                $.when(
                    // Auto close success message
                    $('#t_Alert_Success').show(),
                    $('#t_Alert_Success').fadeIn(300).delay(2000).fadeOut(400)
                ).then(
                        function(){
                            $('#APEX_SUCCESS_MESSAGE').remove();
                        });

            }else if(Type=='error'){
                    // Set error style ...
                    $('#t_Alert_Success').attr('style','background-color: #e95b54;');
                    $('#t_Alert_Success div div.t-Alert-icon span').removeClass('fa-check');
                    $('#t_Alert_Success div div.t-Alert-icon span').addClass('fa-close');
                    $('#t_Alert_Success').show();
            }       
    }
}

function mensajeExito(Msg){
	mensaje('exito',Msg);
}

function mensajeError(Msg){
	mensaje('error',Msg);
}
//FLUJO DE APROBACION
var restBuscarToken='http://pruebas.zaimella.com/FlujoAprobacion-WebService/rest/flujoAprobacion/buscarFlujoToken/';
var compania;
var modulo;
var usuario;
var objeto;
var objetoId;
var carga;


function buscarFlujoToken(detalle, token, resultado) {
	var url = restBuscarToken+detalle+'/'+token;
    console.log("buscarFlujoToken url: "+url);
    jQuery.ajax({
        type: "GET",
        url: url,
        
        dataType: "jsonp",
        success: function (data, status, jqXHR) {           
            resultado(data);
        },
        error: function (jqXHR, status) {
            resultado({
            "mensaje": "Error al buscar flujo con Token",
            "codigo": "0",
            "exito": false,
            "resultado": ""
			});
        }
    });
}

function buscarFlujoAprobacion(detalle, token, itemCompania, itemModulo, itemUsuario, itemObjeto, itemId){	
		buscarFlujoToken(detalle,token, function (trama) {		
		console.log("resultado: "+trama.exito);
		console.log("resultado: "+trama.resultado);
			if (trama.exito === true) {
				compania= trama.resultado.codCompania;
				modulo = trama.resultado.codModulo;
				usuario = trama.resultado.usuarioActual;
				objeto= trama.resultado.entidadClase;
				objetoId = trama.resultado.entidadId;	
				llenarItemFlujoAprobacion(itemCompania, itemModulo, itemUsuario, itemObjeto, itemId);		
				apex.server.process("CARGAR_DATOS", 
				{ x01: trama.resultado.codCompania, x02: trama.resultado.codModulo , x03: trama.resultado.usuarioActual,
					x04: trama.resultado.entidadClase, x05: trama.resultado.entidadId},
				   {
					  success: function(pData) {
						 console.log("process CARGAR_DATOS" + pData);
					  }
				   }
				);	
				mensaje('exito', 'Se genero con exito');				
			} else {					
				mensaje('error', trama.mensaje);   
				alert(trama.mensaje);				
			}
		});
}

function llenarItemFlujoAprobacion(itemCompania, itemModulo, itemUsuario, itemObjeto, itemId){
	console.log("llenarItemFlujoAprobacion "
	+itemCompania+": "+compania+" "
	+itemModulo+": "+modulo+" "+itemUsuario+": "+usuario+" "
	+itemObjeto+": "+objeto+" "+itemId+": "+objetoId+" "
	);
	apex.item(itemCompania).setValue(compania)
	apex.item(itemModulo).setValue(modulo)
	apex.item(itemUsuario).setValue(usuario)
	apex.item(itemObjeto).setValue(objeto)
	apex.item(itemId).setValue(objetoId)	
}

/*INTERACTIVE GRID 
function (config) {
 return cargarToolbar(config);
}
*/
function cargarToolbar(config) {
  
  config.toolbarData = [
        {
            groupTogether: true,
            controls: [
                {
                    type: "TEXT",
                    id: "search_field",
                    placeholder: "Buscar todos",
                    enterAction: "search"
                }
             ]
        },
        {
            align: "end",
            controls: [
				{
                    type: "BUTTON",
                    action: "show-download-dialog",
                    title: "Descargar",
                    id:"btnDescargar",
                    label: " ",
                    icon:"fa fa-file-excel-o"
                },
                {
                    type: "BUTTON",
                    action: "save",
                    title: "Guardar",
                    id:"btnGuardar",
                    label: " ",
                    icon:"fa fa-save"
                },
                {
                    type: "BUTTON",
                    action: "row-add-row",
                    title: "Agregar",
                    id:"btnAgregar",
                    label: " ",
                    icon:"fa fa-plus"
                },
                {
                    type: "BUTTON",
                    id:"btnEliminar",
                    action: "selection-delete",
                    title: "Eliminar",
                    label: " ",
                    icon:"fa fa-trash"
                }
                
            ]
        }
    ];
    
      config.initActions = function( actions ) {
        actions.remove("single-row-view");
        actions.remove("selection-refresh");
        actions.remove("selection-copy");
        actions.remove("selection-revert");
        actions.remove("selection-duplicate");
        actions.remove("row-refresh");
        actions.remove("row-revert");
        var selectionDelete = actions.lookup("selection-delete"),
            originalDeleteAction = selectionDelete.action; 
        var save = actions.lookup("save"), 
            originalSave = save.action;
         selectionDelete.action = function(_, el) {
             apex.message.confirm("¿Esta seguro de eliminar el registro?", function(ok) {
                 if (ok){
                    originalDeleteAction(_, el);
                    originalSave(_,el);
                 }
             });
        };
    };
    
    return config;
}


function moverToolbar() {
   $(".btnAccion").each(function () { 
		$(this).appendTo($(this).parent().parent().parent().find(".a-IG-header .a-Toolbar-groupContainer.a-Toolbar-groupContainer--end .a-Toolbar-group"));
	});
	
	$(".t-Region-headerItems.t-Region-headerItems--buttons").each(function () { 
		$(this).appendTo($(this).parent().parent().parent().find(".a-IRR-toolbar"));
	});
}

window.onload = function() {
 $('.apex-item-wrapper--rich-text-editor').find('br').remove();
};


var spinner;

function mostrarBarra(){
//	spinner = apex.util.showSpinner();	
	spinner = apex.widget.waitPopup();
}

function ocultarBarra(){
	spinner.remove();
}
