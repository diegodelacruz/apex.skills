prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 109
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(6852855897190625)
,p_last_updated_on=>wwv_flow_imp.dz('20230705164636Z')
);
wwv_flow_imp.component_end;
end;
/
