prompt --application/pages/page_00184
begin
--   Manifest
--     PAGE: 00184
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>184
,p_name=>'GESTION TRIBUTARIA - PARAMETRIZACION COLUMNAS'
,p_alias=>'GESTION-TRIBUTARIA-PARAMETRIZACION-COLUMNAS'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Configuraci\00F3n de Columnas')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(document).on("click", ".btn-subir, .btn-bajar", function () {',
'    mostrarBarra();',
'    var region = apex.region("rgColumnas"); // Static ID correcto',
'    var view = region.call("getCurrentView");',
'    var model = view.model;',
'    var $td = $(this).closest("td");',
'    var record = view.getContextRecord($td)[0];',
'',
'    if (!record){ ocultarBarra();return;}',
'    var ordenActual = Number(model.getValue(record, "ORDEN_VISUAL"));',
'    var seqActual   = model.getValue(record, "SEQ_ID");',
'    var direccion   = $(this).hasClass("btn-subir") ? -1 : 1;',
'',
'    // Reemplazo correcto del getRecords',
'    var allRecords = [];',
'    model.forEach(function(rec) {allRecords.push(rec);});',
'',
'    var index = allRecords.findIndex(r => model.getValue(r, "SEQ_ID") === seqActual);',
'',
'    var indexDestino = index + direccion;',
'    if (indexDestino < 0 || indexDestino >= allRecords.length){ ocultarBarra();return;}',
'',
'    var recordDestino = allRecords[indexDestino];',
'',
'    var seqDestino = model.getValue(recordDestino, "SEQ_ID");',
'',
'    f_llamarInterCambiarOrden(seqActual,seqDestino	).then((resultado) => {',
'        console.log("resultado:"+resultado);',
'        if(resultado=="OK"){',
'            region.refresh();',
'        }',
'    }).catch((error) => {',
'       console.log("Hubo un error: " + error);',
'    });',
'    ocultarBarra();',
'});',
'function f_llamarInterCambiarOrden (seqActual, seqDestino){',
'    var result = null;',
'    // Llamada al proceso en el servidor',
'',
'    return new Promise((resolve, reject) => {',
'        apex.server.process(',
'            ''INTERCAMBIAR_ORDEN'', // Nombre del proceso',
'            {',
'                x01:seqActual,',
'                x02:seqDestino,',
'            }, // variables del proceso',
'            {',
'                dataType: "json",',
'                success: function(pData)',
'                {',
'                    result = pData.result;',
'                    resolve(result);  // Resuelve la promesa con los datos del servidor',
'                }',
'                ,error: function(err) {',
'                    // Manejo de errores',
'                    console.error("Error INTERCAMBIAR_ORDEN:", err);',
'                        reject(err);  // Rechaza la promesa en caso de error',
'                }',
'            }',
'        );',
'    });',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(secItems).hide();',
'$(secMasivo).hide();',
'moverToolbar();'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.ui-dialog .ui-dialog-titlebar-close {',
'    position: absolute;',
'    right: 12px;',
'    top: 12px;',
'    width: 24px;',
'    margin: 0;',
'    padding: 0;',
'    height: 24px;',
'    border-radius: 100%;',
'    display: none;',
'}'))
,p_step_template=>wwv_flow_imp.id(37774372912106498)
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_dialog_height=>'Auto'
,p_protection_level=>'C'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(540590534107045007)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(540590888541045010)
,p_plug_name=>'Campos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(540591537363045017)
,p_plug_name=>'Columnas'
,p_region_name=>'rgColumnas'
,p_parent_plug_id=>wwv_flow_imp.id(540590888541045010)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'  SEQ_ID,',
'  C001,',
'  C002,',
'  C003,',
'  C004,',
'  C005,',
'  C006,',
'  nvl(C007,''N'')C007,',
'  nvl(C008,''N'')C008,',
'  to_number(C010)C010,',
'  decode(SEQ_ID,1,null,''subir'') subir,',
'  decode(SEQ_ID,max(seq_id)over(),null,''bajar'') bajar',
'  ',
'FROM APEX_COLLECTIONS ',
'WHERE COLLECTION_NAME = ''COLECCION_COLUMNAS''',
' '))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P184_MAYUSCULAS_SINO'
,p_plug_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_plug_read_only_when=>'P184_READONLY'
,p_plug_read_only_when2=>'1'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Columnas'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_plug_customized=>'1'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(34444829337782331)
,p_name=>'SUBIR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SUBIR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_LINK'
,p_heading=>'<span class="fa fa-chevron-circle-up"  title="Subir" aria-hidden="true">'
,p_label=>'Subir'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>110
,p_value_alignment=>'CENTER'
,p_link_target=>'javascript:void(0);'
,p_link_text=>'<span aria-hidden="true" class="fa fa-angle-double-up"></span>'
,p_link_attributes=>'class="btn-subir"'
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_include_in_export=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(34444951294782332)
,p_name=>'BAJAR'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'BAJAR'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_LINK'
,p_heading=>'<span class="fa fa-chevron-circle-down" title="Bajar" aria-hidden="true"></span>'
,p_label=>'Bajar'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>120
,p_value_alignment=>'CENTER'
,p_link_target=>'javascript:void(0);'
,p_link_text=>'<span aria-hidden="true" class="fa fa-angle-double-down"></span>'
,p_link_attributes=>'class="btn-bajar"'
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_include_in_export=>false
,p_escape_on_http_output=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(42164705178330508)
,p_name=>'C010'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C010'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'C010'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>130
,p_value_alignment=>'CENTER'
,p_attribute_03=>'left'
,p_attribute_04=>'decimal'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(42164824440330509)
,p_name=>'C005'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C005'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_SINGLE_CHECKBOX'
,p_heading=>'<span aria-hidden="true" title="Editable" class="fa fa-pencil-square-o"></span>'
,p_label=>'Editable'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>90
,p_value_alignment=>'CENTER'
,p_attribute_01=>'Y'
,p_is_required=>false
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'Y'
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(43067571769983323)
,p_name=>'C006'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C006'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_SINGLE_CHECKBOX'
,p_heading=>'<span aria-hidden="true" title="Qry Resultado" class="fa fa-file-sql-o"></span>'
,p_label=>'Qry Resultado'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>100
,p_value_alignment=>'CENTER'
,p_attribute_01=>'Y'
,p_is_required=>false
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'Y'
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(45214390248289117)
,p_name=>'C007'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C007'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_SINGLE_CHECKBOX'
,p_heading=>'<span aria-hidden="true" title="Calculado" class="fa fa-calculator"></span>'
,p_label=>'Calculado'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>140
,p_value_alignment=>'CENTER'
,p_attribute_01=>'N'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_is_required=>false
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_default_type=>'SQL_QUERY'
,p_default_expression=>'SELECT ''N'' FROM DUAL'
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(57499268776306252)
,p_name=>'C008'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C008'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_SINGLE_CHECKBOX'
,p_heading=>'<span aria-hidden="true" title="Genera PK JSON" class="fa fa-key"></span>'
,p_label=>'PK JSON'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>75
,p_value_alignment=>'CENTER'
,p_attribute_01=>'N'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_is_required=>false
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_default_type=>'SQL_QUERY'
,p_default_expression=>'SELECT ''N'' FROM DUAL'
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(540591937787045021)
,p_name=>'SEQ_ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'SEQ_ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>'Seq Id'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>40
,p_value_alignment=>'CENTER'
,p_attribute_02=>'VALUE'
,p_attribute_05=>'PLAIN'
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(540592514365045027)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>30
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(540592696216045028)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>20
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_display_condition=>'P184_READONLY'
,p_display_condition2=>'1'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(581858886280074702)
,p_name=>'C001'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C001'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>'Columna/Campo'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'Y'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_is_required=>false
,p_max_length=>4000
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with tablesObjetos as (SELECT  TO_CHAR(ITEM) TABLENAME FROM TABLE(PK_COMMONS.F_DIVIDIRTEXTO(:P184_OBJETO,'':'')))',
',tablesJDE as (',
'    SELECT DISTINCT C.TABLE_NAME||''.''||c.COLUMN_NAME D,C.TABLE_NAME||''.''||c.COLUMN_NAME R ,C.TABLE_NAME,c.COLUMN_NAME , C.COLUMN_ID ORDEN ',
'    FROM ALL_TAB_COLUMNS@JDEDTADL C ',
'    INNER JOIN tablesObjetos  I ON C.TABLE_NAME =I.TABLENAME order by C.TABLE_NAME,C.COLUMN_ID',
')',
',tablesDTA as (',
'    SELECT DISTINCT C.TABLE_NAME||''.''||c.COLUMN_NAME D,C.TABLE_NAME||''.''||c.COLUMN_NAME R ,C.TABLE_NAME,c.COLUMN_NAME , C.COLUMN_ID ORDEN ',
'    FROM ALL_TAB_COLUMNS  C ',
'    INNER JOIN tablesObjetos  I ON C.TABLE_NAME =I.TABLENAME order by C.TABLE_NAME,C.COLUMN_ID',
')',
',RESUMEN AS ',
'(SELECT d,r,ORDEN FROM tablesJDE ',
'UNION ALL',
'SELECT d,r,ORDEN FROM tablesDTA)',
'SELECT D,R FROM RESUMEN;'))
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_lov_cascade_parent_items=>'P184_MAYUSCULAS_SINO'
,p_ajax_optimize_refresh=>true
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(581858947364074703)
,p_name=>'C002'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C002'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Alias '
,p_heading_alignment=>'LEFT'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_is_required=>false
,p_max_length=>4000
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(581859720567074711)
,p_name=>'C003'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C003'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_SINGLE_CHECKBOX'
,p_heading=>'<span class="fa fa-eye" title="Visualizar" aria-hidden="true"></span>'
,p_label=>'Visualizar'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>80
,p_value_alignment=>'CENTER'
,p_attribute_01=>'Y'
,p_is_required=>false
,p_enable_filter=>false
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'Y'
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(581862968698074743)
,p_name=>'C004'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'C004'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Tipo Dato'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'STATIC'
,p_lov_source=>'STATIC2:Texto;T,Numero;N,Decimal;D,Moneda;M,Fecha;F'
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_lov_null_text=>'Seleccione'
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_default_type=>'STATIC'
,p_default_expression=>'T'
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(540591832700045020)
,p_internal_uid=>540591832700045020
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>false
,p_submit_checked_rows=>false
,p_lazy_loading=>true
,p_requires_filter=>false
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SET'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:ACTIONS_MENU:SAVE'
,p_add_button_label=>'Agregar Fila'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>false
,p_download_formats=>null
,p_enable_mail_download=>true
,p_fixed_header=>'NONE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function (config) {',
'	return cargarToolbar(config);',
'}'))
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(540617176109277750)
,p_interactive_grid_id=>wwv_flow_imp.id(540591832700045020)
,p_static_id=>'5406172'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_rows_per_page=>1000
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(540617353238277750)
,p_report_id=>wwv_flow_imp.id(540617176109277750)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(6700092407223776)
,p_view_id=>wwv_flow_imp.id(540617353238277750)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(581862968698074743)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>120
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(35252417798053229)
,p_view_id=>wwv_flow_imp.id(540617353238277750)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(34444829337782331)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>30
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(35253200946053232)
,p_view_id=>wwv_flow_imp.id(540617353238277750)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(34444951294782332)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>30
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(42447255928820731)
,p_view_id=>wwv_flow_imp.id(540617353238277750)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(42164705178330508)
,p_is_visible=>false
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(42450123755834910)
,p_view_id=>wwv_flow_imp.id(540617353238277750)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(42164824440330509)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>30
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(43647397790756541)
,p_view_id=>wwv_flow_imp.id(540617353238277750)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(43067571769983323)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>30
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(47625300586729668)
,p_view_id=>wwv_flow_imp.id(540617353238277750)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(45214390248289117)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>30
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(57499268776306253)
,p_view_id=>wwv_flow_imp.id(540617353238277750)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(57499268776306252)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>30
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(540617824182277754)
,p_view_id=>wwv_flow_imp.id(540617353238277750)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(540591937787045021)
,p_is_visible=>false
,p_is_frozen=>false
,p_sort_order=>1
,p_sort_direction=>'ASC'
,p_sort_nulls=>'LAST'
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(540628115303360090)
,p_view_id=>wwv_flow_imp.id(540617353238277750)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(540592514365045027)
,p_is_visible=>false
,p_is_frozen=>true
,p_width=>41
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(581865948391106657)
,p_view_id=>wwv_flow_imp.id(540617353238277750)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(581858886280074702)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(581866812436106661)
,p_view_id=>wwv_flow_imp.id(540617353238277750)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(581858947364074703)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(582322187955689104)
,p_view_id=>wwv_flow_imp.id(540617353238277750)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(581859720567074711)
,p_is_visible=>true
,p_is_frozen=>false
,p_width=>30
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(550996734659588439)
,p_plug_name=>'Carga Masiva de Columnas  <span style="color:#0088ff">(TABLA.CAMPO as ALIAS)</span>'
,p_region_name=>'secMasivo'
,p_parent_plug_id=>wwv_flow_imp.id(540590888541045010)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(37807886111106520)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(540592479540045026)
,p_plug_name=>'Botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290276266120143)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(540593049723045032)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(540592479540045026)
,p_button_name=>'Cerrar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Cerrar'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(125467606418948911)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(540591537363045017)
,p_button_name=>'Todo_Mayusculas'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Todo Mayusculas'
,p_button_position=>'RIGHT_OF_TITLE'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'btnAccion'
,p_icon_css_classes=>'fa-text-height'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(554595232414141613)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(540591537363045017)
,p_button_name=>'Add_SCRIPT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Script'
,p_button_position=>'RIGHT_OF_TITLE'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'(:P184_TIPOOBJETO   IN (''001'') or TO_NUMBER(:P184_TIPOOBJETO)>900)'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_button_css_classes=>'btnAccion'
,p_icon_css_classes=>'fa-file-sql-o'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8908333076245724)
,p_name=>'P184_ACCION'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(540590534107045007)
,p_prompt=>'Accion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12447729990806320)
,p_name=>'P184_TIPOOBJETO'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(540590534107045007)
,p_prompt=>'Tipoobjeto'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29613035759218707)
,p_name=>'P184_TIENE_DATOS'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(540590534107045007)
,p_prompt=>'Tiene Datos'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45214434538289118)
,p_name=>'P184_NUMERO_REGISTROS'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(540590534107045007)
,p_prompt=>'Numero Registros'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(50248059772209227)
,p_name=>'P184_PRIMERVEZ'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(540590534107045007)
,p_prompt=>'Primervez'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(60504305016174915)
,p_name=>'P184_GURDACOLLUMNAS'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(540590534107045007)
,p_prompt=>'Gurdacollumnas'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(125467903725948914)
,p_name=>'P184_MAYUSCULAS_SINO'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(540590534107045007)
,p_prompt=>'Mayusculas Sino'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540590630475045008)
,p_name=>'P184_OBJETO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(540590534107045007)
,p_prompt=>'Objeto'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(545176835726787440)
,p_name=>'P184_READONLY'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(540590534107045007)
,p_prompt=>'Readonly'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(550996894698588440)
,p_name=>'P184_PASTE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(550996734659588439)
,p_prompt=>'Paste'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(57499268776306254)
,p_validation_name=>'Debe seleccionar PK JSON'
,p_validation_sequence=>10
,p_validation=>'SELECT 1 FROM APEX_COLLECTIONS WHERE COLLECTION_NAME = ''COLECCION_COLUMNAS'' AND UPPER(NVL(C008,''N'')) = ''Y'''
,p_validation_type=>'EXISTS'
,p_error_message=>'Debe seleccionar al menos una columna PK JSON'
,p_always_execute=>'Y'
,p_when_button_pressed=>wwv_flow_imp.id(540593049723045032)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(540594747800045049)
,p_name=>'cargarColeccion'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(540591537363045017)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|interactivegridsave'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(540594828077045050)
,p_event_id=>wwv_flow_imp.id(540594747800045049)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_datos CLOB;',
'    v_contador number;',
'BEGIN',
'    v_datos := '''';',
'       SELECT ',
'          JSON_ARRAYAGG(JSON_OBJECT(*) RETURNING CLOB)',
'            into v_datos',
'',
'           FROM (',
'				select ID,',
'				COLUMNA,',
'				trim(decode(:P184_MAYUSCULAS_SINO,1,upper(ALIAS),ALIAS))alias, ',
'				VISIBLE',
'				,TIPODATO',
'				,EDITABLE',
'				,QRYRESUL',
'				,CALCULO',
'				,PK_JSON						',
'			from ( ',
'				SELECT seq_id ID',
'                    ,trim(UPPER(C001)) COLUMNA',
unistr('                    ,trim(TRANSLATE(CASE WHEN C002 IS NULL THEN  SUBSTR(trim(C001),(INSTR(trim(C001),''.''))+CASE WHEN (INSTR(trim(C001),''.''))>0 THEN 1 ELSE 0 END ) ELSE C002 END , ''\00E1\00E9\00ED\00F3\00FA\00C1\00C9\00CD\00D3\00DA\00F1\00D1'', ''aeiouAEIOUnN'' )) alias'),
'                    ,UPPER(NVL(C003,''Y'')) VISIBLE',
'                    ,UPPER(NVL(C004,''T'')) TIPODATO',
'                    ,UPPER(NVL(C005,''N'')) EDITABLE',
'                    ,UPPER(NVL(C006,''Y'')) QRYRESUL',
'                    ,UPPER(NVL(C007,''0'')) CALCULO',
'                    ,UPPER(NVL(C008,''N'')) PK_JSON',
'                FROM APEX_COLLECTIONS ',
'                WHERE COLLECTION_NAME = ''COLECCION_COLUMNAS'' ',
'                ORDER BY seq_id',
'			)',
'           )',
'    ;',
'    :G_GT_COLUMNAS:=v_datos;',
'END;'))
,p_attribute_02=>'G_GT_COLUMNAS,P184_MAYUSCULAS_SINO'
,p_attribute_03=>'G_GT_COLUMNAS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(542355473164543012)
,p_event_id=>wwv_flow_imp.id(540594747800045049)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(550997167167588443)
,p_name=>'PasteColumnas'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P184_PASTE'
,p_condition_element=>'P184_PASTE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'focusout'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(550997327929588445)
,p_event_id=>wwv_flow_imp.id(550997167167588443)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Con esta acci\00F3n se eliminan las columnas antes ingresadas. <br />\00BFDesea Continuar?')
,p_attribute_03=>'warning'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P184_TIENE_DATOS'
,p_client_condition_expression=>'1'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(550997297168588444)
,p_event_id=>wwv_flow_imp.id(550997167167588443)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  v_sql CLOB := q''[P184_PASTE]'';',
'  v_out CLOB;',
'  v_estrim number;',
'BEGIN',
'    v_estrim:=case :P184_TIPOOBJETO when ''001'' then 0 else 0 end;',
'    v_sql:=:P184_PASTE;--replace(v_sql ,''P184_PASTE'',:P184_PASTE);',
'    ',
'    v_out := DATA.pk_finz_gestiontributaria.f_campos_y_alias(v_sql,v_estrim);',
'    SELECT JSON_ARRAYAGG(JSON_OBJECT(*) RETURNING CLOB)',
'    INTO v_out',
'    FROM (',
unistr('      SELECT to_number(CAMPO1) id,CAMPO2 columna,TRANSLATE(CAMPO3, ''\00E1\00E9\00ED\00F3\00FA\00C1\00C9\00CD\00D3\00DA\00F1\00D1'', ''aeiouAEIOUnN'') alias,''Y'' visible,''T'' tipodato,''Y'' QRYRESUL,''N''EDITABLE,''N''CALCULADO,''N'' PK_JSON'),
unistr('      FROM TABLE(pk_commons.f_split_cadena_tabla(((V_OUT)), ''#'', ''\00AC'') )'),
'      order by to_number(CAMPO1)',
'    );',
'     f_imprimir_clob_completo(v_out); ',
unistr('    -- 8. Asignaci\00F3n al item'),
'  :G_GT_COLUMNAS := v_out;',
'END;'))
,p_attribute_02=>'P184_PASTE'
,p_attribute_03=>'G_GT_COLUMNAS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(554594735958141608)
,p_event_id=>wwv_flow_imp.id(550997167167588443)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P184_PASTE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(550997491710588446)
,p_event_id=>wwv_flow_imp.id(550997167167588443)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(554595593810141616)
,p_name=>'clickScript'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(554595232414141613)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(554595612371141617)
,p_event_id=>wwv_flow_imp.id(554595593810141616)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var region$ = $("#secMasivo");',
'',
'if (region$.is(":visible")) {',
'    region$.hide();',
'} else {',
'    region$.show();',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(50247753151209224)
,p_name=>'CARGAR_PAGINA'
,p_event_sequence=>40
,p_condition_element=>'P184_PRIMERVEZ'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(50248147764209228)
,p_event_id=>wwv_flow_imp.id(50247753151209224)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P184_PRIMERVEZ'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(50247891690209225)
,p_event_id=>wwv_flow_imp.id(50247753151209224)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(540591537363045017)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(125467730819948912)
,p_name=>'New'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(125467606418948911)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(125467861938948913)
,p_event_id=>wwv_flow_imp.id(125467730819948912)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P184_MAYUSCULAS_SINO:=CASE NVL(:P184_MAYUSCULAS_SINO,0) WHEN 0 THEN 1 ELSE 0 END;'
,p_attribute_02=>'P184_MAYUSCULAS_SINO'
,p_attribute_03=>'P184_MAYUSCULAS_SINO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(540592719523045029)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(540591537363045017)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Columnas - Save Interactive Grid Data'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    v_alias varchar2(3999);',
'    v_columna varchar2(3999);',
'    v_visible varchar2(3999);',
'    v_tipodato varchar2(3999);',
'    v_editable varchar2(3999);',
'    v_qryresul varchar2(3999);',
'    v_calculo varchar2(3999);',
'    v_pk_json varchar2(3999);',
'    v_cont  number;',
'    v_indx number;',
'    v_APEXROW_STATUS varchar2(3999);',
'BEGIN',
'    v_APEXROW_STATUS:=:APEX$ROW_STATUS;',
'    v_columna :=trim(upper(:C001));',
'    v_alias:=trim((:C002));',
'    v_visible :=trim(upper(:C003));',
'    v_tipodato:=trim(upper(:C004));',
'    v_editable:=NVL(trim(upper(:C005)),''N'');',
'    v_qryresul:=NVL(trim(upper(:C006)),''Y'');',
'    v_calculo:=NVL(trim(upper(:C007)),''0'');',
'    v_pk_json:=NVL(trim(upper(:C008)),''N'');',
'    ',
'    v_indx :=INSTR(v_columna,''.'');',
'    DBMS_OUTPUT.PUT_LINE(''v_indx:''||v_indx);',
'    if (v_indx<0)then v_indx:=0;end if;',
'    if (v_indx>0)then v_indx:=v_indx+1;end if;',
'    v_alias :=CASE WHEN v_alias IS NULL THEN  SUBSTR(v_columna,v_indx)  ELSE v_alias END;',
'    v_alias :=trim(v_alias);',
'    v_alias := REGEXP_REPLACE((v_alias), ''[^A-Za-z0-9"]+'', ''_'');',
unistr('    v_alias:=TRANSLATE( v_alias, ''\00E1\00E9\00ED\00F3\00FA\00C1\00C9\00CD\00D3\00DA\00F1\00D1'', ''aeiouAEIOUnN'' );'),
'    DBMS_OUTPUT.PUT_LINE(''v_indx:''||v_alias);',
'    ',
'    case v_APEXROW_STATUS  ',
'        WHEN ''C'' THEN',
'            if  (:P184_GURDACOLLUMNAS=1)then',
'                IF (TRIM(v_columna) IS NOT NULL )THEN',
'                    APEX_COLLECTION.ADD_MEMBER(p_collection_name => ''COLECCION_COLUMNAS'',            p_c001=>v_columna,p_c002=>v_alias,p_c003=>v_visible,p_c004=>v_tipodato,p_c005=>v_editable,p_c006=>v_qryresul,p_c007=>v_calculo,p_c008=>v_pk_json);',
'                END IF;',
'            end if;',
'        WHEN ''U'' THEN',
'            APEX_COLLECTION.UPDATE_MEMBER(p_collection_name => ''COLECCION_COLUMNAS'',p_seq => :seq_id,p_c001=>v_columna,p_c002=>v_alias,p_c003=>v_visible,p_c004=>v_tipodato,p_c005=>v_editable,p_c006=>v_qryresul,p_c007=>v_calculo,p_c008=>v_pk_json);',
'        WHEN ''D'' THEN',
'            if  (:P184_GURDACOLLUMNAS=1)then',
'                APEX_COLLECTION.DELETE_MEMBER(p_collection_name => ''COLECCION_COLUMNAS'',p_seq => :seq_id);',
'            end if;',
'    END CASE;',
'EXCEPTION WHEN OTHERS THEN ',
'    apex_error.add_error (',
'    p_message          => ''ERROR::''||v_APEXROW_STATUS||'' ''||SQLERRM  ,',
'    p_display_location =>apex_error.c_inline_in_notification );',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_only_for_changed_rows=>'N'
,p_internal_uid=>540592719523045029
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(581863236469074746)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Cargarcoleccion'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_datos CLOB;',
'    v_contador number;',
'BEGIN',
'    v_datos := '''';',
'       SELECT ',
'          JSON_ARRAYAGG(JSON_OBJECT(*) RETURNING CLOB)',
'            into v_datos',
'',
'           FROM (',
'				select ID,',
'				COLUMNA,',
'				trim(decode(:P184_MAYUSCULAS_SINO,1,upper(ALIAS),ALIAS))alias, ',
'				VISIBLE',
'				,TIPODATO',
'				,EDITABLE',
'				,QRYRESUL',
'				,CALCULO',
'				,PK_JSON						',
'			from ( ',
'				SELECT seq_id ID',
'                    ,trim(UPPER(C001)) COLUMNA',
unistr('                    ,trim(TRANSLATE(CASE WHEN C002 IS NULL THEN  SUBSTR(trim(C001),(INSTR(trim(C001),''.''))+CASE WHEN (INSTR(trim(C001),''.''))>0 THEN 1 ELSE 0 END ) ELSE C002 END , ''\00E1\00E9\00ED\00F3\00FA\00C1\00C9\00CD\00D3\00DA\00F1\00D1'', ''aeiouAEIOUnN'' )) alias'),
'                    ,UPPER(NVL(C003,''Y'')) VISIBLE',
'                    ,UPPER(NVL(C004,''T'')) TIPODATO',
'                    ,UPPER(NVL(C005,''N'')) EDITABLE',
'                    ,UPPER(NVL(C006,''Y'')) QRYRESUL',
'                    ,UPPER(NVL(C007,''0'')) CALCULO',
'                    ,UPPER(NVL(C008,''N'')) PK_JSON',
'                FROM APEX_COLLECTIONS ',
'                WHERE COLLECTION_NAME = ''COLECCION_COLUMNAS'' ',
'                ORDER BY seq_id',
'			)',
'           )',
'    ;',
'    :G_GT_COLUMNAS:=v_datos;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(540593049723045032)
,p_internal_uid=>581863236469074746
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(540593325610045035)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog '
,p_attribute_01=>'G_GT_COLUMNAS'
,p_attribute_02=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(540593049723045032)
,p_internal_uid=>540593325610045035
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(540591122418045013)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'    v_contador number;',
'    v_indx number;',
'    v_alias varchar2(3999);',
'     v_columna varchar2(3999);',
'begin',
'    IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_COLUMNAS'') THEN',
'        APEX_COLLECTION.TRUNCATE_COLLECTION(''COLECCION_COLUMNAS'');',
'    END IF;',
' ',
'    IF(:G_GT_OBJETOS IS NOT NULL)THEN',
'       :P184_OBJETO:= :G_GT_OBJETOS ;',
'    END IF;',
'',
'    IF(:G_GT_COLUMNAS IS NOT NULL)THEN',
'        FOR COLS IN (',
'            SELECT ROWNUM ORDEN, ID,COLUMNA,ALIAS,VISIBLE,TIPODATO,EDITABLE,NVL(QRYRESUL,''Y'')QRYRESUL,NVL(CALCULO,''N'')CALCULO,NVL(PK_JSON,''N'')PK_JSON,instr(COLUMNA,''.'')+1 idx ',
'            FROM JSON_TABLE(',
'              :G_GT_COLUMNAS, -- tu variable o columna con el JSON',
'              ''$[*]'' -- indica que es un arreglo',
'              COLUMNS (',
'                ID   VARCHAR2(3999) PATH ''$.ID'',',
'                COLUMNA   VARCHAR2(3999) PATH ''$.COLUMNA'',',
'                ALIAS     varchar2(3999) PATH ''$.ALIAS'',',
'                VISIBLE   VARCHAR2(1)   PATH ''$.VISIBLE'',',
'                TIPODATO  VARCHAR2(100)  PATH ''$.TIPODATO'',',
'                EDITABLE VARCHAR2(1)   PATH ''$.EDITABLE'',',
'                QRYRESUL VARCHAR2(1)   PATH ''$.QRYRESUL'',',
'                CALCULO VARCHAR2(1)   PATH ''$.CALCULO'',',
'                PK_JSON VARCHAR2(1)   PATH ''$.PK_JSON''',
'              )',
'            ) ORDER BY TO_NUMBER(ID)',
'',
'        )',
'        LOOP',
'',
'            v_alias:=trim((COLS.ALIAS));',
'            v_columna:=trim(upper(COLS.COLUMNA));',
'            v_indx:=COLS.idx;',
'            v_alias := REGEXP_REPLACE((trim(CASE WHEN v_alias IS NULL THEN  SUBSTR(v_columna,v_indx)  ELSE v_alias END)), ''[^A-Za-z0-9"-.]+'', ''_'');',
'            DBMS_OUTPUT.PUT_LINE(''v_alias:''||v_alias);',
'         ',
'            APEX_COLLECTION.ADD_MEMBER(',
'                p_collection_name =>''COLECCION_COLUMNAS'',',
'                p_c001 => trim(COLS.COLUMNA),',
'                p_c002 => v_alias,',
'                p_c003 => trim(COLS.VISIBLE),',
'                p_c004 => trim(COLS.TIPODATO),',
'                p_c005 => trim(COLS.EDITABLE),',
'                p_c006 => trim(COLS.QRYRESUL),',
'                p_c007 => trim(COLS.CALCULO),',
'                p_c008 => trim(COLS.PK_JSON),',
'                p_c010 => COLS.orden',
'            );',
'            :P184_TIENE_DATOS:=1;',
'            :P184_NUMERO_REGISTROS:=NVL(:P184_NUMERO_REGISTROS,0)+1;',
'        END LOOP;',
'     ',
'    END IF;',
'     ',
'    :P184_GURDACOLLUMNAS:=0;',
'    IF (not (:P184_TIPOOBJETO between ''002'' and ''899'')) THEN :P184_GURDACOLLUMNAS:=1;END IF;',
'    IF (    (:P184_TIPOOBJETO =''005'') )THEN :P184_GURDACOLLUMNAS:=1;END IF;',
'',
'	:P184_MAYUSCULAS_SINO:=1;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>540591122418045013
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(34444796985782330)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'INTERCAMBIAR_ORDEN'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  v_orden1  apex_collections%ROWTYPE;',
'  v_orden2  apex_collections%ROWTYPE;',
'',
'BEGIN',
'    apex_json.open_object;',
unistr('    -- Llama a la funci\00F3n con los par\00E1metros que recibir\00E1 del lado del cliente'),
'    apex_json.write( p_name => ''X01'', p_value => apex_application.g_x01);',
'    apex_json.write( p_name => ''X02'', p_value => apex_application.g_x02);',
'',
'    SELECT * INTO v_orden1 ',
'    FROM APEX_COLLECTIONS WHERE COLLECTION_NAME = ''COLECCION_COLUMNAS'' AND SEQ_ID = TO_NUMBER(apex_application.g_x01);',
'    SELECT * INTO v_orden2 ',
'    FROM APEX_COLLECTIONS WHERE COLLECTION_NAME = ''COLECCION_COLUMNAS'' AND SEQ_ID = TO_NUMBER(apex_application.g_x02);',
'',
'    APEX_COLLECTION.UPDATE_MEMBER(p_collection_name => ''COLECCION_COLUMNAS'',p_seq => TO_NUMBER(apex_application.g_x01),',
'    p_c001 => v_orden2.c001,',
'    p_c002 => v_orden2.c002,',
'    p_c003 => v_orden2.c003,',
'    p_c004 => v_orden2.c004,',
'    p_c005 => v_orden2.c005,',
'    p_c006 => v_orden2.c006,',
'    p_c007 => v_orden2.c007,',
'    p_c008 => v_orden2.c008,',
'    p_c010 => TO_CHAR(v_orden2.c010));',
'    APEX_COLLECTION.UPDATE_MEMBER(p_collection_name => ''COLECCION_COLUMNAS'',p_seq => TO_NUMBER(apex_application.g_x02),',
'    p_c001 => v_orden1.c001,',
'    p_c002 => v_orden1.c002,',
'    p_c003 => v_orden1.c003,',
'    p_c004 => v_orden1.c004,',
'    p_c005 => v_orden1.c005,',
'    p_c006 => v_orden1.c006,',
'    p_c007 => v_orden1.c007,',
'    p_c008 => v_orden1.c008,',
'    p_c010 => TO_CHAR(v_orden1.c010));',
'    -- Devuelve el resultado para el lado del cliente',
'    apex_json.write( p_name => ''result'', p_value => ''OK'');',
'    apex_json.close_object;',
'END;',
'',
'',
'',
'',
'',
' ',
' '))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>34444796985782330
);
wwv_flow_imp.component_end;
end;
/
