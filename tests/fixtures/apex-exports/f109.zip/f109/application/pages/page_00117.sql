prompt --application/pages/page_00117
begin
--   Manifest
--     PAGE: 00117
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>117
,p_name=>'Saldos de Cierre Inventarios'
,p_alias=>'SALDOS-DE-CIERRE-INVENTARIOS'
,p_step_title=>'Saldos de Cierre Inventarios'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240920134939Z')
,p_last_updated_on=>wwv_flow_imp.dz('20251013172045Z')
,p_last_updated_by=>'EZAMBRANO'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(328888909094964609)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(328889141276964611)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(329067672088643374)
,p_plug_name=>'Saldos de Cierre Inventarios'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  ',
'     num01                               codigojde',
unistr('    ,txt02                               "C\00D3DIGO ITEM"'),
unistr('    ,txt03                               descripci\00F3n'),
'    ,txt04                               um',
'    ,txt05                               "GL CLASS"',
'    ,txt06                               bodega',
'    ,txt07                               lote',
'    ,SUM(num05)                          cantidad',
'    ,SUM(num04)                          costo',
'    ,SUM(num07)                          "COSTO_UNITARIO"',
'    ,num06                               costo_promedio',
'    ,txt08                               tipodecosteo                                       ',
'    ,SUM(num05) * num06                  costo_total_promedio',
'    ,SUM(num04) - (SUM(num05) * num06 ) variacion',
'',
'FROM data.t_apex_temporal',
'WHERE    1= 1',
'AND CONTROL01 = :G_COMPANIA',
'AND CONTROL02 = ''SALDOS''',
'AND CONTROL03 = :APP_USER',
'AND TO_CHAR(FLAG) = ''2''',
'--AND CONTROL04 = ''data.pk_finz_reportes.sp_saldoscierreinventario''',
'--AND CONTROL04 = ''SALDOSMES''',
'GROUP BY  num01, txt02 , txt03 , txt04 , txt05 , txt06  ,txt07,num06,txt08'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Saldos de Cierre Inventarios'
,p_updated_on=>wwv_flow_imp.dz('20251013172045Z')
,p_updated_by=>'EZAMBRANO'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(329067711398643374)
,p_name=>'Saldos de Cierre Inventarios'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>329067711398643374
,p_updated_on=>wwv_flow_imp.dz('20251013172045Z')
,p_updated_by=>'EZAMBRANO'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(329068171904643380)
,p_db_column_name=>'CODIGOJDE'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Codigojde'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(329068548914643380)
,p_db_column_name=>unistr('C\00D3DIGO ITEM')
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>unistr('C\00F3digo Item')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(329068902986643381)
,p_db_column_name=>unistr('DESCRIPCI\00D3N')
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>unistr('Descripci\00F3n')
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(329069330884643381)
,p_db_column_name=>'UM'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Um'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(329069759186643381)
,p_db_column_name=>'GL CLASS'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Gl Class'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(114135955609459248)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(329070191792643381)
,p_db_column_name=>'BODEGA'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(114136295824465848)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(329070584946643382)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Cantidad'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(329070956534643382)
,p_db_column_name=>'COSTO'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Costo'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(329071729561643382)
,p_db_column_name=>'COSTO_UNITARIO'
,p_display_order=>10
,p_column_identifier=>'J'
,p_column_label=>'Costo Unitario'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(329072165857643382)
,p_db_column_name=>'COSTO_PROMEDIO'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Costo Promedio'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(404092385787906646)
,p_db_column_name=>'COSTO_TOTAL_PROMEDIO'
,p_display_order=>21
,p_column_identifier=>'L'
,p_column_label=>'Costo Total Promedio'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240920200326Z')
,p_updated_on=>wwv_flow_imp.dz('20240920215248Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(404092579221906648)
,p_db_column_name=>'VARIACION'
,p_display_order=>31
,p_column_identifier=>'N'
,p_column_label=>unistr('Variaci\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20240920215627Z')
,p_updated_on=>wwv_flow_imp.dz('20240920215707Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(604956541088629738)
,p_db_column_name=>'LOTE'
,p_display_order=>41
,p_column_identifier=>'O'
,p_column_label=>'Lote'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20250228215542Z')
,p_updated_on=>wwv_flow_imp.dz('20250228215542Z')
,p_created_by=>'EZAMBRANO'
,p_updated_by=>'EZAMBRANO'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(110367028067802535)
,p_db_column_name=>'TIPODECOSTEO'
,p_display_order=>51
,p_column_identifier=>'P'
,p_column_label=>'Tipo Costeo'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20251013171915Z')
,p_updated_on=>wwv_flow_imp.dz('20251013172009Z')
,p_created_by=>'EZAMBRANO'
,p_updated_by=>'EZAMBRANO'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(329072534773643752)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3290726'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>unistr('BODEGA:C\00D3DIGO ITEM:DESCRIPCI\00D3N:UM:GL CLASS:COSTO:CANTIDAD:COSTO_UNITARIO:COSTO_PROMEDIO:TIPODECOSTEO:COSTO_TOTAL_PROMEDIO:VARIACION:')
,p_sort_column_1=>unistr('DESCRIPCI\00D3N')
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'BODEGA'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20240920134939Z')
,p_updated_on=>wwv_flow_imp.dz('20251013172045Z')
,p_created_by=>'EMASABANDA'
,p_updated_by=>'EZAMBRANO'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(328889023472964610)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(328888909094964609)
,p_button_name=>'Buscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(328889200683964612)
,p_name=>'P117_FECHA_CORTE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(328889141276964611)
,p_item_default=>'trunc(add_months(sysdate,-1),''month'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Corte'
,p_placeholder=>'Seleccione una Fecha'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:TODAY-BUTTON:CLEAR-BUTTON'
,p_attribute_13=>'HIDDEN'
,p_attribute_15=>'IMAGE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(328889394339964613)
,p_name=>'P117_GLCLASS'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(328889141276964611)
,p_prompt=>'Gl Class'
,p_placeholder=>'Seleccione un Gl Class'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_JDE_GLCLASS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select TRIM(DRKY) || '' - '' || DRDL01, DRKY ',
'from  vt_jde_udcjde where drsy=''41'' and drrt=''9'' AND DRSPHD=''ZAIMELLA  ''',
'order by 1'))
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_updated_on=>wwv_flow_imp.dz('20240920220945Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(328889424921964614)
,p_name=>'P117_PRODUCTO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(328889141276964611)
,p_prompt=>'Producto'
,p_placeholder=>'Seleccione un producto'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_JDE_PRODUCTO_CODPRD_CODOCORTO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  (nombreproducto) || ''  (''|| trim (CODIGOPRODUCTO) ||'') - '' ||codigocorto d, codigocorto r ',
'from vt_jde_productos',
'where  trim(nombreproducto) is not null',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Todos'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_updated_on=>wwv_flow_imp.dz('20240920220945Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(328889500265964615)
,p_name=>'P117_BODEGA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(328889141276964611)
,p_prompt=>'Bodega'
,p_placeholder=>'Seleccione una Bodega'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_JDE_BODEGAS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CODUNIDAD ||'' - ''||DESCRIPCION , CODUNIDAD from vt_jde_bodegas',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Todos'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_updated_on=>wwv_flow_imp.dz('20240920220945Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(328889640353964616)
,p_validation_name=>'No vacio Fecha Corte'
,p_validation_sequence=>10
,p_validation=>'P117_FECHA_CORTE'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor'
,p_when_button_pressed=>wwv_flow_imp.id(328889023472964610)
,p_associated_item=>wwv_flow_imp.id(328889200683964612)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(328889750651964617)
,p_validation_name=>'No vacio Gl Class'
,p_validation_sequence=>20
,p_validation=>'P117_GLCLASS'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor'
,p_when_button_pressed=>wwv_flow_imp.id(328889023472964610)
,p_associated_item=>wwv_flow_imp.id(328889394339964613)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(328889826790964618)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Buscar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    sp_saldoscierreinventario_1(',
'		  p_compania	=> :G_COMPANIA',
'		, p_usuario	=> :APP_USER',
'		, p_fechacorte	=> :P117_FECHA_CORTE',
'		, p_glclass	=> :P117_GLCLASS',
'		, p_producto => :P117_PRODUCTO',
'        , p_bodega => :P117_BODEGA',
'',
'	) ;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>328889826790964618
);
wwv_flow_imp.component_end;
end;
/
