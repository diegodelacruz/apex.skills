prompt --application/pages/page_00122
begin
--   Manifest
--     PAGE: 00122
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>122
,p_name=>'Estado de Costos'
,p_alias=>'ESTADO-DE-COSTOS'
,p_step_title=>'Estado de Costos'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>' $(secItems).hide();'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-button.a-IRR-sortWidget-button[data-option="hide"], .a-IRR-button.a-IRR-sortWidget-button[data-option="freeze"]{',
'    display:none;',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230911202846Z')
,p_last_updated_on=>wwv_flow_imp.dz('20230911192506Z')
,p_last_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(92124089838074030)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(175292908490253186)
,p_plug_name=>'Filtros'
,p_region_name=>'secFiltros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(175293178174253188)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(184696267693840413)
,p_plug_name=>'Estado de Costos'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    pk_commons.f_jde2g(num01) fec_lm,',
'    pk_commons.f_jde2g(num02) fec_creacion,',
'    txt01                     categ_lm,',
'    txt02                     cta_objeto,',
'    txt03                     tp_doc,',
'    txt04                     tp_ord,',
'    num03                     num_orden,',
'    num04                     num_documento,',
'    num05                     num_batch,',
'    num06                     id_clave_unica,',
'    num07                     num_corto_art,',
'    trim(txt05)               "2do_num_art",',
'    num08 / 10000             cantidad,',
'    txt06                     um,',
'    num09 / 10000             costo_uni,',
'    num10                     precio_total,',
'    txt07                     bodega,',
'    txt08                     sucursal,',
'    txt09                     cod_contabilizacion,',
'    num11                     fec_orden,',
'    txt10                     ubicacion,',
'    txt11                     cod_motivo,',
'    txt12                     id_cuenta,',
'    txt13                     id_usuario,',
'    num12                     num_direcccion,',
'    txt14                     unidad_negocio,',
'    txt15                     um_secundaria,',
'    txt16                     explicacion,',
'    txt17                     descripcion',
'FROM',
'    t_apex_temporal',
'WHERE',
'        control01 = :p122_compania',
'    AND control02 = :p122_modulo',
'    AND control03 = :p122_usuario',
'    AND control04 = :p122_aplicacion',
'    and :P122_BANDERA=1;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P122_COMPANIA,P122_MODULO,P122_USUARIO,P122_APLICACION'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Estado de Costos'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(184696395932840414)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>184696395932840414
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92679727936351078)
,p_db_column_name=>'DESCRIPCION'
,p_display_order=>10
,p_column_identifier=>'AC'
,p_column_label=>unistr('Descripci\00F3n Secuencia')
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(92683063879351084)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92668523101351072)
,p_db_column_name=>'FEC_LM'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Fec Lm'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92668997652351072)
,p_db_column_name=>'FEC_CREACION'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Fec Creacion'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92669305898351072)
,p_db_column_name=>'CATEG_LM'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Categ Lm'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92669777019351073)
,p_db_column_name=>'CTA_OBJETO'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Cta Objeto'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92670196227351073)
,p_db_column_name=>'TP_DOC'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Tp Doc'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92670504411351073)
,p_db_column_name=>'TP_ORD'
,p_display_order=>70
,p_column_identifier=>'F'
,p_column_label=>'Tp Ord'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92670961015351073)
,p_db_column_name=>'NUM_ORDEN'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Num Orden'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92671343333351073)
,p_db_column_name=>'NUM_DOCUMENTO'
,p_display_order=>90
,p_column_identifier=>'H'
,p_column_label=>'Num Documento'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92671744440351074)
,p_db_column_name=>'NUM_BATCH'
,p_display_order=>100
,p_column_identifier=>'I'
,p_column_label=>'Num Batch'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92672136734351074)
,p_db_column_name=>'ID_CLAVE_UNICA'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Id Clave Unica'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92672557307351074)
,p_db_column_name=>'NUM_CORTO_ART'
,p_display_order=>120
,p_column_identifier=>'K'
,p_column_label=>'Num Corto Art'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92672997804351074)
,p_db_column_name=>'2do_num_art'
,p_display_order=>130
,p_column_identifier=>'L'
,p_column_label=>'2do Num Art'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(464664643734590584)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92673302448351075)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>'Cantidad'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92673738761351075)
,p_db_column_name=>'UM'
,p_display_order=>150
,p_column_identifier=>'N'
,p_column_label=>'Um'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92674185598351075)
,p_db_column_name=>'COSTO_UNI'
,p_display_order=>160
,p_column_identifier=>'O'
,p_column_label=>'Costo Uni'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92674531602351075)
,p_db_column_name=>'PRECIO_TOTAL'
,p_display_order=>170
,p_column_identifier=>'P'
,p_column_label=>'Precio Total'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92674955346351075)
,p_db_column_name=>'BODEGA'
,p_display_order=>180
,p_column_identifier=>'Q'
,p_column_label=>'Bodega'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92675376319351075)
,p_db_column_name=>'SUCURSAL'
,p_display_order=>190
,p_column_identifier=>'R'
,p_column_label=>'Sucursal'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92675762260351076)
,p_db_column_name=>'COD_CONTABILIZACION'
,p_display_order=>200
,p_column_identifier=>'S'
,p_column_label=>'Cod Contabilizacion'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92676134329351076)
,p_db_column_name=>'FEC_ORDEN'
,p_display_order=>210
,p_column_identifier=>'T'
,p_column_label=>'Fec Orden'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92676577308351076)
,p_db_column_name=>'UBICACION'
,p_display_order=>220
,p_column_identifier=>'U'
,p_column_label=>'Ubicacion'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92676994462351076)
,p_db_column_name=>'COD_MOTIVO'
,p_display_order=>230
,p_column_identifier=>'V'
,p_column_label=>'Cod Motivo'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92677327473351077)
,p_db_column_name=>'ID_CUENTA'
,p_display_order=>240
,p_column_identifier=>'W'
,p_column_label=>'Id Cuenta'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92677714906351077)
,p_db_column_name=>'ID_USUARIO'
,p_display_order=>250
,p_column_identifier=>'X'
,p_column_label=>'Id Usuario'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92678159348351077)
,p_db_column_name=>'NUM_DIRECCCION'
,p_display_order=>260
,p_column_identifier=>'Y'
,p_column_label=>'Num Direcccion'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(92685403493351092)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92678547930351077)
,p_db_column_name=>'UNIDAD_NEGOCIO'
,p_display_order=>270
,p_column_identifier=>'Z'
,p_column_label=>'Unidad Negocio'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92678920136351078)
,p_db_column_name=>'UM_SECUNDARIA'
,p_display_order=>280
,p_column_identifier=>'AA'
,p_column_label=>'Um Secundaria'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(92679376370351078)
,p_db_column_name=>'EXPLICACION'
,p_display_order=>290
,p_column_identifier=>'AB'
,p_column_label=>'Explicacion'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(184807192470428005)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'921446'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'DESCRIPCION:FEC_LM:FEC_CREACION:CATEG_LM:CTA_OBJETO:TP_DOC:TP_ORD:NUM_ORDEN:NUM_DOCUMENTO:NUM_BATCH:ID_CLAVE_UNICA:NUM_CORTO_ART:2do_num_art:CANTIDAD:UM:COSTO_UNI:PRECIO_TOTAL:BODEGA:SUCURSAL:COD_CONTABILIZACION:FEC_ORDEN:UBICACION:COD_MOTIVO:ID_CUEN'
||'TA:ID_USUARIO:NUM_DIRECCCION:UNIDAD_NEGOCIO:UM_SECUNDARIA:EXPLICACION:'
,p_created_on=>wwv_flow_imp.dz('20230911202846Z')
,p_updated_on=>wwv_flow_imp.dz('20230911202846Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(92663286540351066)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(92124089838074030)
,p_button_name=>'Buscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(92663976833351067)
,p_name=>'P122_FECHADESDE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(175292908490253186)
,p_item_default=>'trunc(ADD_MONTHS(SYSDATE,-1),''MONTH'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Desde'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'STATIC'
,p_attribute_07=>'+0d'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:NUMBER-OF-MONTH:TODAY-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(92664320786351068)
,p_name=>'P122_FECHAHASTA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(175292908490253186)
,p_item_default=>'trunc(sysdate)'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Hasta'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'STATIC'
,p_attribute_07=>'+0d'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:NUMBER-OF-MONTH:TODAY-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(92664720522351068)
,p_name=>'P122_SECUENCIA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(175292908490253186)
,p_prompt=>'Secuencia'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_ESTADOCOSTOSEC'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    entry,',
unistr('    b.descripcion descripci\00F3n,'),
unistr('    a.iddescripcion "id descripci\00F3n",'),
'    a.activo',
'FROM dp.t_pf_estadocostos a',
'INNER JOIN dp.t_generaldet b ON ( a.iddescripcion = b.id_tabla AND b.id_tgralcab = 598 )',
'WHERE a.activo = 1',
'    AND iddescripcion IN ( SELECT item FROM TABLE ( pk_commons.f_dividirtexto(( SELECT valor FROM "DATA"."T_CORP_UDC" WHERE id_cabecera = ''COMP_ESTCO'' AND id_tabla = ''DT'' ), '','') ) )',
'ORDER BY',
'    to_number(a.iddescripcion);'))
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'Y'
,p_attribute_06=>'0'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>'|'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(92665105928351069)
,p_name=>'P122_NEW_2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(175292908490253186)
,p_prompt=>'New'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859379436106556)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(92665873263351069)
,p_name=>'P122_COMPANIA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(175293178174253188)
,p_prompt=>'Compania'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(92666293293351069)
,p_name=>'P122_MODULO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(175293178174253188)
,p_prompt=>'Modulo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(92666659543351070)
,p_name=>'P122_USUARIO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(175293178174253188)
,p_prompt=>'Usuario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(92667006933351070)
,p_name=>'P122_APLICACION'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(175293178174253188)
,p_prompt=>'Aplicacion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(92667432058351070)
,p_name=>'P122_BANDERA'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(175293178174253188)
,p_prompt=>'Bandera'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(92681108779351080)
,p_validation_name=>'No vacio Secuencia'
,p_validation_sequence=>10
,p_validation=>'P122_SECUENCIA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor'
,p_when_button_pressed=>wwv_flow_imp.id(92663286540351066)
,p_associated_item=>wwv_flow_imp.id(92664720522351068)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(92681577293351081)
,p_validation_name=>'No vacio FechaDesde'
,p_validation_sequence=>20
,p_validation=>'P122_FECHADESDE'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor'
,p_when_button_pressed=>wwv_flow_imp.id(92663286540351066)
,p_associated_item=>wwv_flow_imp.id(92663976833351067)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(92681947416351081)
,p_validation_name=>'No vacio FechaHasta'
,p_validation_sequence=>30
,p_validation=>'P122_FECHAHASTA'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'#LABEL# debe tener un valor'
,p_when_button_pressed=>wwv_flow_imp.id(92663286540351066)
,p_associated_item=>wwv_flow_imp.id(92664320786351068)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(92682605944351082)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Buscar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P122_BANDERA:=0;',
'    pk_finz_reportes.sp_estadocostos (',
'          p_secuencia => :P122_SECUENCIA',
'        , p_desde     => :P122_FECHADESDE',
'        , p_hasta     => :P122_FECHAHASTA',
'        , p_compania  => :P122_COMPANIA',
'        , p_usuario   => :P122_USUARIO',
'    );',
':P122_BANDERA:=1;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>92682605944351082
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(92682296648351081)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Setup Interface'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P122_COMPANIA:=:g_compania;',
':P122_MODULO:=''FINZ'';',
':P122_USUARIO:=:app_user;',
':P122_APLICACION:=''data.pk_comp_reportes.sp_estadocostos'';'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>92682296648351081
);
wwv_flow_imp.component_end;
end;
/
