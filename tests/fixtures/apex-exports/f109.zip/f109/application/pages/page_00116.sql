prompt --application/pages/page_00116
begin
--   Manifest
--     PAGE: 00116
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>116
,p_name=>unistr('Aprobaci\00F3n Desbloqueo de Pago')
,p_step_title=>unistr('Aprobaci\00F3n Desbloqueo de Pago')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_page_component_map=>'03'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260213192309Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1391070604216520096)
,p_plug_name=>unistr('Aprobaci\00F3n Bloqueo de Pagos')
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37817215439106526)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(1549067352350352853)
,p_name=>unistr('Aprobaci\00F3n Desbloqueo')
,p_template=>wwv_flow_imp.id(37807886111106520)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  select APEX_ITEM.CHECKBOX(1, trim(a.NUMEROFACTURA)||a.LINEA,''CHECKED class="chkF01"'') seleccion,a.COMPANIA, b.NUMERODOCUMENTO, c.DESCRIPCION PROVEEDOR, a.ORDENDECOMPRA, a.TIPOORDENCOMPRA, a.NUMEROFACTURA, a.MOTIVO, ',
'  a.MONTOTOTAL, a.MONTOPENDIENTE, a.MONTOBLOQUEO, b.TIPO',
'  from t_finz_retencionpagos a, VT_FINZ_MESATRABAJO_BLOQUEO b, VT_JDE_MAESTROPROVEEDOR c ',
'  where a.id_proceso = b.NUMERODOCUMENTO AND a.COMPANIA = b.COMPANIA AND a.CODIGOPROVEEDOR = c.CODIGOPROVEEDOR',
'  AND a.id_proceso = :P116_DOCUMENTO ',
'  and b.APROBADOR = :P116_APROBADOR',
'  AND a.ESTADO = ''EN_PROCESO'''))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(37830327650106535)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>'No existen datos para aprobar'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>500
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(340065852905719130)
,p_query_column_id=>1
,p_column_alias=>'SELECCION'
,p_column_display_sequence=>1
,p_column_heading=>'Seleccion'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(340000524912886084)
,p_query_column_id=>2
,p_column_alias=>'COMPANIA'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(340001394337886085)
,p_query_column_id=>3
,p_column_alias=>'NUMERODOCUMENTO'
,p_column_display_sequence=>3
,p_column_heading=>'ID Proceso'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(340000998432886085)
,p_query_column_id=>4
,p_column_alias=>'PROVEEDOR'
,p_column_display_sequence=>4
,p_column_heading=>'Proveedor'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(340001729792886085)
,p_query_column_id=>5
,p_column_alias=>'ORDENDECOMPRA'
,p_column_display_sequence=>5
,p_column_heading=>'OC'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(340002183399886085)
,p_query_column_id=>6
,p_column_alias=>'TIPOORDENCOMPRA'
,p_column_display_sequence=>6
,p_column_heading=>'Tipo OC'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(340002590396886087)
,p_query_column_id=>7
,p_column_alias=>'NUMEROFACTURA'
,p_column_display_sequence=>7
,p_column_heading=>'Factura'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(340002975581886087)
,p_query_column_id=>8
,p_column_alias=>'MOTIVO'
,p_column_display_sequence=>8
,p_column_heading=>'Motivo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(340003314686886087)
,p_query_column_id=>9
,p_column_alias=>'MONTOTOTAL'
,p_column_display_sequence=>9
,p_column_heading=>'Total'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(340003784555886087)
,p_query_column_id=>10
,p_column_alias=>'MONTOPENDIENTE'
,p_column_display_sequence=>10
,p_column_heading=>'Pendiente'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(340004171908886087)
,p_query_column_id=>11
,p_column_alias=>'MONTOBLOQUEO'
,p_column_display_sequence=>11
,p_column_heading=>'Bloqueado'
,p_use_as_row_header=>'N'
,p_column_format=>'FML999G999G999G999G990D00'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(340004505377886087)
,p_query_column_id=>12
,p_column_alias=>'TIPO'
,p_column_display_sequence=>12
,p_column_heading=>'Tipo'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1901021831198360988)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2023500316283415828)
,p_plug_name=>'Botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290276266120143)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>'PK_CORP_FLUJOAPROBACION.F_APROBADORFLUJO(:P116_USUARIO, :P116_APROBADOR, :APP_MODULO ,:G_COMPANIA)=1'
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(340478077797412284)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1901021831198360988)
,p_button_name=>'Regresar'
,p_button_static_id=>'btnRegresar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:RP::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(339998732521886082)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1901021831198360988)
,p_button_name=>'Ver_Ruta'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Ver Ruta'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:104:&SESSION.::&DEBUG.:RP:G_OBJETO,G_OBJETO_ID,G_TODO:&APP_OBJETO.,&P116_DOCUMENTO.,true'
,p_icon_css_classes=>'fa-road'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(339999432056886084)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(2023500316283415828)
,p_button_name=>'APROBAR'
,p_button_static_id=>'btnAprobar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Aprobar'
,p_button_redirect_url=>'f?p=100:102:&SESSION.::&DEBUG.:RP,:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO:&G_COMPANIA.,&APP_MODULO.,&P116_USUARIO.,RETENCION_DE_PAGO,&P116_DOCUMENTO.,&P116_APROBADOR.'
,p_grid_new_row=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260213192308Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(339999866539886084)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(2023500316283415828)
,p_button_name=>'RECHAZAR'
,p_button_static_id=>'btnRechazar'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Rechazar'
,p_button_redirect_url=>'f?p=100:103:&SESSION.::&DEBUG.:RP,:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID,G_USUARIO_FLUJO:&G_COMPANIA.,&APP_MODULO.,&P116_USUARIO.,RETENCION_DE_PAGO,&P116_DOCUMENTO.,&P116_APROBADOR.'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260213192308Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(340012462772886098)
,p_branch_name=>'Regresa a Mesa'
,p_branch_action=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(106108166994260245)
,p_name=>'P116_USUARIO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(1549067352350352853)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(340004844018886089)
,p_name=>'P116_APROBADOR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1549067352350352853)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(340005293554886090)
,p_name=>'P116_DOCUMENTO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1549067352350352853)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(340005633091886090)
,p_name=>'P116_APROBACION_EXITO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(1549067352350352853)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(340006059667886090)
,p_name=>'P116_TERMINA_FLUJO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(1549067352350352853)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(340470289381351918)
,p_name=>'P116_SINSELECCION'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(1549067352350352853)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(340011475584886096)
,p_name=>unistr('Cierre di\00E1logo: aprobar')
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(339999432056886084)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(340011989473886096)
,p_event_id=>wwv_flow_imp.id(340011475584886096)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'apex.item( "P116_TERMINA_FLUJO" ).setValue(0);',
'',
'if(this.data.G_EXITO==''true''){',
'    mensaje(''exito'', this.data.G_MENSAJE);',
'    if(isTerminoFlujo){',
'        apex.item( "P116_TERMINA_FLUJO" ).setValue(1);',
'    }',
'    $(''#btnAprobar'').hide();',
'    $(''#btnRechazar'').hide();',
'}',
'else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(340006739391886092)
,p_name=>unistr('Cierre di\00E1logo: aprobar exito')
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(339999432056886084)
,p_condition_element=>'P116_TERMINA_FLUJO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(340008298350886095)
,p_event_id=>wwv_flow_imp.id(340006739391886092)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    V_ID_PROCESO_BLQ NUMBER;',
'    V_ID_PROCESO     NUMBER;',
'begin',
'    V_ID_PROCESO:= :P116_DOCUMENTO;',
'    ',
'    SELECT ID_PROCESO_BLQ INTO V_ID_PROCESO_BLQ from t_finz_retencionpagos where ID_PROCESO= V_ID_PROCESO and rownum=1;',
'    ',
'    UPDATE T_FINZ_RETENCIONPAGOS',
'    SET ESTADO = ''DESBLOQUEADO'', APROBADOR = :APP_USER',
'    ,FECHADESBLOQUEO = SYSDATE',
'    WHERE ID_PROCESO =V_ID_PROCESO',
'    AND (ID NOT IN (SELECT regexp_substr(:P116_SINSELECCION,''[^,]+'', 1, level) FROM DUAL connect by regexp_substr(:P116_SINSELECCION, ''[^,]+'', 1, level) is not null )',
'    OR :P116_SINSELECCION IS NULL);',
'',
'    UPDATE T_FINZ_RETENCIONPAGOS',
'    SET ESTADO = ''DESBLOQUEO_PADRE'', APROBADOR = :APP_USER',
'    WHERE ID_PROCESO =V_ID_PROCESO_BLQ',
'    AND ESTADO =''EN_PROCESO_DESBLOQUE''',
'    AND (ID NOT IN (SELECT regexp_substr(:P116_SINSELECCION,''[^,]+'', 1, level) FROM DUAL connect by regexp_substr(:P116_SINSELECCION, ''[^,]+'', 1, level) is not null )',
'    OR :P116_SINSELECCION IS NULL);',
'',
'    PK_FINZ_RETENCIONPAGOS.SP_PROCESA_DESBLOQUEO_APROBADO(:P116_DOCUMENTO);',
'',
'    PK_FINZ_RETENCIONPAGOS.SP_NOTIF_DESBLOQUEO_APROBADO(:P116_DOCUMENTO);',
'    COMMIT;',
'end;'))
,p_attribute_02=>'P116_DOCUMENTO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(340007212002886093)
,p_event_id=>wwv_flow_imp.id(340006739391886092)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>' $(''#btnRegresar'').trigger("click");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(340009176252886095)
,p_name=>unistr('Cierre di\00E1logo: rechazar')
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(339999866539886084)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(340009650090886095)
,p_event_id=>wwv_flow_imp.id(340009176252886095)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.item( "P116_TERMINA_FLUJO" ).setValue(0);',
'if(this.data.G_EXITO==''true''){',
'    mensaje(''exito'', this.data.G_MENSAJE);',
'    apex.item( "P116_TERMINA_FLUJO" ).setValue(1);',
'    $(''#btnAprobar'').hide();',
'    $(''#btnRechazar'').hide();',
'}    ',
'else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}',
'',
'/*',
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo= trama.resultado.terminoFlujo;',
'apex.item( "P116_TERMINA_FLUJO" ).setValue(0);',
'',
'if(this.data.G_EXITO==''true''){',
'    mensaje(''exito'', this.data.G_MENSAJE);',
'    if(isTerminoFlujo){',
'        apex.item( "P116_TERMINA_FLUJO" ).setValue(1);',
'    $(''#btnAprobar'').hide();',
'    $(''#btnRechazar'').hide();',
'    }',
'    else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}',
'}',
'*/'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(340010021678886095)
,p_name=>unistr('Cierre di\00E1logo: rechazar exito')
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(339999866539886084)
,p_condition_element=>'P116_TERMINA_FLUJO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(340011089188886096)
,p_event_id=>wwv_flow_imp.id(340010021678886095)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    V_ID_PROCESO_BLQ NUMBER;',
'    V_ID_PROCESO     NUMBER;',
'begin',
'    V_ID_PROCESO:= :P116_DOCUMENTO;    ',
'    SELECT ID_PROCESO_BLQ INTO V_ID_PROCESO_BLQ from t_finz_retencionpagos where ID_PROCESO= V_ID_PROCESO AND ROWNUM=1;    ',
'    UPDATE T_FINZ_RETENCIONPAGOS',
'    SET ESTADO = ''RECHAZADO'', APROBADOR = :APP_USER',
'    WHERE ID_PROCESO =V_ID_PROCESO',
'    AND (ID NOT IN (SELECT regexp_substr(:P116_SINSELECCION,''[^,]+'', 1, level) FROM DUAL connect by regexp_substr(:P116_SINSELECCION, ''[^,]+'', 1, level) is not null )',
'    OR :P116_SINSELECCION IS NULL);',
'',
'    UPDATE T_FINZ_RETENCIONPAGOS',
'    SET ESTADO = ''BLOQUEADO'', APROBADOR = :APP_USER',
'    WHERE ID_PROCESO =V_ID_PROCESO_BLQ',
'    AND ESTADO =''EN_PROCESO_DESBLOQUE''',
'    AND (ID NOT IN (SELECT regexp_substr(:P116_SINSELECCION,''[^,]+'', 1, level) FROM DUAL connect by regexp_substr(:P116_SINSELECCION, ''[^,]+'', 1, level) is not null )',
'    OR :P116_SINSELECCION IS NULL);',
'    COMMIT;',
'end;'))
,p_attribute_02=>'P116_APROBADOR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(340010531899886096)
,p_event_id=>wwv_flow_imp.id(340010021678886095)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>' $(''#btnRegresar'').trigger("click");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(340474221221358895)
,p_name=>'Seleccionados'
,p_event_sequence=>50
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.chkF01'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(340474639619358900)
,p_event_id=>wwv_flow_imp.id(340474221221358895)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P116_SELECCION'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var lineas =""; ',
'document.querySelectorAll(''.chkF01'').forEach(function(seleccion) {',
'    if(!seleccion.checked){',
'        var linea = seleccion.value',
'        if(lineas==""){',
'            lineas = linea;',
'        }else{',
'            ',
'            lineas = lineas+'',''+linea;',
'        }      ',
'    }else{',
'        ',
'    }',
'    ',
'});',
'',
'apex.item("P116_SINSELECCION").setValue(lineas);',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(106108089530260244)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Page Setup'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_tipo varchar2(999) := '''';',
'begin',
'	:p116_usuario := :app_user;',
'	if :g_detalle_id is not null and :g_token is not null then -- aprobacion con token (desde link del correo)',
'		pk_corp_flujoaprobacion.sp_buscaraprobacion(:g_detalle_id, :g_token, :g_compania, :p116_aprobador, v_tipo, :p116_documento);',
'		:p116_usuario := :p116_aprobador;',
'	end if;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>106108089530260244
,p_updated_on=>wwv_flow_imp.dz('20260213192309Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
