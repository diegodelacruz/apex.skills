prompt --application/pages/page_00100
begin
--   Manifest
--     PAGE: 00100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>100
,p_name=>'Mesa de Trabajo'
,p_step_title=>'Mesa de Trabajo'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function mostrarErrorAPEX(mensaje, ubicacion, item) {',
'    apex.message.clearErrors();',
'',
'    // Construimos el objeto de error',
'    var error = {',
'        type: "error",',
'        location: ubicacion,',
'        message: mensaje,',
'        unsafe: false',
'    };',
'',
unistr('    // Si la ubicaci\00F3n incluye ''inline'', se necesita un pageItem'),
'    if ((ubicacion === "inline" || ',
'         (Array.isArray(ubicacion) && ubicacion.includes("inline"))) && item) {',
'        error.pageItem = item;',
'    }',
'',
'    // Mostrar el error',
'    apex.message.showErrors([error]);',
'',
unistr('    // Ocultado autom\00E1tico'),
'    apex.message.setDismissPreferences( {',
'        dismissPageSuccess: true,',
'        dismissPageSuccessDuration: 5000  // 5 segundos',
'    } );',
'}',
''))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(secItems).hide();',
'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();',
'',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#R119022001573879508_control_panel{',
'    display: none;',
'}',
'',
'.a-IRR-aggregate-value{',
'       font-weight: bolder;',
'}',
'',
'#btnBuscar, #btnBuscarAsof { display: none; }'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_last_updated_on=>wwv_flow_imp.dz('20260630221116Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(129200876701469933)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(348972021051859410)
,p_plug_name=>'Mesa'
,p_region_name=>'rgMesa'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:t-TabsRegion-mod--fillLabels:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_imp.id(37814656137106525)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(118843012099907529)
,p_plug_name=>'AsOf - Kardex'
,p_region_name=>'tbAsofKadex'
,p_parent_plug_id=>wwv_flow_imp.id(348972021051859410)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20260630184406Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(119021399406879501)
,p_plug_name=>'Filtros'
,p_parent_plug_id=>wwv_flow_imp.id(118843012099907529)
,p_region_template_options=>'#DEFAULT#:t-Form--slimPadding:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'htp.p(''<div id="coloresLista">'');',
'        FOR codigoColores IN (SELECT VALOR, VALOR2 FROM T_CORP_UDC WHERE ID_CABECERA = ''INVE_COLOR'' AND VALOR3 =1)',
'        LOOP',
'         htp.p(''<span style="margin-left : 15px;">''|| codigoColores.VALOR || ''<span class="fa fa-square" style="color: '' || codigoColores.VALOR2 ||''; margin-left: 5px;" >',
'                                                  <spam class="visuallyhidden">Verificado</spam>',
'                                              </span>''||   ''</span>'');',
'        END LOOP;',
'   htp.p(''</div>'');'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(119022001573879508)
,p_plug_name=>'Consutas'
,p_region_name=>'regAsof'
,p_parent_plug_id=>wwv_flow_imp.id(118843012099907529)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ftedata AS (',
'    SELECT',
'        anio,',
'        mes,',
'        mes                          mes_valor,',
'        bodega,',
'        SUM(cantidadmeskrdx) / 10000 kardex_cantidad,',
'        SUM(costomeskrdx) / 100      kardex_costo,',
'        SUM(cantidadmesasof) / 10000 asof_cantidad,',
'        SUM(costomesasof) / 100      asof_costo',
'    FROM',
'        DATA.t_apex_asofkardex',
'    WHERE 1 = 1',
'		and :P100_BANDERA= 1',
'		-- and :p100_tipo = ''#tbAsofKadex''',
'		and flag = ''asof_kardex''',
'        and anio = :p100_anio - 2000',
'        and mes = nvl(:p100_mes,mes)',
'        and bodega = nvl(:p100_bodega,bodega)',
'        and glcls = nvl(:P100_GLCLASS, glcls)',
'        and codigojde = nvl(:p100_producto,codigojde)',
'    GROUP BY',
'        anio,',
'        mes,',
'        bodega',
')',
'SELECT',
'    bodega,',
'    mes,',
'    asof_cantidad,',
'    asof_costo,',
'    kardex_cantidad,',
'    kardex_costo,',
'    CASE',
'        WHEN round(kardex_cantidad, 2) <> round(asof_cantidad, 2) THEN',
'            1',
'        WHEN round(kardex_costo, 2) <> round(asof_costo, 2)       THEN',
'            2',
'        ELSE',
'            0',
'    END diffcantidad,',
'    CASE',
'        WHEN round(kardex_cantidad, 2) <> round(asof_cantidad, 2) OR round(kardex_costo, 2) <> round(asof_costo, 2) THEN',
'			''<span title="Ver" style="color:#050000;" class="verDiferncias fa fa-binoculars"/>''',
'        ELSE',
'            NULL',
'    END boton1,',
'    mes_valor',
'FROM ftedata'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(119022647584879514)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>119022647584879514
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119022753851879515)
,p_db_column_name=>'BODEGA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119022803299879516)
,p_db_column_name=>'MES'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Mes'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(350337138530635159)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119022934934879517)
,p_db_column_name=>'ASOF_CANTIDAD'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Asof Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119023064883879518)
,p_db_column_name=>'ASOF_COSTO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Asof Costo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119023173308879519)
,p_db_column_name=>'KARDEX_CANTIDAD'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Kardex Cantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119023251673879520)
,p_db_column_name=>'KARDEX_COSTO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Kardex Costo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119023356200879521)
,p_db_column_name=>'DIFFCANTIDAD'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Diffcantidad'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119023411084879522)
,p_db_column_name=>'BOTON1'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'-'
,p_column_link=>'f?p=&APP_ID.:109:&SESSION.::&DEBUG.:RP,:P109_ANIO,P109_MES,P109_BODEGA,P109_GLCLS,P109_MES_PARAMETRO,P109_PRODUCTO:&P100_ANIO.,#MES_VALOR#,#BODEGA#,&P100_GLCLASS.,&P100_MES.,&P100_PRODUCTO.'
,p_column_linktext=>'#BOTON1#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119023598586879523)
,p_db_column_name=>'MES_VALOR'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Mes Valor'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(119048351672986653)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1190484'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'BODEGA:MES:ASOF_CANTIDAD:ASOF_COSTO:KARDEX_CANTIDAD:KARDEX_COSTO:BOTON1:'
,p_sort_column_1=>'BODEGA'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_sum_columns_on_break=>'ASOF_CANTIDAD:ASOF_COSTO:KARDEX_CANTIDAD:KARDEX_COSTO'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(310044948606083576)
,p_report_id=>wwv_flow_imp.id(119048351672986653)
,p_name=>'DIFERENCIA CANTIDAD'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIFFCANTIDAD'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("DIFFCANTIDAD" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#F7F37B'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(310045366390083579)
,p_report_id=>wwv_flow_imp.id(119048351672986653)
,p_name=>'DIFERENCIA COSTO'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIFFCANTIDAD'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("DIFFCANTIDAD" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#B3C8C9'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(331318058323309903)
,p_plug_name=>unistr('Documentos Electr\00F3nicos')
,p_region_name=>'tbDocElec'
,p_parent_plug_id=>wwv_flow_imp.id(348972021051859410)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20260630184406Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(385761174477263238)
,p_plug_name=>unistr('Documentos Electr\00F3nicos')
,p_region_name=>'regDocumentosElectornicos'
,p_parent_plug_id=>wwv_flow_imp.id(331318058323309903)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(112813843178917343)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id',
'	, orden',
'	, num_orden',
'	, bodega',
'	, claveacceso',
'	, estado',
'	, cliente_proveedor',
'	, numero_documento',
'	, tipo_documento',
'	, fecha_orden',
'	, fecha_factura',
'	, estado_autorizacion',
'	, batch',
'	, retencion',
'	, usuario_factura',
'	, descripcion_error',
'	, descargar',
'	, enviar',
'	, aprobar',
'	, '''' reprocesar',
'	, anular',
'	, orden_estado',
'from data.vt_finz_mesadocumetoelectronico',
'where 1 = 1',
'	and (tipo_documento = :p100_documento or :p100_documento is null)',
'	and fecha_factura between trunc(sysdate-7) and trunc(sysdate)',
'	-- and autorizado = 0',
'	-- and aprobado not in (-2)'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P100_DOCUMENTO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Mesa de trabajo'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20260630221115Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(385761183774263239)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>385761183774263239
,p_updated_on=>wwv_flow_imp.dz('20260630221115Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195191072791343703)
,p_db_column_name=>'ORDEN'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'TO'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195191447102343704)
,p_db_column_name=>'NUM_ORDEN'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>unistr('N\00FAm. Orden')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195191874335343704)
,p_db_column_name=>'BODEGA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Bodega'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195192605784343704)
,p_db_column_name=>'ESTADO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195193055750343704)
,p_db_column_name=>'CLIENTE_PROVEEDOR'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Cliente/Proveedor'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(92685403493351092)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195193417657343705)
,p_db_column_name=>'NUMERO_DOCUMENTO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>unistr('N\00FAm. Doc.')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195193861364343705)
,p_db_column_name=>'TIPO_DOCUMENTO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'TD'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195194224458343705)
,p_db_column_name=>'FECHA_ORDEN'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'F. Orden'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195195497116343706)
,p_db_column_name=>'BATCH'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Batch'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195195866944343706)
,p_db_column_name=>'RETENCION'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>unistr('Retenci\00F3n')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195196295357343706)
,p_db_column_name=>'USUARIO_FACTURA'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195195020885343706)
,p_db_column_name=>'ESTADO_AUTORIZACION'
,p_display_order=>190
,p_column_identifier=>'L'
,p_column_label=>'-'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195197030942343707)
,p_db_column_name=>'DESCARGAR'
,p_display_order=>200
,p_column_identifier=>'R'
,p_column_label=>'-'
,p_column_link=>'f?p=&APP_ID.:407:&SESSION.::&DEBUG.:RP,407:P407_TABLA,P407_ID,P407_ESTADO:T_FINZ_DOCUMENTO_ELECTRONICO,#ID#,1'
,p_column_linktext=>'#DESCARGAR#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195196684725343707)
,p_db_column_name=>'DESCRIPCION_ERROR'
,p_display_order=>210
,p_column_identifier=>'Q'
,p_column_label=>'-'
,p_column_link=>'f?p=&APP_ID.:406:&SESSION.::&DEBUG.::P406_ID:#ID#'
,p_column_linktext=>'#DESCRIPCION_ERROR#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195197489832343707)
,p_db_column_name=>'ENVIAR'
,p_display_order=>220
,p_column_identifier=>'S'
,p_column_label=>'-'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P100_ENVIARSRI'
,p_display_condition2=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(311983483576363322)
,p_db_column_name=>'REPROCESAR'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Reprocesar'
,p_column_link=>'javascript: $s("P100_TIPODOCUMENTO","");$s("P100_TIPODOCUMENTO","#TIPO_DOCUMENTO#"); $s("P100_NUMERODOCUMENTO","");$s("P100_NUMERODOCUMENTO","#NUMERO_DOCUMENTO#"); $s("P100_ACCION","");$s("P100_ACCION","APROBAR");'
,p_column_linktext=>'<span class="fa fa-cloud-download" title="Descargar Documentos" aria-hidden="true"></span>'
,p_column_type=>'STRING'
,p_display_condition_type=>'NEVER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(194810110465733935)
,p_db_column_name=>'APROBAR'
,p_display_order=>240
,p_column_identifier=>'U'
,p_column_label=>'-'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_display_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_display_condition=>'P100_APROBARSRI'
,p_display_condition2=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(195197886974343707)
,p_db_column_name=>'ID'
,p_display_order=>250
,p_column_identifier=>'T'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(311983314689363321)
,p_db_column_name=>'FECHA_FACTURA'
,p_display_order=>260
,p_column_identifier=>'V'
,p_column_label=>unistr('Fecha Emisi\00F3n')
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(331317882127309901)
,p_db_column_name=>'CLAVEACCESO'
,p_display_order=>270
,p_column_identifier=>'X'
,p_column_label=>'Clave de Acceso'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(284751150577074936)
,p_db_column_name=>'ANULAR'
,p_display_order=>280
,p_column_identifier=>'Y'
,p_column_label=>'-'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(284751952644074944)
,p_db_column_name=>'ORDEN_ESTADO'
,p_display_order=>290
,p_column_identifier=>'Z'
,p_column_label=>'Orden Estado'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(345460893870601413)
,p_application_user=>'APXWS_ALTERNATIVE'
,p_name=>'BODEGA'
,p_report_seq=>10
,p_report_alias=>'3454609'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'ID:ORDEN:NUM_ORDEN:ESTADO:CLIENTE_PROVEEDOR:CLAVEACCESO:NUMERO_DOCUMENTO:TIPO_DOCUMENTO:USUARIO_FACTURA:FECHA_FACTURA:ESTADO_AUTORIZACION:DESCRIPCION_ERROR:DESCARGAR:APROBAR:ENVIAR:'
,p_sort_column_1=>'TIPO_DOCUMENTO'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'NUMERO_DOCUMENTO'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(346785288204249453)
,p_report_id=>wwv_flow_imp.id(345460893870601413)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'NUM_ORDEN'
,p_operator=>'>'
,p_expr=>'0'
,p_condition_sql=>'"NUM_ORDEN" > to_number(#APXWS_EXPR#)'
,p_condition_display=>'#APXWS_COL_NAME# > #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(346785671600249453)
,p_report_id=>wwv_flow_imp.id(345460893870601413)
,p_condition_type=>'FILTER'
,p_allow_delete=>'Y'
,p_column_name=>'TIPO_DOCUMENTO'
,p_operator=>'in'
,p_expr=>'FE,FN,D1,GN,GE'
,p_condition_sql=>'"TIPO_DOCUMENTO" in (#APXWS_EXPR_VAL1#, #APXWS_EXPR_VAL2#, #APXWS_EXPR_VAL3#, #APXWS_EXPR_VAL4#, #APXWS_EXPR_VAL5#)'
,p_condition_display=>'#APXWS_COL_NAME# #APXWS_OP_NAME# ''FE, FN, D1, GN, GE''  '
,p_enabled=>'Y'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(390008869130079912)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1948181'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>100000
,p_report_columns=>'ESTADO_AUTORIZACION:ESTADO:ORDEN:NUM_ORDEN:TIPO_DOCUMENTO:NUMERO_DOCUMENTO:CLIENTE_PROVEEDOR:CLAVEACCESO:FECHA_FACTURA:USUARIO_FACTURA:DESCRIPCION_ERROR:DESCARGAR:APROBAR:ENVIAR:ANULAR:'
,p_sort_column_1=>'TIPO_DOCUMENTO'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'NUMERO_DOCUMENTO'
,p_sort_direction_2=>'DESC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'TIPO_DOCUMENTO'
,p_break_enabled_on=>'TIPO_DOCUMENTO'
,p_updated_on=>wwv_flow_imp.dz('20260630221114Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(339864920054312517)
,p_plug_name=>'Desbloqueo de Pagos'
,p_region_name=>'tbDesbloqueo'
,p_parent_plug_id=>wwv_flow_imp.id(348972021051859410)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    MESAFINAL.*,',
'    (SELECT PK_CORP_FLUJOAPROBACION.F_MESAICONORUTA(APROBADOR) FROM DUAL ) RUTA,',
'    (SELECT PK_CORP_FLUJOAPROBACION.F_MESAORDEN(CSS) FROM DUAL) ORDEN',
'FROM',
'    (SELECT MESA.*,(SELECT PK_CORP_FLUJOAPROBACION.F_GESTIONCOLOR(:APP_USER, APROBADOR, ETAPA, ''00001'', :APP_MODULO) FROM DUAL ) CSS',
'     FROM VT_FINZ_MESATRABAJO_BLOQUEO MESA',
'     WHERE :P100_BANDERA=0 ',
'     AND TIPO = ''SOLICITUD DE DESBLOQUEO'' AND ETAPA = ''EN_PROCESO'' AND COMPANIA = :G_COMPANIA',
'     AND (  ',
'            (:P100_ESTADO = 2 AND ( TRUNC(FECHA) BETWEEN  TRUNC(TO_DATE(:P100_FECHA_INICIO) ) AND TRUNC(TO_DATE(:P100_FECHA_FIN) ) ) )',
'         OR (:P100_ESTADO = 1 AND PK_CORP_FLUJOAPROBACION.F_APROBADORFLUJO(:APP_USER, APROBADOR, :APP_MODULO, :G_COMPANIA) = 1 )',
'         )',
'    ) MESAFINAL',
'ORDER BY ORDEN,NUMERODOCUMENTO'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_updated_on=>wwv_flow_imp.dz('20260630184406Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(339865057735312518)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'No hay datos'
,p_show_nulls_as=>'-'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'CVACA'
,p_internal_uid=>339865057735312518
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339865110684312519)
,p_db_column_name=>'COMPANIA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339865248974312520)
,p_db_column_name=>'APROBADOR'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Aprobador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339865664129312524)
,p_db_column_name=>'MONTO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339865778945312525)
,p_db_column_name=>'ORIGINADOR'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Originador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339865859395312526)
,p_db_column_name=>'FECHA'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'YYYY-MM-DD'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339865973495312527)
,p_db_column_name=>'NUMERODOCUMENTO'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'ID Proceso'
,p_column_link=>'f?p=&APP_ID.:116:&SESSION.::&DEBUG.:RP:P116_APROBADOR,P116_DOCUMENTO:#APROBADOR#,#NUMERODOCUMENTO#'
,p_column_linktext=>'<span class=''#CSS#''>Documento #NUMERODOCUMENTO#</span>'
,p_column_type=>'NUMBER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339866118666312529)
,p_db_column_name=>'ETAPA'
,p_display_order=>100
,p_column_identifier=>'K'
,p_column_label=>'Etapa'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339866292413312530)
,p_db_column_name=>'TIPO'
,p_display_order=>110
,p_column_identifier=>'L'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(340063325376719105)
,p_db_column_name=>'CSS'
,p_display_order=>120
,p_column_identifier=>'M'
,p_column_label=>'Css'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(340063426618719106)
,p_db_column_name=>'RUTA'
,p_display_order=>130
,p_column_identifier=>'N'
,p_column_label=>'-'
,p_column_link=>'f?p=100:104:&SESSION.::&DEBUG.:RP,:G_OBJETO,G_OBJETO_ID,G_TODO:RETENCION_DE_PAGO,#NUMERODOCUMENTO#,true'
,p_column_linktext=>'#RUTA#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(340063566052719107)
,p_db_column_name=>'ORDEN'
,p_display_order=>140
,p_column_identifier=>'O'
,p_column_label=>'Orden'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(339991064290612810)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3399911'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMERODOCUMENTO:FECHA:ORIGINADOR:APROBADOR:MONTO:CSS:RUTA:ORDEN'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(364562354738580110)
,p_plug_name=>'Tasas de Manufactura'
,p_region_name=>'tbTasas'
,p_parent_plug_id=>wwv_flow_imp.id(348972021051859410)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select mesafinal.*',
', (select  pk_corp_flujoaprobacion.f_mesaiconoruta(aprobador) from dual) ruta',
', (select  pk_corp_flujoaprobacion.f_mesaorden(css) from dual) orden',
', mesafinal.dominio||'':''||mesafinal.pagina||'':''||:app_session||''::NO:RP,''||mesafinal.pagina||'':''||mesafinal.param_id||'',''||mesafinal.param_aprobador||'':''||mesafinal.numerodocumento||'',''||mesafinal.aprobador enlace',
'from (',
'		select mesa.*',
'            , (select pk_corp_flujoaprobacion.f_gestioncolor(:app_user,aprobador,null,''00001'',:app_modulo) from dual) css',
'            , decode(mesa.entidad_clase,''ESTANDARESMANUFACTURA'',''1104'',''VARGASTOSMANUFACTURA'',''1106'') pagina',
'            , decode(mesa.entidad_clase,''ESTANDARESMANUFACTURA'',''P1104_ID'',''VARGASTOSMANUFACTURA'',''P1106_ID'') param_id',
'            , decode(mesa.entidad_clase,''ESTANDARESMANUFACTURA'',''P1104_APROBADOR'',''VARGASTOSMANUFACTURA'',''P1106_APROBADOR'') param_aprobador',
'		from vt_finz_mesatrabajo_tasasmanuf mesa',
'		where 1 = 1',
'			and compania = :g_compania',
'			and (',
'					(',
'						:p100_estado = 2 and fecha between :p100_fecha_inicio and :p100_fecha_fin',
'					)',
'					or ',
'					(',
'						:p100_estado = 1 and pk_corp_flujoaprobacion.f_aprobadorflujo(:app_user,aprobador,:app_modulo,:g_compania) = 1',
'					)',
'				)        ',
'			) mesafinal',
'order by orden, numerodocumento;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_updated_on=>wwv_flow_imp.dz('20260630184406Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(365063311309294632)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>365063311309294632
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(365063444582294633)
,p_db_column_name=>'NUMERODOCUMENTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'ID Proceso'
,p_column_link=>'#ENLACE#'
,p_column_linktext=>'<span class=''#CSS#''>#NUMERODOCUMENTO#</span>'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(365063676413294635)
,p_db_column_name=>'ESTADO'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(365063706403294636)
,p_db_column_name=>'ANNO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>unistr('A\00F1o')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(365063883395294637)
,p_db_column_name=>'MES'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Mes'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(365063983585294638)
,p_db_column_name=>'NUMEROVERSION'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>unistr('Versi\00F3n')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(365064198068294640)
,p_db_column_name=>'ORIGINADOR'
,p_display_order=>70
,p_column_identifier=>'H'
,p_column_label=>'Originador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(365064014147294639)
,p_db_column_name=>'APROBADOR'
,p_display_order=>80
,p_column_identifier=>'G'
,p_column_label=>'Aprobador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(365064215406294641)
,p_db_column_name=>'FECHA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(365064447439294643)
,p_db_column_name=>'RUTA'
,p_display_order=>100
,p_column_identifier=>'K'
,p_column_label=>'-'
,p_column_link=>'f?p=100:104:&SESSION.::&DEBUG.:RP:G_OBJETO,G_OBJETO_ID,G_TODO:#ENTIDAD_CLASE#,#NUMERODOCUMENTO#,TRUE'
,p_column_linktext=>'#RUTA#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(365063535378294634)
,p_db_column_name=>'COMPANIA'
,p_display_order=>110
,p_column_identifier=>'B'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(365064318253294642)
,p_db_column_name=>'CSS'
,p_display_order=>120
,p_column_identifier=>'J'
,p_column_label=>'Css'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(365064542297294644)
,p_db_column_name=>'ORDEN'
,p_display_order=>130
,p_column_identifier=>'L'
,p_column_label=>'Orden'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(400607301429760124)
,p_db_column_name=>'ENTIDAD_CLASE'
,p_display_order=>140
,p_column_identifier=>'M'
,p_column_label=>'Entidad Clase'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(400607476416760125)
,p_db_column_name=>'DOMINIO'
,p_display_order=>150
,p_column_identifier=>'N'
,p_column_label=>'Dominio'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(400607519403760126)
,p_db_column_name=>'ENLACE'
,p_display_order=>160
,p_column_identifier=>'O'
,p_column_label=>'Enlace'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(400607619812760127)
,p_db_column_name=>'PAGINA'
,p_display_order=>170
,p_column_identifier=>'P'
,p_column_label=>'Pagina'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(400607798438760128)
,p_db_column_name=>'PARAM_ID'
,p_display_order=>180
,p_column_identifier=>'Q'
,p_column_label=>'Param Id'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(400607825939760129)
,p_db_column_name=>'PARAM_APROBADOR'
,p_display_order=>190
,p_column_identifier=>'R'
,p_column_label=>'Param Aprobador'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(400609177113760142)
,p_db_column_name=>'NOMBRE'
,p_display_order=>200
,p_column_identifier=>'S'
,p_column_label=>unistr('Aprobaci\00F3n')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(365195429115034767)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3651955'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMERODOCUMENTO:NOMBRE:ESTADO:ANNO:MES:NUMEROVERSION:APROBADOR:ORIGINADOR:FECHA:RUTA:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(393681130796239004)
,p_plug_name=>'Conciliacion'
,p_region_name=>'tbConciliacion'
,p_parent_plug_id=>wwv_flow_imp.id(348972021051859410)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>70
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT mesaFinal.*',
',(SELECT  PK_CORP_FLUJOAPROBACION.F_MESAICONORUTA(APROBADOR) FROM DUAL) ruta',
',(SELECT  PK_CORP_FLUJOAPROBACION.F_MESAORDEN(CSS) FROM DUAL) orden  ',
'FROM ',
'    (',
'        SELECT ',
'            mesa.* ',
'            ,(SELECT  PK_CORP_FLUJOAPROBACION.F_GESTIONCOLOR(:APP_USER, APROBADOR, ''EN_PROCESO'', ''00001'', :APP_MODULO) FROM DUAL) CSS',
'        FROM VT_FINZ_MESATRABAJO_CONCILIACION mesa',
'        where 1=1',
'      AND TIPO LIKE ''%CONCILIACION_TRIBUTARIA%'' ',
'        --AND ETAPA = ''EN_PROCESO'' ',
'        AND compania=:G_COMPANIA ',
'		AND :P100_BANDERA=3',
'        AND (',
'                (:P100_ESTADO=2 AND  (TRUNC(FECHA) BETWEEN TRUNC(TO_DATE(:P100_FECHA_INICIO) ) AND TRUNC(TO_DATE(:P100_FECHA_FIN) ) ) )',
'            OR  (:P100_ESTADO=1 AND  (PK_CORP_FLUJOAPROBACION.F_APROBADORFLUJO(:APP_USER, APROBADOR, :APP_MODULO ,:G_COMPANIA )=1 ) )',
'            )',
'    ) mesaFinal',
'ORDER BY orden, numerodocumento'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Conciliacion'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_updated_on=>wwv_flow_imp.dz('20260630184406Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(393681212778239005)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'MALBAN'
,p_internal_uid=>393681212778239005
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(393681377311239006)
,p_db_column_name=>'NUMERODOCUMENTO'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'ID Proceso'
,p_column_link=>'f?p=&APP_ID.:155:&SESSION.::&DEBUG.::P155_IDPROCESO,P155_APROBADOR,P155_USUARIO:#NUMERODOCUMENTO#,#APROBADOR#,&APP_USER.'
,p_column_linktext=>'<span class=''#CSS#''>#NUMERODOCUMENTO#</span>'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(393681459112239007)
,p_db_column_name=>'TIPO'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(393681553467239008)
,p_db_column_name=>'COMPANIA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(393681623614239009)
,p_db_column_name=>'ESTADO'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(393681751857239010)
,p_db_column_name=>'APROBADOR'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Aprobador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(393681887052239011)
,p_db_column_name=>'ORIGINADOR'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Originador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(393681975168239012)
,p_db_column_name=>'FECHA'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(393682081434239013)
,p_db_column_name=>'CSS'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Css'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(393682129401239014)
,p_db_column_name=>'RUTA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Ruta'
,p_column_link=>'f?p=100:104:&SESSION.::&DEBUG.::G_OBJETO,G_OBJETO_ID,G_TODO:CONCILIACION_TRIBUTARIA,#NUMERODOCUMENTO#,true'
,p_column_linktext=>'#RUTA#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(393682214628239015)
,p_db_column_name=>'ORDEN'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Orden'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(397956225694974514)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3979563'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMERODOCUMENTO:ESTADO:ORIGINADOR:APROBADOR:FECHA:TIPO:RUTA:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1599615398693868725)
,p_plug_name=>'Bloqueo de Pagos'
,p_region_name=>'tbBloqueo'
,p_parent_plug_id=>wwv_flow_imp.id(348972021051859410)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT mesaFinal.*',
',(SELECT  PK_CORP_FLUJOAPROBACION.F_MESAICONORUTA(APROBADOR) FROM DUAL) ruta',
',(SELECT  PK_CORP_FLUJOAPROBACION.F_MESAORDEN(CSS) FROM DUAL) orden  ',
'FROM ',
'    (',
'        SELECT ',
'            mesa.* ',
'            ,(SELECT  PK_CORP_FLUJOAPROBACION.F_GESTIONCOLOR(:APP_USER, APROBADOR, etapa, ''00001'', :APP_MODULO) FROM DUAL) CSS',
'        FROM VT_FINZ_MESATRABAJO_BLOQUEO mesa',
'        WHERE :P100_BANDERA=0 ',
'		AND TIPO = ''SOLICITUD DE BLOQUEO'' ',
'        AND ETAPA = ''EN_PROCESO'' ',
'        AND compania=:G_COMPANIA ',
'        AND (',
'                (:P100_ESTADO=2 AND  (TRUNC(FECHA) BETWEEN TRUNC(TO_DATE(:P100_FECHA_INICIO) ) AND TRUNC(TO_DATE(:P100_FECHA_FIN) ) ) )',
'            OR  (:P100_ESTADO=1 AND  (PK_CORP_FLUJOAPROBACION.F_APROBADORFLUJO(:APP_USER, APROBADOR, :APP_MODULO ,:G_COMPANIA )=1 ) )',
'            )',
'     ) mesaFinal',
'',
'ORDER BY orden, numerodocumento',
'',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_updated_on=>wwv_flow_imp.dz('20260630184406Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(1599615411428868726)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>'No hay datos'
,p_show_nulls_as=>'-'
,p_show_actions_menu=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'DCUEVA'
,p_internal_uid=>1599615411428868726
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(338316053210934350)
,p_db_column_name=>'COMPANIA'
,p_display_order=>240
,p_column_identifier=>'BA'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(338316491627934350)
,p_db_column_name=>'APROBADOR'
,p_display_order=>260
,p_column_identifier=>'BC'
,p_column_label=>'Aprobador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(338316848111934351)
,p_db_column_name=>'CSS'
,p_display_order=>290
,p_column_identifier=>'BF'
,p_column_label=>'Css'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(338317236570934351)
,p_db_column_name=>'RUTA'
,p_display_order=>300
,p_column_identifier=>'BG'
,p_column_label=>'-'
,p_column_link=>'f?p=100:104:&SESSION.::&DEBUG.:RP,:G_OBJETO,G_OBJETO_ID,G_TODO:RETENCION_DE_PAGO,#NUMERODOCUMENTO#,true'
,p_column_linktext=>'#RUTA#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(338317613241934351)
,p_db_column_name=>'ORDEN'
,p_display_order=>310
,p_column_identifier=>'BH'
,p_column_label=>'Orden'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(338318488215934353)
,p_db_column_name=>'MONTO'
,p_display_order=>360
,p_column_identifier=>'BM'
,p_column_label=>'Monto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(338318812448934353)
,p_db_column_name=>'ORIGINADOR'
,p_display_order=>370
,p_column_identifier=>'BN'
,p_column_label=>'Originador'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(338319205112934354)
,p_db_column_name=>'FECHA'
,p_display_order=>380
,p_column_identifier=>'BO'
,p_column_label=>'Fecha'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'YYYY-MM-DD'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(337500375020323012)
,p_db_column_name=>'NUMERODOCUMENTO'
,p_display_order=>390
,p_column_identifier=>'BQ'
,p_column_label=>'ID Proceso'
,p_column_link=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.:RP:P113_APROBADOR,P113_DOCUMENTO:#APROBADOR#,#NUMERODOCUMENTO#'
,p_column_linktext=>'<span class=''#CSS#''>Documento #NUMERODOCUMENTO#</span>'
,p_column_type=>'NUMBER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339866355307312531)
,p_db_column_name=>'ETAPA'
,p_display_order=>400
,p_column_identifier=>'BS'
,p_column_label=>'Etapa'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(339866407434312532)
,p_db_column_name=>'TIPO'
,p_display_order=>410
,p_column_identifier=>'BT'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(1599721209310947021)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3383200'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUMERODOCUMENTO:FECHA:ORIGINADOR:APROBADOR:MONTO:RUTA::TIPO'
,p_sort_column_1=>'PESO'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1599336607791477717)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1599615173809868723)
,p_plug_name=>'Filtros'
,p_region_name=>'filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>50
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1652322821036946617)
,p_plug_name=>'MENSAJE'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--removeHeader:t-Region--scrollBody:t-Form--leftLabels:margin-top-none:margin-bottom-none'
,p_plug_template=>wwv_flow_imp.id(37807886111106520)
,p_plug_display_sequence=>40
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P100_MENSAJE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(119023892434879526)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1599336607791477717)
,p_button_name=>'BUSCAR_ASOF'
,p_button_static_id=>'btnBuscarAsof'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_css_classes=>'barraaccion'
,p_icon_css_classes=>'fa-search'
,p_button_cattributes=>' '
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(338313059278934345)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(1599336607791477717)
,p_button_name=>'BUSCAR'
,p_button_static_id=>'btnBuscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(292376925445702205)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(1599336607791477717)
,p_button_name=>'BUSCAR_DOC_ELECTRONICOS'
,p_button_static_id=>'btnBuscarDoce'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(292377503791702211)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(1599336607791477717)
,p_button_name=>'BUSCAR_CONCILIACION'
,p_button_static_id=>'btnConciliacion'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(307125442116577801)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(331318058323309903)
,p_button_name=>'AUTORIZARSRI'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Autorizar'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>':app_user in (''DDELACRUZ'',''GCACHIPUENDO'',''SSOCASI'',''EMASABANDA'')'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_grid_new_row=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260630184735Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(331318282431309905)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(331318058323309903)
,p_button_name=>'AUTORIZAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Autorizar masivo SRI'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'1 = 0'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_grid_new_row=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260630184735Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(344635019494857945)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(331318058323309903)
,p_button_name=>'REPROCESAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Reprocesar XML con error'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'1 = 0'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260630184735Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(362607850701005412)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(331318058323309903)
,p_button_name=>'APROBAR_MASIVO'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>unistr('Aprobaci\00F3n Automatico')
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'1 = 0'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260630184735Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(344634555184857940)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(385761174477263238)
,p_button_name=>'REPROCESAR_FACTURA'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Reprocesar Factura'
,p_button_position=>'COPY'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-file-arrow-down'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(119021481902879502)
,p_name=>'P100_ANIO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(119021399406879501)
,p_prompt=>unistr('A\00F1o')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT year D, year R FROM (select',
'to_char(sysdate, ''yyyy'') - (select trunc(months_between (sysdate, ''01/01/2020'')/12)+1 anios  from dual) + level year',
'from',
'dual',
'connect by',
'level <= (select trunc(months_between (sysdate, ''01/01/2020'')/12)+1 anios  from dual)  ',
')   A'))
,p_cHeight=>1
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(119021599685879503)
,p_name=>'P100_MES'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(119021399406879501)
,p_prompt=>'Mes'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(to_date(level, ''MM''), ''Month'') d,',
'    level                                  r',
'FROM',
'    dual',
'CONNECT BY',
'    level <= (CASE WHEN :p100_anio = to_char(to_date(sysdate), ''YYYY'') THEN to_number(to_char(to_date(sysdate), ''MM'')) ELSE 12 END)'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Todos'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(119021691542879504)
,p_name=>'P100_BODEGA'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(119021399406879501)
,p_prompt=>'Bodega'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_JDE_BODEGAS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CODUNIDAD ||'' - ''||DESCRIPCION , CODUNIDAD from vt_jde_bodegas',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Todos'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(119021741111879505)
,p_name=>'P100_GLCLASS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(119021399406879501)
,p_prompt=>'Gl Class'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_JDE_GLCLASS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select TRIM(DRKY) || '' - '' || DRDL01, DRKY ',
'from  vt_jde_udcjde where drsy=''41'' and drrt=''9'' AND DRSPHD=''ZAIMELLA  ''',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Todos'
,p_cHeight=>1
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(119021836445879506)
,p_name=>'P100_PRODUCTO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(119021399406879501)
,p_prompt=>'Producto'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  (nombreproducto) || ''  (''|| trim (CODIGOPRODUCTO) ||'') - '' ||codigocorto d, codigocorto r ',
'from vt_jde_productos',
'where  trim(nombreproducto) is not null',
'and TRIM(tipoinventario)=nvl(TRIM(:P100_GLCLASS),TRIM(tipoinventario))',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Todos'
,p_lov_cascade_parent_items=>'P100_GLCLASS'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'DIALOG'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(119021939136879507)
,p_name=>'P100_UNIDAD_MEDIDA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(119021399406879501)
,p_prompt=>'UM'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(119022556968879513)
,p_name=>'P100_BANDERA'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(119021399406879501)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(127364951476346929)
,p_name=>'P100_TIPO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(129200876701469933)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194810274917733936)
,p_name=>'P100_TIPODOCUMENTO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(129200876701469933)
,p_prompt=>'Tipodocumento'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194810348615733937)
,p_name=>'P100_NUMERODOCUMENTO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(129200876701469933)
,p_prompt=>'Numerodocumento'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194810572001733939)
,p_name=>'P100_APROBARSRI'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(129200876701469933)
,p_prompt=>'Aprobarsri'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(194810666101733940)
,p_name=>'P100_ENVIARSRI'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(129200876701469933)
,p_prompt=>'Enviarsri'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(195202113470371925)
,p_name=>'P100_ID'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(129200876701469933)
,p_prompt=>'Id'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(195202580984371927)
,p_name=>'P100_ACCION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(129200876701469933)
,p_prompt=>'Accion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(284751363446074938)
,p_name=>'P100_ESERROR'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(129200876701469933)
,p_prompt=>'Eserror'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(284751497227074939)
,p_name=>'P100_MSJERROR'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(129200876701469933)
,p_prompt=>'Msjerror'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(292377485781702210)
,p_name=>'P100_NAVEGADORTABS'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(129200876701469933)
,p_prompt=>'Navegadortabs'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(331318142885309904)
,p_name=>'P100_DOCUMENTO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(331318058323309903)
,p_prompt=>'Documento'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_UDC_TIPODOCSRI'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select descripcion, id_tabla codigo',
'from data.t_corp_udc',
'where 1 = 1',
'	and codigocompania = :g_compania',
'	and id_cabecera = ''FINZ_TDSRI''',
'	and activo = 1',
'	order by descripcion'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'TODOS'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(338313719805934346)
,p_name=>'P100_ESTADO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1599615173809868723)
,p_item_default=>'1'
,p_prompt=>'Estado'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_UDC_ESTADOMESA'
,p_lov=>'SELECT DESCRIPCION, ID_TABLA FROM T_CORP_UDC WHERE id_cabecera=''ESTADOMESA'' ORDER BY id_tabla;'
,p_cHeight=>1
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(338314127052934346)
,p_name=>'P100_FECHA_INICIO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1599615173809868723)
,p_item_default=>'to_char(sysdate-31, ''dd-mm-yyyy'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Desde: '
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(338314533898934348)
,p_name=>'P100_FECHA_FIN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(1599615173809868723)
,p_item_default=>'to_char(sysdate, ''dd-mm-yyyy'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Fecha Hasta: '
,p_display_as=>'NATIVE_DATE_PICKER'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attribute_04=>'button'
,p_attribute_05=>'N'
,p_attribute_07=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(338320789984934356)
,p_name=>'P100_MENSAJE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1652322821036946617)
,p_prompt=>'New'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(338327232326934367)
,p_name=>'Mostrar Filtros'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P100_ESTADO'
,p_condition_element=>'P100_ESTADO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(338327734421934367)
,p_event_id=>wwv_flow_imp.id(338327232326934367)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P100_FECHA_INICIO,P100_FECHA_FIN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(338328123999934368)
,p_name=>'Ocultar Filtros'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P100_ESTADO'
,p_condition_element=>'P100_ESTADO'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(338328656912934368)
,p_event_id=>wwv_flow_imp.id(338328123999934368)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P100_FECHA_INICIO,P100_FECHA_FIN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(119023646124879524)
,p_name=>'Cambia Producto'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P100_PRODUCTO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(119023724799879525)
,p_event_id=>wwv_flow_imp.id(119023646124879524)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin ',
'    select  UNIDADPRINCIPAL into :p100_unidad_medida',
'    from vt_jde_productos',
'    where  trim(nombreproducto) is not null',
'    and codigocorto= :p100_producto;',
' exception when others then',
'     :p100_unidad_medida:='''';',
' end;'))
,p_attribute_02=>'P100_PRODUCTO'
,p_attribute_03=>'P100_UNIDAD_MEDIDA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(129200928980469934)
,p_name=>'Cambio Tipo'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P100_TIPO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129201534381469940)
,p_event_id=>wwv_flow_imp.id(129200928980469934)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(1599336607791477717)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(195203025715376073)
,p_name=>'DOCUMENTOS ELECTRONICOS'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P100_ACCION'
,p_condition_element=>'P100_ACCION'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(195204409555376076)
,p_event_id=>wwv_flow_imp.id(195203025715376073)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(284751861924074943)
,p_event_id=>wwv_flow_imp.id(195203025715376073)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEst\00E1 seguro de generar la anulaci\00F3n del registro?')
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-warning'
,p_attribute_06=>unistr('S\00CD')
,p_attribute_07=>'NO'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P100_ACCION'
,p_client_condition_expression=>'ANULAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(195203489040376074)
,p_event_id=>wwv_flow_imp.id(195203025715376073)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log(new Date().toString());',
'mostrarBarra()',
'console.log("P100_ID:"+$v("P100_ID"));',
'console.log("P100_TIPODOCUMENTO:"+$v("P100_TIPODOCUMENTO"));',
'console.log("P100_NUMERODOCUMENTO:"+$v("P100_NUMERODOCUMENTO"));',
'console.log("P100_ACCION:"+$v("P100_ACCION"));',
' '))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(195203991812376076)
,p_event_id=>wwv_flow_imp.id(195203025715376073)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    if(:P100_ACCION=''ENVIAR'')THEN',
'        PK_FINZ_SRI_AUTORIZACION.sp_documento_autorizar(:P100_ID);    ',
'    ELSif(:P100_ACCION=''APROBAR'')THEN',
'        SELECT TIPODOCUMENTO,NUMERODOCUMENTO INTO :P100_TIPODOCUMENTO,:P100_NUMERODOCUMENTO ',
'        FROM t_finz_documento_electronico WHERE ID = :P100_ID;',
'        PK_FINZ_SRI_AUTORIZACION.sp_documento_jde_aprobar(:P100_TIPODOCUMENTO,:P100_NUMERODOCUMENTO,0,0);   ',
'    ELSif(:P100_ACCION=''AUTORIZAR'')THEN',
'        PK_FINZ_SRI_AUTORIZACION.sp_documento_jde_aprobar(:P100_TIPODOCUMENTO,:P100_NUMERODOCUMENTO,0,0);   ',
'     --   PK_FINZ_SRI_AUTORIZACION.sp_documento_autorizar(:P100_ID);    ',
'    ELSif(:P100_ACCION=''ANULAR'')THEN',
'        UPDATE t_finz_documento_electronico ',
'        SET ESTADO= -1 , APROBADO=-2 ',
'        WHERE ID = :P100_ID;',
'        --PK_FINZ_SRI_AUTORIZACION.sp_documento_jde_aprobar(:P100_TIPODOCUMENTO,:P100_NUMERODOCUMENTO,0,0);   ',
'     --   PK_FINZ_SRI_AUTORIZACION.sp_documento_autorizar(:P100_ID);    ',
'    END IF;',
'    :P100_ID:=NULL;',
'    :P100_ACCION:=NULL;',
'    :P100_TIPODOCUMENTO:=NULL;',
'    :P100_NUMERODOCUMENTO:=NULL;',
'    :P100_ESERROR:=0;',
'    :P100_MSJERROR:=NULL;',
'exception when others then ',
'    :P100_ESERROR:=1;',
'    :P100_MSJERROR:=sqlerrm;',
'end;',
''))
,p_attribute_02=>'P100_ACCION,P100_ID,P100_TIPODOCUMENTO,P100_NUMERODOCUMENTO'
,p_attribute_03=>'P100_ACCION,P100_ID,P100_TIPODOCUMENTO,P100_NUMERODOCUMENTO,P100_ESERROR,P100_MSJERROR'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(198204411789087904)
,p_event_id=>wwv_flow_imp.id(195203025715376073)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(385761174477263238)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(195204951266376076)
,p_event_id=>wwv_flow_imp.id(195203025715376073)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'console.log($v("P100_MSJERROR"));',
'if($v("P100_ESERROR")===''1''){',
'    mostrarErrorAPEX($v("P100_MSJERROR"), "page"); ',
'}',
'    ',
'ocultarBarra()',
'console.log(new Date().toString());'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(331318303104309906)
,p_name=>'OnChange documento'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P100_DOCUMENTO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(331318484834309907)
,p_event_id=>wwv_flow_imp.id(331318303104309906)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'null;',
'-- declare ',
'--     V_COMPANIA VARCHAR2(20):=:G_COMPANIA;',
'--     V_tipodocumento varchar2(20):=:P100_DOCUMENTO;',
'-- 	    V_FECHADESDE DATE:=TRUNC(SYSDATE-8);',
'-- 	    V_FECHAHASTA DATE:=(TRUNC(SYSDATE+1))- 1/86400;',
'-- BEGIN',
'--     pk_finz_sri_autorizacion.sp_obteter_documentos_jde(P_COMPANIA =>V_COMPANIA,p_tipodocumento =>V_tipodocumento, p_FECHADESDE =>V_FECHADESDE, p_FECHAHASTA =>V_FECHAHASTA);',
'--     COMMIT;',
'-- END;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(292377636930702212)
,p_event_id=>wwv_flow_imp.id(331318303104309906)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#btnBuscarDoce'').trigger("click");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(331318534428309908)
,p_name=>'Autorizar'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(331318282431309905)
,p_condition_element=>'P100_DOCUMENTO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(331318681632309909)
,p_event_id=>wwv_flow_imp.id(331318534428309908)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEsta seguro de enviar autorizar de forma masiva?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(331318714811309910)
,p_event_id=>wwv_flow_imp.id(331318534428309908)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'AUTORIZAR'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(344635112680857946)
,p_name=>'Reprocesar'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(344635019494857945)
,p_condition_element=>'P100_DOCUMENTO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(344635230015857947)
,p_event_id=>wwv_flow_imp.id(344635112680857946)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEsta seguro de reprocesar de forma masiva?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(344635354538857948)
,p_event_id=>wwv_flow_imp.id(344635112680857946)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'REPROCESAR'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'REPROCESAR'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(362607942937005413)
,p_name=>'Reprocesar_1'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(362607850701005412)
,p_condition_element=>'P100_DOCUMENTO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(362608075028005414)
,p_event_id=>wwv_flow_imp.id(362607942937005413)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEsta seguro de aprobar documentos financieros de forma masiva?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(362608120246005415)
,p_event_id=>wwv_flow_imp.id(362607942937005413)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'REPROCESAR'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'APROBAR_MASIVO'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(344634721549857942)
,p_name=>'reprocesar facturas'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(344634555184857940)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(344634865039857943)
,p_event_id=>wwv_flow_imp.id(344634721549857942)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEsta seguro de reprocesar facturas?')
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(344634900823857944)
,p_event_id=>wwv_flow_imp.id(344634721549857942)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'REPROCESAR_FACTURA'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(307125663347577803)
,p_name=>'Autorizar SRI'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(307125442116577801)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(307125758102577804)
,p_event_id=>wwv_flow_imp.id(307125663347577803)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('\00BFEst\00E1 seguro de realizar esta acci\00F3n?'),
unistr('Este proceso traer\00E1, aprobar\00E1 y autorizar\00E1 los documentos electr\00F3nicos.')))
,p_attribute_02=>unistr('Confirmaci\00F3n')
,p_attribute_03=>'warning'
,p_attribute_04=>'fa-head-microchip'
,p_attribute_06=>unistr('S\00ED')
,p_attribute_07=>'Cancelar'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(307125806057577805)
,p_event_id=>wwv_flow_imp.id(307125663347577803)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'APROBARAUTORIZAR'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(292377150225702207)
,p_name=>'Activar Tab'
,p_event_sequence=>120
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(348972021051859410)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'custom'
,p_bind_event_type_custom=>'atabsactivate'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(292377273103702208)
,p_event_id=>wwv_flow_imp.id(292377150225702207)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var atab = apex.region("rgMesa").widget().aTabs("getActive").href;',
'var ttab = atab.replace("SR_","") ;',
'console.log("ttab:''"+ttab+"''");',
'$s("P100_TIPO",ttab);',
'$s("P100_NAVEGADORTABS",atab);',
'$("#btnBuscarAsof").hide();',
'$("#btnBuscar").hide();',
'$("#btnBuscarDoce").hide();',
'$("#btnConciliacion").hide();',
'',
'switch(ttab) { ',
'    case ''#tbBloqueo'': 	   ',
'    case ''#tbDesbloqueo'':  ',
'    case ''#tbTasas'': 	   ',
'    case ''#tbConciliacion'':$("#filtros").show(100);break;',
'    case ''#tbAsofKadex'':   $("#filtros").hide(100);break;',
'    case ''#tbDocElec'': 	   $("#filtros").hide(100);break;',
'}',
'',
'',
'switch(ttab) { ',
'    case ''#tbBloqueo'': 	   apex.region("tbBloqueo").refresh();	 $s("P100_BANDERA",0);$(''#btnBuscar'').show();break;',
'    case ''#tbDesbloqueo'':  apex.region("tbDesbloqueo").refresh();$s("P100_BANDERA",0);$(''#btnBuscar'').show();break;',
'    case ''#tbTasas'': 	   apex.region("tbTasas").refresh();	 $s("P100_BANDERA",0);$(''#btnBuscar'').show();break;',
'    case ''#tbAsofKadex'':   apex.region("tbAsofKadex").refresh(); $s("P100_BANDERA",1);$(''#btnBuscarAsof'').show();break;',
'    case ''#tbDocElec'': 	   apex.region("tbDocElec").refresh();	 $s("P100_BANDERA",2);$(''#btnBuscarDoce'').show();break;',
'    case ''#tbConciliacion'':apex.region("tbTasas").refresh();	 $s("P100_BANDERA",3);$(''#btnConciliacion'').show();break;',
'}',
'console.log("P100_TIPO:''"+$v("P100_TIPO")+"''");',
'console.log("P100_BANDERA:''"+$v("P100_BANDERA")+"''");',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(292377343267702209)
,p_event_id=>wwv_flow_imp.id(292377150225702207)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    :g_navegadortabs := :P100_NAVEGADORTABS;',
'end;'))
,p_attribute_02=>'P100_NAVEGADORTABS'
,p_attribute_03=>'G_NAVEGADORTABS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(194810412695733938)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Setup Interface'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P100_APROBARSRI := pk_admi_gestionparametros.f_admi_accesoacciones(:app_modulo,:app_user,:app_page_id,''APROBAR_SRI'');',
':P100_ENVIARSRI  := pk_admi_gestionparametros.f_admi_accesoacciones(:app_modulo,:app_user,:app_page_id,''ENVIAR_SRI'');',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>194810412695733938
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(119024003527879528)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Setea Bandera'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P100_TIPO := ''#tbAsofKadex'';',
':P100_BANDERA := 0;',
'',
'	PK_JDE_INVENTARIO.sp_jde_consultaasof(',
'	    :P100_ANIO,',
'	    :P100_MES,',
'	    :P100_BODEGA,',
'	    :APP_USER,',
'	    :P100_GLCLASS,',
'	    :P100_PRODUCTO',
'	);',
'',
':P100_BANDERA := 1;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(119023892434879526)
,p_process_when_type=>'NEVER'
,p_internal_uid=>119024003527879528
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(292377053132702206)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ejecutar Asof'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (:P100_BANDERA=1) then',
'	PK_JDE_INVENTARIO.sp_jde_consultaasof(',
'	    :P100_ANIO,',
'	    :P100_MES,',
'	    :P100_BODEGA,',
'	    :APP_USER,',
'	    :P100_GLCLASS,',
'	    :P100_PRODUCTO',
'	);',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(119023892434879526)
,p_internal_uid=>292377053132702206
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(331318836972309911)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Autorizar masivo'
,p_process_sql_clob=>'pk_finz_sri_autorizacion.sp_documento_autorizar (p_TIPODOCUMENTO =>:P100_DOCUMENTO);'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(331318282431309905)
,p_internal_uid=>331318836972309911
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(362608259413005416)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Aprobacion automatica'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'	PK_FINZ_SRI_AUTORIZACION.SP_APROBAR_DOCUMENTOSAUTOMATICOS();',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(362607850701005412)
,p_internal_uid=>362608259413005416
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(344635497344857949)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Reprocesar documento'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Facturas que no pasaron el aprobar',
'BEGIN',
'  PK_FINZ_SRI_AUTORIZACION.SP_documentos_REPROCESAR(p_TIPODOCUMENTO =>:P100_DOCUMENTO);',
'--rollback; ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(344635019494857945)
,p_process_success_message=>unistr('Se reproceso el xml con \00E9xito')
,p_internal_uid=>344635497344857949
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(344634673034857941)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Reprocesar factura'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--Facturas que no pasaron el aprobar',
'BEGIN',
'  PK_FINZ_SRI_AUTORIZACION.SP_FACTURAS_REPROCESAR();',
'--rollback; ',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(344634555184857940)
,p_internal_uid=>344634673034857941
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(307125509342577802)
,p_process_sequence=>70
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'AprobarAutorizar'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_compania		varchar2(5);',
'v_log_app		varchar2(100);',
'v_iddocumento	number;',
'v_fecha			date;',
'begin',
'	data.pk_finanzas.sp_procesardocumentoselectronicos(:g_compania,:app_user,:p100_documento,null);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'APROBARAUTORIZAR'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>307125509342577802
);
wwv_flow_imp.component_end;
end;
/
