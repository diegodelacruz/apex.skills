prompt --application/pages/page_00310
begin
--   Manifest
--     PAGE: 00310
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>310
,p_name=>'Copiar Costos'
,p_alias=>'COPIAR-COSTOS'
,p_step_title=>'Copiar Costos'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'11'
,p_created_on=>wwv_flow_imp.dz('20231127195835Z')
,p_last_updated_on=>wwv_flow_imp.dz('20240708135423Z')
,p_last_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(94143609043582127)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(130593727747177437)
,p_plug_name=>'Copiar Costos'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37817215439106526)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(94143760992582128)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(94143609043582127)
,p_button_name=>'Copiar'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Copiar'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-copy'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(94144237266582133)
,p_name=>'New'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(94143760992582128)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_updated_on=>wwv_flow_imp.dz('20240708135423Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94144310501582134)
,p_event_id=>wwv_flow_imp.id(94144237266582133)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('Est\00E1 seguro de copiar costos?')
,p_attribute_03=>'danger'
,p_attribute_06=>'SI'
,p_attribute_07=>'NO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94144699560582137)
,p_event_id=>wwv_flow_imp.id(94144237266582133)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94144425640582135)
,p_event_id=>wwv_flow_imp.id(94144237266582133)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- borro la tabla que es una copia de la F4105',
'--raise_application_error (-20001,''Entra a este procedimiento'');',
'DELETE FROM  F564105@JDEDTADL; ',
'',
'-- COPIO los costos',
'',
'INSERT INTO F564105@JDEDTADL (C5ITM,C5LITM,C5MCU,C5LOCN,C5LOTN,C5LEDG,C5UNCS,C5CSPO,C5CSIN,C5URCD,C5URAB,C5URAT,C5URRF,C5USER,C5UPMJ,C5UPMT)',
'SELECT COITM,COLITM,COMCU,COLOCN,COLOTN,COLEDG,COUNCS,COCSPO,',
'       NVL(COCSIN,'' ''),COURCD,COURAB,COURAT,COURRF,COUSER,COUPMJ,',
'       TO_CHAR(SYSDATE,''HH24MISS'')',
'FROM F4105@JDEDTADL',
';',
'',
unistr('-- borro tabla respaldo \00FAltimo mes'),
'DELETE FROM F573002@JDEDTADL;',
'',
'-- respaldo lista de materiales vigente al momento del cierre',
'',
'INSERT INTO F573002@JDEDTADL',
'SELECT * FROM F3002@JDEDTADL',
'WHERE IXEFFT>=TO_CHAR(SYSDATE,''YYYYDDD'')-1900000;',
''))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20240708135423Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94144574818582136)
,p_event_id=>wwv_flow_imp.id(94144237266582133)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(94144757848582138)
,p_event_id=>wwv_flow_imp.id(94144237266582133)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>unistr('Datos copiados con \00E9xito.')
,p_attribute_03=>'information'
,p_updated_on=>wwv_flow_imp.dz('20231127195929Z')
,p_updated_by=>'MALBAN'
);
wwv_flow_imp.component_end;
end;
/
