prompt --application/pages/page_02012
begin
--   Manifest
--     PAGE: 02012
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>2012
,p_name=>'Reporte Gastos Directos y Distribucion'
,p_step_title=>'Reporte Gastos Directos y Distribucion'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>' $(secItems).hide();'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.t-Form-label{',
'    font-weight: bold;',
'',
'}',
'#R119025535554879543_control_panel{',
'    display: block;',
'',
'}',
'.a-IRR-controls-item--controlBreak {',
'     display: block;',
'}',
'.a-IRR-reportSummary-item--controlBreak{',
'     display: block;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20240613132707Z')
,p_last_updated_on=>wwv_flow_imp.dz('20250314201506Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(94366869691038217)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(119025535554879543)
,p_plug_name=>'Detalle'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>40
,p_plug_item_display_point=>'BELOW'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH fteacatgv AS (',
'    SELECT acayar,acames,acamcu,acaobj,acasub,acalvl1,acalvl2,acaan8,acalitm',
'        ,SUM(acagdcl + acagdpr + acagdcp) vtadirecta',
'        ,SUM(acagdst)                     vtadistribuida',
'    FROM t_aca_tgv@etldl a',
'    WHERE acalvl1 IN ( 40,10 )',
'        AND acayar = :p2012_anio',
'        -- AND acames = nvl(:p2012_mes,acames)',
'		AND (ACAMES = case when to_number(:P2012_MES)<=0 then  to_number(acames) else to_number(:P2012_MES)  end)',
'		and :p2012_bandera=1',
'    GROUP BY acayar,acames,acamcu,acaobj,acasub,acalvl1,acalvl2,acaan8,acalitm,acaan8',
'    having SUM(acagdcl + acagdpr + acagdcp)<>0',
'), fteprod AS (',
'    SELECT DISTINCT codlinea,lineanegocio,codmarca,marca,codigoproducto,codigocorto,codigoalterno,nombreproducto',
'    FROM vt_jde_productos',
'    WHERE compania = ''00001''',
'        AND TRIM(codlinea) = nvl(TRIM(:p2012_linea), TRIM(codlinea))',
'        AND TRIM(codmarca) = nvl(TRIM(:p2012_marca), TRIM(codmarca))',
'        AND codigoproducto IN ( SELECT acalitm FROM fteacatgv )',
'), ftecliente AS (',
'    SELECT DISTINCT ',
'        CODIGO codigocliente,',
'        DECODE (:P2012_CLIENTEGRUPO,1,CODIGOGRUPO,CODIGO)codigo,',
'        DECODE (:P2012_CLIENTEGRUPO,1,GRUPO,nombres)nombres,codigopais,codigocanal,canal',
'    FROM vt_jde_cliente',
'    WHERE TRIM(codigocanal) = nvl(TRIM(:p2012_canal), TRIM(codigocanal))',
'    AND codigo IN ( SELECT acaan8 FROM fteacatgv )',
'    --AND (codigo = :P2012_cliente or :P2012_cliente is null)',
')',
'SELECT acayar,acames,codigocanal,canal,codigopais,codlinea,lineanegocio,codmarca,marca,acalvl1,acamcu||''.''||acaobj||''.''|| acasub cuenta',
',codigo,nombres,SUM(vtadirecta) vtadirecta',
'    --,SUM(vtadistribuida)vtadistribuida',
'FROM fteacatgv a',
'    inner JOIN ftecliente b ON codigocliente = acaan8',
'    inner JOIN fteprod    c ON codigoproducto = acalitm',
'GROUP BY acayar,acames,codigocanal,canal,codigopais,codlinea,lineanegocio,codmarca,marca,acalvl1,acamcu||''.''||acaobj||''.''|| acasub,codigo,nombres',
'order by ACALVL1, ACAYAR, ACAMES, CODIGOCANAL, CODIGOPAIS, CODLINEA, CODMARCA, CUENTA'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P2012_ANIO,P2012_CANAL,P2012_CLIENTE,P2012_CLIENTEGRUPO,P2012_LINEA,P2012_MARCA,P2012_MES'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_updated_on=>wwv_flow_imp.dz('20250314201506Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(119025624150879544)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_textbox=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_highlight=>'N'
,p_show_chart=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'CSV:XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>119025624150879544
,p_updated_on=>wwv_flow_imp.dz('20250314201506Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119025739721879545)
,p_db_column_name=>'ACAYAR'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>unistr('A\00F1o')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119025819267879546)
,p_db_column_name=>'ACAMES'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Mes'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(350337138530635159)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119025939898879547)
,p_db_column_name=>'CANAL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Canal'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119026096975879548)
,p_db_column_name=>'CODIGOPAIS'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>unistr('Pa\00EDs')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119026190358879549)
,p_db_column_name=>'LINEANEGOCIO'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>unistr('L\00EDnea Negocio')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119026270596879550)
,p_db_column_name=>'MARCA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Marca'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119160605047559701)
,p_db_column_name=>'CUENTA'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Cuenta'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119161129999559706)
,p_db_column_name=>'VTADIRECTA'
,p_display_order=>80
,p_column_identifier=>'L'
,p_column_label=>'Venta Directa'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D009999999999999999999999999999999'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119161664093559711)
,p_db_column_name=>'ACALVL1'
,p_display_order=>100
,p_column_identifier=>'N'
,p_column_label=>'Nivel 1'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(119193859528059131)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119163221603559727)
,p_db_column_name=>'CODIGOCANAL'
,p_display_order=>120
,p_column_identifier=>'S'
,p_column_label=>'Cod. Canal'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119163398268559728)
,p_db_column_name=>'CODLINEA'
,p_display_order=>130
,p_column_identifier=>'T'
,p_column_label=>'Cod, Linea'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119163409668559729)
,p_db_column_name=>'CODMARCA'
,p_display_order=>140
,p_column_identifier=>'U'
,p_column_label=>'Cod. Marca'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200494351779509012)
,p_db_column_name=>'CODIGO'
,p_display_order=>150
,p_column_identifier=>'V'
,p_column_label=>'Codigo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(200494402400509013)
,p_db_column_name=>'NOMBRES'
,p_display_order=>160
,p_column_identifier=>'W'
,p_column_label=>'Nombres'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(119176315306564751)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1191764'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ACALVL1:ACAYAR:ACAMES:CODIGOPAIS:CODIGOCANAL:CANAL:CODLINEA:LINEANEGOCIO:CODIGO:NOMBRES:CODMARCA:MARCA:CUENTA:VTADIRECTA:'
,p_sort_column_1=>'CODIGOCANAL'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'CODIGOPAIS'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'CODLINEA'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'CODLINEA'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'CODMARCA'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'CUENTA'
,p_sort_direction_6=>'ASC'
,p_break_on=>'0:0:ACALVL1'
,p_break_enabled_on=>'0:0:ACALVL1'
,p_sum_columns_on_break=>'VTADIRECTA:VTADISTRIBUIDA'
,p_created_on=>wwv_flow_imp.dz('20240613132707Z')
,p_updated_on=>wwv_flow_imp.dz('20240613132707Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(119162688416559721)
,p_plug_name=>'Reporte'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(119162058549559715)
,p_plug_name=>'Totales'
,p_parent_plug_id=>wwv_flow_imp.id(119162688416559721)
,p_region_template_options=>'#DEFAULT#:t-Form--slimPadding:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>5
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    WITH fteacatgv AS (',
'        SELECT  acayar,acames,acamcu,acaobj,acasub,acalvl1,acalvl2,acaan8,acalitm,',
'                SUM(acagdcl + acagdpr + acagdcp) vtadirecta,',
'                SUM(acagdst)                     vtadistribuida',
'        FROM t_aca_tgv@etldl a',
'        WHERE   acalvl1 IN ( 40, 10 )',
'            AND acayar = :p2012_anio',
'			AND (ACAMES = case when to_number(:P2012_MES)<=0 then  to_number(acames) else to_number(:P2012_MES)  end)',
'            and :p2012_bandera=1',
'        GROUP BY acayar,acames,acamcu,acaobj,acasub,acalvl1,acalvl2,acaan8,acalitm',
'    ), fteprod AS (',
'        SELECT DISTINCT codlinea,lineanegocio,codmarca,marca,codigoproducto,codigocorto,codigoalterno,nombreproducto',
'        FROM vt_jde_productos',
'        WHERE compania = ''00001''',
'            AND TRIM(codlinea) = nvl(TRIM(:p2012_linea), TRIM(codlinea))',
'            AND TRIM(codmarca) = nvl(TRIM(:p2012_marca), TRIM(codmarca))',
'            AND codigoproducto IN (SELECT acalitm FROM fteacatgv)',
'    ), ftecliente AS (',
'        SELECT DISTINCT codigo,nombres,codigopais,codigocanal,canal',
'        FROM vt_jde_cliente',
'        WHERE TRIM(codigocanal) = nvl(TRIM(:p2012_canal), TRIM(codigocanal))',
'           AND codigo IN (SELECT acaan8 FROM fteacatgv )',
'    ), fteres as (',
'        select 10 acalvl1, 0 vtadirecta--, 0 vtadistribuida',
'        from dual union ',
'        select 40 acalvl1, 0 vtadirecta--, 0 vtadistribuida',
'        from dual union',
'        select acalvl1,round(sum(vtadirecta), 2)     vtadirecta',
'        -- ,round(SUM(vtadistribuida), 2) vtadistribuida',
'    FROM fteacatgv a ',
'         inner JOIN ftecliente b ON acaan8 = codigo',
'         inner join fteprod    c on acalitm = codigoproducto',
'    group by acayar, acames, acalvl1',
'    ) ',
'        select acalvl1, sum(vtadirecta) vtadirecta --, sum(VTADISTRIBUIDA)VTADISTRIBUIDA ',
'    from fteres group by acalvl1',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_updated_on=>wwv_flow_imp.dz('20250314201437Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(119162154972559716)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_show_search_bar=>'N'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'Y'
,p_owner=>'EMASABANDA'
,p_internal_uid=>119162154972559716
,p_updated_on=>wwv_flow_imp.dz('20250314201437Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119162294306559717)
,p_db_column_name=>'ACALVL1'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Nivel 1'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(119193859528059131)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(119162867591559723)
,p_db_column_name=>'VTADIRECTA'
,p_display_order=>20
,p_column_identifier=>'E'
,p_column_label=>'Total Venta Directa'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(119393536134150023)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1193936'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ACALVL1:VTADIRECTA'
,p_created_on=>wwv_flow_imp.dz('20240613132707Z')
,p_updated_on=>wwv_flow_imp.dz('20250314201320Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(119162544223559720)
,p_plug_name=>'Filtros'
,p_parent_plug_id=>wwv_flow_imp.id(119162688416559721)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(213221481134815802)
,p_plug_name=>'items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_updated_on=>wwv_flow_imp.dz('20250314194217Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(94366906036038218)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(94366869691038217)
,p_button_name=>'Buscar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
,p_updated_on=>wwv_flow_imp.dz('20250314195225Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(92532156101702147)
,p_name=>'P2012_MES'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(119162544223559720)
,p_item_default=>'to_char(trunc(sysdate),''yyyymm'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Mes'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    to_char(to_date(level, ''MM''), ''Month'') d,',
'    level                                  r',
'FROM',
'    dual',
'CONNECT BY',
'    level <= (CASE WHEN :p2012_anio = to_char(to_date(sysdate), ''YYYY'') THEN to_number(to_char(to_date(sysdate), ''MM'')) ELSE 12 END)'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_null_value=>'-1'
,p_lov_cascade_parent_items=>'P2012_ANIO'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20250314200911Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(92532361161702149)
,p_name=>'P2012_LINEA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(119162544223559720)
,p_prompt=>unistr('L\00EDnea de Negocio')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT RPAD(TRIM(DRKY), 4, '' '') ||''- '' || DRDL01 display_value, DRKY return_value ',
'  FROM  vt_jde_udc C',
'  where C.DRSY=''41'' AND C.DRRT=''S4''',
'and DRKY is not null',
'and trim(DRKY)  <> ''.'''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(92532499257702150)
,p_name=>'P2012_MARCA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(119162544223559720)
,p_prompt=>'Marca'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT RPAD(TRIM(DRKY), 4, '' '') ||''- '' || DRDL01 display_value, DRKY return_value ',
'  FROM   vt_jde_udc C',
'  where C.DRSY=''41'' AND C.DRRT=''S1''',
'and trim(DRKY) not in (''001'', ''999'')',
'order by DRKY'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20250313162240Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(94365278558038201)
,p_name=>'P2012_CANAL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(119162544223559720)
,p_prompt=>'Canal'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT RPAD(TRIM(DRKY), 4, '' '') ||''- '' || DRDL01 display_value, DRKY return_value ',
'  FROM vt_jde_udc C',
'  where DRSY =''01  ''and  DRRT=''01''',
'and trim(DRKY)<>''.'' and DRKY is not null'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(94369617658038245)
,p_name=>'P2012_BANDERA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(119162544223559720)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(119024195876879529)
,p_name=>'P2012_ANIO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(119162544223559720)
,p_prompt=>unistr('A\00F1o')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT year D, year R FROM (select',
'to_char(sysdate, ''yyyy'') - (select trunc(months_between (sysdate, ''01/01/2021'')/12)+1 anios  from dual) + level year',
'from',
'dual',
'connect by',
'level <= (select trunc(months_between (sysdate, ''01/01/2021'')/12)+1 anios  from dual)  ',
')   A'))
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20250313162104Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(213221307619815801)
,p_name=>'P2012_CLIENTEGRUPO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(119162544223559720)
,p_item_default=>'1'
,p_prompt=>'Cliente/Grupo'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:Grupo;1,Cliente;2'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'12'
,p_attribute_02=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20250313162240Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(94369770917038246)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Setear Bandera de consulta'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    :p2012_bandera := 1;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>94369770917038246
,p_updated_on=>wwv_flow_imp.dz('20250314195257Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
