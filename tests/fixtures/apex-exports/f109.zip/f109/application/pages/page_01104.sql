prompt --application/pages/page_01104
begin
--   Manifest
--     PAGE: 01104
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>1104
,p_name=>unistr('Aprobaci\00F3n de Est\00E1ndares de Manufactura')
,p_step_title=>unistr('Aprobaci\00F3n de Est\00E1ndares de Manufactura')
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#htmlDivision tr td {position: relative;}',
'#htmlDivision tr td span {',
'    position: absolute;',
'    top: -15px;',
'    left: 110px;',
'    border: 1px solid #00eef7;',
'    display: none;',
'    background: #87fff4;',
'    transition: 0.3s all ease;',
'    z-index: 9999;',
'}',
'#htmlDivision tr td:hover span {display:block;}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'17'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260320175402Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(365083944062560948)
,p_plug_name=>unistr('Aprobaci\00F3n de Est\00E1ndares de Manufactura')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37786313898106507)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(365061556956294614)
,p_plug_name=>'Contenido'
,p_region_name=>'htmlDivision'
,p_parent_plug_id=>wwv_flow_imp.id(365083944062560948)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>'select contenido from t_finz_costeocab where id = :p1104_id'
,p_plug_source_type=>'PLUGIN_CLOBREGION_OVDP'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(365061605402294615)
,p_name=>'CONTENIDO'
,p_data_type=>'CLOB'
,p_session_state_data_type=>'VARCHAR2'
,p_is_visible=>true
,p_heading=>'Contenido'
,p_display_sequence=>10
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(715455435171827382)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(365153198164269865)
,p_button_sequence=>1
,p_button_plug_id=>wwv_flow_imp.id(715455435171827382)
,p_button_name=>'CANCEL'
,p_button_static_id=>'btnAtras'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Salir'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(365061870426294617)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(715455435171827382)
,p_button_name=>'APROBAR'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Aprobar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:102:&SESSION.::&DEBUG.:RP:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID:&G_COMPANIA.,&APP_MODULO.,&APP_USER.,&APP_OBJETO_STDMNF.,&P1104_ID.'
,p_button_condition=>'P1104_FLAG'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-thumbs-up'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(365061939173294618)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(715455435171827382)
,p_button_name=>'RECHAZAR'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Rechazar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=100:103:&SESSION.::&DEBUG.:RP:G_COMPANIA,G_MODULO,G_USUARIO,G_OBJETO,G_OBJETO_ID:&G_COMPANIA.,&APP_MODULO.,&APP_USER.,&APP_OBJETO_STDMNF.,&P1104_ID.'
,p_button_condition=>'P1104_FLAG'
,p_button_condition2=>'1'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-thumbs-down'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(365086259393560953)
,p_branch_action=>'f?p=&APP_ID.:100:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(365060338283294602)
,p_name=>'P1104_APROBADOR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(365083944062560948)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(365064792230294646)
,p_name=>'P1104_FLAG'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(365083944062560948)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(365064890052294647)
,p_name=>'P1104_APROBAR_EXITO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(365083944062560948)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(365086665203560957)
,p_name=>'P1104_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(365083944062560948)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(365064993462294648)
,p_name=>'Cierre Dialogo: aprobar'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(365061870426294617)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(365065054645294649)
,p_event_id=>wwv_flow_imp.id(365064993462294648)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mostrarBarra();',
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo = trama.resultado.terminoFlujo;',
'',
'apex.item( "P1104_APROBAR_EXITO" ).setValue(0);',
'',
'if(this.data.G_EXITO == ''true''){',
'    mensaje(''exito'', this.data.G_MENSAJE);',
'    apex.item( "P1104_APROBAR_EXITO" ).setValue(1);',
'    if(isTerminoFlujo){',
'        apex.item( "P1104_APROBAR_EXITO" ).setValue(2);',
'    }',
'}',
'else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(365224308488517002)
,p_event_id=>wwv_flow_imp.id(365064993462294648)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	if :p1104_aprobar_exito = 2 then',
'		update t_finz_costeocab x set x.codigoestado = ''APROBADO'', x.codigoestadovar = ''REGISTRADO'' where id = :p1104_id;',
'	end if;',
'end;'))
,p_attribute_02=>'P1104_APROBAR_EXITO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(365511479631941905)
,p_event_id=>wwv_flow_imp.id(365064993462294648)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ocultarBarra();',
'$(''#btnAtras'').trigger("click");'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(365065194026294650)
,p_name=>'Cierre Dialogo: rechazar'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(365061939173294618)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(365224212556517001)
,p_event_id=>wwv_flow_imp.id(365065194026294650)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mostrarBarra();',
'var trama = JSON.parse(this.data.G_RESULTADO);',
'var isTerminoFlujo = trama.resultado.terminoFlujo;',
'',
'apex.item( "P1104_APROBAR_EXITO" ).setValue(0);',
'',
'if(this.data.G_EXITO == ''true''){',
'    mensaje(''exito'', this.data.G_MENSAJE);',
'    apex.item( "P1104_APROBAR_EXITO" ).setValue(1);',
'}',
'else{',
'    mensaje(''error'', this.data.G_MENSAJE);',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(365224419307517003)
,p_event_id=>wwv_flow_imp.id(365065194026294650)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'IF :P1104_APROBAR_EXITO = 1 THEN',
'    update t_finz_costeocab x set x.codigoestado = ''RECHAZADO'' where id = :p1104_id;',
'    update t_finz_costeodet x set x.estado = null where idcab = :p1104_id;',
'end if;'))
,p_attribute_02=>'P1104_APROBAR_EXITO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(365511307389941904)
,p_event_id=>wwv_flow_imp.id(365065194026294650)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'ocultarBarra();',
'$(''#btnAtras'').trigger("click");'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(365064615630294645)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :p1104_aprobador = :app_user then',
'    :p1104_flag := 1;',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>365064615630294645
);
wwv_flow_imp.component_end;
end;
/
