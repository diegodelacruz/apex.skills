prompt --application/pages/page_01128
begin
--   Manifest
--     PAGE: 01128
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>1128
,p_name=>'Prueba Departamental - Mesa de Trabajo'
,p_step_title=>'Mesa de Trabajo PD'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(".t-Button.t-Button--icon.t-Button--header.t-Button--headerTree.is-active").click();',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260427202935Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(532603707602435775)
,p_plug_name=>'Pruebas Departamentales'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id',
'	, anno',
'	, mes',
'	, fechadesde',
'	, fechahasta',
'	, estado',
'	, codusuario',
'	, codresponsable',
'	, fechaeje',
'	, idcuenta',
'from t_finz_pruebadepcab',
'where compania = :g_compania and estado != ''BORRADO''',
'and ((anno = :p1128_anno or :p1128_anno is null) and (mes <= :p1128_mes or :p1128_mes is null))',
'and (codresponsable = :p1128_codresponsable or :p1128_codresponsable is null)'))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(532603836215435775)
,p_name=>'Pruebas Departamentales'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:1130:&SESSION.::&DEBUG.:1130:P1130_ID:#ID#'
,p_detail_link_text=>'<img src="#IMAGE_PREFIX#app_ui/img/icons/apex-edit-page.png" class="apex-edit-page" alt="">'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>532603836215435775
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(532604269962435782)
,p_db_column_name=>'ID'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(532604604320435784)
,p_db_column_name=>'ESTADO'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(532605073218435784)
,p_db_column_name=>'CODUSUARIO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Usr. Ejecuta'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(532605490655435784)
,p_db_column_name=>'FECHAEJE'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>unistr('Fecha ejecuci\00F3n')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy hh24:mi'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(529454127491316924)
,p_db_column_name=>'CODRESPONSABLE'
,p_display_order=>34
,p_column_identifier=>'H'
,p_column_label=>'Usr. Responsable'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(532838944349979534)
,p_db_column_name=>'ANNO'
,p_display_order=>44
,p_column_identifier=>'I'
,p_column_label=>unistr('A\00F1o')
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(532839088459979535)
,p_db_column_name=>'MES'
,p_display_order=>54
,p_column_identifier=>'J'
,p_column_label=>'Mes'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(532839195921979536)
,p_db_column_name=>'FECHADESDE'
,p_display_order=>64
,p_column_identifier=>'K'
,p_column_label=>'Fecha desde'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(532839267880979537)
,p_db_column_name=>'FECHAHASTA'
,p_display_order=>74
,p_column_identifier=>'L'
,p_column_label=>'Fecha hasta'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(536251960269286905)
,p_db_column_name=>'IDCUENTA'
,p_display_order=>84
,p_column_identifier=>'M'
,p_column_label=>'Cuenta'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(532084568011346114)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(532618383382463957)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5326184'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ANNO:MES:IDCUENTA:CODRESPONSABLE:CODUSUARIO:ESTADO:'
,p_sort_column_1=>'ID'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164635Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(882925025170039296)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(897185280058050249)
,p_plug_name=>'Filtros'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(532619215669466896)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(882925025170039296)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Crear'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:1129:&SESSION.::&DEBUG.:1129::'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(532619628685466896)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(882925025170039296)
,p_button_name=>'BUSCAR'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Buscar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-search'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(539885768103683029)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(532603707602435775)
,p_button_name=>'REPORTE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Ver Reporte General'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:1133:&SESSION.::&DEBUG.:RP,1133::'
,p_icon_css_classes=>'fa-media-list'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(529453000316316913)
,p_name=>'P1128_CODRESPONSABLE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(897185280058050249)
,p_prompt=>'Responsable'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select distinct codresponsable d, codresponsable r from t_finz_pruebadepcab order by 1'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(532620375960470112)
,p_name=>'P1128_ANNO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(897185280058050249)
,p_prompt=>unistr('A\00F1o:')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_ANNOS'
,p_lov=>'select to_char(sysdate,''yyyy'') + (level-3) d,to_char(sysdate,''yyyy'') + (level-3) r from dual connect by level <= 4'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20241231163952Z')
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(532620742208470112)
,p_name=>'P1128_MES'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(897185280058050249)
,p_prompt=>'Mes:'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_MESES'
,p_lov=>'select to_char(to_date(level,''MM''),''Month'') d, level r from dual connect by level <= 12'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(529453454799316917)
,p_name=>'Cierra 1129'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(532619215669466896)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(529453547328316918)
,p_event_id=>wwv_flow_imp.id(529453454799316917)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(532603707602435775)
);
wwv_flow_imp.component_end;
end;
/
