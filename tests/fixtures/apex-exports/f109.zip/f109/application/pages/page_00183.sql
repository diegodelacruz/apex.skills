prompt --application/pages/page_00183
begin
--   Manifest
--     PAGE: 00183
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>183
,p_name=>'GESTION TRIBUTARIA - CONFIGURACION'
,p_alias=>'GESTION-TRIBUTARIA-CONFIGURACION'
,p_step_title=>unistr('A\00F1adir/Editar Configuraci\00F3n')
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function fn_setTabRegion(pStaticId, pShow, pTitle){',
'    var $region = $("#" + pStaticId);',
'    console.log("P183_TAB_REGION", {staticId: pStaticId, title: pTitle, show: pShow, regionExists: $region.length > 0});',
'    if (pShow) {',
'        $region.show();',
'    } else {',
'        $region.hide();',
'    }',
'    fn_setTabVisible(pStaticId, pTitle, pShow);',
'    setTimeout(function(){',
'        fn_setTabVisible(pStaticId, pTitle, pShow);',
'    }, 100);',
'}',
'',
'function fn_normalizeTabText(value){',
'    return $.trim(String(value || "")).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");',
'}',
'',
'function fn_setTabVisible(pStaticId, pTitle, pShow){',
'    var titleNorm = fn_normalizeTabText(pTitle);',
'    var $tabLink = $("a,button").filter(function(){',
'        var href = $(this).attr("href") || "";',
'        var controls = $(this).attr("aria-controls") || "";',
'        var labelNorm = fn_normalizeTabText($(this).text());',
'        return href === "#" + pStaticId || href.indexOf(pStaticId) >= 0 || controls === pStaticId || labelNorm === titleNorm;',
'    });',
'    var $tabItem = $tabLink.closest("li,.a-Tabs-item,.t-Tabs-item");',
'    if (!$tabItem.length) {',
'        $tabItem = $tabLink;',
'    }',
'    console.log("P183_TAB_VISIBLE", {staticId: pStaticId, title: pTitle, show: pShow, tabLinks: $tabLink.length, tabItems: $tabItem.length});',
'    if (pShow) {',
'        $tabItem.show();',
'    } else {',
'        $tabItem.hide();',
'    }',
'}',
'',
'function showRegion(staticId) {',
'    var $r = $("#" + staticId);',
'    console.log("P183_SHOW_REGION", {staticId: staticId, exists: $r.length > 0});',
'    if ($r.length) {',
'        $r.show();',
'    }',
'}',
'',
'function hideRegion(staticId) {',
'    var $r = $("#" + staticId);',
'    console.log("P183_HIDE_REGION", {staticId: staticId, exists: $r.length > 0});',
'    if ($r.length) {',
'        $r.hide();',
'    }',
'}',
'',
'function fn_activarPrimerTabVisible(){',
'    setTimeout(function(){',
'        var $link = $("#tabs").find("li:visible a:visible,.a-Tabs-item:visible a:visible").first();',
'        if ($link.length) {',
'            $link.trigger("click");',
'        }',
'    }, 0);',
'}',
'',
'function fn_cambioTipoobjeto(){',
'    var tipo = Number($v("P183_TIPOOBJETO"));',
'    console.log("P183_CAMBIO_TIPOOBJETO_INICIO", {id: $v("P183_ID"), tipoObjeto: $v("P183_TIPOOBJETO"), tipoNumero: tipo});',
'    $(''#P183_ERP'').closest(''.t-Form-fieldContainer'').hide();',
'    $(''#P183_ESQUEMA'').closest(''.t-Form-fieldContainer'').hide();',
'    $(''#P183_OBJETO'').closest(''.t-Form-fieldContainer'').hide();',
'    $(''#P183_JSON'').closest(''.t-Form-fieldContainer'').hide();',
'    $(''#P183_VALIDAANTERIOR'').closest(''.t-Form-fieldContainer'').hide();',
'    $(''#P183_TIENE_RESUMEN'').closest(''.t-Form-fieldContainer'').hide();',
'    $(''#P183_IDFORMULARIOSRI'').closest(''.t-Form-fieldContainer'').hide();',
'',
'    $("#btnArchivoXLS").hide();',
'    $("#btnArchivoCSV").hide();',
'    $("#btnArchivoTXT").hide();',
'    hideRegion("tabs");',
'    fn_setTabRegion("rgColumnas", false, "Columnas");',
unistr('    fn_setTabRegion("rgParametros", false, "Par\00C3\00A1metros");'),
'    fn_setTabRegion("rgCondicionesVis", false, "Condiciones Vista");',
'    fn_setTabRegion("rgCondicionesJsn", false, "Condiciones Json");',
'    fn_setTabRegion("rgValidacionesVis", false, "Validaciones Vista");',
'    fn_setTabRegion("rgValidacionesJsn", false, "Validaciones Json");',
'    if ($v("P183_ID")===""){',
'        console.log("P183_CAMBIO_TIPOOBJETO_FIN", {motivo: "sin_id"});',
'        return;',
'    }',
'',
'    if ($v("P183_TIPOOBJETO")===''001'' ){',
'        $(''#P183_ERP'').closest(''.t-Form-fieldContainer'').show();',
'        $(''#P183_ESQUEMA'').closest(''.t-Form-fieldContainer'').show();',
'        $(''#P183_OBJETO'').closest(''.t-Form-fieldContainer'').show();',
'        showRegion("tabs");',
'        fn_setTabRegion("rgColumnas", true, "Columnas");',
unistr('        fn_setTabRegion("rgParametros", true, "Par\00C3\00A1metros");'),
'        fn_setTabRegion("rgCondicionesVis", true, "Condiciones Vista");',
'        fn_setTabRegion("rgValidacionesVis", true, "Validaciones Vista");',
'        apex.region("rgColumnas").refresh();',
'        apex.region("rgParametros").refresh();',
'        apex.region("rgCondicionesVis").refresh();',
'        apex.region("rgValidacionesVis").refresh();',
'        fn_activarPrimerTabVisible();',
'        console.log("P183_CAMBIO_TIPOOBJETO_FIN", {rama: "001"});',
'    }',
'    if ($v("P183_TIPOOBJETO")===''002''){',
'        $(''#P183_VALIDAANTERIOR'').closest(''.t-Form-fieldContainer'').show();',
'        $("#btnArchivoXLS").show();',
'        showRegion("tabs");',
'        fn_setTabRegion("rgColumnas", true, "Columnas");',
'        apex.region("rgColumnas").refresh();',
'        fn_activarPrimerTabVisible();',
'        console.log("P183_CAMBIO_TIPOOBJETO_FIN", {rama: "002"});',
'    }',
'    if ($v("P183_TIPOOBJETO")===''003''){',
'        $(''#P183_VALIDAANTERIOR'').closest(''.t-Form-fieldContainer'').show();',
'        $("#btnArchivoCSV").show();',
'        showRegion("tabs");',
'        fn_setTabRegion("rgColumnas", true, "Columnas");',
'        apex.region("rgColumnas").refresh();',
'        fn_activarPrimerTabVisible();',
'        console.log("P183_CAMBIO_TIPOOBJETO_FIN", {rama: "003"});',
'    }',
'    if ($v("P183_TIPOOBJETO")===''004''){',
'        $(''#P183_VALIDAANTERIOR'').closest(''.t-Form-fieldContainer'').show();',
'        $("#btnArchivoTXT").show();',
'        showRegion("tabs");',
'        fn_setTabRegion("rgColumnas", true, "Columnas");',
'        apex.region("rgColumnas").refresh();',
'        fn_activarPrimerTabVisible();',
'        console.log("P183_CAMBIO_TIPOOBJETO_FIN", {rama: "004"});',
'    }',
'    if ($v("P183_TIPOOBJETO")===''005''){',
'        $(''#P183_IDFORMULARIOSRI'').closest(''.t-Form-fieldContainer'').show();',
'        showRegion("tabs");',
'        fn_setTabRegion("rgColumnas", true, "Columnas");',
'        apex.region("rgColumnas").refresh();',
'        fn_activarPrimerTabVisible();',
'        console.log("P183_CAMBIO_TIPOOBJETO_FIN", {rama: "005"});',
'    }',
'    if ($v("P183_TIPOOBJETO")>=''900''){',
'        $(''#P183_TIENE_RESUMEN'').closest(''.t-Form-fieldContainer'').show();',
'        $(''#P183_JSON'').closest(''.t-Form-fieldContainer'').show();',
'        showRegion("tabs");',
'        fn_setTabRegion("rgColumnas", true, "Columnas");',
unistr('        fn_setTabRegion("rgParametros", true, "Par\00C3\00A1metros");'),
'        fn_setTabRegion("rgCondicionesJsn", true, "Condiciones Json");',
'        fn_setTabRegion("rgValidacionesJsn", true, "Validaciones Json");',
'        apex.region("rgColumnas").refresh();',
'        apex.region("rgParametros").refresh();',
'        apex.region("rgCondicionesJsn").refresh();',
'        apex.region("rgValidacionesJsn").refresh();',
'        if (tipo >= 910 && tipo <= 990){',
'            $(''#P183_IDFORMULARIOSRI'').closest(''.t-Form-fieldContainer'').show();',
'            console.log("P183_RANGO_FORMULARIO_SRI", {tipoNumero: tipo, aplica: true});',
'        }',
'        fn_activarPrimerTabVisible();',
'        console.log("P183_CAMBIO_TIPOOBJETO_FIN", {rama: "900", tipoNumero: tipo});',
'    }',
'',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#secItems").hide();',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(540151210120116729)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(540151333715116730)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(540438088030603471)
,p_plug_name=>'GESTION TRIBUTARIA - CONFIGURACION'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'T_FINZ_GESTIONTRIBUTARIACFG'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(264136036002477947)
,p_plug_name=>'tabs'
,p_region_name=>'tabs'
,p_parent_plug_id=>wwv_flow_imp.id(540438088030603471)
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:t-TabsRegion-mod--fillLabels:t-TabsRegion-mod--pill:t-TabsRegion-mod--large'
,p_plug_template=>wwv_flow_imp.id(37814656137106525)
,p_plug_display_sequence=>90
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13163224539985734)
,p_plug_name=>'Condiciones'
,p_region_name=>'rgCondicionesJsn'
,p_parent_plug_id=>wwv_flow_imp.id(264136036002477947)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('    SEQ_ID,  -- ID \00FAnico de la colecci\00F3n'),
'    C001 ,',
'    C002 ,',
'    C003 ,',
'    C004 ,',
'    C005 ,',
'    C006     ',
'FROM APEX_COLLECTIONS ',
'WHERE COLLECTION_NAME = ''COLECCION_CONDICIONES'''))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(13163322814985735)
,p_max_row_count=>'1000000'
,p_allow_report_saving=>'N'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_select_columns=>'N'
,p_show_rows_per_page=>'N'
,p_show_sort=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>13163322814985735
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13163400283985736)
,p_db_column_name=>'SEQ_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Seq Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13163565508985737)
,p_db_column_name=>'C001'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>unistr('Operador L\00F3gico')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(542425739667048154)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13163622140985738)
,p_db_column_name=>'C002'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Configuracion A'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(16929366129683584)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13163764243985739)
,p_db_column_name=>'C003'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Campo'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(542425179350034424)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13163801871985740)
,p_db_column_name=>'C004'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Operador Relacional'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13163966677985741)
,p_db_column_name=>'C005'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Configuracion B'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(16929366129683584)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13164069360985742)
,p_db_column_name=>'C006'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Valor'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(13268319250902708)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'132684'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEQ_ID:C001:C002:C003:C004:C005:C006'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13871203103746221)
,p_plug_name=>'Validaciones'
,p_region_name=>'rgValidacionesJsn'
,p_parent_plug_id=>wwv_flow_imp.id(264136036002477947)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>70
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with operador as (',
'    SELECT CASE WHEN ID<=6 THEN CAMPO1 ||'' '' ELSE '''' END ||CAMPO2 d,trim(campo1) r',
'    FROM TABLE',
unistr('        (PK_COMMONS.f_split2table(''=|IGUAL\00AC<|MENOR\00AC>|MAYOR\00AC<=|MENOR IGUAL\00AC>=|MAYOR IGUAL\00AC<>|DIFERENTE\00ACIS_NULL|ES NULO\00ACIS_NOT_NULL|NO ES NULO\00ACIN|DENTRO (SEPARADO POR COMAS)\00ACNOT_IN|NO DENTRO (SEPARADO POR COMAS)\00ACBETWEEN|ENTRE\00ACNOT_BETWEEN|NO ENTRE\00ACLIKE|')
||unistr('CONTIENE\00ACNOT_LIKE|NO CONTIENE'',''|'',''\00AC'') ) A order by id'),
'), cole as (SELECT SEQ_ID,C001 ,C002 ,C003,trim(C004) C004,C005,C006,C007,C008 FROM APEX_COLLECTIONS WHERE COLLECTION_NAME = ''COLECCION_VALIDACIONES'')',
unistr('SELECT SEQ_ID,  -- ID \00FAnico de la colecci\00F3n'),
'C001 ,',
'C002 ,',
'C003,',
'o.d C004,',
'C005,',
'C006,',
'C007,',
'C008,O.D,O.R',
'FROM cole,operador o',
'where  C004 =o.r(+)',
''))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(13871323573746222)
,p_max_row_count=>'1000000'
,p_allow_report_saving=>'N'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_select_columns=>'N'
,p_show_rows_per_page=>'N'
,p_show_sort=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>13871323573746222
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13871487864746223)
,p_db_column_name=>'SEQ_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Seq Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13871521993746224)
,p_db_column_name=>'C001'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Operador Relacional'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(542425739667048154)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13871641383746225)
,p_db_column_name=>'C002'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Configuracion A'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(16929366129683584)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13871790676746226)
,p_db_column_name=>'C003'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'CAMPO A'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13871810078746227)
,p_db_column_name=>'C004'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>unistr('Operador L\00F3gico')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13871973784746228)
,p_db_column_name=>'C005'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Configuracion B'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(16929366129683584)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13872024990746229)
,p_db_column_name=>'C006'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'CAMPO B'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13872195140746230)
,p_db_column_name=>'C007'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Error'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(555182144916921250)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(13872220790746231)
,p_db_column_name=>'C008'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Advertencia'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(555182144916921250)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(58701638629752234)
,p_db_column_name=>'D'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'D'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(58701791764752235)
,p_db_column_name=>'R'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'R'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(16153336635774952)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'161534'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEQ_ID:C001:C002:C003:C004:C005:C006:C007:C008'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(540152406828116741)
,p_plug_name=>'Columnas'
,p_region_name=>'rgColumnas'
,p_parent_plug_id=>wwv_flow_imp.id(264136036002477947)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('    SEQ_ID,  -- ID \00FAnico de la colecci\00F3n'),
'    C001, ',
'    C002, ',
'    ''<span class="fa ''||decode(C003,''Y'',''fa-check-square'',''fa-square-o'')||''" aria-hidden="true"></span>''C003, ',
'    --C003,',
'    CASE C004 ',
'    WHEN ''T'' then ''Texto''',
'    WHEN ''N'' then ''Numero''',
'    WHEN ''D'' then ''Decimal''',
'    WHEN ''M'' then ''Moneda''',
'    WHEN ''F'' then ''Fecha''',
'    end C004,',
'    ''<span class="fa ''||decode(C005,''Y'',''fa-check-square'',''fa-square-o'')||''" aria-hidden="true"></span>''C005,',
'    ''<span class="fa ''||decode(C006,''Y'',''fa-check-square'',''fa-square-o'')||''" aria-hidden="true"></span>''C006,',
'    ''<span class="fa ''||decode(C007,''Y'',''fa-check-square'',''fa-square-o'')||''" aria-hidden="true"></span>''C007,',
'    ''<span class="fa ''||decode(C008,''Y'',''fa-check-square'',''fa-square-o'')||''" aria-hidden="true"></span>''C008',
'FROM APEX_COLLECTIONS ',
'WHERE COLLECTION_NAME = ''COLECCION_COLUMNAS''',
' order by SEQ_ID'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Columnas'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(543460019417406629)
,p_max_row_count=>'1000000'
,p_max_rows_per_page=>'1000'
,p_allow_report_saving=>'N'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_select_columns=>'N'
,p_show_rows_per_page=>'N'
,p_show_sort=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>543460019417406629
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(543460131839406630)
,p_db_column_name=>'SEQ_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Seq Id'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(554594566371141606)
,p_db_column_name=>'C001'
,p_display_order=>20
,p_column_identifier=>'D'
,p_column_label=>'Columna/Campo'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(554594662633141607)
,p_db_column_name=>'C002'
,p_display_order=>30
,p_column_identifier=>'E'
,p_column_label=>'Alias'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(581863083919074744)
,p_db_column_name=>'C003'
,p_display_order=>40
,p_column_identifier=>'F'
,p_column_label=>'<span class="fa fa-eye" title="Visualizar" aria-hidden="true"></span>'
,p_alternative_label=>'Visualizar'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(581863191029074745)
,p_db_column_name=>'C004'
,p_display_order=>50
,p_column_identifier=>'G'
,p_column_label=>'Tipo Dato'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(183184008000000001)
,p_db_column_name=>'C008'
,p_display_order=>60
,p_column_identifier=>'K'
,p_column_label=>'<span aria-hidden="true" title="PK JSON" class="fa fa-key"></span>'
,p_alternative_label=>'PK JSON'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(42164941132330510)
,p_db_column_name=>'C005'
,p_display_order=>70
,p_column_identifier=>'H'
,p_column_label=>'<span aria-hidden="true" title="Editable" class="fa fa-pencil-square-o"></span>'
,p_alternative_label=>'Editable'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43067628467983324)
,p_db_column_name=>'C006'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'<span aria-hidden="true" title="Qry Resultado" class="fa fa-file-sql-o"></span>'
,p_alternative_label=>'Qry Resultado'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45214509608289119)
,p_db_column_name=>'C007'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'<span aria-hidden="true" title="Calculado" class="fa fa-calculator"></span>'
,p_alternative_label=>'Calculado'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(544819472400597654)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5448195'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>1000
,p_report_columns=>'C001:C002:C004:C008:C005:C003:C007:C006:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(540152518510116742)
,p_plug_name=>'Condiciones'
,p_region_name=>'rgCondicionesVis'
,p_parent_plug_id=>wwv_flow_imp.id(264136036002477947)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('    SEQ_ID,  -- ID \00FAnico de la colecci\00F3n'),
'    C001 ,',
'    C002 ,',
'    C003 ,',
'    C004     ',
'FROM APEX_COLLECTIONS ',
'WHERE COLLECTION_NAME = ''COLECCION_CONDICIONES'''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Condiciones'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(543460446578406633)
,p_max_row_count=>'1000000'
,p_allow_report_saving=>'N'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_select_columns=>'N'
,p_show_rows_per_page=>'N'
,p_show_sort=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>543460446578406633
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(543460547019406634)
,p_db_column_name=>'SEQ_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Seq Id'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(549654752772944702)
,p_db_column_name=>'C001'
,p_display_order=>20
,p_column_identifier=>'J'
,p_column_label=>unistr('Operador L\00F3gico')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(542425739667048154)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(549654831136944703)
,p_db_column_name=>'C002'
,p_display_order=>30
,p_column_identifier=>'K'
,p_column_label=>'Columna'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(549654990749944704)
,p_db_column_name=>'C003'
,p_display_order=>40
,p_column_identifier=>'L'
,p_column_label=>'Operador Relacional'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(542425179350034424)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(549655011095944705)
,p_db_column_name=>'C004'
,p_display_order=>50
,p_column_identifier=>'M'
,p_column_label=>'Valor'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(544833356694651716)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5448334'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'C001:C002:C003:C004'
,p_sort_column_1=>'SEQ_ID'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(545174176202787413)
,p_plug_name=>unistr('Par\00E1metros')
,p_region_name=>'rgParametros'
,p_parent_plug_id=>wwv_flow_imp.id(264136036002477947)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('    SEQ_ID,  -- ID \00FAnico de la colecci\00F3n'),
'    C001,',
'    C002,',
'    C003',
'FROM APEX_COLLECTIONS ',
'WHERE COLLECTION_NAME = ''COLECCION_PARAMETROS'''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Parametros'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(545174202894787414)
,p_max_row_count=>'1000000'
,p_allow_report_saving=>'N'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_select_columns=>'N'
,p_show_rows_per_page=>'N'
,p_show_sort=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>545174202894787414
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(545174341030787415)
,p_db_column_name=>'SEQ_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Seq Id'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(545175178794787423)
,p_db_column_name=>'C001'
,p_display_order=>20
,p_column_identifier=>'I'
,p_column_label=>unistr('Nombre Par\00E1metro')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(545175246955787424)
,p_db_column_name=>'C002'
,p_display_order=>30
,p_column_identifier=>'J'
,p_column_label=>'Valor 1'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(545175388341787425)
,p_db_column_name=>'C003'
,p_display_order=>40
,p_column_identifier=>'K'
,p_column_label=>'Valor 2'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(545596539118118268)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5455966'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'C001:C002:C003:'
,p_sort_column_1=>'SEQ_ID'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(550997735117588449)
,p_plug_name=>'Validaciones'
,p_region_name=>'rgValidacionesVis'
,p_parent_plug_id=>wwv_flow_imp.id(264136036002477947)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>60
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with operador as (',
'    SELECT CASE WHEN ID<=6 THEN CAMPO1 ||'' '' ELSE '''' END ||CAMPO2 d,trim(campo1) r',
'    FROM TABLE',
unistr('        (PK_COMMONS.f_split2table(''=|IGUAL\00AC<|MENOR\00AC>|MAYOR\00AC<=|MENOR IGUAL\00AC>=|MAYOR IGUAL\00AC<>|DIFERENTE\00ACIS_NULL|ES NULO\00ACIS_NOT_NULL|NO ES NULO\00ACIN|DENTRO (SEPARADO POR COMAS)\00ACNOT_IN|NO DENTRO (SEPARADO POR COMAS)\00ACBETWEEN|ENTRE\00ACNOT_BETWEEN|NO ENTRE\00ACLIKE|')
||unistr('CONTIENE\00ACNOT_LIKE|NO CONTIENE'',''|'',''\00AC'') ) A order by id'),
'), cole as (SELECT SEQ_ID,C001 ,C002 ,C003,trim(C004) C004,C005,C006,C007,C008 FROM APEX_COLLECTIONS WHERE COLLECTION_NAME = ''COLECCION_VALIDACIONES'')',
unistr('SELECT SEQ_ID,  -- ID \00FAnico de la colecci\00F3n'),
'C001 ,',
'C002 ,',
'o.d C003,',
'C004,',
'C005,',
'C006',
'FROM cole,operador o',
'where  C003 =o.r(+)'))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(550997856723588450)
,p_max_row_count=>'1000000'
,p_allow_report_saving=>'N'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_select_columns=>'N'
,p_show_rows_per_page=>'N'
,p_show_sort=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>550997856723588450
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(554594048116141601)
,p_db_column_name=>'SEQ_ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Seq Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(554594146067141602)
,p_db_column_name=>'C001'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Operador Relacional'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(542425739667048154)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(554594203866141603)
,p_db_column_name=>'C002'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Columna'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(554594361115141604)
,p_db_column_name=>'C003'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Operador Relacional'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(542425179350034424)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(554595795814141618)
,p_db_column_name=>'C004'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Valor'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(554595853566141619)
,p_db_column_name=>'C005'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Error'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(555182144916921250)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(554595905018141620)
,p_db_column_name=>'C006'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Advertencia'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(555182144916921250)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(554601088635149734)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'5546011'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SEQ_ID:C001:C002:C003:C004:C005:C006:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(540152397761116740)
,p_plug_name=>unistr('Configuraci\00F3n')
,p_parent_plug_id=>wwv_flow_imp.id(540438088030603471)
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(37807886111106520)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(540451100427603489)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(540151333715116730)
,p_button_name=>'Atras'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Atras'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:180:&SESSION.::&DEBUG.:180::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(540451795583603490)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(540151333715116730)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Eliminar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_confirm_message=>unistr('\00BFDesea realizar esta acci\00F3n de eliminar?')
,p_confirm_style=>'danger'
,p_button_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id from T_FINZ_GESTIONTRIBUTARIACFG cfg',
'where id=:P183_ID ',
'and not exists (SELECT distinct 1  FROM  t_finz_gestiontributariadatos DAT where (DAT.idcfg = cfg.id));'))
,p_button_condition_type=>'EXISTS'
,p_icon_css_classes=>'fa-trash'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(540452526141603490)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(540151333715116730)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P183_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_icon_css_classes=>'fa-save-as'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(50248335515209230)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(540151333715116730)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P183_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-save-as'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(540452103578603490)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(540151333715116730)
,p_button_name=>'SAVE_EXIT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Guardar y Salir'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P183_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11930796481404225)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_imp.id(540152397761116740)
,p_button_name=>'ARCHIVO_EXCEL'
,p_button_static_id=>'btnArchivoXLS'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#:t-Button--small:t-Button--success:t-Button--link:t-Button--iconLeft:t-Button--pillStart:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(37860234333106559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Estructura Excel'
,p_button_redirect_url=>'f?p=109:193:&SESSION.::&DEBUG.:RR,193:G_VALOR1,G_VALOR2:0,1'
,p_button_css_classes=>'t-Button t-Button--primary t-Button--small'
,p_icon_css_classes=>'fa-file-json-o'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12388049354717846)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_imp.id(540152397761116740)
,p_button_name=>'ARCHIVO_CSV'
,p_button_static_id=>'btnArchivoCSV'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#:t-Button--small:t-Button--success:t-Button--link:t-Button--iconLeft:t-Button--pillStart:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(37860234333106559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Estructura CSV'
,p_button_redirect_url=>'f?p=109:193:&SESSION.::&DEBUG.:RR,300:G_VALOR1,G_VALOR2,G_VALOR3:0,2,pco'
,p_button_css_classes=>'t-Button t-Button--primary t-Button--small'
,p_icon_css_classes=>'fa-file-json-o'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(34443350652782316)
,p_button_sequence=>130
,p_button_plug_id=>wwv_flow_imp.id(540152397761116740)
,p_button_name=>'ARCHIVO_TXT'
,p_button_static_id=>'btnArchivoTXT'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#:t-Button--small:t-Button--success:t-Button--link:t-Button--iconLeft:t-Button--pillStart:t-Button--padBottom'
,p_button_template_id=>wwv_flow_imp.id(37860234333106559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Estructura TXT'
,p_button_redirect_url=>'f?p=109:193:&SESSION.::&DEBUG.:RR,193:G_VALOR1,G_VALOR2,G_VALOR3:0,2,tab'
,p_button_css_classes=>'t-Button t-Button--primary t-Button--small'
,p_icon_css_classes=>'fa-file-text-o'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(541027549130436816)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(540152518510116742)
,p_button_name=>'ADD_CONDS_001'
,p_button_static_id=>'btnCondiciones'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Agregar/Editar Condiciones'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:185:&SESSION.::&DEBUG.:RR,185::'
,p_button_condition=>'P183_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-pencil-square-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13160573086985707)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(13163224539985734)
,p_button_name=>'ADD_CONDS_999'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Agregar/Editar Condiciones'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:191:&SESSION.::&DEBUG.:RR,191:P191_IDPROCESO:&P183_IDPROCESO.'
,p_button_condition=>'P183_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-pencil-square-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(540152789076116744)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(540152406828116741)
,p_button_name=>'ADD_COLS'
,p_button_static_id=>'btnColumnas'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Agregar/Editar Columnas'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:184:&SESSION.::&DEBUG.:RR,184:P184_TIPOOBJETO:&P183_TIPOOBJETO.'
,p_button_condition=>'P183_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-pencil-square-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(540590446537045006)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(545174176202787413)
,p_button_name=>'ADD_PARAMS'
,p_button_static_id=>'btnParametros'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Agregar/Editar Parametros'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:186:&SESSION.::&DEBUG.:RR,186::'
,p_button_condition=>'P183_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-pencil-square-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(554594818368141609)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(550997735117588449)
,p_button_name=>'ADD_VALID_001'
,p_button_static_id=>'btnValidaciones'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Agregar/Editar Validaciones'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:189:&SESSION.::&DEBUG.:RR,189::'
,p_button_condition=>'P183_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-pencil-square-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13872664224746235)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(13871203103746221)
,p_button_name=>'ADD_VALID_999'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Agregar/Editar Validaciones'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:192:&SESSION.::&DEBUG.:RR,192:P192_IDPROCESO:&P183_IDPROCESO.'
,p_button_condition=>'P183_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-pencil-square-o'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(545175430653787426)
,p_branch_name=>'Go To Page 180'
,p_branch_action=>'f?p=&APP_ID.:180:&SESSION.::&DEBUG.:RR,180::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(540451795583603490)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(50248278621209229)
,p_branch_name=>'Go To Page 180'
,p_branch_action=>'f?p=&APP_ID.:180:&SESSION.::&DEBUG.:RR,180::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(540452103578603490)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11930522739404223)
,p_name=>'P183_JSON'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(540152397761116740)
,p_prompt=>'Objeto'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with ',
'      tob as ( SELECT id_tabla tob_id, descripcion tob_descripcion FROM DATA.T_CORP_UDC WHERE activo=''1'' and id_cabecera = ''FINZ_GT02'' AND id_tabla != ''000'' )',
'    , tpr as ( SELECT id_tabla tpr_id, descripcion tpr_descripcion FROM DATA.T_CORP_UDC WHERE activo=''1'' and id_cabecera = ''FINZ_GT01'' AND id_tabla != ''000'' )',
'SELECT cfg.descripcion ||'' (''||PK_FINZ_GESTIONTRIBUTARIA.F_OBTENER_ALIAS_JSON(cfg.ID) ||'')'' cfg_descripcion,cfg.id idcfg',
'FROM t_finz_gestiontributariacfg cfg',
'INNER JOIN tob ON tob_id = cfg.tipoobjeto',
'INNER JOIN tpr ON tpr_id = cfg.idproceso',
'WHERE cfg.compania = :G_COMPANIA',
'and cfg.id!=:P183_ID',
'-- and ( ',
'--             (:P183_TIPOOBJETO>=991) ',
'--         OR ',
'--             (:P183_TIPOOBJETO<991 AND tpr_id  in (:P183_IDPROCESO, ''999'') ) ',
'--     )',
'and cfg.columnas is not null',
'and cfg.estado=1',
''))
,p_lov_cascade_parent_items=>'P183_ID,P183_IDPROCESO'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>5
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'ALL'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13873697420746245)
,p_name=>'P183_EDITAR'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(540151210120116729)
,p_prompt=>'Editar'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(29612787005218704)
,p_name=>'P183_LOADPAGE'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(540151210120116729)
,p_prompt=>'Editar'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(45214631346289120)
,p_name=>'P183_IDENTIFICADOR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(540152397761116740)
,p_prompt=>'Identificador'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>1
,p_display_when=>'P183_ID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(50249132773209238)
,p_name=>'P183_TIENE_RESUMEN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(540152397761116740)
,p_item_source_plug_id=>wwv_flow_imp.id(540438088030603471)
,p_item_default=>'SELECT ''N'' FROM DUAL'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Tiene Resumen'
,p_source=>'TIENE_RESUMEN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'Y'
,p_attribute_03=>unistr('S\00CD')
,p_attribute_04=>'N'
,p_attribute_05=>'NO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57499268776306250)
,p_name=>'P183_VALIDAANTERIOR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(540152397761116740)
,p_item_source_plug_id=>wwv_flow_imp.id(540438088030603471)
,p_item_default=>'SELECT ''N'' FROM DUAL'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Valida con Anterior'
,p_source=>'VALIDAANTERIOR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_grid_label_column_span=>1
,p_read_only_when=>':P183_TIPOOBJETO IN (''001'',''005'') OR :P183_TIPOOBJETO LIKE''9%'''
,p_read_only_when2=>'PLSQL'
,p_read_only_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'Y'
,p_attribute_03=>unistr('S\00CD')
,p_attribute_04=>'N'
,p_attribute_05=>'NO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57499268776306251)
,p_name=>'P183_PERSISTE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(540152397761116740)
,p_item_source_plug_id=>wwv_flow_imp.id(540438088030603471)
,p_item_default=>'SELECT ''N'' FROM DUAL'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Persiste'
,p_source=>'PERSISTE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'S'
,p_attribute_03=>unistr('S\00CD')
,p_attribute_04=>'N'
,p_attribute_05=>'NO'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(125467024581948905)
,p_name=>'P183_IDFORMULARIOSRI'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(540152397761116740)
,p_item_source_plug_id=>wwv_flow_imp.id(540438088030603471)
,p_prompt=>'Formulario SRI'
,p_source=>'IDFORMULARIOSRI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_lov=>'SELECT DESCRIPCION, VALOR FROM DATA.T_CORP_UDC WHERE ID_CABECERA=''FINZ_GT11'' and id_tabla!=''000'';'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'1'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540151508526116732)
,p_name=>'P183_ERP_SEL'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(540151210120116729)
,p_prompt=>'Erp Sel'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540151605138116733)
,p_name=>'P183_ESQUEMA_SEL'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(540151210120116729)
,p_prompt=>'Esquema Sel'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540151746868116734)
,p_name=>'P183_CONEXION_SEL'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(540151210120116729)
,p_prompt=>'Conexion Sel'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540438474131603473)
,p_name=>'P183_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(540151210120116729)
,p_item_source_plug_id=>wwv_flow_imp.id(540438088030603471)
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540438817152603477)
,p_name=>'P183_USERCREA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(540151210120116729)
,p_item_source_plug_id=>wwv_flow_imp.id(540438088030603471)
,p_prompt=>'Usercrea'
,p_source=>'USERCREA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>25
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540439299185603479)
,p_name=>'P183_FECHCREA'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(540151210120116729)
,p_item_source_plug_id=>wwv_flow_imp.id(540438088030603471)
,p_prompt=>'Fechcrea'
,p_source=>'FECHCREA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540440071627603481)
,p_name=>'P183_USERMODI'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(540151210120116729)
,p_item_source_plug_id=>wwv_flow_imp.id(540438088030603471)
,p_prompt=>'Usermodi'
,p_source=>'USERMODI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>25
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540440421860603482)
,p_name=>'P183_FECHMODI'
,p_source_data_type=>'TIMESTAMP'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(540151210120116729)
,p_item_source_plug_id=>wwv_flow_imp.id(540438088030603471)
,p_prompt=>'Fechmodi'
,p_source=>'FECHMODI'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'null'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540441227440603482)
,p_name=>'P183_COMPANIA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(540151210120116729)
,p_item_source_plug_id=>wwv_flow_imp.id(540438088030603471)
,p_prompt=>'Compania'
,p_source=>'COMPANIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>5
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540441665954603482)
,p_name=>'P183_IDPROCESO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(540152397761116740)
,p_item_source_plug_id=>wwv_flow_imp.id(540438088030603471)
,p_prompt=>'Actividad'
,p_source=>'IDPROCESO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FINZ_GTACTIVIDADES'
,p_lov=>'SELECT ID_TABLA||'' - ''||DESCRIPCION DESCRIPCION,ID_TABLA FROM "DATA"."T_CORP_UDC" WHERE ID_CABECERA=''FINZ_GT01'' AND ID_TABLA!=''000''  AND ACTIVO=''1'' ORDER BY TO_NUMBER(VALOR3);'
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_grid_label_column_span=>1
,p_read_only_when=>'P183_EDITAR'
,p_read_only_when2=>'0'
,p_read_only_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540442019710603482)
,p_name=>'P183_ALMACENAMIENTO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(540152397761116740)
,p_item_source_plug_id=>wwv_flow_imp.id(540438088030603471)
,p_prompt=>'Almacenamiento'
,p_source=>'ALMACENAMIENTO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_YES_NO'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'S'
,p_attribute_03=>'Fijo'
,p_attribute_04=>'I'
,p_attribute_05=>'Incremental'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540442447021603482)
,p_name=>'P183_DESCRIPCION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(540152397761116740)
,p_item_source_plug_id=>wwv_flow_imp.id(540438088030603471)
,p_prompt=>unistr('Descripci\00F3n')
,p_source=>'DESCRIPCION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>60
,p_cMaxlength=>500
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540442816808603483)
,p_name=>'P183_ESTADO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(540152397761116740)
,p_item_source_plug_id=>wwv_flow_imp.id(540438088030603471)
,p_prompt=>'Estado'
,p_source=>'ESTADO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'LOV_ESTADO'
,p_lov=>'.'||wwv_flow_imp.id(103334473958064327)||'.'
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'2'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540443224664603484)
,p_name=>'P183_TIPOOBJETO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(540152397761116740)
,p_item_source_plug_id=>wwv_flow_imp.id(540438088030603471)
,p_prompt=>'Tipo Objeto'
,p_source=>'TIPOOBJETO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with udc as (',
'SELECT DESCRIPCION,ID_TABLA  FROM "DATA"."T_CORP_UDC" ',
'WHERE ID_CABECERA=''FINZ_GT02'' AND ID_TABLA not in(''000'')  AND ACTIVO=''1''  ',
')',
',cruce as (',
'SELECT DESCRIPCION,ID_TABLA  FROM "DATA"."T_CORP_UDC" ',
'WHERE ID_CABECERA=''FINZ_GT02'' AND ID_TABLA =''999''  AND ACTIVO=''1''  ',
'AND exists (SELECT 1 FROM DATA.t_finz_gestiontributariacfg where IDPROCESO =:P183_IDPROCESO and columnas is not null having count(1)>1)',
'and :P183_IDPROCESO is not null and  :P183_DESCRIPCION not like ''%(COPIA -%''',
'',
')',
'SELECT * FROM UDC UNION ALL',
'SELECT * FROM cruce',
'order by 2 '))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540443644646603484)
,p_name=>'P183_ERP'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(540152397761116740)
,p_item_source_plug_id=>wwv_flow_imp.id(540438088030603471)
,p_prompt=>'Erp'
,p_source=>'ERP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_FINZ_GTERP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION,ID_TABLA FROM "DATA"."T_CORP_UDC" ',
'WHERE ID_CABECERA=''FINZ_GT03'' AND ID_TABLA!=''000'' AND ACTIVO=''1''  order by to_number(ID_TABLA);',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540444051208603484)
,p_name=>'P183_ESQUEMA'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(540152397761116740)
,p_item_source_plug_id=>wwv_flow_imp.id(540438088030603471)
,p_prompt=>'Esquema'
,p_source=>'ESQUEMA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT DESCRIPCION,ID_TABLA FROM "DATA"."T_CORP_UDC" ',
'WHERE ID_CABECERA=''FINZ_GT04'' AND ID_TABLA!=''000''  AND ACTIVO=''1''  AND VALOR2=:P183_ERP order by to_number(ID_TABLA);',
''))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_lov_cascade_parent_items=>'P183_ERP'
,p_ajax_items_to_submit=>'P183_ERP'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540444448600603484)
,p_name=>'P183_OBJETO'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(540152397761116740)
,p_item_source_plug_id=>wwv_flow_imp.id(540438088030603471)
,p_prompt=>'Objeto'
,p_source=>'OBJETO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DISTINCT TABLE_NAME d, TABLE_NAME r  from ALL_TABLES@jdedtadl WHERE OWNER=:P183_ESQUEMA_SEL AND :P183_ERP_SEL=''JDE'' UNION ALL',
'select DISTINCT VIEW_NAME  d, VIEW_NAME  r  from ALL_VIEWS@jdedtadl  WHERE OWNER=:P183_ESQUEMA_SEL AND :P183_ERP_SEL=''JDE''UNION ALL',
'select DISTINCT TABLE_NAME d, TABLE_NAME r  from ALL_TABLES          WHERE OWNER=:P183_ESQUEMA_SEL AND :P183_ERP_SEL=''APEX'' UNION ALL',
'select DISTINCT VIEW_NAME  d, VIEW_NAME  r  from ALL_VIEWS           WHERE OWNER=:P183_ESQUEMA_SEL AND :P183_ERP_SEL=''APEX'';'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P183_ESQUEMA_SEL,P183_ERP_SEL'
,p_ajax_items_to_submit=>'P183_ESQUEMA_SEL,P183_ERP_SEL'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_label_column_span=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'Y'
,p_attribute_05=>'N'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540444867939603484)
,p_name=>'P183_COLUMNAS'
,p_source_data_type=>'CLOB'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(540151210120116729)
,p_item_source_plug_id=>wwv_flow_imp.id(540438088030603471)
,p_prompt=>'Columnas'
,p_placeholder=>'Columas de tablas a ser visualizadas'
,p_source=>'COLUMNAS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_css_classes=>'custom-border'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(540445204612603485)
,p_name=>'P183_CONDICIONES'
,p_source_data_type=>'CLOB'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(540151210120116729)
,p_item_source_plug_id=>wwv_flow_imp.id(540438088030603471)
,p_prompt=>'Condiciones'
,p_source=>'CONDICIONES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(546799225376499539)
,p_name=>'P183_PARAMETROS'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(540151210120116729)
,p_item_source_plug_id=>wwv_flow_imp.id(540438088030603471)
,p_prompt=>'Parametros'
,p_source=>'PARAMETROS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(550997674387588448)
,p_name=>'P183_VALIDACIONES'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(540151210120116729)
,p_item_source_plug_id=>wwv_flow_imp.id(540438088030603471)
,p_prompt=>'Validaciones'
,p_source=>'VALIDACIONES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_03=>'N'
,p_attribute_04=>'BOTH'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(540439782008603481)
,p_validation_name=>'P183_FECHCREA must be timestamp'
,p_validation_sequence=>20
,p_validation=>'P183_FECHCREA'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>'#LABEL# must be a valid timestamp.'
,p_associated_item=>wwv_flow_imp.id(540439299185603479)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(540440977449603482)
,p_validation_name=>'P183_FECHMODI must be timestamp'
,p_validation_sequence=>40
,p_validation=>'P183_FECHMODI'
,p_validation_type=>'ITEM_IS_TIMESTAMP'
,p_error_message=>'#LABEL# must be a valid timestamp.'
,p_associated_item=>wwv_flow_imp.id(540440421860603482)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(34442712870782310)
,p_name=>'CAMBIO TIPO OBJETO'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P183_TIPOOBJETO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34442805639782311)
,p_event_id=>wwv_flow_imp.id(34442712870782310)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>' fn_cambioTipoobjeto()'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(540151922312116736)
,p_name=>'cambio esquema'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P183_ESQUEMA'
,p_condition_element=>'P183_ESQUEMA'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(540152154540116738)
,p_event_id=>wwv_flow_imp.id(540151922312116736)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P183_ERP_SEL:=NULL;:P183_ESQUEMA_SEL:=NULL;:P183_CONEXION_SEL:=NULL;',
'',
''))
,p_attribute_02=>'P183_ERP_SEL,P183_ESQUEMA_SEL,P183_CONEXION_SEL'
,p_attribute_03=>'P183_ERP_SEL,P183_ESQUEMA_SEL,P183_CONEXION_SEL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(540152062402116737)
,p_event_id=>wwv_flow_imp.id(540151922312116736)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'    f_traervalorudc(P_ID_CABECERA =>''FINZ_GT03'', p_id_tabla=>:P183_ERP,    p_COMPANIA =>NULL,P_tipo=>''DESCRIPCION'',p_VALOR  =>'''',p_ACTIVO=>''1'')ERP,',
'    f_traervalorudc(P_ID_CABECERA =>''FINZ_GT04'', p_id_tabla=>:P183_ESQUEMA,p_COMPANIA =>NULL,P_tipo=>''DESCRIPCION'',p_VALOR  =>'''',p_ACTIVO=>''1'')ESQUEMA    ,',
'    f_traervalorudc(P_ID_CABECERA =>''FINZ_GT04'', p_id_tabla=>:P183_ESQUEMA,p_COMPANIA =>NULL,P_tipo=>''VALOR'',p_VALOR  =>'''',p_ACTIVO=>''1'')CONEXION ',
'    INTO :P183_ERP_SEL,:P183_ESQUEMA_SEL,:P183_CONEXION_SEL',
'FROM DUAL;',
'',
''))
,p_attribute_02=>'P183_ERP,P183_ESQUEMA'
,p_attribute_03=>'P183_ERP_SEL,P183_ESQUEMA_SEL,P183_CONEXION_SEL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(540593487951045036)
,p_name=>'Close Dialog Columnas'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(540152789076116744)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(540593520651045037)
,p_event_id=>wwv_flow_imp.id(540593487951045036)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
':P183_COLUMNAS:=:G_GT_COLUMNAS;',
''))
,p_attribute_02=>'G_GT_COLUMNAS'
,p_attribute_03=>'P183_COLUMNAS'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(554596594260141626)
,p_event_id=>wwv_flow_imp.id(540593487951045036)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mostrarBarra();',
'',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(543461457471406643)
,p_event_id=>wwv_flow_imp.id(540593487951045036)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(540152406828116741)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29613553166218712)
,p_event_id=>wwv_flow_imp.id(540593487951045036)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(540594186200045043)
,p_name=>'cambio objeto'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P183_OBJETO'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'(($v("P183_TIPOOBJETO")===''001''||$v("P183_TIPOOBJETO")===''999'')&&$v("P183_OBJETO")!=='''')'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(540594325018045045)
,p_event_id=>wwv_flow_imp.id(540594186200045043)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':G_GT_OBJETOS:=:P183_OBJETO;'
,p_attribute_02=>'P183_OBJETO'
,p_attribute_03=>'G_GT_OBJETOS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(542355833739543016)
,p_name=>'Close Dialog Parametro'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(540590446537045006)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(542356067940543018)
,p_event_id=>wwv_flow_imp.id(542355833739543016)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P183_PARAMETROS:=:G_GT_PARAMETROS;'
,p_attribute_02=>'G_GT_PARAMETROS'
,p_attribute_03=>'P183_PARAMETROS'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29613646333218713)
,p_event_id=>wwv_flow_imp.id(542355833739543016)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(546795430509499501)
,p_event_id=>wwv_flow_imp.id(542355833739543016)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(545174176202787413)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29613775587218714)
,p_event_id=>wwv_flow_imp.id(542355833739543016)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(542359277652543050)
,p_name=>'Cambio actividad'
,p_event_sequence=>110
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P183_IDPROCESO'
,p_condition_element=>'P183_IDPROCESO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29614641141218723)
,p_event_id=>wwv_flow_imp.id(542359277652543050)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P183_TIPOOBJETO'
,p_client_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_client_condition_expression=>'$v("P183_IDPROCESO") !== "" && !$v("P183_DESCRIPCION").includes("(COPIA -")'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29614748665218724)
,p_event_id=>wwv_flow_imp.id(542359277652543050)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P183_TIPOOBJETO'
,p_client_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_client_condition_expression=>'$v("P183_IDPROCESO") !== "" && !$v("P183_DESCRIPCION").includes("(COPIA -")'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(542844042738557101)
,p_event_id=>wwv_flow_imp.id(542359277652543050)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P183_DESCRIPCION,P183_TIPOOBJETO,P183_ESTADO,P183_ALMACENAMIENTO,P183_PERSISTE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(542844228999557103)
,p_event_id=>wwv_flow_imp.id(542359277652543050)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P183_DESCRIPCION,P183_TIPOOBJETO,P183_ESTADO,P183_ALMACENAMIENTO,P183_PERSISTE,P183_JSON,P183_ERP,P183_ESQUEMA,P183_OBJETO'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12446487027806307)
,p_event_id=>wwv_flow_imp.id(542359277652543050)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(11930796481404225)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12446545072806308)
,p_event_id=>wwv_flow_imp.id(542359277652543050)
,p_event_result=>'FALSE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(12388049354717846)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(543457585732406604)
,p_name=>'Close Dialog Condiciones 001'
,p_event_sequence=>120
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(541027549130436816)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(543457674602406605)
,p_event_id=>wwv_flow_imp.id(543457585732406604)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P183_CONDICIONES:=:G_GT_CONDICIONES;'
,p_attribute_02=>'G_GT_CONDICIONES'
,p_attribute_03=>'P183_CONDICIONES'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29613801494218715)
,p_event_id=>wwv_flow_imp.id(543457585732406604)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(545177888244787450)
,p_event_id=>wwv_flow_imp.id(543457585732406604)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(540152518510116742)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29613911102218716)
,p_event_id=>wwv_flow_imp.id(543457585732406604)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(13160689691985708)
,p_name=>'Close Dialog Condiciones_999'
,p_event_sequence=>130
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(13160573086985707)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13160740213985709)
,p_event_id=>wwv_flow_imp.id(13160689691985708)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P183_CONDICIONES:=:G_GT_CONDICIONES;'
,p_attribute_02=>'G_GT_CONDICIONES'
,p_attribute_03=>'P183_CONDICIONES'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29614015608218717)
,p_event_id=>wwv_flow_imp.id(13160689691985708)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13160892287985710)
,p_event_id=>wwv_flow_imp.id(13160689691985708)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(13163224539985734)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29614150456218718)
,p_event_id=>wwv_flow_imp.id(13160689691985708)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(554596038147141621)
,p_name=>'Close Dialog Validaciones 001'
,p_event_sequence=>140
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(554594818368141609)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(554596114602141622)
,p_event_id=>wwv_flow_imp.id(554596038147141621)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P183_VALIDACIONES:=:G_GT_VALIDACIONES;'
,p_attribute_02=>'G_GT_VALIDACIONES'
,p_attribute_03=>'P183_VALIDACIONES'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29614297051218719)
,p_event_id=>wwv_flow_imp.id(554596038147141621)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(554596298203141623)
,p_event_id=>wwv_flow_imp.id(554596038147141621)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(550997735117588449)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29614327359218720)
,p_event_id=>wwv_flow_imp.id(554596038147141621)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(13872777261746236)
,p_name=>'Close Dialog Validaciones 999'
,p_event_sequence=>150
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(13872664224746235)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13872857825746237)
,p_event_id=>wwv_flow_imp.id(13872777261746236)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P183_VALIDACIONES:=:G_GT_VALIDACIONES;'
,p_attribute_02=>'G_GT_VALIDACIONES'
,p_attribute_03=>'P183_VALIDACIONES'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29614452657218721)
,p_event_id=>wwv_flow_imp.id(13872777261746236)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13872993868746238)
,p_event_id=>wwv_flow_imp.id(13872777261746236)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(13871203103746221)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29614500112218722)
,p_event_id=>wwv_flow_imp.id(13872777261746236)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(12446646785806309)
,p_name=>'CARGA_ARCHIVOS_EXCEL'
,p_event_sequence=>160
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(11930796481404225)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12446797567806310)
,p_event_id=>wwv_flow_imp.id(12446646785806309)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'CARGA_ARCHIVOS'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(12446995632806312)
,p_name=>'CARGA_ARCHIVOS_CSV'
,p_event_sequence=>170
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(12388049354717846)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12447019705806313)
,p_event_id=>wwv_flow_imp.id(12446995632806312)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'CARGA_ARCHIVOS'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(34443454792782317)
,p_name=>'CARGA_ARCHIVOS_TEXTO'
,p_event_sequence=>180
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(34443350652782316)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34443581313782318)
,p_event_id=>wwv_flow_imp.id(34443454792782317)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'CARGA_ARCHIVOS'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(12450250585806345)
,p_name=>'Cambio Objeto Json '
,p_event_sequence=>190
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P183_JSON'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12450364688806346)
,p_event_id=>wwv_flow_imp.id(12450250585806345)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin    ',
'    PK_FINZ_GESTIONTRIBUTARIA.sp_trae_camposJSCfgColumnas(:P183_JSON,:P183_IDPROCESO,:P183_TIPOOBJETO,:P183_COLUMNAS);',
'    :G_GT_COLUMNAS:=:P183_COLUMNAS;',
'    begin--columnas',
'        ',
'        IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_COLUMNAS'') THEN',
'            APEX_COLLECTION.TRUNCATE_COLLECTION(''COLECCION_COLUMNAS'');',
'        END IF;',
'        IF(:G_GT_COLUMNAS IS NOT NULL)THEN',
'            FOR COLS IN ( ',
'                SELECT COLUMNA CAMPO1,ALIAS CAMPO2,VISIBLE CAMPO3,TIPODATO CAMPO4,EDITABLE CAMPO5,QRYRESUL CAMPO6,CALCULO CAMPO7,PK_JSON CAMPO8',
'                FROM JSON_TABLE(',
'                    :G_GT_COLUMNAS, -- tu variable o columna con el JSON',
'                    ''$[*]'' -- indica que es un arreglo',
'                    COLUMNS (',
'                        COLUMNA   VARCHAR2(3999) PATH ''$.COLUMNA'',',
'                        ALIAS     VARCHAR2(399) PATH ''$.ALIAS'',',
'                        VISIBLE   VARCHAR2(1)   PATH ''$.VISIBLE'',',
'                        TIPODATO  VARCHAR2(100)  PATH ''$.TIPODATO'',',
'                        EDITABLE  VARCHAR2(100)  PATH ''$.EDITABLE'',',
'                        QRYRESUL  VARCHAR2(100)  PATH ''$.QRYRESUL'',',
'                        CALCULO  VARCHAR2(100)  PATH ''$.CALCULO'',',
'                        PK_JSON  VARCHAR2(1)    PATH ''$.PK_JSON''',
'                    )',
'                )',
'            )',
'            LOOP',
'                APEX_COLLECTION.ADD_MEMBER(',
'                    p_collection_name =>''COLECCION_COLUMNAS'',',
'                    p_c001 => COLS.CAMPO1,',
'                    p_c002 => COLS.CAMPO2,',
'                    p_c003 => COLS.CAMPO3,',
'                    p_c004 => COLS.CAMPO4,',
'                    p_c005 => COLS.CAMPO5,',
'                    p_c006 => COLS.CAMPO6,',
'                    p_c007 => COLS.CAMPO7,',
'                    p_c008 => NVL(COLS.CAMPO8,''N'')',
'                );',
'            END LOOP;',
'        END IF;',
'    end;--fin columnas',
'    :P183_OBJETO:=:P183_JSON;',
'    :G_GT_OBJETOS:=:P183_JSON;',
'end;',
''))
,p_attribute_02=>'P183_JSON,P183_ID,P183_IDPROCESO,P183_TIPOOBJETO'
,p_attribute_03=>'P183_COLUMNAS,G_GT_COLUMNAS,P183_OBJETO,G_GT_OBJETOS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12450426393806347)
,p_event_id=>wwv_flow_imp.id(12450250585806345)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(540152406828116741)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(34443098092782313)
,p_name=>'page load'
,p_event_sequence=>200
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34443161824782314)
,p_event_id=>wwv_flow_imp.id(34443098092782313)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>' fn_cambioTipoobjeto();'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(125467136813948906)
,p_name=>'IDFORMULARIOSRI'
,p_event_sequence=>210
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P183_IDFORMULARIOSRI'
,p_condition_element=>'P183_IDFORMULARIOSRI'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(125467263978948907)
,p_event_id=>wwv_flow_imp.id(125467136813948906)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
unistr('// Suponiendo que el valor est\00E1 en el item P182_IDFORMULARIOSRI'),
'let val = $v("P183_IDFORMULARIOSRI"); ',
'',
'if (val) {',
'    // separa por ":"',
'    let partes = val.split(":");',
unistr('    // convierte a n\00FAmeros y ordena'),
'    partes = partes.map(p => parseInt(p.trim(), 10)).sort((a,b) => a - b);',
'    // une de nuevo',
'    let nuevo = partes.join(":");',
'    // guarda en el item',
'	console.log("nuevo:"+nuevo);',
'    $s("P183_IDFORMULARIOSRI", nuevo);',
'}',
''))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(540453776371603491)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(540438088030603471)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'GESTION TRIBUTARIA - CONFIGURACION'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Datos almacenados correctamente'
,p_internal_uid=>540453776371603491
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(12446818118806311)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'ProcesarArchivos'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin    ',
'    PK_FINZ_GESTIONTRIBUTARIA.sp_datosExcelCSV2Json(:P183_ID,''config'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CARGA_ARCHIVOS'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>12446818118806311
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(540151481711116731)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P183_COMPANIA:=:G_COMPANIA;',
'if (:P183_id is null)then ',
'    :P183_ESTADO:=0;',
'    :P183_ERP_SEL:=null;',
'    :P183_ESQUEMA_SEL:=null;',
'    :P183_CONEXION_SEL:=null;',
'    :P183_ALMACENAMIENTO:=''S'';',
'',
'    :G_GT_COLUMNAS:=null;',
'    :G_GT_CONDICIONES:=null;',
'    :G_GT_PARAMETROS:=null;',
'    :G_GT_OBJETOS:=null;',
'    :G_GT_VALIDACIONES:=null;',
'',
'    IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_COLUMNAS'') THEN',
'        APEX_COLLECTION.DELETE_COLLECTION(''COLECCION_COLUMNAS'');',
'    END IF;',
'    IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_CONDICIONES'') THEN',
'        APEX_COLLECTION.DELETE_COLLECTION(''COLECCION_CONDICIONES'');',
'    END IF;',
'    IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_PARAMETROS'') THEN',
'        APEX_COLLECTION.DELETE_COLLECTION(''COLECCION_PARAMETROS'');',
'    END IF;',
'    IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_VALIDACIONES'') THEN',
'        APEX_COLLECTION.DELETE_COLLECTION(''COLECCION_VALIDACIONES'');',
'    END IF;',
'end if;',
'',
':P183_IDENTIFICADOR:=''CFG''||TRIM(to_char(:P183_ID,''0000000''));'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>540151481711116731
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(540453336215603491)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(540438088030603471)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form GESTION TRINUTARIA - CONFIGURACION'
,p_internal_uid=>540453336215603491
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(545177785921787449)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Setup Interface'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE V_CONTADOR NUMBER;',
' v_json_array   JSON_ARRAY_T;',
' v_nuevo_objeto JSON_OBJECT_T;',
' v_clob clob;',
' V_json1 varchar2(3999);',
'BEGIN',
'    IF NOT APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_COLUMNAS'') THEN',
'     APEX_COLLECTION.CREATE_COLLECTION(''COLECCION_COLUMNAS'');',
'    END IF;',
'    IF NOT APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_CONDICIONES'') THEN',
'     APEX_COLLECTION.CREATE_COLLECTION(''COLECCION_CONDICIONES'');',
'    END IF;',
'    IF NOT APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_PARAMETROS'') THEN',
'     APEX_COLLECTION.CREATE_COLLECTION(''COLECCION_PARAMETROS'');',
'    END IF;',
'    IF NOT APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_VALIDACIONES'') THEN',
'     APEX_COLLECTION.CREATE_COLLECTION(''COLECCION_VALIDACIONES'');',
'    END IF;',
'',
'',
'    IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_COLUMNAS'') THEN',
'     APEX_COLLECTION.TRUNCATE_COLLECTION(''COLECCION_COLUMNAS'');',
'    END IF;',
'    IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_CONDICIONES'') THEN',
'     APEX_COLLECTION.TRUNCATE_COLLECTION(''COLECCION_CONDICIONES'');',
'    END IF;',
'    IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_PARAMETROS'') THEN',
'     APEX_COLLECTION.TRUNCATE_COLLECTION(''COLECCION_PARAMETROS'');',
'    END IF;',
'    IF APEX_COLLECTION.COLLECTION_EXISTS(''COLECCION_VALIDACIONES'') THEN',
'     APEX_COLLECTION.TRUNCATE_COLLECTION(''COLECCION_VALIDACIONES'');',
'    END IF;',
'',
'',
'    :G_GT_OBJETOS:=:P183_OBJETO;',
'    :G_GT_COLUMNAS:=:P183_COLUMNAS;',
'    :G_GT_CONDICIONES:=:P183_CONDICIONES;',
'    :G_GT_PARAMETROS:=:P183_PARAMETROS;',
'    :G_GT_VALIDACIONES:=:P183_VALIDACIONES;',
'    v_clob :=:P183_COLUMNAS;',
'    :P183_JSON:=:P183_OBJETO;',
'    :P183_COLUMNAS:=v_clob;',
'    ',
'    ',
'    begin--columnas',
'        IF(:G_GT_COLUMNAS IS NOT NULL)THEN',
'            FOR COLS IN ( ',
'                SELECT COLUMNA,ALIAS,VISIBLE,TIPODATO,EDITABLE,QRYRESUL,CALCULO,PK_JSON',
'                FROM JSON_TABLE(',
'                    :G_GT_COLUMNAS, -- tu variable o columna con el JSON',
'                    ''$[*]'' -- indica que es un arreglo',
'                    COLUMNS (',
'                        COLUMNA   VARCHAR2(3999) PATH ''$.COLUMNA'',',
'                        ALIAS     VARCHAR2(399) PATH ''$.ALIAS'',',
'                        VISIBLE   VARCHAR2(1)   PATH ''$.VISIBLE'',',
'                        TIPODATO  VARCHAR2(100)  PATH ''$.TIPODATO'',',
'                        EDITABLE   VARCHAR2(1)   PATH ''$.EDITABLE'',',
'                        QRYRESUL   VARCHAR2(1)   PATH ''$.QRYRESUL'',',
'                        CALCULO   VARCHAR2(1)   PATH ''$.CALCULO'',',
'                        PK_JSON   VARCHAR2(1)   PATH ''$.PK_JSON''',
'                    )',
'                )',
'            )',
'            LOOP',
'                APEX_COLLECTION.ADD_MEMBER(',
'                    p_collection_name =>''COLECCION_COLUMNAS'',',
'                    p_c001 => COLS.COLUMNA,',
'                    p_c002 => COLS.ALIAS,',
'                    p_c003 => COLS.VISIBLE,',
'                    p_c004 => COLS.TIPODATO,',
'                    p_c005 => COLS.EDITABLE,',
'                    p_c006 => COLS.QRYRESUL,',
'                    p_c007 => COLS.CALCULO,',
'                    p_c008 => NVL(COLS.PK_JSON,''N'')  ',
'                );',
'            END LOOP;',
'        END IF;',
'    end;--fin columnas',
'    begin--parametros',
'        IF (:P183_TIPOOBJETO=''001'')THEN ',
'            SELECT COUNT(DISTINCT 1 ) INTO V_CONTADOR ',
'            from (',
'                SELECT PARAMETRO CAMPO1 FROM JSON_TABLE(:G_GT_PARAMETROS,''$[*]'' COLUMNS (PARAMETRO VARCHAR2(3999) PATH ''$.PARAMETRO''))',
'            )WHERE CAMPO1 =''PERIODO'';',
'         ',
'            IF (V_CONTADOR=0)THEN ',
'                V_json1:=''{"PARAMETRO": "PERIODO","VALOR1": "PERIODO","VALOR2": "PERIODO"}'';',
'                if(:G_GT_PARAMETROS is null)then',
'                    :G_GT_PARAMETROS   :=''[''||V_json1||'']''; ',
'                 else',
'                     V_json_array := JSON_ARRAY_T.parse(:G_GT_PARAMETROS);',
'                     v_nuevo_objeto := JSON_OBJECT_T.parse(V_json1);',
'                     v_json_array.append(v_nuevo_objeto);',
'                     :G_GT_PARAMETROS := v_json_array.to_clob;',
'                end if;',
'                :P183_PARAMETROS:=:G_GT_PARAMETROS;',
'                begin',
'                    update t_finz_gestiontributariacfg set PARAMETROS=:P183_PARAMETROS where id = :P183_ID;',
'                    commit;',
'                end;',
'            END IF;        ',
'        END IF;',
'        IF(:G_GT_PARAMETROS IS NOT NULL)THEN',
'            FOR COLS IN (',
'             SELECT PARAMETRO CAMPO1,VALOR1 CAMPO2,VALOR2 CAMPO3',
'                FROM JSON_TABLE(',
'                    :G_GT_PARAMETROS, -- tu variable o columna con el JSON',
'                    ''$[*]'' -- indica que es un arreglo',
'                    COLUMNS (',
'                        PARAMETRO VARCHAR2(3999) PATH ''$.PARAMETRO'',',
'                        VALOR1    VARCHAR2(399) PATH ''$.VALOR1'',',
'                        VALOR2    VARCHAR2(1)   PATH ''$.VALOR2''',
'                    )',
'                )',
'            )LOOP',
'                APEX_COLLECTION.ADD_MEMBER(',
'                    p_collection_name => ''COLECCION_PARAMETROS'',',
'                    p_c001 => COLS.CAMPO1,',
'                    p_c002 => COLS.CAMPO2,',
'                    p_c003 => COLS.CAMPO3',
'                );',
'            END LOOP;',
'        END IF;',
'',
'    end;--fin parametros',
'',
'    begin--condiciones',
'        IF (:P183_TIPOOBJETO=''001'')then',
'            IF(:G_GT_CONDICIONES IS NOT NULL)THEN',
'                    FOR COLS IN (',
'                    SELECT OLOGICO CAMPO1,COLUMNA CAMPO2,ORELACIONAL CAMPO3,VALOR CAMPO4',
'                    FROM JSON_TABLE(',
'                        :G_GT_CONDICIONES, -- tu variable o columna con el JSON',
'                        ''$[*]'' -- indica que es un arreglo',
'                        COLUMNS (',
'                            OLOGICO   VARCHAR2(3999) PATH ''$.OLOGICO'',',
'                            COLUMNA     VARCHAR2(399) PATH ''$.COLUMNA'',',
'                            ORELACIONAL   VARCHAR2(399)   PATH ''$.ORELACIONAL'',',
'                            VALOR  VARCHAR2(399)  PATH ''$.VALOR''',
'                        )',
'                    )',
'                )',
'                LOOP',
'                    APEX_COLLECTION.ADD_MEMBER(',
'                        p_collection_name => ''COLECCION_CONDICIONES'',',
'                        p_c001 => COLS.CAMPO1,',
'                        p_c002 => COLS.CAMPO2,',
'                        p_c003 => COLS.CAMPO3,',
'                        p_c004 => COLS.CAMPO4',
'                    );',
'                END LOOP;',
'            END IF;',
'        END IF;',
'        IF (:P183_TIPOOBJETO>=''900'')then',
'            IF(:G_GT_CONDICIONES IS NOT NULL)THEN',
'                    FOR COLS IN (',
'                    SELECT OLOGICO CAMPO1,CONFIGURACION_A CAMPO2,CAMPO_A CAMPO3,ORELACIONAL CAMPO4,CONFIGURACION_B CAMPO5,CAMPO_B CAMPO6 ',
'                    FROM JSON_TABLE(',
'                        :G_GT_CONDICIONES, -- tu variable o columna con el JSON',
'                        ''$[*]'' -- indica que es un arreglo',
'                        COLUMNS (',
'                            OLOGICO   VARCHAR2(3999) PATH ''$.OLOGICO'',',
'                            CONFIGURACION_A     VARCHAR2(399) PATH ''$.CONFIGURACION_A'',',
'                            CAMPO_A   VARCHAR2(399)   PATH ''$.CAMPO_A'',',
'                            ORELACIONAL  VARCHAR2(399)  PATH ''$.ORELACIONAL'',',
'                            CONFIGURACION_B  VARCHAR2(100)  PATH ''$.CONFIGURACION_B'',',
'                            CAMPO_B  VARCHAR2(100)  PATH ''$.CAMPO_B''',
'                        )',
'                    )',
'                )',
'                LOOP',
'                    APEX_COLLECTION.ADD_MEMBER(',
'                        p_collection_name => ''COLECCION_CONDICIONES'',',
'                        p_c001 => COLS.CAMPO1,',
'                        p_c002 => COLS.CAMPO2,',
'                        p_c003 => COLS.CAMPO3,',
'                        p_c004 => COLS.CAMPO4,',
'                        p_c005 => COLS.CAMPO5,',
'                        p_c006 => COLS.CAMPO6',
'                    );',
'                END LOOP;',
'            END IF;',
'        END IF;',
'    end;--fin condiciones',
'    begin--validaciones',
'        IF (:P183_TIPOOBJETO=''001'')then',
'            IF(:G_GT_VALIDACIONES IS NOT NULL)THEN',
'                FOR COLS IN (',
'                    SELECT OLOGICO CAMPO1,COLUMNA CAMPO2,ORELACIONAL CAMPO3,VALOR CAMPO4,MSJ_ERROR CAMPO5,MSJ_ADVERTECNIA CAMPO6',
'                    FROM JSON_TABLE(',
'                        :G_GT_VALIDACIONES, -- tu variable o columna con el JSON',
'                        ''$[*]'' -- indica que es un arreglo',
'                        COLUMNS (',
'                            OLOGICO   VARCHAR2(3999) PATH ''$.OLOGICO'',',
'                            COLUMNA     VARCHAR2(399) PATH ''$.COLUMNA'',',
'                            ORELACIONAL   VARCHAR2(399)   PATH ''$.ORELACIONAL'',',
'                            VALOR  VARCHAR2(399)  PATH ''$.VALOR'',',
'                            MSJ_ERROR  VARCHAR2(100)  PATH ''$.MSJ_ERROR'',',
'                            MSJ_ADVERTECNIA  VARCHAR2(100)  PATH ''$.MSJ_ADVERTECNIA''',
'                        )',
'                    )',
'                )LOOP',
'                    APEX_COLLECTION.ADD_MEMBER(',
'                        p_collection_name => ''COLECCION_VALIDACIONES'',',
'                        p_c001 => COLS.CAMPO1,',
'                        p_c002 => COLS.CAMPO2,',
'                        p_c003 => COLS.CAMPO3,',
'                        p_c004 => COLS.CAMPO4,',
'                        p_c005 => COLS.CAMPO5,',
'                        p_c006 => COLS.CAMPO6',
'                    );',
'                END LOOP;',
'            END IF;',
'        END IF;',
'        IF (:P183_TIPOOBJETO>=''900'')then',
'            IF(:G_GT_VALIDACIONES IS NOT NULL)THEN',
'                FOR COLS IN (',
'                        SELECT OLOGICO CAMPO1,CONFIGURACION_A CAMPO2,CAMPO_A CAMPO3,ORELACIONAL CAMPO4,CONFIGURACION_B CAMPO5,CAMPO_B CAMPO6,MSJ_ERROR CAMPO7,MSJ_ADVERTECNIA CAMPO8',
'                        FROM JSON_TABLE(',
'                            :G_GT_VALIDACIONES, -- tu variable o columna con el JSON',
'                            ''$[*]'' -- indica que es un arreglo',
'                            COLUMNS (',
'                                OLOGICO   VARCHAR2(3999) PATH ''$.OLOGICO'',',
'                                CONFIGURACION_A     VARCHAR2(399) PATH ''$.CONFIGURACION_A'',',
'                                CAMPO_A   VARCHAR2(399)   PATH ''$.CAMPO_A'',',
'                                ORELACIONAL  VARCHAR2(399)  PATH ''$.ORELACIONAL'',',
'                                CONFIGURACION_B  VARCHAR2(100)  PATH ''$.CONFIGURACION_B'',',
'                                CAMPO_B  VARCHAR2(100)  PATH ''$.CAMPO_B'',',
'                                MSJ_ERROR  VARCHAR2(100)  PATH ''$.MSJ_ERROR'',',
'                                MSJ_ADVERTECNIA  VARCHAR2(100)  PATH ''$.MSJ_ADVERTECNIA''',
'                            )',
'                        )',
'                )LOOP',
'                    APEX_COLLECTION.ADD_MEMBER(',
'                        p_collection_name => ''COLECCION_VALIDACIONES'',',
'                        p_c001 => COLS.CAMPO1,',
'                        p_c002 => COLS.CAMPO2,',
'                        p_c003 => COLS.CAMPO3,',
'                        p_c004 => COLS.CAMPO4,',
'                        p_c005 => COLS.CAMPO5,',
'                        p_c006 => COLS.CAMPO6,',
'                        p_c007 => COLS.CAMPO7,',
'                        p_c008 => COLS.CAMPO8',
'                    );',
'                END LOOP;',
'            END IF;',
'        END IF;',
'    end;--fin validaciones',
'    BEGIN',
'        SELECT ',
'            f_traervalorudc(P_ID_CABECERA =>''FINZ_GT03'', p_id_tabla=>:P183_ERP,    p_COMPANIA =>NULL,P_tipo=>''DESCRIPCION'',p_VALOR  =>'''',p_ACTIVO=>''1'')ERP,',
'            f_traervalorudc(P_ID_CABECERA =>''FINZ_GT04'', p_id_tabla=>:P183_ESQUEMA,p_COMPANIA =>NULL,P_tipo=>''DESCRIPCION'',p_VALOR  =>'''',p_ACTIVO=>''1'')ESQUEMA    ,',
'            f_traervalorudc(P_ID_CABECERA =>''FINZ_GT04'', p_id_tabla=>:P183_ESQUEMA,p_COMPANIA =>NULL,P_tipo=>''VALOR'',p_VALOR  =>'''',p_ACTIVO=>''1'')CONEXION ',
'            INTO :P183_ERP_SEL,:P183_ESQUEMA_SEL,:P183_CONEXION_SEL',
'        FROM DUAL;',
'    EXCEPTION WHEN OTHERS THEN ',
'        NULL;',
'    END;',
'',
'    IF (:P183_TIPOOBJETO between ''002'' and ''899'')THEN',
'        :G_GT_PARAMETROS:=NULL;',
'        :G_GT_CONDICIONES:=NULL;',
'        :G_GT_OBJETOS:=:P183_OBJETO;',
'    END IF;',
'    :P183_EDITAR := pk_admi_gestionparametros.f_admi_accesoacciones(:app_modulo,:app_user,:app_page_id,''EDITAR'');',
'	IF (:P183_ID IS NULL)THEN :P183_EDITAR := 1; RETURN;END IF;',
'	IF (:P183_EDITAR =0)THEN :P183_EDITAR := 0; RETURN;END IF;',
'	IF (:P183_EDITAR =1 AND :P183_ID IS NOT NULL)THEN :P183_EDITAR := 1; RETURN;END IF;',
' END;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>545177785921787449
);
wwv_flow_imp.component_end;
end;
/
