prompt --application/pages/page_00119
begin
--   Manifest
--     PAGE: 00119
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>119
,p_name=>unistr('Modificaci\00F3n de Vi\00E1ticos')
,p_step_title=>unistr('Modificaci\00F3n de Vi\00E1ticos')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_last_updated_on=>wwv_flow_imp.dz('20230310212038Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(212076820243340848)
,p_plug_name=>unistr('Selecci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(212077012329340850)
,p_plug_name=>unistr('Vi\00E1ticos')
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>'select * from t_gvia_viaticos where compania = :g_compania'
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(250126631042278302)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_control_break=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_help=>'N'
,p_download_formats=>'CSV'
,p_enable_mail_download=>'N'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>250126631042278302
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250126770803278303)
,p_db_column_name=>'COMPANIA'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250126893734278304)
,p_db_column_name=>'USUARIOCREA'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Usr. Crea'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250126917366278305)
,p_db_column_name=>'USUARIOMODIFICA'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Usr. Modifica'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250127050121278306)
,p_db_column_name=>'FECHASOLICITUD'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Solicitud'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250127191997278307)
,p_db_column_name=>'FECHAAPROBACION'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>unistr('Aprobaci\00F3n')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250127212169278308)
,p_db_column_name=>'FECHAPAGO'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Pago'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250127370700278309)
,p_db_column_name=>'NUMEROVIATICO'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>unistr('Vi\00E1tico')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250127430487278310)
,p_db_column_name=>'FECHAINICIO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Inicio'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250127535132278311)
,p_db_column_name=>'FECHAFIN'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Fin'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250127672597278312)
,p_db_column_name=>'TIPOVIATICO'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Tipo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250127797708278313)
,p_db_column_name=>'MOTIVOVIAJE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Motivo viaje'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250127862229278314)
,p_db_column_name=>'MOTIVORECHAZO'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Motivo rechazo'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250127966666278315)
,p_db_column_name=>'ACUERDOLEGAL'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Acuerdolegal'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250128021110278316)
,p_db_column_name=>'ESTADOAPROBACION'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Est. aprob.'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250128119292278317)
,p_db_column_name=>'ESTADO'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250128248303278318)
,p_db_column_name=>'NUMEROBATCH'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Batch'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250128319298278319)
,p_db_column_name=>'IDFLUJO'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'ID Flujo'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250128408919278320)
,p_db_column_name=>'USUARIOFLUJO'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Usr. flujo'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250128503032278321)
,p_db_column_name=>'CENTROCOSTOS'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Centrocostos'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(250128687319278322)
,p_db_column_name=>'FECHALIQUIDACION'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>unistr('Liquidaci\00F3n')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(250138688240285712)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'2501387'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'USUARIOCREA:USUARIOMODIFICA:NUMEROVIATICO:TIPOVIATICO:ESTADOAPROBACION:ESTADO:NUMEROBATCH:IDFLUJO:USUARIOFLUJO:FECHAINICIO:FECHASOLICITUD:FECHALIQUIDACION:FECHAAPROBACION:FECHAPAGO:FECHAFIN:'
,p_sort_column_1=>'NUMEROVIATICO'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164634Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1445480405101902790)
,p_plug_name=>'Barra de Acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(250129767205278333)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1445480405101902790)
,p_button_name=>'REGRESAR'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:2007:&SESSION.::&DEBUG.:RP,2007::'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(250139708177287489)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1445480405101902790)
,p_button_name=>'PROCESAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Procesar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-gear'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(212076907433340849)
,p_name=>'P119_VIATICO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(212076820243340848)
,p_prompt=>'Viaticos:'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select lpad(numeroviatico,5,''0'')||'' - ''||usuariocrea d, numeroviatico r',
'from t_gvia_viaticos where compania = :g_compania and estadoaprobacion = ''G'' and numerobatch is null',
'order by numeroviatico desc'))
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(37859556976106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(250129262043278328)
,p_name=>'Procesar'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(250139708177287489)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(250128833337278324)
,p_event_id=>wwv_flow_imp.id(250129262043278328)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(250129125258278327)
,p_event_id=>wwv_flow_imp.id(250129262043278328)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_control01 varchar2(100);',
'v_control02 varchar2(100);',
'v_control03 varchar2(100);',
'v_control04 varchar2(100);',
'v_control05 varchar2(100);',
'v_viaticos	varchar2(500);',
'cursor viaticos is',
'	(select num01 vtc from data.t_apex_temporal where control01 = v_control01 and control02 = v_control02 and control03 = v_control03 and control04 = v_control04);',
'begin',
'	v_control01 := :g_compania;',
'	v_control02 := :app_modulo;',
'	v_control03 := :app_user;',
'	v_control04 := ''apex.109.119.procesar'';',
'',
'	v_viaticos	:= :p119_viatico;',
'',
'	delete from data.t_apex_temporal where control01 = v_control01 and control02 = v_control02 and control03 = v_control03 and control04 = v_control04;',
'',
'	insert into data.t_apex_temporal (control01,control02,control03,control04,txt01,num01)',
'	select v_control01,v_control02,v_control03,v_control04,v_viaticos,regexp_substr(v_viaticos,''[^:]+'',1,level) value',
'	from dual connect by level <= length (v_viaticos) - length(replace(v_viaticos,'':''))+1;',
'	commit;',
'',
'	for viatico in viaticos loop',
'	begin',
'		update t_gvia_viaticos x set x.estadoaprobacion = ''G'' where x.numeroviatico = viatico.vtc; commit;',
'		pk_gvia_gestionviaticos.sp_insertaviatico(p_compania=>''00001'',p_numeroviatico=>viatico.vtc,p_valorliquidar=>0,p_pagar=>0);',
'	end;',
'	end loop;',
'',
'	:p119_viatico := null;',
'end;'))
,p_attribute_02=>'P119_VIATICO'
,p_attribute_03=>'P119_VIATICO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(250129448079278330)
,p_event_id=>wwv_flow_imp.id(250129262043278328)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(212077012329340850)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(250129562656278331)
,p_event_id=>wwv_flow_imp.id(250129262043278328)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(212076820243340848)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(250129020916278326)
,p_event_id=>wwv_flow_imp.id(250129262043278328)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp.component_end;
end;
/
