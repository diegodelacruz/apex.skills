prompt --application/pages/page_00109
begin
--   Manifest
--     PAGE: 00109
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>109
,p_name=>'Jde Difrencias AsOf vs Kardex'
,p_step_title=>'Jde Difrencias AsOf vs Kardex'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'$(secItems).hide();'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-controls-item--controlBreak {',
'     display: block;',
'}',
'.a-IRR-reportSummary-item--controlBreak{',
'     display: block;',
'}',
'.a-IRR-controls-item--highlight{',
'     display: block;',
'}',
'#R226498368479535669_control_panel{',
'    display: none;',
'}',
'.a-IRR-button.a-IRR-button--controls {',
'    display: block;',
'    background-color: transparent;',
'}',
'.a-IRR-aggregate-value{',
'    font-weight: bolder;',
'}',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_last_updated_on=>wwv_flow_imp.dz('20251002140846Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(113494160425431023)
,p_plug_name=>'Barra de Accion'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(114166567261666534)
,p_plug_name=>'New'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(114166366372666532)
,p_plug_name=>'Filtros'
,p_parent_plug_id=>wwv_flow_imp.id(114166567261666534)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37787379178106507)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(114166401884666533)
,p_plug_name=>'Esquema de colores'
,p_parent_plug_id=>wwv_flow_imp.id(114166567261666534)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'htp.p(''<div id="coloresLista">'');',
'        FOR codigoColores IN (SELECT VALOR, VALOR2 FROM T_CORP_UDC WHERE ID_CABECERA = ''INVE_COLOR'' AND VALOR3 =1)',
'        LOOP',
'         htp.p(''<span style="margin-left : 15px;">''|| codigoColores.VALOR || ''<span class="fa fa-square" style="color: '' || codigoColores.VALOR2 ||''; margin-left: 5px;" >',
'                                                  <spam class="visuallyhidden">Verificado</spam>',
'                                              </span>''||   ''</span>'');',
'        END LOOP;',
'   htp.p(''</div>'');'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(226498368479535669)
,p_plug_name=>'consulta'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ftedata AS (',
'    SELECT',
'        anio,mes,codigojde producto,codigojde codproducto,',
'        mes mes_valor,bodega,ubicacion locacion,lote,glcls,',
'        SUM(cantidadmeskrdx) / 10000 kardex_cantidad,',
'        SUM(costomeskrdx) / 100      kardex_costo,',
'        SUM(cantidadmesasof) / 10000 asof_cantidad,',
'        SUM(costomesasof) / 100      asof_costo,',
'        1 asof_existe',
'    FROM t_apex_asofkardex',
'    WHERE flag = ''asof_kardex''',
'        AND anio = (:p109_anio - 2000)',
'        AND mes = :p109_mes',
'        AND (bodega = :p109_bodega or :p109_bodega is null)',
'        AND (glcls =  :p109_glcls or :p109_glcls is null)',
'        AND (codigojde = :p109_producto or :p109_producto is null)',
'    GROUP BY anio,mes,codigojde,bodega,ubicacion,lote,glcls',
')',
'SELECT',
'    anio,mes,producto,codproducto,mes_valor,bodega,locacion,lote,glcls,kardex_cantidad,kardex_costo,',
'    asof_cantidad,asof_costo,',
'    CASE WHEN round(kardex_cantidad, 4) <> round(asof_cantidad, 4) THEN 1',
'         WHEN round(kardex_costo, 2) <> round(asof_costo, 2)       THEN 2 ',
'         ELSE 0',
'    END diffcantidad,',
'    CASE WHEN round(kardex_cantidad, 4) <> round(asof_cantidad, 4) ',
'           OR round(kardex_costo, 2) <> round(asof_costo, 2) THEN',
'            ''<span title="''||decode(asof_existe,0,''Ver/Inserta Asof'',''Ver/Actualiza detalle'')||''" style="color:''||decode(asof_existe,0,''red'',''#040404'')||'';" class="fa fa-list-alt"/>''',
'         ELSE NULL',
'    END boton2',
'    ',
'FROM',
'    ftedata',
'WHERE',
'    ( CASE WHEN round(kardex_cantidad, 4) <> round(asof_cantidad, 4)',
'             OR round(kardex_costo, 2) <> round(asof_costo, 2) THEN 1 ',
'           ELSE 0',
'        END',
'    ) = 1',
'ORDER BY bodega,mes_valor'))
,p_plug_source_type=>'NATIVE_IR'
,p_translate_title=>'N'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_updated_on=>wwv_flow_imp.dz('20230719150653Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(114827376099295209)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'TOP_AND_BOTTOM_LEFT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>114827376099295209
,p_updated_on=>wwv_flow_imp.dz('20230719150652Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114827598127295211)
,p_db_column_name=>'BODEGA'
,p_display_order=>10
,p_column_identifier=>'B'
,p_column_label=>'Bodega'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114827941029295215)
,p_db_column_name=>'MES'
,p_display_order=>30
,p_column_identifier=>'F'
,p_column_label=>'Mes'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(350337138530635159)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114827611214295212)
,p_db_column_name=>'LOCACION'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>unistr('Ubicaci\00F3n')
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114827786537295213)
,p_db_column_name=>'LOTE'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Lote'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114827806350295214)
,p_db_column_name=>'GLCLS'
,p_display_order=>60
,p_column_identifier=>'E'
,p_column_label=>'Glcls'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114919786441411501)
,p_db_column_name=>'ASOF_CANTIDAD'
,p_display_order=>70
,p_column_identifier=>'T'
,p_column_label=>'Asof Cantidad'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114919866738411502)
,p_db_column_name=>'ASOF_COSTO'
,p_display_order=>80
,p_column_identifier=>'U'
,p_column_label=>'Asof Costo'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114919901069411503)
,p_db_column_name=>'KARDEX_CANTIDAD'
,p_display_order=>90
,p_column_identifier=>'V'
,p_column_label=>'Kardex Cantidad'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114920019354411504)
,p_db_column_name=>'KARDEX_COSTO'
,p_display_order=>100
,p_column_identifier=>'W'
,p_column_label=>'Kardex Costo'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'FML999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114920271916411506)
,p_db_column_name=>'DIFFCANTIDAD'
,p_display_order=>120
,p_column_identifier=>'Y'
,p_column_label=>'Diffcantidad'
,p_allow_filtering=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114827439485295210)
,p_db_column_name=>'ANIO'
,p_display_order=>140
,p_column_identifier=>'A'
,p_column_label=>'Anio'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114920180618411505)
,p_db_column_name=>'MES_VALOR'
,p_display_order=>150
,p_column_identifier=>'X'
,p_column_label=>'Mes Valor'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114920414617411508)
,p_db_column_name=>'PRODUCTO'
,p_display_order=>160
,p_column_identifier=>'AA'
,p_column_label=>'Producto'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(114099867162270301)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(114921494559411518)
,p_db_column_name=>'CODPRODUCTO'
,p_display_order=>170
,p_column_identifier=>'AB'
,p_column_label=>'Codproducto'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(115357866725760105)
,p_db_column_name=>'BOTON2'
,p_display_order=>180
,p_column_identifier=>'AC'
,p_column_label=>'-'
,p_column_link=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.:RP,110:P110_ANIO_FILTRO,P110_BODEGA_FILTRO,P110_GLCLS_FILTRO,P110_LOTE_FILTRO,P110_MES_FILTRO,P110_UBICACION_FILTRO,P110_PRODUCTO_FILTRO:&P109_ANIO.,#BODEGA#,#GLCLS#,#LOTE#,#MES_VALOR#,#LOCACION#,#CODPRODUCTO#'
,p_column_linktext=>'#BOTON2#'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_updated_on=>wwv_flow_imp.dz('20230719150652Z')
,p_updated_by=>'EMASABANDA'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(114885172826312978)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1148852'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'PRODUCTO:BODEGA:MES:LOCACION:LOTE:GLCLS:ASOF_CANTIDAD:ASOF_COSTO:KARDEX_CANTIDAD:KARDEX_COSTO::BOTON2'
,p_sort_column_1=>'DIFFCANTIDAD'
,p_sort_direction_1=>'DESC'
,p_sort_column_2=>'0'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'0'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'0'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'PRODUCTO:0:0:0:0:0'
,p_break_enabled_on=>'PRODUCTO:0:0:0:0:0'
,p_sum_columns_on_break=>'ASOF_CANTIDAD:ASOF_COSTO:KARDEX_CANTIDAD:KARDEX_COSTO'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164634Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(115335866255244035)
,p_report_id=>wwv_flow_imp.id(114885172826312978)
,p_name=>'NO EXISTE EN ASOF'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIFFCANTIDAD'
,p_operator=>'='
,p_expr=>'-1'
,p_condition_sql=>' (case when ("DIFFCANTIDAD" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#FFA1A1'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164634Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(115336273289244036)
,p_report_id=>wwv_flow_imp.id(114885172826312978)
,p_name=>'NO EXISTE EN KADEX'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIFFCANTIDAD'
,p_operator=>'='
,p_expr=>'-2'
,p_condition_sql=>' (case when ("DIFFCANTIDAD" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#A1D0FF'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164634Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(115336668975244036)
,p_report_id=>wwv_flow_imp.id(114885172826312978)
,p_name=>'DIFERENCIA CANTIDAD'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIFFCANTIDAD'
,p_operator=>'='
,p_expr=>'1'
,p_condition_sql=>' (case when ("DIFFCANTIDAD" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#F7F37B'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164634Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_worksheet_condition(
 p_id=>wwv_flow_imp.id(115337039772244036)
,p_report_id=>wwv_flow_imp.id(114885172826312978)
,p_name=>'DIFERENCIA COSTO'
,p_condition_type=>'HIGHLIGHT'
,p_allow_delete=>'Y'
,p_column_name=>'DIFFCANTIDAD'
,p_operator=>'='
,p_expr=>'2'
,p_condition_sql=>' (case when ("DIFFCANTIDAD" = to_number(#APXWS_EXPR#)) then #APXWS_HL_ID# end) '
,p_condition_display=>'#APXWS_COL_NAME# = #APXWS_EXPR_NUMBER#  '
,p_enabled=>'Y'
,p_highlight_sequence=>10
,p_row_bg_color=>'#B3C8C9'
,p_created_on=>wwv_flow_imp.dz('20230705164634Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164634Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(226499504460535670)
,p_plug_name=>'regitems'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'N')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(113494310533431025)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(113494160425431023)
,p_button_name=>'Regresar'
,p_button_static_id=>'Regresar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Regresar'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:100:&SESSION.::&DEBUG.:RP:P100_ANIO,P100_MES:&P109_ANIO.,&P109_MES_PARAMETRO.'
,p_icon_css_classes=>'fa-arrow-left'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(113338250400862453)
,p_name=>'P109_BODEGA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(114166366372666532)
,p_prompt=>'Bodega'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select CODUNIDAD ||'' - ''||DESCRIPCION , CODUNIDAD from vt_jde_bodegas',
'order by 1 '))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Todos'
,p_cHeight=>1
,p_tag_attributes=>'disabled="true"'
,p_field_template=>wwv_flow_imp.id(37859556976106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(113339097930862453)
,p_name=>'P109_MES'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(226499504460535670)
,p_prompt=>'Mes'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(113339448266862453)
,p_name=>'P109_ANIO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(226499504460535670)
,p_prompt=>'Anio'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(113494658486431028)
,p_name=>'P109_GLCLS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(114166366372666532)
,p_prompt=>'GL Class'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select TRIM(DRKY) || '' - '' || DRDL01, DRKY ',
'from  vt_jde_udcjde where drsy=''41'' and drrt=''9'' AND DRSPHD=''ZAIMELLA  ''',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Todos'
,p_cHeight=>1
,p_tag_attributes=>'disabled="true"'
,p_field_template=>wwv_flow_imp.id(37859556976106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(113494719107431029)
,p_name=>'P109_PRODUCTO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(114166366372666532)
,p_prompt=>'Producto'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_JDE_PRODUCTO_CODPRD_CODOCORTO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  (nombreproducto) || ''  (''|| trim (CODIGOPRODUCTO) ||'') - '' ||codigocorto d, codigocorto r ',
'from vt_jde_productos',
'where  trim(nombreproducto) is not null',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Todos'
,p_cHeight=>1
,p_tag_attributes=>'disabled="true"'
,p_field_template=>wwv_flow_imp.id(37859556976106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(114167306049666542)
,p_name=>'P109_MES_PARAMETRO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(226499504460535670)
,p_prompt=>'Mes Parametro'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(115606500313890549)
,p_name=>'P109_PERIODO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(114166366372666532)
,p_prompt=>'Periodo'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859556976106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(118840392824907502)
,p_name=>'P109_USUARIO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(226499504460535670)
,p_prompt=>'Usuario'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(118841690620907515)
,p_name=>'P109_EXISTE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(226499504460535670)
,p_prompt=>'Existe'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(201981631951808922)
,p_name=>'P109_'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(226499504460535670)
,p_prompt=>'Periodo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20251002140846Z')
,p_updated_on=>wwv_flow_imp.dz('20251002140846Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(114922378491411527)
,p_name=>'Cerrar Dialogo'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(226498368479535669)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(114922471268411528)
,p_event_id=>wwv_flow_imp.id(114922378491411527)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(226498368479535669)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(118842042729907519)
,p_name=>'New'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(118842108905907520)
,p_event_id=>wwv_flow_imp.id(118842042729907519)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'WITH ftedata AS (',
'    SELECT',
'        anio,',
'        mes,',
'        codigojde                    producto,',
'        codigojde                    codproducto,',
'        mes                          mes_valor,',
'        bodega,',
'        ubicacion                    locacion,',
'        lote,',
'        glcls,',
'        SUM(cantidadmeskrdx) / 10000 kardex_cantidad,',
'        SUM(costomeskrdx) / 100      kardex_costo,',
'        SUM(cantidadmesasof) / 10000 asof_cantidad,',
'        SUM(costomesasof) / 100      asof_costo',
'    FROM',
'        t_apex_asofkardex',
'    WHERE',
'            flag = ''asof_kardex''',
'        AND anio = :p109_anio - 2000',
'        AND mes = nvl(:p109_mes, mes)',
'        AND bodega = nvl(:p109_bodega, bodega)',
'        AND glcls = nvl(:p109_glcls, glcls)',
'        AND codigojde = nvl(:p109_producto, codigojde)',
'    GROUP BY',
'        anio,',
'        mes,',
'        codigojde,',
'        bodega,',
'        ubicacion,',
'        lote,',
'        glcls',
')',
'SELECT',
'    COUNT(1) ',
'       INTO :P109_EXISTE',
'FROM',
'    ftedata',
'WHERE',
'    (',
'        CASE',
'            WHEN round(kardex_cantidad, 2) <> round(asof_cantidad, 2)',
'                 OR round(kardex_costo, 2) <> round(asof_costo, 2) THEN',
'                1',
'            ELSE',
'                0',
'        END',
'    ) = 1',
'ORDER BY',
'    bodega,',
'    mes_valor       ;'))
,p_attribute_02=>'P109_ANIO,P109_MES,P109_PERIODO,P109_GLCLS,P109_EXISTE'
,p_attribute_03=>'P109_EXISTE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(118842215492907521)
,p_event_id=>wwv_flow_imp.id(118842042729907519)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if($v("P109_EXISTE")==0){',
'$(''#Regresar'').trigger(''click'')',
'}'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(129198297396469907)
,p_name=>'Inserta'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P109_INSERTA'
,p_condition_element=>'P109_INSERTA'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129198475039469909)
,p_event_id=>wwv_flow_imp.id(129198297396469907)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129198570292469910)
,p_event_id=>wwv_flow_imp.id(129198297396469907)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Esta seguro de inserta datos en el AsOf'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(129198345623469908)
,p_event_id=>wwv_flow_imp.id(129198297396469907)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'Inserta'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(118841797957907516)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'P109_EXISTE'
,p_process_when_type=>'ITEM_IS_ZERO'
,p_internal_uid=>118841797957907516
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(129198642448469911)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Inserta'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'    v_initm  NUMBER;',
'    v_inlitm NCHAR(25);',
'    v_inaitm NCHAR(25);',
'    v_inmcu  NCHAR(12);',
'    v_inlocn NCHAR(20);',
'    v_inlotn NCHAR(30);',
'    v_inglpt NCHAR(4);',
'    v_infy   NUMBER;',
'    v_intday number;',
'    v_inupmj NUMBER(6);',
'    v_injobn NCHAR(10) ;',
'BEGIN',
'    v_infy   := :P109_ANIO - 2000;',
'    v_inmcu  := lpad(trim(:P109_CODIGOBODEGA), 12, '' '');',
'    v_inlocn := lpad(trim(:P109_UBICACION), 20, '' '');',
'    v_inlotn := lpad(trim(:P109_LOTE), 30, '' '');',
'    v_inglpt := lpad(trim(:P109_CODIGOGLCLAS), 4, '' '');',
'    v_initm  := :P109_CODIGOCORTO;',
'    v_intday :=to_number( TO_CHAR(Sysdate, ''HH24MISS''));',
'    v_inupmj:=pk_commons.f_g2jde(sysdate);',
'    v_injobn:=''JDELBNSERV'';',
'    ',
'    SELECT imitm,   imlitm,   imaitm',
'    INTO v_initm, v_inlitm, v_inaitm',
'    FROM f4101@jdedtadl',
'    WHERE imitm = v_initm;',
'',
'    INSERT INTO F41112@jdedtadl (INDCT,  INFY,INCTRY,  INITM,  INLITM,  INAITM,  INMCU,  INLOCN,  INLOTN,  INGLPT,INAN8,INSHAN,INNQ01,INNQ02,INNQ03,INNQ04,INNQ05,INNQ06,INNQ07,INNQ08,INNQ09,INNQ10,INNQ11,INNQ12,INNQ13,INNQ14,INAN01,INAN02,INAN03,INAN'
||'04,INAN05,INAN06,INAN07,INAN08,INAN09,INAN10,INAN11,INAN12,INAN13,INAN14,INCUMA,INCMQT,    INAISL,     INBIN,  INTDAY,INUSER,       INPID,  INUPMJ,  INJOBN) ',
'    VALUES                         ( ''BF'',v_infy,  ''20'',v_initm,v_inlitm,v_inaitm,v_inmcu,v_inlocn,v_inlotn,v_inglpt,    0,     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,     0, '
||'    0,     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,''        '',''        '',v_INTDAY,''ORCL'',''          '',v_inupmj,v_injobn);',
'    COMMIT;',
'    :P109_UBICACION:=null;',
'    :P109_LOTE:=null;',
'    :P109_CODIGOCORTO:=null;',
'    :P109_INSERTA:=null;',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'Inserta'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>129198642448469911
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(113342509147862457)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Setup Interface'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT  ',
'     TRIM(to_char(to_date(:p109_mes,''MM''),''Month''))  || '' / '' || :P109_ANIO',
'into',
'     :P109_PERIODO',
'from dual  ;',
'',
':P109_USUARIO:=:APP_USER;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>113342509147862457
);
wwv_flow_imp.component_end;
end;
/
