prompt --application/pages/page_00190
begin
--   Manifest
--     PAGE: 00190
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>190
,p_name=>'GESTION TRIBUTARIA - EJECUCION CONFIGURACION'
,p_alias=>'GESTION-TRIBUTARIA-EJECUCION-CONFIGURACION'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Ejecuci\00F3n de Configuraci\00F3n')
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function P190_getScrollEl() {',
'    return document.querySelector(',
'      ''#rptConfiguraciones .a-IRR-content, '' +',
'      ''#rptConfiguraciones .t-IRR-regionBody, '' +',
'      ''#rptConfiguraciones .t-Report-body, '' +',
'      ''#rptConfiguraciones .t-Region-body''',
'    ) || document.querySelector(''#rptConfiguraciones'');',
'}',
'',
'function P190_getModalScrollEl() {',
'  var rpt = document.querySelector(''#rptConfiguraciones'');',
'  var dialogs = document.querySelectorAll(''.ui-dialog-content'');',
'  for (var i = 0; i < dialogs.length; i++) {',
'    if (dialogs[i].contains(rpt)) return dialogs[i];',
'  }',
'  while (rpt && rpt !== document.body) {',
'    if (rpt.classList && (rpt.classList.contains("ui-dialog-content") || rpt.classList.contains("t-Dialog-body"))) return rpt;',
'    rpt = rpt.parentElement;',
'  }',
'  return document.scrollingElement || document.documentElement;',
'}',
'',
'function P190_saveScrollPosition() {',
'  var sc = P190_getScrollEl();',
'  var modal = P190_getModalScrollEl();',
'  window._p190ScrollState = {',
'    win: window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0,',
'    reg: sc ? sc.scrollTop : 0,',
'    modal: modal ? modal.scrollTop : 0',
'  };',
'  $s("P190_POSICION", window._p190ScrollState.win);',
'}',
'',
'function P190_saveTarget(p_kind, p_dat_id, p_prc_id) {',
'  window._p190Target = {',
'    kind: String(p_kind || ""),',
'    datid: String(p_dat_id || ""),',
'    prcid: String(p_prc_id || "")',
'  };',
'}',
'',
'function P190_restoreScrollPosition() {',
'  var state = window._p190ScrollState;',
'  if (!state) {',
'    var itemY = Number($v("P190_POSICION"));',
'    if (!Number.isFinite(itemY)) return;',
'    state = { win: itemY, reg: 0, modal: itemY };',
'  }',
'  var apply = function () {',
'    if (document.activeElement && document.activeElement !== document.body) {',
'      try { document.activeElement.blur(); } catch (e) {}',
'    }',
'    var sc = P190_getScrollEl();',
'    var modal = P190_getModalScrollEl();',
'    if (sc) sc.scrollTop = state.reg || 0;',
'    if (modal) modal.scrollTop = state.modal || state.win || 0;',
'    window.scrollTo(0, state.win || 0);',
'    var rpt = document.querySelector(''#rptConfiguraciones'');',
'    var target = window._p190Target;',
'    var btn = null;',
'    if (target) {',
'      var selector = ''#rptConfiguraciones button[data-p190-kind="'' + target.kind + ''"][data-p190-datid="'' + target.datid + ''"][data-p190-prcid="'' + target.prcid + ''"]'';',
'      btn = document.querySelector(selector);',
'    }',
'    if (btn) {',
'      var row = btn.closest("tr") || btn;',
'      try { row.scrollIntoView({ block: "center", inline: "nearest" }); } catch (e) { row.scrollIntoView(); }',
'    }',
'    if (rpt) {',
'      if (!rpt.hasAttribute("tabindex")) rpt.setAttribute("tabindex", "-1");',
'      try { rpt.focus({ preventScroll: true }); } catch (e) {}',
'    }',
'  };',
'  apply();',
'  setTimeout(apply, 50);',
'  setTimeout(apply, 250);',
'  setTimeout(apply, 700);',
'}',
'',
'(function () {',
'',
'  var reg = apex.region(''rptConfiguraciones'');',
'  if (!reg || !reg.element) return;',
'',
unistr('  // guardar posici\00F3n antes del refresh'),
'  reg.element.on(''apexbeforerefresh'', function () {',
'    if (!window._p190ScrollState) P190_saveScrollPosition();',
'  });',
'',
unistr('  // restaurar posici\00F3n al terminar'),
'  reg.element.on(''apexafterrefresh'', function () {',
'    P190_restoreScrollPosition();',
'  });',
'})();',
'',
'',
'function abrirPopup(p_dat_id,p_tob_id,p_cdf_des) {',
'    P190_saveScrollPosition();',
'    P190_saveTarget("archivo", p_dat_id, p_tob_id);',
'    console.log("p_tob_id:"+p_tob_id+",p_dat_id:"+p_dat_id);',
'    $s("P190_TIPOOBJETO","");',
'    $s("P190_DATID","");',
'    $s("P190_CFGDESCRIPCION","");',
'    $s("P190_TIPOEJECUCION","" );    ',
'    $s("P190_IDPROCESO","" );    ',
'',
'',
'    $s("P190_TIPOOBJETO",p_tob_id);',
'    $s("P190_DATID",p_dat_id );',
'    $s("P190_CFGDESCRIPCION",p_cdf_des);',
'	var scrollTopPosition = $(window).scrollTop();',
'	$s("P190_POSICION",scrollTopPosition);',
'	console.log(scrollTopPosition);',
'    ',
'}',
'function ejecutarSQL(p_dat_id,p_tipo_ejecucion,p_prc_id) {',
'    P190_saveScrollPosition();',
'    P190_saveTarget(p_tipo_ejecucion, p_dat_id, p_prc_id);',
'    $s("P190_TIPOOBJETO","");',
'    $s("P190_DATID","");',
'    $s("P190_CFGDESCRIPCION","");',
'    $s("P190_TIPOEJECUCION","" );    ',
'    $s("P190_IDPROCESO","" );    ',
'',
'    $s("P190_DATID",p_dat_id);',
'    $s("P190_TIPOEJECUCION",p_tipo_ejecucion );    ',
'    $s("P190_IDPROCESO",p_prc_id ); ',
'	var scrollTopPosition = $(window).scrollTop();',
'	$s("P190_POSICION",scrollTopPosition);',
'	console.log(scrollTopPosition);	   ',
'    $(''#btnEnviarPag'').trigger("click");   ',
'}',
'function abrirError(p_dat_id) {',
'    P190_mostrarDetallePopup("Cargando detalle del error...");',
'    apex.server.process(',
'        "GET_DATOSERROR",',
'        { x01: p_dat_id },',
'        {',
'            dataType: "json",',
'            success: function (data) {',
'                P190_mostrarDetallePopup(data.datoserror || "Sin detalle de error.", !!data.datoserror);',
'            },',
'            error: function (jqXHR, textStatus) {',
'                P190_mostrarDetallePopup("No se pudo cargar el detalle del error: " + textStatus);',
'            }',
'        }',
'    );',
'}',
'function abrirSqlError(p_dat_id) {',
'    P190_mostrarDetallePopup("Cargando consulta SQL...");',
'    apex.server.process(',
'        "GET_CONSULTASQL",',
'        { x01: p_dat_id },',
'        {',
'            dataType: "json",',
'            success: function (data) {',
'                P190_mostrarDetallePopup(data.consultasql || "Sin consulta SQL registrada.", !!data.consultasql, !!data.consultasql);',
'            },',
'            error: function (jqXHR, textStatus) {',
'                P190_mostrarDetallePopup("No se pudo cargar la consulta SQL: " + textStatus);',
'            }',
'        }',
'    );',
'}',
'function mostrarErrorFormulario() {',
'    P190_mostrarDetallePopup("Revisar el contenido del formulario");',
'}',
'function P190_mostrarDetallePopup(p_texto, p_copiable, p_forzar_grande) {',
'    var texto = String(p_texto || "");',
'    var lineas = (texto.match(/\n/g) || []).length + 1;',
'    var grande = !!p_forzar_grande || texto.length > 500 || lineas > 8;',
'    $("#P190_DATOSERROR_DISPLAY").text(texto);',
'    $("#P190_DETALLE_POPUP").toggleClass("p190-can-copy", !!p_copiable);',
'    apex.theme.openRegion("dlgError");',
'    setTimeout(function () {',
'        var dlg = $("#dlgError_dialog");',
'        try { dlg.position({ my: "center", at: "center", of: window }); } catch (e) {}',
'    }, 0);',
'}',
'function P190_copiarDetallePopup() {',
'    var texto = $("#P190_DATOSERROR_DISPLAY").text();',
'    if (!texto) return;',
'    function ok() {',
'        if (apex.message && apex.message.showPageSuccess) {',
'            apex.message.showPageSuccess("Contenido copiado al portapapeles");',
'        }',
'    }',
'    function error() {',
'        var el = document.getElementById("P190_DATOSERROR_DISPLAY");',
'        if (window.getSelection && document.createRange && el) {',
'            var range = document.createRange();',
'            range.selectNodeContents(el);',
'            var sel = window.getSelection();',
'            sel.removeAllRanges();',
'            sel.addRange(range);',
'        }',
'        if (typeof mensajeError === "function") {',
'            mensajeError("No se pudo copiar automaticamente. El contenido quedo seleccionado.");',
'        } else if (apex.message && apex.message.alert) {',
'            apex.message.alert("No se pudo copiar automaticamente. El contenido quedo seleccionado.");',
'        }',
'    }',
'    if (P190_copiarDetallePorEvento(texto)) {',
'        ok();',
'        return;',
'    }',
'    if (navigator.clipboard && navigator.clipboard.writeText) {',
'        navigator.clipboard.writeText(texto).then(ok).catch(error);',
'    } else {',
'        error();',
'    }',
'}',
'function P190_copiarDetallePorEvento(texto) {',
'    var copiado = false;',
'    function handler(e) {',
'        e.preventDefault();',
'        e.clipboardData.setData("text/plain", texto);',
'        copiado = true;',
'    }',
'    document.addEventListener("copy", handler);',
'    try {',
'        document.execCommand("copy");',
'    } catch (e) {',
'        copiado = false;',
'    }',
'    document.removeEventListener("copy", handler);',
'    return copiado;',
'}',
'function P190_copiarDetalleFallback(texto) {',
'    var ta = document.createElement("textarea");',
'    ta.value = texto;',
'    ta.style.position = "fixed";',
'    ta.style.left = "-9999px";',
'    ta.style.top = "0";',
'    ta.setAttribute("readonly", "readonly");',
'    document.body.appendChild(ta);',
'    ta.focus();',
'    ta.select();',
'    ta.setSelectionRange(0, texto.length);',
'    var copiado = false;',
'    try { copiado = document.execCommand("copy"); } catch (e) { copiado = false; }',
'    document.body.removeChild(ta);',
'    return copiado;',
'}',
'function P190_mostrarDatosCargados() {',
'    if (typeof mensajeExito === "function") {',
'        mensajeExito("Datos Cargados");',
'    } else if (apex.message && apex.message.showPageSuccess) {',
'        apex.message.showPageSuccess("Datos Cargados");',
'    }',
'}',
'function P190_finalizaCargaDatos() {',
'    var mensaje = String($v("P190_MENSAJE") || "");',
'    if (mensaje.toUpperCase().indexOf("ERROR") === 0) {',
'        $s("P190_ESTADO_EJECUCION","ERROR");',
'        mensajeError(mensaje);',
'    } else {',
'        $s("P190_ESTADO_EJECUCION","TERMINADO");',
'        location.reload();',
'    }',
'    ocultarBarra();',
'}',
'function P190_actualizarEstadoEjecucion() {',
'    apex.server.process("GET_ESTADO_EJECUCION", {',
'        pageItems: "#P190_IDPERIODO"',
'    }, {',
'        dataType: "json"',
'    }).done(function(data) {',
'        if (data && data.estado) {',
'            $s("P190_ESTADO_EJECUCION", data.estado);',
'        }',
'    });',
'}',
'function subirArchivo(input) {',
'    ',
'    const file = input.files[0];',
'    if (file) {',
'        if (file.name.endsWith(''.txt'') || file.name.endsWith(''.csv'')) {',
'            console.log(''Subiendo archivo:'', file.name);',
'        } else {',
'            alert(''Solo se permiten archivos .txt o .csv'');',
'            input.value = '''';',
'        }',
'    }',
'}',
'',
'',
'window.autoRefresh = (function () {',
'  let t = null;',
'',
'  function parseSecs() {',
'    const v = Number(apex.item("P190_REFRESH_SEC").getValue());',
'    return Number.isFinite(v) && v > 0 ? v : 0;',
'  }',
'',
'  function stop() {',
'    if (t) { clearInterval(t); t = null; }',
'  }',
'',
'  function start(refreshFn) {',
'    stop();',
'    const secs = parseSecs();',
'    if (!secs) return;',
'    t = setInterval(refreshFn, secs * 1000);',
'  }',
'',
'  return { start, stop };',
'})();',
'',
'function doRefresh(){',
'  P190_saveScrollPosition();',
'  P190_actualizarEstadoEjecucion();',
'  location.reload();',
'}'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(secItems).hide();',
'P190_actualizarEstadoEjecucion();',
'autoRefresh.start(doRefresh);',
'',
'',
' '))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.a-IRR-chartView,  .a-IRR-detailView, .a-IRR-groupByView, .a-IRR-iconViewTable, .a-IRR-pivotView ,.a-IRR-controls-item--controlBreak ,.a-IRR-reportSummary-item--controlBreak{',
'    border-top-color: #E6E6E6;',
'    display: block;',
'}',
'#rptConfiguraciones .a-IRR-header,',
'#rptConfiguraciones .a-IRR-header a,',
'#rptConfiguraciones .a-IRR-headerLink,',
'#rptConfiguraciones .a-IRR-headerLabel,',
'#rptConfiguraciones th,',
'#rptConfiguraciones th a,',
'#rptConfiguraciones th span,',
'#rptConfiguraciones th .fa {',
'    color: #000000 !important;',
'}',
'#P190_DETALLE_POPUP {',
'    position: relative;',
'    height: 100%;',
'}',
'#P190_COPY_SQL {',
'    display: none;',
'    position: absolute;',
'    top: 8px;',
'    right: 8px;',
'    z-index: 2;',
'    width: 28px;',
'    height: 28px;',
'    padding: 0;',
'    border: 1px solid #b6c2d2;',
'    border-radius: 4px;',
'    background: #ffffff;',
'    color: #2f5f9f;',
'    cursor: pointer;',
'}',
'#P190_DETALLE_POPUP.p190-can-copy #P190_COPY_SQL {',
'    display: inline-flex;',
'    align-items: center;',
'    justify-content: center;',
'}',
'#P190_DETALLE_POPUP.p190-can-copy #P190_DATOSERROR_DISPLAY {',
'    padding-top: 44px;',
'}',
'#P190_DATOSERROR_DISPLAY {',
'    white-space: pre-wrap;',
'    overflow: auto;',
'    box-sizing: border-box;',
'    width: 100%;',
'    height: 100%;',
'    min-height: 0;',
'    margin: 0;',
'    padding: 12px;',
'    font-family: Consolas, monospace;',
'    font-size: 12px;',
'    line-height: 1.45;',
'    background: #fff7f7;',
'    border: 1px solid #f0b3b3;',
'    color: #611a15;',
'    border-radius: 4px;',
'}',
'#dlgError_dialog {',
'    max-width: calc(100vw - 40px) !important;',
'    max-height: calc(100vh - 40px) !important;',
'}',
'#dlgError_dialog.p190-dialog-small {',
'    width: 420px !important;',
'    height: auto !important;',
'}',
'#dlgError_dialog.p190-dialog-small .ui-dialog-content {',
'    height: auto !important;',
'    max-height: 35vh !important;',
'    box-sizing: border-box;',
'    overflow: auto;',
'}',
'#dlgError_dialog.p190-dialog-large {',
'    width: 85vw !important;',
'    height: 75vh !important;',
'}',
'#dlgError_dialog.p190-dialog-large .ui-dialog-content {',
'    height: calc(75vh - 52px) !important;',
'    max-height: calc(75vh - 52px) !important;',
'    box-sizing: border-box;',
'    overflow: hidden;',
'}',
'#dlgError,',
'#dlgError .t-Region,',
'#dlgError .t-Region-body,',
'#dlgError .t-Region-bodyWrap {',
'    height: 100%;',
'    box-sizing: border-box;',
'}',
''))
,p_step_template=>wwv_flow_imp.id(37774372912106498)
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch'
,p_overwrite_navigation_list=>'Y'
,p_navigation_list_position=>'SIDE'
,p_navigation_list_id=>wwv_flow_imp.id(38387485495133968)
,p_navigation_list_template_id=>wwv_flow_imp.id(37858104930106556)
,p_nav_list_template_options=>'#DEFAULT#:t-WizardSteps--vertical:t-WizardSteps--displayLabels'
,p_page_component_map=>'18'
,p_last_updated_on=>wwv_flow_imp.dz('20260702154641Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8909480915245735)
,p_plug_name=>'Items'
,p_region_name=>'secItems'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>40
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9708380388489237)
,p_plug_name=>'CONFIGURACIONES'
,p_region_name=>'rptConfiguraciones'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with tob as (',
'    select id_tabla tob_id, descripcion tob_descripcion',
'    from data.t_corp_udc',
'    where activo = ''1''',
'    and id_cabecera = ''FINZ_GT02''',
'    and id_tabla != ''000''',
'), tpr as (',
'    select id_tabla tpr_id, descripcion tpr_descripcion',
'    from data.t_corp_udc',
'    where activo = ''1''',
'    and id_cabecera = ''FINZ_GT01''',
'    and id_tabla != ''000''',
'), base_cfg as (',
'    select',
'        case',
'            when cfg.tipoobjeto in (''002'', ''003'', ''004'', ''006'') then 0',
'            when cfg.tipoobjeto = ''001'' then 1',
'            when cfg.idproceso in (''999'') then 2',
'            when cfg.tipoobjeto >= ''900'' then 3',
'            when cfg.tipoobjeto = ''005'' then 9',
'            else 99',
'        end orden,',
'        gtb.id idgtb,',
'        cfg.id idcfg,',
'        act.item tpr_id,',
'        gtb.compania,',
'        gtb.periodo,',
'        gtb.observacion observaciongtb,',
'        tpr.tpr_id || '' '' || tpr.tpr_descripcion tpr_descripcion,',
'        cfg.idproceso,',
'        cfg.almacenamiento,',
'        cfg.descripcion,',
'        cfg.estado,',
'        cfg.erp,',
'        cfg.esquema,',
'        cfg.tipoobjeto,',
'        cfg.objeto,',
'        cfg.columnas,',
'        cfg.condiciones,',
'        cfg.parametros,',
'        cfg.validaciones,',
'        cfg.tiene_resumen,',
'        cfg.validaanterior,',
'        cfg.idformulariosri',
'    from t_finz_gestiontributaria gtb',
'        cross join table(pk_commons.f_dividirtexto(gtb.actividades,'':'')) act',
'        inner join data.t_finz_gestiontributariacfg cfg on act.item = cfg.idproceso',
'            and gtb.compania = cfg.compania',
'            and cfg.estado = 1',
'        left join tpr on act.item = tpr.tpr_id',
'    where gtb.id = :P190_IDPERIODO',
'    and gtb.compania = :G_COMPANIA',
'    and gtb.estado != 3',
'), base_det as (',
'    select',
'        det.id iddet,',
'        det.idgtb,',
'        det.idproceso,',
'        det.observacion,',
'        to_number(kfg.item) idcfg',
'    from data.t_finz_gestiontributariadet det,',
'        table(pk_commons.f_dividirtexto(det.idcfg,'':'')) kfg',
'    where det.idgtb = :P190_IDPERIODO',
')',
'select',
'    cfg.idgtb, det.iddet, cfg.idcfg, dat.id iddat, tob.tob_id idtob, cfg.tpr_id idtpr,',
'    cfg.orden,',
'    case',
'        when cfg.tipoobjeto in (''002'', ''003'', ''004'', ''006'') then 1',
'        when cfg.tipoobjeto = ''005'' then 3',
'        else 2',
'    end seccion_orden,',
'    case',
'        when cfg.tipoobjeto in (''002'', ''003'', ''004'', ''006'') then ''Archivos''',
'        when cfg.tipoobjeto = ''005'' then ''Formularios''',
'        else ''Procesos''',
'    end seccion,',
'    cfg.tpr_descripcion,',
'    cfg.descripcion cfg_descripcion,',
'    tob.tob_descripcion,',
'    case',
'        when dat.id is null then null',
'        when dat.estado = 3 then ''<span style="color:red">Actividad Cerrada</span>''',
'        when cfg.tipoobjeto = ''001'' then ''<button type="button" data-p190-kind="sql" data-p190-datid="''||dat.id||''" data-p190-prcid="''||cfg.tpr_id||''" style="background: #3cbc75;color: white;" class="t-Button t-Button--primary  t-Button--small fa fa-'
||'file-sql-o" onClick="ejecutarSQL(''''''|| dat.id || '''''',''''sql'''',''''''|| cfg.tpr_id || '''''');"> Ejecutar</button>''',
'        when cfg.tipoobjeto >= ''900'' then ''<button type="button" data-p190-kind="res" data-p190-datid="''||dat.id||''" data-p190-prcid="''||cfg.tpr_id||''" style="background: #3cbc75;color: white;" class="t-Button t-Button--primary  t-Button--small fa fa'
||'-file-sql-o" onClick="ejecutarSQL(''''''|| dat.id || '''''',''''res'''',''''''|| cfg.tpr_id || '''''');"> Ejecutar</button>''',
'        when cfg.tipoobjeto in (''002'', ''003'', ''004'') then ''<button type="button" style="background: #093ac3c2;color: white;" class="t-Button t-Button--primary  t-Button--small ''||case cfg.tipoobjeto when ''002'' then ''fa fa-file-excel-o'' when ''003'' the'
||'n ''fa fa-file-csv-o'' when ''004'' then ''fa fa-file-text'' when ''005'' then ''fa fa-forms'' end|| ''" data-p190-kind="archivo" data-p190-datid="''||dat.id||''" data-p190-prcid="''||cfg.tipoobjeto||''" onClick="abrirPopup(''''''|| dat.id || '''''',''''''|| cfg.tipoobjeto '
||'|| '''''',''''''|| apex_escape.html(cfg.descripcion)|| '''''');">Archivo</button>''',
'        when cfg.tipoobjeto in (''005'') then ''<button type="button" style="background: #c35609d4;color: white;" class="t-Button t-Button--primary  t-Button--small ''||case cfg.tipoobjeto when ''002'' then ''fa fa-file-excel-o'' when ''003'' then ''fa fa-file-'
||'csv-o'' when ''004'' then ''fa fa-file-text'' when ''005'' then ''fa fa-forms'' end|| ''" data-p190-kind="archivo" data-p190-datid="''||dat.id||''" data-p190-prcid="''||cfg.tipoobjeto||''" onClick="abrirPopup(''''''|| dat.id || '''''',''''''|| cfg.tipoobjeto || '''''',''''''|| a'
||'pex_escape.html(cfg.descripcion)|| '''''');"> Formulario</button>''',
'        else ''''',
'    end accion_html,',
'    case',
'        when dat.estado = 3 then ''<button type="button" style="background:transparent;color:#d63b25;border:none;" class="t-Button t-Button--primary  t-Button--small fa fa-gears" disabled> </button>''',
'        when cfg.tipoobjeto = ''005'' then ''''',
'        else ''<button type="button" style="background:transparent;color:#d63b25;border:none;" class="t-Button t-Button--primary  t-Button--small fa fa-gears" onClick="ejecutarSQL(''''''|| ''''|| '''''',''''''|| ''''|| '''''',''''''|| cfg.tpr_id || '''''');"> </button>''',
'    end accion_html2,',
'    case when dat.datosmod is null then null else nvl(dat.fechmodi, dat.fechcrea) end fecha_carga,',
'    case',
'        when dat.datosmod is null then ''<span aria-hidden="true" title="''||case cfg.descripcion when ''DATOS_FORMULARIO 103'' then ''Revise el FORMULARIO DE PRUEBA DEPARTAMENTAL'' else '' '' end ||''" style="color:red" class="fa fa-times-circle"></span>''',
'        else ''<span aria-hidden="true" style="color:green" class="fa fa-check-circle"></span>''',
'    end estatus,',
'    case',
'        when dat.id is null then null',
'        when dat.datosmod is null then null',
'        else case when cfg.tipoobjeto = ''005'' then '''' else ''<span aria-hidden="true" style="color:blue" class="fa fa-eye"></span>'' end',
'    end ver_datos,',
'    case',
'        when dat.id is null then null',
'        when dat.datosmod is null then null',
'        else case when cfg.tipoobjeto = ''005'' then '''' else ''<span aria-hidden="true" style="color:blue" class="fa fa-eye"></span>'' end',
'    end ver_datos2,',
'    case',
'        when dat.id is null then null',
'        when upper(tob.tob_descripcion) like ''%FORMULARIO%'' and dat.datosmod is null then ''<button type="button" title="Ver detalle del error" style="background:transparent;color:#d63b25;border:none;" class="fa fa-comments" onclick="mostrarErrorFormu'
||'lario();"> </button>''',
'        when dat.datoserror is null then null',
'        else ''<button type="button" title="Ver detalle del error" style="background:transparent;color:#d63b25;border:none;" class="fa fa-comments" onClick="abrirError(''''''|| dat.id || '''''');"> </button>''',
'    end error_html,',
'    case',
'        when dat.id is null then null',
'        when dat.datoserror is null then null',
'        when upper(nvl(v(''APP_USER''), sys_context(''APEX$SESSION'',''APP_USER''))) not in (''EMASABANDA'', ''DDELACRUZ'') then null',
'        else ''<button type="button" title="Ver SQL ejecutado" style="background:transparent;color:''||case when dat.consultasql is null then ''#8b5a2b'' else ''#2f5f9f'' end||'';border:none;" class="fa fa-file-sql-o" onClick="abrirSqlError(''''''|| dat.id || '
||''''''');"> </button>''',
'    end sql_html,',
'    pk_finz_gestiontributaria.f_obtener_alias_json(cfg.idcfg) alias',
'from base_cfg cfg',
'    left join base_det det on det.idgtb = cfg.idgtb and det.idproceso = cfg.idproceso and det.idcfg = cfg.idcfg',
'    left join data.t_finz_gestiontributariadatos dat on det.iddet = dat.iddet and cfg.idcfg = dat.idcfg',
'    left join tob on cfg.tipoobjeto = tob.tob_id',
'WHERE   cfg.tpr_id in (SELECT DISTINCT ITEM FROM TABLE(PK_COMMONS.F_DIVIDIRTEXTO(:P190_ACTIVIDADESPERMISO,'':'') ) )',
'order by seccion_orden, IDTPR, cfg.orden, IDTOB'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'G_COMPANIA,P190_IDPERIODO'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(9724751300582211)
,p_max_row_count=>'1000000'
,p_allow_report_saving=>'N'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_finder_drop_down=>'N'
,p_report_list_mode=>'NONE'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_highlight=>'N'
,p_show_computation=>'N'
,p_show_aggregate=>'N'
,p_show_chart=>'N'
,p_show_group_by=>'N'
,p_show_pivot=>'N'
,p_show_flashback=>'N'
,p_show_reset=>'N'
,p_show_help=>'N'
,p_download_formats=>'XLSX'
,p_enable_mail_download=>'N'
,p_owner=>'EMASABANDA'
,p_internal_uid=>9724751300582211
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9725900513582223)
,p_db_column_name=>'TPR_DESCRIPCION'
,p_display_order=>10
,p_column_identifier=>'I'
,p_column_label=>'Proceso'
,p_allow_sorting=>'N'
,p_allow_highlighting=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9725706850582221)
,p_db_column_name=>'CFG_DESCRIPCION'
,p_display_order=>20
,p_column_identifier=>'G'
,p_column_label=>unistr('Configuraci\00F3n')
,p_allow_sorting=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9726138087582225)
,p_db_column_name=>'TOB_DESCRIPCION'
,p_display_order=>40
,p_column_identifier=>'K'
,p_column_label=>'Tipo de Objeto Origen'
,p_allow_sorting=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9728289814582246)
,p_db_column_name=>'ORDEN'
,p_display_order=>70
,p_column_identifier=>'M'
,p_column_label=>'Orden'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(270616000000000101)
,p_db_column_name=>'SECCION_ORDEN'
,p_display_order=>75
,p_column_identifier=>'AA'
,p_column_label=>'Seccion Orden'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(270616000000000102)
,p_db_column_name=>'SECCION'
,p_display_order=>80
,p_column_identifier=>'AB'
,p_column_label=>'Seccion'
,p_allow_sorting=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9728555220582249)
,p_db_column_name=>'IDGTB'
,p_display_order=>90
,p_column_identifier=>'O'
,p_column_label=>'Idgtb'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9728699552582250)
,p_db_column_name=>'IDDET'
,p_display_order=>110
,p_column_identifier=>'P'
,p_column_label=>'Iddet'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11712428451621001)
,p_db_column_name=>'IDCFG'
,p_display_order=>120
,p_column_identifier=>'Q'
,p_column_label=>'Idcfg'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11712547789621002)
,p_db_column_name=>'IDTOB'
,p_display_order=>130
,p_column_identifier=>'R'
,p_column_label=>'Idtob'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11712691176621003)
,p_db_column_name=>'IDTPR'
,p_display_order=>150
,p_column_identifier=>'S'
,p_column_label=>'Idtpr'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11712802019621005)
,p_db_column_name=>'IDDAT'
,p_display_order=>160
,p_column_identifier=>'T'
,p_column_label=>'Iddat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(45213046235289104)
,p_db_column_name=>'ALIAS'
,p_display_order=>170
,p_column_identifier=>'Y'
,p_column_label=>'Alias'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11713512433621012)
,p_db_column_name=>'FECHA_CARGA'
,p_display_order=>180
,p_column_identifier=>'U'
,p_column_label=>'Fecha Carga'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY HH24:MI:SS'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(11713618264621013)
,p_db_column_name=>'ESTATUS'
,p_display_order=>190
,p_column_identifier=>'V'
,p_column_label=>'Estado'
,p_allow_highlighting=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(9725234654582216)
,p_db_column_name=>'ACCION_HTML'
,p_display_order=>200
,p_column_identifier=>'E'
,p_column_label=>unistr('Procesa Configuraci\00F3n')
,p_allow_sorting=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(43067729453983325)
,p_db_column_name=>'ACCION_HTML2'
,p_display_order=>210
,p_column_identifier=>'X'
,p_column_label=>'Ejecuta Proceso'
,p_allow_sorting=>'N'
,p_allow_highlighting=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(30882627978092413)
,p_db_column_name=>'VER_DATOS'
,p_display_order=>220
,p_column_identifier=>'W'
,p_column_label=>'-'
,p_alternative_label=>'Ver Datos'
,p_column_link=>'f?p=&APP_ID.:187:&SESSION.::&DEBUG.:RR,187:P187_IDDATO,P187_ACTIVIDADES,P187_NOMBRE,P187_ALIAS,P187_IDPERIODO:#IDDAT#,#IDTPR#,#CFG_DESCRIPCION#,#ALIAS#,#IDGTB#'
,p_column_linktext=>'#VER_DATOS#'
,p_allow_sorting=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(214748483563636307)
,p_db_column_name=>'VER_DATOS2'
,p_display_order=>230
,p_column_identifier=>'Z'
,p_column_label=>'-'
,p_column_link=>'f?p=&APP_ID.:187:&SESSION.::&DEBUG.:RR,187:P187_IDPERIODO,P187_IDDATO,P187_ACTIVIDADES,P187_NOMBRE,P187_ALIAS:&P190_IDPERIODO.,#IDDAT#,#IDTPR#,#CFG_DESCRIPCION#,#ALIAS#'
,p_column_linktext=>'#VER_DATOS2#'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(270616000000000002)
,p_db_column_name=>'ERROR_HTML'
,p_display_order=>240
,p_column_identifier=>'Y'
,p_column_label=>'-'
,p_allow_sorting=>'N'
,p_allow_highlighting=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(270616000000000004)
,p_db_column_name=>'SQL_HTML'
,p_display_order=>245
,p_column_identifier=>'AC'
,p_column_label=>'-'
,p_allow_sorting=>'N'
,p_allow_highlighting=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_allow_hide=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(10909362271940035)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'109094'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'SECCION:ACCION_HTML2:TPR_DESCRIPCION:FECHA_CARGA:CFG_DESCRIPCION:TOB_DESCRIPCION:ACCION_HTML:VER_DATOS:ERROR_HTML:SQL_HTML:'
,p_sort_column_1=>'SECCION_ORDEN'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'IDTPR'
,p_sort_direction_2=>'ASC'
,p_sort_column_3=>'ORDEN'
,p_sort_direction_3=>'ASC'
,p_sort_column_4=>'IDTOB'
,p_sort_direction_4=>'ASC'
,p_sort_column_5=>'0'
,p_sort_direction_5=>'ASC'
,p_sort_column_6=>'0'
,p_sort_direction_6=>'ASC'
,p_break_on=>'SECCION:ACCION_HTML2:TPR_DESCRIPCION'
,p_break_enabled_on=>'SECCION:ACCION_HTML2:TPR_DESCRIPCION'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11712958711621006)
,p_plug_name=>'Botones'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38290276266120143)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(270616000000000001)
,p_plug_name=>'Detalle del Error'
,p_region_name=>'dlgError'
,p_region_css_classes=>'js-dialog-size720x480 js-dialog-autoheight'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37804699672106518)
,p_plug_display_sequence=>50
,p_location=>null
,p_plug_source=>'<div id="P190_DETALLE_POPUP"><button type="button" id="P190_COPY_SQL" class="fa fa-copy" title="Copiar SQL" onclick="P190_copiarDetallePopup();"></button><pre id="P190_DATOSERROR_DISPLAY"></pre></div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(374181685114975101)
,p_plug_name=>'Titulo'
,p_title=>'PERIODO: &P190_PERIODO_NOMBRE.        <br />Estado ejecucion: &P190_ESTADO_EJECUCION.    '
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>50
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(579354299256876327)
,p_plug_name=>'Alerta'
,p_region_name=>'secAlerta'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--warning:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(37782629797106503)
,p_plug_display_sequence=>20
,p_plug_item_display_point=>'BELOW'
,p_location=>null
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P190_ALERTAERROR'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11713020873621007)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(11712958711621006)
,p_button_name=>'Cerrar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Cerrar'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9725473072582218)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(8909480915245735)
,p_button_name=>'Excel'
,p_button_static_id=>'btnExcel'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Excel'
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_redirect_url=>'f?p=109:193:&SESSION.::&DEBUG.:RR,300::'
,p_icon_css_classes=>'fa-file-excel-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(9728131656582245)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(8909480915245735)
,p_button_name=>'CSV'
,p_button_static_id=>'btnCsv'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Csv'
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_redirect_url=>'f?p=109:193:&SESSION.::&DEBUG.:RR,193::'
,p_icon_css_classes=>'fa-file-csv-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(30883458836092421)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(8909480915245735)
,p_button_name=>'TEXTO'
,p_button_static_id=>'btnTexto'
,p_button_action=>'REDIRECT_APP'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Texto'
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_redirect_url=>'f?p=109:193:&SESSION.::&DEBUG.:RR,193::'
,p_icon_css_classes=>'fa-file-text'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(42565309062705613)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(8909480915245735)
,p_button_name=>'Formulario188'
,p_button_static_id=>'btnForm188'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Formulario188'
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_redirect_url=>'f?p=&APP_ID.:188:&SESSION.::&DEBUG.:RR,188:P188_IDDAT:&P190_DATID.'
,p_icon_css_classes=>'fa-forms'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(65695869125146316)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(8909480915245735)
,p_button_name=>'Formulario196'
,p_button_static_id=>'btnForm196'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Formulario'
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_redirect_url=>'f?p=&APP_ID.:196:&SESSION.::&DEBUG.:RR,196:P196_IDDAT:&P190_DATID.'
,p_icon_css_classes=>'fa-forms'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(125468087154948915)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(8909480915245735)
,p_button_name=>'Formulario197'
,p_button_static_id=>'btnForm197'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Formulario'
,p_button_position=>'RIGHT_OF_TITLE'
,p_button_redirect_url=>'f?p=&APP_ID.:197:&SESSION.::&DEBUG.:CR,196:P196_IDDAT:&P190_DATID.'
,p_icon_css_classes=>'fa-forms'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13869217370746201)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(8909480915245735)
,p_button_name=>'SQL'
,p_button_static_id=>'btnEnviarPag'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Aceptar'
,p_button_position=>'RIGHT_OF_TITLE'
,p_warn_on_unsaved_changes=>null
,p_confirm_message=>unistr('Este proceso puede tardar varios minutos en completarse. \00BFDesea continuar?')
,p_confirm_style=>'warning'
,p_icon_css_classes=>'fa-file-sql-o'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9725320423582217)
,p_name=>'P190_SESSION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(8909480915245735)
,p_prompt=>'Session'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9726907075582233)
,p_name=>'P190_TIPOARCHIVO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(8909480915245735)
,p_prompt=>'Tipoarchivo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9727028292582234)
,p_name=>'P190_SEPARADOR'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(8909480915245735)
,p_prompt=>'Separador'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9727159576582235)
,p_name=>'P190_CABECERA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(8909480915245735)
,p_prompt=>'Cabecera'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9728379247582247)
,p_name=>'P190_IDPERIODO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(8909480915245735)
,p_prompt=>'Idperiodo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11712730493621004)
,p_name=>'P190_DATID'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(8909480915245735)
,p_prompt=>'Datid'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13869669107746205)
,p_name=>'P190_TIPOEJECUCION'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(8909480915245735)
,p_prompt=>'Tipoejecucion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(43067803047983326)
,p_name=>'P190_IDPROCESO'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(8909480915245735)
,p_prompt=>'Idproceso'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(50248432533209231)
,p_name=>'P190_POSICION'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(8909480915245735)
,p_prompt=>'Posicion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57498593907306243)
,p_name=>'P190_TIPOOBJETO'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(8909480915245735)
,p_prompt=>'Tipoobjeto'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57498833355306246)
,p_name=>'P190_CARGAROBJETO'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(8909480915245735)
,p_prompt=>'Tipoobjeto'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(65695778573146315)
,p_name=>'P190_CFGDESCRIPCION'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(8909480915245735)
,p_prompt=>'Cfgdescripcion'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(70243931957060101)
,p_name=>'P190_MENSAJE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(8909480915245735)
,p_prompt=>'Mensaje'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(70243931957060102)
,p_name=>'P190_ESTADO_EJECUCION'
,p_item_sequence=>11
,p_item_plug_id=>wwv_flow_imp.id(8909480915245735)
,p_prompt=>'Estado ejecucion'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(180873738536614246)
,p_name=>'P190_REFRESH_SEC'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(8909480915245735)
,p_item_default=>'30'
,p_prompt=>'Refresh Sec'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(201983346378814937)
,p_name=>'P190_PERIODO_NOMBRE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(8909480915245735)
,p_prompt=>'Periodo:'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(284750438501074929)
,p_name=>'P190_ACTIVIDADESROL'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(8909480915245735)
,p_prompt=>'Actividadesrol'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(284751721301074942)
,p_name=>'P190_ACTIVIDADESPERMISO'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(8909480915245735)
,p_prompt=>'Actividadespermiso'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(579354545248876339)
,p_name=>'P190_ALERTAERROR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(579354299256876327)
,p_prompt=>'Alertaerror'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_label_column_span=>0
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(9727933848582243)
,p_name=>'CierraDialogoArchivosExcel'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(9725473072582218)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13869921434746208)
,p_event_id=>wwv_flow_imp.id(9727933848582243)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43065990755983307)
,p_event_id=>wwv_flow_imp.id(9727933848582243)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin    ',
'    PK_FINZ_GESTIONTRIBUTARIA.sp_datosExcelCSV2Json(:P190_DATID,''datos'');',
'    :P190_mensaje:=''exito'';',
'exception when others then',
'    :P190_mensaje:=''ERROR SQLCODE: ''||sqlcode||'' SQLERRM: ''||sqlerrm||'' TRACE: ''||dbms_utility.format_error_backtrace;',
'end;',
''))
,p_attribute_02=>'P190_DATID'
,p_attribute_03=>'P190_MENSAJE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43066096297983308)
,p_event_id=>wwv_flow_imp.id(9727933848582243)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'P190_finalizaCargaDatos();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9728083970582244)
,p_event_id=>wwv_flow_imp.id(9727933848582243)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'CARGAR_DATOS'
,p_attribute_02=>'Y'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11713274912621009)
,p_name=>'CierraDialogoArchivosCSV'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(9728131656582245)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(13869884790746207)
,p_event_id=>wwv_flow_imp.id(11713274912621009)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43066291884983310)
,p_event_id=>wwv_flow_imp.id(11713274912621009)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin    ',
'    PK_FINZ_GESTIONTRIBUTARIA.sp_datosExcelCSV2Json(:P190_DATID,''datos'');',
'    :P190_mensaje:=''exito'';',
'exception when others then',
'    :P190_mensaje:=''ERROR SQLCODE: ''||sqlcode||'' SQLERRM: ''||sqlerrm||'' TRACE: ''||dbms_utility.format_error_backtrace;',
'end;'))
,p_attribute_02=>'P190_DATID'
,p_attribute_03=>'P190_MENSAJE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43066312277983311)
,p_event_id=>wwv_flow_imp.id(11713274912621009)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'P190_finalizaCargaDatos();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11713353345621010)
,p_event_id=>wwv_flow_imp.id(11713274912621009)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'CARGAR_DATOS'
,p_attribute_02=>'Y'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(43065632096983304)
,p_name=>'CierraDialogoArchivosFRM188'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(42565309062705613)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43065724179983305)
,p_event_id=>wwv_flow_imp.id(43065632096983304)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mostrarBarra();',
'$s("P190_ESTADO_EJECUCION","EJECUTANDO...");',
'apex.region("rptConfiguraciones").refresh();',
'P190_mostrarDatosCargados();',
'ocultarBarra();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(65695993419146317)
,p_name=>'CierraDialogoArchivosFRM196'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(65695869125146316)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(65696061469146318)
,p_event_id=>wwv_flow_imp.id(65695993419146317)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mostrarBarra();',
'$s("P190_ESTADO_EJECUCION","EJECUTANDO...");',
'apex.region("rptConfiguraciones").refresh();',
'P190_mostrarDatosCargados();',
'ocultarBarra();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(125468173010948916)
,p_name=>'CierraDialogoArchivosFRM197'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(125468087154948915)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosecanceldialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(125468217865948917)
,p_event_id=>wwv_flow_imp.id(125468173010948916)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mostrarBarra();',
'$s("P190_ESTADO_EJECUCION","EJECUTANDO...");',
'apex.region("rptConfiguraciones").refresh();',
'P190_mostrarDatosCargados();',
'ocultarBarra();'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(30883589373092422)
,p_name=>'CierraDialogoArchivosTexto'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(30883458836092421)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(30883667390092423)
,p_event_id=>wwv_flow_imp.id(30883589373092422)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43066427122983312)
,p_event_id=>wwv_flow_imp.id(30883589373092422)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin    ',
'    PK_FINZ_GESTIONTRIBUTARIA.sp_datosExcelCSV2Json(:P190_DATID,''datos'');',
'    :P190_mensaje:=''exito'';',
'exception when others then',
'    :P190_mensaje:=''ERROR SQLCODE: ''||sqlcode||'' SQLERRM: ''||sqlerrm||'' TRACE: ''||dbms_utility.format_error_backtrace;',
'end;'))
,p_attribute_02=>'P190_DATID'
,p_attribute_03=>'P190_MENSAJE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43066511566983313)
,p_event_id=>wwv_flow_imp.id(30883589373092422)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'P190_finalizaCargaDatos();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(30883794475092424)
,p_event_id=>wwv_flow_imp.id(30883589373092422)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'CARGAR_DATOS'
,p_attribute_02=>'Y'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(43067343491983321)
,p_name=>'Ejecutar SQL'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(13869217370746201)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43066939640983317)
,p_event_id=>wwv_flow_imp.id(43067343491983321)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mostrarBarra();',
'$s("P190_ESTADO_EJECUCION","EJECUTANDO...");',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43067092416983318)
,p_event_id=>wwv_flow_imp.id(43067343491983321)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    pk_finz_gestiontributaria.sp_ejecutar_actividad(',
'        p_iddat =>:P190_DATID, ',
'        p_idgtb =>:P190_IDPERIODO,',
'        p_idpro =>:P190_IDPROCESO',
'    );',
'		:P190_MENSAJE :='''';',
'exception when others then ',
'     pk_commons.sp_apex_log(''109.190.da_sql.pk_finz_gestiontributaria.sp_log'',1,''v_log_dsc'',''ERROR SQLCODE: ''||SQLCODE||chr(10)||chr(9)||''SQLERRM: ''||SQLERRM||chr(10)||chr(9)||''TRACE: ''||DBMS_UTILITY.format_error_backtrace,null,''PK_FINZ_GESTIONTRIBUT'
||'ARIA.sp_ejecutar_actividad p_iddat=''||:P190_DATID||'', p_idgtb=''||:P190_IDPERIODO||'', p_idpro=''||:P190_IDPROCESO);',
'	:P190_MENSAJE :=''Error:''||sqlerrm;',
'end;'))
,p_attribute_02=>'P190_DATID,P190_IDPERIODO,P190_IDPROCESO'
,p_attribute_03=>'P190_MENSAJE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43067119986983319)
,p_event_id=>wwv_flow_imp.id(43067343491983321)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'P190_finalizaCargaDatos();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(43067205846983320)
,p_event_id=>wwv_flow_imp.id(43067343491983321)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'CARGAR_DATOS'
,p_attribute_02=>'Y'
,p_server_condition_type=>'NEVER'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(44521977027941343)
,p_name=>'cambia DATID'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P190_DATID'
,p_condition_element=>'P190_DATID'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(44522056360941344)
,p_event_id=>wwv_flow_imp.id(44521977027941343)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P190_CARGAROBJETO:=0;',
'if (:P190_TIPOOBJETO=''002'')then/*excel*/',
'    :G_VALOR1:=0;',
'    :G_VALOR2:=1;',
'    :G_VALOR3:=null;',
'    :P190_CARGAROBJETO:=1;',
'elsif (:P190_TIPOOBJETO=''003'')then/*csv punto y coma*/',
'    :G_VALOR1:=0;',
'    :G_VALOR2:=2;',
'    :G_VALOR3:=''pco'';',
'    :P190_CARGAROBJETO:=2;',
'elsif (:P190_TIPOOBJETO =''004'')then/*csv tabulacion*/',
'    :G_VALOR1:=0;',
'    :G_VALOR2:=2;',
'    :G_VALOR3:=''tab'';',
'    :P190_CARGAROBJETO:=3;',
'elsif (:P190_TIPOOBJETO =''005'')then/*csv tabulacion*/',
'    :G_VALOR1:=:P190_DATID;',
'    :P190_CARGAROBJETO:=4;    ',
'elsif (:P190_TIPOOBJETO =''006'')then/*csv coma*/',
'    :G_VALOR1:=0;',
'    :G_VALOR2:=2;',
'    :G_VALOR3:=''com'';',
'    :P190_CARGAROBJETO:=5;',
'end if;',
''))
,p_attribute_02=>'P190_CARGAROBJETO,P190_TIPOOBJETO,P190_SEPARADOR,P190_DATID'
,p_attribute_03=>'G_VALOR1,G_VALOR2,G_VALOR3,P190_CARGAROBJETO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(57498973331306247)
,p_event_id=>wwv_flow_imp.id(44521977027941343)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    if ($v("P190_TIPOOBJETO")==="002"){',
'        $(''#btnExcel'').trigger("click");',
'    }',
'    if ($v("P190_TIPOOBJETO")==="003" || $v("P190_TIPOOBJETO")==="006"){',
'        $(''#btnCsv'').trigger("click");',
'    } ',
'    if ($v("P190_TIPOOBJETO")==="004"){',
'        $(''#btnTexto'').trigger("click");',
'    } ',
'    if ($v("P190_TIPOOBJETO")==="005"){',
'        let cadena = $v("P190_CFGDESCRIPCION");',
'        let contieneFormYPrue = cadena.includes("FORM") && cadena.includes("PRUEBA");',
'        let contieneAnexoInform = cadena.includes("ANEXO") && cadena.includes("INFORMANTE");',
'        let contieneFormYRete = cadena.includes("FORM") && cadena.includes("RETENCION");',
'',
'        if (contieneFormYPrue) {',
'            $(''#btnForm188'').trigger("click");',
'        }',
'		if (contieneFormYRete) {',
'            $(''#btnForm196'').trigger("click");',
'        }        ',
'      ',
'		if (contieneAnexoInform) {',
'            $(''#btnForm197'').trigger("click");',
'        }',
'      ',
'    }',
' '))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(50248525630209232)
,p_name=>'New'
,p_event_sequence=>90
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(9708380388489237)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(50248617499209233)
,p_event_id=>wwv_flow_imp.id(50248525630209232)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'    var scrollTopPosition = $(window).scrollTop();',
'    console.warn(scrollTopPosition);',
'    $s("P190_POSICION",scrollTopPosition);'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8909611672245737)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SetupPage'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with ',
'    t_tmpb as(',
'        SELECT count(cfg.TIPOOBJETO ) over(partition by cfg.IDPROCESO) CONTADOR, cfg.idproceso,cfg.TIPOOBJETO',
'        FROM t_finz_gestiontributariacfg cfg',
'        left  join DATA.t_finz_gestiontributariadet det on cfg.IDPROCESO=det.IDPROCESO',
'        left  join DATA.t_finz_gestiontributariadatos dat on det.id = dat.iddet and cfg.id=dat.IDCFG',
'        WHERE cfg.compania = :G_COMPANIA',
'        and det.idgtb=:P190_IDPERIODO',
'        and cfg.estado=1',
'    )',
'    select  listagg( distinct DESCRIPCION,'', '')DESCRIPCION',
'    into :P190_ALERTAERROR',
'    from  t_tmpb a ',
'    inner join "DATA"."T_CORP_UDC" u on (ID_CABECERA=''FINZ_GT01'' AND idproceso= ID_TABLA and ID_TABLA < ''900'')',
'    where not exists (SELECT * FROM  t_tmpb b where a.idproceso= b.idproceso and TIPOOBJETO>= ''900'') and CONTADOR>1;',
unistr('    :P190_ALERTAERROR:=CASE WHEN :P190_ALERTAERROR IS NOT NULL THEN (''Resultados finales de ''||:P190_ALERTAERROR||'' dependen de tener una configuraci\00F3n de RESULTADO DE DATOS'') ELSE '''' END ;'),
'    DBMS_OUTPUT.PUT_LINE(:P190_ALERTAERROR);',
'',
'',
'	  SELECT REPLACE(to_char(to_date(PERIODO ,''YYYYMM''),''Month/YYYY''),'' '','''') INTO :P190_PERIODO_NOMBRE FROM T_FINZ_GESTIONTRIBUTARIA where id =:P190_IDPERIODO;',
'',
'    declare',
'        v_running number := 0;',
'        v_estado_periodo number;',
'        v_datos_periodo number := 0;',
'    begin',
'        select count(1)',
'        into v_running',
'        from user_scheduler_running_jobs',
'        where job_name like ''GT_EJEC_ACT_'' || :P190_IDPERIODO || ''\_%'' escape ''\'';',
'',
'',
'        if v_running > 0 then',
'                    select listagg(job_name ,''|'')||'' - EJECUTANDO...''',
'        into :P190_ESTADO_EJECUCION',
'        from user_scheduler_running_jobs',
'        where job_name like ''GT_EJEC_ACT_'' || :P190_IDPERIODO || ''\_%'' escape ''\'';',
'',
'            --:P190_ESTADO_EJECUCION := v_running||'' - EJECUTANDO...'';',
'        else',
'            begin',
'                select estado',
'                into v_estado_periodo',
'                from t_finz_gestiontributaria',
'                where id = :P190_IDPERIODO;',
'            exception',
'                when no_data_found then',
'                    v_estado_periodo := null;',
'            end;',
'',
'            select count(1)',
'            into v_datos_periodo',
'            from data.t_finz_gestiontributariadet det',
'            join data.t_finz_gestiontributariadatos dat on dat.iddet = det.id',
'            where det.idgtb = :P190_IDPERIODO',
'              and rownum = 1;',
'',
'            :P190_ESTADO_EJECUCION := case',
'                when nvl(v_estado_periodo, 0) = 2 or v_datos_periodo > 0 then ''TERMINADO''',
'                else ''SIN EJECUTAR''',
'            end;',
'        end if;',
'    exception',
'        when others then',
'            :P190_ESTADO_EJECUCION := ''SIN INFORMACION'';',
'    end;',
' ',
'',
'BEGIN',
'    SELECT VALOR2,DESCRIPCION INTO :P190_ACTIVIDADESPERMISO,:P190_ACTIVIDADESROL',
'    FROM DATA.T_CORP_UDC',
'    WHERE ID_TABLA <> ''000''',
'      AND ACTIVO = ''1''',
'      AND ID_CABECERA = ''FINZ_GT00''',
'      AND NVL(UPPER(VALOR), UPPER(:APP_USER)) = UPPER(:APP_USER)',
'    ORDER BY DECODE(UPPER(VALOR), UPPER(:APP_USER), 1, 2)',
'    FETCH FIRST 1 ROW ONLY;',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>8909611672245737
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11713196751621008)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'CerrarDialogo'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(11713020873621007)
,p_internal_uid=>11713196751621008
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(270616000000000007)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_ESTADO_EJECUCION'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_estado varchar2(50);',
'    v_running number := 0;',
'    v_estado_periodo number;',
'    v_datos_periodo number := 0;',
'begin',
'    select count(1)',
'    into v_running',
'    from user_scheduler_running_jobs',
'    where job_name like ''GT_EJEC_ACT_'' || :P190_IDPERIODO || ''\_%'' escape ''\'';',
'',
'    if v_running > 0 then',
'        l_estado := ''EJECUTANDO...'';',
'    else',
'        begin',
'            select estado',
'            into v_estado_periodo',
'            from t_finz_gestiontributaria',
'            where id = :P190_IDPERIODO;',
'        exception',
'            when no_data_found then',
'                v_estado_periodo := null;',
'        end;',
'',
'        select count(1)',
'        into v_datos_periodo',
'        from data.t_finz_gestiontributariadet det',
'        join data.t_finz_gestiontributariadatos dat on dat.iddet = det.id',
'        where det.idgtb = :P190_IDPERIODO',
'          and rownum = 1;',
'',
'        l_estado := case',
'            when nvl(v_estado_periodo, 0) = 2 or v_datos_periodo > 0 then ''TERMINADO''',
'            else ''SIN EJECUTAR''',
'        end;',
'    end if;',
'',
'    apex_json.open_object;',
'    apex_json.write(''estado'', l_estado);',
'    apex_json.close_object;',
'exception',
'    when others then',
'        apex_json.open_object;',
'        apex_json.write(''estado'', ''SIN INFORMACION'');',
'        apex_json.close_object;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>270616000000000007
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(270616000000000003)
,p_process_sequence=>20
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_DATOSERROR'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_error clob;',
'begin',
'    select datoserror',
'    into l_error',
'    from data.t_finz_gestiontributariadatos',
'    where id = to_number(apex_application.g_x01);',
'',
'    apex_json.open_object;',
'    apex_json.write(''datoserror'', l_error);',
'    apex_json.close_object;',
'exception',
'    when no_data_found then',
'        apex_json.open_object;',
'        apex_json.write(''datoserror'', ''No existe detalle de error para el registro seleccionado.'');',
'        apex_json.close_object;',
'    when others then',
'        apex_json.open_object;',
'        apex_json.write(''datoserror'', ''ERROR SQLCODE: ''||sqlcode||chr(10)||''SQLERRM: ''||sqlerrm||chr(10)||''TRACE: ''||dbms_utility.format_error_backtrace);',
'        apex_json.close_object;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>270616000000000003
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(270616000000000005)
,p_process_sequence=>30
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GET_CONSULTASQL'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_sql clob;',
'begin',
'    if upper(nvl(v(''APP_USER''), sys_context(''APEX$SESSION'',''APP_USER''))) not in (''EMASABANDA'', ''DDELACRUZ'') then',
'        apex_json.open_object;',
'        apex_json.write(''consultasql'', ''Usuario no autorizado para ver la consulta SQL.'');',
'        apex_json.close_object;',
'        return;',
'    end if;',
'',
'    select consultasql',
'    into l_sql',
'    from data.t_finz_gestiontributariadatos',
'    where id = to_number(apex_application.g_x01)',
'      and datoserror is not null;',
'',
'    apex_json.open_object;',
'    apex_json.write(''consultasql'', l_sql);',
'    apex_json.close_object;',
'exception',
'    when no_data_found then',
'        apex_json.open_object;',
'        apex_json.write(''consultasql'', ''No existe consulta SQL con error para el registro seleccionado.'');',
'        apex_json.close_object;',
'    when others then',
'        apex_json.open_object;',
'        apex_json.write(''consultasql'', ''ERROR SQLCODE: ''||sqlcode||chr(10)||''SQLERRM: ''||sqlerrm||chr(10)||''TRACE: ''||dbms_utility.format_error_backtrace);',
'        apex_json.close_object;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>270616000000000005
);
wwv_flow_imp.component_end;
end;
/
