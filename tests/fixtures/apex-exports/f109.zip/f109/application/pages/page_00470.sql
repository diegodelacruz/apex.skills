prompt --application/pages/page_00470
begin
--   Manifest
--     PAGE: 00470
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>470
,p_name=>unistr('Activos Fijos - Impresi\00F3n Etiqueta')
,p_alias=>unistr('ACTIVOS-FIJOS-IMPRESI\00D3N-ETIQUETA')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Activos Fijos - Impresi\00F3n Etiqueta')
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>'https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var ancho = $v(''P470_ANCHO_MM'') || ''85.60'';',
'var alto  = $v(''P470_ALTO_MM'') || ''53.98'';',
'',
'var stylePrint = document.createElement(''style'');',
'stylePrint.innerHTML = `',
'@page {',
'	size: ${ancho}mm ${alto}mm;',
'	margin: 0;',
'}',
'',
'@media print {',
'	html,',
'	body {',
'		width: ${ancho}mm;',
'		height: ${alto}mm;',
'		margin: 0;',
'		padding: 0;',
'		overflow: hidden;',
'	}',
'',
'	body * {',
'		visibility: hidden;',
'	}',
'',
'	.etiqueta-af,',
'	.etiqueta-af * {',
'		visibility: visible;',
'	}',
'',
'	.etiqueta-af {',
'		position: fixed;',
'		top: 0;',
'		left: 0;',
'		width: ${ancho}mm;',
'		height: ${alto}mm;',
'		margin: 0;',
'		border: 1px solid #000;',
'		box-sizing: border-box;',
'	}',
'}',
'`;',
'document.head.appendChild(stylePrint);',
'',
'if ($v(''P470_CODACTIVO'')) {',
'    JsBarcode("#barcode", $v("P470_CODACTIVO"), {',
'        format: "CODE128",',
'        displayValue: false,',
'        margin: 0,',
'        width: 1.9,',
'        height: 60',
'    });',
'}',
'',
'$(regOcultos).hide();'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.etiqueta-af {',
'	box-sizing: border-box;',
'	padding: 1.2mm 2.2mm 0.4mm 2.2mm;',
'	border: none;',
'	background: #fff;',
'	font-family: Arial, sans-serif;',
'	display: grid;',
'	grid-template-rows: auto auto 1fr auto;',
'	row-gap: 0;',
'	overflow: hidden;',
'}',
'',
'.etiqueta-header {',
'	display: flex;',
'	flex-direction: column;',
'	align-items: center;',
'	justify-content: center;',
'	gap: 0;',
'	margin: 0;',
'	padding: 0;',
'}',
'',
'.etiqueta-empresa {',
'	font-size: 15pt;',
'	font-weight: 700;',
'	text-align: center;',
'	line-height: 1;',
'	letter-spacing: 0.2px;',
'	margin: 0 0 10px;',
'	padding: 0;',
'}',
'',
'.etiqueta-titulo {',
'	font-size: 12pt;',
'	font-weight: 600;',
'	text-align: center;',
'	line-height: 1;',
'	letter-spacing: 0.5px;',
'	margin: 0 0 10px;',
'	padding: 0;',
'}',
'',
'.etiqueta-body {',
'	display: flex;',
'	align-items: center;',
'	justify-content: center;',
'	min-height: 0;',
'	height: 100%;',
'	margin: 0;',
'	padding: 0;',
'}',
'',
'.etiqueta-barcode {',
'	width: 100%;',
'	height: 100%;',
'	display: flex;',
'	align-items: center;',
'	justify-content: center;',
'	margin: 0;',
'	padding: 0;',
'}',
'',
'.etiqueta-barcode svg {',
'	display: block;',
'	width: 100%;',
'	height: auto;',
'	max-width: 100%;',
'	max-height: 100%;',
'}',
'',
'.etiqueta-footer {',
'	display: flex;',
'	align-items: flex-start;',
'	justify-content: center;',
'	margin: 0;',
'	padding: 0;',
'}',
'',
'.etiqueta-codigo {',
'	font-family: Consolas, "Courier New", monospace;',
'	font-size: 14pt;',
'	font-weight: 700;',
'	letter-spacing: 10.0px;',
'	text-align: center;',
'	line-height: 1;',
'	margin:  10px 0 0;',
'	padding: 0;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_created_on=>wwv_flow_imp.dz('20260408205222Z')
,p_last_updated_on=>wwv_flow_imp.dz('20260409135522Z')
,p_created_by=>'DDELACRUZ'
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(420269258541760233)
,p_plug_name=>'Ocultos'
,p_region_name=>'regOcultos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20260408205344Z')
,p_updated_on=>wwv_flow_imp.dz('20260408210541Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(420269557848760236)
,p_plug_name=>unistr('C\00F3digo de Barras')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="etiqueta-af" id="etiqueta-af"',
'     style="width: &P470_ANCHO_MM.mm; height: &P470_ALTO_MM.mm;">',
'	<div class="etiqueta-header">',
'		<div class="etiqueta-empresa">ZAIMELLA DEL ECUADOR S.A.</div>',
'		<div class="etiqueta-titulo">ACTIVO FIJO</div>',
'	</div>',
'',
'	<div class="etiqueta-body">',
'		<div class="etiqueta-barcode">',
'			<svg id="barcode"></svg>',
'		</div>',
'	</div>',
'',
'	<div class="etiqueta-footer">',
'		<div class="etiqueta-codigo">&P470_CODACTIVO.</div>',
'	</div>',
'</div>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20260408205645Z')
,p_updated_on=>wwv_flow_imp.dz('20260408215005Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(420269619113760237)
,p_plug_name=>'Botones'
,p_parent_plug_id=>wwv_flow_imp.id(420269557848760236)
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>15
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20260408205645Z')
,p_updated_on=>wwv_flow_imp.dz('20260408213227Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(420270509200760246)
,p_plug_name=>'Mensaje'
,p_parent_plug_id=>wwv_flow_imp.id(420269557848760236)
,p_region_template_options=>'t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--removeHeading'
,p_plug_template=>wwv_flow_imp.id(37782629797106503)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>'&P470_MENSAJE_ETIQUETA.'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20260408213227Z')
,p_updated_on=>wwv_flow_imp.dz('20260408213326Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(420269727266760238)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(420269619113760237)
,p_button_name=>'IMPRIMIR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_image_alt=>'Imprimir'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P470_CODACTIVO'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_row=>'Y'
,p_created_on=>wwv_flow_imp.dz('20260408205645Z')
,p_updated_on=>wwv_flow_imp.dz('20260408212735Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(420269352544760234)
,p_name=>'P470_CODACTIVO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(420269258541760233)
,p_prompt=>'Codactivo'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260408205345Z')
,p_updated_on=>wwv_flow_imp.dz('20260408205645Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(420269453714760235)
,p_name=>'P470_COMPANIA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(420269258541760233)
,p_prompt=>'Compania'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260408205645Z')
,p_updated_on=>wwv_flow_imp.dz('20260408205645Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(420270100783760242)
,p_name=>'P470_ANCHO_MM'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(420269258541760233)
,p_prompt=>'Ancho (mm)'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260408212650Z')
,p_updated_on=>wwv_flow_imp.dz('20260408212734Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(420270292243760243)
,p_name=>'P470_ALTO_MM'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(420269258541760233)
,p_prompt=>'Alto (mm)'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260408212650Z')
,p_updated_on=>wwv_flow_imp.dz('20260408212734Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(420270315334760244)
,p_name=>'P470_MENSAJE_ETIQUETA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(420269258541760233)
,p_prompt=>unistr('Tama\00F1o configurado')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_created_on=>wwv_flow_imp.dz('20260408212650Z')
,p_updated_on=>wwv_flow_imp.dz('20260408213227Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(420269964217760240)
,p_name=>'imprimir'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(420269727266760238)
,p_condition_element=>'P470_CODACTIVO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
,p_created_on=>wwv_flow_imp.dz('20260408211155Z')
,p_updated_on=>wwv_flow_imp.dz('20260408211333Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(420270008139760241)
,p_event_id=>wwv_flow_imp.id(420269964217760240)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'window.print();'
,p_created_on=>wwv_flow_imp.dz('20260408211156Z')
,p_updated_on=>wwv_flow_imp.dz('20260408211333Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(420270460044760245)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('Par\00E1metros')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'	select json_value(valor, ''$.ancho_mm'' returning varchar2(20))',
'		, json_value(valor, ''$.alto_mm'' returning varchar2(20))',
'	into :P470_ANCHO_MM',
'		, :P470_ALTO_MM',
'	from data.t_corp_udc',
'	where 1 = 1',
'		and id_cabecera = ''FINZ_AFETQ''',
'		and id_tabla = ''SIZE''',
'		and activo = ''1'';',
'',
unistr('	:P470_MENSAJE_ETIQUETA := ''Tama\00F1o configurado: '''),
'		|| :P470_ANCHO_MM',
'		|| '' mm x ''',
'		|| :P470_ALTO_MM',
'		|| '' mm'';',
'exception',
'	when no_data_found then',
'		:P470_ANCHO_MM := ''85.60'';',
'		:P470_ALTO_MM := ''53.98'';',
unistr('		:P470_MENSAJE_ETIQUETA := ''Tama\00F1o configurado por defecto: 85.60 mm x 53.98 mm'';'),
'end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>420270460044760245
,p_created_on=>wwv_flow_imp.dz('20260408212850Z')
,p_updated_on=>wwv_flow_imp.dz('20260408212850Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
