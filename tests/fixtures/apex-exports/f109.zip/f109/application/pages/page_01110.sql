prompt --application/pages/page_01110
begin
--   Manifest
--     PAGE: 01110
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>1110
,p_name=>'Detalle de Materiales'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Detalle de Materiales'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_last_updated_on=>wwv_flow_imp.dz('20210323050000Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(494056157873929903)
,p_plug_name=>'Detalle'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(494057799510929919)
,p_plug_name=>'Detalle'
,p_parent_plug_id=>wwv_flow_imp.id(494056157873929903)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with',
'w_periodo as (',
'	select :p1110_anno anno, :p1110_mes mes',
'		, pk_commons.f_g2jde(to_date(:p1110_anno||:p1110_mes,''yyyymm'')) fjde',
'		, to_char(add_months(to_date(:p1110_anno||:p1110_mes,''yyyymm''),-1),''yyyy'') annoa',
'		, to_number(to_char(add_months(to_date(:p1110_anno||:p1110_mes,''yyyymm''),-1),''mm'')) mesa',
'		, pk_commons.f_g2jde(add_months(to_date(:p1110_anno||:p1110_mes,''yyyymm''),-1)) fjdea',
'		from dual),',
'w_f4101 as (',
'	select * from w_periodo,f4101@jdedtadl',
') select a.ixkit, a.ixkit dixkit',
', trim(a.ixkitl) ixkitl',
', a.ixmmcu',
', trim(a.ixlitm) ixlitm',
', trim(a.ixlitm) dixlitm',
', a.ixum',
', cs.costo compra',
', a.ixqnty/100000000 cantidad',
', (a.ixqnty/100000000)*cs.costo costomp',
', (a.ixqnty/100000000)*b1.iexscr costomo',
', (a.ixqnty/100000000)*b3.iexscr costocf',
', csa.costo compraa',
', b.ixqnty/100000000 cantidada',
', (b.ixqnty/100000000)*csa.costo costompa',
', (b.ixqnty/100000000)*b1a.iexscr costomoa',
', (b.ixqnty/100000000)*b3a.iexscr costocfa',
', (a.ixqnty - b.ixqnty)/100000000 varcn',
', cs.costo - csa.costo varcm',
', ((a.ixqnty/100000000)*cs.costo) - ((b.ixqnty/100000000)*csa.costo) varmp',
', ((a.ixqnty/100000000)*b1.iexscr) - ((b.ixqnty/100000000)*b1a.iexscr) varmo',
', ((a.ixqnty/100000000)*b3.iexscr) - ((b.ixqnty/100000000)*b3a.iexscr) varcf',
'from w_f4101 z',
'--Mes Actual',
'inner join f3002@jdedtadl a on z.imitm = a.ixkit',
'	and fjde between a.ixefff and decode(nvl(a.ixefft,0),0,140366,a.ixefft)',
'left join dp.t_hist_f30026 a1 on z.anno = (a1.iefy + 2000) and z.mes = a1.iepn and a.ixkit = a1.ieitm and a.ixmmcu = a1.iemmcu and a1.iecost = ''A1''',
'left join dp.t_hist_f30026 b1 on z.anno = (b1.iefy + 2000) and z.mes = b1.iepn and a.ixkit = b1.ieitm and a.ixmmcu = b1.iemmcu and b1.iecost = ''B1''',
'left join dp.t_hist_f30026 b3 on z.anno = (b3.iefy + 2000) and z.mes = b3.iepn and a.ixkit = b3.ieitm and a.ixmmcu = b3.iemmcu and b3.iecost = ''B3''',
'left join dp.t_historico_f4105 cs on cs.tipo_costo = ''02'' and cs.unidad_negocio = a.ixmmcu and cs.codigo_producto = a.ixlitm and to_date(cs.periodo,''yyyymm'') = to_date(anno||mes,''yyyymm'')',
'--Mes Anterior',
'left join f3002@jdedtadl b on z.imitm = b.ixkit and a.ixtbm = b.ixtbm and a.ixopsq = b.ixopsq and a.ixmmcu = b.ixmmcu and a.ixum = b.ixum and a.ixitm = b.ixitm',
'	and fjdea between b.ixefff and decode(nvl(b.ixefft,0),0,140366,b.ixefft)',
'left join dp.t_hist_f30026 a1a on z.annoa = (a1a.iefy + 2000) and z.mesa = a1a.iepn and a.ixkit = a1a.ieitm and a.ixmmcu = a1a.iemmcu and a1a.iecost = ''A1''',
'left join dp.t_hist_f30026 b1a on z.annoa = (b1a.iefy + 2000) and z.mesa = b1a.iepn and a.ixkit = b1a.ieitm and a.ixmmcu = b1a.iemmcu and b1a.iecost = ''B1''',
'left join dp.t_hist_f30026 b3a on z.annoa = (b3a.iefy + 2000) and z.mesa = b3a.iepn and a.ixkit = b3a.ieitm and a.ixmmcu = b3a.iemmcu and b3a.iecost = ''B3''',
'left join dp.t_historico_f4105 csa on csa.tipo_costo = ''02'' and csa.unidad_negocio = a.ixmmcu and csa.codigo_producto = a.ixlitm and to_date(csa.periodo,''yyyymm'') = to_date(annoa||mesa,''yyyymm'')',
'where 1 = 1',
'and a.ixtbm = ''M  ''',
'and a.ixkit = :p1110_codcortoproceso',
'and a.ixmmcu = lpad(:p1110_planta,12,'' '')',
'and a.ixopsq = :p1110_operacion',
';'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P1110_ANNO,P1110_MES,P1110_CODCORTOPROCESO,P1110_PLANTA'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(494057841530929920)
,p_max_row_count=>'1000000'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'HTML:CSV'
,p_enable_mail_download=>'N'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>494057841530929920
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(494057913659929921)
,p_db_column_name=>'IXKIT'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Ixkit'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(494058076932929922)
,p_db_column_name=>'DIXKIT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Dixkit'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(494058163748929923)
,p_db_column_name=>'IXKITL'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>unistr('C\00F3d. Proceso')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(494058234987929924)
,p_db_column_name=>'IXMMCU'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Ixmmcu'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(494059556095929937)
,p_db_column_name=>'DIXLITM'
,p_display_order=>90
,p_column_identifier=>'J'
,p_column_label=>'Desc. Componente'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(464664643734590584)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(494059654186929938)
,p_db_column_name=>'IXLITM'
,p_display_order=>100
,p_column_identifier=>'K'
,p_column_label=>unistr('C\00F3d. Componente')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(494060143793929943)
,p_db_column_name=>'IXUM'
,p_display_order=>110
,p_column_identifier=>'M'
,p_column_label=>'UM'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(494060378040929945)
,p_db_column_name=>'CANTIDAD'
,p_display_order=>120
,p_column_identifier=>'O'
,p_column_label=>'Cant.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(495169686321187201)
,p_db_column_name=>'CANTIDADA'
,p_display_order=>130
,p_column_identifier=>'U'
,p_column_label=>'Cant. (ant)'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(494651498473917003)
,p_db_column_name=>'COMPRA'
,p_display_order=>140
,p_column_identifier=>'S'
,p_column_label=>'Compra'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(494651570753917004)
,p_db_column_name=>'COMPRAA'
,p_display_order=>150
,p_column_identifier=>'T'
,p_column_label=>'Compra (ant)'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(494058302836929925)
,p_db_column_name=>'COSTOMP'
,p_display_order=>160
,p_column_identifier=>'E'
,p_column_label=>'Costo MP'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(494060734822929949)
,p_db_column_name=>'COSTOMPA'
,p_display_order=>170
,p_column_identifier=>'P'
,p_column_label=>'Costo MP (ant)'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(494058492682929926)
,p_db_column_name=>'COSTOMO'
,p_display_order=>180
,p_column_identifier=>'F'
,p_column_label=>'Costo MO'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(494060848171929950)
,p_db_column_name=>'COSTOMOA'
,p_display_order=>190
,p_column_identifier=>'Q'
,p_column_label=>'Costo MO (ant)'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(494058535611929927)
,p_db_column_name=>'COSTOCF'
,p_display_order=>200
,p_column_identifier=>'G'
,p_column_label=>'Costo CF'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(494379113422640201)
,p_db_column_name=>'COSTOCFA'
,p_display_order=>210
,p_column_identifier=>'R'
,p_column_label=>'Costo CF (ant)'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(495170019725187205)
,p_db_column_name=>'VARCN'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Var. Cant.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(495170201067187207)
,p_db_column_name=>'VARMP'
,p_display_order=>240
,p_column_identifier=>'X'
,p_column_label=>'Var. MP'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(495170353817187208)
,p_db_column_name=>'VARMO'
,p_display_order=>250
,p_column_identifier=>'Y'
,p_column_label=>'Var. MO'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(495170404513187209)
,p_db_column_name=>'VARCF'
,p_display_order=>260
,p_column_identifier=>'Z'
,p_column_label=>'Var. CF'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(495170508420187210)
,p_db_column_name=>'VARCM'
,p_display_order=>270
,p_column_identifier=>'AA'
,p_column_label=>'Var. Cmp.'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D0000'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(494132121775193776)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'4941322'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'IXLITM:DIXLITM:IXUM:CANTIDAD:CANTIDADA:VARCN:COMPRA:COMPRAA:VARCM:COSTOMP:COSTOMPA:VARMP:COSTOMO:COSTOMOA:VARMO:COSTOCF:COSTOCFA:VARCF:'
,p_sort_column_1=>'IXLITM'
,p_sort_direction_1=>'ASC'
,p_sort_column_2=>'DIXLITM'
,p_sort_direction_2=>'ASC'
,p_sum_columns_on_break=>'COSTOMP:COSTOMPA:VARMP'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_updated_on=>wwv_flow_imp.dz('20230705164635Z')
,p_created_by=>'CVACA'
,p_updated_by=>'CVACA'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(494056242055929904)
,p_name=>'P1110_ANNO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(494056157873929903)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(494056337104929905)
,p_name=>'P1110_CODCORTOPROCESO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(494056157873929903)
,p_prompt=>'Proceso'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_named_lov=>'LOV_JDE_PRODUCTOS_CODCORTO'
,p_lov=>'select trim(nombreproducto) d, codigocorto r from vt_jde_productos'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(494056497159929906)
,p_name=>'P1110_CODCORTOPRODUCTO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(494056157873929903)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(494056526322929907)
,p_name=>'P1110_MES'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(494056157873929903)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(494058701018929929)
,p_name=>'P1110_PLANTA'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(494056157873929903)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(494059865940929940)
,p_name=>'P1110_OPERACION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(494056157873929903)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
