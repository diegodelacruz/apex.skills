prompt --application/pages/page_00463
begin
--   Manifest
--     PAGE: 00463
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>463
,p_name=>unistr('Activos Fijos - Prog. Auditor\00EDa')
,p_alias=>unistr('PROGRAMACI\00D3N-DE-AUDITOR\00CDA')
,p_step_title=>unistr('Programaci\00F3n Auditor\00EDa')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function borrarArchivo( numeroRegistro ){',
'    ',
'    apex.item("P463_IDREGISTRO").setValue(numeroRegistro);',
'    ',
'}',
'',
'function editarRegistro( idRegistro ){',
'    ',
'    apex.item("P463_IDEDITAR").setValue(idRegistro);',
'    ',
'}',
'',
'function pausarRegistro( pausaRegistro ){',
'    ',
'    apex.item("P463_IDPAUSAR").setValue(pausaRegistro);',
'    ',
'}'))
,p_javascript_code_onload=>'$(regOcultos).hide();'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
,p_last_updated_on=>wwv_flow_imp.dz('20260522065905Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(101711234345016615)
,p_plug_name=>unistr('Configuraci\00F3n General')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(101712366362016626)
,p_plug_name=>unistr('Programaci\00F3n')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>20
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(101712992536016632)
,p_plug_name=>'Responsable'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(95503811913299190)
,p_plug_display_sequence=>30
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(102137791152959404)
,p_plug_name=>'Barra de acciones'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(38289497777120142)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(37761271469106475)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(37860983999106559)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(341501209267855501)
,p_plug_name=>'Ocultos'
,p_region_name=>'regOcultos'
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>1
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
,p_created_on=>wwv_flow_imp.dz('20260203053653Z')
,p_updated_on=>wwv_flow_imp.dz('20260203054324Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(341501313071855502)
,p_plug_name=>'Configurado'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(37806762584106520)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select	x.id',
'	, x.compania',
'	, x.codtipo',
'	, x.codcategoria',
'	, x.codsubcategoria',
'	, x.porcentaje',
'	, x.cantitems',
'	, x.frecuencia',
'	, x.proximaeje',
'	, x.ultimaeje',
'	, x.codusuario',
'	, x.estado',
'	, x.observaciones',
'	, x.programada',
'	, ''<a href="javascript:editarRegistro('' || x.id || '')" class="btn btn-icon btn-sm" title="Editar">''',
'		|| ''<span class="fa fa-pencil"></span>''',
'		|| ''</a>'' editar',
'	, ''<a href="javascript:pausarRegistro('' || x.id || '')" class="btn btn-icon btn-sm" title="''',
'		|| case',
unistr('			when x.estado = ''ACTIVA'' then ''Pausar auditor\00EDa'''),
unistr('			when x.estado = ''PAUSADA'' then ''Reactivar auditor\00EDa'''),
'			else ''Cambiar estado''',
'		end',
'		|| ''">''',
'		|| case',
'			when x.estado = ''ACTIVA'' then ''<span class="fa fa-toggle-on" style="color:#28a745;"></span>''',
'			when x.estado = ''PAUSADA'' then ''<span class="fa fa-toggle-off" style="color:#6c757d;"></span>''',
'			else ''<span class="fa fa-toggle-on" style="color:#6c757d;"></span>''',
'		end',
'		|| ''</a>'' pausar',
unistr('	, ''<a href="javascript:borrarArchivo('' || x.id || '')" class="btn btn-icon btn-sm" title="Eliminar" onclick="return confirm(''''\00BFEliminar esta configuraci\00F3n de auditor\00EDa?'''');">'''),
'		|| ''<span class="fa fa-trash-o" style="color:#dc3545;"></span>''',
'		|| ''</a>'' borra_reg',
'from data.t_finz_activosfijosaud x',
'order by x.proximaeje nulls first',
'	, x.id;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
,p_created_on=>wwv_flow_imp.dz('20260203054621Z')
,p_updated_on=>wwv_flow_imp.dz('20260521220718Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(341501402124855503)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'DDELACRUZ'
,p_internal_uid=>341501402124855503
,p_created_on=>wwv_flow_imp.dz('20260203054621Z')
,p_updated_on=>wwv_flow_imp.dz('20260521220718Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(341501545559855504)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260203054621Z')
,p_updated_on=>wwv_flow_imp.dz('20260203054621Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(341502040925855509)
,p_db_column_name=>'COMPANIA'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Compania'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260203054621Z')
,p_updated_on=>wwv_flow_imp.dz('20260203054621Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(341502284514855511)
,p_db_column_name=>'CODTIPO'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Tipo'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(98576969558658537)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260203054621Z')
,p_updated_on=>wwv_flow_imp.dz('20260203061003Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(341502394351855512)
,p_db_column_name=>'CODCATEGORIA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>unistr('Categor\00EDa')
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(98577560814666584)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260203054621Z')
,p_updated_on=>wwv_flow_imp.dz('20260203061003Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(341502411625855513)
,p_db_column_name=>'CODSUBCATEGORIA'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>unistr('Subcategor\00EDa')
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(98577774561669941)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260203054621Z')
,p_updated_on=>wwv_flow_imp.dz('20260203061003Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(341502521022855514)
,p_db_column_name=>'PORCENTAJE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'% Activos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260203054621Z')
,p_updated_on=>wwv_flow_imp.dz('20260203062026Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(341502604373855515)
,p_db_column_name=>'CANTITEMS'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Cant. Activos'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260203054621Z')
,p_updated_on=>wwv_flow_imp.dz('20260203062026Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(341502971560855518)
,p_db_column_name=>'PROGRAMADA'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Programada'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20260203054621Z')
,p_updated_on=>wwv_flow_imp.dz('20260203055116Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(341503080821855519)
,p_db_column_name=>'FRECUENCIA'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Frecuencia'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(341489306372633407)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260203054621Z')
,p_updated_on=>wwv_flow_imp.dz('20260203061048Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(341503352915855522)
,p_db_column_name=>'PROXIMAEJE'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>unistr('Pr\00F3xima')
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'dd/mm/yyyy'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260203054621Z')
,p_updated_on=>wwv_flow_imp.dz('20260521213734Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(341503441210855523)
,p_db_column_name=>'ULTIMAEJE'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Ultimaeje'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_tz_dependent=>'N'
,p_created_on=>wwv_flow_imp.dz('20260203054621Z')
,p_updated_on=>wwv_flow_imp.dz('20260203055116Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(341503522772855524)
,p_db_column_name=>'CODUSUARIO'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Usuario'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260203054621Z')
,p_updated_on=>wwv_flow_imp.dz('20260521213925Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(341503642740855525)
,p_db_column_name=>'ESTADO'
,p_display_order=>220
,p_column_identifier=>'V'
,p_column_label=>'Estado'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260203054621Z')
,p_updated_on=>wwv_flow_imp.dz('20260203061907Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(341503705655855526)
,p_db_column_name=>'OBSERVACIONES'
,p_display_order=>230
,p_column_identifier=>'W'
,p_column_label=>'Observaciones'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_created_on=>wwv_flow_imp.dz('20260203054621Z')
,p_updated_on=>wwv_flow_imp.dz('20260203055116Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(469082850399075107)
,p_db_column_name=>'EDITAR'
,p_display_order=>240
,p_column_identifier=>'AA'
,p_column_label=>'-'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260521220208Z')
,p_updated_on=>wwv_flow_imp.dz('20260521220313Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(469082935850075108)
,p_db_column_name=>'PAUSAR'
,p_display_order=>250
,p_column_identifier=>'AB'
,p_column_label=>'-'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260521220208Z')
,p_updated_on=>wwv_flow_imp.dz('20260521220313Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(469083012059075109)
,p_db_column_name=>'BORRA_REG'
,p_display_order=>260
,p_column_identifier=>'AC'
,p_column_label=>'-'
,p_allow_sorting=>'N'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_allow_ctrl_breaks=>'N'
,p_allow_aggregations=>'N'
,p_allow_computations=>'N'
,p_allow_charting=>'N'
,p_allow_group_by=>'N'
,p_allow_pivot=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
,p_created_on=>wwv_flow_imp.dz('20260521220208Z')
,p_updated_on=>wwv_flow_imp.dz('20260521220313Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(341525257391913684)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'3415253'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODTIPO:CODCATEGORIA:CODSUBCATEGORIA:PORCENTAJE:CANTITEMS:FRECUENCIA:PROXIMAEJE:CODUSUARIO:ESTADO:BORRA_REG:PAUSAR:'
,p_created_on=>wwv_flow_imp.dz('20260203054622Z')
,p_updated_on=>wwv_flow_imp.dz('20260521220718Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(101710983182016612)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(102137791152959404)
,p_button_name=>'Cancelar'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Cancelar'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'LEFT'
,p_button_redirect_url=>'f?p=&APP_ID.:460:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-arrow-left'
,p_updated_on=>wwv_flow_imp.dz('20260203062214Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(101711077293016613)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(102137791152959404)
,p_button_name=>'Guardar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Guardar'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(101711158355016614)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(102137791152959404)
,p_button_name=>'Ejecutar'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860056812106557)
,p_button_image_alt=>'Ejecutar'
,p_button_position=>'ABOVE_BOX'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'1=2'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-gear'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101711343004016616)
,p_name=>'P463_COMPANIA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(101711234345016615)
,p_item_default=>':G_COMPANIA'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101711460823016617)
,p_name=>'P463_TIPO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(101711234345016615)
,p_prompt=>'Tipo'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_AFI_TIPO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRDL01 D, DRKY R',
'from vt_jde_udcjde where drsy = ''12'' and drrt = ''21''',
'and DRKY is not null',
'order by 2;'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260521211526Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101711730982016620)
,p_name=>'P463_CATEGORIA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(101711234345016615)
,p_prompt=>unistr('Categor\00EDa')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRKY||''-''||DRDL01 D, DRKY R',
'from vt_jde_udcjde where drsy = ''12'' and drrt = ''22''',
'and substr(DRKY,1,1)=:P463_TIPO',
'order by 2;'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P463_TIPO'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260521211548Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101711829994016621)
,p_name=>'P463_SUBCATEGORIA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(101711234345016615)
,p_prompt=>unistr('Sub categor\00EDa')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select DRKY||''-''||DRDL01 D, DRKY R',
'from vt_jde_udcjde@datadl where drsy = ''12'' and drrt = ''23''',
'and substr(DRKY,1,4)=:P463_CATEGORIA',
'order by 2;'))
,p_lov_display_null=>'YES'
,p_lov_cascade_parent_items=>'P463_CATEGORIA'
,p_ajax_optimize_refresh=>'Y'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260521220623Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101711921770016622)
,p_name=>'P463_PORCENTAJE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(101711234345016615)
,p_prompt=>'Porcentaje de activos a auditar'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'numeric'
,p_updated_on=>wwv_flow_imp.dz('20260521211526Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101712009593016623)
,p_name=>'P463_CANTIDADFIJA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(101711234345016615)
,p_prompt=>'Cantidad Fija de Items: '
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'numeric'
,p_updated_on=>wwv_flow_imp.dz('20260203061456Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101712168107016624)
,p_name=>'P463_INCLUIR'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(101711234345016615)
,p_item_default=>'N'
,p_prompt=>'Incluir al asignar'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_SI_NO_SN'
,p_lov=>'.'||wwv_flow_imp.id(341484489208595861)||'.'
,p_cHeight=>1
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20260521211526Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101712203649016625)
,p_name=>'P463_ESTADO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(341501209267855501)
,p_item_default=>'ACTIVA'
,p_prompt=>'Estado'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260521220542Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101712428874016627)
,p_name=>'P463_PROGRAMADA'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(101712366362016626)
,p_item_default=>'N'
,p_prompt=>'Programada'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LOV_SI_NO_SN'
,p_lov=>'.'||wwv_flow_imp.id(341484489208595861)||'.'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20260521211526Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101712530917016628)
,p_name=>'P463_FRECUENCIA'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(101712366362016626)
,p_prompt=>'Frecuencia'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>' LOV_APEX_FRECUENCIA'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select valor codigo, descripcion, valor2 codaumento, to_number(valor3) valaumento ',
'from data.t_corp_udc  where id_cabecera = ''APEX'' and id_tabla = ''FRECUENCIA''',
'order by valor2,to_number(valor3)'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Seleccione'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_updated_on=>wwv_flow_imp.dz('20260521211526Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101712719078016630)
,p_name=>'P463_FECRECORDAR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(101712366362016626)
,p_prompt=>'Recordar hasta'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260521211526Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101712861251016631)
,p_name=>'P463_UMBRALDIAS'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(101712366362016626)
,p_prompt=>unistr('Umbral de d\00EDas sin gesti\00F3n')
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_display_when_type=>'NEVER'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_03=>'left'
,p_attribute_04=>'numeric'
,p_updated_on=>wwv_flow_imp.dz('20260521211526Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101713070223016633)
,p_name=>'P463_USUARIORESPONSABLE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(101712992536016632)
,p_prompt=>'Responsable'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'LOV_APEX_USUARIO'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case',
'	when trim(apellidos) is null then trim(nombres)',
'	when trim(nombres) is null then trim(apellidos)',
'	else trim(apellidos)||'' ''||trim(nombres) end d',
'	, nombreusuario r',
'from data.vt_corp_usuario',
'where 1 = 1',
'order by 1'))
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_updated_on=>wwv_flow_imp.dz('20260521211526Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(101713193676016634)
,p_name=>'P463_OBSERVACION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(101712992536016632)
,p_prompt=>unistr('Observaci\00F3n')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260521211526Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(102168385487365814)
,p_name=>'P463_IDREGISTRO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(341501209267855501)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260203053802Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(102169062555365821)
,p_name=>'P463_IDEDITAR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(341501209267855501)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260203053802Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(102170296689365833)
,p_name=>'P463_IDPAUSAR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(341501209267855501)
,p_prompt=>'New'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_updated_on=>wwv_flow_imp.dz('20260203053802Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(349044480948138618)
,p_name=>'P463_CANTESTIMADA'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(101711234345016615)
,p_prompt=>'Cant. Estimada'
,p_format_mask=>'999G999G999G990'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'1=2'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
,p_created_on=>wwv_flow_imp.dz('20260209214145Z')
,p_updated_on=>wwv_flow_imp.dz('20260521180748Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(102168465487365815)
,p_name=>'EjecutarBorradoRegistro'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P463_IDREGISTRO'
,p_condition_element=>'P463_IDREGISTRO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_updated_on=>wwv_flow_imp.dz('20260209174426Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102168596202365816)
,p_event_id=>wwv_flow_imp.id(102168465487365815)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEst\00E1 seguro de eliminar el registro?')
,p_attribute_03=>'danger'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102168631954365817)
,p_event_id=>wwv_flow_imp.id(102168465487365815)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- genero LOG',
'PK_FINZ_ACTIVOSFIJOS.SP_LOG(:G_COMPANIA,''T_FINZ_ACTIVOSFIJOSAUD'',:P463_IDREGISTRO,'''','''',''BEFORE_BORRAR'',:APP_PAGE_ID,'''',''PROGRAMACION AUDITORIA BORRADA'');',
'DELETE FROM T_FINZ_ACTIVOSFIJOSAUD ',
'WHERE ID = :P463_IDREGISTRO;',
''))
,p_attribute_02=>'P463_IDREGISTRO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_updated_on=>wwv_flow_imp.dz('20260209174426Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(349044366310138617)
,p_event_id=>wwv_flow_imp.id(102168465487365815)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20260209174425Z')
,p_updated_on=>wwv_flow_imp.dz('20260209174425Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102168864076365819)
,p_event_id=>wwv_flow_imp.id(102168465487365815)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P463_IDREGISTRO'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    :P463_IDREGISTRO := NULL;',
'END;'))
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(102169187643365822)
,p_name=>'EjecutarEditarRegistro'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P463_IDEDITAR'
,p_condition_element=>'P463_IDEDITAR'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102170140806365832)
,p_event_id=>wwv_flow_imp.id(102169187643365822)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  SELECT COMPANIA,CODTIPO,CODCATEGORIA,CODSUBCATEGORIA,PORCENTAJE,CANTITEMS,INCLUIRALASIGNAR,',
'         ESTADO,PROGRAMADA,FRECUENCIA,RECORDAR_HASTA,UMBRALDIASSINGESTION,CODUSUARIO,OBSERVACIONES',
'  INTO :P463_COMPANIA,:P463_TIPO,:P463_CATEGORIA,:P463_SUBCATEGORIA,:P463_PORCENTAJE,:P463_CANTIDADFIJA,:P463_INCLUIR,',
'       :P463_ESTADO,:P463_PROGRAMADA,:P463_FRECUENCIA,:P463_FECRECORDAR,:P463_UMBRALDIAS,:P463_USUARIORESPONSABLE,:P463_OBSERVACION',
'  FROM T_FINZ_ACTIVOSFIJOSAUD',
'  WHERE ID=:P463_IDEDITAR;',
' EXCEPTION WHEN NO_DATA_FOUND THEN NULL;',
'END;'))
,p_attribute_02=>'P463_IDEDITAR'
,p_attribute_03=>'P463_TIPO,P463_CATEGORIA,P463_SUBCATEGORIA,P463_PORCENTAJE,P463_CANTIDADFIJA,P463_INCLUIR,P463_ESTADO,P463_PROGRAMADA,P463_FRECUENCIA,P463_FECRECORDAR,P463_UMBRALDIAS,P463_USUARIORESPONSABLE,P463_OBSERVACION'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P463_IDEDITAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102169209949365823)
,p_event_id=>wwv_flow_imp.id(102169187643365822)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(101711234345016615)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102169392885365824)
,p_event_id=>wwv_flow_imp.id(102169187643365822)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P463_IDEDITAR'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    :P463_IDEDITAR := NULL;',
'END;'))
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(102170325424365834)
,p_name=>'EjecutarPausaRegistro'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P463_IDPAUSAR'
,p_condition_element=>'P463_IDPAUSAR'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_updated_on=>wwv_flow_imp.dz('20260521214048Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102170457688365835)
,p_event_id=>wwv_flow_imp.id(102170325424365834)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>unistr('\00BFEst\00E1 seguro de PAUSAR/ACTIVAR la programaci\00F3n?')
,p_attribute_03=>'danger'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102170514489365836)
,p_event_id=>wwv_flow_imp.id(102170325424365834)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- genero LOG',
'PK_FINZ_ACTIVOSFIJOS.SP_LOG(:G_COMPANIA,''T_FINZ_ACTIVOSFIJOSAUD'',:P463_IDPAUSAR,'''','''',''BEFORE_PAUSAR'',:APP_PAGE_ID,'''',''ACTIVAR/PAUSAR PROGRAMACION AUDITORIA'');',
'UPDATE T_FINZ_ACTIVOSFIJOSAUD',
'SET ESTADO=(CASE WHEN ESTADO=''ACTIVA'' THEN ''PAUSADA''',
'                 WHEN ESTADO=''PAUSADA'' THEN ''ACTIVA'' END)',
'WHERE ID=:P463_IDPAUSAR;',
'-- genero LOG',
'PK_FINZ_ACTIVOSFIJOS.SP_LOG(:G_COMPANIA,''T_FINZ_ACTIVOSFIJOSAUD'',:P463_IDPAUSAR,'''','''',''AFTER_PAUSAR'',:APP_PAGE_ID,'''',''ACTIVAR/PAUSAR PROGRAMACION AUDITORIA'');'))
,p_attribute_02=>'P463_IDPAUSAR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102170809241365839)
,p_event_id=>wwv_flow_imp.id(102170325424365834)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'  SELECT ESTADO',
'  INTO :P463_ESTADO',
'  FROM T_FINZ_ACTIVOSFIJOSAUD',
'  WHERE ID=:P463_IDPAUSAR;',
' EXCEPTION WHEN NO_DATA_FOUND THEN NULL;',
'END;'))
,p_attribute_02=>'P463_IDPAUSAR'
,p_attribute_03=>'P463_ESTADO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P463_IDPAUSAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102170696711365837)
,p_event_id=>wwv_flow_imp.id(102170325424365834)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(101711234345016615)
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P463_IDPAUSAR'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102170797269365838)
,p_event_id=>wwv_flow_imp.id(102170325424365834)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P463_IDPAUSAR'
,p_attribute_01=>'FUNCTION_BODY'
,p_attribute_06=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    :P463_IDPAUSAR := NULL;',
'END;'))
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(469082756005075106)
,p_event_id=>wwv_flow_imp.id(102170325424365834)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
,p_created_on=>wwv_flow_imp.dz('20260521214048Z')
,p_updated_on=>wwv_flow_imp.dz('20260521214048Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(102171148797365842)
,p_name=>'VALIDA_PORCENTAJE'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P463_PORCENTAJE'
,p_condition_element=>'P463_PORCENTAJE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_updated_on=>wwv_flow_imp.dz('20260209214145Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102171221842365843)
,p_event_id=>wwv_flow_imp.id(102171148797365842)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P463_CANTIDADFIJA'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(349044597951138619)
,p_event_id=>wwv_flow_imp.id(102171148797365842)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'	v_total number;',
'	v_calc  number;',
'begin',
'	select count(*)',
'	into v_total',
'	from data.t_finz_activosfijos af',
'	where 1 = 1',
'		and af.estado = ''CREADO''',
'		and (af.codtipo = :P463_TIPO or :P463_TIPO is null)',
'		and (af.codcategoria = :P463_CATEGORIA or :P463_CATEGORIA is null)',
'		and (af.codsubcategoria = :P463_SUBCATEGORIA or :P463_SUBCATEGORIA is null);',
'',
'	if :P463_PORCENTAJE is not null then',
'		v_calc := round((:P463_PORCENTAJE * v_total) / 100);',
'	else',
'		v_calc := nvl(:P463_CANTIDADFIJA, 0);',
'	end if;',
'',
'	:P463_CANTESTIMADA := least(nvl(v_calc,0), nvl(v_total,0));',
'end;',
''))
,p_attribute_02=>'P463_TIPO,P463_CATEGORIA,P463_SUBCATEGORIA,P463_PORCENTAJE,P463_CANTIDADFIJA'
,p_attribute_03=>'P463_CANTESTIMADA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20260209214145Z')
,p_updated_on=>wwv_flow_imp.dz('20260209214145Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(102171370382365844)
,p_name=>'VALIDA_CANTIDADFIJA'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P463_CANTIDADFIJA'
,p_condition_element=>'P463_CANTIDADFIJA'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
,p_updated_on=>wwv_flow_imp.dz('20260209214145Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(102171414761365845)
,p_event_id=>wwv_flow_imp.id(102171370382365844)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P463_PORCENTAJE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(349044746637138621)
,p_event_id=>wwv_flow_imp.id(102171370382365844)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'	v_total number;',
'	v_calc  number;',
'begin',
'	select count(*)',
'	into v_total',
'	from data.t_finz_activosfijos af',
'	where 1 = 1',
'		and af.estado = ''CREADO''',
'		and (af.codtipo = :P463_TIPO or :P463_TIPO is null)',
'		and (af.codcategoria = :P463_CATEGORIA or :P463_CATEGORIA is null)',
'		and (af.codsubcategoria = :P463_SUBCATEGORIA or :P463_SUBCATEGORIA is null);',
'',
'	if :P463_PORCENTAJE is not null then',
'		v_calc := round((:P463_PORCENTAJE * v_total) / 100);',
'	else',
'		v_calc := nvl(:P463_CANTIDADFIJA, 0);',
'	end if;',
'',
'	:P463_CANTESTIMADA := least(nvl(v_calc,0), nvl(v_total,0));',
'end;',
''))
,p_attribute_02=>'P463_TIPO,P463_CATEGORIA,P463_SUBCATEGORIA,P463_PORCENTAJE,P463_CANTIDADFIJA'
,p_attribute_03=>'P463_CANTESTIMADA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
,p_created_on=>wwv_flow_imp.dz('20260209214145Z')
,p_updated_on=>wwv_flow_imp.dz('20260209214145Z')
,p_created_by=>'DDELACRUZ'
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(102167980330365810)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Graba Auditoria'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_maxid			number := 0;',
'v_proximaeje	date;',
'v_codaumento	varchar2(10);',
'v_valaumento	number;',
'v_log_app		varchar2(100);',
'v_log_dsc		varchar2(999);',
'v_log_msg		varchar2(999);',
'v_log_obs		varchar2(999);',
'begin',
'	v_log_app := ''apex.109.463.grabauditoria'';',
unistr('	v_log_dsc := ''Par\00E1metros: compania=''||:p463_compania||'', tipo=''||:p463_tipo||'', categoria=''||:p463_categoria||'', frecuencia=''||:p463_frecuencia||'', programada=''||:p463_programada;'),
'',
'	-- LOG 1: Inicio del procedimiento',
unistr('	v_log_msg := ''INICIO: Crear auditor\00EDa de activos fijos'';'),
unistr('	v_log_obs := ''Usuario APEX: ''||:app_user||'', Compa\00F1\00EDa: ''||:p463_compania;'),
'	data.pk_commons.sp_apex_log(v_log_app,1,v_log_dsc,v_log_msg,v_log_obs,null);',
'',
unistr('	-- LOG 2: Validar par\00E1metro PROGRAMADA (cr\00EDtico)'),
unistr('	v_log_msg := ''Validando par\00E1metro PROGRAMADA'';'),
'	v_log_obs := ''PROGRAMADA=''||:p463_programada||'' (S=programada, N=manual)'';',
'	data.pk_commons.sp_apex_log(v_log_app,2,v_log_dsc,v_log_msg,v_log_obs,null);',
'',
'	if :p463_programada = ''S'' then',
'		-- LOG 3: Validar FRECUENCIA (solo si PROGRAMADA=''S'')',
'		v_log_msg := ''PROGRAMADA=S: Validando FRECUENCIA en UDC'';',
'		v_log_obs := ''Buscando: id_cabecera=APEX, id_tabla=FRECUENCIA, valor=''||:p463_frecuencia;',
'		data.pk_commons.sp_apex_log(v_log_app,3,v_log_dsc,v_log_msg,v_log_obs,null);',
'',
'		begin',
'			select	valor2',
'				, to_number(valor3)',
'			into	v_codaumento',
'				, v_valaumento',
'			from data.t_corp_udc',
'			where 1 = 1',
'				and id_cabecera = ''APEX''',
'				and id_tabla = ''FRECUENCIA''',
'				and valor = :p463_frecuencia;',
'',
'			v_log_msg := ''Frecuencia encontrada en UDC'';',
'			v_log_obs := ''FRECUENCIA=''||:p463_frecuencia||'', codaumento=''||v_codaumento||'', valaumento=''||v_valaumento;',
'			data.pk_commons.sp_apex_log(v_log_app,3,v_log_dsc,v_log_msg,v_log_obs,null);',
'',
'			exception',
'			when no_data_found then',
'				v_log_msg := ''ERROR: Frecuencia NO encontrada en UDC'';',
'				v_log_obs := ''FRECUENCIA=''||:p463_frecuencia||'' no existe en tabla data.t_corp_udc (id_cabecera=APEX, id_tabla=FRECUENCIA)'';',
'				data.pk_commons.sp_apex_log(v_log_app,-1,v_log_dsc,v_log_msg,v_log_obs,null);',
unistr('				raise_application_error(-20001, ''Error al crear auditor\00EDa: Frecuencia ''||:p463_frecuencia||'' no configurada en sistema. Verifica tabla UDC.'');'),
'			when too_many_rows then',
unistr('				v_log_msg := ''ERROR: M\00FAltiples registros para la misma frecuencia'';'),
unistr('				v_log_obs := ''FRECUENCIA=''||:p463_frecuencia||'' devolvi\00F3 m\00E1s de una fila en data.t_corp_udc'';'),
'				data.pk_commons.sp_apex_log(v_log_app,-2,v_log_dsc,v_log_msg,v_log_obs,null);',
unistr('				raise_application_error(-20002, ''Error de configuraci\00F3n: Frecuencia duplicada en tabla UDC.'');'),
'		end;',
'',
unistr('		-- LOG 4: Calcular pr\00F3xima ejecuci\00F3n (PROGRAMADA=''S'')'),
unistr('		v_log_msg := ''Calculando pr\00F3xima ejecuci\00F3n (PROGRAMADA=S)'';'),
'		v_log_obs := ''codaumento=''||v_codaumento||'', valaumento=''||v_valaumento;',
'		data.pk_commons.sp_apex_log(v_log_app,4,v_log_dsc,v_log_msg,v_log_obs,null);',
unistr('		v_log_msg := ''PROGRAMADA=S: Calculando pr\00F3xima ejecuci\00F3n'';'),
'		if v_codaumento = ''M'' then',
'			v_proximaeje := add_months(trunc(sysdate), v_valaumento);',
unistr('			v_log_obs := ''codaumento=M (mensual), valaumento=''||v_valaumento||'' meses. Primera pr\00F3xima eje: ''||v_proximaeje;'),
'		elsif v_codaumento = ''D'' then',
'			v_proximaeje := trunc(sysdate) + v_valaumento;',
unistr('			v_log_obs := ''codaumento=D (diaria), valaumento=''||v_valaumento||'' d\00EDas. Primera pr\00F3xima eje: ''||v_proximaeje;'),
'		else',
'			v_log_msg := ''ERROR: codaumento no soportado'';',
'			v_log_obs := ''codaumento=''||v_codaumento||'' no es M ni D'';',
'			data.pk_commons.sp_apex_log(v_log_app,4,v_log_dsc,v_log_msg,v_log_obs,null);',
'			raise_application_error(-20001, ''Tipo de aumento no soportado: '' || v_codaumento);',
'		end if;',
'		data.pk_commons.sp_apex_log(v_log_app,4,v_log_dsc,v_log_msg,v_log_obs,null);',
'',
unistr('		-- LOG 5: Catch-up si pr\00F3xima eje est\00E1 en pasado'),
unistr('		v_log_msg := ''Validando pr\00F3xima ejecuci\00F3n (catch-up si est\00E1 en pasado)'';'),
'		v_log_obs := ''v_proximaeje=''||v_proximaeje||'', hoy=''||trunc(sysdate);',
'		data.pk_commons.sp_apex_log(v_log_app,5,v_log_dsc,v_log_msg,v_log_obs,null);',
'',
'		if v_proximaeje <= trunc(sysdate) then',
unistr('			v_log_msg := ''Pr\00F3xima ejecuci\00F3n en pasado, aplicando catch-up'';'),
'			v_log_obs := ''v_proximaeje (''||v_proximaeje||'') <= hoy (''||trunc(sysdate)||''). Avanzando...'';',
'			while v_proximaeje <= trunc(sysdate) loop',
'				if v_codaumento = ''M'' then',
'					v_proximaeje := add_months(v_proximaeje, v_valaumento);',
'				elsif v_codaumento = ''D'' then',
'					v_proximaeje := v_proximaeje + v_valaumento;',
'				end if;',
unistr('				v_log_obs := v_log_obs||chr(10)||''Iteraci\00F3n: v_proximaeje=''||v_proximaeje;'),
'			end loop;',
'			data.pk_commons.sp_apex_log(v_log_app,5,v_log_dsc,v_log_msg,v_log_obs,null);',
'		else',
unistr('			v_log_msg := ''Pr\00F3xima ejecuci\00F3n v\00E1lida (en futuro)'';'),
'			v_log_obs := ''v_proximaeje=''||v_proximaeje||'' > hoy=''||trunc(sysdate);',
'			data.pk_commons.sp_apex_log(v_log_app,5,v_log_dsc,v_log_msg,v_log_obs,null);',
'		end if;',
'	else',
unistr('		-- PROGRAMADA = ''N'': Auditor\00EDa puntual, sin validaci\00F3n de FRECUENCIA'),
'		v_proximaeje := trunc(sysdate);',
unistr('		v_log_msg := ''PROGRAMADA=N: Auditor\00EDa manual/puntual (sin validaci\00F3n de FRECUENCIA)'';'),
unistr('		v_log_obs := ''Se omite validaci\00F3n UDC. v_proximaeje=''||v_proximaeje||'' (hoy). Ejecuta inmediatamente.'';'),
'		data.pk_commons.sp_apex_log(v_log_app,3,v_log_dsc,v_log_msg,v_log_obs,null);',
'	end if;',
'',
unistr('	-- LOG 6: Validar que no exista auditor\00EDa activa/pausada con mismos criterios'),
unistr('	v_log_msg := ''Validando unicidad de auditor\00EDa'';'),
'	v_log_obs := ''Verificando: compania=''||:p463_compania||'', tipo=''||:p463_tipo||'', categoria=''||:p463_categoria||'', subcategoria=''||:p463_subcategoria;',
'	data.pk_commons.sp_apex_log(v_log_app,6,v_log_dsc,v_log_msg,v_log_obs,null);',
'',
'	-- LOG 7: Insertando registro',
unistr('	v_log_msg := ''Insertando auditor\00EDa en t_finz_activosfijosaud'';'),
'	v_log_obs := ''compania=''||:p463_compania||'', estado=''||:p463_estado||'', programada=''||:p463_programada||'', proximaeje=''||v_proximaeje;',
'	data.pk_commons.sp_apex_log(v_log_app,7,v_log_dsc,v_log_msg,v_log_obs,null);',
'',
'	insert into data.t_finz_activosfijosaud (',
'		compania',
'		, codtipo',
'		, codcategoria',
'		, codsubcategoria',
'		, porcentaje',
'		, cantitems',
'		, incluiralasignar',
'		, estado',
'		, programada',
'		, frecuencia',
'		, recordar_hasta',
'		, umbraldiassingestion',
'		, codusuario',
'		, observaciones',
'		, proximaeje',
'	)',
'	select',
'		:p463_compania',
'		, :p463_tipo',
'		, :p463_categoria',
'		, :p463_subcategoria',
'		, :p463_porcentaje',
'		, :p463_cantidadfija',
'		, :p463_incluir',
'		, :p463_estado',
'		, :p463_programada',
'		, :p463_frecuencia',
'		, :p463_fecrecordar',
'		, :p463_umbraldias',
'		, :p463_usuarioresponsable',
'		, :p463_observacion',
'		, v_proximaeje',
'	from dual',
'	where not exists (',
'		select ''X''',
'		from data.t_finz_activosfijosaud',
'		where 1 = 1',
'			and compania = :p463_compania',
'			and codtipo = :p463_tipo',
'			and codcategoria = :p463_categoria',
'			and codsubcategoria = :p463_subcategoria',
'			and estado in (''ACTIVA'', ''PAUSADA'')',
'	);',
'',
'	if sql%rowcount = 0 then',
unistr('		v_log_msg := ''ADVERTENCIA: No se insert\00F3 registro (auditor\00EDa duplicada)'';'),
unistr('		v_log_obs := ''Ya existe auditor\00EDa ACTIVA o PAUSADA con los mismos criterios. Compania=''||:p463_compania||'', tipo=''||:p463_tipo;'),
'		data.pk_commons.sp_apex_log(v_log_app,7,v_log_dsc,v_log_msg,v_log_obs,null);',
unistr('		raise_application_error(-20003, ''Auditor\00EDa duplicada: Ya existe una auditor\00EDa activa o pausada con estos criterios.'');'),
'	end if;',
'',
unistr('	v_log_msg := ''Inserci\00F3n exitosa en t_finz_activosfijosaud'';'),
'	v_log_obs := ''sql%rowcount=''||sql%rowcount||'' registros insertados'';',
'	data.pk_commons.sp_apex_log(v_log_app,7,v_log_dsc,v_log_msg,v_log_obs,null);',
'',
unistr('	-- LOG 8: Obtener ID de la auditor\00EDa creada'),
unistr('	v_log_msg := ''Obteniendo ID de auditor\00EDa creada'';'),
'	begin',
'		select max(id) into v_maxid from data.t_finz_activosfijosaud;',
'		v_log_obs := ''v_maxid=''||v_maxid;',
'		data.pk_commons.sp_apex_log(v_log_app,8,v_log_dsc,v_log_msg,v_log_obs,null);',
'',
'		exception when others then',
'			v_log_msg := ''ERROR al obtener max(id)'';',
'			v_log_obs := ''sqlerrm=''||sqlerrm;',
'			data.pk_commons.sp_apex_log(v_log_app,8,v_log_dsc,v_log_msg,v_log_obs,null);',
'			raise;',
'	end;',
'',
'	-- LOG 9: Si PROGRAMADA=''N'', ejecutar sp_generaauditorias inmediatamente',
'	if :p463_programada = ''N'' then',
'		v_log_msg := ''PROGRAMADA=N: Ejecutando sp_generaauditorias inmediatamente'';',
'		v_log_obs := ''p_idauditoria=''||v_maxid||'', p_compania=''||:g_compania||'', p_usuario=''||:app_user;',
'		data.pk_commons.sp_apex_log(v_log_app,9,v_log_dsc,v_log_msg,v_log_obs,null);',
'',
'		begin',
'			data.pk_finz_activosfijos.sp_generaauditorias(',
'				p_compania => :g_compania',
'				, p_usuario => :app_user',
'				, p_idauditoria => v_maxid',
'			);',
'			v_log_msg := ''sp_generaauditorias ejecutado exitosamente'';',
unistr('			v_log_obs := ''Generados levantamientos para auditor\00EDa ID=''||v_maxid;'),
'			data.pk_commons.sp_apex_log(v_log_app,9,v_log_dsc,v_log_msg,v_log_obs,null);',
'',
'			exception when others then',
'				v_log_msg := ''ERROR en sp_generaauditorias'';',
'				v_log_obs := ''p_idauditoria=''||v_maxid||'', sqlerrm=''||sqlerrm;',
'				data.pk_commons.sp_apex_log(v_log_app,9,v_log_dsc,v_log_msg,v_log_obs,null);',
'				raise;',
'		end;',
'	else',
unistr('		v_log_msg := ''PROGRAMADA=S: sp_generaauditorias se ejecutar\00E1 por job diario'';'),
unistr('		v_log_obs := ''La auditor\00EDa se ejecutar\00E1 cuando PROXIMAEJE coincida con fecha de ejecuci\00F3n del job'';'),
'		data.pk_commons.sp_apex_log(v_log_app,9,v_log_dsc,v_log_msg,v_log_obs,null);',
'	end if;',
'',
unistr('	-- LOG 10: Commit y limpieza de par\00E1metros'),
'	commit;',
'	v_log_msg := ''COMMIT realizado exitosamente'';',
unistr('	v_log_obs := ''Auditor\00EDa creada con ID=''||v_maxid||'', PROGRAMADA=''||:p463_programada||'', PROXIMAEJE=''||v_proximaeje;'),
'	data.pk_commons.sp_apex_log(v_log_app,10,v_log_dsc,v_log_msg,v_log_obs,null);',
'',
'	:p463_compania := null;',
'	:p463_tipo := null;',
'	:p463_categoria := null;',
'	:p463_subcategoria := null;',
'	:p463_porcentaje := null;',
'	:p463_cantidadfija := null;',
'	:p463_incluir := null;',
'	:p463_estado := null;',
'	:p463_programada := null;',
'	:p463_frecuencia := null;',
'	:p463_fecrecordar := null;',
'	:p463_umbraldias := null;',
'	:p463_usuarioresponsable := null;',
'	:p463_observacion := null;',
'',
unistr('	v_log_msg := ''FIN: Auditor\00EDa creada exitosamente'';'),
unistr('	v_log_obs := ''ID=''||v_maxid||''. Par\00E1metros APEX limpiados.'';'),
'	data.pk_commons.sp_apex_log(v_log_app,10,v_log_dsc,v_log_msg,v_log_obs,null);',
'',
'	exception when others then',
'		rollback;',
unistr('		v_log_msg := ''EXCEPCI\00D3N no manejada'';'),
'		v_log_obs := ''sqlcode=''||sqlcode||'', sqlerrm=''||sqlerrm;',
'		data.pk_commons.sp_apex_log(v_log_app,99,v_log_dsc,v_log_msg,v_log_obs,null);',
'		apex_debug.error(''ERROR en procedimiento: '' || sqlerrm);',
unistr('		raise_application_error(-20000, ''Error al crear auditor\00EDa: '' || sqlerrm);'),
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(101711077293016613)
,p_internal_uid=>102167980330365810
,p_updated_on=>wwv_flow_imp.dz('20260522065905Z')
,p_updated_by=>'DDELACRUZ'
);
wwv_flow_imp.component_end;
end;
/
