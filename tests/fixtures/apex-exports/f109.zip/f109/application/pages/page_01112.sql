prompt --application/pages/page_01112
begin
--   Manifest
--     PAGE: 01112
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.3'
,p_default_workspace_id=>1282803584972340
,p_default_application_id=>109
,p_default_id_offset=>0
,p_default_owner=>'DATA'
);
wwv_flow_imp_page.create_page(
 p_id=>1112
,p_name=>unistr('Env\00EDo de Tasas')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Env\00EDo de Tasas')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'17'
,p_created_on=>wwv_flow_imp.dz('20230705164635Z')
,p_last_updated_on=>wwv_flow_imp.dz('20210526050000Z')
,p_last_updated_by=>'DDELACRUZ'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(537765898799717640)
,p_plug_name=>unistr('Par\00E1metros')
,p_region_template_options=>'#DEFAULT#:t-Form--large:t-Form--stretchInputs:t-Form--leftLabels'
,p_plug_template=>wwv_flow_imp.id(38289867500120143)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(537766646311717648)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(537765898799717640)
,p_button_name=>'ENVIAR'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(37860181880106559)
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Env\00EDar')
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(537766088182717642)
,p_name=>'P1112_DIVISION'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(537765898799717640)
,p_prompt=>unistr('Divisi\00F3n')
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'LOV_UNPADRE'
,p_lov=>'select drdl01,drky from vt_jde_udcjde where DRSY = ''00'' and DRRT = ''50'' and drky is not null order by drdl01'
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'3'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(537766156469717643)
,p_name=>'P1112_DESTINATARIO'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(537765898799717640)
,p_prompt=>'Destinatario(s):'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select apellidos||'' ''||nombres d, lower(email) r',
'from vt_corp_usuario where estado = 1 and apellidos is not null and nombres is not null and pk_commons.f_escorreo(email) = 1 order by 1'))
,p_cHeight=>5
,p_field_template=>wwv_flow_imp.id(37859428400106557)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'MOVE'
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(537766253603717644)
,p_name=>'P1112_IDCAB'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(537765898799717640)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(537766381922717645)
,p_name=>'P1112_ANNO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(537765898799717640)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(537766492205717646)
,p_name=>'P1112_MES'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(537765898799717640)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(537766545993717647)
,p_name=>'P1112_NUMEROVERSION'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(537765898799717640)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(537766896405717650)
,p_name=>unistr('Env\00EDar')
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(537766646311717648)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(538863041010470001)
,p_event_id=>wwv_flow_imp.id(537766896405717650)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'mostrarBarra();'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(538863238639470003)
,p_event_id=>wwv_flow_imp.id(537766896405717650)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'v_contenido	clob;',
'v_tabla 	clob;',
'v_log_app    varchar2(100);',
'v_log_sub    varchar2(100);',
'v_log_des    varchar2(500);',
'v_log_cco    varchar2(100);',
'v_log_rem    varchar2(100);',
'cursor uns is',
'	select distinct anno,mes,numeroversion,codigodivision,descripciondivision from vt_finz_costeo',
'	where idcab = :p1112_idcab and codigodivision in (',
'		select regexp_substr(:p1112_division,''[^:]+'', 1, level) codigodivision',
'		from dual connect by regexp_substr(:p1112_division, ''[^:]+'',1, level) is not null) order by codigodivision;',
'begin',
'	v_contenido := null; v_tabla := null;',
'    v_log_app := ''pk_finz_costeo'';',
'    v_log_rem := ''finanzas@zaimella.com'';',
'',
'    select replace(:p1112_destinatario,'':'','',''),email into v_log_des,v_log_cco from vt_corp_usuario',
'    where nombreusuario = :app_user and pk_commons.f_escorreo(email) = 1;',
'    insert into t_apex_temporal (flag,txt01) select v_log_app,:p1112_destinatario from dual;',
'',
'	for un in uns loop',
'        v_log_sub := ''Tasas de Manufactura, ''||to_char(to_date(:p1112_anno||:p1112_mes,''yyyymm''),''mon-yyyy'')||'': ''||un.descripciondivision;',
'',
'        v_contenido := ''<div>'' || utl_tcp.crlf;',
'		v_contenido := v_contenido || ''<h2>'' || un.descripciondivision || ''</h2>'' || utl_tcp.crlf;',
'		pk_finz_costeo.sp_construyetasas(:g_compania,:app_user,:p1112_anno,:p1112_mes,:p1112_numeroversion,un.codigodivision,v_tabla);',
'		v_contenido := v_contenido || v_tabla || ''</br>'' ||utl_tcp.crlf;',
'        v_contenido := v_contenido || ''</div>'' || utl_tcp.crlf;        ',
'',
'        pk_commons.sp_apex_correohtml(v_contenido,v_contenido);',
'        v_contenido := regexp_replace(v_contenido,''<span.*?span>'',null);',
'        pk_commons.sp_apex_correo(v_log_app,v_log_rem,v_log_des,v_log_cco,null,v_log_sub,v_contenido);',
'		v_contenido := null; v_tabla := null;',
'	end loop;    ',
'end;'))
,p_attribute_02=>'P1112_IDCAB,P1112_DIVISION,P1112_DESTINATARIO,APP_USER'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(538863139892470002)
,p_event_id=>wwv_flow_imp.id(537766896405717650)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'ocultarBarra();'
);
wwv_flow_imp.component_end;
end;
/
